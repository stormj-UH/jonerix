# exproxide

Clean-room Rust implementation of `expr` for jonerix.

The implementation is developed from public documentation, black-box behavior
of compiled `expr` binaries, and test suites. GNU coreutils implementation
source code is not used.

## Compatibility Mode

Set `exproxide_test_mode=TRUE` to make diagnostics target GNU `gexpr`
compatibility for oracle tests.

```sh
exproxide_test_mode=TRUE cargo test
```

## Testing

Local tests include Rust unit tests and black-box oracle tests. If
`EXPR_ORACLE` is set, tests compare stdout, stderr, and exit status against
that binary.

```sh
EXPR_ORACLE=/opt/homebrew/bin/gexpr cargo test
cargo build
./tools/oracle_sweep.py
```

Current status: the implementation passes the custom oracle sweep against GNU
coreutils `gexpr` and the extracted upstream coreutils 9.10 `tests/expr/expr.pl`
suite. Covered behavior includes arithmetic, logical operators, comparisons,
parenthesized expressions, string functions, anchored BRE matching, back
references, interval expressions, and common diagnostics. Broader compatibility
should still be tested against additional real-world `expr` workloads.

Upstream coreutils test inputs and generated binary-analysis output belong
under `cleanroom/private/`, which is intentionally ignored by git. Do not
extract or inspect GNU coreutils implementation source files.

```sh
mkdir -p cleanroom/private/upstream
cd cleanroom/private/upstream
curl -fsSLO https://ftp.gnu.org/gnu/coreutils/coreutils-9.10.tar.xz
mkdir -p coreutils-9.10-tests
tar -xf coreutils-9.10.tar.xz -C coreutils-9.10-tests --strip-components=1 \
  coreutils-9.10/tests/expr coreutils-9.10/tests/Coreutils.pm
cd ../../..
./tools/run_upstream_expr_tests.py cleanroom/private/upstream/coreutils-9.10-tests
```
