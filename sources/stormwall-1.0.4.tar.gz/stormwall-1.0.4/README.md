# stormwall

Pure Rust firewall front-end that speaks both Linux **nft** and OpenBSD **pf**.
One binary, two DSLs, same in-kernel nftables backend.

Talks directly to the kernel's nf_tables subsystem via netlink — no libnftnl,
no libmnl, no C dependencies. Statically links against musl for a single,
zero-dependency binary.

**Version 1.0.4** | [Releases](https://castle.great-morpho.ts.net:3000/jonerik/stormwall/releases) | MIT license

## Quick start

```sh
# jonerix
jpkg install stormwall

# Or from source
cargo build --release        # -> target/release/stormwall + target/release/pfctl
```

The build produces two binaries:

| Binary | Purpose |
|--------|---------|
| `stormwall` | nft-compatible CLI (also installs as an `nft` symlink) |
| `pfctl` | FreeBSD-compatible pfctl(8) shim for pfSense on Linux |

```sh
# nft mode — same syntax as the upstream nft CLI
stormwall add table inet filter
stormwall add chain inet filter input '{ type filter hook input priority filter; policy drop; }'
stormwall add rule inet filter input ct state established,related accept
stormwall add rule inet filter input tcp dport 22 accept
stormwall list ruleset

# Load from file
stormwall -f /etc/nftables.conf

# pf mode — translate a BSD pf.conf to nftables and apply it
stormwall --pf /etc/pf.conf

# Parse-only (no root needed, no kernel interaction)
stormwall --pf --dump-exprs -f /etc/pf.conf
```

## nft compatibility

### Supported operations

| Command | Status |
|---------|--------|
| `add/create/delete/destroy table` | Working |
| `add/create/delete chain` (base + regular) | Working |
| `add/insert/delete rule` | Working |
| `list table/tables/chain/chains/rules/ruleset` | Working |
| `list sets/maps/counters/quotas/limits/objects/flowtables` | Working |
| `flush table/chain/ruleset` | Working |
| `rename chain` | Working |
| `add/delete set`, `add/delete element` | Working |
| `reset rules/counters/quotas` | Working |
| Named objects: counter, quota, limit, ct helper/timeout/expectation, synproxy, secmark, tunnel | Working |
| `-f` file input, `-i` interactive REPL | Working |
| `-a` show handles, `-s` stateless, `-c` check | Working |
| `-j` JSON output | Working (20/20) |
| `-nn`/`-y`/`-p` numeric output | Working (6/6) |
| `define`/`redefine`/`undefine` (incl. hyphenated names) | Working |

### Rule expressions

| Expression | Status |
|-----------|--------|
| `ip saddr/daddr`, `ip6 saddr/daddr` | Working |
| `tcp/udp sport/dport`, `tcp flags` (incl. masked `&`) | Working |
| `icmp type/code`, `icmpv6 type/code` | Working |
| `ether saddr/daddr/type`, `ip dscp` | Working |
| `meta iifname/oifname/mark/l4proto/skuid/length` | Working |
| `ct state/mark/status/zone`, `ct helper` | Working |
| `counter`, `log`, `limit rate` | Working |
| Named counters, quotas, limits | Working |
| `accept/drop/return/jump/goto/continue` | Working |
| Anonymous chain bindings (`jump { ... }`, `goto { ... }`) | Working |
| `masquerade/snat/dnat` | Working |
| `notrack`, `reject`, `dup`, `fwd`, `synproxy` | Working |
| Anonymous and named sets, interval sets, maps, vmaps | Working |
| Dynamic sets (timeout, `flags dynamic`) | Working |
| `lookup` (set/map reference) | Working |
| `fib`, `jhash`, `numgen`, `socket`, `rt` | Working |
| `flowtable` | Working |
| `define` variable substitution | Working |
| CIDR matching, bitwise mask/xor | Working |

### Consumer compatibility

Wrappers and management tools that call `nft` under the hood work transparently
when stormwall is symlinked as `/usr/sbin/nft`:

- **firewalld** — zone/service/rich-rule operations (9/9 smoke tests)
- **iptables-translate** — 10/10 common rule shapes
- **fail2ban** — jail ban/unban via nftables backend
- **ufw** — tested via consumer-matrix harness

## pf.conf translation

stormwall's `--pf` mode parses OpenBSD `pf.conf` syntax and emits equivalent
nftables rules. A `pf.conf` carried over from a BSD box runs unmodified on
Linux.

**21/21 pf-parity tests pass** — expression-level byte equivalence against
upstream `nft --debug=netlink`. The test harness (`tests/pf-parity.sh`) runs
entirely offline (no root, no kernel) by comparing bracketed netlink IR.

### pf features covered

| Feature | Tests | Notes |
|---------|:-----:|-------|
| scrub (no-df, random-id, min-ttl, max-mss) | 5 | Packet normalization |
| Source tracking (max-src-conn, rate, states, overload) | 4 | Connection limiting |
| antispoof | 1 | Interface-based spoofing prevention |
| set skip on lo | 1 | Loopback bypass |
| Time-based rules | 1 | Schedule matching |
| block return-rst | 1 | TCP reset on block |
| log | 1 | pflog integration |
| Routing actions (route-to, reply-to, dup-to) | 1 | Policy routing |
| NAT (rdr-to, nat-to) | 1 | DNAT + SNAT |
| Tables (persist) | 1 | Named address tables |
| Anchors | 1 | Nested rulesets |
| State flags (keep, modulate, synproxy) | 1 | Stateful inspection |
| Queue (ALTQ via TC) | 1 | Traffic shaping |

### pfctl shim

`pfctl` (`src/pfctl_main.rs`, 1074 lines) provides a FreeBSD-compatible
pfctl(8) CLI. pfSense's PHP web UI calls it directly for all firewall
operations.

| Operation | Flags |
|-----------|-------|
| Rule loading | `-f file`, `-n` (check-only), `-O` (optimise) |
| Daemon mode | `-D` (stay resident, SIGHUP reload, SIGTERM exit, PID file) |
| Show | `-sr` `-sn` `-ss` `-si` `-sa` `-sT` `-st` `-sm` `-sI` `-s queue` |
| Flush | `-F states` `-F Sources` `-F all` |
| Tables | `-t NAME -T show/add/delete/flush/kill` |
| Kill states | `-k host`, `-k gw -k ip` via conntrack(8) + `/proc` fallback |
| Enable/disable | `-e` / `-d` |
| TC queues | HTB/HFSC/PRIO via `src/tc.rs` |

## pfSense Docker container

`docker/pfsense/` runs the pfSense CE web UI natively on Linux. stormwall's
pfctl binary replaces FreeBSD's, and a PHP compatibility layer translates
BSD system calls to Linux equivalents.

```sh
docker build -f docker/pfsense/Dockerfile -t stormwall-pfsense .
docker run -d --name pfsense --cap-add NET_ADMIN -p 8443:443 stormwall-pfsense
# Login: admin / stormwall
```

**20/20 page tests pass** (login, dashboard, all firewall/status/system pages):

| Category | Pages tested | Status |
|----------|:------------:|:------:|
| Dashboard + login | 1 | Pass |
| Firewall (rules, NAT, aliases, schedules) | 5 | Pass |
| Status (dashboard, filter reload) | 2 | Pass |
| Diagnostics (pfInfo, states, ARP, DNS, command) | 5 | Pass |
| Interfaces (WAN, assignments) | 2 | Pass |
| Services (DHCP) | 1 | Pass |
| System (general, users, admin, certs) | 4 | Pass |

Architecture: nginx → PHP-FPM 8.2 → pfSense PHP (Apache 2.0) → pfctl/stormwall → kernel nf_tables.

## Test suites

### How to run

```sh
# Unit tests (parser + output, no root needed)
cargo test

# pf-parity (offline, no root)
./tests/pf-parity.sh ./target/release/stormwall

# Integration tests (root + Linux nf_tables kernel module)
cargo test -- --ignored
bash tests/stormwall_test.sh
```

### nft test results

| Harness | What it tests | Result |
|---------|---------------|--------|
| `stormwall_test.sh` | Core nft compatibility (file, JSON, round-trip, ct, meta, NAT) | **25/25** |
| `monitor-diff.sh` | 45 rulesets: monitor event parity vs upstream nft | **45/45** |
| `traffic-parity.sh` | 16 ruleset shapes, real veth pair, accept/drop per rule | **16/16** |
| `traffic-parity-ipv6.sh` | IPv6 rules, real packets through kernel | **18/18** |
| `traffic-parity-bridge.sh` | Bridge/L2 rules, 3-netns setup | **9/12** (3 env issues) |
| `traffic-nat.sh` | masquerade, snat, dnat, negative case | **4/4** |
| `fuzz-parity.sh` | 50 random rulesets, apply+list compare vs nft | **50/50** |
| `iperf3-throughput.sh` | Throughput vs nft under load (6 scenarios) | **6/6** (0.81–1.03x) |
| `nft-check-parity.sh` | `-c` flag validation (35-case corpus) | **34/35** |
| `json-parity.sh` | `-j list ruleset` JSON shape (20-case corpus) | **20/20** |
| `iptables-translate-parity.sh` | iptables-translate wrapper (10 rule shapes) | **10/10** |
| `firewalld-smoke.sh` | firewalld/fail2ban/ufw consumer compat | **9/9** |
| `concurrent-writers.sh` | 8-worker kernel contention, EBUSY/EAGAIN | **4/4** |
| `numeric-output-parity.sh` | `-nn`/`-y`/`-p` numeric output (6 rulesets × 3 modes) | **6/6** |
| `upstream-nft-suite.sh` | Upstream nftables shell suite (22 categories, 493 tests) | **487/493** (99%) |
| Dump parse coverage | Parser `-c` accepts upstream nft dump files | **142/142** (100%) |

#### Upstream nftables shell suite breakdown

Tested on Raspberry Pi 5 (aarch64, kernel 6.18, Debian trixie).

| Category | Pass | Skip | Fail | Total |
|----------|-----:|-----:|-----:|------:|
| sets | 108 | 0 | 0 | 108 |
| chains | 53 | 0 | 0 | 53 |
| transactions | 48 | 4 | 0 | 52 |
| maps | 49 | 0 | 0 | 49 |
| nft-f | 35 | 1 | 0 | 36 |
| packetpath | 31 | 0 | 0 | 31 |
| listing | 25 | 0 | 0 | 25 |
| optimizations | 24 | 0 | 0 | 24 |
| include | 22 | 0 | 0 | 22 |
| bitwise | 17 | 0 | 0 | 17 |
| flowtable | 16 | 0 | 0 | 16 |
| rule_management | 12 | 0 | 0 | 12 |
| cache | 11 | 0 | 0 | 11 |
| optionals | 11 | 0 | 0 | 11 |
| json | 10 | 0 | 0 | 10 |
| parsing | 4 | 1 | 0 | 5 |
| netns | 3 | 0 | 0 | 3 |
| nft-i | 3 | 0 | 0 | 3 |
| owner | 2 | 0 | 0 | 2 |
| comments | 1 | 0 | 0 | 1 |
| bogons | 1 | 0 | 0 | 1 |
| trace | 1 | 0 | 0 | 1 |
| **Total** | **487** | **6** | **0** | **493** |

The 6 skipped tests are all stress/performance tests (large rulesets, 30-second
stress loops) that upstream nft also skips by default.

### pf test results

| Harness | What it tests | Result |
|---------|---------------|--------|
| `pf-parity.sh` | 21 pf→nft expression-level parity vs `nft --debug=netlink` | **21/21** |
| pfSense Docker | 20 page tests (login, dashboard, firewall, status, system) | **20/20** |

### Performance

| Scenario | stormwall | nft | Ratio |
|----------|----------:|----:|------:|
| Throughput, no rules | 1960 Mbps | 1900 Mbps | 1.03x |
| Throughput, 100 rules | 1073 Mbps | 1320 Mbps | 0.81x |
| Single op latency | 80 ms | 88 ms | 0.9x |

The ct-soak 52% stateful gap is a thermal artifact from sequential 5-minute
arms on the RPi5 test host. Alternating 10-second measurements show 0.97–1.12x.
See `tests/ct-state-perf-investigation.md`.

## Architecture

```
src/
  parser.rs       7688 lines   Tokenizer + nft command parser
  ops.rs          5129 lines   nftables CRUD via netlink batches
  output.rs       4418 lines   Format kernel data back to nft syntax
  pf_parser.rs    2663 lines   pf.conf parser + nft lowering
  netlink.rs      1547 lines   Raw netlink socket, message builder
  pfctl_main.rs   1096 lines   pfctl(8) shim for pfSense
  tc.rs            968 lines   TC queue setup (HTB/HFSC/PRIO)
  templates.rs     692 lines   Compiled rule templates
  main.rs          491 lines   CLI entry point, option parsing
  json.rs          183 lines   JSON output formatter
                 ─────────
                 24875 lines total
```

Single dependency: `libc` (socket syscalls). Everything else is implemented
from scratch against the nf_tables netlink protocol.

Unsafe code is confined to 6 libc calls in `netlink.rs` (socket, bind,
getsockname, send, recv, close). All message construction, parsing, and
output formatting is safe Rust.

## Environment variables

| Variable | Effect |
|----------|--------|
| `STORMWALL_TEST_MODE=1` | Impersonate upstream nft 1.1.3 for version-string checks |
| `STORMWALL_NLDUMP=path` | Dump outgoing netlink bytes to file instead of sending to kernel |
| `STORMWALL_PF_CBQ_FALLBACK=hfsc\|error` | CBQ qdisc fallback (removed in Linux 6.5+) |
| `PFCTL_PID_FILE=path` | Override pfctl daemon PID file location |

## Known gaps

- **JSON input** (`-j -f file.json`) — only JSON output is available
- **`-o` optimizer** — rule optimization pass not implemented

## Build from source

```sh
cargo build --release
# Binaries: target/release/stormwall, target/release/pfctl

# Cross-compile for aarch64
RUSTFLAGS="-C linker=rust-lld" cargo build --release --target aarch64-unknown-linux-musl

# Build .jpkg package
./mkjpkg.sh x86_64    # or aarch64
```

## License

MIT
