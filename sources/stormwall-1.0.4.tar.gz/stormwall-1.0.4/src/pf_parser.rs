//! Minimal pf-syntax parser. Handles `scrub` (feature #1), the four
//! "cheap wins" sub-features of feature #9, `log` (feature #8), and
//! the source-tracking `keep state ( ... )` clauses of feature #2:
//!
//!   * `scrub on <iface> { no-df, random-id, min-ttl, max-mss }`
//!                                      -> ip header rewrites
//!   * `antispoof for <iface>`          -> fib saddr . iif oif missing drop
//!   * `set skip on <iface>`            -> iifname "<iface>" accept (top of chain)
//!   * `pass`/`block` ... `hours { N-N } days { mon-fri }`
//!                                      -> meta hour/day range/lookup
//!   * `block return`/`return-rst`/`return-icmp`
//!                                      -> reject with <kind>
//!   * `pass`/`block` ... `keep state ( max-src-conn / max-src-conn-rate
//!     / max-src-states / overload <table> [flush global] )`
//!                                      -> connlimit / rate-limited
//!                                         dynset / overload-table-add
//!
//! Future PRs grow the grammar; the OpenBSD `parse.y` vendored under
//! tests/pf-upstream/ is the reference.
//!
//! Entry point is `parse_file(input) -> Vec<Command>`. Each pf rule
//! lowers to one or more nftables Commands carrying a flat expression
//! list — the same IR the nft-syntax parser emits, so
//! `ops::compile_rule` doesn't need to know the source language. A pf
//! rule with N source-tracking limits expands to N+1 nft rules: one
//! `<match clauses> <gate> [overload-add] drop` per limit, then a final
//! `<match clauses> <pf-action>` rule that handles packets that didn't
//! trip a limit.
//!
//! Two base chains are emitted lazily:
//!   * `output` (filter, output hook, priority -150)  — for `scrub`.
//!   * `in`     (filter, input hook,  priority 0)     — for antispoof,
//!     set skip, pass/block.
//!
//! Rules destined for `in` go in two buckets so set-skip's "trust this
//! interface, short-circuit later rules" semantic is preserved: the
//! skip-bucket is flushed BEFORE the body-bucket so its `accept`
//! verdict is the first thing the chain evaluates. Synthesised set
//! declarations (overload tables, rate_limit meter) are spliced in
//! after the table command so they exist before the rules that
//! reference them.

use std::collections::HashMap;

use crate::netlink::{
    NF_ACCEPT, NF_DROP, NFT_JUMP,
    NFPROTO_IPV4, NFT_BYTEORDER_HTON, NFT_EXTHDR_OP_TCPOPT,
    NFT_PAYLOAD_CSUM_INET, NFT_PAYLOAD_NETWORK_HEADER,
    NFT_PAYLOAD_TRANSPORT_HEADER, NFT_REG_1,
    NFT_META_IIFNAME, NFT_META_L4PROTO,
    NFT_META_TIME_DAY, NFT_META_TIME_HOUR,
    NFT_CMP_EQ, NFT_RANGE_EQ,
    NFT_DYNSET_OP_ADD, NFT_SET_TIMEOUT, NFT_LIMIT_TYPE_PKTS,
    NFTA_FIB_F_SADDR, NFTA_FIB_F_IIF, NFT_FIB_RESULT_OIF,
    NFT_REJECT_TCP_RST, NFT_REJECT_ICMP_UNREACH,
    NFT_REJECT_ICMPX_UNREACH,
    ICMP_PORT_UNREACH, ICMP_HOST_UNREACH,
    NFT_REJECT_ICMPX_ADMIN_PROHIBITED,
    NFT_NAT_SNAT, NFT_NAT_DNAT,
};
use crate::parser::{ChainSpec, CmdObj, CmdOp, Command, Expr, SetSpec};

// Hook + chain housekeeping. Scrub uses the `output` chain at priority
// -150 (kernel mangle slot), pass/block uses an `input` chain at
// priority 0 (kernel filter input slot) — same placement upstream pf
// picks for the corresponding anchors.
const PF_TABLE: &str = "pf";
const PF_CHAIN_SCRUB: &str = "output";
const PF_CHAIN_SCRUB_PRIO: i32 = -150;
const PF_CHAIN_IN: &str = "in";
const PF_CHAIN_IN_PRIO: i32 = 0;
const PF_CHAIN_OUT: &str = "out";
const PF_CHAIN_OUT_PRIO: i32 = 0;
const PF_CHAIN_FWD: &str = "fwd";
const PF_CHAIN_FWD_PRIO: i32 = 0;

// Default limit unit for `max-src-conn-rate N/T`: nft's burst defaults
// to "rate value" packets, type 0 = NFT_LIMIT_TYPE_PKTS. We mirror that
// so the bracketed listing matches upstream.
fn limit_unit_seconds(unit: &str) -> Result<u64, String> {
    match unit {
        "second" | "sec" | "s" => Ok(1),
        "minute" | "min"  => Ok(60),
        "hour" | "hr" | "h" => Ok(3600),
        "day"  | "d"  => Ok(86400),
        "week" | "w"  => Ok(604800),
        other => Err(format!("pf: unknown rate unit `{}`", other)),
    }
}

/// Full parse result including nftables commands and tc declarations.
pub struct ParseResult {
    pub commands: Vec<Command>,
    pub altq_root: Option<AltqRoot>,
    pub queue_decls: Vec<QueueDecl>,
    pub queue_map: HashMap<String, u32>,
}

/// Parse pf syntax, returning both nftables commands and tc queue
/// declarations.  The caller is responsible for applying tc state
/// via the tc module after applying nftables commands via ops.
pub fn parse_file_full(input: &str) -> Result<ParseResult, String> {
    let (commands, state) = parse_file_inner(input)?;
    Ok(ParseResult {
        commands,
        altq_root: state.altq_root,
        queue_decls: state.queue_decls,
        queue_map: state.queue_map,
    })
}

pub fn parse_file(input: &str) -> Result<Vec<Command>, String> {
    let (commands, _) = parse_file_inner(input)?;
    Ok(commands)
}

fn parse_file_inner(input: &str) -> Result<(Vec<Command>, ParseState), String> {
    let mut tokens = tokenize(input);
    // Three streams: the unconditional table+chain headers, the skip
    // rules (must fire first in `in`), and the body rules. We assemble
    // them at the end so the kernel sees the order we want.
    let mut headers: Vec<Command> = Vec::new();
    let mut skip_rules: Vec<Command> = Vec::new();
    let mut body_rules: Vec<Command> = Vec::new();
    let mut needs_in_chain = false;
    let mut needs_scrub_chain = false;
    let mut needs_out_chain = false;
    // Source-tracking sets (overload tables, rate-limit meter) get
    // declared once each and spliced in after the headers.
    let mut state = ParseState::default();

    while !tokens.is_empty() {
        match tokens[0].as_str() {
            "scrub" => {
                tokens.remove(0);
                let cmd = parse_scrub(&mut tokens)?;
                needs_scrub_chain = true;
                body_rules.push(cmd);
            }
            "antispoof" => {
                tokens.remove(0);
                let cmd = parse_antispoof(&mut tokens)?;
                needs_in_chain = true;
                body_rules.push(cmd);
            }
            "set" => {
                tokens.remove(0);
                let cmd = parse_set_skip(&mut tokens)?;
                needs_in_chain = true;
                skip_rules.push(cmd);
            }
            "pass" | "block" | "match" => {
                let verb = tokens.remove(0);
                let rules = parse_pass_block(&mut tokens, &verb, &mut state)?;
                for r in &rules {
                    if r.chain == PF_CHAIN_OUT {
                        needs_out_chain = true;
                    } else {
                        needs_in_chain = true;
                    }
                }
                body_rules.extend(rules);
            }
            "table" => {
                tokens.remove(0);
                let cmds = parse_table_decl(&mut tokens)?;
                // Table set declarations go in headers so they precede
                // any rules that reference them.
                headers.extend(cmds);
            }
            "anchor" => {
                tokens.remove(0);
                let name = pop_ident(&mut tokens, "anchor name")?;
                // Strip quotes around anchor name: `anchor "foo"` → `foo`
                let name = name.trim_matches('"').to_string();
                if tokens.first().map(String::as_str) == Some("{") {
                    // Inline anchor: parse the body and emit a child
                    // chain + the rules inside it + a jump from the
                    // parent chain.
                    tokens.remove(0);
                    emit_regular_chain(&mut headers, &name);
                    while tokens.first().map(String::as_str) != Some("}") && !tokens.is_empty() {
                        match tokens[0].as_str() {
                            "pass" | "block" | "match" => {
                                let verb = tokens.remove(0);
                                let mut rules = parse_pass_block(&mut tokens, &verb, &mut state)?;
                                // Override chain: rules go into the anchor
                                // chain, not the default in/out chain.
                                for r in &mut rules {
                                    r.chain = name.clone();
                                }
                                body_rules.extend(rules);
                            }
                            _ => {
                                return Err(format!("pf: unsupported keyword `{}` inside anchor", tokens[0]));
                            }
                        }
                    }
                    if tokens.first().map(String::as_str) == Some("}") {
                        tokens.remove(0);
                    }
                    // Emit a jump rule in the parent input chain.
                    let mut jump = new_rule(PF_CHAIN_IN);
                    jump.exprs.push(Expr::Verdict {
                        code: NFT_JUMP,
                        chain: name.clone(),
                    });
                    needs_in_chain = true;
                    body_rules.push(jump);
                } else {
                    // Bare `anchor "name"` — reference to a previously
                    // defined or externally managed anchor. Emit a jump.
                    let mut jump = new_rule(PF_CHAIN_IN);
                    jump.exprs.push(Expr::Verdict {
                        code: NFT_JUMP,
                        chain: name.clone(),
                    });
                    needs_in_chain = true;
                    body_rules.push(jump);
                }
            }
            "altq" => {
                // `altq on <iface> <discipline> bandwidth <bw> queue { q1, q2 ... }`
                // Consumed and recorded in state for tc-side emission.
                tokens.remove(0);
                parse_altq(&mut tokens, &mut state)?;
            }
            "queue" => {
                // Top-level `queue NAME { bandwidth <bw>, qlimit <n>, ... }`
                // defines a tc class. Also allocates a priority marker.
                tokens.remove(0);
                parse_queue_decl(&mut tokens, &mut state)?;
            }
            // Blank lines / stray semicolons / comments already stripped
            // by the tokenizer; an unrecognised top-level word is a
            // hard error so we don't silently drop unsupported pf
            // features.
            other => {
                return Err(format!("pf: unsupported top-level keyword `{}`", other));
            }
        }
    }

    emit_table(&mut headers);
    if needs_scrub_chain {
        emit_chain(&mut headers, PF_CHAIN_SCRUB, "output", PF_CHAIN_SCRUB_PRIO);
    }
    if needs_out_chain {
        emit_chain(&mut headers, PF_CHAIN_OUT, "output", PF_CHAIN_OUT_PRIO);
    }
    if needs_in_chain {
        emit_chain(&mut headers, PF_CHAIN_IN, "input", PF_CHAIN_IN_PRIO);
    }

    // Splice deferred overload-set + meter-set declarations in right
    // after the table+chain headers — the rules that reference them
    // come below in skip_rules / body_rules and the kernel needs the
    // sets to exist before the rule-add lands. Order mirrors upstream
    // nft: overload sets (typed ipv4_addr, timeout-flagged) precede
    // dynamic meter sets, matching the line order in the frozen
    // straces.
    let mut out = headers;
    // overload_decls and meter_decls are moved out, but altq_root/queue_decls
    // stay in state for parse_file_full to extract.
    out.extend(std::mem::take(&mut state.overload_decls));
    out.extend(std::mem::take(&mut state.meter_decls));
    out.append(&mut skip_rules);
    out.append(&mut body_rules);
    Ok((out, state))
}

fn emit_table(cmds: &mut Vec<Command>) {
    let mut t = Command::default();
    t.op = CmdOp::Add;
    t.obj = CmdObj::Table;
    t.family = NFPROTO_IPV4;
    t.table = PF_TABLE.to_string();
    cmds.push(t);
}

fn emit_chain(cmds: &mut Vec<Command>, name: &str, hook: &str, prio: i32) {
    let mut c = Command::default();
    c.op = CmdOp::Add;
    c.obj = CmdObj::Chain;
    c.family = NFPROTO_IPV4;
    c.table = PF_TABLE.to_string();
    c.chain = name.to_string();
    c.chain_spec = ChainSpec {
        is_base: true,
        chain_type: "filter".to_string(),
        hook: hook.to_string(),
        priority: prio,
        has_priority: true,
        policy: "accept".to_string(),
        has_policy: true,
        device: String::new(),
        has_device: false,
        is_binding: false,
        chain_id: 0,
        has_chain_id: false,
    };
    cmds.push(c);
}

/// Emit a regular (non-hook) chain — used for anchors.
fn emit_regular_chain(cmds: &mut Vec<Command>, name: &str) {
    let mut c = Command::default();
    c.op = CmdOp::Add;
    c.obj = CmdObj::Chain;
    c.family = NFPROTO_IPV4;
    c.table = PF_TABLE.to_string();
    c.chain = name.to_string();
    // is_base defaults to false — regular chain, no hook.
    cmds.push(c);
}

/// Tracks state allocated lazily during pf parsing — chiefly the
/// synthesised `overload <table>` and `rate_limit` meter sets that
/// `keep state ( ... )` clauses reference. We dedupe so multiple
/// references to the same overload table share one `add set` command.
struct ParseState {
    /// Overload-set name → declaration command, dedup'd across rules.
    /// Kept separately and spliced after the table+chain headers so
    /// multiple `overload <abusers>` references share one
    /// `add set ip pf abusers`.
    overload_seen: HashMap<String, ()>,
    overload_decls: Vec<Command>,
    /// Same dedup pattern for synthesised meter sets. The first
    /// `max-src-conn-rate` clause in a corpus allocates `rate_limit`;
    /// further clauses reuse it (matching upstream nft, which the
    /// frozen straces all named `rate_limit`).
    meter_seen: HashMap<String, ()>,
    meter_decls: Vec<Command>,
    /// Queue name → priority marker (u32). The marker encodes
    /// `TC_H_MAKE(SW_TC_MAJOR, minor)` so `meta priority set <marker>`
    /// on the nftables side matches `tc filter ... classid 1:<minor>`
    /// on the tc side. Minor numbers start at 0x10 to avoid colliding
    /// with the qdisc handle (1:0) and the root class.
    queue_map: HashMap<String, u32>,
    queue_next_minor: u16,
    /// Parsed altq root declaration: (interface, discipline, bandwidth_bps).
    altq_root: Option<AltqRoot>,
    /// Parsed queue declarations for tc class emission.
    queue_decls: Vec<QueueDecl>,
}

/// Root qdisc configuration from `altq on <iface> <discipline> ...`.
#[derive(Clone, Debug)]
pub struct AltqRoot {
    pub iface: String,
    pub discipline: String,
    pub bandwidth_bps: u64,
    pub child_queues: Vec<String>,
}

/// Per-queue class declaration from `queue NAME { ... }`.
#[derive(Clone, Debug)]
pub struct QueueDecl {
    pub name: String,
    pub bandwidth_bps: Option<u64>,
    pub qlimit: Option<u32>,
    pub priority: Option<u32>,
    pub parent: Option<String>,
    pub child_queues: Vec<String>,
    pub marker: u32,
}

impl Default for ParseState {
    fn default() -> Self {
        ParseState {
            overload_seen: HashMap::new(),
            overload_decls: Vec::new(),
            meter_seen: HashMap::new(),
            meter_decls: Vec::new(),
            queue_map: HashMap::new(),
            queue_next_minor: 0x10,
            altq_root: None,
            queue_decls: Vec::new(),
        }
    }
}

impl ParseState {
    /// Resolve a queue name to its tc priority marker.  Allocates a
    /// new minor number on first use, reuses the existing one for
    /// repeated references.  Returns `TC_H_MAKE(1, minor)`.
    fn queue_priority(&mut self, name: &str) -> u32 {
        if let Some(&marker) = self.queue_map.get(name) {
            return marker;
        }
        let minor = self.queue_next_minor;
        self.queue_next_minor += 1;
        // TC_H_MAKE(major, minor) = (major << 16) | minor
        let marker = ((crate::tc::SW_TC_MAJOR as u32) << 16) | (minor as u32);
        self.queue_map.insert(name.to_string(), marker);
        marker
    }

    /// Allocate (or reuse) a dynamic meter set for `max-src-conn-rate`.
    /// The synthesised name `rate_limit` matches the frozen straces
    /// 1:1 — upstream nft calls anonymous meters by the source-given
    /// name, and our corpus uses `rate_limit` consistently. Wire form:
    /// `add set ip pf rate_limit { type ipv4_addr; flags dynamic; }`
    /// (NFT_SET_EVAL=0x20 is the kernel's "dynamic" bit). Per-element
    /// timeout is omitted — the limit expression handles its own
    /// burst/recovery without leaning on a kernel timer sweep.
    fn ensure_meter_set(&mut self, name: &str) {
        if self.meter_seen.contains_key(name) { return; }
        self.meter_seen.insert(name.to_string(), ());

        let mut c = Command::default();
        c.op = CmdOp::Add;
        c.obj = CmdObj::Set;
        c.family = NFPROTO_IPV4;
        c.table = PF_TABLE.to_string();
        c.set_name = name.to_string();

        let mut spec = SetSpec::default();
        spec.key_type_name = "ipv4_addr".to_string();
        spec.key_type = 7;
        spec.key_len = 4;
        // NFT_SET_EVAL = 0x20 = "dynamic" — required for sets that
        // accept dynset expressions with NFTA_DYNSET_EXPR (i.e. the
        // anonymous-meter shape).
        spec.flags = 0x20;
        spec.has_flags = true;
        c.set_spec = spec;
        self.meter_decls.push(c);
    }

    fn ensure_overload_set(&mut self, name: &str, _flush_global: bool) {
        if self.overload_seen.contains_key(name) { return; }
        self.overload_seen.insert(name.to_string(), ());

        let mut c = Command::default();
        c.op = CmdOp::Add;
        c.obj = CmdObj::Set;
        c.family = NFPROTO_IPV4;
        c.table = PF_TABLE.to_string();
        c.set_name = name.to_string();
        // ipv4_addr key, flags=timeout, default 1h timeout. Mirrors
        // upstream pf's "overload <abusers> flush global" default
        // expiration so an attacker stops getting blocked an hour
        // after they stop attacking. `flush global` itself is a kernel
        // hint with no wire bit on the set declaration — it's
        // conventionally encoded as an out-of-band userspace flag and
        // we accept and ignore it for now (deferred until pf-parity
        // adds the overload-flush expression).
        let mut spec = SetSpec::default();
        spec.key_type_name = "ipv4_addr".to_string();
        spec.key_type = 7; // IPV4_ADDR per netlink::set_key_type
        spec.key_len = 4;
        spec.flags = NFT_SET_TIMEOUT;
        spec.has_flags = true;
        spec.timeout_ms = 3_600_000; // 1 hour
        spec.has_timeout = true;
        c.set_spec = spec;
        self.overload_decls.push(c);
    }
}

fn new_rule(chain: &str) -> Command {
    let mut cmd = Command::default();
    cmd.op = CmdOp::Add;
    cmd.obj = CmdObj::Rule;
    cmd.family = NFPROTO_IPV4;
    cmd.table = PF_TABLE.to_string();
    cmd.chain = chain.to_string();
    cmd
}

// ── scrub ──────────────────────────────────────────────────────────

// `scrub on <iface> [proto X] [from S] [to D] <opts>`
// Where <opts> is either a single bare opt (e.g. `no-df`) or a brace-
// enclosed list separated by commas or whitespace.
fn parse_scrub(tokens: &mut Vec<String>) -> Result<Command, String> {
    expect(tokens, "on")?;
    let _iface = pop_ident(tokens, "iface")?;
    // Skip optional `proto`/`from`/`to` clauses for now — we don't
    // gate on them yet, but we must consume them so the opt parse
    // doesn't see them as a keyword.
    while let Some(head) = tokens.first().map(String::as_str) {
        match head {
            "proto" | "from" | "to" => {
                tokens.remove(0);
                // Each clause takes one value token.
                if !tokens.is_empty() { tokens.remove(0); }
            }
            _ => break,
        }
    }

    let opts = parse_scrub_opt_list(tokens)?;

    let mut cmd = new_rule(PF_CHAIN_SCRUB);
    for opt in opts {
        lower_scrub_opt(&opt, &mut cmd.exprs)?;
    }
    Ok(cmd)
}

// ── pass / block ───────────────────────────────────────────────────
//
// `pass`/`block [in|out] [proto X] [from S] [to D] [port N] keep state
// ( max-src-conn N | max-src-conn-rate R/T | max-src-states N |
//   overload <table> [flush global] [, ...] )`
//
// Lowering rules (derived from the upstream nft straces under
// tests/pf-corpus/strace/):
//
//   block + any-limits → ONE rule that combines every limit clause in
//                        source order, terminal verdict = drop.
//   pass  + only rate  → ONE rule with rate_limit dynset, accept.
//   pass  + connlimit  → ONE rule with `connlimit drop`, no fallthrough
//                        rule (chain default policy=accept handles
//                        non-tripping packets).
//   pass  + multi      → one rule per limit clause, each ending in
//                        either `drop` (connlimit-style or
//                        rate+overload) or `accept` (rate-only). A
//                        terminal `accept` rule closes the block.
//
// Source-tracked counter: rate_limit and overload sets allocate at
// most once per parse via `ParseState::ensure_*_set`.

#[derive(Debug)]
enum LimitClause {
    /// `max-src-conn N` and `max-src-states N` both lower to this —
    /// the kernel's `connlimit` expression covers both.
    Connlimit { count: u32 },
    /// `max-src-conn-rate N/T` — rate-limited dynset over a synthesised
    /// dynamic set.
    Rate { rate: u64, unit: u64 },
    /// `overload <name> [flush global]` — recorded as a clause so the
    /// rule-builder can attach a `dynset add @<name>` to the right
    /// limit-rule. `flush_global` is parsed-and-stored but not yet
    /// emitted (deferred until pf-parity adds the overload-flush op).
    Overload { name: String, flush_global: bool },
}

#[derive(Default)]
struct PassBlockClauses {
    direction_in: bool,
    direction_out: bool,
    proto: Option<u32>,        // 6=tcp, 17=udp, 1=icmp
    from_addr: Option<[u8; 4]>,
    to_addr:   Option<[u8; 4]>,
    port:      Option<u16>,
    limits:    Vec<LimitClause>,
    /// `hours { LO-HI }` — seconds-since-midnight range. None when
    /// the rule has no time gate.
    hours:     Option<(u32, u32)>,
    /// `days { mon, tue-fri, ... }` — sorted unique weekday integers
    /// (sunday=0..saturday=6). Empty when the rule has no day gate.
    days:      Vec<u8>,
    /// `block return` / `return-rst` / `return-icmp [<code>]` —
    /// captured here so the verdict at the end of the body knows
    /// which reject form to emit. Always None for `pass`.
    reject_form: Option<RejectForm>,
    /// `log` / `log (all)` / `log (to pflog0)` — emit Expr::Log
    /// before the verdict. None when the rule has no log clause.
    log_prefix: Option<String>,
    /// `route-to` / `reply-to` / `dup-to` — routing action. On Linux
    /// all three lower to `dup to <addr> device "<iface>"` since true
    /// policy routing requires `ip rule` outside nftables.
    dup_target: Option<(Vec<u8>, u32)>,  // (addr, ifindex)
    /// `nat-to` — source NAT. `(egress)` means masquerade; otherwise
    /// a specific address. Optional port range.
    nat_to: Option<NatTarget>,
    /// `rdr-to` — destination NAT (port forward).
    rdr_to: Option<NatTarget>,
    /// `binat-to` — bidirectional 1:1 NAT (emits paired SNAT+DNAT).
    binat_to: Option<NatTarget>,
    /// `no state` — disable connection tracking for this rule. Emits
    /// notrack before the verdict.
    no_state: bool,
    /// `flags S/SA` — TCP flag check (check_byte, mask_byte). Emits
    /// a payload load + bitwise mask + cmp.
    tcp_flags: Option<(u8, u8)>,
    /// `queue NAME` or `queue (NAME)` — tc queue assignment.  The name
    /// is resolved to a numeric priority marker at rule-emit time and
    /// appended as `Immediate(marker) + MetaSet(NFT_META_PRIORITY)`.
    queue_name: Option<String>,
}

#[derive(Clone)]
struct NatTarget {
    masquerade: bool,
    addr: [u8; 4],
    port: Option<u16>,
}

// ── altq / queue declarations ──────────────────────────────────────

/// Parse bandwidth value: `100Mb`, `10Gb`, `1000Kb`, `50%` etc.
/// Returns bytes/sec. pf uses bits/sec; tc uses bytes/sec.
fn parse_bandwidth(s: &str) -> Result<u64, String> {
    let s = s.trim();
    if s.ends_with('%') {
        // Percentage of parent — not supported yet. Consume and warn.
        return Ok(0);
    }
    let (num_str, multiplier) = if s.ends_with("Gb") || s.ends_with("gb") {
        (&s[..s.len()-2], 1_000_000_000u64 / 8)
    } else if s.ends_with("Mb") || s.ends_with("mb") {
        (&s[..s.len()-2], 1_000_000u64 / 8)
    } else if s.ends_with("Kb") || s.ends_with("kb") {
        (&s[..s.len()-2], 1_000u64 / 8)
    } else if s.ends_with('b') {
        (&s[..s.len()-1], 1u64 / 8)
    } else {
        // Bare number = bits/sec
        (s, 1u64 / 8)
    };
    let n: u64 = num_str.parse()
        .map_err(|_| format!("pf: invalid bandwidth `{}`", s))?;
    Ok(n * multiplier)
}

/// `altq on <iface> <discipline> bandwidth <bw> queue { q1, q2 ... }`
fn parse_altq(tokens: &mut Vec<String>, state: &mut ParseState) -> Result<(), String> {
    expect(tokens, "on")?;
    let iface = pop_ident(tokens, "altq interface")?;

    // Discipline: hfsc, cbq, priq (or omitted = hfsc default)
    let discipline = match tokens.first().map(String::as_str) {
        Some("hfsc") | Some("cbq") | Some("priq") => tokens.remove(0),
        _ => "hfsc".to_string(),
    };

    // Optional bandwidth
    let mut bandwidth_bps = 0u64;
    if tokens.first().map(String::as_str) == Some("bandwidth") {
        tokens.remove(0);
        let bw = pop_ident(tokens, "bandwidth value")?;
        bandwidth_bps = parse_bandwidth(&bw)?;
    }

    // Optional `tbrsize N`
    if tokens.first().map(String::as_str) == Some("tbrsize") {
        tokens.remove(0);
        let _ = pop_ident(tokens, "tbrsize value");
    }

    // `queue { q1, q2, ... }` child list
    let mut child_queues = Vec::new();
    if tokens.first().map(String::as_str) == Some("queue") {
        tokens.remove(0);
        if tokens.first().map(String::as_str) == Some("{") {
            tokens.remove(0);
            while tokens.first().map(String::as_str) != Some("}") && !tokens.is_empty() {
                let name = tokens.remove(0);
                if name != "," {
                    child_queues.push(name);
                }
            }
            if tokens.first().map(String::as_str) == Some("}") {
                tokens.remove(0);
            }
        } else {
            // Single queue name
            child_queues.push(pop_ident(tokens, "queue name")?);
        }
    }

    // Pre-allocate priority markers for all child queues
    for name in &child_queues {
        state.queue_priority(name);
    }

    state.altq_root = Some(AltqRoot { iface, discipline, bandwidth_bps, child_queues });
    Ok(())
}

/// `queue NAME [on <iface>] [bandwidth <bw>] [qlimit <n>] [priority <n>]
///   [{ sub1, sub2 }]` or brace-enclosed form
///   `queue NAME { bandwidth <bw>, qlimit <n>, ... }`
fn parse_queue_decl(tokens: &mut Vec<String>, state: &mut ParseState) -> Result<(), String> {
    let name = pop_ident(tokens, "queue name")?;
    let name = name.trim_matches('"').to_string();
    let marker = state.queue_priority(&name);

    let mut bandwidth_bps = None;
    let mut qlimit = None;
    let mut priority = None;
    let mut parent = None;
    let mut child_queues = Vec::new();

    // Parse optional attributes — either inline or brace-enclosed
    let braced = tokens.first().map(String::as_str) == Some("{");
    if braced { tokens.remove(0); }

    loop {
        match tokens.first().map(String::as_str) {
            None => break,
            Some("}") if braced => { tokens.remove(0); break; }
            Some(",") => { tokens.remove(0); continue; }
            Some("bandwidth") => {
                tokens.remove(0);
                let bw = pop_ident(tokens, "bandwidth value")?;
                bandwidth_bps = Some(parse_bandwidth(&bw)?);
            }
            Some("qlimit") => {
                tokens.remove(0);
                let n = pop_u32(tokens, "qlimit value")?;
                qlimit = Some(n);
            }
            Some("priority") => {
                tokens.remove(0);
                let n = pop_u32(tokens, "priority value")?;
                priority = Some(n);
            }
            Some("parent") => {
                tokens.remove(0);
                let p = pop_ident(tokens, "parent queue")?;
                parent = Some(p.trim_matches('"').to_string());
            }
            Some("on") => {
                tokens.remove(0);
                let _ = pop_ident(tokens, "interface");
            }
            // HFSC curve specs: `hfsc(realtime BW, linkshare BW, upperlimit BW)`
            Some("hfsc") => {
                tokens.remove(0);
                // Consume `(` ... `)` block
                if tokens.first().map(String::as_str) == Some("(") {
                    tokens.remove(0);
                    while tokens.first().map(String::as_str) != Some(")") && !tokens.is_empty() {
                        tokens.remove(0);
                    }
                    if tokens.first().map(String::as_str) == Some(")") { tokens.remove(0); }
                }
            }
            // Sub-queue list: `{ sub1, sub2 }`
            Some("{") if !braced => {
                tokens.remove(0);
                while tokens.first().map(String::as_str) != Some("}") && !tokens.is_empty() {
                    let n = tokens.remove(0);
                    if n != "," {
                        child_queues.push(n);
                    }
                }
                if tokens.first().map(String::as_str) == Some("}") { tokens.remove(0); }
            }
            // Top-level keywords → end of this declaration
            _ if !braced => break,
            // Inside braces, skip unknown keywords
            _ => { tokens.remove(0); }
        }
    }

    // Pre-allocate markers for child queues
    for cq in &child_queues {
        state.queue_priority(cq);
    }

    state.queue_decls.push(QueueDecl {
        name,
        bandwidth_bps,
        qlimit,
        priority,
        parent,
        child_queues,
        marker,
    });
    Ok(())
}

fn parse_pass_block(
    tokens: &mut Vec<String>,
    verb: &str,
    state: &mut ParseState,
) -> Result<Vec<Command>, String> {
    let mut cl = PassBlockClauses::default();

    // Optional `return` / `return-rst` / `return-icmp` modifier on
    // `block`. Captured up front so the verdict at the end of the
    // body knows which reject form to emit.
    if verb == "block" {
        if let Some(head) = tokens.first().map(String::as_str) {
            match head {
                "return" => {
                    tokens.remove(0);
                    cl.reject_form = Some(RejectForm::IcmpPortUnreach);
                }
                "return-rst" => {
                    tokens.remove(0);
                    cl.reject_form = Some(RejectForm::TcpRst);
                }
                "return-icmp" => {
                    tokens.remove(0);
                    // Optional `<code-name>` (port-unreach / host-unreach
                    // / admin-prohibited). Default = port-unreachable,
                    // the pf default.
                    let form = match tokens.first().map(String::as_str) {
                        Some("host-unreach") => { tokens.remove(0); RejectForm::IcmpHostUnreach }
                        Some("admin-prohibited") => {
                            tokens.remove(0); RejectForm::IcmpxAdminProhibited
                        }
                        Some("port-unreach") | None => {
                            if !tokens.is_empty() && tokens[0] == "port-unreach" { tokens.remove(0); }
                            RejectForm::IcmpPortUnreach
                        }
                        _ => RejectForm::IcmpPortUnreach,
                    };
                    cl.reject_form = Some(form);
                }
                _ => {}
            }
        }
    }

    // Walk the rule body, consuming each clause until we hit either
    // `keep` (start of state-tracking opts) or run out of tokens.
    loop {
        let head = match tokens.first().map(String::as_str) {
            Some(h) => h.to_string(),
            None => break,
        };
        match head.as_str() {
            "in"    => { tokens.remove(0); cl.direction_in = true; }
            "out"   => {
                tokens.remove(0); cl.direction_out = true;
            }
            "quick" => { tokens.remove(0); /* pf-only; nft is first-match-wins */ }
            "on" => {
                tokens.remove(0);
                let _iface = pop_ident(tokens, "interface name")?;
            }
            "log" => {
                tokens.remove(0);
                if tokens.first().map(String::as_str) == Some("(") {
                    tokens.remove(0);
                    let modifier = pop_ident(tokens, "log modifier")?;
                    match modifier.as_str() {
                        "all" => {
                            cl.log_prefix = Some("all: ".to_string());
                            expect(tokens, ")")?;
                        }
                        "to" => {
                            let iface = pop_ident(tokens, "log interface")?;
                            cl.log_prefix = Some(format!("{}: ", iface));
                            expect(tokens, ")")?;
                        }
                        _ => {
                            cl.log_prefix = Some(format!("{}: ", modifier));
                            while tokens.first().map(String::as_str) != Some(")") && !tokens.is_empty() {
                                tokens.remove(0);
                            }
                            if !tokens.is_empty() { tokens.remove(0); }
                        }
                    }
                } else {
                    cl.log_prefix = Some(String::new());
                }
            }
            "route-to" | "reply-to" | "dup-to" => {
                tokens.remove(0);
                // Syntax: `route-to ( iface addr )` or `route-to iface`
                let (iface, addr) = if tokens.first().map(String::as_str) == Some("(") {
                    tokens.remove(0);
                    let iface = pop_ident(tokens, "routing interface")?;
                    let addr = if tokens.first().map(String::as_str) != Some(")") {
                        let a = pop_ident(tokens, "routing address")?;
                        parse_ipv4(&a)?.to_vec()
                    } else {
                        vec![0, 0, 0, 0]
                    };
                    expect(tokens, ")")?;
                    (iface, addr)
                } else {
                    let iface = pop_ident(tokens, "routing interface")?;
                    let addr = if !tokens.is_empty() && tokens[0].contains('.') {
                        let a = pop_ident(tokens, "routing address")?;
                        parse_ipv4(&a)?.to_vec()
                    } else {
                        vec![0, 0, 0, 0]
                    };
                    (iface, addr)
                };
                // Resolve interface to index at parse time; fall back to
                // 0 if the interface doesn't exist on this host (the rule
                // still encodes, just without a device).
                let idx = iface_index(&iface);
                cl.dup_target = Some((addr, idx));
            }
            "nat-to" => {
                tokens.remove(0);
                // `nat-to (egress)` → masquerade; `nat-to <addr>` → SNAT
                if tokens.first().map(String::as_str) == Some("(") {
                    tokens.remove(0);
                    let _iface = pop_ident(tokens, "nat interface")?;
                    expect(tokens, ")")?;
                    cl.nat_to = Some(NatTarget { masquerade: true, addr: [0;4], port: None });
                } else {
                    let a = pop_ident(tokens, "nat address")?;
                    let addr = parse_ipv4(&a)?;
                    let port = if tokens.first().map(String::as_str) == Some("port") {
                        tokens.remove(0);
                        let p = pop_u32(tokens, "nat port")?;
                        // Consume optional `:upper` port range
                        if tokens.first().map(|s| s.starts_with(':')).unwrap_or(false) {
                            tokens.remove(0);
                        }
                        Some(p as u16)
                    } else { None };
                    cl.nat_to = Some(NatTarget { masquerade: false, addr, port });
                }
            }
            "rdr-to" => {
                tokens.remove(0);
                let a = pop_ident(tokens, "rdr address")?;
                let addr = parse_ipv4(&a)?;
                let port = if tokens.first().map(String::as_str) == Some("port") {
                    tokens.remove(0);
                    let p = pop_u32(tokens, "rdr port")?;
                    Some(p as u16)
                } else { None };
                cl.rdr_to = Some(NatTarget { masquerade: false, addr, port });
            }
            "binat-to" => {
                tokens.remove(0);
                let a = pop_ident(tokens, "binat address")?;
                let addr = parse_ipv4(&a)?;
                cl.binat_to = Some(NatTarget { masquerade: false, addr, port: None });
            }
            "proto" => {
                tokens.remove(0);
                let p = pop_ident(tokens, "proto value")?;
                cl.proto = Some(match p.as_str() {
                    "tcp"  => 6,
                    "udp"  => 17,
                    "icmp" => 1,
                    "icmpv6" => 58,
                    other  => return Err(format!("pf: unknown proto `{}`", other)),
                });
            }
            "from" => {
                tokens.remove(0);
                let v = pop_ident(tokens, "from address")?;
                if v != "any" {
                    cl.from_addr = Some(parse_ipv4(&v)?);
                }
            }
            "to" => {
                tokens.remove(0);
                let v = pop_ident(tokens, "to address")?;
                if v != "any" {
                    cl.to_addr = Some(parse_ipv4(&v)?);
                }
            }
            "port" => {
                tokens.remove(0);
                let n = pop_u32(tokens, "port")?;
                if n > 0xFFFF { return Err(format!("pf: port out of range: {}", n)); }
                cl.port = Some(n as u16);
            }
            "hours" => {
                tokens.remove(0);
                cl.hours = Some(parse_hours_block(tokens)?);
            }
            "days" => {
                tokens.remove(0);
                cl.days = parse_days_block(tokens)?;
            }
            "label" | "tag" => {
                // `label "name"` / `tag "name"` — metadata that
                // doesn't affect packet matching. Consume and ignore.
                tokens.remove(0);
                if !tokens.is_empty() { tokens.remove(0); }
            }
            "flags" => {
                tokens.remove(0);
                let spec = pop_ident(tokens, "flags spec")?;
                // pf format: `flags S/SA` (check/mask). The tokenizer
                // may deliver this as one token `S/SA` or two tokens
                // `S` `/` `SA` depending on whitespace. Handle both.
                let (check_str, mask_str) = if let Some((c, m)) = spec.split_once('/') {
                    (c.to_string(), m.to_string())
                } else {
                    expect(tokens, "/")?;
                    let m = pop_ident(tokens, "flags mask")?;
                    (spec, m)
                };
                let check = tcp_flag_byte(&check_str)?;
                let mask = tcp_flag_byte(&mask_str)?;
                cl.tcp_flags = Some((check, mask));
            }
            "no" => {
                tokens.remove(0);
                expect(tokens, "state")?;
                cl.no_state = true;
            }
            "modulate" => {
                tokens.remove(0);
                expect(tokens, "state")?;
                // Modulate state (TCP ISN randomisation) has no nftables
                // equivalent — treat as keep state (conntrack implicit).
            }
            "queue" => {
                tokens.remove(0);
                // `queue NAME` or `queue (NAME)` or `queue (NAME, NAME2)`.
                // The second name (ACK queue) is parsed and stored but only
                // the first is used for priority assignment (see design doc
                // §2.3 known limitation).
                let name = if tokens.first().map(String::as_str) == Some("(") {
                    tokens.remove(0);
                    let n = pop_ident(tokens, "queue name")?;
                    // Skip optional second queue and trailing paren
                    if tokens.first().map(String::as_str) == Some(",") {
                        tokens.remove(0);
                        let _ack_queue = pop_ident(tokens, "ack queue name");
                    }
                    if tokens.first().map(String::as_str) == Some(")") {
                        tokens.remove(0);
                    }
                    n
                } else {
                    pop_ident(tokens, "queue name")?
                };
                cl.queue_name = Some(name.trim_matches('"').to_string());
            }
            "keep" => {
                tokens.remove(0);
                expect(tokens, "state")?;
                // `keep state` without `(` is just the default — consume it.
                if tokens.first().map(String::as_str) == Some("(") {
                    tokens.remove(0);
                    cl.limits = parse_limit_clauses(tokens)?;
                    // `parse_limit_clauses` consumes the trailing `)`.
                }
                break;
            }
            // Top-level keywords (or a closing brace from an inline
            // anchor body) mean we've fallen out of this rule.
            "scrub" | "antispoof" | "set" | "pass" | "block" | "match" | "table" | "anchor" | "}" => break,
            // Any other token belongs to a clause we don't yet support
            // (`label`, `tag`, `flags S/SA`, etc.). Stop walking and
            // let the caller drain — we'd rather hard-error than
            // silently drop semantics.
            _ => return Err(format!("pf: unsupported pass/block clause `{}`", head)),
        }
    }

    let action = if verb == "block" { NF_DROP } else { NF_ACCEPT };

    // When the rule uses cheap-wins-only features (hours / days /
    // block-return) AND no source-tracking limits, lower it to a
    // single rule via the cheap-wins path. Otherwise dispatch to the
    // srctrack multi-rule builder.
    if cl.limits.is_empty() && (cl.hours.is_some() || !cl.days.is_empty() || cl.reject_form.is_some() || cl.log_prefix.is_some() || cl.dup_target.is_some() || cl.nat_to.is_some() || cl.rdr_to.is_some() || cl.binat_to.is_some() || cl.no_state || cl.tcp_flags.is_some() || cl.queue_name.is_some()) {
        return Ok(vec![build_simple_pass_block(verb, &cl, state)?]);
    }

    build_pass_block_rules(action, cl, state)
}

// Cheap-wins single-rule lowering for pass/block bodies that have
// time-based gates (`hours { N-N }` / `days { ... }`) and/or a `block
// return-*` reject verdict, but no source-tracking limits. The clause
// order on wire matches the order pfctl emits: l4proto, optional dport,
// optional hours, optional days, then the verdict.
fn build_simple_pass_block(verb: &str, cl: &PassBlockClauses, state: &mut ParseState) -> Result<Command, String> {
    let chain = if cl.direction_out { PF_CHAIN_OUT } else { PF_CHAIN_IN };
    let mut cmd = new_rule(chain);

    // Source/destination address matching.
    if let Some(addr) = cl.from_addr {
        cmd.exprs.push(Expr::PayloadLoadReg {
            dreg: NFT_REG_1,
            base: NFT_PAYLOAD_NETWORK_HEADER,
            offset: 12,  // ip saddr
            len: 4,
        });
        cmd.exprs.push(Expr::Cmp { op: NFT_CMP_EQ, data: addr.to_vec() });
    }
    if let Some(addr) = cl.to_addr {
        cmd.exprs.push(Expr::PayloadLoadReg {
            dreg: NFT_REG_1,
            base: NFT_PAYLOAD_NETWORK_HEADER,
            offset: 16,  // ip daddr
            len: 4,
        });
        cmd.exprs.push(Expr::Cmp { op: NFT_CMP_EQ, data: addr.to_vec() });
    }

    // Track whether l4proto has been emitted so `port` knows whether
    // to predicate on tcp/udp.
    let mut last_proto: Option<u8> = None;
    if let Some(p) = cl.proto {
        let n = p as u8;
        cmd.exprs.push(Expr::Meta { key: NFT_META_L4PROTO, width: 1 });
        cmd.exprs.push(Expr::Cmp { op: NFT_CMP_EQ, data: vec![n] });
        last_proto = Some(n);
    }
    if let Some(p) = cl.port {
        // dport offset is 2 in both TCP and UDP transport headers. If
        // the user didn't write `proto X` we default to tcp (matching
        // pf's bare `port N` semantics).
        if last_proto.is_none() {
            cmd.exprs.push(Expr::Meta { key: NFT_META_L4PROTO, width: 1 });
            cmd.exprs.push(Expr::Cmp { op: NFT_CMP_EQ, data: vec![6] });
        }
        cmd.exprs.push(Expr::PayloadLoadReg {
            dreg: NFT_REG_1,
            base: NFT_PAYLOAD_TRANSPORT_HEADER,
            offset: 2,
            len: 2,
        });
        let nb = p.to_be_bytes();
        cmd.exprs.push(Expr::Cmp { op: NFT_CMP_EQ, data: vec![nb[0], nb[1]] });
    }
    // TCP flags: `flags S/SA` → payload load 1b @ th+13, bitwise & mask, cmp == check.
    if let Some((check, mask)) = cl.tcp_flags {
        cmd.exprs.push(Expr::PayloadLoadReg {
            dreg: NFT_REG_1,
            base: NFT_PAYLOAD_TRANSPORT_HEADER,
            offset: 13,
            len: 1,
        });
        cmd.exprs.push(Expr::BitwiseReg {
            reg: NFT_REG_1,
            mask: vec![mask],
            xor: vec![0],
        });
        cmd.exprs.push(Expr::Cmp { op: NFT_CMP_EQ, data: vec![check] });
    }

    if let Some((lo, hi)) = cl.hours {
        lower_hours(&mut cmd.exprs, lo, hi);
    }
    if !cl.days.is_empty() {
        lower_days(&mut cmd.exprs, &cl.days);
    }

    // NAT actions — nat-to → SNAT/masquerade, rdr-to → DNAT.
    if let Some(ref nat) = cl.nat_to {
        if nat.masquerade {
            cmd.exprs.push(Expr::Masquerade { flags: 0 });
        } else {
            let has_port = nat.port.is_some();
            cmd.exprs.push(Expr::Nat {
                nat_type: NFT_NAT_SNAT,
                family: NFPROTO_IPV4,
                addr: nat.addr.to_vec(),
                port: nat.port.unwrap_or(0),
                has_addr: true,
                has_port,
                addr_max: Vec::new(),
                has_addr_max: false,
                flags: if has_port { crate::netlink::NF_NAT_RANGE_PROTO_SPECIFIED } else { 0 },
            });
        }
    }
    if let Some(ref rdr) = cl.rdr_to {
        let has_port = rdr.port.is_some();
        cmd.exprs.push(Expr::Nat {
            nat_type: NFT_NAT_DNAT,
            family: NFPROTO_IPV4,
            addr: rdr.addr.to_vec(),
            port: rdr.port.unwrap_or(0),
            has_addr: true,
            has_port,
            addr_max: Vec::new(),
            has_addr_max: false,
            flags: if has_port { crate::netlink::NF_NAT_RANGE_PROTO_SPECIFIED } else { 0 },
        });
    }
    if let Some(ref binat) = cl.binat_to {
        // binat-to lowers to SNAT in this rule; a paired DNAT rule
        // would need a prerouting chain — deferred for now, emit SNAT
        // only as a useful approximation.
        cmd.exprs.push(Expr::Nat {
            nat_type: NFT_NAT_SNAT,
            family: NFPROTO_IPV4,
            addr: binat.addr.to_vec(),
            port: 0,
            has_addr: true,
            has_port: false,
            addr_max: Vec::new(),
            has_addr_max: false,
            flags: 0,
        });
    }

    // Routing action (route-to / reply-to / dup-to) — emits a dup
    // expression before the verdict. All three lower identically on
    // Linux since true policy routing requires `ip rule` outside nft.
    if let Some((ref addr, dev)) = cl.dup_target {
        cmd.exprs.push(Expr::Dup { addr: addr.clone(), dev: if dev != 0 { Some(dev) } else { None } });
    }

    // Log expression — fires before the verdict.
    if let Some(ref prefix) = cl.log_prefix {
        cmd.exprs.push(Expr::Log { prefix: prefix.clone() });
    }

    // `no state` → notrack (disable conntrack for this flow).
    if cl.no_state {
        cmd.exprs.push(Expr::Notrack);
    }

    // `queue NAME` → meta priority set <marker>. Emitted before the
    // verdict so the packet's skb->priority is set before it leaves
    // nftables and enters the tc qdisc tree.
    if let Some(ref name) = cl.queue_name {
        use crate::netlink::NFT_META_PRIORITY;
        let marker = state.queue_priority(name);
        cmd.exprs.push(Expr::Immediate {
            dreg: NFT_REG_1,
            data: marker.to_ne_bytes().to_vec(),
        });
        cmd.exprs.push(Expr::MetaSet { key: NFT_META_PRIORITY });
    }

    // Final verdict. `match` rules in pf have no terminal verdict —
    // they apply NAT/log/etc. and let processing continue. In nftables
    // that means we simply omit the verdict expression; `pass` emits
    // accept, `block` emits drop or reject.
    match (verb, cl.reject_form) {
        ("pass", _) => {
            cmd.exprs.push(Expr::Verdict { code: NF_ACCEPT, chain: String::new() });
        }
        ("match", _) => {
            // No verdict — match rules don't terminate evaluation.
        }
        ("block", None) => {
            cmd.exprs.push(Expr::Verdict { code: NF_DROP, chain: String::new() });
        }
        ("block", Some(form)) => {
            let (rt, code, has_code) = form.to_wire();
            cmd.exprs.push(Expr::RejectWith { reject_type: rt, code, has_code });
        }
        _ => unreachable!(),
    }
    Ok(cmd)
}

fn parse_limit_clauses(tokens: &mut Vec<String>) -> Result<Vec<LimitClause>, String> {
    let mut out = Vec::new();
    loop {
        match tokens.first().map(String::as_str) {
            Some(")") => { tokens.remove(0); break; }
            Some(",") => { tokens.remove(0); continue; }
            None => return Err("pf: unterminated `keep state ( ... )`".into()),
            Some(_) => {
                let kw = tokens.remove(0);
                match kw.as_str() {
                    "max-src-conn" | "max-src-states" => {
                        let n = pop_u32(tokens, &kw)?;
                        out.push(LimitClause::Connlimit { count: n });
                    }
                    "max-src-conn-rate" => {
                        // Token form is `R/T` (single token from the
                        // tokenizer, since `/` is not a token break).
                        let raw = pop_ident(tokens, "max-src-conn-rate value")?;
                        let (n, t) = raw.split_once('/')
                            .ok_or_else(|| format!("pf: bad rate `{}`", raw))?;
                        let rate: u64 = n.parse()
                            .map_err(|e| format!("pf: bad rate `{}`: {}", n, e))?;
                        let unit = limit_unit_seconds(t)?;
                        out.push(LimitClause::Rate { rate, unit });
                    }
                    "overload" => {
                        // Form: `<name>` [flush global]. The angle
                        // brackets are their own tokens.
                        expect(tokens, "<")?;
                        let name = pop_ident(tokens, "overload table name")?;
                        expect(tokens, ">")?;
                        let mut flush_global = false;
                        if tokens.first().map(String::as_str) == Some("flush") {
                            tokens.remove(0);
                            expect(tokens, "global")?;
                            flush_global = true;
                        }
                        out.push(LimitClause::Overload { name, flush_global });
                    }
                    other => {
                        return Err(format!("pf: unknown keep-state opt `{}`", other));
                    }
                }
            }
        }
    }
    Ok(out)
}

// Build the actual nft Command stream from the parsed clauses.
//
// Strategy (matches the frozen 02_srctrack_*.strace references):
//   * Emit base matches once (l4proto cmp, dport cmp, optional saddr/daddr).
//   * For `block`: emit a single rule that interleaves connlimit /
//     dynset_meter / saddr-load+dynset_add@overload in source order
//     and ends in `drop`.
//   * For `pass`: emit one rule per limit clause. connlimit-style
//     clauses end in drop; rate-only clauses end in accept; an
//     overload attaches to the FIRST connlimit clause when one is
//     present, or to the FIRST rate clause otherwise. A trailing
//     accept rule handles non-tripping packets. When the only limit
//     is a connlimit (no overload, no rate), the trailing accept is
//     omitted — the chain default policy is already accept.
fn build_pass_block_rules(
    action: i32,
    cl: PassBlockClauses,
    state: &mut ParseState,
) -> Result<Vec<Command>, String> {
    let chain = if cl.direction_out { PF_CHAIN_OUT } else { PF_CHAIN_IN };
    // from_addr / to_addr matching is emitted by push_base() below
    // so srctrack rules also gate on source/dest addresses.

    let mut out = Vec::new();

    // Pre-allocate any sets that limit clauses reference. Doing it up
    // front keeps the splice ordering deterministic regardless of
    // multi-rule expansion below.
    for c in &cl.limits {
        match c {
            LimitClause::Rate { .. } => state.ensure_meter_set("rate_limit"),
            LimitClause::Overload { name, flush_global } => {
                state.ensure_overload_set(name, *flush_global);
            }
            LimitClause::Connlimit { .. } => {}
        }
    }

    // Helper closures for the two repeated pattern fragments.
    let proto = cl.proto.unwrap_or(6); // default to tcp when only a port is given
    let port  = cl.port;

    let from_addr = cl.from_addr;
    let to_addr = cl.to_addr;
    let push_base = |exprs: &mut Vec<Expr>| {
        // Source/dest address matching (before proto/port).
        if let Some(addr) = from_addr {
            exprs.push(Expr::PayloadLoadReg {
                dreg: NFT_REG_1,
                base: NFT_PAYLOAD_NETWORK_HEADER,
                offset: 12,  // ip saddr
                len: 4,
            });
            exprs.push(Expr::Cmp { op: NFT_CMP_EQ, data: addr.to_vec() });
        }
        if let Some(addr) = to_addr {
            exprs.push(Expr::PayloadLoadReg {
                dreg: NFT_REG_1,
                base: NFT_PAYLOAD_NETWORK_HEADER,
                offset: 16,  // ip daddr
                len: 4,
            });
            exprs.push(Expr::Cmp { op: NFT_CMP_EQ, data: addr.to_vec() });
        }
        // `meta load l4proto => reg 1` + `cmp eq reg 1 <proto>` —
        // 1-byte cmp (matches the meta read width). The dump pretty-
        // prints it as LE u32 0x00000006 by zero-extending wire bytes.
        exprs.push(Expr::Meta { key: NFT_META_L4PROTO, width: 1 });
        exprs.push(Expr::Cmp { op: NFT_CMP_EQ, data: vec![proto as u8] });
        if let Some(p) = port {
            // `payload load 2b @ transport header + 2 => reg 1` + 2-
            // byte NBO cmp. Wire bytes for port 22: [0x00, 0x16]; the
            // bracketed dump prints LE-u32 0x00001600.
            exprs.push(Expr::PayloadLoadReg {
                dreg: NFT_REG_1,
                base: NFT_PAYLOAD_TRANSPORT_HEADER,
                offset: 2,
                len: 2,
            });
            let nb = p.to_be_bytes();
            exprs.push(Expr::Cmp {
                op: NFT_CMP_EQ,
                data: vec![nb[0], nb[1]],
            });
        }
    };

    let push_saddr_load = |exprs: &mut Vec<Expr>| {
        exprs.push(Expr::PayloadLoadReg {
            dreg: NFT_REG_1,
            base: NFT_PAYLOAD_NETWORK_HEADER,
            offset: 12,
            len: 4,
        });
    };

    // Find the overload (at most one per rule body) up front so it
    // can attach to the right gate.
    let overload_name: Option<String> = cl.limits.iter().find_map(|c| match c {
        LimitClause::Overload { name, .. } => Some(name.clone()),
        _ => None,
    });

    if action == NF_DROP {
        // block: ONE rule, drop.
        let mut r = new_rule(chain);
        push_base(&mut r.exprs);
        for c in &cl.limits {
            match c {
                LimitClause::Connlimit { count } => {
                    r.exprs.push(Expr::Connlimit { count: *count, inv: true });
                }
                LimitClause::Rate { rate, unit } => {
                    push_saddr_load(&mut r.exprs);
                    r.exprs.push(Expr::DynsetMeter {
                        set_name: "rate_limit".to_string(),
                        key_width: 4,
                        rate: *rate,
                        unit: *unit,
                        burst: *rate as u32,
                        limit_type: NFT_LIMIT_TYPE_PKTS,
                        limit_flags: 0,
                    });
                }
                LimitClause::Overload { name, .. } => {
                    push_saddr_load(&mut r.exprs);
                    r.exprs.push(Expr::Dynset {
                        set_name: name.clone(),
                        op: NFT_DYNSET_OP_ADD,
                        key_width: 4,
                        timeout_ms: 0,
                        set_id: None,
                    });
                }
            }
        }
        r.exprs.push(Expr::Verdict { code: NF_DROP, chain: String::new() });
        out.push(r);
    } else {
        // pass: split into per-limit rules. Track whether we've
        // already attached the overload to a connlimit-style rule —
        // pf semantics tie the overload to the FIRST gate that fires
        // when a source goes over the limit.
        let mut overload_attached = false;
        let connlimit_present = cl.limits.iter()
            .any(|c| matches!(c, LimitClause::Connlimit { .. }));

        let mut emitted_any = false;
        for c in &cl.limits {
            match c {
                LimitClause::Connlimit { count } => {
                    let mut r = new_rule(chain);
                    push_base(&mut r.exprs);
                    r.exprs.push(Expr::Connlimit { count: *count, inv: true });
                    if !overload_attached {
                        if let Some(n) = overload_name.as_ref() {
                            push_saddr_load(&mut r.exprs);
                            r.exprs.push(Expr::Dynset {
                                set_name: n.clone(),
                                op: NFT_DYNSET_OP_ADD,
                                key_width: 4,
                                timeout_ms: 0,
                                set_id: None,
                            });
                            overload_attached = true;
                        }
                    }
                    r.exprs.push(Expr::Verdict { code: NF_DROP, chain: String::new() });
                    out.push(r);
                    emitted_any = true;
                }
                LimitClause::Rate { rate, unit } => {
                    let mut r = new_rule(chain);
                    push_base(&mut r.exprs);
                    push_saddr_load(&mut r.exprs);
                    r.exprs.push(Expr::DynsetMeter {
                        set_name: "rate_limit".to_string(),
                        key_width: 4,
                        rate: *rate,
                        unit: *unit,
                        burst: *rate as u32,
                        limit_type: NFT_LIMIT_TYPE_PKTS,
                        limit_flags: 0,
                    });
                    // If the source has overload but no connlimit, the
                    // overload-add hangs off the rate clause and the
                    // verdict flips to drop (the abuser is being added
                    // to the table and dropped in the same rule).
                    let mut verdict = NF_ACCEPT;
                    if !overload_attached && !connlimit_present {
                        if let Some(n) = overload_name.as_ref() {
                            push_saddr_load(&mut r.exprs);
                            r.exprs.push(Expr::Dynset {
                                set_name: n.clone(),
                                op: NFT_DYNSET_OP_ADD,
                                key_width: 4,
                                timeout_ms: 0,
                                set_id: None,
                            });
                            overload_attached = true;
                            verdict = NF_DROP;
                        }
                    }
                    r.exprs.push(Expr::Verdict { code: verdict, chain: String::new() });
                    out.push(r);
                    emitted_any = true;
                }
                LimitClause::Overload { .. } => {
                    // Already folded into the connlimit/rate rule
                    // above — no standalone rule.
                }
            }
        }

        // Trailing accept rule. Only emitted when pass had at least
        // one limit AND that limit-mix can let an above-rate packet
        // miss every rule. The cases where a trailing accept is
        // unnecessary: the only limit was a single connlimit (no
        // overload, no rate) — pf semantics fall through to chain
        // policy=accept, and we'd be duplicating that. Same for the
        // single-rate / single-rate+overload cases (the rate rule
        // itself ends in accept or drop).
        let needs_trailing_accept = emitted_any && {
            let n_conn = cl.limits.iter()
                .filter(|c| matches!(c, LimitClause::Connlimit { .. })).count();
            let n_rate = cl.limits.iter()
                .filter(|c| matches!(c, LimitClause::Rate { .. })).count();
            // Multi-clause pass needs the trailing accept; otherwise
            // the standalone rate or single-connlimit-with-overload
            // already emits the right verdict.
            (n_conn + n_rate) >= 2 || (n_conn == 1 && overload_name.is_some())
        };
        if needs_trailing_accept {
            let mut r = new_rule(chain);
            push_base(&mut r.exprs);
            r.exprs.push(Expr::Verdict { code: NF_ACCEPT, chain: String::new() });
            out.push(r);
        }
        if !emitted_any {
            // Bare `pass` with no limits — emit a single accept rule.
            let mut r = new_rule(chain);
            push_base(&mut r.exprs);
            r.exprs.push(Expr::Verdict { code: NF_ACCEPT, chain: String::new() });
            out.push(r);
        }
    }

    Ok(out)
}

fn parse_ipv4(s: &str) -> Result<[u8; 4], String> {
    let parts: Vec<&str> = s.split('.').collect();
    if parts.len() != 4 {
        return Err(format!("pf: bad ipv4 `{}`", s));
    }
    let mut out = [0u8; 4];
    for (i, p) in parts.iter().enumerate() {
        out[i] = p.parse().map_err(|e| format!("pf: bad ipv4 octet `{}`: {}", p, e))?;
    }
    Ok(out)
}

#[derive(Debug)]
enum ScrubOpt {
    NoDf,
    RandomId,
    MinTtl(u8),
    MaxMss(u16),
}

fn parse_scrub_opt_list(tokens: &mut Vec<String>) -> Result<Vec<ScrubOpt>, String> {
    let mut opts = Vec::new();
    if tokens.first().map(String::as_str) == Some("{") {
        tokens.remove(0);
        loop {
            match tokens.first().map(String::as_str) {
                Some("}") => { tokens.remove(0); break; }
                Some(",") => { tokens.remove(0); continue; }
                None => return Err("pf: unterminated scrub option block".into()),
                _ => {
                    let opt = parse_one_scrub_opt(tokens)?;
                    opts.push(opt);
                }
            }
        }
    } else {
        // Single-form: one option, no braces.
        if !tokens.is_empty() {
            opts.push(parse_one_scrub_opt(tokens)?);
        }
    }
    Ok(opts)
}

fn parse_one_scrub_opt(tokens: &mut Vec<String>) -> Result<ScrubOpt, String> {
    let head = tokens.remove(0);
    match head.as_str() {
        "no-df" => Ok(ScrubOpt::NoDf),
        "random-id" => Ok(ScrubOpt::RandomId),
        "min-ttl" => {
            let n = pop_u32(tokens, "min-ttl")?;
            if n > 255 { return Err(format!("pf: min-ttl out of range: {}", n)); }
            Ok(ScrubOpt::MinTtl(n as u8))
        }
        "max-mss" => {
            let n = pop_u32(tokens, "max-mss")?;
            if n > 0xFFFF { return Err(format!("pf: max-mss out of range: {}", n)); }
            Ok(ScrubOpt::MaxMss(n as u16))
        }
        "reassemble" => Err("pf: `scrub reassemble` is not yet supported (deferred)".into()),
        other => Err(format!("pf: unknown scrub option `{}`", other)),
    }
}

fn lower_scrub_opt(opt: &ScrubOpt, exprs: &mut Vec<Expr>) -> Result<(), String> {
    match opt {
        ScrubOpt::NoDf => {
            exprs.push(Expr::Immediate { dreg: NFT_REG_1, data: vec![0, 0, 0, 0] });
            exprs.push(Expr::PayloadSet {
                base: NFT_PAYLOAD_NETWORK_HEADER,
                offset: 6,
                len: 2,
                sreg: NFT_REG_1,
                csum_type: NFT_PAYLOAD_CSUM_INET,
                csum_offset: 10,
                csum_flags: 0,
            });
        }
        ScrubOpt::RandomId => {
            exprs.push(Expr::Numgen { ng_type: 1, modulus: 65536, offset: 0 });
            exprs.push(Expr::Byteorder {
                sreg: NFT_REG_1, dreg: NFT_REG_1,
                op: NFT_BYTEORDER_HTON, len: 4, size: 4,
            });
            exprs.push(Expr::PayloadSet {
                base: NFT_PAYLOAD_NETWORK_HEADER,
                offset: 4,
                len: 2,
                sreg: NFT_REG_1,
                csum_type: NFT_PAYLOAD_CSUM_INET,
                csum_offset: 10,
                csum_flags: 0,
            });
        }
        ScrubOpt::MinTtl(n) => {
            exprs.push(Expr::PayloadLoadReg {
                dreg: NFT_REG_1,
                base: NFT_PAYLOAD_NETWORK_HEADER,
                offset: 8,
                len: 2,
            });
            exprs.push(Expr::BitwiseReg {
                reg: NFT_REG_1,
                mask: vec![0x00, 0xff],
                xor:  vec![*n, 0x00],
            });
            exprs.push(Expr::PayloadSet {
                base: NFT_PAYLOAD_NETWORK_HEADER,
                offset: 8,
                len: 2,
                sreg: NFT_REG_1,
                csum_type: NFT_PAYLOAD_CSUM_INET,
                csum_offset: 10,
                csum_flags: 0,
            });
        }
        ScrubOpt::MaxMss(n) => {
            let nb = n.to_be_bytes();
            exprs.push(Expr::Immediate {
                dreg: NFT_REG_1,
                data: vec![nb[0], nb[1], 0x00, 0x00],
            });
            exprs.push(Expr::ExthdrSet {
                op: NFT_EXTHDR_OP_TCPOPT,
                kind: 2,
                offset: 2,
                len: 2,
                sreg: NFT_REG_1,
            });
        }
    }
    Ok(())
}

// ── antispoof ──────────────────────────────────────────────────────

// `antispoof for <iface>` (single-iface only this PR — pf supports
// `antispoof for { em0, em1 }` but lists are deferred).
//
// Lowers to:
//   fib saddr . iif oif => reg 1
//   cmp eq reg 1 0
//   immediate reg 0 drop
//
// The kernel's `fib` lookup with flags=SADDR|IIF and result=OIF
// returns the chosen output interface's ifindex; missing routes (no
// reverse path through the same iface) yield 0.
fn parse_antispoof(tokens: &mut Vec<String>) -> Result<Command, String> {
    expect(tokens, "for")?;
    if tokens.first().map(String::as_str) == Some("{") {
        return Err("pf: `antispoof for { ... }` interface lists not yet supported".into());
    }
    let _iface = pop_ident(tokens, "iface")?;

    let mut cmd = new_rule(PF_CHAIN_IN);
    cmd.exprs.push(Expr::Fib {
        flags: NFTA_FIB_F_SADDR | NFTA_FIB_F_IIF,
        result: NFT_FIB_RESULT_OIF,
        dreg: NFT_REG_1,
    });
    cmd.exprs.push(Expr::Cmp { op: NFT_CMP_EQ, data: vec![0, 0, 0, 0] });
    cmd.exprs.push(Expr::Verdict { code: crate::netlink::NF_DROP, chain: String::new() });
    Ok(cmd)
}

// ── set skip on ────────────────────────────────────────────────────

// `set skip on <iface>` — accept everything that arrives on this
// interface so it short-circuits later filter rules. Rule body:
//   meta load iifname => reg 1
//   cmp eq reg 1 "<iface>"
//   immediate reg 0 accept
//
// The bare `set <option> = <val>` family of statements isn't parsed
// yet — we error out for anything except `set skip on` so a typo
// can't be silently dropped.
fn parse_set_skip(tokens: &mut Vec<String>) -> Result<Command, String> {
    expect(tokens, "skip")?;
    expect(tokens, "on")?;
    if tokens.first().map(String::as_str) == Some("{") {
        return Err("pf: `set skip on { ... }` interface lists not yet supported".into());
    }
    let iface = pop_ident(tokens, "iface")?;

    let mut cmd = new_rule(PF_CHAIN_IN);
    cmd.exprs.push(Expr::Meta { key: NFT_META_IIFNAME, width: 16 });
    cmd.exprs.push(Expr::Cmp { op: NFT_CMP_EQ, data: ifname_pad16(&iface) });
    cmd.exprs.push(Expr::Verdict { code: crate::netlink::NF_ACCEPT, chain: String::new() });
    Ok(cmd)
}

// IIFNAME comparisons load 16 bytes (IFNAMSIZ) into NFT_REG_1 and
// the cmp data is the same 16 bytes, NUL-padded. Callers strip
// surrounding quotes; we don't here so a quoted "lo" still works.
fn ifname_pad16(s: &str) -> Vec<u8> {
    let s = s.trim_matches('"');
    let mut v = vec![0u8; 16];
    for (i, b) in s.bytes().take(16).enumerate() { v[i] = b; }
    v
}

// ── pass / block reject forms ──────────────────────────────────────

#[derive(Copy, Clone, Debug)]
enum RejectForm {
    TcpRst,
    IcmpPortUnreach,
    IcmpHostUnreach,
    IcmpxAdminProhibited,
}

impl RejectForm {
    fn to_wire(self) -> (u32, u8, bool) {
        match self {
            // TCP_RST ignores the code on the wire — upstream nft
            // omits NFTA_REJECT_ICMP_CODE entirely. We mirror that to
            // keep the byte diff zero.
            RejectForm::TcpRst => (NFT_REJECT_TCP_RST, 0, false),
            RejectForm::IcmpPortUnreach => (NFT_REJECT_ICMP_UNREACH, ICMP_PORT_UNREACH, true),
            RejectForm::IcmpHostUnreach => (NFT_REJECT_ICMP_UNREACH, ICMP_HOST_UNREACH, true),
            RejectForm::IcmpxAdminProhibited => (
                NFT_REJECT_ICMPX_UNREACH, NFT_REJECT_ICMPX_ADMIN_PROHIBITED, true,
            ),
        }
    }
}

// `hours { LO-HI }` — accept LO and HI as either decimal seconds-since-
// midnight (the literal value the kernel matches against) or hour-of-day
// integers 0..=24. The latter is the natural pf form: `hours { 9-17 }`
// is "between 9am and 5pm".
fn parse_hours_block(tokens: &mut Vec<String>) -> Result<(u32, u32), String> {
    expect(tokens, "{")?;
    if tokens.is_empty() {
        return Err("pf: empty `hours { }`".into());
    }
    let head = tokens.remove(0);
    // Accept either a single hyphenated token (`9-17`) or three
    // tokens (`9 - 17`).
    let (lo_s, hi_s) = if let Some((a, b)) = head.split_once('-') {
        (a.to_string(), b.to_string())
    } else {
        let dash = tokens.remove(0);
        if dash != "-" {
            return Err(format!("pf: expected `-` in hours range, got `{}`", dash));
        }
        let hi = if tokens.is_empty() {
            return Err("pf: missing hours range upper bound".into());
        } else { tokens.remove(0) };
        (head, hi)
    };
    expect(tokens, "}")?;
    let lo = parse_hour_value(&lo_s)?;
    let hi = parse_hour_value(&hi_s)?;
    Ok((lo, hi))
}

fn parse_hour_value(s: &str) -> Result<u32, String> {
    let n: u32 = s.parse()
        .map_err(|e| format!("pf: bad hour value `{}`: {}", s, e))?;
    // Heuristic: 0..24 inclusive => hour-of-day, scale to seconds.
    // 24..=86400 => already seconds-since-midnight.
    if n <= 24 { Ok(n * 3600) }
    else if n <= 86400 { Ok(n) }
    else { Err(format!("pf: hour value out of range: {}", n)) }
}

// meta load TIME_HOUR -> reg 1 ; byteorder hton ; range eq reg 1 LO HI.
// LO/HI go on the wire NBO (4-byte BE) so the byteorder-swapped
// register matches them as a u32 range — the same shape upstream
// produces for `meta hour 32400-61200`.
fn lower_hours(exprs: &mut Vec<Expr>, lo: u32, hi: u32) {
    exprs.push(Expr::Meta { key: NFT_META_TIME_HOUR, width: 4 });
    exprs.push(Expr::Byteorder {
        sreg: NFT_REG_1, dreg: NFT_REG_1,
        op: NFT_BYTEORDER_HTON, len: 4, size: 4,
    });
    let lo_be = lo.to_be_bytes().to_vec();
    let hi_be = hi.to_be_bytes().to_vec();
    exprs.push(Expr::Range {
        sreg: NFT_REG_1, op: NFT_RANGE_EQ,
        from: lo_be, to: hi_be,
    });
}

// `days { mon, tue, wed, thu, fri }` or `days { mon-fri }` or any
// mix. Returns a sorted unique list of weekday integers, where
// Sunday=0 .. Saturday=6 (matching the kernel's NFT_META_TIME_DAY).
fn parse_days_block(tokens: &mut Vec<String>) -> Result<Vec<u8>, String> {
    expect(tokens, "{")?;
    let mut days = Vec::new();
    loop {
        match tokens.first().map(String::as_str) {
            Some("}") => { tokens.remove(0); break; }
            Some(",") => { tokens.remove(0); continue; }
            None => return Err("pf: unterminated `days {`".into()),
            _ => {
                let head = tokens.remove(0);
                // Either `mon` or `mon-fri` (single hyphenated token)
                // or `mon - fri` (three tokens).
                if let Some((a, b)) = head.split_once('-') {
                    let a = day_to_int(a)?;
                    let b = day_to_int(b)?;
                    fill_day_range(&mut days, a, b);
                } else if tokens.first().map(String::as_str) == Some("-") {
                    tokens.remove(0);
                    let bn = pop_ident(tokens, "day name")?;
                    let a = day_to_int(&head)?;
                    let b = day_to_int(&bn)?;
                    fill_day_range(&mut days, a, b);
                } else {
                    days.push(day_to_int(&head)?);
                }
            }
        }
    }
    days.sort();
    days.dedup();
    Ok(days)
}

fn day_to_int(s: &str) -> Result<u8, String> {
    // Strip optional surrounding quotes (some pf dialects quote names).
    let s = s.trim_matches('"').to_ascii_lowercase();
    Ok(match s.as_str() {
        "sun" | "sunday" | "0" => 0,
        "mon" | "monday" | "1" => 1,
        "tue" | "tuesday" | "2" => 2,
        "wed" | "wednesday" | "3" => 3,
        "thu" | "thursday" | "4" => 4,
        "fri" | "friday" | "5" => 5,
        "sat" | "saturday" | "6" => 6,
        other => return Err(format!("pf: unknown day name `{}`", other)),
    })
}

fn fill_day_range(out: &mut Vec<u8>, lo: u8, hi: u8) {
    if lo <= hi {
        for d in lo..=hi { out.push(d); }
    } else {
        // Wrap-around (e.g. `fri-mon` = fri, sat, sun, mon).
        for d in lo..=6 { out.push(d); }
        for d in 0..=hi { out.push(d); }
    }
}

// Anonymous-set lookup. Each weekday is a 1-byte key but the kernel
// stores set elements in 4-byte slots padded LE — strace shows
// `element 00000001` for Monday. The encoder takes raw bytes; we
// hand it the 4-byte little-endian width so the wire matches.
fn lower_days(exprs: &mut Vec<Expr>, days: &[u8]) {
    exprs.push(Expr::Meta { key: NFT_META_TIME_DAY, width: 1 });
    let elements: Vec<(Vec<u8>, Option<Vec<u8>>)> = days.iter().map(|d| {
        // The kernel stores TIME_DAY as a u8 but cmp-via-set lookup
        // reads back in 1-byte width matching the meta load. Pad to
        // 1 byte (NLA payload) — the encoder will round-up to the 4-
        // byte minimum on wire automatically.
        (vec![*d], None)
    }).collect();
    exprs.push(Expr::AnonSet { elements, width: 1, inverted: false });
}

/// Parse a pf `table <name> persist [counters] [{ addr, ... }]`
/// declaration. Lowers to one or two Commands: a NEWSET for the named
/// set, plus optionally a NEWSETELEM if initial elements were given.
fn parse_table_decl(tokens: &mut Vec<String>) -> Result<Vec<Command>, String> {
    expect(tokens, "<")?;
    let name = pop_ident(tokens, "table name")?;
    expect(tokens, ">")?;

    let mut _persist = false;
    let mut _counters = false;
    // Consume optional `persist` / `counters` modifiers.
    loop {
        match tokens.first().map(String::as_str) {
            Some("persist")  => { tokens.remove(0); _persist = true; }
            Some("counters") => { tokens.remove(0); _counters = true; }
            _ => break,
        }
    }

    // Build NEWSET command. Type is ipv4_addr with interval flag so
    // CIDR elements are supported.
    let mut set_cmd = Command::default();
    set_cmd.op = CmdOp::Add;
    set_cmd.obj = CmdObj::Set;
    set_cmd.family = NFPROTO_IPV4;
    set_cmd.table = PF_TABLE.to_string();
    set_cmd.set_name = name.clone();
    set_cmd.set_spec = SetSpec {
        key_type_name: "ipv4_addr".to_string(),
        key_type: 7,   // NFT_DATATYPE_IPADDR
        key_len: 4,
        data_type_name: String::new(),
        data_type: 0,
        data_len: 0,
        flags: 0x40, // NFT_SET_INTERVAL
        has_flags: true,
        is_map: false,
        is_obj_map: false,
        obj_type: 0,
        size: 0,
        timeout_ms: 0,
        has_timeout: false,
        concat_widths: Vec::new(),
    };
    let mut out = vec![set_cmd];

    // Parse optional initial elements: `{ addr, addr, ... }`
    if tokens.first().map(String::as_str) == Some("{") {
        tokens.remove(0);
        let mut elems: Vec<(Vec<u8>, Option<Vec<u8>>)> = Vec::new();
        loop {
            match tokens.first().map(String::as_str) {
                Some("}") => { tokens.remove(0); break; }
                Some(",") => { tokens.remove(0); continue; }
                None => break,
                Some(_) => {
                    let raw = tokens.remove(0);
                    // CIDR: 10.0.0.0/8 → range [10.0.0.0, 10.255.255.255]
                    if let Some((addr_str, prefix_str)) = raw.split_once('/') {
                        let addr = parse_ipv4(addr_str)?;
                        let prefix: u32 = prefix_str.parse()
                            .map_err(|e| format!("pf: bad CIDR prefix: {}", e))?;
                        let mask = if prefix == 0 { 0u32 } else { !0u32 << (32 - prefix) };
                        let start = u32::from_be_bytes(addr) & mask;
                        let end = start | !mask;
                        elems.push((start.to_be_bytes().to_vec(), Some(end.to_be_bytes().to_vec())));
                    } else {
                        let addr = parse_ipv4(&raw)?;
                        elems.push((addr.to_vec(), None));
                    }
                }
            }
        }
        if !elems.is_empty() {
            let mut elem_cmd = Command::default();
            elem_cmd.op = CmdOp::Add;
            elem_cmd.obj = CmdObj::Element;
            elem_cmd.family = NFPROTO_IPV4;
            elem_cmd.table = PF_TABLE.to_string();
            elem_cmd.set_name = name;
            elem_cmd.elements = elems;
            out.push(elem_cmd);
        }
    }

    Ok(out)
}

/// Resolve an interface name to its kernel index. Returns 0 if the
/// interface doesn't exist (the rule still encodes without a device).
fn iface_index(name: &str) -> u32 {
    #[cfg(target_os = "linux")]
    {
        let cname = std::ffi::CString::new(name).unwrap_or_default();
        let idx = unsafe { libc::if_nametoindex(cname.as_ptr()) };
        idx
    }
    #[cfg(not(target_os = "linux"))]
    {
        let _ = name;
        0
    }
}

/// Convert a pf flag-letter string like `"SA"` to a TCP flags bitmask.
/// Layout matches the 13th byte of the TCP header: FIN=1, SYN=2,
/// RST=4, PSH=8, ACK=16, URG=32, ECE=64, CWR=128.
fn tcp_flag_byte(s: &str) -> Result<u8, String> {
    let mut v: u8 = 0;
    for c in s.chars() {
        v |= match c {
            'F' => 0x01,
            'S' => 0x02,
            'R' => 0x04,
            'P' => 0x08,
            'A' => 0x10,
            'U' => 0x20,
            'E' => 0x40,
            'W' => 0x80,
            other => return Err(format!("pf: unknown TCP flag `{}`", other)),
        };
    }
    Ok(v)
}

// ── Token helpers ──────────────────────────────────────────────────

fn expect(tokens: &mut Vec<String>, want: &str) -> Result<(), String> {
    match tokens.first() {
        Some(t) if t == want => { tokens.remove(0); Ok(()) }
        Some(t) => Err(format!("pf: expected `{}`, got `{}`", want, t)),
        None => Err(format!("pf: expected `{}`, got end-of-input", want)),
    }
}

fn pop_ident(tokens: &mut Vec<String>, label: &str) -> Result<String, String> {
    if tokens.is_empty() {
        return Err(format!("pf: expected {}", label));
    }
    Ok(tokens.remove(0))
}

fn pop_u32(tokens: &mut Vec<String>, label: &str) -> Result<u32, String> {
    if tokens.is_empty() {
        return Err(format!("pf: expected {}", label));
    }
    let t = tokens.remove(0);
    t.parse::<u32>().map_err(|e| format!("pf: bad {} `{}`: {}", label, t, e))
}

// Tokenizer: comments to EOL with `#`; `{` `}` `,` `(` `)` `<` `>` are
// their own tokens (the latter four needed for `keep state ( ... )`
// and `overload <table>`). The `/` inside `5/second` is NOT a token
// break — limit clauses parse the rate-pair as a single token.
fn tokenize(input: &str) -> Vec<String> {
    let mut out = Vec::new();
    for line in input.lines() {
        let line = match line.find('#') {
            Some(i) => &line[..i],
            None => line,
        };
        let mut cur = String::new();
        for c in line.chars() {
            if c.is_whitespace() {
                if !cur.is_empty() { out.push(std::mem::take(&mut cur)); }
            } else if matches!(c, '{' | '}' | ',' | '(' | ')' | '<' | '>') {
                if !cur.is_empty() { out.push(std::mem::take(&mut cur)); }
                out.push(c.to_string());
            } else {
                cur.push(c);
            }
        }
        if !cur.is_empty() { out.push(cur); }
    }
    out
}

/// Pretty-print a parsed Command stream in the same bracketed format
/// `nft --debug=netlink` uses, so the pf-parity harness can diff against
/// the frozen strace captures under tests/pf-corpus/strace/. Output
/// shape:
///     ip <table> <chain> use 0
///     ip <table> <chain>
///       [ <expr> args ]
///       ...
/// One block per `add rule` Command; table/chain Commands are skipped
/// because the upstream `--debug=netlink` output also skips them.
pub fn dump_exprs(cmds: &[Command]) -> String {
    use crate::parser::{CmdObj, Expr};
    use crate::netlink::{NFT_PAYLOAD_NETWORK_HEADER, NFT_PAYLOAD_TRANSPORT_HEADER};
    let mut out = String::new();
    let family_str = |f: u8| -> &'static str {
        match f {
            crate::netlink::NFPROTO_IPV4 => "ip",
            crate::netlink::NFPROTO_IPV6 => "ip6",
            crate::netlink::NFPROTO_INET => "inet",
            _ => "ip",
        }
    };
    // Anon-set placeholder counter — the real ops compiler picks a
    // `__setN` name when it lowers AnonSet to Lookup, but the dump
    // path runs without an NftCtx so we synthesise `__set%d` to mirror
    // upstream nft's monitor display for unresolved anon sets.
    for cmd in cmds {
        if !matches!(cmd.obj, CmdObj::Rule) { continue; }
        let fam = family_str(cmd.family);
        out.push_str(&format!("{} {} {} use 0\n", fam, cmd.table, cmd.chain));
        out.push_str(&format!("{} {} {}\n", fam, cmd.table, cmd.chain));
        // NAT/masquerade are terminal in nft — suppress the trailing
        // accept verdict that the pf lowering appends for "pass" rules.
        let has_nat = cmd.exprs.iter().any(|e|
            matches!(e, Expr::Nat { .. } | Expr::Masquerade { .. }));
        for e in &cmd.exprs {
            match e {
                Expr::Immediate { dreg, data } => {
                    let v = if data.len() == 4 {
                        u32::from_le_bytes([data[0], data[1], data[2], data[3]])
                    } else { 0 };
                    out.push_str(&format!("  [ immediate reg {} 0x{:08x} ]\n",
                        reg_name(*dreg), v));
                }
                Expr::PayloadLoadReg { dreg, base, offset, len } => {
                    out.push_str(&format!(
                        "  [ payload load {}b @ {} + {} => reg {} ]\n",
                        len, base_name(*base), offset, reg_name(*dreg)));
                    let _ = (NFT_PAYLOAD_NETWORK_HEADER, NFT_PAYLOAD_TRANSPORT_HEADER);
                }
                Expr::BitwiseReg { reg, mask, xor } => {
                    fn le_u32(v: &[u8]) -> u32 {
                        let mut b = [0u8; 4];
                        for i in 0..v.len().min(4) { b[i] = v[i]; }
                        u32::from_le_bytes(b)
                    }
                    out.push_str(&format!(
                        "  [ bitwise reg {} = ( reg {} & 0x{:08x} ) ^ 0x{:08x} ]\n",
                        reg_name(*reg), reg_name(*reg), le_u32(mask), le_u32(xor)));
                }
                Expr::PayloadSet { base, offset, len, sreg, csum_type, csum_offset, csum_flags } => {
                    out.push_str(&format!(
                        "  [ payload write reg {} => {}b @ {} + {} csum_type {} csum_off {} csum_flags 0x{:x} ]\n",
                        reg_name(*sreg), len, base_name(*base), offset,
                        csum_type, csum_offset, csum_flags));
                }
                Expr::ExthdrSet { op, kind, offset, len, sreg } => {
                    let op_name = if *op == crate::netlink::NFT_EXTHDR_OP_TCPOPT { "tcpopt" } else { "exthdr" };
                    out.push_str(&format!(
                        "  [ exthdr write {} reg {} => {}b @ {} + {} ]\n",
                        op_name, reg_name(*sreg), len, kind, offset));
                }
                Expr::Numgen { ng_type, modulus, offset: _ } => {
                    let typ = if *ng_type == 1 { "random" } else { "incremental" };
                    out.push_str(&format!(
                        "  [ numgen reg {} = {} mod {} ]\n",
                        reg_name(crate::netlink::NFT_REG_1), typ, modulus));
                }
                Expr::Byteorder { sreg, dreg, op, len, size } => {
                    let opn = if *op == crate::netlink::NFT_BYTEORDER_HTON { "hton" } else { "ntoh" };
                    out.push_str(&format!(
                        "  [ byteorder reg {} = {}(reg {}, {}, {}) ]\n",
                        reg_name(*dreg), opn, reg_name(*sreg), len, size));
                }
                Expr::Meta { key, .. } => {
                    out.push_str(&format!(
                        "  [ meta load {} => reg {} ]\n",
                        meta_key_name(*key), reg_name(crate::netlink::NFT_REG_1)));
                }
                Expr::Cmp { op, data } => {
                    // Upstream prints cmp data as one or more LE u32
                    // chunks separated by spaces. 16-byte iifname
                    // values become four chunks; smaller values are
                    // padded to one chunk.
                    let opn = match *op {
                        crate::netlink::NFT_CMP_EQ => "eq",
                        crate::netlink::NFT_CMP_NEQ => "neq",
                        crate::netlink::NFT_CMP_LT => "lt",
                        crate::netlink::NFT_CMP_LTE => "lte",
                        crate::netlink::NFT_CMP_GT => "gt",
                        crate::netlink::NFT_CMP_GTE => "gte",
                        _ => "eq",
                    };
                    let chunks = chunk_data(data);
                    out.push_str(&format!(
                        "  [ cmp {} reg {}{} ]\n",
                        opn, reg_name(crate::netlink::NFT_REG_1), chunks));
                }
                Expr::Verdict { code, chain } => {
                    // nft considers NAT/masquerade terminal — suppress
                    // the accept verdict that pf "pass" rules append.
                    if has_nat && *code == crate::netlink::NF_ACCEPT {
                        continue;
                    }
                    let v = verdict_name(*code);
                    if chain.is_empty() {
                        out.push_str(&format!("  [ immediate reg 0 {} ]\n", v));
                    } else {
                        out.push_str(&format!(
                            "  [ immediate reg 0 {} -> {} ]\n", v, chain));
                    }
                }
                Expr::Fib { flags, result, dreg } => {
                    out.push_str(&format!(
                        "  [ fib {} {} => reg {} ]\n",
                        fib_flags_name(*flags), fib_result_name(*result),
                        reg_name(*dreg)));
                }
                Expr::Range { sreg, op, from, to } => {
                    let opn = if *op == crate::netlink::NFT_RANGE_EQ { "eq" } else { "neq" };
                    let fc = chunk_data(from);
                    let tc = chunk_data(to);
                    out.push_str(&format!(
                        "  [ range {} reg {}{}{} ]\n",
                        opn, reg_name(*sreg), fc, tc));
                }
                Expr::RejectWith { reject_type, code, has_code } => {
                    let c = if *has_code { *code } else { 0 };
                    out.push_str(&format!(
                        "  [ reject type {} code {} ]\n", reject_type, c));
                }
                Expr::AnonSet { elements, .. } => {
                    // Anon set lookup placeholder — upstream renders
                    // the lookup expression instead, but for the dump
                    // the harness only looks at the bracketed lines
                    // up to the lookup line. Emit a single-line
                    // "  [ lookup reg 1 set __set%d ]" so the diff
                    // matches upstream's dump format.
                    let _ = elements;
                    out.push_str(&format!(
                        "  [ lookup reg {} set __set%d ]\n",
                        reg_name(crate::netlink::NFT_REG_1)));
                }
                Expr::Connlimit { count, inv } => {
                    // Upstream always prints `flags N` (even N=0 when
                    // not over). The frozen straces include `flags 1`
                    // for the over-form; matching that.
                    let f = if *inv { 1 } else { 0 };
                    out.push_str(&format!("  [ connlimit count {} flags {} ]\n",
                        count, f));
                }
                Expr::Dynset { set_name, op: _, key_width: _, timeout_ms: _, set_id: _ } => {
                    out.push_str(&format!(
                        "  [ dynset add reg_key 1 set {} ]\n", set_name));
                }
                Expr::DynsetMeter { set_name, key_width: _, rate, unit, burst, .. } => {
                    // Render `unit` back to the source-side name. Only
                    // the cases pf-parser can emit are listed; other
                    // values won't occur.
                    let un = match *unit {
                        1     => "second",
                        60    => "minute",
                        3600  => "hour",
                        86400 => "day",
                        604800 => "week",
                        _ => "second",
                    };
                    out.push_str(&format!(
                        "  [ dynset add reg_key 1 set {} expr [ limit rate {}/{} burst {} type packets flags 0x0 ] ]\n",
                        set_name, rate, un, burst));
                }
                Expr::Log { prefix } => {
                    if prefix.is_empty() {
                        out.push_str("  [ log ]\n");
                    } else {
                        out.push_str(&format!("  [ log prefix {} ]\n", prefix));
                    }
                }
                Expr::Dup { addr, dev } => {
                    let addr_val = if addr.len() >= 4 {
                        u32::from_le_bytes([addr[0], addr[1], addr[2], addr[3]])
                    } else { 0 };
                    out.push_str(&format!("  [ immediate reg 1 0x{:08x} ]\n", addr_val));
                    if let Some(d) = dev {
                        out.push_str(&format!("  [ immediate reg 2 0x{:08x} ]\n", d));
                        out.push_str("  [ dup sreg_addr 1 sreg_dev 2 ]\n");
                    } else {
                        out.push_str("  [ dup sreg_addr 1 ]\n");
                    }
                }
                Expr::Masquerade { flags } => {
                    if *flags == 0 {
                        out.push_str("  [ masq ]\n");
                    } else {
                        out.push_str(&format!("  [ masq flags 0x{:x} ]\n", flags));
                    }
                }
                Expr::Nat { nat_type, family, addr, port, has_addr, has_port, flags, .. } => {
                    if *has_addr && addr.len() >= 4 {
                        let v = u32::from_le_bytes([addr[0], addr[1], addr[2], addr[3]]);
                        out.push_str(&format!("  [ immediate reg 1 0x{:08x} ]\n", v));
                    }
                    if *has_port && *port != 0 {
                        let p_be = (*port as u16).to_be() as u32;
                        out.push_str(&format!("  [ immediate reg 2 0x{:08x} ]\n", p_be));
                    }
                    let nat_name = if *nat_type == crate::netlink::NFT_NAT_SNAT { "snat" } else { "dnat" };
                    let fam = family_str(*family);
                    let mut s = format!("  [ nat {} {}", nat_name, fam);
                    if *has_addr { s.push_str(" addr_min reg 1"); }
                    if *has_port && *port != 0 { s.push_str(" proto_min reg 2"); }
                    if *flags != 0 { s.push_str(&format!(" flags 0x{:x}", flags)); }
                    s.push_str(" ]\n");
                    out.push_str(&s);
                }
                Expr::Notrack => {
                    out.push_str("  [ notrack ]\n");
                }
                Expr::Counter => {
                    out.push_str("  [ counter pkts 0 bytes 0 ]\n");
                }
                Expr::MetaSet { key } => {
                    out.push_str(&format!("  [ meta set {} with reg 1 ]\n", meta_key_name(*key)));
                }
                _ => out.push_str("  [ <unsupported in dump-exprs> ]\n"),
            }
        }
    }
    out
}

fn reg_name(r: u32) -> String {
    match r {
        crate::netlink::NFT_REG_VERDICT => "0".to_string(),
        crate::netlink::NFT_REG_1 => "1".to_string(),
        crate::netlink::NFT_REG_2 => "2".to_string(),
        crate::netlink::NFT_REG32_00 => "1".to_string(),
        crate::netlink::NFT_REG32_01 => "2".to_string(),
        n => n.to_string(),
    }
}

fn base_name(b: u32) -> &'static str {
    match b {
        crate::netlink::NFT_PAYLOAD_LL_HEADER => "link layer header",
        crate::netlink::NFT_PAYLOAD_NETWORK_HEADER => "network header",
        crate::netlink::NFT_PAYLOAD_TRANSPORT_HEADER => "transport header",
        _ => "?",
    }
}

fn meta_key_name(k: u32) -> &'static str {
    match k {
        crate::netlink::NFT_META_LEN => "len",
        crate::netlink::NFT_META_PROTOCOL => "protocol",
        crate::netlink::NFT_META_PRIORITY => "priority",
        crate::netlink::NFT_META_MARK => "mark",
        crate::netlink::NFT_META_IIF => "iif",
        crate::netlink::NFT_META_OIF => "oif",
        crate::netlink::NFT_META_IIFNAME => "iifname",
        crate::netlink::NFT_META_OIFNAME => "oifname",
        crate::netlink::NFT_META_NFPROTO => "nfproto",
        crate::netlink::NFT_META_L4PROTO => "l4proto",
        crate::netlink::NFT_META_PKTTYPE => "pkttype",
        crate::netlink::NFT_META_CPU => "cpu",
        crate::netlink::NFT_META_CGROUP => "cgroup",
        crate::netlink::NFT_META_TIME_DAY => "day",
        crate::netlink::NFT_META_TIME_HOUR => "hour",
        _ => "?",
    }
}

fn verdict_name(code: i32) -> &'static str {
    use crate::netlink::*;
    if code == NF_ACCEPT { "accept" }
    else if code == NF_DROP { "drop" }
    else if code == NFT_RETURN { "return" }
    else if code == NFT_JUMP { "jump" }
    else if code == NFT_GOTO { "goto" }
    else if code == NFT_CONTINUE { "continue" }
    else { "verdict" }
}

fn fib_flags_name(flags: u32) -> String {
    use crate::netlink::*;
    let mut parts: Vec<&str> = Vec::new();
    if flags & NFTA_FIB_F_SADDR != 0 { parts.push("saddr"); }
    if flags & NFTA_FIB_F_DADDR != 0 { parts.push("daddr"); }
    if flags & NFTA_FIB_F_MARK  != 0 { parts.push("mark"); }
    if flags & NFTA_FIB_F_IIF   != 0 { parts.push("iif"); }
    if flags & NFTA_FIB_F_OIF   != 0 { parts.push("oif"); }
    parts.join(" . ")
}

fn fib_result_name(r: u32) -> &'static str {
    // Upstream nft's `--debug=netlink` renderer prints the OIF result
    // as the two-word form "oif present" — "oif" is the result kind,
    // "present" is the existence-check modifier the kernel's nft_fib
    // expression always implies for OIF (returns 0 when no route).
    // The string match is what the pf-parity harness diffs against,
    // so we mirror it verbatim.
    use crate::netlink::*;
    if r == NFT_FIB_RESULT_OIF { "oif present" }
    else if r == NFT_FIB_RESULT_OIFNAME { "oifname" }
    else if r == NFT_FIB_RESULT_ADDRTYPE { "type" }
    else { "?" }
}

// Format raw bytes as the LE-u32 chunk listing upstream nft prints.
// Empty input yields no output; otherwise leading space.
fn chunk_data(data: &[u8]) -> String {
    if data.is_empty() { return String::new(); }
    // Pad up to 4-byte multiple.
    let mut padded = data.to_vec();
    while padded.len() % 4 != 0 { padded.push(0); }
    let mut s = String::new();
    for chunk in padded.chunks(4) {
        let v = u32::from_le_bytes([chunk[0], chunk[1], chunk[2], chunk[3]]);
        s.push_str(&format!(" 0x{:08x}", v));
    }
    s
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn tokenize_basic() {
        let t = tokenize("scrub on em0 { no-df, random-id }");
        assert_eq!(t, vec!["scrub", "on", "em0", "{", "no-df", ",", "random-id", "}"]);
    }

    #[test]
    fn parse_no_df() {
        let cmds = parse_file("scrub on em0 no-df\n").unwrap();
        // table + chain + 1 rule.
        assert_eq!(cmds.len(), 3);
        let exprs = &cmds[2].exprs;
        assert_eq!(exprs.len(), 2, "no-df = imm + payload-write");
    }

    #[test]
    fn parse_combined() {
        let cmds = parse_file("scrub on em0 { no-df, random-id, min-ttl 64, max-mss 1440 }\n").unwrap();
        assert_eq!(cmds.len(), 3);
        let exprs = &cmds[2].exprs;
        // 2 (no-df) + 3 (random-id) + 3 (min-ttl) + 2 (max-mss) = 10.
        assert_eq!(exprs.len(), 10, "combined scrub: 4 sub-features in one rule");
    }

    #[test]
    fn parse_antispoof() {
        let cmds = parse_file("antispoof for em0\n").unwrap();
        // table + in-chain + 1 rule.
        assert_eq!(cmds.len(), 3);
        let exprs = &cmds[2].exprs;
        assert_eq!(exprs.len(), 3, "antispoof = fib + cmp + drop verdict");
    }

    #[test]
    fn parse_set_skip() {
        let cmds = parse_file("set skip on lo\n").unwrap();
        assert_eq!(cmds.len(), 3);
        let exprs = &cmds[2].exprs;
        assert_eq!(exprs.len(), 3, "set skip = meta-load + cmp + accept verdict");
    }

    #[test]
    fn parse_block_return_rst() {
        let cmds = parse_file("block return-rst proto tcp port 22\n").unwrap();
        assert_eq!(cmds.len(), 3);
        let exprs = &cmds[2].exprs;
        // l4proto-meta + l4proto-cmp + payload-load(dport) + dport-cmp + reject-with.
        assert_eq!(exprs.len(), 5);
        match exprs.last().unwrap() {
            Expr::RejectWith { reject_type, .. } =>
                assert_eq!(*reject_type, NFT_REJECT_TCP_RST),
            other => panic!("expected RejectWith, got {:?}", other),
        }
    }

    #[test]
    fn parse_hours_block() {
        let cmds = parse_file("pass in proto tcp port 22 hours { 9-17 }\n").unwrap();
        let exprs = &cmds[2].exprs;
        // proto-meta + proto-cmp + dport-load + dport-cmp + hour-meta
        // + hour-byteorder + range + accept.
        assert_eq!(exprs.len(), 8);
        match &exprs[6] {
            Expr::Range { from, to, .. } => {
                assert_eq!(from, &[0, 0, 0x7e, 0x90]); // 32400 NBO
                assert_eq!(to,   &[0, 0, 0xef, 0x10]); // 61200 NBO
            }
            other => panic!("expected Range, got {:?}", other),
        }
    }

    #[test]
    fn parse_nat_to_masquerade() {
        let cmds = parse_file("match out nat-to (egress)\n").unwrap();
        assert!(cmds.len() >= 3); // table + chain + rule
        let rule = &cmds[2];
        assert!(rule.exprs.iter().any(|e| matches!(e, Expr::Masquerade { .. })),
            "expected Masquerade expr");
    }

    #[test]
    fn parse_nat_to_snat() {
        let cmds = parse_file("match out nat-to 198.51.100.1 port 1024\n").unwrap();
        let rule = &cmds[2];
        let nat = rule.exprs.iter().find(|e| matches!(e, Expr::Nat { .. }));
        assert!(nat.is_some(), "expected Nat expr");
        match nat.unwrap() {
            Expr::Nat { nat_type, addr, has_addr, has_port, port, .. } => {
                assert_eq!(*nat_type, NFT_NAT_SNAT);
                assert_eq!(addr, &[198, 51, 100, 1]);
                assert!(*has_addr);
                assert!(*has_port);
                assert_eq!(*port, 1024);
            }
            _ => unreachable!(),
        }
    }

    #[test]
    fn parse_rdr_to() {
        let cmds = parse_file("pass in rdr-to 10.0.0.1 port 8080 proto tcp port 80\n").unwrap();
        let rule = &cmds[2];
        let nat = rule.exprs.iter().find(|e| matches!(e, Expr::Nat { .. }));
        assert!(nat.is_some(), "expected Nat (DNAT) expr");
        match nat.unwrap() {
            Expr::Nat { nat_type, addr, port, .. } => {
                assert_eq!(*nat_type, NFT_NAT_DNAT);
                assert_eq!(addr, &[10, 0, 0, 1]);
                assert_eq!(*port, 8080);
            }
            _ => unreachable!(),
        }
    }

    #[test]
    fn parse_table_with_elements() {
        let cmds = parse_file(
            "table <blocklist> persist { 10.0.0.0/8, 192.168.1.1 }\n"
        ).unwrap();
        // Should produce: table + chain + NEWSET + NEWSETELEM
        // (table and chain come from the implicit pf scaffold)
        let sets: Vec<_> = cmds.iter().filter(|c| matches!(c.obj, CmdObj::Set)).collect();
        assert_eq!(sets.len(), 1, "expected one NEWSET command");
        assert_eq!(sets[0].set_name, "blocklist");
        let elems: Vec<_> = cmds.iter().filter(|c| matches!(c.obj, CmdObj::Element)).collect();
        assert_eq!(elems.len(), 1, "expected one NEWSETELEM command");
        assert_eq!(elems[0].elements.len(), 2, "expected 2 elements (CIDR + host)");
        // First element is a CIDR range: 10.0.0.0 - 10.255.255.255
        let (ref lo, ref hi) = elems[0].elements[0];
        assert_eq!(lo, &[10, 0, 0, 0]);
        assert_eq!(hi, &Some(vec![10, 255, 255, 255]));
    }

    #[test]
    fn parse_anchor_inline() {
        let cmds = parse_file(concat!(
            "anchor \"child\" {\n",
            "  pass in proto tcp port 80\n",
            "}\n",
        )).unwrap();
        // table + in-chain + regular-chain("child") + rule(in child) + jump-rule
        let chains: Vec<_> = cmds.iter().filter(|c| matches!(c.obj, CmdObj::Chain)).collect();
        assert_eq!(chains.len(), 2, "expected in-chain + child chain");
        assert!(chains.iter().any(|c| c.chain == "child"), "expected child chain");
        // The last rule should be a jump to "child" in the `in` chain.
        let last = cmds.last().unwrap();
        assert_eq!(last.chain, PF_CHAIN_IN);
        match last.exprs.last().unwrap() {
            Expr::Verdict { code, chain } => {
                assert_eq!(*code, NFT_JUMP);
                assert_eq!(chain, "child");
            }
            other => panic!("expected jump verdict, got {:?}", other),
        }
    }

    #[test]
    fn parse_no_state() {
        let cmds = parse_file("pass in proto tcp port 22 no state\n").unwrap();
        let rule = &cmds[2];
        assert!(rule.exprs.iter().any(|e| matches!(e, Expr::Notrack)),
            "expected Notrack expr for `no state`");
    }

    #[test]
    fn parse_tcp_flags() {
        let cmds = parse_file("pass in proto tcp port 80 flags S/SA\n").unwrap();
        let rule = &cmds[2];
        // Should have a bitwise mask expression.
        assert!(rule.exprs.iter().any(|e| matches!(e, Expr::BitwiseReg { .. })),
            "expected BitwiseReg for tcp flags");
    }

    #[test]
    fn parse_keep_state_bare() {
        // `keep state` without `(...)` should parse without error.
        let cmds = parse_file("pass in proto tcp port 22 keep state\n").unwrap();
        assert!(cmds.len() >= 3, "expected table + chain + rule");
    }

    #[test]
    fn parse_pass_out_direction() {
        let cmds = parse_file("pass out proto tcp port 443\n").unwrap();
        // Should have an `out` chain.
        let chains: Vec<_> = cmds.iter()
            .filter(|c| matches!(c.obj, CmdObj::Chain))
            .collect();
        assert!(chains.iter().any(|c| c.chain == PF_CHAIN_OUT),
            "expected an output chain for `pass out`");
        let rule = cmds.last().unwrap();
        assert_eq!(rule.chain, PF_CHAIN_OUT, "rule should be in the out chain");
    }

    #[test]
    fn parse_queue_rule_action() {
        // `pass out proto tcp port 22 queue bulk` should emit
        // Immediate(marker) + MetaSet(PRIORITY) before the verdict.
        let cmds = parse_file("pass out proto tcp port 22 queue bulk\n").unwrap();
        let rule = cmds.last().unwrap();
        // Look for MetaSet { key: NFT_META_PRIORITY } in the expressions
        let has_meta_set = rule.exprs.iter().any(|e| matches!(e, Expr::MetaSet { key } if *key == crate::netlink::NFT_META_PRIORITY));
        assert!(has_meta_set, "expected MetaSet(PRIORITY) expression for queue clause");
        // Should be preceded by an Immediate loading the marker
        let has_immediate = rule.exprs.iter().any(|e| matches!(e, Expr::Immediate { .. }));
        assert!(has_immediate, "expected Immediate expression before MetaSet");
    }

    #[test]
    fn parse_queue_paren_form() {
        // `pass out queue (bulk, urgent)` — paren form with two queues
        let cmds = parse_file("pass out queue (bulk, urgent)\n").unwrap();
        let rule = cmds.last().unwrap();
        let has_meta_set = rule.exprs.iter().any(|e| matches!(e, Expr::MetaSet { key } if *key == crate::netlink::NFT_META_PRIORITY));
        assert!(has_meta_set, "expected MetaSet for queue clause with parens");
    }

    #[test]
    fn parse_altq_declaration() {
        let input = "altq on em0 hfsc bandwidth 100Mb queue { bulk, priority }\n\
                      pass out proto tcp port 22 queue bulk\n";
        let result = parse_file_full(input).unwrap();
        assert!(result.altq_root.is_some(), "expected altq root");
        let root = result.altq_root.unwrap();
        assert_eq!(root.iface, "em0");
        assert_eq!(root.discipline, "hfsc");
        assert_eq!(root.bandwidth_bps, 100_000_000 / 8);
        assert_eq!(root.child_queues, vec!["bulk", "priority"]);
        // Both "bulk" and "priority" should have markers allocated
        assert!(result.queue_map.contains_key("bulk"));
        assert!(result.queue_map.contains_key("priority"));
    }

    #[test]
    fn parse_queue_declaration() {
        let input = "queue bulk bandwidth 10Mb qlimit 50\n";
        let result = parse_file_full(input).unwrap();
        assert_eq!(result.queue_decls.len(), 1);
        let q = &result.queue_decls[0];
        assert_eq!(q.name, "bulk");
        assert_eq!(q.bandwidth_bps, Some(10_000_000 / 8));
        assert_eq!(q.qlimit, Some(50));
    }

    #[test]
    fn parse_bandwidth_units() {
        assert_eq!(parse_bandwidth("100Mb").unwrap(), 100_000_000 / 8);
        assert_eq!(parse_bandwidth("10Gb").unwrap(), 10_000_000_000 / 8);
        assert_eq!(parse_bandwidth("1000Kb").unwrap(), 1_000_000 / 8);
    }
}
