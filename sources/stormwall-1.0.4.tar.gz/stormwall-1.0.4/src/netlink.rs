//! Raw netlink socket and nf_tables message construction.
//! Minimal unsafe only for libc socket syscalls.

use std::io;
use std::mem;

// ── Netlink / nfnetlink constants ───────────────────────────────
pub const NETLINK_NETFILTER: i32 = 12;
pub const NFNL_SUBSYS_NFTABLES: u16 = 10;
pub const NFNL_MSG_BATCH_BEGIN: u16 = 0x10;
pub const NFNL_MSG_BATCH_END: u16 = 0x11;

// NLM flags
pub const NLM_F_REQUEST: u16 = 1;
pub const NLM_F_ACK: u16 = 4;
pub const NLM_F_EXCL: u16 = 0x200;
pub const NLM_F_DUMP: u16 = 0x300;
pub const NLM_F_ECHO: u16 = 0x8;
pub const NLM_F_CREATE: u16 = 0x400;
pub const NLM_F_APPEND: u16 = 0x800;
pub const NLM_F_REPLACE: u16 = 0x100;

// NLMSG types
pub const NLMSG_ERROR: u16 = 2;
pub const NLMSG_DONE: u16 = 3;

// NFPROTO
pub const NFPROTO_UNSPEC: u8 = 0;
pub const NFPROTO_INET: u8 = 1;
pub const NFPROTO_IPV4: u8 = 2;
pub const NFPROTO_ARP: u8 = 3;
pub const NFPROTO_NETDEV: u8 = 5;
pub const NFPROTO_BRIDGE: u8 = 7;
pub const NFPROTO_IPV6: u8 = 10;

// NFT message types
pub const NFT_MSG_NEWTABLE: u16 = 0;
pub const NFT_MSG_GETTABLE: u16 = 1;
pub const NFT_MSG_DELTABLE: u16 = 2;
pub const NFT_MSG_NEWCHAIN: u16 = 3;
pub const NFT_MSG_GETCHAIN: u16 = 4;
pub const NFT_MSG_DELCHAIN: u16 = 5;
pub const NFT_MSG_NEWRULE: u16 = 6;
pub const NFT_MSG_GETRULE: u16 = 7;
pub const NFT_MSG_DELRULE: u16 = 8;
pub const NFT_MSG_NEWSET: u16 = 9;
pub const NFT_MSG_GETSET: u16 = 10;
pub const NFT_MSG_DELSET: u16 = 11;
pub const NFT_MSG_NEWSETELEM: u16 = 12;
pub const NFT_MSG_GETSETELEM: u16 = 13;
pub const NFT_MSG_DELSETELEM: u16 = 14;
pub const NFT_MSG_DESTROYTABLE: u16 = 26;
pub const NFT_MSG_DESTROYCHAIN: u16 = 27;
pub const NFT_MSG_DESTROYRULE: u16 = 28;
pub const NFT_MSG_DESTROYSET: u16 = 29;
pub const NFT_MSG_DESTROYSETELEM: u16 = 30;
pub const NFT_MSG_DESTROYOBJ: u16 = 31;

// Named stateful objects (counter / quota / limit / ...).
// UAPI: include/uapi/linux/netfilter/nf_tables.h
pub const NFT_MSG_NEWOBJ: u16 = 18;
pub const NFT_MSG_GETOBJ: u16 = 19;
pub const NFT_MSG_DELOBJ: u16 = 20;
/// NFT_MSG_GETOBJ_RESET — same shape as GETOBJ but the kernel atomically
/// zeros the object's stateful counters (counter packets/bytes, quota
/// consumed) after returning the pre-reset snapshot. Used by
/// `nft reset counter|quota|counters|quotas …`.
pub const NFT_MSG_GETOBJ_RESET: u16 = 21;

/// NFT_MSG_GETRULE_RESET — same shape as GETRULE but the kernel atomically
/// zeros each rule's per-rule stateful counters (inline `counter` expressions)
/// after returning the pre-reset snapshot. Used by `nft reset rule|rules …`.
pub const NFT_MSG_GETRULE_RESET: u16 = 25;

// Flowtable messages — kernel-side packet-bypass / offload table.
// UAPI: enum nf_tables_msg_types (NFT_MSG_NEWFLOWTABLE = 22).
pub const NFT_MSG_NEWFLOWTABLE: u16 = 22;
pub const NFT_MSG_GETFLOWTABLE: u16 = 23;
pub const NFT_MSG_DELFLOWTABLE: u16 = 24;

// Flowtable attributes — UAPI enum nft_flowtable_attributes.
pub const NFTA_FLOWTABLE_TABLE: u16 = 1;
pub const NFTA_FLOWTABLE_NAME: u16 = 2;
pub const NFTA_FLOWTABLE_HOOK: u16 = 3;
pub const NFTA_FLOWTABLE_USE: u16 = 4;
pub const NFTA_FLOWTABLE_HANDLE: u16 = 5;
pub const NFTA_FLOWTABLE_FLAGS: u16 = 6;

// Flowtable hook nest attributes — UAPI enum nft_flowtable_hook_attributes.
//   HOOK_NUM   : u32 NBO — hook number (always NF_NETDEV_INGRESS=0 today).
//   HOOK_PRIO  : s32 NBO — priority within the ingress hook.
//   HOOK_DEVS  : nested list of NFTA_DEVICE_NAME strings.
pub const NFTA_FLOWTABLE_HOOK_NUM: u16 = 1;
pub const NFTA_FLOWTABLE_HOOK_PRIORITY: u16 = 2;
pub const NFTA_FLOWTABLE_HOOK_DEVS: u16 = 3;

// Device-list attribute (string entry inside the HOOK_DEVS nest).
pub const NFTA_DEVICE_NAME: u16 = 1;

// `flow_offload` rule expression — `flow add @ft`.
pub const NFTA_FLOW_TABLE_NAME: u16 = 1;

pub const NFTA_OBJ_TABLE: u16 = 1;
pub const NFTA_OBJ_NAME: u16 = 2;
pub const NFTA_OBJ_TYPE: u16 = 3;
pub const NFTA_OBJ_DATA: u16 = 4;
pub const NFTA_OBJ_USE: u16 = 5;
pub const NFTA_OBJ_HANDLE: u16 = 6;
pub const NFTA_OBJ_USERDATA: u16 = 8;

// nft_object_type values
pub const NFT_OBJECT_COUNTER: u32 = 1;
pub const NFT_OBJECT_QUOTA: u32 = 2;
pub const NFT_OBJECT_CT_HELPER: u32 = 3;
pub const NFT_OBJECT_LIMIT: u32 = 4;
pub const NFT_OBJECT_SYNPROXY: u32 = 10;
pub const NFT_OBJECT_CT_TIMEOUT: u32 = 7;
pub const NFT_OBJECT_SECMARK: u32 = 8;
pub const NFT_OBJECT_CT_EXPECT: u32 = 9;
pub const NFT_OBJECT_TUNNEL: u32 = 6;

// Tunnel object attributes (under NFTA_OBJ_DATA for NFT_OBJECT_TUNNEL).
pub const NFTA_TUNNEL_KEY_ID:    u16 = 1;
pub const NFTA_TUNNEL_KEY_IP:    u16 = 2;
pub const NFTA_TUNNEL_KEY_IP6:   u16 = 3;
pub const NFTA_TUNNEL_KEY_FLAGS: u16 = 4;
pub const NFTA_TUNNEL_KEY_TOS:   u16 = 5;
pub const NFTA_TUNNEL_KEY_TTL:   u16 = 6;
pub const NFTA_TUNNEL_KEY_SPORT: u16 = 7;
pub const NFTA_TUNNEL_KEY_DPORT: u16 = 8;
pub const NFTA_TUNNEL_KEY_OPTS:  u16 = 9;

pub const NFTA_TUNNEL_KEY_IP_SRC: u16 = 1;
pub const NFTA_TUNNEL_KEY_IP_DST: u16 = 2;

pub const NFTA_TUNNEL_KEY_IP6_SRC:       u16 = 1;
pub const NFTA_TUNNEL_KEY_IP6_DST:       u16 = 2;
pub const NFTA_TUNNEL_KEY_IP6_FLOWLABEL: u16 = 3;

pub const NFTA_TUNNEL_KEY_OPTS_VXLAN:  u16 = 1;
pub const NFTA_TUNNEL_KEY_OPTS_ERSPAN: u16 = 2;
pub const NFTA_TUNNEL_KEY_OPTS_GENEVE: u16 = 3;

pub const NFTA_TUNNEL_KEY_VXLAN_GBP: u16 = 1;

pub const NFTA_TUNNEL_KEY_ERSPAN_VERSION:  u16 = 1;
pub const NFTA_TUNNEL_KEY_ERSPAN_V1_INDEX: u16 = 2;
pub const NFTA_TUNNEL_KEY_ERSPAN_V2_HWID:  u16 = 3;
pub const NFTA_TUNNEL_KEY_ERSPAN_V2_DIR:   u16 = 4;

pub const NFTA_TUNNEL_KEY_GENEVE_CLASS: u16 = 1;
pub const NFTA_TUNNEL_KEY_GENEVE_TYPE:  u16 = 2;
pub const NFTA_TUNNEL_KEY_GENEVE_DATA:  u16 = 3;

// Synproxy object attributes reuse the same NFTA_SYNPROXY_* constants
// defined below (near the expression section) — MSS=1, WSCALE=2, FLAGS=3.
// Synproxy flag bits:
//   NF_SYNPROXY_OPT_MSS        = 0x01
//   NF_SYNPROXY_OPT_WSCALE     = 0x02
//   NF_SYNPROXY_OPT_SACK_PERM  = 0x04
//   NF_SYNPROXY_OPT_TIMESTAMP  = 0x08
//   NF_SYNPROXY_OPT_ECN        = 0x10

// Secmark object attributes (under NFTA_OBJ_DATA for NFT_OBJECT_SECMARK).
pub const NFTA_SECMARK_CTX: u16 = 1;

// CT helper object attributes (under NFTA_OBJ_DATA for NFT_OBJECT_CT_HELPER).
// UAPI: enum nft_ct_helper_attributes in nf_tables.h.
//   NAME    — kernel helper module name ("ftp", "sip", "tftp", ...).
//             This is the *type* the user writes as `type "ftp"` —
//             the user-facing object name (e.g. "myftp") is carried
//             outside this nest as NFTA_OBJ_NAME.
//   L3PROTO — layer-3 family in network byte order (NFPROTO_IPV4=2,
//             NFPROTO_IPV6=10, NFPROTO_INET=1). Optional; the kernel
//             defaults from the table family when unset.
//   L4PROTO — L4 transport (IPPROTO_TCP=6, IPPROTO_UDP=17, etc.) — u8.
pub const NFTA_CT_HELPER_NAME: u16 = 1;
pub const NFTA_CT_HELPER_L3PROTO: u16 = 2;
pub const NFTA_CT_HELPER_L4PROTO: u16 = 3;

// CT timeout object attributes (under NFTA_OBJ_DATA for NFT_OBJECT_CT_TIMEOUT).
// UAPI: enum ctattr_timeout / nf_ct_timeout in kernel sources.
//   L4PROTO  — IPPROTO_* u16 NBO: transport protocol (TCP=6, UDP=17).
//   L3PROTO  — NFPROTO_* u16 NBO: address family.
//   DATA     — nested attribute set of per-state timeouts (u32 NBO, seconds).
//              The attribute id within DATA matches the conntrack state index.
pub const NFTA_CT_TIMEOUT_L3PROTO: u16 = 1;
pub const NFTA_CT_TIMEOUT_L4PROTO: u16 = 2;
pub const NFTA_CT_TIMEOUT_DATA: u16    = 3;

// TCP conntrack state indices for CTA_TIMEOUT_TCP_* (0-based, match kernel).
// Used as attribute IDs inside the NFTA_CT_TIMEOUT_DATA nest for TCP.
pub const CTA_TIMEOUT_TCP_SYN_SENT:   u16 = 1;
pub const CTA_TIMEOUT_TCP_SYN_RECV:   u16 = 2;
pub const CTA_TIMEOUT_TCP_ESTABLISHED: u16 = 3;
pub const CTA_TIMEOUT_TCP_FIN_WAIT:   u16 = 4;
pub const CTA_TIMEOUT_TCP_CLOSE_WAIT: u16 = 5;
pub const CTA_TIMEOUT_TCP_LAST_ACK:   u16 = 6;
pub const CTA_TIMEOUT_TCP_TIME_WAIT:  u16 = 7;
pub const CTA_TIMEOUT_TCP_CLOSE:      u16 = 8;
pub const CTA_TIMEOUT_TCP_SYN_SENT2:  u16 = 9;
pub const CTA_TIMEOUT_TCP_RETRANS:    u16 = 10;
pub const CTA_TIMEOUT_TCP_UNACK:      u16 = 11;

// UDP conntrack state indices.
pub const CTA_TIMEOUT_UDP_UNREPLIED: u16 = 1;
pub const CTA_TIMEOUT_UDP_REPLIED:   u16 = 2;

// CT expectation object attributes (under NFTA_OBJ_DATA for NFT_OBJECT_CT_EXPECT).
// UAPI: nft_ct_expect_attributes in nf_tables.h.
//   L3PROTO  — NFPROTO_* u16 NBO.
//   PROTOCOL — IPPROTO_* u8: master connection protocol.
//   DPORT    — u16 NBO: destination port for the expected connection.
//   TIMEOUT  — u32 NBO: timeout in seconds.
//   SIZE     — u8: maximum number of simultaneous expectations.
pub const NFTA_CT_EXPECT_L3PROTO: u16  = 1;
pub const NFTA_CT_EXPECT_PROTOCOL: u16 = 2;
pub const NFTA_CT_EXPECT_DPORT: u16    = 3;
pub const NFTA_CT_EXPECT_TIMEOUT: u16  = 4;
pub const NFTA_CT_EXPECT_SIZE: u16     = 5;

// Counter object attributes
// (NFTA_COUNTER_BYTES=1, NFTA_COUNTER_PACKETS=2 already exist in the
// expression-level counter path and are reused for the object payload.)

// Quota object attributes (all under NFTA_OBJ_DATA for NFT_OBJECT_QUOTA).
// Kernel UAPI ordering: BYTES=1, FLAGS=2, PAD=3, CONSUMED=4. The PAD
// slot is reserved for nla_pad alignment and must not be used as
// CONSUMED — that's an off-by-one we used to make and the kernel
// silently dropped the value.
pub const NFTA_QUOTA_BYTES: u16 = 1;
pub const NFTA_QUOTA_FLAGS: u16 = 2;
pub const NFTA_QUOTA_CONSUMED: u16 = 4;
pub const NFT_QUOTA_F_INV: u32 = 1;

// objref expression: references a named stateful object from a rule.
// Emitted as `counter name "cnt"` or similar in text form.
pub const NFTA_OBJREF_IMM_TYPE: u16 = 1;
pub const NFTA_OBJREF_IMM_NAME: u16 = 2;

// Table attributes
pub const NFTA_TABLE_NAME: u16 = 1;
pub const NFTA_TABLE_FLAGS: u16 = 2;
pub const NFTA_TABLE_HANDLE: u16 = 4;
pub const NFTA_TABLE_USERDATA: u16 = 6;

// Chain attributes
pub const NFTA_CHAIN_TABLE: u16 = 1;
pub const NFTA_CHAIN_HANDLE: u16 = 2;
pub const NFTA_CHAIN_NAME: u16 = 3;
pub const NFTA_CHAIN_HOOK: u16 = 4;
pub const NFTA_CHAIN_POLICY: u16 = 5;
pub const NFTA_CHAIN_TYPE: u16 = 7;
pub const NFTA_CHAIN_FLAGS: u16 = 10;
/// Anonymous/binding chain ID. Emitted in NEWCHAIN for `jump { … }` /
/// `goto { … }` chains so the kernel can resolve the chain reference
/// from the same transaction before the chain is committed.
pub const NFTA_CHAIN_ID: u16 = 11;
/// Opaque user-data blob (NLA_BINARY). Stores TLV-encoded metadata such
/// as a chain comment; same wire shape as NFTA_RULE_USERDATA.
pub const NFTA_CHAIN_USERDATA: u16 = 12;
/// Chain flags. NFT_CHAIN_BASE marks a base/hooked chain; NFT_CHAIN_BINDING
/// marks an anonymous in-rule chain referenced by `jump { … }`. Stormwall
/// doesn't yet emit binding chains itself, but listings need to recognise
/// them so the rule-reset and rule-list paths can suppress them.
pub const NFT_CHAIN_BINDING: u32 = 0x4;
/// Base (hooked) chain flag — set on chains that have a netfilter hook.
/// Distinct from NFT_CHAIN_BINDING (0x4). Kernel header: NFT_CHAIN_BASE.
pub const NFT_CHAIN_BASE: u32 = 1 << 0;

// Hook attributes
pub const NFTA_HOOK_HOOKNUM: u16 = 1;
pub const NFTA_HOOK_PRIORITY: u16 = 2;
pub const NFTA_HOOK_DEV: u16 = 3;

// Rule attributes
pub const NFTA_RULE_TABLE: u16 = 1;
pub const NFTA_RULE_CHAIN: u16 = 2;
pub const NFTA_RULE_HANDLE: u16 = 3;
pub const NFTA_RULE_EXPRESSIONS: u16 = 4;
pub const NFTA_RULE_POSITION: u16 = 6;
pub const NFTA_RULE_USERDATA: u16 = 7;
/// NFTA_RULE_ID — client-assigned u32 used to refer to a not-yet-committed
/// rule from a later message in the same batch (e.g. `index N` where the
/// Nth rule was added earlier in the same `nft -f` invocation).
pub const NFTA_RULE_ID: u16 = 9;
/// NFTA_RULE_POSITION_ID — counterpart to NFTA_RULE_POSITION that
/// references a same-batch rule by its NFTA_RULE_ID instead of by handle.
pub const NFTA_RULE_POSITION_ID: u16 = 10;

// Expression attributes
pub const NFTA_EXPR_NAME: u16 = 1;
pub const NFTA_EXPR_DATA: u16 = 2;
pub const NFTA_LIST_ELEM: u16 = 1;
pub const NLA_F_NESTED: u16 = 1 << 15;

// Registers
pub const NFT_REG_VERDICT: u32 = 0;
pub const NFT_REG_1: u32 = 1; // 16-byte register (aliases NFT_REG32_00..03)
pub const NFT_REG32_00: u32 = 8;
pub const NFT_REG32_01: u32 = 9;

// Pick the right register for a given value width. 4-byte (and shorter)
// values fit in the 32-bit register NFT_REG32_00; anything wider needs
// NFT_REG_1, the 16-byte register. Using NFT_REG32_00 for a 16-byte
// value (e.g. iifname/oifname, ct helper) makes the kernel reject the
// expression with EOVERFLOW during validation.
pub fn reg_for_width(width: usize) -> u32 {
    if width > 4 { NFT_REG_1 } else { NFT_REG32_00 }
}

// Verdicts
pub const NF_DROP: i32 = 0;
pub const NF_ACCEPT: i32 = 1;
pub const NFT_JUMP: i32 = -3;
pub const NFT_GOTO: i32 = -4;
pub const NFT_RETURN: i32 = -5;
pub const NFT_CONTINUE: i32 = -1;

// Hooks
pub const NF_INET_PRE_ROUTING: u32 = 0;
pub const NF_INET_LOCAL_IN: u32 = 1;
pub const NF_INET_FORWARD: u32 = 2;
pub const NF_INET_LOCAL_OUT: u32 = 3;
pub const NF_INET_POST_ROUTING: u32 = 4;

// Payload expression
pub const NFTA_PAYLOAD_DREG: u16 = 1;
pub const NFTA_PAYLOAD_BASE: u16 = 2;
pub const NFTA_PAYLOAD_OFFSET: u16 = 3;
pub const NFTA_PAYLOAD_LEN: u16 = 4;
// Write-side payload uses SREG plus checksum descriptors. SREG sits in
// slot 5 (right after the four read-side attributes); CSUM_TYPE/OFFSET
// in slots 6/7; CSUM_FLAGS in slot 8. Wire-captured against /sbin/nft.
pub const NFTA_PAYLOAD_SREG: u16 = 5;
pub const NFTA_PAYLOAD_CSUM_TYPE: u16 = 6;
pub const NFTA_PAYLOAD_CSUM_OFFSET: u16 = 7;
pub const NFTA_PAYLOAD_CSUM_FLAGS: u16 = 8;
pub const NFT_PAYLOAD_LL_HEADER: u32 = 0;
pub const NFT_PAYLOAD_NETWORK_HEADER: u32 = 1;
pub const NFT_PAYLOAD_TRANSPORT_HEADER: u32 = 2;
// Checksum types — must match enum nft_payload_csum_types in the kernel.
// NFT_PAYLOAD_CSUM_INET (1) is the IPv4 ones-complement form; the kernel
// recomputes the IP header checksum after the write so packets that pass
// through the host don't get dropped as corrupt.
pub const NFT_PAYLOAD_CSUM_NONE: u32 = 0;
pub const NFT_PAYLOAD_CSUM_INET: u32 = 1;

// Exthdr expression. The same kernel module backs both IPv6-extension-header
// and TCP-option reads; nftables picks between them with NFTA_EXTHDR_OP.
// For TCP-option writes (PR #1 of pf-parity) the kernel takes SREG (slot 6)
// instead of DREG (slot 1).
pub const NFTA_EXTHDR_DREG: u16 = 1;
pub const NFTA_EXTHDR_TYPE: u16 = 2;
pub const NFTA_EXTHDR_OFFSET: u16 = 3;
pub const NFTA_EXTHDR_LEN: u16 = 4;
pub const NFTA_EXTHDR_FLAGS: u16 = 5;
pub const NFTA_EXTHDR_OP: u16 = 6;
pub const NFTA_EXTHDR_SREG: u16 = 7;
pub const NFT_EXTHDR_OP_IPV6: u32 = 0;
pub const NFT_EXTHDR_OP_TCPOPT: u32 = 1;

// Byteorder expression — converts a register's value between host order
// and network order. Used by `ip id set numgen ...` to flip the random
// 16-bit number into NBO before the payload write.
pub const NFTA_BYTEORDER_SREG: u16 = 1;
pub const NFTA_BYTEORDER_DREG: u16 = 2;
pub const NFTA_BYTEORDER_OP: u16 = 3;
pub const NFTA_BYTEORDER_LEN: u16 = 4;
pub const NFTA_BYTEORDER_SIZE: u16 = 5;
pub const NFT_BYTEORDER_NTOH: u32 = 0;
pub const NFT_BYTEORDER_HTON: u32 = 1;

// CMP expression
pub const NFTA_CMP_SREG: u16 = 1;
pub const NFTA_CMP_OP: u16 = 2;
pub const NFTA_CMP_DATA: u16 = 3;
pub const NFT_CMP_EQ: u32 = 0;
pub const NFT_CMP_NEQ: u32 = 1;
pub const NFT_CMP_LT: u32 = 2;
pub const NFT_CMP_LTE: u32 = 3;
pub const NFT_CMP_GT: u32 = 4;
pub const NFT_CMP_GTE: u32 = 5;

// Meta expression
// Kernel UAPI: NFTA_META_UNSPEC=0, NFTA_META_DREG=1, NFTA_META_KEY=2.
// Prior versions of stormwall had these two swapped; for simple 4-byte
// meta matches the bug was papered over by the equally-swapped output
// decoder, which is why tailscale's live ruleset showed every meta
// expression as "meta unknown" and iifname encodes were rejected by
// the kernel with EOVERFLOW.
pub const NFTA_META_DREG: u16 = 1;
pub const NFTA_META_KEY: u16 = 2;
pub const NFTA_META_SREG: u16 = 3;
// Order matches enum nft_meta_keys in include/uapi/linux/netfilter/nf_tables.h.
// NFT_META_MARK was 15 (collides with NFPROTO), NFT_META_NFPROTO was 17
// (collides with BRI_IIFNAME), NFT_META_PKTTYPE was 26 (collides with
// IIFKIND), and IIF/OIF were 3/4 (the kernel slots for MARK and IIF
// respectively). nft monitor decoded our `meta mark` rules as
// `meta nfproto` because of the slot collision.
pub const NFT_META_LEN: u32 = 0;
pub const NFT_META_PROTOCOL: u32 = 1;
pub const NFT_META_PRIORITY: u32 = 2;
pub const NFT_META_MARK: u32 = 3;
pub const NFT_META_IIF: u32 = 4;
pub const NFT_META_OIF: u32 = 5;
pub const NFT_META_IIFNAME: u32 = 6;
pub const NFT_META_OIFNAME: u32 = 7;
pub const NFT_META_IIFTYPE: u32 = 8;
pub const NFT_META_OIFTYPE: u32 = 9;
pub const NFT_META_SKUID: u32 = 10;
pub const NFT_META_SKGID: u32 = 11;
pub const NFT_META_NFPROTO: u32 = 15;
pub const NFT_META_L4PROTO: u32 = 16;
// Kernel uapi values (NFT_META_PKTTYPE=19, NFT_META_CPU=20,
// NFT_META_CGROUP=23). The task spec gave 14/18, but those are
// reserved for SECMARK and BRI_OIFNAME respectively in the actual
// upstream enum — using 14 makes the kernel reject `meta cgroup`
// with EOPNOTSUPP. Wire-captured strace confirms 20 / 23.
pub const NFT_META_CPU: u32 = 20;
pub const NFT_META_CGROUP: u32 = 23;
pub const NFT_META_PKTTYPE: u32 = 19;
// Time meta keys. Counted from NFT_META_LEN=0 through the kernel's
// nft_meta_keys enum (PRANDOM=24, SECPATH=25, IIFKIND=26, OIFKIND=27,
// BRI_IIFPVID=28, BRI_IIFVPROTO=29, TIME_NS=30, TIME_DAY=31,
// TIME_HOUR=32). pf-syntax `hours { N-N }` and `days { mon-fri }`
// lower to range/lookup matches against these keys.
pub const NFT_META_TIME_DAY:  u32 = 31;
pub const NFT_META_TIME_HOUR: u32 = 32;

// Hash expression (NFTA_HASH_*) — kernel expression name "hash".
// Drives both jhash (NFT_HASH_JENKINS=0; needs SREG+LEN) and
// symhash (NFT_HASH_SYM=1; no source register, the kernel hashes
// the packet directly). Wire-captured from upstream nft, the
// emission order inside NFTA_EXPR_DATA is SREG, DREG, LEN,
// MODULUS, [SEED,] OFFSET, TYPE — OFFSET and TYPE go *last*, not
// in tag order, and the kernel parser doesn't care but external
// byte-diff tests are sensitive to the order.
pub const NFTA_HASH_SREG:    u16 = 1;
pub const NFTA_HASH_DREG:    u16 = 2;
pub const NFTA_HASH_LEN:     u16 = 3;
pub const NFTA_HASH_MODULUS: u16 = 4;
pub const NFTA_HASH_SEED:    u16 = 5;
pub const NFTA_HASH_OFFSET:  u16 = 6;
pub const NFTA_HASH_TYPE:    u16 = 7;
pub const NFT_HASH_JENKINS: u32 = 0;
pub const NFT_HASH_SYM:     u32 = 1;

// Queue expression (NFTA_QUEUE_*) — kernel expression name "queue".
// The classic form encodes a literal queue number / range:
//   `queue num 5 bypass`   -> NUM=5, TOTAL=1, FLAGS=0x1
//   `queue num 1-10`       -> NUM=1, TOTAL=10
// The dynamic form replaces NUM/TOTAL with SREG_QNUM, pointing at a
// register filled by jhash / symhash / map lookup:
//   `queue to symhash mod 2`            -> SREG_QNUM=NFT_REG_1
//   `queue flags bypass to jhash ... mod 4`
//   `queue flags bypass to ip saddr . ip daddr . tcp dport map @m`
// All u16 attributes are big-endian on the wire; SREG_QNUM is u32.
pub const NFTA_QUEUE_NUM:       u16 = 1;
pub const NFTA_QUEUE_TOTAL:     u16 = 2;
pub const NFTA_QUEUE_FLAGS:     u16 = 3;
pub const NFTA_QUEUE_SREG_QNUM: u16 = 4;
pub const NFT_QUEUE_FLAG_BYPASS:     u16 = 0x01;
pub const NFT_QUEUE_FLAG_CPU_FANOUT: u16 = 0x02;

// Numgen expression (NFTA_NG_*) — kernel name "numgen". Generates
// either a monotonically increasing u32 or a random one, takes it
// modulo MODULUS, adds OFFSET, and stores the result into DREG
// (always NFT_REG_1 in upstream emission). All four attributes
// are emitted even when offset is 0.
pub const NFTA_NG_DREG:    u16 = 1;
pub const NFTA_NG_MODULUS: u16 = 2;
pub const NFTA_NG_TYPE:    u16 = 3;
pub const NFTA_NG_OFFSET:  u16 = 4;
pub const NFT_NG_INCREMENTAL: u32 = 0;
pub const NFT_NG_RANDOM:      u32 = 1;

// 16-byte register #2. Upstream nft picks NFT_REG_2 (not the 4-byte
// NFT_REG32_*) for the source-side payload load that feeds a jhash
// expression, so the wire bytes match only when we use this slot
// rather than the default NFT_REG32_00 the bare-payload encoder
// picks.
pub const NFT_REG_2: u32 = 2;

// Socket expression (NFTA_SOCKET_*) — match on the local-socket attributes
// of the packet's owning socket (transparent flag, fwmark, cgroupv2 id, …).
// Wire order matches enum nft_socket_attributes in nf_tables.h:
//   NFTA_SOCKET_UNSPEC=0, NFTA_SOCKET_KEY=1, NFTA_SOCKET_DREG=2,
//   NFTA_SOCKET_LEVEL=3.
// (rt and meta both use DREG=1 / KEY=2 — socket is the odd one out.)
pub const NFTA_SOCKET_KEY: u16 = 1;
pub const NFTA_SOCKET_DREG: u16 = 2;
pub const NFTA_SOCKET_LEVEL: u16 = 3;
pub const NFT_SOCKET_TRANSPARENT: u32 = 0;
pub const NFT_SOCKET_MARK: u32 = 1;
pub const NFT_SOCKET_WILDCARD: u32 = 2;
pub const NFT_SOCKET_CGROUPV2: u32 = 3;

// Routing expression (NFTA_RT_*) — match on routing-derived metadata
// (egress classid, ipv4/ipv6 nexthop, tcpmss).
pub const NFTA_RT_DREG: u16 = 1;
pub const NFTA_RT_KEY: u16 = 2;
pub const NFT_RT_CLASSID: u32 = 0;
pub const NFT_RT_NEXTHOP4: u32 = 1;
pub const NFT_RT_NEXTHOP6: u32 = 2;
pub const NFT_RT_TCPMSS: u32 = 3;

// CT expression
pub const NFTA_CT_DREG: u16 = 1;
pub const NFTA_CT_KEY: u16 = 2;
pub const NFTA_CT_DIR: u16 = 3;
// Order matches enum nft_ct_keys in nf_tables.h. The earlier table
// had EXPIRATION/HELPER/L3PROTOCOL/PROTOCOL/PKTS/BYTES/LABELS off by
// the count of intervening kernel enum entries (SECMARK at 4, SRC/DST
// at 8/9, etc.) — so e.g. `ct labels` was being encoded as ZONE+5 and
// `ct packets` as DST_IP. The chain-rule tests didn't exercise these
// keys, so the bug went unnoticed until monitor-diff caught it.
pub const NFT_CT_STATE: u32 = 0;
pub const NFT_CT_DIRECTION: u32 = 1;
pub const NFT_CT_STATUS: u32 = 2;
pub const NFT_CT_MARK: u32 = 3;
pub const NFT_CT_SECMARK: u32 = 4;
pub const NFT_CT_EXPIRATION: u32 = 5;
pub const NFT_CT_HELPER: u32 = 6;
pub const NFT_CT_L3PROTOCOL: u32 = 7;
pub const NFT_CT_PROTOCOL: u32 = 10;
pub const NFT_CT_LABELS: u32 = 13;
pub const NFT_CT_PKTS: u32 = 14;
pub const NFT_CT_BYTES: u32 = 15;
pub const NFT_CT_AVGPKT: u32 = 16;
pub const NFT_CT_ZONE: u32 = 17;

// Immediate expression
pub const NFTA_IMM_DREG: u16 = 1;
pub const NFTA_IMM_DATA: u16 = 2;
pub const NFTA_DATA_VALUE: u16 = 1;
pub const NFTA_DATA_VERDICT: u16 = 2;
pub const NFTA_VERDICT_CODE: u16 = 1;
pub const NFTA_VERDICT_CHAIN: u16 = 2;
/// Binding chain ID in a verdict — used by `jump { … }` / `goto { … }`
/// to reference a chain that may not yet be committed (in-transaction).
pub const NFTA_VERDICT_CHAIN_ID: u16 = 3;

// Counter
pub const NFTA_COUNTER_BYTES: u16 = 1;
pub const NFTA_COUNTER_PACKETS: u16 = 2;

// Bitwise
pub const NFTA_BITWISE_SREG: u16 = 1;
pub const NFTA_BITWISE_DREG: u16 = 2;
pub const NFTA_BITWISE_LEN: u16 = 3;
pub const NFTA_BITWISE_MASK: u16 = 4;
pub const NFTA_BITWISE_XOR: u16 = 5;

// Log
// Order matches enum nft_log_attributes: GROUP=1, PREFIX=2.
// Stormwall had these reversed, so a `log prefix "hello: "` rule
// was being sent with the prefix bytes under the GROUP attribute —
// the kernel then read the first two prefix bytes as a u16 group
// number ("he" → 0x6865 → 26725) and discarded the prefix entirely.
pub const NFTA_LOG_GROUP: u16 = 1;
pub const NFTA_LOG_PREFIX: u16 = 2;

// Limit
pub const NFTA_LIMIT_RATE: u16 = 1;
pub const NFTA_LIMIT_UNIT: u16 = 2;
pub const NFTA_LIMIT_BURST: u16 = 3;
pub const NFTA_LIMIT_TYPE: u16 = 4;
pub const NFTA_LIMIT_FLAGS: u16 = 5;
pub const NFT_LIMIT_F_INV: u32 = 0x1;
// nft_limit type bitmap. Upstream nft emits NFTA_LIMIT_TYPE=0 for the
// packet-rate form (`limit rate 5/second`) and TYPE=1 for the byte-rate
// form (`limit rate 1mbytes/second`). We carry both as named constants
// so encoders don't sprinkle magic 0/1.
pub const NFT_LIMIT_TYPE_PKTS: u32 = 0;
pub const NFT_LIMIT_TYPE_PKT_BYTES: u32 = 1;

// Connlimit expression (kernel: net/netfilter/nft_connlimit.c).
// Encoded as the `connlimit` expression carrying a u32 NBO threshold
// and a u32 NBO flag bitmap whose only bit (0x1) flips the comparison
// from "<=" to ">". `ct count over N` sets flags=1; `ct count N` (no
// `over`) sets flags=0.
pub const NFTA_CONNLIMIT_COUNT: u16 = 1;
pub const NFTA_CONNLIMIT_FLAGS: u16 = 2;
pub const NFT_CONNLIMIT_F_INV: u32 = 0x1;

// NAT
pub const NFTA_NAT_TYPE: u16 = 1;
pub const NFTA_NAT_FAMILY: u16 = 2;
pub const NFTA_NAT_REG_ADDR_MIN: u16 = 3;
pub const NFTA_NAT_REG_ADDR_MAX: u16 = 4;
pub const NFTA_NAT_REG_PROTO_MIN: u16 = 5;
pub const NFTA_NAT_REG_PROTO_MAX: u16 = 6;
pub const NFTA_NAT_FLAGS: u16 = 7;
pub const NFT_NAT_SNAT: u32 = 0;
pub const NFT_NAT_DNAT: u32 = 1;

// Dup expression (kernel: net/netfilter/nft_dup_netdev.c, nft_dup_ipv4.c).
// Loads of address / device index live in NFT_REG_1 / NFT_REG_2 via a
// preceding immediate; dup itself just references the registers.
pub const NFTA_DUP_SREG_ADDR: u16 = 1;
pub const NFTA_DUP_SREG_DEV:  u16 = 2;

// Fwd expression (netdev family only, kernel: nft_fwd_netdev.c).
// SREG_DEV is mandatory; SREG_ADDR + NFPROTO are used for the L3
// forwarding flavour and stay zero/absent for plain L2 forwarding.
pub const NFTA_FWD_SREG_DEV:  u16 = 1;
pub const NFTA_FWD_SREG_ADDR: u16 = 2;
pub const NFTA_FWD_NFPROTO:   u16 = 3;

// Tproxy expression (kernel: nft_tproxy.c). FAMILY is BE u32
// NFPROTO_IPV4 / NFPROTO_IPV6; REG_ADDR is optional (omitted for a
// `tproxy to :PORT` shorthand) and REG_PORT is the source register
// holding a u16 destination port.
pub const NFTA_TPROXY_FAMILY:   u16 = 1;
pub const NFTA_TPROXY_REG_ADDR: u16 = 2;
pub const NFTA_TPROXY_REG_PORT: u16 = 3;

// Synproxy expression (kernel: nft_synproxy.c). MSS is BE u16, WSCALE
// is u8, FLAGS is BE u32 with bits per `enum nf_synproxy_options`.
pub const NFTA_SYNPROXY_MSS:    u16 = 1;
pub const NFTA_SYNPROXY_WSCALE: u16 = 2;
pub const NFTA_SYNPROXY_FLAGS:  u16 = 3;

// Synproxy flag bits (must match include/uapi/linux/netfilter/nf_synproxy.h
// enum nf_synproxy_options). Used by both the netlink emitter and the
// monitor/list decoder to translate the wire bitfield into the symbolic
// `mss <n> wscale <n> timestamp sack-perm` rule text.
pub const NF_SYNPROXY_OPT_MSS:       u32 = 0x01;
pub const NF_SYNPROXY_OPT_WSCALE:    u32 = 0x02;
pub const NF_SYNPROXY_OPT_SACK_PERM: u32 = 0x04;
pub const NF_SYNPROXY_OPT_TIMESTAMP: u32 = 0x08;

// Masquerade
pub const NFTA_MASQ_FLAGS: u16 = 1;

// NF_NAT_RANGE flag bits (shared across nat / masq / redir).
// See include/uapi/linux/netfilter/nf_nat.h. The user-facing
// nft modifiers map as:
//   (map_ips)     -> NF_NAT_RANGE_MAP_IPS             (0x1)
//   (proto_spec)  -> NF_NAT_RANGE_PROTO_SPECIFIED     (0x2)
//   random        -> NF_NAT_RANGE_PROTO_RANDOM        (0x4)
//   persistent    -> NF_NAT_RANGE_PERSISTENT          (0x8)
//   fully-random  -> NF_NAT_RANGE_PROTO_RANDOM_FULLY  (0x10)
pub const NF_NAT_RANGE_MAP_IPS: u32 = 0x1;
pub const NF_NAT_RANGE_PROTO_SPECIFIED: u32 = 0x2;
pub const NF_NAT_RANGE_PROTO_RANDOM: u32 = 0x4;
pub const NF_NAT_RANGE_PERSISTENT: u32 = 0x8;
pub const NF_NAT_RANGE_PROTO_RANDOM_FULLY: u32 = 0x10;

// Set attributes
pub const NFTA_SET_TABLE: u16 = 1;
pub const NFTA_SET_NAME: u16 = 2;
pub const NFTA_SET_FLAGS: u16 = 3;
pub const NFTA_SET_KEY_TYPE: u16 = 4;
pub const NFTA_SET_KEY_LEN: u16 = 5;
pub const NFTA_SET_FAMILY: u16 = 8;
pub const NFTA_SET_DATA_TYPE: u16 = 6;
pub const NFTA_SET_DATA_LEN: u16 = 7;
pub const NFTA_SET_DESC: u16 = 9;
pub const NFTA_SET_ID: u16 = 10;
pub const NFTA_SET_HANDLE: u16 = 16;
/// Opaque user-data blob for a named set/map. Stores TLV-encoded
/// metadata (e.g. a set comment); same wire shape as
/// NFTA_CHAIN_USERDATA / NFTA_RULE_USERDATA.
/// UAPI: enum nft_set_attributes, NFTA_SET_USERDATA = 13.
pub const NFTA_SET_USERDATA: u16 = 13;
/// Object type for stateful-object-valued maps (e.g. `type ipv4_addr : counter`).
/// UAPI: NFTA_SET_OBJ_TYPE = 15.
pub const NFTA_SET_OBJ_TYPE: u16 = 15;

// Set desc attributes
pub const NFTA_SET_DESC_SIZE: u16 = 1;

/// u64 NBO: default per-element timeout in milliseconds.  Emitted on
/// NEWSET when the source declares `add set ... { ... timeout 1m; }`,
/// and read back on `nft list ruleset` as `"timeout": 60` / `timeout 1m`.
pub const NFTA_SET_TIMEOUT: u16 = 11;

// Set element list attributes
pub const NFTA_SET_ELEM_LIST_TABLE: u16 = 1;
pub const NFTA_SET_ELEM_LIST_SET: u16 = 2;
pub const NFTA_SET_ELEM_LIST_ELEMENTS: u16 = 3;

// Set element attributes
pub const NFTA_SET_ELEM_KEY: u16 = 1;
pub const NFTA_SET_ELEM_DATA: u16 = 2;
pub const NFTA_SET_ELEM_FLAGS: u16 = 3;   // per kernel uapi
/// u64 NBO milliseconds: per-element timeout. Set when the source
/// declared `add element ... { 1.2.3.4 timeout 10s }`. Round-trips
/// in `nft list ruleset` as `1.2.3.4 timeout 10s` (text) /
/// `{"elem": {"val": "1.2.3.4", "timeout": 10}}` (JSON).
pub const NFTA_SET_ELEM_TIMEOUT: u16 = 4;
/// u64 NBO milliseconds: time remaining before the element expires.
/// Kernel-maintained; nft renders it after `timeout` as `expires 5s912ms`.
pub const NFTA_SET_ELEM_EXPIRATION: u16 = 5;
/// Opaque user-data blob for a set element. Stores TLV-encoded
/// metadata (e.g. a per-element comment); same wire shape as
/// NFTA_RULE_USERDATA. UAPI: NFTA_SET_ELEM_USERDATA = 6.
pub const NFTA_SET_ELEM_USERDATA: u16 = 6;
/// Stateful-object reference for object-reference maps (counter, quota, etc.)
/// UAPI: NFTA_SET_ELEM_OBJREF = 9.  Sent as NLA_STRING (the object name).
pub const NFTA_SET_ELEM_OBJREF: u16 = 9;
pub const NFT_SET_ELEM_INTERVAL_END: u32 = 0x1;

// Lookup expression (used for `ip saddr @setname drop`)
pub const NFTA_LOOKUP_SET: u16 = 1;   // string: set name
pub const NFTA_LOOKUP_SREG: u16 = 2;  // u32: source register
pub const NFTA_LOOKUP_DREG: u16 = 3;  // u32: dest register (map lookup)
// In kernel 6.1 UAPI the order is SET_ID=4, FLAGS=5 (not the other
// way around, which is what earlier versions of stormwall assumed).
// Sending FLAGS=4 lands in the SET_ID slot, the kernel silently
// ignores it, and `!= @set` never round-trips — the exact bug we've
// been chasing for days. UAPI wins.
pub const NFTA_LOOKUP_SET_ID: u16 = 4;
pub const NFTA_LOOKUP_FLAGS: u16 = 5;   // u32: NFT_LOOKUP_F_INV for `!=`
pub const NFT_LOOKUP_F_INV: u32 = 0x1;

// Dynset expression — `add @setname { ip saddr [timeout 10s] }` /
// `update @setname { ip saddr }`. Encoded by the kernel as the
// "dynset" expression; mutates the named set at packet time.
pub const NFTA_DYNSET_SET_NAME: u16 = 1;   // string: target set name
pub const NFTA_DYNSET_SET_ID:   u16 = 2;   // u32: set id (anon-set transactions)
pub const NFTA_DYNSET_OP:       u16 = 3;   // u32 NBO: NFT_DYNSET_OP_*
pub const NFTA_DYNSET_SREG_KEY: u16 = 4;   // u32: source register holding the key
pub const NFTA_DYNSET_SREG_DATA:u16 = 5;   // u32: source register holding map data
pub const NFTA_DYNSET_TIMEOUT:  u16 = 6;   // u64 NBO: per-elem timeout in ms
pub const NFTA_DYNSET_EXPR:     u16 = 7;   // nested expr (update + counter etc.)
pub const NFTA_DYNSET_FLAGS:    u16 = 8;   // u32 NBO: NFT_DYNSET_F_INV

pub const NFT_DYNSET_OP_ADD:    u32 = 0;
pub const NFT_DYNSET_OP_UPDATE: u32 = 1;
pub const NFT_DYNSET_OP_DELETE: u32 = 2;

// Set flags
pub const NFT_SET_ANONYMOUS: u32 = 0x1;
pub const NFT_SET_CONSTANT: u32 = 0x2;
pub const NFT_SET_INTERVAL: u32 = 0x4;
pub const NFT_SET_MAP: u32 = 0x8;
pub const NFT_SET_TIMEOUT: u32 = 0x10;
pub const NFT_SET_EVAL: u32 = 0x20;
/// NFT_SET_OBJECT: set values are stateful object references.
pub const NFT_SET_OBJECT: u32 = 0x40;

// Table flags
pub const NFT_TABLE_F_DORMANT: u32 = 0x1;

// Reject
pub const NFTA_REJECT_TYPE: u16 = 1;
pub const NFTA_REJECT_ICMP_CODE: u16 = 2;
// Reject types (enum nft_reject_types)
pub const NFT_REJECT_ICMP_UNREACH:  u32 = 0;
pub const NFT_REJECT_TCP_RST:       u32 = 1;
pub const NFT_REJECT_ICMPX_UNREACH: u32 = 2;
// Generic ICMPX codes (enum nft_reject_inet_code) — used with
// NFT_REJECT_ICMPX_UNREACH for family-agnostic emitters.
pub const NFT_REJECT_ICMPX_NO_ROUTE:        u8 = 0;
pub const NFT_REJECT_ICMPX_PORT_UNREACH:    u8 = 1;
pub const NFT_REJECT_ICMPX_HOST_UNREACH:    u8 = 2;
pub const NFT_REJECT_ICMPX_ADMIN_PROHIBITED:u8 = 3;
// IPv4 ICMP unreachable codes (subset used by pf `block return-icmp`).
// Kept narrow — pf only routes to two of these by name today.
pub const ICMP_PORT_UNREACH:        u8 = 3;
pub const ICMP_HOST_UNREACH:        u8 = 1;
pub const ICMP_NET_UNREACH:         u8 = 0;

// Range expression (NFTA_RANGE_*) — kernel name "range". Used by
// pf-syntax `hours { N-N }` lowering: load meta TIME_HOUR into a
// register, byteorder-swap to NBO, then `range eq reg LO HI`.
pub const NFTA_RANGE_SREG:      u16 = 1;
pub const NFTA_RANGE_OP:        u16 = 2;
pub const NFTA_RANGE_FROM_DATA: u16 = 3;
pub const NFTA_RANGE_TO_DATA:   u16 = 4;
pub const NFT_RANGE_EQ:  u32 = 0;
pub const NFT_RANGE_NEQ: u32 = 1;

// FIB expression (NFTA_FIB_*) — kernel name "fib". Used by pf
// `antispoof for <iface>` lowering: `fib saddr . iif oif missing`
// runs an in-kernel routing-table lookup keyed by source address +
// input interface and returns the chosen output interface; "missing"
// matches when the lookup yields oif==0 (asymmetric route).
pub const NFTA_FIB_DREG:   u16 = 1;
pub const NFTA_FIB_RESULT: u16 = 2;
pub const NFTA_FIB_FLAGS:  u16 = 3;
pub const NFT_FIB_RESULT_OIF:      u32 = 1;
pub const NFT_FIB_RESULT_OIFNAME:  u32 = 2;
pub const NFT_FIB_RESULT_ADDRTYPE: u32 = 3;
pub const NFTA_FIB_F_SADDR:   u32 = 1 << 0;
pub const NFTA_FIB_F_DADDR:   u32 = 1 << 1;
pub const NFTA_FIB_F_MARK:    u32 = 1 << 2;
pub const NFTA_FIB_F_IIF:     u32 = 1 << 3;
pub const NFTA_FIB_F_OIF:     u32 = 1 << 4;
pub const NFTA_FIB_F_PRESENT: u32 = 1 << 5;

// ── Alignment helper (shared with tc.rs) ───────────────────────
pub fn align4(n: usize) -> usize { (n + 3) & !3 }

// ── Helper functions ────────────────────────────────────────────

pub fn family_str(f: u8) -> &'static str {
    match f {
        NFPROTO_IPV4 => "ip", NFPROTO_IPV6 => "ip6", NFPROTO_INET => "inet",
        NFPROTO_ARP => "arp", NFPROTO_BRIDGE => "bridge", NFPROTO_NETDEV => "netdev",
        _ => "unknown",
    }
}

pub fn family_from_str(s: &str) -> Option<u8> {
    match s {
        "ip" => Some(NFPROTO_IPV4), "ip6" => Some(NFPROTO_IPV6),
        "inet" => Some(NFPROTO_INET), "arp" => Some(NFPROTO_ARP),
        "bridge" => Some(NFPROTO_BRIDGE), "netdev" => Some(NFPROTO_NETDEV),
        _ => None,
    }
}

pub fn hook_str(h: u32) -> &'static str {
    hook_str_family(h, NFPROTO_UNSPEC)
}

pub fn hook_str_family(h: u32, family: u8) -> &'static str {
    // netdev and arp families use different hook numbering from inet.
    if family == NFPROTO_NETDEV {
        return match h { 0 => "ingress", 1 => "egress", _ => "unknown" };
    }
    if family == NFPROTO_ARP {
        return match h { 0 => "input", 1 => "output", 2 => "forward", _ => "unknown" };
    }
    match h {
        NF_INET_PRE_ROUTING => "prerouting", NF_INET_LOCAL_IN => "input",
        NF_INET_FORWARD => "forward", NF_INET_LOCAL_OUT => "output",
        NF_INET_POST_ROUTING => "postrouting",
        // inet family sprouted an `ingress` hook with number 5 in
        // later kernels; we report it for that context only.
        5 if family == NFPROTO_INET => "ingress",
        _ => "unknown",
    }
}

pub fn hook_from_str(s: &str) -> Option<u32> {
    match s {
        "prerouting" => Some(NF_INET_PRE_ROUTING), "input" => Some(NF_INET_LOCAL_IN),
        "forward" => Some(NF_INET_FORWARD), "output" => Some(NF_INET_LOCAL_OUT),
        "postrouting" => Some(NF_INET_POST_ROUTING),
        "ingress" => Some(0), "egress" => Some(1),
        _ => None,
    }
}

pub fn verdict_str(code: i32) -> &'static str {
    match code {
        NF_ACCEPT => "accept", NF_DROP => "drop", NFT_RETURN => "return",
        NFT_JUMP => "jump", NFT_GOTO => "goto", NFT_CONTINUE => "continue",
        _ => "unknown",
    }
}

pub fn priority_from_str(s: &str, family: u8) -> i32 {
    priority_from_str_opt(s, family).unwrap_or(0)
}

/// Strict form used by the parser: returns None when `name` isn't a
/// recognised priority keyword so callers can surface a syntax error
/// (`priority dummy` shouldn't silently land at 0).
pub fn priority_from_str_opt(s: &str, family: u8) -> Option<i32> {
    let s = s.trim();
    // Try i32 first; on overflow try i64 and truncate — upstream nft
    // silently wraps huge literals rather than rejecting them.
    if let Ok(n) = s.parse::<i32>() { return Some(n); }
    if let Ok(n) = s.parse::<i64>() { return Some(n as i32); }

    let (name, rest) = if let Some(pos) = s.find(|c: char| c == '+' || c == '-') {
        (s[..pos].trim(), s[pos..].trim())
    } else {
        (s, "")
    };

    let base = match name {
        "raw" => -300,
        "mangle" => -150,
        "dstnat" => if family == NFPROTO_BRIDGE { -300 } else { -100 },
        "filter" => if family == NFPROTO_BRIDGE { -200 } else { 0 },
        "security" => 50,
        "srcnat" => if family == NFPROTO_BRIDGE { 300 } else { 100 },
        "out" => 100,
        _ => return None,
    };

    if rest.is_empty() { return Some(base); }
    let offset: i32 = rest.replace(' ', "").parse().ok()?;
    Some(base + offset)
}

// ── Netlink socket ──────────────────────────────────────────────

pub struct NlSocket {
    fd: i32,
    pub portid: u32,
    pub seq: u32,
}

impl NlSocket {
    pub fn open() -> io::Result<Self> {
        Self::open_protocol(NETLINK_NETFILTER)
    }

    /// Open a netlink socket for any protocol family (NETLINK_NETFILTER,
    /// NETLINK_ROUTE, etc.). The NLDUMP, buffer-size, NO_ENOBUFS, and
    /// CAP_ACK setup is shared across all families.
    pub fn open_protocol(protocol: i32) -> io::Result<Self> {
        // These 3 syscalls are the only unsafe in the entire crate
        let fd = unsafe {
            libc::socket(libc::AF_NETLINK, libc::SOCK_RAW | libc::SOCK_CLOEXEC, protocol)
        };
        if fd < 0 { return Err(io::Error::last_os_error()); }

        // Bump the send/recv buffers. The default ~208KB runs out of
        // headroom on big atomic ruleset loads (a few hundred chains
        // in one batch) and the kernel returns ENOBUFS. 16 MB is
        // generous; libmnl uses 1 MB by default. SO_*BUFFORCE bypasses
        // the rmem/wmem_max sysctls when we have CAP_NET_ADMIN.
        let sz: libc::c_int = 16 * 1024 * 1024;
        unsafe {
            libc::setsockopt(fd, libc::SOL_SOCKET, libc::SO_SNDBUFFORCE,
                &sz as *const _ as *const _, mem::size_of::<libc::c_int>() as u32);
            libc::setsockopt(fd, libc::SOL_SOCKET, libc::SO_RCVBUFFORCE,
                &sz as *const _ as *const _, mem::size_of::<libc::c_int>() as u32);
            libc::setsockopt(fd, libc::SOL_SOCKET, libc::SO_SNDBUF,
                &sz as *const _ as *const _, mem::size_of::<libc::c_int>() as u32);
            libc::setsockopt(fd, libc::SOL_SOCKET, libc::SO_RCVBUF,
                &sz as *const _ as *const _, mem::size_of::<libc::c_int>() as u32);
        }

        // NETLINK_NO_ENOBUFS: when the kernel's own send queue to us
        // fills up (we're too slow reading ACKs), don't return
        // ENOBUFS on our send(); just drop the overflow ACKs. This
        // is how libmnl handles bulk adds. A real error is still
        // delivered reliably; only redundant "no-error" ACKs get
        // dropped. (NETLINK_NO_ENOBUFS = 5 in linux/netlink.h UAPI.)
        const NETLINK_NO_ENOBUFS: libc::c_int = 5;
        let one: libc::c_int = 1;
        unsafe {
            libc::setsockopt(fd, libc::SOL_NETLINK, NETLINK_NO_ENOBUFS,
                &one as *const _ as *const _, mem::size_of::<libc::c_int>() as u32);
        }

        // NETLINK_CAP_ACK: tell the kernel we only want the nlmsghdr
        // of the original message echoed back in ACK/error messages,
        // not the whole body. Shrinks ACK traffic dramatically on
        // big batches so the kernel tx queue doesn't fill. libmnl
        // does the same. (NETLINK_CAP_ACK = 10.)
        const NETLINK_CAP_ACK: libc::c_int = 10;
        unsafe {
            libc::setsockopt(fd, libc::SOL_NETLINK, NETLINK_CAP_ACK,
                &one as *const _ as *const _, mem::size_of::<libc::c_int>() as u32);
        }

        let mut addr: libc::sockaddr_nl = unsafe { mem::zeroed() };
        addr.nl_family = libc::AF_NETLINK as u16;
        let ret = unsafe {
            libc::bind(fd, &addr as *const _ as *const libc::sockaddr,
                       mem::size_of::<libc::sockaddr_nl>() as u32)
        };
        if ret < 0 {
            unsafe { libc::close(fd); }
            return Err(io::Error::last_os_error());
        }

        // Get assigned portid
        let mut bound_addr: libc::sockaddr_nl = unsafe { mem::zeroed() };
        let mut len = mem::size_of::<libc::sockaddr_nl>() as u32;
        let ret = unsafe {
            libc::getsockname(fd, &mut bound_addr as *mut _ as *mut libc::sockaddr, &mut len)
        };
        let portid = if ret == 0 { bound_addr.nl_pid } else { 0 };

        Ok(NlSocket { fd, portid, seq: 1 })
    }

    pub fn send(&self, buf: &[u8]) -> io::Result<usize> {
        // STORMWALL_NLDUMP=<path>: append every outgoing netlink buffer
        // (BATCH_BEGIN..BATCH_END inclusive) to <path> as a hex dump.
        // Each call appends one record:
        //   ---\n<hex bytes one per line, 16 per row>\n
        // This is what the pf-parity harness diffs against the upstream
        // strace capture; without it we'd need a working kernel
        // (castle's missing nf_tables.ko otherwise blocks every
        // wire-format test).
        if let Ok(path) = std::env::var("STORMWALL_NLDUMP") {
            use std::io::Write;
            if let Ok(mut f) = std::fs::OpenOptions::new()
                .create(true).append(true).open(&path)
            {
                let _ = writeln!(f, "---");
                for chunk in buf.chunks(16) {
                    for (i, b) in chunk.iter().enumerate() {
                        if i > 0 { let _ = write!(f, " "); }
                        let _ = write!(f, "{:02x}", b);
                    }
                    let _ = writeln!(f);
                }
            }
            // When STORMWALL_NLDUMP is set we also short-circuit the
            // actual sendto() — the harness runs without root / without
            // a working kernel, so a real send would EPERM/ENOPKG.
            return Ok(buf.len());
        }
        let n = unsafe {
            libc::send(self.fd, buf.as_ptr() as *const _, buf.len(), 0)
        };
        if n < 0 { Err(io::Error::last_os_error()) } else { Ok(n as usize) }
    }

    pub fn recv(&self, buf: &mut [u8]) -> io::Result<usize> {
        let n = unsafe {
            libc::recv(self.fd, buf.as_mut_ptr() as *mut _, buf.len(), 0)
        };
        if n < 0 { Err(io::Error::last_os_error()) } else { Ok(n as usize) }
    }

    pub fn recv_timeout(&self, buf: &mut [u8], timeout_ms: i32) -> io::Result<usize> {
        let mut pfd = libc::pollfd { fd: self.fd, events: libc::POLLIN, revents: 0 };
        let ret = unsafe { libc::poll(&mut pfd, 1, timeout_ms) };
        if ret <= 0 { return Ok(0); }
        self.recv(buf)
    }

    /// Reuse a caller-owned buffer (resized to 65536 if smaller) and recv into it.
    /// Returns the number of bytes received.
    pub fn recv_with_buf(&self, buf: &mut Vec<u8>) -> io::Result<usize> {
        if buf.len() < 65536 { buf.resize(65536, 0); }
        self.recv(buf)
    }

    /// Same as recv_with_buf but with a poll timeout (milliseconds).
    pub fn recv_timeout_with_buf(&self, buf: &mut Vec<u8>, timeout_ms: i32) -> io::Result<usize> {
        if buf.len() < 65536 { buf.resize(65536, 0); }
        self.recv_timeout(buf, timeout_ms)
    }
}

impl Drop for NlSocket {
    fn drop(&mut self) {
        unsafe { libc::close(self.fd); }
    }
}

// ── Message builder (100% safe) ─────────────────────────────────

pub struct MsgBuilder {
    pub buf: Vec<u8>,
    pub seq: u32,
}

impl MsgBuilder {
    pub fn new() -> Self { MsgBuilder { buf: Vec::with_capacity(4096), seq: 1 } }

    pub fn batch_begin(&mut self) {
        // Batch begin uses nfnetlink subsystem 0, with res_id=NFNL_SUBSYS_NFTABLES
        let msg_type = NFNL_MSG_BATCH_BEGIN; // subsystem 0
        self.write_nlmsghdr(20, msg_type, NLM_F_REQUEST);
        self.write_nfgenmsg_batch();
    }

    pub fn batch_end(&mut self) {
        let msg_type = NFNL_MSG_BATCH_END;
        self.write_nlmsghdr(20, msg_type, NLM_F_REQUEST);
        self.write_nfgenmsg_batch();
    }

    /// Begin nftables message. Returns position of nlmsghdr for later fixup.
    pub fn begin_msg(&mut self, msg_type: u16, family: u8, flags: u16) -> usize {
        let pos = self.buf.len();
        let nl_type = (NFNL_SUBSYS_NFTABLES << 8) | msg_type;
        self.write_nlmsghdr(0, nl_type, NLM_F_REQUEST | flags); // len=0 placeholder
        self.write_nfgenmsg(family);
        pos
    }

    /// Fix up nlmsghdr.nlmsg_len at given position
    pub fn end_msg(&mut self, pos: usize) {
        let len = (self.buf.len() - pos) as u32;
        self.buf[pos..pos + 4].copy_from_slice(&len.to_ne_bytes());
    }

    pub fn put_str(&mut self, attr_type: u16, val: &str) {
        let data_len = val.len() + 1; // NUL terminated
        let nla_len = 4 + data_len;
        self.buf.extend_from_slice(&(nla_len as u16).to_ne_bytes());
        self.buf.extend_from_slice(&attr_type.to_ne_bytes());
        self.buf.extend_from_slice(val.as_bytes());
        self.buf.push(0); // NUL
        self.pad4();
    }

    pub fn put_u32(&mut self, attr_type: u16, val: u32) {
        self.buf.extend_from_slice(&8u16.to_ne_bytes()); // nla_len = 4 + 4
        self.buf.extend_from_slice(&attr_type.to_ne_bytes());
        self.buf.extend_from_slice(&val.to_ne_bytes());
    }

    pub fn put_u32_be(&mut self, attr_type: u16, val: u32) {
        self.buf.extend_from_slice(&8u16.to_ne_bytes());
        self.buf.extend_from_slice(&attr_type.to_ne_bytes());
        self.buf.extend_from_slice(&val.to_be_bytes());
    }

    pub fn put_u64_be(&mut self, attr_type: u16, val: u64) {
        self.buf.extend_from_slice(&12u16.to_ne_bytes()); // 4 + 8
        self.buf.extend_from_slice(&attr_type.to_ne_bytes());
        self.buf.extend_from_slice(&val.to_be_bytes());
    }

    pub fn put_u64(&mut self, attr_type: u16, val: u64) {
        self.buf.extend_from_slice(&12u16.to_ne_bytes()); // 4 + 8
        self.buf.extend_from_slice(&attr_type.to_ne_bytes());
        self.buf.extend_from_slice(&val.to_ne_bytes());
    }

    /// 1-byte attribute. The kernel still expects 4-byte alignment, so
    /// the trailing 3 bytes are zero-padded — same as put_bytes.
    pub fn put_u8(&mut self, attr_type: u16, val: u8) {
        self.buf.extend_from_slice(&5u16.to_ne_bytes()); // 4 + 1
        self.buf.extend_from_slice(&attr_type.to_ne_bytes());
        self.buf.push(val);
        self.pad4();
    }

    /// 2-byte attribute in network byte order. Used for L3PROTO fields
    /// (e.g. NFTA_CT_HELPER_L3PROTO) where the kernel reads big-endian.
    pub fn put_u16_be(&mut self, attr_type: u16, val: u16) {
        self.buf.extend_from_slice(&6u16.to_ne_bytes()); // 4 + 2
        self.buf.extend_from_slice(&attr_type.to_ne_bytes());
        self.buf.extend_from_slice(&val.to_be_bytes());
        self.pad4();
    }

    pub fn put_bytes(&mut self, attr_type: u16, data: &[u8]) {
        let nla_len = 4 + data.len();
        self.buf.extend_from_slice(&(nla_len as u16).to_ne_bytes());
        self.buf.extend_from_slice(&attr_type.to_ne_bytes());
        self.buf.extend_from_slice(data);
        self.pad4();
    }

    /// Begin nested attribute. Returns position for fixup.
    pub fn begin_nested(&mut self, attr_type: u16) -> usize {
        let pos = self.buf.len();
        self.buf.extend_from_slice(&0u16.to_ne_bytes()); // placeholder len
        self.buf.extend_from_slice(&(NLA_F_NESTED | attr_type).to_ne_bytes());
        pos
    }

    /// End nested attribute (fix up nla_len)
    pub fn end_nested(&mut self, pos: usize) {
        let len = (self.buf.len() - pos) as u16;
        self.buf[pos..pos + 2].copy_from_slice(&len.to_ne_bytes());
    }

    /// Put data wrapped in NFTA_DATA_VALUE nested attribute
    pub fn put_data_value(&mut self, attr_type: u16, data: &[u8]) {
        let outer = self.begin_nested(attr_type);
        self.put_bytes(NFTA_DATA_VALUE, data);
        self.end_nested(outer);
    }

    /// Emit a nested attribute whose body is a pre-encoded byte slice.
    /// Writes the 4-byte nested-attribute header (NLA_F_NESTED | attr_type,
    /// length = 4 + body.len()) and then appends `body` verbatim.  No
    /// padding is added — callers must ensure `body` is already aligned.
    pub fn put_nested_raw(&mut self, attr_type: u16, body: &[u8]) {
        let nla_len = 4 + body.len();
        self.buf.extend_from_slice(&(nla_len as u16).to_ne_bytes());
        self.buf.extend_from_slice(&(NLA_F_NESTED | attr_type).to_ne_bytes());
        self.buf.extend_from_slice(body);
    }

    pub fn finish(self) -> Vec<u8> { self.buf }
    pub fn current_seq(&self) -> u32 { self.seq }

    /// Write a raw nlmsghdr. Used by nftables begin_msg and by tc.rs.
    pub fn write_nlmsghdr(&mut self, len: u32, msg_type: u16, flags: u16) {
        let seq = self.seq;
        self.seq += 1;
        self.buf.extend_from_slice(&len.to_ne_bytes());
        self.buf.extend_from_slice(&msg_type.to_ne_bytes());
        self.buf.extend_from_slice(&flags.to_ne_bytes());
        self.buf.extend_from_slice(&seq.to_ne_bytes());
        self.buf.extend_from_slice(&0u32.to_ne_bytes()); // pid
    }

    fn write_nfgenmsg(&mut self, family: u8) {
        self.buf.push(family);
        self.buf.push(0); // version = NFNETLINK_V0
        self.buf.extend_from_slice(&0u16.to_be_bytes()); // res_id
    }

    fn write_nfgenmsg_batch(&mut self) {
        self.buf.push(0); // AF_UNSPEC
        self.buf.push(0); // NFNETLINK_V0
        self.buf.extend_from_slice(&(NFNL_SUBSYS_NFTABLES as u16).to_be_bytes()); // res_id = subsystem
    }

    pub fn pad4(&mut self) {
        let aligned = align4(self.buf.len());
        while self.buf.len() < aligned { self.buf.push(0); }
    }
}

// ── Response parser (100% safe) ─────────────────────────────────

/// Parse netlink attributes from a byte slice. Returns (type, value) pairs.
pub fn parse_attrs(data: &[u8]) -> Vec<(u16, Vec<u8>)> {
    let mut result = Vec::new();
    let mut pos = 0;
    while pos + 4 <= data.len() {
        let nla_len = u16::from_ne_bytes([data[pos], data[pos + 1]]) as usize;
        let nla_type = u16::from_ne_bytes([data[pos + 2], data[pos + 3]]) & 0x3FFF; // mask NLA_F_*
        if nla_len < 4 || pos + nla_len > data.len() { break; }
        let val = data[pos + 4..pos + nla_len].to_vec();
        result.push((nla_type, val));
        pos += align4(nla_len);
    }
    result
}

/// Get a string attribute (NUL-terminated)
pub fn attr_str(val: &[u8]) -> &str {
    let end = val.iter().position(|&b| b == 0).unwrap_or(val.len());
    std::str::from_utf8(&val[..end]).unwrap_or("")
}

/// Get a u32 attribute (native endian)
pub fn attr_u32(val: &[u8]) -> u32 {
    if val.len() >= 4 {
        u32::from_ne_bytes([val[0], val[1], val[2], val[3]])
    } else { 0 }
}

/// Get a u32 attribute (big endian)
pub fn attr_u32_be(val: &[u8]) -> u32 {
    if val.len() >= 4 {
        u32::from_be_bytes([val[0], val[1], val[2], val[3]])
    } else { 0 }
}

/// Get a u16 attribute (big endian). Used by `queue` whose NUM/TOTAL/
/// FLAGS attributes are u16-NBO rather than u32-NBO.
pub fn attr_u16_be(val: &[u8]) -> u16 {
    if val.len() >= 2 {
        u16::from_be_bytes([val[0], val[1]])
    } else { 0 }
}

/// Get a u64 attribute (big endian)
pub fn attr_u64_be(val: &[u8]) -> u64 {
    if val.len() >= 8 {
        u64::from_be_bytes([val[0], val[1], val[2], val[3], val[4], val[5], val[6], val[7]])
    } else { 0 }
}

/// Get an i32 attribute (big endian)
pub fn attr_i32_be(val: &[u8]) -> i32 {
    if val.len() >= 4 {
        i32::from_be_bytes([val[0], val[1], val[2], val[3]])
    } else { 0 }
}

/// Process received netlink data. Calls handler for each nftables message.
/// Returns true if NLMSG_DONE was seen.
/// Handler receives (msg_type_without_subsys, family, attrs_data).
pub fn process_response<F>(
    data: &[u8], portid: u32, mut handler: F
) -> io::Result<bool>
where F: FnMut(u16, u8, &[u8])
{
    let mut pos = 0;
    while pos + 16 <= data.len() {
        let nlmsg_len = u32::from_ne_bytes([data[pos], data[pos+1], data[pos+2], data[pos+3]]) as usize;
        let nlmsg_type = u16::from_ne_bytes([data[pos+4], data[pos+5]]);
        let _flags = u16::from_ne_bytes([data[pos+6], data[pos+7]]);
        let _seq = u32::from_ne_bytes([data[pos+8], data[pos+9], data[pos+10], data[pos+11]]);
        let _pid = u32::from_ne_bytes([data[pos+12], data[pos+13], data[pos+14], data[pos+15]]);

        if nlmsg_len < 16 || pos + nlmsg_len > data.len() { break; }

        if nlmsg_type == NLMSG_DONE {
            return Ok(true);
        }

        if nlmsg_type == NLMSG_ERROR {
            // Body is an nlmsgerr: i32 error code (negative errno if set,
            // zero for a pure ACK) followed by the echoed original header.
            // Previously we swallowed EOPNOTSUPP; the kernel returns that
            // for legitimate rejections (jump loops, masquerade in the
            // wrong hook, invalid family-hook combos) so swallowing it
            // makes every negative test pass silently. Any non-zero
            // value is a real error.
            // nlmsgerr: i32 error + original nlmsghdr
            if nlmsg_len >= 20 {
                let err = i32::from_ne_bytes([data[pos+16], data[pos+17], data[pos+18], data[pos+19]]);
                if err < 0 {
                    return Err(io::Error::from_raw_os_error(-err));
                }
            }
            pos += align4(nlmsg_len);
            continue;
        }

        // nftables message: after nlmsghdr comes nfgenmsg (4 bytes)
        if nlmsg_len >= 20 {
            let family = data[pos + 16];
            let msg_type_raw = nlmsg_type & 0xFF; // strip subsystem
            let payload_start = pos + 20; // after nlmsghdr(16) + nfgenmsg(4)
            let payload_end = pos + nlmsg_len;
            if payload_start <= payload_end && payload_end <= data.len() {
                handler(msg_type_raw, family, &data[payload_start..payload_end]);
            }
        }

        pos += align4(nlmsg_len);
    }
    let _ = portid;
    Ok(false)
}

/// Check batch ACK responses. Returns Ok if no kernel errors.
pub fn check_ack(data: &[u8]) -> io::Result<()> {
    process_response(data, 0, |_, _, _| {})?;
    Ok(())
}

/// Process a receive buffer for pipelined (multi-dump) mode.
///
/// `seq_base` is the seq of the first request in the batch; requests are
/// assigned seq_base, seq_base+1, ..., seq_base+N-1.  `done_flags` is a
/// mutable slice of N booleans — entry i is set to true when NLMSG_DONE for
/// seq_base+i arrives.  `handler` receives (index_into_batch, msg_type,
/// family, payload).
///
/// Returns Ok(()) on success; returns Err on any kernel error response.
pub fn process_response_multi<F>(
    data: &[u8],
    seq_base: u32,
    n_reqs: usize,
    done_flags: &mut [bool],
    mut handler: F,
) -> io::Result<()>
where F: FnMut(usize, u16, u8, &[u8])
{
    let mut pos = 0;
    while pos + 16 <= data.len() {
        let nlmsg_len = u32::from_ne_bytes([data[pos], data[pos+1], data[pos+2], data[pos+3]]) as usize;
        let nlmsg_type = u16::from_ne_bytes([data[pos+4], data[pos+5]]);
        let seq = u32::from_ne_bytes([data[pos+8], data[pos+9], data[pos+10], data[pos+11]]);

        if nlmsg_len < 16 || pos + nlmsg_len > data.len() { break; }

        // Map seq → batch index. Seqs are assigned monotonically starting
        // at seq_base, so any seq outside [seq_base, seq_base+n_reqs) is
        // stale or unrelated — skip it.
        let idx = seq.wrapping_sub(seq_base) as usize;

        if nlmsg_type == NLMSG_DONE {
            if idx < n_reqs { done_flags[idx] = true; }
            pos += align4(nlmsg_len);
            continue;
        }

        if nlmsg_type == NLMSG_ERROR {
            if nlmsg_len >= 20 {
                let err = i32::from_ne_bytes([data[pos+16], data[pos+17], data[pos+18], data[pos+19]]);
                if err < 0 {
                    return Err(io::Error::from_raw_os_error(-err));
                }
            }
            pos += align4(nlmsg_len);
            continue;
        }

        // nftables data message
        if nlmsg_len >= 20 && idx < n_reqs {
            let family = data[pos + 16];
            let msg_type_raw = nlmsg_type & 0xFF;
            let payload_start = pos + 20;
            let payload_end = pos + nlmsg_len;
            if payload_start <= payload_end && payload_end <= data.len() {
                handler(idx, msg_type_raw, family, &data[payload_start..payload_end]);
            }
        }

        pos += align4(nlmsg_len);
    }
    Ok(())
}

/// Map nft set type name to (kernel_type_id, key_len_bytes).
/// Kernel type IDs match include/uapi/linux/netfilter/nf_tables.h
/// NFT_DATA_* plus type-specific ids used by libnftables.
pub fn set_key_type(s: &str) -> (u32, u32) {
    match s {
        "invalid_type" => (0, 0),
        // Data side only — kernel wants NFT_DATA_VERDICT (a mask, not
        // a numeric type index) with dlen=0 since the verdict struct
        // size is supplied via the element's NFTA_DATA_VERDICT nesting.
        "verdict" => (0xffffff00, 0),
        "nf_proto" => (2, 1),
        "bitmask" => (3, 4),
        "integer" => (4, 4),
        "string" => (5, 16),
        "ll_addr" => (6, 6),
        "ipv4_addr" => (7, 4),
        "ipv6_addr" => (8, 16),
        "ether_addr" => (9, 6),
        "ether_type" => (10, 2),
        "arp_op" => (11, 2),
        "inet_proto" => (12, 1),
        "inet_service" => (13, 2),
        "icmp_type" => (14, 1),
        "mark" => (15, 4),
        "ifname" => (16, 16),
        "pkttype" => (17, 1),
        "icmp_code" => (18, 1),
        "icmpv6_type" => (19, 1),
        "icmpv6_code" => (20, 1),
        "icmpx_code" => (21, 1),
        "devgroup" => (22, 4),
        "classid" => (23, 4),
        "dscp" => (36, 1),
        "ecn" => (37, 1),
        "fib_addrtype" => (38, 4),
        "boolean" => (26, 1),
        "ct_state" => (27, 4),
        "ct_dir" => (28, 1),
        "ct_status" => (29, 4),
        "icmp_kind" => (30, 1),
        "ct_label" => (31, 16),
        "iface_index" | "ifindex" => (36, 4),
        // `queue` — integer (type 4) with u16 width, used as the
        // data type in `typeof ... : queue` maps. The kernel
        // stores NFTA_SET_DATA_TYPE=4 (integer) with DATA_LEN=2.
        "queue" => (4, 2),
        // Stateful-object type names for object-reference maps.
        // Encoded as 0x80000000 | NFT_OBJECT_XXX so callers can detect
        // them without a separate is_obj_type flag. The kernel uses the
        // NFT_SET_OBJECT (0x40) flag plus NFTA_SET_OBJ_TYPE = N; the
        // data_type in the netlink message is not separately set for
        // these maps (the kernel doesn't populate NFTA_SET_DATA_TYPE).
        "counter"     => (0x80000001, 0), // NFT_OBJECT_COUNTER = 1
        "quota"       => (0x80000002, 0), // NFT_OBJECT_QUOTA   = 2
        "limit"       => (0x80000004, 0), // NFT_OBJECT_LIMIT   = 4
        "ct helper"   => (0x80000003, 0), // NFT_OBJECT_CT_HELPER = 3
        "synproxy"    => (0x8000000a, 0), // NFT_OBJECT_SYNPROXY = 10
        "secmark"     => (0x80000008, 0), // NFT_OBJECT_SECMARK = 8
        _ => (0, 0),
    }
}

/// Return true if the value returned by `set_key_type` encodes a
/// stateful-object type (NFT_SET_OBJECT map data type).
pub fn is_obj_type(v: u32) -> bool { v & 0x80000000 != 0 }

/// Strip the sentinel high bit to get the raw NFT_OBJECT_XXX constant.
pub fn obj_type_from_sentinel(v: u32) -> u32 { v & 0x7fffffff }

pub fn set_type_name(t: u32) -> &'static str {
    match t {
        // NFT_DATA_VERDICT is a mask (0xffffff00), not a numeric
        // type index — maps that store verdicts set this on
        // NFTA_SET_DATA_TYPE with DATA_LEN=0.
        0xffffff00 => "verdict",
        1 => "integer_legacy", 2 => "nf_proto", 3 => "bitmask",
        4 => "integer", 5 => "string", 6 => "ll_addr",
        7 => "ipv4_addr", 8 => "ipv6_addr", 9 => "ether_addr",
        10 => "ether_type", 11 => "arp_op",
        12 => "inet_proto", 13 => "inet_service",
        14 => "icmp_type", 15 => "mark", 16 => "ifname",
        17 => "pkttype", 18 => "icmp_code",
        19 => "icmpv6_type", 20 => "icmpv6_code",
        21 => "icmpx_code", 22 => "devgroup",
        23 => "classid",
        25 => "fib_addrtype", 26 => "boolean",
        27 => "ct_state", 28 => "ct_dir", 29 => "ct_status",
        30 => "icmp_kind", 31 => "ct_label",
        36 => "iface_index",
        _ => "unknown",
    }
}

/// Decode a (potentially concat-packed) NFTA_SET_KEY_TYPE value into the
/// human-readable type string used by `nft list`.
///
/// Simple types (value fits in 6 bits, i.e. <= 63) are looked up directly.
/// Concat types are packed by upstream nft as a sequence of 6-bit slots built
/// with `dtype_pack`: `packed = (packed << 6) | next_type_id`.  Decoding peels
/// 6-bit chunks from the LSB, reverses them, drops trailing zero slots, and
/// joins the names with " . ".
///
/// Example: ipv4_addr . inet_service . ipv4_addr . inet_service . inet_proto
///   = 7,13,7,13,12 → 0x0734734c
pub fn key_type_str(t: u32) -> String {
    if t <= 63 {
        // Single type — no concat packing.
        return set_type_name(t).to_string();
    }
    // Unpack 6-bit slots from LSB.
    let mut slots: [u32; 6] = [0; 6];
    let mut count = 0usize;
    let mut v = t;
    while v != 0 && count < 6 {
        slots[count] = v & 0x3f;
        v >>= 6;
        count += 1;
    }
    // slots[0] is the last (rightmost) type; reverse to get declaration order.
    let mut parts = Vec::with_capacity(count);
    let mut i = count;
    while i > 0 {
        i -= 1;
        let id = slots[i];
        if id != 0 {
            parts.push(set_type_name(id));
        }
    }
    if parts.is_empty() {
        return set_type_name(t).to_string();
    }
    parts.join(" . ")
}

/// Map an NFT_OBJECT_XXX constant to the nft type-name string used in
/// `type KEY : OBJ` map declarations. Returns "unknown" for unrecognised IDs.
pub fn obj_type_name(obj: u32) -> &'static str {
    match obj {
        1  => "counter",
        2  => "quota",
        3  => "ct helper",
        4  => "limit",
        5  => "synproxy",
        6  => "tunnel",
        7  => "ct timeout",
        8  => "secmark",
        9  => "ct expectation",
        10 => "synproxy",
        _  => "unknown",
    }
}
