//! nft command parser - tokenizer + command parser. 100% safe Rust.

use crate::netlink::*;
use std::net::Ipv4Addr;

// `if_nametoindex(3)` — resolve an interface name to its kernel index.
// Used by `dup`/`fwd` parsers, both of which encode the index directly
// into the immediate that feeds the SREG_DEV register. We dlsym via
// libc rather than re-implement the netlink walk; the kernel rejects
// index 0, so a missing iface naturally surfaces as a load failure
// during the apply.
pub(crate) fn if_nametoindex(name: &str) -> Option<u32> {
    use std::ffi::CString;
    let c = CString::new(name).ok()?;
    let idx = unsafe { libc::if_nametoindex(c.as_ptr()) };
    if idx == 0 { None } else { Some(idx) }
}

// ── Types ───────────────────────────────────────────────────────

#[derive(Debug, Clone)] pub enum CmdOp { Add, Create, Delete, Destroy, List, Flush, Rename, Insert, Replace, Reset }
#[derive(Debug, Clone, PartialEq)] pub enum CmdObj {
    Table, Chain, Rule, Set, Map, Element,
    Ruleset, Tables, Chains, Rules, Sets, Maps,
    // Named stateful objects.
    Counter, Quota, Limit,
    Counters, Quotas, Limits,
    // ct helper / ct timeout / ct expectation named objects.
    CtHelper,
    CtTimeout,
    CtExpect,
    // synproxy named object: SYN-proxy cookie offload.
    //   add synproxy inet t sp { mss 1460; wscale 7; timestamp sack-perm; }
    Synproxy,
    // secmark named object: SELinux context mark.
    //   add secmark inet t sm { "system_u:object_r:ssh_server_packet_t:s0"; }
    Secmark,
    // Flowtable: kernel-side packet-bypass / offload object.
    //   add flowtable inet t ft { hook ingress priority filter; devices = { lo }; }
    Flowtable,
    // `list flowtables` — plural form for listing all flowtables.
    Flowtables,
    // `list objects` — list all named stateful objects.
    Objects,
    // Tunnel named object (NFT_OBJECT_TUNNEL).
    //   add tunnel netdev t geneve-t { id 10; ... geneve { class 0x1 ... } }
    Tunnel,
}

/// Attributes for a flowtable declaration. The flowtable lives directly
/// inside a table (NFT_MSG_NEWFLOWTABLE) and carries a hook number,
/// priority and a list of underlying network devices that feed it. Flags
/// is reserved for `flags offload` (HW offload) — collected here so the
/// encoder can write NFTA_FLOWTABLE_FLAGS when the source asked for it.
#[derive(Debug, Clone, Default)]
pub struct FlowtableSpec {
    pub hook: String,        // always "ingress" today
    pub priority: i32,
    pub has_priority: bool,
    pub devices: Vec<String>,
    pub flags: u32,
}

#[derive(Debug, Clone, Default)]
pub struct ChainSpec {
    pub is_base: bool,
    pub chain_type: String,
    pub hook: String,
    pub priority: i32,
    pub has_priority: bool,
    pub policy: String,
    pub has_policy: bool,
    pub device: String,
    pub has_device: bool,
    pub is_binding: bool,
    pub chain_id: u32,
    pub has_chain_id: bool,
}

#[derive(Debug, Clone, Default)]
pub struct TableSpec {
    pub flags: u32,
    pub has_flags: bool,
}

#[derive(Debug, Clone, Default)]
pub struct SetSpec {
    pub key_type_name: String,
    pub key_type: u32,
    pub key_len: u32,
    pub data_type_name: String,
    pub data_type: u32,
    pub data_len: u32,
    pub flags: u32,
    pub has_flags: bool,
    pub is_map: bool,
    /// True when data_type is a stateful-object type name (e.g. "counter").
    /// In this case `obj_type` carries the NFT_OBJECT_XXX constant and the
    /// kernel expects NFT_SET_OBJECT flag + NFTA_SET_OBJ_TYPE instead of
    /// NFTA_SET_DATA_TYPE.
    pub is_obj_map: bool,
    /// NFT_OBJECT_XXX constant for the map's value type; only valid when
    /// `is_obj_map == true`.
    pub obj_type: u32,
    /// Explicit `size N` from the set declaration; 0 means not specified.
    /// When non-zero, ops emits NFTA_SET_DESC → NFTA_SET_DESC_SIZE so the
    /// kernel pre-sizes the rhashtable — mirroring nft wire behaviour exactly.
    pub size: u32,
    /// Default per-element timeout in milliseconds for sets carrying
    /// the timeout flag (`add set ... { ... timeout 1m; }`). 0 when
    /// no default was specified.
    pub timeout_ms: u64,
    pub has_timeout: bool,
    /// For concat key types, stores the byte width of each slot (e.g.
    /// `[4, 4, 2]` for `ipv4_addr . ipv4_addr . inet_service`). Empty
    /// for non-concat keys. Used to encode each concat element value
    /// in its natural width before 4-byte padding.
    pub concat_widths: Vec<u32>,
}

/// Attributes for a named stateful object declaration:
///     add counter t cnt { packets 0 bytes 0 ; }
///     add quota t q   { over 500 mbytes ; }
///     add limit t l   { rate 10/second burst 5 packets ; }
/// The `kind` field is one of NFT_OBJECT_COUNTER / _QUOTA / _LIMIT.
#[derive(Debug, Clone, Default)]
pub struct ObjSpec {
    pub kind: u32,
    pub packets: u64,       // counter init + limit `rate <N>`
    pub bytes: u64,         // counter init + quota `<N> bytes`
    pub quota_consumed: u64, // quota `used <N> bytes` initial consumed value
    pub quota_flags: u32,   // NFT_QUOTA_F_INV when `over` is used
    pub limit_rate: u64,
    pub limit_unit: u64,    // seconds per period (1, 60, 3600, 86400)
    pub limit_burst: u32,
    pub limit_type: u32,    // NFT_LIMIT_PKTS (0) or NFT_LIMIT_PKT_BYTES (1)
    pub limit_flags: u32,   // NFT_LIMIT_F_INV
    /// `ct helper` body fields. `helper_type` is the kernel helper
    /// module name ("ftp", "sip", ...). `helper_l4proto` is the L4
    /// transport (IPPROTO_TCP=6, IPPROTO_UDP=17). `helper_l3proto` is
    /// the L3 family (NFPROTO_*) — defaulted to the table's family
    /// when the source omits an explicit `l3proto` line.
    pub helper_type: String,
    pub helper_l4proto: u8,
    pub helper_l3proto: u16,
    pub has_helper_l3proto: bool,
    /// `ct timeout` body fields. `ct_timeout_l4proto` is IPPROTO_* (u16 NBO
    /// in the kernel, but we store host-order u16 here). `ct_timeout_l3proto`
    /// is NFPROTO_*. `ct_timeout_policy` is a list of (state_name, seconds)
    /// pairs that map to per-state attributes inside NFTA_CT_TIMEOUT_DATA.
    pub ct_timeout_l4proto: u16,
    pub ct_timeout_l3proto: u16,
    pub has_ct_timeout_l3proto: bool,
    pub ct_timeout_policy: Vec<(String, u32)>,
    /// `ct expectation` body fields.
    pub ct_expect_l3proto: u16,
    pub ct_expect_protocol: u8,
    pub ct_expect_dport: u16,
    pub ct_expect_timeout: u32,  // seconds
    pub ct_expect_size: u8,
    /// `synproxy` body fields.
    pub synproxy_mss: u16,
    pub synproxy_wscale: u8,
    pub synproxy_flags: u32,
    /// `secmark` body field: SELinux security context string.
    pub secmark_ctx: String,
    /// `tunnel` body fields.
    pub tunnel_id: u32,
    pub tunnel_src_v4: [u8; 4],
    pub tunnel_dst_v4: [u8; 4],
    pub tunnel_src_v6: [u8; 16],
    pub tunnel_dst_v6: [u8; 16],
    pub tunnel_is_v6: bool,
    pub tunnel_sport: u16,
    pub tunnel_dport: u16,
    pub tunnel_tos: u8,
    pub tunnel_ttl: u8,
    pub tunnel_flags: u32,
    /// Sub-type options: geneve TLVs, vxlan GBP, or erspan version/params.
    pub tunnel_opts: TunnelOpts,
}

/// Tunnel sub-type options inside a tunnel object.
#[derive(Debug, Clone, Default)]
pub enum TunnelOpts {
    #[default]
    None,
    Geneve { tlvs: Vec<GeneveTlv> },
    Vxlan { gbp: u32 },
    ErspanV1 { index: u32 },
    ErspanV2 { hwid: u8, dir: u8 },
}

#[derive(Debug, Clone)]
pub struct GeneveTlv {
    pub class: u16,
    pub opt_type: u8,
    pub data: Vec<u8>,
}

#[derive(Debug, Clone)]
pub enum Expr {
    Payload { base: u32, offset: u32, len: u32, protocol: u8 },
    // `width` is the source value's byte width; used to pick the correct
    // destination register (NFT_REG_1 for 16-byte keys like iifname,
    // NFT_REG32_00 for 4-byte keys like mark). Default 4 for back-compat.
    Meta { key: u32, width: usize },
    Ct { key: u32, dir: i8, width: usize },
    Cmp { op: u32, data: Vec<u8> },
    Bitwise { mask: Vec<u8>, xor: Vec<u8> },
    Verdict { code: i32, chain: String },
    /// `ip saddr @blocked` / `tcp dport != @allowed` — look the value in
    /// the current register up in a named set. `inverted` is true for
    /// `!=` (NFT_LOOKUP_F_INV). `width` is the key width, used to pick
    /// the same register the preceding Meta/Payload stored into.
    Lookup { set_name: String, inverted: bool, width: usize },
    /// Anonymous set literal: `ip saddr { 1.1.1.1, 2.2.2.2 }` or
    /// `tcp dport { 22, 80 }`. At rule-build time ops.rs allocates a
    /// `__setN` name, emits NEWSET+NEWSETELEM into the same batch, and
    /// replaces this variant with an Expr::Lookup that points at the
    /// freshly-created anon set. Element tuples use the same
    /// (key, optional-range-end) shape as Command::elements, so CIDR
    /// ranges and `a-b` literals lower naturally.
    AnonSet { elements: Vec<(Vec<u8>, Option<Vec<u8>>)>, width: usize, inverted: bool },
    /// `... vmap @set` — named verdict map lookup. `set_id` is `Some(n)`
    /// for anon vmaps so the lookup's NFTA_LOOKUP_SET_ID matches the
    /// NEWSET's NFTA_SET_ID in the same batch (required by the kernel
    /// for transactional-name resolution); `None` for named maps.
    Vmap { set_name: String, width: usize, set_id: Option<u32> },
    /// `... map @set` returning a non-verdict data value into a
    /// destination register. Used by `queue ... to <fields...> map
    /// @qmap` (data type = queue/u16) and other dynamic-target
    /// statements where the loaded value is then consumed by a
    /// trailing expression's SREG. Identical wire format to a vmap
    /// lookup but with DREG=NFT_REG_1 instead of NFT_REG_VERDICT.
    MapLookup { set_name: String, key_width: usize, dreg: u32 },
    /// `... vmap { key : VERDICT, ... }` — anonymous verdict map literal.
    /// Each tuple: (start_key, optional_end_key, verdict_code, chain_name).
    /// End key is Some when using range syntax (e.g. `100-222 : accept`).
    /// `packed_key_type` carries the dtype_pack value (6-bit-per-slot
    /// encoding of NFT_SET_KEY_TYPE) so ops.rs can emit the correct
    /// NFTA_SET_KEY_TYPE attribute.  Zero means "infer from width".
    AnonVmap { pairs: Vec<(Vec<u8>, Option<Vec<u8>>, i32, String)>, width: usize, packed_key_type: u32 },
    /// Reference to a named stateful object from a rule:
    ///     counter name "cnt"        (kind = NFT_OBJECT_COUNTER)
    ///     quota name   "q"          (kind = NFT_OBJECT_QUOTA)
    ///     limit name   "l"          (kind = NFT_OBJECT_LIMIT)
    /// Encodes as the `objref` expression with IMM_TYPE + IMM_NAME.
    ObjRef { kind: u32, name: String },
    Counter,
    Log { prefix: String },
    Limit { rate: u64, unit: u64, burst: u32, flags: u32 },
    Nat { nat_type: u32, family: u8, addr: Vec<u8>, port: u16, has_addr: bool, has_port: bool,
          /// Upper bound for address ranges (`snat to a-b`); empty when
          /// the rule names a single address.
          addr_max: Vec<u8>,
          has_addr_max: bool,
          /// NF_NAT_RANGE_* bitmap, encoded as NFTA_NAT_FLAGS u32 NBO.
          /// 0 when no `random`/`fully-random`/`persistent` modifier.
          flags: u32 },
    Masquerade { flags: u32 },
    Notrack,
    Reject,
    /// `add @setname { <key> [timeout <duration>] }` — adds the value
    /// in the prior key-load register to a named dynamic set. The
    /// preceding expression (a Payload/Meta/Ct load) writes the key
    /// into the same register the dynset expression then reads via
    /// NFTA_DYNSET_SREG_KEY. `op` is NFT_DYNSET_OP_ADD or
    /// NFT_DYNSET_OP_UPDATE; `timeout_ms` is 0 when no per-element
    /// timeout was specified.
    Dynset { set_name: String, op: u32, key_width: usize, timeout_ms: u64, set_id: Option<u32> },
    /// `meter <name> { <key> limit rate R/UNIT [burst B] }` — anonymous-
    /// meter form of dynset, where the dynset expression carries a
    /// nested NFTA_DYNSET_EXPR holding a `limit` block (rate/unit/burst/
    /// type/flags). The pf-syntax lowerer emits this for
    /// `max-src-conn-rate R/T`. Wire form: same as Dynset above plus
    /// NFTA_DYNSET_EXPR containing one NFTA_LIST_ELEM with EXPR_NAME
    /// "limit" and the standard limit attributes.
    DynsetMeter {
        set_name: String,
        key_width: usize,
        rate: u64,
        unit: u64,
        burst: u32,
        limit_type: u32,
        limit_flags: u32,
    },
    /// `ct count [over] N` — per-source-address connection / state cap.
    /// pf's `max-src-conn N` and `max-src-states N` both lower to this
    /// since nftables tracks connections-and-states together. `inv`
    /// toggles NFT_CONNLIMIT_F_INV (the "over" qualifier); `pass keep
    /// state (max-src-conn N)` always emits inv=true so the rule body
    /// only runs when the count exceeds the threshold.
    Connlimit { count: u32, inv: bool },
    /// `flow add @ft` — push the matching connection into a named
    /// flowtable for kernel-side bypass once the conntrack entry is
    /// established. Encoded as the `flow_offload` expression with
    /// NFTA_FLOW_TABLE_NAME = "ft".
    FlowOffload { name: String },
    /// `socket KEY` — load an attribute of the packet's owning local
    /// socket into a register so the next cmp can match on it.
    /// `width` picks the register class (4 bytes for transparent /
    /// mark / wildcard, 8 bytes for cgroupv2). `level` is only used
    /// for cgroupv2 lookups (NFTA_SOCKET_LEVEL).
    Socket { key: u32, width: usize, level: Option<u32> },
    /// `rt KEY` — load a routing-derived value (classid, nexthop4/6,
    /// tcpmss) into a register so the next cmp can match on it.
    Rt { key: u32, width: usize },
    /// `meta KEY set <expr>` — store the value left in NFT_REG_1 by
    /// the preceding numgen / jhash / symhash expression into a
    /// writable meta key (mark, priority, pkttype, …). The wire form
    /// is the `meta` expression with NFTA_META_SREG=NFT_REG_1 instead
    /// of the read-side NFTA_META_DREG. Always preceded in the
    /// expression stream by the producing Numgen / Hash variant.
    MetaSet { key: u32 },
    /// `numgen (inc|random) mod M [offset N]` — generate a packet
    /// counter / random number, take it modulo M, optionally add a
    /// constant offset, and store into NFT_REG_1 for the next
    /// expression to consume. `ng_type` is NFT_NG_INCREMENTAL=0 or
    /// NFT_NG_RANDOM=1.
    Numgen { ng_type: u32, modulus: u32, offset: u32 },
    /// `jhash <key-expr> mod M [seed S] [offset N]` and
    /// `symhash mod M [offset N]` — hash a register into a small
    /// modular bucket. `sreg` is `Some(NFT_REG_2)` for jhash (the
    /// preceding HashKeyPayload load fills that register) and `None`
    /// for symhash (no key, the kernel computes a packet-symmetric
    /// hash). `len` is the number of source bytes (jhash only;
    /// upstream omits NFTA_HASH_LEN for symhash). `hash_type` is
    /// NFT_HASH_JENKINS=0 or NFT_HASH_SYM=1.
    Hash { sreg: Option<u32>, len: u32, modulus: u32, seed: u32, has_seed: bool, offset: u32, hash_type: u32 },
    /// Payload load that feeds a jhash. Identical wire form to
    /// `Expr::Payload` except DREG is hard-coded to NFT_REG_2 — that
    /// is the slot upstream nft picks when the next expression is
    /// the `hash` (jhash) consumer, and the surrounding tests are
    /// byte-sensitive. For concat keys (`jhash a . b mod N`) the
    /// caller bumps `dreg` by netlink_register_space(prev_len_bits)
    /// for each subsequent field, so the second key lands in
    /// NFT_REG_3 etc. For single-field jhash, `dreg` is left at the
    /// default NFT_REG_2 by the parser.
    HashKeyPayload { base: u32, offset: u32, len: u32, dreg: u32 },
    /// `dup to <addr> [device "<dev>"]` — copy the packet to another
    /// destination (used for taps / mirroring). When `device` is
    /// omitted the kernel routes the copy to the gateway. `addr` is
    /// the raw 4-byte (IPv4) or 16-byte (IPv6) destination; `dev` is
    /// the interface index to inject the copy on. The compiler emits
    /// preceding immediates that load addr into NFT_REG_1 and (when
    /// present) dev into NFT_REG_2, then references both via SREG_*.
    Dup { addr: Vec<u8>, dev: Option<u32> },
    /// `fwd to "<dev>"` — netdev-family only: forward the packet to
    /// the named interface. Like `Dup` we lower the device index into
    /// NFT_REG_1 via a preceding immediate. L3 forwarding (with addr
    /// + NFPROTO) is not yet wired through the parser.
    Fwd { dev: u32 },
    /// `tproxy [ip|ip6] to [<addr>][:<port>]` — transparent proxy
    /// redirect. The destination address is left in NFT_REG_1 (only
    /// when present), the destination port in NFT_REG_2 if both are
    /// given, otherwise NFT_REG_1. `family` carries `NFPROTO_IPV4` /
    /// `NFPROTO_IPV6` when the user (or chain context) has nailed it
    /// down, or `NFPROTO_UNSPEC` for a bare `tproxy to :PORT` in an
    /// inet chain — the kernel matches on either L3 in that case.
    /// `addr` is 0/4/16 bytes; `has_addr` and `has_port` flag which
    /// halves were given so the encoder can omit registers the kernel
    /// would otherwise reject as unset.
    Tproxy { family: u32, addr: Vec<u8>, port: u16, has_addr: bool, has_port: bool },
    /// `synproxy mss <n> wscale <n> [timestamp] [sack-perm]` — install
    /// the kernel's SYN-flood mitigation handler on this rule. `flags`
    /// is the OR of `NF_SYNPROXY_OPT_*` bits; MSS / WSCALE are always
    /// present (the parser fills in zeros when omitted).
    Synproxy { mss: u16, wscale: u8, flags: u32 },
    /// Standalone immediate: load `data` into register `dreg`. The
    /// existing immediate path is folded into NAT / DUP / FWD / TPROXY
    /// arms; pf-syntax scrub statements need a free-standing form so
    /// `ip frag-off set 0` can preload reg 1 before the PayloadSet
    /// store.
    Immediate { dreg: u32, data: Vec<u8> },
    /// Read-side payload load with an explicit destination register.
    /// `Expr::Payload` hard-codes NFT_REG32_00 because all of its
    /// existing call sites then feed `cmp`, which reads from the same
    /// 4-byte slot. pf-scrub's min-ttl lowering needs the load target
    /// to be NFT_REG_1 instead so the bitwise/payload-write chain that
    /// follows is byte-identical to upstream nft.
    PayloadLoadReg { dreg: u32, base: u32, offset: u32, len: u32 },
    /// Bitwise mask+xor with explicit register. The existing
    /// `Expr::Bitwise` derives the register from `mask.len()` via
    /// `reg_for_width`; pf-scrub overrides that so the read-modify-write
    /// chain stays anchored on NFT_REG_1.
    BitwiseReg { reg: u32, mask: Vec<u8>, xor: Vec<u8> },
    /// Generic write-side payload. Mirrors `Expr::Payload` but stores
    /// the value already in `sreg` back into the packet at
    /// (`base`, `offset`, `len`). The kernel recomputes the IP header
    /// checksum when `csum_type` is `NFT_PAYLOAD_CSUM_INET` and
    /// `csum_offset` points at the 16-bit checksum field — without
    /// these the host forwards corrupt packets, so the encoder always
    /// emits both for IP-header writes.
    PayloadSet {
        base: u32,
        offset: u32,
        len: u32,
        sreg: u32,
        csum_type: u32,
        csum_offset: u32,
        csum_flags: u32,
    },
    /// Write-side TCP-option store. Used by pf scrub's `max-mss N`
    /// lowering: an Immediate prelude loads the 16-bit MSS (in network
    /// byte order) into reg 1, then this expression substitutes
    /// it into the TCP MSS option (kind=2, intra-option offset=2,
    /// len=2). `op` is `NFT_EXTHDR_OP_TCPOPT`.
    ExthdrSet { op: u32, kind: u8, offset: u32, len: u32, sreg: u32 },
    /// `byteorder` expression. Swaps a register's value between host
    /// and network byte order in place. pf scrub `random-id` lowers
    /// to `numgen random mod 65536` (which deposits a host-order u32
    /// in NFT_REG_1) followed by `byteorder hton(reg 1, 4, 4)` so the
    /// IP id field receives big-endian bytes.
    Byteorder { sreg: u32, dreg: u32, op: u32, len: u32, size: u32 },
    /// `range eq reg X LO HI` — kernel `range` expression. Used by
    /// pf `hours { N-N }` time-of-day match: the preceding meta+byteorder
    /// chain leaves an NBO u32 in `sreg`, then this expression checks
    /// that it falls inside [`from`, `to`] (inclusive). `op` is
    /// `NFT_RANGE_EQ` or `NFT_RANGE_NEQ`. `from`/`to` are raw bytes
    /// (caller-side big-endian for hour seconds-since-midnight).
    Range { sreg: u32, op: u32, from: Vec<u8>, to: Vec<u8> },
    /// `fib FLAGS RESULT => DREG` — kernel `fib` expression. pf
    /// `antispoof for <iface>` lowers to flags=`F_SADDR|F_IIF`,
    /// result=`OIF`; the next cmp checks the loaded oif index against
    /// 0 (== "no route back through this iface").
    Fib { flags: u32, result: u32, dreg: u32 },
    /// `queue [num N | num L-H] [flags F]` (literal form) and
    /// `queue [flags F] to <hash|map-lookup>` (dynamic form). The
    /// kernel `queue` expression has two mutually-exclusive shapes:
    /// either NUM/TOTAL are set (literal), or SREG_QNUM points to a
    /// register loaded by a preceding jhash / symhash / map lookup
    /// (dynamic). `has_sreg` toggles between the two when emitting
    /// the netlink message; `num`/`total` are zero in the dynamic
    /// case and `sreg_qnum` is zero in the literal case.
    /// `flags` is `NFT_QUEUE_FLAG_BYPASS|NFT_QUEUE_FLAG_CPU_FANOUT`.
    Queue { num: u16, total: u16, flags: u16, has_sreg: bool, sreg_qnum: u32 },
    /// `reject with <kind>` — extension of bare `Expr::Reject`. pf
    /// `block return-rst` -> RST (type=NFT_REJECT_TCP_RST), `block
    /// return-icmp` -> port-unreachable (type=NFT_REJECT_ICMP_UNREACH,
    /// code=ICMP_PORT_UNREACH). The encoder always emits NFTA_REJECT_TYPE
    /// and emits NFTA_REJECT_ICMP_CODE only for the ICMP_UNREACH /
    /// ICMPX_UNREACH variants (the kernel ignores the code field for
    /// TCP_RST so omitting it keeps the wire identical to upstream nft).
    RejectWith { reject_type: u32, code: u8, has_code: bool },
    /// Placeholder for nft expressions that are syntactically valid but
    /// not yet implemented in stormwall (ipsec, osf, ip option, sctp
    /// chunk, etc.). Recognised during parsing so the enclosing rule is
    /// treated as non-empty; produces no netlink output in compile_expr.
    Unimplemented,
    /// Like `Verdict` but carries an NFTA_CHAIN_ID for in-batch
    /// resolution of anonymous chain bindings (`jump { ... }`).
    VerdictBinding { code: i32, chain: String, chain_id: u32 },
}

#[derive(Debug, Clone)]
pub struct Command {
    pub op: CmdOp,
    pub obj: CmdObj,
    pub family: u8,
    pub table: String,
    pub chain: String,
    pub set_name: String,
    pub new_name: String,
    pub handle: u64,
    pub has_handle: bool,
    pub rule_index: i32,         // 0-based position within chain for `index N`
    pub has_rule_index: bool,
    pub comment: String,
    pub has_comment: bool,
    pub chain_spec: ChainSpec,
    pub table_spec: TableSpec,
    pub set_spec: SetSpec,
    pub obj_spec: ObjSpec,
    /// Flowtable declaration body — populated when `obj == Flowtable`.
    /// Carries hook/priority/devices/flags for the `add flowtable …`
    /// command; ignored for any other object kind.
    pub flow_spec: FlowtableSpec,
    pub exprs: Vec<Expr>,
    // Each element is (key, optional-range-end). A range `a-b` in the
    // source serialises as (a, Some(b)); a bare key is (a, None). The
    // encoder emits two records per range (start without flag, end+1
    // with NFT_SET_ELEM_INTERVAL_END) so interval-flagged sets get the
    // kernel encoding the manpage documents.
    pub elements: Vec<(Vec<u8>, Option<Vec<u8>>)>,
    /// For verdict-map element blocks: per-element (code, chain) pairs
    /// parallel to `elements`. Empty when the set isn't a vmap. Chain
    /// is empty for accept/drop/return/continue verdicts.
    pub element_verdicts: Vec<(i32, String)>,
    /// For data-value maps (`type ipv4_addr : ipv4_addr` etc.):
    /// per-element data-value bytes parallel to `elements`. Each
    /// Option is None for a keyed-only element; Some(bytes) for
    /// a mapping entry. Empty vec when the set is plain (no values).
    pub element_datas: Vec<Option<Vec<u8>>>,
    /// Per-element timeout in milliseconds, parallel to `elements`.
    /// Source `add element ip t s { 1.2.3.4 timeout 10s }` produces
    /// a 10000 ms entry; bare elements get 0 (no override). The
    /// encoder writes NFTA_SET_ELEM_TIMEOUT only for non-zero values.
    pub element_timeouts: Vec<u64>,
    /// Per-element comment string, parallel to `elements`.
    /// Source `add element ip t s { 1.2.3.4 comment "host" }` stores
    /// Some("host") at the matching index; bare elements get None.
    /// The encoder writes NFTA_SET_ELEM_USERDATA only when Some.
    pub element_comments: Vec<Option<String>>,
    /// Per-element object reference name parallel to `elements`.
    /// Used for object-reference maps (`type ipv4_addr : counter`):
    /// `add element m { 1 : c1 }` stores Some("c1") here so the
    /// encoder can send NFTA_SET_ELEM_OBJREF instead of DATA.
    /// Plain (non-objref) elements get None.
    pub element_objrefs: Vec<Option<String>>,
}

impl Default for Command {
    fn default() -> Self {
        Command {
            op: CmdOp::List, obj: CmdObj::Ruleset, family: NFPROTO_IPV4,
            table: String::new(), chain: String::new(), set_name: String::new(),
            new_name: String::new(), handle: 0, has_handle: false,
            rule_index: -1, has_rule_index: false,
            comment: String::new(), has_comment: false,
            chain_spec: ChainSpec::default(), table_spec: TableSpec::default(),
            set_spec: SetSpec::default(), obj_spec: ObjSpec::default(),
            flow_spec: FlowtableSpec::default(),
            exprs: Vec::new(), elements: Vec::new(),
            element_verdicts: Vec::new(), element_datas: Vec::new(),
            element_timeouts: Vec::new(), element_comments: Vec::new(),
            element_objrefs: Vec::new(),
        }
    }
}

// ── Tokenizer ───────────────────────────────────────────────────

fn tokenize(input: &str) -> Result<Vec<String>, String> {
    let mut tokens = Vec::new();
    let mut chars = input.chars().peekable();
    let mut brace_depth: i32 = 0;

    while let Some(&c) = chars.peek() {
        // Newline always acts as a statement terminator. This matches
        // nft(8) syntax inside chain bodies (rules separated by `;`
        // OR newline) and between top-level commands. List parsers
        // (set element enumerations etc.) skip stray `;` so emitting
        // one at every newline depth is safe.
        if c == '\n' {
            chars.next();
            if tokens.last().map_or(true, |t| t != ";") {
                tokens.push(";".into());
            }
            continue;
        }
        if c.is_whitespace() { chars.next(); continue; }
        if c == '#' { while chars.peek().map_or(false, |&c| c != '\n') { chars.next(); } continue; }

        // Single-char tokens
        if matches!(c, '{' | '}' | '(' | ')' | ';' | ',') {
            if c == '{' { brace_depth += 1; }
            if c == '}' { brace_depth = brace_depth.saturating_sub(1); }
            tokens.push(c.to_string()); chars.next(); continue;
        }

        // Operators
        if c == '!' { chars.next();
            if chars.peek() == Some(&'=') { chars.next(); tokens.push("!=".into()); }
            else { tokens.push("!".into()); }
            continue;
        }
        if c == '=' { chars.next();
            if chars.peek() == Some(&'=') { chars.next(); tokens.push("==".into()); }
            else { tokens.push("=".into()); }
            continue;
        }
        if c == '<' { chars.next();
            if chars.peek() == Some(&'=') { chars.next(); tokens.push("<=".into()); }
            else { tokens.push("<".into()); }
            continue;
        }
        if c == '>' { chars.next();
            if chars.peek() == Some(&'=') { chars.next(); tokens.push(">=".into()); }
            else { tokens.push(">".into()); }
            continue;
        }

        // Range dash between quoted strings, e.g. `meta hour "01:00"-"04:00"`.
        // The unquoted form (`01:00 - 04:00` or `01:00-04:00`) is handled by
        // the dash absorption rule inside the word loop, but a `"` doesn't
        // trigger that path because the preceding token already terminated.
        // Detect `-"` immediately after a quoted token and emit `-` solo.
        if c == '-' {
            let prev_quoted = tokens.last().map_or(false, |t| t.starts_with('"') && t.ends_with('"'));
            let next_is_quote = chars.clone().nth(1) == Some('"');
            if prev_quoted && next_is_quote {
                tokens.push("-".into());
                chars.next();
                continue;
            }
        }

        // Quoted string
        if c == '"' {
            chars.next();
            let mut s = String::new();
            let mut closed = false;
            while let Some(&ch) = chars.peek() {
                if ch == '"' { chars.next(); closed = true; break; }
                if ch == '\\' { chars.next(); if let Some(&esc) = chars.peek() { s.push(esc); chars.next(); } }
                else { s.push(ch); chars.next(); }
            }
            if !closed {
                return Err("syntax error, unexpected end of file".into());
            }
            tokens.push(format!("\"{}\"", s));
            continue;
        }

        // Words, numbers, addresses
        let mut word = String::new();
        while let Some(&ch) = chars.peek() {
            if ch.is_whitespace() || matches!(ch, '{' | '}' | '(' | ')' | ';' | ',' | '!' | '=' | '<' | '>') { break; }
            // Colon handling: `:` is a token separator (used in map
            // declarations like `type inet_service:verdict`) UNLESS
            // it's part of an IPv6 address. An IPv6 address token
            // consists only of hex digits, colons, and dots.
            // Pure-decimal words (0-9 only) are NOT treated as IPv6
            // starts — `10080:drop` is a map element, not an address.
            // Require at least one prior colon or hex letter (a-f/A-F)
            // for the colon to be absorbed into the word.
            if ch == ':' {
                let has_hex_letter = word.chars().any(|c| matches!(c, 'a'..='f' | 'A'..='F'));
                let has_prior_colon = word.contains(':');
                let is_ipv6 = (has_hex_letter || has_prior_colon || word.is_empty())
                    && word.chars().all(|c| c.is_ascii_hexdigit() || c == ':' || c == '.');
                if !is_ipv6 {
                    if !word.is_empty() { tokens.push(word.clone()); word.clear(); }
                    tokens.push(":".into());
                    chars.next();
                    continue;
                }
            }
            // Dash handling. Ranges like 10.0.0.20-10.0.0.25 or 1000-2000
            // need the dash to break the token; but hyphenated names like
            // "foo-bar" are identifiers and keep it. Rule: if the current
            // word is a numeric literal or IPv4 address (digits + dots
            // only) AND the next character is a digit, the dash is a
            // range separator.
            if ch == '-' && !word.is_empty() {
                // IPv4 range: left is digits-plus-dots, right starts digit.
                let is_ipv4_like = word.chars().all(|c| c.is_ascii_digit() || c == '.');
                // IPv6 range: left contains `:` and uses only hex+colon+dot
                // (allow embedded ipv4 for ::ffff:a.b.c.d), right starts
                // with a hex digit or `:` (for an abbreviation like `::1`).
                let is_ipv6_like = word.contains(':')
                    && word.chars().all(|c| c.is_ascii_hexdigit() || c == ':' || c == '.');
                if is_ipv4_like || is_ipv6_like {
                    let next_c = chars.clone().skip(1).next().unwrap_or(' ');
                    let right_starts_addr = if is_ipv4_like {
                        next_c.is_ascii_digit()
                    } else {
                        next_c.is_ascii_hexdigit() || next_c == ':'
                    };
                    if right_starts_addr {
                        tokens.push(word.clone());
                        word.clear();
                        tokens.push("-".into());
                        chars.next();
                        continue;
                    }
                }
            }
            word.push(ch); chars.next();
        }
        if !word.is_empty() { tokens.push(word); }
    }
    if brace_depth > 0 {
        return Err("syntax error, unexpected end of file".into());
    }
    Ok(tokens)
}

// ── Parser ──────────────────────────────────────────────────────

struct Parser {
    tokens: Vec<String>,
    pos: usize,
    /// When true, integer literals from `parse_value` are emitted in
    /// host byte order rather than network byte order. The kernel
    /// stores meta/ct register values in the CPU's native order, so a
    /// `meta mark 0x10` rule needs the comparison-side value to match
    /// — otherwise nft monitor decodes our `0x10` as `0x10000000` on
    /// a little-endian box. Set by callers right before invoking
    /// parse_cmp_and_value, cleared after.
    host_order_value: bool,
    /// When true, symbolic names like `echo-request` resolve via the
    /// ICMPv6 table (echo-request=128) rather than the ICMPv4 one
    /// (echo-request=8). Set by the icmpv6 token handler before
    /// delegating to parse_cmp_and_value, cleared after.
    icmpv6_context: bool,
    /// Deferred validation errors found during expression parsing
    /// (which can't return Result). Checked after each command.
    deferred_errors: Vec<String>,
    /// Extra commands generated by `parse_table_block` when the inline
    /// `add table ... { chain/set/counter/... }` form contains child
    /// objects. Drained by the outer `parse()` loop after each command.
    pending_commands: Vec<Command>,
    /// Anonymous chain commands generated by `jump { ... }` / `goto { ... }`
    /// bindings. Drained by the outer parse loop before the parent rule is
    /// pushed so the kernel sees the chain before the rule that jumps to it.
    pending_anon_chains: Vec<Command>,
    /// Monotonic counter for generating unique anonymous chain names
    /// (`__chain0`, `__chain1`, …) within a parser session.
    anon_chain_counter: u32,
}

impl Parser {
    fn new(tokens: Vec<String>) -> Self {
        Parser { tokens, pos: 0, host_order_value: false, icmpv6_context: false, deferred_errors: Vec::new(), pending_commands: Vec::new(), pending_anon_chains: Vec::new(), anon_chain_counter: 0 }
    }
    fn peek(&self) -> &str { self.tokens.get(self.pos).map(|s| s.as_str()).unwrap_or("") }
    fn peek_offset(&self, n: usize) -> &str { self.tokens.get(self.pos + n).map(|s| s.as_str()).unwrap_or("") }
    fn advance(&mut self) -> &str {
        let t = self.tokens.get(self.pos).map(|s| s.as_str()).unwrap_or("");
        self.pos += 1; t
    }
    fn at_end(&self) -> bool { self.pos >= self.tokens.len() }
    fn matches(&mut self, s: &str) -> bool {
        if self.peek() == s { self.advance(); true } else { false }
    }
    /// Insert a synthetic token at the current position so that the
    /// next `advance()` returns it. Used to inject an implicit `add`
    /// verb when a bare object keyword appears at the top level in
    /// file-mode.
    fn inject(&mut self, s: &str) {
        self.tokens.insert(self.pos, s.to_string());
    }
    /// Set a comment on `cmd`, enforcing the 128-byte kernel limit
    /// and rejecting duplicates.
    fn set_comment(&mut self, cmd: &mut Command, c: String) {
        if cmd.has_comment {
            self.deferred_errors.push(
                "duplicated comment in object".to_string());
            return;
        }
        if c.len() > 128 {
            self.deferred_errors.push(
                "comment too long, 128 characters maximum allowed".to_string());
        }
        cmd.comment = c;
        cmd.has_comment = true;
    }

    fn is_family(s: &str) -> bool {
        matches!(s, "ip" | "ip6" | "inet" | "arp" | "bridge" | "netdev")
    }

    fn parse_family_default_ip(&mut self) -> u8 {
        if Self::is_family(self.peek()) { family_from_str(self.advance()).unwrap_or(NFPROTO_IPV4) }
        else { NFPROTO_IPV4 }
    }

    fn parse_family_default_unspec(&mut self) -> u8 {
        if Self::is_family(self.peek()) { family_from_str(self.advance()).unwrap_or(NFPROTO_UNSPEC) }
        else { NFPROTO_UNSPEC }
    }

    fn parse_name(&mut self) -> String {
        let t = self.advance();
        if t.starts_with('"') && t.ends_with('"') { t[1..t.len()-1].to_string() }
        else { t.to_string() }
    }

    /// Pad a byte vector up to 4-byte alignment (concat key slot width).
    fn pad4(mut v: Vec<u8>) -> Vec<u8> {
        let r = v.len() % 4;
        if r != 0 { v.resize(v.len() + 4 - r, 0); }
        v
    }

    /// Parse a single element value token (no range, no concat).
    /// Tries IPv6, IPv4, hex literal, then decimal integer.
    /// `width` is a hint for integer encoding: 1=u8, 2=u16, 4=u32.
    fn parse_one_element_w(tok: &str, width: u32) -> Vec<u8> {
        let s = tok.trim_matches('"');
        if let Some(a) = Self::parse_ipv6(s) { return a.to_vec(); }
        if let Some(a) = Self::parse_ipv4(s) { return a.to_vec(); }
        if let Some(mac) = parse_mac(s) { return mac.to_vec(); }
        // Hex like 0x123434
        let num: Option<u32> = if s.starts_with("0x") || s.starts_with("0X") {
            u32::from_str_radix(&s[2..], 16).ok()
        } else {
            s.parse::<u32>().ok()
        };
        if let Some(n) = num {
            return match width {
                1 => vec![n as u8],
                2 => (n as u16).to_be_bytes().to_vec(),
                _ => n.to_be_bytes().to_vec(),
            };
        }
        // Fallback: NUL-terminated string (ifname etc.)
        let mut v = s.as_bytes().to_vec();
        v.push(0);
        v
    }

    /// Convenience wrapper without width hint (default to u32).
    fn parse_one_element(tok: &str) -> Vec<u8> {
        Self::parse_one_element_w(tok, 4)
    }

    fn parse_ipv4(s: &str) -> Option<[u8; 4]> {
        s.parse::<Ipv4Addr>().ok().map(|a| a.octets())
    }

    /// Consume any `random` / `fully-random` / `persistent` modifiers
    /// trailing a `snat`, `dnat`, or `masquerade` statement and return
    /// their bitwise-OR encoded as NF_NAT_RANGE_*. Order is not
    /// significant; multiple modifiers may stack.
    ///
    /// `prefix` is recognised but emits no flag bit on this kernel
    /// (NF_NAT_RANGE_NETMAP is the post-5.5 spelling and is unused
    /// in the bare-`prefix` form upstream nft accepts on aarch64
    /// 6.1). We swallow the keyword so the parser doesn't error out.
    fn parse_nat_mod_flags(&mut self) -> u32 {
        let mut flags = 0u32;
        loop {
            match self.peek() {
                "random" => { self.advance(); flags |= NF_NAT_RANGE_PROTO_RANDOM; }
                "fully-random" => { self.advance(); flags |= NF_NAT_RANGE_PROTO_RANDOM_FULLY; }
                "persistent" => { self.advance(); flags |= NF_NAT_RANGE_PERSISTENT; }
                "prefix" => { self.advance(); /* deferred — no kernel flag bit */ }
                _ => break,
            }
        }
        flags
    }

    /// Parse an IPv6 address literal into 16 bytes. Accepts the usual
    /// forms: full (`2001:db8:1:2:3:4:5:6`), abbreviated (`fe80::1`,
    /// `::1`, `::`), and IPv4-mapped (`::ffff:1.2.3.4`). Returns None
    /// for malformed input — callers fall back to other element
    /// parsing paths (string key etc.) on None.
    fn parse_ipv6(s: &str) -> Option<[u8; 16]> {
        s.parse::<std::net::Ipv6Addr>().ok().map(|a| a.octets())
    }

    fn parse_priority(&mut self, family: u8) -> Result<i32, String> {
        self.parse_priority_ctx(family, "", "")
    }

    /// Priority parsing with the chain type and hook available so
    /// we can reject nat-specific names (`dstnat`, `srcnat`, `out`)
    /// when the enclosing chain is a plain `filter` chain — what
    /// upstream nft does and what chains/0023..0029 check.
    fn parse_priority_ctx(&mut self, family: u8, chain_type: &str, hook: &str) -> Result<i32, String> {
        // A priority expression is one of:
        //   <int>                  e.g. 10, -10
        //   <name>                 e.g. filter, dstnat
        //   <name> <+|-> <int>     e.g. filter + 10
        //   "<name> <+|-> <int>"   quoted (coming from a variable)
        // Consume at most those four tokens and stop at the next
        // statement keyword so we don't swallow `policy ...`, `device
        // ...`, or the chain-block terminator.
        let mut prio_str = String::new();
        let stop = |t: &str| {
            matches!(t, "" | ";" | "}" | "policy" | "device" | "hook" | "type" | "flags" | "comment")
        };
        // First token: number, name, or a quoted string that itself
        // contains the whole expression.
        if stop(self.peek()) { return Ok(0); }
        let first = self.advance().to_string();
        // Strip surrounding quotes the tokenizer preserved (for
        // `define for = "filter - 100"` style values).
        let first_unquoted = if first.starts_with('"') && first.ends_with('"') && first.len() >= 2 {
            first[1..first.len() - 1].to_string()
        } else {
            first.clone()
        };
        prio_str.push_str(&first_unquoted);
        // Optional `+ N` / `- N` tail.
        if matches!(self.peek(), "+" | "-") && !stop(self.peek_offset(1)) {
            let sign = self.advance().to_string();
            let num = self.advance().to_string();
            prio_str.push(' ');
            prio_str.push_str(&sign);
            prio_str.push(' ');
            prio_str.push_str(&num);
        } else {
            // Handle combined signed-number tokens like `-11` or `+11`
            // (tokenizer absorbs the sign into the number when the sign
            // immediately precedes digits with no intervening whitespace).
            // e.g. `priority raw -11` → tokens: `raw`, `-11`
            let next = self.peek();
            let is_signed_num = (next.starts_with('+') || next.starts_with('-'))
                && next.len() > 1
                && next[1..].chars().all(|c| c.is_ascii_digit())
                && !next[1..].is_empty();
            if is_signed_num && !stop(next) {
                let combined = self.advance().to_string();
                prio_str.push(' ');
                prio_str.push_str(&combined);
            }
        }
        // Extract the bare name (before any `+`/`-` offset) for
        // validating it against the chain context.
        let prio_name = prio_str.split_whitespace().next().unwrap_or("");
        let prio_val = crate::netlink::priority_from_str_opt(&prio_str, family)
            .ok_or_else(|| format!("unknown priority '{}'", prio_str.trim()))?;

        // Priority name validity depends on (family, chain_type, hook).
        // Upstream nft rejects mismatches at parse time — we mirror
        // the same table here.
        if !chain_type.is_empty() && !hook.is_empty() {
            let is_bridge = family == crate::netlink::NFPROTO_BRIDGE;
            let is_arp = family == crate::netlink::NFPROTO_ARP;
            let is_netdev = family == crate::netlink::NFPROTO_NETDEV;
            let hook_ok = |allowed: &[&str]| allowed.iter().any(|h| *h == hook);
            // arp and netdev only accept `filter` (and bare integers),
            // no named priorities beyond that.
            if (is_arp || is_netdev)
                && matches!(prio_name, "raw" | "mangle" | "dstnat" | "security" | "srcnat" | "out")
            {
                return Err(format!(
                    "priority '{}' is not valid in {} family",
                    prio_name,
                    if is_arp { "arp" } else { "netdev" }));
            }
            // `dstnat` binds the prerouting (or ip6 output) hook.
            if prio_name == "dstnat" {
                let allowed: &[&str] = if family == crate::netlink::NFPROTO_IPV6 {
                    &["prerouting", "output"]
                } else {
                    &["prerouting"]
                };
                if !hook_ok(allowed) {
                    return Err(format!(
                        "priority 'dstnat' is only valid in the prerouting hook"));
                }
            }
            // `srcnat` binds postrouting.
            if prio_name == "srcnat" && !hook_ok(&["postrouting"]) {
                return Err(format!(
                    "priority 'srcnat' is only valid in the postrouting hook"));
            }
            // `out` is bridge-only and hook output only.
            if prio_name == "out" {
                if !is_bridge {
                    return Err(format!(
                        "priority 'out' is only valid in the bridge family"));
                }
                if !hook_ok(&["output"]) {
                    return Err(format!(
                        "priority 'out' is only valid in the output hook"));
                }
            }
        }

        Ok(prio_val)
    }

    fn parse_cmp_op(&mut self) -> u32 {
        match self.peek() {
            "==" | "=" => { self.advance(); NFT_CMP_EQ }
            "!=" => { self.advance(); NFT_CMP_NEQ }
            _ => NFT_CMP_EQ,
        }
    }

    fn parse_value(&mut self, data_len: usize) -> Vec<u8> {
        let tok = self.advance().to_string();

        // TCP flag names — `tcp flags syn,ack accept`. The flags
        // field is one byte at TCP offset 13; the rule wants an OR
        // of the named bits compared for equality. Accumulate
        // comma-separated names, fall through to other parsers if
        // the token isn't a flag name.
        if data_len == 1 {
            if let Some(b) = tcp_flag_byte(&tok) {
                let mut v = b;
                while self.peek() == "," {
                    self.advance();
                    let next = self.peek().to_string();
                    if let Some(extra) = tcp_flag_byte(&next) {
                        v |= extra;
                        self.advance();
                    } else {
                        break;
                    }
                }
                return vec![v];
            }
        }

        // CT state bitmask - return as native endian bytes
        if matches!(tok.as_str(), "new" | "established" | "related" | "untracked" | "invalid") {
            let mut state = ct_state_val(&tok);
            while self.peek() == "," {
                self.advance();
                state |= ct_state_val(self.advance());
            }
            // For bitmask comparisons, kernel needs: bitwise(reg & mask) + cmp(result != 0)
            // We return the bitmask value and let parse_cmp_and_value handle the special case
            return state.to_ne_bytes().to_vec();
        }

        // Protocol name as value
        if let Some(proto) = proto_num(&tok) {
            return vec![proto];
        }

        // ICMP type names — `icmp type echo-request` arrives here as
        // tok="echo-request" with data_len=1. Without this lookup the
        // string falls through to the integer-parse path, fails, and
        // we end up emitting the raw bytes "echo-request\0" — a
        // 12-byte cmp that overflows the 1-byte register.
        if data_len == 1 {
            if self.icmpv6_context {
                if let Some(t) = icmpv6_type_num(&tok) { return vec![t]; }
            }
            if let Some(t) = icmp_type_num(&tok) { return vec![t]; }
        }

        // Ethernet MAC (6-byte data, colon-separated hex). Tokenizer
        // keeps `aa:bb:cc:dd:ee:ff` as one token because `:` is
        // continuation. parse_mac decodes it; on miss we fall through
        // to the other parsers.
        if data_len == 6 {
            if let Some(mac) = parse_mac(&tok) {
                return mac.to_vec();
            }
        }

        // Ethernet protocol type names ("ip", "ip6", "arp", "vlan",
        // ...) → 2-byte big-endian values. Without this lookup
        // `ether type ip accept` falls through to the string fallback
        // and stormwall emits the literal bytes "ip\0\0" which the
        // kernel interprets as a wholly different ethertype.
        if data_len == 2 {
            if let Some(et) = ether_type_num(&tok) {
                return et.to_be_bytes().to_vec();
            }
        }

        // IPv6 (16-byte data) — try first because parse_ipv4 would
        // reject `fd99::2` cleanly anyway, but explicit ordering means
        // an IPv4 literal like `1.2.3.4` doesn't accidentally match an
        // IPv6 parser that's overly permissive.
        if data_len == 16 {
            if let Some(slash) = tok.find('/') {
                if let Some(addr) = Self::parse_ipv6(&tok[..slash]) {
                    return addr.to_vec();
                }
            }
            if let Some(addr) = Self::parse_ipv6(&tok) {
                return addr.to_vec();
            }
        }

        // IPv4 with optional /prefix
        if let Some(slash) = tok.find('/') {
            if let Some(addr) = Self::parse_ipv4(&tok[..slash]) {
                return addr.to_vec(); // CIDR handled by caller
            }
        }
        if let Some(addr) = Self::parse_ipv4(&tok) {
            return addr.to_vec();
        }

        // Number (port, mark, etc). Accept hex (0x..), octal (0o.. / 0..),
        // and decimal. meta mark / ct mark routinely use hex.
        let parsed: Option<u64> = if let Some(hex) = tok.strip_prefix("0x").or_else(|| tok.strip_prefix("0X")) {
            u64::from_str_radix(hex, 16).ok()
        } else if let Some(oct) = tok.strip_prefix("0o").or_else(|| tok.strip_prefix("0O")) {
            u64::from_str_radix(oct, 8).ok()
        } else {
            tok.parse::<u64>().ok()
        };
        if let Some(n) = parsed {
            if data_len == 1 { return vec![n as u8]; }
            // Reject out-of-range values for 2-byte fields (ports)
            if data_len == 2 && n > 65535 {
                self.deferred_errors.push(format!("Service out of range"));
            }
            if self.host_order_value {
                if data_len == 2 { return (n as u16).to_ne_bytes().to_vec(); }
                if data_len == 8 { return (n as u64).to_ne_bytes().to_vec(); }
                return (n as u32).to_ne_bytes().to_vec();
            }
            if data_len == 2 { return (n as u16).to_be_bytes().to_vec(); }
            if data_len == 8 { return (n as u64).to_be_bytes().to_vec(); }
            return (n as u32).to_be_bytes().to_vec();
        }

        // String value (interface name). Strip the surrounding quotes the
        // tokenizer preserved for unambiguous lookahead; the kernel wants
        // the raw bytes, not `"lo"`.
        let raw = if tok.starts_with('"') && tok.ends_with('"') && tok.len() >= 2 {
            &tok[1..tok.len() - 1]
        } else {
            tok.as_str()
        };
        let mut v = raw.as_bytes().to_vec();
        v.push(0);
        while v.len() < data_len { v.push(0); }
        v
    }

    /// Parse the key half of a dynset block: the `ip saddr`,
    /// `ip6 saddr`, or `meta <key>` payload load that the dynset
    /// expression's NFTA_DYNSET_SREG_KEY will read from. Pushes the
    /// load expression(s) onto cmd.exprs and returns the key width
    /// in bytes.
    fn parse_dynset_key(&mut self, cmd: &mut Command) -> usize {
        let head = self.peek().to_string();
        if head == "ip" {
            self.advance();
            let field = self.advance().to_string();
            let (base, offset, len) = match field.as_str() {
                "saddr" => (NFT_PAYLOAD_NETWORK_HEADER, 12u32, 4u32),
                "daddr" => (NFT_PAYLOAD_NETWORK_HEADER, 16, 4),
                _ => return 4,
            };
            cmd.exprs.push(Expr::Payload { base, offset, len, protocol: 0 });
            len as usize
        } else if head == "ip6" {
            self.advance();
            let field = self.advance().to_string();
            let (base, offset, len) = match field.as_str() {
                "saddr"    => (NFT_PAYLOAD_NETWORK_HEADER, 8u32, 16u32),
                "daddr"    => (NFT_PAYLOAD_NETWORK_HEADER, 24, 16),
                "nexthdr"  => (NFT_PAYLOAD_NETWORK_HEADER, 6, 1),
                "hoplimit" => (NFT_PAYLOAD_NETWORK_HEADER, 7, 1),
                "length"   => (NFT_PAYLOAD_NETWORK_HEADER, 4, 2),
                "flowlabel" => (NFT_PAYLOAD_NETWORK_HEADER, 0, 4),
                _ => return 16,
            };
            cmd.exprs.push(Expr::Payload { base, offset, len, protocol: 0 });
            len as usize
        } else if head == "meta" {
            self.advance();
            let key = self.advance().to_string();
            let (k, w) = match key.as_str() {
                "mark"     => (NFT_META_MARK, 4),
                "iif"      => (NFT_META_IIF, 4),
                "oif"      => (NFT_META_OIF, 4),
                "iifname"  => (NFT_META_IIFNAME, 16),
                "oifname"  => (NFT_META_OIFNAME, 16),
                "skuid"    => (NFT_META_SKUID, 4),
                "skgid"    => (NFT_META_SKGID, 4),
                "cpu"      => (NFT_META_CPU, 4),
                "cgroup"   => (NFT_META_CGROUP, 4),
                _          => (NFT_META_MARK, 4),
            };
            cmd.exprs.push(Expr::Meta { key: k, width: w });
            w
        } else {
            // Unknown key form; advance one token to make progress
            // and default to a 4-byte key — the kernel will reject
            // the resulting rule cleanly so the user gets an error.
            self.advance();
            4
        }
    }

    /// Parse the right-hand side of `meta KEY set <expr>`.
    ///
    /// Recognised forms (mirror upstream nft v1.0.x):
    ///   numgen inc    mod M [offset N]
    ///   numgen random mod M [offset N]
    ///   jhash <key-expr> mod M [seed S] [offset N]
    ///   symhash mod M [offset N]
    ///
    /// The producing expression always writes into NFT_REG_1; the
    /// trailing Expr::MetaSet that the caller pushes after this
    /// helper reads back from the same register.
    fn parse_meta_set_source(&mut self, cmd: &mut Command) {
        let head = self.peek().to_string();
        if head == "numgen" {
            self.advance();
            let kind = self.advance().to_string();
            let ng_type = match kind.as_str() {
                "inc"    => NFT_NG_INCREMENTAL,
                "random" => NFT_NG_RANDOM,
                _        => NFT_NG_INCREMENTAL,
            };
            self.matches("mod");
            let modulus: u32 = self.advance().parse().unwrap_or(0);
            let mut offset: u32 = 0;
            if self.peek() == "offset" {
                self.advance();
                offset = self.advance().parse().unwrap_or(0);
            }
            cmd.exprs.push(Expr::Numgen { ng_type, modulus, offset });
            return;
        }
        if head == "symhash" {
            self.advance();
            self.matches("mod");
            let modulus: u32 = self.advance().parse().unwrap_or(0);
            let mut offset: u32 = 0;
            if self.peek() == "offset" {
                self.advance();
                offset = self.advance().parse().unwrap_or(0);
            }
            cmd.exprs.push(Expr::Hash {
                sreg: None,
                len: 0,
                modulus,
                seed: 0,
                has_seed: false,
                offset,
                hash_type: NFT_HASH_SYM,
            });
            return;
        }
        if head == "jhash" {
            self.advance();
            // Key expression. Concatenated keys (`tcp dport . tcp
            // sport`) advance the destination register by
            // netlink_register_space(prev_field_bytes) per field —
            // rounded up to the next 32-bit slot — so 2- and
            // 4-byte fields move dreg by 1 slot, 16-byte fields
            // (ip6 saddr/daddr) move it by 4. SREG points at the
            // first slot.
            let first_len = self.parse_jhash_key(cmd);
            let mut total_len = first_len;
            let mut next_dreg = NFT_REG_2 + ((first_len + 3) / 4);
            while self.peek() == "." {
                self.advance();
                let f = self.parse_jhash_key_at(cmd, next_dreg);
                total_len = total_len.saturating_add(f);
                next_dreg += (f + 3) / 4;
            }
            let len = total_len;
            self.matches("mod");
            let modulus: u32 = self.advance().parse().unwrap_or(0);
            let mut seed: u32 = 0;
            let mut has_seed = false;
            let mut offset: u32 = 0;
            // `seed` and `offset` may appear in either order. Loop
            // until we hit something that isn't one of them.
            loop {
                let next = self.peek().to_string();
                if next == "seed" {
                    self.advance();
                    let v = self.advance().to_string();
                    seed = if let Some(hex) = v.strip_prefix("0x").or_else(|| v.strip_prefix("0X")) {
                        u32::from_str_radix(hex, 16).unwrap_or(0)
                    } else {
                        v.parse().unwrap_or(0)
                    };
                    has_seed = true;
                } else if next == "offset" {
                    self.advance();
                    offset = self.advance().parse().unwrap_or(0);
                } else {
                    break;
                }
            }
            cmd.exprs.push(Expr::Hash {
                sreg: Some(NFT_REG_2),
                len,
                modulus,
                seed,
                has_seed,
                offset,
                hash_type: NFT_HASH_JENKINS,
            });
            return;
        }
        // Unknown source — advance one token to make progress; the
        // caller will still push the trailing MetaSet, which the
        // kernel will reject with an EINVAL the user can act on.
        self.advance();
    }

    /// `meta hour "HH:MM[:SS]"-"HH:MM[:SS]"` (or unquoted forms).
    /// Lowers to `meta load TIME_HOUR -> reg 1 ; byteorder hton ;
    /// range eq reg 1 LO_BE HI_BE` where LO/HI are seconds-of-day
    /// stored as big-endian u32.  The endpoints are interpreted in
    /// the current TZ (env `TZ` via libc localtime_r) and stored as
    /// UTC seconds-of-day so the kernel's UTC clock fires at the
    /// wall-clock window the user typed.  Endpoint precision matches
    /// upstream (HH:MM:SS round-trips, plain integer seconds also
    /// accepted).
    fn parse_meta_hour(&mut self, cmd: &mut Command) {
        let lo_str = self.advance_hour_endpoint();
        // `-` between endpoints is a token of its own (range_dash split
        // for quoted forms; word-loop split for `01:00-04:00`).
        if self.peek() == "-" { self.advance(); }
        let hi_str = self.advance_hour_endpoint();
        let gmtoff = tz_gmtoff_seconds();
        let lo = match parse_hour_endpoint(&lo_str) {
            Some(s) => apply_tz_to_store(s, gmtoff),
            None => { self.deferred_errors.push(format!("meta hour: bad endpoint {}", lo_str)); 0 }
        };
        let hi = match parse_hour_endpoint(&hi_str) {
            Some(s) => apply_tz_to_store(s, gmtoff),
            None => { self.deferred_errors.push(format!("meta hour: bad endpoint {}", hi_str)); 0 }
        };
        cmd.exprs.push(Expr::Meta { key: NFT_META_TIME_HOUR, width: 4 });
        cmd.exprs.push(Expr::Byteorder {
            sreg: NFT_REG_1, dreg: NFT_REG_1,
            op: NFT_BYTEORDER_HTON, len: 4, size: 4,
        });
        cmd.exprs.push(Expr::Range {
            sreg: NFT_REG_1, op: NFT_RANGE_EQ,
            from: lo.to_be_bytes().to_vec(),
            to:   hi.to_be_bytes().to_vec(),
        });
    }

    /// Reassemble a single time-of-day endpoint.  The tokenizer keeps
    /// `"HH:MM"` (quoted) intact, but splits an unquoted `HH:MM` into
    /// `HH`, `:`, `MM` because plain decimal words don't match its
    /// IPv6 pattern.  Glue them back together so parse_hour_endpoint
    /// can accept either form.
    fn advance_hour_endpoint(&mut self) -> String {
        let mut s = self.advance().to_string();
        // Already a complete quoted endpoint or numeric seconds.
        if s.starts_with('"') || s.contains(':') { return s; }
        while self.peek() == ":" {
            self.advance();
            s.push(':');
            let next = self.advance().to_string();
            s.push_str(&next);
        }
        s
    }

    /// Parse the key-loading expression that comes between `jhash`
    /// and `mod`. Returns the byte width of the loaded key (used
    /// for NFTA_HASH_LEN). Supports the single-field payload forms
    /// (`ip saddr`, `ip daddr`, `ip6 saddr`, …). The `dreg` argument
    /// picks the destination register; for the bare single-field
    /// form callers pass NFT_REG_2 (matching upstream nft); for
    /// concat keys the second-and-later calls advance dreg by
    /// netlink_register_space(prev_len_bits) so each subfield
    /// lands in its own register slot.
    fn parse_jhash_key(&mut self, cmd: &mut Command) -> u32 {
        self.parse_jhash_key_at(cmd, NFT_REG_2)
    }

    fn parse_jhash_key_at(&mut self, cmd: &mut Command, dreg: u32) -> u32 {
        let head = self.peek().to_string();
        if head == "ip" {
            self.advance();
            let field = self.advance().to_string();
            let (base, offset, len) = match field.as_str() {
                "saddr" => (NFT_PAYLOAD_NETWORK_HEADER, 12u32, 4u32),
                "daddr" => (NFT_PAYLOAD_NETWORK_HEADER, 16, 4),
                _       => return 0,
            };
            cmd.exprs.push(Expr::HashKeyPayload { base, offset, len, dreg });
            return len;
        }
        if head == "ip6" {
            self.advance();
            let field = self.advance().to_string();
            let (offset, len) = match field.as_str() {
                "saddr" => (8u32, 16u32),
                "daddr" => (24, 16),
                _       => return 0,
            };
            cmd.exprs.push(Expr::HashKeyPayload {
                base: NFT_PAYLOAD_NETWORK_HEADER,
                offset,
                len,
                dreg,
            });
            return len;
        }
        if head == "tcp" || head == "udp" {
            self.advance();
            let field = self.advance().to_string();
            let (offset, len) = match field.as_str() {
                "sport" => (0u32, 2u32),
                "dport" => (2, 2),
                _       => return 0,
            };
            cmd.exprs.push(Expr::HashKeyPayload {
                base: NFT_PAYLOAD_TRANSPORT_HEADER,
                offset,
                len,
                dreg,
            });
            return len;
        }
        // Unknown key form — make progress and let the kernel reject.
        self.advance();
        0
    }

    fn parse_rule_exprs(&mut self, cmd: &mut Command) {
        while !self.at_end() && self.peek() != ";" && self.peek() != "}" {
            let tok = self.peek().to_string();

            // Dynset: `add @s { ip saddr [timeout 10s] }` /
            //         `update @s { ip saddr }`.
            // The `add`/`update` keywords are unambiguous here because a
            // rule body never starts with the bare commands; the outer
            // command parser has already consumed `add rule …`.
            if (tok == "add" || tok == "update") && self.peek_offset(1).starts_with('@') {
                let op = if tok == "add" { NFT_DYNSET_OP_ADD } else { NFT_DYNSET_OP_UPDATE };
                self.advance();
                let set_tok = self.advance().to_string();
                let set_name = set_tok.trim_start_matches('@').to_string();
                self.matches("{");
                let key_width = self.parse_dynset_key(cmd);
                let mut timeout_ms: u64 = 0;
                if self.matches("timeout") {
                    let v = self.advance().to_string();
                    timeout_ms = parse_duration_ms(&v);
                }
                self.matches("}");
                cmd.exprs.push(Expr::Dynset { set_name, op, key_width, timeout_ms, set_id: None });
                continue;
            }

            // Comment
            if tok == "comment" {
                self.advance();
                if !self.at_end() {
                    let c = self.parse_name();
                    self.set_comment(cmd, c);
                }
                continue;
            }

            // ip saddr/daddr/protocol/dscp — inject `meta nfproto ipv4`
            // for inet-family tables. The kernel needs it to route
            // the payload load to the correct header.
            if tok == "ip" {
                self.advance();
                let field = self.advance().to_string();
                // Inject meta nfproto == ipv4 if not already present.
                let inject_nfproto_v4 = || -> Vec<Expr> {
                    vec![
                        Expr::Meta { key: NFT_META_NFPROTO, width: 1 },
                        Expr::Cmp { op: NFT_CMP_EQ, data: vec![2] }, // NFPROTO_IPV4
                    ]
                };
                let has_nfproto = cmd.exprs.windows(2).any(|w| {
                    matches!(&w[0], Expr::Meta { key, .. } if *key == NFT_META_NFPROTO)
                });
                // `ip dscp V` — DSCP occupies the upper 6 bits of the TOS
                // byte (IP header offset 1).  nft encodes this as:
                //   payload load 1 byte @ offset 1  → reg 1
                //   bitwise: reg1 & 0xfc ^ 0        → reg 1
                //   cmp eq reg 1  (V << 2)
                // The user writes the 6-bit codepoint (0-63); the kernel
                // sees it aligned into bits 7:2 of the TOS byte.
                if field == "dscp" {
                    if !has_nfproto { cmd.exprs.extend(inject_nfproto_v4()); }
                    cmd.exprs.push(Expr::Payload { base: NFT_PAYLOAD_NETWORK_HEADER, offset: 1, len: 1, protocol: 0 });
                    cmd.exprs.push(Expr::Bitwise { mask: vec![0xfcu8], xor: vec![0x00u8] });
                    let op = self.parse_cmp_op();
                    let tok_val = self.advance().to_string();
                    let raw: u8 = if let Some(hex) = tok_val.strip_prefix("0x").or_else(|| tok_val.strip_prefix("0X")) {
                        u8::from_str_radix(hex, 16).unwrap_or(0)
                    } else {
                        tok_val.parse::<u8>().unwrap_or(0)
                    };
                    let shifted = (raw << 2) & 0xfc;
                    cmd.exprs.push(Expr::Cmp { op, data: vec![shifted] });
                    continue;
                }
                let (base, offset, len) = match field.as_str() {
                    "saddr" => (NFT_PAYLOAD_NETWORK_HEADER, 12u32, 4u32),
                    "daddr" => (NFT_PAYLOAD_NETWORK_HEADER, 16, 4),
                    "protocol" => (NFT_PAYLOAD_NETWORK_HEADER, 9, 1),
                    "length" => (NFT_PAYLOAD_NETWORK_HEADER, 2, 2),
                    "ttl"    => (NFT_PAYLOAD_NETWORK_HEADER, 8, 1),
                    _ => { continue; }
                };
                if !has_nfproto { cmd.exprs.extend(inject_nfproto_v4()); }
                cmd.exprs.push(Expr::Payload { base, offset, len, protocol: 0 });
                self.parse_cmp_and_value(cmd, len as usize);
                continue;
            }

            // ip6 — inject `meta nfproto ipv6` dependency for fields
            // that share offset space with IPv4 (nexthdr at offset 6,
            // hoplimit at offset 7). saddr/daddr are unambiguous by
            // length (16 bytes), but the kernel still expects the
            // dependency for `inet` family tables.
            if tok == "ip6" {
                self.advance();
                let field = self.advance();
                let (offset, len, needs_nfproto) = match field {
                    "saddr"    => (8u32, 16u32, true),
                    "daddr"    => (24, 16, true),
                    "nexthdr"  => (6, 1, true),
                    "hoplimit" => (7, 1, true),
                    "length"   => (4, 2, true),
                    "flowlabel" => (0, 4, true),
                    _ => { continue; }
                };
                // Inject meta nfproto == ipv6 if not already present.
                if needs_nfproto {
                    let has = cmd.exprs.windows(2).any(|w| {
                        matches!(&w[0], Expr::Meta { key, .. } if *key == NFT_META_NFPROTO)
                    });
                    if !has {
                        cmd.exprs.push(Expr::Meta { key: NFT_META_NFPROTO, width: 1 });
                        cmd.exprs.push(Expr::Cmp { op: NFT_CMP_EQ, data: vec![10] }); // NFPROTO_IPV6
                    }
                }
                cmd.exprs.push(Expr::Payload { base: NFT_PAYLOAD_NETWORK_HEADER, offset, len, protocol: 0 });
                self.parse_cmp_and_value(cmd, len as usize);
                continue;
            }

            // tcp / udp / icmp: real nft injects an implicit
            // `meta l4proto ==` match so the kernel reads the
            // transport header only after it's confirmed the
            // packet is of the expected protocol. Without it
            // the listing decoder can't tell tcp sport apart
            // from udp sport (both are transport offset 0, len
            // 2) and defaults to `tcp` for every case.
            if tok == "tcp" || tok == "udp" || tok == "icmp" || tok == "icmpv6" {
                let proto_name = tok.clone();
                let proto_num: u8 = match proto_name.as_str() {
                    "tcp" => 6, "udp" => 17, "icmp" => 1, "icmpv6" => 58,
                    _ => unreachable!(),
                };
                self.advance();
                let field = self.advance().to_string();
                let (offset, len) = match (proto_name.as_str(), field.as_str()) {
                    ("tcp", "sport") => (0u32, 2u32),
                    ("tcp", "dport") => (2, 2),
                    ("tcp", "flags") => (13, 1),
                    ("udp", "sport") => (0, 2),
                    ("udp", "dport") => (2, 2),
                    ("udp", "length") => (4, 2),
                    ("icmp", "type") => (0, 1),
                    ("icmp", "code") => (1, 1),
                    // icmpv6 uses the same first two bytes (Type, Code)
                    // as icmpv4 because they're both transport-layer
                    // protocols starting with type+code octets. The
                    // injected dependency match is meta l4proto = 58.
                    ("icmpv6", "type") => (0, 1),
                    ("icmpv6", "code") => (1, 1),
                    _ => { continue; }
                };
                // Only inject the dependency if we haven't already
                // seen an equivalent match earlier in this rule
                // (user-written `meta l4proto tcp` / `ip protocol tcp`).
                let has_proto_match = cmd.exprs.windows(2).any(|w| {
                    matches!(&w[0], Expr::Meta { key, .. } if *key == NFT_META_L4PROTO)
                        || matches!(&w[0], Expr::Payload { base, offset: 9, len: 1, .. } if *base == NFT_PAYLOAD_NETWORK_HEADER)
                });
                if !has_proto_match {
                    cmd.exprs.push(Expr::Meta { key: NFT_META_L4PROTO, width: 1 });
                    cmd.exprs.push(Expr::Cmp { op: NFT_CMP_EQ, data: vec![proto_num] });
                }
                cmd.exprs.push(Expr::Payload { base: NFT_PAYLOAD_TRANSPORT_HEADER, offset, len, protocol: proto_num });
                if proto_name == "icmpv6" { self.icmpv6_context = true; }
                // `tcp flags` supports two extended forms in addition to the
                // simple direct-compare path handled by parse_cmp_and_value:
                //
                //   Masked:  tcp flags & (syn | rst | ack) == syn
                //     → payload load @ offset 13, len 1
                //     → bitwise reg & mask ^ 0
                //     → cmp eq reg expected_value
                //
                //   Slash:   tcp flags syn / syn,ack,rst
                //     (syn is the expected value; syn,ack,rst is the mask)
                //     → same encoding as the masked form above
                //
                // Both forms mirror how upstream nft encodes them.  The
                // renderer already understands bitwise+cmp for tcp flags
                // so the listing side needs no changes.
                if proto_name == "tcp" && field == "flags" && !self.at_end() && self.peek() != ";" && !is_statement_start(self.peek()) {
                    if self.peek() == "&" {
                        // Masked form: & ( f1 | f2 | ... ) == val_flags
                        self.advance(); // consume `&`
                        self.matches("(");
                        let mut mask: u8 = 0;
                        loop {
                            let t = self.advance().to_string();
                            // Each token may be a flag name; `|` and `,`
                            // are separators consumed separately.
                            if let Some(b) = tcp_flag_byte(&t) { mask |= b; }
                            if self.peek() == "|" { self.advance(); continue; }
                            if self.peek() == "," { self.advance(); continue; }
                            break;
                        }
                        self.matches(")");
                        self.matches("==");
                        // RHS value: one or more flag names separated by
                        // `|` or `,`.
                        let mut val: u8 = 0;
                        loop {
                            let t = self.advance().to_string();
                            if let Some(b) = tcp_flag_byte(&t) { val |= b; }
                            if self.peek() == "|" { self.advance(); continue; }
                            if self.peek() == "," { self.advance(); continue; }
                            // Stop when the next token is not a flag name
                            // (i.e. we've consumed all RHS flag tokens).
                            if tcp_flag_byte(self.peek()).is_none() { break; }
                        }
                        cmd.exprs.push(Expr::Bitwise { mask: vec![mask], xor: vec![0u8] });
                        cmd.exprs.push(Expr::Cmp { op: NFT_CMP_EQ, data: vec![val] });
                    } else {
                        // Slash form or simple form.  Peek ahead to decide.
                        //
                        // Slash form with spaces:  syn / syn,ack,rst
                        //   → tokens: "syn", "/", "syn", ",", "ack", ...
                        // Slash form without spaces:  syn/syn,ack,rst
                        //   → single token "syn/syn,ack,rst"
                        //
                        // In both cases we detect the slash in or after the
                        // first value token.
                        let first = self.peek().to_string();
                        let has_slash_joined = first.contains('/');
                        let has_slash_ahead = !has_slash_joined
                            && tcp_flag_byte(first.as_str()).is_some()
                            && self.peek_offset(1) == "/";
                        if has_slash_joined || has_slash_ahead {
                            // Slash form — VAL / MASK
                            self.advance(); // consume the first token
                            let (val_str, mask_str): (String, String) = if has_slash_joined {
                                // Split the single joined token on '/'
                                let slash = first.find('/').unwrap();
                                (first[..slash].to_string(), first[slash + 1..].to_string())
                            } else {
                                // Separate tokens: we already consumed val token
                                self.advance(); // consume "/"
                                // Mask is everything up to the next non-flag token;
                                // collect comma-separated names into a string so
                                // tcp_flag_byte can parse each piece.
                                let mut acc = self.advance().to_string();
                                while self.peek() == "," || self.peek() == "|" {
                                    self.advance(); // consume separator
                                    if tcp_flag_byte(self.peek()).is_some() {
                                        acc.push_str(",");
                                        acc.push_str(self.advance());
                                    } else {
                                        break;
                                    }
                                }
                                (first, acc)
                            };
                            // Compute expected value from val_str (comma/pipe-sep)
                            let mut val: u8 = 0;
                            for part in val_str.split(|c| c == ',' || c == '|') {
                                if let Some(b) = tcp_flag_byte(part.trim()) { val |= b; }
                            }
                            // Compute mask from mask_str (comma/pipe-sep)
                            let mut mask: u8 = 0;
                            for part in mask_str.split(|c| c == ',' || c == '|') {
                                if let Some(b) = tcp_flag_byte(part.trim()) { mask |= b; }
                            }
                            cmd.exprs.push(Expr::Bitwise { mask: vec![mask], xor: vec![0u8] });
                            cmd.exprs.push(Expr::Cmp { op: NFT_CMP_EQ, data: vec![val] });
                        } else {
                            // Simple form: `tcp flags syn,ack accept`
                            // nft encodes this as a bitwise mask test, NOT a
                            // direct equality check.  The semantics are
                            // "any of these flags are set":
                            //   bitwise(mask = flags_value, xor = 0) + cmp(neq, 0)
                            // Parse the flag names to build the mask byte.
                            let mut flags_val: u8 = 0;
                            loop {
                                let t = self.peek().to_string();
                                if let Some(b) = tcp_flag_byte(&t) {
                                    self.advance();
                                    flags_val |= b;
                                } else {
                                    break;
                                }
                                if self.peek() == "," || self.peek() == "|" {
                                    self.advance();
                                } else {
                                    break;
                                }
                            }
                            cmd.exprs.push(Expr::Bitwise { mask: vec![flags_val], xor: vec![0x00u8] });
                            cmd.exprs.push(Expr::Cmp { op: NFT_CMP_NEQ, data: vec![0x00u8] });
                        }
                    }
                } else {
                    self.parse_cmp_and_value(cmd, len as usize);
                }
                self.icmpv6_context = false;
                continue;
            }

            // `th sport/dport/...` — protocol-agnostic transport-header
            // load. Upstream uses `th` when a preceding match has
            // already pinned the layer-4 protocol (typically via a set
            // membership: `meta l4proto { tcp, udp } th dport 53`),
            // so we don't inject our own l4proto dependency — we
            // assume the user established it. Field offsets match the
            // common tcp/udp header (sport @0, dport @2, both u16).
            if tok == "th" {
                self.advance();
                let field = self.advance();
                let (offset, len) = match field {
                    "sport" => (0u32, 2u32),
                    "dport" => (2, 2),
                    _ => { continue; }
                };
                cmd.exprs.push(Expr::Payload { base: NFT_PAYLOAD_TRANSPORT_HEADER, offset, len, protocol: 0 });
                self.parse_cmp_and_value(cmd, len as usize);
                continue;
            }

            // ether
            if tok == "ether" {
                self.advance();
                let field = self.advance();
                let (offset, len) = match field {
                    "saddr" => (6u32, 6u32), "daddr" => (0, 6), "type" => (12, 2),
                    _ => { continue; }
                };
                cmd.exprs.push(Expr::Payload { base: NFT_PAYLOAD_LL_HEADER, offset, len, protocol: 0 });
                self.parse_cmp_and_value(cmd, len as usize);
                continue;
            }

            // meta
            if tok == "meta" {
                self.advance();
                let key_str = self.advance().to_string();
                // `meta hour "HH:MM[:SS]"-"HH:MM[:SS]"` — time-of-day
                // window match. Loads the kernel's seconds-since-midnight
                // counter (NFT_META_TIME_HOUR), byteorder-swaps to NBO so
                // a `range eq` over big-endian endpoints matches, then
                // emits the range. The HH:MM endpoints are interpreted
                // in the current TZ and stored as UTC seconds-of-day so
                // the kernel's UTC clock fires at the wall-clock window.
                if key_str == "hour" {
                    self.parse_meta_hour(cmd);
                    continue;
                }
                let (key, vlen) = meta_key(&key_str);
                // `meta KEY set <expr>` — assignment statement, not
                // a match. The producing expression (numgen / jhash /
                // symhash) writes into NFT_REG_1 and the trailing
                // MetaSet stores it back into the meta key. We do
                // *not* push a read-side Meta { key } for this form
                // because the kernel sees only the producer + the
                // SREG-style meta sink.
                if self.peek() == "set" {
                    self.advance();
                    self.parse_meta_set_source(cmd);
                    cmd.exprs.push(Expr::MetaSet { key });
                    continue;
                }
                cmd.exprs.push(Expr::Meta { key, width: vlen });
                if !self.at_end() && !is_statement_start(self.peek()) && self.peek() != ";" {
                    // Meta values come out of the kernel register in
                    // host byte order; mark/iif/oif/skuid/skgid/etc.
                    // need the comparison RHS encoded the same way.
                    // L4PROTO/NFPROTO are 1 byte so byte order is moot.
                    self.host_order_value = matches!(key,
                        NFT_META_MARK | NFT_META_IIF | NFT_META_OIF |
                        NFT_META_SKUID | NFT_META_SKGID | NFT_META_LEN |
                        NFT_META_PRIORITY |
                        // cpu and cgroup ride in the same CPU-native
                        // u32 register slot as mark, so the cmp RHS
                        // must be encoded host-order to match.
                        NFT_META_CPU | NFT_META_CGROUP);
                    self.parse_cmp_and_value(cmd, vlen);
                    self.host_order_value = false;
                }
                continue;
            }

            // socket KEY [VAL]  — load a socket attribute into a register
            // (NFT_SOCKET_TRANSPARENT/MARK/WILDCARD/CGROUPV2) and follow
            // with a cmp against the user-supplied value. The kernel
            // stores into a 4-byte slot for transparent/mark/wildcard
            // and an 8-byte slot for cgroupv2 (which also takes a
            // `level N` ancestor depth).
            if tok == "socket" {
                self.advance();
                let key_str = self.advance().to_string();
                // Kernel store widths (see nft_socket_eval): transparent
                // and wildcard are u8; mark and cgroupv2 are u32. Using
                // a 4-byte cmp on transparent makes the kernel record
                // 4 bytes for the rule, which round-trips through nft's
                // decoder as a `concat` on a 4-byte value rather than
                // the bare `socket transparent N` form upstream prints.
                let (key, vlen) = match key_str.as_str() {
                    "transparent" => (NFT_SOCKET_TRANSPARENT, 1),
                    "mark"        => (NFT_SOCKET_MARK, 4),
                    "wildcard"    => (NFT_SOCKET_WILDCARD, 1),
                    "cgroupv2"    => (NFT_SOCKET_CGROUPV2, 4),
                    _             => (NFT_SOCKET_TRANSPARENT, 1),
                };
                let mut level: Option<u32> = None;
                if key == NFT_SOCKET_CGROUPV2 && self.peek() == "level" {
                    self.advance();
                    if let Ok(n) = self.advance().parse::<u32>() {
                        level = Some(n);
                    }
                }
                cmd.exprs.push(Expr::Socket { key, width: vlen, level });
                if !self.at_end() && !is_statement_start(self.peek()) && self.peek() != ";" {
                    // Socket mark / cgroupv2 / transparent / wildcard
                    // all live in CPU-native register slots — encode
                    // the cmp RHS in host order so the bytes line up.
                    self.host_order_value = true;
                    self.parse_cmp_and_value(cmd, vlen);
                    self.host_order_value = false;
                }
                continue;
            }

            // rt KEY [VAL] — routing-derived match. classid / tcpmss
            // are u32 / u16 host-order; nexthop4/6 are address-shaped
            // and ride in the IPv4/IPv6 register slot.
            if tok == "rt" {
                self.advance();
                let key_str = self.advance().to_string();
                let (key, vlen) = match key_str.as_str() {
                    "classid"  => (NFT_RT_CLASSID, 4),
                    "nexthop"  => (NFT_RT_NEXTHOP4, 4),
                    "tcpmss"   => (NFT_RT_TCPMSS, 2),
                    _          => (NFT_RT_CLASSID, 4),
                };
                cmd.exprs.push(Expr::Rt { key, width: vlen });
                if !self.at_end() && !is_statement_start(self.peek()) && self.peek() != ";" {
                    // classid is host-order u32; tcpmss is host-order
                    // u16. Nexthop addresses are stored network-order
                    // by the kernel — leave host_order_value at its
                    // default for those.
                    self.host_order_value = matches!(key, NFT_RT_CLASSID | NFT_RT_TCPMSS);
                    self.parse_cmp_and_value(cmd, vlen);
                    self.host_order_value = false;
                }
                continue;
            }

            // iifname/oifname without meta prefix
            if tok == "iifname" || tok == "oifname" {
                self.advance();
                let key = if tok == "iifname" { NFT_META_IIFNAME } else { NFT_META_OIFNAME };
                cmd.exprs.push(Expr::Meta { key, width: 16 });
                self.parse_cmp_and_value(cmd, 16);
                continue;
            }

            // ct helper set "name"  (objref to a named ct helper).
            // Match before the generic `ct <key>` path so `ct helper`
            // doesn't lower to a payload load + cmp like `ct state`.
            if tok == "ct" && self.peek_offset(1) == "helper" && self.peek_offset(2) == "set" {
                self.advance(); // ct
                self.advance(); // helper
                self.advance(); // set
                let n = self.parse_name();
                cmd.exprs.push(Expr::ObjRef { kind: NFT_OBJECT_CT_HELPER, name: n });
                continue;
            }

            // ct expectation set "name"  (objref to a named ct expectation).
            // Must come before the generic `ct <key>` path.
            if tok == "ct" && self.peek_offset(1) == "expectation" && self.peek_offset(2) == "set" {
                self.advance(); // ct
                self.advance(); // expectation
                self.advance(); // set
                let n = self.parse_name();
                cmd.exprs.push(Expr::ObjRef { kind: NFT_OBJECT_CT_EXPECT, name: n });
                continue;
            }

            // ct timeout set "name"  (objref to a named ct timeout object).
            // Must come before the generic `ct <key>` path so "timeout" is
            // not misread as a ct key (which it isn't — ct has no timeout key).
            if tok == "ct" && self.peek_offset(1) == "timeout" && self.peek_offset(2) == "set" {
                self.advance(); // ct
                self.advance(); // timeout
                self.advance(); // set
                let n = self.parse_name();
                cmd.exprs.push(Expr::ObjRef { kind: NFT_OBJECT_CT_TIMEOUT, name: n });
                continue;
            }

            // ct
            if tok == "ct" {
                self.advance();
                let mut dir: i8 = -1;
                if self.peek() == "original" { self.advance(); dir = 0; }
                else if self.peek() == "reply" { self.advance(); dir = 1; }
                let key_str = self.advance().to_string();
                let (key, vlen) = ct_key(&key_str);
                cmd.exprs.push(Expr::Ct { key, dir, width: vlen });

                if !self.at_end() && !is_statement_start(self.peek()) && self.peek() != ";" {
                    if key == NFT_CT_STATE {
                        // ct state uses bitmask matching:
                        //   `ct state X`   → bitwise + cmp(NEQ, 0)
                        //     — reg & mask != 0, i.e. any bit present
                        //   `ct state != X` → bitwise + cmp(EQ, 0)
                        //     — reg & mask == 0, i.e. no bit present
                        let op = self.parse_cmp_op();
                        let mask_bytes = self.parse_value(vlen);
                        let zeros = vec![0u8; mask_bytes.len()];
                        cmd.exprs.push(Expr::Bitwise { mask: mask_bytes, xor: zeros.clone() });
                        let cmp_op = if op == NFT_CMP_NEQ { NFT_CMP_EQ } else { NFT_CMP_NEQ };
                        cmd.exprs.push(Expr::Cmp { op: cmp_op, data: zeros });
                    } else {
                        // Same host-byte-order rule as `meta`: ct mark,
                        // ct expiration, ct count etc. live in CPU-native
                        // order in the kernel register.
                        self.host_order_value = matches!(key,
                            NFT_CT_MARK | NFT_CT_SECMARK | NFT_CT_EXPIRATION |
                            NFT_CT_PKTS | NFT_CT_BYTES | NFT_CT_AVGPKT);
                        self.parse_cmp_and_value(cmd, vlen);
                        self.host_order_value = false;
                    }
                }
                continue;
            }

            // Verdicts
            if tok == "accept" { self.advance(); cmd.exprs.push(Expr::Verdict { code: NF_ACCEPT, chain: String::new() }); continue; }
            if tok == "drop" { self.advance(); cmd.exprs.push(Expr::Verdict { code: NF_DROP, chain: String::new() }); continue; }
            if tok == "return" { self.advance(); cmd.exprs.push(Expr::Verdict { code: NFT_RETURN, chain: String::new() }); continue; }
            if tok == "jump" || tok == "goto" {
                let vcode = if tok == "jump" { NFT_JUMP } else { NFT_GOTO };
                self.advance();
                // Anonymous chain binding: `jump { <stmts> }` or
                // `goto { <stmts> }`. Consume the braced body and record
                // a deferred error — anonymous bound chains require kernel
                // support that we do not implement, so the feature probe
                // for NFT_TEST_HAVE_chain_binding must fail (returning
                // an error here causes --check to return non-zero, which
                // the feature probing scripts interpret as "feature absent").
                if self.peek() == "{" {
                    // Anonymous chain binding: `jump { <stmts> }` or
                    // `goto { <stmts> }`. Allocate a synthetic chain name
                    // and chain_id, parse the braced body as rules, and
                    // push a VerdictBinding expression so ops.rs can emit
                    // NFTA_CHAIN_ID for in-batch resolution.
                    if cmd.table.is_empty() {
                        self.deferred_errors.push(
                            "anonymous chain binding requires a table context".into());
                        // Consume the braced body and push a placeholder.
                        self.advance(); // consume `{`
                        let mut depth = 1i32;
                        while !self.at_end() && depth > 0 {
                            match self.peek() {
                                "{" => { depth += 1; self.advance(); }
                                "}" => { depth -= 1; self.advance(); }
                                _   => { self.advance(); }
                            }
                        }
                        cmd.exprs.push(Expr::Unimplemented);
                    } else {
                        let chain_id = self.anon_chain_counter;
                        self.anon_chain_counter += 1;
                        let anon_name = format!("__chain{}", chain_id);

                        // Build the NEWCHAIN command for the anonymous chain.
                        let mut ccmd = Command::default();
                        ccmd.op = CmdOp::Add;
                        ccmd.obj = CmdObj::Chain;
                        ccmd.family = cmd.family;
                        ccmd.table = cmd.table.clone();
                        ccmd.chain = anon_name.clone();
                        ccmd.chain_spec.is_binding = true;
                        ccmd.chain_spec.chain_id = chain_id;
                        ccmd.chain_spec.has_chain_id = true;
                        self.pending_anon_chains.push(ccmd);

                        // Parse the braced body as rules belonging to the
                        // anonymous chain.
                        self.advance(); // consume `{`
                        while !self.at_end() && self.peek() != "}" {
                            while self.matches(";") {}
                            if self.peek() == "}" { break; }
                            let mut rcmd = Command::default();
                            rcmd.op = CmdOp::Add;
                            rcmd.obj = CmdObj::Rule;
                            rcmd.family = cmd.family;
                            rcmd.table = cmd.table.clone();
                            rcmd.chain = anon_name.clone();
                            self.parse_rule_exprs(&mut rcmd);
                            self.matches(";");
                            if !rcmd.exprs.is_empty() || rcmd.has_comment {
                                self.pending_anon_chains.push(rcmd);
                            }
                        }
                        self.matches("}"); // consume closing `}`

                        cmd.exprs.push(Expr::VerdictBinding {
                            code: vcode,
                            chain: anon_name,
                            chain_id,
                        });
                    }
                } else {
                    let c = self.parse_name();
                    cmd.exprs.push(Expr::Verdict { code: vcode, chain: c });
                }
                continue;
            }
            if tok == "continue" { self.advance(); cmd.exprs.push(Expr::Verdict { code: NFT_CONTINUE, chain: String::new() }); continue; }

            // Counter
            if tok == "counter" {
                self.advance();
                // `counter name "x"` → reference a named counter object
                // (objref expression). Bare `counter` is the per-rule
                // anonymous counter.
                if self.peek() == "name" {
                    self.advance();
                    let n = self.parse_name();
                    cmd.exprs.push(Expr::ObjRef { kind: NFT_OBJECT_COUNTER, name: n });
                } else {
                    cmd.exprs.push(Expr::Counter);
                }
                continue;
            }
            if tok == "quota" && self.peek_offset(1) == "name" {
                self.advance(); self.advance();
                let n = self.parse_name();
                cmd.exprs.push(Expr::ObjRef { kind: NFT_OBJECT_QUOTA, name: n });
                continue;
            }
            if tok == "limit" && self.peek_offset(1) == "name" {
                self.advance(); self.advance();
                let n = self.parse_name();
                cmd.exprs.push(Expr::ObjRef { kind: NFT_OBJECT_LIMIT, name: n });
                continue;
            }

            // Log
            if tok == "log" {
                self.advance();
                let prefix = if self.peek() == "prefix" { self.advance(); self.parse_name() } else { String::new() };
                cmd.exprs.push(Expr::Log { prefix });
                continue;
            }

            // Limit
            if tok == "limit" {
                self.advance();
                self.matches("rate");
                // `limit rate over N/second` — `over` inverts the match
                // (NFT_LIMIT_F_INV): packets that EXCEED the rate are matched.
                let limit_flags: u32 = if self.peek() == "over" { self.advance(); NFT_LIMIT_F_INV } else { 0 };
                // The tokenizer keeps `/` joined to its neighbours
                // (CIDR addresses depend on it), so `5/second`
                // arrives here as a single token. Split on the first
                // `/` and parse each half. Falling back to the legacy
                // "rate then `/` then unit" form keeps any future
                // tokenizer-split callers working.
                let first = self.advance().to_string();
                let (rate, unit_str) = if let Some(slash) = first.find('/') {
                    (
                        first[..slash].parse::<u64>().unwrap_or(0),
                        first[slash + 1..].to_string(),
                    )
                } else {
                    let r: u64 = first.parse().unwrap_or(0);
                    self.matches("/");
                    (r, self.advance().to_string())
                };
                let unit = match unit_str.as_str() {
                    "second" => 1u64, "minute" => 60, "hour" => 3600, "day" => 86400, "week" => 604800,
                    _ => 1,
                };
                let burst = if self.matches("burst") { self.advance().parse().unwrap_or(5) } else { 5 };
                self.matches("packets");
                cmd.exprs.push(Expr::Limit { rate, unit, burst, flags: limit_flags });
                continue;
            }

            // NAT
            if tok == "masquerade" {
                self.advance();
                let flags = self.parse_nat_mod_flags();
                cmd.exprs.push(Expr::Masquerade { flags });
                continue;
            }
            if tok == "snat" || tok == "dnat" {
                let nat_type = if tok == "snat" { NFT_NAT_SNAT } else { NFT_NAT_DNAT };
                self.advance(); self.matches("to");
                // The tokenizer keeps `10.0.0.1:8080` joined into a
                // single token because `:` is a continuation char.
                // Split on the first `:` to recover both halves —
                // without this, addr_str includes the port suffix,
                // parse_ipv4 fails, and the rule arrives at the
                // kernel with no NAT target at all.
                let addr_str_full = self.advance().to_string();
                let (addr_part, port_part) = match addr_str_full.find(':') {
                    Some(i) => (&addr_str_full[..i], Some(&addr_str_full[i + 1..])),
                    None => (addr_str_full.as_str(), None),
                };
                let mut addr = Vec::new();
                let mut has_addr = false;
                let mut addr_max = Vec::new();
                let mut has_addr_max = false;
                let mut port = 0u16;
                let mut has_port = false;
                if let Some(a) = Self::parse_ipv4(addr_part) { addr = a.to_vec(); has_addr = true; }
                // Address range: `snat to 1.2.3.4-1.2.3.10`. The
                // tokenizer breaks the literal into three tokens
                // (addr, "-", addr); look ahead for the dash and
                // consume the upper bound when found. Only valid for
                // the no-port form — `a:p-b:q` is not a thing in nft.
                if !has_port && self.peek() == "-" {
                    self.advance();
                    let upper = self.advance().to_string();
                    if let Some(a) = Self::parse_ipv4(&upper) {
                        addr_max = a.to_vec();
                        has_addr_max = true;
                    }
                }
                if let Some(ps) = port_part {
                    port = ps.parse().unwrap_or(0);
                    has_port = true;
                } else if self.peek() == ":" {
                    // Tokenizer does split on `:` if it's surrounded by
                    // spaces or follows a non-numeric token; keep the
                    // legacy fallback so that form still works.
                    self.advance();
                    port = self.advance().parse().unwrap_or(0);
                    has_port = true;
                }
                let flags = self.parse_nat_mod_flags();
                cmd.exprs.push(Expr::Nat {
                    nat_type, family: cmd.family,
                    addr, port, has_addr, has_port,
                    addr_max, has_addr_max, flags,
                });
                continue;
            }

            // Flowtable offload: `flow add @ft` — encode as the
            // `flow_offload` expression. Upstream nft only wires up the
            // `add` verb today; we mirror that and silently skip any
            // unknown verb so a future `flow update @ft` doesn't
            // explode the parser.
            if tok == "flow" {
                self.advance();
                if self.peek() == "add" {
                    self.advance();
                    let set_tok = self.advance().to_string();
                    let name = set_tok.trim_start_matches('@').to_string();
                    cmd.exprs.push(Expr::FlowOffload { name });
                }
                continue;
            }

            // Notrack / Reject
            if tok == "notrack" { self.advance(); cmd.exprs.push(Expr::Notrack); continue; }
            if tok == "reject" { self.advance(); cmd.exprs.push(Expr::Reject); continue; }

            // dup — `dup to <ipv4> [device "<dev>"]`. Optional device
            // resolves through if_nametoindex; without it the kernel
            // routes the copy to the gateway.
            if tok == "dup" {
                self.advance();
                self.matches("to");
                let addr_tok = self.advance().to_string();
                let mut addr = Vec::new();
                if let Some(a) = Self::parse_ipv4(&addr_tok) { addr = a.to_vec(); }
                let mut dev: Option<u32> = None;
                if self.peek() == "device" {
                    self.advance();
                    let dev_tok = self.advance().to_string();
                    let dev_name = dev_tok.trim_matches('"').to_string();
                    dev = Some(if_nametoindex(&dev_name).unwrap_or(0));
                }
                cmd.exprs.push(Expr::Dup { addr, dev });
                continue;
            }

            // fwd — netdev-only: `fwd to "<dev>"`. The device is the
            // sole argument; we resolve to an interface index here so
            // the netlink emitter just writes a register load.
            if tok == "fwd" {
                self.advance();
                self.matches("to");
                let dev_tok = self.advance().to_string();
                let dev_name = dev_tok.trim_matches('"').to_string();
                let dev = if_nametoindex(&dev_name).unwrap_or(0);
                cmd.exprs.push(Expr::Fwd { dev });
                continue;
            }

            // tproxy — `tproxy [ip|ip6] to [ADDR][:PORT]`.
            // Forms accepted:
            //   tproxy to :PORT
            //   tproxy to ADDR
            //   tproxy to ADDR:PORT
            //   tproxy to [IPV6]:PORT
            //   tproxy ip|ip6 to ...
            // The tokenizer splits on `:` for non-IPv6 words, so
            // `1.2.3.4:1088` arrives as three tokens `1.2.3.4`, `:`,
            // `1088`. A bare `:PORT` form skips the addr immediate
            // entirely (kernel falls back to the listener's bound IP)
            // and a bare `ADDR` form skips the port. When the user
            // doesn't write `ip` / `ip6`, family is left UNSPEC; the
            // kernel either resolves it from chain context (ip / ip6
            // tables) or matches both L3 protocols (inet table) — see
            // `nft_tproxy_eval` and upstream evaluate.c.
            if tok == "tproxy" {
                self.advance();
                let mut family = NFPROTO_UNSPEC as u32;
                if self.peek() == "ip" {
                    self.advance();
                    family = NFPROTO_IPV4 as u32;
                } else if self.peek() == "ip6" {
                    self.advance();
                    family = NFPROTO_IPV6 as u32;
                }
                self.matches("to");

                let mut addr: Vec<u8> = Vec::new();
                let mut has_addr = false;
                let mut port: u16 = 0;
                let mut has_port = false;

                // The tokenizer absorbs `:` into a leading-empty word
                // when the rest of the chars look hex-ish, so a bare
                // `:1088` (or `1.2.3.4:1088`) often arrives as one
                // token. We therefore split the next token on `:`
                // ourselves: anything before is the address and
                // anything after is the port. Bracketed IPv6 forms
                // `[2001:db8::1]:1088` come in as `[`, `2001:db8::1`,
                // `]`, `:`, `1088` (or `]:1088`) and need separate
                // handling.
                if !self.at_end() && self.peek() != ";" {
                    let target = self.advance().to_string();
                    if target == "[" {
                        let a = self.advance().to_string();
                        self.matches("]");
                        if let Some(b) = Self::parse_ipv6(&a) {
                            addr = b.to_vec();
                            has_addr = true;
                            if family == NFPROTO_UNSPEC as u32 { family = NFPROTO_IPV6 as u32; }
                        }
                        // `]:1088` — the bracket-close token may carry
                        // the colon and the port glued on; otherwise
                        // we expect a separate `:` `port` pair.
                        if self.peek() == ":" {
                            self.advance();
                            if !self.at_end() && self.peek() != ";" {
                                let p = self.advance().to_string();
                                if let Ok(n) = p.parse::<u16>() {
                                    port = n;
                                    has_port = true;
                                }
                            }
                        }
                    } else {
                        // `:port` — bare port form. Address half empty.
                        // `addr:port` — split on first ':'. The inner
                        // colon split is safe because the tokenizer
                        // doesn't absorb `:` into a non-empty word
                        // unless the word already looks hex-like, and
                        // an `addr:port` literal that goes through here
                        // is by construction the IPv4 form (IPv6 came
                        // through the `[ ... ]` arm above).
                        let trimmed = target.trim_matches('"');
                        let (addr_part, port_part) = match trimmed.find(':') {
                            Some(i) => (&trimmed[..i], Some(&trimmed[i + 1..])),
                            None => (trimmed, None),
                        };
                        if !addr_part.is_empty() {
                            if let Some(b) = Self::parse_ipv4(addr_part) {
                                addr = b.to_vec();
                                has_addr = true;
                            } else if let Some(b) = Self::parse_ipv6(addr_part) {
                                addr = b.to_vec();
                                has_addr = true;
                                if family == NFPROTO_UNSPEC as u32 { family = NFPROTO_IPV6 as u32; }
                            }
                        }
                        if let Some(p) = port_part {
                            if !p.is_empty() {
                                if let Ok(n) = p.parse::<u16>() {
                                    port = n;
                                    has_port = true;
                                }
                            } else if self.peek() != ";" && !self.at_end() {
                                // `addr :` `port` — port arrived as a
                                // separate token after the colon got
                                // glued onto addr.
                                let p2 = self.advance().to_string();
                                if let Ok(n) = p2.parse::<u16>() {
                                    port = n;
                                    has_port = true;
                                }
                            }
                        } else if self.peek() == ":" {
                            // `addr` `:` `port` — three separate tokens.
                            self.advance();
                            if !self.at_end() && self.peek() != ";" {
                                let p = self.advance().to_string();
                                if let Ok(n) = p.parse::<u16>() {
                                    port = n;
                                    has_port = true;
                                }
                            }
                        }
                    }
                }

                cmd.exprs.push(Expr::Tproxy { family, addr, port, has_addr, has_port });
                continue;
            }

            // synproxy — `synproxy mss N wscale N [timestamp] [sack-perm]`.
            // mss/wscale tokens are mandatory in the upstream rule
            // syntax we mirror; flag tokens are order-independent.
            if tok == "synproxy" {
                self.advance();
                let mut mss: u16 = 0;
                let mut wscale: u8 = 0;
                let mut flags: u32 = 0;
                loop {
                    let p = self.peek();
                    if p.is_empty() || p == ";" { break; }
                    if p == "mss" {
                        self.advance();
                        mss = self.advance().parse().unwrap_or(0);
                        flags |= NF_SYNPROXY_OPT_MSS;
                    } else if p == "wscale" {
                        self.advance();
                        wscale = self.advance().parse().unwrap_or(0);
                        flags |= NF_SYNPROXY_OPT_WSCALE;
                    } else if p == "timestamp" {
                        self.advance();
                        flags |= NF_SYNPROXY_OPT_TIMESTAMP;
                    } else if p == "sack-perm" {
                        self.advance();
                        flags |= NF_SYNPROXY_OPT_SACK_PERM;
                    } else {
                        break;
                    }
                }
                cmd.exprs.push(Expr::Synproxy { mss, wscale, flags });
                continue;
            }

            // `fib <key>[. <key>]... <result> [<value>]` — kernel fib
            // expression. Keys form a bitflag ORed into NFTA_FIB_FLAGS;
            // result selects what the kernel stores in DREG. With a
            // value, an implicit cmp follows so `fib saddr type local`
            // matches when the source has RTN_LOCAL.
            if tok == "fib" {
                self.advance();
                let mut flags: u32 = 0;
                loop {
                    match self.peek() {
                        "saddr" => { flags |= crate::netlink::NFTA_FIB_F_SADDR; self.advance(); }
                        "daddr" => { flags |= crate::netlink::NFTA_FIB_F_DADDR; self.advance(); }
                        "mark"  => { flags |= crate::netlink::NFTA_FIB_F_MARK;  self.advance(); }
                        "iif"   => { flags |= crate::netlink::NFTA_FIB_F_IIF;   self.advance(); }
                        "oif"   => { flags |= crate::netlink::NFTA_FIB_F_OIF;   self.advance(); }
                        "."     => { self.advance(); }
                        _       => break,
                    }
                }
                let (result, dreg, width) = match self.peek() {
                    "type" => {
                        self.advance();
                        (crate::netlink::NFT_FIB_RESULT_ADDRTYPE,
                         crate::netlink::NFT_REG32_00, 4usize)
                    }
                    "oif" => {
                        self.advance();
                        (crate::netlink::NFT_FIB_RESULT_OIF,
                         crate::netlink::NFT_REG32_00, 4usize)
                    }
                    "oifname" => {
                        self.advance();
                        (crate::netlink::NFT_FIB_RESULT_OIFNAME,
                         crate::netlink::NFT_REG_1, 16usize)
                    }
                    _ => {
                        cmd.exprs.push(Expr::Fib { flags, result: 0, dreg: crate::netlink::NFT_REG32_00 });
                        cmd.exprs.push(Expr::Unimplemented);
                        continue;
                    }
                };
                cmd.exprs.push(Expr::Fib { flags, result, dreg });
                // If a value follows, emit an implicit cmp. RTN_* values
                // for `type`: unspec=0, unicast=1, local=2, broadcast=3,
                // anycast=4, multicast=5, blackhole=6, unreachable=7,
                // prohibit=8.
                if !self.at_end() && self.peek() != ";" && self.peek() != "}" {
                    if result == crate::netlink::NFT_FIB_RESULT_ADDRTYPE {
                        let v = self.peek();
                        let rtn: Option<u32> = match v {
                            "unspec"      => Some(0), "unicast"   => Some(1),
                            "local"       => Some(2), "broadcast" => Some(3),
                            "anycast"     => Some(4), "multicast" => Some(5),
                            "blackhole"   => Some(6), "unreachable" => Some(7),
                            "prohibit"    => Some(8), _ => None,
                        };
                        if let Some(n) = rtn {
                            self.advance();
                            cmd.exprs.push(Expr::Cmp {
                                op: NFT_CMP_EQ,
                                data: n.to_le_bytes().to_vec(),
                            });
                        }
                        let _ = dreg; let _ = width;
                    } else if result == crate::netlink::NFT_FIB_RESULT_OIFNAME {
                        let name = self.advance().to_string().trim_matches('"').to_string();
                        let mut bytes = vec![0u8; 16];
                        let nb = name.as_bytes();
                        bytes[..nb.len().min(15)].copy_from_slice(&nb[..nb.len().min(15)]);
                        cmd.exprs.push(Expr::Cmp {
                            op: NFT_CMP_EQ,
                            data: bytes,
                        });
                    }
                }
                continue;
            }

            // `queue` statement — supports the legacy
            //   `queue [num N | num L-H] [bypass] [flags ...]`
            // form (NUM/TOTAL on the wire) and the modern
            //   `queue [flags F[,F...]] to <hash|map-lookup>`
            // form (SREG_QNUM on the wire, fed by a preceding
            // jhash / symhash / Lookup). Flags can appear before
            // OR after `num`, mirroring upstream's grammar.
            if tok == "queue" {
                self.advance();
                let mut num: u16 = 0;
                let mut total: u16 = 1;
                let mut flags: u16 = 0;
                let mut has_num = false;
                let mut has_sreg = false;

                // Loop over `num`, `flags`, `bypass`, `to ...`.
                // The grammar is permissive — any order, any
                // combination — so a small state-free loop works.
                loop {
                    match self.peek() {
                        "num" => {
                            self.advance();
                            let v = self.advance().to_string();
                            // num accepts `N` or `L-H`. The bare-`N`
                            // case sets total=1 (single queue);
                            // `L-H` sets num=L, total=H-L+1.
                            if let Some(dash) = v.find('-') {
                                let lo: u16 = v[..dash].parse().unwrap_or(0);
                                let hi: u16 = v[dash+1..].parse().unwrap_or(0);
                                num = lo;
                                total = hi.saturating_sub(lo).saturating_add(1).max(1);
                            } else {
                                num = v.parse().unwrap_or(0);
                                total = 1;
                            }
                            has_num = true;
                        }
                        "flags" => {
                            self.advance();
                            // Comma-separated flag list, no whitespace
                            // around the commas because the tokenizer
                            // splits on commas already.
                            loop {
                                match self.peek() {
                                    "bypass" => { flags |= crate::netlink::NFT_QUEUE_FLAG_BYPASS; self.advance(); }
                                    "fanout" => { flags |= crate::netlink::NFT_QUEUE_FLAG_CPU_FANOUT; self.advance(); }
                                    "," => { self.advance(); }
                                    _ => break,
                                }
                            }
                        }
                        "bypass" => {
                            // `queue num 5 bypass` legacy shorthand.
                            flags |= crate::netlink::NFT_QUEUE_FLAG_BYPASS;
                            self.advance();
                        }
                        "fanout" => {
                            flags |= crate::netlink::NFT_QUEUE_FLAG_CPU_FANOUT;
                            self.advance();
                        }
                        "to" => {
                            self.advance();
                            // The dynamic form: a single queue-number
                            // expression follows. Dispatch to the
                            // small per-source helpers — symhash and
                            // jhash share the existing Hash variant
                            // (with hash output forced into NFT_REG_1)
                            // and a map lookup goes through the
                            // existing payload+lookup chain. After
                            // emitting the producer, the queue
                            // expression below will reference
                            // NFT_REG_1 via SREG_QNUM.
                            self.parse_queue_dynamic(cmd);
                            has_sreg = true;
                            break;
                        }
                        _ => break,
                    }
                }
                let _ = has_num;
                let sreg_qnum = if has_sreg { crate::netlink::NFT_REG_1 } else { 0 };
                cmd.exprs.push(Expr::Queue {
                    num, total, flags, has_sreg, sreg_qnum,
                });
                continue;
            }

            // Unknown token — advance past it and mark this rule as
            // having at least one expression so the enclosing declarative
            // parser does not reject it as "empty" syntax.
            self.advance();
            cmd.exprs.push(Expr::Unimplemented);
        }
    }

    /// Parse the right-hand side of `queue ... to <expr>`. Emits the
    /// preceding expressions (payload load + jhash/symhash/lookup)
    /// that fill NFT_REG_1 with the dynamic queue index. The caller
    /// emits the trailing Expr::Queue with `has_sreg = true`.
    fn parse_queue_dynamic(&mut self, cmd: &mut Command) {
        let head = self.peek().to_string();
        if head == "symhash" {
            self.advance();
            self.matches("mod");
            let modulus: u32 = self.advance().parse().unwrap_or(0);
            let mut offset: u32 = 0;
            if self.peek() == "offset" {
                self.advance();
                offset = self.advance().parse().unwrap_or(0);
            }
            cmd.exprs.push(Expr::Hash {
                sreg: None, len: 0, modulus, seed: 0, has_seed: false,
                offset, hash_type: NFT_HASH_SYM,
            });
            return;
        }
        if head == "jhash" {
            self.advance();
            // Concatenated keys: each field's load advances dreg by
            // netlink_register_space(prev_bytes) — rounded up to
            // the next 32-bit slot.
            let first = self.parse_jhash_key(cmd);
            let mut len = first;
            let mut next_dreg = NFT_REG_2 + ((first + 3) / 4);
            while self.peek() == "." {
                self.advance();
                let f = self.parse_jhash_key_at(cmd, next_dreg);
                len = len.saturating_add(f);
                next_dreg += (f + 3) / 4;
            }
            self.matches("mod");
            let modulus: u32 = self.advance().parse().unwrap_or(0);
            let mut seed: u32 = 0;
            let mut has_seed = false;
            let mut offset: u32 = 0;
            loop {
                let next = self.peek().to_string();
                if next == "seed" {
                    self.advance();
                    let v = self.advance().to_string();
                    seed = if let Some(hex) = v.strip_prefix("0x").or_else(|| v.strip_prefix("0X")) {
                        u32::from_str_radix(hex, 16).unwrap_or(0)
                    } else {
                        v.parse().unwrap_or(0)
                    };
                    has_seed = true;
                } else if next == "offset" {
                    self.advance();
                    offset = self.advance().parse().unwrap_or(0);
                } else {
                    break;
                }
            }
            cmd.exprs.push(Expr::Hash {
                sreg: Some(NFT_REG_2), len, modulus, seed, has_seed,
                offset, hash_type: NFT_HASH_JENKINS,
            });
            return;
        }
        // `queue ... to <field> [. <field>...] map @name` —
        // map-based dispatch. The kernel needs the concatenated
        // key in NFT_REG_1.. so each subfield gets its own
        // register slot (advances by one 4-byte slot per field).
        // We reuse Expr::HashKeyPayload — its only function is
        // "payload load with explicit DREG" — and start at
        // NFT_REG_1 instead of NFT_REG_2. The trailing
        // Expr::MapLookup reads SREG=NFT_REG_1 and writes the
        // looked-up u16 queue id back to NFT_REG_1 for queue's
        // SREG_QNUM.
        let mut total_len: u32 = 0;
        let mut dreg = crate::netlink::NFT_REG_1;
        loop {
            let cur = self.peek().to_string();
            if cur == "ip" {
                self.advance();
                let field = self.advance().to_string();
                let (offset, len) = match field.as_str() {
                    "saddr" => (12u32, 4u32),
                    "daddr" => (16, 4),
                    _ => break,
                };
                cmd.exprs.push(Expr::HashKeyPayload {
                    base: NFT_PAYLOAD_NETWORK_HEADER, offset, len, dreg,
                });
                total_len = total_len.saturating_add(len);
                dreg += 1;
            } else if cur == "ip6" {
                self.advance();
                let field = self.advance().to_string();
                let (offset, len) = match field.as_str() {
                    "saddr" => (8u32, 16u32),
                    "daddr" => (24, 16),
                    _ => break,
                };
                cmd.exprs.push(Expr::HashKeyPayload {
                    base: NFT_PAYLOAD_NETWORK_HEADER, offset, len, dreg,
                });
                total_len = total_len.saturating_add(len);
                // ip6 saddr/daddr are 16 bytes = 4 4-byte slots
                dreg += 4;
            } else if cur == "tcp" || cur == "udp" {
                self.advance();
                let field = self.advance().to_string();
                let (offset, len) = match field.as_str() {
                    "sport" => (0u32, 2u32),
                    "dport" => (2, 2),
                    _ => break,
                };
                cmd.exprs.push(Expr::HashKeyPayload {
                    base: NFT_PAYLOAD_TRANSPORT_HEADER, offset, len, dreg,
                });
                total_len = total_len.saturating_add(len);
                dreg += 1;
            } else {
                break;
            }
            if self.peek() == "." { self.advance(); continue; }
            break;
        }
        if self.peek() == "map" {
            self.advance();
            if self.peek().starts_with('@') {
                let tok = self.advance().to_string();
                let set_name = tok.trim_start_matches('@').to_string();
                // Data-side map: the kernel writes the looked-up
                // queue u16 into NFT_REG_1; the trailing
                // Expr::Queue then references it via SREG_QNUM.
                cmd.exprs.push(Expr::MapLookup {
                    set_name,
                    key_width: total_len as usize,
                    dreg: crate::netlink::NFT_REG_1,
                });
            }
        }
    }

    fn parse_cmp_and_value(&mut self, cmd: &mut Command, data_len: usize) {
        if self.at_end() || self.peek() == ";" { return; }

        // A bare `.` means this is a concat key selector (e.g. `ip daddr .
        // meta iif vmap { ... }`).  The outer parse_rule_exprs loop will
        // advance past "." and parse the next selector; return now so we
        // don't consume the dot or produce a garbage Cmp expression.
        if self.peek() == "." { return; }

        // `ip saddr vmap @m` and `ip saddr vmap { 1.1.1.1 : jump c2 }`
        // lower to a lookup with a DREG for the verdict output. For
        // now we only support the named-set form; anon vmap literals
        // are a future expansion.
        if self.peek() == "vmap" {
            self.advance();
            if self.peek().starts_with('@') {
                let tok = self.advance().to_string();
                let set_name = tok.trim_start_matches('@').to_string();
                cmd.exprs.push(Expr::Vmap { set_name, width: data_len, set_id: None });
                return;
            }
            // Anonymous vmap literal: collect `k : verdict` pairs.
            if self.peek() == "{" {
                self.advance();
                let mut pairs: Vec<(Vec<u8>, Option<Vec<u8>>, i32, String)> = Vec::new();
                // Track the total concat key width; may grow beyond data_len
                // when elements use `. field` concat notation.
                let mut concat_width = data_len;
                // dtype_pack accumulator for the concat key type sent to
                // NFTA_SET_KEY_TYPE.  Matches upstream nft's dtype_pack()
                // scheme: each 6-bit slot type_id is shifted in MSB-first.
                // Initialised from data_len; updated with each concat slot.
                // Type-id mapping (from nft/include/datatype.h):
                //   7=ipv4_addr, 8=ipv6_addr, 13=inet_service, 12=inet_proto,
                //   36=ifindex, 15=mark, 4=unsigned32 (generic)
                let first_slot_typeid: u32 = match data_len {
                    4  => 7,  // ipv4_addr (may be overridden below if integer)
                    16 => 8,  // ipv6_addr
                    2  => 13, // inet_service
                    1  => 12, // inet_proto
                    _  => 4,  // generic u32
                };
                // packed_key_type is built as each element's first slot is
                // processed; it reflects the concat key structure of the first
                // fully-parsed element (subsequent elements must match).
                let mut packed_key_type: u32 = 0;
                while !self.at_end() && self.peek() != "}" {
                    if self.peek() == "," || self.peek() == ";" { self.advance(); continue; }
                    let tok = self.advance().to_string();
                    // First key slot — IPv4 or integer, same as before.
                    // Track whether the value was an IPv4 addr to choose
                    // the right type_id for the packed key type.
                    let (first_slot, first_is_ipv4) = if data_len == 4 {
                        if let Some(a) = Self::parse_ipv4(&tok) {
                            (Some(a.to_vec()), true)
                        } else if let Some(n) = tok.parse::<u32>().ok() {
                            (Some(n.to_be_bytes().to_vec()), false)
                        } else {
                            (None, false)
                        }
                    } else if data_len == 2 {
                        (tok.parse::<u16>().ok().map(|n| n.to_be_bytes().to_vec()), false)
                    } else { (None, false) };
                    if first_slot.is_none() { continue; }
                    // Pad first slot to 4-byte alignment so concat slots
                    // are positioned correctly in the key vector.
                    let mut key_bytes = first_slot.unwrap();
                    while key_bytes.len() < ((data_len + 3) & !3) { key_bytes.push(0); }
                    // dtype_pack for the first slot: ipv4 if the value was
                    // an address, else the default for data_len.
                    let slot0_typeid = if first_is_ipv4 { 7u32 } else { first_slot_typeid };
                    let mut packed = slot0_typeid;
                    let has_concat = self.peek() == ".";
                    // Consume additional concat slots: `. <value>` where
                    // value is an IPv4 address, a decimal/hex u32, or an
                    // interface name (resolved via if_nametoindex). Each
                    // slot is 4 bytes (u32) in the kernel's register space.
                    // Interface index slots (meta iif / meta oif) are stored
                    // in host byte order in the kernel register, so we match
                    // that encoding here.
                    while self.peek() == "." {
                        self.advance(); // consume "."
                        let stok = self.advance().to_string();
                        let (slot_bytes, slot_typeid): (Vec<u8>, u32) =
                            if let Some(a) = Self::parse_ipv4(&stok) {
                                (a.to_vec(), 7) // ipv4_addr
                            } else if let Some(n) = stok.parse::<u32>().ok() {
                                (n.to_be_bytes().to_vec(), 4) // generic u32
                            } else {
                                // Treat as an interface name and resolve it.
                                // iif/oif values in the kernel register are
                                // host-byte-order u32, so use to_ne_bytes().
                                let idx = if_nametoindex(&stok).unwrap_or(0);
                                (idx.to_ne_bytes().to_vec(), 36) // ifindex
                            };
                        key_bytes.extend_from_slice(&slot_bytes);
                        // Pad to next 4-byte boundary.
                        while key_bytes.len() % 4 != 0 { key_bytes.push(0); }
                        // dtype_pack: shift accumulated type left by 6,
                        // OR in the new slot's type_id.
                        packed = (packed << 6) | slot_typeid;
                        // Update the running concat key width (first pass only).
                        if key_bytes.len() > concat_width {
                            concat_width = key_bytes.len();
                        }
                    }
                    // Record the packed type from the first multi-slot element.
                    if has_concat && packed_key_type == 0 {
                        packed_key_type = packed;
                    }
                    let key = key_bytes;
                    // Optional range end: `100-222 : accept`
                    let range_end: Option<Vec<u8>> = if self.peek() == "-" {
                        self.advance();
                        let etok = self.advance().to_string();
                        if data_len == 4 {
                            Self::parse_ipv4(&etok).map(|a| a.to_vec())
                                .or_else(|| etok.parse::<u32>().ok().map(|n| n.to_be_bytes().to_vec()))
                        } else if data_len == 2 {
                            etok.parse::<u16>().ok().map(|n| n.to_be_bytes().to_vec())
                        } else { None }
                    } else { None };
                    self.matches(":");
                    let vtok = self.advance().to_string();
                    let (code, cn) = match vtok.as_str() {
                        "accept" => (NF_ACCEPT, String::new()),
                        "drop" => (NF_DROP, String::new()),
                        "return" => (NFT_RETURN, String::new()),
                        "continue" => (NFT_CONTINUE, String::new()),
                        "jump" => (NFT_JUMP, self.advance().to_string()),
                        "goto" => (NFT_GOTO, self.advance().to_string()),
                        _ => {
                            self.deferred_errors.push(format!("syntax error, unexpected string"));
                            continue;
                        }
                    };
                    pairs.push((key, range_end, code, cn));
                }
                self.matches("}");
                cmd.exprs.push(Expr::AnonVmap { pairs, width: concat_width, packed_key_type });
                return;
            }
            return;
        }

        let op = self.parse_cmp_op();

        // Named-set reference: `ip saddr @blocked drop`. Emits a
        // lookup expression that matches against the set referenced
        // by the preceding Meta / Payload load. NFT_CMP_NEQ becomes
        // the inverted flag on the lookup.
        if self.peek().starts_with('@') {
            let tok = self.advance().to_string();
            let set_name = tok.trim_start_matches('@').to_string();
            let inverted = op == NFT_CMP_NEQ;
            cmd.exprs.push(Expr::Lookup { set_name, inverted, width: data_len });
            return;
        }

        // Check for set literal { ... } — an anonymous set. Previously
        // this lowered to multiple Expr::Cmp entries which the kernel
        // ANDed together (so `ip saddr { 1.1.1.1, 2.2.2.2 }` matched
        // nothing). Now we emit a single Expr::AnonSet and let
        // add_rule allocate a __setN, NEWSET it, populate elements,
        // and rewrite this into an Expr::Lookup.
        if self.peek() == "{" {
            self.advance();
            let inverted = op == NFT_CMP_NEQ;
            let mut elements: Vec<(Vec<u8>, Option<Vec<u8>>)> = Vec::new();
            while !self.at_end() && self.peek() != "}" {
                if self.peek() == "," || self.peek() == ";" { self.advance(); continue; }
                let tok = self.advance().to_string();

                // CIDR: expand `1.1.1.0/24` to [start, end] (IPv4 only
                // for now; non-IP-width callers should never produce
                // CIDR tokens).
                if data_len == 4 {
                    if let Some(slash) = tok.find('/') {
                        if let (Some(addr), Ok(prefix)) =
                            (Self::parse_ipv4(&tok[..slash]), tok[slash + 1..].parse::<u32>())
                        {
                            let prefix = prefix.min(32);
                            let base = u32::from_be_bytes(addr);
                            let host_mask = if prefix == 32 { 0u32 } else { (1u32 << (32 - prefix)) - 1 };
                            let start = base & !host_mask;
                            let end = start | host_mask;
                            elements.push((
                                start.to_be_bytes().to_vec(),
                                Some(end.to_be_bytes().to_vec()),
                            ));
                            continue;
                        }
                    }
                }

                // Bare value plus optional `-` range tail. For 4-byte
                // fields the value may be an IPv4 address (`1.1.1.1`)
                // or an integer literal (`123`, `0x7b`) depending on
                // context — `meta mark`, `ct mark`, etc. use integer
                // form. Try address first, fall back to integer.
                let parse_scalar = |tok: &str| -> Option<Vec<u8>> {
                    if data_len == 4 {
                        if let Some(a) = Self::parse_ipv4(tok) { return Some(a.to_vec()); }
                        let n: Option<u32> = if let Some(s) = tok.strip_prefix("0x") {
                            u32::from_str_radix(s, 16).ok()
                        } else { tok.parse::<u32>().ok() };
                        n.map(|n| n.to_be_bytes().to_vec())
                    } else if data_len == 2 {
                        tok.parse::<u16>().ok().map(|n| n.to_be_bytes().to_vec())
                    } else if data_len == 1 {
                        // Symbolic protocol/icmp-type names — `meta l4proto
                        // { tcp, udp }` and `icmp type { echo-request,
                        // echo-reply }` are upstream idioms. Try the
                        // protocol table and the icmp-type table before
                        // falling back to numeric parsing so the brace
                        // body doesn't silently become `{ }`.
                        if let Some(p) = proto_num(tok) { return Some(vec![p]); }
                        if let Some(t) = icmp_type_num(tok) { return Some(vec![t]); }
                        if let Some(s) = tok.strip_prefix("0x") {
                            u8::from_str_radix(s, 16).ok().map(|n| vec![n])
                        } else {
                            tok.parse::<u8>().ok().map(|n| vec![n])
                        }
                    } else {
                        tok.parse::<u32>().ok().map(|n| n.to_be_bytes().to_vec())
                    }
                };
                let start: Option<Vec<u8>> = parse_scalar(&tok);

                if let Some(s) = start {
                    let end = if self.peek() == "-" {
                        self.advance();
                        let end_tok = self.advance().to_string();
                        parse_scalar(&end_tok)
                    } else { None };
                    elements.push((s, end));
                    continue;
                }

                // Fallback: bytes-pad via parse_value would consume
                // additional tokens and is wrong here. Silently skip
                // unparseable tokens; this matches the old loop's
                // behaviour for unknown entries.
            }
            self.matches("}");
            cmd.exprs.push(Expr::AnonSet { elements, width: data_len, inverted });
            return;
        }

        // Check for CIDR
        let tok = self.peek().to_string();
        if let Some(slash) = tok.find('/') {
            if let Some(addr_bytes) = Self::parse_ipv4(&tok[..slash]) {
                let prefix_len: u32 = tok[slash+1..].parse().unwrap_or(32);
                self.advance();

                // Generate bitwise mask
                let mut mask = [0u8; 4];
                for i in 0..prefix_len.min(32) {
                    mask[(i / 8) as usize] |= 1 << (7 - (i % 8));
                }
                let xor = [0u8; 4];
                let masked: Vec<u8> = addr_bytes.iter().zip(mask.iter()).map(|(a, m)| a & m).collect();

                cmd.exprs.push(Expr::Bitwise { mask: mask.to_vec(), xor: xor.to_vec() });
                cmd.exprs.push(Expr::Cmp { op, data: masked });
                return;
            }
        }

        let data = self.parse_value(data_len);
        cmd.exprs.push(Expr::Cmp { op, data });
    }

    fn parse_chain_block(&mut self, cmd: &mut Command) -> Result<(), String> {
        if !self.matches("{") { return Ok(()); }
        while !self.at_end() && self.peek() != "}" {
            while self.matches(";") {}
            if self.peek() == "}" { break; }
            let t = self.peek().to_string();
            if self.matches("type") {
                cmd.chain_spec.is_base = true;
                cmd.chain_spec.chain_type = self.parse_name();
                if self.matches("hook") { cmd.chain_spec.hook = self.parse_name(); }
                // Reject duplicate hook keyword
                if self.peek() == "hook" {
                    return Err("syntax error, unexpected hook, expecting priority".into());
                }
                if self.matches("device") {
                    let dev = self.parse_name();
                    // IFNAMSIZ = 16 → max 15 usable chars.
                    if dev.len() > 15 {
                        return Err(format!("interface name too long"));
                    }
                    cmd.chain_spec.device = dev;
                    cmd.chain_spec.has_device = true;
                }
                // `devices = { dev [, dev ...] }` — plural form used by
                // egress/multidevice chains. Store only the first device;
                // multiple-device support requires kernel NFT_CHAIN_F_HW_OFFLOAD.
                if self.matches("devices") {
                    self.matches("=");
                    if self.matches("{") {
                        while !self.at_end() && self.peek() != "}" {
                            if self.peek() == "," || self.peek() == ";" { self.advance(); continue; }
                            let d = self.advance().to_string();
                            let dev = if d.starts_with('"') && d.ends_with('"') && d.len() >= 2 {
                                d[1..d.len()-1].to_string()
                            } else { d };
                            if dev.len() > 15 {
                                return Err(format!("interface name too long"));
                            }
                            if !dev.is_empty() && !cmd.chain_spec.has_device {
                                cmd.chain_spec.device = dev;
                                cmd.chain_spec.has_device = true;
                            }
                        }
                        self.matches("}");
                    }
                }
                if self.matches("priority") {
                    let ct = cmd.chain_spec.chain_type.clone();
                    let hk = cmd.chain_spec.hook.clone();
                    cmd.chain_spec.priority = self.parse_priority_ctx(cmd.family, &ct, &hk)?;
                    cmd.chain_spec.has_priority = true;
                }
                self.matches(";");
            } else if self.matches("priority") {
                // `priority` outside a `type` context is a syntax error
                // (non-base chain cannot have a priority).
                return Err("syntax error, unexpected priority".into());
            } else if self.matches("policy") {
                let pol = self.parse_name();
                if pol != "accept" && pol != "drop" {
                    return Err(format!("unknown policy '{}'", pol));
                }
                cmd.chain_spec.policy = pol;
                cmd.chain_spec.has_policy = true;
                self.matches(";");
            } else if self.matches("comment") {
                // Chain-level comment: `comment "text"` inside the chain body.
                if !self.at_end() && self.peek() != ";" {
                    let c = self.parse_name();
                    self.set_comment(cmd, c);
                }
                self.matches(";");
            } else {
                // A rule statement: parse expressions into a deferred
                // rule command, the same way declarative table bodies do.
                let mut rcmd = Command::default();
                rcmd.op = CmdOp::Add;
                rcmd.obj = CmdObj::Rule;
                rcmd.family = cmd.family;
                rcmd.table = cmd.table.clone();
                rcmd.chain = cmd.chain.clone();
                self.parse_rule_exprs(&mut rcmd);
                self.matches(";");
                if !rcmd.exprs.is_empty() || rcmd.has_comment {
                    self.pending_commands.push(rcmd);
                }
            }
        }
        self.matches("}");
        Ok(())
    }

    /// Resolve a two-token `<family> <field>` selector (or a single
    /// meta keyword) to `(type_name, type_id, byte_len)`.
    fn resolve_selector(&self, sel0: &str, sel1: &str) -> (String, u32, u32) {
        match (sel0, sel1) {
            ("meta", "l4proto")  => ("inet_proto".into(), 12, 1),
            ("meta", "nfproto")  => ("nf_proto".into(), 2, 1),
            ("meta", "mark")     => ("mark".into(), 15, 4),
            ("meta", "iif") | ("meta", "oif") => ("ifindex".into(), 36, 4),
            ("meta", "iifname") | ("meta", "oifname") => ("ifname".into(), 16, 16),
            ("ip", "saddr") | ("ip", "daddr") => ("ipv4_addr".into(), 7, 4),
            ("ip6", "saddr") | ("ip6", "daddr") => ("ipv6_addr".into(), 8, 16),
            ("ip", "protocol")   => ("inet_proto".into(), 12, 1),
            ("tcp", "dport") | ("tcp", "sport") |
            ("udp", "dport") | ("udp", "sport") |
            ("th", "dport")  | ("th", "sport") => ("inet_service".into(), 13, 2),
            ("ether", "saddr") | ("ether", "daddr") => ("ether_addr".into(), 9, 6),
            ("ct", "state")      => ("ct_state".into(), 27, 4),
            ("ct", "direction")  => ("ct_dir".into(), 28, 1),
            ("ct", "status")     => ("ct_status".into(), 29, 4),
            _ => (format!("{} {}", sel0, sel1), 0, 0),
        }
    }

    /// Parse one or more `.`-separated `typeof` selectors, packing
    /// concat key types via the 6-bit shift-OR dtype_pack scheme.
    /// Returns `(type_name, packed_key_type, total_key_len, slot_widths)`.
    /// `slot_widths` is empty for non-concat selectors.
    fn parse_typeof_selectors(&mut self) -> Result<(String, u32, u32, Vec<u32>), String> {
        // Read first selector (two tokens: `ip saddr`, `meta mark`, etc.)
        let sel0 = self.advance().to_string();
        let sel1 = if !self.at_end()
            && self.peek() != ";" && self.peek() != "}"
            && self.peek() != "." && self.peek() != ":"
        {
            self.advance().to_string()
        } else {
            String::new()
        };
        let (name0, kt0, kl0) = self.resolve_selector(&sel0, &sel1);
        if kt0 == 0 {
            return Ok((name0, 0, 0, Vec::new()));
        }

        // Check for concat: `. <selector> [. <selector> ...]`
        if self.peek() != "." {
            return Ok((name0, kt0, kl0, Vec::new()));
        }
        let mut packed = kt0;
        let mut total_len = (kl0 + 3) & !3; // pad to 4
        let mut widths: Vec<u32> = vec![kl0];
        let mut name_parts = vec![name0];
        while self.peek() == "." {
            self.advance(); // skip "."
            let s0 = self.advance().to_string();
            let s1 = if !self.at_end()
                && self.peek() != ";" && self.peek() != "}"
                && self.peek() != "." && self.peek() != ":"
            {
                self.advance().to_string()
            } else {
                String::new()
            };
            let (n, kt_i, kl_i) = self.resolve_selector(&s0, &s1);
            if kt_i == 0 {
                return Err(format!("unknown typeof selector: {} {}", s0, s1));
            }
            packed = (packed << 6) | kt_i;
            total_len += (kl_i + 3) & !3;
            widths.push(kl_i);
            name_parts.push(n);
        }
        Ok((name_parts.join(" . "), packed, total_len, widths))
    }

    fn parse_set_block(&mut self, cmd: &mut Command) -> Result<(), String> {
        if !self.matches("{") { return Ok(()); }
        while !self.at_end() && self.peek() != "}" {
            if self.matches("typeof") {
                // `typeof <selector> [. <selector> ...]` — set key
                // derived from payload / meta / ct selectors. Concat
                // keys pack each 6-bit type index MSB-first into
                // NFTA_SET_KEY_TYPE, matching upstream dtype_pack.
                let (name, kt, kl, widths) = self.parse_typeof_selectors()?;
                cmd.set_spec.key_type_name = name;
                cmd.set_spec.key_type = kt;
                cmd.set_spec.key_len = kl;
                cmd.set_spec.concat_widths = widths;
                // Optional data type after `:` (maps only).
                if self.peek() == ":" {
                    self.advance();
                    cmd.set_spec.is_map = true;
                    let dt_tok = self.advance().to_string();
                    // Data side can be a typeof selector or a type name.
                    let (dt, dl) = crate::netlink::set_key_type(&dt_tok);
                    cmd.set_spec.data_type_name = dt_tok.clone();
                    cmd.set_spec.data_type = dt;
                    cmd.set_spec.data_len = dl;
                    if dt_tok != "verdict" && crate::netlink::is_obj_type(dt) {
                        cmd.set_spec.is_obj_map = true;
                        cmd.set_spec.obj_type = crate::netlink::obj_type_from_sentinel(dt);
                    }
                }
                self.matches(";");
                continue;
            }
            if self.matches("type") {
                // Concat key: `type T1 . T2 . T3 …` packs each 6-bit type
                // index MSB-first into NFTA_SET_KEY_TYPE (matches upstream
                // datatype.c::dtype_pack). KEY_LEN is the sum of constituent
                // widths, padded up to 4 bytes per slot. Single-type sets
                // (no `.`) bypass the packing path so KEY_LEN stays exact.
                let first_name = self.advance().to_string();
                let (kt0, kl0) = crate::netlink::set_key_type(&first_name);
                if kt0 == 0 && first_name != "invalid_type" {
                    return Err(format!("unknown datatype {}", first_name));
                }
                let (final_type_name, kt, kl) = if self.peek() == "." {
                    // Concat: pack subsequent types into the same u32.
                    let mut packed: u32 = kt0;
                    let mut total_len: u32 = (kl0 + 3) & !3; // pad to 4
                    let mut name_parts: Vec<String> = vec![first_name];
                    while self.peek() == "." {
                        self.advance();
                        let n = self.advance().to_string();
                        let (kt_i, kl_i) = crate::netlink::set_key_type(&n);
                        if kt_i == 0 && n != "invalid_type" {
                            return Err(format!("unknown datatype {}", n));
                        }
                        // dtype_pack: shift current packed left 6 bits, OR new id.
                        packed = (packed << 6) | kt_i;
                        total_len += (kl_i + 3) & !3;
                        name_parts.push(n);
                    }
                    (name_parts.join(" . "), packed, total_len)
                } else {
                    (first_name, kt0, kl0)
                };
                cmd.set_spec.key_type_name = final_type_name;
                cmd.set_spec.key_type = kt;
                cmd.set_spec.key_len = kl;
                if self.peek() == ":" {
                    // Colon (data type) is only valid for maps, not sets
                    if !matches!(cmd.obj, CmdObj::Map) {
                        return Err("syntax error, unexpected colon, expecting newline or semicolon".into());
                    }
                    self.advance();
                    cmd.set_spec.is_map = true;
                    let dt_name = self.advance().to_string();
                    let (dt, dl) = crate::netlink::set_key_type(&dt_name);
                    if dt == 0 && dt_name != "invalid_type" && dt_name != "verdict" {
                        return Err(format!("unknown datatype {}", dt_name));
                    }
                    cmd.set_spec.data_type_name = dt_name.clone();
                    cmd.set_spec.data_type = dt;
                    cmd.set_spec.data_len = dl;
                    // Mark object-reference maps so add_set sends the right flags.
                    // Exclude verdict (0xffffff00) — it has the high bit set
                    // like object sentinels but is a data-type sentinel.
                    if dt_name != "verdict" && crate::netlink::is_obj_type(dt) {
                        cmd.set_spec.is_obj_map = true;
                        cmd.set_spec.obj_type = crate::netlink::obj_type_from_sentinel(dt);
                    }
                }
                self.matches(";");
            } else if self.matches("flags") {
                cmd.set_spec.has_flags = true;
                while !self.at_end() && self.peek() != ";" {
                    match self.peek() {
                        "constant" => { cmd.set_spec.flags |= 0x2; self.advance(); }
                        "interval" => { cmd.set_spec.flags |= 0x4; self.advance(); }
                        "timeout"  => { cmd.set_spec.flags |= NFT_SET_TIMEOUT; self.advance(); }
                        "dynamic"  => { cmd.set_spec.flags |= NFT_SET_EVAL; self.advance(); }
                        "," => { self.advance(); }
                        _ => { self.advance(); }
                    }
                }
                self.matches(";");
            } else if self.matches("size") {
                if let Ok(n) = self.peek().parse::<u32>() {
                    cmd.set_spec.size = n;
                    self.advance();
                }
                self.matches(";");
            } else if self.matches("timeout") {
                cmd.set_spec.timeout_ms = parse_duration_ms(self.advance());
                cmd.set_spec.has_timeout = true;
                self.matches(";");
            } else if self.matches("comment") {
                // Set-level comment: `comment "text"` inside the set body.
                if !self.at_end() && self.peek() != ";" {
                    let c = self.parse_name();
                    self.set_comment(cmd, c);
                }
                self.matches(";");
            } else if self.matches("elements") {
                // Inline elements in CLI mode: `add set ... { type inet_service ;
                // elements = { 80, 443 } ; }`. Emit them as cmd.elements so
                // exec_add can create a follow-up NEWSETELEM.
                self.matches("=");
                self.parse_element_block(cmd);
                self.matches(";");
            } else if self.matches("auto-merge") {
                // Recognised but not acted on — skip to prevent the
                // fallback `advance()` from eating a following keyword.
                self.matches(";");
            } else if self.matches(";") {
            } else { self.advance(); }
        }
        self.matches("}");
        Ok(())
    }

    fn parse_element_block(&mut self, cmd: &mut Command) {
        if !self.matches("{") { return; }
        // For sets whose key is the layer-4 protocol byte (typeof
        // meta l4proto / type inet_proto), the element list uses
        // protocol *names* (`tcp`, `udp`, ...) which we need to
        // translate to their IANA numbers. inet_proto = 12 in our
        // datatype tables.
        let key_is_inet_proto = cmd.set_spec.key_type == 12 && cmd.set_spec.key_len == 1;
        while !self.at_end() && self.peek() != "}" {
            // Newlines tokenise to `;`; inside an element list they
            // are just whitespace, so skip along with `,`.
            if self.peek() == "," || self.peek() == ";" { self.advance(); continue; }
            let tok = self.advance().to_string();

            // Resolve `tcp` / `udp` / `icmp` / ... when the set key
            // is inet_proto (typeof meta l4proto). Falls through if
            // the name isn't a known protocol so the regular numeric
            // / string paths still see it.
            if key_is_inet_proto {
                if let Some(n) = proto_num(&tok) {
                    cmd.elements.push((vec![n], None));
                    self.consume_element_timeout(cmd);
                    self.consume_element_comment(cmd);
                    continue;
                }
            }

            // CIDR first — an interval-set element written as
            // `1.1.1.0/24` expands to the range [1.1.1.0, 1.1.1.255]
            // so add_elements' INTERVAL_END expansion works. Not
            // special-cased for plain sets: a CIDR in a non-interval
            // set is a user error and the kernel will reject it.
            if let Some(slash) = tok.find('/') {
                let addr_part = &tok[..slash];
                let prefix_part = &tok[slash + 1..];
                if let (Some(addr), Ok(prefix)) = (Self::parse_ipv4(addr_part), prefix_part.parse::<u32>()) {
                    let prefix = prefix.min(32);
                    let base = u32::from_be_bytes(addr);
                    let host_mask = if prefix == 32 { 0u32 } else { (1u32 << (32 - prefix)) - 1 };
                    let start = base & !host_mask;
                    let end = start | host_mask;
                    cmd.elements.push((
                        start.to_be_bytes().to_vec(),
                        Some(end.to_be_bytes().to_vec()),
                    ));
                    self.consume_element_timeout(cmd);
                    self.consume_element_comment(cmd);
                    if self.peek() == ":" { self.parse_element_value(cmd); }
                    continue;
                }
                if let (Some(addr), Ok(prefix)) = (Self::parse_ipv6(addr_part), prefix_part.parse::<u32>()) {
                    let prefix = prefix.min(128);
                    let base = u128::from_be_bytes(addr);
                    let host_mask: u128 = if prefix == 128 { 0 } else { (1u128 << (128 - prefix)) - 1 };
                    let start = base & !host_mask;
                    let end = start | host_mask;
                    cmd.elements.push((
                        start.to_be_bytes().to_vec(),
                        Some(end.to_be_bytes().to_vec()),
                    ));
                    self.consume_element_timeout(cmd);
                    self.consume_element_comment(cmd);
                    if self.peek() == ":" { self.parse_element_value(cmd); }
                    continue;
                }
            }

            // Try address / port first so we can peek for a following `-`
            // which indicates a range. IPv6 comes first because it'd also
            // be reflected in parse_ipv4 failures — any unambiguous IPv6
            // representation (with `::` or >3 colons) parses cleanly here.
            let start: Option<Vec<u8>> = if let Some(addr) = Self::parse_ipv6(&tok) {
                Some(addr.to_vec())
            } else if let Some(addr) = Self::parse_ipv4(&tok) {
                Some(addr.to_vec())
            } else if let Some(mac) = parse_mac(&tok) {
                // Ether-addr typed sets: `add element bridge filter
                // blocked_macs { aa:bb:cc:dd:ee:ff }`. Without this
                // path the MAC falls through to the string fallback
                // and ends up as the literal ASCII bytes, so the
                // kernel's set lookup never matches the actual MAC
                // it gets from the bridge frame.
                Some(mac.to_vec())
            } else if let Ok(n) = tok.parse::<u32>() {
                Some(n.to_be_bytes().to_vec())
            } else {
                None
            };

            if let Some(s) = start {
                let end = if self.peek() == "-" {
                    self.advance();
                    let end_tok = self.advance().to_string();
                    Self::parse_ipv6(&end_tok).map(|a| a.to_vec())
                        .or_else(|| Self::parse_ipv4(&end_tok).map(|a| a.to_vec()))
                        .or_else(|| end_tok.parse::<u32>().ok().map(|n| n.to_be_bytes().to_vec()))
                } else { None };
                // Concat: `. <val> [- <val>] [. ...]` — concatenate
                // subsequent slot values, padding each to 4 bytes.
                // Use concat_widths to encode each slot in its
                // natural width (e.g. u16 for ports) before padding.
                if self.peek() == "." {
                    let cw = &cmd.set_spec.concat_widths;
                    let mut key = Self::pad4(s);
                    let mut key_end: Option<Vec<u8>> = end.map(Self::pad4);
                    let mut slot = 1usize;
                    while self.peek() == "." {
                        self.advance();
                        let ct = self.advance().to_string();
                        let w = cw.get(slot).copied().unwrap_or(4);
                        let cv = Self::parse_one_element_w(&ct, w);
                        let ce = if self.peek() == "-" {
                            self.advance();
                            let et = self.advance().to_string();
                            Some(Self::parse_one_element_w(&et, w))
                        } else { None };
                        key.extend_from_slice(&Self::pad4(cv));
                        if let Some(ref mut ke) = key_end {
                            ke.extend_from_slice(&Self::pad4(ce.unwrap_or_else(|| ke[ke.len()-4..].to_vec())));
                        } else if let Some(cev) = ce {
                            let mut backfill = key[..key.len()-4].to_vec();
                            backfill.extend_from_slice(&Self::pad4(cev));
                            key_end = Some(backfill);
                        }
                        slot += 1;
                    }
                    cmd.elements.push((key, key_end));
                } else {
                    cmd.elements.push((s, end));
                }
                self.consume_element_timeout(cmd);
                self.consume_element_comment(cmd);
                if self.peek() == ":" { self.parse_element_value(cmd); }
                continue;
            }

            // String element (interface name, etc.) — no range semantics.
            let raw = if tok.starts_with('"') && tok.ends_with('"') && tok.len() >= 2 {
                &tok[1..tok.len()-1]
            } else { tok.as_str() };
            let mut v = raw.as_bytes().to_vec();
            v.push(0);
            // Concat: `. <val> ...` after a string element.
            if self.peek() == "." {
                let mut key = Self::pad4(v);
                while self.peek() == "." {
                    self.advance();
                    let ct = self.advance().to_string();
                    let cv = Self::parse_one_element(&ct);
                    key.extend_from_slice(&Self::pad4(cv));
                }
                cmd.elements.push((key, None));
            } else {
                cmd.elements.push((v, None));
            }
            self.consume_element_timeout(cmd);
            self.consume_element_comment(cmd);
            if self.peek() == ":" { self.parse_element_value(cmd); }
        }
        self.matches("}");
    }

    /// Consume an optional `timeout <duration>` after a parsed element key
    /// and stash the resulting milliseconds in `cmd.element_timeouts`,
    /// padded with zeros for any prior keyless elements so the index
    /// stays parallel to `cmd.elements`. Pure no-op when the next token
    /// isn't `timeout`.
    fn consume_element_timeout(&mut self, cmd: &mut Command) {
        let target = cmd.elements.len();
        let mut ms: u64 = 0;
        if self.matches("timeout") {
            ms = parse_duration_ms(self.advance());
        }
        while cmd.element_timeouts.len() + 1 < target {
            cmd.element_timeouts.push(0);
        }
        cmd.element_timeouts.push(ms);
    }

    /// Consume an optional `comment "text"` after a parsed element key
    /// (and any optional timeout) and stash the string in
    /// `cmd.element_comments`, padded with None for any prior keyless
    /// elements so the index stays parallel to `cmd.elements`.
    /// Pure no-op when the next token isn't `comment`.
    fn consume_element_comment(&mut self, cmd: &mut Command) {
        let target = cmd.elements.len();
        let cmt = if self.matches("comment") {
            if !self.at_end() && self.peek() != ";" && self.peek() != "," && self.peek() != "}" {
                Some(self.parse_name())
            } else {
                Some(String::new())
            }
        } else {
            None
        };
        while cmd.element_comments.len() + 1 < target {
            cmd.element_comments.push(None);
        }
        cmd.element_comments.push(cmt);
    }

    /// After a `key :`, either a verdict keyword (accept/drop/jump...)
    /// or a data value (ipv4/ipv6/integer/string) follows. For
    /// verdicts the parsed `(code, chain)` goes to element_verdicts
    /// and None is pushed into element_datas so indexes stay aligned.
    /// For data values the raw bytes go to element_datas and a
    /// stub entry (0, "") goes into element_verdicts.
    fn parse_element_value(&mut self, cmd: &mut Command) {
        self.advance(); // ":"
        let v = self.peek().to_string();
        match v.as_str() {
            "accept" | "drop" | "return" | "continue" | "jump" | "goto" => {
                let t = self.advance().to_string();
                let (code, chain) = match t.as_str() {
                    "accept" => (NF_ACCEPT, String::new()),
                    "drop" => (NF_DROP, String::new()),
                    "return" => (NFT_RETURN, String::new()),
                    "continue" => (NFT_CONTINUE, String::new()),
                    "jump" => (NFT_JUMP, self.advance().to_string()),
                    "goto" => (NFT_GOTO, self.advance().to_string()),
                    _ => (NF_ACCEPT, String::new()),
                };
                cmd.element_verdicts.push((code, chain));
                cmd.element_datas.push(None);
                cmd.element_objrefs.push(None);
            }
            _ => {
                let t = self.advance().to_string();
                // Bare identifiers that are not IPs or integers are
                // object-reference names (e.g. `add element m { 1 : c1 }`
                // for `type ipv4_addr : counter` maps).
                let is_identifier = !t.starts_with('"')
                    && t.chars().next().map_or(false, |c| c.is_ascii_alphabetic() || c == '_')
                    && Self::parse_ipv4(&t).is_none()
                    && t.parse::<u32>().is_err();
                if is_identifier {
                    // A bare identifier after `:` in a verdict map is an
                    // invalid verdict keyword (e.g. `192.168.0.1 : ber` where
                    // `ber` is not accept/drop/jump/goto/return/continue).
                    // Reject it rather than silently treating it as an objref.
                    if cmd.set_spec.data_type_name == "verdict" {
                        self.deferred_errors.push(format!(
                            "syntax error, invalid verdict '{}'", t));
                        cmd.element_verdicts.push((0, String::new()));
                        cmd.element_datas.push(None);
                        cmd.element_objrefs.push(None);
                    } else {
                    cmd.element_verdicts.push((0, String::new()));
                    cmd.element_datas.push(None);
                    cmd.element_objrefs.push(Some(t));
                    }
                } else {
                    let bytes = if let Some(a) = Self::parse_ipv4(&t) {
                        Some(a.to_vec())
                    } else if let Ok(n) = t.parse::<u32>() {
                        Some(n.to_be_bytes().to_vec())
                    } else if t.starts_with('"') && t.ends_with('"') && t.len() >= 2 {
                        // Try TC classid handle first (`"1:0xc7cb"` style).
                        if let Some(tc) = Self::parse_tc_handle(&t) {
                            Some(tc)
                        } else {
                            // Fall back to interface-name string: strip quotes,
                            // NUL-terminate, and pad to 16 bytes.
                            let mut v = t[1..t.len()-1].as_bytes().to_vec();
                            v.push(0);
                            while v.len() < 16 { v.push(0); }
                            Some(v)
                        }
                    } else { None };
                    cmd.element_verdicts.push((0, String::new()));
                    cmd.element_datas.push(bytes);
                    cmd.element_objrefs.push(None);
                }
            }
        }
    }

    /// Try to parse a TC classid handle of the form `major:minor` where
    /// both parts are hexadecimal.  The input may be bare (`1:bbf8`) or
    /// double-quoted (`"1:0xc7cb"`).  Returns the 4-byte host-endian
    /// encoding on success, or None if the string does not look like a
    /// TC handle.
    pub fn parse_tc_handle(s: &str) -> Option<Vec<u8>> {
        // Strip surrounding double-quotes if present (parser keeps them).
        let s = if s.starts_with('"') && s.ends_with('"') && s.len() >= 2 {
            &s[1..s.len() - 1]
        } else {
            s
        };
        let colon = s.find(':')?;
        let major_s = s[..colon].trim();
        let minor_s = s[colon + 1..].trim()
            .trim_start_matches("0x").trim_start_matches("0X");
        // Require both parts to be non-empty and purely hexadecimal.
        if major_s.is_empty() || minor_s.is_empty() { return None; }
        if !major_s.chars().all(|c| c.is_ascii_hexdigit()) { return None; }
        if !minor_s.chars().all(|c| c.is_ascii_hexdigit()) { return None; }
        let major = u32::from_str_radix(major_s, 16).ok()?;
        let minor = u32::from_str_radix(minor_s, 16).ok()?;
        let handle: u32 = (major << 16) | minor;
        // Classid is host-endian in the kernel.
        Some(handle.to_ne_bytes().to_vec())
    }

    /// Parse the body of `add counter/quota/limit name { ... }`. Each
    /// object kind has its own keyword set; we dispatch on
    /// `cmd.obj_spec.kind` (already set by the caller). Unknown tokens
    /// inside the block are skipped so mismatched listings don't abort.
    fn parse_object_block(&mut self, cmd: &mut Command) {
        if !self.matches("{") { return; }
        while !self.at_end() && self.peek() != "}" {
            // Comment on any named object: `comment "text"`.
            // Handled first so kind-specific blocks don't consume it.
            if self.peek() == "comment" {
                self.advance();
                if !self.at_end() && self.peek() != ";" {
                    let c = self.parse_name();
                    self.set_comment(cmd, c);
                }
                self.matches(";");
                continue;
            }
            // ct helper body:  { type "ftp" protocol tcp ; l3proto ip ; }
            // The `type` keyword in this context names the kernel helper
            // module, not a chain hook type — dispatch on cmd.obj_spec.kind
            // so it doesn't clash with the chain block's `type filter ...`.
            if cmd.obj_spec.kind == NFT_OBJECT_CT_HELPER {
                match self.peek() {
                    ";" => { self.advance(); continue; }
                    "type" => {
                        self.advance();
                        cmd.obj_spec.helper_type = self.parse_name();
                        // `protocol tcp` may follow on the same line
                        // without a `;` separator.
                        if self.peek() == "protocol" {
                            self.advance();
                            cmd.obj_spec.helper_l4proto = match self.peek() {
                                "tcp"  => 6,
                                "udp"  => 17,
                                "dccp" => 33,
                                "sctp" => 132,
                                _      => 0,
                            };
                            self.advance();
                        }
                        self.matches(";");
                        continue;
                    }
                    "protocol" => {
                        self.advance();
                        cmd.obj_spec.helper_l4proto = match self.peek() {
                            "tcp"  => 6,
                            "udp"  => 17,
                            "dccp" => 33,
                            "sctp" => 132,
                            _      => 0,
                        };
                        self.advance();
                        self.matches(";");
                        continue;
                    }
                    "l3proto" => {
                        self.advance();
                        let f = match self.peek() {
                            "ip"   => 2,    // NFPROTO_IPV4
                            "ip6"  => 10,   // NFPROTO_IPV6
                            "inet" => 1,    // NFPROTO_INET
                            _      => 0,
                        };
                        self.advance();
                        cmd.obj_spec.helper_l3proto = f;
                        cmd.obj_spec.has_helper_l3proto = true;
                        self.matches(";");
                        continue;
                    }
                    _ => { self.advance(); continue; }
                }
            }
            // ct timeout body:
            //   protocol tcp ; l3proto ip ;
            //   policy = { syn_sent : 120s, established : 432000s, ... }
            if cmd.obj_spec.kind == NFT_OBJECT_CT_TIMEOUT {
                match self.peek() {
                    ";" => { self.advance(); continue; }
                    "protocol" => {
                        self.advance();
                        cmd.obj_spec.ct_timeout_l4proto = match self.peek() {
                            "tcp"  => 6,
                            "udp"  => 17,
                            "dccp" => 33,
                            "sctp" => 132,
                            _      => 0,
                        };
                        self.advance();
                        self.matches(";");
                        continue;
                    }
                    "l3proto" => {
                        self.advance();
                        cmd.obj_spec.ct_timeout_l3proto = match self.peek() {
                            "ip"   => 2,
                            "ip6"  => 10,
                            "inet" => 1,
                            _      => 0,
                        };
                        cmd.obj_spec.has_ct_timeout_l3proto = true;
                        self.advance();
                        self.matches(";");
                        continue;
                    }
                    "policy" => {
                        self.advance();
                        self.matches("=");
                        if self.matches("{") {
                            while !self.at_end() && self.peek() != "}" {
                                if matches!(self.peek(), "," | ";") { self.advance(); continue; }
                                let state = self.advance().to_string();
                                self.matches(":");
                                let dur_tok = self.advance().to_string();
                                let secs = (parse_duration_ms(&dur_tok) / 1000) as u32;
                                cmd.obj_spec.ct_timeout_policy.push((state, secs));
                            }
                            self.matches("}");
                        }
                        self.matches(";");
                        continue;
                    }
                    _ => { self.advance(); continue; }
                }
            }
            // ct expectation body:
            //   protocol tcp ; dport 5432 ; timeout 1h ; size 12 ; l3proto ip ;
            if cmd.obj_spec.kind == NFT_OBJECT_CT_EXPECT {
                match self.peek() {
                    ";" => { self.advance(); continue; }
                    "protocol" => {
                        self.advance();
                        cmd.obj_spec.ct_expect_protocol = match self.peek() {
                            "tcp"  => 6,
                            "udp"  => 17,
                            "dccp" => 33,
                            "sctp" => 132,
                            _      => 0,
                        };
                        self.advance();
                        self.matches(";");
                        continue;
                    }
                    "dport" => {
                        self.advance();
                        if let Ok(n) = self.advance().parse::<u16>() {
                            cmd.obj_spec.ct_expect_dport = n;
                        }
                        self.matches(";");
                        continue;
                    }
                    "timeout" => {
                        self.advance();
                        let dur_tok = self.advance().to_string();
                        cmd.obj_spec.ct_expect_timeout = parse_duration_ms(&dur_tok) as u32;
                        self.matches(";");
                        continue;
                    }
                    "size" => {
                        self.advance();
                        if let Ok(n) = self.advance().parse::<u8>() {
                            cmd.obj_spec.ct_expect_size = n;
                        }
                        self.matches(";");
                        continue;
                    }
                    "l3proto" => {
                        self.advance();
                        cmd.obj_spec.ct_expect_l3proto = match self.peek() {
                            "ip"   => 2,
                            "ip6"  => 10,
                            "inet" => 1,
                            _      => 0,
                        };
                        self.advance();
                        self.matches(";");
                        continue;
                    }
                    _ => { self.advance(); continue; }
                }
            }
            // Synproxy body:
            //   mss 1460; wscale 7; timestamp sack-perm;
            if cmd.obj_spec.kind == NFT_OBJECT_SYNPROXY {
                match self.peek() {
                    ";" => { self.advance(); continue; }
                    "mss" => {
                        self.advance();
                        if let Ok(n) = self.advance().parse::<u16>() {
                            cmd.obj_spec.synproxy_mss = n;
                            cmd.obj_spec.synproxy_flags |= 0x01; // OPT_MSS
                        }
                        self.matches(";");
                        continue;
                    }
                    "wscale" => {
                        self.advance();
                        if let Ok(n) = self.advance().parse::<u8>() {
                            cmd.obj_spec.synproxy_wscale = n;
                            cmd.obj_spec.synproxy_flags |= 0x02; // OPT_WSCALE
                        }
                        self.matches(";");
                        continue;
                    }
                    "timestamp" => {
                        self.advance();
                        cmd.obj_spec.synproxy_flags |= 0x08; // OPT_TIMESTAMP
                        // `sack-perm` may follow on the same line.
                        if self.peek() == "sack-perm" {
                            self.advance();
                            cmd.obj_spec.synproxy_flags |= 0x04; // OPT_SACK_PERM
                        }
                        self.matches(";");
                        continue;
                    }
                    "sack-perm" => {
                        self.advance();
                        cmd.obj_spec.synproxy_flags |= 0x04;
                        self.matches(";");
                        continue;
                    }
                    _ => { self.advance(); continue; }
                }
            }
            // Secmark body:
            //   "system_u:object_r:ssh_server_packet_t:s0";
            if cmd.obj_spec.kind == NFT_OBJECT_SECMARK {
                match self.peek() {
                    ";" => { self.advance(); continue; }
                    _ => {
                        let tok = self.advance().to_string();
                        if tok.starts_with('"') && tok.ends_with('"') && tok.len() >= 2 {
                            cmd.obj_spec.secmark_ctx = tok[1..tok.len()-1].to_string();
                        } else if !tok.is_empty() {
                            cmd.obj_spec.secmark_ctx = tok;
                        }
                        self.matches(";");
                        continue;
                    }
                }
            }
            // Tunnel body:
            //   id 10; ip saddr 192.168.2.10; ip daddr 192.168.2.11;
            //   sport 10; dport 10; tos 10; ttl 10;
            //   geneve { class 0x1 opt-type 0x1 data "0x12345678" }
            //   vxlan { gbp 200 }
            //   erspan { version 1 index 5 }
            //   erspan { version 2 direction ingress id 10 }
            if cmd.obj_spec.kind == NFT_OBJECT_TUNNEL {
                match self.peek() {
                    ";" => { self.advance(); continue; }
                    "id" => {
                        self.advance();
                        cmd.obj_spec.tunnel_id = self.advance().parse().unwrap_or(0);
                        self.matches(";");
                        continue;
                    }
                    "ip" => {
                        self.advance();
                        match self.peek() {
                            "saddr" => {
                                self.advance();
                                let tok = self.advance().to_string();
                                if let Some(a) = Self::parse_ipv4(&tok) {
                                    cmd.obj_spec.tunnel_src_v4 = a;
                                }
                            }
                            "daddr" => {
                                self.advance();
                                let tok = self.advance().to_string();
                                if let Some(a) = Self::parse_ipv4(&tok) {
                                    cmd.obj_spec.tunnel_dst_v4 = a;
                                }
                            }
                            _ => { self.advance(); }
                        }
                        self.matches(";");
                        continue;
                    }
                    "ip6" => {
                        self.advance();
                        match self.peek() {
                            "saddr" => {
                                self.advance();
                                let tok = self.advance().to_string();
                                if let Some(a) = Self::parse_ipv6(&tok) {
                                    cmd.obj_spec.tunnel_src_v6 = a;
                                    cmd.obj_spec.tunnel_is_v6 = true;
                                }
                            }
                            "daddr" => {
                                self.advance();
                                let tok = self.advance().to_string();
                                if let Some(a) = Self::parse_ipv6(&tok) {
                                    cmd.obj_spec.tunnel_dst_v6 = a;
                                    cmd.obj_spec.tunnel_is_v6 = true;
                                }
                            }
                            _ => { self.advance(); }
                        }
                        self.matches(";");
                        continue;
                    }
                    "sport" => {
                        self.advance();
                        cmd.obj_spec.tunnel_sport = self.advance().parse().unwrap_or(0);
                        self.matches(";");
                        continue;
                    }
                    "dport" => {
                        self.advance();
                        cmd.obj_spec.tunnel_dport = self.advance().parse().unwrap_or(0);
                        self.matches(";");
                        continue;
                    }
                    "tos" => {
                        self.advance();
                        cmd.obj_spec.tunnel_tos = self.advance().parse().unwrap_or(0);
                        self.matches(";");
                        continue;
                    }
                    "ttl" => {
                        self.advance();
                        cmd.obj_spec.tunnel_ttl = self.advance().parse().unwrap_or(0);
                        self.matches(";");
                        continue;
                    }
                    "geneve" => {
                        self.advance();
                        let mut tlvs: Vec<GeneveTlv> = Vec::new();
                        if self.matches("{") {
                            while !self.at_end() && self.peek() != "}" {
                                if self.peek() == ";" { self.advance(); continue; }
                                // Each TLV line: class 0x1 opt-type 0x1 data "0x12345678"
                                if self.peek() == "class" {
                                    self.advance();
                                    let class_tok = self.advance().to_string();
                                    let class = parse_hex_or_dec_u16(&class_tok);
                                    self.matches("opt-type");
                                    let type_tok = self.advance().to_string();
                                    let opt_type = parse_hex_or_dec_u8(&type_tok);
                                    self.matches("data");
                                    let data_tok = self.advance().to_string();
                                    let data = parse_hex_string(&data_tok);
                                    tlvs.push(GeneveTlv { class, opt_type, data });
                                } else {
                                    self.advance();
                                }
                            }
                            self.matches("}");
                        }
                        cmd.obj_spec.tunnel_opts = TunnelOpts::Geneve { tlvs };
                        self.matches(";");
                        continue;
                    }
                    "vxlan" => {
                        self.advance();
                        let mut gbp = 0u32;
                        if self.matches("{") {
                            while !self.at_end() && self.peek() != "}" {
                                if self.peek() == ";" { self.advance(); continue; }
                                if self.peek() == "gbp" {
                                    self.advance();
                                    gbp = self.advance().parse().unwrap_or(0);
                                } else {
                                    self.advance();
                                }
                            }
                            self.matches("}");
                        }
                        cmd.obj_spec.tunnel_opts = TunnelOpts::Vxlan { gbp };
                        self.matches(";");
                        continue;
                    }
                    "erspan" => {
                        self.advance();
                        let mut version = 0u32;
                        let mut index = 0u32;
                        let mut hwid = 0u8;
                        let mut dir = 0u8;
                        if self.matches("{") {
                            while !self.at_end() && self.peek() != "}" {
                                if self.peek() == ";" { self.advance(); continue; }
                                match self.peek() {
                                    "version" => {
                                        self.advance();
                                        version = self.advance().parse().unwrap_or(0);
                                    }
                                    "index" => {
                                        self.advance();
                                        index = self.advance().parse().unwrap_or(0);
                                    }
                                    "direction" => {
                                        self.advance();
                                        let dtok = self.advance().to_string();
                                        dir = if dtok == "egress" { 1 } else { 0 };
                                    }
                                    "id" => {
                                        self.advance();
                                        hwid = self.advance().parse().unwrap_or(0);
                                    }
                                    _ => { self.advance(); }
                                }
                            }
                            self.matches("}");
                        }
                        cmd.obj_spec.tunnel_opts = if version == 2 {
                            TunnelOpts::ErspanV2 { hwid, dir }
                        } else {
                            TunnelOpts::ErspanV1 { index }
                        };
                        self.matches(";");
                        continue;
                    }
                    _ => { self.advance(); continue; }
                }
            }
            // Quota body can start with a bare number + unit:
            //   quota q { 25 mbytes }
            if cmd.obj_spec.kind == NFT_OBJECT_QUOTA {
                if let Ok(n) = self.peek().parse::<u64>() {
                    self.advance();
                    let mul = match self.peek() {
                        "bytes"  => 1u64,
                        "kbytes" => 1024,
                        "mbytes" => 1024 * 1024,
                        "gbytes" => 1024 * 1024 * 1024,
                        _        => 1,
                    };
                    if matches!(self.peek(), "bytes" | "kbytes" | "mbytes" | "gbytes") {
                        self.advance();
                    }
                    cmd.obj_spec.bytes = n * mul;
                    // Optional `used N {unit}` — the amount already
                    // accounted for, reported back by `list quota`.
                    if self.peek() == "used" {
                        self.advance();
                        let used: u64 = self.advance().parse().unwrap_or(0);
                        let umul: u64 = match self.peek() {
                            "kbytes" => { self.advance(); 1 << 10 }
                            "mbytes" => { self.advance(); 1 << 20 }
                            "gbytes" => { self.advance(); 1 << 30 }
                            "bytes"  => { self.advance(); 1 }
                            _ => 1,
                        };
                        cmd.obj_spec.quota_consumed = used * umul;
                    }
                    continue;
                }
            }
            match self.peek() {
                ";" => { self.advance(); }
                "packets" => {
                    self.advance();
                    if let Ok(n) = self.advance().parse::<u64>() {
                        if cmd.obj_spec.kind == NFT_OBJECT_LIMIT {
                            cmd.obj_spec.limit_type = 0; // NFT_LIMIT_PKTS
                        } else {
                            cmd.obj_spec.packets = n;
                        }
                    }
                }
                "bytes" => {
                    self.advance();
                    if let Ok(n) = self.advance().parse::<u64>() {
                        cmd.obj_spec.bytes = n;
                    }
                }
                "over" => {
                    self.advance();
                    cmd.obj_spec.quota_flags |= NFT_QUOTA_F_INV;
                    // `over N bytes` — consume the number + unit.
                    if let Ok(n) = self.advance().parse::<u64>() { cmd.obj_spec.bytes = n; }
                    if matches!(self.peek(), "bytes" | "kbytes" | "mbytes" | "gbytes") { self.advance(); }
                }
                "rate" => {
                    self.advance();
                    // optional `over` invert
                    if self.peek() == "over" { self.advance(); cmd.obj_spec.limit_flags |= 1; }
                    // `rate` value can arrive as either a bare number
                    // followed by `/` + unit, or as a single word like
                    // `10/second` (the tokenizer doesn't split on `/`
                    // because `/` is used by CIDR). Handle both.
                    let tok = self.advance().to_string();
                    if let Some(slash) = tok.find('/') {
                        cmd.obj_spec.limit_rate = tok[..slash].parse::<u64>().unwrap_or(0);
                        cmd.obj_spec.limit_unit = match &tok[slash + 1..] {
                            "second" => 1, "minute" => 60, "hour" => 3600,
                            "day" => 86400, "week" => 604800, _ => 1,
                        };
                    } else if let Ok(n) = tok.parse::<u64>() {
                        cmd.obj_spec.limit_rate = n;
                        if self.peek() == "/" {
                            self.advance();
                            cmd.obj_spec.limit_unit = match self.advance() {
                                "second" => 1, "minute" => 60, "hour" => 3600,
                                "day" => 86400, "week" => 604800, _ => 1,
                            };
                        } else {
                            cmd.obj_spec.limit_unit = 1;
                        }
                    }
                }
                "burst" => {
                    self.advance();
                    if let Ok(n) = self.advance().parse::<u32>() {
                        cmd.obj_spec.limit_burst = n;
                    }
                    if matches!(self.peek(), "packets" | "bytes") { self.advance(); }
                }
                _ => { self.advance(); }
            }
        }
        self.matches("}");
    }

    /// Parse the body of `add flowtable t ft { ... }`. Recognised lines:
    ///   hook <name> [priority <N|keyword>]    — required
    ///   devices = { dev1, dev2, ... }         — required (one or more)
    ///   flags offload                         — optional
    /// Stops on `}`. Unknown attributes are consumed up to the next ; so
    /// stray text doesn't desync the outer parser.
    fn parse_flowtable_block(&mut self, cmd: &mut Command) {
        if !self.matches("{") { return; }
        let family = cmd.family;
        while !self.at_end() && self.peek() != "}" {
            while self.matches(";") {}
            if self.peek() == "}" { break; }
            match self.peek() {
                "hook" => {
                    self.advance();
                    cmd.flow_spec.hook = self.parse_name();
                    // `hook X` must be immediately followed by `priority Y`
                    // on the same statement. Upstream's grammar makes
                    // `hook ingress; priority 10` invalid because the
                    // semicolon ends the statement before priority can
                    // attach. Reject the same way so that
                    // `nft -c add flowtable …` correctly fails on this
                    // shape.
                    if self.peek() != "priority" {
                        self.deferred_errors.push(
                            "missing priority in flowtable declaration".into());
                    } else {
                        self.advance();
                        // Flowtables only accept "filter" as a named
                        // priority (or bare integers / "filter + N").
                        // Named priorities like "raw", "mangle", etc.
                        // are NOT valid for flowtables.
                        let peek = self.peek().to_string();
                        let bare_name = peek.split_whitespace().next().unwrap_or("");
                        if matches!(bare_name, "raw" | "mangle" | "dstnat" | "dstnar"
                            | "security" | "srcnat" | "out" | "dummy")
                        {
                            self.deferred_errors.push(format!(
                                "unknown priority '{}'", bare_name));
                            self.advance();
                        } else if let Ok(p) = self.parse_priority_ctx(family, "filter", &cmd.flow_spec.hook) {
                            cmd.flow_spec.priority = p;
                            cmd.flow_spec.has_priority = true;
                        }
                    }
                    // Each statement inside a flowtable block must be
                    // terminated by `;` (or a newline, which the tokenizer
                    // converts to `;`). Real nft rejects forms where `}`
                    // immediately follows a statement without a separator.
                    if !self.matches(";") && self.deferred_errors.is_empty() {
                        self.deferred_errors.push(
                            "syntax error, unexpected '}', expecting newline or semicolon".into());
                    }
                }
                "devices" => {
                    self.advance();
                    self.matches("=");
                    if self.matches("{") {
                        while !self.at_end() && self.peek() != "}" {
                            if self.peek() == "," { self.advance(); continue; }
                            let t = self.advance().to_string();
                            // Strip optional surrounding quotes — nft
                            // accepts both `lo` and `"lo"` here, so we
                            // canonicalise to bare.
                            let dev = if t.starts_with('"') && t.ends_with('"') && t.len() >= 2 {
                                t[1..t.len() - 1].to_string()
                            } else { t };
                            if !dev.is_empty() {
                                cmd.flow_spec.devices.push(dev);
                            }
                        }
                        self.matches("}");
                    }
                    // Require `;` (or tokenizer-synthesised `;` from `\n`) after
                    // the devices clause. Without this check a single-line input
                    // like `devices = { lo } }` (no explicit `;` and no newline
                    // before the closing `}`) is silently accepted, whereas real
                    // nft rejects it with "unexpected '}', expecting newline or
                    // semicolon".
                    if !self.matches(";") && self.deferred_errors.is_empty() {
                        self.deferred_errors.push(
                            "syntax error, unexpected '}', expecting newline or semicolon".into());
                    }
                }
                "counter" => {
                    self.advance();
                    // NFT_FLOWTABLE_COUNTER = 0x2.
                    cmd.flow_spec.flags |= 0x2;
                    if !self.matches(";") && self.deferred_errors.is_empty() {
                        self.deferred_errors.push(
                            "syntax error, unexpected '}', expecting newline or semicolon".into());
                    }
                }
                "flags" => {
                    self.advance();
                    if self.peek() == "offload" {
                        self.advance();
                        // NF_FLOWTABLE_HW_OFFLOAD = 0x1.
                        cmd.flow_spec.flags |= 0x1;
                    }
                    if !self.matches(";") && self.deferred_errors.is_empty() {
                        self.deferred_errors.push(
                            "syntax error, unexpected '}', expecting newline or semicolon".into());
                    }
                }
                _ => {
                    while !self.at_end() && self.peek() != ";" && self.peek() != "}" {
                        self.advance();
                    }
                    self.matches(";");
                }
            }
        }
        self.matches("}");
    }

    fn parse_table_block(&mut self, cmd: &mut Command) {
        // The inline form `add table FAMILY NAME { ... }` can contain the
        // same declarations as a top-level `table FAMILY NAME { ... }` block.
        // Named objects (counter, quota, limit, synproxy, secmark, ct helper,
        // etc.) may appear with `{ }` bodies. We parse them into synthetic
        // commands pushed to `self.pending_commands`.
        if !self.matches("{") { return; }
        let family = cmd.family;
        let table_name = cmd.table.clone();
        while !self.at_end() && self.peek() != "}" {
            while self.matches(";") {}
            if self.peek() == "}" { break; }

            let tok = self.peek().to_string();
            match tok.as_str() {
                "comment" => {
                    self.advance();
                    let c = self.parse_name();
                    cmd.comment = c;
                    cmd.has_comment = true;
                    self.matches(";");
                }
                "flags" => {
                    self.advance();
                    cmd.table_spec.has_flags = true;
                    loop {
                        let p = self.peek();
                        if self.at_end() || p == ";" || p == "}"
                            || p == "chain" || p == "set" || p == "map"
                            || p == "counter" || p == "quota" || p == "limit"
                            || p == "ct" || p == "tunnel"
                        { break; }
                        if p == "dormant" {
                            cmd.table_spec.flags |= NFT_TABLE_F_DORMANT;
                        }
                        self.advance();
                    }
                    self.matches(";");
                }
                "counter" | "quota" | "limit" => {
                    self.advance();
                    let name = self.parse_name();
                    let mut ocmd = Command::default();
                    ocmd.op = CmdOp::Add;
                    ocmd.family = family;
                    ocmd.table = table_name.clone();
                    ocmd.set_name = name;
                    ocmd.obj = match tok.as_str() {
                        "counter" => CmdObj::Counter,
                        "quota" => CmdObj::Quota,
                        _ => CmdObj::Limit,
                    };
                    ocmd.obj_spec.kind = match tok.as_str() {
                        "counter" => NFT_OBJECT_COUNTER,
                        "quota" => NFT_OBJECT_QUOTA,
                        _ => NFT_OBJECT_LIMIT,
                    };
                    if self.peek() == "{" {
                        self.parse_object_block(&mut ocmd);
                    }
                    self.matches(";");
                    self.pending_commands.push(ocmd);
                }
                "synproxy" => {
                    self.advance();
                    let name = self.parse_name();
                    let mut ocmd = Command::default();
                    ocmd.op = CmdOp::Add;
                    ocmd.family = family;
                    ocmd.table = table_name.clone();
                    ocmd.set_name = name;
                    ocmd.obj = CmdObj::Synproxy;
                    ocmd.obj_spec.kind = NFT_OBJECT_SYNPROXY;
                    if self.peek() == "{" {
                        self.parse_object_block(&mut ocmd);
                    }
                    self.matches(";");
                    self.pending_commands.push(ocmd);
                }
                "secmark" => {
                    self.advance();
                    let name = self.parse_name();
                    let mut ocmd = Command::default();
                    ocmd.op = CmdOp::Add;
                    ocmd.family = family;
                    ocmd.table = table_name.clone();
                    ocmd.set_name = name;
                    ocmd.obj = CmdObj::Secmark;
                    ocmd.obj_spec.kind = NFT_OBJECT_SECMARK;
                    if self.peek() == "{" {
                        self.parse_object_block(&mut ocmd);
                    }
                    self.matches(";");
                    self.pending_commands.push(ocmd);
                }
                "tunnel" => {
                    self.advance();
                    let name = self.parse_name();
                    let mut ocmd = Command::default();
                    ocmd.op = CmdOp::Add;
                    ocmd.family = family;
                    ocmd.table = table_name.clone();
                    ocmd.set_name = name;
                    ocmd.obj = CmdObj::Tunnel;
                    ocmd.obj_spec.kind = NFT_OBJECT_TUNNEL;
                    if self.peek() == "{" {
                        self.parse_object_block(&mut ocmd);
                    }
                    self.matches(";");
                    self.pending_commands.push(ocmd);
                }
                "ct" => {
                    self.advance();
                    let sub = self.advance().to_string();
                    let name = self.parse_name();
                    let mut ocmd = Command::default();
                    ocmd.op = CmdOp::Add;
                    ocmd.family = family;
                    ocmd.table = table_name.clone();
                    ocmd.set_name = name;
                    match sub.as_str() {
                        "helper" => {
                            ocmd.obj = CmdObj::CtHelper;
                            ocmd.obj_spec.kind = NFT_OBJECT_CT_HELPER;
                            ocmd.obj_spec.helper_l3proto = family as u16;
                        }
                        "timeout" => {
                            ocmd.obj = CmdObj::CtTimeout;
                            ocmd.obj_spec.kind = NFT_OBJECT_CT_TIMEOUT;
                            ocmd.obj_spec.ct_timeout_l3proto = family as u16;
                        }
                        "expectation" => {
                            ocmd.obj = CmdObj::CtExpect;
                            ocmd.obj_spec.kind = NFT_OBJECT_CT_EXPECT;
                            ocmd.obj_spec.ct_expect_l3proto = family as u16;
                        }
                        _ => {
                            // Unknown ct sub-object: skip body
                            if self.matches("{") {
                                let mut depth = 1;
                                while !self.at_end() && depth > 0 {
                                    match self.peek() {
                                        "{" => { depth += 1; self.advance(); }
                                        "}" => { depth -= 1; self.advance(); }
                                        _ => { self.advance(); }
                                    }
                                }
                            }
                            self.matches(";");
                            continue;
                        }
                    }
                    if self.peek() == "{" {
                        self.parse_object_block(&mut ocmd);
                    }
                    self.matches(";");
                    self.pending_commands.push(ocmd);
                }
                _ => {
                    // Unknown token or child (chain, set, map, etc.) —
                    // skip to next `;` or `}`, tracking brace depth so
                    // nested bodies don't desync the outer loop.
                    let mut depth = 0i32;
                    loop {
                        if self.at_end() { break; }
                        match self.peek() {
                            "{" => { depth += 1; self.advance(); }
                            "}" => {
                                if depth <= 0 { break; }
                                depth -= 1;
                                self.advance();
                            }
                            ";" if depth == 0 => { self.advance(); break; }
                            _ => { self.advance(); }
                        }
                    }
                }
            }
        }
        self.matches("}");
    }

    /// Parse a top-level declarative `table FAMILY NAME { ... }` block
    /// (the form used in /etc/nftables.conf and the output of `nft list
    /// ruleset`). Emits synthetic `add table` / `add chain` / `add set`
    /// / `add rule` commands into `out`.
    fn parse_declarative_table(&mut self, out: &mut Vec<Command>) -> Result<(), String> {
        // leading "table"
        self.advance();
        let family = self.parse_family_default_ip();
        let table_name = self.parse_name();

        // Emit `add table FAMILY NAME`
        let mut tcmd = Command::default();
        tcmd.op = CmdOp::Add;
        tcmd.obj = CmdObj::Table;
        tcmd.family = family;
        tcmd.table = table_name.clone();
        out.push(tcmd);

        // Rules may reference chains defined later in the same block
        // (jump/goto targets, or rules before the forward chain).
        // In an atomic batch those references fail with ENOENT. So
        // collect chains separately from rules and flush all
        // chains first, then rules — matches libnftables ordering.
        // Element commands are also deferred: verdict map elements
        // like `{ 1.2.3.4 : goto CIn_1 }` reference chains that
        // may appear later in the block. Kernel order: table →
        // chains → sets/maps → elements → rules.
        let mut deferred_elements: Vec<Command> = Vec::new();
        let mut deferred_rules: Vec<Command> = Vec::new();

        if !self.matches("{") { return Ok(()); }

        while !self.at_end() && self.peek() != "}" {
            while self.matches(";") {}
            if self.peek() == "}" { break; }

            let tok = self.peek().to_string();
            match tok.as_str() {
                "comment" => {
                    self.advance();
                    let c = self.parse_name();
                    if let Some(last) = out.iter_mut().rev().find(|c| matches!(c.obj, CmdObj::Table)) {
                        last.comment = c;
                        last.has_comment = true;
                    }
                    self.matches(";");
                }
                "flags" => {
                    self.advance();
                    // Rule body has no `;` after `flags dormant` when the
                    // writer used newlines, so bail on any token that
                    // could start the next member as well.
                    loop {
                        let p = self.peek();
                        if self.at_end() || p == ";" || p == "}"
                            || p == "chain" || p == "set" || p == "map"
                            || p == "counter" || p == "quota" || p == "limit"
                            || p == "ct" || p == "tunnel"
                        { break; }
                        if p == "dormant" {
                            if let Some(last) = out.iter_mut().rev().find(|c| matches!(c.obj, CmdObj::Table)) {
                                last.table_spec.has_flags = true;
                                last.table_spec.flags |= NFT_TABLE_F_DORMANT;
                            }
                        }
                        self.advance();
                    }
                    self.matches(";");
                }
                "chain" => {
                    self.advance();
                    let chain_name = self.parse_name();
                    let mut ccmd = Command::default();
                    ccmd.op = CmdOp::Add;
                    ccmd.obj = CmdObj::Chain;
                    ccmd.family = family;
                    ccmd.table = table_name.clone();
                    ccmd.chain = chain_name.clone();

                    // Collect rule commands emitted from statements in the chain body.
                    let mut rules: Vec<Command> = Vec::new();
                    if self.matches("{") {
                        while !self.at_end() && self.peek() != "}" {
                            while self.matches(";") {}
                            if self.peek() == "}" { break; }
                            let t = self.peek().to_string();
                            if t == "type" {
                                self.advance();
                                ccmd.chain_spec.is_base = true;
                                ccmd.chain_spec.chain_type = self.parse_name();
                                if self.matches("hook") { ccmd.chain_spec.hook = self.parse_name(); }
                                if self.matches("device") {
                                    let dev = self.parse_name();
                                    if dev.len() > 15 {
                                        return Err(format!("interface name too long"));
                                    }
                                    ccmd.chain_spec.device = dev;
                                    ccmd.chain_spec.has_device = true;
                                }
                                // `devices = { dev [, dev ...] }` — plural form for
                                // egress and multidevice netdev chains.
                                if self.matches("devices") {
                                    self.matches("=");
                                    if self.matches("{") {
                                        while !self.at_end() && self.peek() != "}" {
                                            if self.peek() == "," || self.peek() == ";" { self.advance(); continue; }
                                            let d = self.advance().to_string();
                                            let dev = if d.starts_with('"') && d.ends_with('"') && d.len() >= 2 {
                                                d[1..d.len()-1].to_string()
                                            } else { d };
                                            if dev.len() > 15 {
                                                return Err(format!("interface name too long"));
                                            }
                                            if !dev.is_empty() && !ccmd.chain_spec.has_device {
                                                ccmd.chain_spec.device = dev;
                                                ccmd.chain_spec.has_device = true;
                                            }
                                        }
                                        self.matches("}");
                                    }
                                }
                                if self.matches("priority") {
                                    let ct = ccmd.chain_spec.chain_type.clone();
                                    let hk = ccmd.chain_spec.hook.clone();
                                    ccmd.chain_spec.priority = self.parse_priority_ctx(family, &ct, &hk)?;
                                    ccmd.chain_spec.has_priority = true;
                                }
                                self.matches(";");
                            } else if t == "policy" {
                                self.advance();
                                let pol = self.parse_name();
                                if pol != "accept" && pol != "drop" {
                                    return Err(format!("unknown policy '{}'", pol));
                                }
                                ccmd.chain_spec.policy = pol;
                                ccmd.chain_spec.has_policy = true;
                                self.matches(";");
                            } else if t == "comment" {
                                // Chain-level comment: `comment "text"` inside
                                // the declarative chain body.
                                self.advance();
                                if !self.at_end() && self.peek() != ";" {
                                    let c = self.parse_name();
                                    self.set_comment(&mut ccmd, c);
                                }
                                self.matches(";");
                            } else {
                                // A rule statement: consume tokens up to next ';' or '}'
                                // into a fresh rule command. Fail if the line
                                // was entirely unknown — a rule that silently
                                // lexes to no expressions would otherwise let
                                // garbage rulesets load (upstream's rollback
                                // tests rely on bad syntax failing).
                                let before = self.pos;
                                let mut rcmd = Command::default();
                                rcmd.op = CmdOp::Add;
                                rcmd.obj = CmdObj::Rule;
                                rcmd.family = family;
                                rcmd.table = table_name.clone();
                                rcmd.chain = chain_name.clone();
                                self.parse_rule_exprs(&mut rcmd);
                                self.matches(";");
                                // If the rule has only Unimplemented expressions AND
                                // the first token was not a recognised nft keyword,
                                // treat it as an error so bad rulesets are rejected.
                                let all_unimpl = !rcmd.exprs.is_empty()
                                    && rcmd.exprs.iter().all(|e| matches!(e, Expr::Unimplemented));
                                if all_unimpl && !is_statement_start(&t) {
                                    return Err(format!("syntax error near '{}'", t));
                                }
                                if !rcmd.exprs.is_empty() || rcmd.has_comment {
                                    rules.extend(self.pending_anon_chains.drain(..));
                                    rules.push(rcmd);
                                } else if self.pos != before {
                                    return Err(format!("unknown rule statement near '{}'", t));
                                }
                            }
                        }
                        self.matches("}");
                    }
                    out.push(ccmd);
                    deferred_rules.extend(rules);
                }
                "set" | "map" => {
                    let is_map = tok == "map";
                    self.advance();
                    let set_name = self.parse_name();
                    let mut scmd = Command::default();
                    scmd.op = CmdOp::Add;
                    scmd.obj = if is_map { CmdObj::Map } else { CmdObj::Set };
                    scmd.family = family;
                    scmd.table = table_name.clone();
                    scmd.set_name = set_name.clone();
                    if is_map { scmd.set_spec.is_map = true; }

                    // Collect elements separately so we can emit them as
                    // a follow-up `add element` command.
                    let mut elements: Vec<(Vec<u8>, Option<Vec<u8>>)> = Vec::new();
                    let mut element_verdicts: Vec<(i32, String)> = Vec::new();
                    let mut element_datas: Vec<Option<Vec<u8>>> = Vec::new();
                    if self.matches("{") {
                        while !self.at_end() && self.peek() != "}" {
                            while self.matches(";") {}
                            if self.peek() == "}" { break; }
                            if self.matches("typeof") {
                                let (name, kt, kl, widths) = self.parse_typeof_selectors()?;
                                scmd.set_spec.key_type_name = name;
                                scmd.set_spec.key_type = kt;
                                scmd.set_spec.key_len = kl;
                                scmd.set_spec.concat_widths = widths;
                                if self.peek() == ":" {
                                    self.advance();
                                    scmd.set_spec.is_map = true;
                                    let dt_tok = self.advance().to_string();
                                    let (dt, dl) = crate::netlink::set_key_type(&dt_tok);
                                    scmd.set_spec.data_type_name = dt_tok.clone();
                                    scmd.set_spec.data_type = dt;
                                    scmd.set_spec.data_len = dl;
                                    if dt_tok != "verdict" && crate::netlink::is_obj_type(dt) {
                                        scmd.set_spec.is_obj_map = true;
                                        scmd.set_spec.obj_type =
                                            crate::netlink::obj_type_from_sentinel(dt);
                                    }
                                }
                                self.matches(";");
                                continue;
                            }
                            if self.matches("type") {
                                // Same concat handling as the standalone
                                // path above — `T1 . T2 . T3 …` packs into
                                // a single u32 NFTA_SET_KEY_TYPE.
                                let first_name = self.advance().to_string();
                                let (kt0, kl0) = crate::netlink::set_key_type(&first_name);
                                let (type_name, kt, kl) = if self.peek() == "." {
                                    let mut packed: u32 = kt0;
                                    let mut total_len: u32 = (kl0 + 3) & !3;
                                    let mut name_parts: Vec<String> = vec![first_name];
                                    while self.peek() == "." {
                                        self.advance();
                                        let n = self.advance().to_string();
                                        let (kt_i, kl_i) = crate::netlink::set_key_type(&n);
                                        packed = (packed << 6) | kt_i;
                                        total_len += (kl_i + 3) & !3;
                                        name_parts.push(n);
                                    }
                                    (name_parts.join(" . "), packed, total_len)
                                } else {
                                    (first_name, kt0, kl0)
                                };
                                scmd.set_spec.key_type_name = type_name;
                                scmd.set_spec.key_type = kt;
                                scmd.set_spec.key_len = kl;
                                // Map type declared as `type KEY : VALUE`.
                                if self.peek() == ":" {
                                    self.advance();
                                    scmd.set_spec.is_map = true;
                                    let dt_name = self.advance().to_string();
                                    let (dt, dl) = crate::netlink::set_key_type(&dt_name);
                                    scmd.set_spec.data_type_name = dt_name;
                                    scmd.set_spec.data_type = dt;
                                    scmd.set_spec.data_len = dl;
                                    // Object-reference map (type KEY : counter/quota/…)
                                    if scmd.set_spec.data_type_name != "verdict" && crate::netlink::is_obj_type(dt) {
                                        scmd.set_spec.is_obj_map = true;
                                        scmd.set_spec.obj_type =
                                            crate::netlink::obj_type_from_sentinel(dt);
                                    }
                                }
                                self.matches(";");
                            } else if self.matches("flags") {
                                scmd.set_spec.has_flags = true;
                                // Stop at ";" OR "}" OR any next-attribute keyword.
                                // Inside braces newlines no longer inject ";", so
                                // "flags interval elements = {...}" must terminate
                                // on the keyword "elements" rather than running off
                                // the end of the set body.
                                loop {
                                    let p = self.peek();
                                    if self.at_end() || p == ";" || p == "}"
                                        || p == "elements" || p == "type"
                                        || p == "size"
                                        || p == "gc-interval" || p == "policy"
                                        || p == "auto-merge"
                                    { break; }
                                    match p {
                                        "constant" => { scmd.set_spec.flags |= 0x2; self.advance(); }
                                        "interval" => { scmd.set_spec.flags |= 0x4; self.advance(); }
                                        "timeout"  => { scmd.set_spec.flags |= NFT_SET_TIMEOUT; self.advance(); }
                                        "dynamic"  => { scmd.set_spec.flags |= NFT_SET_EVAL; self.advance(); }
                                        "," => { self.advance(); }
                                        _ => { self.advance(); }
                                    }
                                }
                                self.matches(";");
                            } else if self.matches("size") {
                                if let Ok(n) = self.peek().parse::<u32>() {
                                    scmd.set_spec.size = n;
                                    self.advance();
                                }
                                self.matches(";");
                            } else if self.matches("timeout") {
                                scmd.set_spec.timeout_ms = parse_duration_ms(self.advance());
                                scmd.set_spec.has_timeout = true;
                                self.matches(";");
                            } else if self.matches("comment") {
                                // Set-level comment in declarative form:
                                // `set foo { type ipv4_addr; comment "..."; }`
                                if !self.at_end() && self.peek() != ";" && self.peek() != "}" {
                                    let c = self.parse_name();
                                    self.set_comment(&mut scmd, c);
                                }
                                self.matches(";");
                            } else if self.matches("elements") {
                                self.matches("=");
                                let key_is_inet_proto = scmd.set_spec.key_type == 12 && scmd.set_spec.key_len == 1;
                                if self.matches("{") {
                                    while !self.at_end() && self.peek() != "}" {
                                        if self.peek() == "," || self.peek() == ";" { self.advance(); continue; }
                                        let tok = self.advance().to_string();
                                        // Resolve `tcp`/`udp`/etc when
                                        // the key type is inet_proto
                                        // (typeof meta l4proto / type
                                        // inet_proto). Falls through to
                                        // the numeric / address paths
                                        // when the name isn't a known
                                        // protocol.
                                        if key_is_inet_proto {
                                            if let Some(n) = proto_num(&tok) {
                                                elements.push((vec![n], None));
                                                continue;
                                            }
                                        }
                                        // CIDR shorthand → [addr, broadcast].
                                        if let Some(slash) = tok.find('/') {
                                            let addr_part = &tok[..slash];
                                            let prefix_part = &tok[slash + 1..];
                                            let cidr_pair: Option<(Vec<u8>, Vec<u8>)> =
                                                if let (Some(addr), Ok(prefix)) = (Self::parse_ipv4(addr_part), prefix_part.parse::<u32>()) {
                                                    let p = prefix.min(32);
                                                    let base = u32::from_be_bytes(addr);
                                                    let host_mask = if p == 32 { 0u32 } else { (1u32 << (32 - p)) - 1 };
                                                    let s_i = base & !host_mask;
                                                    let e_i = s_i | host_mask;
                                                    Some((s_i.to_be_bytes().to_vec(), e_i.to_be_bytes().to_vec()))
                                                } else if let (Some(addr), Ok(prefix)) = (Self::parse_ipv6(addr_part), prefix_part.parse::<u32>()) {
                                                    let p = prefix.min(128);
                                                    let base = u128::from_be_bytes(addr);
                                                    let host_mask: u128 = if p == 128 { 0 } else { (1u128 << (128 - p)) - 1 };
                                                    let s_i = base & !host_mask;
                                                    let e_i = s_i | host_mask;
                                                    Some((s_i.to_be_bytes().to_vec(), e_i.to_be_bytes().to_vec()))
                                                } else { None };
                                            if let Some((s_b, e_b)) = cidr_pair {
                                                elements.push((s_b, Some(e_b)));
                                                if self.peek() == ":" {
                                                    self.advance();
                                                    let vtok = self.advance().to_string();
                                                    let bytes = Self::parse_ipv6(&vtok).map(|a| a.to_vec())
                                                        .or_else(|| Self::parse_ipv4(&vtok).map(|a| a.to_vec()))
                                                        .or_else(|| vtok.parse::<u32>().ok().map(|n| n.to_be_bytes().to_vec()));
                                                    element_verdicts.push((0, String::new()));
                                                    element_datas.push(bytes);
                                                }
                                                continue;
                                            }
                                        }
                                        let start: Option<Vec<u8>> =
                                            if let Some(addr) = Self::parse_ipv6(&tok) {
                                                Some(addr.to_vec())
                                            } else if let Some(addr) = Self::parse_ipv4(&tok) {
                                                Some(addr.to_vec())
                                            } else if let Ok(n) = tok.parse::<u32>() {
                                                Some(n.to_be_bytes().to_vec())
                                            } else { None };
                                        if let Some(s) = start {
                                            let end = if self.peek() == "-" {
                                                self.advance();
                                                let et = self.advance().to_string();
                                                Self::parse_ipv6(&et).map(|a| a.to_vec())
                                                    .or_else(|| Self::parse_ipv4(&et).map(|a| a.to_vec()))
                                                    .or_else(|| et.parse::<u32>().ok().map(|n| n.to_be_bytes().to_vec()))
                                            } else { None };
                                            // Concat key: `. val [- val] . val ...`
                                            if self.peek() == "." {
                                                let cw = &scmd.set_spec.concat_widths;
                                                let mut key = Self::pad4(s);
                                                let mut key_end: Option<Vec<u8>> = end.map(Self::pad4);
                                                let mut slot = 1usize;
                                                while self.peek() == "." {
                                                    self.advance();
                                                    let ct = self.advance().to_string();
                                                    let w = cw.get(slot).copied().unwrap_or(4);
                                                    let cv = Self::parse_one_element_w(&ct, w);
                                                    let ce = if self.peek() == "-" {
                                                        self.advance();
                                                        let et2 = self.advance().to_string();
                                                        Some(Self::parse_one_element_w(&et2, w))
                                                    } else { None };
                                                    key.extend_from_slice(&Self::pad4(cv));
                                                    if let Some(ref mut ke) = key_end {
                                                        ke.extend_from_slice(&Self::pad4(
                                                            ce.unwrap_or_else(|| ke[ke.len()-4..].to_vec())));
                                                    } else if let Some(cev) = ce {
                                                        let mut bf = key[..key.len()-4].to_vec();
                                                        bf.extend_from_slice(&Self::pad4(cev));
                                                        key_end = Some(bf);
                                                    }
                                                    slot += 1;
                                                }
                                                elements.push((key, key_end));
                                            } else {
                                                elements.push((s, end));
                                            }
                                        } else {
                                            let raw = if tok.starts_with('"') && tok.ends_with('"') && tok.len() >= 2 {
                                                tok[1..tok.len()-1].to_string()
                                            } else { tok };
                                            let mut v = raw.as_bytes().to_vec();
                                            v.push(0);
                                            elements.push((v, None));
                                        }
                                        // Inline `key : value` for maps — either a verdict
                                        // (accept/drop/jump c/...) or a data value matching
                                        // the declared data_type (ipv4/integer/ifname).
                                        if self.peek() == ":" {
                                            self.advance();
                                            let v = self.peek().to_string();
                                            match v.as_str() {
                                                "accept" | "drop" | "return" | "continue" | "jump" | "goto" => {
                                                    let t = self.advance().to_string();
                                                    let (code, chain) = match t.as_str() {
                                                        "accept" => (NF_ACCEPT, String::new()),
                                                        "drop" => (NF_DROP, String::new()),
                                                        "return" => (NFT_RETURN, String::new()),
                                                        "continue" => (NFT_CONTINUE, String::new()),
                                                        "jump" => (NFT_JUMP, self.advance().to_string()),
                                                        "goto" => (NFT_GOTO, self.advance().to_string()),
                                                        _ => (NF_ACCEPT, String::new()),
                                                    };
                                                    element_verdicts.push((code, chain));
                                                    element_datas.push(None);
                                                }
                                                _ => {
                                                    let t = self.advance().to_string();
                                                    // A bare identifier as the value of a
                                                    // verdict map is an invalid verdict.
                                                    let is_bare_ident = !t.starts_with('"')
                                                        && t.chars().next().map_or(false, |c| c.is_ascii_alphabetic() || c == '_')
                                                        && Self::parse_ipv4(&t).is_none()
                                                        && t.parse::<u32>().is_err();
                                                    if is_bare_ident && scmd.set_spec.data_type_name == "verdict" {
                                                        self.deferred_errors.push(format!(
                                                            "syntax error, invalid verdict '{}'", t));
                                                        element_verdicts.push((0, String::new()));
                                                        element_datas.push(None);
                                                    } else {
                                                    let bytes = if let Some(a) = Self::parse_ipv4(&t) {
                                                        Some(a.to_vec())
                                                    } else if let Ok(n) = t.parse::<u32>() {
                                                        Some(n.to_be_bytes().to_vec())
                                                    } else if t.starts_with('"') && t.ends_with('"') && t.len() >= 2 {
                                                        let mut v = t[1..t.len()-1].as_bytes().to_vec();
                                                        v.push(0);
                                                        while v.len() < 16 { v.push(0); }
                                                        Some(v)
                                                    } else { None };
                                                    element_verdicts.push((0, String::new()));
                                                    element_datas.push(bytes);
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    self.matches("}");
                                }
                                self.matches(";");
                            } else {
                                // Unknown attribute inside set block; consume to next ;
                                while !self.at_end() && self.peek() != ";" && self.peek() != "}" {
                                    self.advance();
                                }
                                self.matches(";");
                            }
                        }
                        self.matches("}");
                    }
                    let ss = scmd.set_spec.clone();
                    out.push(scmd);
                    if !elements.is_empty() {
                        let mut ecmd = Command::default();
                        ecmd.op = CmdOp::Add;
                        ecmd.obj = CmdObj::Element;
                        ecmd.family = family;
                        ecmd.table = table_name.clone();
                        ecmd.set_name = set_name;
                        ecmd.set_spec = ss;
                        ecmd.elements = elements;
                        ecmd.element_verdicts = element_verdicts;
                        ecmd.element_datas = element_datas;
                        deferred_elements.push(ecmd);
                    }
                }
                "flowtable" => {
                    // Declarative flowtable inside a table body:
                    //   flowtable ft { hook ingress priority filter; devices = { lo }; }
                    self.advance();
                    let name = self.parse_name();
                    let mut fcmd = Command::default();
                    fcmd.op = CmdOp::Add;
                    fcmd.obj = CmdObj::Flowtable;
                    fcmd.family = family;
                    fcmd.table = table_name.clone();
                    fcmd.set_name = name;
                    if self.peek() == "{" {
                        self.parse_flowtable_block(&mut fcmd);
                    }
                    self.matches(";");
                    out.push(fcmd);
                }
                "synproxy" => {
                    // synproxy declarative form:
                    //   synproxy name { mss 1460; wscale 7; timestamp sack-perm; }
                    self.advance(); // synproxy
                    let name = self.parse_name();
                    let mut ocmd = Command::default();
                    ocmd.op = CmdOp::Add;
                    ocmd.family = family;
                    ocmd.table = table_name.clone();
                    ocmd.set_name = name;
                    ocmd.obj = CmdObj::Synproxy;
                    ocmd.obj_spec.kind = NFT_OBJECT_SYNPROXY;
                    if self.peek() == "{" {
                        self.parse_object_block(&mut ocmd);
                    }
                    self.matches(";");
                    out.push(ocmd);
                }
                "secmark" => {
                    // secmark declarative form:
                    //   secmark name { "context_string"; }
                    self.advance(); // secmark
                    let name = self.parse_name();
                    let mut ocmd = Command::default();
                    ocmd.op = CmdOp::Add;
                    ocmd.family = family;
                    ocmd.table = table_name.clone();
                    ocmd.set_name = name;
                    ocmd.obj = CmdObj::Secmark;
                    ocmd.obj_spec.kind = NFT_OBJECT_SECMARK;
                    if self.peek() == "{" {
                        self.parse_object_block(&mut ocmd);
                    }
                    self.matches(";");
                    out.push(ocmd);
                }
                "tunnel" => {
                    self.advance();
                    let name = self.parse_name();
                    let mut ocmd = Command::default();
                    ocmd.op = CmdOp::Add;
                    ocmd.family = family;
                    ocmd.table = table_name.clone();
                    ocmd.set_name = name;
                    ocmd.obj = CmdObj::Tunnel;
                    ocmd.obj_spec.kind = NFT_OBJECT_TUNNEL;
                    if self.peek() == "{" {
                        self.parse_object_block(&mut ocmd);
                    }
                    self.matches(";");
                    out.push(ocmd);
                }
                "counter" | "quota" | "limit" => {
                    // Named stateful object declarative form:
                    //   counter name { packets 0 bytes 0; comment "..."; }
                    //   quota name { over 100 mbytes used 0 bytes; }
                    //   limit name { rate 10/second burst 5 packets; }
                    self.advance();
                    let name = self.parse_name();
                    let mut ocmd = Command::default();
                    ocmd.op = CmdOp::Add;
                    ocmd.family = family;
                    ocmd.table = table_name.clone();
                    ocmd.set_name = name;
                    ocmd.obj = match tok.as_str() {
                        "counter" => CmdObj::Counter,
                        "quota" => CmdObj::Quota,
                        _ => CmdObj::Limit,
                    };
                    ocmd.obj_spec.kind = match tok.as_str() {
                        "counter" => NFT_OBJECT_COUNTER,
                        "quota" => NFT_OBJECT_QUOTA,
                        _ => NFT_OBJECT_LIMIT,
                    };
                    if self.peek() == "{" {
                        self.parse_object_block(&mut ocmd);
                    }
                    self.matches(";");
                    out.push(ocmd);
                }
                "ct" => {
                    // ct helper / ct timeout / ct expectation declarative
                    // form, e.g.
                    //   ct helper myftp { type "ftp" protocol tcp; l3proto ip; }
                    self.advance(); // ct
                    let sub = self.advance().to_string();
                    let name = self.parse_name();
                    let mut ocmd = Command::default();
                    ocmd.op = CmdOp::Add;
                    ocmd.family = family;
                    ocmd.table = table_name.clone();
                    ocmd.set_name = name;
                    match sub.as_str() {
                        "helper" => {
                            ocmd.obj = CmdObj::CtHelper;
                            ocmd.obj_spec.kind = NFT_OBJECT_CT_HELPER;
                            ocmd.obj_spec.helper_l3proto = family as u16;
                        }
                        "timeout" => {
                            ocmd.obj = CmdObj::CtTimeout;
                            ocmd.obj_spec.kind = NFT_OBJECT_CT_TIMEOUT;
                            ocmd.obj_spec.ct_timeout_l3proto = family as u16;
                        }
                        "expectation" => {
                            ocmd.obj = CmdObj::CtExpect;
                            ocmd.obj_spec.kind = NFT_OBJECT_CT_EXPECT;
                            ocmd.obj_spec.ct_expect_l3proto = family as u16;
                        }
                        _ => {
                            // Unknown ct-* object — skip the body so the
                            // rest of the table still parses.
                            if self.matches("{") {
                                let mut depth = 1;
                                while !self.at_end() && depth > 0 {
                                    match self.peek() {
                                        "{" => { depth += 1; self.advance(); }
                                        "}" => { depth -= 1; self.advance(); }
                                        _   => { self.advance(); }
                                    }
                                }
                            }
                            self.matches(";");
                            continue;
                        }
                    }
                    if self.peek() == "{" {
                        self.parse_object_block(&mut ocmd);
                    }
                    self.matches(";");
                    out.push(ocmd);
                }
                _ => {
                    // Unknown top-level element inside table; skip to next ;.
                    while !self.at_end() && self.peek() != ";" && self.peek() != "}" {
                        self.advance();
                    }
                    self.matches(";");
                }
            }
        }
        self.matches("}");
        out.extend(deferred_elements);
        out.extend(deferred_rules);
        Ok(())
    }

    fn parse_command(&mut self) -> Result<Option<Command>, String> {
        while self.matches(";") {}
        if self.at_end() { return Ok(None); }

        let mut cmd = Command::default();

        // Operation
        let op_str = self.advance().to_string();
        cmd.op = match op_str.as_str() {
            "add" => CmdOp::Add, "create" => CmdOp::Create, "delete" => CmdOp::Delete,
            "destroy" => CmdOp::Destroy, "list" => CmdOp::List, "flush" => CmdOp::Flush,
            "rename" => CmdOp::Rename, "insert" => CmdOp::Insert, "replace" => CmdOp::Replace,
            "reset" => CmdOp::Reset,
            _ => return Err(format!("expected command, got '{}'", op_str)),
        };

        // Object type. `ct` is a two-token namespace — `ct helper`,
        // `ct timeout`, `ct expectation` — so when we see `ct` we
        // peek the next token to disambiguate.
        let obj_str = self.advance().to_string();
        cmd.obj = match obj_str.as_str() {
            "table" => CmdObj::Table, "chain" => CmdObj::Chain, "rule" => CmdObj::Rule,
            "set" => CmdObj::Set, "map" => CmdObj::Map, "element" => CmdObj::Element,
            "ruleset" => CmdObj::Ruleset, "tables" => CmdObj::Tables, "chains" => CmdObj::Chains,
            "rules" => CmdObj::Rules, "sets" => CmdObj::Sets, "maps" => CmdObj::Maps,
            "counter" => CmdObj::Counter, "quota" => CmdObj::Quota, "limit" => CmdObj::Limit,
            "counters" => CmdObj::Counters, "quotas" => CmdObj::Quotas, "limits" => CmdObj::Limits,
            "flowtable" => CmdObj::Flowtable,
            "flowtables" => CmdObj::Flowtables,
            "synproxy" => CmdObj::Synproxy,
            "secmark" => CmdObj::Secmark,
            "tunnel" => CmdObj::Tunnel,
            "objects" => CmdObj::Objects,
            "ct" => {
                let sub = self.advance().to_string();
                match sub.as_str() {
                    "helper"      => CmdObj::CtHelper,
                    "timeout"     => CmdObj::CtTimeout,
                    "expectation" => CmdObj::CtExpect,
                    _ => return Err(format!("unsupported ct object 'ct {}'", sub)),
                }
            }
            _ => {
                // Shorthand: `add TABLE CHAIN EXPR...` is equivalent to
                // `add rule TABLE CHAIN EXPR...`. Upstream nft supports
                // this form — the first unrecognised word after `add` is
                // treated as the table name.
                if matches!(cmd.op, CmdOp::Add | CmdOp::Insert) {
                    cmd.obj = CmdObj::Rule;
                    cmd.family = NFPROTO_IPV4;
                    cmd.table = obj_str;
                    cmd.chain = self.parse_name();
                    self.parse_rule_exprs(&mut cmd);
                    return Ok(Some(cmd));
                }
                return Err(format!("expected object type, got '{}'", obj_str));
            }
        };

        // Ruleset/plural: optional family, optional table [chain]
        match cmd.obj {
            CmdObj::Ruleset | CmdObj::Tables => {
                cmd.family = self.parse_family_default_unspec();
                return Ok(Some(cmd));
            }
            CmdObj::Chains | CmdObj::Rules |
            CmdObj::Sets | CmdObj::Maps |
            CmdObj::Counters | CmdObj::Quotas | CmdObj::Limits |
            CmdObj::Flowtables | CmdObj::Objects => {
                cmd.family = self.parse_family_default_unspec();
                // `reset rules chain TABLE CHAIN` / `reset rules table TABLE`
                // scope keywords — consume the scope keyword before the name(s).
                let nxt = self.peek();
                if matches!(cmd.obj, CmdObj::Rules) && nxt == "chain" {
                    self.advance(); // consume "chain"
                    cmd.table = self.parse_name();
                    let nxt2 = self.peek();
                    if !nxt2.is_empty() && nxt2 != ";" && nxt2 != "}" && nxt2 != "\n" {
                        cmd.chain = self.parse_name();
                    }
                } else if matches!(cmd.obj, CmdObj::Rules) && nxt == "table" {
                    self.advance(); // consume "table"
                    cmd.table = self.parse_name();
                } else {
                    // Optional table [chain] — e.g. `list rules ip mytable mychain`
                    if !nxt.is_empty() && nxt != ";" && nxt != "}" && nxt != "\n" {
                        cmd.table = self.parse_name();
                        let nxt2 = self.peek();
                        if !nxt2.is_empty() && nxt2 != ";" && nxt2 != "}" && nxt2 != "\n" {
                            cmd.chain = self.parse_name();
                        }
                    }
                }
                return Ok(Some(cmd));
            }
            _ => {}
        }

        // [family] table
        cmd.family = self.parse_family_default_ip();

        // `delete table FAMILY handle N` / `destroy table FAMILY handle N`
        // — target a table by kernel handle instead of name. Upstream's
        // transactions/handle_bad_family round-trips the handle grabbed
        // from `nft -a -e add table ip x`.
        if matches!(cmd.obj, CmdObj::Table)
            && matches!(cmd.op, CmdOp::Delete | CmdOp::Destroy)
            && self.peek() == "handle"
        {
            self.advance();
            let htok = self.advance().to_string();
            if htok.starts_with('-') {
                return Err("syntax error, unexpected -, expecting number".into());
            }
            cmd.handle = htok.parse().unwrap_or(0);
            cmd.has_handle = true;
            return Ok(Some(cmd));
        }

        cmd.table = self.parse_name();

        // Table-only commands
        if matches!(cmd.obj, CmdObj::Table) {
            if matches!(cmd.op, CmdOp::Add | CmdOp::Create) && self.peek() == "{" {
                self.parse_table_block(&mut cmd);
            }
            return Ok(Some(cmd));
        }

        // Chain/rule/set/object need another name. For chain delete
        // (and rule delete) the name slot can carry `handle N` instead
        // of a named identifier — `nft delete chain TABLE handle 42`.
        match cmd.obj {
            CmdObj::Chain | CmdObj::Rule => {
                if matches!(cmd.op, CmdOp::Delete | CmdOp::Destroy) && self.peek() == "handle" {
                    self.advance();
                    let htok = self.advance().to_string();
                    if htok.starts_with('-') {
                        return Err("syntax error, unexpected -, expecting number".into());
                    }
                    cmd.handle = htok.parse().unwrap_or(0);
                    cmd.has_handle = true;
                    return Ok(Some(cmd));
                }
                cmd.chain = self.parse_name();
            }
            CmdObj::Set | CmdObj::Map | CmdObj::Element => {
                if matches!(cmd.op, CmdOp::Delete | CmdOp::Destroy)
                    && !matches!(cmd.obj, CmdObj::Element)
                    && self.peek() == "handle"
                {
                    self.advance();
                    let htok = self.advance().to_string();
                    cmd.handle = htok.parse().unwrap_or(0);
                    cmd.has_handle = true;
                    return Ok(Some(cmd));
                }
                cmd.set_name = self.parse_name();
            }
            CmdObj::Counter | CmdObj::Quota | CmdObj::Limit => {
                if matches!(cmd.op, CmdOp::Delete | CmdOp::Destroy) && self.peek() == "handle" {
                    self.advance();
                    let htok = self.advance().to_string();
                    cmd.handle = htok.parse().unwrap_or(0);
                    cmd.has_handle = true;
                    return Ok(Some(cmd));
                }
                cmd.set_name = self.parse_name();
            }
            CmdObj::CtHelper | CmdObj::CtTimeout | CmdObj::CtExpect => {
                if matches!(cmd.op, CmdOp::Delete | CmdOp::Destroy) && self.peek() == "handle" {
                    self.advance();
                    let htok = self.advance().to_string();
                    cmd.handle = htok.parse().unwrap_or(0);
                    cmd.has_handle = true;
                    return Ok(Some(cmd));
                }
                cmd.set_name = self.parse_name();
            }
            CmdObj::Synproxy | CmdObj::Secmark => {
                if matches!(cmd.op, CmdOp::Delete | CmdOp::Destroy) && self.peek() == "handle" {
                    self.advance();
                    let htok = self.advance().to_string();
                    cmd.handle = htok.parse().unwrap_or(0);
                    cmd.has_handle = true;
                    return Ok(Some(cmd));
                }
                cmd.set_name = self.parse_name();
            }
            CmdObj::Flowtable => {
                if matches!(cmd.op, CmdOp::Delete | CmdOp::Destroy) && self.peek() == "handle" {
                    self.advance();
                    let htok = self.advance().to_string();
                    cmd.handle = htok.parse().unwrap_or(0);
                    cmd.has_handle = true;
                    return Ok(Some(cmd));
                }
                cmd.set_name = self.parse_name();
            }
            _ => {}
        }

        // Flowtable body: parse the `{ hook ... priority ...; devices = { ... }; }`
        // block. Returning here so the generic chain-block path doesn't
        // try to consume the same braces.
        if matches!(cmd.obj, CmdObj::Flowtable)
            && matches!(cmd.op, CmdOp::Add | CmdOp::Create)
        {
            if self.peek() == "{" {
                self.parse_flowtable_block(&mut cmd);
            }
            return Ok(Some(cmd));
        }

        // Named stateful-object body:   add counter t cnt { packets 0 bytes 0 ; }
        if matches!(cmd.obj, CmdObj::Counter | CmdObj::Quota | CmdObj::Limit
                            | CmdObj::CtHelper | CmdObj::CtTimeout | CmdObj::CtExpect
                            | CmdObj::Synproxy | CmdObj::Secmark)
            && matches!(cmd.op, CmdOp::Add | CmdOp::Create)
        {
            cmd.obj_spec.kind = match cmd.obj {
                CmdObj::Counter   => NFT_OBJECT_COUNTER,
                CmdObj::Quota     => NFT_OBJECT_QUOTA,
                CmdObj::Limit     => NFT_OBJECT_LIMIT,
                CmdObj::CtHelper  => NFT_OBJECT_CT_HELPER,
                CmdObj::CtTimeout => NFT_OBJECT_CT_TIMEOUT,
                CmdObj::CtExpect  => NFT_OBJECT_CT_EXPECT,
                CmdObj::Synproxy  => NFT_OBJECT_SYNPROXY,
                CmdObj::Secmark   => NFT_OBJECT_SECMARK,
                _ => 0,
            };
            // Default helper l3proto to the table family when the
            // source omits an explicit `l3proto` line. nft renders the
            // attribute back as `inet` for inet-family tables, `ip` for
            // ip, etc., so the round-trip stays byte-identical.
            if cmd.obj_spec.kind == NFT_OBJECT_CT_HELPER {
                cmd.obj_spec.helper_l3proto = cmd.family as u16;
            }
            if cmd.obj_spec.kind == NFT_OBJECT_CT_TIMEOUT {
                cmd.obj_spec.ct_timeout_l3proto = cmd.family as u16;
            }
            if cmd.obj_spec.kind == NFT_OBJECT_CT_EXPECT {
                cmd.obj_spec.ct_expect_l3proto = cmd.family as u16;
            }
            if self.peek() == "{" {
                self.parse_object_block(&mut cmd);
            } else if cmd.obj_spec.kind == NFT_OBJECT_QUOTA {
                // Inline quota form: `add quota t q [over] 25 mbytes`.
                if self.peek() == "over" {
                    self.advance();
                    cmd.obj_spec.quota_flags |= NFT_QUOTA_F_INV;
                }
                if let Ok(n) = self.peek().parse::<u64>() {
                    self.advance();
                    let mul = match self.peek() {
                        "bytes"  => 1u64,
                        "kbytes" => 1024,
                        "mbytes" => 1024 * 1024,
                        "gbytes" => 1024 * 1024 * 1024,
                        _        => 1,
                    };
                    if matches!(self.peek(), "bytes" | "kbytes" | "mbytes" | "gbytes") {
                        self.advance();
                    }
                    cmd.obj_spec.bytes = n * mul;
                    // Optional `used N {unit}` initial-consumed value.
                    if self.peek() == "used" {
                        self.advance();
                        if let Ok(u) = self.peek().parse::<u64>() {
                            self.advance();
                            let umul = match self.peek() {
                                "kbytes" => { self.advance(); 1u64 << 10 }
                                "mbytes" => { self.advance(); 1u64 << 20 }
                                "gbytes" => { self.advance(); 1u64 << 30 }
                                "bytes"  => { self.advance(); 1u64 }
                                _ => 1u64,
                            };
                            cmd.obj_spec.quota_consumed = u * umul;
                        }
                    }
                }
            }
            return Ok(Some(cmd));
        }

        // Chain block
        if matches!(cmd.obj, CmdObj::Chain) && matches!(cmd.op, CmdOp::Add | CmdOp::Create) && self.peek() == "{" {
            self.parse_chain_block(&mut cmd)?;
            return Ok(Some(cmd));
        }

        // Chain rename
        if matches!(cmd.obj, CmdObj::Chain) && matches!(cmd.op, CmdOp::Rename) {
            cmd.new_name = self.parse_name();
            return Ok(Some(cmd));
        }

        // Set block
        if matches!(cmd.obj, CmdObj::Set | CmdObj::Map) && matches!(cmd.op, CmdOp::Add | CmdOp::Create) && self.peek() == "{" {
            self.parse_set_block(&mut cmd)?;
            if matches!(cmd.obj, CmdObj::Map) { cmd.set_spec.is_map = true; }
            return Ok(Some(cmd));
        }

        // Element block
        if matches!(cmd.obj, CmdObj::Element) && !self.at_end() && self.peek() == "{" {
            self.parse_element_block(&mut cmd);
            return Ok(Some(cmd));
        }

        // Rule positioning: `[add|insert|replace] rule T C [position N |
        // handle N | index N] EXPRS`. `position` and `handle` both take
        // the kernel rule handle as the anchor; `index` is a 0-based
        // ordinal within the chain that we resolve to a handle via a
        // GETRULE dump at exec time. All three set has_handle so the
        // encoder can attach NFTA_RULE_POSITION to the netlink msg.
        if matches!(cmd.obj, CmdObj::Rule) {
            match self.peek() {
                "handle" | "position" => {
                    self.advance();
                    let htok = self.advance().to_string();
                    if htok.starts_with('-') {
                        return Err("syntax error, unexpected -, expecting number".into());
                    }
                    cmd.handle = htok.parse().unwrap_or(0);
                    cmd.has_handle = true;
                }
                "index" => {
                    self.advance();
                    cmd.rule_index = self.advance().parse().unwrap_or(-1);
                    cmd.has_rule_index = true;
                }
                _ => {}
            }
            if matches!(cmd.op, CmdOp::Add | CmdOp::Insert | CmdOp::Replace) {
                self.parse_rule_exprs(&mut cmd);
            }
        }

        Ok(Some(cmd))
    }
}

pub fn parse(input: &str) -> Result<Vec<Command>, String> {
    // JSON detection: if the first non-whitespace byte is '{', treat the
    // input as an nft JSON command stream (as produced by `nft -j list
    // ruleset` or hand-written for `nft -j -f file.json`). This is the
    // same convention upstream libnftables uses internally.
    if input.trim_start().starts_with('{') {
        let v = crate::json::parse(input).map_err(|e| format!("json: {}", e))?;
        return json_to_commands(&v);
    }

    // Variable preprocessor. nft(8) documents `define NAME = value`
    // declarations and `$NAME` references; both are purely textual
    // (the kernel never sees them). Strip defines out of the input
    // and substitute uses inline before tokenising. A value can span
    // multiple tokens (`define ADDRS = { 1.1.1.1, 2.2.2.2 }`), so we
    // capture up to end-of-line, respecting balanced braces.
    let input = expand_variables(input)?;
    let input = input.as_str();

    let tokens = tokenize(input)?;
    let mut parser = Parser::new(tokens);
    let mut cmds = Vec::new();
    while !parser.at_end() {
        while parser.matches(";") {}
        if parser.at_end() { break; }

        // Declarative top-level block: `table FAMILY NAME { ... }` with no
        // leading verb. Standard /etc/nftables.conf style.
        if parser.peek() == "table" {
            parser.parse_declarative_table(&mut cmds)?;
            if let Some(err) = parser.deferred_errors.first() {
                return Err(err.clone());
            }
            continue;
        }

        // Bare object keyword without a verb (e.g. `chain inet filter
        // c { ... }` is shorthand for `add chain ...`). Inject a
        // synthetic "add" token so parse_command sees a well-formed
        // command.
        if matches!(parser.peek(), "chain" | "set" | "map" | "flowtable"
            | "counter" | "quota" | "limit" | "element")
        {
            parser.inject("add");
        }

        if let Some(cmd) = parser.parse_command()? {
            cmds.extend(parser.pending_anon_chains.drain(..));
            cmds.push(cmd);
        }
        // Drain any extra commands generated by parse_table_block (inline
        // `add table ... { counter/quota/... }` form).
        cmds.extend(parser.pending_commands.drain(..));
        if let Some(err) = parser.deferred_errors.first() {
            return Err(err.clone());
        }
    }
    Ok(cmds)
}


/// Like `parse`, but honours a list of include search directories that
/// were supplied via `-I`/`--include-path` flags.
pub fn parse_with_paths(input: &str, include_paths: &[String]) -> Result<Vec<Command>, String> {
    if input.trim_start().starts_with('{') {
        let v = crate::json::parse(input).map_err(|e| format!("json: {}", e))?;
        return json_to_commands(&v);
    }

    let mut defs: std::collections::HashMap<String, String> = std::collections::HashMap::new();
    let input = expand_variables_with_paths(&mut defs, input, include_paths)?;
    let input = input.as_str();

    let tokens = tokenize(input)?;
    let mut parser = Parser::new(tokens);
    let mut cmds = Vec::new();
    while !parser.at_end() {
        while parser.matches(";") {}
        if parser.at_end() { break; }

        if parser.peek() == "table" {
            parser.parse_declarative_table(&mut cmds)?;
            if let Some(err) = parser.deferred_errors.first() {
                return Err(err.clone());
            }
            continue;
        }

        // Bare object keyword → implicit `add` (same as in parse()).
        if matches!(parser.peek(), "chain" | "set" | "map" | "flowtable"
            | "counter" | "quota" | "limit" | "element")
        {
            parser.inject("add");
        }

        if let Some(cmd) = parser.parse_command()? {
            cmds.extend(parser.pending_anon_chains.drain(..));
            cmds.push(cmd);
        }
        cmds.extend(parser.pending_commands.drain(..));
        if let Some(err) = parser.deferred_errors.first() {
            return Err(err.clone());
        }
    }
    Ok(cmds)
}

// ── JSON command interpreter ────────────────────────────────────
//
// Walks the {"nftables": [...]} array and turns each element into a
// Command. Handles both the verb-wrapped form used for command scripts
//   {"add": {"table": {...}}}
// and the bare-object form used for dumps
//   {"table": {...}}.
// Rules inside a JSON dump carry a "raw" string field with the
// text-rendered rule body; we re-parse that body through the text
// parser so stormwall can round-trip its own JSON output (the
// upstream framework runs `-j --check -f <json>` on stormwall's own
// emission and expects it to succeed).

use crate::json::Value as JV;

fn json_to_commands(v: &JV) -> Result<Vec<Command>, String> {
    let root = v.as_object().ok_or("json: expected top-level object")?;
    let arr = root.get("nftables").and_then(|x| x.as_array())
        .ok_or("json: expected \"nftables\" array")?;
    let mut out = Vec::new();
    'items: for item in arr {
        let obj = match item.as_object() { Some(o) => o, None => continue };
        if let Some(mi) = obj.get("metainfo").and_then(|x| x.as_object()) {
            // Reject future schema versions we don't understand.
            // Upstream nft errors out on json_schema_version > 1.
            if let Some(v) = mi.get("json_schema_version").and_then(|x| x.as_u64()) {
                if v > 1 {
                    return Err(format!("JSON schema version {} not supported (max 1)", v));
                }
            }
            continue;
        }

        // Verb-wrapped forms: {"add": {"table": {...}}}. Upstream emits
        // these for command scripts. Each object carries exactly one
        // verb key; the nested value is the object spec.
        for (verb, op) in &[("add", CmdOp::Add), ("create", CmdOp::Create),
                             ("delete", CmdOp::Delete), ("destroy", CmdOp::Destroy),
                             ("insert", CmdOp::Insert), ("replace", CmdOp::Replace),
                             ("flush", CmdOp::Flush), ("reset", CmdOp::Reset)] {
            if let Some(inner) = obj.get(*verb).and_then(|x| x.as_object()) {
                if let Some(cmd) = json_object_to_command(inner, op.clone())? {
                    out.push(cmd);
                }
                continue 'items;
            }
        }

        // Bare form (dump): {"table": {...}} → `add table ...`.
        // For rules in dump form, the "handle" field is the existing
        // kernel handle (not a position hint), so clear has_handle so
        // the rule gets appended rather than positioned after itself.
        if let Some(mut cmd) = json_object_to_command(obj, CmdOp::Add)? {
            if matches!(cmd.obj, CmdObj::Rule) { cmd.has_handle = false; }
            out.push(cmd);
        }
    }
    Ok(out)
}

fn json_family(s: &str) -> u8 {
    match s {
        "ip" => NFPROTO_IPV4, "ip6" => NFPROTO_IPV6,
        "inet" => NFPROTO_INET, "arp" => NFPROTO_ARP,
        "bridge" => NFPROTO_BRIDGE, "netdev" => NFPROTO_NETDEV,
        _ => NFPROTO_IPV4,
    }
}

fn json_object_to_command(obj: &std::collections::BTreeMap<String, JV>, op: CmdOp)
    -> Result<Option<Command>, String>
{
    // Each object has exactly one key naming the nft object type.
    // Support the common ones: table, chain, rule, set, map, element.
    // The body may be null for bare singleton objects like {"ruleset": null}.
    let (kind, body_opt) = match obj.iter().next() {
        Some((k, v)) => (k.as_str(), v.as_object()),
        None => return Ok(None),
    };

    // `{"flush": {"ruleset": null}}` — body is null, kind is "ruleset".
    // Treat this as `flush ruleset`.
    if body_opt.is_none() {
        let mut cmd = Command::default();
        cmd.op = op;
        match kind {
            "ruleset" => { cmd.obj = CmdObj::Ruleset; return Ok(Some(cmd)); }
            _ => return Ok(None),
        }
    }
    let body = body_opt.unwrap();

    let mut cmd = Command::default();
    cmd.op = op;
    cmd.family = body.get("family").and_then(|x| x.as_str()).map(json_family).unwrap_or(NFPROTO_IPV4);
    cmd.table = body.get("table").and_then(|x| x.as_str()).unwrap_or("").to_string();

    match kind {
        "table" => {
            cmd.obj = CmdObj::Table;
            cmd.table = body.get("name").and_then(|x| x.as_str()).unwrap_or("").to_string();
        }
        "chain" => {
            cmd.obj = CmdObj::Chain;
            cmd.chain = body.get("name").and_then(|x| x.as_str()).unwrap_or("").to_string();
            if let Some(t) = body.get("type").and_then(|x| x.as_str()) {
                cmd.chain_spec.chain_type = t.to_string();
                cmd.chain_spec.is_base = true;
            }
            if let Some(h) = body.get("hook").and_then(|x| x.as_str()) {
                cmd.chain_spec.hook = h.to_string();
            }
            if let Some(p) = body.get("prio").and_then(|x| x.as_i64()) {
                cmd.chain_spec.priority = p as i32;
                cmd.chain_spec.has_priority = true;
            }
            if let Some(pol) = body.get("policy").and_then(|x| x.as_str()) {
                cmd.chain_spec.policy = pol.to_string();
                cmd.chain_spec.has_policy = true;
            }
            // netdev chain needs a device name for the ingress hook.
            if let Some(dev) = body.get("dev").and_then(|x| x.as_str()) {
                cmd.chain_spec.device = dev.to_string();
                cmd.chain_spec.has_device = true;
            }
        }
        "rule" => {
            cmd.obj = CmdObj::Rule;
            cmd.chain = body.get("chain").and_then(|x| x.as_str()).unwrap_or("").to_string();
            if let Some(h) = body.get("handle").and_then(|x| x.as_u64()) {
                cmd.handle = h; cmd.has_handle = true;
            }
            if let Some(c) = body.get("comment").and_then(|x| x.as_str()) {
                cmd.comment = c.to_string();
                cmd.has_comment = true;
            }
            // If a "raw" text rendering is present (stormwall's own JSON
            // dump carries one), re-parse it through the text expression
            // parser so we can faithfully reconstruct the rule body.
            if let Some(raw) = body.get("raw").and_then(|x| x.as_str()) {
                if !raw.trim().is_empty() {
                    let synth = format!("add rule {} {} {} {}",
                        family_name_for_parse(cmd.family), cmd.table, cmd.chain, raw);
                    if let Ok(mut cmds) = parse(&synth) {
                        if let Some(inner) = cmds.pop() {
                            cmd.exprs = inner.exprs;
                            if inner.has_comment && !cmd.has_comment {
                                cmd.comment = inner.comment;
                                cmd.has_comment = true;
                            }
                        }
                    }
                }
            }
        }
        "set" | "map" => {
            cmd.obj = if kind == "map" { CmdObj::Map } else { CmdObj::Set };
            cmd.set_name = body.get("name").and_then(|x| x.as_str()).unwrap_or("").to_string();
            if let Some(t) = body.get("type").and_then(|x| x.as_str()) {
                let (kt, kl) = crate::netlink::set_key_type(t);
                cmd.set_spec.key_type_name = t.to_string();
                cmd.set_spec.key_type = kt;
                cmd.set_spec.key_len = kl;
            }
            // Map value type comes from the "map" key (e.g., "map": "mark").
            if let Some(vt) = body.get("map").and_then(|x| x.as_str()) {
                let (dt, dl) = crate::netlink::set_key_type(vt);
                cmd.set_spec.data_type_name = vt.to_string();
                cmd.set_spec.data_type = dt;
                cmd.set_spec.data_len = dl;
                cmd.set_spec.is_map = true;
            }
            // Optional set size.
            if let Some(sz) = body.get("size").and_then(|x| x.as_u64()) {
                cmd.set_spec.size = sz as u32;
            }
            // Per-element statement sets need NFT_SET_EVAL flag.
            if body.get("stmt").and_then(|x| x.as_array()).map(|a| !a.is_empty()).unwrap_or(false) {
                cmd.set_spec.flags |= crate::netlink::NFT_SET_EVAL;
            }
            // Flags from JSON ("interval", "timeout", "dynamic", ...).
            match body.get("flags") {
                Some(JV::String(s)) => {
                    for f in s.split(',') {
                        match f.trim() {
                            "constant" => { cmd.set_spec.flags |= 0x2; }
                            "interval" => { cmd.set_spec.flags |= 0x4; }
                            "timeout"  => { cmd.set_spec.flags |= crate::netlink::NFT_SET_TIMEOUT; }
                            "dynamic"  => { cmd.set_spec.flags |= crate::netlink::NFT_SET_EVAL; }
                            _ => {}
                        }
                    }
                }
                Some(JV::Array(arr)) => {
                    for jv in arr {
                        if let Some(s) = jv.as_str() {
                            match s {
                                "constant" => { cmd.set_spec.flags |= 0x2; }
                                "interval" => { cmd.set_spec.flags |= 0x4; }
                                "timeout"  => { cmd.set_spec.flags |= crate::netlink::NFT_SET_TIMEOUT; }
                                "dynamic"  => { cmd.set_spec.flags |= crate::netlink::NFT_SET_EVAL; }
                                _ => {}
                            }
                        }
                    }
                }
                _ => {}
            }
        }
        "counter" => {
            cmd.obj = CmdObj::Counter;
            cmd.obj_spec.kind = NFT_OBJECT_COUNTER;
            cmd.set_name = body.get("name").and_then(|x| x.as_str()).unwrap_or("").to_string();
            if let Some(p) = body.get("packets").and_then(|x| x.as_u64()) {
                cmd.obj_spec.packets = p;
            }
            if let Some(b) = body.get("bytes").and_then(|x| x.as_u64()) {
                cmd.obj_spec.bytes = b;
            }
            if let Some(c) = body.get("comment").and_then(|x| x.as_str()) {
                cmd.comment = c.to_string();
                cmd.has_comment = true;
            }
        }
        "quota" => {
            cmd.obj = CmdObj::Quota;
            cmd.obj_spec.kind = NFT_OBJECT_QUOTA;
            cmd.set_name = body.get("name").and_then(|x| x.as_str()).unwrap_or("").to_string();
            if let Some(b) = body.get("bytes").and_then(|x| x.as_u64()) {
                cmd.obj_spec.bytes = b;
            }
            if matches!(body.get("inv"), Some(JV::Bool(true))) {
                cmd.obj_spec.quota_flags |= 1; // NFT_QUOTA_F_INV
            }
        }
        "limit" => {
            cmd.obj = CmdObj::Limit;
            cmd.obj_spec.kind = NFT_OBJECT_LIMIT;
            cmd.set_name = body.get("name").and_then(|x| x.as_str()).unwrap_or("").to_string();
            if let Some(r) = body.get("rate").and_then(|x| x.as_u64()) {
                cmd.obj_spec.limit_rate = r;
            }
            if let Some(b) = body.get("burst").and_then(|x| x.as_u64()) {
                cmd.obj_spec.limit_burst = b as u32;
            }
            cmd.obj_spec.limit_unit = match body.get("per").and_then(|x| x.as_str()) {
                Some("second") | None => 1,
                Some("minute") => 60,
                Some("hour")   => 3600,
                Some("day")    => 86400,
                _              => 1,
            };
            if body.get("rate_unit").and_then(|x| x.as_str()) == Some("bytes") {
                cmd.obj_spec.limit_type = 1; // NFT_LIMIT_PKT_BYTES
            }
        }
        "flowtable" => {
            cmd.obj = CmdObj::Flowtable;
            cmd.set_name = body.get("name").and_then(|x| x.as_str()).unwrap_or("").to_string();
            if let Some(h) = body.get("hook").and_then(|x| x.as_str()) {
                cmd.flow_spec.hook = h.to_string();
            }
            if let Some(p) = body.get("prio").and_then(|x| x.as_i64()) {
                cmd.flow_spec.priority = p as i32;
            }
            if let Some(devs) = body.get("dev").and_then(|x| x.as_array()) {
                for d in devs {
                    if let Some(s) = d.as_str() {
                        cmd.flow_spec.devices.push(s.to_string());
                    }
                }
            } else if let Some(dev) = body.get("dev").and_then(|x| x.as_str()) {
                cmd.flow_spec.devices.push(dev.to_string());
            }
        }
        "element" => {
            cmd.obj = CmdObj::Element;
            cmd.set_name = body.get("name").and_then(|x| x.as_str()).unwrap_or("").to_string();
        }
        "ct helper" => {
            cmd.obj = CmdObj::CtHelper;
            cmd.obj_spec.kind = NFT_OBJECT_CT_HELPER;
            cmd.set_name = body.get("name").and_then(|x| x.as_str()).unwrap_or("").to_string();
            if let Some(t) = body.get("type").and_then(|x| x.as_str()) {
                cmd.obj_spec.helper_type = t.to_string();
            }
            cmd.obj_spec.helper_l4proto = match body.get("protocol").and_then(|x| x.as_str()) {
                Some("tcp")  => 6,
                Some("udp")  => 17,
                Some("dccp") => 33,
                Some("sctp") => 132,
                _            => 0,
            };
            cmd.obj_spec.helper_l3proto = match body.get("l3proto").and_then(|x| x.as_str()) {
                Some("ip")   => NFPROTO_IPV4 as u16,
                Some("ip6")  => NFPROTO_IPV6 as u16,
                Some("inet") => NFPROTO_INET as u16,
                _            => cmd.family as u16,
            };
        }
        "ct timeout" => {
            cmd.obj = CmdObj::CtTimeout;
            cmd.obj_spec.kind = NFT_OBJECT_CT_TIMEOUT;
            cmd.set_name = body.get("name").and_then(|x| x.as_str()).unwrap_or("").to_string();
            cmd.obj_spec.ct_timeout_l4proto = match body.get("protocol").and_then(|x| x.as_str()) {
                Some("tcp")  => 6,
                Some("udp")  => 17,
                Some("dccp") => 33,
                Some("sctp") => 132,
                _            => 0,
            };
            cmd.obj_spec.ct_timeout_l3proto = match body.get("l3proto").and_then(|x| x.as_str()) {
                Some("ip")   => NFPROTO_IPV4 as u16,
                Some("ip6")  => NFPROTO_IPV6 as u16,
                Some("inet") => NFPROTO_INET as u16,
                _            => cmd.family as u16,
            };
            if let Some(pol) = body.get("policy").and_then(|x| x.as_object()) {
                for (state, val) in pol {
                    if let Some(secs) = val.as_u64() {
                        cmd.obj_spec.ct_timeout_policy.push((state.clone(), secs as u32));
                    }
                }
            }
        }
        "ct expectation" => {
            cmd.obj = CmdObj::CtExpect;
            cmd.obj_spec.kind = NFT_OBJECT_CT_EXPECT;
            cmd.set_name = body.get("name").and_then(|x| x.as_str()).unwrap_or("").to_string();
            cmd.obj_spec.ct_expect_l3proto = match body.get("l3proto").and_then(|x| x.as_str()) {
                Some("ip")   => NFPROTO_IPV4 as u16,
                Some("ip6")  => NFPROTO_IPV6 as u16,
                Some("inet") => NFPROTO_INET as u16,
                _            => cmd.family as u16,
            };
            cmd.obj_spec.ct_expect_protocol = match body.get("protocol").and_then(|x| x.as_str()) {
                Some("tcp")  => 6,
                Some("udp")  => 17,
                Some("dccp") => 33,
                Some("sctp") => 132,
                _            => 0,
            };
            if let Some(p) = body.get("dport").and_then(|x| x.as_u64()) {
                cmd.obj_spec.ct_expect_dport = p as u16;
            }
            if let Some(t) = body.get("timeout").and_then(|x| x.as_u64()) {
                cmd.obj_spec.ct_expect_timeout = t as u32;
            }
            if let Some(s) = body.get("size").and_then(|x| x.as_u64()) {
                cmd.obj_spec.ct_expect_size = s as u8;
            }
        }
        "synproxy" => {
            cmd.obj = CmdObj::Synproxy;
            cmd.obj_spec.kind = NFT_OBJECT_SYNPROXY;
            cmd.set_name = body.get("name").and_then(|x| x.as_str()).unwrap_or("").to_string();
            if let Some(m) = body.get("mss").and_then(|x| x.as_u64()) {
                cmd.obj_spec.synproxy_mss = m as u16;
                cmd.obj_spec.synproxy_flags |= 0x01;
            }
            if let Some(w) = body.get("wscale").and_then(|x| x.as_u64()) {
                cmd.obj_spec.synproxy_wscale = w as u8;
                cmd.obj_spec.synproxy_flags |= 0x02;
            }
            if let Some(f) = body.get("flags").and_then(|x| x.as_u64()) {
                cmd.obj_spec.synproxy_flags = f as u32;
            }
        }
        "secmark" => {
            cmd.obj = CmdObj::Secmark;
            cmd.obj_spec.kind = NFT_OBJECT_SECMARK;
            cmd.set_name = body.get("name").and_then(|x| x.as_str()).unwrap_or("").to_string();
            // Upstream nft JSON uses "context" for the SELinux context string.
            if let Some(c) = body.get("context").or_else(|| body.get("ctx"))
                                  .and_then(|x| x.as_str()) {
                cmd.obj_spec.secmark_ctx = c.to_string();
            }
        }
        "tunnel" => {
            cmd.obj = CmdObj::Tunnel;
            cmd.obj_spec.kind = NFT_OBJECT_TUNNEL;
            cmd.set_name = body.get("name").and_then(|x| x.as_str()).unwrap_or("").to_string();
            if let Some(id) = body.get("id").and_then(|x| x.as_u64()) {
                cmd.obj_spec.tunnel_id = id as u32;
            }
        }
        _ => return Ok(None), // unknown — silently ignore for --check
    }
    Ok(Some(cmd))
}

fn family_name_for_parse(f: u8) -> &'static str {
    match f {
        NFPROTO_IPV4 => "ip", NFPROTO_IPV6 => "ip6",
        NFPROTO_INET => "inet", NFPROTO_ARP => "arp",
        NFPROTO_BRIDGE => "bridge", NFPROTO_NETDEV => "netdev",
        _ => "ip",
    }
}

// ── Variable preprocessor ────────────────────────────────────────
//
// Handles `define NAME = value` declarations and `$NAME` references in
// a single preprocessor pass over the input text, before tokenisation.
// Value extends from after `=` to the end of the logical statement:
// the first semicolon or newline at brace-depth 0. Braces and
// double-quoted strings are tracked so `define ADDRS = { 1.1.1.1,
// 2.2.2.2 }` or a value spanning multiple lines both work.

// Minimal shell-style glob: `*` matches any non-slash sequence, `?`
// matches a single non-slash char, anything else literal. Returns
// absolute/relative paths the caller passed through, lexicographically
// sorted — matching nft's `include` behaviour. If the pattern has no
// wildcards the result is just `[pattern]` (to preserve the error
// path for "file not found" errors at read time).
fn glob_expand(pattern: &str) -> Vec<String> {
    let has_wild = pattern.chars().any(|c| c == '*' || c == '?' || c == '[');
    if !has_wild { return vec![pattern.to_string()]; }

    // Split the pattern into (dir, filename-pattern).
    let (dir, fname) = match pattern.rfind('/') {
        Some(i) => (&pattern[..=i], &pattern[i + 1..]),
        None    => ("./", pattern),
    };

    let entries = match std::fs::read_dir(dir) {
        Ok(it) => it,
        Err(_) => return Vec::new(),
    };
    let mut out: Vec<String> = Vec::new();
    for e in entries.flatten() {
        let name = match e.file_name().into_string() { Ok(s) => s, Err(_) => continue };
        if name.starts_with('.') && !fname.starts_with('.') { continue; }
        if glob_match(fname, &name) {
            let full = format!("{}{}", dir, name);
            if let Ok(meta) = std::fs::metadata(&full) {
                if meta.is_dir() { continue; }
            }
            out.push(full);
        }
    }
    out.sort();
    out
}

fn glob_match(pat: &str, s: &str) -> bool {
    // Standard recursive glob — `*` can match zero or more characters
    // within a single path component, `?` matches exactly one.
    let pat = pat.as_bytes();
    let s   = s.as_bytes();
    fn rec(p: &[u8], s: &[u8]) -> bool {
        if p.is_empty() { return s.is_empty(); }
        match p[0] {
            b'*' => {
                for i in 0..=s.len() {
                    if rec(&p[1..], &s[i..]) { return true; }
                }
                false
            }
            b'?' => !s.is_empty() && rec(&p[1..], &s[1..]),
            c    => !s.is_empty() && s[0] == c && rec(&p[1..], &s[1..]),
        }
    }
    rec(pat, s)
}

fn expand_variables(src: &str) -> Result<String, String> {
    let mut defs: std::collections::HashMap<String, String> = std::collections::HashMap::new();
    expand_variables_with_paths(&mut defs, src, &[])
}

fn expand_variables_with(
    defs: &mut std::collections::HashMap<String, String>,
    src: &str,
) -> Result<String, String> {
    expand_variables_with_paths(defs, src, &[])
}

fn expand_variables_with_paths(
    defs: &mut std::collections::HashMap<String, String>,
    src: &str,
    include_paths: &[String],
) -> Result<String, String> {
    let mut out = String::with_capacity(src.len());

    let bytes = src.as_bytes();
    let mut i = 0usize;
    // Running brace depth so `$v` expansion can decide whether to
    // splice `{ ... }` values inline (stripped) vs. preserve the
    // braces when used outside another set literal. Matches upstream
    // where `elements = { 2.2.2.2, $addrs }` unfolds the brace-value.
    let mut brace_depth: i32 = 0;
    while i < bytes.len() {
        // Skip #-comments (preserve them in output).
        if bytes[i] == b'#' {
            while i < bytes.len() && bytes[i] != b'\n' { out.push(bytes[i] as char); i += 1; }
            continue;
        }
        // `include "..."` — inline the referenced file. Matches
        // nft(8)'s directive. Relative paths are resolved against
        // the process cwd; wildcards are expanded with glob order.
        if bytes[i] == b'i'
            && bytes[i..].starts_with(b"include ")
            && (i == 0 || matches!(bytes[i - 1], b' ' | b'\t' | b'\n' | b';'))
        {
            let mut j = i + "include ".len();
            while j < bytes.len() && matches!(bytes[j], b' ' | b'\t') { j += 1; }
            if j >= bytes.len() || bytes[j] != b'"' { i += 1; continue; }
            j += 1;
            let path_start = j;
            while j < bytes.len() && bytes[j] != b'"' { j += 1; }
            if j >= bytes.len() { return Err("unterminated include string".into()); }
            let path = std::str::from_utf8(&bytes[path_start..j]).map_err(|e| e.to_string())?.to_string();
            j += 1; // skip closing quote
            // Eat optional trailing ';' / '\n'.
            while j < bytes.len() && matches!(bytes[j], b' ' | b'\t') { j += 1; }
            if j < bytes.len() && (bytes[j] == b';' || bytes[j] == b'\n') { j += 1; }

            // Expand glob patterns; load each matched file in sorted
            // order and recursively run the preprocessor on it so
            // defines and nested includes inside the file work. The
            // recursive call shares the defs map so the included
            // file's variables are visible to the including one.
            let is_absolute = path.starts_with('/');
            let has_wild = path.chars().any(|c| c == '*' || c == '?' || c == '[');
            let resolved: Vec<String> = if is_absolute {
                glob_expand(&path)
            } else if has_wild {
                let cwd_hits = glob_expand(&path);
                if !cwd_hits.is_empty() {
                    cwd_hits
                } else {
                    let mut found = Vec::new();
                    for dir in include_paths {
                        let candidate = format!("{}/{}", dir.trim_end_matches('/'), path);
                        let hits = glob_expand(&candidate);
                        if !hits.is_empty() { found = hits; break; }
                    }
                    found
                }
            } else {
                if std::fs::metadata(&path).map(|m| !m.is_dir()).unwrap_or(false) {
                    vec![path.clone()]
                } else {
                    let mut found = String::new();
                    for dir in include_paths {
                        let candidate = format!("{}/{}", dir.trim_end_matches('/'), path);
                        if std::fs::metadata(&candidate).map(|m| !m.is_dir()).unwrap_or(false) {
                            found = candidate; break;
                        }
                    }
                    if found.is_empty() { vec![path.clone()] } else { vec![found] }
                }
            };
            for p in &resolved {
                let body = std::fs::read_to_string(p)
                    .map_err(|e| format!("include {}: {}", p, e))?;
                let expanded = expand_variables_with_paths(defs, &body, include_paths)?;
                out.push_str(&expanded);
                out.push('\n');
            }
            i = j;
            continue;
        }

        // $NAME reference.
        if bytes[i] == b'$' {
            let start = i + 1;
            let mut j = start;
            while j < bytes.len() && is_ident_byte(bytes[j]) { j += 1; }
            if j > start {
                let name = std::str::from_utf8(&bytes[start..j]).map_err(|e| e.to_string())?;
                let val = defs.get(name).ok_or_else(|| format!("undefined variable: ${}", name))?;
                // Strip outer braces from a `{ ... }` value only when the
                // reference site is DIRECTLY inside a set element list —
                // i.e. the preceding non-whitespace character is `{` or `,`.
                // This handles `{ $addr, other }` and `elements = { $addr }`
                // correctly while preserving braces for `ip saddr $addr`
                // (where $addr = { 1.1.1.1, 2.2.2.2 }) inside a table block.
                let trimmed = val.trim();
                let prev_non_ws = out.trim_end().as_bytes().last().copied();
                let in_set_literal = matches!(prev_non_ws, Some(b'{') | Some(b','));
                if in_set_literal && trimmed.starts_with('{') && trimmed.ends_with('}') && trimmed.len() >= 2 {
                    out.push_str(trimmed[1..trimmed.len() - 1].trim());
                } else {
                    out.push_str(val);
                }
                i = j;
                continue;
            }
        }

        // Track braces for brace-aware $-expansion above. `{` opens
        // a context (we strip inner $set braces), `}` closes it.
        if bytes[i] == b'{' { brace_depth += 1; }
        if bytes[i] == b'}' { brace_depth = (brace_depth - 1).max(0); }
        // `define` / `redefine` / `undefine` directives — must start
        // a statement.
        let kw = if bytes[i..].starts_with(b"define ")
            && (i == 0 || matches!(bytes[i - 1], b' ' | b'\t' | b'\n' | b';'))
        { Some(("define", true, false)) }
        else if bytes[i..].starts_with(b"redefine ")
            && (i == 0 || matches!(bytes[i - 1], b' ' | b'\t' | b'\n' | b';'))
        { Some(("redefine", true, true)) }
        else if bytes[i..].starts_with(b"undefine ")
            && (i == 0 || matches!(bytes[i - 1], b' ' | b'\t' | b'\n' | b';'))
        { Some(("undefine", false, false)) }
        else { None };
        if let Some((kind, has_value, allow_redefine)) = kw {
            i += kind.len() + 1;
            while i < bytes.len() && matches!(bytes[i], b' ' | b'\t') { i += 1; }
            let name_start = i;
            while i < bytes.len() && is_ident_byte(bytes[i]) { i += 1; }
            let name = std::str::from_utf8(&bytes[name_start..i]).map_err(|e| e.to_string())?.to_string();

            if !has_value {
                // `undefine NAME` — remove the binding. Error if
                // missing, matching nft(8).
                if defs.remove(&name).is_none() {
                    return Err(format!("undefine: unknown variable '{}'", name));
                }
                while i < bytes.len() && matches!(bytes[i], b' ' | b'\t') { i += 1; }
                if i < bytes.len() && (bytes[i] == b';' || bytes[i] == b'\n') { i += 1; }
                continue;
            }

            // `[re]define NAME = VALUE`.
            while i < bytes.len() && matches!(bytes[i], b' ' | b'\t') { i += 1; }
            if i >= bytes.len() || bytes[i] != b'=' {
                return Err(format!("{} {}: expected '='", kind, name));
            }
            i += 1;
            while i < bytes.len() && matches!(bytes[i], b' ' | b'\t') { i += 1; }
            let val_start = i;
            let mut depth = 0i32;
            let mut in_quote = false;
            while i < bytes.len() {
                let c = bytes[i];
                if in_quote {
                    if c == b'\\' && i + 1 < bytes.len() { i += 2; continue; }
                    if c == b'"' { in_quote = false; }
                    i += 1; continue;
                }
                match c {
                    b'"' => { in_quote = true; i += 1; }
                    b'{' | b'(' | b'[' => { depth += 1; i += 1; }
                    b'}' | b')' | b']' => { depth -= 1; i += 1; }
                    b';' | b'\n' if depth == 0 => break,
                    _ => { i += 1; }
                }
            }
            let val = src[val_start..i].trim().to_string();
            // Expand with the current defs map so earlier
            // definitions (from CLI --define or previous lines) are
            // visible inside the new value.
            let expanded = expand_variables_with_paths(defs, &val, include_paths)?;

            // `define` on a name that already exists is an error.
            // `redefine` requires the name to already exist — nft(8)
            // is strict on both.
            match (defs.contains_key(&name), allow_redefine) {
                (true, false) => {
                    return Err(format!("variable '{}' already defined", name));
                }
                (false, true) => {
                    return Err(format!("redefine: unknown variable '{}'", name));
                }
                _ => {}
            }
            defs.insert(name, expanded);
            if i < bytes.len() && (bytes[i] == b';' || bytes[i] == b'\n') { i += 1; }
            continue;
        }
        // Double-quoted strings: expand $NAME references inside them
        // (matching upstream nft behaviour).
        if bytes[i] == b'"' {
            out.push('"'); i += 1;
            while i < bytes.len() {
                if bytes[i] == b'\\' && i + 1 < bytes.len() {
                    out.push(bytes[i] as char); out.push(bytes[i + 1] as char);
                    i += 2; continue;
                }
                if bytes[i] == b'"' { out.push('"'); i += 1; break; }
                // Expand $NAME inside quoted strings. Strip outer
                // quotes from the value so `"prefix $var"` with
                // `define var = "value"` produces `"prefix value"`
                // rather than `"prefix "value""`.
                if bytes[i] == b'$' {
                    let start = i + 1;
                    let mut j = start;
                    while j < bytes.len() && is_ident_byte(bytes[j]) { j += 1; }
                    if j > start {
                        let name = std::str::from_utf8(&bytes[start..j]).map_err(|e| e.to_string())?;
                        let val = defs.get(name).ok_or_else(|| format!("undefined variable: ${}", name))?;
                        let v = val.trim();
                        if v.starts_with('"') && v.ends_with('"') && v.len() >= 2 {
                            out.push_str(&v[1..v.len()-1]);
                        } else {
                            out.push_str(val);
                        }
                        i = j;
                        continue;
                    }
                }
                out.push(bytes[i] as char);
                i += 1;
            }
            continue;
        }
        out.push(bytes[i] as char);
        i += 1;
    }
    Ok(out)
}

/// Parse an nft duration literal (`10s`, `1m`, `2h`, `1d`, `500ms`)
/// into milliseconds. Returns 0 for unparseable input — the rule
/// will be rejected by the kernel rather than silently misbehave.
/// Composite forms like `1m30s` aren't accepted here because nft's
/// own dynset timeout grammar doesn't generate them in the rule
/// stream we round-trip against.
pub fn parse_duration_ms(s: &str) -> u64 {
    let bytes = s.as_bytes();
    let mut split = bytes.len();
    for (i, b) in bytes.iter().enumerate() {
        if !b.is_ascii_digit() { split = i; break; }
    }
    let (num, unit) = (&s[..split], &s[split..]);
    let n: u64 = num.parse().unwrap_or(0);
    match unit {
        "" | "s" => n * 1000,
        "ms" => n,
        "m" => n * 60 * 1000,
        "h" => n * 3600 * 1000,
        "d" => n * 86400 * 1000,
        _ => n * 1000,
    }
}

fn is_ident_byte(b: u8) -> bool {
    b.is_ascii_alphanumeric() || b == b'_' || b == b'-'
}

// ── Tunnel helpers ──────────────────────────────────────────────

fn parse_hex_or_dec_u16(s: &str) -> u16 {
    if let Some(h) = s.strip_prefix("0x").or_else(|| s.strip_prefix("0X")) {
        u16::from_str_radix(h, 16).unwrap_or(0)
    } else {
        s.parse().unwrap_or(0)
    }
}

fn parse_hex_or_dec_u8(s: &str) -> u8 {
    if let Some(h) = s.strip_prefix("0x").or_else(|| s.strip_prefix("0X")) {
        u8::from_str_radix(h, 16).unwrap_or(0)
    } else {
        s.parse().unwrap_or(0)
    }
}

/// Parse a hex string like `"0x12345678"` or `0x12345678` into raw bytes.
fn parse_hex_string(s: &str) -> Vec<u8> {
    let s = s.trim_matches('"');
    let hex = s.strip_prefix("0x").or_else(|| s.strip_prefix("0X")).unwrap_or(s);
    let mut out = Vec::with_capacity(hex.len() / 2);
    let mut i = 0;
    let bytes = hex.as_bytes();
    while i + 1 < bytes.len() {
        let hi = char::from(bytes[i]).to_digit(16).unwrap_or(0) as u8;
        let lo = char::from(bytes[i + 1]).to_digit(16).unwrap_or(0) as u8;
        out.push(hi << 4 | lo);
        i += 2;
    }
    out
}

// ── Helpers ─────────────────────────────────────────────────────

fn ct_state_val(s: &str) -> u32 {
    match s {
        "invalid" => 1, "established" => 2, "related" => 4,
        "new" => 8, "untracked" => 64, _ => 0,
    }
}

fn proto_num(s: &str) -> Option<u8> {
    match s {
        "tcp" => Some(6), "udp" => Some(17), "icmp" => Some(1),
        "icmpv6" => Some(58), "sctp" => Some(132), "esp" => Some(50),
        _ => None,
    }
}

/// TCP flag names → single-byte OR mask. Matches the bit layout of
/// the TCP flags field at byte offset 13: FIN(0), SYN(1), RST(2),
/// PSH(3), ACK(4), URG(5), ECN-Echo(6), CWR(7).
fn tcp_flag_byte(s: &str) -> Option<u8> {
    match s {
        "fin" => Some(0x01),
        "syn" => Some(0x02),
        "rst" => Some(0x04),
        "psh" => Some(0x08),
        "ack" => Some(0x10),
        "urg" => Some(0x20),
        "ecn" | "ece" => Some(0x40),
        "cwr" => Some(0x80),
        _ => None,
    }
}

/// Ethernet hardware address parser. Accepts the canonical
/// colon-separated lowercase hex form `aa:bb:cc:dd:ee:ff`. Returns
/// six bytes in network order. Does not accept dash-separated or
/// any of the other obscure forms `nft` accepts; we add those if
/// real rulesets need them.
fn parse_mac(s: &str) -> Option<[u8; 6]> {
    let parts: Vec<&str> = s.split(':').collect();
    if parts.len() != 6 { return None; }
    let mut out = [0u8; 6];
    for (i, p) in parts.iter().enumerate() {
        if p.len() != 2 { return None; }
        out[i] = u8::from_str_radix(p, 16).ok()?;
    }
    Some(out)
}

/// Ethernet type symbolic names → big-endian 2-byte EtherType. Used
/// when parsing `ether type X` rule values; without this lookup the
/// literal name bytes become the EtherType comparison and the kernel
/// matches the wrong frames.
fn ether_type_num(s: &str) -> Option<u16> {
    match s {
        "ip" | "ipv4" => Some(0x0800),
        "arp" => Some(0x0806),
        "ip6" | "ipv6" => Some(0x86dd),
        "vlan" => Some(0x8100),
        "ppp" => Some(0x880b),
        "8021q" | "qinq" => Some(0x88a8),
        "wlan" => Some(0x88c7),
        _ => None,
    }
}

/// IANA ICMPv6 type names. Numbers come from RFC 4443; the
/// neighbor-discovery extensions live in 133–137. Distinct from the
/// ICMPv4 table — `echo-request` is 128 here, 8 there.
fn icmpv6_type_num(s: &str) -> Option<u8> {
    match s {
        "destination-unreachable" => Some(1),
        "packet-too-big" => Some(2),
        "time-exceeded" => Some(3),
        "parameter-problem" => Some(4),
        "echo-request" => Some(128),
        "echo-reply" => Some(129),
        "mld-listener-query" => Some(130),
        "mld-listener-report" => Some(131),
        "mld-listener-done" => Some(132),
        "nd-router-solicit" => Some(133),
        "nd-router-advert" => Some(134),
        "nd-neighbor-solicit" => Some(135),
        "nd-neighbor-advert" => Some(136),
        "nd-redirect" => Some(137),
        "router-renumbering" => Some(138),
        "ind-neighbor-solicit" => Some(141),
        "ind-neighbor-advert" => Some(142),
        "mld2-listener-report" => Some(143),
        _ => None,
    }
}

/// IANA ICMPv4 type names accepted by upstream nft. Listed here
/// because plain decimal works through the integer-parse path; this
/// table just covers the symbolic forms (`echo-request`, etc.) so
/// `icmp type echo-request` and anon-set members like
/// `icmp type { echo-request, echo-reply }` round-trip.
fn icmp_type_num(s: &str) -> Option<u8> {
    match s {
        "echo-reply" => Some(0),
        "destination-unreachable" => Some(3),
        "source-quench" => Some(4),
        "redirect" => Some(5),
        "echo-request" => Some(8),
        "router-advertisement" => Some(9),
        "router-solicitation" => Some(10),
        "time-exceeded" => Some(11),
        "parameter-problem" => Some(12),
        "timestamp-request" => Some(13),
        "timestamp-reply" => Some(14),
        "info-request" => Some(15),
        "info-reply" => Some(16),
        "address-mask-request" => Some(17),
        "address-mask-reply" => Some(18),
        _ => None,
    }
}

fn meta_key(s: &str) -> (u32, usize) {
    match s {
        "iifname" => (NFT_META_IIFNAME, 16), "oifname" => (NFT_META_OIFNAME, 16),
        "iif" => (NFT_META_IIF, 4), "oif" => (NFT_META_OIF, 4),
        "mark" => (NFT_META_MARK, 4), "skuid" => (NFT_META_SKUID, 4),
        "skgid" => (NFT_META_SKGID, 4), "nfproto" => (NFT_META_NFPROTO, 1),
        "l4proto" => (NFT_META_L4PROTO, 1),
        // pkttype is u8 in the kernel, not u32 — using 4 here makes the
        // kernel reject the comparison as an over-wide register store.
        "pkttype" => (NFT_META_PKTTYPE, 1),
        "priority" => (NFT_META_PRIORITY, 4),
        "length" => (NFT_META_LEN, 4), "protocol" => (NFT_META_PROTOCOL, 2),
        // cpu — packet-processing CPU number (u32).
        "cpu" => (NFT_META_CPU, 4),
        // cgroup — cgroup v2 ancestor id (u32 register store).
        "cgroup" => (NFT_META_CGROUP, 4),
        _ => (0, 4),
    }
}

fn ct_key(s: &str) -> (u32, usize) {
    match s {
        "state" => (NFT_CT_STATE, 4), "mark" => (NFT_CT_MARK, 4),
        "status" => (NFT_CT_STATUS, 4), "direction" => (NFT_CT_DIRECTION, 1),
        "zone" => (NFT_CT_ZONE, 2), "helper" => (NFT_CT_HELPER, 16),
        "l3proto" => (NFT_CT_L3PROTOCOL, 1), "protocol" => (NFT_CT_PROTOCOL, 1),
        "bytes" => (NFT_CT_BYTES, 8), "packets" => (NFT_CT_PKTS, 8),
        "expiration" => (NFT_CT_EXPIRATION, 4), "label" => (NFT_CT_LABELS, 16),
        _ => (0, 4),
    }
}

fn is_statement_start(s: &str) -> bool {
    matches!(s, "accept" | "drop" | "reject" | "return" | "jump" | "goto" | "continue" |
        "counter" | "quota" | "log" | "limit" | "masquerade" | "snat" | "dnat" | "notrack" |
        "meta" | "ct" | "ip" | "ip6" | "tcp" | "udp" | "icmp" | "ether" |
        "iifname" | "oifname" | "comment" | "flow" |
        "dup" | "fwd" | "tproxy" | "synproxy")
}

/// Parse a `meta hour` endpoint into seconds-since-midnight (local TZ).
/// Accepts `"HH:MM"`, `"HH:MM:SS"`, plain `HH:MM[:SS]` (already split into
/// a single quoted token by the parser), or a raw integer count of seconds.
/// The token may carry surrounding `"` from quoting — strip first.
pub(crate) fn parse_hour_endpoint(raw: &str) -> Option<u32> {
    let s = raw.trim_matches('"');
    // Plain decimal integer — accept as raw seconds-of-day, like upstream.
    if !s.is_empty() && s.chars().all(|c| c.is_ascii_digit()) {
        return s.parse::<u32>().ok();
    }
    // HH:MM or HH:MM:SS
    let mut parts = s.split(':');
    let hh: u32 = parts.next()?.parse().ok()?;
    let mm: u32 = parts.next()?.parse().ok()?;
    let ss: u32 = match parts.next() {
        Some(t) => t.parse().ok()?,
        None    => 0,
    };
    if parts.next().is_some() { return None; }
    if hh > 23 || mm > 59 || ss > 59 { return None; }
    Some(hh * 3600 + mm * 60 + ss)
}

/// Convert local-TZ seconds-of-day to the UTC value the kernel stores.
/// Mirrors upstream nft (meta.c hour_type_parse).
pub(crate) fn apply_tz_to_store(local_seconds: u32, gmtoff: i64) -> u32 {
    const DAY: i64 = 86400;
    let s = local_seconds as i64;
    if s >= gmtoff {
        ((s - gmtoff).rem_euclid(DAY)) as u32
    } else {
        (DAY - gmtoff + s) as u32
    }
}

/// Read `localtime_r(time(NULL)).tm_gmtoff` for the current process TZ.
/// Used to translate `meta hour` between wall-clock and the kernel's
/// UTC seconds-of-day. Returns 0 on any libc failure (matching upstream's
/// "no adjustment" fallback).
pub(crate) fn tz_gmtoff_seconds() -> i64 {
    unsafe {
        let now = libc::time(std::ptr::null_mut());
        if now == -1 { return 0; }
        let mut tm: libc::tm = std::mem::zeroed();
        if libc::localtime_r(&now, &mut tm).is_null() { return 0; }
        tm.tm_gmtoff as i64
    }
}

// ── Tests ────────────────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;
    use crate::netlink::*;

    // Helper: parse exactly one command, panic otherwise
    fn parse_one(input: &str) -> Command {
        let mut cmds = parse(input).expect("parse failed");
        assert_eq!(cmds.len(), 1, "expected 1 command, got {}", cmds.len());
        cmds.remove(0)
    }

    // ── Basic table commands ─────────────────────────────────────

    #[test]
    fn test_add_table_ip() {
        let cmd = parse_one("add table ip mytable");
        assert!(matches!(cmd.op, CmdOp::Add));
        assert!(matches!(cmd.obj, CmdObj::Table));
        assert_eq!(cmd.family, NFPROTO_IPV4);
        assert_eq!(cmd.table, "mytable");
    }

    #[test]
    fn test_add_table_inet() {
        let cmd = parse_one("add table inet filter");
        assert!(matches!(cmd.op, CmdOp::Add));
        assert!(matches!(cmd.obj, CmdObj::Table));
        assert_eq!(cmd.family, NFPROTO_INET);
        assert_eq!(cmd.table, "filter");
    }

    #[test]
    fn test_delete_table() {
        let cmd = parse_one("delete table ip mytable");
        assert!(matches!(cmd.op, CmdOp::Delete));
        assert!(matches!(cmd.obj, CmdObj::Table));
        assert_eq!(cmd.family, NFPROTO_IPV4);
        assert_eq!(cmd.table, "mytable");
    }

    #[test]
    fn test_list_ruleset() {
        let cmd = parse_one("list ruleset");
        assert!(matches!(cmd.op, CmdOp::List));
        assert!(matches!(cmd.obj, CmdObj::Ruleset));
    }

    #[test]
    fn test_list_tables() {
        let cmd = parse_one("list tables");
        assert!(matches!(cmd.op, CmdOp::List));
        assert!(matches!(cmd.obj, CmdObj::Tables));
    }

    #[test]
    fn test_flush_ruleset() {
        let cmd = parse_one("flush ruleset");
        assert!(matches!(cmd.op, CmdOp::Flush));
        assert!(matches!(cmd.obj, CmdObj::Ruleset));
    }

    // ── Basic chain commands ─────────────────────────────────────

    #[test]
    fn test_add_chain() {
        let cmd = parse_one("add chain ip filter mychain");
        assert!(matches!(cmd.op, CmdOp::Add));
        assert!(matches!(cmd.obj, CmdObj::Chain));
        assert_eq!(cmd.family, NFPROTO_IPV4);
        assert_eq!(cmd.table, "filter");
        assert_eq!(cmd.chain, "mychain");
    }

    #[test]
    fn test_delete_chain() {
        let cmd = parse_one("delete chain inet filter input");
        assert!(matches!(cmd.op, CmdOp::Delete));
        assert!(matches!(cmd.obj, CmdObj::Chain));
        assert_eq!(cmd.family, NFPROTO_INET);
        assert_eq!(cmd.table, "filter");
        assert_eq!(cmd.chain, "input");
    }

    #[test]
    fn test_list_chain() {
        let cmd = parse_one("list chain ip filter mychain");
        assert!(matches!(cmd.op, CmdOp::List));
        assert!(matches!(cmd.obj, CmdObj::Chain));
        assert_eq!(cmd.table, "filter");
        assert_eq!(cmd.chain, "mychain");
    }

    // ── Base chain spec ──────────────────────────────────────────

    #[test]
    fn test_add_chain_base_chain_spec() {
        let cmd = parse_one(
            "add chain inet filter input { type filter hook input priority filter; policy accept; }"
        );
        assert!(matches!(cmd.op, CmdOp::Add));
        assert!(matches!(cmd.obj, CmdObj::Chain));
        assert_eq!(cmd.family, NFPROTO_INET);
        assert_eq!(cmd.table, "filter");
        assert_eq!(cmd.chain, "input");

        let cs = &cmd.chain_spec;
        assert!(cs.is_base, "expected is_base=true");
        assert_eq!(cs.chain_type, "filter");
        assert_eq!(cs.hook, "input");
        assert_eq!(cs.priority, 0, "filter priority on inet should be 0");
        assert!(cs.has_priority);
        assert_eq!(cs.policy, "accept");
        assert!(cs.has_policy);
    }

    #[test]
    fn test_add_chain_prerouting_dstnat() {
        let cmd = parse_one(
            "add chain ip nat prerouting { type nat hook prerouting priority dstnat; policy accept; }"
        );
        let cs = &cmd.chain_spec;
        assert!(cs.is_base);
        assert_eq!(cs.chain_type, "nat");
        assert_eq!(cs.hook, "prerouting");
        // dstnat priority on ip = -100
        assert_eq!(cs.priority, -100);
        assert!(cs.has_policy);
        assert_eq!(cs.policy, "accept");
    }

    #[test]
    fn test_add_chain_numeric_priority() {
        let cmd = parse_one(
            "add chain ip filter fwd { type filter hook forward priority 50; policy drop; }"
        );
        let cs = &cmd.chain_spec;
        assert!(cs.is_base);
        assert_eq!(cs.priority, 50);
        assert_eq!(cs.policy, "drop");
    }

    // ── Basic rule commands ──────────────────────────────────────

    #[test]
    fn test_add_rule_empty() {
        let cmd = parse_one("add rule ip filter input accept");
        assert!(matches!(cmd.op, CmdOp::Add));
        assert!(matches!(cmd.obj, CmdObj::Rule));
        assert_eq!(cmd.family, NFPROTO_IPV4);
        assert_eq!(cmd.table, "filter");
        assert_eq!(cmd.chain, "input");
    }

    #[test]
    fn test_delete_rule_by_handle() {
        let cmd = parse_one("delete rule ip filter input handle 42");
        assert!(matches!(cmd.op, CmdOp::Delete));
        assert!(matches!(cmd.obj, CmdObj::Rule));
        assert_eq!(cmd.handle, 42);
        assert!(cmd.has_handle);
    }

    // ── Rule expressions: ip saddr/daddr ─────────────────────────

    #[test]
    fn test_rule_ip_saddr() {
        let cmd = parse_one("add rule ip filter input ip saddr 192.168.1.1 accept");
        let exprs = &cmd.exprs;
        // Meta(nfproto) + Cmp(ipv4) + Payload load + Cmp + Verdict
        assert!(exprs.len() >= 5, "expected at least 5 exprs, got {}", exprs.len());

        // The parser injects `meta nfproto ipv4` before ip payload.
        match &exprs[0] {
            Expr::Meta { key, .. } => assert_eq!(*key, NFT_META_NFPROTO),
            other => panic!("expected Meta(nfproto), got {:?}", other),
        }
        match &exprs[2] {
            Expr::Payload { base, offset, len, .. } => {
                assert_eq!(*base, NFT_PAYLOAD_NETWORK_HEADER);
                assert_eq!(*offset, 12); // saddr offset
                assert_eq!(*len, 4);
            }
            other => panic!("expected Payload, got {:?}", other),
        }
        match &exprs[3] {
            Expr::Cmp { op, data } => {
                assert_eq!(*op, NFT_CMP_EQ);
                assert_eq!(data, &[192, 168, 1, 1]);
            }
            other => panic!("expected Cmp, got {:?}", other),
        }
        match &exprs[4] {
            Expr::Verdict { code, .. } => assert_eq!(*code, NF_ACCEPT),
            other => panic!("expected Verdict, got {:?}", other),
        }
    }

    #[test]
    fn test_rule_ip_daddr() {
        let cmd = parse_one("add rule ip filter output ip daddr 10.0.0.1 drop");
        let exprs = &cmd.exprs;
        // Meta(nfproto) + Cmp(ipv4) injected before ip payload.
        match &exprs[2] {
            Expr::Payload { offset, .. } => assert_eq!(*offset, 16), // daddr offset
            other => panic!("expected Payload, got {:?}", other),
        }
        match &exprs[3] {
            Expr::Cmp { data, .. } => assert_eq!(data, &[10, 0, 0, 1]),
            other => panic!("expected Cmp, got {:?}", other),
        }
        match &exprs[4] {
            Expr::Verdict { code, .. } => assert_eq!(*code, NF_DROP),
            other => panic!("expected Verdict(drop), got {:?}", other),
        }
    }

    // ── Rule expressions: tcp dport ──────────────────────────────

    #[test]
    fn test_rule_tcp_dport() {
        let cmd = parse_one("add rule ip filter input tcp dport 80 accept");
        let exprs = &cmd.exprs;
        // exprs[0] = Meta(l4proto), exprs[1] = Cmp(eq, 6) — implicit dependency injection
        match &exprs[0] {
            Expr::Meta { key, .. } => assert_eq!(*key, NFT_META_L4PROTO),
            other => panic!("expected Meta(l4proto), got {:?}", other),
        }
        match &exprs[1] {
            Expr::Cmp { data, .. } => assert_eq!(data, &[6]), // TCP proto number
            other => panic!("expected Cmp(proto=6), got {:?}", other),
        }
        match &exprs[2] {
            Expr::Payload { base, offset, len, protocol } => {
                assert_eq!(*base, NFT_PAYLOAD_TRANSPORT_HEADER);
                assert_eq!(*offset, 2);
                assert_eq!(*len, 2);
                assert_eq!(*protocol, 6); // TCP
            }
            other => panic!("expected Payload, got {:?}", other),
        }
        match &exprs[3] {
            Expr::Cmp { data, .. } => assert_eq!(data, &[0, 80]),
            other => panic!("expected Cmp(80), got {:?}", other),
        }
    }

    #[test]
    fn test_rule_tcp_sport() {
        let cmd = parse_one("add rule ip filter input tcp sport 443 accept");
        // exprs[0] = Meta(l4proto), exprs[1] = Cmp(eq, 6) — implicit dependency injection
        match &cmd.exprs[0] {
            Expr::Meta { key, .. } => assert_eq!(*key, NFT_META_L4PROTO),
            other => panic!("expected Meta(l4proto), got {:?}", other),
        }
        match &cmd.exprs[1] {
            Expr::Cmp { data, .. } => assert_eq!(data, &[6]), // TCP proto number
            other => panic!("expected Cmp(proto=6), got {:?}", other),
        }
        match &cmd.exprs[2] {
            Expr::Payload { offset, .. } => assert_eq!(*offset, 0),
            other => panic!("expected Payload, got {:?}", other),
        }
        match &cmd.exprs[3] {
            Expr::Cmp { data, .. } => assert_eq!(data, &[1, 187]), // 443 = 0x01BB
            other => panic!("expected Cmp, got {:?}", other),
        }
    }

    // ── Rule expressions: meta iifname ───────────────────────────

    #[test]
    fn test_rule_meta_iifname() {
        // Use unquoted name so parse_value gets plain bytes without surrounding quotes
        let cmd = parse_one("add rule ip filter input meta iifname eth0 accept");
        match &cmd.exprs[0] {
            Expr::Meta { key, .. } => assert_eq!(*key, NFT_META_IIFNAME),
            other => panic!("expected Meta, got {:?}", other),
        }
        match &cmd.exprs[1] {
            Expr::Cmp { data, .. } => {
                // Interface name: "eth0" + null terminator, padded to 16 bytes
                assert_eq!(data[0..4], *b"eth0");
                assert_eq!(data[4], 0); // null terminator
            }
            other => panic!("expected Cmp, got {:?}", other),
        }
    }

    #[test]
    fn test_rule_iifname_shorthand() {
        let cmd = parse_one("add rule ip filter input iifname lo accept");
        match &cmd.exprs[0] {
            Expr::Meta { key, .. } => assert_eq!(*key, NFT_META_IIFNAME),
            other => panic!("expected Meta(iifname), got {:?}", other),
        }
    }

    #[test]
    fn test_rule_oifname_shorthand() {
        let cmd = parse_one("add rule ip filter output oifname eth0 drop");
        match &cmd.exprs[0] {
            Expr::Meta { key, .. } => assert_eq!(*key, NFT_META_OIFNAME),
            other => panic!("expected Meta(oifname), got {:?}", other),
        }
    }

    // ── Rule expressions: ct state ───────────────────────────────

    #[test]
    fn test_rule_ct_state_established() {
        let cmd = parse_one("add rule ip filter input ct state established accept");
        match &cmd.exprs[0] {
            Expr::Ct { key, dir, .. } => {
                assert_eq!(*key, NFT_CT_STATE);
                assert_eq!(*dir, -1);
            }
            other => panic!("expected Ct, got {:?}", other),
        }
        // ct state uses bitwise mask matching
        match &cmd.exprs[1] {
            Expr::Bitwise { mask, xor } => {
                let val = u32::from_ne_bytes(mask[..4].try_into().unwrap());
                assert_eq!(val, 2); // established = 2
                assert_eq!(xor, &[0, 0, 0, 0]);
            }
            other => panic!("expected Bitwise, got {:?}", other),
        }
        match &cmd.exprs[2] {
            Expr::Cmp { op, data } => {
                assert_eq!(*op, NFT_CMP_NEQ);
                assert_eq!(data, &[0, 0, 0, 0]);
            }
            other => panic!("expected Cmp(NEQ, 0), got {:?}", other),
        }
    }

    #[test]
    fn test_rule_ct_state_new_established() {
        let cmd = parse_one("add rule ip filter input ct state new,established accept");
        match &cmd.exprs[1] {
            Expr::Bitwise { mask, .. } => {
                let val = u32::from_ne_bytes(mask[..4].try_into().unwrap());
                assert_eq!(val, 8 | 2); // new=8, established=2
            }
            other => panic!("expected Bitwise, got {:?}", other),
        }
        match &cmd.exprs[2] {
            Expr::Cmp { op, data } => {
                assert_eq!(*op, NFT_CMP_NEQ);
                assert_eq!(data, &[0, 0, 0, 0]);
            }
            other => panic!("expected Cmp(NEQ, 0), got {:?}", other),
        }
    }

    // ── Rule expressions: counter ────────────────────────────────

    #[test]
    fn test_rule_counter() {
        let cmd = parse_one("add rule ip filter input counter accept");
        assert!(cmd.exprs.iter().any(|e| matches!(e, Expr::Counter)),
            "expected Counter expr");
    }

    // ── Rule expressions: log ────────────────────────────────────

    #[test]
    fn test_rule_log_no_prefix() {
        let cmd = parse_one("add rule ip filter input log drop");
        assert!(cmd.exprs.iter().any(|e| matches!(e, Expr::Log { .. })),
            "expected Log expr");
    }

    #[test]
    fn test_rule_log_with_prefix() {
        let cmd = parse_one("add rule ip filter input log prefix \"DROP: \" drop");
        let log_expr = cmd.exprs.iter().find(|e| matches!(e, Expr::Log { .. }));
        assert!(log_expr.is_some());
        match log_expr.unwrap() {
            Expr::Log { prefix } => assert_eq!(prefix, "DROP: "),
            _ => unreachable!(),
        }
    }

    // ── Rule expressions: limit ──────────────────────────────────

    #[test]
    fn test_rule_limit_rate() {
        // The parser expects rate, "/", and unit as separate tokens
        let cmd = parse_one("add rule ip filter input limit rate 100 / second accept");
        let limit_expr = cmd.exprs.iter().find(|e| matches!(e, Expr::Limit { .. }));
        assert!(limit_expr.is_some(), "expected Limit expr");
        match limit_expr.unwrap() {
            Expr::Limit { rate, unit, .. } => {
                assert_eq!(*rate, 100);
                assert_eq!(*unit, 1); // second = 1
            }
            _ => unreachable!(),
        }
    }

    #[test]
    fn test_rule_limit_per_minute() {
        // The parser expects rate, "/", and unit as separate tokens
        let cmd = parse_one("add rule ip filter input limit rate 10 / minute accept");
        let limit_expr = cmd.exprs.iter().find(|e| matches!(e, Expr::Limit { .. }));
        match limit_expr.unwrap() {
            Expr::Limit { rate, unit, .. } => {
                assert_eq!(*rate, 10);
                assert_eq!(*unit, 60); // minute = 60
            }
            _ => unreachable!(),
        }
    }

    // ── Rule expressions: verdicts ───────────────────────────────

    #[test]
    fn test_rule_verdict_accept() {
        let cmd = parse_one("add rule ip filter input accept");
        let v = cmd.exprs.iter().find(|e| matches!(e, Expr::Verdict { .. }));
        match v.unwrap() {
            Expr::Verdict { code, .. } => assert_eq!(*code, NF_ACCEPT),
            _ => unreachable!(),
        }
    }

    #[test]
    fn test_rule_verdict_drop() {
        let cmd = parse_one("add rule ip filter input drop");
        let v = cmd.exprs.iter().find(|e| matches!(e, Expr::Verdict { .. }));
        match v.unwrap() {
            Expr::Verdict { code, .. } => assert_eq!(*code, NF_DROP),
            _ => unreachable!(),
        }
    }

    #[test]
    fn test_rule_verdict_jump() {
        let cmd = parse_one("add rule ip filter input jump log-and-drop");
        let v = cmd.exprs.iter().find(|e| matches!(e, Expr::Verdict { .. }));
        match v.unwrap() {
            Expr::Verdict { code, chain } => {
                assert_eq!(*code, NFT_JUMP);
                assert_eq!(chain, "log-and-drop");
            }
            _ => unreachable!(),
        }
    }

    #[test]
    fn test_rule_verdict_goto() {
        let cmd = parse_one("add rule ip filter input goto mychaintarget");
        let v = cmd.exprs.iter().find(|e| matches!(e, Expr::Verdict { .. }));
        match v.unwrap() {
            Expr::Verdict { code, chain } => {
                assert_eq!(*code, NFT_GOTO);
                assert_eq!(chain, "mychaintarget");
            }
            _ => unreachable!(),
        }
    }

    // ── Rule expressions: masquerade ─────────────────────────────

    #[test]
    fn test_rule_masquerade() {
        let cmd = parse_one("add rule ip nat postrouting masquerade");
        assert!(cmd.exprs.iter().any(|e| matches!(e, Expr::Masquerade { .. })),
            "expected Masquerade expr");
    }

    // ── Rule expressions: snat/dnat ──────────────────────────────

    #[test]
    fn test_rule_snat() {
        let cmd = parse_one("add rule ip nat postrouting snat to 203.0.113.5");
        let nat = cmd.exprs.iter().find(|e| matches!(e, Expr::Nat { .. }));
        assert!(nat.is_some(), "expected Nat expr");
        match nat.unwrap() {
            Expr::Nat { nat_type, addr, has_addr, has_port, .. } => {
                assert_eq!(*nat_type, NFT_NAT_SNAT);
                assert!(has_addr);
                assert!(!has_port);
                assert_eq!(addr, &[203, 0, 113, 5]);
            }
            _ => unreachable!(),
        }
    }

    #[test]
    fn test_rule_dnat() {
        let cmd = parse_one("add rule ip nat prerouting dnat to 10.0.0.10");
        let nat = cmd.exprs.iter().find(|e| matches!(e, Expr::Nat { .. }));
        match nat.unwrap() {
            Expr::Nat { nat_type, addr, has_addr, .. } => {
                assert_eq!(*nat_type, NFT_NAT_DNAT);
                assert!(has_addr);
                assert_eq!(addr, &[10, 0, 0, 10]);
            }
            _ => unreachable!(),
        }
    }

    // ── Rule expressions: notrack/reject ─────────────────────────

    #[test]
    fn test_rule_notrack() {
        let cmd = parse_one("add rule ip raw prerouting notrack");
        assert!(cmd.exprs.iter().any(|e| matches!(e, Expr::Notrack)),
            "expected Notrack expr");
    }

    #[test]
    fn test_rule_reject() {
        let cmd = parse_one("add rule ip filter input reject");
        assert!(cmd.exprs.iter().any(|e| matches!(e, Expr::Reject)),
            "expected Reject expr");
    }

    // ── CIDR matching ────────────────────────────────────────────

    #[test]
    fn test_rule_cidr_8() {
        let cmd = parse_one("add rule ip filter input ip saddr 10.0.0.0/8 accept");
        // Expected: Meta(nfproto) + Cmp + Payload + Bitwise + Cmp + Verdict
        assert!(cmd.exprs.len() >= 5, "expected at least 5 exprs, got {}", cmd.exprs.len());

        match &cmd.exprs[2] {
            Expr::Payload { base, offset, len, .. } => {
                assert_eq!(*base, NFT_PAYLOAD_NETWORK_HEADER);
                assert_eq!(*offset, 12);
                assert_eq!(*len, 4);
            }
            other => panic!("expected Payload, got {:?}", other),
        }
        match &cmd.exprs[3] {
            Expr::Bitwise { mask, xor } => {
                // /8 mask: 0xff 0x00 0x00 0x00
                assert_eq!(mask, &[0xff, 0x00, 0x00, 0x00]);
                assert_eq!(xor, &[0x00, 0x00, 0x00, 0x00]);
            }
            other => panic!("expected Bitwise, got {:?}", other),
        }
        match &cmd.exprs[4] {
            Expr::Cmp { data, .. } => {
                // 10.0.0.0 & /8 mask = [10, 0, 0, 0]
                assert_eq!(data, &[10, 0, 0, 0]);
            }
            other => panic!("expected Cmp, got {:?}", other),
        }
    }

    #[test]
    fn test_rule_cidr_24() {
        let cmd = parse_one("add rule ip filter input ip saddr 192.168.1.0/24 drop");
        // Meta(nfproto) + Cmp injected before Payload+Bitwise+Cmp.
        match &cmd.exprs[3] {
            Expr::Bitwise { mask, .. } => {
                // /24 mask: 0xff 0xff 0xff 0x00
                assert_eq!(mask, &[0xff, 0xff, 0xff, 0x00]);
            }
            other => panic!("expected Bitwise, got {:?}", other),
        }
        match &cmd.exprs[4] {
            Expr::Cmp { data, .. } => {
                assert_eq!(data, &[192, 168, 1, 0]);
            }
            other => panic!("expected Cmp, got {:?}", other),
        }
    }

    #[test]
    fn test_rule_cidr_32() {
        let cmd = parse_one("add rule ip filter input ip saddr 1.2.3.4/32 accept");
        // Meta(nfproto) + Cmp injected before Payload+Bitwise+Cmp.
        match &cmd.exprs[3] {
            Expr::Bitwise { mask, .. } => {
                assert_eq!(mask, &[0xff, 0xff, 0xff, 0xff]);
            }
            other => panic!("expected Bitwise, got {:?}", other),
        }
        match &cmd.exprs[4] {
            Expr::Cmp { data, .. } => {
                assert_eq!(data, &[1, 2, 3, 4]);
            }
            other => panic!("expected Cmp, got {:?}", other),
        }
    }

    // ── Rename chain ─────────────────────────────────────────────

    #[test]
    fn test_rename_chain() {
        let cmd = parse_one("rename chain inet filter old_name new_name");
        assert!(matches!(cmd.op, CmdOp::Rename));
        assert!(matches!(cmd.obj, CmdObj::Chain));
        assert_eq!(cmd.family, NFPROTO_INET);
        assert_eq!(cmd.table, "filter");
        assert_eq!(cmd.chain, "old_name");
        assert_eq!(cmd.new_name, "new_name");
    }

    #[test]
    fn test_rename_chain_ip() {
        let cmd = parse_one("rename chain ip mytable src dst");
        assert!(matches!(cmd.op, CmdOp::Rename));
        assert_eq!(cmd.family, NFPROTO_IPV4);
        assert_eq!(cmd.table, "mytable");
        assert_eq!(cmd.chain, "src");
        assert_eq!(cmd.new_name, "dst");
    }

    // ── add set ──────────────────────────────────────────────────

    #[test]
    fn test_add_set_ipv4_constant() {
        let cmd = parse_one(
            "add set inet filter myset { type ipv4_addr; flags constant; }"
        );
        assert!(matches!(cmd.op, CmdOp::Add));
        assert!(matches!(cmd.obj, CmdObj::Set));
        assert_eq!(cmd.family, NFPROTO_INET);
        assert_eq!(cmd.table, "filter");
        assert_eq!(cmd.set_name, "myset");

        let ss = &cmd.set_spec;
        assert_eq!(ss.key_type_name, "ipv4_addr");
        assert_eq!(ss.key_type, 7);  // ipv4_addr type id
        assert_eq!(ss.key_len, 4);   // 4 bytes
        assert!(ss.has_flags);
        assert_eq!(ss.flags & 0x2, 0x2, "expected constant flag (0x2)");
    }

    #[test]
    fn test_add_set_ipv4_interval() {
        let cmd = parse_one(
            "add set ip filter blocked { type ipv4_addr; flags interval; }"
        );
        let ss = &cmd.set_spec;
        assert_eq!(ss.key_type, 7);
        assert_eq!(ss.key_len, 4);
        assert!(ss.has_flags);
        assert_eq!(ss.flags & 0x4, 0x4, "expected interval flag (0x4)");
    }

    #[test]
    fn test_add_set_inet_service() {
        let cmd = parse_one(
            "add set ip filter ports { type inet_service; }"
        );
        let ss = &cmd.set_spec;
        assert_eq!(ss.key_type_name, "inet_service");
        assert_eq!(ss.key_type, 13);
        assert_eq!(ss.key_len, 2);
    }

    // ── delete set ───────────────────────────────────────────────

    #[test]
    fn test_delete_set() {
        let cmd = parse_one("delete set inet filter myset");
        assert!(matches!(cmd.op, CmdOp::Delete));
        assert!(matches!(cmd.obj, CmdObj::Set));
        assert_eq!(cmd.family, NFPROTO_INET);
        assert_eq!(cmd.table, "filter");
        assert_eq!(cmd.set_name, "myset");
    }

    // ── add element ──────────────────────────────────────────────

    #[test]
    fn test_add_element_ipv4() {
        let cmd = parse_one(
            "add element inet filter myset { 10.0.0.1, 10.0.0.2 }"
        );
        assert!(matches!(cmd.op, CmdOp::Add));
        assert!(matches!(cmd.obj, CmdObj::Element));
        assert_eq!(cmd.family, NFPROTO_INET);
        assert_eq!(cmd.table, "filter");
        assert_eq!(cmd.set_name, "myset");

        assert_eq!(cmd.elements.len(), 2);
        assert_eq!(cmd.elements[0], (vec![10, 0, 0, 1], None));
        assert_eq!(cmd.elements[1], (vec![10, 0, 0, 2], None));
    }

    #[test]
    fn test_add_element_single() {
        let cmd = parse_one("add element ip filter myset { 192.168.0.1 }");
        assert_eq!(cmd.elements.len(), 1);
        assert_eq!(cmd.elements[0], (vec![192, 168, 0, 1], None));
    }

    #[test]
    fn test_add_element_three_addrs() {
        let cmd = parse_one(
            "add element ip filter myset { 1.1.1.1, 8.8.8.8, 9.9.9.9 }"
        );
        assert_eq!(cmd.elements.len(), 3);
        assert_eq!(cmd.elements[0], (vec![1, 1, 1, 1], None));
        assert_eq!(cmd.elements[1], (vec![8, 8, 8, 8], None));
        assert_eq!(cmd.elements[2], (vec![9, 9, 9, 9], None));
    }

    // ── delete element ───────────────────────────────────────────

    #[test]
    fn test_delete_element() {
        let cmd = parse_one(
            "delete element inet filter myset { 10.0.0.1 }"
        );
        assert!(matches!(cmd.op, CmdOp::Delete));
        assert!(matches!(cmd.obj, CmdObj::Element));
        assert_eq!(cmd.table, "filter");
        assert_eq!(cmd.set_name, "myset");
        assert_eq!(cmd.elements.len(), 1);
        assert_eq!(cmd.elements[0], (vec![10, 0, 0, 1], None));
    }

    // ── Multiple commands separated by semicolons ─────────────────

    #[test]
    fn test_multiple_commands_semicolons() {
        let cmds = parse(
            "add table inet filter; add chain inet filter input; add chain inet filter output"
        ).expect("parse failed");
        assert_eq!(cmds.len(), 3);

        assert!(matches!(cmds[0].op, CmdOp::Add));
        assert!(matches!(cmds[0].obj, CmdObj::Table));
        assert_eq!(cmds[0].table, "filter");

        assert!(matches!(cmds[1].op, CmdOp::Add));
        assert!(matches!(cmds[1].obj, CmdObj::Chain));
        assert_eq!(cmds[1].chain, "input");

        assert!(matches!(cmds[2].op, CmdOp::Add));
        assert!(matches!(cmds[2].obj, CmdObj::Chain));
        assert_eq!(cmds[2].chain, "output");
    }

    #[test]
    fn test_multiple_commands_with_trailing_semicolon() {
        let cmds = parse(
            "add table ip filter; delete table ip filter;"
        ).expect("parse failed");
        assert_eq!(cmds.len(), 2);
    }

    // ── File input with newlines ──────────────────────────────────

    #[test]
    fn test_file_input_newlines() {
        let input = "add table inet filter\nadd chain inet filter input\nadd rule ip filter input accept\n";
        let cmds = parse(input).expect("parse failed");
        assert_eq!(cmds.len(), 3);
        assert!(matches!(cmds[0].obj, CmdObj::Table));
        assert!(matches!(cmds[1].obj, CmdObj::Chain));
        assert!(matches!(cmds[2].obj, CmdObj::Rule));
    }

    #[test]
    fn test_file_input_comments_and_newlines() {
        let input = "# This is a comment\nadd table inet filter\n# Another comment\nadd chain inet filter input\n";
        let cmds = parse(input).expect("parse failed");
        assert_eq!(cmds.len(), 2);
        assert_eq!(cmds[0].table, "filter");
        assert_eq!(cmds[1].chain, "input");
    }

    #[test]
    fn test_file_input_mixed_semicolons_and_newlines() {
        let input = "add table ip filter\nadd chain ip filter input; add chain ip filter output\nadd rule ip filter input accept\n";
        let cmds = parse(input).expect("parse failed");
        assert_eq!(cmds.len(), 4);
    }

    // ── Compound rule expressions ─────────────────────────────────

    #[test]
    fn test_rule_counter_and_accept() {
        let cmd = parse_one("add rule inet filter input counter accept");
        assert!(cmd.exprs.iter().any(|e| matches!(e, Expr::Counter)));
        assert!(cmd.exprs.iter().any(|e| matches!(e, Expr::Verdict { code, .. } if *code == NF_ACCEPT)));
    }

    #[test]
    fn test_rule_tcp_dport_counter_accept() {
        let cmd = parse_one("add rule inet filter input tcp dport 443 counter accept");
        assert!(cmd.exprs.iter().any(|e| matches!(e, Expr::Payload { .. })));
        assert!(cmd.exprs.iter().any(|e| matches!(e, Expr::Counter)));
        assert!(cmd.exprs.iter().any(|e| matches!(e, Expr::Verdict { .. })));
    }

    #[test]
    fn test_rule_ct_state_established_related_accept() {
        let cmd = parse_one("add rule inet filter input ct state established,related accept");
        match &cmd.exprs[1] {
            Expr::Bitwise { mask, .. } => {
                let val = u32::from_ne_bytes(mask[..4].try_into().unwrap());
                assert_eq!(val, 2 | 4); // established=2, related=4
            }
            other => panic!("expected Bitwise, got {:?}", other),
        }
        match &cmd.exprs[2] {
            Expr::Cmp { op, data } => {
                assert_eq!(*op, NFT_CMP_NEQ);
                assert_eq!(data, &[0, 0, 0, 0]);
            }
            other => panic!("expected Cmp(NEQ, 0), got {:?}", other),
        }
    }

    // ── Neq comparison ────────────────────────────────────────────

    #[test]
    fn test_rule_neq_comparison() {
        let cmd = parse_one("add rule ip filter input ip saddr != 10.0.0.1 accept");
        // Meta(nfproto) + Cmp injected before Payload + Cmp(neq).
        match &cmd.exprs[3] {
            Expr::Cmp { op, data } => {
                assert_eq!(*op, NFT_CMP_NEQ);
                assert_eq!(data, &[10, 0, 0, 1]);
            }
            other => panic!("expected Cmp(neq), got {:?}", other),
        }
    }

    // ── Family defaults ───────────────────────────────────────────

    #[test]
    fn test_family_default_ip_for_table() {
        // Without explicit family on table, defaults to NFPROTO_IPV4
        let cmd = parse_one("add table filter");
        assert_eq!(cmd.family, NFPROTO_IPV4);
        assert_eq!(cmd.table, "filter");
    }

    #[test]
    fn test_family_ipv6() {
        let cmd = parse_one("add table ip6 mytable");
        assert_eq!(cmd.family, NFPROTO_IPV6);
    }

    #[test]
    fn test_family_bridge() {
        let cmd = parse_one("add table bridge mytable");
        assert_eq!(cmd.family, NFPROTO_BRIDGE);
    }

    #[test]
    fn test_family_netdev() {
        let cmd = parse_one("add table netdev mytable");
        assert_eq!(cmd.family, NFPROTO_NETDEV);
    }

    // ── Priority from named strings ───────────────────────────────

    #[test]
    fn test_priority_raw() {
        let cmd = parse_one(
            "add chain ip filter prerouting { type filter hook prerouting priority raw; policy accept; }"
        );
        assert_eq!(cmd.chain_spec.priority, -300);
    }

    #[test]
    fn test_priority_mangle() {
        let cmd = parse_one(
            "add chain ip filter prerouting { type filter hook prerouting priority mangle; policy accept; }"
        );
        assert_eq!(cmd.chain_spec.priority, -150);
    }

    #[test]
    fn test_priority_srcnat() {
        let cmd = parse_one(
            "add chain ip nat postrouting { type nat hook postrouting priority srcnat; policy accept; }"
        );
        assert_eq!(cmd.chain_spec.priority, 100);
    }

    // ── Flush table/chain ─────────────────────────────────────────

    #[test]
    fn test_flush_table() {
        let cmd = parse_one("flush table ip filter");
        assert!(matches!(cmd.op, CmdOp::Flush));
        assert!(matches!(cmd.obj, CmdObj::Table));
        assert_eq!(cmd.table, "filter");
    }

    #[test]
    fn test_flush_chain() {
        let cmd = parse_one("flush chain ip filter input");
        assert!(matches!(cmd.op, CmdOp::Flush));
        assert!(matches!(cmd.obj, CmdObj::Chain));
        assert_eq!(cmd.table, "filter");
        assert_eq!(cmd.chain, "input");
    }

    // ── Insert rule ───────────────────────────────────────────────

    #[test]
    fn test_insert_rule() {
        let cmd = parse_one("insert rule ip filter input drop");
        assert!(matches!(cmd.op, CmdOp::Insert));
        assert!(matches!(cmd.obj, CmdObj::Rule));
        assert!(cmd.exprs.iter().any(|e| matches!(e, Expr::Verdict { code, .. } if *code == NF_DROP)));
    }

    // ── Destroy commands ──────────────────────────────────────────

    #[test]
    fn test_destroy_table() {
        let cmd = parse_one("destroy table ip mytable");
        assert!(matches!(cmd.op, CmdOp::Destroy));
        assert!(matches!(cmd.obj, CmdObj::Table));
        assert_eq!(cmd.table, "mytable");
    }

    // ── Create command ────────────────────────────────────────────

    #[test]
    fn test_create_table() {
        let cmd = parse_one("create table inet filter");
        assert!(matches!(cmd.op, CmdOp::Create));
        assert!(matches!(cmd.obj, CmdObj::Table));
        assert_eq!(cmd.family, NFPROTO_INET);
        assert_eq!(cmd.table, "filter");
    }

    #[test]
    fn test_create_chain_base() {
        let cmd = parse_one(
            "create chain ip nat postrouting { type nat hook postrouting priority 100; policy accept; }"
        );
        assert!(matches!(cmd.op, CmdOp::Create));
        assert!(matches!(cmd.obj, CmdObj::Chain));
        assert!(cmd.chain_spec.is_base);
        assert_eq!(cmd.chain_spec.priority, 100);
    }

    // ── Rule with handle ──────────────────────────────────────────

    #[test]
    fn test_rule_with_position_handle() {
        let cmd = parse_one("add rule ip filter input handle 7 accept");
        assert_eq!(cmd.handle, 7);
        assert!(cmd.has_handle);
        assert!(cmd.exprs.iter().any(|e| matches!(e, Expr::Verdict { code, .. } if *code == NF_ACCEPT)));
    }

    // ── Quoted names ──────────────────────────────────────────────

    #[test]
    fn test_quoted_chain_name() {
        let cmd = parse_one("add chain ip filter \"my chain\"");
        assert_eq!(cmd.chain, "my chain");
    }

    #[test]
    fn test_quoted_table_name() {
        let cmd = parse_one("add table ip \"my table\"");
        assert_eq!(cmd.table, "my table");
    }

    // ── List chains/rules/sets ────────────────────────────────────

    #[test]
    fn test_list_chains() {
        let cmd = parse_one("list chains");
        assert!(matches!(cmd.op, CmdOp::List));
        assert!(matches!(cmd.obj, CmdObj::Chains));
    }

    #[test]
    fn test_list_rules() {
        let cmd = parse_one("list rules");
        assert!(matches!(cmd.op, CmdOp::List));
        assert!(matches!(cmd.obj, CmdObj::Rules));
    }

    #[test]
    fn test_list_sets() {
        let cmd = parse_one("list sets");
        assert!(matches!(cmd.op, CmdOp::List));
        assert!(matches!(cmd.obj, CmdObj::Sets));
    }

    // ── Map object ────────────────────────────────────────────────

    #[test]
    fn test_add_map() {
        let cmd = parse_one(
            "add map ip filter mymap { type ipv4_addr : inet_service; }"
        );
        assert!(matches!(cmd.op, CmdOp::Add));
        assert!(matches!(cmd.obj, CmdObj::Map));
        assert_eq!(cmd.set_name, "mymap");
        assert!(cmd.set_spec.is_map);
        assert_eq!(cmd.set_spec.key_type, 7);   // ipv4_addr
        assert_eq!(cmd.set_spec.key_len, 4);
        assert_eq!(cmd.set_spec.data_type, 13);  // inet_service
        assert_eq!(cmd.set_spec.data_len, 2);
    }

    // ── tproxy ──────────────────────────────────────────────────

    #[test]
    fn test_tproxy_inet_bare_port() {
        // Bare `tproxy to :PORT` in inet table — no family qualifier,
        // no addr; family stays UNSPEC so the kernel resolves it
        // against the chain's L3 context.
        let cmds = parse(
            "add rule inet test pre meta l4proto 6 tproxy to :1088"
        ).expect("parse failed");
        let rule = cmds.into_iter().find(|c| matches!(c.obj, CmdObj::Rule)).expect("no rule");
        let tp = rule.exprs.iter().find_map(|e| match e {
            Expr::Tproxy { family, addr, port, has_addr, has_port } =>
                Some((*family, addr.clone(), *port, *has_addr, *has_port)),
            _ => None,
        }).expect("no tproxy expr");
        assert_eq!(tp.0, NFPROTO_UNSPEC as u32);
        assert!(!tp.3, "has_addr should be false");
        assert!(tp.4, "has_port should be true");
        assert_eq!(tp.2, 1088);
    }

    #[test]
    fn test_tproxy_ip_addr_port() {
        let cmds = parse(
            "add rule ip test pre meta l4proto 6 tproxy to 127.0.0.1:1088"
        ).expect("parse failed");
        let rule = cmds.into_iter().find(|c| matches!(c.obj, CmdObj::Rule)).expect("no rule");
        let tp = rule.exprs.iter().find_map(|e| match e {
            Expr::Tproxy { family, addr, port, has_addr, has_port } =>
                Some((*family, addr.clone(), *port, *has_addr, *has_port)),
            _ => None,
        }).expect("no tproxy expr");
        assert!(tp.3, "has_addr should be true");
        assert!(tp.4, "has_port should be true");
        assert_eq!(tp.2, 1088);
        assert_eq!(tp.1, vec![127, 0, 0, 1]);
    }

    #[test]
    fn test_tproxy_ip_qualifier() {
        let cmds = parse(
            "add rule inet test pre meta l4proto 6 tproxy ip to :1088"
        ).expect("parse failed");
        let rule = cmds.into_iter().find(|c| matches!(c.obj, CmdObj::Rule)).expect("no rule");
        let tp = rule.exprs.iter().find_map(|e| match e {
            Expr::Tproxy { family, addr: _, port: _, has_addr: _, has_port: _ } =>
                Some(*family),
            _ => None,
        }).expect("no tproxy expr");
        assert_eq!(tp, NFPROTO_IPV4 as u32);
    }

    #[test]
    fn test_named_set_as_protocol_dep_dumpfile() {
        // The exact contents of the upstream
        // tests/shell/testcases/nft-f/dumps/named_set_as_protocol_dep.nft
        // dump that the matching shell test loads with `nft -f`.
        // We only care that stormwall accepts the file and produces
        // the four pieces (table, set, set elements, chain with
        // tproxy rule) the kernel needs.
        let src = "table inet test {\n\
                   \tset protos {\n\
                   \t\ttypeof meta l4proto\n\
                   \t\telements = { tcp, udp }\n\
                   \t}\n\
                   \n\
                   \tchain prerouting {\n\
                   \t\ttype filter hook prerouting priority mangle; policy accept;\n\
                   \t\tmeta l4proto @protos tproxy to :1088\n\
                   \t}\n\
                   }\n";
        let cmds = parse(src).expect("parse failed");
        let set = cmds.iter().find(|c| matches!(c.obj, CmdObj::Set)).expect("no set");
        assert_eq!(set.set_spec.key_type, 12, "set key_type should be inet_proto");
        assert_eq!(set.set_spec.key_len, 1);
        let elem = cmds.iter().find(|c| matches!(c.obj, CmdObj::Element)).expect("no elements");
        let keys: Vec<u8> = elem.elements.iter().map(|(k, _)| k[0]).collect();
        assert!(keys.contains(&6),  "tcp (6) missing: {:?}", keys);
        assert!(keys.contains(&17), "udp (17) missing: {:?}", keys);
        let chain = cmds.iter().find(|c| matches!(c.obj, CmdObj::Chain)).expect("no chain");
        assert_eq!(chain.chain, "prerouting");
        let rule = cmds.iter().find(|c| matches!(c.obj, CmdObj::Rule)).expect("no rule");
        // Lookup against the named set, then a tproxy with port 1088
        // and family UNSPEC (the inet bare-port form).
        let has_lookup = rule.exprs.iter().any(|e| matches!(e, Expr::Lookup { set_name, .. } if set_name == "protos"));
        assert!(has_lookup, "rule should reference @protos lookup");
        let tp = rule.exprs.iter().find_map(|e| match e {
            Expr::Tproxy { family, port, has_addr, has_port, .. } => Some((*family, *port, *has_addr, *has_port)),
            _ => None,
        }).expect("no tproxy expr");
        assert_eq!(tp.0, NFPROTO_UNSPEC as u32, "family should be UNSPEC for bare inet tproxy");
        assert_eq!(tp.1, 1088);
        assert!(!tp.2, "has_addr should be false");
        assert!(tp.3, "has_port should be true");
    }

    #[test]
    fn test_typeof_meta_l4proto_set() {
        // `typeof meta l4proto` ⇒ inet_proto datatype, plus
        // `tcp`/`udp` element resolution.
        let cmds = parse(
            "table inet test { set protos { typeof meta l4proto ; elements = { tcp, udp } } }"
        ).expect("parse failed");
        let set = cmds.iter().find(|c| matches!(c.obj, CmdObj::Set)).expect("no set");
        assert_eq!(set.set_spec.key_type, 12); // inet_proto
        assert_eq!(set.set_spec.key_len, 1);
        let elem = cmds.iter().find(|c| matches!(c.obj, CmdObj::Element)).expect("no element");
        let keys: Vec<u8> = elem.elements.iter().map(|(k, _)| k[0]).collect();
        assert!(keys.contains(&6),  "tcp (6) missing: {:?}", keys);
        assert!(keys.contains(&17), "udp (17) missing: {:?}", keys);
    }

    // ── meta hour parsing ────────────────────────────────────────

    #[test]
    fn test_parse_hour_endpoint_quoted() {
        assert_eq!(parse_hour_endpoint("\"01:00\""), Some(3600));
        assert_eq!(parse_hour_endpoint("\"23:59\""), Some(86340));
        assert_eq!(parse_hour_endpoint("\"00:00\""), Some(0));
        assert_eq!(parse_hour_endpoint("\"12:30:45\""), Some(45045));
    }

    #[test]
    fn test_parse_hour_endpoint_unquoted() {
        assert_eq!(parse_hour_endpoint("01:00"), Some(3600));
        assert_eq!(parse_hour_endpoint("23:59"), Some(86340));
    }

    #[test]
    fn test_parse_hour_endpoint_seconds() {
        assert_eq!(parse_hour_endpoint("32400"), Some(32400));
        assert_eq!(parse_hour_endpoint("0"), Some(0));
    }

    #[test]
    fn test_parse_hour_endpoint_invalid() {
        assert_eq!(parse_hour_endpoint("24:00"), None);
        assert_eq!(parse_hour_endpoint("not:a:time"), None);
        assert_eq!(parse_hour_endpoint(""), None);
    }

    #[test]
    fn test_apply_tz_to_store_utc() {
        // gmtoff=0: identity
        assert_eq!(apply_tz_to_store(0, 0), 0);
        assert_eq!(apply_tz_to_store(3600, 0), 3600);
        assert_eq!(apply_tz_to_store(86399, 0), 86399);
    }

    #[test]
    fn test_apply_tz_to_store_negative_offset() {
        // TZ=UTC+1 → gmtoff=-3600
        // input "00:00" (0) → store 3600 (so display in UTC is "01:00")
        assert_eq!(apply_tz_to_store(0, -3600), 3600);
        // input "23:59" (86340) → store (86340 - (-3600)) % 86400 = 3540
        assert_eq!(apply_tz_to_store(86340, -3600), 3540);
    }

    #[test]
    fn test_apply_tz_to_store_positive_offset() {
        // TZ=UTC-2 → gmtoff=+7200
        // input "00:00" (0) → store 86400 - 7200 + 0 = 79200
        assert_eq!(apply_tz_to_store(0, 7200), 79200);
        // input "01:00" (3600) → store 86400 - 7200 + 3600 = 82800
        assert_eq!(apply_tz_to_store(3600, 7200), 82800);
        // input "03:00" (10800) → store 10800 - 7200 = 3600
        assert_eq!(apply_tz_to_store(10800, 7200), 3600);
    }

    #[test]
    fn test_meta_hour_quoted_dash() {
        // Tokenizer handles "01:00"-"04:00" with my new dash-quote split.
        let cmd = parse_one("add rule t c meta hour \"01:00\"-\"04:00\"");
        // Should produce 3 exprs: Meta, Byteorder, Range
        let metas = cmd.exprs.iter().filter(|e| matches!(e, Expr::Meta { key, .. } if *key == NFT_META_TIME_HOUR)).count();
        assert_eq!(metas, 1, "expected exactly one Meta(TIME_HOUR), got {} in {:?}", metas, cmd.exprs);
        let ranges = cmd.exprs.iter().filter(|e| matches!(e, Expr::Range { .. })).count();
        assert_eq!(ranges, 1, "expected one Range");
    }

    #[test]
    fn test_meta_hour_quoted_spaces() {
        let cmd = parse_one("add rule t c meta hour \"01:00\" - \"04:00\"");
        let metas = cmd.exprs.iter().filter(|e| matches!(e, Expr::Meta { key, .. } if *key == NFT_META_TIME_HOUR)).count();
        assert_eq!(metas, 1);
        let ranges = cmd.exprs.iter().filter(|e| matches!(e, Expr::Range { .. })).count();
        assert_eq!(ranges, 1);
    }

    #[test]
    fn test_meta_hour_unquoted() {
        let cmd = parse_one("add rule t c meta hour 01:00 - 04:00");
        let metas = cmd.exprs.iter().filter(|e| matches!(e, Expr::Meta { key, .. } if *key == NFT_META_TIME_HOUR)).count();
        assert_eq!(metas, 1, "exprs: {:?}", cmd.exprs);
        let ranges = cmd.exprs.iter().filter(|e| matches!(e, Expr::Range { .. })).count();
        assert_eq!(ranges, 1, "exprs: {:?}", cmd.exprs);
    }

    #[test]
    fn test_meta_hour_endpoint_bytes_utc() {
        // With TZ=UTC, the test relies on tm_gmtoff=0 — which we set up
        // process-wide for the duration of this test. (libc reads $TZ at
        // tzset() time; localtime_r implicitly tzset's, but only on the
        // first call per env — set $TZ before the call.)
        std::env::set_var("TZ", "UTC");
        unsafe { extern "C" { fn tzset(); } tzset(); }
        let cmd = parse_one("add rule t c meta hour \"01:00\"-\"04:00\"");
        // Find the Range and check its bytes
        for e in &cmd.exprs {
            if let Expr::Range { from, to, .. } = e {
                assert_eq!(from.len(), 4);
                assert_eq!(to.len(), 4);
                let lo = u32::from_be_bytes([from[0], from[1], from[2], from[3]]);
                let hi = u32::from_be_bytes([to[0], to[1], to[2], to[3]]);
                assert_eq!(lo, 3600, "lo seconds-of-day");
                assert_eq!(hi, 14400, "hi seconds-of-day");
                return;
            }
        }
        panic!("no Range expr");
    }
}
