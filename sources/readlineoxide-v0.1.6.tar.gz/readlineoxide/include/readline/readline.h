#ifndef READLINEOXIDE_READLINE_H
#define READLINEOXIDE_READLINE_H

#include <stdio.h>
#include "chardefs.h"
#include "history.h"
#include "keymaps.h"
#include "tilde.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef int rl_command_func_t(int, int);
typedef char *rl_compentry_func_t(const char *, int);
typedef char **rl_completion_func_t(const char *, int, int);
typedef int rl_hook_func_t(void);
typedef char *rl_cpvfunc_t(void);
typedef int rl_getc_func_t(FILE *);
typedef int rl_icpfunc_t(char *);
typedef int rl_icppfunc_t(char **);
typedef void rl_compdisp_func_t(char **, int, int);
typedef void rl_voidfunc_t(void);
typedef void rl_vintfunc_t(int);
typedef void rl_vcpfunc_t(char *);
typedef char *rl_filename_quoting_func_t(char *, int, char *);
typedef char *rl_filename_dequoting_func_t(char *, int);
typedef int rl_char_is_quoted_func_t(char *, int);
typedef void rl_macro_print_func_t(const char *, const char *, int, const char *);
typedef int rl_keyseq_type_t;

#define RL_VERSION_MAJOR 8
#define RL_VERSION_MINOR 3
#define RL_READLINE_VERSION 0x0803

extern char *rl_readline_name;
extern char *rl_terminal_name;
extern char *rl_library_version;
extern int rl_readline_version;
extern int rl_gnu_readline_p;
extern char *rl_prompt;
extern char *rl_line_buffer;
extern int rl_line_buffer_len;
extern int rl_point;
extern int rl_end;
extern int rl_done;
extern int rl_eof_found;
extern int rl_already_prompted;
extern int rl_num_chars_to_read;
extern unsigned long rl_readline_state;
extern int rl_completion_append_character;
extern int rl_completion_suppress_append;
extern int rl_completion_type;
extern int rl_attempted_completion_over;
extern int rl_completion_query_items;
extern int rl_catch_signals;
extern int rl_catch_sigwinch;
extern int rl_byte_oriented;
extern int rl_editing_mode;
extern int rl_insert_mode;
extern int rl_explicit_arg;
extern int rl_numeric_arg;
extern int rl_arg_sign;
extern int rl_dispatching;
extern int rl_executing_key;
extern int rl_completion_invoking_key;
extern int rl_completion_quote_character;
extern int rl_completion_found_quote;
extern int rl_completion_suppress_quote;
extern int rl_filename_quoting_desired;
extern int rl_full_quoting_desired;
extern int rl_inhibit_completion;
extern int rl_pending_input;
extern int rl_visible_prompt_length;
extern char *rl_display_prompt;
extern int rl_blink_matching_paren;
extern int rl_change_environment;
extern int rl_complete_with_tilde_expansion;
extern int rl_completion_mark_symlink_dirs;
extern int rl_key_sequence_length;
extern int rl_persistent_signal_handlers;
extern int rl_prefer_env_winsize;
extern int rl_mark;
extern rl_command_func_t *rl_last_func;
extern rl_command_func_t *rl_linefunc;
extern void *rl_undo_list;
extern char *rl_executing_keyseq;
extern char *rl_executing_macro;
extern int rl_display_fixed;
extern int rl_erase_empty_line;
extern char *rl_special_prefixes;
extern char *rl_basic_word_break_characters;
extern char *rl_completer_word_break_characters;
extern const char *rl_basic_quote_characters;
extern const char *rl_completer_quote_characters;
extern const char *rl_filename_quote_characters;
extern int rl_filename_completion_desired;
extern int rl_ignore_completion_duplicates;
extern int rl_sort_completion_matches;
extern int rl_visible_stats;
extern int _rl_complete_mark_directories;
extern int _rl_completion_prefix_display_length;
extern int _rl_print_completions_horizontally;
extern int _rl_term_autowrap;
extern rl_completion_func_t *rl_attempted_completion_function;
extern rl_compentry_func_t *rl_completion_entry_function;
extern rl_compentry_func_t *rl_menu_completion_entry_function;
extern rl_cpvfunc_t *rl_completion_word_break_hook;
extern rl_compdisp_func_t *rl_completion_display_matches_hook;
extern rl_icppfunc_t *rl_directory_completion_hook;
extern rl_filename_dequoting_func_t *rl_completion_rewrite_hook;
extern rl_icppfunc_t *rl_directory_rewrite_hook;
extern rl_filename_dequoting_func_t *rl_filename_rewrite_hook;
extern rl_icppfunc_t *rl_ignore_some_completions_function;
extern rl_filename_quoting_func_t *rl_filename_quoting_function;
extern rl_filename_dequoting_func_t *rl_filename_dequoting_function;
extern rl_filename_dequoting_func_t *rl_filename_stat_hook;
extern rl_char_is_quoted_func_t *rl_char_is_quoted_p;
extern FILE *rl_instream;
extern FILE *rl_outstream;
extern rl_hook_func_t *rl_startup_hook;
extern rl_hook_func_t *rl_pre_input_hook;
extern rl_hook_func_t *rl_event_hook;
extern rl_hook_func_t *rl_signal_event_hook;
extern rl_hook_func_t *rl_timeout_event_hook;
extern rl_hook_func_t *rl_input_available_hook;
extern rl_getc_func_t *rl_getc_function;
extern rl_voidfunc_t *rl_deprep_term_function;
extern rl_vintfunc_t *rl_prep_term_function;
extern rl_macro_print_func_t *rl_macro_display_hook;
extern rl_voidfunc_t *rl_redisplay_function;
extern Keymap rl_executing_keymap;
extern Keymap rl_binding_keymap;

struct readline_state {
    unsigned long opaque_magic;
    unsigned long opaque_slot;
};

#define SINGLE_MATCH 1
#define MULT_MATCH 2

#define READERR (-2)
#define RL_STATE_NONE 0x00000000UL
#define RL_STATE_INITIALIZING 0x00000001UL
#define RL_STATE_INITIALIZED 0x00000002UL
#define RL_STATE_TERMPREPPED 0x00000004UL
#define RL_STATE_READCMD 0x00000008UL
#define RL_STATE_METANEXT 0x00000010UL
#define RL_STATE_DISPATCHING 0x00000020UL
#define RL_STATE_MOREINPUT 0x00000040UL
#define RL_STATE_ISEARCH 0x00000080UL
#define RL_STATE_NSEARCH 0x00000100UL
#define RL_STATE_SEARCH 0x00000200UL
#define RL_STATE_NUMERICARG 0x00000400UL
#define RL_STATE_MACROINPUT 0x00000800UL
#define RL_STATE_MACRODEF 0x00001000UL
#define RL_STATE_OVERWRITE 0x00002000UL
#define RL_STATE_COMPLETING 0x00004000UL
#define RL_STATE_SIGHANDLER 0x00008000UL
#define RL_STATE_UNDOING 0x00010000UL
#define RL_STATE_INPUTPENDING 0x00020000UL
#define RL_STATE_TTYCSAVED 0x00040000UL
#define RL_STATE_CALLBACK 0x00080000UL
#define RL_STATE_VIMOTION 0x00100000UL
#define RL_STATE_MULTIKEY 0x00200000UL
#define RL_STATE_VICMDONCE 0x00400000UL
#define RL_STATE_CHARSEARCH 0x00800000UL
#define RL_STATE_REDISPLAYING 0x01000000UL
#define RL_STATE_DONE 0x02000000UL
#define RL_STATE_TIMEOUT 0x04000000UL
#define RL_STATE_EOF 0x08000000UL
#define RL_STATE_READSTR 0x10000000UL
#define RL_SETSTATE(x) (rl_readline_state |= (x))
#define RL_UNSETSTATE(x) (rl_readline_state &= ~(x))
#define RL_ISSTATE(x) (rl_readline_state & (x))

char *readline(const char *prompt);
int rl_initialize(void);
void rl_cleanup_after_signal(void);
void rl_reset_after_signal(void);
void rl_free_line_state(void);
void rl_deprep_terminal(void);
int rl_prep_terminal(int meta_flag);
int rl_set_prompt(const char *prompt);
int rl_on_new_line(void);
int rl_newline(int count, int key);
void rl_redisplay(void);
int rl_forced_update_display(void);
int rl_refresh_line(int ignore1, int ignore2);
int rl_message(const char *text, ...);
int rl_clear_message(void);
int rl_on_new_line_with_prompt(void);
int rl_clear_display(void);
int rl_clear_screen(int count, int key);
int rl_clear_visible_line(void);
void rl_display_match_list(char **matches, int len, int max);
int rl_expand_prompt(char *prompt);
void rl_save_prompt(void);
void rl_restore_prompt(void);
int rl_reset_line_state(void);
int rl_clear_pending_input(void);
void _rl_erase_entire_line(void);
int _rl_qsort_string_compare(const void *left, const void *right);
void rl_replace_line(const char *text, int clear_undo);
int rl_insert_text(const char *text);
int rl_delete_text(int start, int end);
int rl_beginning_of_line(int count, int key);
int rl_beg_of_line(int count, int key);
int rl_end_of_line(int count, int key);
int rl_forward_char(int count, int key);
int rl_forward(int count, int key);
int rl_forward_byte(int count, int key);
int rl_backward_char(int count, int key);
int rl_backward(int count, int key);
int rl_backward_byte(int count, int key);
int rl_forward_word(int count, int key);
int rl_backward_word(int count, int key);
int rl_delete(int count, int key);
int rl_rubout(int count, int key);
int rl_unix_line_discard(int count, int key);
int rl_kill_line(int count, int key);
int rl_backward_kill_line(int count, int key);
int rl_kill_full_line(int count, int key);
int rl_kill_word(int count, int key);
int rl_backward_kill_word(int count, int key);
int rl_unix_word_rubout(int count, int key);
int rl_unix_filename_rubout(int count, int key);
int rl_delete_horizontal_space(int count, int key);
int rl_copy_region_to_kill(int count, int key);
int rl_kill_region(int count, int key);
int rl_copy_forward_word(int count, int key);
int rl_copy_backward_word(int count, int key);
int rl_yank(int count, int key);
int rl_yank_pop(int count, int key);
int rl_yank_nth_arg(int count, int key);
int rl_yank_last_arg(int count, int key);
int rl_set_mark(int count, int key);
void rl_activate_mark(void);
void rl_deactivate_mark(void);
int rl_mark_active_p(void);
int rl_exchange_point_and_mark(int count, int key);
int rl_transpose_chars(int count, int key);
int rl_upcase_word(int count, int key);
int rl_downcase_word(int count, int key);
int rl_capitalize_word(int count, int key);
int rl_do_undo(void);
int rl_undo_command(int count, int key);
int rl_begin_undo_group(void);
int rl_end_undo_group(void);
int rl_add_undo(int what, int start, int end, char *text);
void rl_free_undo_list(void);
int rl_maybe_save_line(void);
int rl_maybe_unsave_line(void);
int rl_maybe_replace_line(void);
int rl_revert_line(int count, int key);
int rl_bind_key(int key, rl_command_func_t *function);
int rl_bind_key_in_map(int key, rl_command_func_t *function, Keymap map);
int rl_bind_keyseq(const char *keyseq, rl_command_func_t *function);
int rl_bind_keyseq_in_map(const char *keyseq, rl_command_func_t *function, Keymap map);
int rl_bind_key_if_unbound(int key, rl_command_func_t *function);
int rl_bind_key_if_unbound_in_map(int key, rl_command_func_t *function, Keymap map);
int rl_bind_keyseq_if_unbound(const char *keyseq, rl_command_func_t *function);
int rl_bind_keyseq_if_unbound_in_map(const char *keyseq, rl_command_func_t *function, Keymap map);
int rl_unbind_key(int key);
int rl_unbind_key_in_map(int key, Keymap map);
int rl_unbind_function_in_map(rl_command_func_t *function, Keymap map);
int rl_unbind_command_in_map(const char *command, Keymap map);
rl_command_func_t *rl_named_function(const char *name);
rl_command_func_t *rl_function_of_keyseq(const char *keyseq, Keymap map, rl_keyseq_type_t *type);
rl_command_func_t *rl_function_of_keyseq_len(const char *keyseq, int len, Keymap map, rl_keyseq_type_t *type);
int rl_add_funmap_entry(const char *name, rl_command_func_t *function);
int rl_generic_bind(int type, const char *keyseq, const char *data, Keymap map);
int rl_macro_bind(const char *keyseq, const char *macro, Keymap map);
int rl_translate_keyseq(const char *keyseq, char *array, int *len);
char **rl_invoking_keyseqs(rl_command_func_t *function);
char **rl_invoking_keyseqs_in_map(rl_command_func_t *function, Keymap map);
char **rl_funmap_names(void);
void rl_list_funmap_names(void);
void rl_print_keybinding(const char *keyseq, rl_command_func_t *function);
void rl_function_dumper(int readable);
void rl_macro_dumper(int readable);
void rl_variable_dumper(int readable);
void rl_dump_functions(int readable);
void rl_dump_macros(int readable);
void rl_dump_variables(int readable);
int rl_echo_signal_char(int sig);
int rl_print_last_kbd_macro(void);
int rl_push_macro_input(const char *macro);
int readline_internal_setup(void);
int readline_internal_teardown(int eof);
int readline_common_teardown(int eof);
int readline_internal_char(void);
int rl_alphabetic(int key);
int rl_character_len(int c, int pos);
int rl_arrow_keys(int count, int key);
int rl_backward_char_search(int count, int key);
int rl_char_search(int count, int key);
int rl_bracketed_paste_begin(int count, int key);
int rl_call_last_kbd_macro(int count, int key);
int rl_complete_internal(int what);
int rl_completion_mode(rl_command_func_t *function);
int rl_delete_or_show_completions(int count, int key);
int rl_digit_argument(int count, int key);
int rl_universal_argument(int count, int key);
int rl_discard_argument(void);
int rl_do_lowercase_version(int count, int key);
int rl_emacs_editing_mode(int count, int key);
void rl_empty_keymap(Keymap map);
int rl_end_kbd_macro(int count, int key);
int rl_start_kbd_macro(int count, int key);
int rl_execute_named_command(char *name, int count, int key);
int rl_execute_next(int key);
int rl_export_completions(int count, int key);
char *rl_get_keymap_name_from_edit_mode(void);
char *rl_get_termcap(const char *cap);
int rl_history_substr_search_forward(int count, int key);
int rl_history_substr_search_backward(int count, int key);
int rl_initialize_funmap(void);
int rl_insert_close(int count, int key);
int rl_insert_comment(int count, int key);
int rl_insert_completions(int count, int key);
int rl_possible_completions(int count, int key);
int rl_menu_complete(int count, int key);
int rl_old_menu_complete(int count, int key);
int rl_backward_menu_complete(int count, int key);
void rl_keep_mark_active(void);
int rl_kill_text(int start, int end);
int rl_next_screen_line(int count, int key);
int rl_previous_screen_line(int count, int key);
int rl_noninc_forward_search(int count, int key);
int rl_noninc_reverse_search(int count, int key);
int rl_noninc_forward_search_again(int count, int key);
int rl_noninc_reverse_search_again(int count, int key);
int rl_forward_search_history(int count, int key);
int rl_reverse_search_history(int count, int key);
int rl_overwrite_mode(int count, int key);
int rl_quoted_insert(int count, int key);
int rl_re_read_init_file(int count, int key);
int rl_redraw_prompt_last_line(void);
int rl_reparse_colors(void);
int rl_restart_output(int count, int key);
int rl_stop_output(int count, int key);
int rl_save_state(struct readline_state *state);
int rl_restore_state(struct readline_state *state);
int rl_rubout_or_delete(int count, int key);
int rl_set_key(const char *keyseq, rl_command_func_t *function, Keymap map);
void rl_set_keymap_from_edit_mode(void);
int rl_set_paren_blink_timeout(int usec);
int rl_set_retained_kills(int num);
int rl_show_char(int key);
int rl_skip_csi_sequence(void);
int rl_tab_insert(int count, int key);
int rl_transpose_words(int count, int key);
char *rl_trim_arg_from_keyseq(const char *keyseq, int type);
void rl_tty_set_default_bindings(Keymap map);
void rl_tty_unset_default_bindings(Keymap map);
int rl_tty_set_echoing(int value);
int rl_tty_status(int count, int key);
int rl_vi_append_eol(int count, int key);
int rl_vi_append_mode(int count, int key);
int rl_vi_arg_digit(int count, int key);
int rl_vi_bWord(int count, int key);
int rl_vi_back_to_indent(int count, int key);
int rl_vi_bracktype(int count, int key);
int rl_vi_bword(int count, int key);
int rl_vi_change_case(int count, int key);
int rl_vi_change_char(int count, int key);
int rl_vi_change_to(int count, int key);
int rl_vi_char_search(int count, int key);
int rl_vi_check(int count, int key);
int rl_vi_column(int count, int key);
int rl_vi_complete(int count, int key);
int rl_vi_delete(int count, int key);
int rl_vi_delete_to(int count, int key);
int rl_vi_domove(int count, int key);
int rl_vi_eWord(int count, int key);
int rl_vi_editing_mode(int count, int key);
int rl_vi_end_word(int count, int key);
int rl_vi_eof_maybe(int count, int key);
int rl_vi_eword(int count, int key);
int rl_vi_fWord(int count, int key);
int rl_vi_fetch_history(int count, int key);
int rl_vi_first_print(int count, int key);
int rl_vi_fword(int count, int key);
int rl_vi_goto_mark(int count, int key);
int rl_vi_insert_beg(int count, int key);
int rl_vi_insert_mode(int count, int key);
int rl_vi_insertion_mode(int count, int key);
int rl_vi_match(int count, int key);
int rl_vi_movement_mode(int count, int key);
int rl_vi_next_word(int count, int key);
int rl_vi_overstrike(int count, int key);
int rl_vi_overstrike_delete(int count, int key);
int rl_vi_prev_word(int count, int key);
int rl_vi_put(int count, int key);
int rl_vi_redo(int count, int key);
int rl_vi_replace(int count, int key);
int rl_vi_rubout(int count, int key);
int rl_vi_search(int count, int key);
int rl_vi_search_again(int count, int key);
int rl_vi_set_mark(int count, int key);
int rl_vi_start_inserting(int count, int key);
int rl_vi_subst(int count, int key);
int rl_vi_tilde_expand(int count, int key);
int rl_vi_undo(int count, int key);
int rl_vi_unix_word_rubout(int count, int key);
int rl_vi_yank_arg(int count, int key);
int rl_vi_yank_pop(int count, int key);
int rl_vi_yank_to(int count, int key);
int rl_variable_bind(const char *variable, const char *value);
char *rl_variable_value(const char *variable);
int rl_parse_and_bind(char *line);
int rl_read_init_file(const char *filename);
int rl_add_defun(const char *name, rl_command_func_t *function, int key);
char **rl_completion_matches(const char *text, rl_compentry_func_t *entry_func);
char *rl_filename_completion_function(const char *text, int state);
char *rl_username_completion_function(const char *text, int state);
char *filename_completion_function(const char *text, int state);
char *username_completion_function(const char *text, int state);
char *rl_copy_text(int start, int end);
int rl_extend_line_buffer(int len);
int rl_ding(void);
int rl_abort(int count, int key);
int rl_insert(int count, int key);
int rl_complete(int count, int key);
int rl_tilde_expand(int count, int key);
void rl_free(void *mem);
int rl_modifying(int start, int end);
int rl_history_search_forward(int count, int key);
int rl_history_search_backward(int count, int key);
void rl_clear_history(void);
int rl_get_previous_history(int count, int key);
int rl_get_next_history(int count, int key);
int rl_replace_from_history(HIST_ENTRY *entry, int flags);
int rl_fetch_history(void);
int rl_beginning_of_history(int count, int key);
int rl_end_of_history(int count, int key);
int rl_operate_and_get_next(int count, int key);
int rl_reset_terminal(const char *terminal_name);
void rl_resize_terminal(void);
void rl_set_screen_size(int rows, int cols);
void rl_get_screen_size(int *rows, int *cols);
void rl_reset_screen_size(void);
int rl_set_signals(void);
int rl_clear_signals(void);
int rl_pending_signal(void);
int rl_check_signals(void);
int rl_set_timeout(unsigned int seconds, unsigned int useconds);
int rl_timeout_remaining(unsigned int *seconds, unsigned int *useconds);
int rl_set_keyboard_input_timeout(int usec);
int rl_getc(FILE *stream);
int rl_read_key(void);
int rl_stuff_char(int key);
int rl_crlf(void);
char *rl_untranslate_keyseq(int key);
void rl_callback_handler_install(const char *prompt, rl_vcpfunc_t *handler);
void rl_callback_read_char(void);
void rl_callback_handler_remove(void);
void rl_callback_sigcleanup(void);

Keymap rl_make_bare_keymap(void);
Keymap rl_make_keymap(void);
Keymap rl_copy_keymap(Keymap map);
void rl_discard_keymap(Keymap map);
void rl_free_keymap(Keymap map);
Keymap rl_get_keymap_by_name(const char *name);
char *rl_get_keymap_name(Keymap map);
void rl_set_keymap(Keymap map);
Keymap rl_get_keymap(void);
int rl_set_keymap_name(const char *name, Keymap map);

#ifdef __cplusplus
}
#endif

#endif
