#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <readline/readline.h>

static FILE *capture;

static void
fail(const char *message)
{
    fprintf(stderr, "display_message_semantics: %s\n", message);
    exit(1);
}

static void
reset_capture(void)
{
    if (capture != NULL)
        fclose(capture);
    capture = tmpfile();
    if (capture == NULL)
        fail("tmpfile");
    rl_outstream = capture;
}

static size_t
read_capture(unsigned char *buffer, size_t size)
{
    size_t used;

    if (fflush(capture) != 0)
        fail("fflush");
    if (fseek(capture, 0, SEEK_SET) != 0)
        fail("fseek");
    used = fread(buffer, 1, size, capture);
    if (ferror(capture))
        fail("fread");
    return used;
}

static void
expect_output(const char *message, const unsigned char *expected, size_t len)
{
    unsigned char buffer[128];
    size_t used = read_capture(buffer, sizeof(buffer));

    if (used != len || memcmp(buffer, expected, len) != 0) {
        fprintf(stderr, "display_message_semantics: %s: output mismatch\n",
            message);
        exit(1);
    }
}

static void
expect_display(const char *message, const char *expected)
{
    if (rl_display_prompt == NULL || strcmp(rl_display_prompt, expected) != 0) {
        fprintf(stderr, "display_message_semantics: %s: <%s> != <%s>\n",
            message, rl_display_prompt == NULL ? "(null)" : rl_display_prompt,
            expected);
        exit(1);
    }
}

int
main(void)
{
    static const unsigned char redisplay[] = "P> abc";
    static const unsigned char clear_line[] = "\r\033[K\r";
    static const unsigned char bell[] = "\007";

    reset_capture();
    if (rl_initialize() != 0)
        fail("initialize");
    if (rl_set_prompt("P> ") != 0)
        fail("set prompt");
    rl_replace_line("abc", 0);
    rl_point = 1;

    if (rl_ding() != -1)
        fail("ding before prep");
    expect_output("ding before prep", (const unsigned char *)"", 0);

    if (rl_message("MSG:%s:%d", "ok", 7) != 0)
        fail("message");
    expect_display("message display", "MSG:ok:7");
    if (rl_clear_message() != 0)
        fail("clear message");
    expect_display("clear message display", "P> ");

    reset_capture();
    rl_redisplay();
    expect_output("redisplay", redisplay, sizeof(redisplay) - 1);

    reset_capture();
    if (rl_forced_update_display() != 0)
        fail("forced update");
    expect_output("forced update", redisplay, sizeof(redisplay) - 1);

    reset_capture();
    if (rl_clear_visible_line() != 0)
        fail("clear visible line");
    expect_output("clear visible line", clear_line, sizeof(clear_line) - 1);

    reset_capture();
    if (rl_prep_terminal(1) != 0)
        fail("prep terminal");
    if (rl_ding() != 0)
        fail("ding after prep");
    expect_output("ding after prep", bell, sizeof(bell) - 1);
    rl_deprep_terminal();

    fclose(capture);
    capture = NULL;
    rl_outstream = NULL;
    return 0;
}
