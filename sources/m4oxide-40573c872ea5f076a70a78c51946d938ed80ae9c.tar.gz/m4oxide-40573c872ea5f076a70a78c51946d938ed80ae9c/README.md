# m4oxide

Clean-room Rust implementation of `m4`, a macro expander, for jonerix.

The implementation is developed from public documentation, black-box behavior
of compiled `m4` binaries, Ghidra/disassembly observations, and test suites.
GNU m4 implementation source code is not used.

Zero runtime dependencies — `Cargo.toml` declares no third-party crates, the
binary is built against the Rust standard library only. The regex engine, eval
parser, and macro engine are all hand-rolled.

## Build & install

```sh
cargo build --release
cargo install --path .
```

Or install via jonerix once the package is published:

```sh
jpkg install m4oxide
```

The jonerix package installs both `/bin/m4oxide` and a `/bin/m4` symlink so
existing tools that look for `m4` find m4oxide.

## Compatibility Mode

Set `M4OXIDE_TEST_MODE=1` to make diagnostics and identity strings emit the
exact same bytes as GNU m4. This is the only mode under which black-box
oracle tests can pass — without it, `--version`, `--help`, and error
prefixes all identify as `m4oxide`.

```sh
M4OXIDE_TEST_MODE=1 cargo test
```

Without `M4OXIDE_TEST_MODE`, `m4oxide --version` reports `m4oxide <version>`
and error prefixes are `m4oxide:` rather than `m4:`.

## Testing

Local tests include Rust unit tests and black-box oracle tests. The oracle
defaults to `m4` from `$PATH`; set `M4_ORACLE` to point at a specific binary.

```sh
M4_ORACLE=/usr/bin/m4 cargo test
cargo build --release
./tools/oracle_sweep.py --candidate target/release/m4oxide
```

Current upstream GNU m4 1.4.21 check-suite status: the implementation passes
the custom oracle sweep and 248/248 extracted upstream check inputs. No known
failures remain in the extracted upstream check inputs; broader m4
compatibility should still be tested against additional real-world workloads.

Upstream GNU m4 check inputs can be downloaded into `cleanroom/private/`, which
is intentionally ignored by git:

```sh
mkdir -p cleanroom/private/upstream
cd cleanroom/private/upstream
curl -fsSLO https://ftp.gnu.org/gnu/m4/m4-1.4.21.tar.xz
mkdir -p m4-1.4.21-checks
tar -xf m4-1.4.21.tar.xz -C m4-1.4.21-checks --strip-components=1 \
  m4-1.4.21/checks m4-1.4.21/examples
cd ../../..
./tools/run_upstream_checks.py cleanroom/private/upstream/m4-1.4.21-checks/checks
```

Do not extract or inspect GNU m4 implementation source files.

## Repository layout

- `src/main.rs` — single-file binary crate (engine, eval, regex, builtins).
- `tests/` — Rust integration tests (oracle parity).
- `tools/` — runtime developer tools (`oracle_sweep.py`, `run_upstream_checks.py`).
- `cleanroom/` — clean-room provenance: notes, binary-analysis tools, and
  `cleanroom/private/` (gitignored) for downloaded upstream archives and
  generated traces.
- `.forgejo/workflows/ci.yml` — fmt, clippy, unit tests, oracle sweep against
  Debian's GNU m4.

## Lint policy

`#![deny(warnings)]` is in effect at the crate root, and CI also passes
`RUSTFLAGS=-D warnings`. Any rustc warning is a hard error. CI additionally
runs `cargo clippy --all-targets -- -D warnings` and `cargo fmt --check`.

## License

MIT — see [`LICENSE`](LICENSE).
