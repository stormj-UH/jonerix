dnl Basic divert/undivert: deferred output pattern
dnl Everything in diversion 1 comes after diversion 0
divert(`1')
DEFERRED LINE 1
DEFERRED LINE 2
divert(`0')
IMMEDIATE LINE
undivert(`1')
AFTER UNDIVERT
