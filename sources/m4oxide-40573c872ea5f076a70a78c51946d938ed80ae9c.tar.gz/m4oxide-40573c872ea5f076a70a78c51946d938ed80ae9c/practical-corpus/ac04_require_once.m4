dnl AC_REQUIRE-like one-time macro idiom
dnl Pattern: run a macro body exactly once; subsequent calls are no-ops
define(`_run_once_set', `')
define(`AC_REQUIRE',
`ifdef(`_done_$1', `', `define(`_done_$1', `1')$1')')
define(`CHECK_HEADERS',
`define(`_have_headers', `yes')
HEADERS_CHECKED
')
define(`CHECK_COMPILER',
`AC_REQUIRE(`CHECK_HEADERS')dnl
define(`_have_compiler', `yes')
COMPILER_CHECKED
')
dnl First call triggers CHECK_HEADERS once
AC_REQUIRE(`CHECK_HEADERS')
dnl Second call: already done, no output
AC_REQUIRE(`CHECK_HEADERS')
dnl CHECK_COMPILER triggers CHECK_HEADERS but it's already done
CHECK_COMPILER
dnl Verify state
have_headers: _have_headers
have_compiler: _have_compiler
