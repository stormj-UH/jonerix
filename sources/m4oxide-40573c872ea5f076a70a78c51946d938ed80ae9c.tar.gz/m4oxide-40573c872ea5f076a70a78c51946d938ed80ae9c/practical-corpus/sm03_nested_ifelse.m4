dnl sendmail.cf-style deeply nested ifelse + define interactions
define(`confSMTP_MAILER', `esmtp')
define(`confLOCAL_MAILER', `local')
define(`confPROG_MAILER', `prog')
define(`MAIL_HUB', `')
define(`LOCAL_RELAY', `')
define(`SMART_HOST', `relay.example.com')
dnl sendmail ruleset-like macro dispatch
define(`route_addr',
`ifelse(`$1', `local',
  `ifelse(MAIL_HUB, `',
    `local_delivery(`$2')',
    `relay_to(MAIL_HUB, `$2')'),
  `$1', `relay',
  `ifelse(LOCAL_RELAY, `',
    `ifelse(SMART_HOST, `',
      `error(`no relay defined')',
      `relay_to(SMART_HOST, `$2')'),
    `relay_to(LOCAL_RELAY, `$2')'),
  `direct_delivery(`$1', `$2')')')
route_addr(`local', `user@localhost')
route_addr(`relay', `user@remote.com')
route_addr(`direct', `user@direct.com')
