dnl m4_format / format (sprintf-style) usage
dnl format is a GNU m4 extension
format(`%d', 42)
format(`%05d', 7)
format(`%s and %s', `foo', `bar')
format(`%10s', `right')
format(`%-10s|', `left')
format(`%x', 255)
format(`%X', 255)
format(`%o', 8)
dnl Combining with eval
format(`%d', eval(`2 ** 10'))
format(`%d + %d = %d', 3, 4, eval(`3 + 4'))
