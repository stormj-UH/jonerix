dnl patsubst with backreferences and complex patterns
dnl Replace foo(x) with x_wrapped
patsubst(`foo(a) bar foo(bb) baz foo(ccc)', `foo(\([^)]*\))', `\1_wrapped')
dnl Remove C-style line comments
patsubst(`code; // comment
more_code; // another
final;', `//[^\n]*', `')
dnl Double-quote words
patsubst(`alpha beta gamma', `\([a-z]*\)', `"\1"')
dnl Collapse multiple spaces
patsubst(`a   b    c     d', ` [ ]*', ` ')
dnl Autoconf-style: escape shell special chars
define(`AS_ESCAPE',
`patsubst(patsubst(`$1', `[\&]', `\\\&'), `[`"$\\]', `\\\&')')
AS_ESCAPE(`hello $world "foo" & bar\baz')
