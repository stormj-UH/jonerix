dnl eval with bit-twiddling operations
dnl Basic bitwise ops
eval(`0xFF & 0x0F')
eval(`0xF0 | 0x0F')
eval(`0xFF ^ 0x0F')
eval(`~0 & 0xFF')
dnl Shifts
eval(`1 << 8')
eval(`256 >> 4')
eval(`0xAB << 4')
dnl Masks and flags via literal eval
eval(`1 | 2 | 4')
eval(`1 & 3')
eval(`2 & 3')
eval(`4 & 3')
dnl Check flag set: (rw_flags & FLAG_WRITE) != 0
eval(`(1 | 2) & 2')
eval(`(1 | 4) & 2')
dnl Hex literals
eval(`0xDEAD & 0xFF00')
eval(`0xBEEF | 0x1000')
eval(`0xCAFE ^ 0xF00F')
dnl XOR trick: swap via XOR
define(`xor_swap_check',
`eval(`($1 ^ $2 ^ $1) == $2')')
xor_swap_check(`42', `17')
xor_swap_check(`255', `0')
