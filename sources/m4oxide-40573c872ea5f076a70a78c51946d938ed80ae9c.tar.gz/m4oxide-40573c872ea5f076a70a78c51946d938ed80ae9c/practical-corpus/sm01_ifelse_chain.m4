dnl sendmail.cf-style: heavy ifelse chains + define
define(`MAILER_WANTED', `smtp')
define(`RELAY_HOST', `mail.example.com')
define(`RELAY_PORT', `587')
dnl Multi-branch ifelse (sendmail uses these extensively)
define(`MAILER_CLASS',
`ifelse(`$1', `smtp', `SMTP[$2]',
        `$1', `local', `LOCAL',
        `$1', `relay', `RELAY:$2',
        `UNKNOWN')')
MAILER_CLASS(`smtp', `mailserver.example.com')
MAILER_CLASS(`local', `')
MAILER_CLASS(`relay', `relay.example.com')
MAILER_CLASS(`fax', `')
dnl Nested defines used like sendmail feature macros
define(`FEATURE',
`ifdef(`_feature_$1',
`',
`define(`_feature_$1', `1')dnl
_enable_feature_$1($2)dnl
')')
define(`_enable_feature_masquerade',
`define(`_MASQUERADE_DOMAIN', ifelse(`$1', `', `example.com', `$1'))')
define(`_enable_feature_nullclient',
`define(`_SMARTHOST', `$1')')
FEATURE(`masquerade', `my.domain.com')
FEATURE(`masquerade', `ignored')
FEATURE(`nullclient', `smarthost.example.com')
MASQUERADE: _MASQUERADE_DOMAIN
SMARTHOST: _SMARTHOST
