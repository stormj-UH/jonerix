dnl Generate a function dispatch table (non-recursive, fixed arity)
dnl DISPATCH5(TableName, fn0, fn1, fn2, fn3, fn4)
define(`DISPATCH5',
`typedef int (*$1_fn)(void *ctx);
static $1_fn $1_table[] = {
    [$2_CMD] = $2_handler,
    [$3_CMD] = $3_handler,
    [$4_CMD] = $4_handler,
    [$5_CMD] = $5_handler,
    [$6_CMD] = $6_handler,
};
#define $1_DISPATCH(cmd, ctx) \
    ($1_table[(cmd)]((ctx)))
')
DISPATCH5(`ipc', `CREATE', `READ', `UPDATE', `DELETE', `LIST')
dnl Also test: generating #defines for offsets
define(`STRUCT_FIELD',
`#define OFFSET_$2 eval(`$3')
')
define(`STRUCT_LAYOUT',
`/* struct $1 layout */
STRUCT_FIELD(`$1', `field_a', `0')dnl
STRUCT_FIELD(`$1', `field_b', `eval(`0 + 8')')dnl
STRUCT_FIELD(`$1', `field_c', `eval(`0 + 8 + 4')')dnl
#define SIZEOF_$1 eval(`0 + 8 + 4 + 8')
')
STRUCT_LAYOUT(`MyRecord')
