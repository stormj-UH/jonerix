dnl ADVERSARIAL: macro names as arguments, indir, defn, and pushdef/popdef stack
dnl Tests subtle m4 behavior with macro name manipulation
define(`DISPATCH', `indir(`handler_$1', $2)')
define(`handler_add', `eval(`$1 + $2')')
define(`handler_mul', `eval(`$1 * $2')')
define(`handler_sub', `eval(`$1 - $2')')
DISPATCH(`add', `3, 5')
DISPATCH(`mul', `3, 5')
DISPATCH(`sub', `10, 3')
dnl defn returns the definition (not expansion)
define(`a', `FIRST')
define(`b', defn(`a'))
b
dnl pushdef/popdef stack manipulation - real autoconf pattern
pushdef(`LOCAL', `outer')
pushdef(`LOCAL', `inner')
LOCAL
popdef(`LOCAL')
LOCAL
popdef(`LOCAL')
dnl After both pops, LOCAL is undefined
ifdef(`LOCAL', `still defined', `correctly undefined')
dnl Self-referential but bounded: macro that redefines itself
define(`counter', `0')
define(`tick', `define(`counter', incr(counter))counter')
tick
tick
tick
counter
