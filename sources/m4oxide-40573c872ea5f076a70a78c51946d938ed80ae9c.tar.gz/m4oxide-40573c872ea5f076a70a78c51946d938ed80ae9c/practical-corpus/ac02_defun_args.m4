dnl AC_DEFUN-style macro with $@, $#, $*
define(`AC_DEFUN',
`define(`$1', `$2')')
AC_DEFUN(`MY_CHECK_LIB',
`dnl arg1=$1 arg2=$2 nargs=$#
define(`_have_$1', ifelse(`$2', `', `yes', `$2'))dnl
')
MY_CHECK_LIB(`pthread')
MY_CHECK_LIB(`ssl', `no')
have_pthread: _have_pthread
have_ssl: _have_ssl

dnl Test $@ and $* expansion
define(`SHOW_AT', `[$@]')
define(`SHOW_STAR', `[$*]')
SHOW_AT(`a', `b', `c')
SHOW_STAR(`a', `b', `c')

dnl Test $# count
define(`NARGS', `$#')
NARGS(`a', `b', `c')
NARGS()
NARGS(`only')
