dnl m4_define / m4_ifval style - expects -P flag
dnl extra options: -P
m4_define(`m4_ifval',
`m4_ifelse(`$1', `', `$3', `$2')')
m4_define(`m4_ifblank',
`m4_ifelse(m4_translit(`$1', ` 	', `'), `', `$2', `$3')')
m4_define(`RESULT', `not-set')
m4_define(`maybe_set',
`m4_ifval(`$1', `m4_define(`RESULT', `$1')')')
maybe_set(`hello')
RESULT
maybe_set(`')
RESULT
m4_ifblank(`   ', `IS_BLANK', `NOT_BLANK')
m4_ifblank(`x', `IS_BLANK', `NOT_BLANK')
