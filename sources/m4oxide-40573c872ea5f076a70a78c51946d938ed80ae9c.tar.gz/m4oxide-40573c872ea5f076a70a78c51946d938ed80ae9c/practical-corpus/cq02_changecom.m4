dnl changecom interactions
dnl Default: # is comment
define(`X', `hello')
X # this is a comment
# another comment
dnl Disable comments
changecom()
X # not a comment now
# also not a comment
dnl Custom comment delimiters
changecom(`//', `
')
X // C++ style comment
normal text
dnl Block-comment style
changecom(`/*', `*/')
X /* block comment */ Y
before /* multi
line
comment */ after
dnl Restore default
changecom(`#')
X # default again
