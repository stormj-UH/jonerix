dnl changequote interaction patterns
dnl Switch to [[ ]] quoting (common in autoconf m4sugar)
changequote([[, ]])
define([[SQUARE_QUOTED]], [[hello world]])
SQUARE_QUOTED
dnl Nested square brackets in quoted content
define([[WITH_BRACKETS]], [[array[0] = 1]])
WITH_BRACKETS
changequote(`, ')
dnl Back to defaults
define(`BACK_TO_NORMAL', `regular quoting')
BACK_TO_NORMAL
dnl changequote to disable (single-arg form)
changequote(`<<', `>>')
define(<<ANGLE>>, <<bracket style>>)
ANGLE
changequote
dnl After no-arg changequote, back to ` and '
define(`RESTORED', `works again')
RESTORED
