dnl Generate C enum + string table from a fixed list
dnl Non-recursive version using explicit positional args
define(`ENUM4',
`typedef enum {
    $2 = 0,
    $3 = 1,
    $4 = 2,
    $5 = 3,
} $1;
static const char *$1_names[] = {
    "$2",
    "$3",
    "$4",
    "$5",
    NULL
};')
define(`ENUM6',
`typedef enum {
    $2 = 0,
    $3 = 1,
    $4 = 2,
    $5 = 3,
    $6 = 4,
    $7 = 5,
} $1;
static const char *$1_names[] = {
    "$2",
    "$3",
    "$4",
    "$5",
    "$6",
    "$7",
    NULL
};')
ENUM4(`Color', `RED', `GREEN', `BLUE', `ALPHA')
ENUM6(`Direction', `NORTH', `SOUTH', `EAST', `WEST', `UP', `DOWN')
