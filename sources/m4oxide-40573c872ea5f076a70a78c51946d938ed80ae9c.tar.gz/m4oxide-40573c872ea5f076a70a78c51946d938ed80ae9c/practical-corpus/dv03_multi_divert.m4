dnl Multiple diversions with undivert ordering
dnl Autoconf uses this to reorder output sections
divert(`3')SECTION_3_A
divert(`1')SECTION_1_A
divert(`2')SECTION_2_A
divert(`3')SECTION_3_B
divert(`1')SECTION_1_B
divert(`2')SECTION_2_B
divert(`0')dnl
IMMEDIATE_START
undivert(`1')
undivert(`2')
undivert(`3')
IMMEDIATE_END
dnl discard (divert -1) then back
divert(`-1')DISCARDED OUTPUT
divert(`0')
AFTER_DISCARD
