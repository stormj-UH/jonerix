dnl Bounded switch/case generator using ifelse chains
dnl Generates a C-style switch statement from pairs
define(`CASE',
`    case $1:
        $2
        break;
')
define(`DEFAULT',
`    default:
        $1
        break;
')
define(`SWITCH2',
`switch ($1) {
CASE(`$2', `$3')CASE(`$4', `$5')DEFAULT(`$6')
}')
define(`SWITCH3',
`switch ($1) {
CASE(`$2', `$3')CASE(`$4', `$5')CASE(`$6', `$7')DEFAULT(`$8')
}')
define(`SWITCH4',
`switch ($1) {
CASE(`$2', `$3')CASE(`$4', `$5')CASE(`$6', `$7')CASE(`$8', `$9')DEFAULT(`$10')
}')
SWITCH3(`cmd',
  `1', `handle_create(ctx)',
  `2', `handle_read(ctx)',
  `3', `handle_update(ctx)',
  `return ERR_UNKNOWN_CMD')
SWITCH2(`op',
  `OP_ADD', `result = a + b',
  `OP_SUB', `result = a - b',
  `result = 0')
