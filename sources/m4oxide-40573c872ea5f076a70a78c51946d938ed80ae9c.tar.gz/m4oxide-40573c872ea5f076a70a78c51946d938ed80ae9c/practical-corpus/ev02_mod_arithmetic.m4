dnl eval with modular arithmetic and comparisons in ifelse
define(`is_even', `ifelse(eval(`$1 % 2'), `0', `yes', `no')')
define(`is_odd',  `ifelse(eval(`$1 % 2'), `1', `yes', `no')')
is_even(`4')
is_even(`7')
is_odd(`3')
is_odd(`8')
dnl fizzbuzz via eval
define(`fizzbuzz',
`ifelse(eval(`$1 % 15 == 0'), `1', `FizzBuzz',
        `ifelse(eval(`$1 % 3 == 0'), `1', `Fizz',
                `ifelse(eval(`$1 % 5 == 0'), `1', `Buzz',
                        `$1')')')')
fizzbuzz(`1')
fizzbuzz(`3')
fizzbuzz(`5')
fizzbuzz(`9')
fizzbuzz(`10')
fizzbuzz(`15')
fizzbuzz(`30')
dnl Integer division / alignment
define(`align_to', `eval(`(($1 + $2 - 1) / $2) * $2')')
align_to(`10', `4')
align_to(`16', `4')
align_to(`17', `8')
align_to(`0', `64')
