dnl ADVERSARIAL: bash-style autoconf macro that abuses m4 quoting
dnl Mimics how autoconf generates shell code with m4 quoting
dnl The tricky part: shell $var syntax inside m4 quotes
define(`AS_IF',
`if $1; then
  :
  $2
fi
')
define(`AS_VAR_SET',
`eval $1=`$2`'`'')
define(`AS_VAR_GET',
`eval `echo `'"\$$1"`'')
dnl Shell heredoc-like pattern (common in autoconf)
define(`AS_ECHO',
`printf "%s\n" "$1"')
dnl This tests that m4 handles unbalanced quotes in shell-like output
AS_IF(`test -f /etc/passwd',
`AS_ECHO(`/etc/passwd exists')')
AS_VAR_SET(`myvar', `hello world')
dnl Pattern: macros that emit other m4 macros to be re-expanded
define(`SECOND_EXPAND',
`define(`INNER', `$1')INNER')
SECOND_EXPAND(`recursion_test')
dnl Quoting depth stress: quotes-within-quotes
define(`Q1', ``level 1'')
define(`Q2', ```level 2''')
Q1
Q2
