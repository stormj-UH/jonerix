dnl regexp + patsubst combos from real autoconf usage
dnl Strip leading/trailing whitespace (autoconf m4_strip style)
define(`strip',
`patsubst(patsubst(`$1', `^[ 	]*', `'), `[ 	]*$', `')')
strip(`  hello world  ')
strip(`	tabs and spaces	')
strip(`already clean')
dnl Extract version components
define(`version_major',
`regexp(`$1', `^\([0-9]*\)', `\1')')
define(`version_minor',
`regexp(`$1', `^[0-9]*\.\([0-9]*\)', `\1')')
define(`version_patch',
`regexp(`$1', `^[0-9]*\.[0-9]*\.\([0-9]*\)', `\1')')
version_major(`3.14.159')
version_minor(`3.14.159')
version_patch(`3.14.159')
dnl Autoconf-style identifier sanitization (make it a valid C id)
define(`AS_TR_CPP',
`patsubst(translit(`$1', `abcdefghijklmnopqrstuvwxyz', `ABCDEFGHIJKLMNOPQRSTUVWXYZ'), `[^A-Z0-9_]', `_')')
AS_TR_CPP(`my-package/name.h')
AS_TR_CPP(`3foo bar')
