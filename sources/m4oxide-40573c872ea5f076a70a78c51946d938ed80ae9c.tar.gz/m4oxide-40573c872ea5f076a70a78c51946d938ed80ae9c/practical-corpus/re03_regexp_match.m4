dnl regexp for matching and extraction
dnl regexp(string, regexp) -> 0-based pos, or -1
regexp(`hello world', `world')
regexp(`hello world', `xyz')
regexp(`hello world', `o w')
dnl regexp with replacement
regexp(`2024-01-15', `\([0-9]*\)-\([0-9]*\)-\([0-9]*\)', `year=\1 month=\2 day=\3')
dnl Complex: validate identifier
define(`is_ident',
`ifelse(regexp(`$1', `^[A-Za-z_][A-Za-z0-9_]*$'), `-1', `no', `yes')')
is_ident(`valid_name')
is_ident(`123invalid')
is_ident(`also_valid_99')
is_ident(`bad-name')
dnl Autoconf-style token extraction
define(`m4_head',
`regexp(`$1', `^\([^ ]*\) .*', `\1')')
define(`m4_tail',
`regexp(`$1', `^[^ ]* \(.*\)', `\1')')
m4_head(`first second third')
m4_tail(`first second third')
