dnl AC_INIT-style argument quoting patterns
define(`AC_INIT',
`define(`PACKAGE_NAME', `$1')dnl
define(`PACKAGE_VERSION', `$2')dnl
define(`PACKAGE_BUGREPORT', `$3')dnl
')
AC_INIT(`MyPackage', `1.2.3', `bugs@example.com')
Package: PACKAGE_NAME
Version: PACKAGE_VERSION
Report: PACKAGE_BUGREPORT
