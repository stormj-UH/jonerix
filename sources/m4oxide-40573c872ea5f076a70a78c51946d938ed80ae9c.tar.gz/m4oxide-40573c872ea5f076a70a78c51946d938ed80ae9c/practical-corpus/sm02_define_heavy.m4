dnl sendmail.cf-style: define-heavy with conditional expansion
define(`TRUE', `1')
define(`FALSE', `0')
define(`bool_str',
`ifelse(`$1', `1', `true', `false')')
define(`not',
`ifelse(`$1', `1', `0', `1')')
define(`and',
`ifelse(`$1', `1', `ifelse(`$2', `1', `1', `0')', `0')')
define(`or',
`ifelse(`$1', `1', `1', `ifelse(`$2', `1', `1', `0')')')
bool_str(`TRUE')
bool_str(`FALSE')
bool_str(not(`TRUE'))
bool_str(and(`TRUE', `FALSE'))
bool_str(and(`TRUE', `TRUE'))
bool_str(or(`FALSE', `TRUE'))
bool_str(or(`FALSE', `FALSE'))
dnl Sendmail-style hostname munging
define(`CANONIFY',
`patsubst(`$1', `\.\([^.]*\)$', ``'')')
define(`DOMAIN_PART',
`patsubst(`$1', `^[^.]*\.', ``'')')
CANONIFY(`host.example.com')
DOMAIN_PART(`host.example.com')
DOMAIN_PART(`sub.host.example.com')
