dnl Complex quote + comment interaction
dnl This tests that changequote and changecom don't interfere
changequote(`{', `}')
changecom(`%', `
')
define({FOO}, {bar})
FOO % this is a comment under new comment style
{literal braces}
% comment line
changecom()
FOO % no longer a comment
changequote
define(`NORMAL', `restored')
NORMAL
% not a comment (comments disabled)
changecom(`#')
# comment again
NORMAL
