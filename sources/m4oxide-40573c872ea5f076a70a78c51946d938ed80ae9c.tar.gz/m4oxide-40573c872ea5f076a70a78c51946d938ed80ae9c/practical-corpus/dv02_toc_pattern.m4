dnl Table-of-contents pattern: collect headers into diversion 1,
dnl body goes to diversion 0, then prepend TOC via undivert
define(`SECTION',
`divert(`1')  * $1
divert(`0')== $1 ==
$2
')
dnl Collect sections - TOC ends up in diversion 1
divert(`2')dnl
TABLE OF CONTENTS
undivert(`1')dnl
divert(`0')
---BODY---
SECTION(`Introduction', `This is the intro.')
SECTION(`Methods', `These are the methods.')
SECTION(`Results', `Here are results.')
---END---
undivert(`2')
