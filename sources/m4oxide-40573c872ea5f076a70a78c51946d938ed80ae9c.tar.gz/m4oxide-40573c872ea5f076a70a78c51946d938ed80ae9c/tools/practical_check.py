#!/usr/bin/env python3
"""Practical-corpus oracle checker for m4oxide.

Diffs m4oxide vs oracle output (stdout + stderr + exit code) for every
.m4 file in practical-corpus/ and reports pass/fail.
"""

from __future__ import annotations

import argparse
import os
import subprocess
import sys
from pathlib import Path


def extra_args(path: Path) -> list[str]:
    """Return extra CLI args declared via 'dnl extra options: ...' in the file."""
    import shlex
    try:
        for line in path.read_text(errors="replace").splitlines():
            if line.startswith("dnl extra options:"):
                return shlex.split(line.split(":", 1)[1].strip())
    except OSError:
        pass
    return []


def run_m4(binary: str, path: Path, extra: list[str], timeout: float = 10.0) -> tuple[int, bytes, bytes]:
    env = dict(os.environ)
    env["M4OXIDE_TEST_MODE"] = "1"
    try:
        proc = subprocess.run(
            [binary, *extra, str(path)],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            env=env,
            check=False,
            timeout=timeout,
        )
    except subprocess.TimeoutExpired as e:
        return 124, e.stdout or b"", (e.stderr or b"") + b"\nTIMEOUT\n"
    return proc.returncode, proc.stdout, proc.stderr


def main() -> int:
    parser = argparse.ArgumentParser(description="Practical corpus oracle checker for m4oxide")
    parser.add_argument("--oracle", default=os.environ.get("M4_ORACLE", "m4"))
    parser.add_argument("--candidate", default="target/debug/m4oxide")
    parser.add_argument("--corpus", default="practical-corpus")
    parser.add_argument("--verbose", "-v", action="store_true")
    ns = parser.parse_args()

    corpus_dir = Path(ns.corpus)
    if not corpus_dir.is_dir():
        print(f"error: corpus directory not found: {corpus_dir}", file=sys.stderr)
        return 2

    files = sorted(corpus_dir.glob("*.m4"))
    if not files:
        print(f"error: no .m4 files in {corpus_dir}", file=sys.stderr)
        return 2

    passed = 0
    failed = 0
    errors: list[str] = []

    for path in files:
        extra = extra_args(path)
        expected_rc, expected_out, expected_err = run_m4(ns.oracle, path, extra)
        actual_rc, actual_out, actual_err = run_m4(ns.candidate, path, extra)

        ok = (actual_rc == expected_rc and actual_out == expected_out and actual_err == expected_err)
        if ok:
            print(f"ok {path.name}")
            passed += 1
        else:
            label = f"FAIL {path.name}"
            print(label, file=sys.stderr)
            if ns.verbose or actual_rc != expected_rc:
                print(f"  exit: oracle={expected_rc} ours={actual_rc}", file=sys.stderr)
            if actual_out != expected_out:
                import difflib
                diff = list(difflib.unified_diff(
                    expected_out.decode(errors="replace").splitlines(keepends=True),
                    actual_out.decode(errors="replace").splitlines(keepends=True),
                    fromfile="oracle-stdout",
                    tofile="ours-stdout",
                    n=3,
                ))
                print("".join(diff[:30]), file=sys.stderr)
            if actual_err != expected_err:
                import difflib
                diff = list(difflib.unified_diff(
                    expected_err.decode(errors="replace").splitlines(keepends=True),
                    actual_err.decode(errors="replace").splitlines(keepends=True),
                    fromfile="oracle-stderr",
                    tofile="ours-stderr",
                    n=3,
                ))
                print("".join(diff[:20]), file=sys.stderr)
            errors.append(label)
            failed += 1

    print(f"\n{passed} passed, {failed} failed out of {passed + failed} total")
    return 0 if failed == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
