#!/bin/sh
# bench.sh — re-run the m4oxide perf benchmarks
# Usage: ./bench.sh [candidate_binary]
# Requires: /opt/homebrew/Cellar/m4/1.4.21/bin/m4 as GNU m4 oracle
#           /tmp/m4oxide-perf/upstream/m4-1.4.21-checks/checks/ for corpus
#           Python3

set -e
CANDIDATE="${1:-target/release/m4oxide}"
ORACLE="${M4_ORACLE:-/opt/homebrew/Cellar/m4/1.4.21/bin/m4}"
CHECKS="/tmp/m4oxide-perf/upstream/m4-1.4.21-checks/checks"
STRESS="$(dirname "$0")/stress.m4"

echo "=== m4oxide perf benchmark ==="
echo "candidate: $CANDIDATE"
echo "oracle:    $ORACLE"
echo ""

# Build release if requested
if [ "${BUILD:-0}" = "1" ]; then
  cargo build --release --locked
fi

# --- 248-file corpus timing ---
echo "--- 248-file corpus (3 runs) ---"
for run in 1 2 3; do
  start=$(python3 -c 'import time; print(time.time())')
  for f in "$CHECKS"/*; do M4OXIDE_TEST_MODE=1 "$CANDIDATE" "$f" > /dev/null 2>&1; done
  end=$(python3 -c 'import time; print(time.time())')
  python3 -c "print(f'm4oxide run$run: {$end - $start:.3f}s')"
done
for run in 1 2 3; do
  start=$(python3 -c 'import time; print(time.time())')
  for f in "$CHECKS"/*; do M4OXIDE_TEST_MODE=1 "$ORACLE" "$f" > /dev/null 2>&1; done
  end=$(python3 -c 'import time; print(time.time())')
  python3 -c "print(f'GNU m4  run$run: {$end - $start:.3f}s')"
done

echo ""
echo "--- stress.m4 (3 runs each) ---"
for run in 1 2 3; do
  { time M4OXIDE_TEST_MODE=1 "$CANDIDATE" "$STRESS" > /dev/null 2>&1; } 2>&1 | \
    awk '{print "m4oxide run'"$run"':", $1}'
done
for run in 1 2 3; do
  { time M4OXIDE_TEST_MODE=1 "$ORACLE" "$STRESS" > /dev/null 2>&1; } 2>&1 | \
    awk '{print "GNU m4  run'"$run"':", $1}'
done

echo ""
echo "--- Peak RSS (Makefile.in) ---"
/usr/bin/time -l sh -c \
  "M4OXIDE_TEST_MODE=1 $CANDIDATE $CHECKS/Makefile.in > /dev/null 2>&1" \
  2>&1 | grep "maximum resident"

echo ""
echo "--- Correctness: 248-file check ---"
M4_ORACLE="$ORACLE" python3 tools/run_upstream_checks.py "$CHECKS" \
  --candidate "$CANDIDATE" 2>&1 | tail -1

echo ""
echo "--- Binary size ---"
ls -lh "$CANDIDATE"
