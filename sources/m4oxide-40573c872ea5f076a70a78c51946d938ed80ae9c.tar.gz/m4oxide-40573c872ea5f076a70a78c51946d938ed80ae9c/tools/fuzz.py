#!/usr/bin/env python3
"""Random valid m4 input fuzzer for m4oxide.

Generates 200 random but syntactically-valid m4 inputs, feeds each to both
the oracle and m4oxide, and compares stdout + stderr + exit code.

Usage:
    python3 fuzz.py [--oracle /path/to/m4] [--candidate ./target/debug/m4oxide]
    python3 fuzz.py --seed 42 --count 200 --timeout 5

Exit: 0 if all match, 1 if any diverge, 2 on setup error.
"""

from __future__ import annotations

import argparse
import os
import random
import subprocess
import sys
from pathlib import Path


# ── grammar knobs ─────────────────────────────────────────────────────────────

NAMES = [
    "foo", "bar", "baz", "x", "y", "z", "m", "n", "a", "b",
    "hello", "world", "val", "res", "tmp", "item", "obj", "msg",
]

LITERALS = [
    "hello", "world", "42", "abc", "xyz", "1", "0", "yes", "no",
    "true", "false", "alpha", "beta", "gamma",
]

EVAL_EXPRS = [
    "1 + 2",
    "10 * 3 - 5",
    "eval(`2 ** 8')",
    "255 & 0x0F",
    "0xFF | 0x100",
    "1 << 4",
    "128 >> 2",
    "100 % 7",
    "42 == 42",
    "3 != 5",
    "10 > 5",
    "5 < 10",
    "~0 & 0xFFFF",
    "0xAB ^ 0xF0",
]

SIMPLE_STRINGS = [
    "hello world",
    "foo bar baz",
    "abc 123 xyz",
    "alpha beta gamma",
    "one two three",
]

TRANSLIT_FROM = ["abcdef", "aeiou", "abc", "xyz", "0123456789"]
TRANSLIT_TO   = ["ABCDEF", "AEIOU", "ABC", "XYZ", "9876543210"]

REGEXP_PATTERNS = [
    r"\([a-z]*\)",
    r"[0-9]*",
    r"\w+",
    r"^[a-z]",
    r"[a-z]*$",
    r"[a-zA-Z_][a-zA-Z0-9_]*",
]

PATSUBST_REPLS = [r"\1", r"[\1]", r"(\&)", "_", r"\1_wrapped"]


# ── generator helpers ─────────────────────────────────────────────────────────

def rng_name(rng: random.Random) -> str:
    return rng.choice(NAMES)

def rng_lit(rng: random.Random) -> str:
    return rng.choice(LITERALS)

def rng_quote(s: str) -> str:
    return f"`{s}'"

def rng_define(rng: random.Random) -> str:
    name = rng_name(rng)
    body = rng_lit(rng)
    return f"define({rng_quote(name)}, {rng_quote(body)})\n"

def rng_ifdef(rng: random.Random) -> str:
    name = rng_name(rng)
    yes = rng_lit(rng)
    no  = rng_lit(rng)
    return f"ifdef({rng_quote(name)}, {rng_quote(yes)}, {rng_quote(no)})\n"

def rng_ifelse(rng: random.Random) -> str:
    a = rng_lit(rng)
    b = rng.choice([a, rng_lit(rng)])
    yes = rng_lit(rng)
    no  = rng_lit(rng)
    return f"ifelse({rng_quote(a)}, {rng_quote(b)}, {rng_quote(yes)}, {rng_quote(no)})\n"

def rng_eval(rng: random.Random) -> str:
    expr = rng.choice(EVAL_EXPRS)
    return f"eval(`{expr}')\n"

def rng_translit(rng: random.Random) -> str:
    idx = rng.randrange(len(TRANSLIT_FROM))
    s   = rng.choice(SIMPLE_STRINGS)
    return f"translit({rng_quote(s)}, {rng_quote(TRANSLIT_FROM[idx])}, {rng_quote(TRANSLIT_TO[idx])})\n"

def rng_len(rng: random.Random) -> str:
    return f"len({rng_quote(rng_lit(rng))})\n"

def rng_index(rng: random.Random) -> str:
    s = rng.choice(SIMPLE_STRINGS)
    words = s.split()
    sub = rng.choice(words + ["xyz"])
    return f"index({rng_quote(s)}, {rng_quote(sub)})\n"

def rng_substr(rng: random.Random) -> str:
    s = rng.choice(SIMPLE_STRINGS)
    start = rng.randint(0, max(0, len(s) - 2))
    length = rng.randint(1, max(1, len(s) - start))
    return f"substr({rng_quote(s)}, `{start}', `{length}')\n"

def rng_changequote(rng: random.Random) -> str:
    # Use safe bracket pairs only
    pairs = [("[[", "]]"), ("{{{", "}}}")]
    l, r = rng.choice(pairs)
    name = rng_name(rng)
    body = rng_lit(rng)
    return (
        f"changequote(`{l}', `{r}')\n"
        f"define({l}{name}{r}, {l}{body}{r})\n"
        f"{name}\n"
        f"changequote\n"
    )

def rng_divert(rng: random.Random) -> str:
    n = rng.randint(1, 5)
    lines = [f"divert(`{n}')\nDEFERRED_{n}\n", "divert(`0')\nIMMEDIATE\n", f"undivert(`{n}')\n"]
    return "".join(lines)

def rng_dnl(rng: random.Random) -> str:
    lit = rng_lit(rng)
    return f"{lit} dnl this is discarded\nnext_line\n"

def rng_patsubst(rng: random.Random) -> str:
    s   = rng.choice(SIMPLE_STRINGS)
    pat = rng.choice(REGEXP_PATTERNS[:3])  # safe patterns only
    rep = rng.choice(PATSUBST_REPLS[:3])
    return f"patsubst({rng_quote(s)}, {rng_quote(pat)}, {rng_quote(rep)})\n"

def rng_regexp(rng: random.Random) -> str:
    s   = rng.choice(SIMPLE_STRINGS)
    pat = rng.choice(REGEXP_PATTERNS[:3])
    return f"regexp({rng_quote(s)}, {rng_quote(pat)})\n"

def rng_pushpop(rng: random.Random) -> str:
    name = rng_name(rng)
    v1   = rng_lit(rng)
    v2   = rng_lit(rng)
    return (
        f"define({rng_quote(name)}, {rng_quote(v1)})\n"
        f"pushdef({rng_quote(name)}, {rng_quote(v2)})\n"
        f"{name}\n"
        f"popdef({rng_quote(name)})\n"
        f"{name}\n"
    )

def rng_indir(rng: random.Random) -> str:
    name = rng_name(rng)
    body = rng_lit(rng)
    return (
        f"define({rng_quote(name)}, {rng_quote(body)})\n"
        f"indir({rng_quote(name)})\n"
    )

def rng_incr_decr(rng: random.Random) -> str:
    n = rng.randint(0, 100)
    return f"incr(`{n}') decr(`{n}')\n"

def rng_m4wrap(rng: random.Random) -> str:
    msg = rng_lit(rng)
    return f"m4wrap({rng_quote(msg + chr(10))})\nbody_text\n"

def rng_format(rng: random.Random) -> str:
    fmts = [
        ("`%d'", "`42'"),
        ("`%05d'", "`7'"),
        ("`%s and %s'", "`foo', `bar'"),
        ("`%x'", "`255'"),
    ]
    fmt, args = rng.choice(fmts)
    return f"format({fmt}, {args})\n"


GENERATORS = [
    rng_define,
    rng_ifdef,
    rng_ifelse,
    rng_eval,
    rng_translit,
    rng_len,
    rng_index,
    rng_substr,
    rng_changequote,
    rng_divert,
    rng_dnl,
    rng_patsubst,
    rng_regexp,
    rng_pushpop,
    rng_indir,
    rng_incr_decr,
    rng_m4wrap,
    rng_format,
]


def generate_input(rng: random.Random) -> str:
    n = rng.randint(2, 8)
    lines = []
    for _ in range(n):
        gen = rng.choice(GENERATORS)
        lines.append(gen(rng))
    return "".join(lines)


# ── runner ────────────────────────────────────────────────────────────────────

def run_m4(binary: str, stdin_data: bytes, timeout: float) -> tuple[int, bytes, bytes]:
    env = dict(os.environ)
    env["M4OXIDE_TEST_MODE"] = "1"
    try:
        proc = subprocess.run(
            [binary],
            input=stdin_data,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            env=env,
            check=False,
            timeout=timeout,
        )
    except subprocess.TimeoutExpired as e:
        return 124, e.stdout or b"", (e.stderr or b"") + b"\nTIMEOUT\n"
    return proc.returncode, proc.stdout, proc.stderr


def main() -> int:
    parser = argparse.ArgumentParser(description="m4oxide random fuzzer")
    parser.add_argument("--oracle",    default=os.environ.get("M4_ORACLE", "m4"))
    parser.add_argument("--candidate", default="target/debug/m4oxide")
    parser.add_argument("--seed",      type=int, default=0,   help="RNG seed (0 = random)")
    parser.add_argument("--count",     type=int, default=200, help="Number of test cases")
    parser.add_argument("--timeout",   type=float, default=5.0)
    parser.add_argument("--verbose",   "-v", action="store_true")
    parser.add_argument("--stop-on-first-fail", action="store_true")
    ns = parser.parse_args()

    if not Path(ns.oracle).exists():
        print(f"error: oracle not found: {ns.oracle}", file=sys.stderr)
        return 2

    seed = ns.seed if ns.seed != 0 else random.randrange(2**32)
    print(f"fuzz seed={seed} count={ns.count} oracle={ns.oracle}")
    rng = random.Random(seed)

    passed = 0
    failed = 0
    divergences: list[dict] = []

    for i in range(ns.count):
        src = generate_input(rng)
        data = src.encode()

        expected = run_m4(ns.oracle,    data, ns.timeout)
        actual   = run_m4(ns.candidate, data, ns.timeout)

        if actual == expected:
            if ns.verbose:
                print(f"  ok #{i+1}")
            passed += 1
        else:
            print(f"FAIL #{i+1}", file=sys.stderr)
            if ns.verbose:
                print(f"  input:\n{src}", file=sys.stderr)
                print(f"  oracle:    rc={expected[0]} stdout={expected[1]!r}", file=sys.stderr)
                print(f"  candidate: rc={actual[0]}   stdout={actual[1]!r}", file=sys.stderr)
                if expected[2] or actual[2]:
                    print(f"  oracle-stderr:    {expected[2]!r}", file=sys.stderr)
                    print(f"  candidate-stderr: {actual[2]!r}", file=sys.stderr)
            divergences.append({
                "index": i + 1,
                "input": src,
                "oracle": expected,
                "actual": actual,
            })
            failed += 1
            if ns.stop_on_first_fail:
                break

    print(f"\nfuzz results: {passed} passed, {failed} failed out of {passed + failed} total")

    if divergences:
        print(f"\nFirst divergent input (case #{divergences[0]['index']}):")
        print(divergences[0]["input"])

    return 0 if failed == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
