#!/usr/bin/env python3
"""Black-box comparison helper for m4oxide.

This script compares stdout, stderr, and exit status against a GNU m4 binary.
It intentionally treats GNU m4 as an executable oracle only; it does not read
or require GNU source code.
"""

from __future__ import annotations

import argparse
import os
import subprocess
import sys
from dataclasses import dataclass


@dataclass
class Case:
    name: str
    input: bytes
    args: tuple[str, ...] = ()


CASES: list[Case] = [
    Case("literal", b"plain text\n"),
    Case("quote-strip", b"`quoted'\n"),
    Case("nested-quote", b"``nested''\n"),
    Case("define-basic", b"define(`x', `hello')x\n"),
    Case("define-recursive", b"define(`x', `y')define(`y', `z')x\n"),
    Case("args", b"define(`f', `$1|$2|$#|$*')f(`a', `b')\n"),
    Case("at-args", b"define(`f', `$@')f(`a', `b')\n"),
    Case("shift", b"shift(`a', `b', `c')\n"),
    Case("push-pop", b"define(`x', `1')pushdef(`x', `2')x popdef(`x')x\n"),
    Case("ifdef-yes", b"ifdef(`define', `yes', `no')\n"),
    Case("ifdef-no", b"ifdef(`nope', `yes', `no')\n"),
    Case("ifelse-true", b"ifelse(`a', `a', `yes', `no')\n"),
    Case("ifelse-false", b"ifelse(`a', `b', `yes', `no')\n"),
    Case("len", b"len(`abcdef')\n"),
    Case("index", b"index(`abcdef', `cd')\n"),
    Case("substr", b"substr(`abcdef', `2', `3')\n"),
    Case("translit", b"translit(`abcdef', `ace', `ACE')\n"),
    Case("incr-decr", b"incr(`41') decr(`41')\n"),
    Case("eval", b"eval(`(1 + 2) * 3 == 9')\n"),
    Case("changequote", b"changequote([[, ]])[[abc]]\n"),
    Case("changecom-disable", b"changecom()#not a comment\n"),
    Case("dnl", b"abc dnl discard me\nnext\n"),
    Case("divert", b"divert(`1')one\ndivert`'zero\nundivert(`1')"),
    Case("indir", b"define(`x', `hello')indir(`x')\n"),
    Case("m4wrap", b"m4wrap(`wrapped\n')body\n"),
    Case("cli-define", b"X\n", ("-DX=cli",)),
    Case("cli-prefix", b"m4_define(`x', `p')x\n", ("-P",)),
]


def run(binary: str, case: Case) -> tuple[int, bytes, bytes]:
    env = dict(os.environ)
    env["M4OXIDE_TEST_MODE"] = "1"
    proc = subprocess.run(
        [binary, *case.args],
        input=case.input,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env=env,
        check=False,
    )
    return proc.returncode, proc.stdout, proc.stderr


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--oracle", default=os.environ.get("M4_ORACLE", "m4"))
    parser.add_argument("--candidate", default="target/debug/m4oxide")
    parser.add_argument("--list", action="store_true")
    ns = parser.parse_args()

    if ns.list:
        for case in CASES:
            print(case.name)
        return 0

    failed = 0
    for case in CASES:
        expected = run(ns.oracle, case)
        actual = run(ns.candidate, case)
        if expected != actual:
            failed += 1
            print(f"FAIL {case.name}", file=sys.stderr)
            print(f"  input={case.input!r} args={case.args!r}", file=sys.stderr)
            print(f"  expected rc={expected[0]} stdout={expected[1]!r} stderr={expected[2]!r}", file=sys.stderr)
            print(f"  actual   rc={actual[0]} stdout={actual[1]!r} stderr={actual[2]!r}", file=sys.stderr)
        else:
            print(f"ok {case.name}")
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
