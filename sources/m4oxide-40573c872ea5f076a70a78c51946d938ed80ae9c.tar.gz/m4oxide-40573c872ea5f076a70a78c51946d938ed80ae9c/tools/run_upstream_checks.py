#!/usr/bin/env python3
"""Run extracted GNU m4 check files as black-box oracle tests.

The check files are test inputs, not implementation source. Keep extracted
upstream assets under cleanroom/private so they are not committed.
"""

from __future__ import annotations

import argparse
import os
import shlex
import subprocess
import sys
from pathlib import Path


def extra_options(path: Path) -> list[str]:
    opts: list[str] = []
    with path.open("r", encoding="utf-8", errors="replace") as f:
        for line in f:
            if line.startswith("dnl @ extra options:"):
                value = line.split(":", 1)[1].strip()
                if value:
                    opts = shlex.split(value)
                break
    return opts


def run(binary: str, path: Path, opts: list[str], timeout: float) -> tuple[int, bytes, bytes]:
    env = dict(os.environ)
    env["M4OXIDE_TEST_MODE"] = "1"
    examples = path.parent.parent / "examples"
    if examples.is_dir():
        prior = env.get("M4PATH")
        env["M4PATH"] = str(examples) if not prior else f"{examples}:{prior}"
    try:
        proc = subprocess.run(
            [binary, *opts, str(path)],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            env=env,
            check=False,
            timeout=timeout,
        )
    except subprocess.TimeoutExpired as e:
        return 124, e.stdout or b"", (e.stderr or b"") + b"\nTIMEOUT\n"
    return proc.returncode, proc.stdout, proc.stderr


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("checks", type=Path)
    parser.add_argument("--oracle", default=os.environ.get("M4_ORACLE", "m4"))
    parser.add_argument("--candidate", default="target/debug/m4oxide")
    parser.add_argument("--limit", type=int, default=0)
    parser.add_argument("--prefix", default="")
    parser.add_argument("--timeout", type=float, default=5.0)
    ns = parser.parse_args()

    files = sorted(p for p in ns.checks.iterdir() if p.is_file())
    if ns.prefix:
        files = [p for p in files if p.name.startswith(ns.prefix)]
    if ns.limit:
        files = files[: ns.limit]

    passed = 0
    failed = 0
    for path in files:
        opts = extra_options(path)
        expected = run(ns.oracle, path, opts, ns.timeout)
        actual = run(ns.candidate, path, opts, ns.timeout)
        if expected == actual:
            passed += 1
            print(f"ok {path.name}")
        else:
            failed += 1
            print(f"FAIL {path.name} opts={opts}", file=sys.stderr)
            print(f"  expected rc={expected[0]} out={len(expected[1])} err={expected[2][:200]!r}", file=sys.stderr)
            print(f"  actual   rc={actual[0]} out={len(actual[1])} err={actual[2][:200]!r}", file=sys.stderr)
    print(f"passed={passed} failed={failed} total={passed + failed}")
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
