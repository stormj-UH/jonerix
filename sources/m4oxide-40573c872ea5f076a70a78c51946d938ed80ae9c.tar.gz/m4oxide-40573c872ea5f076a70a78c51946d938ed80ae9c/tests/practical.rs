// Practical-corpus integration tests.
//
// These tests compare m4oxide output against a GNU m4 oracle for a selection
// of real-world-style .m4 inputs.  Each test skips automatically when the
// oracle binary is not present (same pattern as tests/oracle_basic.rs).
//
// Run with:
//   M4_ORACLE=/opt/homebrew/opt/m4/bin/m4 cargo test --test practical

use std::io::Write;
use std::process::{Command, Stdio};

fn oracle_path() -> String {
    std::env::var("M4_ORACLE").unwrap_or_else(|_| "/opt/homebrew/opt/m4/bin/m4".to_string())
}

/// Run a binary with M4OXIDE_TEST_MODE=1 and capture (exit_code, stdout, stderr).
fn run_bin(bin: &str, args: &[&str], stdin_data: &[u8]) -> (i32, Vec<u8>, Vec<u8>) {
    let mut child = Command::new(bin)
        .args(args)
        .env("M4OXIDE_TEST_MODE", "1")
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn()
        .unwrap_or_else(|e| panic!("spawn {bin}: {e}"));
    child.stdin.as_mut().unwrap().write_all(stdin_data).unwrap();
    let out = child.wait_with_output().unwrap();
    (out.status.code().unwrap_or(127), out.stdout, out.stderr)
}

/// Assert that stdin input produces identical output from m4oxide and the oracle.
fn assert_matches_oracle(input: &[u8]) {
    let oracle = oracle_path();
    if !std::path::Path::new(&oracle).exists() {
        eprintln!("skipping; oracle {oracle} not found");
        return;
    }
    let ours = env!("CARGO_BIN_EXE_m4oxide");
    let expected = run_bin(&oracle, &[], input);
    let actual = run_bin(ours, &[], input);
    assert_eq!(
        actual,
        expected,
        "m4oxide output differs from oracle for input:\n{}",
        String::from_utf8_lossy(input)
    );
}

/// Assert identical output with extra CLI args (e.g. -P).
fn assert_matches_oracle_args(input: &[u8], args: &[&str]) {
    let oracle = oracle_path();
    if !std::path::Path::new(&oracle).exists() {
        eprintln!("skipping; oracle {oracle} not found");
        return;
    }
    let ours = env!("CARGO_BIN_EXE_m4oxide");
    let expected = run_bin(&oracle, args, input);
    let actual = run_bin(ours, args, input);
    assert_eq!(
        actual,
        expected,
        "m4oxide output differs from oracle (args={args:?}) for input:\n{}",
        String::from_utf8_lossy(input)
    );
}

// ── Autoconf-style tests ──────────────────────────────────────────────────────

#[test]
fn ac_init_style_quoting() {
    assert_matches_oracle(
        b"define(`AC_INIT', \
`define(`PKG_NAME', `$1')define(`PKG_VER', `$2')')\n\
AC_INIT(`mylib', `2.0')\n\
PKG_NAME PKG_VER\n",
    );
}

#[test]
fn ac_defun_dollar_at_and_hash() {
    assert_matches_oracle(
        b"define(`F', `nargs=$# all=$@ star=$*')\n\
F(`a', `b', `c')\n",
    );
}

#[test]
fn ac_require_once_idiom() {
    assert_matches_oracle(
        b"define(`AC_REQUIRE', `ifdef(`_done_$1', `', `define(`_done_$1', `1')$1')')\n\
define(`INIT_DB', `DB_READY\n')\n\
AC_REQUIRE(`INIT_DB')\n\
AC_REQUIRE(`INIT_DB')\n",
    );
}

#[test]
fn ac_format_sprintf() {
    assert_matches_oracle(b"format(`%05d', 42)\nformat(`%x', 255)\nformat(`%-8s|', `left')\n");
}

#[test]
fn ac_prefix_builtins_flag() {
    assert_matches_oracle_args(b"m4_define(`X', `hello')\nX\n", &["-P"]);
}

// ── sendmail.cf-style tests ───────────────────────────────────────────────────

#[test]
fn sm_nested_ifelse_chain() {
    assert_matches_oracle(
        b"define(`route', `ifelse(`$1', `local', `LOCAL:$2', `$1', `relay', `RELAY:$2', `DIRECT:$2')')\n\
route(`local', `user')\nroute(`relay', `user')\nroute(`direct', `user')\n",
    );
}

#[test]
fn sm_feature_once_idiom() {
    assert_matches_oracle(
        b"define(`FEATURE', `ifdef(`_feat_$1', `', `define(`_feat_$1', 1)ENABLED:$1\n')')\n\
FEATURE(`masq')\nFEATURE(`masq')\nFEATURE(`relay')\n",
    );
}

// ── Regex / patsubst tests ────────────────────────────────────────────────────

#[test]
fn re_negated_character_class() {
    // [^A-Z0-9_] was broken before the NegClass fix
    assert_matches_oracle(b"patsubst(`my-package/name.h', `[^A-Z0-9_a-z.]', `_')\n");
    assert_matches_oracle(
        b"patsubst(translit(`my-pkg', `abcdefghijklmnopqrstuvwxyz', `ABCDEFGHIJKLMNOPQRSTUVWXYZ'), `[^A-Z0-9_]', `_')\n",
    );
}

#[test]
fn re_patsubst_backreference() {
    assert_matches_oracle(b"patsubst(`foo(a) bar foo(bb)', `foo(\\([^)]*\\))', `\\1_wrapped')\n");
}

#[test]
fn re_regexp_extraction() {
    assert_matches_oracle(
        b"regexp(`2024-01-15', `\\([0-9]*\\)-\\([0-9]*\\)-\\([0-9]*\\)', `y=\\1 m=\\2 d=\\3')\n",
    );
}

#[test]
fn re_as_tr_cpp_style() {
    // Combines translit (lowercase->uppercase) then patsubst([^A-Z0-9_] -> _)
    assert_matches_oracle(
        b"define(`AS_TR_CPP',\n\
`patsubst(translit(`$1',\n\
`abcdefghijklmnopqrstuvwxyz',\n\
`ABCDEFGHIJKLMNOPQRSTUVWXYZ'), `[^A-Z0-9_]', `_')')\n\
AS_TR_CPP(`my-package/name.h')\n\
AS_TR_CPP(`3foo bar')\n",
    );
}

// ── Divert / undivert tests ───────────────────────────────────────────────────

#[test]
fn dv_basic_defer() {
    assert_matches_oracle(b"divert(`1')DEFERRED\ndivert(`0')IMMEDIATE\nundivert(`1')\n");
}

#[test]
fn dv_discard_diversion() {
    assert_matches_oracle(b"divert(`-1')DISCARDED\ndivert(`0')VISIBLE\n");
}

// ── Eval tests ────────────────────────────────────────────────────────────────

#[test]
fn ev_bitwise_ops() {
    assert_matches_oracle(b"eval(`0xFF & 0x0F')\neval(`0xF0 | 0x0F')\neval(`1 << 8')\n");
}

#[test]
fn ev_mod_comparisons() {
    assert_matches_oracle(
        b"define(`fizz', `ifelse(eval(`$1 % 3 == 0'), `1', `Fizz', `$1')')\n\
fizz(`9')\nfizz(`7')\n",
    );
}

// ── changequote / changecom tests ─────────────────────────────────────────────

#[test]
fn cq_square_bracket_quotes() {
    assert_matches_oracle(b"changequote([[, ]])\ndefine([[X]], [[hello]])\nX\nchangequote\n");
}

#[test]
fn cc_disable_comments() {
    assert_matches_oracle(b"changecom()\n# not a comment\nchangecom(`#')\n# comment again\n");
}
