// Ghidra Java script. Run with analyzeHeadless -postScript.
// Writes private binary-analysis observations under cleanroom/private.

import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import ghidra.app.decompiler.DecompInterface;
import ghidra.app.decompiler.DecompileResults;
import ghidra.app.script.GhidraScript;
import ghidra.program.model.data.DataType;
import ghidra.program.model.listing.Data;
import ghidra.program.model.listing.Function;
import ghidra.program.model.listing.FunctionIterator;

public class GhidraExport extends GhidraScript {
    private static String safeName(String name) {
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < name.length(); i++) {
            char ch = name.charAt(i);
            if (Character.isLetterOrDigit(ch) || ch == '.' || ch == '_' || ch == '-') {
                out.append(ch);
            } else {
                out.append('_');
            }
        }
        return out.toString();
    }

    private static String oneLine(String s) {
        return s.replace("\n", "\\n").replace("\t", "\\t").replace("\r", "\\r");
    }

    @Override
    protected void run() throws Exception {
        String[] args = getScriptArgs();
        File outDir = new File(args.length > 0 ? args[0] : "/tmp/m4oxide-ghidra");
        outDir.mkdirs();

        try (PrintWriter out = new PrintWriter(new FileWriter(new File(outDir, "program.txt")))) {
            out.println("name=" + currentProgram.getName());
            out.println("language=" + currentProgram.getLanguageID());
            out.println("compiler=" + currentProgram.getCompilerSpec().getCompilerSpecID());
            out.println("image_base=" + currentProgram.getImageBase());
            out.println("min_addr=" + currentProgram.getMinAddress());
            out.println("max_addr=" + currentProgram.getMaxAddress());
        }

        List<Function> functions = new ArrayList<>();
        FunctionIterator it = currentProgram.getFunctionManager().getFunctions(true);
        while (it.hasNext()) {
            functions.add(it.next());
        }
        functions.sort(Comparator.comparing(f -> f.getEntryPoint().toString()));

        try (PrintWriter out = new PrintWriter(new FileWriter(new File(outDir, "functions.tsv")))) {
            out.println("entry\tname\tbody_size\tthunk\texternal");
            for (Function fn : functions) {
                out.printf("%s\t%s\t%d\t%s\t%s%n",
                    fn.getEntryPoint(),
                    fn.getName(),
                    fn.getBody() == null ? 0 : fn.getBody().getNumAddresses(),
                    fn.isThunk(),
                    fn.isExternal());
            }
        }

        try (PrintWriter out = new PrintWriter(new FileWriter(new File(outDir, "strings.tsv")))) {
            out.println("address\tdatatype\tvalue");
            for (Data d : currentProgram.getListing().getDefinedData(true)) {
                DataType dt = d.getDataType();
                if (dt == null || !dt.getName().toLowerCase().contains("string")) {
                    continue;
                }
                Object value = d.getValue();
                if (value == null) {
                    continue;
                }
                String text = value.toString();
                String lower = text.toLowerCase();
                if (lower.contains("m4") || lower.contains("error") || lower.contains("warning")
                        || text.contains("%") || text.contains("$")) {
                    out.printf("%s\t%s\t%s%n", d.getAddress(), dt.getName(), oneLine(text));
                }
            }
        }

        File decompDir = new File(outDir, "decompile");
        decompDir.mkdirs();
        DecompInterface ifc = new DecompInterface();
        ifc.openProgram(currentProgram);
        for (Function fn : functions) {
            if (monitor.isCancelled()) {
                break;
            }
            if (fn.isExternal() || fn.isThunk()) {
                continue;
            }
            DecompileResults res = ifc.decompileFunction(fn, 30, monitor);
            if (!res.decompileCompleted() || res.getDecompiledFunction() == null) {
                continue;
            }
            String name = fn.getEntryPoint() + "_" + safeName(fn.getName()) + ".c";
            try (PrintWriter out = new PrintWriter(new FileWriter(new File(decompDir, name)))) {
                out.print(res.getDecompiledFunction().getC());
            }
        }
    }
}
