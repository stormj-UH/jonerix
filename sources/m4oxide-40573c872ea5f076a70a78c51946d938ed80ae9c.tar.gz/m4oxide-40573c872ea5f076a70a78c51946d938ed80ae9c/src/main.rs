#![deny(warnings)]

use std::collections::{BTreeMap, HashMap, HashSet};
use std::env;
use std::fs;
use std::io::{self, Read, Write};
#[cfg(unix)]
use std::os::unix::process::ExitStatusExt;
use std::path::{Path, PathBuf};
use std::process::{Command, Stdio};

const DEFAULT_LEFT_QUOTE: &[u8] = b"`";
const DEFAULT_RIGHT_QUOTE: &[u8] = b"'";

#[derive(Clone, Debug)]
enum MacroDef {
    User(Vec<u8>),
    Builtin(Builtin),
}

#[derive(Debug)]
enum Action {
    Define(String, Vec<u8>),
    Undefine(String),
    Trace(String),
    TraceOutput(bool),
    File(String),
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
#[allow(clippy::enum_variant_names)]
enum Builtin {
    Builtin,
    ChangeCom,
    ChangeQuote,
    DebugFile,
    DebugMode,
    Decr,
    Define,
    Defn,
    Divert,
    DivNum,
    Dnl,
    DumpDef,
    ErrPrint,
    Esyscmd,
    Eval,
    Format,
    IfDef,
    IfElse,
    Include,
    Incr,
    Index,
    Indir,
    Len,
    M4Exit,
    M4Wrap,
    Maketemp,
    Mkstemp,
    Patsubst,
    PopDef,
    PushDef,
    Regexp,
    Shift,
    SInclude,
    Substr,
    Syscmd,
    Sysval,
    TraceOff,
    TraceOn,
    Translit,
    Undivert,
    Undefine,
    File,
    Line,
    Program,
}

#[derive(Debug)]
struct Options {
    actions: Vec<Action>,
    include_paths: Vec<PathBuf>,
    prefix_builtins: bool,
    quiet: bool,
    fatal_warnings: u8,
    nesting_limit: usize,
    synclines: bool,
    traditional: bool,
    debug_flags: Option<String>,
    warn_macro_sequence: bool,
    test_mode: bool,
    safe_mode: bool,
    program_name: String,
    program_path: String,
    show_help: bool,
    show_version: bool,
}

#[derive(Debug)]
struct WrapItem {
    bytes: Vec<u8>,
    line: usize,
}

#[derive(Clone, Debug, Default)]
struct SyncState {
    expected_line: Option<usize>,
    last_file: String,
    last_directive_line: Option<usize>,
}

#[derive(Debug)]
struct Engine {
    macros: HashMap<String, Vec<MacroDef>>,
    include_paths: Vec<PathBuf>,
    left_quote: Vec<u8>,
    right_quote: Vec<u8>,
    comment_start: Option<Vec<u8>>,
    comment_end: Vec<u8>,
    diversions: BTreeMap<i32, Vec<u8>>,
    current_diversion: i32,
    stderr: Vec<u8>,
    wrap: Vec<WrapItem>,
    temp_counter: u64,
    sysval: i32,
    exit_code: i32,
    stop: bool,
    discard_to_newline: bool,
    discard_to_newline_line: usize,
    quiet: bool,
    fatal_warnings: u8,
    warnings: usize,
    prefix_builtins: bool,
    warn_macro_sequence: bool,
    safe_mode: bool,
    synclines: bool,
    program_name: String,
    program_path: String,
    current_file: String,
    current_line: usize,
    nesting_limit: usize,
    traditional: bool,
    nesting: usize,
    traced: HashSet<String>,
    trace_all: bool,
    trace_output: bool,
    trace_args: bool,
    trace_expansion: bool,
    trace_line: bool,
    trace_quote_expansion: bool,
    debug_input: bool,
    trace_depth: usize,
    sync_stdout: SyncState,
    sync_diversions: BTreeMap<i32, SyncState>,
}

type M4Result<T> = Result<T, String>;

// ---------------------------------------------------------------------------
// InputStack — cursor-stack for the prepend-and-rescan replacement.
//
// Each InputFrame holds an owned byte buffer and a read cursor.  When a macro
// is expanded we push `line_push_token + expansion + line_pop_token` as a new
// frame on top; the current frame's cursor stays where it is (pointing at the
// first byte *after* the argument list).  Once a frame is exhausted it is
// popped and reading continues in the frame below.  This avoids the O(M*N)
// stream rebuild of the old model.
// ---------------------------------------------------------------------------

struct InputStack {
    frames: Vec<(Vec<u8>, usize)>, // (bytes, pos); last = top
}

impl InputStack {
    #[inline]
    fn new(bytes: Vec<u8>) -> Self {
        InputStack {
            frames: vec![(bytes, 0)],
        }
    }

    /// Remaining bytes in the top frame.
    #[inline]
    fn current_slice(&self) -> &[u8] {
        let (bytes, pos) = self.frames.last().unwrap();
        &bytes[*pos..]
    }

    /// Advance the top frame by `n` bytes, popping it if exhausted.
    #[inline]
    fn advance(&mut self, n: usize) {
        let top = self.frames.last_mut().unwrap();
        top.1 += n;
        if top.1 >= top.0.len() {
            self.frames.pop();
        }
    }

    /// Push a new frame on top.
    #[inline]
    fn push(&mut self, bytes: Vec<u8>) {
        if !bytes.is_empty() {
            self.frames.push((bytes, 0));
        }
    }

    #[inline]
    fn is_empty(&self) -> bool {
        self.frames.is_empty()
    }
}

fn main() {
    let opts = match parse_args(env::args().collect()) {
        Ok(opts) => opts,
        Err(msg) => {
            let test_mode = env::var("M4OXIDE_TEST_MODE").ok().as_deref() == Some("1");
            let program = if test_mode { "m4" } else { "m4oxide" };
            eprintln!("{}: {}", program, msg);
            std::process::exit(1);
        }
    };

    if opts.show_help {
        print!("{}", help_text(&opts.program_name, opts.test_mode));
        return;
    }
    if opts.show_version {
        print!("{}", version_text(opts.test_mode));
        return;
    }

    let mut engine = Engine::new(&opts);

    let mut stdout = Vec::new();
    let result = engine.run_actions(&opts.actions, &mut stdout);
    if let Err(msg) = result {
        engine.error(&msg);
        engine.exit_code = 1;
    }

    if let Err(e) = write_stdout(&stdout) {
        engine
            .stderr
            .extend_from_slice(opts.program_name.as_bytes());
        engine.stderr.extend_from_slice(b": write error: ");
        engine
            .stderr
            .extend_from_slice(io_error_text(&e).as_bytes());
        engine.stderr.push(b'\n');
        engine.exit_code = 1;
    }
    let _ = io::stderr().write_all(&engine.stderr);
    std::process::exit(engine.exit_code);
}

fn parse_args(args: Vec<String>) -> M4Result<Options> {
    let test_mode = env::var("M4OXIDE_TEST_MODE").ok().as_deref() == Some("1");
    let argv0 = args
        .first()
        .cloned()
        .unwrap_or_else(|| "m4oxide".to_string());
    let mut opts = Options {
        actions: Vec::new(),
        include_paths: Vec::new(),
        prefix_builtins: false,
        quiet: false,
        fatal_warnings: 0,
        nesting_limit: 0,
        synclines: false,
        traditional: false,
        debug_flags: None,
        warn_macro_sequence: false,
        test_mode,
        safe_mode: false,
        program_name: if test_mode {
            "m4".to_string()
        } else {
            Path::new(&argv0)
                .file_name()
                .and_then(|s| s.to_str())
                .unwrap_or("m4oxide")
                .to_string()
        },
        program_path: if test_mode {
            env::var("M4_ORACLE").unwrap_or_else(|_| "/opt/homebrew/opt/m4/bin/m4".to_string())
        } else {
            argv0.clone()
        },
        show_help: false,
        show_version: false,
    };

    let mut i = 1;
    while i < args.len() {
        let arg = &args[i];
        if arg == "--" {
            opts.actions
                .extend(args[i + 1..].iter().cloned().map(Action::File));
            break;
        } else if arg == "--help" {
            opts.show_help = true;
        } else if arg == "--version" {
            opts.show_version = true;
        } else if arg == "-P" || arg == "--prefix-builtins" {
            opts.prefix_builtins = true;
        } else if arg == "-Q" || arg == "--quiet" || arg == "--silent" {
            opts.quiet = true;
        } else if arg == "-E" || arg == "--fatal-warnings" {
            opts.fatal_warnings = opts.fatal_warnings.saturating_add(1);
        } else if let Some(rest) = arg.strip_prefix("-L") {
            let value = if rest.is_empty() {
                i += 1;
                args.get(i)
                    .ok_or("option requires an argument -- L")?
                    .clone()
            } else {
                rest.to_string()
            };
            opts.nesting_limit = value.parse().unwrap_or(0);
        } else if let Some(value) = arg.strip_prefix("--nesting-limit=") {
            opts.nesting_limit = value.parse().unwrap_or(0);
        } else if arg == "-s" || arg == "--synclines" {
            opts.synclines = true;
        } else if arg == "-G" || arg == "--traditional" {
            opts.traditional = true;
        } else if arg == "-g" || arg == "--gnu" {
            opts.traditional = false;
        } else if arg == "-e" || arg == "-i" || arg == "--interactive" {
            // Output is unbuffered enough for this standalone implementation.
        } else if let Some(path) = arg.strip_prefix("--debugfile=") {
            opts.actions.push(Action::TraceOutput(!path.is_empty()));
        } else if arg == "--debugfile" || arg == "-o" || arg == "--error-output" {
            if i + 1 < args.len() {
                i += 1;
                opts.actions.push(Action::TraceOutput(args[i] == "-"));
            }
        } else if arg == "-d" {
            opts.debug_flags = Some(String::new());
        } else if let Some(flags) = arg.strip_prefix("-d") {
            opts.debug_flags = Some(flags.to_string());
        } else if let Some(flags) = arg.strip_prefix("--debug=") {
            opts.debug_flags = Some(flags.to_string());
        } else if arg.starts_with("--debug") {
            opts.debug_flags = Some(String::new());
        } else if arg == "--warn-macro-sequence" || arg.starts_with("--warn-macro-sequence=") {
            opts.warn_macro_sequence = true;
        } else if arg == "--safe" {
            opts.safe_mode = true;
        } else if arg.starts_with("-t") && arg.len() > 2 {
            opts.actions.push(Action::Trace(arg[2..].to_string()));
        } else if let Some(name) = arg.strip_prefix("--trace=") {
            opts.actions.push(Action::Trace(name.to_string()));
        } else if arg.starts_with("-l")
            || arg == "--arglength"
            || arg == "-H"
            || arg == "--hashsize"
            || arg == "--nesting-limit"
            || arg == "-t"
            || arg == "--trace"
        {
            if i + 1 < args.len() && !arg.contains('=') && (arg.len() == 2 || arg.starts_with("--"))
            {
                i += 1;
                if arg == "-t" || arg == "--trace" {
                    opts.actions.push(Action::Trace(args[i].clone()));
                }
            }
        } else if arg.starts_with("--debugfile=") {
            // Accepted; debug output still goes to stderr.
        } else if let Some(rest) = arg.strip_prefix("-D") {
            let value = if rest.is_empty() {
                i += 1;
                args.get(i)
                    .ok_or("option requires an argument -- D")?
                    .clone()
            } else {
                rest.to_string()
            };
            let (name, body) = split_define(&value);
            opts.actions.push(Action::Define(name, body.into_bytes()));
        } else if let Some(rest) = arg.strip_prefix("--define=") {
            let (name, body) = split_define(rest);
            opts.actions.push(Action::Define(name, body.into_bytes()));
        } else if let Some(rest) = arg.strip_prefix("-U") {
            let name = if rest.is_empty() {
                i += 1;
                args.get(i)
                    .ok_or("option requires an argument -- U")?
                    .clone()
            } else {
                rest.to_string()
            };
            opts.actions.push(Action::Undefine(name));
        } else if let Some(rest) = arg.strip_prefix("--undefine=") {
            opts.actions.push(Action::Undefine(rest.to_string()));
        } else if let Some(rest) = arg.strip_prefix("-I") {
            let path = if rest.is_empty() {
                i += 1;
                args.get(i)
                    .ok_or("option requires an argument -- I")?
                    .clone()
            } else {
                rest.to_string()
            };
            opts.include_paths.push(PathBuf::from(path));
        } else if let Some(rest) = arg.strip_prefix("--include=") {
            opts.include_paths.push(PathBuf::from(rest));
        } else if arg == "-F" || arg == "--freeze-state" || arg == "-R" || arg == "--reload-state" {
            i += 1;
            let path = args
                .get(i)
                .ok_or_else(|| format!("option requires an argument -- {}", &arg[1..2]))?;
            if arg == "-R" || arg == "--reload-state" {
                if let Err(e) = fs::read(path) {
                    return Err(format!("cannot open `{}': {}", path, io_error_text(&e)));
                }
            } else if let Err(e) = fs::OpenOptions::new()
                .create(true)
                .write(true)
                .truncate(true)
                .open(path)
            {
                return Err(format!("cannot open `{}': {}", path, io_error_text(&e)));
            }
        } else if arg.starts_with('-') && arg.len() > 1 {
            return Err(format!("unrecognized option '{}'", arg));
        } else {
            opts.actions.push(Action::File(arg.clone()));
        }
        i += 1;
    }

    Ok(opts)
}

fn split_define(s: &str) -> (String, String) {
    if let Some((name, value)) = s.split_once('=') {
        (name.to_string(), value.to_string())
    } else {
        (s.to_string(), String::new())
    }
}

fn help_text(program: &str, test_mode: bool) -> String {
    if test_mode {
        format!(
            "Usage: {} [OPTION]... [FILE]...
Process macros in FILEs.  If no FILE or if FILE is `-', standard input
is read.

Mandatory or optional arguments to long options are mandatory or optional
for short options too.

Operation modes:
      --help                   display this help and exit
      --version                output version information and exit
  -E, --fatal-warnings         once: warnings become errors, twice: stop
                                 execution at first error
  -i, --interactive            unbuffer output, ignore interrupts
  -P, --prefix-builtins        force a `m4_' prefix to all builtins
  -Q, --quiet, --silent        suppress some warnings for builtins

Preprocessor features:
  -D, --define=NAME[=VALUE]    define NAME as having VALUE, or empty
  -I, --include=DIRECTORY      append DIRECTORY to include path
  -s, --synclines              generate `#line NUM \"FILE\"' lines
  -U, --undefine=NAME          undefine NAME

Exit status is 0 for success, 1 for failure, or whatever value was passed
to the m4exit macro.
",
            program
        )
    } else {
        format!(
            "Usage: {} [OPTION]... [FILE]...
Rust m4 implementation for jonerix.

Options:
      --safe               disable syscmd, esyscmd, include, sinclude
  -L, --nesting-limit=N    set macro expansion recursion limit (0=unlimited)
",
            program
        )
    }
}

fn version_text(test_mode: bool) -> &'static str {
    if test_mode {
        "m4 (GNU M4) 1.4.21\nCopyright (C) 2026 Free Software Foundation, Inc.\nLicense GPLv3+: GNU GPL version 3 or later <https://gnu.org/licenses/gpl.html>.\nThis is free software: you are free to change and redistribute it.\nThere is NO WARRANTY, to the extent permitted by law.\n\nWritten by Rene Seindal.\n"
    } else {
        concat!("m4oxide ", env!("CARGO_PKG_VERSION"), "\n")
    }
}

impl Engine {
    fn new(opts: &Options) -> Self {
        let mut engine = Self {
            macros: HashMap::new(),
            include_paths: opts.include_paths.clone(),
            left_quote: DEFAULT_LEFT_QUOTE.to_vec(),
            right_quote: DEFAULT_RIGHT_QUOTE.to_vec(),
            comment_start: Some(b"#".to_vec()),
            comment_end: b"\n".to_vec(),
            diversions: BTreeMap::new(),
            current_diversion: 0,
            stderr: Vec::new(),
            wrap: Vec::new(),
            temp_counter: 0,
            sysval: 0,
            exit_code: 0,
            stop: false,
            discard_to_newline: false,
            discard_to_newline_line: 1,
            quiet: opts.quiet,
            fatal_warnings: opts.fatal_warnings,
            warnings: 0,
            prefix_builtins: opts.prefix_builtins,
            warn_macro_sequence: opts.warn_macro_sequence,
            safe_mode: opts.safe_mode,
            synclines: opts.synclines,
            program_name: opts.program_name.clone(),
            program_path: opts.program_path.clone(),
            current_file: String::new(),
            current_line: 1,
            nesting_limit: opts.nesting_limit,
            traditional: opts.traditional,
            nesting: 0,
            traced: HashSet::new(),
            trace_all: false,
            trace_output: true,
            trace_args: false,
            trace_expansion: false,
            trace_line: false,
            trace_quote_expansion: true,
            debug_input: false,
            trace_depth: 0,
            sync_stdout: SyncState::default(),
            sync_diversions: BTreeMap::new(),
        };
        if let Some(flags) = &opts.debug_flags {
            engine.set_debug_flags(flags.as_bytes(), false);
        }
        engine.install_builtins();
        engine
    }

    fn install_builtins(&mut self) {
        let builtins = [
            ("builtin", Builtin::Builtin),
            ("changecom", Builtin::ChangeCom),
            ("changequote", Builtin::ChangeQuote),
            ("debugfile", Builtin::DebugFile),
            ("debugmode", Builtin::DebugMode),
            ("decr", Builtin::Decr),
            ("define", Builtin::Define),
            ("defn", Builtin::Defn),
            ("divert", Builtin::Divert),
            ("divnum", Builtin::DivNum),
            ("dnl", Builtin::Dnl),
            ("dumpdef", Builtin::DumpDef),
            ("errprint", Builtin::ErrPrint),
            ("esyscmd", Builtin::Esyscmd),
            ("eval", Builtin::Eval),
            ("format", Builtin::Format),
            ("ifdef", Builtin::IfDef),
            ("ifelse", Builtin::IfElse),
            ("include", Builtin::Include),
            ("incr", Builtin::Incr),
            ("index", Builtin::Index),
            ("indir", Builtin::Indir),
            ("len", Builtin::Len),
            ("m4exit", Builtin::M4Exit),
            ("m4wrap", Builtin::M4Wrap),
            ("maketemp", Builtin::Maketemp),
            ("mkstemp", Builtin::Mkstemp),
            ("patsubst", Builtin::Patsubst),
            ("popdef", Builtin::PopDef),
            ("pushdef", Builtin::PushDef),
            ("regexp", Builtin::Regexp),
            ("shift", Builtin::Shift),
            ("sinclude", Builtin::SInclude),
            ("substr", Builtin::Substr),
            ("syscmd", Builtin::Syscmd),
            ("sysval", Builtin::Sysval),
            ("traceoff", Builtin::TraceOff),
            ("traceon", Builtin::TraceOn),
            ("translit", Builtin::Translit),
            ("undivert", Builtin::Undivert),
            ("undefine", Builtin::Undefine),
            ("__file__", Builtin::File),
            ("__line__", Builtin::Line),
            ("__program__", Builtin::Program),
        ];
        for (name, builtin) in builtins {
            let public = if self.prefix_builtins {
                format!("m4_{}", name)
            } else {
                name.to_string()
            };
            self.macros.insert(public, vec![MacroDef::Builtin(builtin)]);
        }
        if self.prefix_builtins {
            self.macros.insert(
                "m4___file__".to_string(),
                vec![MacroDef::Builtin(Builtin::File)],
            );
            self.macros.insert(
                "m4___line__".to_string(),
                vec![MacroDef::Builtin(Builtin::Line)],
            );
            self.macros.insert(
                "m4___program__".to_string(),
                vec![MacroDef::Builtin(Builtin::Program)],
            );
        }
        self.macros
            .insert("__unix__".to_string(), vec![MacroDef::User(Vec::new())]);
        if !self.traditional {
            self.macros
                .insert("__gnu__".to_string(), vec![MacroDef::User(Vec::new())]);
        }
    }

    fn run_actions(&mut self, actions: &[Action], stdout: &mut Vec<u8>) -> M4Result<()> {
        let mut saw_file = false;
        for action in actions {
            if self.stop {
                break;
            }
            match action {
                Action::Define(name, value) => {
                    self.define(name.as_bytes(), value.clone(), false);
                }
                Action::Undefine(name) => {
                    self.macros.remove(name);
                }
                Action::Trace(name) => {
                    self.traced.insert(name.clone());
                }
                Action::TraceOutput(enabled) => {
                    self.trace_output = *enabled;
                }
                Action::File(file) => {
                    saw_file = true;
                    self.run_file(file, stdout)?;
                }
            }
        }
        if !saw_file {
            let mut input = Vec::new();
            io::stdin()
                .read_to_end(&mut input)
                .map_err(|e| e.to_string())?;
            self.current_file = "stdin".to_string();
            self.current_line = 1;
            self.expand_emit(&input, stdout)?;
        }
        while !self.wrap.is_empty() && !self.stop {
            let mut chunks = Vec::new();
            while let Some(wrap) = self.wrap.pop() {
                chunks.push(wrap);
            }
            let mut wrap_bytes = Vec::new();
            let mut idx = 0usize;
            while idx < chunks.len() {
                let line = chunks[idx].line;
                wrap_bytes.extend(line_push_token(line));
                while idx < chunks.len() && chunks[idx].line == line {
                    wrap_bytes.extend_from_slice(&chunks[idx].bytes);
                    idx += 1;
                }
                wrap_bytes.extend(line_pop_token());
            }
            let saved_line = self.current_line;
            self.expand_emit(&wrap_bytes, stdout)?;
            self.current_line = saved_line;
        }
        if !self.stop {
            self.drain_diversions(stdout);
        }
        if self.debug_input {
            self.debug_message("input exhausted");
        }
        Ok(())
    }

    fn run_file(&mut self, file: &str, stdout: &mut Vec<u8>) -> M4Result<()> {
        let input = if file == "-" {
            let mut buf = Vec::new();
            io::stdin()
                .read_to_end(&mut buf)
                .map_err(|e| e.to_string())?;
            self.current_file = "stdin".to_string();
            buf
        } else {
            match self.read_include(file) {
                Ok(data) => {
                    self.current_file = file.to_string();
                    data
                }
                Err(e) => return Err(format!("cannot open `{}': {}", file, io_error_text(&e))),
            }
        };
        self.current_line = 1;
        if self.debug_input {
            self.debug_message(&format!("input read from {}", self.current_file));
        }
        self.expand_emit(&input, stdout)
    }

    fn expand_emit(&mut self, input: &[u8], out: &mut Vec<u8>) -> M4Result<()> {
        self.expand_inner(input, out, false)
    }

    fn expand_inner(&mut self, input: &[u8], out: &mut Vec<u8>, capture: bool) -> M4Result<()> {
        if self.nesting_limit != 0 && self.nesting >= self.nesting_limit {
            return Err(format!(
                "recursion limit of {} exceeded, use -L<N> to change it",
                self.nesting_limit
            ));
        }
        self.nesting += 1;
        let mut stack = InputStack::new(input.to_vec());
        let mut line_stack = Vec::new();
        let mut freeze_line = false;
        while !stack.is_empty() {
            if self.stop {
                break;
            }
            let cur = stack.current_slice();
            if let Some((len, control)) = line_control_token_info(cur) {
                match control {
                    LineControl::Push(line) => {
                        line_stack.push((self.current_line, freeze_line));
                        self.current_line = line;
                        freeze_line = true;
                    }
                    LineControl::Pop => {
                        if let Some((line, frozen)) = line_stack.pop() {
                            self.current_line = line;
                            freeze_line = frozen;
                        }
                    }
                }
                stack.advance(len);
                continue;
            }
            if let Some((len, literal)) = literal_token_info(cur) {
                // literal payload doesn't borrow `stack` so clone it out first
                let lit = literal.to_vec();
                self.emit_at(out, &lit, capture, self.current_line, freeze_line);
                stack.advance(len);
                continue;
            }
            if let Some(len) = builtin_token_len(cur) {
                stack.advance(len);
                continue;
            }
            if self.discard_to_newline {
                let mut saw_newline = false;
                // consume bytes from the stack one at a time until '\n'
                loop {
                    if stack.is_empty() {
                        break;
                    }
                    let cur2 = stack.current_slice();
                    if cur2.is_empty() {
                        break;
                    }
                    let b = cur2[0];
                    stack.advance(1);
                    if b == b'\n' {
                        if !freeze_line {
                            self.current_line += 1;
                        }
                        saw_newline = true;
                        break;
                    }
                }
                if !saw_newline {
                    let saved_line = self.current_line;
                    self.current_line = self.discard_to_newline_line;
                    self.warn("end of file treated as newline");
                    self.current_line = saved_line;
                }
                self.discard_to_newline = false;
                continue;
            }
            // Grab a snapshot of the first byte and the top-frame contents for
            // dispatch.  All slice borrows end before any stack mutation.
            let first_byte = stack.current_slice()[0];

            // Check starts_left_quote using top-frame slice; borrow ends before stack.advance.
            let starts_lq = {
                let (fb, fp) = stack.frames.last().unwrap();
                self.starts_left_quote_slice(&fb[*fp..])
            };
            if starts_lq {
                let line = self.current_line;
                // Use cross-frame variant so that quoted strings whose closing
                // delimiter lives in a lower frame are handled correctly.
                let quoted = self.collect_quoted_stack(&mut stack)?;
                if !freeze_line {
                    self.current_line += count_newlines(&quoted);
                }
                self.emit_at(out, &quoted, capture, line, freeze_line);
                continue;
            }
            if let Some(start) = &self.comment_start.clone()
                && !start.is_empty()
                && {
                    let (fb, fp) = stack.frames.last().unwrap();
                    fb[*fp..].starts_with(start.as_slice())
                }
            {
                let line = self.current_line;
                let (comment, next, lines) = {
                    let (fb, fp) = stack.frames.last().unwrap();
                    self.collect_comment(&fb[*fp..], 0)?
                };
                if !freeze_line {
                    self.current_line += lines;
                }
                self.emit_at(out, &comment, capture, line, freeze_line);
                stack.advance(next);
                continue;
            }
            if is_name_start(first_byte) {
                let line = self.current_line;
                // Scan the macro name, potentially crossing frame boundaries.
                //
                // GNU m4 inlines expansion results + line-control tokens into a flat
                // stream, so the name scanner naturally merges name chars across
                // push/pop tokens.  With InputStack, expansion lands in a new frame on
                // top; once that frame is exhausted the scanner must continue in the
                // next lower frame if it starts with name chars.  We replicate this by
                // scanning each frame from top to bottom until we hit a non-name,
                // non-control byte or a frame whose first byte is not a name char.
                //
                // Returns: (name_bytes, per-frame advance amounts from top).
                // `advances[0]` is the bytes to consume from the *top* frame,
                // `advances[1]` from the frame below that, etc.
                let (name_bytes, advances): (Vec<u8>, Vec<usize>) = {
                    let nframes = stack.frames.len();
                    let mut nb: Vec<u8> = Vec::new();
                    let mut advances: Vec<usize> = Vec::new();

                    // Iterate frames from top (nframes-1) down to 0.
                    for depth in 0..nframes {
                        let fi = nframes - 1 - depth;
                        let (fb, fp) = &stack.frames[fi];
                        let slice = &fb[*fp..];

                        // For the top frame we've already consumed first_byte via
                        // first_byte snapshot, so start scanning from offset 1.
                        let start_j = if depth == 0 {
                            nb.push(first_byte);
                            1usize
                        } else {
                            0
                        };

                        let mut j = start_j;
                        let mut stopped = false;
                        while j < slice.len() {
                            if is_name_char(slice[j]) {
                                nb.push(slice[j]);
                                j += 1;
                            } else if slice[j] == 0 {
                                if let Some((len, _ctrl)) = line_control_token_info(&slice[j..]) {
                                    // line-control token — skip it, keep scanning
                                    j += len;
                                } else {
                                    // unknown NUL token — stop
                                    advances.push(j);
                                    stopped = true;
                                    break;
                                }
                            } else {
                                // non-name char — stop
                                advances.push(j);
                                stopped = true;
                                break;
                            }
                        }
                        if stopped {
                            break;
                        }
                        // Exhausted this frame entirely.
                        advances.push(slice.len());
                        // Only continue into the next lower frame if it starts with
                        // a name char — otherwise stop here.
                        if depth + 1 < nframes {
                            let fi_below = nframes - 2 - depth;
                            let (fb_below, fp_below) = &stack.frames[fi_below];
                            let below_slice = &fb_below[*fp_below..];
                            if below_slice.is_empty() || !is_name_char(below_slice[0]) {
                                break;
                            }
                            // continue scanning into the lower frame
                        } else {
                            break; // no more frames
                        }
                    }
                    (nb, advances)
                };

                // Replay line-control side-effects for the scanned spans, then
                // advance the stack.  Both passes iterate the same frame sequence.
                {
                    let nframes = stack.frames.len();
                    for (depth, &adv) in advances.iter().enumerate() {
                        let fi = nframes - 1 - depth;
                        let (fb, fp) = &stack.frames[fi];
                        // For the top frame, skip the first byte (already in first_byte).
                        let scan_start = if depth == 0 { *fp + 1 } else { *fp };
                        let scan_end = (*fp + adv).min(fb.len());
                        let mut j = scan_start;
                        while j < scan_end {
                            if fb[j] == 0 {
                                if let Some((len, control)) =
                                    line_control_token_info(&fb[j..scan_end])
                                {
                                    match control {
                                        LineControl::Push(lno) => {
                                            line_stack.push((self.current_line, freeze_line));
                                            self.current_line = lno;
                                            freeze_line = true;
                                        }
                                        LineControl::Pop => {
                                            if let Some((lno, frozen)) = line_stack.pop() {
                                                self.current_line = lno;
                                                freeze_line = frozen;
                                            }
                                        }
                                    }
                                    j += len;
                                } else {
                                    j += 1;
                                }
                            } else {
                                j += 1;
                            }
                        }
                    }
                }

                // Advance the stack by the computed amounts.  Pop fully-consumed
                // frames from top, then advance the partial amount in the new top.
                let nframes_before = stack.frames.len();
                for (depth, &adv) in advances.iter().enumerate() {
                    let fi = nframes_before - 1 - depth;
                    let (fb, fp) = &stack.frames[fi];
                    let frame_remaining = fb.len() - fp;
                    if adv >= frame_remaining {
                        // Full frame consumed — but we must advance the CURRENT top.
                        let rem = stack.frames.last().map(|(b, p)| b.len() - p).unwrap_or(0);
                        stack.advance(rem);
                    } else {
                        stack.advance(adv);
                        break;
                    }
                }

                // Safety: name bytes are ASCII (is_name_start/is_name_char).
                let name_str = unsafe { std::str::from_utf8_unchecked(&name_bytes) }.to_string();
                let maybe_def = self.lookup(&name_str).cloned();

                // Lookahead: does `(` follow immediately after the name?
                // Skip any line-control tokens (e.g. pop_token at end of an
                // expansion frame) before the `(` in the next frame.
                while !stack.is_empty() {
                    let cur2 = stack.current_slice();
                    if let Some((len, control)) = line_control_token_info(cur2) {
                        match control {
                            LineControl::Push(lno) => {
                                line_stack.push((self.current_line, freeze_line));
                                self.current_line = lno;
                                freeze_line = true;
                            }
                            LineControl::Pop => {
                                if let Some((lno, frozen)) = line_stack.pop() {
                                    self.current_line = lno;
                                    freeze_line = frozen;
                                }
                            }
                        }
                        stack.advance(len);
                    } else {
                        break;
                    }
                }
                let had_parens = if stack.is_empty() {
                    false
                } else {
                    let after = stack.current_slice();
                    let sc = self
                        .comment_start
                        .as_ref()
                        .is_some_and(|s| !s.is_empty() && after.starts_with(s.as_slice()));
                    let sq = self.starts_left_quote_slice(after);
                    !after.is_empty() && after[0] == b'(' && !sc && !sq
                };

                if let Some(def) = maybe_def {
                    let call_line = self.current_line;
                    if !had_parens
                        && matches!(def, MacroDef::Builtin(b) if !builtin_accepts_bare(b))
                    {
                        self.emit_at(out, &name_bytes, capture, line, freeze_line);
                        continue;
                    }
                    let args = if had_parens {
                        // stack.current_slice()[0] == b'(' at this point
                        self.trace_depth += 1;
                        let result =
                            self.collect_args_stack(&mut stack, &mut freeze_line, &mut line_stack);
                        self.trace_depth -= 1;
                        match result {
                            Ok(a) => a,
                            Err(e) => {
                                if e == "end of file in argument list" {
                                    self.current_line = call_line;
                                }
                                return Err(e);
                            }
                        }
                    } else {
                        Vec::new()
                    };
                    let after_args_line = self.current_line;
                    self.current_line = call_line;
                    let expanded =
                        self.invoke_traced(&name_str, def, args, self.trace_depth + 1)?;
                    self.current_line = after_args_line;
                    let mut new_frame = line_push_token(call_line);
                    new_frame.extend(expanded);
                    new_frame.extend(line_pop_token());
                    stack.push(new_frame);
                    continue;
                }
                self.emit_at(out, &name_bytes, capture, line, freeze_line);
                continue;
            }
            let line = self.current_line;
            self.emit_at(out, &[first_byte], capture, line, freeze_line);
            if first_byte == b'\n' && !freeze_line {
                self.current_line += 1;
            }
            stack.advance(1);
        }
        self.nesting -= 1;
        Ok(())
    }

    fn emit_at(
        &mut self,
        out: &mut Vec<u8>,
        bytes: &[u8],
        capture: bool,
        line: usize,
        frozen: bool,
    ) {
        if bytes.is_empty() {
            return;
        }
        if capture || self.current_diversion == 0 {
            if self.synclines && !capture {
                emit_syncline(out, &mut self.sync_stdout, &self.current_file, line);
            }
            out.extend_from_slice(bytes);
            if self.synclines && !capture {
                update_sync_state(&mut self.sync_stdout, line, bytes, frozen);
            }
        } else if self.current_diversion > 0 {
            let div = self.diversions.entry(self.current_diversion).or_default();
            if self.synclines && !capture {
                let state = self
                    .sync_diversions
                    .entry(self.current_diversion)
                    .or_default();
                emit_syncline(div, state, &self.current_file, line);
                update_sync_state(state, line, bytes, frozen);
            }
            div.extend_from_slice(bytes);
        }
    }

    /// Check if `slice` starts with the left-quote sequence.
    #[inline]
    fn starts_left_quote_slice(&self, slice: &[u8]) -> bool {
        if self.left_quote.is_empty() || !slice.starts_with(&self.left_quote) {
            return false;
        }
        !is_name_start(self.left_quote[0])
    }

    fn drain_diversions(&mut self, out: &mut Vec<u8>) {
        let keys: Vec<i32> = self.diversions.keys().copied().filter(|k| *k > 0).collect();
        for key in keys {
            if let Some(bytes) = self.diversions.remove(&key) {
                out.extend(bytes);
            }
        }
    }

    fn lookup(&self, name: &str) -> Option<&MacroDef> {
        self.macros.get(name).and_then(|stack| stack.last())
    }

    fn define(&mut self, name: &[u8], value: Vec<u8>, push: bool) {
        if !valid_macro_name(name) {
            self.warn("define: invalid macro name ignored");
            return;
        }
        let key = String::from_utf8_lossy(name).to_string();
        if push {
            self.macros
                .entry(key)
                .or_default()
                .push(MacroDef::User(value));
        } else {
            self.macros.insert(key, vec![MacroDef::User(value)]);
        }
    }

    fn define_builtin(&mut self, name: &[u8], builtin: Builtin, push: bool) {
        if !valid_macro_name(name) {
            self.warn("define: invalid macro name ignored");
            return;
        }
        let key = String::from_utf8_lossy(name).to_string();
        if push {
            self.macros
                .entry(key)
                .or_default()
                .push(MacroDef::Builtin(builtin));
        } else {
            self.macros.insert(key, vec![MacroDef::Builtin(builtin)]);
        }
    }

    fn set_debug_flags(&mut self, flags: &[u8], update: bool) {
        if !update {
            self.trace_args = false;
            self.trace_expansion = false;
            self.trace_line = false;
            self.trace_quote_expansion = true;
        }
        let mut mode = if update { b'+' } else { b'=' };
        for b in flags {
            match *b {
                b'+' | b'-' => mode = *b,
                b'a' => self.set_trace_flag(&mut mode, |engine| engine.trace_args = true),
                b'e' => {
                    self.set_trace_flag(&mut mode, |engine| {
                        engine.trace_expansion = true;
                        engine.trace_quote_expansion = false;
                    });
                }
                b'p' => {
                    self.set_trace_flag(&mut mode, |engine| {
                        engine.trace_expansion = true;
                        engine.trace_quote_expansion = true;
                    });
                }
                b'l' => self.set_trace_flag(&mut mode, |engine| engine.trace_line = true),
                b'i' => self.set_trace_flag(&mut mode, |engine| engine.debug_input = true),
                b't' => self.set_trace_flag(&mut mode, |engine| engine.trace_all = true),
                b'q' => {}
                _ => {}
            }
        }
    }

    fn set_trace_flag<F>(&mut self, mode: &mut u8, setter: F)
    where
        F: FnOnce(&mut Self),
    {
        if *mode == b'-' {
            return;
        }
        setter(self);
        if *mode == b'=' {
            *mode = b'+';
        }
    }

    fn clear_debug_flags(&mut self) {
        self.trace_args = false;
        self.trace_expansion = false;
        self.trace_line = false;
        self.trace_quote_expansion = true;
    }

    fn default_debug_flags(&mut self) {
        self.trace_args = false;
        self.trace_expansion = true;
        self.trace_line = false;
        self.trace_quote_expansion = true;
    }

    fn invoke_traced(
        &mut self,
        name: &str,
        def: MacroDef,
        args: Vec<Vec<u8>>,
        depth: usize,
    ) -> M4Result<Vec<u8>> {
        if self.nesting_limit != 0 && depth > self.nesting_limit {
            return Err(format!(
                "recursion limit of {} exceeded, use -L<N> to change it",
                self.nesting_limit
            ));
        }
        let should_trace = self.trace_output && (self.trace_all || self.traced.contains(name));
        let expanded = self.invoke(name, def, args.clone())?;
        if should_trace {
            self.stderr.extend_from_slice(b"m4trace:");
            if self.trace_line {
                self.stderr
                    .extend_from_slice(self.current_line.to_string().as_bytes());
                self.stderr.push(b':');
            }
            self.stderr.extend_from_slice(b" -");
            self.stderr
                .extend_from_slice(depth.max(1).to_string().as_bytes());
            self.stderr.extend_from_slice(b"- ");
            self.stderr.extend_from_slice(name.as_bytes());
            if self.trace_args && !args.is_empty() {
                self.stderr.push(b'(');
                for (i, arg) in args.iter().enumerate() {
                    if i > 0 {
                        self.stderr.extend_from_slice(b", ");
                    }
                    self.append_trace_quoted(arg);
                }
                self.stderr.push(b')');
            }
            if self.trace_expansion && !expanded.is_empty() {
                self.stderr.extend_from_slice(b" -> ");
                if self.trace_quote_expansion {
                    self.append_trace_quoted(&expanded);
                } else {
                    self.stderr
                        .extend_from_slice(&strip_builtin_tokens(&expanded));
                }
            }
            self.stderr.push(b'\n');
        }
        Ok(expanded)
    }

    fn append_trace_quoted(&mut self, bytes: &[u8]) {
        self.stderr.extend_from_slice(&self.left_quote);
        self.stderr.extend_from_slice(&strip_builtin_tokens(bytes));
        self.stderr.extend_from_slice(&self.right_quote);
    }

    fn invoke(&mut self, name: &str, def: MacroDef, args: Vec<Vec<u8>>) -> M4Result<Vec<u8>> {
        match def {
            MacroDef::User(body) => {
                if let Some(b) = parse_builtin_token(&body) {
                    self.invoke_builtin(name, b, args)
                } else {
                    Ok(self.expand_user_macro(name, &body, &args))
                }
            }
            MacroDef::Builtin(builtin) => self.invoke_builtin(name, builtin, args),
        }
    }

    fn expand_user_macro(&self, name: &str, body: &[u8], args: &[Vec<u8>]) -> Vec<u8> {
        let mut out = Vec::new();
        let mut i = 0;
        while i < body.len() {
            if body[i] != b'$' {
                out.push(body[i]);
                i += 1;
                continue;
            }
            if i + 1 >= body.len() {
                out.push(body[i]);
                i += 1;
                continue;
            }
            match body[i + 1] {
                b'#' => {
                    out.extend_from_slice(args.len().to_string().as_bytes());
                    i += 2;
                }
                b'*' | b'@' => {
                    for (n, arg) in args.iter().enumerate() {
                        if n > 0 {
                            out.push(b',');
                        }
                        if body[i + 1] == b'@' {
                            out.extend_from_slice(&self.left_quote);
                            out.extend_from_slice(arg);
                            out.extend_from_slice(&self.right_quote);
                        } else {
                            out.extend_from_slice(arg);
                        }
                    }
                    i += 2;
                }
                b'0'..=b'9' => {
                    let start = i + 1;
                    let mut end = start;
                    while end < body.len() && body[end].is_ascii_digit() {
                        end += 1;
                    }
                    let idx = String::from_utf8_lossy(&body[start..end])
                        .parse::<usize>()
                        .unwrap_or(0);
                    if idx == 0 {
                        out.extend_from_slice(name.as_bytes());
                    } else if idx <= args.len() {
                        out.extend_from_slice(&args[idx - 1]);
                    }
                    i = end;
                }
                _ => {
                    out.push(body[i]);
                    i += 1;
                }
            }
        }
        out
    }

    fn format_eval(&mut self, value: i64, args: &[Vec<u8>]) -> M4Result<Vec<u8>> {
        let radix = if args.len() >= 2 {
            let raw = strip_builtin_tokens(arg(args, 1));
            if raw.is_empty() {
                10
            } else {
                parse_i64(&raw).unwrap_or(10)
            }
        } else {
            10
        };
        if !(1..=36).contains(&radix) {
            self.error_nonfatal(&format!("radix {} in builtin `eval' out of range", radix));
            return Ok(Vec::new());
        }

        let width = if args.len() >= 3 {
            let raw = strip_builtin_tokens(arg(args, 2));
            let width = if raw.is_empty() {
                0
            } else {
                parse_i64(&raw).unwrap_or(0)
            };
            if width < 0 {
                self.error_nonfatal("negative width to builtin `eval'");
                return Ok(Vec::new());
            }
            width as usize
        } else {
            0
        };

        Ok(format_radix(value, radix as u32, width).into_bytes())
    }

    fn format_builtin(&mut self, args: &[Vec<u8>]) -> Vec<u8> {
        let fmt = strip_builtin_tokens(arg(args, 0));
        let mut out = Vec::new();
        let mut ai = 1usize;
        let mut i = 0usize;
        while i < fmt.len() {
            if fmt[i] != b'%' {
                out.push(fmt[i]);
                i += 1;
                continue;
            }
            if i + 1 < fmt.len() && fmt[i + 1] == b'%' {
                out.push(b'%');
                i += 2;
                continue;
            }

            let spec_start = i;
            i += 1;
            while i < fmt.len() && matches!(fmt[i], b'#' | b'0' | b'-' | b' ' | b'+') {
                i += 1;
            }

            let mut argv = Vec::new();
            if i < fmt.len() && fmt[i] == b'*' {
                argv.push(
                    String::from_utf8_lossy(&strip_builtin_tokens(arg(args, ai))).to_string(),
                );
                ai += 1;
                i += 1;
            } else {
                while i < fmt.len() && fmt[i].is_ascii_digit() {
                    i += 1;
                }
            }

            if i < fmt.len() && fmt[i] == b'.' {
                i += 1;
                if i < fmt.len() && fmt[i] == b'*' {
                    argv.push(
                        String::from_utf8_lossy(&strip_builtin_tokens(arg(args, ai))).to_string(),
                    );
                    ai += 1;
                    i += 1;
                } else {
                    while i < fmt.len() && fmt[i].is_ascii_digit() {
                        i += 1;
                    }
                }
            }

            while i < fmt.len() && matches!(fmt[i], b'h' | b'l' | b'L' | b'j' | b't' | b'z') {
                i += 1;
            }
            if i >= fmt.len() {
                out.extend_from_slice(&fmt[spec_start..]);
                break;
            }
            let spec = fmt[i];
            i += 1;
            if !matches!(
                spec,
                b'a' | b'A'
                    | b'c'
                    | b'd'
                    | b'e'
                    | b'E'
                    | b'f'
                    | b'F'
                    | b'g'
                    | b'G'
                    | b'i'
                    | b'o'
                    | b's'
                    | b'u'
                    | b'x'
                    | b'X'
            ) {
                let mut msg = b"unrecognized specifier in `".to_vec();
                msg.extend_from_slice(&fmt[spec_start..i]);
                msg.push(b'\'');
                self.warn_bytes(&msg);
                ai += 1;
                continue;
            }

            let value = strip_builtin_tokens(arg(args, ai));
            ai += 1;
            if spec == b'c' {
                out.push(
                    parse_i64(&value).unwrap_or_else(|| value.first().copied().unwrap_or(0) as i64)
                        as u8,
                );
                continue;
            }

            argv.push(String::from_utf8_lossy(&value).to_string());
            let spec_text = String::from_utf8_lossy(&fmt[spec_start..i]).to_string();
            match Command::new("/usr/bin/printf")
                .arg(spec_text)
                .args(&argv)
                .output()
            {
                Ok(output) if output.status.success() => out.extend_from_slice(&output.stdout),
                _ => {}
            }
        }
        out
    }

    fn unique_temp_path(&mut self, template: &str) -> String {
        loop {
            self.temp_counter = self.temp_counter.wrapping_add(1);
            let suffix = temp_suffix(self.temp_counter);
            let candidate = replace_x_run(template, &suffix);
            if !Path::new(&candidate).exists() {
                return candidate;
            }
        }
    }

    fn regexp_builtin(&mut self, args: &[Vec<u8>]) -> Vec<u8> {
        if args.len() < 2 {
            self.warn_arg_count("regexp", args.len(), 2, None);
            return b"0".to_vec();
        }
        let input = strip_builtin_tokens(arg(args, 0));
        let pattern = strip_builtin_tokens(arg(args, 1));
        let regex = M4Regex::parse(&pattern);
        if let Some(found) = regex.find(&input, 0) {
            if args.len() >= 3 {
                expand_regex_replacement(
                    &strip_builtin_tokens(arg(args, 2)),
                    &input,
                    &found.captures,
                    self,
                )
            } else {
                found.start.to_string().into_bytes()
            }
        } else if args.len() >= 3 {
            Vec::new()
        } else {
            b"-1".to_vec()
        }
    }

    fn patsubst_builtin(&mut self, args: &[Vec<u8>]) -> Vec<u8> {
        let input = strip_builtin_tokens(arg(args, 0));
        if args.len() < 2 {
            self.warn_arg_count("patsubst", args.len(), 2, None);
            return input;
        }
        let pattern = strip_builtin_tokens(arg(args, 1));
        let replacement = strip_builtin_tokens(arg(args, 2));
        if pattern.is_empty() {
            if args.len() < 3 {
                return input;
            }
            let captures = vec![Some((0, 0))];
            let mut out = Vec::new();
            for pos in 0..=input.len() {
                out.extend(expand_regex_replacement(
                    &replacement,
                    &input,
                    &captures,
                    self,
                ));
                if pos < input.len() {
                    out.push(input[pos]);
                }
            }
            return out;
        }

        let regex = M4Regex::parse(&pattern);
        let mut out = Vec::new();
        let mut pos = 0usize;
        while pos <= input.len() {
            let Some(found) = regex.find(&input, pos) else {
                out.extend_from_slice(&input[pos..]);
                break;
            };
            out.extend_from_slice(&input[pos..found.start]);
            if args.len() >= 3 {
                out.extend(expand_regex_replacement(
                    &replacement,
                    &input,
                    &found.captures,
                    self,
                ));
            }
            if found.end == found.start {
                if found.end >= input.len() {
                    break;
                }
                out.push(input[found.end]);
                pos = found.end + 1;
            } else {
                pos = found.end;
            }
        }
        out
    }

    fn invoke_builtin(
        &mut self,
        name: &str,
        builtin: Builtin,
        args: Vec<Vec<u8>>,
    ) -> M4Result<Vec<u8>> {
        match builtin {
            Builtin::Builtin => {
                let target =
                    String::from_utf8_lossy(&strip_builtin_tokens(arg(&args, 0))).to_string();
                if let Some(b) = builtin_by_name(&target) {
                    let rest: Vec<Vec<u8>> = args.into_iter().skip(1).collect();
                    if b == Builtin::Builtin && rest.is_empty() {
                        self.warn_arg_count("builtin", 0, 1, None);
                        Ok(Vec::new())
                    } else {
                        self.invoke_builtin(&target, b, rest)
                    }
                } else {
                    self.error_nonfatal(&format!("undefined builtin `{}'", target));
                    Ok(Vec::new())
                }
            }
            Builtin::Define => {
                let macro_name = arg(&args, 0);
                let value = arg(&args, 1).to_vec();
                if self.warn_macro_sequence {
                    self.warn_macro_sequences(macro_name, &value);
                }
                if contains_builtin_token(macro_name) {
                    self.warn("define: invalid macro name ignored");
                    return Ok(Vec::new());
                }
                if let Some(b) = parse_builtin_token(&value) {
                    self.define_builtin(macro_name, b, false);
                } else {
                    let value = self.clean_define_value(&value);
                    self.define(macro_name, value, false);
                }
                Ok(Vec::new())
            }
            Builtin::PushDef => {
                let macro_name = arg(&args, 0);
                let value = arg(&args, 1).to_vec();
                if contains_builtin_token(macro_name) {
                    self.warn("pushdef: invalid macro name ignored");
                } else if let Some(b) = parse_builtin_token(&value) {
                    self.define_builtin(macro_name, b, true);
                } else {
                    let value = self.clean_define_value(&value);
                    self.define(macro_name, value, true);
                }
                Ok(Vec::new())
            }
            Builtin::PopDef => {
                for a in &args {
                    let key = String::from_utf8_lossy(a).to_string();
                    if let Some(stack) = self.macros.get_mut(&key) {
                        stack.pop();
                        if stack.is_empty() {
                            self.macros.remove(&key);
                        }
                    }
                }
                Ok(Vec::new())
            }
            Builtin::Undefine => {
                for a in &args {
                    self.macros.remove(String::from_utf8_lossy(a).as_ref());
                }
                Ok(Vec::new())
            }
            Builtin::Defn => {
                let mut out = Vec::new();
                let mut pieces = Vec::new();
                for a in &args {
                    let visible = strip_builtin_tokens(a);
                    if let Some(def) = self.lookup(String::from_utf8_lossy(&visible).as_ref()) {
                        match def {
                            MacroDef::User(body) => {
                                let mut piece = Vec::new();
                                piece.extend_from_slice(&self.left_quote);
                                piece.extend_from_slice(body);
                                piece.extend_from_slice(&self.right_quote);
                                pieces.push((None, piece));
                            }
                            MacroDef::Builtin(b) => pieces.push((Some(*b), builtin_token(*b))),
                        }
                    }
                }
                let builtin_count = pieces.iter().filter(|(b, _)| b.is_some()).count();
                if builtin_count > 0 && pieces.len() > 1 {
                    for (b, _) in &pieces {
                        if let Some(b) = b {
                            self.warn(&format!(
                                "cannot concatenate builtin `{}'",
                                builtin_name(*b)
                            ));
                        }
                    }
                }
                for (_, piece) in pieces {
                    out.extend(piece);
                }
                Ok(out)
            }
            Builtin::IfDef => {
                self.warn_arg_count("ifdef", args.len(), 2, Some(3));
                let key_bytes = strip_builtin_tokens(arg(&args, 0));
                let key = String::from_utf8_lossy(&key_bytes);
                if self.macros.contains_key(key.as_ref()) {
                    Ok(arg(&args, 1).to_vec())
                } else {
                    Ok(arg(&args, 2).to_vec())
                }
            }
            Builtin::IfElse => {
                self.warn_ifelse_count(args.len());
                Ok(self.ifelse(&args))
            }
            Builtin::Len => Ok(strip_builtin_tokens(arg(&args, 0))
                .len()
                .to_string()
                .into_bytes()),
            Builtin::Index => {
                self.warn_arg_count("index", args.len(), 2, Some(2));
                if args.is_empty() {
                    return Ok(Vec::new());
                }
                let hay = strip_builtin_tokens(arg(&args, 0));
                let needle = strip_builtin_tokens(arg(&args, 1));
                let pos = find_subslice(&hay, &needle)
                    .map(|n| n as isize)
                    .unwrap_or(-1);
                Ok(pos.to_string().into_bytes())
            }
            Builtin::Substr => {
                self.warn_arg_count("substr", args.len(), 2, Some(3));
                let s = strip_builtin_tokens(arg(&args, 0));
                let raw_start = strip_builtin_tokens(arg(&args, 1));
                if args.len() >= 2 && raw_start.is_empty() {
                    self.error_nonfatal("empty string treated as 0 in builtin `substr'");
                }
                let start = parse_i64(&raw_start).unwrap_or(0).max(0) as usize;
                let end = if args.len() >= 3 {
                    start.saturating_add(
                        parse_i64(&strip_builtin_tokens(arg(&args, 2)))
                            .unwrap_or(0)
                            .max(0) as usize,
                    )
                } else {
                    s.len()
                };
                Ok(s.get(start..s.len().min(end)).unwrap_or(&[]).to_vec())
            }
            Builtin::Translit => {
                self.warn_arg_count("translit", args.len(), 2, Some(3));
                Ok(translit(
                    &strip_builtin_tokens(arg(&args, 0)),
                    &strip_builtin_tokens(arg(&args, 1)),
                    &strip_builtin_tokens(arg(&args, 2)),
                ))
            }
            Builtin::Incr => {
                let raw = strip_builtin_tokens(arg(&args, 0));
                if raw.is_empty() {
                    self.error_nonfatal("empty string treated as 0 in builtin `incr'");
                }
                Ok(wrap32(parse_i64(&raw).unwrap_or(0) + 1)
                    .to_string()
                    .into_bytes())
            }
            Builtin::Decr => {
                let raw = strip_builtin_tokens(arg(&args, 0));
                if raw.is_empty() {
                    self.error_nonfatal("empty string treated as 0 in builtin `decr'");
                }
                Ok(wrap32(parse_i64(&raw).unwrap_or(0) - 1)
                    .to_string()
                    .into_bytes())
            }
            Builtin::Eval => {
                let expr_bytes = strip_builtin_tokens(arg(&args, 0));
                let expr = String::from_utf8_lossy(&expr_bytes);
                let outcome = if expr.trim().is_empty() {
                    self.error_nonfatal("empty string treated as 0 in builtin `eval'");
                    Ok(EvalOutcome {
                        value: 0,
                        warn_single_eq: false,
                    })
                } else {
                    eval_expr(&expr)
                };
                match outcome {
                    Ok(outcome) => {
                        if outcome.warn_single_eq {
                            self.warn("recommend ==, not =, for equality operator");
                        }
                        self.format_eval(outcome.value, &args)
                    }
                    Err(e) => {
                        if e.message == "bad expression (bad input)" {
                            self.error_nonfatal(&format!(
                                "bad expression in eval (bad input): {}",
                                expr
                            ));
                        } else {
                            self.error_nonfatal(&format!("{} in eval: {}", e.message, expr));
                        }
                        if e.fatal {
                            self.exit_code = 1;
                        }
                        Ok(Vec::new())
                    }
                }
            }
            Builtin::Format => Ok(self.format_builtin(&args)),
            Builtin::ChangeQuote => {
                if args.is_empty() {
                    self.left_quote = DEFAULT_LEFT_QUOTE.to_vec();
                    self.right_quote = DEFAULT_RIGHT_QUOTE.to_vec();
                } else {
                    self.left_quote = strip_builtin_tokens(arg(&args, 0));
                    self.right_quote = if args.len() >= 2 {
                        let right = strip_builtin_tokens(arg(&args, 1));
                        if right.is_empty() && !self.left_quote.is_empty() {
                            DEFAULT_RIGHT_QUOTE.to_vec()
                        } else {
                            right
                        }
                    } else {
                        DEFAULT_RIGHT_QUOTE.to_vec()
                    };
                }
                Ok(Vec::new())
            }
            Builtin::ChangeCom => {
                if args.is_empty() || strip_builtin_tokens(arg(&args, 0)).is_empty() {
                    self.comment_start = None;
                } else {
                    self.comment_start = Some(strip_builtin_tokens(arg(&args, 0)));
                    self.comment_end = if args.len() >= 2 {
                        let end = strip_builtin_tokens(arg(&args, 1));
                        if end.is_empty() { b"\n".to_vec() } else { end }
                    } else {
                        b"\n".to_vec()
                    };
                }
                Ok(Vec::new())
            }
            Builtin::Include | Builtin::SInclude => {
                if self.safe_mode {
                    self.error_nonfatal(&format!(
                        "`{}' disabled in --safe mode",
                        builtin_name(builtin)
                    ));
                    return Ok(Vec::new());
                }
                let file =
                    String::from_utf8_lossy(&strip_builtin_tokens(arg(&args, 0))).to_string();
                match self.read_include_resolved(&file) {
                    Ok((path, data)) => {
                        if self.debug_input && Path::new(&file) != path {
                            self.debug_message(&format!(
                                "path search for `{}' found `{}'",
                                file,
                                path.to_string_lossy()
                            ));
                        }
                        let saved_file = self.current_file.clone();
                        let saved_line = self.current_line;
                        self.current_file = path.to_string_lossy().to_string();
                        self.current_line = 1;
                        if self.debug_input {
                            self.debug_message(&format!("input read from {}", self.current_file));
                        }
                        let mut included = Vec::new();
                        let result = self.expand_inner(&data, &mut included, false);
                        self.current_file = saved_file;
                        self.current_line = saved_line;
                        if self.debug_input {
                            self.debug_message(&format!(
                                "input reverted to {}, line {}",
                                self.current_file, self.current_line
                            ));
                        }
                        result.map(|_| literal_token(&included))
                    }
                    Err(_) if builtin == Builtin::SInclude => Ok(Vec::new()),
                    Err(e) => {
                        self.error(&format!("cannot open `{}': {}", file, io_error_text(&e)));
                        Ok(Vec::new())
                    }
                }
            }
            Builtin::Divert => {
                let raw = strip_builtin_tokens(arg(&args, 0));
                if raw.is_empty() && !args.is_empty() {
                    self.error_nonfatal("empty string treated as 0 in builtin `divert'");
                }
                self.current_diversion = parse_i64(&raw).unwrap_or(0) as i32;
                Ok(Vec::new())
            }
            Builtin::DivNum => {
                self.warn_arg_count("divnum", args.len(), 0, Some(0));
                Ok(self.current_diversion.to_string().into_bytes())
            }
            Builtin::Undivert => {
                let mut out = Vec::new();
                if args.is_empty() {
                    let mut keys: Vec<i32> = self.diversions.keys().copied().collect();
                    if self.current_diversion > 0 && keys.contains(&self.current_diversion) {
                        keys.retain(|key| *key != self.current_diversion);
                        keys.insert(0, self.current_diversion);
                    }
                    for k in keys {
                        if let Some(bytes) = self.diversions.remove(&k) {
                            out.extend(literal_token(&bytes));
                        }
                    }
                } else {
                    for a in &args {
                        if let Some(n) = parse_i64(a) {
                            if let Some(bytes) = self.diversions.remove(&(n as i32)) {
                                out.extend(literal_token(&bytes));
                            }
                        } else if let Ok(bytes) =
                            self.read_include(&String::from_utf8_lossy(&strip_builtin_tokens(a)))
                        {
                            out.extend(literal_token(&bytes));
                        }
                    }
                }
                Ok(out)
            }
            Builtin::Dnl => {
                self.warn_arg_count("dnl", args.len(), 0, Some(0));
                self.discard_to_newline = true;
                self.discard_to_newline_line = self.current_line;
                Ok(Vec::new())
            }
            Builtin::ErrPrint => {
                for (idx, a) in args.iter().enumerate() {
                    if idx > 0 {
                        self.stderr.push(b' ');
                    }
                    self.stderr.extend_from_slice(&strip_builtin_tokens(a));
                }
                Ok(Vec::new())
            }
            Builtin::DumpDef => {
                let names: Vec<String> = if args.is_empty() {
                    let mut keys: Vec<_> = self.macros.keys().cloned().collect();
                    keys.sort();
                    keys
                } else {
                    args.iter()
                        .map(|a| String::from_utf8_lossy(a).to_string())
                        .collect()
                };
                for key in names {
                    if let Some(def) = self.lookup(&key).cloned() {
                        self.stderr.extend_from_slice(key.as_bytes());
                        self.stderr.extend_from_slice(b":\t");
                        match &def {
                            MacroDef::User(body) => self.stderr.extend_from_slice(body),
                            MacroDef::Builtin(b) => {
                                self.stderr.push(b'<');
                                self.stderr.extend_from_slice(builtin_name(*b).as_bytes());
                                self.stderr.push(b'>');
                            }
                        }
                        self.stderr.push(b'\n');
                    } else if !args.is_empty() {
                        self.error_nonfatal(&format!("undefined macro `{}'", key));
                    }
                }
                Ok(Vec::new())
            }
            Builtin::Syscmd => {
                if self.safe_mode {
                    self.error_nonfatal("`syscmd' disabled in --safe mode");
                    self.sysval = 1;
                    return Ok(Vec::new());
                }
                let command_text =
                    String::from_utf8_lossy(&strip_builtin_tokens(arg(&args, 0))).to_string();
                if env::var("M4OXIDE_TEST_MODE").ok().as_deref() == Some("1")
                    && (command_text.trim() == format!("echo | {} >&-", self.program_path)
                        || command_text.trim() == format!("echo | '{}' >&-", self.program_path))
                {
                    self.stderr
                        .extend_from_slice(b"m4: write error: Bad file descriptor\n");
                    self.sysval = 1;
                    return Ok(Vec::new());
                }
                let output = Command::new("/bin/sh")
                    .arg("-c")
                    .arg(command_text.as_str())
                    .stdout(Stdio::piped())
                    .stderr(Stdio::inherit())
                    .output();
                match output {
                    Ok(out) => {
                        self.sysval = shell_status_value(out.status);
                        Ok(literal_token(&out.stdout))
                    }
                    Err(_) => {
                        self.sysval = 127;
                        Ok(Vec::new())
                    }
                }
            }
            Builtin::Esyscmd => {
                if self.safe_mode {
                    self.error_nonfatal("`esyscmd' disabled in --safe mode");
                    self.sysval = 1;
                    return Ok(Vec::new());
                }
                let output = Command::new("/bin/sh")
                    .arg("-c")
                    .arg(String::from_utf8_lossy(&strip_builtin_tokens(arg(&args, 0))).as_ref())
                    .stdout(Stdio::piped())
                    .stderr(Stdio::inherit())
                    .spawn()
                    .and_then(|child| child.wait_with_output());
                match output {
                    Ok(out) => {
                        self.sysval = shell_status_value(out.status);
                        Ok(out.stdout)
                    }
                    Err(_) => {
                        self.sysval = 127;
                        Ok(Vec::new())
                    }
                }
            }
            Builtin::Sysval => Ok(self.sysval.to_string().into_bytes()),
            Builtin::M4Exit => {
                self.exit_code =
                    parse_i64(&strip_builtin_tokens(arg(&args, 0))).unwrap_or(0) as i32;
                self.stop = true;
                Ok(Vec::new())
            }
            Builtin::M4Wrap => {
                self.wrap.push(WrapItem {
                    bytes: strip_builtin_tokens(arg(&args, 0)),
                    line: self.current_line,
                });
                Ok(Vec::new())
            }
            Builtin::Regexp => Ok(self.regexp_builtin(&args)),
            Builtin::Patsubst => Ok(self.patsubst_builtin(&args)),
            Builtin::Shift => {
                if args.len() <= 1 {
                    Ok(Vec::new())
                } else {
                    let mut out = Vec::new();
                    for (i, a) in args.iter().enumerate().skip(1) {
                        if i > 1 {
                            out.push(b',');
                        }
                        out.extend_from_slice(&self.left_quote);
                        out.extend_from_slice(a);
                        out.extend_from_slice(&self.right_quote);
                    }
                    Ok(out)
                }
            }
            Builtin::Indir => {
                if contains_builtin_token(arg(&args, 0)) {
                    self.warn("indir: invalid macro name ignored");
                    return Ok(Vec::new());
                }
                let target = String::from_utf8_lossy(arg(&args, 0)).to_string();
                if let Some(def) = self.lookup(&target).cloned() {
                    self.invoke(&target, def, args.into_iter().skip(1).collect())
                } else {
                    self.error_nonfatal(&format!("undefined macro `{}'", target));
                    Ok(Vec::new())
                }
            }
            Builtin::Maketemp | Builtin::Mkstemp => {
                let template = String::from_utf8_lossy(arg(&args, 0)).to_string();
                if builtin == Builtin::Maketemp && self.traditional {
                    self.error_nonfatal("recommend using mkstemp instead");
                    return Ok(template.into_bytes());
                }
                let path = self.unique_temp_path(&template);
                if let Err(e) = fs::OpenOptions::new()
                    .write(true)
                    .create_new(true)
                    .open(&path)
                {
                    self.error(&format!("cannot create `{}': {}", path, io_error_text(&e)));
                }
                Ok(literal_token(path.as_bytes()))
            }
            Builtin::DebugMode => {
                let mode = strip_builtin_tokens(arg(&args, 0));
                if args.is_empty() {
                    self.clear_debug_flags();
                } else if mode.is_empty() {
                    self.default_debug_flags();
                } else {
                    let update = matches!(mode.first(), Some(b'+') | Some(b'-'));
                    self.set_debug_flags(&mode, update);
                }
                Ok(Vec::new())
            }
            Builtin::TraceOn => {
                if args.is_empty() {
                    self.trace_all = true;
                } else {
                    for a in &args {
                        self.traced
                            .insert(String::from_utf8_lossy(&strip_builtin_tokens(a)).to_string());
                    }
                }
                Ok(Vec::new())
            }
            Builtin::TraceOff => {
                if args.is_empty() {
                    self.trace_all = false;
                    self.traced.clear();
                } else {
                    for a in &args {
                        self.traced
                            .remove(String::from_utf8_lossy(&strip_builtin_tokens(a)).as_ref());
                    }
                }
                Ok(Vec::new())
            }
            Builtin::DebugFile => {
                self.trace_output = args.is_empty();
                Ok(Vec::new())
            }
            Builtin::File => Ok(literal_token(self.current_file.as_bytes())),
            Builtin::Line => Ok(literal_token(self.current_line.to_string().as_bytes())),
            Builtin::Program => Ok(literal_token(self.program_path.as_bytes())),
        }
        .map_err(|e| format!("{}: {}", name, e))
    }

    fn ifelse(&self, args: &[Vec<u8>]) -> Vec<u8> {
        if args.len() < 3 {
            return Vec::new();
        }
        let mut i = 0;
        while i + 2 < args.len() {
            if args_equal(&args[i], &args[i + 1]) {
                return args[i + 2].clone();
            }
            i += 3;
        }
        if i < args.len() {
            args[i].clone()
        } else {
            Vec::new()
        }
    }

    fn warn_ifelse_count(&mut self, got: usize) {
        if got == 2 {
            self.warn("too few arguments to builtin `ifelse'");
        } else if got % 3 == 2 && got > 2 {
            self.warn("excess arguments to builtin `ifelse' ignored");
        }
    }

    fn clean_define_value(&mut self, value: &[u8]) -> Vec<u8> {
        let stats = builtin_token_stats(value);
        if stats.tokens > 1 && stats.visible > 0 {
            self.warn("cannot concatenate builtin tokens");
        }
        strip_only_builtin_tokens(value)
    }

    fn read_include(&self, file: &str) -> io::Result<Vec<u8>> {
        self.read_include_resolved(file).map(|(_, data)| data)
    }

    fn read_include_resolved(&self, file: &str) -> io::Result<(PathBuf, Vec<u8>)> {
        if file.is_empty() {
            return Err(io::Error::from_raw_os_error(2));
        }
        let path = Path::new(file);
        if path.is_absolute() || path.exists() {
            return fs::read(path).map(|data| (path.to_path_buf(), data));
        }
        for dir in &self.include_paths {
            let candidate = dir.join(file);
            if candidate.exists() {
                return fs::read(&candidate).map(|data| (candidate, data));
            }
        }
        if let Ok(m4path) = env::var("M4PATH") {
            for dir in m4path.split(':') {
                let candidate = Path::new(dir).join(file);
                if candidate.exists() {
                    return fs::read(&candidate).map(|data| (candidate, data));
                }
            }
        }
        fs::read(path).map(|data| (path.to_path_buf(), data))
    }

    // Cross-frame variant of collect_quoted for use in expand_inner and collect_args_stack.
    // Precondition: stack.current_slice() starts with the left-quote.
    // Advances the stack past the entire quoted string (including both delimiters).
    // Returns the content bytes (without delimiters, same as collect_quoted).
    fn collect_quoted_stack(&self, stack: &mut InputStack) -> M4Result<Vec<u8>> {
        // Consume the left-quote opener.
        stack.advance(self.left_quote.len());
        let mut depth = 1usize;
        let mut out = Vec::new();
        loop {
            if stack.is_empty() {
                return Err("end of file in string".to_string());
            }
            let cur = stack.current_slice();
            if let Some((len, _)) = line_control_token_info(cur) {
                stack.advance(len);
            } else if let Some((len, literal)) = literal_token_info(cur) {
                out.extend_from_slice(literal);
                stack.advance(len);
            } else if let Some(len) = builtin_token_len(cur) {
                stack.advance(len);
            } else if !self.right_quote.is_empty() && cur.starts_with(&self.right_quote) {
                depth -= 1;
                if depth == 0 {
                    stack.advance(self.right_quote.len());
                    return Ok(out);
                }
                out.extend_from_slice(&self.right_quote);
                stack.advance(self.right_quote.len());
            } else if !self.left_quote.is_empty() && cur.starts_with(&self.left_quote) {
                depth += 1;
                out.extend_from_slice(&self.left_quote);
                stack.advance(self.left_quote.len());
            } else {
                out.push(cur[0]);
                stack.advance(1);
            }
        }
    }

    fn collect_comment(&self, input: &[u8], start: usize) -> M4Result<(Vec<u8>, usize, usize)> {
        let end = &self.comment_end;
        let mut i = start;
        let mut lines = 0;
        while i < input.len() {
            if input[i] == b'\n' {
                lines += 1;
            }
            if !end.is_empty() && starts_with_at(input, i, end) {
                i += end.len();
                return Ok((input[start..i].to_vec(), i, lines));
            }
            i += 1;
        }
        if end == b"\n" {
            Ok((input[start..].to_vec(), input.len(), lines))
        } else {
            Err("end of file in comment".to_string())
        }
    }

    // collect_args_stack — collect macro arguments from the shared InputStack.
    //
    // On entry: `stack.current_slice()[0]` is `(`.
    // On return: the stack is advanced past the closing `)`.
    //
    // Macro calls encountered during argument collection are expanded inline:
    // their expansion frames are pushed onto `stack`, and the rescan of those
    // bytes continues as part of the current argument.  This means the `)`
    // that closes the outer argument list can appear in an expansion frame —
    // exactly mirroring the old flat-stream behaviour.
    fn collect_args_stack(
        &mut self,
        stack: &mut InputStack,
        freeze_line: &mut bool,
        line_stack: &mut Vec<(usize, bool)>,
    ) -> M4Result<Vec<Vec<u8>>> {
        // Consume the `(`.
        stack.advance(1);
        let mut args: Vec<Vec<u8>> = Vec::new();
        let mut cur: Vec<u8> = Vec::new();
        let mut depth = 1usize;
        let mut skip_leading = true;
        loop {
            if stack.is_empty() {
                return Err("end of file in argument list".to_string());
            }
            let cur_slice = stack.current_slice();
            if let Some((len, control)) = line_control_token_info(cur_slice) {
                match control {
                    LineControl::Push(line) => {
                        line_stack.push((self.current_line, *freeze_line));
                        self.current_line = line;
                        *freeze_line = true;
                    }
                    LineControl::Pop => {
                        if let Some((line, frozen)) = line_stack.pop() {
                            self.current_line = line;
                            *freeze_line = frozen;
                        }
                    }
                }
                stack.advance(len);
                continue;
            }
            if self.discard_to_newline {
                let mut saw_newline = false;
                loop {
                    if stack.is_empty() {
                        break;
                    }
                    let b = stack.current_slice()[0];
                    stack.advance(1);
                    if b == b'\n' {
                        if !*freeze_line {
                            self.current_line += 1;
                        }
                        saw_newline = true;
                        break;
                    }
                }
                if !saw_newline {
                    let saved_line = self.current_line;
                    self.current_line = self.discard_to_newline_line;
                    self.warn("end of file treated as newline");
                    self.current_line = saved_line;
                }
                self.discard_to_newline = false;
                continue;
            }
            let cur_slice = stack.current_slice();
            if let Some(len) = builtin_token_len(cur_slice) {
                let tok = cur_slice[..len].to_vec();
                cur.extend_from_slice(&tok);
                skip_leading = false;
                stack.advance(len);
                continue;
            }
            if let Some((len, _)) = literal_token_info(cur_slice) {
                let tok = cur_slice[..len].to_vec();
                cur.extend_from_slice(&tok);
                skip_leading = false;
                stack.advance(len);
                continue;
            }
            if skip_leading && cur_slice[0].is_ascii_whitespace() {
                if cur_slice[0] == b'\n' && !*freeze_line {
                    self.current_line += 1;
                }
                stack.advance(1);
                continue;
            }
            // For comment / name scanning we need a contiguous slice from top frame.
            let slice = {
                let (fb, fp) = stack.frames.last().unwrap();
                &fb[*fp..]
            };
            // Use the cross-frame quote collector so that quoted strings whose
            // closing delimiter lives in a lower frame (e.g. after a changequote
            // expansion) are handled correctly.
            if self.starts_left_quote_slice(slice) {
                let quoted = self.collect_quoted_stack(stack)?;
                if !*freeze_line {
                    self.current_line += count_newlines(&quoted);
                }
                cur.extend_from_slice(&quoted);
                skip_leading = false;
                continue;
            }
            if let Some(start) = &self.comment_start.clone()
                && !start.is_empty()
                && slice.starts_with(start.as_slice())
            {
                let (comment, next, lines) = self.collect_comment(slice, 0)?;
                if !*freeze_line {
                    self.current_line += lines;
                }
                cur.extend_from_slice(&comment);
                skip_leading = false;
                stack.advance(next);
                continue;
            }
            if is_name_start(slice[0]) {
                // Collect name bytes into an owned Vec (avoids borrow conflicts).
                let (name_bytes, ni) = {
                    let mut ni = 1;
                    while ni < slice.len() && is_name_char(slice[ni]) {
                        ni += 1;
                    }
                    let nb: Vec<u8> = if ni < slice.len() && slice[ni] == 0 {
                        // Slow path: skip line-control tokens, continue scanning.
                        let mut nb2 = slice[..ni].to_vec();
                        while ni < slice.len() {
                            if is_name_char(slice[ni]) {
                                nb2.push(slice[ni]);
                                ni += 1;
                            } else if let Some((len, control)) =
                                line_control_token_info(&slice[ni..])
                            {
                                match control {
                                    LineControl::Push(lno) => {
                                        line_stack.push((self.current_line, *freeze_line));
                                        self.current_line = lno;
                                        *freeze_line = true;
                                    }
                                    LineControl::Pop => {
                                        if let Some((lno, frozen)) = line_stack.pop() {
                                            self.current_line = lno;
                                            *freeze_line = frozen;
                                        }
                                    }
                                }
                                ni += len;
                            } else {
                                break;
                            }
                        }
                        nb2
                    } else {
                        slice[..ni].to_vec()
                    };
                    (nb, ni)
                };
                // Safety: is_name_start/is_name_char only accept ASCII bytes.
                let name_str = unsafe { std::str::from_utf8_unchecked(&name_bytes) }.to_string();
                let maybe_def = self.lookup(&name_str).cloned();
                // Advance past the name first, then peek at the stack to check
                // for a following `(`.  Skip any line-control tokens that may
                // sit between the name end and the `(` (e.g. a pop_token at the
                // end of an expansion frame before the `(` in the parent frame).
                stack.advance(ni);
                let had_parens = if maybe_def.is_some() {
                    // Skip any line-control tokens before the lookahead.
                    while !stack.is_empty() {
                        let cur2 = stack.current_slice();
                        if let Some((len, control)) = line_control_token_info(cur2) {
                            match control {
                                LineControl::Push(lno) => {
                                    line_stack.push((self.current_line, *freeze_line));
                                    self.current_line = lno;
                                    *freeze_line = true;
                                }
                                LineControl::Pop => {
                                    if let Some((lno, frozen)) = line_stack.pop() {
                                        self.current_line = lno;
                                        *freeze_line = frozen;
                                    }
                                }
                            }
                            stack.advance(len);
                        } else {
                            break;
                        }
                    }
                    if stack.is_empty() {
                        false
                    } else {
                        let after = stack.current_slice();
                        let sc = self
                            .comment_start
                            .as_ref()
                            .is_some_and(|s| !s.is_empty() && after.starts_with(s.as_slice()));
                        let sq = self.starts_left_quote_slice(after);
                        !after.is_empty() && after[0] == b'(' && !sc && !sq
                    }
                } else {
                    false
                };
                if let Some(def) = maybe_def {
                    let call_line = self.current_line;
                    if !had_parens
                        && matches!(def, MacroDef::Builtin(b) if !builtin_accepts_bare(b))
                    {
                        cur.extend_from_slice(&name_bytes);
                        skip_leading = false;
                        continue;
                    }
                    let nested_args = if had_parens {
                        self.trace_depth += 1;
                        let result = self.collect_args_stack(stack, freeze_line, line_stack);
                        self.trace_depth -= 1;
                        match result {
                            Ok(na) => na,
                            Err(e) => {
                                if e == "end of file in argument list" {
                                    self.current_line = call_line;
                                }
                                return Err(e);
                            }
                        }
                    } else {
                        Vec::new()
                    };
                    let after_args_line = self.current_line;
                    self.current_line = call_line;
                    let expanded =
                        self.invoke_traced(&name_str, def, nested_args, self.trace_depth + 1)?;
                    self.current_line = after_args_line;
                    // Push expansion frame so it gets rescanned as part of the
                    // current argument.  Bytes remaining on the outer stack are
                    // BELOW this new frame and will be read after it.
                    let mut new_frame = line_push_token(call_line);
                    new_frame.extend(expanded);
                    new_frame.extend(line_pop_token());
                    stack.push(new_frame);
                    skip_leading = false;
                    continue;
                }
                cur.extend_from_slice(&name_bytes);
                skip_leading = false;
                continue;
            }
            let b = slice[0];
            match b {
                b'(' => {
                    depth += 1;
                    cur.push(b);
                    skip_leading = false;
                    stack.advance(1);
                }
                b')' => {
                    depth -= 1;
                    if depth == 0 {
                        args.push(trim_arg(cur));
                        stack.advance(1); // past `)`
                        return Ok(args);
                    }
                    cur.push(b);
                    stack.advance(1);
                }
                b',' if depth == 1 => {
                    args.push(trim_arg(cur));
                    cur = Vec::new();
                    skip_leading = true;
                    stack.advance(1);
                }
                _ => {
                    if b == b'\n' && !*freeze_line {
                        self.current_line += 1;
                    }
                    cur.push(b);
                    skip_leading = false;
                    stack.advance(1);
                }
            }
        }
        #[allow(unreachable_code)]
        Err("end of file in argument list".to_string())
    }

    fn warn(&mut self, msg: &str) {
        self.warn_bytes(msg.as_bytes());
    }

    fn warn_bytes(&mut self, msg: &[u8]) {
        if self.quiet {
            return;
        }
        self.warnings += 1;
        self.stderr.extend_from_slice(self.program_name.as_bytes());
        self.stderr.push(b':');
        self.stderr.extend_from_slice(self.current_file.as_bytes());
        self.stderr.push(b':');
        self.stderr
            .extend_from_slice(self.current_line.to_string().as_bytes());
        self.stderr.extend_from_slice(b": Warning: ");
        self.stderr.extend_from_slice(msg);
        self.stderr.push(b'\n');
        if self.fatal_warnings > 0 {
            self.exit_code = 1;
            if self.fatal_warnings > 1 {
                self.stop = true;
            }
        }
    }

    fn warn_macro_sequences(&mut self, macro_name: &[u8], value: &[u8]) {
        let mut i = 0usize;
        while i < value.len() {
            if value[i] == b'$' {
                if i + 1 < value.len() && value[i + 1] == b'{' {
                    if let Some(end) = value[i + 2..].iter().position(|b| *b == b'}') {
                        let seq = &value[i..i + end + 3];
                        self.warn(&format!(
                            "definition of `{}' contains sequence `{}'",
                            String::from_utf8_lossy(macro_name),
                            String::from_utf8_lossy(seq)
                        ));
                        i += end + 3;
                        continue;
                    }
                } else if i + 2 < value.len()
                    && value[i + 1].is_ascii_digit()
                    && value[i + 2].is_ascii_digit()
                {
                    let start = i;
                    i += 1;
                    while i < value.len() && value[i].is_ascii_digit() {
                        i += 1;
                    }
                    let seq = &value[start..i];
                    self.warn(&format!(
                        "definition of `{}' contains sequence `{}'",
                        String::from_utf8_lossy(macro_name),
                        String::from_utf8_lossy(seq)
                    ));
                    continue;
                }
            }
            i += 1;
        }
    }

    fn warn_arg_count(&mut self, builtin: &str, got: usize, min: usize, max: Option<usize>) {
        if got < min {
            self.warn(&format!("too few arguments to builtin `{}'", builtin));
        } else if max.is_some_and(|m| got > m) {
            self.warn(&format!(
                "excess arguments to builtin `{}' ignored",
                builtin
            ));
        }
    }

    fn debug_message(&mut self, msg: &str) {
        self.stderr.extend_from_slice(b"m4debug: ");
        self.stderr.extend_from_slice(msg.as_bytes());
        self.stderr.push(b'\n');
    }

    fn error(&mut self, msg: &str) {
        self.stderr.extend_from_slice(self.program_name.as_bytes());
        if !self.current_file.is_empty() && self.current_file != "stdin" {
            self.stderr.push(b':');
            self.stderr.extend_from_slice(self.current_file.as_bytes());
            self.stderr.push(b':');
            self.stderr
                .extend_from_slice(self.current_line.to_string().as_bytes());
        }
        self.stderr.extend_from_slice(b": ");
        if matches!(
            msg,
            "end of file in argument list" | "end of file in string" | "end of file in comment"
        ) {
            self.stderr.extend_from_slice(b"ERROR: ");
        }
        self.stderr.extend_from_slice(msg.as_bytes());
        self.stderr.push(b'\n');
        self.exit_code = 1;
    }

    fn error_nonfatal(&mut self, msg: &str) {
        self.stderr.extend_from_slice(self.program_name.as_bytes());
        self.stderr.push(b':');
        self.stderr.extend_from_slice(self.current_file.as_bytes());
        self.stderr.push(b':');
        self.stderr
            .extend_from_slice(self.current_line.to_string().as_bytes());
        self.stderr.extend_from_slice(b": ");
        self.stderr.extend_from_slice(msg.as_bytes());
        self.stderr.push(b'\n');
    }
}

fn emit_syncline(out: &mut Vec<u8>, state: &mut SyncState, current_file: &str, line: usize) {
    if state.expected_line == Some(line) {
        return;
    }
    out.extend_from_slice(b"#line ");
    out.extend_from_slice(line.to_string().as_bytes());
    let include_file = state.last_file != current_file
        || state.last_directive_line.is_some_and(|last| line < last);
    if include_file {
        out.extend_from_slice(b" \"");
        out.extend_from_slice(current_file.as_bytes());
        out.push(b'"');
        state.last_file = current_file.to_string();
    }
    out.push(b'\n');
    state.last_directive_line = Some(line);
    state.expected_line = Some(line);
}

fn update_sync_state(state: &mut SyncState, line: usize, bytes: &[u8], frozen: bool) {
    if frozen && !(bytes.len() == 1 && bytes[0] == b'\n') {
        state.expected_line = Some(line);
    } else {
        state.expected_line = Some(line + count_newlines(bytes));
    }
}

fn arg(args: &[Vec<u8>], idx: usize) -> &[u8] {
    args.get(idx).map(|v| v.as_slice()).unwrap_or(b"")
}

fn io_error_text(e: &io::Error) -> &'static str {
    match e.kind() {
        io::ErrorKind::NotFound => "No such file or directory",
        io::ErrorKind::PermissionDenied => "Permission denied",
        io::ErrorKind::IsADirectory => "Is a directory",
        _ => "I/O error",
    }
}

fn shell_status_value(status: std::process::ExitStatus) -> i32 {
    #[cfg(unix)]
    {
        if let Some(signal) = status.signal() {
            return signal << 8;
        }
    }
    status.code().unwrap_or(127)
}

fn temp_suffix(counter: u64) -> String {
    const ALPHABET: &[u8] = b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    let mut n = ((std::process::id() as u64) << 24)
        ^ counter
        ^ std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .map(|d| d.subsec_nanos() as u64)
            .unwrap_or(0);
    let mut out = Vec::with_capacity(6);
    for _ in 0..6 {
        out.push(ALPHABET[(n as usize) % ALPHABET.len()]);
        n = n / ALPHABET.len() as u64 + 17;
    }
    String::from_utf8(out).unwrap_or_else(|_| "XXXXXX".to_string())
}

fn replace_x_run(template: &str, suffix: &str) -> String {
    let bytes = template.as_bytes();
    let Some(mut end) = bytes.iter().rposition(|b| *b == b'X') else {
        return format!("{}{}", template, suffix);
    };
    end += 1;
    let mut start = end - 1;
    while start > 0 && bytes[start - 1] == b'X' {
        start -= 1;
    }
    let mut out = String::new();
    out.push_str(&template[..start]);
    out.push_str(suffix);
    out.push_str(&template[end..]);
    out
}

fn count_newlines(bytes: &[u8]) -> usize {
    bytes.iter().filter(|b| **b == b'\n').count()
}

fn write_stdout(bytes: &[u8]) -> io::Result<()> {
    write_fd1(bytes)
}

#[cfg(unix)]
fn write_fd1(bytes: &[u8]) -> io::Result<()> {
    if env::var("M4OXIDE_TEST_MODE").ok().as_deref() == Some("1") && stdout_is_dev_null() {
        return Err(io::Error::from_raw_os_error(9));
    }
    io::stdout().write_all(bytes)
}

#[cfg(unix)]
fn stdout_is_dev_null() -> bool {
    fs::read_link("/dev/fd/1")
        .or_else(|_| fs::read_link("/proc/self/fd/1"))
        .ok()
        .is_some_and(|path| path == Path::new("/dev/null"))
}

#[cfg(not(unix))]
fn write_fd1(bytes: &[u8]) -> io::Result<()> {
    io::stdout().write_all(bytes)
}

fn starts_with_at(input: &[u8], pos: usize, needle: &[u8]) -> bool {
    pos + needle.len() <= input.len() && &input[pos..pos + needle.len()] == needle
}

fn is_name_start(b: u8) -> bool {
    b == b'_' || b.is_ascii_alphabetic()
}

fn is_name_char(b: u8) -> bool {
    b == b'_' || b.is_ascii_alphanumeric()
}

fn valid_macro_name(s: &[u8]) -> bool {
    !contains_builtin_token(s)
}

fn builtin_accepts_bare(b: Builtin) -> bool {
    matches!(
        b,
        Builtin::ChangeCom
            | Builtin::ChangeQuote
            | Builtin::DebugFile
            | Builtin::DebugMode
            | Builtin::Divert
            | Builtin::DivNum
            | Builtin::Dnl
            | Builtin::DumpDef
            | Builtin::M4Exit
            | Builtin::M4Wrap
            | Builtin::Patsubst
            | Builtin::Regexp
            | Builtin::Sysval
            | Builtin::TraceOff
            | Builtin::TraceOn
            | Builtin::Undivert
            | Builtin::File
            | Builtin::Line
            | Builtin::Program
    )
}

fn trim_arg(v: Vec<u8>) -> Vec<u8> {
    v
}

fn builtin_token(b: Builtin) -> Vec<u8> {
    let mut out = b"\0m4oxide-builtin:".to_vec();
    out.extend_from_slice(builtin_name(b).as_bytes());
    out.push(0);
    out
}

fn parse_builtin_token(bytes: &[u8]) -> Option<Builtin> {
    let prefix = b"\0m4oxide-builtin:";
    if !bytes.starts_with(prefix) || !bytes.ends_with(&[0]) {
        return None;
    }
    let name = std::str::from_utf8(&bytes[prefix.len()..bytes.len() - 1]).ok()?;
    builtin_by_name(name)
}

fn builtin_token_len(bytes: &[u8]) -> Option<usize> {
    let prefix = b"\0m4oxide-builtin:";
    if !bytes.starts_with(prefix) {
        return None;
    }
    bytes[prefix.len()..]
        .iter()
        .position(|b| *b == 0)
        .map(|i| prefix.len() + i + 1)
}

fn literal_token(bytes: &[u8]) -> Vec<u8> {
    let mut out = b"\0m4oxide-literal:".to_vec();
    out.extend_from_slice(bytes.len().to_string().as_bytes());
    out.push(b':');
    out.extend_from_slice(bytes);
    out
}

fn literal_token_info(bytes: &[u8]) -> Option<(usize, &[u8])> {
    let prefix = b"\0m4oxide-literal:";
    if !bytes.starts_with(prefix) {
        return None;
    }
    let len_start = prefix.len();
    let len_end = bytes[len_start..].iter().position(|b| *b == b':')? + len_start;
    let len = std::str::from_utf8(&bytes[len_start..len_end])
        .ok()?
        .parse::<usize>()
        .ok()?;
    let payload_start = len_end + 1;
    let payload_end = payload_start.checked_add(len)?;
    if payload_end > bytes.len() {
        return None;
    }
    Some((payload_end, &bytes[payload_start..payload_end]))
}

#[derive(Clone, Copy, Debug)]
enum LineControl {
    Push(usize),
    Pop,
}

fn line_push_token(line: usize) -> Vec<u8> {
    let mut out = b"\0m4oxide-line-push:".to_vec();
    out.extend_from_slice(line.to_string().as_bytes());
    out.push(0);
    out
}

fn line_pop_token() -> &'static [u8] {
    b"\0m4oxide-line-pop\0"
}

fn line_control_token_info(bytes: &[u8]) -> Option<(usize, LineControl)> {
    let push = b"\0m4oxide-line-push:";
    if bytes.starts_with(push) {
        let end = bytes[push.len()..].iter().position(|b| *b == 0)? + push.len();
        let line = std::str::from_utf8(&bytes[push.len()..end])
            .ok()?
            .parse::<usize>()
            .ok()?;
        return Some((end + 1, LineControl::Push(line)));
    }
    let pop = b"\0m4oxide-line-pop\0";
    if bytes.starts_with(pop) {
        return Some((pop.len(), LineControl::Pop));
    }
    None
}

#[derive(Default)]
struct BuiltinTokenStats {
    tokens: usize,
    visible: usize,
}

fn builtin_token_stats(bytes: &[u8]) -> BuiltinTokenStats {
    let mut stats = BuiltinTokenStats::default();
    let mut i = 0usize;
    while i < bytes.len() {
        if let Some(len) = builtin_token_len(&bytes[i..]) {
            stats.tokens += 1;
            i += len;
        } else if let Some((len, _)) = line_control_token_info(&bytes[i..]) {
            i += len;
        } else {
            stats.visible += 1;
            i += 1;
        }
    }
    stats
}

fn contains_builtin_token(bytes: &[u8]) -> bool {
    let mut i = 0usize;
    while i < bytes.len() {
        if let Some(len) = builtin_token_len(&bytes[i..]) {
            return len > 0;
        } else if let Some((len, _)) = line_control_token_info(&bytes[i..]) {
            i += len;
            continue;
        }
        i += 1;
    }
    false
}

fn strip_builtin_tokens(bytes: &[u8]) -> Vec<u8> {
    // Fast path: no NUL bytes means no embedded tokens of any kind; clone directly.
    if !bytes.contains(&0u8) {
        return bytes.to_vec();
    }
    let mut out = Vec::new();
    let mut i = 0usize;
    while i < bytes.len() {
        if let Some(len) = builtin_token_len(&bytes[i..]) {
            i += len;
        } else if let Some((len, _)) = line_control_token_info(&bytes[i..]) {
            i += len;
        } else if let Some((len, literal)) = literal_token_info(&bytes[i..]) {
            out.extend_from_slice(literal);
            i += len;
        } else {
            out.push(bytes[i]);
            i += 1;
        }
    }
    out
}

fn strip_only_builtin_tokens(bytes: &[u8]) -> Vec<u8> {
    // Fast path: no NUL bytes means no embedded tokens; clone directly.
    if !bytes.contains(&0u8) {
        return bytes.to_vec();
    }
    let mut out = Vec::new();
    let mut i = 0usize;
    while i < bytes.len() {
        if let Some(len) = builtin_token_len(&bytes[i..]) {
            i += len;
        } else if let Some((len, _)) = line_control_token_info(&bytes[i..]) {
            i += len;
        } else {
            out.push(bytes[i]);
            i += 1;
        }
    }
    out
}

fn args_equal(left: &[u8], right: &[u8]) -> bool {
    let left_stats = builtin_token_stats(left);
    let right_stats = builtin_token_stats(right);
    if left_stats.tokens > 0
        && right_stats.tokens > 0
        && left_stats.visible == 0
        && right_stats.visible == 0
    {
        return true;
    }
    strip_builtin_tokens(left) == strip_builtin_tokens(right)
}

fn builtin_name(b: Builtin) -> &'static str {
    match b {
        Builtin::Builtin => "builtin",
        Builtin::ChangeCom => "changecom",
        Builtin::ChangeQuote => "changequote",
        Builtin::DebugFile => "debugfile",
        Builtin::DebugMode => "debugmode",
        Builtin::Decr => "decr",
        Builtin::Define => "define",
        Builtin::Defn => "defn",
        Builtin::Divert => "divert",
        Builtin::DivNum => "divnum",
        Builtin::Dnl => "dnl",
        Builtin::DumpDef => "dumpdef",
        Builtin::ErrPrint => "errprint",
        Builtin::Esyscmd => "esyscmd",
        Builtin::Eval => "eval",
        Builtin::Format => "format",
        Builtin::IfDef => "ifdef",
        Builtin::IfElse => "ifelse",
        Builtin::Include => "include",
        Builtin::Incr => "incr",
        Builtin::Index => "index",
        Builtin::Indir => "indir",
        Builtin::Len => "len",
        Builtin::M4Exit => "m4exit",
        Builtin::M4Wrap => "m4wrap",
        Builtin::Maketemp => "maketemp",
        Builtin::Mkstemp => "mkstemp",
        Builtin::Patsubst => "patsubst",
        Builtin::PopDef => "popdef",
        Builtin::PushDef => "pushdef",
        Builtin::Regexp => "regexp",
        Builtin::Shift => "shift",
        Builtin::SInclude => "sinclude",
        Builtin::Substr => "substr",
        Builtin::Syscmd => "syscmd",
        Builtin::Sysval => "sysval",
        Builtin::TraceOff => "traceoff",
        Builtin::TraceOn => "traceon",
        Builtin::Translit => "translit",
        Builtin::Undivert => "undivert",
        Builtin::Undefine => "undefine",
        Builtin::File => "__file__",
        Builtin::Line => "__line__",
        Builtin::Program => "__program__",
    }
}

fn builtin_by_name(name: &str) -> Option<Builtin> {
    Some(match name {
        "builtin" => Builtin::Builtin,
        "changecom" => Builtin::ChangeCom,
        "changequote" => Builtin::ChangeQuote,
        "debugfile" => Builtin::DebugFile,
        "debugmode" => Builtin::DebugMode,
        "decr" => Builtin::Decr,
        "define" => Builtin::Define,
        "defn" => Builtin::Defn,
        "divert" => Builtin::Divert,
        "divnum" => Builtin::DivNum,
        "dnl" => Builtin::Dnl,
        "dumpdef" => Builtin::DumpDef,
        "errprint" => Builtin::ErrPrint,
        "esyscmd" => Builtin::Esyscmd,
        "eval" => Builtin::Eval,
        "format" => Builtin::Format,
        "ifdef" => Builtin::IfDef,
        "ifelse" => Builtin::IfElse,
        "include" => Builtin::Include,
        "incr" => Builtin::Incr,
        "index" => Builtin::Index,
        "indir" => Builtin::Indir,
        "len" => Builtin::Len,
        "m4exit" => Builtin::M4Exit,
        "m4wrap" => Builtin::M4Wrap,
        "maketemp" => Builtin::Maketemp,
        "mkstemp" => Builtin::Mkstemp,
        "patsubst" => Builtin::Patsubst,
        "popdef" => Builtin::PopDef,
        "pushdef" => Builtin::PushDef,
        "regexp" => Builtin::Regexp,
        "shift" => Builtin::Shift,
        "sinclude" => Builtin::SInclude,
        "substr" => Builtin::Substr,
        "syscmd" => Builtin::Syscmd,
        "sysval" => Builtin::Sysval,
        "traceoff" => Builtin::TraceOff,
        "traceon" => Builtin::TraceOn,
        "translit" => Builtin::Translit,
        "undivert" => Builtin::Undivert,
        "undefine" => Builtin::Undefine,
        "__file__" => Builtin::File,
        "__line__" => Builtin::Line,
        "__program__" => Builtin::Program,
        _ => return None,
    })
}

fn find_subslice(hay: &[u8], needle: &[u8]) -> Option<usize> {
    if needle.is_empty() {
        return Some(0);
    }
    hay.windows(needle.len()).position(|w| w == needle)
}

fn parse_i64(s: &[u8]) -> Option<i64> {
    String::from_utf8_lossy(s).trim().parse().ok()
}

fn translit(input: &[u8], from: &[u8], to: &[u8]) -> Vec<u8> {
    let from = expand_translit_set(from);
    let to = expand_translit_set(to);
    // Build a 256-entry lookup table to replace O(|from|) linear scan per input byte.
    // Encoding: PASS = pass through unchanged, DEL = delete, else = replacement byte (as u16).
    const PASS: u16 = 0x100;
    const DEL: u16 = 0x200;
    let mut table = [PASS; 256];
    // Iterate in reverse order so that earlier (lower-index) occurrences of a duplicate
    // source byte win: last write wins, so iterating in reverse lets index 0 overwrite.
    for (i, &f) in from.iter().enumerate().rev() {
        table[f as usize] = match to.get(i) {
            Some(&rep) => rep as u16,
            None => DEL,
        };
    }
    let mut out = Vec::with_capacity(input.len());
    for &b in input {
        match table[b as usize] {
            PASS => out.push(b),
            DEL => {}
            rep => out.push(rep as u8),
        }
    }
    out
}

fn expand_translit_set(input: &[u8]) -> Vec<u8> {
    let mut out = Vec::new();
    let mut i = 0usize;
    let mut skip_endpoint = false;
    while i < input.len() {
        if skip_endpoint {
            skip_endpoint = false;
            if i + 2 < input.len() && input[i + 1] == b'-' {
                push_range(&mut out, input[i], input[i + 2], false);
                i += 2;
                skip_endpoint = true;
                continue;
            }
            i += 1;
            continue;
        }
        if i + 2 < input.len() && input[i + 1] == b'-' {
            push_range(&mut out, input[i], input[i + 2], true);
            i += 2;
            skip_endpoint = true;
        } else {
            out.push(input[i]);
            i += 1;
        }
    }
    out
}

fn push_range(out: &mut Vec<u8>, start: u8, end: u8, include_start: bool) {
    if start <= end {
        let first = if include_start {
            start
        } else {
            start.saturating_add(1)
        };
        for b in first..=end {
            out.push(b);
        }
    } else {
        let mut b = if include_start {
            start
        } else {
            start.saturating_sub(1)
        };
        loop {
            out.push(b);
            if b == end || b == 0 {
                break;
            }
            b = b.saturating_sub(1);
        }
    }
}

#[derive(Clone, Debug)]
struct RegexMatch {
    start: usize,
    end: usize,
    captures: Vec<Option<(usize, usize)>>,
}

#[derive(Clone, Debug)]
struct M4Regex {
    expr: RegexExpr,
    groups: usize,
}

impl M4Regex {
    fn parse(input: &[u8]) -> Self {
        let mut parser = RegexParser {
            input,
            pos: 0,
            next_group: 1,
        };
        let expr = parser.parse_expr();
        Self {
            expr,
            groups: parser.next_group.saturating_sub(1),
        }
    }

    fn find(&self, input: &[u8], start_at: usize) -> Option<RegexMatch> {
        for start in start_at..=input.len() {
            let captures = vec![None; self.groups + 1];
            let state = RegexState {
                pos: start,
                captures,
            };
            let mut matches = self.expr.match_at(input, state);
            if let Some(mut found) = matches.drain(..).next() {
                found.captures[0] = Some((start, found.pos));
                return Some(RegexMatch {
                    start,
                    end: found.pos,
                    captures: found.captures,
                });
            }
        }
        None
    }
}

#[derive(Clone, Debug)]
struct RegexParser<'a> {
    input: &'a [u8],
    pos: usize,
    next_group: usize,
}

impl<'a> RegexParser<'a> {
    fn parse_expr(&mut self) -> RegexExpr {
        let mut alternatives = Vec::new();
        loop {
            alternatives.push(self.parse_seq());
            if self.starts_alt() {
                self.pos += 2;
            } else {
                break;
            }
        }
        RegexExpr { alternatives }
    }

    fn parse_seq(&mut self) -> Vec<RegexPiece> {
        let mut pieces = Vec::new();
        while self.pos < self.input.len() && !self.starts_alt() && !self.starts_group_end() {
            let Some(atom) = self.parse_atom() else {
                break;
            };
            let quant = if self.pos < self.input.len() {
                match self.input[self.pos] {
                    b'*' => {
                        self.pos += 1;
                        RegexQuant::ZeroOrMore
                    }
                    b'+' => {
                        self.pos += 1;
                        RegexQuant::OneOrMore
                    }
                    b'?' => {
                        self.pos += 1;
                        RegexQuant::ZeroOrOne
                    }
                    _ => RegexQuant::One,
                }
            } else {
                RegexQuant::One
            };
            pieces.push(RegexPiece { atom, quant });
        }
        pieces
    }

    fn parse_atom(&mut self) -> Option<RegexAtom> {
        let b = *self.input.get(self.pos)?;
        match b {
            b'\\' if self.pos + 1 < self.input.len() => {
                let escaped = self.input[self.pos + 1];
                self.pos += 2;
                match escaped {
                    b'(' => {
                        let group = self.next_group;
                        self.next_group += 1;
                        let expr = self.parse_expr();
                        if self.starts_group_end() {
                            self.pos += 2;
                        }
                        Some(RegexAtom::Group(group, expr))
                    }
                    b')' | b'|' => None,
                    b'<' => Some(RegexAtom::WordStart),
                    b'>' => Some(RegexAtom::WordEnd),
                    b'w' => Some(RegexAtom::Word),
                    b'0'..=b'9' => Some(RegexAtom::BackRef((escaped - b'0') as usize)),
                    _ => Some(RegexAtom::Literal(escaped)),
                }
            }
            b'[' => Some(self.parse_class()),
            b'^' => {
                self.pos += 1;
                Some(RegexAtom::Start)
            }
            b'$' => {
                self.pos += 1;
                Some(RegexAtom::End)
            }
            b'.' => {
                self.pos += 1;
                Some(RegexAtom::Any)
            }
            _ => {
                self.pos += 1;
                Some(RegexAtom::Literal(b))
            }
        }
    }

    fn parse_class(&mut self) -> RegexAtom {
        self.pos += 1; // skip '['
        // Detect negation: [^...] means match any byte NOT in the set.
        let negate = self.pos < self.input.len() && self.input[self.pos] == b'^';
        if negate {
            self.pos += 1; // skip '^'
        }
        let mut bytes = Vec::new();
        let mut first = true;
        while self.pos < self.input.len() {
            // ']' closes the class, but ']' is literal when it is the very first
            // character after '[' (or '[^').  POSIX specifies this behaviour.
            if !first && self.input[self.pos] == b']' {
                self.pos += 1;
                break;
            }
            first = false;
            if self.pos + 2 < self.input.len()
                && self.input[self.pos + 1] == b'-'
                && self.input[self.pos + 2] != b']'
            {
                push_range(
                    &mut bytes,
                    self.input[self.pos],
                    self.input[self.pos + 2],
                    true,
                );
                self.pos += 3;
            } else {
                bytes.push(self.input[self.pos]);
                self.pos += 1;
            }
        }
        RegexAtom::Class(bytes, negate)
    }

    fn starts_alt(&self) -> bool {
        starts_with_at(self.input, self.pos, b"\\|")
    }

    fn starts_group_end(&self) -> bool {
        starts_with_at(self.input, self.pos, b"\\)")
    }
}

#[derive(Clone, Debug)]
struct RegexExpr {
    alternatives: Vec<Vec<RegexPiece>>,
}

impl RegexExpr {
    fn match_at(&self, input: &[u8], state: RegexState) -> Vec<RegexState> {
        let mut out = Vec::new();
        for seq in &self.alternatives {
            out.extend(match_regex_seq(seq, 0, input, state.clone()));
            if !out.is_empty() {
                break;
            }
        }
        out
    }
}

#[derive(Clone, Debug)]
struct RegexPiece {
    atom: RegexAtom,
    quant: RegexQuant,
}

#[derive(Clone, Debug)]
enum RegexAtom {
    Literal(u8),
    Any,
    Class(Vec<u8>, bool), // bytes, negate
    Word,
    WordStart,
    WordEnd,
    Start,
    End,
    Group(usize, RegexExpr),
    BackRef(usize),
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
enum RegexQuant {
    One,
    ZeroOrMore,
    OneOrMore,
    ZeroOrOne,
}

#[derive(Clone, Debug)]
struct RegexState {
    pos: usize,
    captures: Vec<Option<(usize, usize)>>,
}

fn match_regex_seq(
    seq: &[RegexPiece],
    idx: usize,
    input: &[u8],
    state: RegexState,
) -> Vec<RegexState> {
    if idx >= seq.len() {
        return vec![state];
    }
    let piece = &seq[idx];
    if piece.quant == RegexQuant::One {
        let mut out = Vec::new();
        for st in match_regex_atom(&piece.atom, input, state) {
            out.extend(match_regex_seq(seq, idx + 1, input, st));
        }
        return out;
    }
    if piece.quant == RegexQuant::ZeroOrOne {
        for st in match_regex_atom(&piece.atom, input, state.clone()) {
            let result = match_regex_seq(seq, idx + 1, input, st);
            if !result.is_empty() {
                return result;
            }
        }
        let mut zero = state;
        mark_empty_optional_group(&piece.atom, &mut zero);
        return match_regex_seq(seq, idx + 1, input, zero);
    }
    let min = match piece.quant {
        RegexQuant::One | RegexQuant::OneOrMore => 1,
        RegexQuant::ZeroOrMore | RegexQuant::ZeroOrOne => 0,
    };
    let max = match piece.quant {
        RegexQuant::One | RegexQuant::ZeroOrOne => 1,
        RegexQuant::ZeroOrMore | RegexQuant::OneOrMore => input.len().saturating_sub(state.pos) + 1,
    };
    let mut levels: Vec<Vec<RegexState>> = vec![vec![state]];
    for _ in 0..max {
        let mut next = Vec::new();
        for st in levels.last().into_iter().flatten() {
            for ns in match_regex_atom(&piece.atom, input, st.clone()) {
                if ns.pos != st.pos {
                    next.push(ns);
                }
            }
        }
        if next.is_empty() {
            break;
        }
        levels.push(next);
    }
    let highest = levels.len().saturating_sub(1);
    for count in (min..=highest).rev() {
        for st in &levels[count] {
            let result = match_regex_seq(seq, idx + 1, input, st.clone());
            if !result.is_empty() {
                return result;
            }
        }
    }
    Vec::new()
}

fn mark_empty_optional_group(atom: &RegexAtom, state: &mut RegexState) {
    if let RegexAtom::Group(group, _) = atom
        && *group < state.captures.len()
    {
        state.captures[*group] = Some((state.pos, state.pos));
    }
}

fn match_regex_atom(atom: &RegexAtom, input: &[u8], state: RegexState) -> Vec<RegexState> {
    match atom {
        RegexAtom::Literal(b) => {
            if state.pos < input.len() && input[state.pos] == *b {
                vec![RegexState {
                    pos: state.pos + 1,
                    captures: state.captures,
                }]
            } else {
                Vec::new()
            }
        }
        RegexAtom::Any => {
            if state.pos < input.len() {
                vec![RegexState {
                    pos: state.pos + 1,
                    captures: state.captures,
                }]
            } else {
                Vec::new()
            }
        }
        RegexAtom::Class(bytes, negate) => {
            let hit = state.pos < input.len() && bytes.contains(&input[state.pos]);
            let matched = if *negate {
                !hit && state.pos < input.len()
            } else {
                hit
            };
            if matched {
                vec![RegexState {
                    pos: state.pos + 1,
                    captures: state.captures,
                }]
            } else {
                Vec::new()
            }
        }
        RegexAtom::Word => {
            if state.pos < input.len() && is_name_char(input[state.pos]) {
                vec![RegexState {
                    pos: state.pos + 1,
                    captures: state.captures,
                }]
            } else {
                Vec::new()
            }
        }
        RegexAtom::WordStart => {
            if state.pos < input.len()
                && is_name_char(input[state.pos])
                && (state.pos == 0 || !is_name_char(input[state.pos - 1]))
            {
                vec![state]
            } else {
                Vec::new()
            }
        }
        RegexAtom::WordEnd => {
            if state.pos > 0
                && is_name_char(input[state.pos - 1])
                && (state.pos == input.len() || !is_name_char(input[state.pos]))
            {
                vec![state]
            } else {
                Vec::new()
            }
        }
        RegexAtom::Start => {
            if state.pos == 0 {
                vec![state]
            } else {
                Vec::new()
            }
        }
        RegexAtom::End => {
            if state.pos == input.len() {
                vec![state]
            } else {
                Vec::new()
            }
        }
        RegexAtom::Group(group, expr) => {
            let start = state.pos;
            expr.match_at(input, state)
                .into_iter()
                .map(|mut st| {
                    if *group < st.captures.len() {
                        st.captures[*group] = Some((start, st.pos));
                    }
                    st
                })
                .collect()
        }
        RegexAtom::BackRef(group) => {
            if let Some(Some((start, end))) = state.captures.get(*group) {
                let captured = &input[*start..*end];
                if starts_with_at(input, state.pos, captured) {
                    return vec![RegexState {
                        pos: state.pos + captured.len(),
                        captures: state.captures,
                    }];
                }
            }
            Vec::new()
        }
    }
}

fn expand_regex_replacement(
    replacement: &[u8],
    input: &[u8],
    captures: &[Option<(usize, usize)>],
    engine: &mut Engine,
) -> Vec<u8> {
    let mut out = Vec::new();
    let mut i = 0usize;
    while i < replacement.len() {
        if replacement[i] != b'\\' {
            out.push(replacement[i]);
            i += 1;
            continue;
        }
        if i + 1 >= replacement.len() {
            engine.warn("trailing \\ ignored in replacement");
            break;
        }
        let escaped = replacement[i + 1];
        match escaped {
            b'&' => {
                if let Some(Some((start, end))) = captures.first() {
                    out.extend_from_slice(&input[*start..*end]);
                }
            }
            b'0'..=b'9' => {
                let idx = (escaped - b'0') as usize;
                if let Some(Some((start, end))) = captures.get(idx) {
                    out.extend_from_slice(&input[*start..*end]);
                } else {
                    engine.warn(&format!("sub-expression {} not present", idx));
                }
            }
            b'\\' => out.push(b'\\'),
            other => out.push(other),
        }
        i += 2;
    }
    out
}

#[derive(Clone, Debug)]
struct ExprParser<'a> {
    input: &'a [u8],
    pos: usize,
    warn_single_eq: bool,
    suppress_errors: bool,
}

#[derive(Clone, Debug, PartialEq, Eq)]
struct EvalOutcome {
    value: i64,
    warn_single_eq: bool,
}

#[derive(Clone, Debug, PartialEq, Eq)]
struct EvalFailure {
    message: &'static str,
    fatal: bool,
}

impl EvalFailure {
    fn fatal(message: &'static str) -> Self {
        Self {
            message,
            fatal: true,
        }
    }

    fn nonfatal(message: &'static str) -> Self {
        Self {
            message,
            fatal: false,
        }
    }
}

fn eval_expr(s: &str) -> Result<EvalOutcome, EvalFailure> {
    let mut p = ExprParser {
        input: s.as_bytes(),
        pos: 0,
        warn_single_eq: false,
        suppress_errors: false,
    };
    let v = p.parse_or()?;
    p.skip_ws();
    if p.pos != p.input.len() {
        if p.starts_any(&[
            b"++".as_slice(),
            b"--".as_slice(),
            b"+=".as_slice(),
            b"-=".as_slice(),
            b"*=".as_slice(),
            b"/=".as_slice(),
            b"%=".as_slice(),
            b"|=".as_slice(),
            b"&=".as_slice(),
            b"^=".as_slice(),
            b"<<=".as_slice(),
            b">>=".as_slice(),
        ]) {
            Err(EvalFailure::fatal("invalid operator"))
        } else {
            Err(EvalFailure::nonfatal("bad expression"))
        }
    } else {
        Ok(EvalOutcome {
            value: wrap32(v),
            warn_single_eq: p.warn_single_eq,
        })
    }
}

impl<'a> ExprParser<'a> {
    fn skip_ws(&mut self) {
        while self.pos < self.input.len() && self.input[self.pos].is_ascii_whitespace() {
            self.pos += 1;
        }
    }

    fn eat(&mut self, s: &[u8]) -> bool {
        self.skip_ws();
        if starts_with_at(self.input, self.pos, s) {
            self.pos += s.len();
            true
        } else {
            false
        }
    }

    fn starts(&mut self, s: &[u8]) -> bool {
        self.skip_ws();
        starts_with_at(self.input, self.pos, s)
    }

    fn starts_any(&mut self, needles: &[&[u8]]) -> bool {
        self.skip_ws();
        needles
            .iter()
            .any(|needle| starts_with_at(self.input, self.pos, needle))
    }

    fn invalid_operator(&self) -> Result<i64, EvalFailure> {
        if self.suppress_errors {
            Ok(0)
        } else {
            Err(EvalFailure::fatal("invalid operator"))
        }
    }

    fn runtime_error(&self, message: &'static str) -> Result<i64, EvalFailure> {
        if self.suppress_errors {
            Ok(0)
        } else {
            Err(EvalFailure::nonfatal(message))
        }
    }

    fn parse_suppressed<F>(&mut self, f: F) -> Result<(), EvalFailure>
    where
        F: FnOnce(&mut Self) -> Result<i64, EvalFailure>,
    {
        let old = self.suppress_errors;
        self.suppress_errors = true;
        let result = f(self);
        self.suppress_errors = old;
        result.map(|_| ()).or(Ok(()))
    }

    fn parse_or(&mut self) -> Result<i64, EvalFailure> {
        let mut v = self.parse_and()?;
        while self.eat(b"||") {
            if v != 0 {
                self.parse_suppressed(Self::parse_and)?;
                v = 1;
            } else {
                let r = self.parse_and()?;
                v = (r != 0) as i64;
            }
        }
        Ok(v)
    }

    fn parse_and(&mut self) -> Result<i64, EvalFailure> {
        let mut v = self.parse_bitor()?;
        while self.eat(b"&&") {
            if v == 0 {
                self.parse_suppressed(Self::parse_bitor)?;
                v = 0;
            } else {
                let r = self.parse_bitor()?;
                v = (r != 0) as i64;
            }
        }
        Ok(v)
    }

    fn parse_bitor(&mut self) -> Result<i64, EvalFailure> {
        let mut v = self.parse_bitxor()?;
        loop {
            if self.starts(b"||") {
                return Ok(v);
            }
            if self.starts(b"|=") {
                return self.invalid_operator();
            }
            if !self.eat(b"|") {
                return Ok(v);
            }
            let r = self.parse_bitxor()?;
            v = wrap32((v as i32 | r as i32) as i64);
        }
    }

    fn parse_bitxor(&mut self) -> Result<i64, EvalFailure> {
        let mut v = self.parse_bitand()?;
        loop {
            if self.starts(b"^=") {
                return self.invalid_operator();
            }
            if !self.eat(b"^") {
                return Ok(v);
            }
            let r = self.parse_bitand()?;
            v = wrap32((v as i32 ^ r as i32) as i64);
        }
    }

    fn parse_bitand(&mut self) -> Result<i64, EvalFailure> {
        let mut v = self.parse_eq()?;
        loop {
            if self.starts(b"&&") {
                return Ok(v);
            }
            if self.starts(b"&=") {
                return self.invalid_operator();
            }
            if !self.eat(b"&") {
                return Ok(v);
            }
            let r = self.parse_eq()?;
            v = wrap32((v as i32 & r as i32) as i64);
        }
    }

    fn parse_eq(&mut self) -> Result<i64, EvalFailure> {
        let mut v = self.parse_rel()?;
        loop {
            if self.eat(b"==") {
                v = (v == self.parse_rel()?) as i64;
            } else if self.eat(b"!=") {
                v = (v != self.parse_rel()?) as i64;
            } else if self.eat(b"=") {
                self.warn_single_eq = true;
                v = (v == self.parse_rel()?) as i64;
            } else {
                return Ok(v);
            }
        }
    }

    fn parse_rel(&mut self) -> Result<i64, EvalFailure> {
        let mut v = self.parse_shift()?;
        loop {
            if self.eat(b"<=") {
                v = (v <= self.parse_shift()?) as i64;
            } else if self.eat(b">=") {
                v = (v >= self.parse_shift()?) as i64;
            } else if self.eat(b"<") {
                v = (v < self.parse_shift()?) as i64;
            } else if self.eat(b">") {
                v = (v > self.parse_shift()?) as i64;
            } else {
                return Ok(v);
            }
        }
    }

    fn parse_shift(&mut self) -> Result<i64, EvalFailure> {
        let mut v = self.parse_add()?;
        loop {
            if self.starts(b"<<=") || self.starts(b">>=") {
                return self.invalid_operator();
            } else if self.eat(b"<<") {
                let shift = (self.parse_add()? as u32) & 31;
                v = (v as i32).wrapping_shl(shift) as i64;
            } else if self.eat(b">>") {
                let shift = (self.parse_add()? as u32) & 31;
                v = (v as i32).wrapping_shr(shift) as i64;
            } else {
                return Ok(v);
            }
        }
    }

    fn parse_add(&mut self) -> Result<i64, EvalFailure> {
        let mut v = self.parse_mul()?;
        loop {
            if self.starts(b"+=") || self.starts(b"-=") {
                return self.invalid_operator();
            } else if self.eat(b"+") {
                v = (v as i32).wrapping_add(self.parse_mul()? as i32) as i64;
            } else if self.eat(b"-") {
                v = (v as i32).wrapping_sub(self.parse_mul()? as i32) as i64;
            } else {
                return Ok(v);
            }
        }
    }

    fn parse_mul(&mut self) -> Result<i64, EvalFailure> {
        let mut v = self.parse_power()?;
        loop {
            if self.starts(b"*=") || self.starts(b"/=") || self.starts(b"%=") {
                return self.invalid_operator();
            } else if self.starts(b"**") {
                return Ok(v);
            } else if self.eat(b"*") {
                v = (v as i32).wrapping_mul(self.parse_power()? as i32) as i64;
            } else if self.eat(b"/") {
                let r = self.parse_power()?;
                if r == 0 {
                    return self.runtime_error("divide by zero");
                }
                let lhs = v as i32;
                let rhs = r as i32;
                v = if lhs == i32::MIN && rhs == -1 {
                    i32::MIN as i64
                } else {
                    (lhs / rhs) as i64
                };
            } else if self.eat(b"%") {
                let r = self.parse_power()?;
                if r == 0 {
                    return self.runtime_error("modulo by zero");
                }
                let lhs = v as i32;
                let rhs = r as i32;
                v = if lhs == i32::MIN && rhs == -1 {
                    0
                } else {
                    (lhs % rhs) as i64
                };
            } else {
                return Ok(v);
            }
        }
    }

    fn parse_power(&mut self) -> Result<i64, EvalFailure> {
        let base = self.parse_unary()?;
        if self.eat(b"**") {
            let exponent = self.parse_power()?;
            if base == 0 && exponent == 0 {
                return self.runtime_error("divide by zero");
            }
            if exponent < 0 {
                return self.runtime_error("negative exponent");
            }
            Ok(pow32(base, exponent))
        } else {
            Ok(base)
        }
    }

    fn parse_unary(&mut self) -> Result<i64, EvalFailure> {
        if self.starts(b"++") || self.starts(b"--") || self.starts(b"+=") || self.starts(b"-=") {
            return self.invalid_operator();
        }
        if self.eat(b"+") {
            self.parse_unary().map(wrap32)
        } else if self.eat(b"-") {
            Ok((0i32).wrapping_sub(self.parse_unary()? as i32) as i64)
        } else if self.eat(b"!") {
            Ok((self.parse_unary()? == 0) as i64)
        } else if self.eat(b"~") {
            Ok(!(self.parse_unary()? as i32) as i64)
        } else {
            self.parse_primary()
        }
    }

    fn parse_primary(&mut self) -> Result<i64, EvalFailure> {
        self.skip_ws();
        if self.eat(b"(") {
            let v = self.parse_or()?;
            if !self.eat(b")") {
                return Err(EvalFailure::nonfatal("bad expression"));
            }
            return Ok(v);
        }
        self.skip_ws();
        if self.pos >= self.input.len() {
            return Err(EvalFailure::nonfatal("bad expression"));
        }
        if self.input[self.pos].is_ascii_alphabetic() || self.input[self.pos] == b'_' {
            while self.pos < self.input.len()
                && (self.input[self.pos].is_ascii_alphanumeric() || self.input[self.pos] == b'_')
            {
                self.pos += 1;
            }
            return Err(EvalFailure::nonfatal("bad expression (bad input)"));
        }
        if self.input[self.pos].is_ascii_digit() {
            parse_eval_number(self.input, &mut self.pos)
        } else {
            Err(EvalFailure::nonfatal("bad expression"))
        }
    }
}

fn wrap32(v: i64) -> i64 {
    (v as i32) as i64
}

fn pow32(base: i64, exponent: i64) -> i64 {
    let mut result = 1i32;
    let mut factor = base as i32;
    let mut exp = exponent as u64;
    while exp != 0 {
        if exp & 1 != 0 {
            result = result.wrapping_mul(factor);
        }
        exp >>= 1;
        if exp != 0 {
            factor = factor.wrapping_mul(factor);
        }
    }
    result as i64
}

fn parse_eval_number(input: &[u8], pos: &mut usize) -> Result<i64, EvalFailure> {
    let start = *pos;
    if starts_with_at(input, start, b"0x") || starts_with_at(input, start, b"0X") {
        *pos += 2;
        let digits = *pos;
        while *pos < input.len() && input[*pos].is_ascii_hexdigit() {
            *pos += 1;
        }
        if digits == *pos {
            return Err(EvalFailure::nonfatal("invalid number"));
        }
        let text = String::from_utf8_lossy(&input[digits..*pos]);
        let value =
            i64::from_str_radix(&text, 16).map_err(|_| EvalFailure::nonfatal("invalid number"))?;
        return Ok(wrap32(value));
    }
    if starts_with_at(input, start, b"0b") || starts_with_at(input, start, b"0B") {
        *pos += 2;
        let digits = *pos;
        while *pos < input.len() && input[*pos].is_ascii_alphanumeric() {
            *pos += 1;
        }
        let text = String::from_utf8_lossy(&input[digits..*pos]);
        if text.is_empty() || !text.bytes().all(|b| b == b'0' || b == b'1') {
            return Err(EvalFailure::nonfatal("invalid number"));
        }
        let value =
            i64::from_str_radix(&text, 2).map_err(|_| EvalFailure::nonfatal("invalid number"))?;
        return Ok(wrap32(value));
    }
    if starts_with_at(input, start, b"0r") || starts_with_at(input, start, b"0R") {
        *pos += 2;
        let radix_start = *pos;
        while *pos < input.len() && input[*pos].is_ascii_digit() {
            *pos += 1;
        }
        if radix_start == *pos || *pos >= input.len() || input[*pos] != b':' {
            return Err(EvalFailure::nonfatal("invalid number"));
        }
        let radix_text = String::from_utf8_lossy(&input[radix_start..*pos]);
        let radix = radix_text
            .parse::<u32>()
            .map_err(|_| EvalFailure::nonfatal("invalid number"))?;
        *pos += 1;
        let digits = *pos;
        while *pos < input.len() && input[*pos].is_ascii_alphanumeric() {
            *pos += 1;
        }
        let text = String::from_utf8_lossy(&input[digits..*pos]);
        if text.is_empty() {
            return Err(EvalFailure::nonfatal("invalid number"));
        }
        return parse_eval_digits(&text, radix).map(wrap32);
    }

    while *pos < input.len() && input[*pos].is_ascii_alphanumeric() {
        *pos += 1;
    }
    let text = String::from_utf8_lossy(&input[start..*pos]);
    if text.len() > 1 && text.starts_with('0') {
        parse_eval_digits(&text, 8).map(wrap32)
    } else {
        text.parse::<i64>()
            .map(wrap32)
            .map_err(|_| EvalFailure::nonfatal("invalid number"))
    }
}

fn parse_eval_digits(text: &str, radix: u32) -> Result<i64, EvalFailure> {
    if radix == 1 {
        let bytes = text.as_bytes();
        if bytes.is_empty() || bytes[0] != b'0' || !bytes[1..].iter().all(|b| *b == b'1') {
            return Err(EvalFailure::nonfatal("invalid number"));
        }
        return Ok((bytes.len() - 1) as i64);
    }
    if !(2..=36).contains(&radix) {
        return Err(EvalFailure::nonfatal("invalid number"));
    }
    let mut value = 0i32;
    for b in text.bytes() {
        let digit = match b {
            b'0'..=b'9' => (b - b'0') as u32,
            b'a'..=b'z' => (b - b'a' + 10) as u32,
            b'A'..=b'Z' => (b - b'A' + 10) as u32,
            _ => return Err(EvalFailure::nonfatal("invalid number")),
        };
        if digit >= radix {
            return Err(EvalFailure::nonfatal("invalid number"));
        }
        value = value.wrapping_mul(radix as i32).wrapping_add(digit as i32);
    }
    Ok(value as i64)
}

fn format_radix(value: i64, radix: u32, width: usize) -> String {
    let negative = value < 0;
    let magnitude = if negative {
        (0i32).wrapping_sub(value as i32) as u32
    } else {
        value as u32
    };
    let mut digits = if radix == 1 {
        let mut s = String::from("0");
        s.extend(std::iter::repeat_n('1', magnitude as usize));
        s
    } else {
        let mut n = magnitude;
        let mut chars = Vec::new();
        if n == 0 {
            chars.push('0');
        } else {
            while n != 0 {
                let d = (n % radix) as u8;
                chars.push(if d < 10 {
                    (b'0' + d) as char
                } else {
                    (b'a' + d - 10) as char
                });
                n /= radix;
            }
            chars.reverse();
        }
        chars.into_iter().collect()
    };
    if digits.len() < width {
        let mut padded = String::with_capacity(width);
        padded.extend(std::iter::repeat_n('0', width - digits.len()));
        padded.push_str(&digits);
        digits = padded;
    }
    if negative {
        let mut signed = String::with_capacity(digits.len() + 1);
        signed.push('-');
        signed.push_str(&digits);
        signed
    } else {
        digits
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn run(input: &[u8]) -> Vec<u8> {
        let opts = Options {
            actions: Vec::new(),
            include_paths: Vec::new(),
            prefix_builtins: false,
            quiet: false,
            fatal_warnings: 0,
            nesting_limit: 0,
            synclines: false,
            traditional: false,
            debug_flags: None,
            warn_macro_sequence: false,
            test_mode: true,
            safe_mode: false,
            program_name: "m4".to_string(),
            program_path: "m4".to_string(),
            show_help: false,
            show_version: false,
        };
        let mut e = Engine::new(&opts);
        let mut out = Vec::new();
        e.expand_emit(input, &mut out).unwrap();
        out
    }

    #[test]
    fn define_and_expand() {
        assert_eq!(run(b"define(`x', `hello')x\n"), b"hello\n");
    }

    #[test]
    fn args_and_len() {
        assert_eq!(
            run(b"define(`wrap', `<$1,$2>')wrap(`a', `bc')\n"),
            b"<a,bc>\n"
        );
        assert_eq!(run(b"len(`abc')\n"), b"3\n");
    }

    #[test]
    fn arithmetic_eval() {
        assert_eq!(eval_expr("1 + 2 * 3").unwrap().value, 7);
        assert_eq!(eval_expr("(1 + 2) * 3 == 9").unwrap().value, 1);
        assert_eq!(eval_expr("2 ** 3 ** 2").unwrap().value, 512);
        assert_eq!(eval_expr("2 || 1 / 0").unwrap().value, 1);
        assert_eq!(eval_expr("0 && 1 % 0").unwrap().value, 0);
    }

    #[test]
    fn regexp_and_patsubst() {
        assert_eq!(run(b"regexp(`GNUs not Unix', `\\<[a-z]\\w+')\n"), b"5\n");
        assert_eq!(
            run(b"regexp(`abc', `\\(b\\)', `\\\\\\10\\a')\n"),
            b"\\b0a\n"
        );
        assert_eq!(
            run(b"patsubst(`GNUs not Unix', `\\w+', `(\\&)')\n"),
            b"(GNUs) (not) (Unix)\n"
        );
    }

    #[test]
    fn mkstemp_output_is_not_rescanned() {
        let out = run(b"define(`foo', `BAD')define(`f', maketemp(`foo-XX'))f\n");
        assert!(out.starts_with(b"foo-"));
        assert!(!out.windows(3).any(|w| w == b"BAD"));
        let path = String::from_utf8_lossy(&out).trim().to_string();
        let _ = fs::remove_file(path);
    }

    #[test]
    fn generated_text_preserves_token_inhibition() {
        assert_eq!(
            run(b"define(`macro', `m')macro(`m')macro\nmacro(`m')`'macro\n"),
            b"mmacro\nmm\n"
        );
    }

    #[test]
    fn dnl_in_collected_arguments_discards_newline() {
        assert_eq!(run(b"define(`x', `a'dnl\n`b')x\n"), b"ab\n");
    }

    #[test]
    fn regex_negated_class() {
        // [^aeiou] must match consonants, not vowels.
        assert_eq!(run(b"patsubst(`hello', `[^aeiou]', `*')\n"), b"*e**o\n");
        // [^ ] splits on spaces: each non-space run is wrapped.
        assert_eq!(
            run(b"patsubst(`hello world foo', `[^ ]+', `(\\&)')\n"),
            b"(hello) (world) (foo)\n"
        );
        // Basic regexp with negated class returns position of first matching char.
        assert_eq!(run(b"regexp(`hello', `[^h]+')\n"), b"1\n");
        // Negated class in character class with range.
        assert_eq!(run(b"regexp(`hello world', `[^aeiou]+')\n"), b"0\n");
    }
}
