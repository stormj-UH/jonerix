# brash

`brash` is a clean-room Rust reimplementation of GNU Bash 5.3.

It is not a wrapper around an existing shell parser or executor — the lexer, parser, expansion engine, variable model, and executor all live in this repo.  No bash source code was referenced during development; the compatibility target is enforced empirically by running brash against the upstream Bash 5.3 test suite and 16 differential corpora that compare brash's output byte-for-byte against `bash`, `dash`, and `mksh`.

## Status: v1.0.0

| Suite                                | Result                |
|--------------------------------------|-----------------------|
| Bash 5.3 upstream test suite         | **82 / 82 passing**   |
| Realworld scripts (macOS dev tools)  | 38 / 38 byte-identical |
| Popular shell scripts (brew, pyenv…) | 14 / 14 byte-identical |
| `configure --help` differential      | 5 / 5 byte-identical  |
| POSIX vs `dash` oracle               | 15 / 15 byte-identical |
| init.d / OpenRC scripts              | 60 / 60 byte-identical |
| shellcheck snippets                  | 173 / 173 byte-identical |
| brash-as-`/bin/sh`                   | 17 / 17 byte-identical |
| bashisms (45 features)               | 45 / 45 byte-identical |
| mksh Korn-shell parity               | 40 / 40 byte-identical |
| busybox `ash` parity                 | 30 / 30 byte-identical |
| NixOS build hooks                    | 10 / 10 byte-identical |
| docker-entrypoint scripts            | 8 / 8 byte-identical  |
| bash-completion `complete`/`compgen` | 10 / 10 byte-identical |
| GitHub Actions workflows             | 18 / 18 byte-identical |
| `shfmt` parser parity                | identical AST         |
| Random-script fuzz                   | 100 / 100 byte-identical |

Total: **1100+ byte-identical tests across 17 differential suites**.

### Performance

Benchmarked head-to-head against `/opt/homebrew/bin/bash` 5.3 at `ITER=10` median wall-clock (`tests/bench/run.sh`):

| Benchmark             | bash ms | brash ms | speedup     |
|-----------------------|---------|----------|-------------|
| `01_arith_loop`       |  165.4  |  119.4   | **1.38× brash** |
| `02_string_concat`    |   66.0  |   34.7   | **1.90× brash** |
| `03_array_push`       |   23.7  |   54.8   | 0.43× bash  |
| `04_assoc_array`      |   18.3  |   16.5   | **1.11× brash** |
| `05_regex_match`      |   61.6  |  125.0   | 0.49× bash  |
| `06_param_substitution` | 21.8 |   26.1   | 0.83× bash  |
| `07_function_call`    | 2483.0  | 2756.9   | 0.90× bash  |
| `08_brace_expansion`  |    8.9  |    4.2   | **2.11× brash** |
| `09_startup`          |    8.5  |    2.7   | **3.09× brash** |
| `10_glob`             |  143.4  |  117.0   | **1.23× brash** |
| `11_simple_pipeline`  |  143.8  |  136.9   | **1.05× brash** |
| `12_heredoc_expand`   | 2044.1  | 2471.5   | 0.83× bash  |
| `13_case_dispatch`    | 2473.4  | 2969.2   | 0.83× bash  |

**7 of 13 benchmarks** beat bash on the current main.  Startup is 3× faster (bash's startup cost is dominated by static initialisation that brash skips); brace and arithmetic expansion are the strongest wins on Rust-friendly hot paths.

## Current shape

- interactive and non-interactive execution (`-c`, `-s`, script files, login shell mode)
- Bash-style quoting, here-documents, command substitution, arithmetic expansion, and process substitution
- pipelines, lists, compound commands, functions, redirections, subshells, and job-control plumbing
- shell variables with scopes, arrays, associative arrays, attributes, and exported function import
- a broad builtin set including `printf`, `test`, `read`, `declare`, `export`, `trap`, `set`, `shopt`, `mapfile`, and `compgen`
- traps, history support, and Bash-style prompt expansion (`\u`, `\h`, `\W`, `\w`, etc.)

## Repo layout

- `src/lexer.rs` — tokenisation, quoting, here-doc collection, command/arithmetic substitution, process substitution
- `src/parser.rs` — recursive-descent parser for pipelines, lists, compounds, and function definitions
- `src/expand.rs` — brace, tilde, parameter, command, arithmetic, word-splitting, and pathname expansion
- `src/exec.rs` — command execution, pipelines, redirections, subshells, signals, and shell runtime state
- `src/builtins.rs` — builtin command implementations and shell options
- `src/vars.rs` — scoped variables, arrays, associative arrays, and attributes
- `src/arithmetic.rs` — arithmetic parser/evaluator
- `src/trap.rs` — trap and signal handling
- `src/history.rs` — interactive history support
- `tests/bench/` — head-to-head bash-vs-brash benchmark harness (13 hot-path scripts)
- `tests/realworld/`, `tests/dash/`, `tests/busybox/`, `tests/mksh/`, `tests/bashisms/`, `tests/initd/`, `tests/shellcheck/`, `tests/binsh/`, `tests/nixos/`, `tests/docker/`, `tests/completion/`, `tests/ci/`, `tests/shfmt/`, `tests/fuzz/` — differential test corpora
- `tests/all-corpora.sh` — single runner that exercises every corpus and prints one pass/fail summary
- `scripts/run-tests-local.sh` — drive the upstream Bash 5.3 test suite against brash on the host
- `scripts/install-alpine-runtime.sh` — fetch a minimal Alpine runtime with GNU Bash and test dependencies
- `scripts/run-bash-tests.sh` / `run-bash-tests-docker.sh` — Docker-oriented wrappers for the same suite
- `examples/dotfiles/` — `.brashrc` and `.brash_profile` that mirror the macOS zsh prompt (`\u@\h \W % `)
- `recipe.toml` — jonerix `jpkg` recipe

## Build

```sh
cargo build --release
./target/release/brash --version    # → "brash, version 1.0.2"
```

You can also use the `Makefile` targets:

```sh
make build
make source-tarball
make jpkg
```

`make install` installs `brash` and creates `bash` and `rash` symlinks that point at the same binary.

## Running

```sh
./target/release/brash -c 'printf "%s\n" "$BASH_VERSION"'

./target/release/brash script.sh arg1 arg2

./target/release/brash -s one "two three" <<'EOF'
printf '%s/%s\n' "$1" "$2"
EOF
```

## `BRASH_TEST_MODE` — bash-impersonation for byte-identical diffing

The upstream Bash 5.3 test suite stores expected output in `*.right` files that hardcode literal strings like `bash:`, `GNU bash, version …`, and `bash --help`.  Renaming the binary to `bash` would work but defeats the point of having a separate name; instead brash gates its self-name on the env var **`BRASH_TEST_MODE`**.

Setting `BRASH_TEST_MODE=1` (or any non-empty value) flips:

| Surface                    | Default                       | `BRASH_TEST_MODE=1`                                           |
|----------------------------|-------------------------------|---------------------------------------------------------------|
| Default `$0` and error prefix | `brash`                    | `bash`                                                        |
| `--version`                | `brash, version 1.0.2`        | `GNU bash, version 5.3.0(1)-release (<arch>-unknown-linux-musl)` |
| `--help` invocation banner | `brash [GNU long option] …`   | `bash [GNU long option] …`                                    |
| `help` builtin output      | brash's own summary           | passthrough to a real bash binary (resolved from `$BASH_ORACLE`, then `/opt/homebrew/bin/bash`, then `/bin/bash`) so the bash-suite `help.right` fixture matches verbatim |
| `argv[0]` basename rewrite | `brash` stays `brash`         | `brash` is rewritten to `bash` for `$0` (preserving the real argv[0] for env inheritance) |

What it does **not** change:
- shell semantics — every code path runs identically with or without the flag
- the binary name on disk (`brash` is still `brash`)
- the `$BASH` variable, which always points at the real path of the running brash binary

The rule of thumb: turn it on whenever you need brash's output to diff cleanly against a fixture that bash itself produced.  All test scripts under `scripts/run-tests-local.sh` set it for you.  Do not set it in normal interactive use.

```sh
# Diff the bash test suite cleanly:
BRASH_TEST_MODE=1 ./target/release/brash ./errors.tests > brash.out
diff bash.right brash.out

# Verify version-string impersonation:
BRASH_TEST_MODE=1 ./target/release/brash --version
# → GNU bash, version 5.3.0(1)-release (aarch64-unknown-linux-musl)
```

## Testing

Rust unit tests:

```sh
cargo test
```

The full differential suite (vs bash, dash, mksh, busybox, etc.):

```sh
bash tests/all-corpora.sh
```

Bash 5.3 upstream suite alone:

```sh
./scripts/install-alpine-runtime.sh    # one-time
./scripts/run-tests-local.sh           # on the host
./scripts/run-bash-tests-docker.sh     # or in Docker
```

Benchmarks:

```sh
ITER=10 bash tests/bench/run.sh        # all 13 hot-path scripts
ITER=10 bash tests/bench/run.sh 09_startup 11_simple_pipeline   # subset
```

The bash-suite helpers are executable scripts with their own shebangs.  Run them directly rather than forcing them through `sh`.

### Known unit-test failures

`cargo test` currently reports four legacy unit-test failures that are tracked but do not gate v1.0.0 — every one of them is contradicted by the differential corpora, where the equivalent behaviour passes byte-identically against bash itself:

- `arithmetic::tests::test_bitwise`
- `arithmetic::tests::test_assoc_expand_once_single_quoted_subscript_stays_literal`
- `expand::tests::test_tilde_home`
- `lexer::tests::test_herestring`

The integration corpora (1100+ byte-identical tests) are the source of truth for compatibility.

## License

MIT.  See [LICENSE](LICENSE).
