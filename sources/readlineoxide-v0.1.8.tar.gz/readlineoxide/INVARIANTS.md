# readlineoxide invariant ledger

Copyright (c) 2026 Jon-Erik G. Storm, Inc., a California Corporation, doing
business as LAVA GOAT SOFTWARE.

This ledger records the invariants that serious modules must maintain. Public C
entry points are the messy shell: they accept raw pointers, raw Unix bytes,
process globals, callbacks, environment variables, and filesystem paths. The
internal core should immediately convert that input into owned bytes, checked
indexes, registered handles, and bounded Rust collections.

## FFI boundary and allocation

- C string inputs are either null-checked at the public boundary or documented as
  required non-null before dereference.
- Public headers and exported symbols use the documented Readline ABI shape;
  compatibility cannot depend on callers ignoring mismatched return types or
  command-function arguments.
- C strings that represent filenames or inputrc paths stay raw Unix bytes. They
  must not pass through lossy UTF-8 conversion.
- Memory returned to callers is allocated with the same allocator family that
  `rl_free()` and public free functions expect.
- Public globals that may point at caller-owned storage are never freed unless
  their address is present in the owned-global-string registry.
- Early returns after allocation must free any temporary C allocation owned by
  the callee before returning.
- `struct readline_state` values passed to `rl_save_state()` own a stable opaque
  slot handle. Restores must look up the caller's slot rather than consuming a
  process-global snapshot.

## Line buffer and editor state

- `rl_line_buffer` is null or points to an owned, NUL-terminated allocation with
  at least `rl_line_buffer_len` bytes of capacity.
- `0 <= rl_point <= rl_end`, and `rl_end` is the byte length of the current line.
- Public editing functions must restore the point/end invariant before return,
  even when indexes are negative, inverted, or beyond the current line.
- Internal line editing operates on owned `Vec<u8>` values. Raw globals are only
  synchronized at the boundary before or after command dispatch.
- Panic while holding editor state must not expose a partially updated raw line
  buffer; mutations should be staged in owned values where possible.

## History store and history files

- The history vector owns every `HIST_ENTRY` it stores. `history_get()` and list
  APIs expose borrowed raw pointers that remain valid until the next mutating
  history operation.
- `history_length`, `history_offset`, and `history_max_entries` are mirrors of
  the mutex-protected `History` struct and are synchronized after mutation.
- `history_offset <= entries.len()` after every traversal, removal, restore, or
  stifle/unstifle operation.
- History line and timestamp bytes are preserved exactly except for documented
  newline stripping while reading files.
- With `history_multiline_entries` enabled, timestamp lines delimit logical
  entries. Reads and truncation operate on logical entries and must not split a
  multiline command between two history entries.
- When `history_quotes_inhibit_expansion` is enabled, both literal single quotes
  in the input and an initial single-quote `history_quoting_state` inhibit
  history expansion until quote state changes.
- History filenames are raw byte paths. Missing-file and filesystem errors
  return the platform errno value when available.

## Keymaps and funmap

- Public keymap pointers are valid only if they are built-in handles or appear in
  the keymap registry.
- `rl_set_keymap()` rejects foreign handles by leaving the active keymap
  unchanged.
- `rl_free_keymap()` must not free built-in, foreign, or already-freed handles.
- Key binding lookup returns the correct binding type: function, keymap, macro,
  or no binding.
- Registry locks are not held while calling public callbacks or doing any work
  that may reenter keymap APIs.
- During bound key dispatch, `rl_dispatching`, `rl_executing_key`,
  `rl_executing_keyseq`, and `rl_key_sequence_length` describe the command being
  invoked before user callbacks run.
- `rl_arrow_keys()` consumes exactly one byte after the escape prefix and maps
  documented arrow suffixes to history and character movement commands.
- `rl_bracketed_paste_begin()` inserts all input bytes until the terminal
  bracketed-paste end marker, or all bytes read before EOF if the marker is
  missing.

## Completion

- Completion generator mutexes protect only cached generator state: key bytes and
  match vectors.
- User hooks, dequoting hooks, directory hooks, rewrite hooks, ignore hooks,
  quoting hooks, and filesystem scans run without holding generator mutexes.
- Completion candidates are owned byte strings until converted to C allocations
  for the public ABI.
- `completion-ignore-case` and `completion-map-case` affect comparison only; they
  do not rewrite candidate bytes.
- Directory marking follows the configured public variables and must not append
  directory markers to non-directories.
- Filename quoting is applied during completion insertion only when filename or
  full quoting is desired and the candidate contains a byte from
  `rl_filename_quote_characters`. Raw generator APIs return unquoted candidates.
- Completion entry points reset per-attempt public completion state before
  calling application completers; application hooks may then opt back into
  filename or full quoting for that attempt.

## Inputrc

- `rl_read_init_file()` accepts null, explicit C filenames, `$INPUTRC`, `$HOME`,
  `$include`, and leading-tilde paths as raw byte paths.
- Include recursion is bounded by `inputrc_depth`; every successful increment is
  restored before return on success, parse error, missing file, or early failure.
- Conditional frames restore stack balance: stray `$else` and `$endif` mark the
  file status as failed, and unclosed `$if` fails at EOF.
- `rl_variable_bind()` returns success only for known variables it handles.
  Unknown variables are an explicit failure.

## Callback and blocking readline

- Blocking `readline()` and callback mode initialize inputrc state before first
  use.
- `rl_done` is honored as an accept-line signal during blocking line reads, and
  stale restored `rl_done` state must not terminate the next read.
- Callback state owns its prompt copy and line buffer while installed, and
  handler removal frees that ownership exactly once.
- User handlers are called after the accepted line is detached from callback
  mutable state.

## Display and terminal hooks

- `rl_redisplay()` is the built-in redisplay routine and writes only through the
  configured output adapter.
- `rl_forced_update_display()` dispatches through the public
  `rl_redisplay_function` hook so callers that replace the redisplay routine see
  the forced-refresh ABI event.
- `rl_show_char()` writes its visible character representation to `rl_outstream`
  and returns the number of bytes emitted, including control/meta prefixes.
- `rl_set_paren_blink_timeout()` returns the previous timeout and ignores
  negative replacement values.
- Terminal prep/deprep hooks may be unset; prep state is mirrored by
  `RL_STATE_TERMPREPPED` before returning to C.

## Panic and drop audit

- Mutex poisoning is recovered with `into_inner()` because ABI callers cannot
  handle Rust panics. New code should still avoid panicking inside locks.
- `Drop` implementations that free C allocations must tolerate null pointers and
  partially initialized values.
- New code should prefer checked conversions, saturating arithmetic, and explicit
  error returns over `unwrap()`, `expect()`, or panic-based control flow.
- Any new unsafe block should include nearby `SAFETY:` bullets, and each bullet
  should be backed by a type invariant, constructor check, assertion, or focused
  test where practical.
