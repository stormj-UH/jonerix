#ifndef READLINEOXIDE_KEYMAPS_H
#define READLINEOXIDE_KEYMAPS_H

#ifdef __cplusplus
extern "C" {
#endif

typedef void *Keymap;

#define ISFUNC 0
#define ISKMAP 1
#define ISMACR 2

extern Keymap emacs_standard_keymap;
extern Keymap emacs_meta_keymap;
extern Keymap emacs_ctlx_keymap;
extern Keymap vi_movement_keymap;
extern Keymap vi_insertion_keymap;

#ifdef __cplusplus
}
#endif

#endif
