#ifndef READLINEOXIDE_CHARDEFS_H
#define READLINEOXIDE_CHARDEFS_H

#define RUBOUT 0x7f
#define ABORT_CHAR 0x07
#define NEWLINE '\n'
#define RETURN '\r'

#ifndef CTRL_CHAR
#define CTRL_CHAR(c) (((unsigned char)(c) < 0x20) || ((unsigned char)(c) == RUBOUT))
#endif

#ifndef UNCTRL
#define UNCTRL(c) ((unsigned char)(c) ^ 0x40)
#endif

#endif
