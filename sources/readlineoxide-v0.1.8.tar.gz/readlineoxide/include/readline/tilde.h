#ifndef READLINEOXIDE_TILDE_H
#define READLINEOXIDE_TILDE_H

#ifdef __cplusplus
extern "C" {
#endif

extern char **tilde_additional_prefixes;
extern char **tilde_additional_suffixes;
extern char *(*tilde_expansion_preexpansion_hook)(char *);
extern char *(*tilde_expansion_failure_hook)(char *);

char *tilde_expand(const char *filename);
char *tilde_expand_word(const char *filename);

#ifdef __cplusplus
}
#endif

#endif
