#!/bin/sh
set -eu

script_dir=$(dirname "$0")
repo=$(CDPATH= cd "$script_dir/.." && pwd)
build_dir=$repo/target/release
gnu_src=${GNU_READLINE_SRC:-}
tmp=${TMPDIR:-/tmp}/readlineoxide-gnu-examples-$$
cc=${CC:-cc}

cleanup() {
    rm -rf "$tmp"
}
trap cleanup EXIT HUP INT TERM

if [ -z "$gnu_src" ] || [ ! -d "$gnu_src/examples" ]; then
    printf '%s\n' "GNU_READLINE_SRC must point to an extracted GNU Readline tree" >&2
    exit 2
fi

mkdir -p "$tmp"
cargo build --release --locked

compile_common() {
    src=$1
    extra=$2
    out=$tmp/${src%.c}
    "$cc" -std=gnu89 $extra -I "$repo/include" -I "$repo/include/readline" \
        -I "$gnu_src" -L "$build_dir" -Wl,-rpath,"$build_dir" \
        "$gnu_src/examples/$src" -lreadline -lhistory -o "$out"
}

compile_common rlversion.c "-include unistd.h -include string.h -include stdlib.h"
compile_common histexamp.c "-include unistd.h -include string.h -include stdlib.h"
compile_common rlbasic.c "-include unistd.h -include string.h -include stdlib.h"
compile_common rlcat.c "-include unistd.h -include string.h -include stdlib.h"
compile_common rlevent.c "-include string.h -include stdlib.h"
compile_common rl-callbacktest.c "-include unistd.h -include string.h -include stdlib.h"
compile_common rl-timeout.c "-include unistd.h -include string.h -include stdlib.h"
compile_common rlkeymaps.c "-include unistd.h -include string.h -include stdlib.h"
compile_common hist_erasedups.c "-include unistd.h -include string.h -include stdlib.h"
compile_common hist_purgecmd.c "-include unistd.h -include string.h -include stdlib.h"

run() {
    DYLD_LIBRARY_PATH=$build_dir LD_LIBRARY_PATH=$build_dir "$@"
}

run "$tmp/rlversion" | grep '8.3' >/dev/null
printf 'hello\nexit\n' | run "$tmp/rlbasic" >/dev/null
printf 'alpha\nlist\nquit\n' | run "$tmp/histexamp" >/dev/null
run "$tmp/rlkeymaps"
printf 'first\nsecond\nexit\n' | run "$tmp/rl-callbacktest" >/dev/null
printf 'ready\n' | run "$tmp/rl-timeout" readline1 1 >/dev/null

hist=$tmp/history-file
printf 'one\ntwo\none\nthree\n' > "$hist"
run "$tmp/hist_erasedups" "$hist"
if [ "$(grep -c '^one$' "$hist")" -ne 1 ]; then
    printf '%s\n' "hist_erasedups did not remove duplicate entries" >&2
    exit 1
fi
run "$tmp/hist_purgecmd" -f "$hist" two
if grep '^two$' "$hist" >/dev/null; then
    printf '%s\n' "hist_purgecmd did not purge the command" >&2
    exit 1
fi

printf '%s\n' "GNU Readline examples: ok"
