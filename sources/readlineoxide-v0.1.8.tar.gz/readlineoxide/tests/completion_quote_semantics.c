#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <readline/readline.h>

static const char *active_input;
static int input_pos;
static char captured_text[128];
static int captured_start;
static int captured_end;
static int quote_hook_calls;

static void
fail(const char *message)
{
    fprintf(stderr, "completion_quote_semantics: %s\n", message);
    exit(1);
}

static int
test_getc(FILE *stream)
{
    (void)stream;
    if (active_input[input_pos] == '\0')
        return EOF;
    return active_input[input_pos++];
}

static char *
read_test_line(const char *input)
{
    active_input = input;
    input_pos = 0;
    rl_getc_function = test_getc;
    return readline("");
}

static char **
capture_completion(const char *text, int start, int end)
{
    snprintf(captured_text, sizeof(captured_text), "%s", text);
    captured_start = start;
    captured_end = end;
    rl_attempted_completion_over = 1;
    return NULL;
}

static int
quoted_space(char *line, int index)
{
    quote_hook_calls++;
    if (index > 0 && line[index - 1] == '\\')
        return 1;
    return 0;
}

static void
expect_capture(const char *message, const char *input, const char *text,
    int start, int end)
{
    char *line;

    captured_text[0] = '\0';
    captured_start = -1;
    captured_end = -1;
    rl_attempted_completion_over = 0;
    line = read_test_line(input);
    free(line);
    if (strcmp(captured_text, text) != 0) {
        fprintf(stderr, "completion_quote_semantics: %s: text <%s> != <%s>\n",
            message, captured_text, text);
        exit(1);
    }
    if (captured_start != start || captured_end != end) {
        fprintf(stderr,
            "completion_quote_semantics: %s: range %d,%d != %d,%d\n",
            message, captured_start, captured_end, start, end);
        exit(1);
    }
}

int
main(void)
{
    rl_attempted_completion_function = capture_completion;
    rl_completer_quote_characters = "\"'";

    rl_completion_found_quote = 0;
    rl_completion_quote_character = 0;
    expect_capture("double quote word", "cmd \"al\t\n", "al", 5, 7);
    if (rl_completion_found_quote != 1)
        fail("double quote found state");
    if (rl_completion_quote_character != '"')
        fail("double quote character state");

    rl_completion_found_quote = 0;
    rl_completion_quote_character = 0;
    quote_hook_calls = 0;
    rl_char_is_quoted_p = quoted_space;
    expect_capture("escaped space word", "a\\ b\t\n", "a\\ b", 0, 4);
    if (quote_hook_calls == 0)
        fail("char-is-quoted hook not called");
    if (rl_completion_found_quote != 0)
        fail("escaped space quote state");
    if (rl_completion_quote_character != 0)
        fail("escaped space quote character");

    rl_attempted_completion_function = NULL;
    rl_char_is_quoted_p = NULL;
    rl_getc_function = NULL;
    return 0;
}
