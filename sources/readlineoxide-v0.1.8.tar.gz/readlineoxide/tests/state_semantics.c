#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <readline/readline.h>

static const char *active_input;
static int input_pos;

static void
fail(const char *message)
{
    fprintf(stderr, "state_semantics: %s\n", message);
    exit(1);
}

static int
test_getc(FILE *stream)
{
    (void)stream;
    if (active_input[input_pos] == '\0')
        return EOF;
    return active_input[input_pos++];
}

int
main(void)
{
    struct readline_state marker_a;
    struct readline_state marker_b;
    Keymap saved_map_a;
    Keymap saved_map_b;
    Keymap other_map;
    char *line;

    memset(&marker_a, 0, sizeof(marker_a));
    memset(&marker_b, 0, sizeof(marker_b));

    saved_map_a = rl_make_bare_keymap();
    saved_map_b = rl_make_bare_keymap();
    other_map = rl_make_bare_keymap();
    if (saved_map_a == NULL || saved_map_b == NULL || other_map == NULL)
        fail("make keymaps");

    rl_replace_line("saved-a", 0);
    rl_point = 5;
    rl_mark = 3;
    rl_done = 1;
    rl_eof_found = 1;
    rl_readline_state = RL_STATE_CALLBACK | RL_STATE_DONE;
    rl_set_prompt("saved-a> ");
    rl_set_keymap(saved_map_a);
    rl_pending_input = 'A';
    if (rl_stuff_char('B') != 1)
        fail("stuff char before save");

    if (rl_save_state(&marker_a) != 0)
        fail("save state a");

    rl_replace_line("saved-b", 0);
    rl_point = 2;
    rl_mark = 1;
    rl_done = 0;
    rl_eof_found = 0;
    rl_readline_state = RL_STATE_INITIALIZED;
    rl_set_prompt("saved-b> ");
    rl_set_keymap(saved_map_b);
    rl_pending_input = 'C';
    rl_clear_pending_input();

    if (rl_save_state(&marker_b) != 0)
        fail("save state b");

    rl_replace_line("mutated", 0);
    rl_point = 0;
    rl_mark = 0;
    rl_done = 0;
    rl_eof_found = 0;
    rl_readline_state = 0;
    rl_set_prompt("mutated> ");
    rl_set_keymap(other_map);
    rl_pending_input = 0;
    rl_clear_pending_input();

    if (rl_restore_state(&marker_a) != 0)
        fail("restore state a");

    if (rl_line_buffer == NULL || strcmp(rl_line_buffer, "saved-a") != 0)
        fail("restored line a");
    if (rl_point != 5 || rl_end != 7 || rl_mark != 3)
        fail("restored positions a");
    if (rl_done != 1 || rl_eof_found != 1)
        fail("restored flags a");
    if ((rl_readline_state & (RL_STATE_CALLBACK | RL_STATE_DONE)) !=
        (RL_STATE_CALLBACK | RL_STATE_DONE))
        fail("restored readline state a");
    if (rl_prompt == NULL || strcmp(rl_prompt, "saved-a> ") != 0)
        fail("restored prompt a");
    if (rl_get_keymap() != saved_map_a)
        fail("restored keymap a");

    active_input = "\n";
    input_pos = 0;
    rl_getc_function = test_getc;
    line = readline("");
    if (line == NULL || strcmp(line, "AB") != 0)
        fail("restored pending input");
    free(line);

    if (rl_restore_state(&marker_b) != 0)
        fail("restore state b");
    if (rl_line_buffer == NULL || strcmp(rl_line_buffer, "saved-b") != 0)
        fail("restored line b");
    if (rl_point != 2 || rl_end != 7 || rl_mark != 1)
        fail("restored positions b");
    if (rl_done != 0 || rl_eof_found != 0)
        fail("restored flags b");
    if ((rl_readline_state & RL_STATE_INITIALIZED) != RL_STATE_INITIALIZED)
        fail("restored readline state b");
    if (rl_prompt == NULL || strcmp(rl_prompt, "saved-b> ") != 0)
        fail("restored prompt b");
    if (rl_get_keymap() != saved_map_b)
        fail("restored keymap b");

    rl_getc_function = NULL;
    return 0;
}
