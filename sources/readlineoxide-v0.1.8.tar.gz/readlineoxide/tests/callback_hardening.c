#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <readline/readline.h>

static const char *active_input;
static const char *expected_lines[4];
static int expected_null[4];
static int input_pos;
static int calls;
static int getc_calls;
static int available_calls;
static int prep_calls;
static int deprep_calls;
static char terminal_events[16];
static int terminal_event_pos;
static int handler_requires_deprepped;

static void
fail(const char *message)
{
    fprintf(stderr, "callback_hardening: %s\n", message);
    exit(1);
}

static int
test_getc(FILE *stream)
{
    (void)stream;
    getc_calls++;
    if (active_input[input_pos] == '\0')
        return EOF;
    return active_input[input_pos++];
}

static int
input_available_hook(void)
{
    available_calls++;
    return 0;
}

static void
handler(char *line)
{
    if (calls >= 4)
        fail("extra handler call");
    if (handler_requires_deprepped && RL_ISSTATE(RL_STATE_TERMPREPPED))
        fail("handler called while terminal prepped");
    if (expected_null[calls]) {
        if (line != NULL)
            fail("expected null line");
    } else {
        if (line == NULL)
            fail("unexpected null line");
        if (strcmp(line, expected_lines[calls]) != 0)
            fail("handler line");
    }
    calls++;
    free(line);
}

static void
reset_case(const char *input)
{
    int i;

    active_input = input;
    input_pos = 0;
    calls = 0;
    getc_calls = 0;
    available_calls = 0;
    for (i = 0; i < 4; i++) {
        expected_lines[i] = NULL;
        expected_null[i] = 0;
    }
    rl_done = 0;
    rl_reset_line_state();
}

static void
record_terminal_event(char event)
{
    if (terminal_event_pos >= (int)(sizeof(terminal_events) - 1))
        fail("terminal event overflow");
    terminal_events[terminal_event_pos++] = event;
    terminal_events[terminal_event_pos] = '\0';
}

static void
prep_hook(int meta_flag)
{
    if (meta_flag != 1)
        fail("prep meta flag");
    prep_calls++;
    record_terminal_event('P');
}

static void
deprep_hook(void)
{
    deprep_calls++;
    record_terminal_event('D');
}

int
main(void)
{
    rl_getc_function = test_getc;

    reset_case("abcdef\n");
    expected_lines[0] = "abc";
    rl_num_chars_to_read = 3;
    rl_callback_handler_install("", handler);
    rl_callback_read_char();
    rl_callback_read_char();
    rl_callback_read_char();
    if (calls != 1)
        fail("bounded callback read");
    if (input_pos != 3)
        fail("bounded callback over-read");
    if (rl_line_buffer == NULL || strcmp(rl_line_buffer, "abc") != 0)
        fail("bounded callback line buffer");
    rl_callback_handler_remove();
    rl_num_chars_to_read = 0;

    reset_case("abc");
    expected_lines[0] = "abc";
    rl_callback_handler_install("", handler);
    rl_callback_read_char();
    rl_callback_read_char();
    rl_callback_read_char();
    if (calls != 0)
        fail("partial eof accepted early");
    rl_callback_read_char();
    if (calls != 1)
        fail("partial eof not delivered");
    if (rl_eof_found != 0)
        fail("partial eof marked eof");
    rl_callback_handler_remove();

    reset_case("");
    expected_null[0] = 1;
    rl_callback_handler_install("", handler);
    rl_callback_read_char();
    if (calls != 1)
        fail("empty eof not delivered");
    if (rl_eof_found != 1)
        fail("empty eof not marked");
    rl_callback_handler_remove();

    reset_case("");
    expected_lines[0] = "x";
    rl_input_available_hook = input_available_hook;
    if (rl_stuff_char('x') != 1 || rl_stuff_char('\n') != 1)
        fail("stuff input");
    rl_callback_handler_install("", handler);
    rl_callback_read_char();
    rl_callback_read_char();
    if (calls != 1)
        fail("queued input starved");
    if (getc_calls != 0)
        fail("queued input read stream");
    if (available_calls != 2)
        fail("input available hook count");
    rl_callback_handler_remove();

    rl_input_available_hook = NULL;

    reset_case("ok\n");
    prep_calls = 0;
    deprep_calls = 0;
    terminal_event_pos = 0;
    terminal_events[0] = '\0';
    handler_requires_deprepped = 1;
    expected_lines[0] = "ok";
    rl_prep_term_function = prep_hook;
    rl_deprep_term_function = deprep_hook;
    rl_callback_handler_install("", handler);
    if (prep_calls != 1 || deprep_calls != 0)
        fail("install prep count");
    if (!RL_ISSTATE(RL_STATE_TERMPREPPED))
        fail("install not prepped");
    rl_callback_read_char();
    rl_callback_read_char();
    rl_callback_read_char();
    if (calls != 1)
        fail("lifecycle handler count");
    if (strcmp(terminal_events, "PDP") != 0)
        fail("accept lifecycle events");
    if (!RL_ISSTATE(RL_STATE_TERMPREPPED))
        fail("accept not re-prepped");
    rl_callback_handler_remove();
    if (strcmp(terminal_events, "PDPD") != 0)
        fail("remove lifecycle events");
    if (RL_ISSTATE(RL_STATE_TERMPREPPED))
        fail("remove still prepped");

    reset_case("z\n");
    terminal_event_pos = 0;
    terminal_events[0] = '\0';
    handler_requires_deprepped = 0;
    expected_lines[0] = "z";
    rl_callback_handler_install("", handler);
    rl_callback_sigcleanup();
    rl_callback_read_char();
    rl_callback_read_char();
    if (calls != 1)
        fail("sigcleanup cleared handler");
    rl_callback_handler_remove();
    rl_prep_term_function = NULL;
    rl_deprep_term_function = NULL;

    rl_getc_function = NULL;
    return 0;
}
