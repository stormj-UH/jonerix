#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <readline/readline.h>

static void
fail(const char *message)
{
    fprintf(stderr, "vi_wrapper_semantics: %s\n", message);
    exit(1);
}

static void
expect_line(const char *message, const char *line, int point)
{
    if (rl_line_buffer == NULL || strcmp(rl_line_buffer, line) != 0) {
        fprintf(stderr, "vi_wrapper_semantics: %s: line <%s> != <%s>\n",
            message, rl_line_buffer == NULL ? "(null)" : rl_line_buffer,
            line);
        exit(1);
    }
    if (rl_point != point) {
        fprintf(stderr, "vi_wrapper_semantics: %s: point %d != %d\n",
            message, rl_point, point);
        exit(1);
    }
}

int
main(void)
{
    if (rl_variable_bind("editing-mode", "vi") != 0)
        fail("bind vi editing mode");
    rl_set_keymap_from_edit_mode();
    if (strcmp(rl_get_keymap_name(rl_get_keymap()), "vi-insert") != 0)
        fail("vi insert keymap");

    rl_replace_line("abc def", 0);
    rl_point = 0;
    if (rl_vi_append_mode(1, 'a') != 0)
        fail("vi append mode");
    expect_line("append mode", "abc def", 1);

    rl_replace_line("abc def", 0);
    rl_point = 4;
    if (rl_vi_prev_word(1, 'b') != 0)
        fail("vi previous word");
    expect_line("previous word", "abc def", 0);
    if (rl_vi_next_word(1, 'w') != 0)
        fail("vi next word");
    expect_line("next word", "abc def", 4);
    if (rl_vi_end_word(1, 'e') != 0)
        fail("vi end word");
    expect_line("end word", "abc def", 6);

    rl_point = 0;
    if (rl_vi_change_case(1, '~') != 0)
        fail("vi change case one");
    expect_line("change case one", "Abc def", 1);
    if (rl_vi_change_case(2, '~') != 0)
        fail("vi change case count");
    expect_line("change case count", "ABC def", 3);

    rl_replace_line("abc def", 0);
    rl_point = 5;
    if (rl_vi_insert_beg(1, 'I') != 0)
        fail("vi insert beginning");
    expect_line("insert beginning", "abc def", 0);
    if (strcmp(rl_get_keymap_name(rl_get_keymap()), "vi-insert") != 0)
        fail("vi insert beginning keymap");

    rl_replace_line("  abc", 0);
    rl_point = 5;
    if (rl_vi_first_print(1, '^') != 0)
        fail("vi first print");
    expect_line("first print", "  abc", 2);

    rl_replace_line("abc def", 0);
    rl_point = 7;
    if (rl_vi_unix_word_rubout(1, 0) != 0)
        fail("vi unix word rubout");
    expect_line("unix word rubout", "abc ", 4);

    rl_replace_line("undo", 0);
    rl_point = 4;
    if (rl_insert_text("able") != 4)
        fail("insert undo text");
    if (rl_vi_undo(1, 'u') != 0)
        fail("vi undo");
    expect_line("undo", "undo", 4);

    clear_history();
    add_history("history line");
    if (history_set_pos(1) == 0)
        fail("history set pos");
    if (rl_vi_fetch_history(1, 'G') != 0)
        fail("vi fetch history");
    expect_line("fetch history", "history line", 12);

    return 0;
}
