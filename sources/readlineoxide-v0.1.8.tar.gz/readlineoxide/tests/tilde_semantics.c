#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <readline/tilde.h>

static char pre_arg[128];
static char fail_arg[128];
static char home_env[512];

static void
fail(const char *message)
{
    fprintf(stderr, "tilde_semantics: %s\n", message);
    exit(1);
}

static char *
xdup(const char *text)
{
    char *copy;
    size_t len;

    len = strlen(text);
    copy = malloc(len + 1);
    if (copy == NULL)
        fail("malloc");
    memcpy(copy, text, len + 1);
    return copy;
}

static char *
pre_hook(char *user)
{
    snprintf(pre_arg, sizeof(pre_arg), "%s", user);
    if (strcmp(user, "hook") == 0)
        return xdup("/PRE_USER");
    return NULL;
}

static char *
fail_hook(char *user)
{
    snprintf(fail_arg, sizeof(fail_arg), "%s", user);
    if (strcmp(user, "missing_user_xyz") == 0)
        return xdup("/FAIL_USER");
    return NULL;
}

static void
expect_expand(const char *message, const char *input, const char *expected)
{
    char *expanded;

    expanded = tilde_expand(input);
    if (expanded == NULL || strcmp(expanded, expected) != 0) {
        fprintf(stderr, "tilde_semantics: %s: <%s> != <%s>\n", message,
            expanded == NULL ? "(null)" : expanded, expected);
        exit(1);
    }
    free(expanded);
}

int
main(int argc, char **argv)
{
    char expected[512];
    char *prefixes[3];
    char *suffixes[2];

    if (argc != 2)
        fail("usage");
    if (snprintf(home_env, sizeof(home_env), "HOME=%s", argv[1]) >=
        (int)sizeof(home_env))
        fail("home env too long");
    if (putenv(home_env) != 0)
        fail("putenv");

    if (snprintf(expected, sizeof(expected), "%s/p", argv[1]) >=
        (int)sizeof(expected))
        fail("expected too long");
    expect_expand("home slash", "~/p", expected);

    tilde_expansion_preexpansion_hook = pre_hook;
    expect_expand("pre hook", "~hook/rest", "/PRE_USER/rest");
    if (strcmp(pre_arg, "hook") != 0)
        fail("pre hook argument");

    tilde_expansion_failure_hook = fail_hook;
    expect_expand("failure hook", "~missing_user_xyz/rest", "/FAIL_USER/rest");
    if (strcmp(fail_arg, "missing_user_xyz") != 0)
        fail("failure hook argument");

    prefixes[0] = "=~";
    prefixes[1] = ":~";
    prefixes[2] = NULL;
    tilde_additional_prefixes = prefixes;
    if (snprintf(expected, sizeof(expected), "x=%s/p", argv[1]) >=
        (int)sizeof(expected))
        fail("prefix expected too long");
    expect_expand("additional prefix", "x=~/p", expected);

    suffixes[0] = ":";
    suffixes[1] = NULL;
    tilde_additional_suffixes = suffixes;
    if (snprintf(expected, sizeof(expected), "%s:tail", argv[1]) >=
        (int)sizeof(expected))
        fail("suffix expected too long");
    expect_expand("additional suffix", "~:tail", expected);

    tilde_expansion_preexpansion_hook = NULL;
    tilde_expansion_failure_hook = NULL;
    tilde_additional_prefixes = NULL;
    tilde_additional_suffixes = NULL;
    return 0;
}
