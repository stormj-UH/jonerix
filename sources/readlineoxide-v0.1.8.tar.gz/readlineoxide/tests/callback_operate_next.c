#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <readline/history.h>
#include <readline/readline.h>

static const char input[] = "typed\017\017after\n";
static const char *expected[] = {"typed", "p 9", "after"};
static int input_pos;
static int calls;

static void
fail(const char *message)
{
    fprintf(stderr, "callback_operate_next: %s\n", message);
    exit(1);
}

static int
test_getc(FILE *stream)
{
    (void)stream;
    if (input[input_pos] == '\0')
        return EOF;
    return input[input_pos++];
}

static void
handler(char *line)
{
    if (line == NULL)
        fail("null line");
    if (calls >= 3)
        fail("extra callback line");
    if (strcmp(line, expected[calls]) != 0)
        fail("callback line");
    calls++;
    free(line);
}

int
main(void)
{
    clear_history();
    stifle_history(2);
    add_history("p 7");
    add_history("p 8");
    add_history("p 9");
    if (history_length != 2)
        fail("stifled history length");
    if (history_set_pos(0) == 0)
        fail("history_set_pos");

    rl_getc_function = test_getc;
    if (rl_bind_key('\017', rl_operate_and_get_next) != 0)
        fail("bind operate-and-get-next");
    rl_callback_handler_install("", handler);

    rl_callback_read_char();
    rl_callback_read_char();
    rl_callback_read_char();
    rl_callback_read_char();
    rl_callback_read_char();
    if (calls != 0)
        fail("text accepted early");

    rl_callback_read_char();
    if (calls != 1)
        fail("operate-and-get-next did not accept");
    if (rl_line_buffer == NULL || strcmp(rl_line_buffer, "p 9") != 0)
        fail("saved next line not loaded");

    rl_callback_read_char();
    if (calls != 2)
        fail("repeated operate-and-get-next did not accept saved line");

    rl_callback_read_char();
    if (calls != 2)
        fail("rl_done leaked into next callback line");

    rl_callback_read_char();
    rl_callback_read_char();
    rl_callback_read_char();
    rl_callback_read_char();
    if (calls != 2)
        fail("normal input accepted early after repeated operate");
    if (rl_line_buffer == NULL || strcmp(rl_line_buffer, "after") != 0)
        fail("normal input after repeated operate");

    rl_callback_read_char();
    if (calls != 3)
        fail("normal input after repeated operate not accepted");

    rl_callback_handler_remove();
    rl_getc_function = NULL;
    unstifle_history();
    clear_history();
    return 0;
}
