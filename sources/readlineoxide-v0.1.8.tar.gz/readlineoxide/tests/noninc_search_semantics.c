#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <readline/readline.h>
#include <readline/history.h>

static const char *active_input;
static int input_pos;

static void
fail(const char *message)
{
    fprintf(stderr, "noninc_search_semantics: %s\n", message);
    exit(1);
}

static int
test_getc(FILE *stream)
{
    (void)stream;
    if (active_input[input_pos] == '\0')
        return EOF;
    return active_input[input_pos++];
}

static void
reset_history(void)
{
    clear_history();
    add_history("alpha one");
    add_history("alpha two");
    add_history("beta one");
    add_history("alpha three");
}

static void
set_input(const char *input)
{
    active_input = input;
    input_pos = 0;
    rl_getc_function = test_getc;
}

static void
expect_state(const char *message, int ret, int expected_ret,
    int expected_where, const char *expected_line, int expected_point,
    int expected_used)
{
    if (ret != expected_ret) {
        fprintf(stderr, "noninc_search_semantics: %s: ret %d != %d\n",
            message, ret, expected_ret);
        exit(1);
    }
    if (where_history() != expected_where) {
        fprintf(stderr, "noninc_search_semantics: %s: where %d != %d\n",
            message, where_history(), expected_where);
        exit(1);
    }
    if (rl_line_buffer == NULL || strcmp(rl_line_buffer, expected_line) != 0) {
        fprintf(stderr, "noninc_search_semantics: %s: line <%s> != <%s>\n",
            message, rl_line_buffer == NULL ? "(null)" : rl_line_buffer,
            expected_line);
        exit(1);
    }
    if (rl_point != expected_point) {
        fprintf(stderr, "noninc_search_semantics: %s: point %d != %d\n",
            message, rl_point, expected_point);
        exit(1);
    }
    if (input_pos != expected_used) {
        fprintf(stderr, "noninc_search_semantics: %s: used %d != %d\n",
            message, input_pos, expected_used);
        exit(1);
    }
}

int
main(void)
{
    int ret;

    reset_history();
    if (!history_set_pos(4))
        fail("set reverse start");
    rl_replace_line("seed", 0);
    rl_point = 2;
    set_input("beta\n");
    ret = rl_noninc_reverse_search(1, 0);
    expect_state("reverse search", ret, 0, 2, "beta one", 0, 5);

    reset_history();
    if (!history_set_pos(0))
        fail("set forward start");
    rl_replace_line("seed", 0);
    rl_point = 2;
    set_input("alpha\n");
    ret = rl_noninc_forward_search(1, 0);
    expect_state("forward search", ret, 0, 1, "alpha two", 0, 6);

    set_input("");
    ret = rl_noninc_forward_search_again(1, 0);
    expect_state("forward search again", ret, 0, 3, "alpha three", 0, 0);

    reset_history();
    if (!history_set_pos(0))
        fail("set miss start");
    rl_replace_line("seed", 0);
    rl_point = 2;
    set_input("zzz\n");
    ret = rl_noninc_forward_search(1, 0);
    expect_state("missing search", ret, 1, 0, "seed", 2, 4);

    reset_history();
    if (!history_set_pos(1))
        fail("set abort start");
    rl_replace_line("seed", 0);
    rl_point = 2;
    set_input("\007");
    ret = rl_noninc_reverse_search(1, 0);
    expect_state("abort search", ret, 1, 1, "seed", 2, 1);

    reset_history();
    if (!history_set_pos(0))
        fail("set forward command start");
    rl_replace_line("seed", 0);
    rl_point = 2;
    set_input("three\n");
    ret = rl_forward_search_history(1, 0);
    expect_state("forward search history", ret, 0, 3, "alpha three", 0, 6);

    reset_history();
    if (!history_set_pos(4))
        fail("set reverse command start");
    rl_replace_line("seed", 0);
    rl_point = 2;
    set_input("alpha\n");
    ret = rl_reverse_search_history(1, 0);
    expect_state("reverse search history", ret, 0, 3, "alpha three", 0, 6);

    set_input("");
    ret = rl_noninc_reverse_search_again(1, 0);
    expect_state("reverse search again", ret, 0, 1, "alpha two", 0, 0);

    rl_getc_function = NULL;
    return 0;
}
