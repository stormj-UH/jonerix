#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <readline/readline.h>

static const char *active_input;
static int input_pos;
static int captured_dispatching;
static int captured_key;
static int captured_keyseq_len;
static unsigned char captured_keyseq[8];

static void
fail(const char *message)
{
    fprintf(stderr, "keyseq_macro_semantics: %s\n", message);
    exit(1);
}

static int
test_getc(FILE *stream)
{
    (void)stream;
    if (active_input[input_pos] == '\0')
        return EOF;
    return active_input[input_pos++];
}

static char *
read_test_line(const char *input)
{
    active_input = input;
    input_pos = 0;
    rl_getc_function = test_getc;
    return readline("");
}

static int
insert_x(int count, int key)
{
    (void)count;
    (void)key;
    return rl_insert_text("X");
}

static int
insert_y(int count, int key)
{
    (void)count;
    (void)key;
    return rl_insert_text("Y");
}

static int
capture_keyseq_state(int count, int key)
{
    (void)count;
    captured_dispatching = rl_dispatching;
    captured_key = key;
    captured_keyseq_len = rl_key_sequence_length;
    memset(captured_keyseq, 0, sizeof(captured_keyseq));
    if (rl_executing_keyseq != NULL && rl_key_sequence_length > 0
        && rl_key_sequence_length <= (int)sizeof(captured_keyseq))
        memcpy(captured_keyseq, rl_executing_keyseq,
            (size_t)rl_key_sequence_length);
    return rl_insert_text("K");
}

static void
expect_macro_print(const char *expected)
{
    FILE *capture = tmpfile();
    char buffer[32];
    size_t used;

    if (capture == NULL)
        fail("tmpfile");
    rl_outstream = capture;
    if (rl_print_last_kbd_macro() != 0)
        fail("print last macro");
    if (fflush(capture) != 0)
        fail("fflush macro print");
    if (fseek(capture, 0, SEEK_SET) != 0)
        fail("fseek macro print");
    used = fread(buffer, 1, sizeof(buffer) - 1, capture);
    if (ferror(capture))
        fail("fread macro print");
    buffer[used] = '\0';
    if (strcmp(buffer, expected) != 0) {
        fprintf(stderr, "keyseq_macro_semantics: print <%s> != <%s>\n",
            buffer, expected);
        exit(1);
    }
    fclose(capture);
    rl_outstream = NULL;
}

static void
expect_line(const char *message, const char *input, const char *expected)
{
    char *line = read_test_line(input);

    if (line == NULL || strcmp(line, expected) != 0) {
        fprintf(stderr, "keyseq_macro_semantics: %s: <%s> != <%s>\n",
            message, line == NULL ? "(null)" : line, expected);
        exit(1);
    }
    free(line);
}

static void
write_inputrc(const char *path)
{
    FILE *file = fopen(path, "w");

    if (file == NULL)
        fail("fopen");
    if (fprintf(file,
            "set editing-mode emacs\n"
            "$if mode=emacs\n"
            "Control-a: \"EMACS\"\n"
            "Control-b: \"BMAC\"\n"
            "\"\\M-y\": \"YMAC\"\n"
            "$else\n"
            "Control-a: \"VI\"\n"
            "$endif\n") < 0)
        fail("fprintf");
    if (fclose(file) != 0)
        fail("fclose");
}

int
main(int argc, char **argv)
{
    char buffer[8];
    int len = 0;
    rl_keyseq_type_t type = 0;
    rl_command_func_t *func;

    if (argc != 2)
        fail("usage");

    write_inputrc(argv[1]);
    if (rl_read_init_file(argv[1]) != 0)
        fail("read init file");
    expect_line("inputrc mode conditional", "\001\n", "EMACS");
    expect_line("control-b macro", "\002\n", "BMAC");
    expect_line("meta macro", "\033y\n", "YMAC");

    if (rl_bind_keyseq("\\M-x", insert_x) != 0)
        fail("bind meta keyseq");
    func = rl_function_of_keyseq("\\M-x", rl_get_keymap(), &type);
    if (func != insert_x || type != ISFUNC)
        fail("function of keyseq");
    expect_line("meta keyseq dispatch", "\033x\n", "X");

    if (rl_bind_keyseq("\\C-xp", capture_keyseq_state) != 0)
        fail("bind executing keyseq");
    expect_line("executing keyseq dispatch", "\030p\n", "K");
    if (captured_dispatching != 1)
        fail("executing keyseq dispatching");
    if (captured_key != 'p')
        fail("executing keyseq key");
    if (captured_keyseq_len != 2 ||
        memcmp(captured_keyseq, "\030p", 2) != 0)
        fail("executing keyseq bytes");
    if (rl_executing_key != '\n' || rl_key_sequence_length != 1 ||
        rl_executing_keyseq == NULL || rl_executing_keyseq[0] != '\n')
        fail("accept newline keyseq");

    type = ISFUNC;
    func = rl_function_of_keyseq("\\C-b", rl_get_keymap(), &type);
    if (func != NULL || type != ISMACR)
        fail("macro keyseq type");

    if (rl_translate_keyseq("\\M-a\\C-b", buffer, &len) != 0)
        fail("translate keyseq");
    if (len != 3 || buffer[0] != '\033' || buffer[1] != 'a'
        || buffer[2] != '\002')
        fail("translated keyseq bytes");
    rl_key_sequence_length = 0;
    if (rl_translate_keyseq("\\C-c", buffer, &len) != 0)
        fail("translate keyseq side effect");
    if (rl_key_sequence_length != 0)
        fail("key sequence length variable");

    rl_pending_input = 'P';
    expect_line("pending input", "\n", "P");

    if (rl_stuff_char('S') != 1)
        fail("stuff char");
    expect_line("stuffed input", "\n", "S");

    if (rl_push_macro_input("MACRO\n") != 0)
        fail("push macro input");
    expect_line("macro input", "\n", "MACRO");

    if (rl_bind_key('\036', rl_start_kbd_macro) != 0)
        fail("bind macro start");
    if (rl_bind_key('\037', rl_end_kbd_macro) != 0)
        fail("bind macro end");
    if (rl_bind_key('\024', insert_x) != 0)
        fail("bind macro record key");
    expect_line("record keyboard macro", "\036\024\037\n", "X");
    expect_macro_print("\\C-t\n");

    if (rl_bind_key('\024', insert_y) != 0)
        fail("rebind macro record key");
    if (rl_call_last_kbd_macro(1, 0) != 0)
        fail("call last macro");
    expect_line("replay keyboard macro", "\n", "Y");

    if (rl_bind_keyseq("\\M-z", insert_x) != 0)
        fail("bind macro meta record key");
    expect_line("record keyboard meta macro", "\036\033z\037\n", "X");
    expect_macro_print("\\M-z\n");
    if (rl_bind_keyseq("\\M-z", insert_y) != 0)
        fail("rebind macro meta record key");
    if (rl_call_last_kbd_macro(1, 0) != 0)
        fail("call last meta macro");
    expect_line("replay keyboard meta macro", "\n", "Y");

    rl_replace_line("abc", 0);
    rl_point = 0;
    if (rl_vi_append_eol(1, 0) != 0)
        fail("vi append eol");
    if (rl_point != rl_end)
        fail("vi append eol point");

    rl_getc_function = NULL;
    return 0;
}
