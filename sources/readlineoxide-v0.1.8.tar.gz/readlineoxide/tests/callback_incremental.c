#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <readline/readline.h>

static const char input[] = "go\n";
static int input_pos;
static int calls;

static void
fail(const char *message)
{
    fprintf(stderr, "callback_incremental: %s\n", message);
    exit(1);
}

static int
test_getc(FILE *stream)
{
    (void)stream;
    if (input[input_pos] == '\0')
        return EOF;
    return input[input_pos++];
}

static void
handler(char *line)
{
    if (line == NULL)
        fail("null line");
    if (strcmp(line, "go") != 0)
        fail("line");
    calls++;
    free(line);
}

int
main(void)
{
    rl_getc_function = test_getc;
    rl_callback_handler_install("cb> ", handler);

    rl_callback_read_char();
    if (calls != 0)
        fail("first char dispatched");
    rl_callback_read_char();
    if (calls != 0)
        fail("second char dispatched");
    rl_callback_read_char();
    if (calls != 1)
        fail("newline did not dispatch");
    if (rl_line_buffer == NULL || strcmp(rl_line_buffer, "go") != 0)
        fail("line buffer");
    if (rl_line_buffer_len < rl_end + 1)
        fail("line buffer len");

    rl_callback_handler_remove();
    rl_getc_function = NULL;
    return 0;
}
