#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

#include <readline/readline.h>

static const char *active_input;
static int input_pos;

static void
fail(const char *message)
{
    fprintf(stderr, "inputrc_path_semantics: %s\n", message);
    exit(1);
}

static int
test_getc(FILE *stream)
{
    (void)stream;
    if (active_input[input_pos] == '\0')
        return EOF;
    return active_input[input_pos++];
}

static void
write_file(const char *path, const char *text)
{
    FILE *file;

    file = fopen(path, "w");
    if (file == NULL)
        fail("fopen");
    if (fputs(text, file) == EOF)
        fail("fputs");
    if (fclose(file) != 0)
        fail("fclose");
}

static void
make_byte_path(char *out, size_t out_len, const char *base, const char *tag)
{
    int n;

    n = snprintf(out, out_len, "%s.%s-", base, tag);
    if (n < 0 || n >= (int)out_len)
        fail("byte path prefix too long");
    if ((size_t)n + 11 >= out_len)
        fail("byte path too long");
    out[n++] = (char)0xff;
    if (snprintf(out + n, out_len - (size_t)n, ".inputrc") >=
        (int)(out_len - (size_t)n))
        fail("byte path suffix too long");
}

static void
write_include_file(const char *path, const char *include)
{
    FILE *file;

    file = fopen(path, "w");
    if (file == NULL)
        fail("include fopen");
    if (fputs("$include ", file) == EOF)
        fail("include fputs");
    if (fwrite(include, 1, strlen(include), file) != strlen(include))
        fail("include fwrite");
    if (fputc('\n', file) == EOF)
        fail("include newline");
    if (fclose(file) != 0)
        fail("include fclose");
}

static void
expect_line(const char *message, const char *input, const char *expected)
{
    char *line;

    active_input = input;
    input_pos = 0;
    rl_getc_function = test_getc;
    line = readline("");
    if (line == NULL || strcmp(line, expected) != 0) {
        fprintf(stderr, "inputrc_path_semantics: %s: <%s> != <%s>\n",
            message, line == NULL ? "(null)" : line, expected);
        exit(1);
    }
    free(line);
}

int
main(int argc, char **argv)
{
    char cwd_include[512];
    char cwd_dir[512];
    char parent_dir[512];
    char parent_include[512];
    char mainrc[512];
    char home_include[512];
    char home_main[512];
    char home_env[600];
    char byte_main[512];
    char byte_include[512];

    if (argc != 2)
        fail("usage");

    if (mkdir(argv[1], 0700) != 0)
        fail("mkdir base");
    if (snprintf(cwd_dir, sizeof(cwd_dir), "%s-cwd", argv[1]) >=
        (int)sizeof(cwd_dir))
        fail("cwd dir path too long");
    if (mkdir(cwd_dir, 0700) != 0)
        fail("mkdir cwd");
    if (snprintf(cwd_include, sizeof(cwd_include), "%s/child.inputrc",
            cwd_dir) >= (int)sizeof(cwd_include))
        fail("cwd include path too long");
    if (snprintf(parent_dir, sizeof(parent_dir), "%s-parent", argv[1]) >=
        (int)sizeof(parent_dir))
        fail("parent path too long");
    if (mkdir(parent_dir, 0700) != 0)
        fail("mkdir parent");
    if (snprintf(parent_include, sizeof(parent_include), "%s/child.inputrc",
            parent_dir) >= (int)sizeof(parent_include))
        fail("parent include path too long");
    if (snprintf(mainrc, sizeof(mainrc), "%s/main.inputrc", parent_dir) >=
        (int)sizeof(mainrc))
        fail("main path too long");
    if (snprintf(home_include, sizeof(home_include), "%s/home.inputrc",
            argv[1]) >= (int)sizeof(home_include))
        fail("home include path too long");
    if (snprintf(home_main, sizeof(home_main), "%s/home-main.inputrc",
            argv[1]) >= (int)sizeof(home_main))
        fail("home main path too long");
    if (snprintf(home_env, sizeof(home_env), "HOME=%s", argv[1]) >=
        (int)sizeof(home_env))
        fail("home env too long");
    make_byte_path(byte_main, sizeof(byte_main), argv[1], "main");
    make_byte_path(byte_include, sizeof(byte_include), argv[1], "include");

    write_file(cwd_include, "\"\\C-xc\": \"CWDREL\"\n");
    write_file(parent_include, "\"\\C-xc\": \"PARENTREL\"\n");
    write_file(mainrc, "$include child.inputrc\n$include missing.inputrc\n");
    write_file(home_include, "\"\\C-xh\": \"TILDEHOME\"\n");
    write_file(home_main, "$include ~/home.inputrc\n");
    write_file(byte_include, "\"\\C-xb\": \"BYTEPATH\"\n");
    write_include_file(byte_main, byte_include);

    if (putenv(home_env) != 0)
        fail("putenv");
    if (chdir(cwd_dir) != 0)
        fail("chdir");
    if (rl_read_init_file(mainrc) != 0)
        fail("read relative init file");
    expect_line("relative include from cwd", "\030c\n", "CWDREL");
    if (rl_read_init_file("~/home-main.inputrc") != 0)
        fail("read tilde init file");
    expect_line("tilde include", "\030h\n", "TILDEHOME");
    if (rl_read_init_file(byte_main) != 0)
        fail("read byte init file");
    expect_line("byte include", "\030b\n", "BYTEPATH");

    rl_getc_function = NULL;
    return 0;
}
