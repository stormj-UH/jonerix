#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <readline/readline.h>

static const char *active_input;
static int input_pos;

static void
fail(const char *message)
{
    fprintf(stderr, "char_search_semantics: %s\n", message);
    exit(1);
}

static int
test_getc(FILE *stream)
{
    (void)stream;
    if (active_input[input_pos] == '\0')
        return EOF;
    return active_input[input_pos++];
}

static void
expect_search(const char *message, int backward, int start, int count,
    const char *input, int expected_ret, int expected_point, int expected_used)
{
    int ret;

    rl_replace_line("abacadabra", 0);
    rl_point = start;
    active_input = input;
    input_pos = 0;

    if (backward)
        ret = rl_backward_char_search(count, 'X');
    else
        ret = rl_char_search(count, 'X');

    if (ret != expected_ret) {
        fprintf(stderr, "char_search_semantics: %s: ret %d != %d\n",
            message, ret, expected_ret);
        exit(1);
    }
    if (rl_point != expected_point) {
        fprintf(stderr, "char_search_semantics: %s: point %d != %d\n",
            message, rl_point, expected_point);
        exit(1);
    }
    if (input_pos != expected_used) {
        fprintf(stderr, "char_search_semantics: %s: used %d != %d\n",
            message, input_pos, expected_used);
        exit(1);
    }
    if (rl_line_buffer == NULL || strcmp(rl_line_buffer, "abacadabra") != 0)
        fail("line changed");
}

int
main(void)
{
    if (rl_initialize() != 0)
        fail("initialize");
    rl_getc_function = test_getc;

    expect_search("forward next", 0, 0, 1, "a", 0, 2, 1);
    expect_search("forward count", 0, 0, 2, "a", 0, 4, 1);
    expect_search("forward excludes point", 0, 1, 1, "a", 0, 2, 1);
    expect_search("forward missing", 0, 0, 1, "z", 1, 0, 1);
    expect_search("forward end", 0, 10, 1, "a", 1, 10, 1);
    expect_search("forward negative count", 0, 7, -1, "a", 0, 6, 1);
    expect_search("forward zero count", 0, 7, 0, "a", 0, 7, 1);
    expect_search("forward eof", 0, 7, 1, "", 1, 7, 0);

    expect_search("backward previous", 1, 10, 1, "a", 0, 9, 1);
    expect_search("backward count", 1, 10, 2, "a", 0, 6, 1);
    expect_search("backward excludes point", 1, 9, 1, "a", 0, 6, 1);
    expect_search("backward missing", 1, 10, 1, "z", 1, 10, 1);
    expect_search("backward start", 1, 0, 1, "a", 1, 0, 1);
    expect_search("backward negative count", 1, 7, -1, "a", 0, 9, 1);
    expect_search("backward zero count", 1, 7, 0, "a", 0, 7, 1);
    expect_search("backward eof", 1, 7, 1, "", 1, 7, 0);

    rl_getc_function = NULL;
    return 0;
}
