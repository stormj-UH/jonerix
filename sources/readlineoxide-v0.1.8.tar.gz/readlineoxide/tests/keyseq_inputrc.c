#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <readline/readline.h>
#include <readline/history.h>

static const char first_input[] = "\001\n";
static const char second_input[] = "a\tb\n";
static const char third_input[] = "z\n";
static const char fourth_input[] = "\030\022\n";
static const char *active_input;
static int input_pos;

static void
fail(const char *message)
{
    fprintf(stderr, "keyseq_inputrc: %s\n", message);
    exit(1);
}

static int
test_getc(FILE *stream)
{
    (void)stream;
    if (active_input[input_pos] == '\0')
        return EOF;
    return active_input[input_pos++];
}

static char *
read_test_line(const char *input)
{
    active_input = input;
    input_pos = 0;
    rl_getc_function = test_getc;
    return readline("");
}

static int
insert_custom(int count, int key)
{
    (void)count;
    (void)key;
    return rl_insert_text("X");
}

static void
write_inputrc(const char *path)
{
    FILE *file = fopen(path, "w");
    if (file == NULL)
        fail("fopen");
    if (fprintf(file, "set history-size 2\nControl-a: \"macro\"\n") < 0)
        fail("fprintf");
    if (fclose(file) != 0)
        fail("fclose");
}

static void
write_auto_inputrc(const char *path)
{
    FILE *file = fopen(path, "w");
    if (file == NULL)
        fail("auto fopen");
    if (fprintf(file, "Control-b: \"auto\"\n") < 0)
        fail("auto fprintf");
    if (fclose(file) != 0)
        fail("auto fclose");
}

int
main(int argc, char **argv)
{
    char *line;
    char *value;
    char auto_path[512];

    if (argc != 2)
        fail("usage");
    if (snprintf(auto_path, sizeof(auto_path), "%s.auto", argv[1]) >=
        (int)sizeof(auto_path))
        fail("auto path too long");

    write_auto_inputrc(auto_path);
    if (setenv("INPUTRC", auto_path, 1) != 0)
        fail("set inputrc");
    line = read_test_line("\002\n");
    if (line == NULL || strcmp(line, "auto") != 0)
        fail("auto inputrc");
    free(line);
    if (unsetenv("INPUTRC") != 0)
        fail("unset inputrc");

    clear_history();
    add_history("one");
    add_history("two");
    add_history("three");
    if (rl_variable_bind("history-size", "2") != 0)
        fail("variable bind");
    if (history_length != 2)
        fail("variable bind length");

    write_inputrc(argv[1]);
    if (rl_read_init_file(argv[1]) != 0)
        fail("read init file");

    clear_history();
    add_history("one");
    add_history("two");
    add_history("three");
    if (history_length != 2)
        fail("inputrc history size");

    line = read_test_line(first_input);
    if (line == NULL || strcmp(line, "macro") != 0)
        fail("control-a macro");
    free(line);

    if (rl_bind_key('\t', rl_insert) != 0)
        fail("bind tab insert");
    line = read_test_line(second_input);
    if (line == NULL || strcmp(line, "a\tb") != 0)
        fail("tab insert");
    free(line);

    if (rl_bind_key('z', insert_custom) != 0)
        fail("bind key custom");
    line = read_test_line(third_input);
    if (line == NULL || strcmp(line, "X") != 0)
        fail("custom key");
    free(line);

    if (rl_bind_keyseq("\\C-x\\C-r", insert_custom) != 0)
        fail("bind keyseq custom");
    line = read_test_line(fourth_input);
    if (line == NULL || strcmp(line, "X") != 0)
        fail("custom keyseq");
    free(line);

    value = rl_variable_value("show-all-if-ambiguous");
    if (value == NULL || strcmp(value, "on") != 0)
        fail("variable value");

    rl_getc_function = NULL;
    return 0;
}
