#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <readline/readline.h>

static void
fail(const char *message)
{
    fprintf(stderr, "line_buffer_capacity: %s\n", message);
    exit(1);
}

static void
expect_state(const char *message, int len, int point, int end,
    const char *line)
{
    if (rl_line_buffer_len != len) {
        fprintf(stderr, "line_buffer_capacity: %s: len %d != %d\n",
            message, rl_line_buffer_len, len);
        exit(1);
    }
    if (rl_point != point || rl_end != end) {
        fprintf(stderr,
            "line_buffer_capacity: %s: point/end %d/%d != %d/%d\n",
            message, rl_point, rl_end, point, end);
        exit(1);
    }
    if (rl_line_buffer == NULL || strcmp(rl_line_buffer, line) != 0) {
        fprintf(stderr, "line_buffer_capacity: %s: line <%s> != <%s>\n",
            message, rl_line_buffer == NULL ? "(null)" : rl_line_buffer,
            line);
        exit(1);
    }
}

int
main(void)
{
    char big[400];
    char *small_buffer;
    char *grown_buffer;

    memset(big, 'x', sizeof(big) - 1);
    big[sizeof(big) - 1] = '\0';

    if (rl_initialize() != 0)
        fail("initialize");
    expect_state("initialize", 256, 0, 0, "");

    if (rl_extend_line_buffer(80) != 0)
        fail("extend 80");
    expect_state("extend small", 256, 0, 0, "");

    small_buffer = rl_line_buffer;
    rl_replace_line("abc", 0);
    if (rl_line_buffer != small_buffer)
        fail("replace short reallocated");
    rl_point = 1;
    expect_state("replace short", 256, 1, 3, "abc");

    rl_point = 20;
    rl_replace_line("xy", 0);
    expect_state("replace clamps point", 256, 2, 2, "xy");

    rl_replace_line("abc", 0);
    rl_point = 1;

    if (rl_extend_line_buffer(2) != 0)
        fail("extend below current");
    expect_state("extend below current", 256, 1, 3, "abc");

    rl_replace_line(big, 0);
    expect_state("replace big", 512, 1, 399, big);

    if (rl_extend_line_buffer(1000) != 0)
        fail("extend 1000");
    expect_state("extend 1000", 1024, 1, 399, big);

    grown_buffer = rl_line_buffer;
    rl_replace_line("short", 0);
    if (rl_line_buffer != grown_buffer)
        fail("replace after grow reallocated");
    expect_state("replace after grow", 1024, 1, 5, "short");

    if (rl_extend_line_buffer(-1) != 0)
        fail("extend negative");
    expect_state("extend negative", 1024, 1, 5, "short");

    return 0;
}
