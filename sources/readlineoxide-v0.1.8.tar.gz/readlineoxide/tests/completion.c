#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <readline/readline.h>

static const char *items[] = { "help", "hello", "halt", NULL };

static void
fail(const char *message)
{
    fprintf(stderr, "completion: %s\n", message);
    exit(1);
}

static char *
copy_string(const char *value)
{
    size_t len = strlen(value);
    char *copy = malloc(len + 1);
    if (copy == NULL)
        return NULL;
    memcpy(copy, value, len + 1);
    return copy;
}

static char *
generator(const char *text, int state)
{
    size_t len = strlen(text);
    const char *item;

    item = items[state];
    if (item == NULL)
        return NULL;
    if (strncmp(item, text, len) == 0)
        return copy_string(item);
    return NULL;
}

int
main(void)
{
    char **matches;
    int i;

    matches = rl_completion_matches("he", generator);
    if (matches == NULL)
        fail("matches null");
    if (strcmp(matches[0], "hel") != 0)
        fail("common prefix");
    if (strcmp(matches[1], "help") != 0)
        fail("first match");
    if (strcmp(matches[2], "hello") != 0)
        fail("second match");
    if (matches[3] != NULL)
        fail("terminator");

    for (i = 0; matches[i] != NULL; i++)
        free(matches[i]);
    free(matches);

    return 0;
}
