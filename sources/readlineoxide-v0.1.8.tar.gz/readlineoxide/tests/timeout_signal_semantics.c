#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <readline/readline.h>

static void
fail(const char *message)
{
    fprintf(stderr, "timeout_signal_semantics: %s\n", message);
    exit(1);
}

int
main(void)
{
    unsigned int seconds = 123;
    unsigned int useconds = 456;

    rl_readline_state &= ~RL_STATE_TIMEOUT;
    if (rl_timeout_remaining(&seconds, &useconds) != -1)
        fail("no active timeout");
    if (seconds != 123 || useconds != 456)
        fail("no timeout outputs changed");

    if (rl_set_keyboard_input_timeout(1000) != 100000)
        fail("keyboard timeout default");
    if (RL_ISSTATE(RL_STATE_TIMEOUT))
        fail("keyboard timeout changed state");
    if (rl_set_keyboard_input_timeout(2000) != 1000)
        fail("keyboard timeout old value");
    if (rl_set_keyboard_input_timeout(-1) != 2000)
        fail("keyboard timeout negative old value");
    if (rl_set_keyboard_input_timeout(3000) != 2000)
        fail("keyboard timeout negative changed value");

    seconds = 123;
    useconds = 456;
    if (rl_timeout_remaining(&seconds, &useconds) != -1)
        fail("keyboard timeout reported active");
    if (seconds != 123 || useconds != 456)
        fail("keyboard timeout changed outputs");

    if (rl_set_timeout(7, 8) != 0)
        fail("set timeout");
    if (RL_ISSTATE(RL_STATE_TIMEOUT))
        fail("set timeout changed state");
    seconds = 123;
    useconds = 456;
    if (rl_timeout_remaining(&seconds, &useconds) != -1)
        fail("configured timeout reported active");
    if (seconds != 123 || useconds != 456)
        fail("configured timeout changed outputs");
    if (rl_set_timeout(0, 0) != 0)
        fail("clear timeout");

    rl_replace_line("abcd", 0);
    rl_point = 2;
    rl_end = 4;
    rl_explicit_arg = 1;
    rl_numeric_arg = 44;
    rl_arg_sign = -1;
    rl_free_line_state();
    if (rl_explicit_arg != 0 || rl_numeric_arg != 1 || rl_arg_sign != 1)
        fail("free line numeric reset");
    if (strcmp(rl_line_buffer, "abcd") != 0 || rl_point != 2 || rl_end != 4)
        fail("free line mutated line");

    rl_prep_terminal(1);
    if (!RL_ISSTATE(RL_STATE_TERMPREPPED))
        fail("prep terminal");
    rl_cleanup_after_signal();
    if (RL_ISSTATE(RL_STATE_TERMPREPPED))
        fail("cleanup did not deprep");
    rl_reset_after_signal();
    if (!RL_ISSTATE(RL_STATE_TERMPREPPED))
        fail("reset did not prep");

    rl_set_keyboard_input_timeout(100000);
    return 0;
}
