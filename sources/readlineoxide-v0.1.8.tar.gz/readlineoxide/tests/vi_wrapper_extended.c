#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <readline/readline.h>
#include <readline/history.h>

static const char *active_input;
static int input_pos;

static void
fail(const char *message)
{
    fprintf(stderr, "vi_wrapper_extended: %s\n", message);
    exit(1);
}

static void
expect_line(const char *message, const char *line, int point)
{
    if (rl_line_buffer == NULL || strcmp(rl_line_buffer, line) != 0) {
        fprintf(stderr, "vi_wrapper_extended: %s: line <%s> != <%s>\n",
            message, rl_line_buffer == NULL ? "(null)" : rl_line_buffer,
            line);
        exit(1);
    }
    if (rl_point != point) {
        fprintf(stderr, "vi_wrapper_extended: %s: point %d != %d\n",
            message, rl_point, point);
        exit(1);
    }
}

static int
test_getc(FILE *stream)
{
    (void)stream;
    if (active_input[input_pos] == '\0')
        return EOF;
    return active_input[input_pos++];
}

static char *
simple_generator(const char *text, int state)
{
    char *copy;

    if (state != 0 || strcmp(text, "al") != 0)
        return NULL;
    copy = malloc(6);
    if (copy == NULL)
        fail("malloc");
    memcpy(copy, "alpha", 6);
    return copy;
}

int
main(void)
{
    rl_replace_line("abcdef", 0);
    rl_point = 2;
    if (rl_vi_insert_beg(1, 'I') != 0)
        fail("vi insert beginning");
    expect_line("vi insert beginning", "abcdef", 0);
    if (strcmp(rl_get_keymap_name(rl_get_keymap()), "vi-insert") != 0)
        fail("vi insert beginning keymap");

    rl_replace_line("abcdef", 0);
    rl_point = 2;
    if (rl_vi_delete(2, 'x') != 0)
        fail("vi delete");
    expect_line("vi delete", "abef", 2);
    rl_replace_line("XY", 1);
    rl_point = 0;
    if (rl_vi_put(1, 'p') != 0)
        fail("vi put after delete");
    expect_line("vi put after delete", "XcdY", 2);

    rl_replace_line("abcdef", 0);
    rl_point = 4;
    if (rl_vi_rubout(2, 'X') != 0)
        fail("vi rubout");
    expect_line("vi rubout", "abef", 2);
    rl_replace_line("XY", 1);
    rl_point = 1;
    if (rl_vi_put(2, 'P') != 0)
        fail("vi put before rubout");
    expect_line("vi put before rubout", "XcdcdY", 4);

    if (rl_vi_undo(1, 'u') != 0)
        fail("vi undo");
    expect_line("vi undo", "XY", 1);

    rl_replace_line("  abc def", 0);
    rl_point = 8;
    if (rl_vi_back_to_indent(1, '^') != 0)
        fail("vi back to indent");
    expect_line("vi back to indent", "  abc def", 2);

    rl_replace_line("   ", 0);
    rl_point = 0;
    if (rl_vi_first_print(1, '^') != 0)
        fail("vi first print whitespace");
    expect_line("vi first print whitespace", "   ", 3);

    rl_replace_line("abcdef", 0);
    rl_point = 0;
    if (rl_vi_column(3, '|') != 0)
        fail("vi column");
    expect_line("vi column", "abcdef", 2);

    rl_replace_line("abc.def ghi", 0);
    rl_point = 8;
    if (rl_vi_bWord(1, 'B') != 0)
        fail("vi big previous word");
    expect_line("vi big previous word", "abc.def ghi", 0);

    rl_replace_line("abc.def ghi", 0);
    rl_point = 0;
    if (rl_vi_fWord(1, 'W') != 0)
        fail("vi big next word");
    expect_line("vi big next word", "abc.def ghi", 8);

    rl_replace_line("abc.def ghi", 0);
    rl_point = 0;
    if (rl_vi_eWord(1, 'E') != 0)
        fail("vi big end word");
    expect_line("vi big end word", "abc.def ghi", 6);

    rl_replace_line("abcdef", 0);
    rl_point = 2;
    if (rl_vi_subst(1, 's') != 0)
        fail("vi subst");
    expect_line("vi subst", "abdef", 2);
    if (strcmp(rl_get_keymap_name(rl_get_keymap()), "vi-insert") != 0)
        fail("vi subst keymap");

    rl_replace_line("abcdef", 0);
    rl_point = 2;
    if (rl_vi_overstrike(3, 'Y') != 0)
        fail("vi overstrike");
    expect_line("vi overstrike", "abYYYf", 5);

    rl_done = 0;
    if (rl_vi_eof_maybe(1, 4) != 0)
        fail("vi eof maybe");
    if (rl_done != 1)
        fail("vi eof maybe done");
    rl_done = 0;

    clear_history();
    add_history("cmd zero one two");
    add_history("other alpha beta gamma");
    history_set_pos(2);
    rl_explicit_arg = 0;
    rl_replace_line("", 0);
    if (rl_vi_yank_arg(1, '_') != 0)
        fail("vi yank arg last");
    expect_line("vi yank arg last", "gamma", 5);
    history_set_pos(1);
    rl_explicit_arg = 1;
    rl_replace_line("", 0);
    if (rl_vi_yank_arg(3, '_') != 0)
        fail("vi yank arg explicit");
    expect_line("vi yank arg explicit", "one", 3);
    rl_explicit_arg = 0;

    clear_history();
    add_history("first");
    add_history("second");
    history_set_pos(2);
    rl_replace_line("", 0);
    if (rl_vi_fetch_history(1, 'k') != 0)
        fail("vi fetch history");
    expect_line("vi fetch history", "first", 5);

    active_input = "";
    input_pos = 0;
    rl_getc_function = test_getc;
    rl_replace_line("al", 0);
    rl_point = 2;
    rl_completion_entry_function = simple_generator;
    rl_completion_suppress_append = 1;
    if (rl_vi_complete(1, '\t') != 0)
        fail("vi complete");
    expect_line("vi complete", "alpha ", 6);

    rl_completion_entry_function = NULL;
    rl_getc_function = NULL;
    return 0;
}
