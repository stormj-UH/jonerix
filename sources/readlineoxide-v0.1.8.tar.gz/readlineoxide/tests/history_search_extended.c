#include <stdio.h>
#include <stdlib.h>

#include <readline/readline.h>
#include <readline/history.h>

static void
fail(const char *message)
{
    fprintf(stderr, "history_search_extended: %s\n", message);
    exit(1);
}

int
main(void)
{
    clear_history();
    add_history("alpha one");
    add_history("beta two");
    add_history("alphabet soup");
    add_history("gamma two");

    if (history_search_pos("alpha", -1, 3) != 2)
        fail("backward pos nearest");
    if (where_history() != 0)
        fail("backward pos nearest where");
    if (history_search_pos("alpha", -1, 1) != 0)
        fail("backward pos first");
    if (where_history() != 0)
        fail("backward pos first where");
    if (history_search_pos("two", 1, 0) != 1)
        fail("forward pos");
    if (where_history() != 0)
        fail("forward pos where");
    if (history_search_pos("missing", -1, 3) != -1)
        fail("missing pos");
    if (where_history() != 0)
        fail("missing pos where");
    if (history_search("", 1) != -1)
        fail("empty search");
    if (history_search_prefix("", -1) != -1)
        fail("empty prefix");
    if (history_search_pos("", 1, 0) != -1)
        fail("empty pos");

    if (!history_set_pos(2))
        fail("set pos for negative pos");
    if (history_search_pos("two", 1, -1) != 3)
        fail("negative pos uses current offset");
    if (where_history() != 2)
        fail("negative pos keeps where");

    if (!history_set_pos(0))
        fail("set pos");
    if (history_search("two", 1) < 0)
        fail("forward search");
    if (where_history() != 1)
        fail("forward where");
    if (history_search_prefix("alphabet", 1) != 0)
        fail("prefix forward");
    if (where_history() != 2)
        fail("prefix where");

    clear_history();
    add_history("alpha one");
    add_history("alpha two");
    add_history("beta one");
    add_history("alpha three");

    if (!history_set_pos(0))
        fail("set prefix pos 0");
    rl_replace_line("alpha", 0);
    rl_point = 2;
    if (rl_history_search_forward(1, 0) != 0)
        fail("history prefix forward");
    if (where_history() != 1 || rl_point != 2 || rl_end != 9)
        fail("history prefix forward state");

    if (!history_set_pos(1))
        fail("set prefix pos 1");
    rl_replace_line("alpha", 0);
    rl_point = 2;
    if (rl_history_search_forward(1, 0) != 0)
        fail("history prefix forward skips current");
    if (where_history() != 3 || rl_point != 2 || rl_end != 11)
        fail("history prefix forward skip state");

    if (!history_set_pos(3))
        fail("set prefix pos 3");
    rl_replace_line("alpha", 0);
    rl_point = 2;
    if (rl_history_search_forward(1, 0) != 1)
        fail("history prefix forward no match");
    if (where_history() != 3 || rl_point != 2 || rl_end != 5)
        fail("history prefix forward miss state");

    if (!history_set_pos(4))
        fail("set prefix pos end");
    rl_replace_line("alpha", 0);
    rl_point = 2;
    if (rl_history_search_backward(1, 0) != 0)
        fail("history prefix backward from end");
    if (where_history() != 3 || rl_point != 2 || rl_end != 11)
        fail("history prefix backward end state");

    if (!history_set_pos(3))
        fail("set prefix pos 3 backward");
    rl_replace_line("alpha", 0);
    rl_point = 2;
    if (rl_history_search_backward(1, 0) != 0)
        fail("history prefix backward skips current");
    if (where_history() != 1 || rl_point != 2 || rl_end != 9)
        fail("history prefix backward skip state");

    return 0;
}
