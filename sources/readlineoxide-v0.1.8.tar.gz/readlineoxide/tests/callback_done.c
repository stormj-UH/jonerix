#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <readline/readline.h>

static const char input[] = "x";
static int input_pos;
static int handler_called;
static int event_called;
static int available_called;

static void
fail(const char *message)
{
    fprintf(stderr, "callback_done: %s\n", message);
    exit(1);
}

static int
test_getc(FILE *stream)
{
    (void)stream;
    if (input[input_pos] == '\0')
        return EOF;
    return input[input_pos++];
}

static int
event_hook(void)
{
    event_called++;
    return 0;
}

static int
input_available_hook(void)
{
    available_called++;
    return 1;
}

static int
finish_command(int count, int key)
{
    (void)count;
    (void)key;
    rl_done = 1;
    return 0;
}

static void
handler(char *line)
{
    handler_called++;
    if (line == NULL)
        fail("handler line null");
    if (strcmp(line, "") != 0)
        fail("handler line");
    free(line);
}

int
main(void)
{
    rl_getc_function = test_getc;
    rl_event_hook = event_hook;
    rl_input_available_hook = input_available_hook;
    if (rl_bind_key('x', finish_command) != 0)
        fail("bind key");

    rl_callback_handler_install("", handler);
    rl_callback_read_char();
    rl_callback_handler_remove();

    if (handler_called != 1)
        fail("handler not called");
    if (event_called != 1)
        fail("event hook not called");
    if (available_called != 1)
        fail("input available hook not called");

    rl_getc_function = NULL;
    rl_event_hook = NULL;
    rl_input_available_hook = NULL;
    return 0;
}
