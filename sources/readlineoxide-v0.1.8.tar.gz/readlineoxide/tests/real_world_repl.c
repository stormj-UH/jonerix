#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <readline/readline.h>
#include <readline/history.h>

static char key[64];
static char value[64];

static void
fail(const char *message)
{
    fprintf(stderr, "real_world_repl: %s\n", message);
    exit(1);
}

static void
handle_line(char *line)
{
    if (strncmp(line, "set ", 4) == 0) {
        if (sscanf(line + 4, "%63s %63s", key, value) != 2)
            fail("bad set");
    } else if (strncmp(line, "get ", 4) == 0) {
        if (strcmp(line + 4, key) != 0)
            fail("bad get key");
        if (strcmp(value, "1") != 0)
            fail("bad get value");
    } else if (strcmp(line, "history") == 0) {
        if (history_length != 3)
            fail("history command length");
    } else if (strcmp(line, "quit") != 0) {
        fail("unknown command");
    }
}

int
main(int argc, char **argv)
{
    char *line;

    if (argc != 2)
        fail("usage");

    clear_history();
    for (;;) {
        line = readline("kv> ");
        if (line == NULL)
            fail("unexpected eof");
        add_history(line);
        handle_line(line);
        if (strcmp(line, "quit") == 0) {
            free(line);
            break;
        }
        free(line);
    }

    if (history_length != 4)
        fail("final history length");
    if (write_history(argv[1]) != 0)
        fail("write history");
    clear_history();
    if (read_history(argv[1]) != 0)
        fail("read history");
    if (history_length != 4)
        fail("persisted history length");
    if (strcmp(history_get(history_base)->line, "set alpha 1") != 0)
        fail("persisted first command");

    return 0;
}
