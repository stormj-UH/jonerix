#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <readline/history.h>

static void
expect_expand(const char *message, char *input, int expected_result,
    const char *expected_output)
{
    char *output = NULL;
    int result;

    result = history_expand(input, &output);
    if (result != expected_result) {
        fprintf(stderr, "history_modifier_edges: %s: result %d != %d\n",
            message, result, expected_result);
        exit(1);
    }
    if (output == NULL || strcmp(output, expected_output) != 0) {
        fprintf(stderr, "history_modifier_edges: %s: output <%s> != <%s>\n",
            message, output == NULL ? "(null)" : output, expected_output);
        exit(1);
    }
    free(output);
}

int
main(void)
{
    clear_history();
    history_base = 1;
    add_history("echo alpha beta alpha");
    add_history("cmd /a/b/c.txt one two");

    expect_expand("quoted global substitution", "!-2:gs/alpha/x/:q", 1,
        "'echo x beta x'");
    expect_expand("last word head modifier", "!!:$:h", 1, "two");
    expect_expand("last word tail modifier", "!!:$:t", 1, "two");
    expect_expand("zero through first argument", "!!:0-1", 1,
        "cmd /a/b/c.txt");
    expect_expand("first through last argument", "!!:^-$", 1,
        "/a/b/c.txt one two");
    expect_expand("word substitution modifier", "!-2:1:s/a/A/", 1,
        "Alpha");
    expect_expand("word global substitution modifier", "!-2:1:gs/a/A/", 1,
        "AlphA");
    expect_expand("failed substitution reports error", "!-2:s/zzz/x/", -1,
        ":s/zzz/x/: substitution failed");
    expect_expand("bad current-line word designator", "echo !#:1", -1,
        ":1: bad word specifier");

    return 0;
}
