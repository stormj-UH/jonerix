#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

#include <readline/readline.h>

static int attempted_calls;
static int entry_calls;
static int completion_rewrite_calls;
static int filename_rewrite_calls;
static int directory_rewrite_calls;
static int directory_completion_calls;
static int reentrant_directory_calls;
static int in_reentrant_directory_hook;
static int replacement_directory_calls;
static int filename_stat_calls;
static int identity_dequote_calls;
static int identity_quote_calls;

static const char *input_text;
static const char *reentrant_query;
static const char *reentrant_expected;
static const char *replacement_directory;
static const char *filename_stat_target;
static int input_pos;

static void
fail(const char *message)
{
    fprintf(stderr, "completion_hook_semantics: %s\n", message);
    exit(1);
}

static char *
copy_string(const char *value)
{
    size_t len = strlen(value);
    char *copy = malloc(len + 1);
    if (copy == NULL)
        fail("malloc string");
    memcpy(copy, value, len + 1);
    return copy;
}

static int
test_getc(FILE *stream)
{
    (void)stream;
    if (input_text[input_pos] == '\0')
        return EOF;
    return input_text[input_pos++];
}

static char **
unexpected_attempted_completion(const char *text, int start, int end)
{
    (void)text;
    (void)start;
    (void)end;
    attempted_calls++;
    return NULL;
}

static char *
fallback_generator(const char *text, int state)
{
    if (strcmp(text, "fall") != 0)
        fail("fallback text");
    entry_calls++;
    if (state == 0)
        return copy_string("fallback");
    return NULL;
}

static char *
completion_rewrite_hook(char *text, int len)
{
    if (text == NULL || len < 0)
        fail("completion rewrite argument");
    completion_rewrite_calls++;
    return text;
}

static char *
completion_rewrite_to_ap(char *text, int len)
{
    (void)len;
    if (text == NULL || strcmp(text, "zz") != 0)
        fail("completion rewrite remap argument");
    return copy_string("ap");
}

static char *
filename_rewrite_hook(char *text, int len)
{
    (void)len;
    if (text == NULL)
        fail("filename rewrite argument");
    filename_rewrite_calls++;
    return copy_string(text);
}

static char *
filename_rewrite_alias(char *text, int len)
{
    (void)len;
    if (text == NULL)
        fail("filename rewrite alias argument");
    if (strcmp(text, "actual") == 0)
        return copy_string("alias");
    return text;
}

static char *
filename_stat_hook(char *text, int len)
{
    (void)len;
    if (text == NULL || strstr(text, "stat-file") == NULL)
        fail("filename stat hook argument");
    filename_stat_calls++;
    return copy_string(filename_stat_target);
}

static char *
identity_dequote_hook(char *text, int quote_char)
{
    (void)quote_char;
    if (text == NULL)
        fail("identity dequote argument");
    identity_dequote_calls++;
    return text;
}

static char *
identity_quote_hook(char *text, int match_type, char *quote_ptr)
{
    (void)match_type;
    (void)quote_ptr;
    if (text == NULL)
        fail("identity quote argument");
    identity_quote_calls++;
    return text;
}

static int
directory_rewrite_hook(char **dirname)
{
    if (dirname == NULL || *dirname == NULL)
        fail("directory rewrite argument");
    directory_rewrite_calls++;
    return 0;
}

static int
directory_completion_hook(char **dirname)
{
    if (dirname == NULL || *dirname == NULL)
        fail("directory completion argument");
    directory_completion_calls++;
    return 0;
}

static int
reentrant_directory_completion_hook(char **dirname)
{
    char *item;

    if (dirname == NULL || *dirname == NULL)
        fail("reentrant directory completion argument");
    reentrant_directory_calls++;
    if (in_reentrant_directory_hook)
        return 0;

    in_reentrant_directory_hook = 1;
    item = rl_filename_completion_function(reentrant_query, 0);
    if (item == NULL || strcmp(item, reentrant_expected) != 0)
        fail("reentrant filename completion result");
    free(item);
    in_reentrant_directory_hook = 0;
    return 0;
}

static int
replacement_directory_completion_hook(char **dirname)
{
    if (dirname == NULL || *dirname == NULL)
        fail("replacement directory completion argument");
    replacement_directory_calls++;
    free(*dirname);
    *dirname = copy_string(replacement_directory);
    return 1;
}

static void
write_empty_file(const char *path)
{
    FILE *file = fopen(path, "w");
    if (file == NULL)
        fail("fopen");
    fclose(file);
}

static void
make_dir(const char *path)
{
    if (mkdir(path, 0700) != 0)
        fail("mkdir");
}

static void
reset_input(const char *text)
{
    input_text = text;
    input_pos = 0;
    rl_getc_function = test_getc;
}

static void
check_direct_inhibit(void)
{
    rl_attempted_completion_function = unexpected_attempted_completion;
    rl_completion_entry_function = fallback_generator;
    rl_inhibit_completion = 1;
    rl_replace_line("ab", 0);
    rl_point = 2;

    if (rl_complete(1, '\t') != 0)
        fail("direct inhibit complete");
    if (rl_line_buffer == NULL || strcmp(rl_line_buffer, "ab\t") != 0)
        fail("direct inhibit inserted tab");
    if (rl_point != 3 || rl_end != 3)
        fail("direct inhibit point");
    if (attempted_calls != 0 || entry_calls != 0)
        fail("direct inhibit invoked completer");

    rl_inhibit_completion = 0;
    rl_attempted_completion_function = NULL;
    rl_completion_entry_function = NULL;
}

static void
check_readline_inhibit(void)
{
    char *line;

    attempted_calls = 0;
    entry_calls = 0;
    rl_attempted_completion_function = unexpected_attempted_completion;
    rl_completion_entry_function = fallback_generator;
    rl_inhibit_completion = 1;
    reset_input("al\t\n");

    line = readline("");
    if (line == NULL || strcmp(line, "al\t") != 0)
        fail("readline inhibit inserted tab");
    if (attempted_calls != 0 || entry_calls != 0)
        fail("readline inhibit invoked completer");
    free(line);

    rl_inhibit_completion = 0;
    rl_attempted_completion_function = NULL;
    rl_completion_entry_function = NULL;
    rl_getc_function = NULL;
}

static void
check_entry_function_fallback(void)
{
    char *line;

    entry_calls = 0;
    rl_completion_entry_function = fallback_generator;
    reset_input("fall\t\n");

    line = readline("");
    if (line == NULL || strcmp(line, "fallback ") != 0)
        fail("fallback generator insertion");
    if (entry_calls < 2)
        fail("fallback generator not used");
    free(line);

    rl_completion_entry_function = NULL;
    rl_getc_function = NULL;
}

static void
check_filename_completion_directory_hook(const char *tmp)
{
    char path[256];
    char query[256];
    char *item;

    directory_completion_calls = 0;
    snprintf(path, sizeof(path), "%s/plain", tmp);
    write_empty_file(path);
    snprintf(query, sizeof(query), "%s/pl", tmp);

    rl_directory_completion_hook = directory_completion_hook;
    item = rl_filename_completion_function(query, 0);
    if (item == NULL)
        fail("filename completion item");
    snprintf(path, sizeof(path), "%s/plain", tmp);
    if (strcmp(item, path) != 0)
        fail("filename completion result");
    free(item);
    if (directory_completion_calls != 1)
        fail("directory completion hook not called");

    rl_directory_completion_hook = NULL;
    snprintf(path, sizeof(path), "%s/plain", tmp);
    unlink(path);
}

static void
check_filename_completion_reentrant_directory_hook(const char *tmp)
{
    char plain_path[256];
    char nested_path[256];
    char plain_query[256];
    char nested_query[256];
    char *item;

    reentrant_directory_calls = 0;
    in_reentrant_directory_hook = 0;

    snprintf(plain_path, sizeof(plain_path), "%s/plain", tmp);
    snprintf(nested_path, sizeof(nested_path), "%s/nested", tmp);
    snprintf(plain_query, sizeof(plain_query), "%s/pl", tmp);
    snprintf(nested_query, sizeof(nested_query), "%s/ne", tmp);
    write_empty_file(plain_path);
    write_empty_file(nested_path);

    reentrant_query = nested_query;
    reentrant_expected = nested_path;
    rl_directory_completion_hook = reentrant_directory_completion_hook;

    item = rl_filename_completion_function(plain_query, 0);
    if (item == NULL || strcmp(item, plain_path) != 0)
        fail("outer filename completion result");
    free(item);
    if (reentrant_directory_calls < 2)
        fail("reentrant directory hook not called");

    rl_directory_completion_hook = NULL;
    reentrant_query = NULL;
    reentrant_expected = NULL;
    snprintf(plain_path, sizeof(plain_path), "%s/plain", tmp);
    unlink(plain_path);
    snprintf(nested_path, sizeof(nested_path), "%s/nested", tmp);
    unlink(nested_path);
}

static void
check_filename_completion_replacement_directory_hook(const char *tmp)
{
    char source_dir[256];
    char target_dir[256];
    char replacement_dir[256];
    char target_path[256];
    char query[256];
    char *item;

    replacement_directory_calls = 0;

    snprintf(source_dir, sizeof(source_dir), "%s/source", tmp);
    snprintf(target_dir, sizeof(target_dir), "%s/target", tmp);
    snprintf(replacement_dir, sizeof(replacement_dir), "%s/", target_dir);
    snprintf(target_path, sizeof(target_path), "%s/plain", target_dir);
    snprintf(query, sizeof(query), "%s/pl", source_dir);

    make_dir(source_dir);
    make_dir(target_dir);
    write_empty_file(target_path);

    replacement_directory = replacement_dir;
    rl_directory_completion_hook = replacement_directory_completion_hook;
    item = rl_filename_completion_function(query, 0);
    if (item == NULL || strcmp(item, target_path) != 0)
        fail("replacement directory completion result");
    free(item);
    if (replacement_directory_calls != 1)
        fail("replacement directory hook not called");

    rl_directory_completion_hook = NULL;
    replacement_directory = NULL;
    unlink(target_path);
    rmdir(source_dir);
    rmdir(target_dir);
}

static void
check_filename_rewrite_matching(const char *tmp)
{
    char path[256];
    char query[256];
    char expected[256];
    char *item;

    snprintf(path, sizeof(path), "%s/apple", tmp);
    write_empty_file(path);
    snprintf(query, sizeof(query), "%s/zz", tmp);

    rl_completion_rewrite_hook = completion_rewrite_to_ap;
    item = rl_filename_completion_function(query, 0);
    if (item == NULL || strcmp(item, path) != 0)
        fail("completion rewrite remap result");
    free(item);
    rl_completion_rewrite_hook = NULL;
    unlink(path);

    snprintf(path, sizeof(path), "%s/actual", tmp);
    snprintf(expected, sizeof(expected), "%s/alias", tmp);
    snprintf(query, sizeof(query), "%s/al", tmp);
    write_empty_file(path);

    rl_filename_rewrite_hook = filename_rewrite_alias;
    item = rl_filename_completion_function(query, 0);
    if (item == NULL || strcmp(item, expected) != 0)
        fail("filename rewrite alias result");
    free(item);
    rl_filename_rewrite_hook = NULL;
    unlink(path);
}

static void
check_filename_stat_hook_marking(const char *tmp)
{
    char file_path[256];
    char target_dir[256];
    char query[256];
    char expected[256];
    char *item;

    filename_stat_calls = 0;
    snprintf(file_path, sizeof(file_path), "%s/stat-file", tmp);
    snprintf(target_dir, sizeof(target_dir), "%s/stat-target", tmp);
    snprintf(query, sizeof(query), "%s/stat-fi", tmp);
    snprintf(expected, sizeof(expected), "%s/stat-file/", tmp);

    write_empty_file(file_path);
    make_dir(target_dir);

    filename_stat_target = target_dir;
    rl_filename_stat_hook = filename_stat_hook;
    item = rl_filename_completion_function(query, 0);
    if (item == NULL || strcmp(item, expected) != 0)
        fail("filename stat hook mark result");
    free(item);
    if (filename_stat_calls != 1)
        fail("filename stat hook not called");

    rl_filename_stat_hook = NULL;
    filename_stat_target = NULL;
    unlink(file_path);
    rmdir(target_dir);
}

static void
check_filename_quote_dequote_identity_hooks(const char *tmp)
{
    char expected[256];
    char input[256];
    char path[256];
    char query[256];
    char *item;
    char *line;

    identity_dequote_calls = 0;
    identity_quote_calls = 0;
    snprintf(path, sizeof(path), "%s/identity", tmp);
    snprintf(query, sizeof(query), "%s/id", tmp);
    write_empty_file(path);

    rl_filename_dequoting_function = identity_dequote_hook;
    item = rl_filename_completion_function(query, 0);
    if (item == NULL || strcmp(item, path) != 0)
        fail("identity dequote result");
    free(item);
    if (identity_dequote_calls != 1)
        fail("identity dequote not called");

    rl_filename_quoting_desired = 1;
    rl_filename_quoting_function = identity_quote_hook;
    rl_completer_quote_characters = "\"'";
    rl_filename_quote_characters = "i";
    snprintf(input, sizeof(input), "%s/id\t\n", tmp);
    snprintf(expected, sizeof(expected), "%s ", path);
    reset_input(input);
    line = readline("");
    if (line == NULL || strcmp(line, expected) != 0)
        fail("identity quote result");
    free(line);
    if (identity_quote_calls != 1)
        fail("identity quote not called");

    rl_filename_dequoting_function = NULL;
    rl_filename_quoting_function = NULL;
    rl_completer_quote_characters = NULL;
    rl_filename_quote_characters = NULL;
    rl_getc_function = NULL;
    unlink(path);
}

static void
check_filename_rewrite_hooks(const char *tmp)
{
    char path[256];
    char query[256];
    char *line;

    completion_rewrite_calls = 0;
    filename_rewrite_calls = 0;
    directory_rewrite_calls = 0;
    directory_completion_calls = 0;

    snprintf(path, sizeof(path), "%s/apple", tmp);
    write_empty_file(path);
    snprintf(path, sizeof(path), "%s/apricot", tmp);
    write_empty_file(path);
    snprintf(query, sizeof(query), "%s/ap\t\n", tmp);

    rl_completion_rewrite_hook = completion_rewrite_hook;
    rl_filename_rewrite_hook = filename_rewrite_hook;
    rl_directory_rewrite_hook = directory_rewrite_hook;
    rl_directory_completion_hook = directory_completion_hook;
    reset_input(query);

    line = readline("");
    if (line == NULL)
        fail("filename rewrite line");
    if (completion_rewrite_calls != 1)
        fail("completion rewrite hook not called");
    if (filename_rewrite_calls < 2)
        fail("filename rewrite hook not called");
    if (directory_rewrite_calls != 1)
        fail("directory rewrite hook not called");
    if (directory_completion_calls != 1)
        fail("directory completion hook not called during completion");
    free(line);

    rl_completion_rewrite_hook = NULL;
    rl_filename_rewrite_hook = NULL;
    rl_directory_rewrite_hook = NULL;
    rl_directory_completion_hook = NULL;
    rl_getc_function = NULL;
    snprintf(path, sizeof(path), "%s/apple", tmp);
    unlink(path);
    snprintf(path, sizeof(path), "%s/apricot", tmp);
    unlink(path);
}

int
main(void)
{
    char tmp[] = "/tmp/readlineoxide-hooks-XXXXXX";

    if (mkdtemp(tmp) == NULL)
        fail("mkdtemp");
    alarm(10);

    check_direct_inhibit();
    check_readline_inhibit();
    check_entry_function_fallback();
    check_filename_completion_directory_hook(tmp);
    check_filename_completion_reentrant_directory_hook(tmp);
    check_filename_completion_replacement_directory_hook(tmp);
    check_filename_rewrite_matching(tmp);
    check_filename_stat_hook_marking(tmp);
    check_filename_quote_dequote_identity_hooks(tmp);
    check_filename_rewrite_hooks(tmp);

    rmdir(tmp);
    return 0;
}
