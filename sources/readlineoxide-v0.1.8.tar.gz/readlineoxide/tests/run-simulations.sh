#!/bin/sh
set -eu

script_dir=$(dirname "$0")
repo=$(CDPATH= cd "$script_dir/.." && pwd)
build_dir=$repo/target/release
tmp=${TMPDIR:-/tmp}/readlineoxide-sim-$$
cc=${CC:-cc}
link_mode=${READLINEOXIDE_LINK:-dynamic}

cleanup() {
    rm -rf "$tmp"
}
trap cleanup EXIT HUP INT TERM

mkdir -p "$tmp"

if [ "$link_mode" = static ]; then
    cargo rustc -p readlineoxide-readline --release --locked --lib --crate-type staticlib
elif [ "$link_mode" = dynamic ]; then
    cargo build --release --locked
else
    printf '%s\n' "READLINEOXIDE_LINK must be dynamic or static" >&2
    exit 2
fi

compile() {
    src=$1
    exe=$tmp/${src%.c}
    if [ "$link_mode" = static ]; then
        "$cc" ${CFLAGS:-} -I "$repo/include" "$repo/tests/$src" \
            "$build_dir/libreadline.a" -o "$exe"
    else
        "$cc" ${CFLAGS:-} -I "$repo/include" -L "$build_dir" \
            -Wl,-rpath,"$build_dir" "$repo/tests/$src" \
            -lreadline -lhistory -o "$exe"
    fi
}

run() {
    name=$1
    shift
    if [ "$link_mode" = static ]; then
        "$tmp/$name" "$@"
    else
        DYLD_LIBRARY_PATH=$build_dir LD_LIBRARY_PATH=$build_dir "$tmp/$name" "$@"
    fi
}

compile history_basic.c
compile history_file.c
compile history_state_restore.c
compile readline_pipe.c
compile callback_repl.c
compile callback_incremental.c
compile callback_done.c
compile callback_operate_next.c
compile callback_hardening.c
compile completion.c
compile completion_extended.c
compile completion_internal_semantics.c
compile completion_quote_semantics.c
compile completion_display.c
compile display_message_semantics.c
compile dumper_semantics.c
compile timeout_signal_semantics.c
compile completion_hook_semantics.c
compile consumer_abi.c
compile history_expand.c
compile history_expand_semantics.c
compile history_search_extended.c
compile noninc_search_semantics.c
compile prompt_abi_semantics.c
compile real_world_repl.c
compile edit_commands.c
compile keyseq_inputrc.c
compile completion_semantics.c
compile keyseq_macro_semantics.c
compile keymap_funmap_semantics.c
compile inputrc_conditionals.c
compile inputrc_path_semantics.c
compile inputrc_quoted_semantics.c
compile tilde_semantics.c
compile vi_wrapper_semantics.c
compile vi_wrapper_extended.c
compile vi_input_semantics.c
compile input_queue_semantics.c
compile char_search_semantics.c
compile line_buffer_capacity.c
compile history_modifier_edges.c
compile state_semantics.c

failed=0

run_case() {
    name=$1
    shift
    if run "$name" "$@"; then
        :
    else
        printf '%s\n' "readlineoxide simulation failed: $name" >&2
        failed=1
    fi
}

run_pipe_case() {
    name=$1
    input=$2
    shift 2
    if printf '%s' "$input" | run "$name" "$@"; then
        :
    else
        printf '%s\n' "readlineoxide simulation failed: $name" >&2
        failed=1
    fi
}

run_case history_basic
run_case history_file "$tmp/history.txt"
run_case history_state_restore
run_pipe_case readline_pipe 'select * from users;
'
run_pipe_case callback_repl 'status
exit
'
run_case callback_incremental
run_case callback_done
run_case callback_operate_next
run_case callback_hardening
run_case completion
run_case completion_extended
run_case completion_internal_semantics
run_case completion_quote_semantics
run_case completion_display
run_case display_message_semantics
run_case dumper_semantics
run_case timeout_signal_semantics
run_case completion_hook_semantics
run_case consumer_abi
run_case history_expand
run_case history_expand_semantics
run_case history_search_extended
run_case noninc_search_semantics
run_case prompt_abi_semantics
run_case edit_commands
run_case keyseq_inputrc "$tmp/inputrc"
run_case completion_semantics
run_case keyseq_macro_semantics "$tmp/inputrc2"
run_case keymap_funmap_semantics
run_case inputrc_conditionals "$tmp/inputrc-conditionals"
run_case inputrc_path_semantics "$tmp/inputrc-path"
run_case inputrc_quoted_semantics "$tmp/inputrc-quoted"
run_case tilde_semantics "$tmp/tilde-home"
run_case vi_wrapper_semantics
run_case vi_wrapper_extended
run_case vi_input_semantics
run_case input_queue_semantics
run_case char_search_semantics
run_case line_buffer_capacity
run_case history_modifier_edges
run_case state_semantics
run_pipe_case real_world_repl 'set alpha 1
get alpha
history
quit
' "$tmp/repl.hist"

if [ "$failed" -ne 0 ]; then
    exit 1
fi

printf '%s\n' "readlineoxide simulations: ok"
