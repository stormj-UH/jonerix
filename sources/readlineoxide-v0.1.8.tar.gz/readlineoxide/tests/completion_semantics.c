#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <readline/readline.h>

static const char *items[] = {
    "beta",
    "alpha",
    "alpha",
    "alpine",
    "aardvark",
    "arc",
    NULL
};

static int filter_called;
static int quote_called;
static int quote_match_type;
static int fallback_called;

static const char *active_input;
static int input_pos;

static void
fail(const char *message)
{
    fprintf(stderr, "completion_semantics: %s\n", message);
    exit(1);
}

static char *
copy_string(const char *value)
{
    size_t len = strlen(value);
    char *copy = malloc(len + 1);
    if (copy == NULL)
        return NULL;
    memcpy(copy, value, len + 1);
    return copy;
}

static char *
generator(const char *text, int state)
{
    static int index;
    size_t len = strlen(text);

    if (state == 0)
        index = 0;
    while (items[index] != NULL) {
        const char *item = items[index++];
        if (strncmp(item, text, len) == 0) {
            return copy_string(item);
        }
    }
    return NULL;
}

static void
free_matches(char **matches)
{
    int i;

    if (matches == NULL)
        return;
    for (i = 0; matches[i] != NULL; i++)
        free(matches[i]);
    free(matches);
}

static int
filter_matches(char **matches)
{
    int read_idx;
    int write_idx = 1;

    filter_called++;
    for (read_idx = 1; matches[read_idx] != NULL; read_idx++) {
        if (strcmp(matches[read_idx], "alpine") == 0) {
            free(matches[read_idx]);
            continue;
        }
        matches[write_idx++] = matches[read_idx];
    }
    matches[write_idx] = NULL;
    return 0;
}

static char *
quote_filename(char *text, int match_type, char *quote_ptr)
{
    char *copy;

    (void)quote_ptr;
    if (text == NULL)
        fail("quote text");
    quote_called++;
    quote_match_type = match_type;
    copy = copy_string("quoted-value");
    if (copy == NULL)
        fail("quote allocation");
    return copy;
}

static char **
attempted_completion(const char *text, int start, int end)
{
    (void)start;
    (void)end;
    rl_filename_completion_desired = 1;
    return rl_completion_matches(text, generator);
}

static char **
attempted_full_quote_completion(const char *text, int start, int end)
{
    (void)start;
    (void)end;
    rl_full_quoting_desired = 1;
    return rl_completion_matches(text, generator);
}

static char *
fallback_generator(const char *text, int state)
{
    (void)text;
    if (state != 0)
        return NULL;
    fallback_called++;
    return copy_string("fallback");
}

static int
test_getc(FILE *stream)
{
    (void)stream;
    if (active_input[input_pos] == '\0')
        return EOF;
    return active_input[input_pos++];
}

static char *
read_test_line(const char *input)
{
    active_input = input;
    input_pos = 0;
    rl_getc_function = test_getc;
    return readline("");
}

int
main(void)
{
    char **matches;
    char *line;

    rl_ignore_completion_duplicates = 1;
    rl_sort_completion_matches = 1;
    matches = rl_completion_matches("a", generator);
    if (matches == NULL)
        fail("sorted matches null");
    if (strcmp(matches[0], "a") != 0)
        fail("sorted common prefix");
    if (strcmp(matches[1], "alpha") != 0)
        fail("raw first");
    if (strcmp(matches[2], "alpha") != 0)
        fail("raw duplicate preserved");
    if (strcmp(matches[3], "alpine") != 0)
        fail("raw third");
    if (strcmp(matches[4], "aardvark") != 0)
        fail("raw fourth");
    if (strcmp(matches[5], "arc") != 0)
        fail("raw fifth");
    if (matches[6] != NULL)
        fail("raw terminator");
    free_matches(matches);

    rl_ignore_completion_duplicates = 0;
    rl_sort_completion_matches = 0;
    matches = rl_completion_matches("a", generator);
    if (matches == NULL)
        fail("unsorted matches null");
    if (strcmp(matches[1], "alpha") != 0)
        fail("unsorted first");
    if (strcmp(matches[2], "alpha") != 0)
        fail("unsorted duplicate kept");
    if (strcmp(matches[3], "alpine") != 0)
        fail("unsorted third");
    if (strcmp(matches[4], "aardvark") != 0)
        fail("unsorted fourth");
    if (strcmp(matches[5], "arc") != 0)
        fail("unsorted fifth");
    if (matches[6] != NULL)
        fail("unsorted terminator");
    free_matches(matches);

    rl_inhibit_completion = 1;
    line = read_test_line("ab\tc\n");
    if (line == NULL || strcmp(line, "ab\tc") != 0)
        fail("inhibit completion");
    free(line);
    rl_inhibit_completion = 0;

    rl_completion_entry_function = fallback_generator;
    rl_completion_suppress_append = 1;
    line = read_test_line("fa\t\n");
    if (line == NULL || strcmp(line, "fallback ") != 0)
        fail("completion suppress reset");
    if (fallback_called == 0)
        fail("fallback generator not called");
    free(line);
    rl_completion_append_character = 0;
    line = read_test_line("fa\t\n");
    if (line == NULL || strcmp(line, "fallback ") != 0)
        fail("completion append reset");
    free(line);
    rl_attempted_completion_over = 1;
    line = read_test_line("fa\t\n");
    if (line == NULL || strcmp(line, "fallback ") != 0)
        fail("completion attempted over reset");
    if (rl_attempted_completion_over != 0)
        fail("completion attempted over stale");
    free(line);
    rl_completion_entry_function = rl_filename_completion_function;
    rl_completion_suppress_append = 0;

    rl_attempted_completion_function = attempted_completion;
    rl_ignore_some_completions_function = filter_matches;
    rl_filename_quoting_function = quote_filename;
    rl_completer_quote_characters = "\"'";
    rl_filename_quote_characters = "z";
    quote_called = 0;
    line = read_test_line("al\t\n");
    if (line == NULL || strcmp(line, "alp") != 0)
        fail("quote hook skipped without quote character");
    if (quote_called != 0)
        fail("quote hook called without quote character");
    free(line);

    rl_filename_quote_characters = "a";
    rl_completion_suppress_quote = 1;
    quote_called = 0;
    quote_match_type = 0;
    line = read_test_line("al\t\n");
    if (line == NULL || strcmp(line, "quoted-value") != 0)
        fail("quote hook insertion");
    if (filter_called < 2)
        fail("filter hook not called");
    if (quote_called == 0)
        fail("quote hook not called");
    if (quote_match_type != MULT_MATCH)
        fail("quote hook match type");
    if (rl_completion_suppress_quote != 0)
        fail("completion suppress quote reset");
    free(line);

    rl_attempted_completion_function = attempted_full_quote_completion;
    quote_called = 0;
    line = read_test_line("al\t\n");
    if (line == NULL || strcmp(line, "quoted-value") != 0)
        fail("full quote hook insertion");
    if (quote_called == 0)
        fail("full quote hook not called");
    free(line);

    rl_getc_function = NULL;
    rl_attempted_completion_function = NULL;
    rl_ignore_some_completions_function = NULL;
    rl_filename_quoting_function = NULL;
    rl_filename_quote_characters = NULL;
    rl_completer_quote_characters = NULL;
    return 0;
}
