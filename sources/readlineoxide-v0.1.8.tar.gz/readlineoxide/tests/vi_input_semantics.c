#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <readline/readline.h>
#include <readline/history.h>

static const char *active_input;
static int input_pos;

static void
fail(const char *message)
{
    fprintf(stderr, "vi_input_semantics: %s\n", message);
    exit(1);
}

static int
test_getc(FILE *stream)
{
    (void)stream;
    if (active_input[input_pos] == '\0')
        return EOF;
    return active_input[input_pos++];
}

static void
expect_readline(const char *name, const char *input, const char *expected,
    int expected_point)
{
    char *line;

    if (rl_variable_bind("editing-mode", "vi") != 0)
        fail("vi mode");
    active_input = input;
    input_pos = 0;
    rl_getc_function = test_getc;
    line = readline("");
    if (line == NULL || strcmp(line, expected) != 0 || rl_point != expected_point) {
        fprintf(stderr,
            "vi_input_semantics: %s: line <%s> point %d, expected <%s> point %d\n",
            name, line == NULL ? "(null)" : line, rl_point, expected,
            expected_point);
        exit(1);
    }
    free(line);
}

int
main(void)
{
    clear_history();
    add_history("zero command");
    add_history("alpha one");
    add_history("beta two");
    add_history("alpha two");

    expect_readline("dw", "abc def\0330dw\n", "def", 0);
    expect_readline("de", "abc def\0330de\n", " def", 0);
    expect_readline("cw", "abc def\0330cwX\n", "X def", 1);
    expect_readline("dd", "abcdef\0330dd\n", "", 0);
    expect_readline("yyP", "abcdef\0330yyP\n", "abcdefabcdef", 5);
    expect_readline("r", "abc def\0330lrZ\n", "aZc def", 1);
    expect_readline("replace", "abcdef\0330llRZQ\033\n", "abZQef", 3);
    expect_readline("f", "abc def abc\0330fc\n", "abc def abc", 2);
    expect_readline("t", "abc def abc\0330tc\n", "abc def abc", 1);
    expect_readline("semicolon", "abc def abc\0330fc;\n", "abc def abc", 10);
    expect_readline("comma", "abc def abc\0330fc,\n", "abc def abc", 2);
    expect_readline("match-open", "a(b[c]d)e\0330l%\n", "a(b[c]d)e", 7);
    expect_readline("match-close", "a(b[c]d)e\0330lllll%\n", "a(b[c]d)e", 3);
    expect_readline("mark-goto", "abcdef\0330llma0`a\n", "abcdef", 2);

    if (!history_set_pos(0))
        fail("history start");
    expect_readline("vi-search-forward", "\033/alpha\n\n", "alpha one", 0);
    if (!history_set_pos(history_length))
        fail("history reverse start");
    expect_readline("vi-search-reverse", "\033?alpha\n\n", "alpha two", 0);
    if (!history_set_pos(0))
        fail("history repeat start");
    expect_readline("vi-search-repeat", "\033/alpha\nn\n", "alpha two", 0);

    rl_getc_function = NULL;
    return 0;
}
