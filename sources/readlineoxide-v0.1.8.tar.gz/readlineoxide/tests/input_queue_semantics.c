#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <readline/readline.h>

static const char *active_input;
static int input_pos;
static int getc_calls;

static void
fail(const char *message)
{
    fprintf(stderr, "input_queue_semantics: %s\n", message);
    exit(1);
}

static int
test_getc(FILE *stream)
{
    (void)stream;
    getc_calls++;
    if (active_input[input_pos] == '\0')
        return EOF;
    return active_input[input_pos++];
}

static char *
read_test_line(const char *input)
{
    active_input = input;
    input_pos = 0;
    rl_getc_function = test_getc;
    return readline("");
}

static void
expect_line(const char *message, const char *input, const char *expected)
{
    char *line;

    line = read_test_line(input);
    if (line == NULL || strcmp(line, expected) != 0) {
        fprintf(stderr, "input_queue_semantics: %s: <%s> != <%s>\n",
            message, line == NULL ? "(null)" : line, expected);
        exit(1);
    }
    free(line);
}

int
main(void)
{
    rl_pending_input = 'A';
    if (rl_stuff_char('B') != 1)
        fail("stuff char after pending input");
    expect_line("pending plus stuffed", "\n", "AB");

    if (rl_stuff_char('C') != 1)
        fail("stuff char first");
    if (rl_stuff_char('D') != 1)
        fail("stuff char second");
    expect_line("multiple stuffed chars", "\n", "CD");

    active_input = "G";
    input_pos = 0;
    getc_calls = 0;
    rl_getc_function = test_getc;
    if (rl_stuff_char(0) != 1)
        fail("stuff nul");
    if (rl_read_key() != 0)
        fail("read stuffed nul");
    if (getc_calls != 0)
        fail("stuffed nul avoided getc");
    if (rl_read_key() != 'G')
        fail("read after stuffed nul");
    if (getc_calls != 1)
        fail("getc after stuffed nul");

    if (rl_stuff_char('A') != 1 || rl_stuff_char('B') != 1)
        fail("stuff chars before clear");
    rl_pending_input = 'P';
    rl_clear_pending_input();
    expect_line("clear pending keeps stuffed", "G\n", "ABG");

    if (rl_stuff_char('S') != 1)
        fail("stuff char before macro");
    if (rl_push_macro_input("M\n") != 0)
        fail("push macro after stuff");
    expect_line("macro before stuffed", "\n", "M");
    expect_line("stuffed survives macro", "\n", "S");

    active_input = "Q";
    input_pos = 0;
    getc_calls = 0;
    rl_getc_function = test_getc;
    rl_replace_line("base", 0);
    rl_point = 2;
    if (rl_execute_next('E') != 0)
        fail("execute next");
    if (rl_pending_input != 'E')
        fail("execute next pending");
    if (rl_line_buffer == NULL || strcmp(rl_line_buffer, "base") != 0
        || rl_point != 2)
        fail("execute next edited line");
    if (getc_calls != 0)
        fail("execute next read input");
    if (rl_read_key() != 'E')
        fail("execute next read key");
    if (getc_calls != 0)
        fail("execute next avoided getc");

    rl_getc_function = NULL;
    return 0;
}
