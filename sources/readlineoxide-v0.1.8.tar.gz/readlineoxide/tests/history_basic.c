#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <readline/history.h>

static void
fail(const char *message)
{
    fprintf(stderr, "history_basic: %s\n", message);
    exit(1);
}

static void
expect_line(HIST_ENTRY *entry, const char *line)
{
    if (entry == NULL || entry->line == NULL || strcmp(entry->line, line) != 0)
        fail(line);
}

int
main(void)
{
    HIST_ENTRY **list;
    HIST_ENTRY *entry;

    using_history();
    clear_history();

    add_history("alpha");
    add_history("beta");
    add_history("gamma");
    if (history_length != 3)
        fail("length after add");
    if (where_history() != 0)
        fail("offset after add");

    list = history_list();
    if (list == NULL)
        fail("list is null");
    expect_line(list[0], "alpha");
    expect_line(list[1], "beta");
    expect_line(list[2], "gamma");
    if (list[3] != NULL)
        fail("list terminator");

    expect_line(history_get(history_base + 1), "beta");
    if (!history_set_pos(3))
        fail("set pos to end");
    expect_line(previous_history(), "gamma");
    if (where_history() != 2)
        fail("where after previous");

    entry = remove_history(1);
    expect_line(entry, "beta");
    free_history_entry(entry);
    if (history_length != 2)
        fail("length after remove");

    entry = replace_history_entry(0, "alpha2", (void *)0);
    expect_line(entry, "alpha");
    if (free_history_entry(entry) != NULL)
        fail("replace data");
    expect_line(history_get(history_base), "alpha2");

    add_history("timed");
    add_history_time("#12345");
    if (history_get_time(history_get(history_base + history_length - 1)) != (time_t)12345)
        fail("timestamp parse");

    stifle_history(2);
    add_history("delta");
    add_history("epsilon");
    if (!history_is_stifled())
        fail("stifle flag");
    if (history_length != 2)
        fail("stifle length");
    list = history_list();
    expect_line(list[0], "delta");
    expect_line(list[1], "epsilon");
    if (unstifle_history() != 2)
        fail("unstifle old size");

    clear_history();
    if (history_length != 0 || history_list()[0] != NULL)
        fail("clear");

    return 0;
}
