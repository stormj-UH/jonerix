#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <readline/readline.h>

static void
fail(const char *message)
{
    fprintf(stderr, "prompt_abi_semantics: %s\n", message);
    exit(1);
}

int
main(void)
{
    char plain[] = "abc> ";
    char hidden[] = "\001hidden\002vis> ";
    char multiline[] = "first\nabc> ";
    char multiline_short[] = "top\nabc> ";
    char multiline_space[] = "x\ny ";
    char multiline_two[] = "a\nbc\ndef";
    char multiline_trailing[] = "a\nbc\ndef\n";
    static char foreign_prompt[] = "foreign> ";
    static char foreign_display[] = "display> ";

    if (rl_display_prompt != NULL)
        fail("initial display prompt before initialize");
    if (rl_initialize() != 0)
        fail("initialize");
    if (rl_display_prompt == NULL)
        fail("initial display prompt");
    if (rl_line_buffer == NULL)
        fail("initial line buffer");
    if (!RL_ISSTATE(RL_STATE_INITIALIZED))
        fail("initialized state");
    if (rl_set_prompt(plain) != 0)
        fail("set prompt");
    if (rl_prompt == NULL || strcmp(rl_prompt, plain) != 0)
        fail("prompt value");
    if (rl_display_prompt == NULL || strcmp(rl_display_prompt, plain) != 0)
        fail("display prompt value");
    if (rl_visible_prompt_length != 5)
        fail("set prompt visible length");
    if (rl_expand_prompt(plain) != 5)
        fail("plain expand length");
    if (rl_visible_prompt_length != 5)
        fail("expand prompt does not update visible length");
    if (rl_expand_prompt(hidden) != 5)
        fail("hidden expand length");
    if (rl_expand_prompt(multiline) != 6)
        fail("multiline expand length");
    if (rl_expand_prompt(multiline_short) != 4)
        fail("short multiline expand length");
    if (rl_expand_prompt(multiline_space) != 2)
        fail("space multiline expand length");
    if (rl_expand_prompt(multiline_two) != 5)
        fail("two newline expand length");
    if (rl_expand_prompt(multiline_trailing) != 9)
        fail("trailing newline expand length");
    if (rl_set_prompt(multiline_two) != 0)
        fail("set multiline prompt");
    if (rl_visible_prompt_length != 5)
        fail("set multiline visible length");
    if (rl_set_prompt(rl_prompt) != 0)
        fail("set prompt from prompt alias");
    if (rl_prompt == NULL || strcmp(rl_prompt, multiline_two) != 0)
        fail("prompt alias value");
    if (rl_display_prompt == NULL || strcmp(rl_display_prompt, multiline_two) != 0)
        fail("display prompt alias value");
    if (rl_visible_prompt_length != 5)
        fail("prompt alias visible length");

    rl_prompt = foreign_prompt;
    rl_display_prompt = foreign_display;
    if (rl_set_prompt("owned> ") != 0)
        fail("replace foreign prompt");
    if (strcmp(foreign_prompt, "foreign> ") != 0)
        fail("foreign prompt mutated");
    if (strcmp(foreign_display, "display> ") != 0)
        fail("foreign display mutated");
    if (rl_prompt == NULL || strcmp(rl_prompt, "owned> ") != 0)
        fail("owned prompt value");
    if (rl_display_prompt == NULL || strcmp(rl_display_prompt, "owned> ") != 0)
        fail("owned display value");

    return 0;
}
