#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <readline/history.h>

static void
fail(const char *message)
{
    fprintf(stderr, "history_state_restore: %s\n", message);
    exit(1);
}

static char *
copy_string(const char *text)
{
    size_t len = strlen(text);
    char *copy = malloc(len + 1);

    if (copy == NULL)
        fail("malloc string");
    memcpy(copy, text, len + 1);
    return copy;
}

static void
expect_entry(int index, const char *line)
{
    HIST_ENTRY **list = history_list();

    if (list == NULL || list[index] == NULL || list[index]->line == NULL)
        fail("missing history entry");
    if (strcmp(list[index]->line, line) != 0)
        fail("history entry line");
}

int
main(void)
{
    HIST_ENTRY first[2];
    HIST_ENTRY second[1];
    HIST_ENTRY *first_entries[3];
    HIST_ENTRY *second_entries[2];
    HISTORY_STATE first_state;
    HISTORY_STATE second_state;

    first[0].line = copy_string("alpha one");
    first[0].timestamp = copy_string("#100");
    first[0].data = (void *)0x1234;
    first[1].line = copy_string("beta two");
    first[1].timestamp = NULL;
    first[1].data = NULL;
    first_entries[0] = &first[0];
    first_entries[1] = &first[1];
    first_entries[2] = NULL;
    first_state.entries = first_entries;
    first_state.offset = 1;
    first_state.length = 2;
    first_state.size = 2;
    first_state.flags = 1;

    second[0].line = copy_string("gamma three");
    second[0].timestamp = NULL;
    second[0].data = NULL;
    second_entries[0] = &second[0];
    second_entries[1] = NULL;
    second_state.entries = second_entries;
    second_state.offset = 0;
    second_state.length = 1;
    second_state.size = 0;
    second_state.flags = 0;

    history_set_history_state(&first_state);
    if (history_length != 2)
        fail("first length");
    if (where_history() != 1)
        fail("first offset");
    if (!history_is_stifled())
        fail("first stifled");
    expect_entry(0, "alpha one");
    expect_entry(1, "beta two");
    if (history_get_time(history_get(history_base)) != 100)
        fail("first timestamp");
    if (history_get(history_base)->data != (void *)0x1234)
        fail("first data");

    first[0].line[0] = 'X';
    expect_entry(0, "alpha one");

    history_set_history_state(&second_state);
    if (history_length != 1)
        fail("second length");
    if (where_history() != 0)
        fail("second offset");
    if (history_is_stifled())
        fail("second stifled");
    expect_entry(0, "gamma three");
    if (history_list()[1] != NULL)
        fail("second terminator");

    clear_history();
    free(first[0].line);
    free(first[0].timestamp);
    free(first[1].line);
    free(second[0].line);
    return 0;
}
