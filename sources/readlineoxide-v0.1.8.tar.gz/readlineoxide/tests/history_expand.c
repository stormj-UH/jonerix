#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <readline/history.h>

static void
fail(const char *message)
{
    fprintf(stderr, "history_expand: %s\n", message);
    exit(1);
}

static void
expect_expand(char *input, int expected_result, const char *expected_output)
{
    char *output = NULL;
    int result = history_expand(input, &output);

    if (result != expected_result)
        fail(input);
    if (output == NULL || strcmp(output, expected_output) != 0)
        fail(expected_output);
    free(output);
}

static void
free_tokens(char **tokens)
{
    int i;

    if (tokens == NULL)
        return;
    for (i = 0; tokens[i] != NULL; i++)
        free(tokens[i]);
    free(tokens);
}

int
main(void)
{
    char **tokens;
    char *arg;

    clear_history();
    add_history("alpha one");
    add_history("beta two");
    add_history("gamma one");
    history_set_pos(history_length);

    expect_expand("!!", 1, "gamma one");
    expect_expand("!-2", 1, "beta two");
    expect_expand("!be", 1, "beta two");
    expect_expand("!?mma?", 1, "gamma one");
    expect_expand("!!:$", 1, "one");
    expect_expand("!!:1", 1, "one");
    expect_expand("^one^two^", 1, "gamma two");
    expect_expand("plain", 0, "plain");

    clear_history();
    add_history("cmd 'two words' \"three four\" one\\ two");
    expect_expand("!!:1", 1, "'two words'");
    expect_expand("!!:2", 1, "\"three four\"");
    expect_expand("!!:3", 1, "one\\ two");
    expect_expand("!!:*", 1, "'two words' \"three four\" one\\ two");

    tokens = history_tokenize("cmd 'two words' tail");
    if (tokens == NULL)
        fail("tokens null");
    if (strcmp(tokens[0], "cmd") != 0)
        fail("token 0");
    if (strcmp(tokens[1], "'two words'") != 0)
        fail("token 1");
    if (strcmp(tokens[2], "tail") != 0)
        fail("token 2");
    if (tokens[3] != NULL)
        fail("token terminator");
    free_tokens(tokens);

    tokens = history_tokenize("cmd one\\ two tail");
    if (tokens == NULL)
        fail("escaped tokens null");
    if (strcmp(tokens[1], "one\\ two") != 0)
        fail("escaped token");
    free_tokens(tokens);

    tokens = history_tokenize("");
    if (tokens != NULL)
        fail("empty tokens");

    arg = history_arg_extract(1, -1, "cmd one two");
    if (arg == NULL || strcmp(arg, "one") != 0)
        fail("arg extract");
    free(arg);

    clear_history();
    add_history("alpha one");
    add_history("beta two");
    add_history("gamma one");
    history_set_pos(history_length - 1);
    if (history_search("two", -1) < 0)
        fail("search");
    if (where_history() != 1)
        fail("search pos");
    history_set_pos(history_length - 1);
    if (history_search_prefix("beta", -1) != 0)
        fail("search prefix");
    if (where_history() != 1)
        fail("search prefix pos");

    return 0;
}
