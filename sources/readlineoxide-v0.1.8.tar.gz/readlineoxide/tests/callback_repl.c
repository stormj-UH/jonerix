#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <readline/readline.h>

static int calls;

static void
fail(const char *message)
{
    fprintf(stderr, "callback_repl: %s\n", message);
    exit(1);
}

static void
handler(char *line)
{
    if (line == NULL)
        fail("null callback line");

    if (calls == 0 && strcmp(line, "status") != 0)
        fail("first callback");
    if (calls == 1 && strcmp(line, "exit") != 0)
        fail("second callback");

    calls++;
    free(line);
}

int
main(void)
{
    int i;

    rl_callback_handler_install("app> ", handler);
    for (i = 0; i < 16 && calls < 2; i++)
        rl_callback_read_char();
    rl_callback_handler_remove();

    if (calls != 2)
        fail("call count");

    return 0;
}
