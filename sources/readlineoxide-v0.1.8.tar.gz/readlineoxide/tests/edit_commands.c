#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <readline/readline.h>

static void
fail(const char *message)
{
    fprintf(stderr, "edit_commands: %s\n", message);
    exit(1);
}

static void
expect_line(const char *message, const char *line, int point)
{
    if (rl_line_buffer == NULL || strcmp(rl_line_buffer, line) != 0)
        fail(message);
    if (rl_point != point)
        fail(message);
    if (rl_end != (int)strlen(line))
        fail(message);
}

int
main(void)
{
    char *copy;

    rl_replace_line("abcdef", 0);
    expect_line("replace", "abcdef", 0);

    if (rl_beginning_of_line(1, 0) != 0)
        fail("beginning");
    expect_line("beginning point", "abcdef", 0);
    if (rl_forward_char(2, 0) != 0)
        fail("forward");
    expect_line("forward point", "abcdef", 2);
    if (rl_backward_char(1, 0) != 0)
        fail("backward");
    expect_line("backward point", "abcdef", 1);
    if (rl_end_of_line(1, 0) != 0)
        fail("end");
    expect_line("end point", "abcdef", 6);

    rl_point = 2;
    if (rl_delete(2, 0) != 0)
        fail("delete");
    expect_line("delete text", "abef", 2);

    rl_replace_line("abcdef", 0);
    rl_point = 3;
    if (rl_delete_text(4, 2) != 2)
        fail("delete text reverse");
    expect_line("delete text reverse", "abef", 3);
    rl_point = 20;
    if (rl_delete_text(0, 2) != 2)
        fail("delete text clamps point");
    expect_line("delete text clamps point", "ef", 2);

    rl_replace_line("abcdef", 0);
    rl_point = 3;
    copy = rl_copy_text(4, 1);
    if (copy == NULL || strcmp(copy, "bcd") != 0)
        fail("copy text reverse");
    rl_free(copy);
    copy = rl_copy_text(-2, 2);
    if (copy == NULL || strcmp(copy, "") != 0)
        fail("copy text negative");
    rl_free(copy);

    rl_point = 3;
    if (rl_rubout(2, 0) != 0)
        fail("rubout");
    expect_line("rubout text", "adef", 1);

    rl_replace_line("abcdef", 0);
    rl_point = 3;
    if (rl_kill_text(4, 1) != 0)
        fail("kill text reverse");
    expect_line("kill text reverse", "aef", 3);
    rl_replace_line("XY", 0);
    rl_point = 1;
    if (rl_yank(1, 0) != 0)
        fail("yank reverse kill");
    expect_line("yank reverse kill", "XbcdY", 4);

    rl_replace_line("abcdef", 0);
    if (rl_kill_text(1, 3) != 0)
        fail("first direct kill");
    if (rl_kill_text(1, 3) != 0)
        fail("second direct kill");
    rl_replace_line("XY", 0);
    rl_point = 1;
    if (rl_yank(1, 0) != 0)
        fail("yank appended kills");
    expect_line("yank appended kills", "XbcdeY", 5);

    rl_replace_line("prefix suffix", 0);
    rl_point = 6;
    if (rl_unix_line_discard(1, 0) != 0)
        fail("unix discard");
    expect_line("unix discard text", " suffix", 0);

    rl_replace_line("prefix suffix", 0);
    rl_point = 6;
    if (rl_kill_line(1, 0) != 0)
        fail("kill line");
    expect_line("kill line text", "prefix", 6);

    if (rl_yank(1, 0) != 0)
        fail("yank");
    expect_line("yank text", "prefix suffix", 13);

    rl_replace_line("one two", 0);
    rl_point = 4;
    if (rl_kill_word(1, 0) != 0)
        fail("kill word");
    expect_line("kill word text", "one ", 4);
    if (rl_yank(1, 0) != 0)
        fail("yank word");
    expect_line("yank word text", "one two", 7);

    rl_set_retained_kills(2);
    rl_replace_line("first second", 1);
    rl_point = 0;
    if (rl_kill_word(1, 0) != 0)
        fail("kill ring first");
    expect_line("kill ring first text", " second", 0);
    rl_replace_line("third fourth", 1);
    rl_point = 0;
    if (rl_kill_word(1, 0) != 0)
        fail("kill ring second");
    expect_line("kill ring second text", " fourth", 0);
    rl_replace_line("X", 1);
    rl_point = 1;
    if (rl_yank(1, 0) != 0)
        fail("kill ring yank");
    expect_line("kill ring yank text", "Xthird", 6);
    if (rl_yank_pop(1, 0) != 0)
        fail("kill ring yank pop");
    expect_line("kill ring yank pop text", "Xfirst", 6);
    if (rl_yank_pop(1, 0) != 0)
        fail("kill ring yank pop wrap");
    expect_line("kill ring yank pop wrap text", "Xthird", 6);
    if (rl_insert_text("!") != 1)
        fail("kill ring break yank");
    if (rl_yank_pop(1, 0) != 0)
        fail("kill ring inactive yank pop");
    expect_line("kill ring inactive yank pop text", "Xthird!", 7);

    rl_replace_line("first second", 1);
    rl_point = 0;
    if (rl_kill_word(1, 0) != 0)
        fail("kill ring undo first");
    rl_replace_line("third fourth", 1);
    rl_point = 0;
    if (rl_kill_word(1, 0) != 0)
        fail("kill ring undo second");
    rl_replace_line("X", 1);
    rl_point = 1;
    if (rl_yank(1, 0) != 0)
        fail("kill ring undo yank");
    expect_line("kill ring undo yank text", "Xthird", 6);
    if (rl_yank_pop(1, 0) != 0)
        fail("kill ring undo yank pop");
    expect_line("kill ring undo yank pop text", "Xfirst", 6);
    if (rl_undo_command(1, 0) != 0)
        fail("kill ring undo yank pop undo");
    expect_line("kill ring undo yank pop undo text", "Xthird", 6);

    rl_replace_line("one two three", 1);
    rl_point = 0;
    if (rl_kill_word(1, 0) != 0)
        fail("kill boundary first");
    expect_line("kill boundary first text", " two three", 0);
    if (rl_forward_char(1, 0) != 0)
        fail("kill boundary movement");
    if (rl_kill_word(1, 0) != 0)
        fail("kill boundary second");
    expect_line("kill boundary second text", "  three", 1);
    rl_replace_line("Y", 1);
    rl_point = 1;
    if (rl_yank(1, 0) != 0)
        fail("kill boundary yank");
    expect_line("kill boundary yank text", "Ytwo", 4);

    rl_replace_line("abc", 0);
    rl_point = 1;
    if (rl_set_mark(1, 0) != 0)
        fail("set mark");
    if (!rl_mark_active_p())
        fail("mark active");
    rl_point = 3;
    if (rl_kill_region(1, 0) != 0)
        fail("kill region");
    expect_line("kill region text", "a", 1);
    if (rl_yank(1, 0) != 0)
        fail("yank region");
    expect_line("yank region text", "abc", 3);

    rl_replace_line("ab", 1);
    rl_point = 1;
    if (rl_transpose_chars(1, 0) != 0)
        fail("transpose");
    expect_line("transpose text", "ba", 2);
    if (rl_undo_command(1, 0) != 0)
        fail("undo");
    expect_line("undo text", "ab", 1);
    if (rl_do_undo() != 0)
        fail("empty direct undo");

    rl_replace_line("xy", 1);
    rl_point = 2;
    if (rl_insert_text("z") != 1)
        fail("insert for direct undo");
    if (rl_do_undo() != 1)
        fail("direct undo");
    expect_line("direct undo text", "xy", 2);

    rl_replace_line("abcdef", 1);
    rl_point = 3;
    if (rl_begin_undo_group() != 0)
        fail("begin undo group");
    if (rl_delete_text(1, 3) != 2)
        fail("group delete");
    rl_point = 1;
    if (rl_insert_text("ZZ") != 2)
        fail("group insert");
    if (rl_end_undo_group() != 0)
        fail("end undo group");
    expect_line("group edit text", "aZZdef", 3);
    if (rl_undo_command(1, 0) != 0)
        fail("group undo");
    expect_line("group undo text", "abcdef", 3);

    rl_replace_line("mutable", 1);
    rl_point = 3;
    if (rl_modifying(1, 4) != 0)
        fail("modifying");
    memcpy(rl_line_buffer + 1, "XYZ", 3);
    rl_point = 4;
    expect_line("direct mutation text", "mXYZble", 4);
    if (rl_undo_command(1, 0) != 0)
        fail("direct mutation undo");
    expect_line("direct mutation undo text", "mutable", 3);

    rl_replace_line("add-undo", 1);
    rl_point = 4;
    if (rl_add_undo(0, 0, 0, NULL) != 0)
        fail("add undo");
    memcpy(rl_line_buffer, "ADD", 3);
    rl_point = 3;
    expect_line("add undo mutation text", "ADD-undo", 3);
    if (rl_undo_command(1, 0) != 0)
        fail("add undo restore");
    expect_line("add undo restore text", "add-undo", 4);

    rl_point = 2;
    rl_replace_line("clear", 1);
    if (rl_do_undo() != 0)
        fail("clear undo list");
    expect_line("clear undo text", "clear", 2);

    return 0;
}
