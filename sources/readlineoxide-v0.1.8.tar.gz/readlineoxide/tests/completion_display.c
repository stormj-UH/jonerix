#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <readline/readline.h>

static int display_calls;
static int display_count;
static int display_max;

static void
fail(const char *message)
{
    fprintf(stderr, "completion_display: %s\n", message);
    exit(1);
}

static char *
copy_string(const char *value)
{
    size_t len = strlen(value);
    char *copy = malloc(len + 1);
    if (copy == NULL)
        fail("malloc string");
    memcpy(copy, value, len + 1);
    return copy;
}

static char **
attempted_completion(const char *text, int start, int end)
{
    char **matches;

    if (strcmp(text, "ab") != 0 || start != 0 || end != 2)
        fail("completion arguments");

    matches = malloc(4 * sizeof(matches[0]));
    if (matches == NULL)
        fail("malloc matches");
    matches[0] = copy_string("ab");
    matches[1] = copy_string("aba");
    matches[2] = copy_string("abb");
    matches[3] = NULL;
    return matches;
}

static void
display_hook(char **matches, int num_matches, int max_length)
{
    if (matches == NULL)
        fail("display matches null");
    if (strcmp(matches[0], "ab") != 0)
        fail("display common");
    if (strcmp(matches[1], "aba") != 0 || strcmp(matches[2], "abb") != 0)
        fail("display entries");
    display_calls++;
    display_count = num_matches;
    display_max = max_length;
}

int
main(void)
{
    rl_attempted_completion_function = attempted_completion;
    rl_completion_display_matches_hook = display_hook;
    rl_completion_suppress_append = 0;
    rl_replace_line("ab", 0);
    rl_point = 2;

    if (rl_complete(1, '\t') != 0)
        fail("complete");
    if (display_calls != 1)
        fail("display calls");
    if (display_count != 2 || display_max != 3)
        fail("display dimensions");
    if (rl_line_buffer == NULL || strcmp(rl_line_buffer, "ab") != 0)
        fail("line unchanged");
    if (rl_point != 2 || rl_end != 2)
        fail("point");

    rl_attempted_completion_function = NULL;
    rl_completion_display_matches_hook = NULL;
    return 0;
}
