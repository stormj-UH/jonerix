#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <readline/history.h>

static void
fail(const char *message)
{
    fprintf(stderr, "history_file: %s\n", message);
    exit(1);
}

static void
expect_line(int offset, const char *line)
{
    HIST_ENTRY *entry = history_get(history_base + offset);
    if (entry == NULL || entry->line == NULL || strcmp(entry->line, line) != 0)
        fail(line);
}

static void
write_range_file(const char *path)
{
    FILE *file = fopen(path, "w");
    int i;

    if (file == NULL)
        fail("range file open");
    for (i = 0; i < 5; i++) {
        if (fprintf(file, "r%d\n", i) < 0)
            fail("range file write");
    }
    if (fclose(file) != 0)
        fail("range file close");
}

static void
write_multiline_history_file(const char *path)
{
    FILE *file = fopen(path, "w");

    if (file == NULL)
        fail("multiline file open");
    if (fputs("#100\nfirst line\nsecond line\n#200\nsingle\n", file) < 0)
        fail("multiline file write");
    if (fclose(file) != 0)
        fail("multiline file close");
}

static void
write_byte_history_file(const char *path)
{
    static const unsigned char first[] = { 'b', 'y', 't', 'e', '-', 0xff,
        '-', 'l', 'i', 'n', 'e', '\n' };
    FILE *file = fopen(path, "wb");

    if (file == NULL)
        fail("byte history open");
    if (fwrite(first, 1, sizeof(first), file) != sizeof(first))
        fail("byte history write first");
    if (fputs("ascii-line\n", file) < 0)
        fail("byte history write second");
    if (fclose(file) != 0)
        fail("byte history close");
}

static void
make_byte_path(char *out, size_t out_len, const char *base, const char *tag)
{
    int n;

    n = snprintf(out, out_len, "%s.%s-", base, tag);
    if (n < 0 || n >= (int)out_len)
        fail("byte path prefix too long");
    if ((size_t)n + 7 >= out_len)
        fail("byte path too long");
    out[n++] = (char)0xff;
    if (snprintf(out + n, out_len - (size_t)n, ".hist") >=
        (int)(out_len - (size_t)n))
        fail("byte path suffix too long");
}

static void
expect_line_bytes(int offset, const unsigned char *bytes, size_t len)
{
    HIST_ENTRY *entry = history_get(history_base + offset);

    if (entry == NULL || entry->line == NULL)
        fail("byte line missing");
    if (strlen(entry->line) != len || memcmp(entry->line, bytes, len) != 0)
        fail("byte line mismatch");
}

int
main(int argc, char **argv)
{
    const char *path;
    char missing[512];
    char badpath[512];
    char rangepath[512];
    char multilinepath[512];
    char bytepath[512];
    char rawpath[512];
    static const unsigned char byte_line[] = { 'b', 'y', 't', 'e', '-',
        0xff, '-', 'l', 'i', 'n', 'e' };

    if (argc != 2)
        fail("usage");
    path = argv[1];
    if (snprintf(missing, sizeof(missing), "%s.missing", path) >=
        (int)sizeof(missing))
        fail("missing path too long");
    if (snprintf(badpath, sizeof(badpath), "%s.dir/history", path) >=
        (int)sizeof(badpath))
        fail("bad path too long");
    if (snprintf(rangepath, sizeof(rangepath), "%s.range", path) >=
        (int)sizeof(rangepath))
        fail("range path too long");
    if (snprintf(multilinepath, sizeof(multilinepath), "%s.multiline", path) >=
        (int)sizeof(multilinepath))
        fail("multiline path too long");
    if (snprintf(bytepath, sizeof(bytepath), "%s.bytes", path) >=
        (int)sizeof(bytepath))
        fail("byte path too long");
    make_byte_path(rawpath, sizeof(rawpath), path, "raw-name");

    if (read_history(missing) != 2)
        fail("read missing errno");
    if (read_history_range(missing, 0, -1) != 2)
        fail("read range missing errno");
    if (history_truncate_file(missing, 2) != 2)
        fail("truncate missing errno");

    clear_history();
    add_history("one");
    add_history_time("#100");
    add_history("two");
    add_history_time("#200");
    add_history("three");
    add_history_time("#300");
    history_write_timestamps = 1;
    if (write_history(path) != 0)
        fail("write");
    if (history_lines_written_to_file != 3)
        fail("write count");

    clear_history();
    if (read_history(path) != 0)
        fail("read");
    if (history_length != 3)
        fail("read length");
    if (history_lines_read_from_file != 3)
        fail("read count");
    expect_line(0, "one");
    expect_line(2, "three");
    if (history_get_time(history_get(history_base + 2)) != (time_t)300)
        fail("read timestamp");

    if (append_history(2, path) != 0)
        fail("append");
    clear_history();
    if (read_history(path) != 0)
        fail("reread");
    if (history_length != 5)
        fail("append length");
    expect_line(3, "two");
    expect_line(4, "three");

    if (history_truncate_file(path, 2) != 0)
        fail("truncate");
    clear_history();
    if (read_history(path) != 0)
        fail("read truncated");
    if (history_length != 2)
        fail("truncated length");
    expect_line(0, "two");
    expect_line(1, "three");
    if (history_get_time(history_get(history_base + 1)) != (time_t)300)
        fail("truncated timestamp");

    write_range_file(rangepath);
    clear_history();
    if (read_history_range(rangepath, 0, 1) != 0)
        fail("range 0 1");
    if (history_length != 1)
        fail("range 0 1 length");
    expect_line(0, "r0");

    clear_history();
    if (read_history_range(rangepath, 1, 3) != 0)
        fail("range 1 3");
    if (history_length != 2)
        fail("range 1 3 length");
    expect_line(0, "r1");
    expect_line(1, "r2");

    clear_history();
    if (read_history_range(rangepath, 3, 1) != 0)
        fail("range inverted");
    if (history_length != 1)
        fail("range inverted length");
    expect_line(0, "r3");

    clear_history();
    if (read_history_range(rangepath, -2, 2) != 0)
        fail("range negative start");
    if (history_length != 2)
        fail("range negative start length");
    expect_line(0, "r0");
    expect_line(1, "r1");

    clear_history();
    add_history("seed0");
    add_history("seed1");
    if (read_history_range(rangepath, 1, 3) != 0)
        fail("range append existing");
    if (history_length != 4)
        fail("range append existing length");
    expect_line(0, "seed0");
    expect_line(1, "seed1");
    expect_line(2, "r1");
    expect_line(3, "r2");

    write_multiline_history_file(multilinepath);
    history_multiline_entries = 1;
    clear_history();
    if (read_history(multilinepath) != 0)
        fail("read multiline");
    if (history_length != 2)
        fail("multiline length");
    if (history_lines_read_from_file != 2)
        fail("multiline read count");
    expect_line(0, "first line\nsecond line");
    expect_line(1, "single");
    if (history_get_time(history_get(history_base)) != (time_t)100)
        fail("multiline first timestamp");
    if (history_get_time(history_get(history_base + 1)) != (time_t)200)
        fail("multiline second timestamp");

    if (history_truncate_file(multilinepath, 1) != 0)
        fail("truncate multiline");
    clear_history();
    if (read_history(multilinepath) != 0)
        fail("read truncated multiline");
    if (history_length != 1)
        fail("truncated multiline length");
    expect_line(0, "single");
    if (history_get_time(history_get(history_base)) != (time_t)200)
        fail("truncated multiline timestamp");
    history_multiline_entries = 0;

    write_byte_history_file(bytepath);
    clear_history();
    if (read_history(bytepath) != 0)
        fail("read byte history");
    if (history_length != 2)
        fail("byte history length");
    expect_line_bytes(0, byte_line, sizeof(byte_line));
    expect_line(1, "ascii-line");

    clear_history();
    add_history("raw-path");
    if (write_history(rawpath) != 0)
        fail("write raw byte filename");
    clear_history();
    if (read_history(rawpath) != 0)
        fail("read raw byte filename");
    if (history_length != 1)
        fail("raw byte filename length");
    expect_line(0, "raw-path");
    if (append_history(1, rawpath) != 0)
        fail("append raw byte filename");
    if (history_truncate_file(rawpath, 1) != 0)
        fail("truncate raw byte filename");
    clear_history();
    if (read_history(rawpath) != 0)
        fail("reread raw byte filename");
    if (history_length != 1)
        fail("truncated raw byte filename length");
    expect_line(0, "raw-path");

    if (write_history(badpath) != 2)
        fail("write bad errno");
    if (append_history(1, badpath) != 2)
        fail("append bad errno");
    if (append_history(1, missing) != 2)
        fail("append missing errno");
    if (append_history(-1, path) != 0)
        fail("append negative");
    if (history_lines_written_to_file != -1)
        fail("append negative count");

    return 0;
}
