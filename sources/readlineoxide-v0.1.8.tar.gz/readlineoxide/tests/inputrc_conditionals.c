#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <readline/readline.h>

static const char *active_input;
static int input_pos;

static void
fail(const char *message)
{
    fprintf(stderr, "inputrc_conditionals: %s\n", message);
    exit(1);
}

static int
test_getc(FILE *stream)
{
    (void)stream;
    if (active_input[input_pos] == '\0')
        return EOF;
    return active_input[input_pos++];
}

static char *
read_test_line(const char *input)
{
    active_input = input;
    input_pos = 0;
    rl_getc_function = test_getc;
    return readline("");
}

static void
write_file(const char *path, const char *text)
{
    FILE *file;

    file = fopen(path, "w");
    if (file == NULL)
        fail("fopen");
    if (fputs(text, file) == EOF)
        fail("fputs");
    if (fclose(file) != 0)
        fail("fclose");
}

static void
expect_line(const char *message, const char *input, const char *expected)
{
    char *line;

    line = read_test_line(input);
    if (line == NULL || strcmp(line, expected) != 0) {
        fprintf(stderr, "inputrc_conditionals: %s: <%s> != <%s>\n",
            message, line == NULL ? "(null)" : line, expected);
        exit(1);
    }
    free(line);
}

int
main(int argc, char **argv)
{
    char included[512];
    char mainrc[512];
    char main_text[1400];
    static char app_name[] = "probeapp";

    if (argc != 2)
        fail("usage");

    if (snprintf(included, sizeof(included), "%s.included.inputrc",
            argv[1]) >= (int)sizeof(included))
        fail("included path too long");
    if (snprintf(mainrc, sizeof(mainrc), "%s.main.inputrc",
            argv[1]) >= (int)sizeof(mainrc))
        fail("main path too long");

    write_file(included,
        "\"\\C-xb\": \"INC\"\n"
        "$if probeapp\n"
        "\"\\C-xc\": \"APP\"\n"
        "$endif\n"
        "$if term=rlprobe-term\n"
        "\"\\C-xd\": \"TERM\"\n"
        "$endif\n"
        "$if otherapp\n"
        "\"\\C-xe\": \"BADAPP\"\n"
        "$endif\n"
        "$if term=other-term\n"
        "\"\\C-xf\": \"BADTERM\"\n"
        "$endif\n");

    if (snprintf(main_text, sizeof(main_text),
            "\"\\C-xa\": \"MAIN\"\n$include %s\n", included) >=
        (int)sizeof(main_text))
        fail("main text too long");
    write_file(mainrc, main_text);

    rl_readline_name = app_name;
    putenv("TERM=rlprobe-term");
    if (rl_read_init_file(mainrc) != 0)
        fail("read init file");

    expect_line("main binding", "\030a\n", "MAIN");
    expect_line("included binding", "\030b\n", "INC");
    expect_line("application conditional", "\030c\n", "APP");
    expect_line("term conditional", "\030d\n", "TERM");
    expect_line("inactive application conditional", "\030e\n", "");
    expect_line("inactive term conditional", "\030f\n", "");

    rl_getc_function = NULL;
    return 0;
}
