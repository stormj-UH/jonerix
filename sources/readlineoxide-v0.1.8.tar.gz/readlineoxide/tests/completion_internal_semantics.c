#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <readline/readline.h>

static int captured_type;
static int captured_invoking_key;
static int completion_calls;
static int completion_returns_matches;
static int display_calls;
static int display_count;
static int display_max;
static const char *expected_text = "a";
static const char *match_prefix;
static const char *match_items[8];
static int match_count;

static void
fail(const char *message)
{
    fprintf(stderr, "completion_internal_semantics: %s\n", message);
    exit(1);
}

static char *
xstrdup(const char *text)
{
    size_t len = strlen(text) + 1;
    char *copy = malloc(len);

    if (copy == NULL)
        fail("malloc");
    memcpy(copy, text, len);
    return copy;
}

static void
set_matches(const char *prefix, const char *first, const char *second)
{
    match_prefix = prefix;
    match_items[0] = first;
    match_items[1] = second;
    match_items[2] = NULL;
    match_count = second == NULL ? 1 : 2;
}

static char **
make_matches(void)
{
    int i;
    char **matches = calloc((size_t)match_count + 2, sizeof(char *));

    if (matches == NULL)
        fail("calloc");
    matches[0] = xstrdup(match_prefix);
    for (i = 0; i < match_count; i++)
        matches[i + 1] = xstrdup(match_items[i]);
    return matches;
}

static char **
completion(const char *text, int start, int end)
{
    (void)start;
    (void)end;
    completion_calls++;
    captured_type = rl_completion_type;
    captured_invoking_key = rl_completion_invoking_key;
    if (strcmp(text, expected_text) != 0)
        fail("completion text");
    rl_attempted_completion_over = 1;
    if (!completion_returns_matches)
        return NULL;
    return make_matches();
}

static int
dummy_command(int count, int key)
{
    (void)count;
    (void)key;
    return 0;
}

static int
other_command(int count, int key)
{
    (void)count;
    (void)key;
    return 0;
}

static void
display_hook(char **matches, int num_matches, int max_length)
{
    if (matches == NULL || matches[1] == NULL)
        fail("display matches");
    display_calls++;
    display_count = num_matches;
    display_max = max_length;
}

static void
reset_line(const char *line)
{
    rl_replace_line(line, 0);
    rl_point = (int)strlen(line);
    rl_end = (int)strlen(line);
}

int
main(void)
{
    if (rl_initialize() != 0)
        fail("initialize");
    rl_attempted_completion_function = completion;

    completion_returns_matches = 0;
    rl_completion_type = 777;
    rl_completion_invoking_key = 123;
    reset_line("a");
    if (rl_complete_internal('?') != 0)
        fail("query completion");
    if (completion_calls != 1)
        fail("query hook");
    if (captured_type != '?' || rl_completion_type != '?')
        fail("query completion type");
    if (captured_invoking_key != 123 || rl_completion_invoking_key != 123)
        fail("query invoking key");
    if (strcmp(rl_line_buffer, "a") != 0 || rl_point != 1)
        fail("query line unchanged");

    completion_calls = 0;
    rl_completion_invoking_key = 321;
    reset_line("a");
    if (rl_complete_internal('*') != 0)
        fail("insert completion");
    if (completion_calls != 1)
        fail("insert completion hook");
    if (captured_type != '*' || rl_completion_type != '*')
        fail("insert completion type");
    if (captured_invoking_key != 321 || rl_completion_invoking_key != 321)
        fail("insert invoking key");

    rl_variable_bind("show-all-if-ambiguous", "off");
    rl_variable_bind("show-all-if-unmodified", "off");
    rl_last_func = other_command;
    if (rl_completion_mode(dummy_command) != '\t')
        fail("mode normal");
    rl_last_func = dummy_command;
    if (rl_completion_mode(dummy_command) != '?')
        fail("mode repeat");
    rl_last_func = other_command;
    rl_variable_bind("show-all-if-ambiguous", "on");
    if (rl_completion_mode(dummy_command) != '!')
        fail("mode ambiguous");
    rl_variable_bind("show-all-if-ambiguous", "off");
    rl_variable_bind("show-all-if-unmodified", "on");
    if (rl_completion_mode(dummy_command) != '@')
        fail("mode unmodified");
    rl_last_func = dummy_command;
    if (rl_completion_mode(dummy_command) != '?')
        fail("mode repeat wins");
    rl_variable_bind("show-all-if-unmodified", "off");
    rl_last_func = other_command;

    rl_completion_display_matches_hook = display_hook;
    completion_returns_matches = 1;
    expected_text = "ab";
    set_matches("ab", "abc", "abd");

    completion_calls = 0;
    display_calls = 0;
    rl_completion_invoking_key = 0;
    reset_line("ab");
    if (rl_possible_completions(1, '?') != 0)
        fail("possible completions wrapper");
    if (completion_calls != 1)
        fail("possible completion hook");
    if (captured_type != '?' || rl_completion_type != '?')
        fail("possible completion type");
    if (captured_invoking_key != '?' || rl_completion_invoking_key != '?')
        fail("possible invoking key");
    if (display_calls != 1 || display_count != 2 || display_max != 3)
        fail("possible display dimensions");
    if (strcmp(rl_line_buffer, "ab") != 0 || rl_point != 2)
        fail("possible line unchanged");

    completion_calls = 0;
    display_calls = 0;
    rl_completion_invoking_key = 0;
    reset_line("ab");
    if (rl_insert_completions(1, '*') != 0)
        fail("insert completions wrapper");
    if (completion_calls != 1)
        fail("insert wrapper hook");
    if (captured_type != '*' || rl_completion_type != '*')
        fail("insert wrapper completion type");
    if (captured_invoking_key != '*' || rl_completion_invoking_key != '*')
        fail("insert wrapper invoking key");
    if (strcmp(rl_line_buffer, "abc abd ") != 0 || rl_point != 8 ||
        rl_end != 8)
        fail("insert all line");
    if (display_calls != 0)
        fail("insert displayed");

    expected_text = "a";
    set_matches("alp", "alpha", "alpine");
    completion_calls = 0;
    display_calls = 0;
    reset_line("a");
    if (rl_complete_internal('!') != 0)
        fail("bang internal");
    if (captured_type != '!' || rl_completion_type != '!')
        fail("bang type");
    if (strcmp(rl_line_buffer, "alp") != 0 || display_calls != 1)
        fail("bang complete and display");

    completion_calls = 0;
    display_calls = 0;
    reset_line("a");
    if (rl_complete_internal('@') != 0)
        fail("at changes");
    if (strcmp(rl_line_buffer, "alp") != 0 || display_calls != 0)
        fail("at changed display");

    set_matches("a", "ab", "ac");
    completion_calls = 0;
    display_calls = 0;
    reset_line("a");
    if (rl_complete_internal('@') != 0)
        fail("at unmodified");
    if (strcmp(rl_line_buffer, "a") != 0 || display_calls != 1)
        fail("at unmodified display");

    set_matches("alp", "alpha", "alpine");
    completion_calls = 0;
    reset_line("a");
    if (rl_menu_complete(1, 'm') != 0)
        fail("menu");
    if (captured_type != '%' || rl_completion_type != '%' ||
        strcmp(rl_line_buffer, "alpha ") != 0)
        fail("menu first");

    completion_calls = 0;
    reset_line("a");
    if (rl_backward_menu_complete(1, 'b') != 0)
        fail("back menu");
    if (captured_type != '%' || rl_completion_type != '%' ||
        strcmp(rl_line_buffer, "alpine ") != 0)
        fail("back menu first");

    rl_attempted_completion_function = NULL;
    rl_completion_display_matches_hook = NULL;
    rl_variable_bind("show-all-if-ambiguous", "on");
    return 0;
}
