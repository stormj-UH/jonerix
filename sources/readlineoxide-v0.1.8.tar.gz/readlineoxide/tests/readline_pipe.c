#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <readline/readline.h>

static void
fail(const char *message)
{
    fprintf(stderr, "readline_pipe: %s\n", message);
    exit(1);
}

int
main(void)
{
    char *line;
    char *copy;

    line = readline("sql> ");
    if (line == NULL)
        fail("null line");
    if (strcmp(line, "select * from users;") != 0)
        fail("line contents");
    if (rl_line_buffer == NULL || strcmp(rl_line_buffer, line) != 0)
        fail("line buffer");
    if (rl_point != (int)strlen(line) || rl_end != (int)strlen(line))
        fail("point/end");
    free(line);

    if (rl_insert_text(" limit 1") != 8)
        fail("insert");
    if (strcmp(rl_line_buffer, "select * from users; limit 1") != 0)
        fail("insert contents");

    rl_replace_line("reset", 0);
    copy = rl_copy_text(1, 4);
    if (copy == NULL || strcmp(copy, "ese") != 0)
        fail("copy");
    rl_free(copy);

    return 0;
}
