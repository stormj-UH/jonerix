#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>

#include <readline/readline.h>

static const char *active_input;
static int input_pos;

static void
fail(const char *message)
{
    fprintf(stderr, "inputrc_quoted_semantics: %s\n", message);
    exit(1);
}

static int
test_getc(FILE *stream)
{
    (void)stream;
    if (active_input[input_pos] == '\0')
        return EOF;
    return active_input[input_pos++];
}

static char *
read_test_line(const char *input)
{
    active_input = input;
    input_pos = 0;
    rl_getc_function = test_getc;
    return readline("");
}

static void
write_file(const char *path, const char *text)
{
    FILE *file;

    file = fopen(path, "w");
    if (file == NULL)
        fail("fopen");
    if (fputs(text, file) == EOF)
        fail("fputs");
    if (fclose(file) != 0)
        fail("fclose");
}

static void
expect_line(const char *message, const char *input, const char *expected)
{
    char *line;

    line = read_test_line(input);
    if (line == NULL || strcmp(line, expected) != 0) {
        fprintf(stderr, "inputrc_quoted_semantics: %s: <%s> != <%s>\n",
            message, line == NULL ? "(null)" : line, expected);
        exit(1);
    }
    free(line);
}

int
main(int argc, char **argv)
{
    char dir[512];
    char included[512];
    char mainrc[512];
    char keymaprc[512];
    char boolrc[512];
    char main_text[1600];

    if (argc != 2)
        fail("usage");

    if (snprintf(dir, sizeof(dir), "%s-quoted", argv[1]) >= (int)sizeof(dir))
        fail("dir path too long");
    if (mkdir(dir, 0700) != 0)
        fail("mkdir");
    if (snprintf(included, sizeof(included), "%s/included.inputrc", dir) >=
        (int)sizeof(included))
        fail("included path too long");
    if (snprintf(mainrc, sizeof(mainrc), "%s.main.inputrc", argv[1]) >=
        (int)sizeof(mainrc))
        fail("main path too long");
    if (snprintf(keymaprc, sizeof(keymaprc), "%s.keymap.inputrc", argv[1]) >=
        (int)sizeof(keymaprc))
        fail("keymap path too long");
    if (snprintf(boolrc, sizeof(boolrc), "%s.bool.inputrc", argv[1]) >=
        (int)sizeof(boolrc))
        fail("bool path too long");

    write_file(included, "\"\\C-xq\": \"QUOTEDINC\"\n");
    if (snprintf(main_text, sizeof(main_text), "$include %s\n",
            included) >= (int)sizeof(main_text))
        fail("main text too long");
    write_file(mainrc, main_text);
    write_file(keymaprc, "set keymap \"vi-command\"\n");
    write_file(boolrc, "set completion-ignore-case \"on\"\n");

    if (rl_read_init_file(mainrc) != 0)
        fail("read init file");
    expect_line("included binding", "\030q\n", "QUOTEDINC");
    if (rl_read_init_file(keymaprc) != 0)
        fail("read keymap init file");
    if (strcmp(rl_get_keymap_name(rl_get_keymap()), "vi") != 0)
        fail("quoted vi-command keymap");
    if (rl_read_init_file(boolrc) != 0)
        fail("read bool init file");
    if (strcmp(rl_variable_value("completion-ignore-case"), "off") != 0)
        fail("quoted boolean stays off");
    if (rl_variable_bind("editing-mode", "bogus") != 1)
        fail("invalid editing mode return");
    if (rl_variable_bind("keymap", "bogus") != 1)
        fail("invalid keymap return");
    if (rl_variable_bind("history-size", "bogus") != 0)
        fail("invalid history size return");
    if (rl_variable_bind("editing-mode", "\"vi\"") != 1)
        fail("direct quoted editing mode return");
    if (rl_variable_bind("definitely-unknown-variable", "on") != 1)
        fail("unknown variable return");

    rl_getc_function = NULL;
    return 0;
}
