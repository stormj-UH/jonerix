use std::env;
use std::path::PathBuf;
use std::process::Command;

fn run(mut command: Command, program: &str) {
    let status = command
        .status()
        .unwrap_or_else(|error| panic!("failed to run {program}: {error}"));
    if !status.success() {
        panic!("{program} exited with status {status}");
    }
}

fn main() {
    let out_dir = PathBuf::from(env::var_os("OUT_DIR").expect("OUT_DIR is set by Cargo"));
    let target = env::var("TARGET").expect("TARGET is set by Cargo");
    let source = PathBuf::from("src/message.c");
    let object = out_dir.join("message.o");
    let archive = out_dir.join("libreadlineoxide_message.a");
    let cc = env::var_os("CC").unwrap_or_else(|| "cc".into());
    let ar = env::var_os("AR").unwrap_or_else(|| "ar".into());

    let mut compile = Command::new(&cc);
    compile
        .arg("-std=c99")
        .arg("-fPIC")
        .arg("-Wall")
        .arg("-Wextra")
        .arg("-c")
        .arg(&source)
        .arg("-o")
        .arg(&object);
    run(compile, "cc");

    let mut archive_cmd = Command::new(&ar);
    archive_cmd.arg("crs").arg(&archive).arg(&object);
    run(archive_cmd, "ar");

    println!("cargo:rerun-if-changed={}", source.display());
    println!("cargo:rustc-link-search=native={}", out_dir.display());
    println!("cargo:rustc-link-lib=static:+whole-archive=readlineoxide_message");
    if target.contains("apple") {
        println!("cargo:rustc-cdylib-link-arg=-Wl,-u,_rl_message");
        println!("cargo:rustc-cdylib-link-arg=-Wl,-exported_symbol,_rl_message");
    } else {
        println!("cargo:rustc-cdylib-link-arg=-Wl,--undefined=rl_message");
        println!("cargo:rustc-cdylib-link-arg=-Wl,--export-dynamic-symbol=rl_message");
    }
}
