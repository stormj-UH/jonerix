#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>

extern int readlineoxide_rl_message_formatted(const char *text);

int
rl_message(const char *format, ...)
{
    char *message;
    int needed;
    int result;
    va_list args;
    va_list copy;

    if (format == NULL)
        return readlineoxide_rl_message_formatted(NULL);

    va_start(args, format);
    va_copy(copy, args);
    needed = vsnprintf(NULL, 0, format, copy);
    va_end(copy);
    if (needed < 0) {
        va_end(args);
        return readlineoxide_rl_message_formatted(format);
    }

    message = malloc((size_t)needed + 1);
    if (message == NULL) {
        va_end(args);
        return -1;
    }

    if (vsnprintf(message, (size_t)needed + 1, format, args) < 0) {
        free(message);
        va_end(args);
        return readlineoxide_rl_message_formatted(format);
    }
    va_end(args);

    result = readlineoxide_rl_message_formatted(message);
    free(message);
    return result;
}
