set -uo noclobber
