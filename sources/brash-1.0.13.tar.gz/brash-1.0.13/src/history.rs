// Copyright (c) 2026 Jon-Erik G. Storm, Inc., a California Corporation,
// doing business as LAVA GOAT SOFTWARE. All rights reserved.
// Licensed under MIT.

//! # Module Invariant Ledger
//!
//! ## Structural Invariants
//! - INV-001: `HistoryList::entries` is a contiguous `Vec<HistEntry>` ordered
//!   from oldest (index 0) to newest (last index). Event numbers are virtual:
//!   the absolute event number of `entries[i]` is
//!   `total_added - entries.len() + 1 + i`. This formula is the sole source of
//!   truth for event numbering; no per-entry event number is stored.
//! - INV-002: `total_added` is monotonically non-decreasing. It is incremented
//!   by one on every successful `add` call and decremented by `remove_at` and
//!   `remove_matching_line` by the number of entries actually removed. It is
//!   set to 0 by `clear`. It must never become less than `entries.len()`.
//! - INV-003: `written_count` is the number of entries in `entries` that have
//!   already been appended to the history file. It satisfies
//!   `0 <= written_count <= entries.len()` at all times. When entries before
//!   index `written_count` are removed (eviction or deletion), `written_count`
//!   is decremented by the number of pre-written entries removed.
//! - INV-004: `max_size == 0` means unlimited history. When `max_size > 0`,
//!   `add` evicts the oldest entries until `entries.len() <= max_size` after
//!   the new entry is appended. The eviction loop runs after incrementing
//!   `total_added` so that event numbering remains consistent even when entries
//!   are immediately evicted.
//! - INV-005: History expansion (the `!`-event and `^old^new^` syntax) is
//!   purely functional: it reads `entries` but never modifies it. The expansion
//!   result is a new `String`; the original history list is not mutated during
//!   expansion.
//!
//! ## Safety Invariants
//! - SINV-001: `write_to_file_with_options` in append mode writes only entries
//!   in `entries[written_count..]`. After a successful write it sets
//!   `written_count = entries.len()`. If the write fails, `written_count` is
//!   left unchanged so the same entries are retried on the next write attempt.
//! - SINV-002: `read_from_file_with_options` appends to the current list
//!   without clearing it first. Callers that want a clean load must call
//!   `clear` before reading. Timestamp comment lines (starting with the
//!   `comment_char`) are discarded and never added as history entries.
//!
//! ## Performance Invariants
//! - PINV-001: `search_prefix` and `search_substr` iterate `entries` in reverse
//!   (newest first) and return on the first match. They are O(n) in the worst
//!   case. History lists are bounded by `max_size` (default 500), so the scan
//!   is effectively O(1) amortised for typical shell use.
//! - PINV-002: `get_by_event` converts an absolute event number to a `Vec`
//!   index in O(1) using the formula `abs - first_number()`. No linear scan is
//!   required.

/// History subsystem for brash.
///
/// Implements:
/// - History list (Vec<String>) with HISTSIZE limit
/// - HISTCONTROL (ignoredups/ignorespace/ignoreboth/erasedups)
/// - HISTIGNORE (colon-separated fnmatch patterns)
/// - `history` builtin: list, -c, -a, -w, -r, -s, -d, -p, -n
/// - History expansion: !!, !N, !-N, !string, !?string?, ^old^new^,
///   word designators (:N, :^, :$, :*, :N-M, etc.),
///   modifiers (:h, :t, :r, :e, :q, :x, :p, :s/old/new/, :g, :&)

use std::io::{self, BufRead, Write};
use std::time::{SystemTime, UNIX_EPOCH};

// ===== History List =====

#[derive(Clone, Debug)]
pub struct HistEntry {
    pub line: String,
}

#[derive(Debug, Default)]
pub struct HistoryList {
    pub entries: Vec<HistEntry>,
    /// How many entries were written to HISTFILE (for -a append logic).
    pub written_count: usize,
    /// Maximum entries to keep (HISTSIZE). 0 = unlimited.
    pub max_size: usize,
    /// Current highest history event number.
    /// When entries are evicted or deleted, later events are renumbered to
    /// stay contiguous the way bash's in-memory history does.
    pub total_added: usize,
}

#[derive(Clone, Copy, Debug)]
pub struct HistoryFileOptions {
    pub comment_char: char,
    pub write_timestamps: bool,
    pub histfile_size: Option<usize>,
}

impl Default for HistoryFileOptions {
    fn default() -> Self {
        Self {
            comment_char: '#',
            write_timestamps: false,
            histfile_size: None,
        }
    }
}

impl HistoryList {
    pub fn new() -> Self {
        HistoryList {
            entries: Vec::new(),
            written_count: 0,
            max_size: 500,
            total_added: 0,
        }
    }

    /// The 1-based history number of the first entry in the list.
    pub fn first_number(&self) -> usize {
        if self.entries.is_empty() {
            1
        } else {
            self.total_added.saturating_sub(self.entries.len()) + 1
        }
    }

    /// Add a line. Respects max_size.
    pub fn add(&mut self, line: String) {
        if line.trim().is_empty() {
            return;
        }
        // Fold multi-line compound commands into a single line (matching bash
        // behavior: newlines within compound commands are folded with spaces or
        // semicolons before closing keywords).
        let folded = fold_compound(line);
        // Normalize redirect operators to match bash's deparse format:
        // `2>/dev/null` → `2> /dev/null`, `>foo` → `> foo`, etc.
        let normalized = normalize_redirects(folded);
        self.entries.push(HistEntry { line: normalized });
        self.total_added += 1;
        if self.max_size > 0 {
            while self.entries.len() > self.max_size {
                self.entries.remove(0);
                // Adjust written_count so we don't write removed entries
                if self.written_count > 0 {
                    self.written_count -= 1;
                }
            }
        }
    }

    pub fn clear(&mut self) {
        self.entries.clear();
        self.written_count = 0;
        self.total_added = 0;
    }

    pub fn remove_at(&mut self, idx: usize) {
        self.entries.remove(idx);
        if idx < self.written_count {
            self.written_count -= 1;
        }
        self.total_added = self.total_added.saturating_sub(1);
    }

    pub fn remove_matching_line(&mut self, line: &str) {
        let original_len = self.entries.len();
        let mut removed_before_written = 0usize;

        for (idx, entry) in self.entries.iter().enumerate() {
            if entry.line == line && idx < self.written_count {
                removed_before_written += 1;
            }
        }

        self.entries.retain(|entry| entry.line != line);
        self.written_count = self.written_count.saturating_sub(removed_before_written);
        self.total_added = self
            .total_added
            .saturating_sub(original_len.saturating_sub(self.entries.len()));
    }

    /// Number of entries currently held in memory.
    /// `history` builtin uses indexed iteration directly, so this Vec-style
    /// accessor is not yet wired into any in-tree caller — kept for the
    /// embeddable history-list API used by external tools.
    #[allow(dead_code)]
    pub fn len(&self) -> usize {
        self.entries.len()
    }

    /// Public mirror of `len() == 0`, kept alongside `len` for ergonomic
    /// API parity with `Vec::is_empty`.
    #[allow(dead_code)]
    pub fn is_empty(&self) -> bool {
        self.entries.is_empty()
    }

    /// Get entry by absolute event number (1-based, accounting for evicted entries)
    /// or negative relative (-1 = last).
    pub fn get_by_event(&self, event: i64) -> Option<&str> {
        if self.entries.is_empty() {
            return None;
        }
        if event > 0 {
            // Absolute event number. Adjust for evicted entries.
            let first_num = self.first_number();
            let abs = event as usize;
            if abs < first_num || abs >= first_num + self.entries.len() {
                return None;
            }
            let idx = abs - first_num;
            self.entries.get(idx).map(|e| e.line.as_str())
        } else if event < 0 {
            let from_end = (-event) as usize;
            let len = self.entries.len();
            if from_end > len { None } else {
                self.entries.get(len - from_end).map(|e| e.line.as_str())
            }
        } else {
            None
        }
    }

    pub fn last(&self) -> Option<&str> {
        self.entries.last().map(|e| e.line.as_str())
    }

    /// Search backwards for an entry with the given prefix.
    pub fn search_prefix(&self, prefix: &str) -> Option<&str> {
        for e in self.entries.iter().rev() {
            if e.line.starts_with(prefix) {
                return Some(e.line.as_str());
            }
        }
        None
    }

    /// Search backwards for an entry containing the given substring.
    pub fn search_substr(&self, substr: &str) -> Option<&str> {
        for e in self.entries.iter().rev() {
            if e.line.contains(substr) {
                return Some(e.line.as_str());
            }
        }
        None
    }

    /// Write to HISTFILE. If append_only, write only unwritten entries.
    pub fn write_to_file_with_options(
        &mut self,
        path: &str,
        append_only: bool,
        opts: HistoryFileOptions,
    ) -> Result<(), io::Error> {
        let timestamp = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap_or_default()
            .as_secs();
        if append_only {
            let mut f = std::fs::OpenOptions::new()
                .create(true).append(true).open(path)?;
            for e in &self.entries[self.written_count..] {
                if opts.write_timestamps {
                    writeln!(f, "{}{}", opts.comment_char, timestamp)?;
                }
                writeln!(f, "{}", e.line)?;
            }
            self.written_count = self.entries.len();
        } else {
            let mut f = std::fs::File::create(path)?;
            let start = opts.histfile_size
                .map(|n| self.entries.len().saturating_sub(n))
                .unwrap_or(0);
            for e in &self.entries[start..] {
                if opts.write_timestamps {
                    writeln!(f, "{}{}", opts.comment_char, timestamp)?;
                }
                writeln!(f, "{}", e.line)?;
            }
            self.written_count = self.entries.len();
        }
        Ok(())
    }

    /// Convenience wrapper around `write_to_file_with_options` using the
    /// default options.  In-tree callers always specify options explicitly,
    /// but this is the simpler public form for embedders.
    #[allow(dead_code)]
    pub fn write_to_file(&mut self, path: &str, append_only: bool) -> Result<(), io::Error> {
        self.write_to_file_with_options(path, append_only, HistoryFileOptions::default())
    }

    /// Read from file, appending to the current list.
    pub fn read_from_file_with_options(
        &mut self,
        path: &str,
        opts: HistoryFileOptions,
    ) -> Result<(), io::Error> {
        let f = std::fs::File::open(path)?;
        let mut pending = String::new();
        let mut completed: Option<String> = None;
        for line in io::BufReader::new(f).lines() {
            let line = line?;
            if pending.is_empty() {
                if line.is_empty() {
                    if let Some(entry) = completed.as_mut() {
                        entry.push('\n');
                    }
                    continue;
                }
                if is_history_timestamp_line(&line, opts.comment_char) {
                    if let Some(entry) = completed.take() {
                        self.add(entry);
                    }
                    continue;
                }
                if let Some(entry) = completed.take() {
                    self.add(entry);
                }
            }
            if pending.is_empty() {
                if line.is_empty() || is_history_timestamp_line(&line, opts.comment_char) {
                    continue;
                }
            }
            pending.push_str(&line);
            pending.push('\n');
            if history_buffer_is_complete(&pending) {
                let entry = pending.trim_end_matches('\n').to_string();
                if !entry.trim().is_empty() {
                    completed = Some(entry);
                }
                pending.clear();
            }
        }
        if let Some(entry) = completed.take() {
            self.add(entry);
        }
        if !pending.trim().is_empty() {
            self.add(pending.trim_end_matches('\n').to_string());
        }
        self.written_count = self.entries.len();
        Ok(())
    }

    /// Convenience wrapper around `read_from_file_with_options` using the
    /// default options.  See `write_to_file` for rationale on the dual API.
    #[allow(dead_code)]
    pub fn read_from_file(&mut self, path: &str) -> Result<(), io::Error> {
        self.read_from_file_with_options(path, HistoryFileOptions::default())
    }

    /// Print history, optionally last N entries.
    pub fn print_history(&self, last_n: Option<usize>) {
        let total = self.entries.len();
        let start = if let Some(n) = last_n { total.saturating_sub(n) } else { 0 };
        let base_num = self.first_number();
        for (idx, entry) in self.entries[start..].iter().enumerate() {
            println!("{:5}  {}", base_num + start + idx, entry.line);
        }
    }
}

// ===== HISTCONTROL / HISTIGNORE =====

/// Returns true if this line should be skipped (not added to history).
pub fn should_skip(
    line: &str,
    hist: &HistoryList,
    histcontrol: &str,
    histignore: &str,
) -> bool {
    // ignorespace
    if (histcontrol.contains("ignorespace") || histcontrol.contains("ignoreboth"))
        && line.starts_with(' ')
    {
        return true;
    }
    // ignoredups
    if (histcontrol.contains("ignoredups") || histcontrol.contains("ignoreboth"))
        && hist.last().map(|l| l == line).unwrap_or(false)
    {
        return true;
    }
    // HISTIGNORE patterns
    if !histignore.is_empty() {
        for pat in histignore.split(':') {
            if pat == "&" {
                if hist.last().map(|l| l == line).unwrap_or(false) {
                    return true;
                }
            } else if fnmatch(pat, line) {
                return true;
            }
        }
    }
    false
}

fn fnmatch(pattern: &str, s: &str) -> bool {
    let p: Vec<char> = pattern.chars().collect();
    let t: Vec<char> = s.chars().collect();
    fn m(p: &[char], t: &[char]) -> bool {
        match p.first() {
            None => t.is_empty(),
            Some(&'*') => (0..=t.len()).any(|k| m(&p[1..], &t[k..])),
            Some(&'?') => !t.is_empty() && m(&p[1..], &t[1..]),
            Some(&c) => !t.is_empty() && t[0] == c && m(&p[1..], &t[1..]),
        }
    }
    m(&p, &t)
}

fn is_history_timestamp_line(line: &str, comment_char: char) -> bool {
    line.strip_prefix(comment_char)
        .map(|rest| !rest.is_empty() && rest.chars().all(|c| c.is_ascii_digit()))
        .unwrap_or(false)
}

// ===== History Expansion =====

/// Result of history expansion.
#[derive(Debug)]
pub enum HistExpResult {
    /// Successfully expanded (execute the result).
    Expanded(String),
    /// No history expansion was done.
    NoOp,
    /// Expansion had a `:p` modifier — print but don't execute.
    PrintOnly(String),
    /// Expansion failed — message already formatted.
    Error(String),
}

/// Expand history references in `input`.
///
/// `histchars`: value of $histchars, default "!^#".
/// `last_subst`: mutable reference to the persistent last-substitution state (for `:&`).
/// `posix_mode`: when true, history expansion is suppressed inside double-quoted strings.
pub fn expand(
    hist: &HistoryList,
    input: &str,
    script_name: &str,
    lineno: usize,
    histchars: &str,
    last_subst: &mut Option<(String, String)>,
    posix_mode: bool,
) -> HistExpResult {
    let mut hc = histchars.chars();
    let bang = hc.next().unwrap_or('!');
    let quick = hc.next().unwrap_or('^');

    let chars: Vec<char> = input.chars().collect();
    let n = chars.len();

    // Quick substitution: ^old^new^
    if n > 0 && chars[0] == quick {
        return expand_quick_subst(&chars, hist, script_name, lineno, quick);
    }

    // Check if there's any expansion character at all
    if !chars.contains(&bang) {
        return HistExpResult::NoOp;
    }

    let mut result = String::new();
    let mut i = 0;
    let mut did_expand = false;
    let mut print_only = false;
    // last_subst is passed in from the caller (persists across expand() calls)

    while i < n {
        let c = chars[i];

        // Single-quoted string: no history expansion inside
        if c == '\'' {
            result.push(c);
            i += 1;
            while i < n {
                let c2 = chars[i];
                result.push(c2);
                i += 1;
                if c2 == '\'' { break; }
            }
            continue;
        }

        // Double-quoted string: history expansion happens, but '#' (comment char)
        // suppresses expansion for the rest of the quoted segment.
        if c == '"' {
            result.push(c);
            i += 1;
            let mut suppress_in_dquote = false;
            while i < n {
                let c2 = chars[i];
                if c2 == '"' {
                    result.push(c2);
                    i += 1;
                    break;
                }
                if c2 == '\\' && i + 1 < n {
                    result.push(c2);
                    result.push(chars[i + 1]);
                    i += 2;
                    continue;
                }
                // Check for comment char suppressing expansion
                if c2 == '#' || suppress_in_dquote {
                    suppress_in_dquote = true;
                    result.push(c2);
                    i += 1;
                    continue;
                }
                // Inside double-quoted strings, handle $((...)) (arithmetic) and
                // $(...) (command sub) specially.  Command substitutions restart
                // quoting rules, so '...' inside $(...)  suppresses expansion just
                // like at the top level.  We expand the inner content recursively
                // using a top-level pass so that single-quotes work.
                if c2 == '$' && i + 1 < n && chars[i + 1] == '(' {
                    if i + 2 < n && chars[i + 2] == '(' {
                        // $((...)): arithmetic — copy entirely without expanding
                        result.push(c2); i += 1; // $
                        result.push(chars[i]); i += 1; // first (
                        let mut depth: i32 = 1;
                        while i < n && depth > 0 {
                            let ch = chars[i];
                            if ch == '(' { depth += 1; }
                            if ch == ')' { depth -= 1; }
                            result.push(ch);
                            i += 1;
                        }
                    } else {
                        // $(...): command sub — expand inner content with full
                        // quoting rules (single quotes suppress !, etc.)
                        result.push(c2); i += 1; // $
                        result.push(chars[i]); i += 1; // (
                        // Collect balanced inner content
                        let inner_start = i;
                        let mut depth: i32 = 1;
                        while i < n && depth > 0 {
                            match chars[i] {
                                '\'' => {
                                    i += 1;
                                    while i < n && chars[i] != '\'' { i += 1; }
                                    if i < n { i += 1; }
                                }
                                '"' => {
                                    i += 1;
                                    while i < n && chars[i] != '"' {
                                        if chars[i] == '\\' && i + 1 < n { i += 2; } else { i += 1; }
                                    }
                                    if i < n { i += 1; }
                                }
                                '(' => { depth += 1; i += 1; }
                                ')' => { depth -= 1; if depth > 0 { i += 1; } }
                                _ => { i += 1; }
                            }
                        }
                        let inner: String = chars[inner_start..i].iter().collect();
                        // Expand the inner content using the top-level expander
                        // which handles '...' as single-quotes
                        let inner_expanded = match expand_inner(
                            &inner, hist, script_name, lineno, histchars, last_subst
                        ) {
                            Ok((s, expanded)) => {
                                if expanded { did_expand = true; }
                                s
                            }
                            Err(e) => return HistExpResult::Error(e),
                        };
                        result.push_str(&inner_expanded);
                        if i < n { result.push(')'); i += 1; } // closing )
                    }
                    continue;
                }

                if c2 == bang {
                    // In POSIX mode, history expansion is suppressed inside
                    // double-quoted strings.
                    if posix_mode {
                        result.push(c2);
                        i += 1;
                        continue;
                    }
                    // Expand inside double quotes (unless suppressed)
                    if i + 1 < n {
                        let next2 = chars[i + 1];
                        if matches!(next2, ' ' | '\t' | '\n' | '=' | '(' | ')' | '"') {
                            result.push(c2);
                            i += 1;
                            continue;
                        }
                    } else {
                        result.push(c2);
                        i += 1;
                        continue;
                    }
                    let current_line2 = result.clone();
                    match parse_histexp(&chars, i, hist, &current_line2, script_name, lineno, bang, last_subst) {
                        Ok(None) => { result.push(bang); i += 1; }
                        Ok(Some((expanded, consumed, isp))) => {
                            if isp { print_only = true; }
                            did_expand = true;
                            result.push_str(&expanded);
                            i += consumed;
                        }
                        Err(e) => return HistExpResult::Error(e),
                    }
                    continue;
                }
                result.push(c2);
                i += 1;
            }
            continue;
        }

        // Backslash quoting of bang: \! → output \! literally, no expansion
        if c == '\\' && i + 1 < n && chars[i + 1] == bang {
            result.push('\\');
            result.push(bang);
            i += 2;
            continue;
        }

        // Hash (#) as history comment char: suppress expansion for rest of line
        // when # appears outside of quoted strings (single-quote handling is above,
        // double-quote handling is above — this handles unquoted #).
        // Note: # inside ${...} is part of ${#var} — we handle that below.
        if c == '#' {
            // Don't suppress if it looks like ${#...}
            // Otherwise: copy rest of line literally
            result.push(c);
            i += 1;
            while i < n {
                result.push(chars[i]);
                i += 1;
            }
            continue;
        }

        // Heredoc: << suppresses history expansion in the body.
        // When we see <<, read the delimiter, skip to end of the <<DELIM line,
        // then copy the heredoc body literally (no expansion).
        if c == '<' && i + 1 < n && chars[i + 1] == '<' {
            result.push(c); i += 1;  // first <
            result.push(chars[i]); i += 1;  // second <
            // Handle <<- (strip leading tabs in body)
            if i < n && chars[i] == '-' {
                result.push(chars[i]); i += 1;
            }
            // Skip optional whitespace before delimiter
            while i < n && (chars[i] == ' ' || chars[i] == '\t') {
                result.push(chars[i]); i += 1;
            }
            // Read delimiter, which may be quoted ('...', "...", or bare)
            let mut delim = String::new();
            if i < n && (chars[i] == '\'' || chars[i] == '"') {
                let q = chars[i];
                result.push(chars[i]); i += 1;  // opening quote
                while i < n && chars[i] != q {
                    delim.push(chars[i]);
                    result.push(chars[i]); i += 1;
                }
                if i < n { result.push(chars[i]); i += 1; }  // closing quote
            } else {
                while i < n && !matches!(chars[i], ' ' | '\t' | '\n' | ';' | ')' | '|' | '&') {
                    delim.push(chars[i]);
                    result.push(chars[i]); i += 1;
                }
            }
            // Copy rest of the <<DELIM line (up to and including newline)
            while i < n && chars[i] != '\n' {
                result.push(chars[i]); i += 1;
            }
            if i < n && chars[i] == '\n' {
                result.push(chars[i]); i += 1;  // newline after <<DELIM
            }
            // Copy heredoc body literally until the delimiter line
            if !delim.is_empty() {
                'heredoc: loop {
                    if i >= n { break; }
                    // Check if this line is the delimiter line
                    let line_start = i;
                    let mut j = i;
                    while j < n && chars[j] != '\n' { j += 1; }
                    let line: String = chars[line_start..j].iter().collect();
                    if line.trim_start_matches('\t') == delim.as_str() {
                        // Found the end — copy the delimiter line
                        for k in line_start..j { result.push(chars[k]); }
                        if j < n { result.push('\n'); j += 1; }
                        i = j;
                        break 'heredoc;
                    }
                    // Not the delimiter — copy this line literally (no expansion)
                    for k in line_start..j { result.push(chars[k]); }
                    if j < n { result.push('\n'); j += 1; }
                    i = j;
                }
            }
            continue;
        }

        // Track [ context: ! inside [...] is a negation, not history expansion
        if c == '[' {
            result.push(c);
            i += 1;
            // Check if next char is bang (negation in bracket expression)
            if i < n && chars[i] == bang {
                result.push(chars[i]);
                i += 1;
                // Copy until ] or end
                while i < n && chars[i] != ']' {
                    result.push(chars[i]);
                    i += 1;
                }
                if i < n {
                    result.push(chars[i]);
                    i += 1;
                }
            } else {
                // Regular [ — copy until ]
                while i < n && chars[i] != ']' {
                    result.push(chars[i]);
                    i += 1;
                }
                if i < n {
                    result.push(chars[i]);
                    i += 1;
                }
            }
            continue;
        }

        // Track ${...}: ! inside ${...} is for indirect/length, not history
        if c == '$' && i + 1 < n && chars[i + 1] == '{' {
            result.push(c);
            i += 1;
            result.push(chars[i]);
            i += 1;
            // Copy until matching }
            let mut depth = 1;
            while i < n && depth > 0 {
                let ch = chars[i];
                if ch == '{' { depth += 1; }
                if ch == '}' { depth -= 1; }
                result.push(ch);
                i += 1;
            }
            continue;
        }

        // $((...)): arithmetic expression, no history expansion
        // Only skip for $(( (double-paren = arithmetic). Single-paren $(...)
        // is a command substitution where !! should still expand.
        if c == '$' && i + 2 < n && chars[i + 1] == '(' && chars[i + 2] == '(' {
            result.push(c);
            i += 1;
            result.push(chars[i]);
            i += 1;
            let mut depth = 1;
            while i < n && depth > 0 {
                let ch = chars[i];
                if ch == '(' { depth += 1; }
                if ch == ')' { depth -= 1; }
                result.push(ch);
                i += 1;
            }
            continue;
        }

        if c != bang {
            result.push(c);
            i += 1;
            continue;
        }

        // c == bang character
        if i + 1 >= n {
            result.push(c);
            i += 1;
            continue;
        }

        let next = chars[i + 1];
        // Stop characters: space, tab, newline, =, (, ), |, &, ;, <, >,
        // plus quote-boundary chars — a `!` right before a quote is
        // literal (the quote starts a new token).
        if matches!(next, ' ' | '\t' | '\n' | '=' | '(' | ')' | '|' | '&' | ';' | '<' | '>'
            | '\'' | '"') {
            result.push(c);
            i += 1;
            continue;
        }

        // Parse the history expression
        let current_line = result.clone();
        match parse_histexp(&chars, i, hist, &current_line, script_name, lineno, bang, last_subst) {
            Ok(None) => {
                // No expansion (stop char or unknown)
                result.push(bang);
                i += 1;
            }
            Ok(Some((expanded, chars_consumed, is_print_only))) => {
                if is_print_only { print_only = true; }
                did_expand = true;
                result.push_str(&expanded);
                i += chars_consumed;
            }
            Err(e) => return HistExpResult::Error(e),
        }
    }

    if !did_expand {
        HistExpResult::NoOp
    } else if print_only {
        HistExpResult::PrintOnly(result)
    } else {
        HistExpResult::Expanded(result)
    }
}

/// Expand history references inside a command substitution `$(...)` block.
/// Returns `(expanded_text, did_expand)`.
/// Single-quoted strings inside suppress expansion, just like at the top level.
fn expand_inner(
    input: &str,
    hist: &HistoryList,
    script_name: &str,
    lineno: usize,
    histchars: &str,
    last_subst: &mut Option<(String, String)>,
) -> Result<(String, bool), String> {
    let mut hc = histchars.chars();
    let bang = hc.next().unwrap_or('!');

    let chars: Vec<char> = input.chars().collect();
    let n = chars.len();

    if !chars.contains(&bang) {
        return Ok((input.to_string(), false));
    }

    let mut result = String::new();
    let mut i = 0;
    let mut did_expand = false;

    while i < n {
        let c = chars[i];

        // Single-quoted: suppress expansion
        if c == '\'' {
            result.push(c); i += 1;
            while i < n {
                let c2 = chars[i];
                result.push(c2); i += 1;
                if c2 == '\'' { break; }
            }
            continue;
        }

        // Double-quoted: expansion continues (handle recursively)
        if c == '"' {
            result.push(c); i += 1;
            while i < n {
                let c2 = chars[i];
                if c2 == '"' { result.push(c2); i += 1; break; }
                if c2 == '\\' && i + 1 < n {
                    result.push(c2); result.push(chars[i+1]); i += 2; continue;
                }
                if c2 == bang {
                    if i + 1 < n {
                        let nxt = chars[i + 1];
                        if matches!(nxt, ' ' | '\t' | '\n' | '=' | '(' | ')' | '"') {
                            result.push(c2); i += 1; continue;
                        }
                    } else {
                        result.push(c2); i += 1; continue;
                    }
                    let cur = result.clone();
                    match parse_histexp(&chars, i, hist, &cur, script_name, lineno, bang, last_subst) {
                        Ok(None) => { result.push(bang); i += 1; }
                        Ok(Some((exp, consumed, _))) => {
                            did_expand = true;
                            result.push_str(&exp);
                            i += consumed;
                        }
                        Err(e) => return Err(e),
                    }
                    continue;
                }
                result.push(c2); i += 1;
            }
            continue;
        }

        if c != bang {
            result.push(c); i += 1;
            continue;
        }

        // c == bang
        if i + 1 >= n {
            result.push(c); i += 1;
            continue;
        }

        let next = chars[i + 1];
        // Characters that terminate histexp scanning: whitespace,
        // operators, and quote-boundary characters (a `!` right before
        // a quote character is literal — bash: `echo foo!'` prints
        // `foo!'` because the `'` is the next token, not an event).
        if matches!(next, ' ' | '\t' | '\n' | '=' | '(' | ')' | '|' | '&' | ';' | '<' | '>'
            | '\'' | '"') {
            result.push(c); i += 1;
            continue;
        }

        let current_line = result.clone();
        match parse_histexp(&chars, i, hist, &current_line, script_name, lineno, bang, last_subst) {
            Ok(None) => { result.push(bang); i += 1; }
            Ok(Some((expanded, consumed, _))) => {
                did_expand = true;
                result.push_str(&expanded);
                i += consumed;
            }
            Err(e) => return Err(e),
        }
    }

    Ok((result, did_expand))
}

fn expand_quick_subst(
    chars: &[char],
    hist: &HistoryList,
    script_name: &str,
    lineno: usize,
    quick: char,
) -> HistExpResult {
    let last = match hist.last() {
        Some(s) => s.to_string(),
        None => return HistExpResult::Error(format!(
            "{}: line {}: {}: event not found",
            script_name, lineno,
            chars.iter().collect::<String>()
        )),
    };
    // ^old^new[^]
    let rest: String = chars[1..].iter().collect();
    let mut parts = rest.splitn(3, quick);
    let old = parts.next().unwrap_or("");
    let new_ = parts.next().unwrap_or("");
    match subst_first(&last, old, new_) {
        Some(result) => HistExpResult::Expanded(result),
        None => HistExpResult::Error(format!(
            "{}: line {}: substitution failed",
            script_name, lineno
        )),
    }
}

/// Parse a single history expansion starting at `start` (where chars[start] == bang).
/// Returns Ok(None) if this should be treated as literal (no expansion).
/// Returns Ok(Some((text, chars_consumed, print_only))) on success.
/// Returns Err(message) on failure.
fn parse_histexp(
    chars: &[char],
    start: usize,
    hist: &HistoryList,
    current_line: &str,
    script_name: &str,
    lineno: usize,
    bang: char,
    last_subst: &mut Option<(String, String)>,
) -> Result<Option<(String, usize, bool)>, String> {
    let n = chars.len();
    let i = start + 1; // skip the bang

    if i >= n {
        return Ok(None);
    }

    // Parse event designator
    let (event_text, after_event) = parse_event(chars, i, hist, current_line, bang)?;

    if event_text.is_empty() && after_event == i {
        // Nothing parsed (no event found)
        return Ok(None);
    }

    // Parse optional word designator and modifiers
    let (final_text, after_all, print_only) =
        parse_word_and_mods(chars, after_event, &event_text, script_name, lineno, last_subst)?;

    let consumed = after_all - start;
    Ok(Some((final_text, consumed, print_only)))
}

/// Parse event designator. Returns (event_text, position_after).
/// If event_text.is_empty() AND position_after == i, means no event was found.
/// For !: (bare colon), returns (last_event, i) where i still points to ':'.
fn parse_event(
    chars: &[char],
    i: usize,
    hist: &HistoryList,
    current_line: &str,
    bang: char,
) -> Result<(String, usize), String> {
    let n = chars.len();
    if i >= n { return Ok((String::new(), i)); }

    let c = chars[i];

    // !! — last command
    if c == bang {
        match hist.last() {
            Some(s) => return Ok((s.to_string(), i + 1)),
            None => return Err("!!: event not found".to_string()),
        }
    }

    // !: — bare colon, refers to last event (shorthand for !!:)
    if c == ':' {
        match hist.last() {
            Some(s) => return Ok((s.to_string(), i)), // don't consume ':', parse_word_spec handles it
            None => return Err("!:: event not found".to_string()),
        }
    }

    // !$ — shorthand for !!:$ (last word of previous command)
    // !^ — shorthand for !!:^ (first arg of previous command)
    // !* — shorthand for !!:* (all args of previous command)
    if c == '$' || c == '^' || c == '*' {
        match hist.last() {
            Some(s) => return Ok((s.to_string(), i)), // don't consume, parse_word_spec handles it
            None => return Err(format!("!{}: event not found", c)),
        }
    }

    // !# — current line so far
    if c == '#' {
        return Ok((current_line.to_string(), i + 1));
    }

    // !N — absolute (1-based)
    if c.is_ascii_digit() {
        let mut j = i;
        while j < n && chars[j].is_ascii_digit() { j += 1; }
        let num_str: String = chars[i..j].iter().collect();
        let num: usize = num_str.parse().unwrap_or(0);
        match hist.get_by_event(num as i64) {
            Some(s) => return Ok((s.to_string(), j)),
            None => return Err(format!("!{}: event not found", num)),
        }
    }

    // !-N — negative relative
    if c == '-' && i + 1 < n && chars[i + 1].is_ascii_digit() {
        let mut j = i + 1;
        while j < n && chars[j].is_ascii_digit() { j += 1; }
        let num_str: String = chars[i + 1..j].iter().collect();
        let num: usize = num_str.parse().unwrap_or(0);
        match hist.get_by_event(-(num as i64)) {
            Some(s) => return Ok((s.to_string(), j)),
            None => return Err(format!("!-{}: event not found", num)),
        }
    }

    // !?string? — substring search
    if c == '?' {
        let mut j = i + 1;
        while j < n && chars[j] != '?' { j += 1; }
        let substr: String = chars[i + 1..j].iter().collect();
        let end = if j < n { j + 1 } else { j };
        match hist.search_substr(&substr) {
            Some(s) => return Ok((s.to_string(), end)),
            None => return Err(format!("!?{}?: event not found", substr)),
        }
    }

    // !string — prefix search (or "event not found" error for invalid prefixes)
    // Any character that's not already handled above is treated as the start of
    // a prefix search string. Stop at shell metacharacters and word-designator
    // separators. Special: stop at '-' if followed by a digit (that's a word spec
    // like -1) or at '-' if followed by '$' (word spec -$).
    {
        let mut j = i;
        while j < n {
            let ch = chars[j];
            // Stop at word designator or whitespace or shell meta
            if ch == ':' || ch == ' ' || ch == '\t' || ch == '\n'
                || ch == '|' || ch == '&' || ch == ';'
                || ch == '(' || ch == ')' || ch == '<' || ch == '>'
                || ch == '\'' || ch == '"' || ch == bang
            {
                break;
            }
            // Stop at word designator shortcuts (^, $, *, %)
            if ch == '^' || ch == '$' || ch == '*' || ch == '%' {
                break;
            }
            // Stop at '-' if followed by digit or '$' (word spec like -1 or -$)
            if ch == '-' && j + 1 < n && (chars[j + 1].is_ascii_digit() || chars[j + 1] == '$') {
                break;
            }
            j += 1;
        }
        let prefix: String = chars[i..j].iter().collect();
        if !prefix.is_empty() {
            match hist.search_prefix(&prefix) {
                Some(s) => return Ok((s.to_string(), j)),
                None => return Err(format!("!{}: event not found", prefix)),
            }
        }
        // Single-char non-stop character with no prefix collected (shouldn't happen,
        // but emit error to be safe).
        Err(format!("!{}: event not found", c))
    }
}

/// Parse word designator (optional) and modifiers.
/// Returns (final_text, position_after, print_only).
fn parse_word_and_mods(
    chars: &[char],
    pos: usize,
    event_text: &str,
    script_name: &str,
    lineno: usize,
    last_subst: &mut Option<(String, String)>,
) -> Result<(String, usize, bool), String> {
    let n = chars.len();
    let mut text = event_text.to_string();
    let mut i = pos;
    let mut print_only = false;
    let mut had_word_spec = false;

    // Word designator check: must start with ':' or be one of ^, $, *, %, or -N/-$
    // (without colon) when directly following the event.
    let has_word_indicator = i < n && (
        chars[i] == ':'
        || chars[i] == '^'
        || chars[i] == '$'
        || chars[i] == '*'
        || chars[i] == '%'
        || (chars[i] == '-' && i + 1 < n && (chars[i + 1].is_ascii_digit() || chars[i + 1] == '$'))
    );

    if has_word_indicator {
        let words = tokenize_words(event_text);

        // Check if it's a word spec or a modifier
        let (is_word_spec, advance_colon) = if i < n && chars[i] == ':' {
            // After ':', check if the next char is a word spec indicator
            let nc = if i + 1 < n { chars[i + 1] } else { '\0' };
            let is_ws = nc.is_ascii_digit() || nc == '^' || nc == '$' || nc == '*' || nc == '%' || nc == '-';
            (is_ws, true)
        } else {
            (true, false) // ^, $, *, %, -N directly
        };

        if is_word_spec {
            if advance_colon { i += 1; } // skip ':'
            let (word_text, after_word) = parse_word_spec(chars, i, &words)?;
            text = word_text;
            i = after_word;
            had_word_spec = true;
        }
    }

    // Now parse modifiers, each starting with ':'
    loop {
        if i >= n || chars[i] != ':' { break; }
        i += 1; // skip ':'
        if i >= n { break; }

        let (new_text, new_i, is_p) = parse_modifier(chars, i, &text, script_name, lineno, last_subst, &event_text.to_string())?;
        text = new_text;
        i = new_i;
        if is_p { print_only = true; }
    }

    let _ = had_word_spec;
    Ok((text, i, print_only))
}

/// Parse a word specifier (the part after ':' or the direct ^/$/*).
/// Returns (selected_words_text, position_after).
fn parse_word_spec(
    chars: &[char],
    pos: usize,
    words: &[String],
) -> Result<(String, usize), String> {
    let n = chars.len();
    let mut i = pos;

    if i >= n {
        return Ok((words.join(" "), i));
    }

    let c = chars[i];

    match c {
        '^' => { i += 1; Ok((words.get(1).cloned().unwrap_or_default(), i)) }
        '$' => { i += 1; Ok((words.last().cloned().unwrap_or_default(), i)) }
        '*' => {
            i += 1;
            if words.len() <= 1 { Ok((String::new(), i)) }
            else { Ok((words[1..].join(" "), i)) }
        }
        '%' => {
            // most recent !?string? match word — approximate with last word
            i += 1;
            Ok((words.last().cloned().unwrap_or_default(), i))
        }
        '-' => {
            // -M or -$: words 0 through M (or last)
            if i + 1 < n && chars[i + 1] == '$' {
                i += 2; // skip '-$'
                Ok((select_words_range(words, 0, words.len().saturating_sub(1)), i))
            } else if i + 1 < n && chars[i + 1].is_ascii_digit() {
                i += 1; // skip '-'
                let (end_num, after) = parse_number(chars, i);
                i = after;
                Ok((select_words_range(words, 0, end_num), i))
            } else {
                // bare '-' — not a word spec
                Ok((words.join(" "), pos))
            }
        }
        '0'..='9' => {
            let (start_num, after_start) = parse_number(chars, i);
            i = after_start;

            if i < n && chars[i] == '-' {
                i += 1; // skip '-'
                if i < n && chars[i] == '$' {
                    i += 1;
                    Ok((select_words_range(words, start_num, words.len().saturating_sub(1)), i))
                } else if i < n && chars[i].is_ascii_digit() {
                    let (end_num, after_end) = parse_number(chars, i);
                    i = after_end;
                    Ok((select_words_range(words, start_num, end_num), i))
                } else {
                    // N- : from N to second-to-last
                    let end = words.len().saturating_sub(2);
                    Ok((select_words_range(words, start_num, end), i))
                }
            } else if i < n && chars[i] == '*' {
                i += 1;
                Ok((select_words_range(words, start_num, words.len().saturating_sub(1)), i))
            } else {
                // Just N
                Ok((words.get(start_num).cloned().unwrap_or_default(), i))
            }
        }
        _ => {
            // Not a word spec — return full event, don't advance
            Ok((words.join(" "), pos))
        }
    }
}

fn parse_number(chars: &[char], pos: usize) -> (usize, usize) {
    let n = chars.len();
    let mut i = pos;
    while i < n && chars[i].is_ascii_digit() { i += 1; }
    let s: String = chars[pos..i].iter().collect();
    (s.parse().unwrap_or(0), i)
}

fn select_words_range(words: &[String], from: usize, to: usize) -> String {
    if words.is_empty() || from >= words.len() { return String::new(); }
    let to = to.min(words.len() - 1);
    if from > to { return String::new(); }
    words[from..=to].join(" ")
}

/// Parse one modifier (position is right AFTER the ':'). Returns (new_text, position_after, print_only).
fn parse_modifier(
    chars: &[char],
    pos: usize,
    text: &str,
    _script_name: &str,
    _lineno: usize,
    last_subst: &mut Option<(String, String)>,
    _event_text: &str,
) -> Result<(String, usize, bool), String> {
    let n = chars.len();
    let mut i = pos;

    if i >= n { return Ok((text.to_string(), i, false)); }
    let c = chars[i];
    i += 1;

    let result = match c {
        'h' => path_head(text),
        't' => path_tail(text),
        'r' => remove_extension(text),
        'e' => keep_extension(text),
        'q' => quote_string(text),
        'Q' => quote_string(text), // bash: $'...' style; approximate with 'q'
        'x' => quote_each_word(text),
        'p' => return Ok((text.to_string(), i, true)),
        'l' => lowercase_first(text),
        'u' => uppercase_first(text),
        'L' => text.to_lowercase(),
        'U' => text.to_uppercase(),
        '&' => {
            // Repeat last substitution
            if let Some((ref old, ref new_)) = last_subst.clone() {
                match subst_first(text, old, new_) {
                    Some(s) => s,
                    None => return Err("substitution failed".to_string()),
                }
            } else {
                text.to_string()
            }
        }
        'g' | 'G' => {
            // Global prefix: next modifier applies to all occurrences
            if i >= n { return Ok((text.to_string(), i, false)); }
            let next_c = chars[i];
            i += 1;
            match next_c {
                '&' => {
                    // g& — global repeat of last substitution
                    if let Some((ref old, ref new_)) = last_subst.clone() {
                        subst_all(text, old, new_)
                    } else {
                        text.to_string()
                    }
                }
                's' => {
                    // gs/old/new/
                    if i >= n { return Ok((text.to_string(), i, false)); }
                    let delim = chars[i]; i += 1;
                    let (old, new_, after) = parse_subst_args(chars, i, delim)?;
                    i = after;
                    *last_subst = Some((old.clone(), new_.clone()));
                    subst_all(text, &old, &new_)
                }
                '+' | '^' | '#' | '|' | ',' | '.' | '~' => {
                    // gs with alternate delimiter (same as above but delim != '/')
                    let delim = next_c;
                    if i >= n { return Ok((text.to_string(), i, false)); }
                    let (old, new_, after) = parse_subst_args(chars, i, delim)?;
                    i = after;
                    *last_subst = Some((old.clone(), new_.clone()));
                    subst_all(text, &old, &new_)
                }
                _ => {
                    return Err(format!(
                        "!!:g{}: history expansion failed",
                        next_c
                    ));
                }
            }
        }
        's' => {
            // s/old/new/
            if i >= n { return Ok((text.to_string(), i, false)); }
            let delim = chars[i]; i += 1;
            let (old, new_, after) = parse_subst_args(chars, i, delim)?;
            i = after;
            *last_subst = Some((old.clone(), new_.clone()));
            match subst_first(text, &old, &new_) {
                Some(s) => s,
                None => return Err("substitution failed".to_string()),
            }
        }
        _ => {
            return Err(format!(
                "!!:{}: history expansion failed",
                c
            ));
        }
    };

    Ok((result, i, false))
}

/// Parse substitution arguments old/new/ with given delimiter.
/// Returns (old, new, position_after_closing_delim).
fn parse_subst_args(
    chars: &[char],
    pos: usize,
    delim: char,
) -> Result<(String, String, usize), String> {
    let n = chars.len();
    let mut i = pos;

    let mut old = String::new();
    while i < n && chars[i] != delim {
        old.push(chars[i]);
        i += 1;
    }
    if i < n { i += 1; } // skip delim

    let mut new_ = String::new();
    while i < n && chars[i] != delim {
        new_.push(chars[i]);
        i += 1;
    }
    if i < n { i += 1; } // skip closing delim (optional)

    Ok((old, new_, i))
}

// ===== Compound Command Folding =====

/// Fold a multi-line compound command into a single-line history entry.
/// Normalize redirect operators in a shell command line to match bash's deparse
/// format: ensure there is always a space between a redirect operator and its
/// filename/fd target (e.g. `2>/dev/null` → `2> /dev/null`, `>foo` → `> foo`).
/// This mirrors what bash stores in history after parsing/deparsing a command.
/// Operates at the text level, skipping single-quoted and double-quoted regions.
fn normalize_redirects(line: String) -> String {
    if !line.contains('>') && !line.contains('<') {
        return line;
    }
    let chars: Vec<char> = line.chars().collect();
    let n = chars.len();
    let mut result = String::with_capacity(line.len() + 4);
    let mut i = 0;

    while i < n {
        let c = chars[i];
        match c {
            // Single-quoted string: copy verbatim
            '\'' => {
                result.push(c);
                i += 1;
                while i < n && chars[i] != '\'' {
                    result.push(chars[i]);
                    i += 1;
                }
                if i < n { result.push('\''); i += 1; }
            }
            // Double-quoted string: copy verbatim (no redirect normalization inside)
            '"' => {
                result.push(c);
                i += 1;
                while i < n {
                    if chars[i] == '\\' && i + 1 < n {
                        result.push(chars[i]);
                        result.push(chars[i + 1]);
                        i += 2;
                    } else if chars[i] == '"' {
                        result.push('"');
                        i += 1;
                        break;
                    } else {
                        result.push(chars[i]);
                        i += 1;
                    }
                }
            }
            // Redirect operators: '>' or '<'
            // These may be preceded by a digit (file descriptor number).
            // Ensure there's a space after the operator if the next char isn't space.
            // IMPORTANT: Do NOT add space for process substitutions: <(...) and >(...)
            '>' | '<' => {
                result.push(c);
                i += 1;
                let mut is_here_doc = false;
                // Handle '>>' or '>&', '<<', '<&', '<>'
                if c == '<' && i < n && chars[i] == '<' {
                    is_here_doc = true;
                    result.push(chars[i]);
                    i += 1;
                    if i < n && chars[i] == '-' {
                        result.push(chars[i]);
                        i += 1;
                    }
                } else if i < n && (chars[i] == '>' || chars[i] == '<' || chars[i] == '&' || chars[i] == '|') {
                    result.push(chars[i]);
                    i += 1;
                }
                // Process substitution <(...) or >(...): do NOT insert space
                if i < n && chars[i] == '(' {
                    // This is a process substitution, leave as-is
                } else if is_here_doc {
                    // Here-doc operator `<<` or `<<-`: keep the delimiter tight.
                    while i < n && (chars[i] == ' ' || chars[i] == '\t') {
                        i += 1;
                    }
                } else if i < n && chars[i] != ' ' && chars[i] != '\t' && chars[i] != '\n' {
                    // Regular redirect: insert a space before the filename
                    result.push(' ');
                }
            }
            _ => {
                result.push(c);
                i += 1;
            }
        }
    }
    result
}

/// Bash stores compound commands as single lines with:
///   - `\n` followed by indent (tabs/spaces) → ` ` + indent (flatten newline, keep indent)
///   - `\n` + optional indent + closing keyword (done, fi, esac) → `; keyword`
fn fold_compound(line: String) -> String {
    if !line.contains('\n') {
        return line;
    }
    if line.contains("<<") {
        return line;
    }
    let semicolon_keywords = ["do", "done", "fi", "esac"];
    let chars: Vec<char> = line.chars().collect();
    let mut result = String::with_capacity(line.len());
    let mut i = 0usize;
    let mut in_single = false;
    let mut in_double = false;
    let mut in_backtick = false;

    while i < chars.len() {
        let c = chars[i];
        if in_single {
            result.push(c);
            if c == '\'' {
                in_single = false;
            }
            i += 1;
            continue;
        }
        if in_double {
            result.push(c);
            if c == '\\' && i + 1 < chars.len() {
                i += 1;
                result.push(chars[i]);
            } else if c == '"' {
                in_double = false;
            }
            i += 1;
            continue;
        }
        if in_backtick {
            result.push(c);
            if c == '\\' && i + 1 < chars.len() {
                i += 1;
                result.push(chars[i]);
            } else if c == '`' {
                in_backtick = false;
            }
            i += 1;
            continue;
        }

        match c {
            '\'' => {
                in_single = true;
                result.push(c);
                i += 1;
            }
            '"' => {
                in_double = true;
                result.push(c);
                i += 1;
            }
            '`' => {
                in_backtick = true;
                result.push(c);
                i += 1;
            }
            '\n' => {
                let mut j = i + 1;
                while j < chars.len() && (chars[j] == ' ' || chars[j] == '\t') {
                    j += 1;
                }
                if j >= chars.len() || chars[j] == '\n' {
                    result.push('\n');
                    i += 1;
                    continue;
                }
                let first_word: String = chars[j..]
                    .iter()
                    .take_while(|ch| ch.is_alphanumeric() || **ch == '_')
                    .collect();
                if semicolon_keywords.contains(&first_word.as_str()) {
                    result.push_str("; ");
                    i = j;
                } else {
                    result.push(' ');
                    i += 1;
                }
            }
            _ => {
                result.push(c);
                i += 1;
            }
        }
    }
    result
}

fn history_buffer_is_complete(buf: &str) -> bool {
    if buf.ends_with("\\\n") {
        return false;
    }

    let chars: Vec<char> = buf.chars().collect();
    let mut i = 0usize;
    let n = chars.len();
    let mut in_single = false;
    let mut in_double = false;
    let mut in_backtick = false;
    let mut paren_depth: i32 = 0;
    let mut brace_depth: i32 = 0;
    let mut dparen_depth: i32 = 0;
    let mut compound_depth: i32 = 0;
    let mut pending_heredocs: Vec<(String, bool)> = Vec::new();
    let mut at_stmt_start = true;

    while i < n {
        let c = chars[i];

        if at_stmt_start && !pending_heredocs.is_empty() && !in_single && !in_double && !in_backtick {
            let mut j = i;
            while j < n && chars[j] != '\n' {
                j += 1;
            }
            let line: String = chars[i..j].iter().collect();
            let (want, strip_tabs) = &pending_heredocs[0];
            let candidate = if *strip_tabs {
                line.trim_start_matches('\t')
            } else {
                line.as_str()
            };
            if candidate == want {
                pending_heredocs.remove(0);
            }
            i = if j < n { j + 1 } else { j };
            at_stmt_start = true;
            continue;
        }

        if in_single {
            if c == '\'' {
                in_single = false;
            }
            at_stmt_start = c == '\n';
            i += 1;
            continue;
        }
        if in_double {
            if c == '\\' && i + 1 < n {
                i += 2;
                at_stmt_start = false;
                continue;
            }
            if c == '"' {
                in_double = false;
            }
            at_stmt_start = c == '\n';
            i += 1;
            continue;
        }
        if in_backtick {
            if c == '\\' && i + 1 < n {
                i += 2;
                at_stmt_start = false;
                continue;
            }
            if c == '`' {
                in_backtick = false;
            }
            at_stmt_start = c == '\n';
            i += 1;
            continue;
        }

        match c {
            '\'' => {
                in_single = true;
                at_stmt_start = false;
                i += 1;
            }
            ' ' | '\t' => {
                i += 1;
            }
            '"' => {
                in_double = true;
                at_stmt_start = false;
                i += 1;
            }
            '`' => {
                in_backtick = true;
                at_stmt_start = false;
                i += 1;
            }
            '\\' => {
                if i + 1 < n {
                    i += 2;
                } else {
                    i += 1;
                }
                at_stmt_start = false;
            }
            '$' => {
                if i + 2 < n && chars[i + 1] == '(' && chars[i + 2] == '(' {
                    dparen_depth += 1;
                    i += 3;
                } else if i + 1 < n && chars[i + 1] == '(' {
                    paren_depth += 1;
                    i += 2;
                } else if i + 1 < n && chars[i + 1] == '{' {
                    brace_depth += 1;
                    i += 2;
                } else {
                    at_stmt_start = false;
                    i += 1;
                }
            }
            '(' => {
                if i + 1 < n && chars[i + 1] == '(' {
                    dparen_depth += 1;
                    i += 2;
                } else {
                    paren_depth += 1;
                    i += 1;
                }
                at_stmt_start = false;
            }
            ')' => {
                if dparen_depth > 0 && i + 1 < n && chars[i + 1] == ')' {
                    dparen_depth -= 1;
                    i += 2;
                } else {
                    paren_depth = (paren_depth - 1).max(0);
                    i += 1;
                }
                at_stmt_start = false;
            }
            '}' => {
                brace_depth = (brace_depth - 1).max(0);
                at_stmt_start = false;
                i += 1;
            }
            '<' => {
                if i + 1 < n && chars[i + 1] == '<' {
                    let mut j = i + 2;
                    let mut strip_tabs = false;
                    if j < n && chars[j] == '-' {
                        strip_tabs = true;
                        j += 1;
                    }
                    while j < n && (chars[j] == ' ' || chars[j] == '\t') {
                        j += 1;
                    }
                    let start = j;
                    while j < n && chars[j] != '\n' && chars[j] != ' ' && chars[j] != '\t' {
                        j += 1;
                    }
                    if start < j {
                        let delim: String = chars[start..j].iter().collect();
                        pending_heredocs.push((delim, strip_tabs));
                    }
                    i = j;
                } else {
                    at_stmt_start = false;
                    i += 1;
                }
            }
            ';' | '&' => {
                at_stmt_start = true;
                i += 1;
            }
            '\n' => {
                at_stmt_start = true;
                i += 1;
            }
            c if at_stmt_start && c.is_ascii_alphabetic() => {
                let start = i;
                while i < n && (chars[i].is_ascii_alphanumeric() || chars[i] == '_') {
                    i += 1;
                }
                let word: String = chars[start..i].iter().collect();
                match word.as_str() {
                    "if" | "while" | "until" | "for" | "case" | "select" => compound_depth += 1,
                    "fi" | "done" | "esac" => compound_depth = (compound_depth - 1).max(0),
                    _ => {}
                }
                at_stmt_start = false;
            }
            _ => {
                at_stmt_start = false;
                i += 1;
            }
        }
    }

    !in_single && !in_double && !in_backtick
        && paren_depth <= 0 && brace_depth <= 0
        && dparen_depth <= 0 && compound_depth <= 0
        && pending_heredocs.is_empty()
}

// ===== Word Tokenization =====

/// Split history event text into words (shell-aware tokenization).
pub fn tokenize_words(text: &str) -> Vec<String> {
    let chars: Vec<char> = text.chars().collect();
    let n = chars.len();
    let mut words: Vec<String> = Vec::new();
    let mut current = String::new();
    let mut i = 0;

    while i < n {
        let c = chars[i];
        match c {
            ' ' | '\t' => {
                if !current.is_empty() {
                    words.push(std::mem::take(&mut current));
                }
                i += 1;
            }
            '\'' => {
                current.push(c);
                i += 1;
                while i < n && chars[i] != '\'' {
                    current.push(chars[i]);
                    i += 1;
                }
                if i < n { current.push('\''); i += 1; }
            }
            '"' => {
                current.push(c);
                i += 1;
                while i < n {
                    if chars[i] == '\\' && i + 1 < n {
                        current.push(chars[i]);
                        current.push(chars[i + 1]);
                        i += 2;
                    } else if chars[i] == '"' {
                        current.push('"');
                        i += 1;
                        break;
                    } else {
                        current.push(chars[i]);
                        i += 1;
                    }
                }
            }
            '\\' if i + 1 < n => {
                current.push(c);
                current.push(chars[i + 1]);
                i += 2;
            }
            '$' if i + 1 < n && chars[i + 1] == '(' => {
                // $(…) — consume as one token
                current.push(c);
                i += 1;
                let (inner, after) = consume_balanced(&chars, i, '(', ')');
                current.push_str(&inner);
                i = after;
            }
            '$' if i + 1 < n && chars[i + 1] == '(' => {
                // already handled above (duplicate, remove)
                unreachable!()
            }
            '$' if i + 1 < n && chars[i + 1] == '{' => {
                current.push(c);
                i += 1;
                let (inner, after) = consume_balanced(&chars, i, '{', '}');
                current.push_str(&inner);
                i = after;
            }
            '$' if i + 1 < n && chars[i + 1] == '(' => {
                unreachable!()
            }
            '(' => {
                // Process substitution <(…) or command grouping
                let (inner, after) = consume_balanced(&chars, i, '(', ')');
                current.push_str(&inner);
                i = after;
            }
            '<' if i + 1 < n && chars[i + 1] == '(' => {
                current.push(c);
                i += 1;
                let (inner, after) = consume_balanced(&chars, i, '(', ')');
                current.push_str(&inner);
                i = after;
            }
            '`' => {
                current.push(c);
                i += 1;
                while i < n && chars[i] != '`' {
                    if chars[i] == '\\' && i + 1 < n {
                        current.push(chars[i]);
                        current.push(chars[i + 1]);
                        i += 2;
                    } else {
                        current.push(chars[i]);
                        i += 1;
                    }
                }
                if i < n { current.push('`'); i += 1; }
            }
            _ => {
                current.push(c);
                i += 1;
            }
        }
    }
    if !current.is_empty() { words.push(current); }
    words
}

fn consume_balanced(chars: &[char], start: usize, open: char, close: char) -> (String, usize) {
    let n = chars.len();
    let mut i = start;
    let mut result = String::new();
    let mut depth = 0;

    while i < n {
        let c = chars[i];
        if c == open { depth += 1; }
        if c == close {
            if depth == 0 {
                // consume the closing char too
                result.push(c);
                i += 1;
                break;
            }
            depth -= 1;
        }
        result.push(c);
        i += 1;
    }
    (result, i)
}

// ===== String Modifiers =====

fn path_head(s: &str) -> String {
    if let Some(pos) = s.rfind('/') {
        if pos == 0 { "/".to_string() }
        else { s[..pos].to_string() }
    } else {
        ".".to_string()
    }
}

fn path_tail(s: &str) -> String {
    match s.rfind('/') {
        Some(pos) => s[pos + 1..].to_string(),
        None => s.to_string(),
    }
}

fn remove_extension(s: &str) -> String {
    // :r — remove trailing suffix from last component
    // Apply to each word if multiple words
    let words = s.split_whitespace().collect::<Vec<_>>();
    if words.len() > 1 {
        words.iter().map(|w| remove_ext_one(w)).collect::<Vec<_>>().join(" ")
    } else {
        remove_ext_one(s)
    }
}

fn remove_ext_one(s: &str) -> String {
    // Find the last '.', but only in the tail component
    let tail_start = s.rfind('/').map(|p| p + 1).unwrap_or(0);
    let tail = &s[tail_start..];
    if let Some(pos) = tail.rfind('.') {
        if pos > 0 {
            return format!("{}{}", &s[..tail_start], &tail[..pos]);
        }
    }
    s.to_string()
}

fn keep_extension(s: &str) -> String {
    let words = s.split_whitespace().collect::<Vec<_>>();
    if words.len() > 1 {
        words.iter().map(|w| keep_ext_one(w)).collect::<Vec<_>>().join(" ")
    } else {
        keep_ext_one(s)
    }
}

fn keep_ext_one(s: &str) -> String {
    let tail_start = s.rfind('/').map(|p| p + 1).unwrap_or(0);
    let tail = &s[tail_start..];
    if let Some(pos) = tail.rfind('.') {
        return tail[pos..].to_string();
    }
    s.to_string()
}

fn quote_string(s: &str) -> String {
    // :q — single-quote the whole string
    format!("'{}'", s.replace('\'', "'\\''"))
}

fn quote_each_word(s: &str) -> String {
    // :x — quote each whitespace-separated word
    s.split_whitespace()
        .map(|w| format!("'{}'", w.replace('\'', "'\\''")))
        .collect::<Vec<_>>()
        .join(" ")
}

fn lowercase_first(s: &str) -> String {
    let mut chars = s.chars();
    match chars.next() {
        None => String::new(),
        Some(c) => c.to_lowercase().collect::<String>() + chars.as_str(),
    }
}

fn uppercase_first(s: &str) -> String {
    let mut chars = s.chars();
    match chars.next() {
        None => String::new(),
        Some(c) => c.to_uppercase().collect::<String>() + chars.as_str(),
    }
}

/// Replace the FIRST occurrence of `old` in `s` with `new_` (& in new_ = old).
pub fn subst_first(s: &str, old: &str, new_: &str) -> Option<String> {
    if old.is_empty() { return Some(s.to_string()); }
    if let Some(pos) = s.find(old) {
        let replacement = new_.replace('&', old);
        Some(format!("{}{}{}", &s[..pos], replacement, &s[pos + old.len()..]))
    } else {
        None
    }
}

/// Replace ALL occurrences of `old` in `s` with `new_`.
pub fn subst_all(s: &str, old: &str, new_: &str) -> String {
    if old.is_empty() { return s.to_string(); }
    let replacement = new_.replace('&', old);
    s.replace(old, &replacement)
}

fn history_usage() -> &'static str {
    "history: usage: history [-c] [-d offset] [n] or history -anrw [filename] or history -ps arg [arg...]"
}

fn history_error(script_name: &str, lineno: usize, msg: &str) {
    eprintln!("{}: line {}: history: {}", script_name, lineno, msg);
}

fn history_event_to_index(hist: &HistoryList, event: i64) -> Option<usize> {
    if hist.entries.is_empty() || event == 0 {
        return None;
    }
    let first = hist.first_number() as i64;
    let last = first + hist.entries.len() as i64 - 1;
    let abs = if event > 0 {
        event
    } else {
        last + event + 1
    };
    if abs < first || abs > last {
        None
    } else {
        Some((abs - first) as usize)
    }
}

fn parse_history_event_spec(spec: &str) -> Result<i64, String> {
    spec.trim().parse::<i64>().map_err(|_| format!("{}: invalid number", spec))
}

fn delete_history_spec(hist: &mut HistoryList, spec: &str) -> Result<(), String> {
    if spec.starts_with('@') {
        return Err(format!("{}: invalid number", spec));
    }

    if let Some(sep) = spec[1..].find('-') {
        let sep = sep + 1;
        let start_spec = &spec[..sep];
        let end_spec = &spec[sep + 1..];
        let start = parse_history_event_spec(start_spec)
            .map_err(|_| format!("{}: history position out of range", spec))?;
        let end = parse_history_event_spec(end_spec)
            .map_err(|_| format!("{}: history position out of range", spec))?;
        let start_idx = match history_event_to_index(hist, start) {
            Some(idx) => idx,
            None => {
                return Err(format!("{}: history position out of range", start_spec));
            }
        };
        let end_idx = match history_event_to_index(hist, end) {
            Some(idx) => idx,
            None => {
                return Err(format!("{}: history position out of range", end_spec));
            }
        };
        let (lo, hi) = if start_idx <= end_idx {
            (start_idx, end_idx)
        } else {
            (end_idx, start_idx)
        };
        for idx in (lo..=hi).rev() {
            hist.remove_at(idx);
        }
        return Ok(());
    }

    let event = parse_history_event_spec(spec).map_err(|_| format!("{}: history position out of range", spec))?;
    match history_event_to_index(hist, event) {
        Some(idx) => {
            hist.remove_at(idx);
            Ok(())
        }
        None => Err(format!("{}: history position out of range", spec)),
    }
}

// ===== History Builtin =====

/// Implement `history [args]`. Returns exit status.
pub fn builtin_history(
    hist: &mut HistoryList,
    args: &[String],
    histfile: Option<&str>,
    histfile_opts: HistoryFileOptions,
    script_name: &str,
    lineno: usize,
    histchars: &str,
) -> i32 {
    if args.is_empty() {
        hist.print_history(None);
        return 0;
    }

    let mut i = 0;
    let n = args.len();
    let mut status = 0;
    let mut anrw_count = 0usize;
    let mut file_arg: Option<String> = None;

    while i < n {
        match args[i].as_str() {
            "-c" => { hist.clear(); i += 1; }
            "-a" => {
                anrw_count += 1;
                i += 1;
                if i < n && !args[i].starts_with('-') && file_arg.is_none() {
                    file_arg = Some(args[i].clone());
                    i += 1;
                }
                if anrw_count > 1 {
                    history_error(script_name, lineno, "cannot use more than one of -anrw");
                    return 1;
                }
                if let Some(path) = file_arg.as_deref().or(histfile) {
                    if let Err(e) = hist.write_to_file_with_options(path, true, histfile_opts) {
                        eprintln!("history: {}: {}", path, e);
                        status = 1;
                    }
                }
            }
            "-w" => {
                anrw_count += 1;
                i += 1;
                if i < n && !args[i].starts_with('-') && file_arg.is_none() {
                    file_arg = Some(args[i].clone());
                    i += 1;
                }
                if anrw_count > 1 {
                    history_error(script_name, lineno, "cannot use more than one of -anrw");
                    return 1;
                }
                if let Some(path) = file_arg.as_deref().or(histfile) {
                    if let Err(e) = hist.write_to_file_with_options(path, false, histfile_opts) {
                        eprintln!("history: {}: {}", path, e);
                        status = 1;
                    }
                }
            }
            "-r" => {
                anrw_count += 1;
                i += 1;
                if i < n && !args[i].starts_with('-') && file_arg.is_none() {
                    file_arg = Some(args[i].clone());
                    i += 1;
                }
                if anrw_count > 1 {
                    history_error(script_name, lineno, "cannot use more than one of -anrw");
                    return 1;
                }
                if let Some(path) = file_arg.as_deref().or(histfile) {
                    let _ = hist.read_from_file_with_options(path, histfile_opts);
                }
            }
            "-n" => {
                // Read new lines not yet read — approximate with -r
                anrw_count += 1;
                i += 1;
                if i < n && !args[i].starts_with('-') && file_arg.is_none() {
                    file_arg = Some(args[i].clone());
                    i += 1;
                }
                if anrw_count > 1 {
                    history_error(script_name, lineno, "cannot use more than one of -anrw");
                    return 1;
                }
                if let Some(path) = file_arg.as_deref().or(histfile) {
                    let _ = hist.read_from_file_with_options(path, histfile_opts);
                }
            }
            "-d" => {
                i += 1;
                if i < n {
                    match delete_history_spec(hist, &args[i]) {
                        Ok(()) => {}
                        Err(msg) => {
                            history_error(script_name, lineno, &msg);
                            return 1;
                        }
                    }
                    i += 1;
                }
            }
            "-s" => {
                i += 1;
                while i < n {
                    hist.add(args[i].clone());
                    i += 1;
                }
            }
            "-p" => {
                i += 1;
                let mut last_subst: Option<(String, String)> = None;
                while i < n {
                    let line = &args[i];
                    match expand(hist, line, script_name, lineno, histchars, &mut last_subst, false) {
                        HistExpResult::Expanded(s) | HistExpResult::PrintOnly(s) => println!("{}", s),
                        HistExpResult::NoOp => println!("{}", line),
                        HistExpResult::Error(e) => {
                            // Format: {script}: line {N}: history: {expr}: history expansion failed
                            eprintln!("{}: line {}: history: {}", script_name, lineno, e);
                            status = 1;
                        }
                    }
                    i += 1;
                }
            }
            _ => {
                if args[i].starts_with('-') {
                    history_error(script_name, lineno, &format!("{}: invalid option", args[i]));
                    eprintln!("{}", history_usage());
                    return 1;
                }
                // Numeric argument: print last N
                if args[i].starts_with('@') {
                    eprintln!("{}: line {}: history: {}: numeric argument required", script_name, lineno, args[i]);
                    return 2;
                }
                match args[i].parse::<usize>() {
                    Ok(num) => {
                        if i + 1 < n {
                            history_error(script_name, lineno, "too many arguments");
                            return 2;
                        }
                        hist.print_history(Some(num));
                    }
                    Err(_) => {
                        eprintln!("{}: line {}: history: {}: numeric argument required", script_name, lineno, args[i]);
                        return 2;
                    }
                }
                i += 1;
            }
        }
    }
    status
}
