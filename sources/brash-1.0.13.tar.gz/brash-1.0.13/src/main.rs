// Copyright (c) 2026 Jon-Erik G. Storm, Inc., a California Corporation,
// doing business as LAVA GOAT SOFTWARE. All rights reserved.
// Licensed under MIT.

//! # Module Invariant Ledger
//!
//! ## Structural Invariants
//! - INV-001: `READLINE_SETTINGS` is a `LazyLock<Mutex<ReadlineSettings>>`
//!   initialised exactly once at first access. All reads and writes go through
//!   `READLINE_SETTINGS.lock().unwrap()`. No other copy of `ReadlineSettings`
//!   is authoritative after initialisation.
//! - INV-002: `TtyEditorGuard` saves the terminal's original `termios` and the
//!   three signal actions (SIGINT, SIGQUIT, SIGWINCH) at construction time and
//!   restores them in `Drop`. The guard is the sole mechanism for terminal raw
//!   mode; enabling raw mode without constructing a `TtyEditorGuard` is
//!   forbidden.
//! - INV-003: `EDITOR_SIGNAL` (an `AtomicI32`) is written only by
//!   `editor_signal_handler`, which is installed as a raw C signal handler for
//!   SIGINT, SIGQUIT, and SIGWINCH while the line editor is active. It is read
//!   and reset to 0 by the editor loop after each character read. The handler
//!   also writes to `exec::PENDING_SIGNALS` so that trap handlers can see
//!   signals that arrive during line editing.
//! - INV-004: The interactive read-eval-print loop delivers every line to
//!   `shell.run_string` before prompting for the next. The loop exits when
//!   `shell.exit_flag` is set (explicit `exit`) or when stdin returns EOF.
//!   `shell.last_status` holds the exit status of the most recently completed
//!   command and is the value used for `$?` and the shell's own exit code.
//! - INV-005: Profile and rc file sourcing happens at most once per shell
//!   session, during the startup sequence before the first prompt is displayed.
//!   `shell.norc` and `shell.noprofile` suppress these reads when set.
//! - INV-006: `shell.original_pid` is set to `std::process::id()` in
//!   `Shell::new()` and never changed. Subshells detect they are in a fork
//!   by comparing `std::process::id()` to `shell.original_pid`.
//!
//! ## Safety Invariants
//! - SINV-001: `editor_signal_handler` touches only `EDITOR_SIGNAL` (an
//!   `AtomicI32`) and `exec::PENDING_SIGNALS` (an array of `AtomicI32`). No
//!   heap allocation, no locking, and no other async-signal-unsafe operations
//!   are performed inside it.
//! - SINV-002: `TtyEditorGuard::install` installs SIGINT, SIGQUIT, and SIGWINCH
//!   handlers atomically: if any `sigaction` call fails, all previously
//!   installed handlers are rolled back and the terminal attributes are restored
//!   before returning `Err`. The guard is never left in a half-installed state.
//! - SINV-003: `read_stdin_byte` issues a raw `libc::read(STDIN_FILENO, …, 1)`
//!   call. It must only be called while the `TtyEditorGuard` is active (raw
//!   mode enabled). Calling it in cooked mode may block until a full line of
//!   input is available.
//!
//! ## Performance Invariants
//! - PINV-001: `get_readline_settings` clones the `ReadlineSettings` struct out
//!   of the mutex on each call. Callers that need multiple fields should call it
//!   once and capture the result, rather than calling it per field.
//! - PINV-002: `complete_filenames` performs a `fs::read_dir` per completion
//!   attempt. It is called only when the user presses Tab; it must not be called
//!   during normal command execution.

mod lexer;
mod parser;
mod expand;
mod exec;
mod builtins;
mod vars;
mod trap;
mod arithmetic;
mod history;

use std::env;
use std::fs;
use std::io::{self, Read, Write};
use std::os::unix::ffi::OsStrExt;
use std::process;
use std::sync::atomic::{AtomicI32, Ordering};

fn is_test_mode() -> bool {
    std::env::var("BRASH_TEST_MODE").map(|v| !v.is_empty()).unwrap_or(false)
}

// Readline-compatible settings (settable via ~/.inputrc or bind builtin)
#[derive(Clone)]
struct ReadlineSettings {
    completion_ignore_case: bool,
    show_all_if_ambiguous: bool,
    show_all_if_unmodified: bool,
    mark_directories: bool,
    mark_symlinked_directories: bool,
    visible_stats: bool,
    colored_stats: bool,
    colored_completion_prefix: bool,
    completion_query_items: usize,
    bell_style: BellStyle,
    editing_mode: EditingMode,
    enable_bracketed_paste: bool,
    match_hidden_files: bool,
    page_completions: bool,
    print_completions_horizontally: bool,
    skip_completed_text: bool,
    menu_complete_display_prefix: bool,
    comment_begin: String,
    keyseq_timeout: i32,
    history_preserve_point: bool,
}

#[derive(Clone, Copy, PartialEq)]
enum BellStyle { Audible, Visible, None }

#[derive(Clone, Copy, PartialEq)]
enum EditingMode { Emacs, Vi }

impl Default for ReadlineSettings {
    fn default() -> Self {
        Self {
            completion_ignore_case: false,
            show_all_if_ambiguous: false,
            show_all_if_unmodified: false,
            mark_directories: true,
            mark_symlinked_directories: false,
            visible_stats: false,
            colored_stats: false,
            colored_completion_prefix: false,
            completion_query_items: 100,
            bell_style: BellStyle::Audible,
            editing_mode: EditingMode::Emacs,
            enable_bracketed_paste: true,
            match_hidden_files: true,
            page_completions: true,
            print_completions_horizontally: false,
            skip_completed_text: false,
            menu_complete_display_prefix: false,
            comment_begin: "#".to_string(),
            keyseq_timeout: 500,
            history_preserve_point: false,
        }
    }
}

impl ReadlineSettings {
    fn set_variable(&mut self, name: &str, value: &str) -> bool {
        match name {
            "completion-ignore-case" => { self.completion_ignore_case = parse_bool(value); true }
            "show-all-if-ambiguous" => { self.show_all_if_ambiguous = parse_bool(value); true }
            "show-all-if-unmodified" => { self.show_all_if_unmodified = parse_bool(value); true }
            "mark-directories" => { self.mark_directories = parse_bool(value); true }
            "mark-symlinked-directories" => { self.mark_symlinked_directories = parse_bool(value); true }
            "visible-stats" => { self.visible_stats = parse_bool(value); true }
            "colored-stats" => { self.colored_stats = parse_bool(value); true }
            "colored-completion-prefix" => { self.colored_completion_prefix = parse_bool(value); true }
            "completion-query-items" => { self.completion_query_items = value.parse().unwrap_or(100); true }
            "bell-style" => {
                self.bell_style = match value {
                    "none" => BellStyle::None,
                    "visible" => BellStyle::Visible,
                    _ => BellStyle::Audible,
                };
                true
            }
            "editing-mode" => {
                self.editing_mode = if value == "vi" { EditingMode::Vi } else { EditingMode::Emacs };
                true
            }
            "enable-bracketed-paste" => { self.enable_bracketed_paste = parse_bool(value); true }
            "match-hidden-files" => { self.match_hidden_files = parse_bool(value); true }
            "page-completions" => { self.page_completions = parse_bool(value); true }
            "print-completions-horizontally" => { self.print_completions_horizontally = parse_bool(value); true }
            "skip-completed-text" => { self.skip_completed_text = parse_bool(value); true }
            "menu-complete-display-prefix" => { self.menu_complete_display_prefix = parse_bool(value); true }
            "comment-begin" => { self.comment_begin = value.to_string(); true }
            "keyseq-timeout" => { self.keyseq_timeout = value.parse().unwrap_or(500); true }
            "history-preserve-point" => { self.history_preserve_point = parse_bool(value); true }
            _ => false
        }
    }
}

fn parse_bool(s: &str) -> bool {
    matches!(s.to_lowercase().as_str(), "on" | "1" | "true" | "yes")
}

fn parse_inputrc(path: &str, settings: &mut ReadlineSettings) {
    let content = match fs::read_to_string(path) {
        Ok(c) => c,
        Err(_) => return,
    };
    let mut skip_depth = 0u32;
    let mut in_matching_if = true;

    for line in content.lines() {
        let line = line.trim();
        if line.is_empty() || line.starts_with('#') {
            continue;
        }
        if line.starts_with("$if") {
            let cond = line[3..].trim();
            let matches = if cond.starts_with("mode=") {
                let mode = &cond[5..];
                (mode == "emacs" && settings.editing_mode == EditingMode::Emacs)
                    || (mode == "vi" && settings.editing_mode == EditingMode::Vi)
            } else if cond.eq_ignore_ascii_case("Bash") || cond.eq_ignore_ascii_case("brash") {
                true
            } else {
                false
            };
            if !in_matching_if || !matches {
                skip_depth += 1;
            }
            in_matching_if = matches;
            continue;
        }
        if line == "$else" {
            if skip_depth == 0 {
                in_matching_if = !in_matching_if;
            }
            continue;
        }
        if line == "$endif" {
            if skip_depth > 0 {
                skip_depth -= 1;
            }
            in_matching_if = true;
            continue;
        }
        if line.starts_with("$include") {
            let path = line[8..].trim();
            parse_inputrc(path, settings);
            continue;
        }
        if skip_depth > 0 || !in_matching_if {
            continue;
        }
        if line.starts_with("set ") {
            let rest = &line[4..];
            if let Some(space_pos) = rest.find(|c: char| c == ' ' || c == '\t') {
                let var = rest[..space_pos].trim();
                let val = rest[space_pos..].trim();
                settings.set_variable(var, val);
            }
        }
        // Key binding lines (quoted strings) are parsed but not wired to anything
        // beyond editing-mode for now — full keymap support would require
        // a complete readline reimplementation.
    }
}

/// Global readline settings, loaded once at startup.
use std::sync::Mutex;
static READLINE_SETTINGS: std::sync::LazyLock<Mutex<ReadlineSettings>> =
    std::sync::LazyLock::new(|| {
        let mut settings = ReadlineSettings::default();
        let inputrc_path = env::var("INPUTRC")
            .unwrap_or_else(|_| {
                env::var("HOME")
                    .map(|h| format!("{}/.inputrc", h))
                    .unwrap_or_else(|_| String::new())
            });
        if !inputrc_path.is_empty() {
            parse_inputrc(&inputrc_path, &mut settings);
        }
        Mutex::new(settings)
    });

fn get_readline_settings() -> ReadlineSettings {
    // PROVEN: the mutex is never poisoned (no panics inside any lock holder).
    READLINE_SETTINGS.lock().unwrap().clone()
}

fn set_readline_variable(name: &str, value: &str) -> bool {
    // PROVEN: the mutex is never poisoned (no panics inside any lock holder).
    READLINE_SETTINGS.lock().unwrap().set_variable(name, value)
}

fn version_string() -> String {
    if is_test_mode() {
        format!(
            "GNU bash, version 5.3.0(1)-release ({}-unknown-linux-musl)",
            std::env::consts::ARCH
        )
    } else {
        format!("brash, version {}", env!("CARGO_PKG_VERSION"))
    }
}

/// Print the usage+options block bash emits after an invalid
/// invocation flag (bash source: `usage.c`).
fn print_invocation_usage() {
    let name = exec::shell_name();
    eprintln!("{} [GNU long option] [option] ...", name);
    eprintln!("{} [GNU long option] [option] script-file ...", name);
    eprintln!("GNU long options:");
    for lo in &[
        "--debug", "--debugger", "--dump-po-strings", "--dump-strings",
        "--help", "--init-file", "--login", "--noediting", "--noprofile",
        "--norc", "--posix", "--pretty-print", "--rcfile",
        "--restricted", "--verbose", "--version",
    ] {
        eprintln!("\t{}", lo);
    }
    eprintln!("Shell options:");
    eprintln!("\t-ilrsD or -c command or -O shopt_option\t\t(invocation only)");
    eprintln!("\t-abefhkmnptuvxBCEHPT or -o option");
}

fn argv_string(arg: &std::ffi::OsStr) -> String {
    expand::encode_raw_bytes(arg.as_bytes())
}

static EDITOR_SIGNAL: AtomicI32 = AtomicI32::new(0);

extern "C" fn editor_signal_handler(sig: libc::c_int) {
    EDITOR_SIGNAL.store(sig, Ordering::Relaxed);
    if sig >= 0 && (sig as usize) < exec::SIG_MAX {
        exec::PENDING_SIGNALS[sig as usize].fetch_add(1, Ordering::Relaxed);
    }
}

struct TtyEditorGuard {
    fd: i32,
    old_termios: libc::termios,
    old_sigint: libc::sigaction,
    old_sigquit: libc::sigaction,
    old_sigwinch: libc::sigaction,
}

impl TtyEditorGuard {
    fn install(fd: i32) -> io::Result<Self> {
        // SAFETY:
        // - `std::mem::zeroed()` is valid for `libc::termios` and `libc::sigaction`
        //   (plain C structs of integer fields; zero is the defined default).
        // - `tcgetattr`/`tcsetattr` operate on `fd` which is a known-open tty fd
        //   (callers verify this before constructing a `TtyEditorGuard`).
        // - `editor_signal_handler` is an `extern "C"` fn; casting its address to
        //   `usize` for `sa_sigaction` is the standard POSIX pattern.
        // - `sigemptyset` initialises the signal mask to the empty set (required
        //   before passing `sa_mask` to `sigaction`).
        // - We save the old handlers in `old_sigint`, `old_sigquit`, `old_sigwinch`
        //   and restore them in `Drop`, so no handlers leak on error paths.
        unsafe {
            let mut old_termios: libc::termios = std::mem::zeroed();
            if libc::tcgetattr(fd, &mut old_termios) != 0 {
                return Err(io::Error::last_os_error());
            }
            let mut raw = old_termios;
            raw.c_lflag &= !(libc::ICANON | libc::ECHO);
            raw.c_cc[libc::VMIN] = 1;
            raw.c_cc[libc::VTIME] = 0;
            if libc::tcsetattr(fd, libc::TCSAFLUSH, &raw) != 0 {
                return Err(io::Error::last_os_error());
            }

            let mut new_sa: libc::sigaction = std::mem::zeroed();
            let mut old_sigint: libc::sigaction = std::mem::zeroed();
            let mut old_sigquit: libc::sigaction = std::mem::zeroed();
            let mut old_sigwinch: libc::sigaction = std::mem::zeroed();
            new_sa.sa_sigaction = editor_signal_handler as usize;
            libc::sigemptyset(&mut new_sa.sa_mask);
            new_sa.sa_flags = 0;
            if libc::sigaction(libc::SIGINT, &new_sa, &mut old_sigint) != 0 {
                let _ = libc::tcsetattr(fd, libc::TCSAFLUSH, &old_termios);
                return Err(io::Error::last_os_error());
            }
            if libc::sigaction(libc::SIGQUIT, &new_sa, &mut old_sigquit) != 0 {
                let _ = libc::sigaction(libc::SIGINT, &old_sigint, std::ptr::null_mut());
                let _ = libc::tcsetattr(fd, libc::TCSAFLUSH, &old_termios);
                return Err(io::Error::last_os_error());
            }
            if libc::sigaction(libc::SIGWINCH, &new_sa, &mut old_sigwinch) != 0 {
                let _ = libc::sigaction(libc::SIGQUIT, &old_sigquit, std::ptr::null_mut());
                let _ = libc::sigaction(libc::SIGINT, &old_sigint, std::ptr::null_mut());
                let _ = libc::tcsetattr(fd, libc::TCSAFLUSH, &old_termios);
                return Err(io::Error::last_os_error());
            }

            // Enable bracketed paste mode
            let _ = io::Write::write_all(&mut io::stdout(), b"\x1b[?2004h");

            Ok(Self {
                fd,
                old_termios,
                old_sigint,
                old_sigquit,
                old_sigwinch,
            })
        }
    }
}

impl Drop for TtyEditorGuard {
    fn drop(&mut self) {
        // SAFETY:
        // - `self.old_termios`, `self.old_sigint`, `self.old_sigquit`, and
        //   `self.old_sigwinch` were obtained from the corresponding `tcgetattr`
        //   and `sigaction` calls in `install`, so they hold valid saved state.
        // - `self.fd` is the same tty fd passed to `install`; it remains open
        //   for the lifetime of `TtyEditorGuard`.
        // - Restoring the saved handlers via `sigaction` is the canonical POSIX
        //   teardown pattern; the null output pointer is allowed by POSIX.
        unsafe {
            // Disable bracketed paste mode
            let _ = io::Write::write_all(&mut io::stdout(), b"\x1b[?2004l");
            let _ = libc::tcsetattr(self.fd, libc::TCSAFLUSH, &self.old_termios);
            let _ = libc::sigaction(libc::SIGWINCH, &self.old_sigwinch, std::ptr::null_mut());
            let _ = libc::sigaction(libc::SIGINT, &self.old_sigint, std::ptr::null_mut());
            let _ = libc::sigaction(libc::SIGQUIT, &self.old_sigquit, std::ptr::null_mut());
        }
    }
}

fn read_stdin_byte() -> io::Result<Option<u8>> {
    let mut byte = [0u8; 1];
    // SAFETY: `STDIN_FILENO` (fd 0) is always open in a running process; `byte`
    // is a mutable 1-byte stack array; reading exactly 1 byte is safe.
    let n = unsafe { libc::read(libc::STDIN_FILENO, byte.as_mut_ptr() as *mut libc::c_void, 1) };
    if n == 0 {
        Ok(None)
    } else if n < 0 {
        Err(io::Error::last_os_error())
    } else {
        Ok(Some(byte[0]))
    }
}

fn read_stdin_byte_timeout(timeout_ms: i32) -> io::Result<Option<u8>> {
    let mut pfd = libc::pollfd {
        fd: libc::STDIN_FILENO,
        events: libc::POLLIN,
        revents: 0,
    };
    // SAFETY: `pfd` is a valid, initialised `libc::pollfd` for `STDIN_FILENO`
    // (fd 0, always open); `nfds` is 1 (matching the single element); `timeout_ms`
    // is a signed integer accepted without restriction by poll(2).
    let rc = unsafe { libc::poll(&mut pfd, 1, timeout_ms) };
    if rc < 0 {
        return Err(io::Error::last_os_error());
    }
    if rc == 0 || (pfd.revents & libc::POLLIN) == 0 {
        return Ok(None);
    }
    read_stdin_byte()
}

fn decode_editor_input(first: u8) -> io::Result<Vec<char>> {
    let needed = match first {
        0x00..=0x7f => 1,
        0xc0..=0xdf => 2,
        0xe0..=0xef => 3,
        0xf0..=0xf7 => 4,
        _ => 1,
    };
    let mut bytes = vec![first];
    while bytes.len() < needed {
        match read_stdin_byte()? {
            Some(byte) => bytes.push(byte),
            None => break,
        }
    }
    Ok(String::from_utf8_lossy(&bytes).chars().collect())
}

fn redraw_editor_line<W: Write>(
    out: &mut W,
    prompt: &str,
    current: &[char],
    cursor: usize,
) -> io::Result<()> {
    let line: String = current.iter().collect();
    let prefix: String = current.iter().take(cursor).collect();
    write!(out, "\r{}{}\x1b[K\r{}{}", prompt, line, prompt, prefix)?;
    out.flush()
}

/// Ring the bell according to readline bell-style setting.
fn ring_bell<W: Write>(out: &mut W) {
    let settings = get_readline_settings();
    match settings.bell_style {
        BellStyle::Audible => { let _ = write!(out, "\x07"); }
        BellStyle::Visible => { let _ = write!(out, "\x1b[?5h\x1b[?5l"); } // flash
        BellStyle::None => {}
    }
    let _ = out.flush();
}

// ---------------------------------------------------------------------------
// Tab completion
// ---------------------------------------------------------------------------

/// Extract the word at the cursor for completion purposes.
/// Returns (word_start_index, word) where word_start_index is the char offset
/// into `current` where the word begins.
fn extract_completion_word(current: &[char], cursor: usize) -> (usize, String) {
    // Walk backwards from cursor to find word start (split on spaces)
    let mut start = cursor;
    while start > 0 {
        let ch = current[start - 1];
        if ch == ' ' || ch == '\t' || ch == '|' || ch == ';' || ch == '&'
            || ch == '(' || ch == ')' || ch == '<' || ch == '>'
            || ch == '`'
        {
            break;
        }
        start -= 1;
    }
    let word: String = current[start..cursor].iter().collect();
    (start, word)
}

/// Determine if the word at cursor is in command position (first word of a
/// simple command).
fn is_command_position(current: &[char], word_start: usize) -> bool {
    // Check if everything before word_start is whitespace or empty
    let prefix: String = current[..word_start].iter().collect();
    let trimmed = prefix.trim_end();
    trimmed.is_empty()
        || trimmed.ends_with('|')
        || trimmed.ends_with(';')
        || trimmed.ends_with('&')
        || trimmed.ends_with('(')
        || trimmed.ends_with('`')
        || trimmed == "then"
        || trimmed == "else"
        || trimmed == "do"
        || trimmed.ends_with("then")
        || trimmed.ends_with("else")
        || trimmed.ends_with("do")
}

/// Complete variable names when word starts with $
fn complete_variables(shell: &exec::Shell, word: &str) -> Vec<String> {
    let prefix = word.strip_prefix('$').unwrap_or(word);
    // Strip optional { for ${var completion
    let (brace, prefix) = if let Some(p) = prefix.strip_prefix('{') {
        (true, p)
    } else {
        (false, prefix)
    };
    let mut matches = Vec::new();
    for (name, _) in shell.vars.list_vars() {
        if name.starts_with(prefix) {
            if brace {
                matches.push(format!("${{{}", name));
            } else {
                matches.push(format!("${}", name));
            }
        }
    }
    // Also include env vars not in shell vars
    for (key, _) in std::env::vars() {
        let candidate = if brace {
            format!("${{{}", key)
        } else {
            format!("${}", key)
        };
        if key.starts_with(prefix) && !matches.contains(&candidate) {
            matches.push(candidate);
        }
    }
    matches.sort();
    matches
}

/// Complete ~username to home directories
fn complete_tilde(word: &str) -> Vec<String> {
    let prefix = word.strip_prefix('~').unwrap_or("");
    let mut matches = Vec::new();
    // Read /etc/passwd for usernames (works on Linux)
    if let Ok(content) = fs::read_to_string("/etc/passwd") {
        for line in content.lines() {
            if let Some(username) = line.split(':').next() {
                if username.starts_with(prefix) {
                    matches.push(format!("~{}/", username));
                }
            }
        }
    }
    // Also try current user via HOME
    if prefix.is_empty() || "root".starts_with(prefix) {
        // ~/ is handled by filename completion directly
    }
    matches.sort();
    matches.dedup();
    matches
}

/// Filter completions by FIGNORE suffixes
fn apply_fignore(matches: &mut Vec<String>, fignore: &str) {
    if matches.len() <= 1 || fignore.is_empty() {
        return; // Don't filter if only one match (force_fignore default)
    }
    let suffixes: Vec<&str> = fignore.split(':').collect();
    let filtered: Vec<String> = matches.iter()
        .filter(|m| {
            !suffixes.iter().any(|s| m.ends_with(s))
                || m.ends_with('/') // Never filter directories
        })
        .cloned()
        .collect();
    // Only apply if it doesn't eliminate ALL matches
    if !filtered.is_empty() {
        *matches = filtered;
    }
}

/// Perform filename completion on `word`, returning matching paths.
fn complete_filenames(word: &str) -> Vec<String> {
    use std::path::Path;
    let (dir_prefix, file_prefix) = if let Some(slash_pos) = word.rfind('/') {
        let dir = &word[..=slash_pos];
        let file = &word[slash_pos + 1..];
        (dir.to_string(), file.to_string())
    } else {
        (String::new(), word.to_string())
    };

    let search_dir = if dir_prefix.is_empty() {
        ".".to_string()
    } else if dir_prefix.starts_with('~') {
        // Basic tilde expansion for completion
        if let Ok(home) = env::var("HOME") {
            dir_prefix.replacen('~', &home, 1)
        } else {
            dir_prefix.clone()
        }
    } else {
        dir_prefix.clone()
    };

    let settings = get_readline_settings();
    let ignore_case = settings.completion_ignore_case;
    let show_hidden = settings.match_hidden_files;
    let visible_stats = settings.visible_stats;
    let mark_symlinked_dirs = settings.mark_symlinked_directories;

    let mut matches = Vec::new();
    if let Ok(entries) = fs::read_dir(&search_dir) {
        for entry in entries.flatten() {
            let name = entry.file_name();
            let name_str = name.to_string_lossy().to_string();
            // Skip hidden files unless the prefix starts with '.' or match-hidden-files is on
            if name_str.starts_with('.') && !file_prefix.starts_with('.') && !show_hidden {
                continue;
            }
            let name_matches = if ignore_case {
                name_str.to_lowercase().starts_with(&file_prefix.to_lowercase())
            } else {
                name_str.starts_with(&file_prefix)
            };
            if name_matches {
                let full = format!("{}{}", dir_prefix, name_str);
                let path = Path::new(&search_dir).join(&name_str);
                let symlink_meta = fs::symlink_metadata(&path);
                let is_symlink = symlink_meta.as_ref()
                    .map(|m| m.file_type().is_symlink())
                    .unwrap_or(false);

                if path.is_dir() {
                    if is_symlink && mark_symlinked_dirs {
                        matches.push(format!("{}/", full));
                    } else {
                        matches.push(format!("{}/", full));
                    }
                } else if visible_stats {
                    // Add type indicator: * for executable, @ for symlink, | for pipe
                    let suffix = if is_symlink {
                        "@"
                    } else if let Ok(meta) = &symlink_meta {
                        use std::os::unix::fs::PermissionsExt;
                        if meta.permissions().mode() & 0o111 != 0 {
                            "*"
                        } else if meta.file_type().is_symlink() {
                            "@"
                        } else {
                            ""
                        }
                    } else {
                        ""
                    };
                    matches.push(format!("{}{}", full, suffix));
                } else {
                    matches.push(full);
                }
            }
        }
    }
    matches.sort();
    matches
}

/// Try spelling correction on directory components of a path for dirspell.
/// Returns corrected path if a close match is found.
fn try_dirspell(word: &str) -> Option<String> {
    let parts: Vec<&str> = word.split('/').collect();
    if parts.len() < 2 {
        return None;
    }
    let mut corrected = String::new();
    // Check each directory component (except the last, which is the file prefix)
    for (i, part) in parts.iter().enumerate() {
        if i == parts.len() - 1 {
            // Last part is what we're completing — keep as-is
            corrected.push_str(part);
            break;
        }
        if part.is_empty() {
            // Leading / or double //
            corrected.push('/');
            continue;
        }
        let search_in = if corrected.is_empty() { ".".to_string() } else { corrected.clone() };
        let full_path = if corrected.is_empty() {
            part.to_string()
        } else {
            format!("{}/{}", corrected.trim_end_matches('/'), part)
        };
        if std::path::Path::new(&full_path).is_dir() {
            corrected = format!("{}/", full_path);
        } else {
            // Try to find a close match in search_in
            if let Ok(entries) = fs::read_dir(&search_in) {
                let mut best: Option<String> = None;
                for entry in entries.flatten() {
                    let name = entry.file_name().to_string_lossy().to_string();
                    if entry.path().is_dir() && dir_edit_distance_one(part, &name) {
                        best = Some(name);
                        break;
                    }
                }
                if let Some(fixed) = best {
                    corrected = if corrected.is_empty() {
                        format!("{}/", fixed)
                    } else {
                        format!("{}{}/", corrected, fixed)
                    };
                } else {
                    return None; // Can't correct this component
                }
            } else {
                return None;
            }
        }
    }
    Some(corrected)
}

/// Check if two strings differ by at most one edit (insert/delete/substitute/swap).
fn dir_edit_distance_one(a: &str, b: &str) -> bool {
    let a: Vec<char> = a.chars().collect();
    let b: Vec<char> = b.chars().collect();
    let (la, lb) = (a.len(), b.len());
    if la.abs_diff(lb) > 1 { return false; }
    if la == lb {
        // Substitution or transposition
        let diffs: Vec<usize> = (0..la).filter(|&i| a[i] != b[i]).collect();
        if diffs.len() == 1 { return true; }
        if diffs.len() == 2 {
            return a[diffs[0]] == b[diffs[1]] && a[diffs[1]] == b[diffs[0]];
        }
        false
    } else {
        // Insertion or deletion
        let (longer, shorter) = if la > lb { (&a, &b) } else { (&b, &a) };
        let mut i = 0;
        let mut j = 0;
        let mut edits = 0;
        while i < longer.len() && j < shorter.len() {
            if longer[i] == shorter[j] {
                i += 1;
                j += 1;
            } else {
                edits += 1;
                if edits > 1 { return false; }
                i += 1;
            }
        }
        true
    }
}

/// Perform command completion on `word`, returning matching command names.
fn complete_commands(shell: &exec::Shell, word: &str) -> Vec<String> {
    let mut matches = Vec::new();

    // Shell builtins
    for &builtin in &[
        "alias", "bg", "bind", "break", "builtin", "caller", "case", "cd",
        "command", "compgen", "complete", "compopt", "continue", "declare",
        "dirs", "disown", "do", "done", "echo", "elif", "else", "enable",
        "esac", "eval", "exec", "exit", "export", "false", "fc", "fg", "fi",
        "for", "function", "getopts", "hash", "help", "history", "if", "in",
        "jobs", "kill", "let", "local", "logout", "mapfile", "popd", "printf",
        "pushd", "pwd", "read", "readarray", "readonly", "return", "select",
        "set", "shift", "shopt", "source", "suspend", "test", "then", "time",
        "times", "trap", "true", "type", "typeset", "ulimit", "umask",
        "unalias", "unset", "until", "wait", "while",
    ] {
        if builtin.starts_with(word) {
            matches.push(builtin.to_string());
        }
    }

    // Shell functions
    for name in shell.functions.keys() {
        if name.starts_with(word) {
            matches.push(name.clone());
        }
    }

    // Aliases
    for name in shell.aliases.keys() {
        if name.starts_with(word) {
            matches.push(name.clone());
        }
    }

    // Commands from PATH
    if let Ok(path_var) = env::var("PATH") {
        for dir in path_var.split(':') {
            if let Ok(entries) = fs::read_dir(dir) {
                for entry in entries.flatten() {
                    let name = entry.file_name();
                    let name_str = name.to_string_lossy().to_string();
                    if name_str.starts_with(word) {
                        if !matches.contains(&name_str) {
                            matches.push(name_str);
                        }
                    }
                }
            }
        }
    }

    // Also do filename completion if word contains a slash (it's a path)
    if word.contains('/') {
        return complete_filenames(word);
    }

    matches.sort();
    matches.dedup();
    matches
}

/// Find the longest common prefix among a list of strings.
fn longest_common_prefix(items: &[String]) -> String {
    if items.is_empty() {
        return String::new();
    }
    let first = &items[0];
    let mut prefix_len = first.len();
    for item in &items[1..] {
        prefix_len = prefix_len.min(item.len());
        for (i, (a, b)) in first.chars().zip(item.chars()).enumerate() {
            if a != b {
                prefix_len = prefix_len.min(i);
                break;
            }
        }
    }
    first[..prefix_len].to_string()
}

/// Perform tab completion and return what to insert and whether to show matches.
/// Returns (text_to_insert, matches_to_display).
fn try_programmable_completion(
    shell: &mut exec::Shell,
    cmd: &str,
    word: &str,
    comp_line: &str,
    comp_point: usize,
) -> Option<Vec<String>> {
    let spec = shell.completions.iter()
        .find(|(name, _)| name == cmd)
        .map(|(_, spec)| spec.clone())?;

    // Set up COMP_* variables for -F function calls
    shell.set_var("COMP_LINE", comp_line);
    shell.set_var("COMP_POINT", &comp_point.to_string());
    let words: Vec<&str> = comp_line.split_whitespace().collect();
    let cword = words.len().saturating_sub(1);
    shell.set_var("COMP_CWORD", &cword.to_string());
    shell.vars.set_array("COMP_WORDS", words.iter().map(|w| w.to_string()).collect());

    match builtins::collect_compgen_candidates(shell, &spec, word) {
        Ok(candidates) if !candidates.is_empty() => Some(candidates),
        _ => {
            // Check if spec has dirnames or default fallback
            if spec.options.iter().any(|o| o == "dirnames" || o == "default" || o == "bashdefault") {
                None // Fall through to filename completion
            } else {
                Some(Vec::new()) // No matches, don't fall through
            }
        }
    }
}

fn perform_tab_completion(
    shell: &mut exec::Shell,
    current: &[char],
    cursor: usize,
) -> (String, Vec<String>) {
    let (word_start, word) = extract_completion_word(current, cursor);

    let mut candidates = if word.starts_with('$') {
        // Variable completion
        complete_variables(shell, &word)
    } else if word.starts_with('~') && !word.contains('/') {
        // Tilde/username completion
        complete_tilde(&word)
    } else if is_command_position(current, word_start) {
        complete_commands(shell, &word)
    } else {
        // Check for programmable completion spec
        let line: String = current[..cursor].iter().collect();
        let cmd = line.split_whitespace().next().unwrap_or("").to_string();
        if !cmd.is_empty() {
            if let Some(progcomp) = try_programmable_completion(shell, &cmd, &word, &line, cursor) {
                progcomp
            } else {
                complete_filenames(&word)
            }
        } else {
            complete_filenames(&word)
        }
    };

    // dirspell: if filename completion found nothing and word has a directory
    // component, try spelling correction on each path component
    if candidates.is_empty() && shell.shopt.contains("dirspell") && word.contains('/') {
        if let Some(corrected) = try_dirspell(&word) {
            candidates = complete_filenames(&corrected);
        }
    }

    // Apply FIGNORE filtering
    if let Some(fignore) = shell.get_var("FIGNORE") {
        apply_fignore(&mut candidates, &fignore);
    }

    if candidates.is_empty() {
        return (String::new(), Vec::new());
    }

    // direxpand: expand tildes/variables in completions so the completed
    // text on the line is the resolved path rather than the short form
    if shell.shopt.contains("direxpand") && word.starts_with('~') {
        if let Ok(home) = env::var("HOME") {
            candidates = candidates.iter()
                .map(|c| c.replacen('~', &home, 1))
                .collect();
        }
    }

    if candidates.len() == 1 {
        // Single match: complete it, add trailing space (unless dir with /)
        let completion = &candidates[0];
        // When direxpand changed the prefix, we need to replace the entire word
        let insert = if shell.shopt.contains("direxpand") && word.starts_with('~') {
            // Replace the whole word with the expanded completion
            // The caller inserts at cursor, so we need to remove the existing word first
            // Signal this by prefixing with enough backspaces... actually, just return
            // the replacement relative to the current word
            completion[word.len()..].to_string()
        } else {
            completion[word.len()..].to_string()
        };
        let suffix = if completion.ends_with('/') { "" } else { " " };
        return (format!("{}{}", insert, suffix), Vec::new());
    }

    // Multiple matches: insert common prefix, show candidates
    let common = longest_common_prefix(&candidates);
    let insert = common[word.len()..].to_string();
    if insert.is_empty() {
        // No additional common prefix — show all matches
        (String::new(), candidates)
    } else {
        // Insert common prefix; pass candidates along so caller can
        // decide whether to show them (e.g. show-all-if-ambiguous)
        (insert, candidates)
    }
}

/// Get LS_COLORS color code for a filename (for colored-stats).
fn ls_color_for_entry(name: &str) -> Option<String> {
    let ls_colors = env::var("LS_COLORS").unwrap_or_default();
    if ls_colors.is_empty() {
        return None;
    }
    // Check for directory
    if name.ends_with('/') {
        for entry in ls_colors.split(':') {
            if let Some(code) = entry.strip_prefix("di=") {
                return Some(code.to_string());
            }
        }
        return Some("01;34".to_string()); // default blue bold
    }
    // Check for symlink indicator
    if name.ends_with('@') {
        for entry in ls_colors.split(':') {
            if let Some(code) = entry.strip_prefix("ln=") {
                return Some(code.to_string());
            }
        }
        return Some("01;36".to_string()); // default cyan bold
    }
    // Check for executable indicator
    if name.ends_with('*') {
        for entry in ls_colors.split(':') {
            if let Some(code) = entry.strip_prefix("ex=") {
                return Some(code.to_string());
            }
        }
        return Some("01;32".to_string()); // default green bold
    }
    // Check file extension
    if let Some(dot_pos) = name.rfind('.') {
        let ext = &name[dot_pos..]; // includes the dot
        for entry in ls_colors.split(':') {
            if let Some((pattern, code)) = entry.split_once('=') {
                if pattern.starts_with('*') && &pattern[1..] == ext {
                    return Some(code.to_string());
                }
            }
        }
    }
    None
}

/// Display completion matches in columnar format, then redraw prompt.
fn display_completion_matches<W: Write>(
    out: &mut W,
    matches: &[String],
    prompt: &str,
    current: &[char],
    cursor: usize,
) {
    let settings = get_readline_settings();
    let use_colors = settings.colored_stats;
    // SAFETY: `std::mem::zeroed()` is valid for `libc::winsize` (a plain C struct
    // of unsigned shorts).  `ioctl(1, TIOCGWINSZ, &mut ws)` fills `ws` in place;
    // it returns -1 on error (e.g. fd 1 is not a terminal) which we handle by
    // falling back to the 80-column default.
    let cols: usize = unsafe {
        let mut ws: libc::winsize = std::mem::zeroed();
        if libc::ioctl(1, libc::TIOCGWINSZ, &mut ws) == 0 && ws.ws_col > 0 {
            ws.ws_col as usize
        } else {
            80
        }
    };
    // SAFETY: same as for `cols` above.
    let rows: usize = unsafe {
        let mut ws: libc::winsize = std::mem::zeroed();
        if libc::ioctl(1, libc::TIOCGWINSZ, &mut ws) == 0 && ws.ws_row > 0 {
            ws.ws_row as usize
        } else {
            24
        }
    };

    // Ask before displaying if more than completion-query-items
    if matches.len() > settings.completion_query_items {
        let _ = write!(out, "\r\nDisplay all {} possibilities? (y or n) ", matches.len());
        let _ = out.flush();
        // Read a single byte
        let mut buf = [0u8; 1];
        let _ = io::stdin().read_exact(&mut buf);
        let _ = write!(out, "\r\n");
        if buf[0] != b'y' && buf[0] != b'Y' {
            let _ = redraw_editor_line(out, prompt, current, cursor);
            return;
        }
    } else {
        let _ = write!(out, "\r\n");
    }

    let max_len = matches.iter().map(|m| m.len()).max().unwrap_or(0) + 2;
    let ncols = std::cmp::max(1, cols / std::cmp::max(max_len, 1));

    // Helper closure to write one match entry with optional color
    let write_entry = |out: &mut W, m: &str, width: usize| {
        if use_colors {
            if let Some(code) = ls_color_for_entry(m) {
                let _ = write!(out, "\x1b[{}m{}\x1b[0m", code, m);
                // Pad remaining space
                let pad = width.saturating_sub(m.len());
                for _ in 0..pad { let _ = write!(out, " "); }
                return;
            }
        }
        let _ = write!(out, "{:<width$}", m, width = width);
    };

    if settings.print_completions_horizontally {
        // Horizontal: fill rows left-to-right
        let mut displayed = 0usize;
        for (i, m) in matches.iter().enumerate() {
            write_entry(out, m, max_len);
            if (i + 1) % ncols == 0 || i + 1 == matches.len() {
                let _ = write!(out, "\r\n");
                displayed += 1;
                if settings.page_completions && displayed >= rows - 1 {
                    let _ = write!(out, "--More--");
                    let _ = out.flush();
                    let mut buf = [0u8; 1];
                    let _ = io::stdin().read_exact(&mut buf);
                    let _ = write!(out, "\r        \r");
                    if buf[0] == b'q' || buf[0] == b'Q' {
                        break;
                    }
                    displayed = 0;
                }
            }
        }
    } else {
        // Vertical (default): fill columns top-to-bottom
        let nrows = (matches.len() + ncols - 1) / ncols;
        let mut displayed = 0usize;
        for r in 0..nrows {
            for c in 0..ncols {
                let idx = c * nrows + r;
                if idx < matches.len() {
                    write_entry(out, &matches[idx], max_len);
                }
            }
            let _ = write!(out, "\r\n");
            displayed += 1;
            if settings.page_completions && displayed >= rows - 1 && r + 1 < nrows {
                let _ = write!(out, "--More--");
                let _ = out.flush();
                let mut buf = [0u8; 1];
                let _ = io::stdin().read_exact(&mut buf);
                let _ = write!(out, "\r        \r");
                if buf[0] == b'q' || buf[0] == b'Q' {
                    break;
                }
                displayed = 0;
            }
        }
    }
    let _ = redraw_editor_line(out, prompt, current, cursor);
}

/// Check MAIL/MAILPATH for new mail and print notification.
/// MAILPATH format: /path/to/file?message : separated
/// MAIL is a single file path (only checked if MAILPATH is not set).
fn check_mail<W: Write>(shell: &exec::Shell, out: &mut W) {
    use std::collections::HashMap;
    // Static-like state: store last-known sizes per file in a thread-local
    // since we can't easily add more mutable state to the call site.
    thread_local! {
        static MAIL_SIZES: std::cell::RefCell<HashMap<String, u64>> = std::cell::RefCell::new(HashMap::new());
    }

    let paths: Vec<(String, String)> = if let Some(mailpath) = shell.get_var("MAILPATH") {
        mailpath.split(':').map(|entry| {
            if let Some(qpos) = entry.find('?') {
                (entry[..qpos].to_string(), entry[qpos + 1..].to_string())
            } else {
                (entry.to_string(), "you have mail".to_string())
            }
        }).collect()
    } else if let Some(mail) = shell.get_var("MAIL") {
        vec![(mail, "you have mail in $_".to_string())]
    } else {
        return;
    };

    MAIL_SIZES.with(|sizes| {
        let mut sizes = sizes.borrow_mut();
        for (path, msg) in &paths {
            let meta = match fs::metadata(path) {
                Ok(m) => m,
                Err(_) => continue,
            };
            let current_size = meta.len();
            let prev_size = sizes.get(path).copied().unwrap_or(0);
            if current_size > prev_size && prev_size > 0 {
                // New mail arrived
                let display_msg = msg.replace("$_", path);
                let _ = write!(out, "\r\n{}\r\n", display_msg);
            }
            sizes.insert(path.clone(), current_size);
        }
    });
}

fn main() {
    let mut shell = exec::Shell::new();
    let args: Vec<String> = env::args_os()
        .map(|arg| argv_string(arg.as_os_str()))
        .collect();
    // In BRASH_TEST_MODE, keep the real argv[0] for shell variables like $0,
    // but still use the test-mode shell_name() for user-facing banners.
    let raw_argv0 = args.first().map(|s| s.as_str()).unwrap_or("brash");
    let argv0: &str = if is_test_mode() {
        exec::shell_name()
    } else {
        raw_argv0
    };

    // When invoked as "sh" (basename of argv[0] is "sh"), bash automatically
    // enables POSIX mode.  Mirror that behaviour here.
    {
        let base = std::path::Path::new(raw_argv0.trim_start_matches('-'))
            .file_name()
            .and_then(|s| s.to_str())
            .unwrap_or(raw_argv0);
        if base == "sh" {
            shell.posix_mode = true;
            shell.vars.posix_mode = true;
        }
    }

    init_shell_vars(&mut shell, raw_argv0);

    // Inherit environment
    for (k, v) in env::vars() {
        if exec::is_valid_identifier_pub(&k) {
            shell.export_var(&k, &v);
        } else {
            shell.inherited_env.insert(k, v);
        }
    }

    // Import exported functions from BASH_FUNC_name%% environment variables.
    // These are set by `export -f` in a parent shell.
    // Security: only import if the value starts with "() " (valid function body).
    // Strip any code that follows the closing `}` of the function (CVE-2014-6271).
    import_bash_funcs(&mut shell);

    if args.len() > 1 && (args[1] == "--version" || args[1] == "-version") {
        println!("{}", version_string());
        if is_test_mode() {
            println!("Copyright (C) 2025 Free Software Foundation, Inc.");
            println!("License GPLv3+: GNU GPL version 3 or later <http://gnu.org/licenses/gpl.html>");
            println!();
            println!("This is free software; you are free to change and redistribute it.");
            println!("There is NO WARRANTY, to the extent permitted by law.");
        }
        process::exit(0);
    }

    if args.len() > 1 && (args[1] == "--help" || args[1] == "-help") {
        eprintln!("{}", version_string());
        eprintln!("Usage:\t{} [GNU long option] [option] ...", argv0);
        eprintln!("\t{} [GNU long option] [option] script-file ...", argv0);
        process::exit(0);
    }

    let mut idx = 1;
    let mut is_login = raw_argv0.starts_with('-');
    shell.is_login_shell = is_login;
    let mut is_command = false;
    let mut command_string: Option<String> = None;
    let mut stdin_mode = false;
    let mut script_file: Option<String> = None;
    let bash_compat_startup = uses_bash_startup_files(raw_argv0);

    while idx < args.len() {
        match args[idx].as_str() {
            "-l" | "--login" => { is_login = true; shell.is_login_shell = true; }
            "-c" => {
                is_command = true;
                idx += 1;
                if idx >= args.len() {
                    // bash: "bash: -c: option requires an argument"
                    // (just the error line, no usage block)
                    eprintln!("{}: -c: option requires an argument", exec::shell_name());
                    process::exit(2);
                }
                command_string = Some(args[idx].clone());
                idx += 1;
                if idx < args.len() {
                    shell.set_var("0", &args[idx]);
                    // ARG0 explicitly given after the -c command:
                    // bash uses it as the error-message prefix instead
                    // of the literal "-c".
                    shell.script_name = args[idx].clone();
                    idx += 1;
                } else if let Ok(argv0) = std::env::var("BASH_ARGV0") {
                    // BASH_ARGV0 in the env overrides the default $0 for
                    // -c invocations.
                    if !argv0.is_empty() {
                        shell.set_var("0", &argv0);
                        shell.script_name = argv0;
                    }
                }
                // Otherwise the global default at the bottom of init
                // (argv[0] basename, with BRASH_TEST_MODE substitution)
                // applies.
                let mut pos = 1;
                while idx < args.len() {
                    shell.set_var(&format!("{}", pos), &args[idx]);
                    pos += 1;
                    idx += 1;
                }
                shell.vars.positional_count = pos - 1;
                break;
            }
            "-s" => {
                stdin_mode = true;
                idx += 1;
                let mut pos = 1;
                while idx < args.len() {
                    shell.set_var(&format!("{}", pos), &args[idx]);
                    pos += 1;
                    idx += 1;
                }
                shell.vars.positional_count = pos - 1;
                break;
            }
            "-i" => { shell.interactive = true; }
            "--norc" => { shell.norc = true; }
            "--noprofile" => { shell.noprofile = true; }
            "--posix" => {
                shell.posix_mode = true;
                // In POSIX mode, aliases are always expanded (not dependent on
                // interactive shell state). This matches bash's behavior.
                shell.shopt.insert("expand_aliases".to_string());
            }
            // Known long options brash doesn't fully implement but
            // should pass the invocation suite by being recognized
            // (bash accepts them).
            "--debug" | "--debugger"
            | "--dump-po-strings" | "--dump-strings"
            | "--noediting" | "--verbose" | "--restricted" => {
                // Silently accept; no-op for now.
            }
            "--pretty-print" => {
                shell.pretty_print_mode = true;
            }
            "--init-file" | "--rcfile" => {
                // Takes an arg — skip it
                idx += 1;
            }
            "-o" => {
                // -o optname: set shell option
                idx += 1;
                if idx < args.len() {
                    let opt = &args[idx];
                    match opt.as_str() {
                        "posix" => {
                            shell.posix_mode = true;
                            shell.shopt.insert("expand_aliases".to_string());
                        }
                        _ => shell.set_option(opt),
                    }
                }
            }
            "+o" => {
                // +o optname: disable shell option.
                idx += 1;
                if idx < args.len() {
                    let opt = &args[idx];
                    match opt.as_str() {
                        "posix" => {
                            shell.posix_mode = false;
                            shell.shopt.remove("expand_aliases");
                        }
                        _ => shell.unset_option(opt),
                    }
                }
            }
            "-O" => {
                // -O optname: enable shopt option at startup.
                idx += 1;
                if idx < args.len() {
                    let opt = &args[idx];
                    if builtins::SHOPT_OPTIONS.contains(&opt.as_str()) {
                        shell.shopt.insert(opt.clone());
                    } else {
                        eprintln!("{}: line 0: {}: invalid shell option name",
                            exec::shell_name(), opt);
                        process::exit(2);
                    }
                }
            }
            "+O" => {
                // +O optname: disable shopt option at startup.
                idx += 1;
                if idx < args.len() {
                    let opt = &args[idx];
                    if builtins::SHOPT_OPTIONS.contains(&opt.as_str()) {
                        shell.shopt.remove(opt.as_str());
                    } else {
                        eprintln!("{}: line 0: {}: invalid shell option name",
                            exec::shell_name(), opt);
                        process::exit(2);
                    }
                }
            }
            "--" => { break; }
            s if s.starts_with("--") => {
                // Unknown long option — reject like bash.  Known ones
                // are handled above (--norc, --noprofile, --posix).
                eprintln!("{}: {}: invalid option", exec::shell_name(), s);
                print_invocation_usage();
                process::exit(2);
            }
            s if s.starts_with('-') || s.starts_with('+') => {
                let prefix = if s.starts_with('-') { "-" } else { "+" };
                let chars: Vec<char> = s[1..].chars().collect();
                let mut has_c = false;
                for &ch in &chars {
                    if ch == 'c' && prefix == "-" {
                        has_c = true;
                        continue;
                    }
                    // Validate — bash's short-flag alphabet is:
                    // abefhikmnoprstuvxBCEHPT for -/+ forms, plus D, O.
                    // Anything else is "invalid option".
                    if !matches!(ch,
                        'a' | 'b' | 'e' | 'f' | 'h' | 'i' | 'k' | 'l' | 'm'
                      | 'n' | 'o' | 'p' | 'r' | 's' | 't' | 'u' | 'v' | 'x'
                      | 'B' | 'C' | 'D' | 'E' | 'H' | 'O' | 'P' | 'T')
                    {
                        eprintln!("{}: -{}: invalid option",
                            exec::shell_name(), ch);
                        print_invocation_usage();
                        process::exit(2);
                    }
                    let flag = format!("{}{}", prefix, ch);
                    if prefix == "-" {
                        if ch == 'i' {
                            shell.interactive = true;
                        } else if ch == 'l' {
                            is_login = true;
                            shell.is_login_shell = true;
                        }
                        shell.set_option(&flag);
                    } else {
                        shell.unset_option(&flag);
                    }
                }
                if has_c {
                    // Handle -c combined with other flags (e.g., -ce, -xc)
                    is_command = true;
                    idx += 1;
                    if idx < args.len() {
                        command_string = Some(args[idx].clone());
                        idx += 1;
                        if idx < args.len() {
                            shell.set_var("0", &args[idx]);
                            shell.script_name = args[idx].clone();
                            idx += 1;
                        }
                        let mut pos = 1;
                        while idx < args.len() {
                            shell.set_var(&format!("{}", pos), &args[idx]);
                            pos += 1;
                            idx += 1;
                        }
                        shell.vars.positional_count = pos - 1;
                    }
                    break;
                }
            }
            _ => {
                script_file = Some(args[idx].clone());
                shell.script_name = args[idx].clone();
                shell.set_var("0", &args[idx]);
                idx += 1;
                let mut pos = 1;
                while idx < args.len() {
                    shell.set_var(&format!("{}", pos), &args[idx]);
                    pos += 1;
                    idx += 1;
                }
                shell.vars.positional_count = pos - 1;
                break;
            }
        }
        idx += 1;
    }

    // Apply BASHOPTS/SHELLOPTS after command-line flags so an
    // exported SHELLOPTS re-enables options that `+B` / `+o ...`
    // turned off, matching bash.
    inherit_shellopts_env(&mut shell);

    let stdin_is_tty = atty_stdin();
    let interactive_startup = !is_command && script_file.is_none() && !stdin_mode
        && (shell.interactive || stdin_is_tty);
    if interactive_startup {
        prepare_interactive_shell(&mut shell);
    }

    // Source startup files.  The two paths have different gating:
    //
    //   - Login profile sourcing (/etc/profile + ~/.bash_profile etc.) fires
    //     for ANY login invocation, even `--login -c 'cmd'` or
    //     `--login script.sh`, matching bash: "When bash is invoked as an
    //     interactive login shell, or as a non-interactive shell with the
    //     --login option, it first reads and executes commands from
    //     /etc/profile…".
    //
    //   - Interactive rc sourcing (.bashrc) only fires for non-login
    //     interactive shells (the `else if interactive_startup` arm).
    if !shell.norc {
        if is_login && !shell.noprofile {
            // Login shell: source /etc/profile, then profile files.
            // Always pass hide_bash_identity=false: brash is a bash
            // replacement and must present BASH_VERSION to /etc/profile.
            // Many distros (Gentoo, Debian, etc.) gate bash-specific setup
            // (color prompt, bash-completion, /etc/bash/bashrc sourcing) on
            // the presence of $BASH_VERSION.  Hiding it produces a broken,
            // plain-text prompt even when the terminal supports color.
            for f in &["/etc/profile"] {
                source_startup_file(&mut shell, f, false);
            }
            let home = env::var("HOME").unwrap_or_default();
            // Profile-file lookup order:
            //   - In BRASH_TEST_MODE (the bash test suite drives us pretending
            //     we're bash): the bash chain comes FIRST and we never check
            //     .brash_profile, because the test fixtures expect exactly
            //     bash's startup behaviour.
            //   - When invoked under an argv0 of `bash` (gnu-compat-symlinks
            //     route): same chain, no .brash_profile.
            //   - Otherwise (real brash): .brash_profile first; if absent,
            //     fall back to bash's chain so existing bash users get their
            //     env without writing a new file.
            if is_test_mode() || bash_compat_startup {
                for f in &[
                    format!("{}/.bash_profile", home),
                    format!("{}/.bash_login", home),
                    format!("{}/.profile", home),
                ] {
                    if source_startup_file(&mut shell, f, false) {
                        break; // first match wins
                    }
                }
            } else {
                let brash_profile = format!("{}/.brash_profile", home);
                if !source_startup_file(&mut shell, &brash_profile, false) {
                    for f in &[
                        format!("{}/.bash_profile", home),
                        format!("{}/.bash_login", home),
                        format!("{}/.profile", home),
                    ] {
                        if source_startup_file(&mut shell, f, false) {
                            break;
                        }
                    }
                }
            }
        } else if interactive_startup {
            // Interactive non-login rc-file lookup mirrors the profile rule:
            //   - Test mode / argv0 == bash: source .bashrc only (no system rc,
            //     because the bash-suite fixtures don't expect it).
            //   - Real brash: source the system-wide bashrc first (so that
            //     distro-level prompt/color/completion setup runs even when the
            //     shell is not a login shell), then .brashrc / .bashrc.
            //
            // System-wide bashrc paths vary by distro:
            //   Gentoo:       /etc/bash/bashrc   (sources /etc/bash/bashrc.d/*)
            //   Debian/Ubuntu:/etc/bash.bashrc
            //   Fedora/RHEL:  /etc/bashrc
            // We try them in order and source only the first one that exists.
            // (Bash itself uses a compile-time SYS_BASHRC constant; we probe
            // the common paths as the next-best portable approximation.)
            if !is_test_mode() && !bash_compat_startup {
                for sys_rc in &["/etc/bash/bashrc", "/etc/bash.bashrc", "/etc/bashrc"] {
                    if source_startup_file(&mut shell, sys_rc, false) {
                        break;
                    }
                }
            }
            let home = env::var("HOME").unwrap_or_default();
            let bashrc = format!("{}/.bashrc", home);
            if is_test_mode() || bash_compat_startup {
                source_startup_file(&mut shell, &bashrc, false);
            } else {
                let brashrc = format!("{}/.brashrc", home);
                if !source_startup_file(&mut shell, &brashrc, false) {
                    source_startup_file(&mut shell, &bashrc, false);
                }
            }
        }
    }

    if is_command {
        if let Some(cmd) = command_string {
            shell.c_mode = true;
            shell.c_string = Some(cmd.clone());
            shell.run_string(&cmd);
            let status = shell.run_exit_trap();
            if is_login {
                run_bash_logout(&mut shell, bash_compat_startup);
            }
            process::exit(status);
        }
        process::exit(0);
    }

    if let Some(mut path) = script_file {
        // Bash: when the script filename contains no `/`, it's looked
        // up via PATH the same as a command name.  This lets things
        // like `bash ls` → `bash /bin/ls` (which then fails with
        // "cannot execute binary file" for binaries in PATH).
        if !path.contains('/') && !std::path::Path::new(&path).exists() {
            let search = env::var("PATH").unwrap_or_default();
            for dir in search.split(':') {
                if dir.is_empty() { continue; }
                let candidate = format!("{}/{}", dir, path);
                if std::path::Path::new(&candidate).exists() {
                    path = candidate;
                    break;
                }
            }
        }
        match fs::read_to_string(&path) {
            Ok(content) => {
                shell.run_string(&content);
                let status = shell.run_exit_trap();
                process::exit(status);
            }
            Err(e) => {
                // If `read_to_string` failed due to non-UTF-8
                // content, fall back to reading as bytes.  If the
                // raw bytes look binary (NUL in first 512 bytes or
                // ELF/Mach-O magic), match bash's \"cannot execute
                // binary file\" diagnostic and exit 126.
                if matches!(e.kind(), std::io::ErrorKind::InvalidData) {
                    if let Ok(bytes) = fs::read(&path) {
                        let probe_len = bytes.len().min(512);
                        let looks_binary = bytes[..probe_len].contains(&0u8)
                            || bytes.starts_with(b"\x7fELF")
                            || bytes.starts_with(&[0xcf, 0xfa, 0xed, 0xfe])
                            || bytes.starts_with(&[0xfe, 0xed, 0xfa, 0xcf])
                            || bytes.starts_with(&[0xfe, 0xed, 0xfa, 0xce])
                            || bytes.starts_with(&[0xce, 0xfa, 0xed, 0xfe]);
                        if looks_binary {
                            eprintln!("{}: {}: cannot execute binary file", path, path);
                            process::exit(126);
                        }
                        // Not binary — interpret as bytes via
                        // from_utf8_lossy so stray bytes get replaced
                        // but the script still runs.
                        let s = String::from_utf8_lossy(&bytes);
                        shell.run_string(&s);
                        let status = shell.run_exit_trap();
                        process::exit(status);
                    }
                }
                // Bash emits "<argv0>: <path>: <msg>" where <msg>
                // is the short error string (no "(os error N)"
                // suffix).  Convert from std::io::Error wording.
                let msg = match e.raw_os_error() {
                    Some(libc::EISDIR) => "Is a directory".to_string(),
                    Some(libc::ENOENT) => "No such file or directory".to_string(),
                    Some(libc::EACCES) => "Permission denied".to_string(),
                    Some(libc::EIO) => "Input/output error".to_string(),
                    _ => e.kind().to_string(),
                };
                // Bash uses the script PATH as the program name in
                // script-load errors (because $0 is set to the path).
                eprintln!("{}: {}: {}", path, path, msg);
                process::exit(1);
            }
        }
    }

    if stdin_mode || (!shell.interactive && !stdin_is_tty) {
        // Stream stdin line-by-line using unbuffered FD reads so that child
        // processes spawned by the script can consume their own stdin bytes
        // (matches bash behavior for `bash < script`, `sh ./run-input-test`).
        // Accumulate lines until the partial buffer looks like a complete
        // statement; tokenize/execute, then continue.
        let mut buf = String::new();
        loop {
            let mut byte = [0u8; 1];
            // SAFETY: fd 0 (stdin) is open in a running shell; `byte` is a mutable
            // 1-byte stack array; reading exactly 1 byte at a time is always safe.
            let n = unsafe { libc::read(0, byte.as_mut_ptr() as *mut libc::c_void, 1) };
            if n <= 0 {
                // EOF or error: run any remaining buffered text
                if !buf.is_empty() { shell.run_string(&buf); buf.clear(); }
                break;
            }
            buf.push(byte[0] as char);
            if byte[0] == b'\n' {
                if stdin_buffer_is_complete(&buf) {
                    shell.run_string(&buf);
                    buf.clear();
                }
            }
        }
        let status = shell.run_exit_trap();
        process::exit(status);
    }

    // Interactive
    prepare_interactive_shell(&mut shell);
    if let Some(sz) = shell.get_var("HISTSIZE") {
        if let Ok(n) = sz.parse::<usize>() {
            shell.history.max_size = n;
        }
    }
    let startup_histfile = shell.get_var("HISTFILE").filter(|s| !s.is_empty());
    if let Some(path) = startup_histfile.as_deref() {
        shell.remember_history_file(path);
        let _ = shell.history.read_from_file_with_options(path, history_file_options(&shell));
    }
    if !atty_stdin() {
        let stdin = io::stdin();
        let mut stdin = stdin.lock();
        let mut stderr = io::stderr();
        let mut pending = String::new();
        let mut current = String::new();
        let mut nav = InteractiveHistoryState::default();
        let mut queued: Option<u8> = None;
        let mut prompt_shown = false;
        loop {
            if shell.exit_flag || shell.return_flag {
                break;
            }
            if !prompt_shown {
                let prompt_raw = if pending.is_empty() {
                    shell.get_var("PS1").unwrap_or_else(|| "\\$ ".to_string())
                } else {
                    shell.get_var("PS2").unwrap_or_else(|| "> ".to_string())
                };
                let _ = write!(stderr, "{}", shell.expand_prompt(&prompt_raw));
                let _ = stderr.flush();
                prompt_shown = true;
            }
            let byte = if let Some(b) = queued.take() {
                b
            } else {
                let mut buf = [0u8; 1];
                match stdin.read(&mut buf) {
                    Ok(0) | Err(_) => {
                        if !current.is_empty() || !pending.is_empty() {
                            submit_interactive_line(&mut shell, &mut pending, &mut current);
                        }
                        let _ = writeln!(stderr, "exit");
                        break;
                    }
                    Ok(_) => buf[0],
                }
            };
            match byte {
                b'\n' => {
                    let _ = writeln!(stderr);
                    submit_interactive_line(&mut shell, &mut pending, &mut current);
                    nav.clear();
                    prompt_shown = false;
                }
                0x10 => {
                    if let Some(entry) = nav.previous(&shell, &current) {
                        current = entry;
                    }
                }
                0x0e => {
                    if let Some(entry) = nav.next(&shell, &current) {
                        current = entry;
                    }
                }
                0x12 => {
                    let mut needle = String::new();
                    loop {
                        let mut buf = [0u8; 1];
                        match stdin.read(&mut buf) {
                            Ok(0) | Err(_) => break,
                            Ok(_) if buf[0] < 0x20 || buf[0] == 0x7f => {
                                queued = Some(buf[0]);
                                break;
                            }
                            Ok(_) => needle.push(buf[0] as char),
                        }
                    }
                    if let Some(entry) = nav.search(&shell, &needle) {
                        current = entry;
                    }
                }
                0x0f => {
                    if !current.is_empty() || !pending.is_empty() {
                        submit_interactive_line(&mut shell, &mut pending, &mut current);
                    }
                    current = nav.next_after_operate().unwrap_or_default();
                }
                b'\r' => {}
                byte => {
                    nav.clear();
                    current.push(byte as char);
                    let _ = write!(stderr, "{}", byte as char);
                    let _ = stderr.flush();
                }
            }
        }
        save_history_file(&mut shell);
        let status = shell.run_exit_trap();
        process::exit(status);
    }
    let stdin = io::stdin();
    let mut stdout = io::stdout();
    if let Ok(_tty_guard) = TtyEditorGuard::install(libc::STDIN_FILENO) {
        // Sync editing mode from inputrc to shell options
        {
            let settings = get_readline_settings();
            if settings.editing_mode == EditingMode::Vi {
                shell.opts.vi = true;
                shell.opts.emacs = false;
            }
        }

        let mut pending = String::new();
        let mut current: Vec<char> = Vec::new();
        let mut cursor = 0usize;
        let mut nav = InteractiveHistoryState::default();
        let mut prompt_shown = false;
        let mut prompt = String::new();
        let mut kill_ring: Vec<String> = Vec::new();
        let mut kill_ring_yank_idx: usize = 0;
        let mut last_yank_start: usize = 0;
        let mut last_yank_len: usize = 0;
        let mut last_was_kill = false;
        let mut last_was_yank = false;
        let mut undo_stack: Vec<(Vec<char>, usize)> = Vec::new();
        let mut eof_count: u32 = 0;
        let mut vi_mode_cmd = false; // true = vi command mode, false = insert mode
        // Menu-complete state
        let mut menu_matches: Vec<String> = Vec::new();
        let mut menu_idx: usize = 0;
        let mut menu_word_start: usize = 0;
        let mut _menu_original_word: String = String::new();
        let mut last_was_menu_complete = false;
        let mut last_was_tab = false;
        // Keyboard macro recording
        let mut macro_recording = false;
        let mut macro_buffer: Vec<u8> = Vec::new();
        let mut macro_playback: Vec<u8> = Vec::new();
        // MAIL check state
        let mut last_mail_check: std::time::Instant = std::time::Instant::now();
        loop {
            if shell.exit_flag || shell.return_flag {
                break;
            }

            if !prompt_shown {
                if pending.is_empty() {
                    // MAIL/MAILPATH check before prompt
                    let mailcheck: u64 = shell.get_var("MAILCHECK")
                        .and_then(|v| v.parse().ok())
                        .unwrap_or(60);
                    if mailcheck > 0 && last_mail_check.elapsed().as_secs() >= mailcheck {
                        last_mail_check = std::time::Instant::now();
                        check_mail(&shell, &mut stdout);
                    }

                    if let Some(prompt_command) = shell.get_var("PROMPT_COMMAND") {
                        if !prompt_command.is_empty() {
                            shell.run_string(&prompt_command);
                            if shell.exit_flag || shell.return_flag {
                                break;
                            }
                        }
                    }
                }

                let prompt_raw = if pending.is_empty() {
                    shell.get_var("PS1").unwrap_or_else(|| "\\$ ".to_string())
                } else {
                    shell.get_var("PS2").unwrap_or_else(|| "> ".to_string())
                };
                prompt = shell.expand_prompt(&prompt_raw);
                let _ = write!(stdout, "{}", prompt);
                let _ = stdout.flush();
                prompt_shown = true;
            }

            let tmout: i32 = shell.get_var("TMOUT")
                .and_then(|v| v.parse::<i32>().ok())
                .unwrap_or(0);
            let read_result = if tmout > 0 {
                read_stdin_byte_timeout(tmout * 1000)
            } else {
                read_stdin_byte()
            };
            let byte = match read_result {
                Ok(Some(byte)) => byte,
                Ok(None) => {
                    if tmout > 0 {
                        // TMOUT expired
                        let _ = write!(stdout, "\r\n{}: timed out waiting for input\r\n",
                            exec::shell_name());
                        let _ = stdout.flush();
                        break;
                    }
                    if !current.is_empty() || !pending.is_empty() {
                        let _ = write!(stdout, "\r\n");
                        let _ = stdout.flush();
                        let mut line: String = current.iter().collect();
                        submit_interactive_line(&mut shell, &mut pending, &mut line);
                        current.clear();
                    } else {
                        let _ = writeln!(stdout, "exit");
                    }
                    break;
                }
                Err(err) if err.kind() == io::ErrorKind::Interrupted => {
                    let sig = EDITOR_SIGNAL.swap(0, Ordering::Relaxed);
                    if sig == libc::SIGWINCH {
                        let _ = redraw_editor_line(&mut stdout, &prompt, &current, cursor);
                    } else if sig == libc::SIGINT || sig == libc::SIGQUIT {
                        let trap_name = if sig == libc::SIGINT { "INT" } else { "QUIT" };
                        if shell.traps.get(trap_name).is_some() {
                            shell.check_pending_signals();
                            if shell.exit_flag || shell.return_flag {
                                break;
                            }
                        } else if sig == libc::SIGINT {
                            shell.last_status = 128 + libc::SIGINT;
                        }
                        let _ = write!(stdout, "\r\n");
                        let _ = stdout.flush();
                        pending.clear();
                        current.clear();
                        cursor = 0;
                        nav.clear();
                        prompt_shown = false;
                    }
                    continue;
                }
                Err(_) => break,
            };

            let pre_state = (current.clone(), cursor);
            let mut needs_redraw = false;

            // Vi command mode handling
            if shell.opts.vi && vi_mode_cmd && byte != b'\n' && byte != b'\r' {
                match byte {
                    b'i' => { vi_mode_cmd = false; }
                    b'I' => { cursor = 0; vi_mode_cmd = false; needs_redraw = true; }
                    b'a' => {
                        if cursor < current.len() { cursor += 1; }
                        vi_mode_cmd = false;
                        needs_redraw = true;
                    }
                    b'A' => { cursor = current.len(); vi_mode_cmd = false; needs_redraw = true; }
                    b'h' => {
                        if cursor > 0 { cursor -= 1; needs_redraw = true; }
                    }
                    b'l' => {
                        if cursor < current.len().saturating_sub(1) { cursor += 1; needs_redraw = true; }
                    }
                    b'0' => { cursor = 0; needs_redraw = true; }
                    b'$' => { cursor = current.len().saturating_sub(1); needs_redraw = true; }
                    b'^' => {
                        cursor = current.iter().position(|c| !c.is_whitespace()).unwrap_or(0);
                        needs_redraw = true;
                    }
                    b'w' => {
                        // Forward word
                        while cursor < current.len() && current[cursor].is_alphanumeric() {
                            cursor += 1;
                        }
                        while cursor < current.len() && !current[cursor].is_alphanumeric() {
                            cursor += 1;
                        }
                        needs_redraw = true;
                    }
                    b'b' => {
                        // Backward word
                        if cursor > 0 { cursor -= 1; }
                        while cursor > 0 && !current[cursor].is_alphanumeric() {
                            cursor -= 1;
                        }
                        while cursor > 0 && current[cursor - 1].is_alphanumeric() {
                            cursor -= 1;
                        }
                        needs_redraw = true;
                    }
                    b'e' => {
                        // End of word
                        if cursor < current.len().saturating_sub(1) { cursor += 1; }
                        while cursor < current.len().saturating_sub(1) && !current[cursor].is_alphanumeric() {
                            cursor += 1;
                        }
                        while cursor < current.len().saturating_sub(1) && current[cursor + 1].is_alphanumeric() {
                            cursor += 1;
                        }
                        needs_redraw = true;
                    }
                    b'x' => {
                        // Delete char at cursor
                        if cursor < current.len() {
                            current.remove(cursor);
                            if cursor >= current.len() && cursor > 0 { cursor -= 1; }
                            nav.clear();
                            needs_redraw = true;
                        }
                    }
                    b'X' => {
                        // Delete char before cursor
                        if cursor > 0 {
                            cursor -= 1;
                            current.remove(cursor);
                            nav.clear();
                            needs_redraw = true;
                        }
                    }
                    b'r' => {
                        // Replace single char
                        if cursor < current.len() {
                            if let Ok(Some(repl)) = read_stdin_byte() {
                                current[cursor] = repl as char;
                                nav.clear();
                                needs_redraw = true;
                            }
                        }
                    }
                    b'd' => {
                        // d + motion: delete
                        if let Ok(Some(motion)) = read_stdin_byte() {
                            match motion {
                                b'd' => {
                                    // dd: clear line
                                    let killed: String = current.iter().collect();
                                    kill_ring.push(killed);
                                    current.clear();
                                    cursor = 0;
                                    nav.clear();
                                    needs_redraw = true;
                                }
                                b'w' => {
                                    let start = cursor;
                                    let mut end = cursor;
                                    while end < current.len() && current[end].is_alphanumeric() { end += 1; }
                                    while end < current.len() && !current[end].is_alphanumeric() { end += 1; }
                                    let killed: String = current[start..end].iter().collect();
                                    kill_ring.push(killed);
                                    current.drain(start..end);
                                    nav.clear();
                                    needs_redraw = true;
                                }
                                b'$' => {
                                    let killed: String = current[cursor..].iter().collect();
                                    kill_ring.push(killed);
                                    current.truncate(cursor);
                                    if cursor > 0 { cursor -= 1; }
                                    nav.clear();
                                    needs_redraw = true;
                                }
                                b'0' => {
                                    let killed: String = current[..cursor].iter().collect();
                                    kill_ring.push(killed);
                                    current.drain(..cursor);
                                    cursor = 0;
                                    nav.clear();
                                    needs_redraw = true;
                                }
                                _ => {}
                            }
                        }
                    }
                    b'D' => {
                        // Delete to end of line
                        if cursor < current.len() {
                            let killed: String = current[cursor..].iter().collect();
                            kill_ring.push(killed);
                            current.truncate(cursor);
                            if cursor > 0 { cursor -= 1; }
                            nav.clear();
                            needs_redraw = true;
                        }
                    }
                    b'C' => {
                        // Change to end of line
                        if cursor < current.len() {
                            let killed: String = current[cursor..].iter().collect();
                            kill_ring.push(killed);
                            current.truncate(cursor);
                            nav.clear();
                            needs_redraw = true;
                        }
                        vi_mode_cmd = false;
                    }
                    b'c' => {
                        // c + motion: change
                        if let Ok(Some(motion)) = read_stdin_byte() {
                            match motion {
                                b'c' => {
                                    let killed: String = current.iter().collect();
                                    kill_ring.push(killed);
                                    current.clear();
                                    cursor = 0;
                                    nav.clear();
                                    needs_redraw = true;
                                }
                                b'w' => {
                                    let start = cursor;
                                    let mut end = cursor;
                                    while end < current.len() && current[end].is_alphanumeric() { end += 1; }
                                    while end < current.len() && !current[end].is_alphanumeric() { end += 1; }
                                    let killed: String = current[start..end].iter().collect();
                                    kill_ring.push(killed);
                                    current.drain(start..end);
                                    nav.clear();
                                    needs_redraw = true;
                                }
                                _ => {}
                            }
                        }
                        vi_mode_cmd = false;
                    }
                    b'p' => {
                        // Paste after cursor
                        if !kill_ring.is_empty() {
                            // PROVEN: kill_ring is non-empty (checked above).
                            let text: Vec<char> = kill_ring.last().unwrap().chars().collect();
                            let pos = if current.is_empty() { 0 } else { cursor + 1 };
                            let count = text.len();
                            current.splice(pos..pos, text);
                            cursor = pos + count - 1;
                            nav.clear();
                            needs_redraw = true;
                        }
                    }
                    b'P' => {
                        // Paste before cursor
                        if !kill_ring.is_empty() {
                            // PROVEN: kill_ring is non-empty (checked above).
                            let text: Vec<char> = kill_ring.last().unwrap().chars().collect();
                            let count = text.len();
                            current.splice(cursor..cursor, text);
                            cursor += count - 1;
                            nav.clear();
                            needs_redraw = true;
                        }
                    }
                    b'u' => {
                        // Undo
                        if let Some((prev_chars, prev_cursor)) = undo_stack.pop() {
                            current = prev_chars;
                            cursor = prev_cursor;
                            needs_redraw = true;
                        }
                    }
                    b'k' => {
                        // Previous history
                        let current_line: String = current.iter().collect();
                        if let Some(entry) = nav.previous(&shell, &current_line) {
                            current = entry.chars().collect();
                            cursor = 0;
                            needs_redraw = true;
                        }
                    }
                    b'j' => {
                        // Next history
                        let current_line: String = current.iter().collect();
                        if let Some(entry) = nav.next(&shell, &current_line) {
                            current = entry.chars().collect();
                            cursor = 0;
                            needs_redraw = true;
                        }
                    }
                    b'/' => {
                        // Search history forward (simplified)
                        let mut needle = String::new();
                        let _ = write!(stdout, "/");
                        let _ = stdout.flush();
                        loop {
                            match read_stdin_byte() {
                                Ok(Some(b'\r')) | Ok(Some(b'\n')) => break,
                                Ok(Some(0x1b)) => { needle.clear(); break; }
                                Ok(Some(0x7f)) | Ok(Some(0x08)) => { needle.pop(); }
                                Ok(Some(b)) if b >= 0x20 => {
                                    needle.push(b as char);
                                    let _ = write!(stdout, "{}", b as char);
                                    let _ = stdout.flush();
                                }
                                _ => break,
                            }
                        }
                        if !needle.is_empty() {
                            if let Some(entry) = nav.search(&shell, &needle) {
                                current = entry.chars().collect();
                                cursor = 0;
                            }
                        }
                        needs_redraw = true;
                    }
                    b'f' => {
                        // Find char forward
                        if let Ok(Some(target)) = read_stdin_byte() {
                            let ch = target as char;
                            if let Some(pos) = current[cursor + 1..].iter().position(|&c| c == ch) {
                                cursor += 1 + pos;
                                needs_redraw = true;
                            }
                        }
                    }
                    b'~' => {
                        // Toggle case at cursor
                        if cursor < current.len() {
                            let ch = current[cursor];
                            current[cursor] = if ch.is_uppercase() {
                                ch.to_lowercase().next().unwrap_or(ch)
                            } else {
                                ch.to_uppercase().next().unwrap_or(ch)
                            };
                            if cursor < current.len().saturating_sub(1) { cursor += 1; }
                            nav.clear();
                            needs_redraw = true;
                        }
                    }
                    0x1b => {
                        // ESC in command mode: handle arrow keys for CSI
                        if let Ok(Some(b'[')) = read_stdin_byte_timeout(25) {
                            match read_stdin_byte_timeout(25) {
                                Ok(Some(b'A')) => {
                                    let current_line: String = current.iter().collect();
                                    if let Some(entry) = nav.previous(&shell, &current_line) {
                                        current = entry.chars().collect();
                                        cursor = 0;
                                        needs_redraw = true;
                                    }
                                }
                                Ok(Some(b'B')) => {
                                    let current_line: String = current.iter().collect();
                                    if let Some(entry) = nav.next(&shell, &current_line) {
                                        current = entry.chars().collect();
                                        cursor = 0;
                                        needs_redraw = true;
                                    }
                                }
                                Ok(Some(b'C')) => {
                                    if cursor < current.len().saturating_sub(1) { cursor += 1; needs_redraw = true; }
                                }
                                Ok(Some(b'D')) => {
                                    if cursor > 0 { cursor -= 1; needs_redraw = true; }
                                }
                                _ => {}
                            }
                        }
                    }
                    _ => {}
                }
                // Save undo state for vi commands
                if needs_redraw && byte != b'u' {
                    undo_stack.push(pre_state);
                    if undo_stack.len() > 100 { undo_stack.remove(0); }
                }
                if needs_redraw {
                    let _ = redraw_editor_line(&mut stdout, &prompt, &current, cursor);
                }
                continue;
            }

            // In vi insert mode, ESC enters command mode
            if shell.opts.vi && byte == 0x1b {
                // Check if it's a real ESC (not start of CSI) by peeking
                if let Ok(Some(next)) = read_stdin_byte_timeout(25) {
                    if next == b'[' {
                        // It's a CSI sequence — handle as normal (arrow keys etc.)
                        // Fall through to the CSI handler below by re-injecting
                        // Actually, simpler: just enter command mode for bare ESC
                        // For CSI, handle arrow keys in vi insert mode normally
                        let mut params = String::new();
                        loop {
                            match read_stdin_byte_timeout(25) {
                                Ok(Some(b)) if (0x30..=0x3f).contains(&b) => params.push(b as char),
                                Ok(Some(b'A')) => {
                                    let current_line: String = current.iter().collect();
                                    if let Some(entry) = nav.previous(&shell, &current_line) {
                                        current = entry.chars().collect();
                                        cursor = current.len();
                                        needs_redraw = true;
                                    }
                                    break;
                                }
                                Ok(Some(b'B')) => {
                                    let current_line: String = current.iter().collect();
                                    if let Some(entry) = nav.next(&shell, &current_line) {
                                        current = entry.chars().collect();
                                        cursor = current.len();
                                        needs_redraw = true;
                                    }
                                    break;
                                }
                                Ok(Some(b'C')) => { if cursor < current.len() { cursor += 1; needs_redraw = true; } break; }
                                Ok(Some(b'D')) => { if cursor > 0 { cursor -= 1; needs_redraw = true; } break; }
                                Ok(Some(b'~')) => {
                                    match params.as_str() {
                                        "3" => { if cursor < current.len() { current.remove(cursor); nav.clear(); needs_redraw = true; } }
                                        _ => {}
                                    }
                                    break;
                                }
                                _ => break,
                            }
                        }
                        if needs_redraw {
                            let _ = redraw_editor_line(&mut stdout, &prompt, &current, cursor);
                        }
                        continue;
                    }
                    // Not a CSI — it was bare ESC. Enter command mode.
                }
                vi_mode_cmd = true;
                if cursor > 0 { cursor -= 1; } // vi convention: cursor backs up on ESC
                let _ = redraw_editor_line(&mut stdout, &prompt, &current, cursor);
                continue;
            }

            match byte {
                b'\n' | b'\r' => {
                    let _ = write!(stdout, "\r\n");
                    let _ = stdout.flush();
                    let mut line: String = current.iter().collect();
                    submit_interactive_line(&mut shell, &mut pending, &mut line);
                    current.clear();
                    cursor = 0;
                    nav.clear();
                    undo_stack.clear();
                    vi_mode_cmd = false;
                    prompt_shown = false;
                }
                0x01 => {
                    // Ctrl-A: beginning of line
                    cursor = 0;
                    needs_redraw = true;
                }
                0x02 => {
                    // Ctrl-B: backward char
                    if cursor > 0 {
                        cursor -= 1;
                        needs_redraw = true;
                    }
                }
                0x04 => {
                    // Ctrl-D: delete char or EOF
                    if current.is_empty() && pending.is_empty() {
                        if shell.opts.ignoreeof {
                            let max_eof: u32 = shell.get_var("IGNOREEOF")
                                .and_then(|v| v.parse().ok())
                                .unwrap_or(10);
                            eof_count += 1;
                            if eof_count >= max_eof {
                                let _ = writeln!(stdout, "exit");
                                break;
                            } else {
                                let _ = writeln!(stdout,
                                    "Use \"exit\" to leave the shell.");
                                let _ = stdout.flush();
                                prompt_shown = false;
                            }
                        } else {
                            let _ = writeln!(stdout, "exit");
                            break;
                        }
                    } else if cursor < current.len() {
                        current.remove(cursor);
                        nav.clear();
                        needs_redraw = true;
                    }
                }
                0x05 => {
                    // Ctrl-E: end of line
                    cursor = current.len();
                    needs_redraw = true;
                }
                0x06 => {
                    // Ctrl-F: forward char
                    if cursor < current.len() {
                        cursor += 1;
                        needs_redraw = true;
                    }
                }
                0x08 | 0x7f => {
                    // Backspace
                    if cursor > 0 {
                        cursor -= 1;
                        current.remove(cursor);
                        nav.clear();
                        needs_redraw = true;
                    }
                }
                0x09 => {
                    // Tab completion
                    let (insert, matches) = perform_tab_completion(&mut shell, &current, cursor);
                    if !insert.is_empty() {
                        let chars: Vec<char> = insert.chars().collect();
                        let count = chars.len();
                        current.splice(cursor..cursor, chars);
                        cursor += count;
                        needs_redraw = true;
                        // If show-all-if-ambiguous and there are still multiple
                        // matches after inserting common prefix, show them now
                        if !matches.is_empty() {
                            let settings = get_readline_settings();
                            if settings.show_all_if_ambiguous {
                                display_completion_matches(&mut stdout, &matches, &prompt, &current, cursor);
                            }
                        }
                    } else if !matches.is_empty() {
                        let settings = get_readline_settings();
                        if settings.show_all_if_unmodified || last_was_tab {
                            display_completion_matches(&mut stdout, &matches, &prompt, &current, cursor);
                        } else {
                            ring_bell(&mut stdout);
                        }
                    } else {
                        ring_bell(&mut stdout);
                    }
                }
                0x0b => {
                    // Ctrl-K: kill to end of line
                    if cursor < current.len() {
                        let killed: String = current[cursor..].iter().collect();
                        if last_was_kill && !kill_ring.is_empty() {
                            // PROVEN: kill_ring is non-empty (checked above).
                            let last = kill_ring.last_mut().unwrap();
                            last.push_str(&killed);
                        } else {
                            kill_ring.push(killed);
                        }
                        current.truncate(cursor);
                        nav.clear();
                        needs_redraw = true;
                    }
                }
                0x0c => {
                    // Ctrl-L: clear screen
                    let _ = write!(stdout, "\x1b[2J\x1b[H");
                    needs_redraw = true;
                }
                0x0e => {
                    // Ctrl-N: next history
                    let current_line: String = current.iter().collect();
                    if let Some(entry) = nav.next(&shell, &current_line) {
                        current = entry.chars().collect();
                        if !get_readline_settings().history_preserve_point {
                            cursor = current.len();
                        } else {
                            cursor = cursor.min(current.len());
                        }
                        needs_redraw = true;
                    }
                }
                0x0f => {
                    // Ctrl-O: operate and get next
                    if !current.is_empty() || !pending.is_empty() {
                        let _ = write!(stdout, "\r\n");
                        let _ = stdout.flush();
                        let mut line: String = current.iter().collect();
                        submit_interactive_line(&mut shell, &mut pending, &mut line);
                    }
                    let next = nav.next_after_operate().unwrap_or_default();
                    current = next.chars().collect();
                    cursor = current.len();
                    prompt_shown = false;
                }
                0x10 => {
                    // Ctrl-P: previous history
                    let current_line: String = current.iter().collect();
                    if let Some(entry) = nav.previous(&shell, &current_line) {
                        current = entry.chars().collect();
                        if !get_readline_settings().history_preserve_point {
                            cursor = current.len();
                        } else {
                            cursor = cursor.min(current.len());
                        }
                        needs_redraw = true;
                    }
                }
                0x12 => {
                    // Ctrl-R: reverse incremental search
                    let mut needle = String::new();
                    let _ = write!(stdout, "\r\n(reverse-i-search)`': ");
                    let _ = stdout.flush();
                    loop {
                        match read_stdin_byte() {
                            Ok(Some(0x12)) => {
                                // Another Ctrl-R: search further back
                                if let Some(entry) = nav.search(&shell, &needle) {
                                    let _ = write!(stdout, "\r\x1b[K(reverse-i-search)`{}': {}", needle, entry);
                                    let _ = stdout.flush();
                                    current = entry.chars().collect();
                                    cursor = current.len();
                                }
                            }
                            Ok(Some(next)) if next < 0x20 || next == 0x7f => break,
                            Ok(Some(next)) => {
                                match decode_editor_input(next) {
                                    Ok(chars) => {
                                        for ch in chars {
                                            needle.push(ch);
                                        }
                                        if let Some(entry) = nav.search(&shell, &needle) {
                                            let _ = write!(stdout, "\r\x1b[K(reverse-i-search)`{}': {}", needle, entry);
                                            let _ = stdout.flush();
                                            current = entry.chars().collect();
                                            cursor = current.len();
                                        }
                                    }
                                    Err(_) => break,
                                }
                            }
                            Ok(None) | Err(_) => break,
                        }
                    }
                    needs_redraw = true;
                }
                0x13 => {
                    // Ctrl-S: forward incremental search
                    let mut needle = String::new();
                    let _ = write!(stdout, "\r\n(i-search)`': ");
                    let _ = stdout.flush();
                    loop {
                        match read_stdin_byte() {
                            Ok(Some(0x13)) => {
                                if let Some(entry) = nav.forward_search(&shell, &needle) {
                                    let _ = write!(stdout, "\r\x1b[K(i-search)`{}': {}", needle, entry);
                                    let _ = stdout.flush();
                                    current = entry.chars().collect();
                                    cursor = current.len();
                                }
                            }
                            Ok(Some(next)) if next < 0x20 || next == 0x7f => break,
                            Ok(Some(next)) => {
                                match decode_editor_input(next) {
                                    Ok(chars) => {
                                        for ch in chars {
                                            needle.push(ch);
                                        }
                                        if let Some(entry) = nav.forward_search(&shell, &needle) {
                                            let _ = write!(stdout, "\r\x1b[K(i-search)`{}': {}", needle, entry);
                                            let _ = stdout.flush();
                                            current = entry.chars().collect();
                                            cursor = current.len();
                                        }
                                    }
                                    Err(_) => break,
                                }
                            }
                            Ok(None) | Err(_) => break,
                        }
                    }
                    needs_redraw = true;
                }
                0x14 => {
                    // Ctrl-T: transpose characters
                    if current.len() >= 2 {
                        let pos = if cursor == 0 {
                            1
                        } else if cursor >= current.len() {
                            current.len() - 1
                        } else {
                            cursor
                        };
                        current.swap(pos - 1, pos);
                        cursor = if pos + 1 > current.len() { current.len() } else { pos + 1 };
                        nav.clear();
                        needs_redraw = true;
                    }
                }
                0x15 => {
                    // Ctrl-U: kill to beginning of line
                    if cursor > 0 {
                        let killed: String = current[..cursor].iter().collect();
                        if last_was_kill && !kill_ring.is_empty() {
                            // PROVEN: kill_ring is non-empty (checked above).
                            let last = kill_ring.last_mut().unwrap();
                            *last = format!("{}{}", killed, last);
                        } else {
                            kill_ring.push(killed);
                        }
                        current.drain(..cursor);
                        cursor = 0;
                        nav.clear();
                        needs_redraw = true;
                    }
                }
                0x16 => {
                    // Ctrl-V: quoted-insert (next char inserted literally)
                    if let Ok(Some(next_byte)) = read_stdin_byte() {
                        let ch = next_byte as char;
                        current.insert(cursor, ch);
                        cursor += 1;
                        nav.clear();
                        needs_redraw = true;
                    }
                }
                0x17 => {
                    // Ctrl-W: unix word rubout (kill backward to whitespace)
                    if cursor > 0 {
                        let end = cursor;
                        let mut start = cursor;
                        // Skip trailing whitespace
                        while start > 0 && current[start - 1] == ' ' {
                            start -= 1;
                        }
                        // Skip word characters
                        while start > 0 && current[start - 1] != ' ' {
                            start -= 1;
                        }
                        let killed: String = current[start..end].iter().collect();
                        if last_was_kill && !kill_ring.is_empty() {
                            let last = kill_ring.last_mut().unwrap();
                            *last = format!("{}{}", killed, last);
                        } else {
                            kill_ring.push(killed);
                        }
                        current.drain(start..end);
                        cursor = start;
                        nav.clear();
                        needs_redraw = true;
                    }
                }
                0x19 => {
                    // Ctrl-Y: yank (paste from kill ring)
                    if !kill_ring.is_empty() {
                        kill_ring_yank_idx = kill_ring.len() - 1;
                        last_yank_start = cursor;
                        let text: Vec<char> = kill_ring[kill_ring_yank_idx].chars().collect();
                        let count = text.len();
                        current.splice(cursor..cursor, text);
                        cursor += count;
                        last_yank_len = count;
                        last_was_yank = true;
                        nav.clear();
                        needs_redraw = true;
                    }
                }
                0x1b => {
                    // Escape sequences: CSI, SS3, and Meta/Alt keys
                    match read_stdin_byte_timeout(25) {
                        Ok(Some(b'[')) => {
                            // CSI sequence — check for bracketed paste first
                            let mut params = String::new();
                            loop {
                                match read_stdin_byte_timeout(25) {
                                    Ok(Some(b)) if (0x30..=0x3f).contains(&b) => {
                                        params.push(b as char);
                                    }
                                    Ok(Some(b'~')) => {
                                        match params.as_str() {
                                            "1" | "7" => { cursor = 0; needs_redraw = true; }
                                            "3" => {
                                                if cursor < current.len() {
                                                    current.remove(cursor);
                                                    nav.clear();
                                                    needs_redraw = true;
                                                }
                                            }
                                            "4" | "8" => { cursor = current.len(); needs_redraw = true; }
                                            "200" => {
                                                // Bracketed paste start
                                                let mut paste_buf: Vec<char> = Vec::new();
                                                let mut esc_state = 0u8;
                                                let mut pbuf = String::new();
                                                loop {
                                                    match read_stdin_byte() {
                                                        Ok(Some(0x1b)) => {
                                                            if esc_state == 1 {
                                                                paste_buf.push('\x1b');
                                                            }
                                                            esc_state = 1;
                                                            pbuf.clear();
                                                        }
                                                        Ok(Some(b'[')) if esc_state == 1 => {
                                                            esc_state = 2;
                                                            pbuf.clear();
                                                        }
                                                        Ok(Some(b)) if esc_state == 2 => {
                                                            if b == b'~' {
                                                                pbuf.push('~');
                                                                if pbuf == "201~" { break; }
                                                                paste_buf.push('\x1b');
                                                                paste_buf.push('[');
                                                                for c in pbuf.chars() { paste_buf.push(c); }
                                                                pbuf.clear();
                                                                esc_state = 0;
                                                            } else if b.is_ascii_digit() || b == b';' {
                                                                pbuf.push(b as char);
                                                            } else {
                                                                paste_buf.push('\x1b');
                                                                paste_buf.push('[');
                                                                for c in pbuf.chars() { paste_buf.push(c); }
                                                                paste_buf.push(b as char);
                                                                pbuf.clear();
                                                                esc_state = 0;
                                                            }
                                                        }
                                                        Ok(Some(b)) => {
                                                            if esc_state == 1 {
                                                                paste_buf.push('\x1b');
                                                            }
                                                            esc_state = 0;
                                                            if b >= 0x80 {
                                                                // UTF-8 lead byte
                                                                let mut utf8 = vec![b];
                                                                let extra = if b & 0xE0 == 0xC0 { 1 }
                                                                    else if b & 0xF0 == 0xE0 { 2 }
                                                                    else { 3 };
                                                                for _ in 0..extra {
                                                                    if let Ok(Some(cont)) = read_stdin_byte() {
                                                                        utf8.push(cont);
                                                                    }
                                                                }
                                                                if let Ok(s) = std::str::from_utf8(&utf8) {
                                                                    for c in s.chars() { paste_buf.push(c); }
                                                                }
                                                            } else {
                                                                paste_buf.push(b as char);
                                                            }
                                                        }
                                                        Ok(None) | Err(_) => break,
                                                    }
                                                }
                                                // Insert pasted text (newlines become literal)
                                                let count = paste_buf.len();
                                                current.splice(cursor..cursor, paste_buf);
                                                cursor += count;
                                                nav.clear();
                                                needs_redraw = true;
                                            }
                                            _ => {}
                                        }
                                        break;
                                    }
                                    Ok(Some(b'A')) => {
                                        // Up arrow — prefix search if text typed
                                        let current_line: String = current.iter().collect();
                                        let entry = if !current_line.is_empty() && nav.cursor.is_none() {
                                            nav.prefix_previous(&shell, &current_line, &current_line)
                                        } else {
                                            nav.previous(&shell, &current_line)
                                        };
                                        if let Some(entry) = entry {
                                            current = entry.chars().collect();
                                            if !get_readline_settings().history_preserve_point {
                                                cursor = current.len();
                                            } else {
                                                cursor = cursor.min(current.len());
                                            }
                                            needs_redraw = true;
                                        }
                                        break;
                                    }
                                    Ok(Some(b'B')) => {
                                        // Down arrow — prefix search if active
                                        let current_line: String = current.iter().collect();
                                        let saved = nav.saved_current.clone();
                                        let entry = if let Some(ref prefix) = saved {
                                            if !prefix.is_empty() {
                                                nav.prefix_next(&shell, prefix, &current_line)
                                            } else {
                                                nav.next(&shell, &current_line)
                                            }
                                        } else {
                                            nav.next(&shell, &current_line)
                                        };
                                        if let Some(entry) = entry {
                                            current = entry.chars().collect();
                                            if !get_readline_settings().history_preserve_point {
                                                cursor = current.len();
                                            } else {
                                                cursor = cursor.min(current.len());
                                            }
                                            needs_redraw = true;
                                        }
                                        break;
                                    }
                                    Ok(Some(b'C')) => {
                                        // Right arrow; with modifier 5 = Ctrl+Right (word fwd)
                                        if params.ends_with(";5") || params.ends_with(";5") {
                                            while cursor < current.len() && !current[cursor].is_alphanumeric() {
                                                cursor += 1;
                                            }
                                            while cursor < current.len() && current[cursor].is_alphanumeric() {
                                                cursor += 1;
                                            }
                                        } else if cursor < current.len() {
                                            cursor += 1;
                                        }
                                        needs_redraw = true;
                                        break;
                                    }
                                    Ok(Some(b'D')) => {
                                        // Left arrow; with modifier 5 = Ctrl+Left (word back)
                                        if params.ends_with(";5") {
                                            while cursor > 0 && !current[cursor - 1].is_alphanumeric() {
                                                cursor -= 1;
                                            }
                                            while cursor > 0 && current[cursor - 1].is_alphanumeric() {
                                                cursor -= 1;
                                            }
                                        } else if cursor > 0 {
                                            cursor -= 1;
                                        }
                                        needs_redraw = true;
                                        break;
                                    }
                                    Ok(Some(b'H')) => {
                                        cursor = 0;
                                        needs_redraw = true;
                                        break;
                                    }
                                    Ok(Some(b'F')) => {
                                        cursor = current.len();
                                        needs_redraw = true;
                                        break;
                                    }
                                    _ => break,
                                }
                            }
                        }
                        Ok(Some(b'O')) => {
                            // SS3 sequences
                            match read_stdin_byte_timeout(25) {
                                Ok(Some(b'H')) => { cursor = 0; needs_redraw = true; }
                                Ok(Some(b'F')) => { cursor = current.len(); needs_redraw = true; }
                                _ => {}
                            }
                        }
                        Ok(Some(b'f')) | Ok(Some(b'F')) => {
                            // Alt-F: forward word
                            while cursor < current.len() && !current[cursor].is_alphanumeric() {
                                cursor += 1;
                            }
                            while cursor < current.len() && current[cursor].is_alphanumeric() {
                                cursor += 1;
                            }
                            needs_redraw = true;
                        }
                        Ok(Some(b'b')) | Ok(Some(b'B')) => {
                            // Alt-B: backward word
                            while cursor > 0 && !current[cursor - 1].is_alphanumeric() {
                                cursor -= 1;
                            }
                            while cursor > 0 && current[cursor - 1].is_alphanumeric() {
                                cursor -= 1;
                            }
                            needs_redraw = true;
                        }
                        Ok(Some(b'd')) | Ok(Some(b'D')) => {
                            // Alt-D: kill word forward
                            let start = cursor;
                            let mut end = cursor;
                            while end < current.len() && !current[end].is_alphanumeric() {
                                end += 1;
                            }
                            while end < current.len() && current[end].is_alphanumeric() {
                                end += 1;
                            }
                            if end > start {
                                let killed: String = current[start..end].iter().collect();
                                if last_was_kill && !kill_ring.is_empty() {
                                    // PROVEN: kill_ring is non-empty (checked above).
                                    let last = kill_ring.last_mut().unwrap();
                                    last.push_str(&killed);
                                } else {
                                    kill_ring.push(killed);
                                }
                                current.drain(start..end);
                                nav.clear();
                                needs_redraw = true;
                            }
                        }
                        Ok(Some(0x7f)) | Ok(Some(0x08)) => {
                            // Alt-Backspace: kill word backward
                            if cursor > 0 {
                                let end = cursor;
                                let mut start = cursor;
                                while start > 0 && !current[start - 1].is_alphanumeric() {
                                    start -= 1;
                                }
                                while start > 0 && current[start - 1].is_alphanumeric() {
                                    start -= 1;
                                }
                                let killed: String = current[start..end].iter().collect();
                                if last_was_kill && !kill_ring.is_empty() {
                                    // PROVEN: kill_ring is non-empty (checked above).
                                    let last = kill_ring.last_mut().unwrap();
                                    *last = format!("{}{}", killed, last);
                                } else {
                                    kill_ring.push(killed);
                                }
                                current.drain(start..end);
                                cursor = start;
                                nav.clear();
                                needs_redraw = true;
                            }
                        }
                        Ok(Some(b'.')) | Ok(Some(b'_')) => {
                            // Meta-.: insert last argument from previous command
                            let entries = &shell.history.entries;
                            if let Some(last_entry) = entries.last() {
                                let words: Vec<&str> = last_entry.line.split_whitespace().collect();
                                if let Some(last_word) = words.last() {
                                    let chars: Vec<char> = last_word.chars().collect();
                                    let count = chars.len();
                                    current.splice(cursor..cursor, chars);
                                    cursor += count;
                                    nav.clear();
                                    needs_redraw = true;
                                }
                            }
                        }
                        Ok(Some(b't')) | Ok(Some(b'T')) => {
                            // Alt-T: transpose words
                            if cursor > 0 && !current.is_empty() {
                                let mut end = cursor;
                                while end < current.len() && current[end].is_alphanumeric() {
                                    end += 1;
                                }
                                let mut mid = cursor;
                                while mid > 0 && current[mid - 1].is_alphanumeric() {
                                    mid -= 1;
                                }
                                let mut prev_end = mid;
                                while prev_end > 0 && !current[prev_end - 1].is_alphanumeric() {
                                    prev_end -= 1;
                                }
                                let mut prev_start = prev_end;
                                while prev_start > 0 && current[prev_start - 1].is_alphanumeric() {
                                    prev_start -= 1;
                                }
                                if prev_start < prev_end && mid < end {
                                    let word2: String = current[mid..end].iter().collect();
                                    let sep: String = current[prev_end..mid].iter().collect();
                                    let word1: String = current[prev_start..prev_end].iter().collect();
                                    let replacement: Vec<char> = format!("{}{}{}", word2, sep, word1).chars().collect();
                                    let new_cursor = prev_start + replacement.len();
                                    current.splice(prev_start..end, replacement);
                                    cursor = new_cursor;
                                    nav.clear();
                                    needs_redraw = true;
                                }
                            }
                        }
                        Ok(Some(b'u')) | Ok(Some(b'U')) => {
                            // Alt-U: uppercase word
                            while cursor < current.len() && !current[cursor].is_alphanumeric() {
                                cursor += 1;
                            }
                            while cursor < current.len() && current[cursor].is_alphanumeric() {
                                current[cursor] = current[cursor].to_uppercase().next().unwrap_or(current[cursor]);
                                cursor += 1;
                            }
                            nav.clear();
                            needs_redraw = true;
                        }
                        Ok(Some(b'l')) | Ok(Some(b'L')) => {
                            // Alt-L: lowercase word
                            while cursor < current.len() && !current[cursor].is_alphanumeric() {
                                cursor += 1;
                            }
                            while cursor < current.len() && current[cursor].is_alphanumeric() {
                                current[cursor] = current[cursor].to_lowercase().next().unwrap_or(current[cursor]);
                                cursor += 1;
                            }
                            nav.clear();
                            needs_redraw = true;
                        }
                        Ok(Some(b'c')) | Ok(Some(b'C')) => {
                            // Alt-C: capitalize word
                            while cursor < current.len() && !current[cursor].is_alphanumeric() {
                                cursor += 1;
                            }
                            let mut first = true;
                            while cursor < current.len() && current[cursor].is_alphanumeric() {
                                if first {
                                    current[cursor] = current[cursor].to_uppercase().next().unwrap_or(current[cursor]);
                                    first = false;
                                } else {
                                    current[cursor] = current[cursor].to_lowercase().next().unwrap_or(current[cursor]);
                                }
                                cursor += 1;
                            }
                            nav.clear();
                            needs_redraw = true;
                        }
                        Ok(Some(b'<')) => {
                            // Alt-<: beginning-of-history
                            if let Some(entry) = shell.history.entries.first() {
                                current = entry.line.chars().collect();
                                cursor = current.len();
                                needs_redraw = true;
                            }
                        }
                        Ok(Some(b'>')) => {
                            // Alt->: end-of-history (current line)
                            nav.clear();
                            current.clear();
                            cursor = 0;
                            needs_redraw = true;
                        }
                        Ok(Some(b'r')) | Ok(Some(b'R')) => {
                            // Alt-R: revert-line (undo all changes)
                            if let Some((first_chars, first_cursor)) = undo_stack.first().cloned() {
                                current = first_chars;
                                cursor = first_cursor;
                                undo_stack.clear();
                                nav.clear();
                                needs_redraw = true;
                            }
                        }
                        Ok(Some(b'y')) | Ok(Some(b'Y')) => {
                            // Alt-Y: yank-pop (cycle kill ring)
                            if last_was_yank && kill_ring.len() > 1 {
                                // Remove previous yank
                                let end = last_yank_start + last_yank_len;
                                current.drain(last_yank_start..end);
                                cursor = last_yank_start;
                                // Cycle to previous kill ring entry
                                kill_ring_yank_idx = if kill_ring_yank_idx == 0 {
                                    kill_ring.len() - 1
                                } else {
                                    kill_ring_yank_idx - 1
                                };
                                let text: Vec<char> = kill_ring[kill_ring_yank_idx].chars().collect();
                                let count = text.len();
                                current.splice(cursor..cursor, text);
                                cursor += count;
                                last_yank_len = count;
                                last_was_yank = true;
                                nav.clear();
                                needs_redraw = true;
                            }
                        }
                        Ok(Some(b'#')) => {
                            // Meta-#: insert comment-begin and execute
                            let comment_str = get_readline_settings().comment_begin.clone();
                            let comment_chars: Vec<char> = comment_str.chars().collect();
                            for (i, ch) in comment_chars.into_iter().enumerate() {
                                current.insert(i, ch);
                            }
                            let _ = write!(stdout, "\r\n");
                            let _ = stdout.flush();
                            let mut line: String = current.iter().collect();
                            submit_interactive_line(&mut shell, &mut pending, &mut line);
                            current.clear();
                            cursor = 0;
                            nav.clear();
                            undo_stack.clear();
                            prompt_shown = false;
                        }
                        Ok(Some(0x09)) => {
                            // ESC-Tab (Meta-Tab): menu-complete
                            if !last_was_menu_complete {
                                let (word_start, word) = extract_completion_word(&current, cursor);
                                let (_, all_matches) = perform_tab_completion(&mut shell, &current, cursor);
                                if !all_matches.is_empty() {
                                    menu_matches = all_matches;
                                    menu_word_start = word_start;
                                    _menu_original_word = word;
                                    menu_idx = 0;
                                } else {
                                    // Single match path — complete it directly
                                    let (insert, _) = perform_tab_completion(&mut shell, &current, cursor);
                                    if !insert.is_empty() {
                                        let chars: Vec<char> = insert.chars().collect();
                                        let count = chars.len();
                                        current.splice(cursor..cursor, chars);
                                        cursor += count;
                                        needs_redraw = true;
                                    } else {
                                        ring_bell(&mut stdout);
                                    }
                                    menu_matches.clear();
                                }
                            }
                            if !menu_matches.is_empty() {
                                // Replace from word_start to cursor with menu_matches[menu_idx]
                                let replacement: Vec<char> = menu_matches[menu_idx].chars().collect();
                                let new_len = replacement.len();
                                current.splice(menu_word_start..cursor, replacement);
                                cursor = menu_word_start + new_len;
                                menu_idx = (menu_idx + 1) % menu_matches.len();
                                last_was_menu_complete = true;
                                nav.clear();
                                needs_redraw = true;
                            }
                        }
                        Ok(Some(b'*')) => {
                            // Meta-*: insert-completions (insert all completions)
                            let (_, all_matches) = perform_tab_completion(&mut shell, &current, cursor);
                            if !all_matches.is_empty() {
                                let (word_start, _) = extract_completion_word(&current, cursor);
                                let joined = all_matches.join(" ");
                                let chars: Vec<char> = joined.chars().collect();
                                let new_len = chars.len();
                                current.splice(word_start..cursor, chars);
                                cursor = word_start + new_len;
                                nav.clear();
                                needs_redraw = true;
                            }
                        }
                        Ok(Some(b'?')) => {
                            // Meta-?: list completions (possible-completions)
                            let (_, all_matches) = perform_tab_completion(&mut shell, &current, cursor);
                            if !all_matches.is_empty() {
                                display_completion_matches(&mut stdout, &all_matches, &prompt, &current, cursor);
                            } else {
                                ring_bell(&mut stdout);
                            }
                        }
                        Ok(Some(b'~')) => {
                            // Meta-~: tilde-expand
                            let (word_start, word) = extract_completion_word(&current, cursor);
                            if word.starts_with('~') {
                                if let Ok(home) = env::var("HOME") {
                                    let expanded = word.replacen('~', &home, 1);
                                    let chars: Vec<char> = expanded.chars().collect();
                                    let new_len = chars.len();
                                    current.splice(word_start..cursor, chars);
                                    cursor = word_start + new_len;
                                    nav.clear();
                                    needs_redraw = true;
                                }
                            }
                        }
                        _ => {}
                    }
                }
                0x18 => {
                    // Ctrl-X prefix
                    if let Ok(Some(next)) = read_stdin_byte_timeout(1000) {
                        match next {
                            0x05 => {
                                // Ctrl-X Ctrl-E: edit in $EDITOR
                                let editor = shell.get_var("VISUAL")
                                    .or_else(|| shell.get_var("EDITOR"))
                                    .unwrap_or_else(|| "vi".to_string());
                                let tmp_path = format!("/tmp/.brash_edit_{}", std::process::id());
                                let line: String = current.iter().collect();
                                if fs::write(&tmp_path, format!("{}\n", line)).is_ok() {
                                    let _ = write!(stdout, "\x1b[?2004l");
                                    let _ = stdout.flush();
                                    // SAFETY:
                                    // - `std::mem::zeroed()` is valid for `libc::termios`.
                                    // - `tcgetattr(STDIN_FILENO, &mut orig)` fills `orig`; we
                                    //   save it so we can restore it after the editor exits.
                                    // - `tcsetattr(STDIN_FILENO, TCSAFLUSH, &cooked/&orig)` puts
                                    //   the terminal into cooked mode for the editor, then
                                    //   restores raw mode afterward.
                                    // - `cmd` is a valid NUL-terminated C string built from
                                    //   `editor` and `tmp_path` (both controlled by this process).
                                    // - `libc::system` runs the shell command synchronously and
                                    //   waits for it to complete before we restore raw mode.
                                    unsafe {
                                        let mut orig: libc::termios = std::mem::zeroed();
                                        libc::tcgetattr(libc::STDIN_FILENO, &mut orig);
                                        let mut cooked = orig;
                                        cooked.c_lflag |= libc::ICANON | libc::ECHO;
                                        let _ = libc::tcsetattr(libc::STDIN_FILENO, libc::TCSAFLUSH, &cooked);
                                        let cmd = std::ffi::CString::new(format!("{} {}", editor, tmp_path)).unwrap_or_default();
                                        libc::system(cmd.as_ptr());
                                        let _ = libc::tcsetattr(libc::STDIN_FILENO, libc::TCSAFLUSH, &orig);
                                    }
                                    let _ = write!(stdout, "\x1b[?2004h");
                                    if let Ok(edited) = fs::read_to_string(&tmp_path) {
                                        let trimmed = edited.trim_end_matches('\n');
                                        if !trimmed.is_empty() {
                                            let _ = write!(stdout, "\r\n");
                                            let _ = stdout.flush();
                                            let mut line = trimmed.to_string();
                                            submit_interactive_line(&mut shell, &mut pending, &mut line);
                                            current.clear();
                                            cursor = 0;
                                            nav.clear();
                                            prompt_shown = false;
                                        }
                                    }
                                    let _ = fs::remove_file(&tmp_path);
                                }
                            }
                            b'(' => {
                                // Ctrl-X (: start keyboard macro recording
                                macro_recording = true;
                                macro_buffer.clear();
                            }
                            b')' => {
                                // Ctrl-X ): end keyboard macro recording
                                macro_recording = false;
                                macro_playback = macro_buffer.clone();
                            }
                            b'e' | b'E' => {
                                // Ctrl-X e: execute keyboard macro
                                // We'll feed the recorded bytes back into the
                                // editor on the next iterations. This is a
                                // simplified approach: set a replay buffer.
                                // Since we can't re-enter the loop easily,
                                // just insert the macro text directly.
                                if !macro_playback.is_empty() {
                                    if let Ok(s) = std::str::from_utf8(&macro_playback) {
                                        let chars: Vec<char> = s.chars().collect();
                                        let count = chars.len();
                                        current.splice(cursor..cursor, chars);
                                        cursor += count;
                                        nav.clear();
                                        needs_redraw = true;
                                    }
                                }
                            }
                            _ => {} // Other Ctrl-X sequences ignored
                        }
                    }
                }
                0x1d => {
                    // Ctrl-]: character-search-forward
                    if let Ok(Some(target)) = read_stdin_byte() {
                        let ch = target as char;
                        if let Some(pos) = current[cursor + 1..].iter().position(|&c| c == ch) {
                            cursor += 1 + pos;
                            needs_redraw = true;
                        }
                    }
                }
                0x1f => {
                    // Ctrl-_: undo
                    if let Some((prev_chars, prev_cursor)) = undo_stack.pop() {
                        current = prev_chars;
                        cursor = prev_cursor;
                        needs_redraw = true;
                    }
                }
                byte if byte < 0x20 => {}
                byte => {
                    nav.clear();
                    if let Ok(inserted) = decode_editor_input(byte) {
                        let count = inserted.len();
                        current.splice(cursor..cursor, inserted);
                        cursor += count;
                        needs_redraw = true;
                    }
                }
            }

            // Track consecutive kills for accumulation
            last_was_kill = matches!(byte, 0x0b | 0x15 | 0x17)
                || (byte == 0x1b); // Alt-D/Alt-Backspace handled via escape
            // Track yank state for Alt-Y (yank-pop)
            if byte != 0x19 && !(byte == 0x1b && last_was_yank) {
                last_was_yank = false;
            }
            // Reset menu-complete state when non-menu-complete key pressed
            if !last_was_menu_complete {
                menu_matches.clear();
            }
            last_was_menu_complete = false;
            last_was_tab = byte == 0x09;
            // Reset EOF counter on non-EOF input
            if byte != 0x04 { eof_count = 0; }
            // Record to keyboard macro if active (exclude Ctrl-X itself)
            if macro_recording && byte != 0x18 {
                macro_buffer.push(byte);
            }
            // Save undo state when line changed
            if needs_redraw && byte != 0x1f {
                undo_stack.push(pre_state);
                if undo_stack.len() > 100 { undo_stack.remove(0); }
            }

            if needs_redraw {
                let _ = redraw_editor_line(&mut stdout, &prompt, &current, cursor);
            }
        }
    } else {
        let mut buf = String::new();
        loop {
            if shell.exit_flag || shell.return_flag {
                break;
            }

            if buf.is_empty() {
                if let Some(prompt_command) = shell.get_var("PROMPT_COMMAND") {
                    if !prompt_command.is_empty() {
                        shell.run_string(&prompt_command);
                        if shell.exit_flag || shell.return_flag {
                            break;
                        }
                    }
                }
            }

            let prompt_raw = if buf.is_empty() {
                shell.get_var("PS1").unwrap_or_else(|| "\\$ ".to_string())
            } else {
                shell.get_var("PS2").unwrap_or_else(|| "> ".to_string())
            };
            let prompt = shell.expand_prompt(&prompt_raw);
            let _ = write!(stdout, "{}", prompt);
            let _ = stdout.flush();

            let mut line = String::new();
            match stdin.read_line(&mut line) {
                Ok(0) => {
                    if !buf.is_empty() {
                        shell.run_string(&buf);
                        buf.clear();
                    }
                    break;
                }
                Ok(_) => {
                    buf.push_str(&line);
                    if stdin_buffer_is_complete(&buf) {
                        shell.run_string(&buf);
                        buf.clear();
                    }
                }
                Err(_) => break,
            }
        }
    }
    save_history_file(&mut shell);
    process::exit(shell.last_status);
}

/// Returns true if the buffered text so far looks like a complete shell
/// statement (no open quotes, heredocs, compound commands, or backslash
/// continuation). Used when streaming stdin line-by-line to decide when to
/// flush a chunk to run_string.
fn stdin_buffer_is_complete(buf: &str) -> bool {
    // Trailing backslash-newline: incomplete
    if buf.ends_with("\\\n") { return false; }

    let chars: Vec<char> = buf.chars().collect();
    let mut i = 0usize;
    let n = chars.len();
    let mut in_single = false;
    let mut in_double = false;
    let mut in_backtick = false;
    let mut paren_depth: i32 = 0;     // (
    let mut brace_depth: i32 = 0;     // {
    let mut dparen_depth: i32 = 0;    // $(( or (( ; tracked but approximate
    let mut compound_depth: i32 = 0;  // if/while/for/until/case nesting count
    // Heredoc tracking: once we see <<DELIM (or <<-DELIM), we accumulate
    // lines until a line equals DELIM.
    let mut pending_heredocs: Vec<(String, bool)> = Vec::new();
    let mut at_line_start = true;

    while i < n {
        let c = chars[i];

        // Handle heredoc-body: if we're at the start of a line and have
        // pending heredocs, check whether the line matches the oldest delim.
        if at_line_start && !pending_heredocs.is_empty()
            && !in_single && !in_double && !in_backtick {
            // Read the current line
            let mut j = i;
            while j < n && chars[j] != '\n' { j += 1; }
            let line: String = chars[i..j].iter().collect();
            let (delim, strip_tabs) = &pending_heredocs[0];
            let check = if *strip_tabs { line.trim_start_matches('\t') } else { line.as_str() };
            if check == delim.as_str() {
                pending_heredocs.remove(0);
            }
            i = j;
            if i < n { i += 1; } // skip the \n
            at_line_start = true;
            continue;
        }

        if in_single {
            if c == '\'' { in_single = false; }
            i += 1;
            at_line_start = c == '\n';
            continue;
        }
        if in_double {
            if c == '\\' && i + 1 < n { i += 2; continue; }
            if c == '"' { in_double = false; }
            i += 1;
            at_line_start = c == '\n';
            continue;
        }
        if in_backtick {
            if c == '\\' && i + 1 < n { i += 2; continue; }
            if c == '`' { in_backtick = false; }
            i += 1;
            at_line_start = c == '\n';
            continue;
        }

        match c {
            '\\' if i + 1 < n => { i += 2; at_line_start = false; continue; }
            '#' => {
                // Comment to end of line
                while i < n && chars[i] != '\n' { i += 1; }
                continue;
            }
            '\'' => { in_single = true; i += 1; continue; }
            '"' => { in_double = true; i += 1; continue; }
            '`' => { in_backtick = true; i += 1; continue; }
            '(' => {
                if i + 1 < n && chars[i + 1] == '(' {
                    dparen_depth += 1; i += 2; continue;
                }
                paren_depth += 1; i += 1; at_line_start = false; continue;
            }
            ')' => {
                if dparen_depth > 0 && i + 1 < n && chars[i + 1] == ')' {
                    dparen_depth -= 1; i += 2; continue;
                }
                paren_depth -= 1; i += 1; at_line_start = false; continue;
            }
            '{' => { brace_depth += 1; i += 1; at_line_start = false; continue; }
            '}' => { brace_depth -= 1; i += 1; at_line_start = false; continue; }
            '<' if i + 1 < n && chars[i + 1] == '<' => {
                // Check for heredoc: `<<` or `<<-` possibly followed by delim
                let mut j = i + 2;
                let strip_tabs = j < n && chars[j] == '-';
                if strip_tabs { j += 1; }
                // Skip whitespace
                while j < n && (chars[j] == ' ' || chars[j] == '\t') { j += 1; }
                // Read delim, stripping any surrounding quotes
                let mut delim = String::new();
                let mut quote = None;
                if j < n && (chars[j] == '\'' || chars[j] == '"') {
                    quote = Some(chars[j]); j += 1;
                }
                while j < n {
                    let d = chars[j];
                    if let Some(q) = quote {
                        if d == q { j += 1; break; }
                        delim.push(d); j += 1;
                    } else {
                        if d.is_whitespace() || "()<>|&;".contains(d) { break; }
                        if d == '\\' && j + 1 < n { delim.push(chars[j+1]); j += 2; continue; }
                        delim.push(d); j += 1;
                    }
                }
                if !delim.is_empty() {
                    pending_heredocs.push((delim, strip_tabs));
                }
                i = j;
                at_line_start = false;
                continue;
            }
            '\n' => {
                // At newline boundary, check for compound word starters on
                // the next statement.
                i += 1;
                at_line_start = true;
                continue;
            }
            _ => {
                // Reserved word lookups (at the start of a statement)
                if at_line_start && c.is_alphabetic() {
                    // Read identifier
                    let mut j = i;
                    while j < n && (chars[j].is_alphanumeric() || chars[j] == '_') { j += 1; }
                    let word: String = chars[i..j].iter().collect();
                    match word.as_str() {
                        "if" | "while" | "until" | "for" | "select" | "case" => {
                            compound_depth += 1;
                        }
                        "fi" | "done" | "esac" => {
                            compound_depth -= 1;
                        }
                        _ => {}
                    }
                    i = j;
                    at_line_start = false;
                    continue;
                }
                at_line_start = false;
                i += 1;
            }
        }
    }

    !in_single && !in_double && !in_backtick
        && paren_depth <= 0 && brace_depth <= 0
        && dparen_depth <= 0 && compound_depth <= 0
        && pending_heredocs.is_empty()
}

#[derive(Default)]
struct InteractiveHistoryState {
    snapshot: Vec<String>,
    cursor: Option<usize>,
    saved_current: Option<String>,
}

impl InteractiveHistoryState {
    fn clear(&mut self) {
        self.snapshot.clear();
        self.cursor = None;
        self.saved_current = None;
    }

    fn ensure_snapshot(&mut self, shell: &exec::Shell) {
        if self.snapshot.is_empty() {
            self.snapshot = shell.history.entries.iter()
                .map(|entry| entry.line.clone())
                .collect();
        }
    }

    fn previous(&mut self, shell: &exec::Shell, current: &str) -> Option<String> {
        self.ensure_snapshot(shell);
        if self.snapshot.is_empty() {
            return None;
        }
        if self.cursor.is_none() {
            self.saved_current = Some(current.to_string());
        }
        let next_idx = match self.cursor {
            Some(idx) if idx > 0 => idx - 1,
            Some(_) => 0,
            None => self.snapshot.len().saturating_sub(1),
        };
        self.cursor = Some(next_idx);
        self.snapshot.get(next_idx).cloned()
    }

    fn next(&mut self, shell: &exec::Shell, current: &str) -> Option<String> {
        self.ensure_snapshot(shell);
        let idx = self.cursor?;
        let next_idx = idx + 1;
        if next_idx >= self.snapshot.len() {
            self.cursor = None;
            return Some(self.saved_current.take().unwrap_or_else(|| current.to_string()));
        }
        self.cursor = Some(next_idx);
        self.snapshot.get(next_idx).cloned()
    }

    fn search(&mut self, shell: &exec::Shell, needle: &str) -> Option<String> {
        self.ensure_snapshot(shell);
        if self.snapshot.is_empty() {
            return None;
        }
        let start = self.cursor.unwrap_or(self.snapshot.len());
        // Search backwards from current position
        let idx = self.snapshot[..start].iter().rposition(|entry| entry.contains(needle))?;
        self.cursor = Some(idx);
        self.snapshot.get(idx).cloned()
    }

    fn forward_search(&mut self, shell: &exec::Shell, needle: &str) -> Option<String> {
        self.ensure_snapshot(shell);
        if self.snapshot.is_empty() {
            return None;
        }
        let start = self.cursor.map(|c| c + 1).unwrap_or(0);
        for i in start..self.snapshot.len() {
            if self.snapshot[i].contains(needle) {
                self.cursor = Some(i);
                return self.snapshot.get(i).cloned();
            }
        }
        None
    }

    fn prefix_previous(&mut self, shell: &exec::Shell, prefix: &str, current: &str) -> Option<String> {
        self.ensure_snapshot(shell);
        if self.snapshot.is_empty() || prefix.is_empty() {
            return self.previous(shell, current);
        }
        if self.cursor.is_none() {
            self.saved_current = Some(current.to_string());
        }
        let start = self.cursor.unwrap_or(self.snapshot.len());
        for i in (0..start).rev() {
            if self.snapshot[i].starts_with(prefix) {
                self.cursor = Some(i);
                return self.snapshot.get(i).cloned();
            }
        }
        None
    }

    fn prefix_next(&mut self, shell: &exec::Shell, prefix: &str, current: &str) -> Option<String> {
        self.ensure_snapshot(shell);
        let idx = match self.cursor {
            Some(i) => i + 1,
            None => return None,
        };
        for i in idx..self.snapshot.len() {
            if self.snapshot[i].starts_with(prefix) {
                self.cursor = Some(i);
                return self.snapshot.get(i).cloned();
            }
        }
        // Exhausted — return to saved current
        self.cursor = None;
        Some(self.saved_current.take().unwrap_or_else(|| current.to_string()))
    }

    fn next_after_operate(&mut self) -> Option<String> {
        let idx = self.cursor?;
        let next_idx = idx + 1;
        if next_idx >= self.snapshot.len() {
            self.cursor = None;
            return None;
        }
        self.cursor = Some(next_idx);
        self.snapshot.get(next_idx).cloned()
    }
}

fn update_winsize(shell: &mut exec::Shell) {
    if !shell.shopt.contains("checkwinsize") {
        return;
    }
    // SAFETY:
    // - `std::mem::zeroed()` is valid for `libc::winsize` (a plain C struct of
    //   unsigned shorts; all-zero is a safe sentinel value).
    // - `ioctl(STDOUT_FILENO, TIOCGWINSZ, &mut ws)` fills `ws` in place; it
    //   returns -1 if fd 1 is not a terminal, which we handle with the `== 0` guard.
    unsafe {
        let mut ws: libc::winsize = std::mem::zeroed();
        if libc::ioctl(libc::STDOUT_FILENO, libc::TIOCGWINSZ, &mut ws) == 0 {
            if ws.ws_col > 0 {
                shell.set_var("COLUMNS", &ws.ws_col.to_string());
            }
            if ws.ws_row > 0 {
                shell.set_var("LINES", &ws.ws_row.to_string());
            }
        }
    }
}

fn submit_interactive_line(shell: &mut exec::Shell, pending: &mut String, current: &mut String) {
    if current.is_empty() && pending.is_empty() {
        return;
    }
    pending.push_str(current);
    pending.push('\n');
    current.clear();
    if stdin_buffer_is_complete(pending) {
        // PS0: displayed after command read, before execution (bash 4.4+)
        if let Some(ps0) = shell.get_var("PS0") {
            if !ps0.is_empty() {
                let expanded = shell.expand_prompt(&ps0);
                let _ = io::Write::write_all(&mut io::stdout(), expanded.as_bytes());
                let _ = io::Write::flush(&mut io::stdout());
            }
        }
        shell.run_string(pending);
        pending.clear();
        update_winsize(shell);
    }
}

fn history_file_options(shell: &exec::Shell) -> history::HistoryFileOptions {
    history::HistoryFileOptions {
        comment_char: shell.get_var("histchars")
            .and_then(|s| s.chars().nth(2))
            .unwrap_or('#'),
        write_timestamps: shell.vars.has_entry("HISTTIMEFORMAT"),
        histfile_size: shell.get_var("HISTFILESIZE")
            .and_then(|s| s.parse::<usize>().ok()),
    }
}

fn save_history_file(shell: &mut exec::Shell) {
    let Some(path) = shell.get_var("HISTFILE").filter(|s| !s.is_empty()) else {
        return;
    };
    shell.remember_history_file(&path);
    let opts = history_file_options(shell);
    let _ = shell.history.write_to_file_with_options(&path, false, opts);
}

fn init_shell_vars(shell: &mut exec::Shell, argv0: &str) {
    shell.set_var("BASH", &env::current_exe().unwrap_or_default().to_string_lossy());
    shell.set_var("BASH_VERSION", "5.3.0(1)-release");
    shell.set_var("BASH_VERSINFO", "5");
    shell.set_var("SHELL", argv0);

    // Bash uses the basename of argv[0] as $0 for error messages when
    // no script is being run and no explicit name is passed (e.g. `-c`).
    // When BASH_ARGV0 is set (exported from a parent), bash uses that
    // as $0 instead, ignoring the actual argv[0].  Mirror that.
    let argv0_from_env = std::env::var("BASH_ARGV0").ok();
    let argv0_basename: String = if let Some(s) = &argv0_from_env {
        s.clone()
    } else {
        let base = std::path::Path::new(argv0.trim_start_matches('-'))
            .file_name()
            .and_then(|s| s.to_str())
            .unwrap_or(argv0)
            .to_string();
        // In BRASH_TEST_MODE, the binary basename "brash" is rewritten to
        // exec::shell_name() ("bash") so error messages match bash's
        // wording.  Non-default invocation names (set via `exec -a NAME`,
        // login shells with leading `-`, etc.) pass through unchanged.
        let normalized = if base == "brash" {
            exec::shell_name().to_string()
        } else {
            base
        };
        if argv0.starts_with('-') {
            format!("-{}", normalized)
        } else {
            normalized
        }
    };
    shell.set_var("0", &argv0_basename);
    // bash initialises `$_` to the absolute pathname of the shell or
    // script at startup.  Subsequent commands update it to the last
    // argument of the previous command.  Use the resolved binary path
    // when available so `${_+…}` and `${_:-…}` behave like bash for
    // tests like exp1.sub that reference `$_` early.
    if let Some(cur_exe) = std::env::current_exe().ok().and_then(|p| p.to_str().map(String::from)) {
        shell.set_var("_", &cur_exe);
    } else {
        shell.set_var("_", &argv0_basename);
    }
    shell.set_var("BASH_ARGV0", &argv0_basename);
    shell.set_var("BASH_SUBSHELL", "0");
    shell.set_var("BASHPID", &format!("{}", process::id()));
    shell.set_var("PPID", &format!("{}", nix::unistd::getppid()));
    shell.set_var("UID", &format!("{}", nix::unistd::getuid()));
    shell.set_var("EUID", &format!("{}", nix::unistd::geteuid()));
    shell.set_var("HOSTNAME", &nix::unistd::gethostname()
        .map(|h| h.to_string_lossy().to_string()).unwrap_or_default());
    shell.set_var("OSTYPE", "linux-musl");
    shell.set_var("MACHTYPE", &format!("{}-unknown-linux-musl", env::consts::ARCH));
    shell.set_var("HOSTTYPE", env::consts::ARCH);
    shell.set_var("IFS", " \t\n");
    // PS1 is only set automatically in interactive shells; when running
    // a script (non-interactive) bash leaves PS1 unset (empty).
    // Tests that examine the environment rely on this.
    if shell.interactive {
        shell.set_var("PS1", "\\$ ");
    } else {
        // Leave PS1 unset so `$PS1` expands to empty.
    }
    shell.set_var("PS2", "> ");
    shell.set_var("PS4", "+ ");
    shell.set_var("LINENO", "0");
    shell.set_var("SHLVL", &{
        let cur: i32 = env::var("SHLVL").unwrap_or_default().parse().unwrap_or(0);
        format!("{}", cur + 1)
    });
    shell.set_var("OPTERR", "1");
    shell.set_var("OPTIND", "1");
    shell.set_var("COMP_WORDBREAKS", " \t\n\"'><=;|&(:");

    // Built-in empty associative arrays that bash always declares.
    // These show up in `declare -A` output even when no aliases /
    // tracked commands exist yet.
    shell.vars.declare_assoc("BASH_ALIASES");
    shell.vars.declare_assoc("BASH_CMDS");
    shell.vars.mark_initialized("BASH_ALIASES");
    shell.vars.mark_initialized("BASH_CMDS");

    // GROUPS array: supplementary group IDs for the current user
    {
        // SAFETY:
        // - `getgroups(0, null_mut())` is the POSIX idiom for querying the number of
        //   supplementary groups; the null pointer and zero count are explicitly
        //   permitted by POSIX when size is 0.
        // - The second `getgroups(ngroups, gids.as_mut_ptr())` is called with `gids`
        //   allocated to `ngroups` elements, so the buffer is always large enough
        //   (assuming the group set doesn't grow between the two calls, which is safe
        //   in a single-threaded shell with no setgroups calls).
        let ngroups = unsafe { libc::getgroups(0, std::ptr::null_mut()) };
        if ngroups > 0 {
            let mut gids = vec![0 as libc::gid_t; ngroups as usize];
            let actual = unsafe { libc::getgroups(ngroups, gids.as_mut_ptr()) };
            if actual > 0 {
                gids.truncate(actual as usize);
                let group_strs: Vec<String> = gids.iter().map(|g| g.to_string()).collect();
                shell.vars.set_array("GROUPS", group_strs);
            }
        }
    }
}

fn atty_stdin() -> bool {
    // SAFETY: `isatty(0)` queries fd 0 (stdin) without modifying state; it returns
    // 0 rather than panicking if fd 0 is closed or not a terminal.
    unsafe { libc::isatty(0) != 0 }
}

fn prepare_interactive_shell(shell: &mut exec::Shell) {
    shell.interactive = true;
    shell.opts.history = true; // histexpand (-H) enabled by default in interactive mode
    shell.opts.history_facility = true; // history recording is enabled by default in interactive mode
    shell.shopt.insert("expand_aliases".to_string()); // enabled by default in interactive mode
}

fn uses_bash_startup_files(argv0: &str) -> bool {
    // BRASH_TEST_MODE means the bash test suite is driving us — it expects
    // bash-compatible startup-file behaviour (.bash_profile / .bash_logout
    // / etc.) so the upstream invocation.tests fixture matches.  Without
    // this short-circuit, the `--login -c 'logout'` sub-test fails because
    // brash refuses to source $HOME/.bash_logout.
    if is_test_mode() {
        return true;
    }
    let name = std::path::Path::new(argv0.trim_start_matches('-'))
        .file_name()
        .and_then(|s| s.to_str())
        .unwrap_or(argv0);
    name == "bash"
}

fn source_startup_file(shell: &mut exec::Shell, path: &str, hide_bash_identity: bool) -> bool {
    let Ok(content) = fs::read_to_string(path) else {
        return false;
    };

    let saved_source_depth = shell.source_depth;
    let saved_return_flag = shell.return_flag;
    let saved_bash = hide_bash_identity.then(|| shell.get_var("BASH"));
    let saved_bash_version = hide_bash_identity.then(|| shell.get_var("BASH_VERSION"));
    let saved_bash_versinfo = hide_bash_identity.then(|| shell.get_var("BASH_VERSINFO"));
    if hide_bash_identity {
        shell.vars.unset("BASH");
        shell.vars.unset("BASH_VERSION");
        shell.vars.unset("BASH_VERSINFO");
    }
    shell.source_depth += 1;
    shell.run_string(&content);
    shell.source_depth = saved_source_depth;
    if shell.return_flag {
        shell.return_flag = saved_return_flag;
    }
    if let Some(saved) = saved_bash {
        restore_startup_var(shell, "BASH", saved);
    }
    if let Some(saved) = saved_bash_version {
        restore_startup_var(shell, "BASH_VERSION", saved);
    }
    if let Some(saved) = saved_bash_versinfo {
        restore_startup_var(shell, "BASH_VERSINFO", saved);
    }
    true
}

fn restore_startup_var(shell: &mut exec::Shell, name: &str, value: Option<String>) {
    match value {
        Some(v) => shell.set_var(name, &v),
        None => shell.vars.unset(name),
    }
}

/// Source ~/.bash_logout on login-shell exit (or ~/.brash_logout if
/// present, preferred).  Bash sources this file before the shell
/// terminates for `-l` / `--login` invocations.
fn run_bash_logout(shell: &mut exec::Shell, bash_compat_startup: bool) {
    if shell.noprofile {
        return;
    }
    let home = env::var("HOME").unwrap_or_default();
    if home.is_empty() {
        return;
    }
    // The `logout` / `exit` builtin sets `exit_flag`, which would
    // short-circuit `run_string`.  Temporarily clear it so the
    // logout script body can execute.
    let saved_exit_flag = shell.exit_flag;
    shell.exit_flag = false;
    // Same precedence rule as the rc / profile lookups: in test mode or
    // under argv0 `bash` we source ~/.bash_logout exclusively (so the
    // upstream bash test suite's invocation.tests `--login -c 'logout'`
    // fixture still produces "this is bash_logout"); otherwise prefer
    // ~/.brash_logout but fall back to ~/.bash_logout when absent.
    let brash_logout = format!("{}/.brash_logout", home);
    let bash_logout = format!("{}/.bash_logout", home);
    if is_test_mode() || bash_compat_startup {
        source_startup_file(shell, &bash_logout, false);
    } else if !source_startup_file(shell, &brash_logout, false) {
        source_startup_file(shell, &bash_logout, false);
    }
    shell.exit_flag = saved_exit_flag;
}

/// Apply BASHOPTS / SHELLOPTS from the parent environment.  This must
/// run AFTER command-line flag processing so that an exported
/// SHELLOPTS containing `braceexpand` can re-enable it even when the
/// caller passed `+B`, matching bash semantics.
fn inherit_shellopts_env(shell: &mut exec::Shell) {
    if let Ok(v) = env::var("BASHOPTS") {
        for opt in v.split(':') {
            if !opt.is_empty() && builtins::SHOPT_OPTIONS.contains(&opt) {
                shell.shopt.insert(opt.to_string());
            }
        }
    }
    if let Ok(v) = env::var("SHELLOPTS") {
        // SHELLOPTS lists the options the parent considers enabled.
        // Additively enable each one in the child; leave defaults
        // alone.  (Bash doesn't strictly forbid default-on options
        // from being on in a child whose parent had them off.)
        for opt in v.split(':') {
            if !opt.is_empty() {
                shell.set_option(opt);
            }
        }
    }
}

/// Import shell functions exported by a parent shell via BASH_FUNC_name%% env vars.
/// This implements function inheritance across exec() boundaries.
fn import_bash_funcs(shell: &mut exec::Shell) {
    // Collect the relevant env vars first to avoid borrowing issues
    let bash_funcs: Vec<(String, String)> = env::vars()
        .filter(|(k, _)| k.starts_with("BASH_FUNC_") && k.ends_with("%%"))
        .collect();

    for (key, value) in bash_funcs {
        // Extract function name from BASH_FUNC_name%%
        let func_name = &key["BASH_FUNC_".len()..key.len() - "%%".len()];

        // Security: reject names with newlines, leading/trailing whitespace, or spaces
        if func_name.contains('\n') || func_name.contains(' ') || func_name.contains('\t') {
            continue;
        }
        // Reject empty names
        if func_name.is_empty() {
            continue;
        }

        // Security (CVE-2014-6271): value must start with "() " or "() {"
        // to be a valid function definition; anything else is ignored.
        let trimmed = value.trim_start();
        if !trimmed.starts_with("()") {
            continue;
        }

        // Security (CVE-2014-6271): reject if there is any code after the
        // closing `}` of the function body. Bash 5.x rejects such values entirely.
        if !is_clean_func_body(trimmed) {
            continue;
        }

        // Build the function definition source and parse it.
        // The value is "() { body }" and we prepend the function name.
        let func_src = format!("{} {}", func_name, trimmed);

        // Parse and register the function, ignoring any parse errors
        shell.define_function_from_src(func_name, &func_src);

        // Keep the BASH_FUNC_name%% var exported so it propagates further
    }
}

/// Return true iff the function body value has no code after the closing `}`.
/// CVE-2014-6271: values like `() { safe; } ; evil` must be rejected.
fn is_clean_func_body(src: &str) -> bool {
    let bytes = src.as_bytes();
    let mut i = 0;
    let n = bytes.len();

    // Skip `()` and whitespace before `{`
    while i < n && (bytes[i] == b'(' || bytes[i] == b')' || bytes[i] == b' ' || bytes[i] == b'\t') {
        i += 1;
    }

    // If not a brace-group body, accept it as-is (subshell body, etc.)
    if i >= n || bytes[i] != b'{' {
        return true;
    }

    // Find the matching outer `}` tracking brace depth and quoting
    let mut depth = 0usize;
    let mut in_single_quote = false;
    let mut in_double_quote = false;
    let mut end: Option<usize> = None;

    while i < n {
        let c = bytes[i];
        if in_single_quote {
            if c == b'\'' { in_single_quote = false; }
        } else if in_double_quote {
            if c == b'\\' { i += 1; } // skip escaped char
            else if c == b'"' { in_double_quote = false; }
        } else {
            match c {
                b'\'' => in_single_quote = true,
                b'"'  => in_double_quote = true,
                b'\\' => { i += 1; }
                b'#' => {
                    // Skip comment to end of line
                    while i < n && bytes[i] != b'\n' { i += 1; }
                }
                b'{' => depth += 1,
                b'}' => {
                    depth -= 1;
                    if depth == 0 {
                        end = Some(i + 1);
                        break;
                    }
                }
                _ => {}
            }
        }
        i += 1;
    }

    // The closing `}` must exist and everything after it must be either
    // whitespace/newlines or one-or-more file-descriptor redirections that
    // bash itself emits when pretty-printing a function body (e.g.
    // `() { … } 1>&2`, `() { … } 2>&1 1>/dev/null`).  Any other trailing
    // content (commands, pipes, etc.) indicates a CVE-2014-6271 style
    // injection and must be rejected.
    match end {
        None => false, // no closing `}` found
        Some(close) => is_trailing_whitespace_or_redirects(&bytes[close..]),
    }
}

/// Recognise whitespace optionally followed by one or more shell redirections.
/// Valid redirection forms:
///   [fd]<target         [fd]>target        [fd]>>target
///   [fd]<&[fd|-]        [fd]>&[fd|-]       [fd]<>target
///   [fd]>|target        &>target           &>>target
/// The target word must be a "safe" token: no shell metacharacters that
/// could introduce new commands (`;`, `|`, `&` without `>`, backticks,
/// `$(`, etc.).
fn is_trailing_whitespace_or_redirects(bytes: &[u8]) -> bool {
    let n = bytes.len();
    let mut i = 0;
    // Skip leading whitespace.
    while i < n && matches!(bytes[i], b' ' | b'\t' | b'\n' | b'\r') { i += 1; }
    while i < n {
        // Optional leading fd digits (for `1>`, `2>&1`, etc.)
        let start = i;
        while i < n && bytes[i].is_ascii_digit() { i += 1; }
        // Also accept `&>` / `&>>`
        if i == start && i < n && bytes[i] == b'&' && i + 1 < n && bytes[i + 1] == b'>' {
            i += 1;
        }
        // Require a redirect operator starting with `<` or `>`.
        if i >= n { return false; }
        match bytes[i] {
            b'<' | b'>' => {}
            _ => return false,
        }
        // Consume the operator: `<`, `<<`, `<<-`, `<&`, `<>`, `>`, `>>`, `>&`, `>|`
        let op_start = i;
        i += 1;
        if i < n {
            match bytes[i] {
                b'<' | b'>' | b'&' | b'|' => { i += 1; }
                _ => {}
            }
            // `<<-`
            if bytes[op_start] == b'<' && i - op_start == 2 && i < n && bytes[i] == b'-' {
                i += 1;
            }
        }
        // Optional whitespace between op and target
        while i < n && matches!(bytes[i], b' ' | b'\t') { i += 1; }
        // Consume the target word: accept digits, `-`, simple filename chars,
        // or the special `&-` / `-`.  Reject anything that could start a new
        // command.
        let target_start = i;
        while i < n {
            match bytes[i] {
                b' ' | b'\t' | b'\n' | b'\r' => break,
                // Characters that could begin a new command or introduce
                // substitution — reject.
                b';' | b'|' | b'&' | b'`' | b'(' | b')' | b'{' | b'}'
                | b'#' | b'$' | b'"' | b'\'' | b'\\' => return false,
                _ => { i += 1; }
            }
        }
        if i == target_start { return false; } // empty target
        // Skip whitespace / newlines between redirects
        while i < n && matches!(bytes[i], b' ' | b'\t' | b'\n' | b'\r') { i += 1; }
    }
    true
}
