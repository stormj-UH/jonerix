// Copyright (c) 2026 Jon-Erik G. Storm, Inc., a California Corporation,
// doing business as LAVA GOAT SOFTWARE. All rights reserved.
// Licensed under MIT.

//! # Module Invariant Ledger
//!
//! ## Structural Invariants
//! - INV-001: Word expansion follows POSIX order: brace → tilde → parameter/
//!   variable → arithmetic → command-substitution markers → word-splitting →
//!   pathname expansion. No phase runs before its predecessor. Functions whose
//!   names encode a phase (e.g., `expand_tilde`, `expand_braces`) must not
//!   invoke a later phase internally.
//! - INV-002: `CTLESC` (U+FDD0) is the sole quote-protection sentinel. Any
//!   character immediately following a `CTLESC` in a partially-expanded string
//!   is treated as quoted and is never split on IFS or matched as a glob
//!   metacharacter. `CTLESC` itself never appears in final output delivered to
//!   the user or to `execvp`; it is stripped by the finalization pass.
//! - INV-003: Raw bytes 0x80–0xFF (from `$'…'` ANSI-C escapes) are encoded as
//!   Unicode PUA codepoints U+F880–U+F8FF during expansion (base `RAW_BYTE_BASE`
//!   = 0xF800). These codepoints are decoded back to single bytes in `exec.rs`
//!   immediately before the `CString` passed to `execvp` is constructed. No
//!   PUA-encoded byte survives into any user-visible string (printed output,
//!   variable values, history entries).
//! - INV-004: Command-substitution markers (`\x00CMDSUB\x00`, `\x00QCMDSUB\x00`,
//!   and the FUNSUB / REPLYSUB variants) are NUL-delimited sentinel strings.
//!   They are placed into word tokens by the expander as placeholders and are
//!   resolved by `exec.rs` before the word reaches the argument vector. A marker
//!   never appears in a value read from or written to a variable.
//! - INV-005: `NO_SPLIT_CONTEXT` (thread-local) is set to `true` only while
//!   expanding a word that must not be field-split (e.g., inside `[[ … ]]` or
//!   an assignment RHS). It is always reset to its previous value before
//!   returning from any function that sets it.
//!
//! ## Safety Invariants
//! - SINV-001: `encode_raw_byte(0)` returns the NUL byte as a one-char string.
//!   Callers that build argument vectors must truncate strings at the first
//!   NUL, matching bash's C-string semantics. The expander itself does not
//!   truncate; truncation happens in `exec.rs` during `CString` construction.
//! - SINV-002: `preprocess_arith_quotes` returns `Cow::Borrowed` (no allocation)
//!   when the input contains neither `'` nor `"`. Callers must not mutate the
//!   returned value through the `Borrowed` variant.
//!
//! ## Performance Invariants
//! - PINV-001: `GLOB_SHOPTS` and `GLOB_RUNTIME` (defined in `exec.rs`) are
//!   thread-local caches that the pathname-expansion helpers read without
//!   holding a `Shell` reference. They must be written by the executor before
//!   any call path that reaches `pathname_expand` or `extglob_pathname_expand`.
//! - PINV-002: Brace expansion is short-circuited when the input word contains
//!   no `{` character. Tilde expansion is short-circuited when the word does
//!   not start with `~`. These fast paths must be preserved to avoid O(n)
//!   scanning in the common case of plain words.

//! expand.rs - Word expansion for the brash shell.
//!
//! Implements Bash-compatible word expansion in POSIX order:
//!   1. Brace expansion
//!   2. Tilde expansion
//!   3. Parameter / variable expansion
//!   4. Arithmetic expansion  $((expr))
//!   5. Command substitution  $(...) / `...`  (markers only – exec fills in)
//!   6. Process substitution  <(...) >(...)   (markers only)
//!   7. Word splitting
//!   8. Pathname expansion (globbing)
//!
//! This module exposes a library-style surface: many `pub fn` entry points
//! are kept as the canonical API for tests, future external callers, and
//! self-contained re-use even when no in-tree code currently calls them
//! (the executor often goes through a `_pub` wrapper or an internal helper
//! instead).  Suppress the dead-code lint at the module level with the
//! usual caveat: keep the set under control — if a fn is genuinely
//! abandoned, delete it rather than letting it rot here behind the allow.
#![allow(dead_code)]

use crate::vars::Variables;
use crate::arithmetic;

// ─────────────────────────────────────────────────────────────────────────────
// Raw-byte encoding for ANSI-C $'...' hex/octal escapes
//
// Bash stores strings as raw byte arrays (char*), so $'\xCD' is the single
// byte 0xCD.  Rush uses Rust `String` (must be valid UTF-8), so we cannot
// store 0xCD directly.  Instead we encode raw bytes 0x80-0xFF using Private
// Use Area codepoints: byte `b` is stored as U+F800+b.  The CString creation
// path (exec.rs) decodes them back to single bytes before passing to execvp.
//
// Byte 0x00 (NUL) is handled by truncating the string at that point (matching
// bash's C-string semantics).
// ─────────────────────────────────────────────────────────────────────────────

/// Base codepoint for raw-byte encoding in the Unicode PUA.
pub const RAW_BYTE_BASE: u32 = 0xF800;

/// Sentinel character used to mark the following character as "quoted"
/// so that word splitting does not treat it as an IFS delimiter.
/// U+FDD0 is a Unicode noncharacter specifically designated as
/// "not a character", so it will never appear in normal text.
pub const CTLESC: char = '\u{FDD0}';
pub const QCMDSUB_MARKER: &str = "\x00QCMDSUB\x00";
const CMDSUB_MARKER: &str = "\x00CMDSUB\x00";
pub const QFUNSUB_MARKER: &str = "\x00QFUNSUB\x00";
pub const FUNSUB_MARKER: &str = "\x00FUNSUB\x00";
pub const QREPLYSUB_MARKER: &str = "\x00QREPLYSUB\x00";
pub const REPLYSUB_MARKER: &str = "\x00REPLYSUB\x00";

/// Hard ceiling on recursive expansion depth (nested `${…}` default words,
/// `$(…)` markers, etc.).  Bash itself has no explicit limit — it relies on
/// the C stack — but a Rust program's default 8 MiB stack overflows at
/// roughly 3 000–5 000 levels of nesting.  1 024 is far beyond any
/// reasonable script while still leaving >75 % of the stack budget unused.
const EXPAND_RECURSION_LIMIT: usize = 1024;

thread_local! {
    static NO_SPLIT_CONTEXT: std::cell::Cell<bool> = std::cell::Cell::new(false);

    /// Current expansion recursion depth.  Incremented on entry to
    /// `expand_impl_full` and decremented on exit.  If this exceeds
    /// `EXPAND_RECURSION_LIMIT` the expander emits an error and returns
    /// the empty string rather than blowing the stack.
    static EXPAND_DEPTH: std::cell::Cell<usize> = std::cell::Cell::new(0);
}

/// Encode a raw byte (0-255) into a string.
/// - 0x00: returns empty string (caller should truncate)
/// - 0x01-0x7F: plain ASCII character
/// - 0x80-0xFF: PUA-encoded codepoint U+F800+b
pub fn encode_raw_byte(b: u8) -> String {
    if b == 0 {
        "\0".to_string()
    } else if b < 0x80 {
        (b as char).to_string()
    } else {
        // PROVEN: RAW_BYTE_BASE is 0xF800 and b is 0x80..=0xFF, so the sum is
        // 0xF880..=0xF8FF, all valid Unicode Private Use Area codepoints.
        char::from_u32(RAW_BYTE_BASE + b as u32).unwrap().to_string()
    }
}

/// Encode a raw byte slice into brash's internal string form.
pub fn encode_raw_bytes(bytes: &[u8]) -> String {
    let mut out = String::new();
    for &b in bytes {
        out.push_str(&encode_raw_byte(b));
    }
    out
}

fn current_locale_codeset() -> Option<String> {
    let locale = std::env::var("LC_ALL").ok().filter(|s| !s.is_empty())
        .or_else(|| std::env::var("LC_CTYPE").ok().filter(|s| !s.is_empty()))
        .or_else(|| std::env::var("LANG").ok().filter(|s| !s.is_empty()))?;
    if locale == "C" || locale == "POSIX" {
        return Some("US-ASCII".to_string());
    }
    let codeset = locale.split('.').nth(1).unwrap_or(locale.as_str());
    let codeset = codeset.split('@').next().unwrap_or(codeset);
    if codeset.is_empty() {
        None
    } else {
        Some(codeset.to_string())
    }
}

fn encode_legacy_utf8(code: u32) -> Option<Vec<u8>> {
    if code <= 0x7f {
        return Some(vec![code as u8]);
    }
    if code <= 0x7ff {
        return Some(vec![
            (0xc0 | ((code >> 6) & 0x1f)) as u8,
            (0x80 | (code & 0x3f)) as u8,
        ]);
    }
    if code <= 0xffff {
        return Some(vec![
            (0xe0 | ((code >> 12) & 0x0f)) as u8,
            (0x80 | ((code >> 6) & 0x3f)) as u8,
            (0x80 | (code & 0x3f)) as u8,
        ]);
    }
    if code <= 0x1f_ffff {
        return Some(vec![
            (0xf0 | ((code >> 18) & 0x07)) as u8,
            (0x80 | ((code >> 12) & 0x3f)) as u8,
            (0x80 | ((code >> 6) & 0x3f)) as u8,
            (0x80 | (code & 0x3f)) as u8,
        ]);
    }
    if code <= 0x3ff_ffff {
        return Some(vec![
            (0xf8 | ((code >> 24) & 0x03)) as u8,
            (0x80 | ((code >> 18) & 0x3f)) as u8,
            (0x80 | ((code >> 12) & 0x3f)) as u8,
            (0x80 | ((code >> 6) & 0x3f)) as u8,
            (0x80 | (code & 0x3f)) as u8,
        ]);
    }
    if code <= 0x7fff_ffff {
        return Some(vec![
            (0xfc | ((code >> 30) & 0x01)) as u8,
            (0x80 | ((code >> 24) & 0x3f)) as u8,
            (0x80 | ((code >> 18) & 0x3f)) as u8,
            (0x80 | ((code >> 12) & 0x3f)) as u8,
            (0x80 | ((code >> 6) & 0x3f)) as u8,
            (0x80 | (code & 0x3f)) as u8,
        ]);
    }
    None
}

fn locale_unit_len(bytes: &[u8], i: usize, codeset: &str) -> usize {
    if i >= bytes.len() {
        return 0;
    }
    if bytes[i] < 0x80 {
        return 1;
    }
    if codeset.eq_ignore_ascii_case("BIG5") || codeset.eq_ignore_ascii_case("BIG-5") {
        if i + 1 < bytes.len() && (0x81..=0xFE).contains(&bytes[i]) {
            return 2;
        }
        return 1;
    }
    if codeset.eq_ignore_ascii_case("UTF-8") || codeset.eq_ignore_ascii_case("UTF8") {
        let len = if bytes[i] < 0xC0 {
            1
        } else if bytes[i] < 0xE0 {
            2
        } else if bytes[i] < 0xF0 {
            3
        } else if bytes[i] < 0xF8 {
            4
        } else if bytes[i] < 0xFC {
            5
        } else if bytes[i] < 0xFE {
            6
        } else {
            1
        };
        if i + len > bytes.len() {
            return 1;
        }
        for j in 1..len {
            if bytes[i + j] < 0x80 || bytes[i + j] >= 0xC0 {
                return 1;
            }
        }
        return len;
    }
    1
}

pub(crate) fn locale_units(s: &str, codeset: &str) -> Vec<String> {
    let bytes = decode_raw_bytes(s);
    let mut units = Vec::new();
    let mut i = 0usize;
    while i < bytes.len() {
        let len = locale_unit_len(&bytes, i, codeset).max(1);
        units.push(encode_raw_bytes(&bytes[i..(i + len).min(bytes.len())]));
        i += len;
    }
    units
}

// libc-rs marks iconv_open / iconv / iconv_close as deprecated in 0.2 ahead
// of dropping them in 1.0 (the `iconv` symbol is splitting off into its own
// crate).  Until that crate exists we still need them here for $LC_CTYPE
// codepoint encoding, so silence the per-call deprecation warning at the
// fn boundary.
#[allow(deprecated)]
pub(crate) fn encode_locale_codepoint(code: u32) -> String {
    let Some(codeset) = current_locale_codeset() else {
        return char::from_u32(code).map(|c| c.to_string()).unwrap_or_default();
    };
    if codeset.eq_ignore_ascii_case("UTF-8") || codeset.eq_ignore_ascii_case("UTF8") {
        if let Some(bytes) = encode_legacy_utf8(code) {
            return encode_raw_bytes(&bytes);
        }
        return String::new();
    }

    let Some(ch) = char::from_u32(code) else {
        return String::new();
    };
    let utf8 = ch.to_string();
    let Ok(to_code) = std::ffi::CString::new(codeset) else {
        return utf8;
    };
    let Ok(from_code) = std::ffi::CString::new("UTF-8") else {
        return utf8;
    };
    // SAFETY:
    // - `to_code` and `from_code` are valid NUL-terminated C strings (from CString).
    // - `iconv_open` returns a conversion descriptor or (iconv_t)-1 on failure; we
    //   check for the -1 sentinel and return early before using the descriptor.
    // - `in_ptr` points into `input` (a heap Vec<u8>) kept alive for this block;
    //   `iconv` updates `in_ptr` and `in_left` in place — both are live for the call.
    // - `out_ptr` points into `output` (a 16-byte stack array); `out_left` starts at
    //   `output.len()` so iconv cannot write past the array.
    // - `iconv_close(cd)` is called exactly once after `iconv_open` succeeds,
    //   releasing the conversion descriptor before any return path.
    unsafe {
        let cd = libc::iconv_open(to_code.as_ptr(), from_code.as_ptr());
        if cd as isize == -1 {
            return utf8;
        }
        let mut input = utf8.into_bytes();
        let mut in_ptr = input.as_mut_ptr() as *mut libc::c_char;
        let mut in_left = input.len();
        let mut output = [0u8; 16];
        let mut out_ptr = output.as_mut_ptr() as *mut libc::c_char;
        let mut out_left = output.len();
        let res = libc::iconv(cd, &mut in_ptr, &mut in_left, &mut out_ptr, &mut out_left);
        libc::iconv_close(cd);
        if res == usize::MAX {
            return input.into_iter().map(|b| encode_raw_byte(b)).collect();
        }
        let written = output.len() - out_left;
        let mut out = String::new();
        for &b in &output[..written] {
            out.push_str(&encode_raw_byte(b));
        }
        out
    }
}

pub(crate) fn encode_locale_char(ch: char) -> String {
    encode_locale_codepoint(ch as u32)
}

/// Decode PUA-encoded raw bytes back to actual bytes for system calls.
/// Characters in U+F800..U+F8FF are converted to the corresponding byte.
/// All other characters are encoded as UTF-8 as normal.
pub fn decode_raw_bytes(s: &str) -> Vec<u8> {
    let mut out = Vec::with_capacity(s.len());
    for ch in s.chars() {
        let cp = ch as u32;
        if cp >= RAW_BYTE_BASE && cp <= RAW_BYTE_BASE + 0xFF {
            out.push((cp - RAW_BYTE_BASE) as u8);
        } else {
            let mut buf = [0u8; 4];
            let encoded = ch.encode_utf8(&mut buf);
            out.extend_from_slice(encoded.as_bytes());
        }
    }
    out
}

/// Count multibyte characters in a string that may contain PUA-encoded raw
/// bytes (from `$'\x..'` / octal escapes).  This is used to implement
/// bash's `${#var}` semantics under a UTF-8 locale: bash reports the
/// character count (number of wchar_t), not the byte count.
///
/// Algorithm: decode PUA bytes back to their raw form, then count UTF-8
/// scalar values.  Sequences that are invalid UTF-8 contribute one
/// "character" per unparseable byte, matching bash fallback behaviour
/// when mbrtowc returns (size_t)-1.
pub fn mb_char_count(s: &str) -> usize {
    // Fast path: if the string has no PUA bytes, we can count chars directly.
    if !s.chars().any(|c| {
        let cp = c as u32;
        cp >= RAW_BYTE_BASE && cp <= RAW_BYTE_BASE + 0xFF
    }) {
        return s.chars().count();
    }
    let bytes = decode_raw_bytes(s);
    count_mb_chars_bytes(&bytes)
}

/// Count UTF-8 scalar values in a byte slice, treating each invalid
/// byte as one character (bash fallback behaviour).
pub fn count_mb_chars_bytes(bytes: &[u8]) -> usize {
    let mut count = 0usize;
    let mut i = 0usize;
    while i < bytes.len() {
        let b = bytes[i];
        let len = if b < 0x80 {
            1
        } else if b < 0xC0 {
            // Orphan continuation byte: treat as 1 char.
            1
        } else if b < 0xE0 {
            2
        } else if b < 0xF0 {
            3
        } else if b < 0xF8 {
            4
        } else {
            1
        };
        if i + len > bytes.len() {
            // Truncated sequence: treat remaining bytes individually.
            count += bytes.len() - i;
            break;
        }
        // Verify continuation bytes are 0x80..=0xBF; if not, treat leading
        // byte as single-byte char and advance by 1.
        let mut ok = true;
        for j in 1..len {
            if bytes[i + j] < 0x80 || bytes[i + j] >= 0xC0 {
                ok = false;
                break;
            }
        }
        if ok {
            count += 1;
            i += len;
        } else {
            count += 1;
            i += 1;
        }
    }
    count
}

// ─────────────────────────────────────────────────────────────────────────────
// Public API
// ─────────────────────────────────────────────────────────────────────────────

/// Expand a word, performing all expansions.
/// If `split` is true the result is split on IFS and globbed.
pub fn expand_word(word: &str, vars: &mut Variables, split: bool) -> Vec<String> {
    // Step 1 – brace expansion (only in unquoted context)
    let brace_expanded = brace_expand(word);

    let mut fields: Vec<String> = Vec::new();
    for token in &brace_expanded {
        // Step 2+3+4+5 – tilde / param / arith / cmd substitution
        let will_split = split && has_expansion_chars(token) && !is_fully_quoted(token);
        let expanded = if will_split {
            expand_all_for_split(token, vars)
        } else {
            expand_all(token, vars)
        };

        if will_split {
            // Step 7 – word splitting (only on results of unquoted expansions)
            let ifs = vars.get("IFS").unwrap_or_else(|| " \t\n".to_string());
            let split_fields = word_split(&expanded, &ifs);

            // Bash rule: if the word contains ANY quoted portion, even
            // empty (\`$x\"\"\` with x unset), the result is ONE
            // empty-string field — not zero fields.  Ordinary unquoted
            // empty expansions (\`$x\`) collapse to zero fields.
            if split_fields.is_empty() && word_has_quoting(token) {
                fields.push(String::new());
            } else {
                // Step 8 – pathname expansion
                for field in split_fields {
                    let globbed = pathname_expand(&field);
                    fields.extend(globbed);
                }
            }
        } else if split && !is_fully_quoted(token) {
            // No expansions — still do pathname expansion but not word splitting
            let globbed = pathname_expand(&expanded);
            fields.extend(globbed);
        } else {
            fields.push(expanded);
        }
    }

    if fields.is_empty() && split {
        // Expansion that produced only empty string after splitting → no fields
        return Vec::new();
    }
    // Clean any QNULL markers and CTLESC quote-escape markers that leaked through
    for f in &mut fields {
        if f.contains("\x00QNULL\x00") {
            *f = f.replace("\x00QNULL\x00", "");
        }
        if f.contains(CTLESC) {
            *f = f.replace(CTLESC, "");
        }
    }
    fields
}

/// Check if word is fully enclosed in quotes (single or double or $'...').
/// Simple heuristic: starts with quote and ends with matching quote.
#[inline]
pub fn is_fully_quoted(word: &str) -> bool {
    let bytes = word.as_bytes();
    if bytes.len() < 2 { return false; }
    if (bytes[0] == b'"' && bytes[bytes.len() - 1] == b'"') ||
       (bytes[0] == b'\'' && bytes[bytes.len() - 1] == b'\'') {
        return true;
    }
    // $'...' ANSI-C quoting
    if bytes.len() >= 3 && bytes[0] == b'$' && bytes[1] == b'\'' && bytes[bytes.len() - 1] == b'\'' {
        return true;
    }
    false
}

/// Check if a word contains unquoted expansion characters ($, `, etc.)
/// Check if a word contains unquoted expansion characters (`$`, `` ` ``).
/// All relevant characters are single-byte ASCII, so we scan the raw byte
/// slice directly — no `Vec<char>` allocation on the hot path.
#[inline]
pub fn has_expansion_chars(word: &str) -> bool {
    let bytes = word.as_bytes();
    let mut i = 0;
    let mut in_sq = false;
    while i < bytes.len() {
        let b = bytes[i];
        if in_sq {
            if b == b'\'' { in_sq = false; }
            i += 1;
            continue;
        }
        match b {
            b'\'' => { in_sq = true; }
            b'\\' => { i += 1; } // skip escaped char
            b'$' | b'`' => return true,
            _ => {}
        }
        i += 1;
    }
    false
}

/// Expand a word to a single string with no word splitting or glob.
/// Used for assignments, here-docs, redirect targets, etc.
pub fn expand_word_nosplit(word: &str, vars: &mut Variables) -> String {
    expand_word_nosplit_ctx(word, vars, false)
}

/// Like `expand_word_nosplit` but for assignment-value contexts where tilde
/// after `:` and `=` should always be expanded (even in POSIX mode).
pub fn expand_word_nosplit_assign(word: &str, vars: &mut Variables) -> String {
    expand_word_nosplit_ctx(word, vars, true)
}

pub fn expand_word_nosplit_assign_passwd(word: &str, vars: &mut Variables) -> String {
    expand_word_nosplit_ctx_with_mode(word, vars, TildeMode::AssignValuePasswd)
}

fn expand_word_nosplit_ctx(word: &str, vars: &mut Variables, assignment_ctx: bool) -> String {
    let mode = if assignment_ctx {
        TildeMode::AssignValue
    } else {
        TildeMode::Normal
    };
    expand_word_nosplit_ctx_with_mode(word, vars, mode)
}

fn expand_word_nosplit_ctx_with_mode(word: &str, vars: &mut Variables, tilde_mode: TildeMode) -> String {
    // Brace expansion is still performed in most contexts, but the result is
    // joined (it rarely matters for single-string contexts; bash does expand
    // braces even for assignments in some cases).  We join with a space to
    // preserve the distinction then do full expansion on each piece.
    let brace_expanded = brace_expand(word);
    let mut parts: Vec<String> = Vec::with_capacity(brace_expanded.len());
    NO_SPLIT_CONTEXT.with(|flag| {
        let old = flag.replace(true);
        for t in &brace_expanded {
            let expanded = match tilde_mode {
                TildeMode::AssignValue => expand_all_assign(t, vars),
                TildeMode::AssignValuePasswd => expand_all_assign_passwd(t, vars),
                _ => expand_all(t, vars),
            };
            parts.push(expanded);
        }
        flag.set(old);
    });
    let result = parts.join(" ");
    let result = result.replace("\x00QNULL\x00", "");
    let result = result.replace(CTLESC, "");
    // In no-split contexts (`foo=$@`, heredocs, etc.), \u{FFFE}/\u{FFFF}
    // markers from $@ / ${A[@]} should join with a plain space —
    // bash uses space here regardless of IFS.  ($* / ${A[*]} already
    // produce the joined string directly and never use these markers.)
    let result = result.replace('\u{FFFE}', " ");
    result.replace('\u{FFFF}', " ")
}

/// Expand a heredoc body: only `$var`, `${var}`, `$(cmd)`, backtick
/// substitution, and backslash escaping of `$`, `\`, and `` ` `` are performed.
/// Single and double quotes are treated as literal characters.
pub fn expand_heredoc(body: &str, vars: &mut Variables) -> String {
    let chars: Vec<char> = body.chars().collect();
    let n = chars.len();
    let mut out = String::new();
    let mut i = 0;
    while i < n {
        let ch = chars[i];
        // Backslash: only special in heredocs before $, \, `, and newline
        if ch == '\\' && i + 1 < n {
            let next = chars[i + 1];
            match next {
                '$' | '\\' | '`' => {
                    out.push(next);
                    i += 2;
                    continue;
                }
                '\n' => {
                    // line continuation
                    i += 2;
                    continue;
                }
                _ => {
                    // Not special: keep the backslash
                    out.push('\\');
                    i += 1;
                    continue;
                }
            }
        }
        // Dollar: expand variables, command subs, arithmetic
        if ch == '$' {
            let (expanded, consumed) = expand_dollar(&chars, i, vars, false, true);
            // If any expansion inside a heredoc hits a bad/nounset error,
            // abandon the heredoc content (error message was already printed
            // to stderr by expand_param_raw).  Bash aborts the heredoc body
            // and runs the command (cat) with empty stdin → no output.
            if expanded.contains("\x00EXPAND_ERROR\x00") || expanded.contains("\x00NOUNSET_ERROR\x00") {
                return String::new();
            }
            out.push_str(&expanded);
            i += consumed;
            continue;
        }
        // Backtick command substitution
        if ch == '`' {
            let start = i + 1;
            let mut j = start;
            while j < n && chars[j] != '`' {
                if chars[j] == '\\' && j + 1 < n { j += 1; }
                j += 1;
            }
            let body_str: String = chars[start..j].iter().collect();
            let marker = format!("\x00CMDSUB\x00{}\x00", body_str);
            out.push_str(&marker);
            i = if j < n { j + 1 } else { j };
            continue;
        }
        // All other characters including " and ' are literal
        out.push(ch);
        i += 1;
    }
    out
}

/// Perform tilde expansion only (no other expansions).
pub fn expand_tilde(word: &str, vars: &Variables) -> String {
    do_tilde_expand(word, vars)
}

/// Perform tilde expansion on the value side of an assignment: tilde
/// at the start and after each `:` is expanded (bash assignment-value
/// tilde rules).  Matches what bash does for `foo=~/a:~/b`.
pub fn expand_tilde_assign_value(word: &str, vars: &Variables) -> String {
    // Only split on unquoted `:`.  Quotes block tilde expansion entirely.
    if word.contains('"') || word.contains('\'') {
        // Simpler: tilde-expand just the leading `~` if present.
        return do_tilde_expand(word, vars);
    }
    let parts: Vec<&str> = word.split(':').collect();
    let expanded: Vec<String> = parts.iter()
        .map(|p| do_tilde_expand(p, vars))
        .collect();
    expanded.join(":")
}

/// Perform tilde expansion for associative-array assignment keys/values.
/// Bash uses passwd-home semantics here instead of preferring the shell's
/// current HOME variable.
pub fn expand_tilde_assoc_assign(word: &str, vars: &Variables) -> String {
    if word.contains('"') || word.contains('\'') {
        return do_tilde_expand_with_policy(word, vars, false);
    }
    let parts: Vec<&str> = word.split(':').collect();
    let expanded: Vec<String> = parts.iter()
        .map(|p| do_tilde_expand_with_policy(p, vars, false))
        .collect();
    expanded.join(":")
}

/// Expand a word, then perform glob / pathname expansion on each field.
pub fn expand_word_glob(word: &str, vars: &mut Variables) -> Vec<String> {
    expand_word(word, vars, true)
}

/// Expand a pattern for `case` matching: variable expansion but no word
/// splitting and no glob interpretation.
pub fn expand_pattern(word: &str, vars: &mut Variables) -> String {
    // No brace expansion for patterns; just param + arith expansion.
    expand_impl(word, vars, TildeMode::Normal, false)
}

/// Expand a case pattern word for `case` matching.
///
/// Rules (matching bash behaviour):
///   - Variable/arithmetic/command-substitution expansions are performed.
///   - Unquoted backslash sequences (\x) are preserved as-is so that the
///     downstream fnmatch engine can interpret them as glob-level escapes.
///   - Single-quoted content has glob metacharacters (* ? [ \) escaped so the
///     fnmatch engine sees them as literals.
///   - Inside double-quotes, variable expansions are performed and the resulting
///     characters have glob metacharacters escaped with `\`.
///   - Unquoted variable expansions pass through unchanged (the value may itself
///     contain glob metacharacters like * and ? that should remain active).
pub fn expand_case_pattern(word: &str, vars: &mut Variables) -> String {
    expand_pattern_word(word, vars, false)
}

/// Expand a glob pattern and immediately resolve any command-substitution
/// markers left by `expand_case_pattern`.  Used by `${var#pat}`,
/// `${var//pat/repl}`, and related parameter-expansion operators where the
/// pattern is built and consumed in the same `expand_param_raw` call (there
/// is no subsequent `resolve_cmdsubs` call on the returned value).
///
/// Two marker variants are handled:
///
/// * `CMDSUB_MARKER` — unquoted command substitution (e.g. `` `cmd` `` or
///   `$(cmd)` outside double-quotes).  The command output is inserted as-is;
///   any glob metacharacters in the output are active pattern elements.
///
/// * `QCMDSUB_MARKER` — double-quoted command substitution (e.g. `"`cmd`"`).
///   The command output is treated as a literal string fragment: every glob
///   metacharacter (`*`, `?`, `[`, `\`) is backslash-escaped so the glob
///   engine matches it literally.
fn expand_case_pattern_for_patsub(word: &str, vars: &mut Variables) -> String {
    let pat = expand_pattern_word(word, vars, false);
    // Fast path: no NUL bytes means no CMDSUB/QCMDSUB markers.
    if !pat.contains('\x00') {
        return pat;
    }
    // Walk the pattern, resolving each marker segment in turn.
    let mut out = String::with_capacity(pat.len());
    let mut rest = pat.as_str();
    loop {
        // Find the earliest CMDSUB or QCMDSUB marker.
        let plain_pos = rest.find("\x00CMDSUB\x00");
        let quoted_pos = rest.find(QCMDSUB_MARKER);
        const PLAIN_MARKER: &str = "\x00CMDSUB\x00";
        let (start, is_quoted, marker_len) = match (plain_pos, quoted_pos) {
            (None, None) => break,
            (Some(p), None) => (p, false, PLAIN_MARKER.len()),
            (None, Some(q)) => (q, true,  QCMDSUB_MARKER.len()),
            (Some(p), Some(q)) => {
                if p <= q { (p, false, PLAIN_MARKER.len()) }
                else      { (q, true,  QCMDSUB_MARKER.len()) }
            }
        };
        out.push_str(&rest[..start]);
        let after_marker = &rest[start + marker_len..];
        let Some(end) = after_marker.find('\x00') else {
            // Malformed marker — pass through verbatim.
            out.push_str(&rest[start..]);
            rest = "";
            break;
        };
        let body = &after_marker[..end];
        // Execute the command substitution body.
        let marker = format!("\x00CMDSUB\x00{body}\x00");
        let result = crate::exec::resolve_cmdsubs_for_expand(&marker, vars);
        if is_quoted {
            // Quoted comsub: the output is literal — escape glob metacharacters
            // so the glob engine treats them as ordinary characters.
            for gc in result.chars() {
                if matches!(gc, '*' | '?' | '[' | '\\') {
                    out.push('\\');
                }
                out.push(gc);
            }
        } else {
            // Unquoted comsub: the output IS the pattern fragment.
            out.push_str(&result);
        }
        rest = &after_marker[end + 1..];
    }
    out.push_str(rest);
    out
}

/// Expand a regex pattern for `[[ STR =~ PATTERN ]]`.  Same as
/// `expand_case_pattern` but escapes ERE regex metacharacters for
/// quoted portions (bash's "quoted regex is literal" rule).
pub fn expand_regex_pattern(word: &str, vars: &mut Variables) -> String {
    expand_pattern_word(word, vars, true)
}

fn expand_pattern_word(word: &str, vars: &mut Variables, regex_mode: bool) -> String {
    // When regex_mode is on, quoted characters have ERE metacharacters
    // escaped (. + ( ) { } | ^ $ plus the usual * ? [ \).  Otherwise
    // only glob metachars (* ? [ \) are escaped.  This lets bash's
    // `[[ \$str =~ "\$pat" ]]` treat the quoted pattern as literal.
    //
    // Inside a regex character class `[...]`, most metacharacters are
    // literal by default — don't double-escape them.
    let regex_metas = |c: char| -> bool {
        matches!(c, '*' | '?' | '[' | '\\' | '.' | '+' | '(' | ')'
            | '{' | '}' | '|' | '^' | '$')
    };
    let regex_metas_in_class = |_c: char| -> bool {
        // Inside a regex character class `[...]`, chars are literal by
        // position — no metachars need backslash escape.  `]` is a
        // terminator but backslash-escaping it in POSIX ERE is wrong
        // (POSIX treats `\` as literal inside brackets); if a user
        // wants a literal `]` they put it right after `[` or `[^`.
        //
        // We leave it to the regex engine to interpret the class
        // contents as the user wrote them.
        false
    };
    let glob_metas = |c: char| -> bool {
        matches!(c, '*' | '?' | '[' | '\\')
    };
    let chars: Vec<char> = word.chars().collect();
    let n = chars.len();
    let mut out = String::new();
    let mut i = 0;
    let mut in_dquote = false;
    // Track nesting inside a regex character class `[...]` so quoted
    // metacharacters inside the class aren't over-escaped.
    let mut regex_class_depth: usize = 0;
    let should_escape = |c: char, class_depth: usize| -> bool {
        if regex_mode {
            if class_depth > 0 { regex_metas_in_class(c) } else { regex_metas(c) }
        } else {
            glob_metas(c)
        }
    };

    while i < n {
        let ch = chars[i];

        // ── ANSI-C quoting $'...' ─────────────────────────────────────────────
        if ch == '$' && i + 1 < n && chars[i + 1] == '\'' && !in_dquote {
            i += 2;
            let mut hit_nul = false;
            while i < n && chars[i] != '\'' {
                let (c, advance) = parse_ansi_escape(&chars, i);
                i += advance;
                // NUL byte truncates (bash C-string semantics)
                if c.contains('\0') {
                    for gc in c.chars() {
                        if gc == '\0' { hit_nul = true; break; }
                        if should_escape(gc, regex_class_depth) {
                            out.push('\\');
                        }
                        out.push(gc);
                    }
                    break;
                }
                // Literal content from $'...' — escape glob metacharacters
                for gc in c.chars() {
                    if should_escape(gc, regex_class_depth) {
                        out.push('\\');
                    }
                    out.push(gc);
                }
            }
            if hit_nul {
                // Skip rest of $'...' content
                while i < n && chars[i] != '\'' { i += 1; }
            }
            if i < n { i += 1; } // consume closing '
            continue;
        }

        // ── Single quotes ────────────────────────────────────────────────────
        if ch == '\'' && !in_dquote {
            i += 1;
            while i < n && chars[i] != '\'' {
                let gc = chars[i];
                // Literal content — escape glob metacharacters
                if should_escape(gc, regex_class_depth) {
                    out.push('\\');
                }
                out.push(gc);
                i += 1;
            }
            if i < n { i += 1; } // consume closing '
            continue;
        }

        // ── Locale-translated double quotes  $"..." ──────────────────────────
        // For pattern words, bash treats $"..." like an ordinary double-quoted
        // string. We don't perform locale lookup here; we only apply the
        // double-quote quoting rules and drop the leading `$`.
        if ch == '$' && i + 1 < n && chars[i + 1] == '"' && !in_dquote {
            in_dquote = true;
            i += 2;
            continue;
        }

        // ── Double-quote open / close ─────────────────────────────────────────
        if ch == '"' {
            in_dquote = !in_dquote;
            i += 1;
            continue;
        }

        // ── Backslash ─────────────────────────────────────────────────────────
        if ch == '\\' {
            if in_dquote {
                // Inside double quotes: backslash is special before $ ` \ " newline
                i += 1;
                if i >= n { out.push('\\'); break; }
                let next = chars[i];
                match next {
                    '$' | '`' | '\\' | '"' | '\n' => {
                        if next != '\n' {
                            // Literal char from dquote backslash escape
                            if should_escape(next, regex_class_depth) {
                                out.push('\\');
                            }
                            out.push(next);
                        }
                        i += 1;
                    }
                    _ => {
                        // Not special in dquote — keep both chars literal.
                        // In pattern context (regex or glob), the `\` itself
                        // is a metachar and must be escaped so the matcher
                        // treats it as a literal backslash, not an escape.
                        if should_escape('\\', regex_class_depth) {
                            out.push('\\'); // escape the backslash itself
                        }
                        out.push('\\');
                        // The following char is literal; escape if it's a metaChar.
                        if should_escape(next, regex_class_depth) {
                            out.push('\\');
                        }
                        out.push(next);
                        i += 1;
                    }
                }
            } else {
                // Unquoted: preserve the backslash as a glob-level escape
                i += 1;
                if i >= n {
                    out.push('\\');
                    break;
                }
                let next = chars[i];
                if next == '\n' {
                    // Line continuation — swallow both
                    i += 1;
                } else if regex_mode && regex_class_depth > 0 {
                    // Inside a regex character class `[...]`, bash treats
                    // `\X` as literal X (the `\` is consumed).  This is
                    // bash-specific — POSIX ERE leaves the `\` literal —
                    // but it matches what `[[ $s =~ [\.] ]]` does in bash.
                    out.push(next);
                    i += 1;
                } else {
                    // Preserve \x verbatim for the pattern matcher
                    out.push('\\');
                    out.push(next);
                    i += 1;
                }
            }
            continue;
        }

        // ── $ expansions ──────────────────────────────────────────────────────
        if ch == '$' {
            let (expanded, advance) = expand_dollar(&chars, i, vars, in_dquote, false);
            if in_dquote {
                // Inside double quotes: escape glob metacharacters in the expanded value
                for gc in expanded.chars() {
                    if should_escape(gc, regex_class_depth) {
                        out.push('\\');
                    }
                    out.push(gc);
                }
            } else {
                // Unquoted: pass the variable value through as-is.
                // The value may contain * ? [ \ which act as glob metacharacters.
                out.push_str(&expanded);
            }
            i += advance;
            continue;
        }

        // ── Backtick command substitution ─────────────────────────────────────
        if ch == '`' {
            let (body, advance) = collect_backtick(&chars, i + 1);
            // Use QCMDSUB_MARKER when inside double-quotes so that the patsub
            // resolver knows to glob-escape the command output (making it a
            // literal fragment of the pattern).  Plain CMDSUB_MARKER is used
            // for unquoted backticks where the output is itself a glob pattern.
            if in_dquote {
                out.push_str(&format!("{QCMDSUB_MARKER}{}\x00", body));
            } else {
                out.push_str(&format!("\x00CMDSUB\x00{}\x00", body));
            }
            i += advance + 1;
            continue;
        }

        // ── Tilde expansion (at start of pattern, unquoted) ──────────────────
        if ch == '~' && !in_dquote && i == 0 {
            // Collect the tilde prefix up to '/' or end
            let tilde_start = i;
            i += 1;
            let mut tilde_valid = true;
            while i < n && chars[i] != '/' && chars[i] != ':' && chars[i] != '=' {
                if chars[i] == '\'' || chars[i] == '"' || chars[i] == '$' || chars[i] == '\\' {
                    tilde_valid = false;
                    break;
                }
                i += 1;
            }
            if tilde_valid {
                let tilde_token: String = chars[tilde_start..i].iter().collect();
                let expanded = do_tilde_expand_with_policy(&tilde_token, vars, false);
                // Escape glob metacharacters in the expanded value so they
                // match literally.
                for gc in expanded.chars() {
                    if matches!(gc, '*' | '?' | '[' | '\\') {
                        out.push('\\');
                    }
                    out.push(gc);
                }
            } else {
                out.push('~');
                i = tilde_start + 1;
            }
            continue;
        }

        // ── Regex character class tracking (regex_mode only) ─────────────────
        // Track unescaped, unquoted `[...]` boundaries so characters inside
        // a regex character class don't get over-escaped.
        if regex_mode && !in_dquote {
            if ch == '[' {
                // Opening a char class.  In ERE you can nest POSIX brackets
                // like [[:alpha:]] — treat as same class.
                regex_class_depth = regex_class_depth.saturating_add(1);
                out.push(ch);
                i += 1;
                // POSIX: a `]` right after `[` (or `[^`) is a literal `]`,
                // not the terminator.  Accept either `[]` or `[^]` here and
                // emit that `]` as literal content before resuming class
                // tracking.
                if i < n && chars[i] == '^' {
                    out.push('^');
                    i += 1;
                }
                if i < n && chars[i] == ']' {
                    out.push(']');
                    i += 1;
                }
                continue;
            }
            if ch == ']' && regex_class_depth > 0 {
                regex_class_depth -= 1;
                out.push(ch);
                i += 1;
                continue;
            }
        }

        // ── Ordinary character ─────────────────────────────────────────────────
        // Inside `"..."` in a pattern context, glob metachars are literal
        // and must be escaped so the matcher treats them as such.
        if in_dquote && should_escape(ch, regex_class_depth) {
            out.push('\\');
        }
        out.push(ch);
        i += 1;
    }

    out
}

fn is_quoted_glob_literal(c: char) -> bool {
    matches!(c, '*' | '?' | '[' | '\\')
}

fn push_literal_char(
    out: &mut String,
    c: char,
    ifs_chars: Option<&str>,
    mark_glob_literal: bool,
    mark_patsub_literal: bool,
) {
    if ifs_chars.map(|ifs| ifs.contains(c)).unwrap_or(false)
        || (mark_glob_literal && is_quoted_glob_literal(c))
        || (mark_patsub_literal && matches!(c, '&' | '\\'))
    {
        out.push(CTLESC);
    }
    out.push(c);
}

// ─────────────────────────────────────────────────────────────────────────────
// Brace expansion
// ─────────────────────────────────────────────────────────────────────────────

/// Expand brace expressions in `word` and return the list of resulting tokens.
/// Handles:
///   {a,b,c}               → ["a", "b", "c"]
///   {1..5}                → ["1", "2", "3", "4", "5"]
///   {01..05}              → ["01", "02", "03", "04", "05"]
///   {a..z}                → ["a", "b", …, "z"]
///   {1..10..2}            → ["1", "3", "5", "7", "9"]  (with increment)
///   prefix{…}suffix       → prefix applied to each element
///   nested {a,{b,c}}      → flattened
pub fn brace_expand(word: &str) -> Vec<String> {
    let chars: Vec<char> = word.chars().collect();
    let results = brace_expand_chars(&chars);
    if results.is_empty() {
        vec![word.to_string()]
    } else {
        results
    }
}

fn brace_expand_chars(chars: &[char]) -> Vec<String> {
    // Find the first unquoted `{`
    let mut i = 0;
    let n = chars.len();
    while i < n {
        if chars[i] == '\\' {
            i += 2;
            continue;
        }
        if chars[i] == '\'' {
            i += 1;
            while i < n && chars[i] != '\'' {
                i += 1;
            }
            i += 1;
            continue;
        }
        if chars[i] == '"' {
            i += 1;
            while i < n && chars[i] != '"' {
                if chars[i] == '\\' {
                    i += 1;
                }
                i += 1;
            }
            i += 1;
            continue;
        }
        // Skip $() and $(()) command/arithmetic substitution
        if chars[i] == '$' && i + 1 < n && chars[i + 1] == '(' {
            i = skip_dollar_paren(chars, i);
            continue;
        }
        // Skip ${...} parameter expansion – commas inside are not brace expansion
        if chars[i] == '$' && i + 1 < n && chars[i + 1] == '{' {
            i = skip_dollar_brace(chars, i);
            continue;
        }
        // Skip backtick command substitution
        if chars[i] == '`' {
            i = skip_backtick(chars, i);
            continue;
        }
        if chars[i] == '{' {
            // Try to find matching `}`
            if let Some((items, close)) = parse_brace_body(chars, i + 1) {
                let prefix: String = chars[..i].iter().collect();
                let suffix: String = chars[close + 1..].iter().collect();

                // Expand prefix and suffix recursively
                let prefix_parts = brace_expand_chars(&chars[..i]);
                let suffix_parts = brace_expand_chars(&chars[close + 1..]);

                let prefix_list = if prefix_parts.is_empty() {
                    vec![prefix]
                } else {
                    prefix_parts
                };
                let suffix_list = if suffix_parts.is_empty() {
                    vec![suffix]
                } else {
                    suffix_parts
                };

                let mut result = Vec::new();
                for pfx in &prefix_list {
                    for item in &items {
                        // Each item may itself contain braces
                        let item_parts = brace_expand(item);
                        for ip in &item_parts {
                            for sfx in &suffix_list {
                                result.push(format!("{}{}{}", pfx, ip, sfx));
                            }
                        }
                    }
                }
                return result;
            }
        }
        i += 1;
    }
    // No brace found
    Vec::new()
}

/// Parse the body of a brace starting after the opening `{` at `start`.
/// Returns `(items, close_pos)` where `close_pos` is the index of `}`.
///
/// Handles:
///   comma-separated items: a,b,c
///   sequence expressions: 1..10, a..z, 01..10, 1..10..2
fn parse_brace_body(chars: &[char], start: usize) -> Option<(Vec<String>, usize)> {
    let n = chars.len();
    let mut items: Vec<String> = Vec::new();
    let mut current = String::new();
    let mut depth = 0usize;
    let mut i = start;
    let mut has_comma = false;

    while i < n {
        let ch = chars[i];
        match ch {
            '\\' => {
                current.push(ch);
                i += 1;
                if i < n {
                    current.push(chars[i]);
                    i += 1;
                }
            }
            '\'' => {
                current.push(ch);
                i += 1;
                while i < n && chars[i] != '\'' {
                    current.push(chars[i]);
                    i += 1;
                }
                if i < n {
                    current.push(chars[i]);
                    i += 1;
                }
            }
            '"' => {
                current.push(ch);
                i += 1;
                while i < n && chars[i] != '"' {
                    if chars[i] == '\\' {
                        current.push(chars[i]);
                        i += 1;
                    }
                    if i < n {
                        current.push(chars[i]);
                        i += 1;
                    }
                }
                if i < n {
                    current.push(chars[i]);
                    i += 1;
                }
            }
            '{' => {
                depth += 1;
                current.push(ch);
                i += 1;
            }
            '}' => {
                if depth == 0 {
                    items.push(current.clone());
                    // Validate: must have comma OR be a sequence expr
                    if has_comma {
                        return Some((items, i));
                    }
                    // Check for sequence expr
                    if items.len() == 1 {
                        if let Some(seq) = parse_sequence_expr(&items[0]) {
                            return Some((seq, i));
                        }
                    }
                    // Otherwise not a valid brace expression – caller will treat as literal
                    return None;
                }
                depth -= 1;
                current.push(ch);
                i += 1;
            }
            ',' if depth == 0 => {
                has_comma = true;
                items.push(current.clone());
                current = String::new();
                i += 1;
            }
            '$' if i + 1 < n && chars[i + 1] == '(' => {
                // Skip $() / $(()) – don't interpret braces/commas inside
                let end = skip_dollar_paren(chars, i);
                for j in i..end {
                    current.push(chars[j]);
                }
                i = end;
            }
            '$' if i + 1 < n && chars[i + 1] == '{' => {
                // Skip ${...} – don't interpret braces/commas inside
                let end = skip_dollar_brace(chars, i);
                for j in i..end {
                    current.push(chars[j]);
                }
                i = end;
            }
            '`' => {
                // Skip backtick command substitution
                let end = skip_backtick(chars, i);
                for j in i..end {
                    current.push(chars[j]);
                }
                i = end;
            }
            _ => {
                current.push(ch);
                i += 1;
            }
        }
    }
    None // No closing `}`
}

/// Parse a sequence expression like "1..10", "01..05", "a..z", "1..10..2".
fn parse_sequence_expr(s: &str) -> Option<Vec<String>> {
    // Split on ".." – there should be 2 or 3 parts
    let parts: Vec<&str> = s.splitn(4, "..").collect();
    if parts.len() < 2 || parts.len() > 3 {
        return None;
    }
    let from_s = parts[0];
    let to_s = parts[1];
    let inc_s = parts.get(2).copied();

    // Numeric sequence?
    if let (Ok(from), Ok(to)) = (from_s.parse::<i64>(), to_s.parse::<i64>()) {
        let mut inc: i64 = match inc_s {
            Some(s) => s.parse::<i64>().ok()?.abs(), // bash uses absolute value of step
            None => 1,
        };
        if inc == 0 {
            return None;
        }
        // Auto-negate step if direction doesn't match
        if from > to {
            inc = -inc;
        }
        // Zero-padding: check if either side has leading zero or explicit width
        let pad_width = {
            let fw = if from_s.starts_with('-') { &from_s[1..] } else { from_s };
            let tw = if to_s.starts_with('-')   { &to_s[1..]   } else { to_s   };
            // Zero-pad only when there's a genuine leading zero on a
            // multi-digit number (e.g., "01", "007"), not for bare "0".
            let fw_pad = fw.starts_with('0') && fw.len() > 1;
            let tw_pad = tw.starts_with('0') && tw.len() > 1;
            if fw_pad || tw_pad {
                // Pad width includes the sign when negative
                let fw_total = if from_s.starts_with('-') { fw.len() + 1 } else { fw.len() };
                let tw_total = if to_s.starts_with('-')   { tw.len() + 1 } else { tw.len() };
                fw_total.max(tw_total)
            } else {
                0
            }
        };
        let mut result = Vec::new();
        let mut cur = from;
        loop {
            if inc > 0 && cur > to { break; }
            if inc < 0 && cur < to { break; }
            if pad_width > 0 {
                if cur < 0 {
                    result.push(format!("-{:0>width$}", -cur, width = pad_width));
                } else {
                    result.push(format!("{:0>width$}", cur, width = pad_width));
                }
            } else {
                result.push(cur.to_string());
            }
            if cur == to {
                break;
            }
            cur = cur.checked_add(inc)?;
        }
        return Some(result);
    }

    // Character sequence? Both must be single ASCII letters.
    let from_chars: Vec<char> = from_s.chars().collect();
    let to_chars: Vec<char> = to_s.chars().collect();
    if from_chars.len() == 1 && to_chars.len() == 1
        && from_chars[0].is_ascii_alphabetic() && to_chars[0].is_ascii_alphabetic()
    {
        let from_c = from_chars[0] as i32;
        let to_c   = to_chars[0]   as i32;
        let inc: i32 = match inc_s {
            Some(s) => s.parse().ok()?,
            None => if from_c <= to_c { 1 } else { -1 },
        };
        if inc == 0 {
            return None;
        }
        let mut result = Vec::new();
        let mut cur = from_c;
        loop {
            if inc > 0 && cur > to_c { break; }
            if inc < 0 && cur < to_c { break; }
            if let Some(c) = char::from_u32(cur as u32) {
                // Escape characters that would be re-interpreted by
                // subsequent expansion stages (backtick, $, etc.)
                if c == '`' || c == '$' {
                    result.push(format!("\\{}", c));
                } else if c == '\\' {
                    // Bash's brace expansion of a character range where the
                    // current char is `\` emits an empty word — the `\`
                    // acts as a quoting backslash with nothing to quote.
                    result.push(String::new());
                } else {
                    result.push(c.to_string());
                }
            }
            cur += inc;
        }
        return Some(result);
    }

    None
}

/// Skip over a `$(...)` or `$((...))` starting at position `i` (where chars[i] == '$').
/// Returns the position just past the closing `)`.
fn skip_dollar_paren(chars: &[char], i: usize) -> usize {
    let n = chars.len();
    // Expect chars[i]=='$', chars[i+1]=='('
    let mut pos = i + 2; // after "$("
    let mut depth = 1usize;
    while pos < n && depth > 0 {
        match chars[pos] {
            '(' => { depth += 1; pos += 1; }
            ')' => { depth -= 1; pos += 1; }
            '\\' => { pos += 2; }
            '\'' => {
                pos += 1;
                while pos < n && chars[pos] != '\'' { pos += 1; }
                if pos < n { pos += 1; }
            }
            '"' => {
                pos += 1;
                while pos < n && chars[pos] != '"' {
                    if chars[pos] == '\\' { pos += 1; }
                    pos += 1;
                }
                if pos < n { pos += 1; }
            }
            '`' => {
                pos += 1;
                while pos < n && chars[pos] != '`' {
                    if chars[pos] == '\\' { pos += 1; }
                    pos += 1;
                }
                if pos < n { pos += 1; }
            }
            _ => { pos += 1; }
        }
    }
    pos
}

/// Skip over `${...}` parameter expansion starting at position `i` (where chars[i]=='$',
/// chars[i+1]=='{'). Returns the position just past the closing `}`.
fn skip_dollar_brace(chars: &[char], i: usize) -> usize {
    let n = chars.len();
    let mut pos = i + 2; // after "${"
    let mut depth = 1usize;
    while pos < n && depth > 0 {
        match chars[pos] {
            '{' => { depth += 1; pos += 1; }
            '}' => { depth -= 1; pos += 1; }
            '\\' => { pos += 2; }
            '\'' => {
                pos += 1;
                while pos < n && chars[pos] != '\'' { pos += 1; }
                if pos < n { pos += 1; }
            }
            '"' => {
                pos += 1;
                while pos < n && chars[pos] != '"' {
                    if chars[pos] == '\\' { pos += 1; }
                    pos += 1;
                }
                if pos < n { pos += 1; }
            }
            _ => { pos += 1; }
        }
    }
    pos
}

/// Skip over a backtick command substitution starting at position `i` (where chars[i] == '`').
/// Returns the position just past the closing backtick.
fn skip_backtick(chars: &[char], i: usize) -> usize {
    let n = chars.len();
    let mut pos = i + 1; // after opening backtick
    while pos < n {
        match chars[pos] {
            '`' => { pos += 1; return pos; }
            '\\' => { pos += 2; }
            _ => { pos += 1; }
        }
    }
    pos
}

/// Report an unmatched command substitution error, mimicking bash's error format.
/// The line number is adjusted to approximate bash's readahead behavior: when bash
/// encounters an unmatched `$(`, it continues reading subsequent lines looking for
/// `)`, and reports the line where the search terminates.
fn report_unmatched_cmdsub(vars: &Variables) {
    let script = vars.get("0").unwrap_or_else(|| crate::exec::shell_name().to_string());
    let lineno: i64 = vars.get("LINENO")
        .unwrap_or_else(|| "0".to_string())
        .parse()
        .unwrap_or(0);
    // Bash's parser reads ahead past the current line when $(  has no matching ).
    // It typically advances past blank lines and into the next statement before
    // giving up. Add 2 to approximate this readahead (+1 blank line, +1 next stmt).
    let report_line = lineno + 2;
    eprintln!("{}: command substitution: line {}: unexpected EOF while looking for matching `)'",
              script, report_line);
}

/// Check if a word contains an unmatched `$(` when single quotes are NOT treated
/// as quoting (double-quote context). This detects cases like `'$('\'` where
/// `$(` appears inside what would be single-quoted text, but since we're inside
/// double quotes, the single quotes are literal and `$(` is a command sub start.
fn has_unmatched_cmdsub_in_dquote(word: &str) -> bool {
    let chars: Vec<char> = word.chars().collect();
    let n = chars.len();
    let mut i = 0;
    while i < n {
        match chars[i] {
            '\\' => { i += 2; }
            '$' if i + 1 < n && chars[i + 1] == '(' => {
                // Found $( — try to find matching ) without SQ quoting
                i += 2;
                let mut depth = 1usize;
                let mut found = false;
                while i < n && depth > 0 {
                    match chars[i] {
                        '(' => { depth += 1; i += 1; }
                        ')' => {
                            depth -= 1;
                            i += 1;
                            if depth == 0 { found = true; }
                        }
                        '\\' => { i += 2; }
                        _ => { i += 1; }
                    }
                }
                if !found {
                    return true;
                }
            }
            _ => { i += 1; }
        }
    }
    false
}

// ─────────────────────────────────────────────────────────────────────────────
// Tilde expansion
// ─────────────────────────────────────────────────────────────────────────────

fn plain_tilde_home(vars: &Variables, _shell_home_first: bool) -> String {
    // Bash uses a single tilde-home cache for ALL `~` expansions:
    // initialised from startup env HOME (or passwd if unset), and
    // refreshed at every fork to the current `$HOME` value at fork time.
    // The shell_home_first flag is no longer meaningful — kept for API
    // compatibility but ignored.  See Variables::home_cache.
    if let Some(ref h) = vars.home_cache {
        if !h.is_empty() {
            return h.clone();
        }
    }
    // Fallbacks: env HOME, then passwd, then "/".
    std::env::var("HOME").ok()
        .filter(|h| !h.is_empty())
        .or_else(|| lookup_current_home())
        .unwrap_or_else(|| "/".to_string())
}

fn do_tilde_expand_with_policy(word: &str, vars: &Variables, shell_home_first: bool) -> String {
    if !word.starts_with('~') {
        return word.to_string();
    }

    // Find the end of the tilde prefix (up to '/' or end of string)
    let rest = &word[1..];
    let (user_part, suffix) = match rest.find('/') {
        Some(pos) => (&rest[..pos], &rest[pos..]),
        None      => (rest, ""),
    };

    match user_part {
        "" => {
            format!("{}{}", plain_tilde_home(vars, shell_home_first), suffix)
        }
        "+" => {
            // ~+  → $PWD
            let pwd = vars.get("PWD")
                .map(|s| s.to_string())
                .or_else(|| std::env::var("PWD").ok())
                .unwrap_or_else(|| ".".to_string());
            format!("{}{}", pwd, suffix)
        }
        "-" => {
            // ~-  → $OLDPWD
            let oldpwd = vars.get("OLDPWD")
                .map(|s| s.to_string())
                .unwrap_or_else(|| "-".to_string());
            format!("{}{}", oldpwd, suffix)
        }
        _ if user_part.starts_with('+') && user_part[1..].parse::<usize>().is_ok() => {
            // PROVEN: guard above confirmed parse succeeds.
            let n: usize = user_part[1..].parse().unwrap();
            if let Some(dir) = vars.get_array_element("DIRSTACK", n) {
                format!("{}{}", dir, suffix)
            } else {
                word.to_string()
            }
        }
        _ if user_part.starts_with('-') && user_part[1..].parse::<usize>().is_ok() => {
            // PROVEN: guard above confirmed parse succeeds.
            let n: usize = user_part[1..].parse().unwrap();
            let len = vars.array_length("DIRSTACK");
            let idx = len.saturating_sub(1 + n);
            if let Some(dir) = vars.get_array_element("DIRSTACK", idx) {
                format!("{}{}", dir, suffix)
            } else {
                word.to_string()
            }
        }
        _ if user_part.parse::<usize>().is_ok() => {
            // PROVEN: guard above confirmed parse succeeds.
            let n: usize = user_part.parse().unwrap();
            if let Some(dir) = vars.get_array_element("DIRSTACK", n) {
                format!("{}{}", dir, suffix)
            } else {
                word.to_string()
            }
        }
        username => {
            // ~user  → home directory of `user` via passwd
            if let Some(home) = lookup_user_home(username) {
                format!("{}{}", home, suffix)
            } else {
                word.to_string() // Leave unexpanded
            }
        }
    }
}

fn do_tilde_expand(word: &str, vars: &Variables) -> String {
    do_tilde_expand_with_policy(word, vars, true)
}

fn lookup_current_home() -> Option<String> {
    // SAFETY:
    // - `geteuid()` has no preconditions and always succeeds.
    // - `getpwuid(geteuid())` looks up the current user's passwd entry; it returns
    //   NULL if the uid has no entry, which we check before dereferencing.
    // - `(*pw).pw_dir` is a C string pointer owned by the C runtime's static passwd
    //   buffer; it remains valid until the next `getpwuid`/`getpwnam` call.  We
    //   convert it to an owned `String` before any subsequent call could invalidate it.
    unsafe {
        let pw = libc::getpwuid(libc::geteuid());
        if pw.is_null() {
            return None;
        }
        let dir = (*pw).pw_dir;
        if dir.is_null() {
            return None;
        }
        std::ffi::CStr::from_ptr(dir).to_str().ok().map(|s| s.to_string())
    }
}

fn lookup_user_home(username: &str) -> Option<String> {
    // Use nix / libc to look up the passwd entry
    use std::ffi::CString;
    let name = CString::new(username).ok()?;
    // SAFETY:
    // - `name.as_ptr()` is a valid NUL-terminated C string kept alive by `name`
    //   for the duration of this block.
    // - `getpwnam` returns NULL if the username has no passwd entry; we check
    //   before dereferencing `pw`.
    // - `(*pw).pw_dir` is owned by the C runtime's static passwd buffer; we
    //   convert it to an owned `String` via `CStr::to_str().to_string()` before
    //   any subsequent passwd call could invalidate the pointer.
    unsafe {
        let pw = libc::getpwnam(name.as_ptr());
        if pw.is_null() {
            return None;
        }
        let dir = (*pw).pw_dir;
        if dir.is_null() {
            return None;
        }
        let cstr = std::ffi::CStr::from_ptr(dir);
        cstr.to_str().ok().map(|s| s.to_string())
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Top-level expansion driver
// ─────────────────────────────────────────────────────────────────────────────

/// Controls how `=` and `:` interact with tilde expansion.
#[derive(Clone, Copy, PartialEq)]
enum TildeMode {
    /// Normal word: first `=` enables tilde, then `:` re-enables it.
    Normal,
    /// Assignment value (already past `var=`): only `:` re-enables tilde.
    AssignValue,
    /// Assignment value using passwd-home semantics for plain `~`.
    AssignValuePasswd,
    /// Parameter expansion default/alternate word: only leading tilde, no
    /// re-arming by `=` or `:`.
    ParamWord,
    /// No tilde expansion at all (double-quoted param word).
    None,
}

/// Expand a single token (after brace expansion).  Processes tilde, params,
/// arithmetic, command substitution markers, and quoting.
pub fn expand_all(word: &str, vars: &mut Variables) -> String {
    expand_impl(word, vars, TildeMode::Normal, false)
}

/// Like `expand_all` but marks IFS-whitespace inside quotes with CTLESC so
/// that subsequent `word_split` preserves them in mixed-quote contexts.
pub fn expand_all_for_split(word: &str, vars: &mut Variables) -> String {
    // Top-level word destined for splitting: also CTLESC-mark literal
    // (non-expansion) characters so that IFS-matching literals like the
    // `+` in `$x+$y` (with IFS=+) don't split the result.
    expand_impl_full(word, vars, TildeMode::Normal, false, true, true, false, false)
}

/// Expand a parameter expansion default/alternate word (unquoted context).
/// Only the leading tilde is expanded; `=` and `:` do not re-arm tilde.
/// IFS-whitespace inside any nested `"..."` is CTLESC-marked so that the
/// outer word-splitting (which will later be applied to the expansion) does
/// not split apart what was quoted inside the default word.
pub fn expand_all_param_word(word: &str, vars: &mut Variables) -> String {
    expand_impl_inner(word, vars, TildeMode::ParamWord, false, true, false, false)
}

/// Expand a parameter expansion default/alternate word inside double quotes.
/// Tilde is completely suppressed and quotes behave as inside `"..."`.
fn expand_all_param_word_dquote(word: &str, vars: &mut Variables) -> String {
    expand_impl(word, vars, TildeMode::None, true)
}

/// Public wrapper for callers outside this module (e.g. apply_assign_defaults
/// in exec.rs) that need the dquote-context variant.
pub fn expand_all_param_word_dq(word: &str, vars: &mut Variables) -> String {
    expand_all_param_word_dquote(word, vars)
}

/// Expand a parameter-operator word for `=` / `:=` assignment semantics.
/// This keeps `$*` / `${arr[*]}` in scalar form while still using parameter-word
/// quoting rules rather than general assignment-word parsing.
pub fn expand_param_assign_word(word: &str, vars: &mut Variables, in_dquote: bool) -> String {
    NO_SPLIT_CONTEXT.with(|flag| {
        let old = flag.replace(true);
        let result = if in_dquote {
            expand_all_param_word_dquote(word, vars)
        } else {
            expand_all_param_word(word, vars)
        };
        flag.set(old);
        result
            .replace("\x00QNULL\x00", "")
            .replace(CTLESC, "")
            .replace('\u{FFFE}', " ")
            .replace('\u{FFFF}', " ")
    })
}

/// Expand a parameter expansion default/alternate word in a heredoc context.
/// Like `expand_all_param_word` but $'...' ANSI-C quoting is NOT expanded,
/// matching bash behaviour where heredocs don't honour $'...' inside ${...}.
fn expand_all_param_word_heredoc(word: &str, vars: &mut Variables) -> String {
    expand_impl_inner(word, vars, TildeMode::ParamWord, false, false, true, false)
}

fn expand_patsub_replacement_word(word: &str, vars: &mut Variables) -> String {
    expand_impl_inner(word, vars, TildeMode::ParamWord, false, false, false, true)
}

/// Like expand_all but for assignment-value contexts where tilde after : and =
/// should always be expanded (even in POSIX mode).
pub fn expand_all_assign(word: &str, vars: &mut Variables) -> String {
    expand_impl(word, vars, TildeMode::AssignValue, false)
}

pub fn expand_all_assign_passwd(word: &str, vars: &mut Variables) -> String {
    expand_impl(word, vars, TildeMode::AssignValuePasswd, false)
}

/// Core expansion engine.
///
/// Parses the word character-by-character, tracking quoting state and
/// dispatching to specialised sub-routines for each expansion type.
/// When `mark_quoted` is true, IFS-whitespace characters inside quotes are
/// prefixed with CTLESC so that downstream word splitting preserves them.
fn expand_impl(word: &str, vars: &mut Variables, tilde_mode: TildeMode, initial_dquote: bool) -> String {
    expand_impl_inner(word, vars, tilde_mode, initial_dquote, false, false, false)
}

fn expand_impl_inner(
    word: &str,
    vars: &mut Variables,
    tilde_mode: TildeMode,
    initial_dquote: bool,
    mark_quoted: bool,
    no_ansi_c: bool,
    mark_patsub_literals: bool,
) -> String {
    expand_impl_full(
        word,
        vars,
        tilde_mode,
        initial_dquote,
        mark_quoted,
        false,
        no_ansi_c,
        mark_patsub_literals,
    )
}

fn expand_impl_full(
    word: &str,
    vars: &mut Variables,
    tilde_mode: TildeMode,
    initial_dquote: bool,
    mark_quoted: bool,
    mark_unquoted_literal: bool,
    no_ansi_c: bool,
    mark_patsub_literals: bool,
) -> String {
    // Guard against pathological nesting (e.g. ${a:-${b:-${c:-…}}} ×5 000).
    // Without this check the Rust stack overflows before the OS can kill us.
    let depth = EXPAND_DEPTH.with(|d| {
        let cur = d.get();
        d.set(cur + 1);
        cur + 1
    });
    if depth > EXPAND_RECURSION_LIMIT {
        EXPAND_DEPTH.with(|d| d.set(d.get() - 1));
        crate::exec::CURRENT_ERR_PREFIX.with(|pfx| {
            let pfx = pfx.borrow();
            let name = if pfx.is_empty() { crate::exec::shell_name() } else { pfx.as_str() };
            eprintln!("{}: maximum expansion recursion depth exceeded ({})",
                name, EXPAND_RECURSION_LIMIT);
        });
        return String::new();
    }

    let chars: Vec<char> = word.chars().collect();
    let n = chars.len();
    let mut out = String::with_capacity(word.len());
    let mut i = 0;
    let ifs = vars.get("IFS").unwrap_or_else(|| " \t\n".to_string());

    // Are we inside double quotes?
    let mut in_dquote = initial_dquote;
    // Was the current in_dquote state entered by a `"` actually present in
    // the word string (as opposed to inherited via initial_dquote)?  This
    // distinguishes `"$'...'"`  (literal double-quote in word → no ANSI-C
    // expansion) from `${foo:-$'\t'}` (outer double-quote context →
    // initial_dquote=true but the word $'\t' has no leading `"`, so
    // ANSI-C expansion should still fire).
    let mut dquote_from_word = false;
    // Are we accumulating a tilde prefix at the very start or after `:`/`=`?
    let mut tilde_allowed = tilde_mode != TildeMode::None;
    let mut dquote_start_len: Option<usize> = None;
    // Track whether we have seen the first `=` in the word.  In a general
    // (non-assignment-context) word, only the first `=` enables tilde; after
    // that only `:` re-enables it, not subsequent `=` signs.  In assignment
    // context (where the value is already separated from the name) we act as
    // if the first `=` has already been consumed.
    let mut seen_first_eq = matches!(tilde_mode, TildeMode::AssignValue | TildeMode::AssignValuePasswd);
    let mut in_unquoted_glob_class = false;

    while i < n {
        let ch = chars[i];

        // ── Single quotes ────────────────────────────────────────────────────
        if ch == '\'' && !in_dquote {
            let content_start = i + 1;
            i += 1;
            while i < n && chars[i] != '\'' {
                push_literal_char(
                    &mut out,
                    chars[i],
                    if mark_quoted { Some(ifs.as_str()) } else { None },
                    true,
                    mark_patsub_literals,
                );
                i += 1;
            }
            // Empty single-quoted (`''`): emit a QNULL marker so that
            // subsequent word splitting preserves the empty field
            // (bash: `${x}${sp}''` → two fields, the second empty).
            if mark_quoted && i == content_start {
                out.push_str("\x00QNULL\x00");
            }
            if i < n { i += 1; } // consume closing '
            tilde_allowed = false;
            continue;
        }

        // ── ANSI-C quoting  $'...' ───────────────────────────────────────────
        // $'...' is processed when not inside a literal double-quoted string.
        // In heredoc context (no_ansi_c=true), $'...' is treated as literal
        // dollars + literal single-quoted text (no ANSI-C expansion).
        // Output $, then the raw '...' content including the quote characters.
        if ch == '$' && i + 1 < n && chars[i + 1] == '\'' && no_ansi_c {
            // Emit literal $
            out.push('$');
            i += 1;
            // Emit the single-quoted string raw (including quote chars and backslashes)
            // but stop at the closing '
            out.push('\''); // opening '
            i += 1; // skip opening '
            while i < n && chars[i] != '\'' {
                if chars[i] == '\\' && i + 1 < n {
                    out.push('\\');
                    i += 1;
                    out.push(chars[i]);
                    i += 1;
                } else {
                    out.push(chars[i]);
                    i += 1;
                }
            }
            if i < n { out.push('\''); i += 1; } // closing '
            tilde_allowed = false;
            continue;
        }

        // When in_dquote was set by initial_dquote (no `"` seen in the word)
        // it means we are in a parameter-expansion word context and $'...'
        // should still expand (e.g. ${foo:-$'\t'}).
        if ch == '$' && i + 1 < n && chars[i + 1] == '\'' && !(in_dquote && dquote_from_word) {
            i += 2;
            let mut hit_nul = false;
            while i < n && chars[i] != '\'' {
                let (c, advance) = parse_ansi_escape(&chars, i);
                i += advance;
                // NUL byte truncates (bash C-string semantics)
                if c.contains('\0') {
                    for gc in c.chars() {
                        if gc == '\0' { hit_nul = true; break; }
                        push_literal_char(
                            &mut out,
                            gc,
                            if mark_quoted { Some(ifs.as_str()) } else { None },
                            true,
                            mark_patsub_literals,
                        );
                    }
                    break;
                }
                for gc in c.chars() {
                    push_literal_char(
                        &mut out,
                        gc,
                        if mark_quoted { Some(ifs.as_str()) } else { None },
                        true,
                        mark_patsub_literals,
                    );
                }
            }
            if hit_nul {
                // Skip rest of $'...' content
                while i < n && chars[i] != '\'' { i += 1; }
            }
            if i < n { i += 1; } // consume closing '
            tilde_allowed = false;
            continue;
        }

        // ── Double-quote open / close ─────────────────────────────────────────
        if ch == '"' {
            if initial_dquote {
                // We are processing a parameter-expansion word that
                // is itself inside an outer `"..."`.  A literal `"`
                // in the word opens or closes a NESTED dquote — but
                // "nested dquote inside dquote" is still dquote, so
                // in_dquote never changes.  We track whether we are
                // currently inside such a nested region via
                // dquote_from_word so that `$'...'` / `\{` handling
                // can distinguish inherited vs. literal-quoted.
                if !dquote_from_word {
                    dquote_start_len = Some(out.len());
                } else if mark_quoted && dquote_start_len == Some(out.len()) {
                    out.push_str("\x00QNULL\x00");
                }
                dquote_from_word = !dquote_from_word;
                if !dquote_from_word {
                    dquote_start_len = None;
                }
            } else {
                if !in_dquote {
                    dquote_start_len = Some(out.len());
                } else if mark_quoted && dquote_start_len == Some(out.len()) {
                    out.push_str("\x00QNULL\x00");
                }
                in_dquote = !in_dquote;
                if in_dquote { dquote_from_word = true; }
                if !in_dquote {
                    dquote_start_len = None;
                }
            }
            i += 1;
            tilde_allowed = false;
            continue;
        }

        // ── Backslash escaping ────────────────────────────────────────────────
        if ch == '\\' {
            i += 1;
            if i >= n {
                // Trailing backslash with no following character: bash
                // preserves it as a literal `\`.
                out.push('\\');
                break;
            }
            let next = chars[i];
            if in_dquote {
                // In double quotes backslash is special only before: $ ` \ " newline.
                // In a param-word context (TildeMode::ParamWord / None)
                // that is *inherited* from an outer dquote (i.e.
                // initial_dquote=true), bash ALSO strips \{ / \} —
                // the backslash was there to keep the brace from
                // closing `${…}`, and is discarded after parsing.
                //
                // When we are currently inside a literal `"..."`
                // nested within an outer dquote context
                // (initial_dquote && dquote_from_word), bash applies
                // unquoted-style backslash stripping: `\X` → `X` for
                // any X.  This matches bash's `extended_quote`
                // behaviour, where e.g. `"${a:+"\'$a\'"}"` emits
                // `'foo'` (backslash dropped before `'`).
                let in_nested_dquote = initial_dquote && dquote_from_word;
                if in_nested_dquote {
                    if next != '\n' {
                        push_literal_char(
                            &mut out,
                            next,
                            if mark_quoted { Some(ifs.as_str()) } else { None },
                            true,
                            mark_patsub_literals,
                        );
                    }
                    i += 1;
                    tilde_allowed = false;
                    continue;
                }
                let strip_brace_bs = !dquote_from_word
                    && matches!(tilde_mode,
                        TildeMode::ParamWord | TildeMode::None);
                match next {
                    '$' | '`' | '\\' | '"' | '\n' => {
                        if next != '\n' {
                            push_literal_char(
                                &mut out,
                                next,
                                if mark_quoted { Some(ifs.as_str()) } else { None },
                                true,
                                mark_patsub_literals,
                            );
                        }
                        i += 1;
                    }
                    '{' | '}' if strip_brace_bs => {
                        push_literal_char(
                            &mut out,
                            next,
                            if mark_quoted { Some(ifs.as_str()) } else { None },
                            true,
                            mark_patsub_literals,
                        );
                        i += 1;
                    }
                    _ => {
                        push_literal_char(
                            &mut out,
                            '\\',
                            if mark_quoted { Some(ifs.as_str()) } else { None },
                            true,
                            mark_patsub_literals,
                        );
                        push_literal_char(
                            &mut out,
                            next,
                            if mark_quoted { Some(ifs.as_str()) } else { None },
                            true,
                            mark_patsub_literals,
                        );
                        i += 1;
                    }
                }
            } else {
                // Unquoted – backslash quotes literally.  When the
                // caller requested `mark_quoted` (param-word context)
                // and the backslashed char is IFS whitespace, mark it
                // with CTLESC so later word splitting keeps the
                // `\<space>` pair as a single literal space inside
                // the field (bash: `${v-a\ b}` → single word `a b`).
                //
                // Also mark backslash-escaped glob metacharacters
                // (* ? [) with CTLESC so pathname_expand treats them
                // as literal rather than as glob patterns.  Without
                // this, `echo \*` would glob against all files
                // instead of emitting a literal `*`.
                if next == '\n' {
                    // Line continuation – swallow both
                } else {
                    let is_ifs = ifs.contains(next);
                    let is_glob_meta = next == '*' || next == '?' || next == '[';
                    if next == '/' && in_unquoted_glob_class {
                        let mut closes = false;
                        let mut j = i + 1;
                        while j < n {
                            match chars[j] {
                                ']' => {
                                    closes = true;
                                    break;
                                }
                                '\\' if j + 1 < n => j += 2,
                                _ => j += 1,
                            }
                        }
                        if closes {
                            out.push('\\');
                            out.push('/');
                        } else {
                            out.push('/');
                        }
                    } else {
                        if (mark_quoted && is_ifs)
                            || is_glob_meta
                            || (mark_patsub_literals && matches!(next, '&' | '\\'))
                        {
                            out.push(CTLESC);
                        }
                        out.push(next);
                    }
                }
                i += 1;
            }
            tilde_allowed = false;
            continue;
        }

        if !in_dquote {
            match ch {
                '[' => in_unquoted_glob_class = true,
                ']' if in_unquoted_glob_class => in_unquoted_glob_class = false,
                _ => {}
            }
        }

        // ── $ expansions ──────────────────────────────────────────────────────
        if ch == '$' {
            let (expanded, advance) = expand_dollar(&chars, i, vars, in_dquote, false);
            // CTLESC-mark IFS-whitespace in the expansion so that subsequent
            // word splitting (applied to the enclosing word once it leaves
            // this quoted context) doesn't split what was quoted here.
            // Skip if the expansion contains internal markers (CMDSUB, etc.)
            // — those are sentinels delimited by \x00 and must pass through
            // intact to later expansion stages.
            if (mark_quoted || mark_patsub_literals) && in_dquote && !expanded.contains('\x00') {
                // Empty expansion inside `"..."` in mark-quoted
                // context: emit a QNULL sentinel so word splitting
                // preserves an empty field at this position (bash:
                // `recho \${x+ab "\$y"}` with y unset → ["ab", ""]).
                if expanded.is_empty() && mark_quoted {
                    out.push_str("\x00QNULL\x00");
                } else {
                    for c in expanded.chars() {
                        push_literal_char(
                            &mut out,
                            c,
                            if mark_quoted { Some(ifs.as_str()) } else { None },
                            true,
                            mark_patsub_literals,
                        );
                    }
                }
            } else {
                if mark_quoted && in_dquote && expanded.contains('\x00') {
                    let quoted = expanded
                        .replace(CMDSUB_MARKER, QCMDSUB_MARKER)
                        .replace(FUNSUB_MARKER, QFUNSUB_MARKER)
                        .replace(REPLYSUB_MARKER, QREPLYSUB_MARKER);
                    out.push_str(&quoted);
                } else {
                    out.push_str(&expanded);
                }
            }
            i += advance;
            tilde_allowed = false;
            continue;
        }

        // ── Backtick command substitution ─────────────────────────────────────
        if ch == '`' && !in_dquote {
            let (body, advance) = collect_backtick(&chars, i + 1);
            // Emit a marker that exec will replace
            out.push_str(&format!("{CMDSUB_MARKER}{}\x00", body));
            i += advance + 1;
            tilde_allowed = false;
            continue;
        }
        if ch == '`' && in_dquote {
            let (body, advance) = collect_backtick(&chars, i + 1);
            let marker = if mark_quoted { QCMDSUB_MARKER } else { CMDSUB_MARKER };
            out.push_str(&format!("{marker}{}\x00", body));
            i += advance + 1;
            tilde_allowed = false;
            continue;
        }

        // ── Tilde expansion  (unquoted only, at word start or after : / =) ────
        if ch == '~' && !in_dquote && tilde_allowed {
            // Collect the tilde prefix up to '/' or end
            let tilde_start = i;
            i += 1;
            let mut tilde_valid = true;
            while i < n && chars[i] != '/' && chars[i] != ':' && chars[i] != '=' {
                // Tilde prefix cannot contain unquoted quotes, $, or backslash
                if chars[i] == '\'' || chars[i] == '"' || chars[i] == '$' || chars[i] == '\\' {
                    tilde_valid = false;
                    break;
                }
                i += 1;
            }
            if tilde_valid {
                let tilde_token: String = chars[tilde_start..i].iter().collect();
                // Param-word contexts (e.g. `${var/pat/~}` replacement and
                // `${var:-~}` defaults) and assignment-value contexts both
                // honour the *current* `$HOME`, while plain `~` in a
                // command word uses the passwd-startup HOME first.
                let shell_home_first = matches!(
                    tilde_mode,
                    TildeMode::AssignValue | TildeMode::ParamWord
                );
                let expanded = do_tilde_expand_with_policy(&tilde_token, vars, shell_home_first);
                out.push_str(&expanded);
            } else {
                // Tilde prefix was quoted — output '~' literally and
                // rewind so the main loop processes the rest normally
                out.push('~');
                i = tilde_start + 1;
            }
            tilde_allowed = false;
            continue;
        }

        // ── Ordinary character ─────────────────────────────────────────────────
        // Tilde expansion after `=` and `:` follows bash semantics:
        //   - Normal mode: first `=` enables tilde, then only `:` re-enables
        //     BUT only if the text before `=` is a valid identifier
        //     (so `=~` alone doesn't trigger tilde expansion).
        //   - AssignValue: only `:` re-enables (already past the assignment `=`)
        //   - ParamWord / None: nothing re-enables tilde
        //   - In POSIX mode without assignment context, nothing re-enables
        if (ch == ':' || ch == '=') && !in_dquote {
            out.push(ch);
            if matches!(tilde_mode, TildeMode::Normal | TildeMode::AssignValue | TildeMode::AssignValuePasswd)
                && (!vars.posix_mode || matches!(tilde_mode, TildeMode::AssignValue | TildeMode::AssignValuePasswd))
            {
                if ch == '=' && !seen_first_eq {
                    // First `=` in the word — enables tilde only if the
                    // preceding text is a valid identifier (i.e. this
                    // is actually an assignment-style prefix).  If the
                    // prefix isn't an identifier (e.g. `=~` with no
                    // NAME), DISABLE tilde_allowed explicitly — it was
                    // true at start-of-word.
                    seen_first_eq = true;
                    let prefix = &out[..out.len() - 1];  // strip trailing `=`
                    if is_valid_assign_prefix(prefix) {
                        tilde_allowed = true;
                    } else {
                        tilde_allowed = false;
                    }
                } else if ch == ':' && seen_first_eq {
                    // `:` after the first `=` — re-enables tilde
                    tilde_allowed = true;
                }
                // else: second+ `=`, or `:` before first `=` — no tilde
            }
            i += 1;
            continue;
        }

        // Words inside ${var:-word} / ${var:=word} are expanded directly
        // here instead of going through the lexer, so unquoted literal
        // `<(...)` / `>(...)` needs the same procsub marker framing that
        // ordinary lexer words get.
        if !in_dquote
            && matches!(ch, '<' | '>')
            && i + 1 < n
            && chars[i + 1] == '('
        {
            let (inner, advance, closed) = collect_paren_cmd(&chars, i + 2);
            if closed {
                let marker = if ch == '<' { '\u{E010}' } else { '\u{E011}' };
                out.push(marker);
                out.push_str(&inner);
                out.push('\u{E012}');
                tilde_allowed = false;
                i += advance + 2;
                continue;
            }
        }

        // Mark literal characters with CTLESC so that subsequent word
        // splitting does not treat them as IFS delimiters.  Bash's rule:
        // only characters from the RESULT of an expansion are subject to
        // IFS splitting — literal source characters never split.
        //
        // Two contexts care about this:
        //   - `in_dquote`: quoted content always escapes splitting
        //     (mark_quoted controls this; marks all chars here).
        //   - unquoted literal at top level (mark_unquoted_literal):
        //     literal `+` between `$x+$y` shouldn't split with IFS=+.
        //
        // `expand_all_param_word` does NOT set mark_unquoted_literal
        // because literal text in a `${foo:-DEFAULT}` default IS
        // subject to splitting in bash (the unquoted default value is
        // treated just like any other expansion result).
        let mark_ws = mark_quoted && (in_dquote || mark_unquoted_literal);
        let mark_glob_literal = in_dquote;
        push_literal_char(
            &mut out,
            ch,
            if mark_ws { Some(ifs.as_str()) } else { None },
            mark_glob_literal,
            mark_patsub_literals && (in_dquote || mark_unquoted_literal),
        );
        tilde_allowed = false;
        i += 1;
    }

    EXPAND_DEPTH.with(|d| d.set(d.get() - 1));
    out
}

// ─────────────────────────────────────────────────────────────────────────────
// $ expansion dispatch
// ─────────────────────────────────────────────────────────────────────────────

/// Handles a `$` at position `i` in `chars`.  Returns (expanded_string, chars_consumed).
fn expand_dollar(chars: &[char], i: usize, vars: &mut Variables, in_dquote: bool, in_heredoc: bool) -> (String, usize) {
    let n = chars.len();
    if i + 1 >= n {
        return ("$".to_string(), 1);
    }

    let next = chars[i + 1];

    // $((expr))  arithmetic expansion
    if next == '(' && i + 2 < n && chars[i + 2] == '(' {
        let (expr, advance, closed_doubled) = collect_arith(&chars, i + 3);
        if !closed_doubled {
            // We stopped because the inner `)` count made it impossible
            // for this to be `$((…))`.  Bash re-parses the whole thing as
            // `$( (…) )` command substitution.  `expr` already holds the
            // subshell body up to (but not including) the inner `)`, and
            // collect_arith has consumed the trailing `)` that closes the
            // outer `$(` for us.
            //
            // Examples:
            //   $(( echo ab cde ) )   →  $( ( echo ab cde ) )
            //   $((echo a);(echo b))  →  $( (echo a);(echo b) )  (but this
            //     path is only hit when `))` wasn't found; the standard
            //     arith collector already matches the outer `))` if it's
            //     syntactically unambiguous.
            let body = format!("({})", expr);
            let marker = format!("\x00CMDSUB\x00{}\x00", body);
            return (marker, advance + 3);
        }
        // Expand $var / ${var} references inside the expression before evaluating.
        let expanded_expr = expand_arith_vars(&expr, vars);
        match arithmetic::eval_expr_mut(&expanded_expr, vars) {
            Ok(v) => return (v.to_string(), advance + 3),
            Err(e) => {
                // Fallback: if the body looks like a command list (unquoted
                // `;`/`&`/`|` at depth 0 or an unmatched `)`), bash treats
                // the whole thing as `$( (cmd) )`.
                if looks_like_subshell_cmdsub(&expr) {
                    let body = format!("({})", expr);
                    let marker = format!("\x00CMDSUB\x00{}\x00", body);
                    return (marker, advance + 3);
                }
                // Embed the expression alongside the error message so
                // exec can format "<expr>: <msg> (error token is …)".
                // Separate with \x1F (unit separator — safe delimiter).
                // If the error contains an INNER marker (recursive variable
                // evaluation failed), extract the inner expression and use
                // that for display instead of the outer expanded_expr.
                let arith_payload = unwrap_inner_arith_error(&expanded_expr, &e);
                return (format!("\x00ARITH_ERR\x00{}\x00", arith_payload), advance + 3);
            }
        }
    }

    // $(cmd)  command substitution
    if next == '(' {
        let (body, advance, closed) = collect_paren_cmd(&chars, i + 2);
        if !closed {
            // Unclosed $( — report error and produce empty expansion.
            report_unmatched_cmdsub(vars);
            return (String::new(), advance + 2);
        }
        let marker = format!("\x00CMDSUB\x00{}\x00", body);
        return (marker, advance + 2);
    }

    // $[expr]  deprecated arithmetic expansion (same as $((expr)))
    if next == '[' {
        let (expr, advance, closed) = collect_bracket_arith(&chars, i + 2);
        if closed {
            let expanded_expr = expand_arith_vars(&expr, vars);
            match arithmetic::eval_expr_mut(&expanded_expr, vars) {
                Ok(v) => return (v.to_string(), advance + 2),
                Err(e) => {
                    let arith_payload = unwrap_inner_arith_error(&expanded_expr, &e);
                    return (format!("\x00ARITH_ERR\x00{}\x00", arith_payload), advance + 2);
                }
            }
        }
        // unclosed $[ — bash leaves it literal
    }

    // ${...}  parameter expansion
    if next == '{' {
        let (value, advance) = expand_param_brace(chars, i + 2, vars, in_dquote, in_heredoc);
        return (value, advance + 2);
    }

    // <(cmd) / >(cmd) process substitution – handled upstream; pass through
    // (these are triggered by the parser, not expand_dollar, but just in case)

    // Special single-character variables
    match next {
        '?' => {
            let v = vars.get("?").unwrap_or_else(|| "0".to_string()).to_string();
            return (v, 2);
        }
        '$' => {
            let v = vars.get("$").unwrap_or_else(|| "0".to_string()).to_string();
            return (v, 2);
        }
        '!' => {
            // $! = PID of last background job.  Unset until the first
            // `cmd &`; with `set -u` that's a fatal error.
            if vars.nounset && vars.get("!").is_none() {
                eprintln!("{}: $!: unbound variable",
                    crate::exec::shell_name_with_line());
                return ("\x00NOUNSET_ERROR\x00".to_string(), 2);
            }
            let v = vars.get("!").unwrap_or_default().to_string();
            return (v, 2);
        }
        '#' => {
            // Could be start of ${#name} but here we just have $#
            let v = vars.positional_count().to_string();
            return (v, 2);
        }
        '@' => {
            // In double quotes $@ expands to each positional as separate word;
            // we join with \u{FFFE} so word_split can treat them separately.
            // (Using \u{FFFE}, a Unicode noncharacter, avoids collisions with
            // user data — the old \x01 sentinel clashed with $'\1'.)
            let positionals = vars.all_positional(vars.positional_count());
            let v = if in_dquote {
                if positionals.is_empty() {
                    // "$@" with 0 args → should produce no words at all.
                    // Use a special marker that the executor recognises and removes.
                    "\x00EMPTY_AT\x00".to_string()
                } else {
                    // Quoted "$@" — each positional is a separate
                    // field, empties preserved.  Use FFFF so that
                    // word_split treats every separator as a forced
                    // field boundary (distinct from FFFE which collapses
                    // empty neighbours).
                    positionals.join("\u{FFFF}")
                }
            } else {
                // Unquoted $@ → each positional is a separate word,
                // subject to further word splitting.
                positionals.join("\u{FFFE}")
            };
            return (v, 2);
        }
        '*' => {
            // $* – join with IFS's first char.  Two special cases:
            //   1. IFS="" AND unquoted: POSIX says $* expands like $@
            //      (each positional a separate word).  Use \u{FFFE}.
            //   2. Otherwise: join with IFS[0].  Word-splitting (if
            //      any) on IFS re-splits the result.
            let positionals = vars.all_positional(vars.positional_count());
            let ifs = vars.get("IFS").unwrap_or_else(|| " ".to_string());
            let no_split = NO_SPLIT_CONTEXT.with(|flag| flag.get());
            if no_split {
                let sep = if ifs.is_empty() {
                    String::new()
                } else {
                    // PROVEN: ifs is non-empty, so chars().next() is Some.
                    ifs.chars().next().unwrap().to_string()
                };
                return (positionals.join(&sep), 2);
            }
            if ifs.is_empty() && !in_dquote {
                return (positionals.join("\u{FFFE}"), 2);
            }
            // PROVEN: ifs is non-empty in both branches (empty case returned above).
            let sep = if ifs.is_empty() { String::new() } else { ifs.chars().next().unwrap().to_string() };
            return (positionals.join(&sep), 2);
        }
        '0'..='9' => {
            // Positional parameter – only single digit here; ${10} goes through ${...}
            let digit = (next as u8 - b'0') as usize;
            if digit == 0 {
                let v = vars.get("0").unwrap_or_default().to_string();
                return (v, 2);
            }
            // `set -u`: expanding $1 when the shell has < N positionals
            // is a fatal error.
            if vars.nounset && vars.get_positional(digit).is_none() {
                eprintln!("{}: ${}: unbound variable",
                    crate::exec::shell_name_with_line(), digit);
                return ("\x00NOUNSET_ERROR\x00".to_string(), 2);
            }
            let v = vars.get_positional(digit).unwrap_or_default().to_string();
            return (v, 2);
        }
        '-' => {
            let v = vars.get("-").unwrap_or_default().to_string();
            return (v, 2);
        }
        '_' => {
            // `$_` is special only when not followed by an identifier-
            // continuation character — `$_G_hook` is the variable
            // `_G_hook`, not `$_` followed by `G_hook`.
            let after = chars.get(i + 2).copied();
            if !matches!(after, Some(c) if c.is_ascii_alphanumeric() || c == '_') {
                let v = vars.get("_").unwrap_or_default().to_string();
                return (v, 2);
            }
            // fall through to plain-name path below
        }
        _ => {}
    }

    // Plain variable name $name
    if next.is_ascii_alphabetic() || next == '_' {
        let start = i + 1;
        let mut end = start;
        while end < n && (chars[end].is_ascii_alphanumeric() || chars[end] == '_') {
            end += 1;
        }
        let name: String = chars[start..end].iter().collect();
        // `set -u` (nounset): expanding a plain $name / ${name} on an
        // unset variable is a fatal error in bash — it prints
        // "NAME: unbound variable" and exits with 127 (or, in a
        // subshell context, returns 127 for the subshell).
        if vars.nounset && vars.get(&name).is_none() {
            eprintln!("{}: {}: unbound variable",
                crate::exec::shell_name_with_line(), name);
            return ("\x00NOUNSET_ERROR\x00".to_string(), end - i);
        }
        let v = expand_var_value(&name, vars).unwrap_or_default();
        return (v, end - i);
    }

    ("$".to_string(), 1)
}

// ─────────────────────────────────────────────────────────────────────────────
// ${...} parameter expansion
// ─────────────────────────────────────────────────────────────────────────────

/// Expand `${...}`.  `i` is the position of the first char after `${`.
/// Returns (expanded_value, total_chars_consumed_after_the_initial_`${`).
fn expand_param_brace(
    chars: &[char],
    i: usize,
    vars: &mut Variables,
    in_dquote: bool,
    in_heredoc: bool,
) -> (String, usize) {
    let first = chars.get(i).copied();
    if matches!(first, Some('|')) {
        let (raw, advance, _unmatched_cmdsub) = collect_brace_cmdsub_body(chars, i);
        let body = raw.strip_prefix('|').unwrap_or(&raw).trim_start();
        return (format!("{REPLYSUB_MARKER}{}\x00", body), advance);
    }
    if first.map(|c| c.is_whitespace()).unwrap_or(false) {
        let (raw, advance, _unmatched_cmdsub) = collect_brace_cmdsub_body(chars, i);
        let body = raw.trim_start();
        return (format!("{FUNSUB_MARKER}{}\x00", body), advance);
    }

    // Collect the raw content inside { }
    let (raw, advance, _unmatched_cmdsub) = collect_brace_body(chars, i, in_dquote);

    let value = expand_param_raw(&raw, vars, in_dquote, in_heredoc);
    (value, advance)
}

fn collect_brace_cmdsub_body(chars: &[char], start: usize) -> (String, usize, bool) {
    let n = chars.len();
    let mut depth = 1usize;
    let mut body = String::new();
    let mut i = start;
    let mut unmatched_cmdsub = false;

    while i < n {
        match chars[i] {
            '{' => {
                depth += 1;
                body.push(chars[i]);
                i += 1;
            }
            '}' => {
                depth -= 1;
                if depth == 0 {
                    i += 1;
                    break;
                }
                body.push(chars[i]);
                i += 1;
            }
            '\\' => {
                body.push(chars[i]);
                i += 1;
                if i < n {
                    body.push(chars[i]);
                    i += 1;
                }
            }
            '\'' => {
                body.push(chars[i]);
                i += 1;
                while i < n && chars[i] != '\'' {
                    body.push(chars[i]);
                    i += 1;
                }
                if i < n {
                    body.push(chars[i]);
                    i += 1;
                }
            }
            '"' => {
                body.push(chars[i]);
                i += 1;
                while i < n && chars[i] != '"' {
                    if chars[i] == '\\' && i + 1 < n {
                        body.push(chars[i]);
                        i += 1;
                    }
                    body.push(chars[i]);
                    i += 1;
                }
                if i < n {
                    body.push(chars[i]);
                    i += 1;
                }
            }
            '`' => {
                body.push(chars[i]);
                i += 1;
                while i < n && chars[i] != '`' {
                    if chars[i] == '\\' && i + 1 < n {
                        body.push(chars[i]);
                        i += 1;
                    }
                    body.push(chars[i]);
                    i += 1;
                }
                if i < n {
                    body.push(chars[i]);
                    i += 1;
                }
            }
            '$' => {
                body.push(chars[i]);
                i += 1;
                if i < n && chars[i] == '\'' {
                    body.push(chars[i]);
                    i += 1;
                    while i < n && chars[i] != '\'' {
                        if chars[i] == '\\' && i + 1 < n {
                            body.push(chars[i]);
                            i += 1;
                        }
                        body.push(chars[i]);
                        i += 1;
                    }
                    if i < n {
                        body.push(chars[i]);
                        i += 1;
                    }
                } else if i < n && chars[i] == '{' {
                    body.push(chars[i]);
                    i += 1;
                    let mut bdepth = 1usize;
                    while i < n && bdepth > 0 {
                        match chars[i] {
                            '{' => {
                                bdepth += 1;
                                body.push(chars[i]);
                                i += 1;
                            }
                            '}' => {
                                bdepth -= 1;
                                body.push(chars[i]);
                                i += 1;
                            }
                            '\'' => {
                                body.push(chars[i]);
                                i += 1;
                                while i < n && chars[i] != '\'' {
                                    body.push(chars[i]);
                                    i += 1;
                                }
                                if i < n {
                                    body.push(chars[i]);
                                    i += 1;
                                }
                            }
                            '"' => {
                                body.push(chars[i]);
                                i += 1;
                                while i < n && chars[i] != '"' {
                                    if chars[i] == '\\' && i + 1 < n {
                                        body.push(chars[i]);
                                        i += 1;
                                    }
                                    body.push(chars[i]);
                                    i += 1;
                                }
                                if i < n {
                                    body.push(chars[i]);
                                    i += 1;
                                }
                            }
                            '\\' => {
                                body.push(chars[i]);
                                i += 1;
                                if i < n {
                                    body.push(chars[i]);
                                    i += 1;
                                }
                            }
                            _ => {
                                body.push(chars[i]);
                                i += 1;
                            }
                        }
                    }
                } else if i < n && chars[i] == '(' {
                    body.push(chars[i]);
                    i += 1;
                    let mut pdepth = 1usize;
                    let mut found_close = false;
                    while i < n {
                        match chars[i] {
                            '(' => {
                                pdepth += 1;
                                body.push(chars[i]);
                                i += 1;
                            }
                            ')' => {
                                pdepth -= 1;
                                body.push(chars[i]);
                                i += 1;
                                if pdepth == 0 {
                                    found_close = true;
                                    break;
                                }
                            }
                            '\'' => {
                                body.push(chars[i]);
                                i += 1;
                                while i < n && chars[i] != '\'' {
                                    body.push(chars[i]);
                                    i += 1;
                                }
                                if i < n {
                                    body.push(chars[i]);
                                    i += 1;
                                }
                            }
                            '"' => {
                                body.push(chars[i]);
                                i += 1;
                                while i < n && chars[i] != '"' {
                                    if chars[i] == '\\' && i + 1 < n {
                                        body.push(chars[i]);
                                        i += 1;
                                    }
                                    body.push(chars[i]);
                                    i += 1;
                                }
                                if i < n {
                                    body.push(chars[i]);
                                    i += 1;
                                }
                            }
                            '\\' => {
                                body.push(chars[i]);
                                i += 1;
                                if i < n {
                                    body.push(chars[i]);
                                    i += 1;
                                }
                            }
                            _ => {
                                body.push(chars[i]);
                                i += 1;
                            }
                        }
                    }
                    if !found_close {
                        unmatched_cmdsub = true;
                    }
                }
            }
            _ => {
                body.push(chars[i]);
                i += 1;
            }
        }
    }

    (body, i - start, unmatched_cmdsub)
}

pub(crate) fn collect_brace_cmdsub_body_pub(
    chars: &[char],
    start: usize,
) -> (String, usize, bool) {
    collect_brace_cmdsub_body(chars, start)
}

/// Collect everything up to the matching `}`, respecting nested braces,
/// quotes, $(...), $((...)).
fn collect_brace_body(chars: &[char], start: usize, in_dquote_outer: bool) -> (String, usize, bool) {
    let n = chars.len();
    let mut depth = 1usize;
    let mut body = String::new();
    let mut i = start;
    let mut unmatched_cmdsub = false;
    // Inside `${...}`, the quoting context is LOCAL — a nested
    // `"..."` opens a new context regardless of whether the enclosing
    // word is already in double quotes.  Start dq=false so the first
    // `"` opens rather than closes, and so `}` inside a nested dquote
    // stays literal.
    let mut dq = false;
    // Posix rule: when `${...}` sits inside an outer `"..."` and
    // posix mode is active, a `'` in the body is LITERAL and the
    // first unescaped `}` terminates.  We honour the rule only when
    // we haven't opened a nested `"..."` inside the body.
    let posix_outer_dquote = in_dquote_outer
        && crate::exec::POSIX_MODE.with(|p| p.get());

    while i < n {
        let ch = chars[i];
        match ch {
            // Only `${` (nested param expansion) increments brace depth.
            // A bare `{` inside the body is literal text, matching bash:
            // `${abc:-G { I } K }` has the first `}` close the outer
            // `${...}`, with `{` and subsequent `}` emitted as text.
            '{' => { body.push(ch); i += 1; }
            '}' if !dq => {
                depth -= 1;
                if depth == 0 {
                    i += 1; // consume the closing }
                    break;
                }
                body.push(ch);
                i += 1;
            }
            '}' => {
                // Inside a nested `"..."`, `}` is literal.
                body.push(ch);
                i += 1;
            }
            '\\' => {
                body.push(ch);
                i += 1;
                if i < n { body.push(chars[i]); i += 1; }
            }
            '`' => {
                // Backtick command substitution inside `${...}`: the
                // body between backticks is collected literally so that
                // a `}` inside does not close the outer brace body.
                body.push(ch);
                i += 1;
                while i < n && chars[i] != '`' {
                    if chars[i] == '\\' && i + 1 < n {
                        body.push(chars[i]);
                        i += 1;
                    }
                    body.push(chars[i]);
                    i += 1;
                }
                if i < n { body.push(chars[i]); i += 1; }
            }
            '\'' if !dq => {
                // Posix rule: when `${...}` sits inside outer `"..."`
                // and posix mode is on, `'` is literal.  Otherwise
                // a `'` inside a brace body starts a single-quoted region
                // that can span multiple lines (matching bash's behaviour:
                // `"${x##'}"` on one line with a closing `'` further down
                // the script is treated as a multi-line SQ region).
                if posix_outer_dquote {
                    body.push(ch);
                    i += 1;
                    continue;
                }
                // Scan for closing '. Unlike the original code we do NOT stop
                // at `\n` — bash allows the closing `'` to appear on a later
                // line in the same brace body.
                let mut j = i + 1;
                let mut found = false;
                while j < n {
                    let cj = chars[j];
                    if cj == '\'' { found = true; break; }
                    if cj == '\\' && j + 1 < n { j += 2; continue; }
                    j += 1;
                }
                if !found {
                    body.push(ch);
                    i += 1;
                    continue;
                }
                body.push(ch);
                i += 1;
                while i < n && chars[i] != '\'' {
                    body.push(chars[i]);
                    i += 1;
                }
                if i < n { body.push(chars[i]); i += 1; }
            }
            '"' => {
                dq = !dq;
                body.push(ch);
                i += 1;
            }
            '$' => {
                body.push(ch);
                i += 1;
                if i < n && chars[i] == '\'' {
                    // $'...' ANSI-C quoted string: collect verbatim, handling
                    // \' so the closing ' is not mistaken for the end of the string.
                    body.push(chars[i]); // push opening '
                    i += 1;
                    while i < n && chars[i] != '\'' {
                        if chars[i] == '\\' && i + 1 < n {
                            body.push(chars[i]);   // push backslash
                            i += 1;
                            body.push(chars[i]);   // push escaped char
                            i += 1;
                        } else {
                            body.push(chars[i]);
                            i += 1;
                        }
                    }
                    if i < n { body.push(chars[i]); i += 1; } // push closing '
                } else if i < n && chars[i] == '{' {
                    // Nested ${…} — track its own brace depth so its
                    // closing `}` doesn't close the outer brace body.
                    body.push(chars[i]);
                    i += 1;
                    let mut bdepth = 1usize;
                    while i < n && bdepth > 0 {
                        match chars[i] {
                            '{' => { bdepth += 1; body.push(chars[i]); i += 1; }
                            '}' => { bdepth -= 1; body.push(chars[i]); i += 1; }
                            '\'' => {
                                body.push(chars[i]);
                                i += 1;
                                while i < n && chars[i] != '\'' {
                                    body.push(chars[i]); i += 1;
                                }
                                if i < n { body.push(chars[i]); i += 1; }
                            }
                            '\\' => {
                                body.push(chars[i]);
                                i += 1;
                                if i < n { body.push(chars[i]); i += 1; }
                            }
                            _ => { body.push(chars[i]); i += 1; }
                        }
                    }
                } else if i < n && chars[i] == '(' {
                    // nested $() or $(())
                    body.push(chars[i]);
                    i += 1;
                    let mut pdepth = 1usize;
                    let mut found_close = false;
                    while i < n {
                        match chars[i] {
                            '(' => { pdepth += 1; body.push(chars[i]); i += 1; }
                            ')' => {
                                pdepth -= 1;
                                body.push(chars[i]);
                                i += 1;
                                if pdepth == 0 { found_close = true; break; }
                            }
                            '\'' => {
                                // Single quotes quote inside $()
                                body.push(chars[i]);
                                i += 1;
                                while i < n && chars[i] != '\'' {
                                    body.push(chars[i]);
                                    i += 1;
                                }
                                if i < n { body.push(chars[i]); i += 1; }
                            }
                            '"' => {
                                body.push(chars[i]);
                                i += 1;
                                while i < n && chars[i] != '"' {
                                    if chars[i] == '\\' { body.push(chars[i]); i += 1; }
                                    if i < n { body.push(chars[i]); i += 1; }
                                }
                                if i < n { body.push(chars[i]); i += 1; }
                            }
                            '\\' => {
                                body.push(chars[i]);
                                i += 1;
                                if i < n { body.push(chars[i]); i += 1; }
                            }
                            _ => { body.push(chars[i]); i += 1; }
                        }
                    }
                    if !found_close {
                        unmatched_cmdsub = true;
                    }
                }
            }
            _ => { body.push(ch); i += 1; }
        }
    }

    (body, i - start, unmatched_cmdsub)
}

pub(crate) fn collect_brace_body_pub(
    chars: &[char],
    start: usize,
    in_dquote_outer: bool,
) -> (String, usize, bool) {
    collect_brace_body(chars, start, in_dquote_outer)
}

fn parameter_expansion_assignable(name: &str) -> bool {
    if matches!(name, "@" | "*" | "#" | "?" | "$" | "!" | "-" | "_") {
        return false;
    }
    if name.parse::<usize>().is_ok() {
        return false;
    }
    true
}

fn format_param_assign_target(name: &str) -> String {
    if matches!(name, "@" | "*" | "#" | "?" | "$" | "!" | "-" | "_")
        || name.parse::<usize>().is_ok()
    {
        format!("${}", name)
    } else {
        name.to_string()
    }
}

/// Given the raw string inside `${...}`, perform the appropriate parameter
/// expansion.
fn expand_param_raw(raw: &str, vars: &mut Variables, in_dquote: bool, in_heredoc: bool) -> String {
    let chars: Vec<char> = raw.chars().collect();
    let n = chars.len();
    if n == 0 {
        return String::new();
    }

    // ${!prefix*} / ${!prefix@} – variable name listing
    if chars[0] == '!' && n > 1 {
        // `${!OP...}` where OP is a parameter operator (`-`, `+`, `=`, `?`,
        // `:-`, `:=`, `:?`, `:+`, `#`, `##`, `%`, `%%`) means the parameter
        // is `$!` itself, NOT an indirect expansion.  In that case fall
        // through to the regular operator handling below by skipping the
        // `${!...}` indirect branch.  Bash: `${!-posparams}` → if $! is
        // unset, use "posparams".
        let next = chars[1];
        // Note: `#` is NOT listed here — `${!#}` is indirect expansion of `#`
        // (the last positional parameter), not the `#` length operator applied
        // to `$!`.  `${!#var}` is bad substitution and is caught later.
        let starts_with_op = matches!(next, '-' | '+' | '=' | '?' | '%' | ',' | '^' | '~' | '@')
            || (n >= 3 && next == ':'
                && matches!(chars[2], '-' | '=' | '?' | '+'));
        if starts_with_op {
            // Don't enter the indirect branch — let the standard
            // parse_param_name → operator code path handle it (it will
            // pick up "!" as the parameter name and the rest as ops).
        } else {
        // Check if it ends with * or @
        let last = chars[n - 1];
        let second_last = if n >= 2 { chars[n - 2] } else { '\0' };
        if (last == '*' || last == '@') && second_last != '[' {
            // Check this is actually a name prefix (no other operators)
            let inner: String = chars[1..n-1].iter().collect();
            if is_valid_name_start(&inner) || inner.is_empty() {
                return expand_name_prefix(&inner, vars, last == '@' && in_dquote);
            }
        }
        let rest_chars: Vec<char> = chars[1..].iter().cloned().collect();
        let (source_name, source_end) = parse_param_name(&rest_chars);
        let source_ops: String = rest_chars[source_end..].iter().collect();
        let special_source_name = matches!(source_name.as_str(), "@" | "*" | "#" | "?" | "$" | "!" | "-" | "_")
            || source_name.parse::<usize>().is_ok();

        if !source_name.is_empty() && source_ops.is_empty() {
            if let Some(bracket) = source_name.find('[') {
                let arr_name = &source_name[..bracket];
                let idx_part = &source_name[bracket + 1..source_name.len().saturating_sub(1)];
                if (idx_part == "@" || idx_part == "*")
                    && (is_valid_varname(arr_name)
                        || matches!(arr_name, "@" | "*" | "#" | "?" | "$" | "!" | "-" | "_")
                        || arr_name.parse::<usize>().is_ok())
                {
                    // `${!name[@]}` / `${!name[*]}` returns keys of the literal
                    // parameter `name`, not an indirect target.
                    let keys: Vec<String> = if let Some(entries) = vars.get_array_sparse(arr_name) {
                        entries.iter().map(|(k, _)| k.to_string()).collect()
                    } else if vars.is_assoc(arr_name) {
                        vars.get_assoc_entries(arr_name)
                            .into_iter().map(|(k, _)| k).collect()
                    } else {
                        return String::new();
                    };
                    if in_dquote {
                        if idx_part == "@" {
                            return keys.join("\u{FFFF}");
                        } else {
                            let ifs = vars.get("IFS").unwrap_or_else(|| " ".to_string());
                            let sep = ifs.chars().next().map(|c| c.to_string()).unwrap_or_default();
                            return keys.join(&sep);
                        }
                    }
                    if idx_part == "*" {
                        let ifs = vars.get("IFS").unwrap_or_else(|| " ".to_string());
                        if ifs.is_empty() {
                            return keys.join("\u{FFFE}");
                        }
                        // PROVEN: ifs is non-empty (empty case returned above).
                        let sep = ifs.chars().next().unwrap().to_string();
                        return keys.join(&sep);
                    }
                    return keys.join("\u{FFFE}");
                }
            }
        }
        // ${!name} – indirect expansion.  For a nameref, bash
        // returns the nameref's TARGET NAME (not the target's value)
        // — that's the one remaining place `!` diverges from a
        // plain indirect: `declare -n foo=bar; echo ${!foo}` prints
        // "bar", not $bar's value.
        let indirect_source_name = is_valid_varname(&source_name)
            || matches!(source_name.as_str(), "@" | "*" | "#" | "?" | "$" | "!" | "-" | "_")
            || source_name.parse::<usize>().is_ok()
            || source_name.contains('[');
        if indirect_source_name {
            if !source_name.contains('[')
                && (source_ops.starts_with('*') || source_ops == "@")
            {
                eprintln!("{}: ${{{}}}: bad substitution",
                    crate::exec::shell_name_with_line(), raw);
                return "\x00EXPAND_ERROR\x00".to_string();
            }
            if source_ops.is_empty() && vars.is_nameref(&source_name) {
                let target = vars.get_nameref_target(&source_name).unwrap_or_default();
                if target.is_empty() {
                    let prefix = crate::exec::CURRENT_ERR_PREFIX.with(|p| p.borrow().clone());
                    if prefix.is_empty() {
                        eprintln!("{}: invalid indirect expansion", source_name);
                    } else {
                        eprintln!("{}: {}: invalid indirect expansion", prefix, source_name);
                    }
                    return "\x00EXPAND_ERROR\x00".to_string();
                }
                return target;
            }
            // Bash: `${!name}` with name unset or empty is "invalid
            // indirect expansion".  Emit the error and return empty.
            match resolve_raw_value(&source_name, vars, false) {
                None => {
                    if special_source_name {
                        if source_ops.is_empty() {
                            return String::new();
                        }
                        let combined = format!("{}{}", source_name, source_ops);
                        return expand_param_raw(&combined, vars, in_dquote, in_heredoc);
                    }
                    let prefix = crate::exec::CURRENT_ERR_PREFIX.with(|p| p.borrow().clone());
                    if prefix.is_empty() {
                        eprintln!("{}: invalid indirect expansion", source_name);
                    } else {
                        eprintln!("{}: {}: invalid indirect expansion", prefix, source_name);
                    }
                    return "\x00EXPAND_ERROR\x00".to_string();
                }
                Some(intermediate) if intermediate.is_empty() => {
                    if special_source_name {
                        if source_ops.is_empty() {
                            return String::new();
                        }
                        let combined = format!("{}{}", source_name, source_ops);
                        return expand_param_raw(&combined, vars, in_dquote, in_heredoc);
                    }
                    let prefix = crate::exec::CURRENT_ERR_PREFIX.with(|p| p.borrow().clone());
                    if prefix.is_empty() {
                        eprintln!("{}: invalid indirect expansion", source_name);
                    } else {
                        eprintln!("{}: {}: invalid indirect expansion", prefix, source_name);
                    }
                    return "\x00EXPAND_ERROR\x00".to_string();
                }
                Some(intermediate) => {
                    // Bash: the intermediate must be a valid variable
                    // name OR a single-char special parameter
                    // (@ * # ? $ ! - _ 0-9).  `v=bad-var; ${!v}` is
                    // "bad-var: invalid variable name", but
                    // `v=@; ${!v}` means ${!@} (positional params)
                    // and `v=arr[@]; ${!v}` means array keys — these
                    // must NOT be flagged as invalid here.
                    let is_special = matches!(intermediate.as_str(),
                        "@" | "*" | "#" | "?" | "$" | "!" | "-" | "_")
                        || intermediate.chars().next()
                            .map(|c| c.is_ascii_digit())
                            .unwrap_or(false)
                        || intermediate.contains('[');
                    if !is_valid_varname(&intermediate) && !is_special {
                        let display = intermediate
                            .replace('\u{FFFE}', " ")
                            .replace('\u{FFFF}', " ");
                        let prefix = crate::exec::CURRENT_ERR_PREFIX.with(|p| p.borrow().clone());
                        if prefix.is_empty() {
                            eprintln!("{}: invalid variable name", display);
                        } else {
                            eprintln!("{}: {}: invalid variable name", prefix, display);
                        }
                        return "\x00EXPAND_ERROR\x00".to_string();
                    }
                    if source_ops.is_empty() {
                        return expand_var_value(&intermediate, vars).unwrap_or_default();
                    }
                    if vars.nounset
                        && matches!(source_ops.as_str(), "@a" | "@A")
                        && !transform_target_is_set_for_nounset(
                            &intermediate,
                            &resolve_raw_value(&intermediate, vars, false),
                            vars,
                        )
                    {
                        eprintln!("{}: !{}: unbound variable",
                            crate::exec::shell_name_with_line(), source_name);
                        return "\x00NOUNSET_ERROR\x00".to_string();
                    }
                    let combined = format!("{}{}", intermediate, source_ops);
                    return expand_param_raw(&combined, vars, in_dquote, in_heredoc);
                }
            }
        }
        if !source_ops.is_empty() {
            if (source_ops == "*" || source_ops == "@")
                && !source_name.contains('[')
            {
                eprintln!("{}: ${{{}}}: bad substitution",
                    crate::exec::shell_name_with_line(), raw);
                return "\x00EXPAND_ERROR\x00".to_string();
            }
            let combined = format!("{}{}", source_name, source_ops);
            return expand_param_raw(&combined, vars, in_dquote, in_heredoc);
        }
        } // else (skip indirect, fall through to operator handling)
    }

    // Extquote: ${$'...'op} — ANSI-C quoted variable name.
    // bash supports $'name' as the variable-name portion of ${...},
    // so ${$'x1'%$'t'} means ${x1%$'t'} (expand ANSI-C "x1" to get the var name).
    // This is only valid when NOT in posix mode.  In posix mode, $' is not
    // interpreted as ANSI-C quoting inside ${...}.
    if n >= 3 && chars[0] == '$' && chars[1] == '\'' {
        let is_posix = crate::exec::POSIX_MODE.with(|p| p.get());
        if !is_posix {
            // Find the closing ' (skip \' escapes)
            let mut end = 2usize;
            while end < n {
                if chars[end] == '\'' { break; }
                if chars[end] == '\\' && end + 1 < n { end += 1; } // skip escaped char
                end += 1;
            }
            if end < n {
                // Extract content between $' and ' and expand ANSI-C escapes
                let content: String = chars[2..end].iter().collect();
                let varname = expand_ansi_c_escapes(&content);
                // Everything after the closing ' is the operator
                let op_rest: String = chars[end + 1..].iter().collect();
                // Rebuild as varname + op_rest and recurse
                let combined = format!("{}{}", varname, op_rest);
                return expand_param_raw(&combined, vars, in_dquote, in_heredoc);
            }
        }
    }

    // ${#NAME} – string length / array length.
    // The distinguishing test: `${#X}` where X is a SINGLE character
    // and X is a valid parameter name (alphanumeric, underscore, or
    // one of the special single-char params @ * # ? $ ! - digits) is
    // the length of `$X`.  Other single chars (`:`, `+`, `=`, `%`, `/`)
    // are invalid names → bad substitution.
    //
    // `${#XY…}` with content after the operator char from `-?+=:` is
    // treated as `${#}` with that operator (e.g. `${#-word}` = count,
    // default word ignored because `#` is always "set").
    //
    // `${#NAME}` with a multi-char name is length of `$NAME`.
    let bad_single = |c: char| -> bool {
        // Single char that is NOT a valid parameter name → bad sub.
        !(c.is_ascii_alphanumeric() || c == '_'
          || matches!(c, '@' | '*' | '#' | '?' | '$' | '!' | '-'))
    };
    if chars[0] == '#' && n == 2 && bad_single(chars[1]) {
        eprintln!("{}: ${{{}}}: bad substitution",
            crate::exec::shell_name_with_line(), raw);
        return "\x00EXPAND_ERROR\x00".to_string();
    }
    let is_length_form = chars[0] == '#' && n > 1 && {
        // Single-char valid special/name → length.
        if n == 2 {
            true
        } else if matches!(chars[1], '-' | '?' | '+' | '=' | ':') {
            // Operator forms: don't treat as length.
            false
        } else {
            // Multi-char name: length of variable.
            true
        }
    };
    if is_length_form {
        let name: String = chars[1..].iter().collect();
        // ${#@} / ${#*}
        if name == "@" || name == "*" {
            return vars.positional_count().to_string();
        }
        // ${#OP} where OP is a single operator char from `%/` — bash
        // treats this as a bad substitution.
        if name.len() == 1 && matches!(chars[1], '%' | '/') {
            eprintln!("{}: ${{{}}}: bad substitution",
                crate::exec::shell_name_with_line(), raw);
            return "\x00EXPAND_ERROR\x00".to_string();
        }
        // Invalid identifier as name: starts with digit but has non-digit
        // chars (e.g. `${#1xyz}`).  Bash rejects this as bad substitution.
        // A name that is all digits is a positional-parameter reference,
        // which we allow.  A name that starts with a letter or underscore
        // must contain only identifier chars.  Single-char special
        // variables (`!`, `-`, `?`, `$`, `@`, `*`, `#`) are already
        // allowed above, but when the name is length > 1 we only accept
        // identifiers or digit-only positional refs.
        if name.len() > 1 {
            let first = chars[1];
            let all_digits = name.chars().all(|c| c.is_ascii_digit());
            let valid_ident = (first.is_ascii_alphabetic() || first == '_')
                && name.chars().all(|c| c.is_ascii_alphanumeric() || c == '_');
            let has_bracket = name.contains('[');
            if !all_digits && !valid_ident && !has_bracket {
                eprintln!("{}: ${{{}}}: bad substitution",
                    crate::exec::shell_name_with_line(), raw);
                return "\x00EXPAND_ERROR\x00".to_string();
            }
        }
        // Array: ${#arr[@]} / ${#arr[*]}
        if let Some(bracket) = name.find('[') {
            let arr_name = &name[..bracket];
            let idx_part = &name[bracket + 1..name.len().saturating_sub(1)];
            if idx_part == "@" || idx_part == "*" {
                let len = if vars.is_assoc(arr_name) {
                    vars.get_assoc_entries(arr_name).len()
                } else if vars.is_array(arr_name) {
                    vars.get_array(arr_name).map(|a| a.len()).unwrap_or(0)
                } else if vars.get(arr_name).is_some() {
                    1
                } else {
                    0
                };
                return len.to_string();
            }
            // Assoc: key is a string; expand any $vars first.
            if vars.is_assoc(arr_name) {
                let key = expand_subscript_word(idx_part, vars);
                if key.is_empty() {
                    eprintln!("{}: [{}]: bad array subscript",
                        crate::exec::shell_name_with_line(), idx_part);
                    return "\x00EXPAND_ERROR\x00".to_string();
                }
                let len = vars.get_assoc(arr_name, &key)
                    .map(|s| mb_char_count(&s)).unwrap_or(0);
                return len.to_string();
            }
            // ${#arr[n]}
            if let Ok(idx) = idx_part.parse::<usize>() {
                // `set -u` nounset on an array element: when arr
                // doesn't exist OR the specific index is unset, bash
                // treats it as an unbound variable error.
                if vars.nounset
                    && vars.get_array_element(arr_name, idx).is_none()
                {
                    eprintln!("{}: {}: unbound variable",
                        crate::exec::shell_name_with_line(), name);
                    return "\x00NOUNSET_ERROR\x00".to_string();
                }
                let len = vars.get_array_element(arr_name, idx)
                    .map(|s| mb_char_count(&s))
                    .unwrap_or(0);
                return len.to_string();
            }
            // Arithmetic subscript — handle negative indices and
            // report bad-subscript errors mirroring bash.
            let expanded_idx = expand_index_subscript_word(idx_part, vars);
            if let Ok(idx_num) = crate::arithmetic::eval_expr(&expanded_idx, vars) {
                let idx_val = if idx_num < 0 {
                    match vars.array_max_index(arr_name) {
                        Some(m) => {
                            let real = (m + 1) as i64 + idx_num;
                            if real < 0 {
                                return format!(
                                    "\x00ARITH_ERR\x00{}\x1Fbad array subscript\x00",
                                    format!("[{}]", expanded_idx)
                                );
                            }
                            real as usize
                        }
                        None => {
                            return format!(
                                "\x00ARITH_ERR\x00{}\x1Fbad array subscript\x00",
                                format!("[{}]", expanded_idx)
                            );
                        }
                    }
                } else {
                    idx_num as usize
                };
                let len = vars.get_array_element(arr_name, idx_val)
                    .map(|s| mb_char_count(&s))
                    .unwrap_or(0);
                return len.to_string();
            }
            let msg = crate::arithmetic::eval_expr(&expanded_idx, vars)
                .err()
                .unwrap_or_else(|| "arithmetic syntax error: operand expected".to_string());
            return format!("\x00ARITH_ERR\x00{}\x1F{}\x00", expanded_idx, msg);
        }
        let array_base_unset = vars.is_array(&name) && vars.get_array_element(&name, 0).is_none();
        let assoc_base_unset = vars.is_assoc(&name) && vars.get_assoc(&name, "0").is_none();
        // `set -u`: ${#NAME} on an unset plain variable is also a
        // fatal error (the length operator doesn't exempt nounset).
        if vars.nounset
            && (vars.get(&name).is_none() || array_base_unset || assoc_base_unset)
            && !name.is_empty()
            && {
                // PROVEN: name is non-empty (checked above), so chars().next() is Some.
                let first = name.chars().next().unwrap();
                (first.is_ascii_alphabetic() || first == '_')
                    || (first.is_ascii_digit() && name.chars().all(|c| c.is_ascii_digit()))
            }
        {
            eprintln!("{}: {}: unbound variable",
                crate::exec::shell_name_with_line(), name);
            return "\x00NOUNSET_ERROR\x00".to_string();
        }
        let val = expand_var_value(&name, vars).unwrap_or_default();
        return mb_char_count(&val).to_string();
    }

    // Detect the name and operator
    // Name can be: a plain identifier, a digit, @, *, #, ?, $, !, -, _
    // or arr[idx]
    let (name, op_start) = parse_param_name(&chars);
    let op_str: String = chars[op_start..].iter().collect();

    // Resolve the raw value of the variable
    let raw_value: Option<String> = resolve_raw_value(&name, vars, in_dquote);

    // Handle operators
    if op_str.is_empty() {
        // "${@}" with no positional args → EMPTY_AT sentinel so exec
        // discards the surrounding quoted word (like "$@" with none).
        if raw_value.is_none()
            && in_dquote
            && (name == "@" || name.ends_with("[@]"))
        {
            return "\x00EMPTY_AT\x00".to_string();
        }
        let array_base_unset = vars.is_array(&name) && vars.get_array_element(&name, 0).is_none();
        let assoc_base_unset = vars.is_assoc(&name) && vars.get_assoc(&name, "0").is_none();
        // `set -u` nounset: ${name} on an unset plain variable is a
        // fatal error.  Special parameters ($#, $@, $0, $1…) are
        // exempt — they're defined even when "unset" textually.
        // Digit-named positional parameters ($1, $9, …) DO trigger
        // nounset when the positional is not set (bash behaviour).
        // `$!` (last background PID) also triggers nounset when no
        // background job has been started yet.
        if vars.nounset && (raw_value.is_none() || array_base_unset || assoc_base_unset) && !name.is_empty() {
            // PROVEN: name is non-empty (checked in the if condition above).
            let first = name.chars().next().unwrap();
            let is_alpha = first.is_ascii_alphabetic() || first == '_';
            let is_digit = first.is_ascii_digit() && name.chars().all(|c| c.is_ascii_digit());
            let is_bang = name == "!"; // $! triggers nounset when no bg job
            if is_alpha || is_digit || is_bang {
                eprintln!("{}: {}: unbound variable",
                    crate::exec::shell_name_with_line(), name);
                return "\x00NOUNSET_ERROR\x00".to_string();
            }
        }
        return raw_value.unwrap_or_default();
    }

    // Helper: expand the word of a parameter expansion operator.
    // In unquoted context, only leading tilde is expanded (ParamWord mode).
    // In double-quoted context, tilde is completely suppressed and quote
    // handling follows double-quote rules.
    // When the word contains quoting and expands to empty, return a
    // QUOTED_NULL marker so that word splitting preserves the empty field.
    //
    // Bash behaviour for unquoted $@ in an operator word (${var-$@}, etc.):
    // • When IFS is null (""), $@ produces FFFE field-boundary markers so
    //   that the caller's word-split step treats each positional as a separate
    //   field.  This matches what bare $@ does with null IFS.
    // • When IFS is non-null (including default space/tab/newline or any
    //   non-standard string), the FFFE markers are converted to literal spaces
    //   before the result is returned.  The spaces may subsequently be split by
    //   word-split (for whitespace IFS) but never by a non-whitespace IFS,
    //   matching bash's observable (if "inconsistent") behaviour.
    let expand_op_word = |w: &str, vars: &mut Variables, in_dq: bool| -> String {
        let result = if in_dq {
            expand_all_param_word_dquote(w, vars)
        } else if in_heredoc {
            expand_all_param_word_heredoc(w, vars)
        } else {
            expand_all_param_word(w, vars)
        };
        // In unquoted / heredoc contexts: if IFS is non-null, convert the
        // \u{FFFE} field-separator markers that $@ produces into literal spaces.
        // (Null IFS keeps FFFE so that the null-IFS word-split step can still
        // distinguish the individual positionals.)
        let result = if !in_dq && result.contains('\u{FFFE}') {
            let ifs = vars.get("IFS").unwrap_or_else(|| " \t\n".to_string());
            if !ifs.is_empty() {
                result.replace('\u{FFFE}', " ")
            } else {
                result
            }
        } else {
            result
        };
        if result.is_empty() && !in_dq && word_has_quoting(w) {
            "\x00QNULL\x00".to_string()
        } else {
            result
        }
    };

    // ${name:-word}  use default if unset or null
    if let Some(word) = strip_prefix_op(&op_str, ":-") {
        if raw_value.as_deref() == Some("") && !in_dquote && word.starts_with('~') {
            return do_tilde_expand_with_policy(word, vars, false);
        }
        if raw_value.as_deref().map(|v| v.is_empty()).unwrap_or(true) {
            return expand_op_word(word, vars, in_dquote);
        }
        return raw_value.unwrap_or_default();
    }
    // ${name-word}  use default if unset
    if let Some(word) = strip_prefix_op(&op_str, "-") {
        if raw_value.is_none() {
            return expand_op_word(word, vars, in_dquote);
        }
        return raw_value.unwrap_or_default();
    }
    // ${name:=word}  assign default if unset or null (can't assign, just expand).
    // Unlike `-`/`:-`, the RHS of `=`/`:=` goes through an assignment,
    // which strips quote markers.  Bash-visible effect: `${a:=a\ b}`
    // unquoted expands to an unquoted literal that word-splits on the
    // space — backslash-quoted IFS chars DON'T protect from splitting
    // the way `${a:-a\ b}` does.  Strip CTLESC markers here so the
    // caller's word-splitter sees bare whitespace.
    if let Some(word) = strip_prefix_op(&op_str, ":=") {
        if raw_value.as_deref().map(|v| v.is_empty()).unwrap_or(true) {
            if !parameter_expansion_assignable(&name) {
                let display = format_param_assign_target(&name);
                eprintln!("{}: {}: cannot assign in this way",
                    crate::exec::shell_name_with_line(), display);
                return "\x00EXPAND_ERROR\x00".to_string();
            }
            let v = expand_op_word(word, vars, in_dquote);
            return v.replace(CTLESC, "");
        }
        return raw_value.unwrap_or_default();
    }
    // ${name=word}  assign default if unset
    if let Some(word) = strip_prefix_op(&op_str, "=") {
        if raw_value.is_none() {
            if !parameter_expansion_assignable(&name) {
                let display = format_param_assign_target(&name);
                eprintln!("{}: {}: cannot assign in this way",
                    crate::exec::shell_name_with_line(), display);
                return "\x00EXPAND_ERROR\x00".to_string();
            }
            let v = expand_op_word(word, vars, in_dquote);
            return v.replace(CTLESC, "");
        }
        return raw_value.unwrap_or_default();
    }
    // ${name:+alt}  use alt if set and non-null
    if let Some(word) = strip_prefix_op(&op_str, ":+") {
        if raw_value.as_deref().map(|v| !v.is_empty()).unwrap_or(false) {
            if in_dquote && has_unmatched_cmdsub_in_dquote(word) {
                report_unmatched_cmdsub(vars);
                return "\x00EXPAND_ERROR\x00".to_string();
            }
            return expand_op_word(word, vars, in_dquote);
        }
        return String::new();
    }
    // ${name+alt}  use alt if set
    if let Some(word) = strip_prefix_op(&op_str, "+") {
        if raw_value.is_some() {
            if in_dquote && has_unmatched_cmdsub_in_dquote(word) {
                report_unmatched_cmdsub(vars);
                return "\x00EXPAND_ERROR\x00".to_string();
            }
            return expand_op_word(word, vars, in_dquote);
        }
        return String::new();
    }
    // ${name:?error}  error if unset or null
    if let Some(word) = strip_prefix_op(&op_str, ":?") {
        if raw_value.as_deref().map(|v| v.is_empty()).unwrap_or(true) {
            let msg = expand_all(word, vars);
            // Bash uses "parameter null or not set" for `:?` with a
            // defaulted (empty) message, and the user-supplied text
            // otherwise.
            let err_msg = if msg.is_empty() {
                format!("{}: parameter null or not set", name)
            } else {
                format!("{}: {}", name, msg)
            };
            eprintln!("{}: {}", crate::exec::shell_name_with_line(), err_msg);
            // Non-interactive shells exit 127 on this error to match
            // bash.  We signal the fatal condition via the
            // EXPAND_ERROR sentinel which exec converts to a
            // non-zero exit + aborts the current command.
            return "\x00EXPAND_ERROR\x00".to_string();
        }
        return raw_value.unwrap_or_default();
    }
    // ${name?error}  error if unset
    if let Some(word) = strip_prefix_op(&op_str, "?") {
        if raw_value.is_none() {
            let msg = expand_all(word, vars);
            // Bash uses "parameter not set" (no "null or") for `?`.
            let err_msg = if msg.is_empty() {
                format!("{}: parameter not set", name)
            } else {
                format!("{}: {}", name, msg)
            };
            eprintln!("{}: {}", crate::exec::shell_name_with_line(), err_msg);
            return "\x00EXPAND_ERROR\x00".to_string();
        }
        return raw_value.unwrap_or_default();
    }

    // `set -u` nounset: for the remaining operators (`#`, `##`, `%`,
    // `%%`, `/`, `//`, `^`, `^^`, `,`, `,,`, `~`, `~~`, `:offset`),
    // bash treats an unset parameter as a fatal error — unlike
    // `${name-word}` / `${name+word}` / `${name?word}` which are
    // deliberately exempt.
    let nounset_transform_exempt = matches!(op_str.as_str(), "@a" | "@A")
        && transform_target_is_set_for_nounset(&name, &raw_value, vars);
    if vars.nounset
        && raw_value.is_none()
        && !name.is_empty()
        && (name.chars().next().map_or(false, |c| c.is_ascii_alphabetic() || c == '_')
            || name == "!") // $! triggers nounset for transform ops too
        && !nounset_transform_exempt
    {
        eprintln!("{}: {}: unbound variable",
            crate::exec::shell_name_with_line(), name);
        return "\x00NOUNSET_ERROR\x00".to_string();
    }

    // From here on we need a concrete value (keep raw_value in scope for
    // later transformations like @A that distinguish unset from empty).
    let value = raw_value.clone().unwrap_or_default();

    // ${name:offset} / ${name:offset:length}  substring or array slice
    if let Some(rest) = op_str.strip_prefix(':') {
        // Check it's not one of the operator prefixes handled above
        if !rest.starts_with('-') && !rest.starts_with('=') &&
           !rest.starts_with('+') && !rest.starts_with('?')
        {
            // For @, *, arr[@], arr[*]: do array element slicing.
            // But for `${scalar[@]:n}` (scalar variable accessed with [@]),
            // bash treats it as character substring (`${scalar:n}`), not
            // element slicing.
            let is_array_like = name == "@" || name == "*"
                || name.ends_with("[@]") || name.ends_with("[*]");
            if is_array_like {
                // Check if the base variable is actually an array or assoc.
                // Positional parameters (@/*) always use element slicing.
                let is_real_array_or_positional = name == "@" || name == "*" || {
                    let base: &str = name.find('[').map(|i| &name[..i]).unwrap_or(&name);
                    vars.is_array(base) || vars.is_assoc(base)
                };
                if is_real_array_or_positional {
                    if let Some(elements) = resolve_elements(&name, vars) {
                        return apply_array_slice(&name, &elements, rest, vars, in_dquote);
                    }
                }
            }
            return apply_substring(&value, rest, vars, &name);
        }
    }

    // ── Per-element operations for array-like parameters ──
    // When the name is @, *, arr[@] or arr[*], bash applies #, ##, %, %%,
    // /, //, ^, ^^, ,, , to **each element individually**.
    let elements = resolve_elements(&name, vars);
    let array_like_param = name == "@" || name == "*"
        || name.ends_with("[@]") || name.ends_with("[*]");
    let no_split = NO_SPLIT_CONTEXT.with(|flag| flag.get());
    let sep = array_sep(&name, vars, in_dquote);
    let sep: &str = sep.as_str();

    // Helper macro: apply a transformation function to each element (if
    // this is an array-like parameter) or to the whole value otherwise.
    macro_rules! apply_per_elem {
        ($f:expr) => {
            if let Some(ref elems) = elements {
                return elems.iter().map(|e| $f(e)).collect::<Vec<_>>().join(sep);
            } else if array_like_param {
                if in_dquote && !no_split
                    && (name == "@" || name.ends_with("[@]"))
                {
                    return "\x00EMPTY_AT\x00".to_string();
                }
                return String::new();
            } else {
                return $f(&value);
            }
        };
    }

    // ${name##pattern} / ${name#pattern}  prefix removal
    if op_str.starts_with("##") {
        let pat_raw = &op_str[2..];
        let pat = expand_case_pattern_for_patsub(pat_raw, vars);
        if pat.contains("\x00EXPAND_ERROR\x00") { return "\x00EXPAND_ERROR\x00".to_string(); }
        apply_per_elem!(|v: &String| glob_remove_prefix(v, &pat, true));
    }
    if op_str.starts_with('#') && !op_str[1..].is_empty() {
        let pat_raw = &op_str[1..];
        let pat = expand_case_pattern_for_patsub(pat_raw, vars);
        if pat.contains("\x00EXPAND_ERROR\x00") { return "\x00EXPAND_ERROR\x00".to_string(); }
        apply_per_elem!(|v: &String| glob_remove_prefix(v, &pat, false));
    }

    // ${name%%pattern} / ${name%pattern}  suffix removal
    if op_str.starts_with("%%") {
        let pat_raw = &op_str[2..];
        let pat = expand_case_pattern_for_patsub(pat_raw, vars);
        if pat.contains("\x00EXPAND_ERROR\x00") { return "\x00EXPAND_ERROR\x00".to_string(); }
        apply_per_elem!(|v: &String| glob_remove_suffix(v, &pat, true));
    }
    if op_str.starts_with('%') {
        let pat_raw = &op_str[1..];
        let pat = expand_case_pattern_for_patsub(pat_raw, vars);
        if pat.contains("\x00EXPAND_ERROR\x00") { return "\x00EXPAND_ERROR\x00".to_string(); }
        apply_per_elem!(|v: &String| glob_remove_suffix(v, &pat, false));
    }

    // ${name//pat/repl} / ${name/pat/repl}  substitution
    // The replacement is always expanded with unquoted semantics so that
    // backslash-quoting (e.g. \') works the same way as outside double quotes.
    if op_str.starts_with("//") {
        let rest = &op_str[2..];
        let (pat_raw, repl_raw) = split_subst_pattern(rest);
        let pat = expand_case_pattern_for_patsub(pat_raw, vars);
        if pat.contains("\x00EXPAND_ERROR\x00") { return "\x00EXPAND_ERROR\x00".to_string(); }
        let repl = protect_ifs_chars_for_subst(&expand_patsub_replacement_word(repl_raw, vars), vars);
        apply_per_elem!(|v: &String| glob_replace(v, &pat, &repl, true));
    }
    if op_str.starts_with('/') {
        let rest = &op_str[1..];
        // Special: /#pat/repl  (anchor at start) and /%pat/repl (anchor at end)
        if rest.starts_with('#') {
            let rest2 = &rest[1..];
            let (pat_raw, repl_raw) = split_subst_pattern_anchored(rest2);
            let pat = expand_case_pattern_for_patsub(pat_raw, vars);
            if pat.contains("\x00EXPAND_ERROR\x00") { return "\x00EXPAND_ERROR\x00".to_string(); }
            let repl = protect_ifs_chars_for_subst(&expand_patsub_replacement_word(repl_raw, vars), vars);
            apply_per_elem!(|v: &String| glob_replace_anchored(v, &pat, &repl, true, false));
        }
        if rest.starts_with('%') {
            let rest2 = &rest[1..];
            let (pat_raw, repl_raw) = split_subst_pattern_anchored(rest2);
            let pat = expand_case_pattern_for_patsub(pat_raw, vars);
            if pat.contains("\x00EXPAND_ERROR\x00") { return "\x00EXPAND_ERROR\x00".to_string(); }
            let repl = protect_ifs_chars_for_subst(&expand_patsub_replacement_word(repl_raw, vars), vars);
            apply_per_elem!(|v: &String| glob_replace_anchored(v, &pat, &repl, false, true));
        }
        let (pat_raw, repl_raw) = split_subst_pattern(rest);
        let pat = expand_case_pattern_for_patsub(pat_raw, vars);
        if pat.contains("\x00EXPAND_ERROR\x00") { return "\x00EXPAND_ERROR\x00".to_string(); }
        let repl = protect_ifs_chars_for_subst(&expand_patsub_replacement_word(repl_raw, vars), vars);
        apply_per_elem!(|v: &String| glob_replace(v, &pat, &repl, false));
    }

    // ${name^^pat} / ${name^pat}  uppercase
    if op_str.starts_with("^^") {
        let pat_raw = &op_str[2..];
        let pat = expand_case_pattern_for_patsub(pat_raw, vars);
        if pat.contains("\x00EXPAND_ERROR\x00") { return "\x00EXPAND_ERROR\x00".to_string(); }
        apply_per_elem!(|v: &String| case_modify(v, &pat, true, true));
    }
    if op_str.starts_with('^') {
        let pat_raw = &op_str[1..];
        let pat = expand_case_pattern_for_patsub(pat_raw, vars);
        if pat.contains("\x00EXPAND_ERROR\x00") { return "\x00EXPAND_ERROR\x00".to_string(); }
        apply_per_elem!(|v: &String| case_modify(v, &pat, true, false));
    }

    // ${name,,pat} / ${name,pat}  lowercase
    if op_str.starts_with(",,") {
        let pat_raw = &op_str[2..];
        let pat = expand_case_pattern_for_patsub(pat_raw, vars);
        if pat.contains("\x00EXPAND_ERROR\x00") { return "\x00EXPAND_ERROR\x00".to_string(); }
        apply_per_elem!(|v: &String| case_modify(v, &pat, false, true));
    }
    if op_str.starts_with(',') {
        let pat_raw = &op_str[1..];
        let pat = expand_case_pattern_for_patsub(pat_raw, vars);
        if pat.contains("\x00EXPAND_ERROR\x00") { return "\x00EXPAND_ERROR\x00".to_string(); }
        apply_per_elem!(|v: &String| case_modify(v, &pat, false, false));
    }

    // ${name~~pat} / ${name~pat}  toggle case
    if op_str.starts_with("~~") {
        let pat_raw = &op_str[2..];
        let pat = expand_case_pattern_for_patsub(pat_raw, vars);
        if pat.contains("\x00EXPAND_ERROR\x00") { return "\x00EXPAND_ERROR\x00".to_string(); }
        apply_per_elem!(|v: &String| case_toggle(v, &pat, true));
    }
    if op_str.starts_with('~') {
        let pat_raw = &op_str[1..];
        let pat = expand_case_pattern_for_patsub(pat_raw, vars);
        if pat.contains("\x00EXPAND_ERROR\x00") { return "\x00EXPAND_ERROR\x00".to_string(); }
        apply_per_elem!(|v: &String| case_toggle(v, &pat, false));
    }

    // ${name@Q}, ${name@E}, ${name@A}, ${name@a}, ${name@U}, ${name@u},
    // ${name@L}, ${name@K}, ${name@k}, ${name@P} — parameter transformation
    if op_str.starts_with('@') && op_str.len() == 2 {
        // PROVEN: op_str has exactly 2 chars (len() == 2 checked above), so nth(1) is Some.
        let op = op_str.chars().nth(1).unwrap();
        return apply_at_transform(op, &name, &value, &raw_value, elements.as_deref(), sep, vars);
    }

    // Normalize $'...' in the raw string for error message display.
    // Bash shows ${'x1'%'t'} not ${'x1'%$'t'} — it strips the $ prefix
    // from ANSI-C quoted strings in bad-substitution error messages.
    let raw_display = raw.replace("$'", "'");
    eprintln!("{}: ${{{}}}: bad substitution",
        crate::exec::shell_name_with_line(), raw_display);
    "\x00EXPAND_ERROR\x00".to_string()
}

/// Apply a ${name@X} parameter transformation.
fn apply_at_transform(
    op: char,
    name: &str,
    value: &str,
    raw_value: &Option<String>,
    elements: Option<&[String]>,
    sep: &str,
    vars: &Variables,
) -> String {
    let base = name.split('[').next().unwrap_or(name);
    let is_unset_scalar = elements.is_none() && raw_value.is_none() && !vars.has_entry(base);
    match op {
        'Q' => {
            if is_unset_scalar {
                return String::new();
            }
            if let Some(elems) = elements {
                return elems.iter().map(|e| at_shell_quote(e))
                    .collect::<Vec<_>>().join(sep);
            }
            at_shell_quote(value)
        }
        'E' => {
            if let Some(elems) = elements {
                return elems.iter().map(|e| expand_ansi_c_escapes(e))
                    .collect::<Vec<_>>().join(sep);
            }
            expand_ansi_c_escapes(value)
        }
        'U' => {
            if let Some(elems) = elements {
                return elems.iter().map(|e| e.to_uppercase())
                    .collect::<Vec<_>>().join(sep);
            }
            value.to_uppercase()
        }
        'u' => {
            if let Some(elems) = elements {
                return elems.iter().map(|e| capitalize_first(e))
                    .collect::<Vec<_>>().join(sep);
            }
            capitalize_first(value)
        }
        'L' => {
            if let Some(elems) = elements {
                return elems.iter().map(|e| e.to_lowercase())
                    .collect::<Vec<_>>().join(sep);
            }
            value.to_lowercase()
        }
        'a' => {
            // Attribute-flag string.
            attribute_flags(name, vars)
        }
        'A' => {
            if is_unset_scalar {
                return String::new();
            }
            // Assignment-statement form (`declare -x name='value'` or `name='value'`).
            declare_form(name, raw_value.as_deref(), vars)
        }
        'K' | 'k' => keyvalue_form(name, op == 'K', sep, vars),
        'P' => {
            let mut prompt_vars = vars.clone();
            crate::exec::expand_prompt_for_expand(value, &mut prompt_vars)
        }
        _ => {
            eprintln!("{}: ${{{}@{}}}: bad substitution",
                crate::exec::shell_name_with_line(), name, op);
            "\x00EXPAND_ERROR\x00".to_string()
        }
    }
}

/// Shell-quote a string for ${var@Q} using sh_single_quote rules.
fn at_shell_quote(s: &str) -> String {
    // Detect chars needing $'…' ANSI-C form: control chars and brash's
    // PUA-encoded raw bytes (U+F801..U+F8FF for 0x01..0xFF).  We iterate
    // by char so a single PUA char prints as one octal escape, not the
    // 3-byte UTF-8 form of that PUA codepoint.
    let needs_ansi = s.chars().any(|c| {
        c.is_control() || matches!(c as u32, 0xF801..=0xF8FF)
    });
    if needs_ansi {
        let mut result = String::from("$'");
        for c in s.chars() {
            match c {
                '\x07' => result.push_str("\\a"),
                '\x08' => result.push_str("\\b"),
                '\t' => result.push_str("\\t"),
                '\n' => result.push_str("\\n"),
                '\x0b' => result.push_str("\\v"),
                '\x0c' => result.push_str("\\f"),
                '\r' => result.push_str("\\r"),
                '\\' => result.push_str("\\\\"),
                '\'' => result.push_str("\\'"),
                c if c.is_control() => {
                    result.push_str(&format!("\\{:03o}", c as u32));
                }
                c if matches!(c as u32, 0xF801..=0xF8FF) => {
                    let b = (c as u32) - 0xF800;
                    result.push_str(&format!("\\{:03o}", b));
                }
                c => result.push(c),
            }
        }
        result.push('\'');
        return result;
    }
    if s == "'" {
        return "\\'".to_string();
    }
    let mut result = String::from("'");
    for c in s.chars() {
        if c == '\'' {
            result.push_str("'\\''");
        } else {
            result.push(c);
        }
    }
    result.push('\'');
    result
}

fn capitalize_first(s: &str) -> String {
    let mut chars = s.chars();
    match chars.next() {
        None => String::new(),
        Some(first) => first.to_uppercase().chain(chars).collect(),
    }
}

/// Return the attribute-flag string for ${var@a}.
/// Order (matching bash's output): a/A, i, r, x, l, u, c, t, n.
fn attribute_flags(name: &str, vars: &Variables) -> String {
    // Strip [@] / [*] / [N] subscript so `${arr[@]@a}` looks at the array.
    let base = if let Some(b) = name.find('[') { &name[..b] } else { name };
    let mut f = String::new();
    if vars.is_array(base) { f.push('a'); }
    if vars.is_assoc(base) { f.push('A'); }
    if vars.get_entry_is_integer_raw(base) { f.push('i'); }
    if vars.is_readonly_raw(base) { f.push('r'); }
    if vars.is_exported_raw(base) { f.push('x'); }
    if vars.is_lowercase_raw(base) { f.push('l'); }
    if vars.is_uppercase_raw(base) { f.push('u'); }
    if vars.is_capitalize_raw(base) { f.push('c'); }
    if vars.is_nameref(base) { f.push('n'); }
    f
}

fn transform_target_is_set_for_nounset(
    name: &str,
    raw_value: &Option<String>,
    vars: &Variables,
) -> bool {
    if raw_value.is_some() {
        return true;
    }
    let base = name.split('[').next().unwrap_or(name);
    if vars.is_assoc(base) {
        return !vars.get_assoc_entries(base).is_empty();
    }
    if vars.is_array(base) {
        return vars.array_length(base) > 0;
    }
    vars.has_entry(base) && vars.get_entry_is_initialized_raw(base)
}

/// Build the `declare …` assignment-statement form for ${var@A}.
/// Unlike `declare -p`, @A uses sh_single_quote style ('…' or $'…') for
/// values, not the double-quoted form.
fn declare_form(name: &str, raw_value: Option<&str>, vars: &Variables) -> String {
    // Strip subscript — assignment form always refers to the whole variable.
    let base = if let Some(b) = name.find('[') { &name[..b] } else { name };

    // Special parameters ($@, $*, etc.) produce the `set --` form.
    if base == "@" || base == "*" {
        let positionals = vars.all_positional(vars.positional_count());
        let mut out = String::from("set --");
        for p in &positionals {
            out.push(' ');
            out.push_str(&at_shell_quote(p));
        }
        return out;
    }

    // Arrays → `declare -a name=([k]=v …)` / `declare -A name=(…)`.
    // Bash's @A uses DOUBLE-quoted element values in the array literal
    // (same format as `declare -p`), but still uses single-quoting for
    // scalar values containing apostrophes.
    if vars.is_array(base) && !vars.is_assoc(base) {
        let elements = vars.get_array(base).unwrap_or_default();
        let mut flags = String::from("a");
        if vars.get_entry_is_integer_raw(base) { flags.push('i'); }
        if vars.is_readonly_raw(base) { flags.push('r'); }
        if vars.is_exported_raw(base) { flags.push('x'); }
        if vars.is_lowercase_raw(base) { flags.push('l'); }
        if vars.is_uppercase_raw(base) { flags.push('u'); }
        if vars.is_capitalize_raw(base) { flags.push('c'); }
        let parts: Vec<String> = elements.iter().enumerate()
            .map(|(i, v)| format!("[{}]={}", i, quote_for_declare(v)))
            .collect();
        // Empty integer arrays print as `declare -ai foo`, while plain empty
        // arrays keep the explicit `=()` form. Uninitialized arrays also omit
        // the assignment entirely.
        if (vars.get_entry_is_integer_raw(base) || !vars.get_entry_is_initialized_raw(base))
            && parts.is_empty()
        {
            return format!("declare -{} {}", flags, base);
        }
        return format!("declare -{} {}=({})", flags, base, parts.join(" "));
    }
    if vars.is_assoc(base) {
        let entries = vars.get_assoc_entries(base);
        let mut flags = String::from("A");
        if vars.get_entry_is_integer_raw(base) { flags.push('i'); }
        if vars.is_readonly_raw(base) { flags.push('r'); }
        if vars.is_exported_raw(base) { flags.push('x'); }
        if vars.is_lowercase_raw(base) { flags.push('l'); }
        if vars.is_uppercase_raw(base) { flags.push('u'); }
        if vars.is_capitalize_raw(base) { flags.push('c'); }
        let parts: Vec<String> = entries.iter()
            .map(|(k, v)| format!("[{}]={}", quote_key_for_assoc_transform(k), quote_for_declare(v)))
            .collect();
        if !vars.get_entry_is_initialized_raw(base) && parts.is_empty() {
            return format!("declare -{} {}", flags, base);
        }
        if parts.is_empty() {
            return format!("declare -{} {}=()", flags, base);
        }
        return format!("declare -{} {}=({} )", flags, base, parts.join(" "));
    }

    // Scalar: build flags string.  Bash uses sh_single_quote for @A on
    // scalars (so `x='ab '\''cd'\'' ef'` rather than double-quoted).
    let mut flags = String::new();
    if vars.get_entry_is_integer_raw(base) { flags.push('i'); }
    if vars.is_readonly_raw(base) { flags.push('r'); }
    if vars.is_exported_raw(base) { flags.push('x'); }
    if vars.is_lowercase_raw(base) { flags.push('l'); }
    if vars.is_uppercase_raw(base) { flags.push('u'); }
    if vars.is_capitalize_raw(base) { flags.push('c'); }
    if vars.is_nameref(base) { flags.push('n'); }
    // Bash `${var@A}` for a flagless scalar emits a bare `name=value`
    // assignment statement (no `declare --` prefix).  Only when the
    // variable has at least one attribute does the `declare -X` form kick
    // in.
    if flags.is_empty() {
        return match raw_value {
            Some(v) => format!("{}={}", base, at_shell_quote(v)),
            None => base.to_string(),
        };
    }
    let flag_str = format!("-{}", flags);
    match raw_value {
        Some(v) => format!("declare {} {}={}", flag_str, base, at_shell_quote(v)),
        None => format!("declare {} {}", flag_str, base),
    }
}

/// Quote a value for use in a `declare name=VALUE` output (same as
/// `builtins::quote_for_declare`).
fn quote_for_declare(s: &str) -> String {
    // Bash's `declare -p` uses a "$"-prefixed single-quoted form when
    // the value contains non-printable chars (control chars OR brash's
    // PUA-encoded raw bytes for 0x80..0xff).  Otherwise a plain
    // double-quoted form with backslash escapes.
    let bytes = s.as_bytes();
    let has_ctl = bytes.iter().any(|&b| b < 0x20 || b == 0x7f);
    let has_high_byte = s.chars().any(|c| matches!(c as u32, 0xF801..=0xF8FF));
    if has_ctl || has_high_byte {
        return at_shell_quote(s);
    }
    // Double-quote with backslash escaping for $, `, ", \
    let mut r = String::from("\"");
    for c in s.chars() {
        match c {
            '$' | '`' | '"' | '\\' => { r.push('\\'); r.push(c); }
            _ => r.push(c),
        }
    }
    r.push('"');
    r
}

fn quote_key_for_assoc_transform(key: &str) -> String {
    let bare = !key.is_empty()
        && key.chars().all(|c| {
            c.is_ascii_alphanumeric()
                || matches!(c, '_' | '+' | '-' | '.' | '/' | ':' | '%' | '=')
        });
    if bare {
        key.to_string()
    } else {
        quote_for_declare(key)
    }
}

/// Produce the key/value pair form for ${var@K} / ${var@k}.
///
/// For associative and indexed arrays: `key0 val0 key1 val1 …` with
/// @K double-quoting values (bash's `declare -p` style) and @k leaving
/// them unquoted.  For scalars: the @Q shell-quoted value.
/// For $@ / $*: positional parameter index/value pairs.
fn keyvalue_form(name: &str, quoted: bool, sep: &str, vars: &Variables) -> String {
    let base = if let Some(b) = name.find('[') { &name[..b] } else { name };

    if base == "@" || base == "*" {
        let positionals = vars.all_positional(vars.positional_count());
        // Bash's ${@@K} / ${@@k} do not synthesize numeric keys.  They
        // return the positional parameters themselves, shell-quoted so the
        // result can be fed back into `eval name=( "${@@K}" )`.
        let parts: Vec<String> = positionals.iter().map(|v| {
            if quoted || base == "@" || base == "*" {
                at_shell_quote(v)
            } else {
                v.clone()
            }
        }).collect();
        return parts.join(sep);
    }

    if vars.is_assoc(base) {
        let entries = vars.get_assoc_entries(base);
        let mut parts = Vec::new();
        for (k, v) in &entries {
            if quoted {
                parts.push(quote_key_for_assoc_transform(k));
                parts.push(quote_for_declare(v));
            } else {
                parts.push(k.clone());
                parts.push(v.clone());
            }
        }
        return parts.join(if quoted { " " } else { sep });
    }
    if vars.is_array(base) {
        let elems = vars.get_array(base).unwrap_or_default();
        let mut parts = Vec::new();
        for (i, v) in elems.iter().enumerate() {
            let key = i.to_string();
            if quoted {
                parts.push(key);
                parts.push(quote_for_declare(v));
            } else {
                parts.push(key);
                parts.push(v.clone());
            }
        }
        return parts.join(if quoted { " " } else { sep });
    }
    // Scalar: @K and @k both produce the @Q (sh_single_quote) form.
    at_shell_quote(&vars.get(base).unwrap_or_default())
}

/// Expand ANSI-C escape sequences in-place (for ${var@E}).
fn expand_ansi_c_escapes(s: &str) -> String {
    let mut out = String::with_capacity(s.len());
    let bytes = s.as_bytes();
    let mut i = 0;
    while i < bytes.len() {
        if bytes[i] == b'\\' && i + 1 < bytes.len() {
            let c = bytes[i + 1];
            match c {
                b'a' => { out.push('\x07'); i += 2; }
                b'b' => { out.push('\x08'); i += 2; }
                b't' => { out.push('\t'); i += 2; }
                b'n' => { out.push('\n'); i += 2; }
                b'v' => { out.push('\x0b'); i += 2; }
                b'f' => { out.push('\x0c'); i += 2; }
                b'r' => { out.push('\r'); i += 2; }
                b'\\' => { out.push('\\'); i += 2; }
                b'\'' => { out.push('\''); i += 2; }
                b'"' => { out.push('"'); i += 2; }
                b'e' | b'E' => { out.push('\x1b'); i += 2; }
                b'0'..=b'7' => {
                    let mut val: u32 = 0;
                    let mut j = 1;
                    while j <= 3 && i + j < bytes.len()
                        && (bytes[i + j] >= b'0' && bytes[i + j] <= b'7')
                    {
                        val = val * 8 + (bytes[i + j] - b'0') as u32;
                        j += 1;
                    }
                    out.push((val & 0xff) as u8 as char);
                    i += j;
                }
                b'x' => {
                    let mut val: u32 = 0;
                    let mut j = 2;
                    while j <= 3 && i + j < bytes.len()
                        && bytes[i + j].is_ascii_hexdigit()
                    {
                        // PROVEN: loop guard confirmed is_ascii_hexdigit(), so to_digit(16) is Some.
                        val = val * 16 + (bytes[i + j] as char).to_digit(16).unwrap();
                        j += 1;
                    }
                    if j == 2 {
                        out.push('\\');
                        out.push('x');
                        i += 2;
                    } else {
                        out.push((val & 0xff) as u8 as char);
                        i += j;
                    }
                }
                _ => {
                    out.push('\\');
                    i += 1;
                }
            }
        } else {
            out.push(bytes[i] as char);
            i += 1;
        }
    }
    out
}

// ─────────────────────────────────────────────────────────────────────────────
// Parameter name parsing helpers
// ─────────────────────────────────────────────────────────────────────────────

/// Parse the variable name portion at the start of a `${…}` body.
/// Returns `(name, operator_start_index)`.
fn parse_param_name(chars: &[char]) -> (String, usize) {
    let n = chars.len();
    if n == 0 {
        return (String::new(), 0);
    }

    // Special single-char names: @ * # ? $ ! - _  and digits
    match chars[0] {
        '@' => return ("@".to_string(), 1),
        '*' => return ("*".to_string(), 1),
        '?' => return ("?".to_string(), 1),
        '$' => return ("$".to_string(), 1),
        '!' => {
            // Could be ${!…} (indirect) – handled in expand_param_raw before we get here
            return ("!".to_string(), 1);
        }
        '#' => return ("#".to_string(), 1),
        '-' => return ("-".to_string(), 1),
        '0'..='9' => {
            // May be multi-digit for ${10} etc.
            let mut end = 0;
            while end < n && chars[end].is_ascii_digit() {
                end += 1;
            }
            let name: String = chars[..end].iter().collect();
            return (name, end);
        }
        _ => {}
    }

    // Regular identifier, possibly with array subscript arr[idx]
    let mut end = 0;
    while end < n && (chars[end].is_ascii_alphanumeric() || chars[end] == '_') {
        end += 1;
    }

    // Array subscript?
    if end < n && chars[end] == '[' {
        end += 1; // skip [
        let mut depth = 1usize;
        let mut in_sq = false;
        let mut in_dq = false;
        while end < n {
            let c = chars[end];
            if in_sq {
                if c == '\'' {
                    in_sq = false;
                }
                end += 1;
                continue;
            }
            if in_dq {
                if c == '\\' && end + 1 < n {
                    end += 2;
                    continue;
                }
                if c == '"' {
                    in_dq = false;
                }
                end += 1;
                continue;
            }
            match c {
                '\\' => {
                    end += if end + 1 < n { 2 } else { 1 };
                    continue;
                }
                '\'' => {
                    in_sq = true;
                    end += 1;
                    continue;
                }
                '"' => {
                    in_dq = true;
                    end += 1;
                    continue;
                }
                '$' if end + 1 < n && chars[end + 1] == '(' => {
                    end += 2;
                    let mut paren_depth = 1usize;
                    while end < n && paren_depth > 0 {
                        match chars[end] {
                            '\\' => {
                                end += if end + 1 < n { 2 } else { 1 };
                            }
                            '\'' => {
                                end += 1;
                                while end < n {
                                    if chars[end] == '\'' {
                                        end += 1;
                                        break;
                                    }
                                    end += 1;
                                }
                            }
                            '"' => {
                                end += 1;
                                while end < n {
                                    if chars[end] == '\\' && end + 1 < n {
                                        end += 2;
                                        continue;
                                    }
                                    if chars[end] == '"' {
                                        end += 1;
                                        break;
                                    }
                                    end += 1;
                                }
                            }
                            '(' => {
                                paren_depth += 1;
                                end += 1;
                            }
                            ')' => {
                                paren_depth -= 1;
                                end += 1;
                            }
                            _ => end += 1,
                        }
                    }
                    continue;
                }
                '[' => depth += 1,
                ']' => {
                    depth -= 1;
                    end += 1;
                    if depth == 0 { break; }
                    continue;
                }
                _ => {}
            }
            end += 1;
        }
        let name: String = chars[..end].iter().collect();
        return (name, end);
    }

    let name: String = chars[..end].iter().collect();
    (name, end)
}

fn expand_subscript_word(expr: &str, vars: &mut Variables) -> String {
    let expanded = expand_impl(expr, vars, TildeMode::None, false)
        .replace("\x00QNULL\x00", "")
        .replace(CTLESC, "")
        .replace('\u{FFFE}', " ")
        .replace('\u{FFFF}', " ");
    crate::exec::resolve_cmdsubs_for_expand(&expanded, vars)
}

fn strip_outer_subscript_quotes(s: &str) -> String {
    if s.len() >= 2 {
        if (s.starts_with('"') && s.ends_with('"'))
            || (s.starts_with('\'') && s.ends_with('\'')) {
            return s[1..s.len() - 1].to_string();
        }
    }
    s.to_string()
}

fn assoc_subscript_needs_source_expansion(expr: &str) -> bool {
    let trimmed = expr.trim();
    trimmed.starts_with('~')
        || trimmed.contains('$')
        || trimmed.contains('`')
        || trimmed.contains('\\')
        || (trimmed.len() >= 2
            && ((trimmed.starts_with('"') && trimmed.ends_with('"'))
                || (trimmed.starts_with('\'') && trimmed.ends_with('\''))))
}

pub fn expand_assoc_subscript_key_pub(expr: &str, vars: &mut Variables) -> String {
    let trimmed = expr.trim();
    if trimmed.is_empty() {
        return expr.to_string();
    }
    let key = if assoc_subscript_needs_source_expansion(expr) {
        if expr == trimmed
            && trimmed.starts_with('~')
            && !trimmed.contains('"')
            && !trimmed.contains('\'')
            && !trimmed.contains('$')
            && !trimmed.contains('`')
            && !trimmed.contains('\\')
        {
            do_tilde_expand_with_policy(trimmed, vars, false)
        } else {
            expand_subscript_word(expr, vars)
        }
    } else {
        expr.to_string()
    };
    strip_outer_subscript_quotes(&key)
}

fn expand_index_subscript_word(expr: &str, vars: &mut Variables) -> String {
    let trimmed = expr.trim();
    if trimmed.len() >= 2 && trimmed.starts_with('\'') && trimmed.ends_with('\'') {
        trimmed.to_string()
    } else {
        expand_subscript_word(expr, vars)
    }
}

pub fn expand_subscript_word_pub(expr: &str, vars: &mut Variables) -> String {
    expand_subscript_word(expr, vars)
}

pub fn expand_index_subscript_word_pub(expr: &str, vars: &mut Variables) -> String {
    expand_index_subscript_word(expr, vars)
}

/// Resolve the value for a variable name (including special vars, arrays, etc.).
fn resolve_raw_value(name: &str, vars: &mut Variables, in_dquote: bool) -> Option<String> {
    match name {
        "@" => {
            let pos = vars.all_positional(vars.positional_count());
            // Both quoted and unquoted $@ produce separate words.
            // For operator checks, treat @ with no positional args as
            // "unset" so that ${@-word} / ${@+word} follow the bash rule
            // of falling to the default when there are no positionals.
            if pos.is_empty() {
                return None;
            }
            let sep = if in_dquote { "\u{FFFF}" } else { "\u{FFFE}" };
            Some(pos.join(sep))
        }
        "*" => {
            let pos = vars.all_positional(vars.positional_count());
            // Like `@`, treat `*` with no positional args as unset for
            // operator checks (`${*-word}` falls to the default).
            if pos.is_empty() {
                return None;
            }
            let no_split = NO_SPLIT_CONTEXT.with(|flag| flag.get());
            if in_dquote || no_split {
                // "$*" → join with IFS[0]
                let ifs = vars.get("IFS").unwrap_or_else(|| " ".to_string());
                let sep = ifs.chars().next().map(|c| c.to_string()).unwrap_or_default();
                Some(pos.join(&sep))
            } else {
                // Unquoted $* → separate words, subject to word splitting
                Some(pos.join("\u{FFFE}"))
            }
        }
        "#" => Some(vars.positional_count().to_string()),
        "?" => Some(vars.get("?").unwrap_or_else(|| "0".to_string())),
        "$" => Some(vars.get("$").unwrap_or_else(|| "0".to_string())),
        "!" => vars.get("!"),
        "-" => Some(vars.get("-").unwrap_or_default()),
        _ => {
            let mut effective_name = name.to_string();
            if vars.is_nameref(name) {
                if let Some(target) = vars.get_nameref_target(name) {
                    if target.contains('[') && target.ends_with(']') {
                        effective_name = target;
                    }
                }
            }
            let name = effective_name.as_str();
            // Check for array subscript
            if let Some(bracket) = name.find('[') {
                let arr_name = &name[..bracket];
                let idx_part = &name[bracket + 1..name.len().saturating_sub(1)];
                if idx_part == "@" || idx_part == "*" {
                    let elements: Vec<String> = if vars.is_assoc(arr_name) {
                        // Assoc values in bash iteration order
                        vars.get_assoc_entries(arr_name)
                            .into_iter().map(|(_, v)| v).collect()
                    } else if vars.is_array(arr_name) {
                        vars.get_array(arr_name)
                            .map(|a| a.clone())
                            .unwrap_or_default()
                    } else {
                        vars.get(arr_name).map(|s| vec![s]).unwrap_or_default()
                    };
                    let no_split = NO_SPLIT_CONTEXT.with(|flag| flag.get());
                    if elements.is_empty() {
                        return None;
                    }
                    if in_dquote {
                        if idx_part == "@" {
                            // "${A[@]}" → separate words, preserve empties
                            return Some(elements.join("\u{FFFF}"));
                        } else {
                            // "${A[*]}" → join with IFS[0]
                            let ifs = vars.get("IFS").unwrap_or_else(|| " ".to_string());
                            let sep = ifs.chars().next().map(|c| c.to_string()).unwrap_or_default();
                            return Some(elements.join(&sep));
                        }
                    }
                    if no_split {
                        if idx_part == "*" {
                            let ifs = vars.get("IFS").unwrap_or_else(|| " ".to_string());
                            let sep = ifs.chars().next().map(|c| c.to_string()).unwrap_or_default();
                            return Some(elements.join(&sep));
                        }
                        return Some(elements.join(" "));
                    }
                    // Unquoted ${A[@]} / ${A[*]} – each element a separate word.
                    // For ${A[*]}: join with IFS[0] then word-split on IFS
                    // (re-splits on the same char).  When IFS is empty,
                    // POSIX says to treat like ${A[@]} — separate words.
                    if idx_part == "*" {
                        let ifs = vars.get("IFS").unwrap_or_else(|| " ".to_string());
                        if ifs.is_empty() {
                            return Some(elements.join("\u{FFFE}"));
                        }
                        // PROVEN: ifs is non-empty (empty case returned above).
                        let sep = ifs.chars().next().unwrap().to_string();
                        return Some(elements.join(&sep));
                    }
                    return Some(elements.join("\u{FFFE}"));
                }
                if vars.is_assoc(arr_name) {
                    let key = expand_assoc_subscript_key_pub(idx_part, vars);
                    return vars.get_assoc(arr_name, &key);
                }
                // Expand any $var / ${var} in the subscript expression first.
                let expanded_idx = expand_index_subscript_word(idx_part, vars);
                // Arithmetic index.  Negative subscripts count back from
                // the highest assigned index.  Use the mutating form so
                // side effects like `arr[i++]` persist.
                let idx_num = match arithmetic::eval_expr_mut(&expanded_idx, vars) {
                    Ok(n) => n,
                    Err(msg) => {
                        return Some(format!("\x00ARITH_ERR\x00{}\x1F{}\x00", expanded_idx, msg));
                    }
                };
                let idx_val = if idx_num < 0 {
                    match vars.array_max_index(arr_name) {
                        Some(m) => {
                            let real = (m + 1) as i64 + idx_num;
                            if real < 0 {
                                eprintln!("{}: {}: bad array subscript",
                                    crate::exec::shell_name_with_line(), arr_name);
                                return None;
                            }
                            real as usize
                        }
                        None => {
                            // Negative subscript on an empty/unset array:
                            // bash emits `NAME: bad array subscript`.
                            eprintln!("{}: {}: bad array subscript",
                                crate::exec::shell_name_with_line(), arr_name);
                            return None;
                        }
                    }
                } else {
                    idx_num as usize
                };
                return vars.get_array_element(arr_name, idx_val).map(|s| s.to_string());
            }

            // Positional parameter by number
            if let Ok(n) = name.parse::<usize>() {
                if n == 0 {
                    return vars.get("0").map(|s| s.to_string());
                }
                return vars.get_positional(n).map(|s| s.to_string());
            }

            if vars.is_assoc(name) {
                vars.get_assoc(name, "0").map(|s| s.to_string())
            } else if vars.is_array(name) {
                vars.get_array_element(name, 0).map(|s| s.to_string())
            } else {
                vars.get(name).map(|s| s.to_string())
            }
        }
    }
}

/// Get the expanded value of a variable name; same as resolve_raw_value but
/// returns None as empty string.
fn expand_var_value(name: &str, vars: &mut Variables) -> Option<String> {
    resolve_raw_value(name, vars, false)
}

/// For array-like parameters (`@`, `*`, `arr[@]`, `arr[*]`), return the
/// individual elements so per-element operators can be applied.
fn resolve_elements(name: &str, vars: &Variables) -> Option<Vec<String>> {
    match name {
        "@" | "*" => {
            // Always return Some for `@`/`*` (even when there are no
            // positional params), so the slice/transform code path
            // includes `$0` for `${@:0}` even with an empty positional
            // list.
            let pos = vars.all_positional(vars.positional_count());
            Some(pos)
        }
        _ => {
            if let Some(bracket) = name.find('[') {
                let arr_name = &name[..bracket];
                let idx_part = &name[bracket + 1..name.len().saturating_sub(1)];
                if idx_part == "@" || idx_part == "*" {
                    let elements: Vec<String> = if vars.is_assoc(arr_name) {
                        vars.get_assoc_entries(arr_name)
                            .into_iter().map(|(_, v)| v).collect()
                    } else if vars.is_array(arr_name) {
                        vars.get_array(arr_name)
                            .map(|a| a.clone())
                            .unwrap_or_default()
                    } else {
                        vars.get(arr_name).map(|s| vec![s]).unwrap_or_default()
                    };
                    if elements.is_empty() { None } else { Some(elements) }
                } else {
                    None
                }
            } else {
                None
            }
        }
    }
}

/// Return the separator to rejoin array-like elements after per-element
/// operations have been applied.
fn array_sep(name: &str, vars: &Variables, in_dquote: bool) -> String {
    // Mirror the raw expansion rules for @/* and arr[@] / arr[*]:
    // - @ / arr[@]: separate words (FFFF quoted, FFFE unquoted)
    // - * / arr[*]: join with IFS[0], except unquoted with empty IFS,
    //   where bash treats it like @ / arr[@] (separate words).
    let is_at = match name {
        "@" => true,
        _ => {
            if let Some(bracket) = name.find('[') {
                let idx_part = &name[bracket + 1..name.len().saturating_sub(1)];
                idx_part == "@"
            } else {
                false
            }
        }
    };
    let is_star = match name {
        "*" => true,
        _ => {
            if let Some(bracket) = name.find('[') {
                let idx_part = &name[bracket + 1..name.len().saturating_sub(1)];
                idx_part == "*"
            } else {
                false
            }
        }
    };
    let no_split = NO_SPLIT_CONTEXT.with(|flag| flag.get());
    if no_split && is_at {
        " ".to_string()
    } else if no_split && is_star {
        let ifs = vars.get("IFS").unwrap_or_else(|| " ".to_string());
        if ifs.is_empty() {
            String::new()
        } else {
            // PROVEN: ifs is non-empty (empty case returns String::new() above).
            ifs.chars().next().unwrap().to_string()
        }
    } else if in_dquote && is_at {
        "\u{FFFF}".to_string()
    } else if is_at {
        "\u{FFFE}".to_string()
    } else if is_star {
        let ifs = vars.get("IFS").unwrap_or_else(|| " ".to_string());
        if !in_dquote && ifs.is_empty() {
            "\u{FFFE}".to_string()
        } else {
            ifs.chars().next().map(|c| c.to_string()).unwrap_or_default()
        }
    } else {
        " ".to_string()
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Operator helper utilities
// ─────────────────────────────────────────────────────────────────────────────

/// If `s` starts with `op`, return the rest; otherwise None.
/// Check if a raw word string contains quoting characters (' or ").
fn word_has_quoting(w: &str) -> bool {
    let chars: Vec<char> = w.chars().collect();
    let mut i = 0;
    while i < chars.len() {
        match chars[i] {
            '\\' => {
                i += 2;
            }
            '\'' | '"' => return true,
            '$' if i + 1 < chars.len() && chars[i + 1] == '{' => {
                i = skip_dollar_brace(&chars, i);
            }
            '$' if i + 1 < chars.len() && chars[i + 1] == '(' => {
                i = skip_dollar_paren(&chars, i);
            }
            '`' => {
                i = skip_backtick(&chars, i);
            }
            _ => {
                i += 1;
            }
        }
    }
    false
}

pub fn word_has_quoting_pub(w: &str) -> bool {
    word_has_quoting(w)
}

fn strip_prefix_op<'a>(s: &'a str, op: &str) -> Option<&'a str> {
    if s.starts_with(op) { Some(&s[op.len()..]) } else { None }
}

fn protect_ifs_chars_for_subst(s: &str, vars: &Variables) -> String {
    let ifs = vars.get("IFS").unwrap_or_else(|| " \t\n".to_string());
    if ifs.is_empty() {
        return s.to_string();
    }
    let mut out = String::with_capacity(s.len());
    for ch in s.chars() {
        if ifs.contains(ch) {
            out.push(CTLESC);
        }
        out.push(ch);
    }
    out
}

/// Return true if `s` is a valid shell identifier (letters, digits, `_`,
/// with leading alpha or `_`).  Used to decide whether `NAME=~...`
/// triggers tilde expansion.
fn is_valid_assign_prefix(s: &str) -> bool {
    if s.is_empty() { return false; }
    let mut iter = s.chars();
    // PROVEN: s is non-empty (checked above), so next() is Some.
    let first = iter.next().unwrap();
    if !first.is_ascii_alphabetic() && first != '_' { return false; }
    iter.all(|c| c.is_ascii_alphanumeric() || c == '_')
}

fn is_valid_name_start(s: &str) -> bool {
    s.chars().next().map(|c| c.is_ascii_alphabetic() || c == '_').unwrap_or(false)
}

pub fn is_valid_varname(s: &str) -> bool {
    !s.is_empty() && s.chars().all(|c| c.is_ascii_alphanumeric() || c == '_')
        && s.chars().next().map(|c| !c.is_ascii_digit()).unwrap_or(false)
}

/// Expand variable names matching `prefix`, returning space-separated list.
/// Expand ${!prefix*} or ${!prefix@}.  `split_in_dquote` is true for the `@`
/// form AND in_dquote context (in which case each name stays a distinct word,
/// using FFFF like "$@").  For `*` the names are joined with IFS[0] — which
/// handles both quoted (no further splitting) and unquoted (word-splitting
/// pass will re-split on IFS).
fn expand_name_prefix(prefix: &str, vars: &Variables, split_in_dquote: bool) -> String {
    let names = vars.list_var_names_with_prefix(prefix);
    if split_in_dquote {
        // "${!prefix@}" — like "$@": each name is its own word.
        return names.join("\u{FFFF}");
    }
    let ifs = vars.get("IFS").unwrap_or_else(|| " \t\n".to_string());
    let sep = if ifs.is_empty() {
        String::new()
    } else {
        // PROVEN: ifs is non-empty (empty case above yields String::new()).
        ifs.chars().next().unwrap().to_string()
    };
    names.join(&sep)
}

// ─────────────────────────────────────────────────────────────────────────────
// Array slice  ${@:offset:length}, ${arr[@]:offset:length}, etc.
// ─────────────────────────────────────────────────────────────────────────────

fn apply_array_slice(
    name: &str,
    elements: &[String],
    spec: &str,
    vars: &mut Variables,
    in_dquote: bool,
) -> String {
    let is_positional = name == "@" || name == "*";
    let is_star = name == "*" || name.ends_with("[*]");

    // Save the original (pre-expansion) spec so we can include it in error
    // messages (bash shows the original expression, e.g. `$(($# - 2))`,
    // not the evaluated value `-1`).
    let original_spec = spec;

    // Pre-expand parameter references in the spec (e.g. `$#` inside
    // `${@:1:$#}`) so eval_expr sees a plain numeric expression.
    let expanded_spec = expand_arith_vars(spec, vars);
    let spec = expanded_spec.as_str();

    // For sparse indexed-array slicing, bash slices over the
    // SUBSCRIPT space: `${arr[@]:OFFSET:LEN}` takes subscripts in
    // [OFFSET, OFFSET+LEN), skipping unset elements.  Operate on
    // the (index, value) pairs so holes don't shift the bounds.
    if !is_positional {
        if let Some(bracket) = name.find('[') {
            let arr_name = &name[..bracket];
            let idx_part = &name[bracket + 1..name.len().saturating_sub(1)];
            if (idx_part == "@" || idx_part == "*")
                && (vars.is_array(arr_name) && !vars.is_assoc(arr_name))
            {
                let sparse = vars.get_array_sparse(arr_name).unwrap_or_default();
                let total_idx = vars.array_max_index(arr_name).map(|m| (m as i64) + 1).unwrap_or(0);

                let (off_str, len_str) = if let Some(colon) = spec.find(':') {
                    (&spec[..colon], Some(&spec[colon + 1..]))
                } else {
                    (spec, None)
                };
                let offset_raw = arithmetic::eval_expr(off_str.trim(), vars).unwrap_or(0);
                let start_idx: i64 = if offset_raw < 0 {
                    (total_idx + offset_raw).max(0)
                } else { offset_raw };

                let mut kept: Vec<String> = Vec::new();
                let mut taken: i64 = 0;
                let max_take: Option<i64> = match len_str {
                    None => None,
                    Some(ls) => Some(arithmetic::eval_expr(ls.trim(), vars).unwrap_or(0)),
                };
                for (i, v) in &sparse {
                    if (*i as i64) < start_idx { continue; }
                    if let Some(n) = max_take {
                        if n < 0 { break; }
                        if taken >= n { break; }
                    }
                    kept.push(v.clone());
                    taken += 1;
                }
                let sep = array_sep(name, vars, in_dquote);
                if in_dquote && is_star {
                    let ifs = vars.get("IFS").unwrap_or_else(|| " ".to_string());
                    let ifs_sep = ifs.chars().next().map(|c| c.to_string()).unwrap_or_default();
                    return kept.join(&ifs_sep);
                }
                return kept.join(&sep);
            }
        }
    }

    // Fallback: positional parameters or dense iteration.
    let total = elements.len() as i64;
    let (off_str, len_str) = if let Some(colon) = spec.find(':') {
        (&spec[..colon], Some(&spec[colon + 1..]))
    } else {
        (spec, None)
    };

    let offset_raw = arithmetic::eval_expr(off_str.trim(), vars).unwrap_or(0);

    // For positional-parameter slicing (`${@:N}`/`${@:N:M}`), bash
    // includes `$0` at index 0.  Prepend `$0` to the working element
    // list and adjust the slice indexing accordingly so offset_raw
    // maps directly to the indexed position.
    let zero_prepended_storage: Vec<String>;
    let (elements, total) = if is_positional {
        let zero = vars.get("0").unwrap_or_default();
        let mut full = Vec::with_capacity(elements.len() + 1);
        full.push(zero);
        full.extend(elements.iter().cloned());
        let new_total = full.len() as i64;
        zero_prepended_storage = full;
        (&zero_prepended_storage[..], new_total)
    } else {
        (elements, total)
    };

    let offset = if is_positional {
        if offset_raw < 0 {
            ((total as i64) + offset_raw).max(0) as usize
        } else {
            (offset_raw as i64).min(total as i64) as usize
        }
    } else {
        if offset_raw < 0 {
            (total + offset_raw).max(0) as usize
        } else {
            offset_raw.min(total) as usize
        }
    };

    let end = match len_str {
        None => total as usize,
        Some(ls) => {
            let len_raw = match arithmetic::eval_expr(ls.trim(), vars) {
                Ok(n) => n,
                Err(msg) => {
                    // Return an error payload similar to apply_substring.
                    return format!("\x00ARITH_ERR\x00{}: {}\x1F{}\x00", name, ls.trim(), msg);
                }
            };
            if len_raw < 0 && is_positional {
                // Bash returns an error for negative length in positional-parameter
                // slices (${@:offset:-n} is always an error).
                // The error message uses the ORIGINAL expression text (from before
                // expand_arith_vars), matching bash's output.
                let orig_len_expr = original_spec
                    .find(':')
                    .map(|i| original_spec[i + 1..].trim())
                    .unwrap_or(ls.trim());
                return format!(
                    "\x00ARITH_ERR\x00{}\x1Fsubstring expression < 0\x00",
                    orig_len_expr
                );
            }
            let length = if len_raw < 0 {
                let e = (total + len_raw).max(0) as usize;
                if e > offset { e - offset } else { 0 }
            } else {
                len_raw as usize
            };
            (offset + length).min(total as usize)
        }
    };

    if offset >= end {
        return String::new();
    }

    let sliced = &elements[offset..end];
    let sep = array_sep(name, vars, in_dquote);

    if in_dquote && is_star {
        let ifs = vars.get("IFS").unwrap_or_else(|| " ".to_string());
        let ifs_sep = ifs.chars().next().map(|c| c.to_string()).unwrap_or_default();
        return sliced.join(&ifs_sep);
    }

    sliced.join(&sep)
}

// ─────────────────────────────────────────────────────────────────────────────
// Substring  ${name:offset:length}
// ─────────────────────────────────────────────────────────────────────────────

fn apply_substring(value: &str, spec: &str, vars: &mut Variables, name: &str) -> String {
    // spec is "offset" or "offset:length"
    let chars: Vec<char> = value.chars().collect();
    let total = chars.len() as i64;

    // Pre-expand parameter references in the spec (e.g. `${#z}` inside
    // `${z:${#z}-3:3}`) so eval_expr sees a plain numeric expression.
    let expanded_spec = expand_arith_vars(spec, vars);
    let spec = expanded_spec.as_str();

    // The offset/length separator is the FIRST `:` at paren depth 0.
    // Colons nested inside `(...)` (e.g. ternary `j?1:0`) must not
    // split the spec.  `${string1:(j?1:0):j}` → offset=`(j?1:0)`,
    // length=`j`.
    let split_colon = {
        let chars: Vec<char> = spec.chars().collect();
        let mut paren_depth = 0i32;
        let mut ternary_depth = 0i32;
        let mut in_squote = false;
        let mut in_dquote = false;
        let mut idx: Option<usize> = None;
        let mut byte_pos = 0usize;
        let mut i = 0usize;
        while i < chars.len() {
            let ch = chars[i];
            if ch == '\\' {
                byte_pos += ch.len_utf8();
                if i + 1 < chars.len() {
                    byte_pos += chars[i + 1].len_utf8();
                    i += 2;
                } else {
                    i += 1;
                }
                continue;
            }
            if !in_dquote && ch == '\'' {
                in_squote = !in_squote;
            } else if !in_squote && ch == '"' {
                in_dquote = !in_dquote;
            } else if !in_squote && !in_dquote {
                match ch {
                    '(' => paren_depth += 1,
                    ')' if paren_depth > 0 => paren_depth -= 1,
                    '?' => ternary_depth += 1,
                    ':' if ternary_depth > 0 => ternary_depth -= 1,
                    ':' if paren_depth == 0 => {
                        idx = Some(byte_pos);
                        break;
                    }
                    _ => {}
                }
            }
            byte_pos += ch.len_utf8();
            i += 1;
        }
        idx
    };
    let (off_str, len_str) = if let Some(colon) = split_colon {
        (&spec[..colon], Some(&spec[colon + 1..]))
    } else {
        (spec, None)
    };

    // Evaluate an arith expression or build an ARITH_ERR payload
    // the caller surfaces via the normal arith-error path.  Empty
    // input evaluates to 0 without an error (bash behaviour).
    //
    // Payload format: `<name>: <expr>\x1F<msg>`.  The caller
    // (Shell::expand_word) prints this as
    //   <script>: line <N>: <name>: <expr>: <msg>
    // matching bash's `#: %: arithmetic syntax error: operand expected
    // (error token is "%")` for substring offset/length failures.
    let eval_or_err = |expr: &str| -> Result<i64, String> {
        let trimmed = expr.trim();
        if trimmed.is_empty() {
            return Ok(0);
        }
        match arithmetic::eval_expr(trimmed, vars) {
            Ok(n) => Ok(n),
            Err(msg) => Err(format!(
                "\x00ARITH_ERR\x00{}: {}\x1F{}\x00",
                name, trimmed, msg
            )),
        }
    };

    let offset_raw = match eval_or_err(off_str) {
        Ok(n) => n,
        Err(payload) => return payload,
    };
    let offset = if offset_raw < 0 {
        (total + offset_raw).max(0) as usize
    } else {
        offset_raw.min(total) as usize
    };

    match len_str {
        None => {
            chars[offset..].iter().collect()
        }
        Some(ls) => {
            let len_raw = match eval_or_err(ls) {
                Ok(n) => n,
                Err(payload) => return payload,
            };
            let length = if len_raw < 0 {
                // Negative length: distance from end
                let end = (total + len_raw).max(0) as usize;
                if end > offset { end - offset } else { 0 }
            } else {
                len_raw as usize
            };
            let end = (offset + length).min(total as usize);
            if offset <= end {
                chars[offset..end].iter().collect()
            } else {
                String::new()
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Glob-pattern matching helpers (used for # % / ^ , operators)
// ─────────────────────────────────────────────────────────────────────────────

/// Check if a glob pattern contains a bracket expression with a malformed
/// POSIX class (e.g., `[[:alpha]` where `:]` is missing).  In builtins.rs,
/// such patterns have their bracket-closing `]` consumed by the POSIX scan,
/// making the outer bracket appear "unclosed" — causing the whole bracket to
/// be treated as a literal `[` instead of matching the intended char set.
/// We detect this so we can route to the local `glob_match_impl` instead.
fn has_malformed_posix_class_in_bracket(pattern: &str) -> bool {
    let chars: Vec<char> = pattern.chars().collect();
    let n = chars.len();
    let mut i = 0;
    while i < n {
        if chars[i] == '\\' {
            i += 2;
            continue;
        }
        if chars[i] == '[' {
            // Scan the bracket expression to look for `[:name]` without `:]`
            let mut j = i + 1;
            if j < n && matches!(chars[j], '!' | '^') { j += 1; }
            while j < n {
                if chars[j] == ']' && j > i + 1 { break; } // outer close
                if chars[j] == '[' && j + 1 < n && chars[j + 1] == ':' {
                    // Scan for `:]`
                    let mut k = j + 2;
                    let mut found_posix_close = false;
                    while k + 1 < n {
                        if chars[k] == ':' && chars[k + 1] == ']' {
                            found_posix_close = true;
                            break;
                        }
                        if chars[k] == ']' {
                            // Hit the outer-bracket closer without finding `:]`
                            // — this is a malformed POSIX class.
                            return true;
                        }
                        k += 1;
                    }
                    if !found_posix_close {
                        return true; // reached end of pattern without `:]`
                    }
                }
                j += 1;
            }
            i = j + 1; // skip past the outer `]`
            continue;
        }
        i += 1;
    }
    false
}

/// Convert a shell glob pattern to a regex-like matcher.
/// We implement a simple NFA directly rather than pulling in a regex crate.
fn glob_matches(pattern: &str, text: &str) -> bool {
    // For patterns containing a bracket expression with a malformed POSIX
    // class (e.g., `[[:alpha]`), builtins.rs incorrectly consumes the
    // bracket-closing `]` and treats the outer bracket as unclosed.  Route
    // these to the local `glob_match_impl` which handles the case correctly.
    if has_malformed_posix_class_in_bracket(pattern) {
        if current_nocasematch() {
            let lp: Vec<char> = pattern.to_lowercase().chars().collect();
            let lt: Vec<char> = text.to_lowercase().chars().collect();
            return glob_match_impl(&lp, &lt, 0, 0);
        } else {
            let pc: Vec<char> = pattern.chars().collect();
            let tc: Vec<char> = text.chars().collect();
            return glob_match_impl(&pc, &tc, 0, 0);
        }
    }
    // Delegate to the extglob-aware matcher in builtins.rs so that
    // `${var#+(a|abc)}` and friends honour extended globs.  When the
    // pattern has no extglob metas this falls through to the regular
    // star/?/[] matcher anyway.
    if current_nocasematch() {
        crate::builtins::glob_match_pub(&pattern.to_lowercase(), &text.to_lowercase())
    } else {
        crate::builtins::glob_match_pub(pattern, text)
    }
}

#[allow(dead_code)]
fn glob_matches_no_extglob(pattern: &str, text: &str) -> bool {
    glob_match_impl(
        &pattern.chars().collect::<Vec<_>>(),
        &text.chars().collect::<Vec<_>>(),
        0,
        0,
    )
}

fn glob_match_impl(pat: &[char], text: &[char], pi: usize, ti: usize) -> bool {
    let pn = pat.len();
    let tn = text.len();

    if pi >= pn {
        return ti == tn;
    }

    match pat[pi] {
        '*' => {
            // Skip consecutive *
            let mut npi = pi + 1;
            while npi < pn && pat[npi] == '*' { npi += 1; }
            // Try matching * against 0..remaining chars
            for nti in ti..=tn {
                if glob_match_impl(pat, text, npi, nti) {
                    return true;
                }
            }
            false
        }
        '?' => {
            ti < tn && glob_match_impl(pat, text, pi + 1, ti + 1)
        }
        '[' => {
            // Character class.  If the bracket expression is unclosed (no
            // matching `]`), bash treats `[` as a literal character.
            if ti >= tn { return false; }
            match match_char_class(pat, pi + 1, text[ti]) {
                Some((matches_class, next_pi)) => {
                    matches_class && glob_match_impl(pat, text, next_pi, ti + 1)
                }
                None => {
                    // Unmatched `[` — treat as literal
                    text[ti] == '[' && glob_match_impl(pat, text, pi + 1, ti + 1)
                }
            }
        }
        '\\' => {
            // Escaped literal
            if pi + 1 < pn && ti < tn && pat[pi + 1] == text[ti] {
                glob_match_impl(pat, text, pi + 2, ti + 1)
            } else {
                false
            }
        }
        c => {
            ti < tn && text[ti] == c && glob_match_impl(pat, text, pi + 1, ti + 1)
        }
    }
}

/// Match a `[...]` character class starting at `start` (just after `[`).
/// Returns `Some((did_match, index_after_closing_']'))` if the bracket
/// expression was properly closed, or `None` if the `[` was unmatched
/// (the caller should treat `[` as a literal character in that case).
fn match_char_class(pat: &[char], start: usize, ch: char) -> Option<(bool, usize)> {
    let n = pat.len();
    let mut i = start;
    let negate = i < n && pat[i] == '!';
    if negate { i += 1; }

    let mut matched = false;
    let mut first = true;

    while i < n && (first || pat[i] != ']') {
        first = false;
        if i + 2 < n && pat[i + 1] == '-' && pat[i + 2] != ']' {
            // Range
            if ch >= pat[i] && ch <= pat[i + 2] {
                matched = true;
            }
            i += 3;
        } else if pat[i] == '[' && i + 1 < n && pat[i + 1] == ':' {
            // POSIX character class [:alpha:] etc.
            // If malformed (no closing `:]`), treat `[` as a literal char.
            if let Some((class_match, next_i)) = match_posix_class(pat, i + 2, ch) {
                if class_match { matched = true; }
                i = next_i;
            } else {
                // Malformed POSIX class: treat `[` as literal
                if '[' == ch { matched = true; }
                i += 1;
            }
        } else {
            if pat[i] == ch { matched = true; }
            i += 1;
        }
    }

    // If we ran out of characters without finding a closing `]`, the `[`
    // should be treated as a literal — return None to signal this.
    if i >= n {
        return None;
    }

    let close = i + 1; // skip the closing `]`
    Some((if negate { !matched } else { matched }, close))
}

/// Try to match a POSIX character class `[:name:]` starting just after `[:`
/// (i.e., `start` points to the class name).
/// Returns `Some((matched, index_after_:]))` if the class is well-formed,
/// or `None` if `:]` is not found (malformed class — caller treats `[` as literal).
fn match_posix_class(pat: &[char], start: usize, ch: char) -> Option<(bool, usize)> {
    let mut end = start;
    let n = pat.len();
    while end + 1 < n && !(pat[end] == ':' && pat[end + 1] == ']') {
        end += 1;
    }
    // If we didn't find `:]`, the class is malformed
    if end + 1 >= n || !(pat[end] == ':' && pat[end + 1] == ']') {
        return None;
    }
    let class_name: String = pat[start..end].iter().collect();
    let m = match class_name.as_str() {
        "alpha"  => ch.is_alphabetic(),
        "digit"  => ch.is_ascii_digit(),
        "alnum"  => ch.is_alphanumeric(),
        "upper"  => ch.is_uppercase(),
        "lower"  => ch.is_lowercase(),
        "space"  => ch.is_whitespace(),
        "blank"  => ch == ' ' || ch == '\t',
        "punct"  => ch.is_ascii_punctuation(),
        "print"  => !ch.is_control(),
        "cntrl"  => ch.is_control(),
        "graph"  => !ch.is_whitespace() && !ch.is_control(),
        "xdigit" => ch.is_ascii_hexdigit(),
        _        => false,
    };
    Some((m, end + 2)) // skip :]
}

/// Remove the shortest/longest matching prefix glob pattern.
fn glob_remove_prefix(value: &str, pattern: &str, greedy: bool) -> String {
    let chars: Vec<char> = value.chars().collect();
    let n = chars.len();

    if greedy {
        // Longest match: try from longest down to 0
        for end in (0..=n).rev() {
            let candidate: String = chars[..end].iter().collect();
            if glob_matches(pattern, &candidate) {
                return chars[end..].iter().collect();
            }
        }
    } else {
        // Shortest match: try from 0 up
        for end in 0..=n {
            let candidate: String = chars[..end].iter().collect();
            if glob_matches(pattern, &candidate) {
                return chars[end..].iter().collect();
            }
        }
    }
    value.to_string()
}

/// Remove the shortest/longest matching suffix glob pattern.
fn glob_remove_suffix(value: &str, pattern: &str, greedy: bool) -> String {
    let chars: Vec<char> = value.chars().collect();
    let n = chars.len();

    if greedy {
        // Longest match: start from the beginning
        for start in 0..=n {
            let candidate: String = chars[start..].iter().collect();
            if glob_matches(pattern, &candidate) {
                return chars[..start].iter().collect();
            }
        }
    } else {
        // Shortest match: start from the end
        for start in (0..=n).rev() {
            let candidate: String = chars[start..].iter().collect();
            if glob_matches(pattern, &candidate) {
                return chars[..start].iter().collect();
            }
        }
    }
    value.to_string()
}

/// Split the pattern/replacement parts of a ${name/pat/repl} expression.
///
/// When `allow_leading_slash` is true, a `/` at position 0 of `rest` is
/// treated as part of the pattern rather than as the separator.  This is
/// used for the global-replace (`//`) and single-replace (`/`) forms where
/// the pattern itself may start with `/` (e.g. `${var///a/repl}` has
/// pattern `/a`).  For anchored forms (`/#pat/repl`, `/%pat/repl`) the
/// anchor character has already been stripped, so `allow_leading_slash`
/// should be false (an empty pattern followed by `/repl` is valid).
fn split_subst_pattern_impl(rest: &str, allow_leading_slash: bool) -> (&str, &str) {
    let chars: Vec<char> = rest.chars().collect();
    let n = chars.len();
    // When allow_leading_slash is true, a `/` at position 0 is treated as
    // part of the pattern rather than the separator.  We achieve this by
    // starting the separator search at index 1 ONLY when the first character
    // is literally `/` (unescaped).  An initial `\` (escape sequence) is
    // handled normally — the escape character at i=0 consumes i+1 via the
    // `'\\'` branch below, so neither i=0 nor i=1 will be misidentified as
    // a separator.
    let mut i = if allow_leading_slash && n > 0 && chars[0] == '/' { 1 } else { 0 };
    while i < n {
        match chars[i] {
            '\\' => { i += 2; }
            '[' => {
                // Scan for closing `]`.  If the bracket expression is
                // unclosed (no `]` found before a `/`), treat `[` as
                // literal and let the separator-finding logic handle
                // the `/` normally.  This matches bash's behaviour of
                // treating a lone `[` as a literal in patterns like
                // `${var//[/repl}`.
                let bracket_start = i;
                let mut j = i + 1;
                // Skip optional negation character
                if j < n && (chars[j] == '!' || chars[j] == '^') { j += 1; }
                let mut found_close = false;
                while j < n {
                    if chars[j] == '\\' { j += 2; continue; }
                    if chars[j] == ']' { found_close = true; break; }
                    j += 1;
                }
                if found_close {
                    i = j + 1; // advance past `]`
                } else {
                    // Unclosed `[`: treat as literal, advance past only `[`
                    let _ = bracket_start;
                    i += 1;
                }
            }
            '/' => {
                // Compute the byte offset of position i.
                let byte_offset: usize = chars[..i].iter().map(|c| c.len_utf8()).sum();
                return (&rest[..byte_offset], &rest[byte_offset + 1..]);
            }
            _ => { i += 1; }
        }
    }
    (rest, "")
}

/// Variant of `split_subst_pattern_impl` with `allow_leading_slash = true`.
/// Use for the `/` and `//` operator forms.
fn split_subst_pattern(rest: &str) -> (&str, &str) {
    split_subst_pattern_impl(rest, true)
}

/// Variant of `split_subst_pattern_impl` with `allow_leading_slash = false`.
/// Use for the `/#` and `/%` anchored forms (where anchor has already been
/// stripped and an empty pattern is possible).
fn split_subst_pattern_anchored(rest: &str) -> (&str, &str) {
    split_subst_pattern_impl(rest, false)
}

/// Replace first (or all if `all` is true) occurrences of glob pattern in value.
fn glob_replace(value: &str, pattern: &str, replacement: &str, all: bool) -> String {
    // When `patsub_replacement` is enabled (bash 5.2+ default), `&` in
    // the replacement is substituted with the matched text; `\&`
    // escapes a literal `&`.  Check here once to avoid doing it in the
    // inner loop.
    let has_ampersand = replacement.contains(|c: char| c == '&' || c == '\\' || c == CTLESC);
    let patsub_on = crate::exec::GLOB_SHOPTS.with(|c| c.get().patsub_replacement);

    // Fast path: purely-literal pattern → plain string replace.  This
    // keeps `${z//;}` with a long z from blowing up to O(N²) in the
    // slow glob_matches matcher (which re-collects char slices for
    // every candidate range).
    if pattern_is_literal(pattern) && !current_nocasematch() {
        let literal = unescape_glob_literal(pattern);
        if literal.is_empty() {
            return value.to_string();
        }
        let effective_repl = if patsub_on && has_ampersand {
            // Replacement references the matched text — compute once.
            substitute_ampersand(replacement, &literal)
        } else if has_ampersand {
            // patsub_replacement off: just strip backslash-escaping of &.
            strip_ampersand_escapes(replacement)
        } else {
            replacement.to_string()
        };
        return if all {
            value.replace(&literal, &effective_repl)
        } else {
            value.replacen(&literal, &effective_repl, 1)
        };
    }

    let chars: Vec<char> = value.chars().collect();
    let n = chars.len();
    let mut result = String::with_capacity(value.len());
    let mut i = 0;

    // Compute a min/max match length bound.  When the pattern is
    // fixed-width (no `*` or extglob wildcards), min == max and we
    // only try one candidate per position — huge win for patterns
    // like `[^;]` against a long input.
    let (min_match, max_match) = pattern_length_bounds(pattern);

    // Track whether the previous iteration produced a non-empty match so that
    // we know to stop at end-of-string rather than trying an empty match there.
    let mut last_was_nonempty_match = false;
    while i <= n {
        // Once we've consumed the entire string via a non-empty match, stop.
        // This prevents spurious empty-match substitutions at end-of-string
        // (e.g. `${var//*/x}` with var=abc → `x` not `xx`).
        if i == n && last_was_nonempty_match {
            break;
        }
        let mut matched_end: Option<usize> = None;
        // Try to find the longest match starting at position i.
        // The range [lower..=upper] is tried in reverse to prefer longer matches.
        // When min_match == 0 the pattern can match an empty string, so we
        // include the empty-match endpoint (i) in the candidate range.
        let lower = i + min_match;
        let upper = match max_match {
            Some(m) => (i + m).min(n),
            None => n,
        };
        if lower <= upper {
            for end in (lower..=upper).rev() {
                if glob_match_slice(pattern, &chars[i..end]) {
                    matched_end = Some(end);
                    break;
                }
            }
        }
        if let Some(end) = matched_end {
            if patsub_on && has_ampersand {
                let matched: String = chars[i..end].iter().collect();
                result.push_str(&substitute_ampersand(replacement, &matched));
            } else if has_ampersand {
                result.push_str(&strip_ampersand_escapes(replacement));
            } else {
                result.push_str(replacement);
            }
            if end == i {
                // Zero-length match: emit replacement, advance by one character
                // to prevent infinite loop.  Copy the current char to output too
                // (it was not consumed by the match).
                last_was_nonempty_match = false;
                if i < n {
                    if all {
                        result.push(chars[i]);
                    }
                    i += 1;
                } else {
                    break;
                }
            } else {
                last_was_nonempty_match = true;
                i = end;
                if !all {
                    result.extend(chars[i..].iter());
                    break;
                }
            }
        } else {
            last_was_nonempty_match = false;
            if i < n {
                result.push(chars[i]);
                i += 1;
            } else {
                break;
            }
        }
    }
    result
}

/// Substitute `&` in the replacement with `matched`, honouring `\&` as a
/// literal `&` and `\\` as a literal `\`.  Other backslash sequences are
/// left untouched (the backslash is preserved).  Called when
/// `shopt -s patsub_replacement` is in effect.
///
/// A `&` that is preceded by the CTLESC quote-protect marker is treated
/// as literal — that's how bash-compatible quoting from e.g. `"&"` marks
/// the character as not an anchor substitution.
fn substitute_ampersand(replacement: &str, matched: &str) -> String {
    let mut out = String::with_capacity(replacement.len());
    let chars: Vec<char> = replacement.chars().collect();
    let mut i = 0;
    while i < chars.len() {
        let c = chars[i];
        if c == CTLESC && i + 1 < chars.len() {
            // The next char is quoted — copy it through as literal
            // (drop the CTLESC marker; surrounding code has already
            // taken quoting into account).
            out.push(chars[i + 1]);
            i += 2;
            continue;
        }
        if c == '\\' && i + 1 < chars.len() {
            let next = chars[i + 1];
            if next == '&' { out.push('&'); i += 2; continue; }
            if next == '\\' { out.push('\\'); i += 2; continue; }
            // Unrecognised: keep the backslash and continue.
            out.push('\\');
            i += 1;
            continue;
        }
        if c == '&' {
            out.push_str(matched);
            i += 1;
            continue;
        }
        out.push(c);
        i += 1;
    }
    out
}

/// When `patsub_replacement` is off, `\&` and `\\` in the replacement are
/// still processed (bash drops the backslash), but unescaped `&` is
/// literal.  Match that behaviour.
fn strip_ampersand_escapes(replacement: &str) -> String {
    let mut out = String::with_capacity(replacement.len());
    let chars: Vec<char> = replacement.chars().collect();
    let mut i = 0;
    while i < chars.len() {
        let c = chars[i];
        if c == CTLESC && i + 1 < chars.len() {
            out.push(chars[i + 1]);
            i += 2;
            continue;
        }
        if c == '\\' && i + 1 < chars.len() {
            let next = chars[i + 1];
            if next == '&' { out.push('&'); i += 2; continue; }
            if next == '\\' { out.push('\\'); i += 2; continue; }
            out.push('\\');
            i += 1;
            continue;
        }
        out.push(c);
        i += 1;
    }
    out
}

/// Compute (min, max) match length for a glob pattern.
/// `max = None` when the pattern is unbounded (contains `*` or an
/// extglob wildcard).  Used to prune candidate ranges in
/// `glob_replace` so single-char patterns like `[^;]` don't trigger
/// O(N²) scans on long inputs.
fn pattern_length_bounds(pattern: &str) -> (usize, Option<usize>) {
    let mut min_count = 0usize;
    let mut max_bounded = true;
    let mut max_count = 0usize;
    let chars: Vec<char> = pattern.chars().collect();
    let mut i = 0;
    while i < chars.len() {
        let c = chars[i];
        // Extglob prefix: ?(…), *(…), +(…), @(…), !(…).  These are
        // unbounded in general; fall back to unlimited max.
        if i + 1 < chars.len() && chars[i + 1] == '(' &&
           matches!(c, '?' | '*' | '+' | '@' | '!') {
            return (0, None);
        }
        match c {
            '*' => {
                max_bounded = false;
            }
            '?' => {
                min_count += 1;
                max_count += 1;
            }
            '[' => {
                // Consume bracket expression as one char match.
                // Handle nested POSIX classes [:alnum:], [.ch.], [=ch=]:
                // they open with `[:`/`[.`/`[=` and close with the
                // corresponding `:]`/`.]`/`=]`, NOT the next `]`.
                min_count += 1;
                max_count += 1;
                let mut j = i + 1;
                if j < chars.len() && (chars[j] == '!' || chars[j] == '^') { j += 1; }
                let start = j;
                let mut found_close = false;
                while j < chars.len() {
                    // Skip over a nested POSIX class/collation/equivalence
                    // so its inner `]` isn't mistaken for the outer close.
                    if j + 1 < chars.len() && chars[j] == '['
                        && matches!(chars[j + 1], ':' | '.' | '=')
                    {
                        let close_prefix = chars[j + 1];
                        let mut k = j + 2;
                        while k + 1 < chars.len() {
                            if chars[k] == close_prefix && chars[k + 1] == ']' {
                                k += 2;
                                break;
                            }
                            k += 1;
                        }
                        j = k;
                        continue;
                    }
                    if chars[j] == ']' && j > start { found_close = true; break; }
                    j += 1;
                }
                // If `]` was found, consume up to it; otherwise treat `[` as
                // literal (matching 1 text char) and don't consume the rest.
                if found_close {
                    i = j; // will be incremented by outer `i += 1`
                }
                // else: i stays at current position, outer i += 1 moves past `[`
            }
            '\\' => {
                min_count += 1;
                max_count += 1;
                i += 1; // skip escaped char
            }
            _ => {
                min_count += 1;
                max_count += 1;
            }
        }
        i += 1;
    }
    if max_bounded { (min_count, Some(max_count)) } else { (min_count, None) }
}

/// Match a glob pattern against a char slice (no String allocation).
fn glob_match_slice(pattern: &str, text: &[char]) -> bool {
    // Fall back to the string-based matcher; the real win was
    // pruning impossible candidate ranges via `pattern_min_length`.
    let s: String = text.iter().collect();
    glob_matches(pattern, &s)
}

/// Does `pattern` contain no glob metacharacters?
fn pattern_is_literal(pattern: &str) -> bool {
    let mut chars = pattern.chars().peekable();
    while let Some(c) = chars.next() {
        match c {
            '*' | '?' | '[' => return false,
            '\\' => { chars.next(); }
            '(' => {
                // Could be part of an extglob prefix — we already
                // would have returned false for the `*`/`?`/`+`/`@`/`!`
                // preceding it, but a bare `(` is literal.
            }
            _ => {}
        }
    }
    true
}

/// Strip `\X` → `X` from a literal glob pattern so the caller can use
/// plain-text `str::replace`.
fn unescape_glob_literal(pattern: &str) -> String {
    let mut out = String::with_capacity(pattern.len());
    let mut chars = pattern.chars().peekable();
    while let Some(c) = chars.next() {
        if c == '\\' {
            if let Some(next) = chars.next() {
                out.push(next);
            }
        } else {
            out.push(c);
        }
    }
    out
}

fn glob_replace_anchored(
    value: &str,
    pattern: &str,
    replacement: &str,
    anchor_start: bool,
    anchor_end: bool,
) -> String {
    let chars: Vec<char> = value.chars().collect();
    let n = chars.len();
    let has_ampersand = replacement.contains(|c: char| c == '&' || c == '\\' || c == CTLESC);
    let patsub_on = crate::exec::GLOB_SHOPTS.with(|c| c.get().patsub_replacement);

    let render = |matched: &str| -> String {
        if patsub_on && has_ampersand {
            substitute_ampersand(replacement, matched)
        } else if has_ampersand {
            strip_ampersand_escapes(replacement)
        } else {
            replacement.to_string()
        }
    };

    if anchor_start {
        // Try to match at position 0
        for end in (0..=n).rev() {
            let candidate: String = chars[..end].iter().collect();
            if glob_matches(pattern, &candidate) {
                let mut result = render(&candidate);
                result.push_str(&chars[end..].iter().collect::<String>());
                return result;
            }
        }
        return value.to_string();
    }

    if anchor_end {
        // Try to match ending at position n
        for start in 0..=n {
            let candidate: String = chars[start..].iter().collect();
            if glob_matches(pattern, &candidate) {
                let mut result: String = chars[..start].iter().collect();
                result.push_str(&render(&candidate));
                return result;
            }
        }
        return value.to_string();
    }

    glob_replace(value, pattern, replacement, false)
}

// ─────────────────────────────────────────────────────────────────────────────
// Case modification: ^ , operators
// ─────────────────────────────────────────────────────────────────────────────

fn case_modify(value: &str, pattern: &str, to_upper: bool, all: bool) -> String {
    let pat = if pattern.is_empty() { "?" } else { pattern };
    let mut result = String::new();
    let mut first = true;

    for c in value.chars() {
        if all || first {
            let s = c.to_string();
            if glob_matches(pat, &s) {
                if to_upper {
                    result.extend(c.to_uppercase());
                } else {
                    result.extend(c.to_lowercase());
                }
                first = false;
                continue;
            }
        }
        // For single-mode (^/,), only the first character is considered
        if first && !all {
            first = false;
        }
        result.push(c);
    }
    result
}

/// Toggle the case of characters in `value` matching `pattern`.
/// `all` = true means toggle every matching char; false means toggle only the first char.
fn case_toggle(value: &str, pattern: &str, all: bool) -> String {
    let pat = if pattern.is_empty() { "?" } else { pattern };
    let mut result = String::new();
    let mut first = true;

    for c in value.chars() {
        if all || first {
            let s = c.to_string();
            if glob_matches(pat, &s) {
                if c.is_uppercase() {
                    result.extend(c.to_lowercase());
                } else {
                    result.extend(c.to_uppercase());
                }
                first = false;
                continue;
            }
        }
        if first && !all {
            first = false;
        }
        result.push(c);
    }
    result
}

// ─────────────────────────────────────────────────────────────────────────────
// ANSI-C quoting  $'...'
// ─────────────────────────────────────────────────────────────────────────────

/// Parse a single escape sequence starting at `i` in `chars`.
/// Returns (expanded_chars_as_string, chars_consumed).
fn parse_ansi_escape(chars: &[char], i: usize) -> (String, usize) {
    let n = chars.len();
    if i >= n {
        return (String::new(), 0);
    }
    if chars[i] != '\\' {
        return (chars[i].to_string(), 1);
    }
    if i + 1 >= n {
        return ("\\".to_string(), 1);
    }
    match chars[i + 1] {
        'a'  => ("\x07".to_string(), 2),
        'b'  => ("\x08".to_string(), 2),
        'e' | 'E' => ("\x1b".to_string(), 2),
        'f'  => ("\x0c".to_string(), 2),
        'n'  => ("\n".to_string(), 2),
        'r'  => ("\r".to_string(), 2),
        't'  => ("\t".to_string(), 2),
        'v'  => ("\x0b".to_string(), 2),
        '\\' => ("\\".to_string(), 2),
        '\'' => ("'".to_string(), 2),
        '"'  => ("\"".to_string(), 2),
        '?'  => ("?".to_string(), 2),
        'x'  => {
            // \xHH or \x{H..} – hex escape (always a single byte)
            let mut hex = String::new();
            let mut j = i + 2;
            if j < n && chars[j] == '{' {
                // Braced form: \x{H..} — read hex digits until '}' or
                // non-hex char.  Bash reads ALL hex digits then truncates
                // the value to a single byte (& 0xFF).
                j += 1;
                while j < n && chars[j] != '}' && chars[j].is_ascii_hexdigit() {
                    hex.push(chars[j]);
                    j += 1;
                }
                if j < n && chars[j] == '}' {
                    j += 1; // consume '}'
                }
                let byte = if hex.is_empty() {
                    0u8
                } else {
                    // Parse full value and truncate to low 8 bits
                    let code = u64::from_str_radix(&hex, 16).unwrap_or(0);
                    (code & 0xFF) as u8
                };
                (encode_raw_byte(byte), j - i)
            } else {
                // Non-braced: read up to 2 hex digits
                while j < n && hex.len() < 2 && chars[j].is_ascii_hexdigit() {
                    hex.push(chars[j]);
                    j += 1;
                }
                if hex.is_empty() {
                    ("\\x".to_string(), 2)
                } else {
                    let byte = u8::from_str_radix(&hex, 16).unwrap_or(0);
                    (encode_raw_byte(byte), j - i)
                }
            }
        }
        'u' => {
            // \uHHHH
            let mut hex = String::new();
            let mut j = i + 2;
            while j < n && hex.len() < 4 && chars[j].is_ascii_hexdigit() {
                hex.push(chars[j]);
                j += 1;
            }
            let code = u32::from_str_radix(&hex, 16).unwrap_or(0);
            let s = encode_locale_codepoint(code);
            (s, j - i)
        }
        'U' => {
            // \UHHHHHHHH
            let mut hex = String::new();
            let mut j = i + 2;
            while j < n && hex.len() < 8 && chars[j].is_ascii_hexdigit() {
                hex.push(chars[j]);
                j += 1;
            }
            let code = u32::from_str_radix(&hex, 16).unwrap_or(0);
            let s = encode_locale_codepoint(code);
            (s, j - i)
        }
        '0'..='7' => {
            // \nnn octal — produces a single byte (not a codepoint).
            // Bytes 0x80-0xFF are PUA-encoded so they round-trip through
            // Rust Strings as raw bytes (matching bash char* semantics).
            let mut octal = String::new();
            let mut j = i + 1;
            while j < n && octal.len() < 3 && chars[j] >= '0' && chars[j] <= '7' {
                octal.push(chars[j]);
                j += 1;
            }
            let code = u8::from_str_radix(&octal, 8).unwrap_or(0);
            (encode_raw_byte(code), j - i)
        }
        'c' => {
            // \cX – control character.
            // Special case: \c? = DEL (127).
            // When the argument is \\ (stored as two-char pair \\), consume all 4
            // chars so that \c\\ (ctrl-backslash = FS) does not leave a stray \.
            if i + 2 < n {
                let target = chars[i + 2];
                let ctrl_char = if target == '?' {
                    '\x7f' // DEL (127)
                } else {
                    (target.to_ascii_uppercase() as u8 & 0x1f) as char
                };
                // Consume an extra char when the argument is itself a backslash
                // stored as the two-char pair \\ so the paired second backslash
                // is not misinterpreted as a new escape sequence.
                let advance = if target == '\\' && i + 3 < n { 4 } else { 3 };
                (ctrl_char.to_string(), advance)
            } else {
                ("\\c".to_string(), 2)
            }
        }
        other => {
            // Unknown escape – keep backslash
            (format!("\\{}", other), 2)
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Collecting nested delimited constructs
// ─────────────────────────────────────────────────────────────────────────────

/// Expand `$name`, `${name}`, and special `$?`, `$!`, `$$`, `$#` references
/// inside an arithmetic expression string.  Bare identifiers (without `$`)
/// are left alone – the arithmetic evaluator resolves them.
fn expand_arith_vars_mode(expr: &str, vars: &mut Variables, allow_cmdsub: bool) -> String {
    // Fast path: an arithmetic expression with no `$`, no backtick, and no
    // `[` subscript brackets needs no per-char expansion — just return the
    // input.  This dominates the common case `$((i+1))`, `$((n*2-1))`,
    // etc. and avoids a chars().collect() + per-char loop in tight arith
    // hot paths.
    if !expr.contains('$') && !expr.contains('`') && !expr.contains('[') {
        return expr.to_string();
    }
    let chars: Vec<char> = expr.chars().collect();
    let n = chars.len();
    let mut out = String::new();
    let mut i = 0;
    let mut square_depth = 0i32;

    while i < n {
        if chars[i] == '[' {
            square_depth += 1;
            out.push(chars[i]);
            i += 1;
            continue;
        }
        if chars[i] == ']' && square_depth > 0 {
            square_depth -= 1;
            out.push(chars[i]);
            i += 1;
            continue;
        }
        // `\$` → literal `$` in arithmetic context (backslash escapes the dollar,
        // preventing variable expansion).  Matches bash's behaviour: `\$iv` in
        // `$(( jv += \$iv ))` produces the literal string `$iv` for the arithmetic
        // evaluator to see as an invalid token.
        if chars[i] == '\\' && i + 1 < n && chars[i + 1] == '$' {
            if square_depth > 0 {
                out.push('\\');
            }
            out.push('$');
            i += 2;
            // Also collect any following identifier chars so the full `$name`
            // string is passed through as-is.
            while i < n && (chars[i].is_ascii_alphanumeric() || chars[i] == '_') {
                out.push(chars[i]);
                i += 1;
            }
            continue;
        }
        if chars[i] == '`' {
            let start = i + 1;
            let mut j = start;
            let mut body = String::new();
            while j < n {
                if chars[j] == '\\' && j + 1 < n {
                    body.push(chars[j + 1]);
                    j += 2;
                    continue;
                }
                if chars[j] == '`' {
                    break;
                }
                body.push(chars[j]);
                j += 1;
            }
            if j < n {
                if allow_cmdsub {
                    let marker = format!("\x00CMDSUB\x00{}\x00", body);
                    let resolved = crate::exec::resolve_cmdsubs_for_expand(&marker, vars);
                    out.push_str(&resolved);
                } else {
                    out.push('`');
                    out.push_str(&body);
                    out.push('`');
                }
                i = j + 1;
                continue;
            }
        }
        if chars[i] == '$' {
            if square_depth > 0 {
                if i + 1 < n && chars[i + 1] == '{' {
                    let start = i;
                    let mut depth = 1usize;
                    let mut j = i + 2;
                    while j < n && depth > 0 {
                        match chars[j] {
                            '{' => depth += 1,
                            '}' => depth -= 1,
                            _ => {}
                        }
                        j += 1;
                    }
                    out.push_str(&chars[start..j.min(n)].iter().collect::<String>());
                    i = j.min(n);
                    continue;
                } else if i + 2 < n && chars[i + 1] == '(' && chars[i + 2] == '(' {
                    let (inner, advance, closed) = collect_arith(&chars, i + 3);
                    if closed {
                        out.push_str("$((");
                        out.push_str(&inner);
                        out.push_str("))");
                        i += advance + 3;
                    } else {
                        out.push('$');
                        i += 1;
                    }
                    continue;
                } else if i + 1 < n && chars[i + 1] == '(' {
                    let (body, advance, closed) = collect_paren_cmd(&chars, i + 2);
                    if closed {
                        out.push_str("$(");
                        out.push_str(&body);
                        out.push(')');
                        i += advance + 2;
                    } else {
                        out.push('$');
                        i += 1;
                    }
                    continue;
                } else if i + 1 < n && (chars[i + 1].is_ascii_alphabetic() || chars[i + 1] == '_') {
                    let start = i + 1;
                    let mut j = start;
                    while j < n && (chars[j].is_ascii_alphanumeric() || chars[j] == '_') {
                        j += 1;
                    }
                    let name: String = chars[start..j].iter().collect();
                    if name == "RANDOM" {
                        let val = vars.get(&name).unwrap_or_default();
                        out.push_str(&val);
                    } else {
                        out.push('$');
                        out.push_str(&name);
                    }
                    i = j;
                    continue;
                } else if i + 1 < n && chars[i + 1].is_ascii_digit() {
                    out.push('$');
                    out.push(chars[i + 1]);
                    i += 2;
                    continue;
                }
            }
            if i + 1 < n && chars[i + 1] == '{' {
                let (val, advance) = expand_param_brace(&chars, i + 2, vars, false, false);
                if allow_cmdsub && val.contains('\x00') {
                    out.push_str(&crate::exec::resolve_cmdsubs_for_expand(&val, vars));
                } else {
                    out.push_str(&val);
                }
                i += advance + 2;
            } else if i + 2 < n && chars[i + 1] == '(' && chars[i + 2] == '(' {
                // $((expr)) — nested arithmetic.  Evaluate the inner
                // and substitute the numeric result into the outer
                // expression.
                let (inner, advance, closed) = collect_arith(&chars, i + 3);
                if closed {
                    if allow_cmdsub {
                        let inner_expanded = expand_arith_vars_mode(&inner, vars, allow_cmdsub);
                        match crate::arithmetic::eval_expr_mut(&inner_expanded, vars) {
                            Ok(v) => out.push_str(&v.to_string()),
                            Err(_) => out.push_str("0"),
                        }
                    } else {
                        out.push_str("$((");
                        out.push_str(&inner);
                        out.push_str("))");
                    }
                    i += advance + 3;
                } else {
                    out.push('$');
                    i += 1;
                }
            } else if i + 1 < n && chars[i + 1] == '(' {
                // $(cmd) — command substitution inside arithmetic context.
                // Bash executes the command substitution first, then feeds
                // its output into the surrounding arithmetic parser.
                let (body, advance, closed) = collect_paren_cmd(&chars, i + 2);
                if closed {
                    if allow_cmdsub {
                        let marker = format!("\x00CMDSUB\x00{}\x00", body);
                        let resolved = crate::exec::resolve_cmdsubs_for_expand(&marker, vars);
                        out.push_str(&resolved);
                    } else {
                        out.push_str("$(");
                        out.push_str(&body);
                        out.push(')');
                    }
                    i += advance + 2;
                } else {
                    out.push('$');
                    i += 1;
                }
            } else if i + 1 < n && (chars[i + 1].is_ascii_alphabetic() || chars[i + 1] == '_') {
                // $name
                let start = i + 1;
                let mut j = start;
                while j < n && (chars[j].is_ascii_alphanumeric() || chars[j] == '_') {
                    j += 1;
                }
                let name: String = chars[start..j].iter().collect();
                let val = vars.get(&name).unwrap_or_default();
                out.push_str(&val);
                i = j;
            } else if i + 1 < n && chars[i + 1].is_ascii_digit() {
                // $0..$9
                let digit = chars[i + 1];
                let name = digit.to_string();
                let val = vars.get(&name).unwrap_or_default();
                out.push_str(&val);
                i += 2;
            } else if i + 1 < n {
                // $? $! $$ $# $@ $* etc. — these don't live in the
                // scoped VARS table; look them up via the same path
                // expand_dollar uses.
                let special = chars[i + 1];
                let val = match special {
                    '#' => vars.positional_count().to_string(),
                    '?' => vars.get("?").unwrap_or_else(|| "0".to_string()),
                    '$' => vars.get("$").unwrap_or_else(|| "0".to_string()),
                    '!' => vars.get("!").unwrap_or_default(),
                    '@' | '*' => {
                        // $@ / $* joined with space (arith context).
                        let positionals = vars.all_positional(vars.positional_count());
                        positionals.join(" ")
                    }
                    '-' => vars.get("-").unwrap_or_default(),
                    '_' => vars.get("_").unwrap_or_default(),
                    _ => vars.get(&special.to_string()).unwrap_or_default(),
                };
                out.push_str(&val);
                i += 2;
            } else {
                out.push('$');
                i += 1;
            }
        } else {
            out.push(chars[i]);
            i += 1;
        }
    }
    out
}

pub fn expand_arith_vars(expr: &str, vars: &mut Variables) -> String {
    expand_arith_vars_mode(expr, vars, true)
}

pub fn expand_arith_vars_no_cmdsub(expr: &str, vars: &mut Variables) -> String {
    expand_arith_vars_mode(expr, vars, false)
}

/// Collect arithmetic expression between `$(( … ))`.
/// `start` is the position after `$((`.
/// Returns (expression, chars_consumed_including_closing_`))`)
/// Heuristic: does this failed-arith body look like a command-substitution
/// expression that got mis-lexed as `$((...))`?  Bash re-parses
/// `$((echo a);(echo b))` as `$( (echo a);(echo b) )` — command sub
/// containing two subshells.  Detect the pattern by:
///   * depth goes negative at some point (an unmatched `)`), OR
///   * a statement separator appears at paren depth 0.
/// Given an outer expanded expression and a raw arithmetic error, build the
/// ARITH_ERR payload.  If the error contains an INNER marker (from a
/// recursive variable evaluation), extract the inner expression and message
/// and use those instead of the outer expression.
/// Returns the payload string: either `<expr>\x1F<msg>` or just `<msg>`.
fn unwrap_inner_arith_error(outer_expr: &str, err: &str) -> String {
    const INNER_PREFIX: &str = "\x00INNER\x00";
    if let Some(start) = err.find(INNER_PREFIX) {
        let rest = &err[start + INNER_PREFIX.len()..];
        // rest is "<inner_expr>\x1F<msg>\x00..."
        if let Some(end) = rest.find('\x00') {
            let payload = &rest[..end];
            return payload.to_string(); // already "<inner_expr>\x1F<msg>"
        }
    }
    // No inner marker: use outer expression.
    format!("{}\x1F{}", outer_expr, err)
}

fn looks_like_subshell_cmdsub(expr: &str) -> bool {
    let chars: Vec<char> = expr.chars().collect();
    let mut depth = 0i32;
    let mut i = 0;
    while i < chars.len() {
        let c = chars[i];
        match c {
            '(' => depth += 1,
            ')' => {
                depth -= 1;
                if depth < 0 { return true; }
            }
            '\\' => { i += 1; }           // skip escaped char
            '\'' => {
                // Skip single-quoted block so `;`/`(` inside don't count.
                i += 1;
                while i < chars.len() && chars[i] != '\'' { i += 1; }
            }
            '"' => {
                i += 1;
                while i < chars.len() && chars[i] != '"' {
                    if chars[i] == '\\' && i + 1 < chars.len() { i += 1; }
                    i += 1;
                }
            }
            // Only `;` or stray `)` are unambiguous subshell
            // markers.  `&` and `|` are VALID arithmetic operators
            // (bitwise + logical), so they must not trigger the
            // fallback — e.g. `\$(( 0 && B=42 ))` is arith, not a
            // command list.
            ';' if depth == 0 => return true,
            _ => {}
        }
        i += 1;
    }
    false
}

/// Collect the body of an `$((expr))`.  Returns (body, chars_consumed,
/// closed_doubled).  `closed_doubled` is true when the body was terminated
/// by `))` (arith form); false when depth ran out without finding `))`,
/// meaning the caller should fall back to `$( (cmd) )` command sub.
/// Collect body of `$[...]` (deprecated arithmetic).  `start` is position
/// after the `[`.  Returns (body, chars_consumed_incl_`]`, closed).
fn collect_bracket_arith(chars: &[char], start: usize) -> (String, usize, bool) {
    let n = chars.len();
    let mut depth = 1usize;
    let mut body = String::new();
    let mut i = start;
    let mut closed = false;
    while i < n {
        if chars[i] == '[' {
            depth += 1;
            body.push('[');
            i += 1;
        } else if chars[i] == ']' {
            depth -= 1;
            if depth == 0 {
                i += 1;
                closed = true;
                break;
            }
            body.push(']');
            i += 1;
        } else {
            body.push(chars[i]);
            i += 1;
        }
    }
    (body, i - start, closed)
}

fn collect_arith(chars: &[char], start: usize) -> (String, usize, bool) {
    let n = chars.len();
    let mut depth = 1usize; // we've already seen the first `(`
    let mut body = String::new();
    let mut i = start;
    let mut closed_doubled = false;

    // We're already inside `((` so track `))`
    while i < n {
        if chars[i] == '(' {
            depth += 1;
            body.push('(');
            i += 1;
        } else if chars[i] == ')' {
            if depth == 1 {
                // Check for second `)`
                if i + 1 < n && chars[i + 1] == ')' {
                    i += 2;
                    closed_doubled = true;
                    break;
                }
            }
            // depth==0 means we've seen more `)` than `(` — this is the
            // `$(( cmd ) )` case that bash re-parses as `$( (cmd) )`.
            // Consume this `)` as the cmdsub closer and stop.
            if depth == 0 {
                i += 1;
                break;
            }
            depth -= 1;
            body.push(')');
            i += 1;
        } else {
            body.push(chars[i]);
            i += 1;
        }
    }
    (body, i - start, closed_doubled)
}

/// Collect body of `$(...)`.  `start` is position after the first `(`.
/// Returns (body, chars_consumed_including_closing_`)`)
fn collect_paren_cmd(chars: &[char], start: usize) -> (String, usize, bool) {
    let n = chars.len();
    let mut depth = 1usize;
    let mut body = String::new();
    let mut i = start;
    let mut closed = false;

    // Case-construct tracking: inside a case body, `)` is a pattern terminator,
    // not a comsub terminator, so we must not decrement paren depth for it.
    #[derive(Copy, Clone, PartialEq)]
    enum CaseScan {
        WaitIn,   // saw `case WORD`, waiting for `in`
        Pattern,  // after `in` or after `;;` — next `)` is pattern end
        Body,     // after pattern `)` — inside case arm body
    }
    let mut case_stack: Vec<CaseScan> = Vec::new();
    let mut at_word_start = true;
    // Pending heredoc: (delimiter, strip_tabs).  Set by `<<delim` and
    // consumed at the next newline by switching to body-reading mode so
    // that a `)` inside the heredoc body does not close the comsub.
    let mut pending_heredoc: Option<(String, bool)> = None;

    // True if `chars[i..]` begins with `word` followed by a word boundary.
    let starts_with_word = |i: usize, word: &str| -> bool {
        let wlen = word.chars().count();
        if i + wlen > n { return false; }
        for (k, wc) in word.chars().enumerate() {
            if chars[i + k] != wc { return false; }
        }
        match chars.get(i + wlen).copied() {
            None => true,
            Some(c) => matches!(c,
                ' ' | '\t' | '\n' | ';' | '&' | '|' | '(' | ')' | '<' | '>' | '`'),
        }
    };

    while i < n {
        // If a heredoc body is pending (we just finished the `<<delim` line),
        // consume lines until we find the delimiter; treat all of it as inert
        // text that does not affect paren depth.
        if let Some((delim, strip_tabs)) = pending_heredoc.take() {
            loop {
                // Read one line (including its trailing `\n`, if any).
                let line_start = i;
                while i < n && chars[i] != '\n' { i += 1; }
                let has_nl = i < n;
                if has_nl { i += 1; }
                let raw_line: String = chars[line_start..i].iter().collect();
                let line_no_nl = raw_line.strip_suffix('\n').unwrap_or(&raw_line);
                let check = if strip_tabs { line_no_nl.trim_start_matches('\t') } else { line_no_nl };
                if check == delim {
                    body.push_str(&raw_line);
                    break;
                }
                // Bash compat: inside $(…), a line that begins with the
                // delimiter followed by optional whitespace and `)` ends
                // the heredoc, and the `)` is left for the outer scanner
                // to close the command substitution.
                if check.starts_with(delim.as_str()) {
                    let after = &check[delim.len()..];
                    let after_trim = after.trim_start();
                    if after_trim.starts_with(')') {
                        // Consume up to and including the delimiter text.
                        let delim_end = line_start + delim.len();
                        let stripped: String = chars[line_start..delim_end].iter().collect();
                        body.push_str(&stripped);
                        i = delim_end;
                        // Skip spaces/tabs so the outer loop sees `)`.
                        while i < n && (chars[i] == ' ' || chars[i] == '\t') { i += 1; }
                        break;
                    }
                }
                body.push_str(&raw_line);
                if !has_nl { break; } // EOF while reading heredoc body
            }
            at_word_start = true;
            continue;
        }
        if at_word_start {
            // `#` at word boundary starts a line comment — do NOT track
            // parens inside it.
            if chars[i] == '#' {
                while i < n {
                    let c = chars[i];
                    body.push(c); i += 1;
                    if c == '\n' { break; }
                }
                at_word_start = true;
                continue;
            }
            if starts_with_word(i, "case") {
                case_stack.push(CaseScan::WaitIn);
            } else if starts_with_word(i, "esac") {
                // Bash case-pattern rule: in a Pattern alternative,
                // `esac` is the closer only when preceded (modulo
                // whitespace) by something other than `(` or `|`.
                // e.g. `foo|esac)` has `esac` as a pattern word, not a
                // closer.
                let esac_is_closer = match case_stack.last() {
                    Some(CaseScan::Pattern) => {
                        let prev = body.trim_end_matches(|c: char| c == ' ' || c == '\t' || c == '\n')
                            .chars().last();
                        !matches!(prev, Some('(') | Some('|'))
                    }
                    _ => true,
                };
                if esac_is_closer {
                    case_stack.pop();
                }
            } else if !case_stack.is_empty()
                && starts_with_word(i, "in")
                && matches!(case_stack.last(), Some(CaseScan::WaitIn))
            {
                // PROVEN: case_stack is non-empty (checked above), last_mut() is Some.
                *case_stack.last_mut().unwrap() = CaseScan::Pattern;
                body.push('i'); body.push('n');
                i += 2;
                at_word_start = false;
                continue;
            }
            at_word_start = false;
        }

        match chars[i] {
            '(' => { depth += 1; body.push('('); i += 1; }
            ')' => {
                // Pattern-state `)` at depth==1 is a pattern terminator.
                if matches!(case_stack.last(), Some(CaseScan::Pattern)) && depth == 1 {
                    // PROVEN: case_stack.last() is Some (just matched above).
                    *case_stack.last_mut().unwrap() = CaseScan::Body;
                    body.push(')'); i += 1;
                    continue;
                }
                depth -= 1;
                if depth == 0 { i += 1; closed = true; break; }
                body.push(')');
                i += 1;
            }
            ';' if i + 1 < n && chars[i + 1] == ';'
                && matches!(case_stack.last(), Some(CaseScan::Body)) =>
            {
                body.push(';'); body.push(';'); i += 2;
                if i < n && chars[i] == '&' { body.push('&'); i += 1; }
                // PROVEN: case_stack.last() is Some (just matched in guard above).
                *case_stack.last_mut().unwrap() = CaseScan::Pattern;
                while i < n && matches!(chars[i], ' ' | '\t' | '\n') {
                    body.push(chars[i]); i += 1;
                }
                at_word_start = true;
                continue;
            }
            ';' if i + 1 < n && chars[i + 1] == '&'
                && matches!(case_stack.last(), Some(CaseScan::Body)) =>
            {
                body.push(';'); body.push('&'); i += 2;
                // PROVEN: case_stack.last() is Some (just matched in guard above).
                *case_stack.last_mut().unwrap() = CaseScan::Pattern;
                while i < n && matches!(chars[i], ' ' | '\t' | '\n') {
                    body.push(chars[i]); i += 1;
                }
                at_word_start = true;
                continue;
            }
            '\'' => {
                body.push('\'');
                i += 1;
                while i < n && chars[i] != '\'' {
                    body.push(chars[i]);
                    i += 1;
                }
                if i < n { body.push('\''); i += 1; }
            }
            '"' => {
                body.push('"');
                i += 1;
                while i < n && chars[i] != '"' {
                    if chars[i] == '\\' {
                        body.push(chars[i]); i += 1;
                        if i < n { body.push(chars[i]); i += 1; }
                        continue;
                    }
                    // Nested `$(...)` inside the double-quoted string:
                    // recurse into it so the `)` closing the nested
                    // cmdsub doesn't mis-close our outer one, and the
                    // `"` inside its body doesn't end our outer quote.
                    if chars[i] == '$' && i + 1 < n && chars[i + 1] == '(' {
                        body.push('$');
                        body.push('(');
                        i += 2;
                        let (inner, inner_advance, _closed) =
                            collect_paren_cmd(chars, i);
                        body.push_str(&inner);
                        body.push(')');
                        i += inner_advance;
                        continue;
                    }
                    // Nested backtick — consume the backtick body
                    // without interpreting its contents.
                    if chars[i] == '`' {
                        body.push('`');
                        i += 1;
                        while i < n && chars[i] != '`' {
                            if chars[i] == '\\' && i + 1 < n {
                                body.push(chars[i]); i += 1;
                            }
                            body.push(chars[i]); i += 1;
                        }
                        if i < n { body.push('`'); i += 1; }
                        continue;
                    }
                    body.push(chars[i]); i += 1;
                }
                if i < n { body.push('"'); i += 1; }
            }
            '\\' => {
                body.push(chars[i]);
                i += 1;
                if i < n { body.push(chars[i]); i += 1; }
            }
            '<' if i + 2 < n && chars[i + 1] == '<' && chars[i + 2] == '<' => {
                body.push('<'); body.push('<'); body.push('<'); i += 3;
            }
            '<' if i + 1 < n && chars[i + 1] == '<' && chars.get(i + 2).copied() != Some('<') => {
                // Heredoc operator `<<` or `<<-`.  Parse the delimiter and
                // stash it so we can consume the body after the next `\n`.
                body.push('<'); body.push('<'); i += 2;
                let strip_tabs = i < n && chars[i] == '-';
                if strip_tabs { body.push('-'); i += 1; }
                // Skip horizontal whitespace between `<<` and the delimiter.
                while i < n && (chars[i] == ' ' || chars[i] == '\t') {
                    body.push(chars[i]); i += 1;
                }
                // Read the delimiter: quoted forms preserve quotes literally
                // in the captured body, but the delimiter compared against
                // body lines is always unquoted.
                let mut delim = String::new();
                if i < n && chars[i] == '\'' {
                    body.push('\''); i += 1;
                    while i < n && chars[i] != '\'' {
                        delim.push(chars[i]); body.push(chars[i]); i += 1;
                    }
                    if i < n { body.push('\''); i += 1; }
                } else if i < n && chars[i] == '"' {
                    body.push('"'); i += 1;
                    while i < n && chars[i] != '"' {
                        if chars[i] == '\\' && i + 1 < n {
                            body.push(chars[i]); i += 1;
                            delim.push(chars[i]); body.push(chars[i]); i += 1;
                        } else {
                            delim.push(chars[i]); body.push(chars[i]); i += 1;
                        }
                    }
                    if i < n { body.push('"'); i += 1; }
                } else if i < n && chars[i] == '\\' {
                    // Leading backslash: consume the next char as the first
                    // delimiter char (even if it would otherwise be a
                    // metacharacter like `)`), then continue reading normal
                    // delimiter chars.
                    body.push('\\'); i += 1;
                    if i < n {
                        if chars[i] == '\n' {
                            body.push(chars[i]); i += 1;
                        } else {
                            delim.push(chars[i]); body.push(chars[i]); i += 1;
                        }
                    }
                    while i < n && !matches!(chars[i], ' '|'\t'|'\n'|';'|'&'|'|'|'<'|'>'|'('|')') {
                        if chars[i] == '\\' && i + 1 < n {
                            body.push(chars[i]); i += 1;
                            if chars[i] == '\n' {
                                body.push(chars[i]); i += 1;
                            } else {
                                delim.push(chars[i]); body.push(chars[i]); i += 1;
                            }
                        } else {
                            delim.push(chars[i]); body.push(chars[i]); i += 1;
                        }
                    }
                } else {
                    while i < n && !matches!(chars[i], ' '|'\t'|'\n'|';'|'&'|'|'|'<'|'>'|'('|')') {
                        delim.push(chars[i]); body.push(chars[i]); i += 1;
                    }
                }
                if !delim.is_empty() {
                    pending_heredoc = Some((delim, strip_tabs));
                }
            }
            c if c == ' ' || c == '\t' || c == '\n' => {
                body.push(c); i += 1;
                at_word_start = true;
            }
            ';' | '|' | '&' => {
                body.push(chars[i]); i += 1;
                at_word_start = true;
            }
            _ => { body.push(chars[i]); i += 1; }
        }
    }
    (body, i - start, closed)
}

pub(crate) fn collect_paren_cmd_pub(chars: &[char], start: usize) -> (String, usize, bool) {
    collect_paren_cmd(chars, start)
}

/// Collect body of backtick command `\`...\``.
/// `start` is position after the opening backtick.
/// Returns (body, chars_consumed_including_closing_backtick).
fn collect_backtick(chars: &[char], start: usize) -> (String, usize) {
    let n = chars.len();
    let mut body = String::new();
    let mut i = start;

    while i < n {
        match chars[i] {
            '`' => { i += 1; break; }
            '\\' => {
                i += 1;
                if i < n {
                    match chars[i] {
                        '$' | '`' | '\\' => { body.push(chars[i]); i += 1; }
                        '\n' => { i += 1; } // line continuation
                        _ => { body.push('\\'); body.push(chars[i]); i += 1; }
                    }
                }
            }
            _ => { body.push(chars[i]); i += 1; }
        }
    }
    (body, i - start)
}

pub(crate) fn collect_backtick_pub(chars: &[char], start: usize) -> (String, usize) {
    collect_backtick(chars, start)
}

// ─────────────────────────────────────────────────────────────────────────────
// Word splitting
// ─────────────────────────────────────────────────────────────────────────────

const QNULL_SENTINEL: char = '\u{FDD1}';

/// Split `s` on IFS characters.
///
/// IFS whitespace characters (space, tab, newline by default) are treated as
/// run-collapsing separators; non-whitespace IFS chars delimit fields even
/// when adjacent.
fn word_split_core(s: &str, ifs: &str) -> Vec<String> {
    if ifs.is_empty() {
        // Empty input → no fields (same as non-empty IFS behavior)
        if s.is_empty() {
            return Vec::new();
        }
        // No ordinary IFS splitting, but still honour the synthetic field
        // separators from array/positional expansions.
        if s.contains('\u{FFFE}') || s.contains('\u{FFFF}') {
            let mut fields = Vec::new();
            let mut current = String::new();
            let mut saw_quoted_sep = false;
            for c in s.chars() {
                if c == '\u{FFFE}' {
                    if !current.is_empty() {
                        fields.push(std::mem::take(&mut current));
                    }
                    continue;
                }
                if c == '\u{FFFF}' {
                    fields.push(std::mem::take(&mut current));
                    saw_quoted_sep = true;
                    continue;
                }
                current.push(c);
            }
            if !current.is_empty() || saw_quoted_sep {
                fields.push(current);
            }
            return fields;
        }
        return vec![s.to_string()];
    }

    let ifs_bytes = decode_raw_bytes(ifs);
    if ifs_bytes.iter().any(|&b| b >= 0x80)
        && !s.contains(CTLESC)
        && !s.contains('\u{FFFE}')
        && !s.contains('\u{FFFF}')
    {
        if let Some(codeset) = current_locale_codeset() {
            let units = locale_units(s, &codeset);
            let ifs_units = locale_units(ifs, &codeset);
            let ifs_ws: Vec<String> = ifs_units.iter()
                .filter(|u| u.chars().all(|c| c.is_whitespace()))
                .cloned()
                .collect();
            let ifs_nonws: Vec<String> = ifs_units.iter()
                .filter(|u| !u.chars().all(|c| c.is_whitespace()))
                .cloned()
                .collect();
            let mut fields = Vec::new();
            let mut current = String::new();
            let mut i = 0usize;
            while i < units.len() && ifs_ws.contains(&units[i]) {
                i += 1;
            }
            while i < units.len() {
                if ifs_ws.contains(&units[i]) {
                    if !current.is_empty() {
                        fields.push(std::mem::take(&mut current));
                    }
                    while i < units.len() && ifs_ws.contains(&units[i]) {
                        i += 1;
                    }
                    continue;
                }
                if ifs_nonws.contains(&units[i]) {
                    fields.push(std::mem::take(&mut current));
                    i += 1;
                    continue;
                }
                current.push_str(&units[i]);
                i += 1;
            }
            if !current.is_empty() {
                fields.push(current);
            }
            if fields.is_empty() && !s.is_empty() {
                return Vec::new();
            }
            return fields;
        }
    }

    let (ifs_white, ifs_non_white): (Vec<char>, Vec<char>) = ifs
        .chars()
        .partition(|c| c.is_whitespace());

    let mut fields: Vec<String> = Vec::new();
    let mut current = String::new();
    // `pushed_content_since_reset` tracks whether the current field (or the
    // last field we pushed) came from non-delimiter characters.  This
    // determines whether a ws-run should absorb an adjacent non-ws IFS
    // char as part of the same delimiter (YES if we had content), or
    // leave it to be processed as a standalone delim boundary (NO).
    let mut pushed_content = false;
    // Set when a \u{FFFF} quoted-positional separator was seen.  A trailing
    // empty field after the last FFFF must be pushed (empty `""` positional
    // at the end of `"$@"`).
    let mut saw_quoted_sep = false;
    let mut chars = s.chars().peekable();

    // Skip leading IFS whitespace (but not CTLESC-marked quoted whitespace)
    while let Some(&c) = chars.peek() {
        if c == CTLESC {
            break; // Quoted character — stop skipping
        }
        if ifs_white.contains(&c) {
            chars.next();
        } else {
            break;
        }
    }

    while let Some(c) = chars.next() {
        // CTLESC marks the next character as quoted (not subject to IFS splitting)
        if c == CTLESC {
            if let Some(nc) = chars.next() {
                current.push(CTLESC);
                current.push(nc);
            }
            continue;
        }

        // The special \u{FFFE} separator from UNQUOTED $@/$*/${A[@]}/${A[*]}
        // always causes a field split.  Only push if current is non-empty;
        // if IFS whitespace already consumed the preceding content, pushing
        // an empty field here would create a spurious blank field.
        if c == '\u{FFFE}' {
            if !current.is_empty() {
                fields.push(current.clone());
                current = String::new();
                pushed_content = true;
            }
            continue;
        }
        // The \u{FFFF} separator is emitted by QUOTED "$@" / "${arr[@]}"
        // to preserve every positional field — including empty ones —
        // across downstream word-splitting, matching bash's behaviour
        // where quoted `"$@"` with an empty positional produces an
        // empty word.
        if c == '\u{FFFF}' {
            fields.push(std::mem::take(&mut current));
            pushed_content = true;
            saw_quoted_sep = true;
            continue;
        }

        if ifs_white.contains(&c) {
            if current.is_empty() && saw_quoted_sep {
                fields.push(String::new());
                saw_quoted_sep = false;
                pushed_content = true;
            }
            // Run of IFS whitespace: end field if there was content
            let had_content = !current.is_empty();
            if had_content {
                fields.push(current.clone());
                current = String::new();
                pushed_content = true;
            }
            // Skip remaining unquoted whitespace
            while let Some(&nc) = chars.peek() {
                if nc == CTLESC {
                    break;
                }
                if ifs_white.contains(&nc) {
                    chars.next();
                } else {
                    break;
                }
            }
            // Absorb an adjacent non-ws IFS only if this ws run just
            // terminated a content-bearing field; otherwise the non-ws
            // char is a standalone delim boundary and must produce its
            // own empty field.
            if had_content || pushed_content {
                if let Some(&nc) = chars.peek() {
                    if ifs_non_white.contains(&nc) {
                        chars.next();
                        pushed_content = false;
                    }
                }
            }
        } else if ifs_non_white.contains(&c) {
            fields.push(current.clone());
            current = String::new();
            pushed_content = false;
        } else {
            current.push(c);
        }
    }

    if !current.is_empty() {
        fields.push(current);
    } else if saw_quoted_sep {
        // Trailing empty positional after "$@" separator — preserve it
        // as an empty field, the way bash's quoted "$@" does.
        fields.push(String::new());
    }

    if fields.is_empty() && !s.is_empty() {
        // Entire string was IFS chars (unquoted)
        return Vec::new();
    }

    fields
}

pub fn word_split(s: &str, ifs: &str) -> Vec<String> {
    if s.contains("\x00QNULL\x00") {
        let qnullized = s.replace("\x00QNULL\x00", &QNULL_SENTINEL.to_string());
        let mut fields = word_split_core(&qnullized, ifs);
        for field in &mut fields {
            if field.contains(QNULL_SENTINEL) {
                *field = field.replace(QNULL_SENTINEL, "");
            }
        }
        return fields;
    }
    word_split_core(s, ifs)
}

// ─────────────────────────────────────────────────────────────────────────────
// Pathname expansion (globbing)
// ─────────────────────────────────────────────────────────────────────────────

/// Expand a single field via pathname (glob) expansion.
/// Returns the list of matching paths, or the original string if no match.
/// Read the current value of the `dotglob` shopt from the thread-local
/// cell maintained by `sync_glob_shopts`.  When true, `*` and `?`
/// patterns include files whose names start with `.`.
fn current_dotglob() -> bool {
    crate::exec::GLOB_SHOPTS.with(|c| c.get().dotglob)
}

/// Read the current value of the `nocaseglob` shopt.
fn current_nocaseglob() -> bool {
    crate::exec::GLOB_SHOPTS.with(|c| c.get().nocaseglob)
}

fn current_nocasematch() -> bool {
    crate::exec::GLOB_SHOPTS.with(|c| c.get().nocasematch)
}

fn current_globstar() -> bool {
    crate::exec::GLOB_SHOPTS.with(|c| c.get().globstar)
}

/// Read the current value of the `globskipdots` shopt.  When true
/// (the bash 5.2+ default), `.` and `..` directory entries are
/// excluded from pattern matches even when the pattern starts with
/// `.`; when false, they're included.
fn current_globskipdots() -> bool {
    crate::exec::GLOB_SHOPTS.with(|c| c.get().globskipdots)
}

fn current_globignore() -> Option<String> {
    crate::exec::GLOB_RUNTIME.with(|r| r.borrow().globignore.clone())
}

fn current_globsort() -> Option<String> {
    crate::exec::GLOB_RUNTIME.with(|r| r.borrow().globsort.clone())
}

fn has_extglob_meta(pat: &str) -> bool {
    let b = pat.as_bytes();
    for i in 0..b.len().saturating_sub(1) {
        if matches!(b[i], b'?' | b'*' | b'+' | b'@' | b'!') && b[i + 1] == b'(' {
            return true;
        }
    }
    false
}

/// Does the pattern contain a `[^...]` negated character class?  The
/// `glob` crate only accepts `[!...]`, so we need to detect this and
/// fall back to our own matcher.
fn has_caret_bracket(pat: &str) -> bool {
    let b = pat.as_bytes();
    for i in 0..b.len().saturating_sub(1) {
        if b[i] == b'[' && b[i + 1] == b'^' {
            return true;
        }
    }
    false
}

/// Does the pattern contain a POSIX `[[:class:]]` character class?
/// The `glob` crate doesn't understand these.
fn has_posix_class(pat: &str) -> bool {
    let b = pat.as_bytes();
    for i in 0..b.len().saturating_sub(1) {
        if b[i] == b'[' && b[i + 1] == b':' {
            return true;
        }
    }
    false
}

/// Minimal pathname expansion for extglob patterns.  Supports only
/// one path-component pattern (no `/` inside extglob).  Iterates the
/// directory (cwd or the parent implied by any literal path prefix)
/// and returns entries matching the extglob pattern.
fn extglob_pathname_expand(field: &str) -> Vec<String> {
    use std::path::Path;
    // Split into dir-prefix (literal) and file-pattern.  For now,
    // we handle only single-component patterns.  A path-pattern with
    // `/` inside the extglob is rare; fall back to returning the
    // pattern itself if that happens.
    let (dir_prefix, pat) = match field.rsplit_once('/') {
        Some((d, p)) => (d, p),
        None => ("", field),
    };
    let search_dir: &Path = if dir_prefix.is_empty() {
        Path::new(".")
    } else {
        Path::new(dir_prefix)
    };
    let entries_iter = match std::fs::read_dir(search_dir) {
        Ok(it) => it,
        Err(_) => return vec![field.to_string()],
    };
    let dotglob = current_dotglob();
    let pat_starts_dot = pattern_component_starts_with_dot(pat);
    let globskipdots = current_globskipdots();
    let mut names: Vec<String> = entries_iter
        .flatten()
        .map(|ent| ent.file_name().to_string_lossy().into_owned())
        .collect();
    // When the pattern can match names starting with `.` and globskipdots is
    // off, add `.` and `..` to the candidate list (read_dir never includes them).
    if pat_starts_dot && !globskipdots {
        names.push(".".to_string());
        names.push("..".to_string());
    }
    let mut results: Vec<String> = Vec::new();
    for name in names {
        // globskipdots: never match `.` or `..`
        if globskipdots && (name == "." || name == "..") {
            continue;
        }
        if name.starts_with('.') {
            // Dotfile protection rules:
            // - `.` and `..` can only be matched if some dot-starting sub-pattern
            //   explicitly matches them (no dotglob exception).
            // - Regular dotfiles can be matched via any pattern when dotglob is on,
            //   but only via dot-starting sub-patterns when dotglob is off.
            if name == "." || name == ".." {
                if !dotfile_pattern_matches(pat, &name) {
                    continue;
                }
            } else if dotglob {
                // dotglob on: allow any match, but pattern must still actually match
                if !pat_starts_dot && !crate::builtins::glob_match_pub(pat, &name) {
                    continue;
                }
            } else {
                // dotglob off: only dot-starting sub-patterns may match dotfiles
                if !dotfile_pattern_matches(pat, &name) {
                    continue;
                }
            }
        }
        if crate::builtins::glob_match_pub(pat, &name) {
            let joined = if dir_prefix.is_empty() {
                name
            } else {
                format!("{}/{}", dir_prefix, name)
            };
            results.push(joined);
        }
    }
    if results.is_empty() {
        // Respect nullglob and failglob just like the main pathname_expand.
        let shopts = crate::exec::GLOB_SHOPTS.with(|c| c.get());
        if shopts.failglob {
            let prefix = crate::exec::CURRENT_ERR_PREFIX.with(|p| p.borrow().clone());
            if prefix.is_empty() {
                eprintln!("no match: {}", field);
            } else {
                eprintln!("{}: no match: {}", prefix, field);
            }
            return vec![format!("\x00EXPAND_ERROR\x00no match: {}\x00", field)];
        }
        if shopts.nullglob {
            Vec::new()
        } else {
            vec![field.to_string()]
        }
    } else {
        results.sort();
        results
    }
}

fn normalize_pathname_pattern(field: &str) -> String {
    let chars: Vec<char> = field.chars().collect();
    let mut out = String::with_capacity(field.len());
    let mut i = 0;
    while i < chars.len() {
        match chars[i] {
            CTLESC => {
                if i + 1 < chars.len() {
                    out.push('\\');
                    out.push(chars[i + 1]);
                    i += 2;
                } else {
                    i += 1;
                }
            }
            '\\' => {
                if i + 1 >= chars.len() {
                    out.push('\\');
                    break;
                }
                let next = chars[i + 1];
                if next == CTLESC {
                    if i + 2 < chars.len() {
                        let quoted = chars[i + 2];
                        out.push('\\');
                        out.push('\\');
                        if matches!(quoted, '*' | '?' | '[' | '\\') {
                            out.push('\\');
                        }
                        out.push(quoted);
                        i += 3;
                        continue;
                    }
                    out.push('\\');
                    i += 2;
                    continue;
                }
                match next {
                    '*' | '?' | '[' | ']' | '\\' => {
                        out.push('\\');
                        out.push(next);
                    }
                    '/' => {
                        out.push('\\');
                        out.push('/');
                    }
                    _ => out.push(next),
                }
                i += 2;
            }
            c => {
                out.push(c);
                i += 1;
            }
        }
    }
    out
}

fn component_has_glob_meta(component: &str) -> bool {
    let chars: Vec<char> = component.chars().collect();
    let mut i = 0;
    while i < chars.len() {
        match chars[i] {
            '\\' => {
                i += 2;
            }
            '*' | '?' => return true,
            '[' => {
                if component_bracket_closes(&chars, i + 1) {
                    return true;
                }
                i += 1;
            }
            c if matches!(c, '?' | '*' | '+' | '@' | '!') && i + 1 < chars.len() && chars[i + 1] == '(' => {
                return true;
            }
            _ => i += 1,
        }
    }
    false
}

fn component_bracket_closes(chars: &[char], mut i: usize) -> bool {
    if i < chars.len() && matches!(chars[i], '!' | '^') {
        i += 1;
    }
    if i < chars.len() && chars[i] == ']' {
        i += 1;
    }
    while i < chars.len() {
        match chars[i] {
            '\\' if i + 1 < chars.len() => i += 2,
            ']' => return true,
            _ => i += 1,
        }
    }
    false
}

fn split_path_pattern(pattern: &str) -> Vec<String> {
    let chars: Vec<char> = pattern.chars().collect();
    let mut components = Vec::new();
    let mut current = String::new();
    let mut i = 0;
    let mut in_class = false;
    let mut escape = false;

    while i < chars.len() {
        let c = chars[i];
        if escape {
            current.push(c);
            escape = false;
            i += 1;
            continue;
        }
        match c {
            '\\' => {
                current.push(c);
                escape = true;
            }
            '[' => {
                in_class = true;
                current.push(c);
            }
            ']' if in_class => {
                in_class = false;
                current.push(c);
            }
            '/' if !in_class => {
                components.push(current);
                current = String::new();
            }
            _ => current.push(c),
        }
        i += 1;
    }
    components.push(current);
    components
}

fn is_globstar_component(component: &str) -> bool {
    current_globstar() && component == "**"
}

fn compress_adjacent_globstars(components: Vec<String>) -> Vec<String> {
    let mut out: Vec<String> = Vec::with_capacity(components.len());
    for component in components {
        if is_globstar_component(&component)
            && out.last().map(|c| is_globstar_component(c)).unwrap_or(false)
        {
            continue;
        }
        out.push(component);
    }
    out
}

/// Find the index of the matching closing `)` for an extglob, starting search
/// at `start` (the character after the opening `(`).  Returns `None` if no
/// matching `)` is found.  Handles nested extglob and bracket expressions.
fn find_extglob_close_pat(chars: &[char], start: usize) -> Option<usize> {
    let mut depth: usize = 0;
    let mut i = start;
    while i < chars.len() {
        match chars[i] {
            '[' => {
                // Skip bracket expression
                i += 1;
                if i < chars.len() && matches!(chars[i], '!' | '^') {
                    i += 1;
                }
                if i < chars.len() && chars[i] == ']' {
                    i += 1; // initial ] is literal
                }
                while i < chars.len() && chars[i] != ']' {
                    i += 1;
                }
                // skip past ']'
            }
            '\\' => {
                i += 2; // skip escaped char
                continue;
            }
            c if matches!(c, '?' | '*' | '+' | '@' | '!') && i + 1 < chars.len() && chars[i + 1] == '(' => {
                depth += 1;
                i += 2;
                continue;
            }
            ')' => {
                if depth == 0 {
                    return Some(i);
                }
                depth -= 1;
            }
            _ => {}
        }
        i += 1;
    }
    None
}

/// Check if a pattern component can match filenames that start with `.`.
/// This is used to decide whether dotfile protection applies: if the pattern
/// *could* produce a match whose first character is `.`, we must allow dotfiles
/// to be considered even when dotglob is off.
///
/// Rules (mirroring bash behaviour):
/// - A literal `.` or `\.` at the start → true.
/// - An extglob `X(alts)suffix` at the start:
///   - If `X != '!'`: true when any `alt` starts_with_dot, OR when `suffix`
///     starts_with_dot (e.g. `*(bar).foo` matches `.foo`).
///   - If `X == '!'`: `!()` extglob does NOT grant dotfile access even if the
///     suffix starts with `.`.  Only literal-dot patterns bypass dotfile
///     protection; `!(bar).foo` does NOT match dotfiles.
fn pattern_component_starts_with_dot(component: &str) -> bool {
    let chars: Vec<char> = component.chars().collect();
    if chars.is_empty() {
        return false;
    }
    // Plain dot or escaped dot at start
    if chars[0] == '.' {
        return true;
    }
    if chars[0] == '\\' {
        return chars.get(1) == Some(&'.');
    }
    // Extglob at start: X(...)  — `!()` never grants dot access.
    if chars.len() >= 2
        && chars[1] == '('
        && matches!(chars[0], '?' | '*' | '+' | '@')
    {
        let op = chars[0];
        if let Some(close) = find_extglob_close_pat(&chars, 2) {
            // For non-`!` extglob: check alternatives
            // Split alternatives by `|` (respecting nesting) and check each
            let mut depth: usize = 0;
            let mut alt_start = 2usize;
            for idx in 2..close {
                match chars[idx] {
                    c if matches!(c, '?' | '*' | '+' | '@' | '!') && idx + 1 < chars.len() && chars[idx + 1] == '(' => {
                        depth += 1;
                    }
                    ')' if depth > 0 => {
                        depth -= 1;
                    }
                    '|' if depth == 0 => {
                        let alt: String = chars[alt_start..idx].iter().collect();
                        if pattern_component_starts_with_dot(&alt) {
                            return true;
                        }
                        alt_start = idx + 1;
                    }
                    _ => {}
                }
            }
            // Last alternative
            let alt: String = chars[alt_start..close].iter().collect();
            if pattern_component_starts_with_dot(&alt) {
                return true;
            }
            // Check the suffix after the closing `)`
            let suffix: String = chars[close + 1..].iter().collect();
            if pattern_component_starts_with_dot(&suffix) {
                return true;
            }
            let _ = op; // used in old code; keep for clarity
        }
    }
    false
}

/// Build a variant of `pat` that contains only alternatives that start with
/// `.`, then test whether that restricted pattern matches `name`.  This is used
/// to enforce bash's dotfile protection rule for extglob pathname expansion:
/// a dotfile may only be matched if the portion of the pattern responsible for
/// the match itself begins with `.`.
///
/// For a plain literal pattern (no extglob) this is equivalent to checking
/// `pattern_component_starts_with_dot(pat) && glob_match_pub(pat, name)`.
/// For extglob it's more subtle: `@(.foo|*)` restricted becomes `@(.foo)`.
fn dotfile_pattern_matches(pat: &str, name: &str) -> bool {
    let chars: Vec<char> = pat.chars().collect();
    if chars.is_empty() {
        return false;
    }
    // Plain literal starting with `.`
    if chars[0] == '.' || (chars[0] == '\\' && chars.get(1) == Some(&'.')) {
        return crate::builtins::glob_match_pub(pat, name);
    }
    // Extglob at start: X(alts)suffix.
    // `!()` extglob does NOT grant dotfile access at all (not via alts, not via suffix).
    if chars.len() >= 2
        && chars[1] == '('
        && matches!(chars[0], '?' | '*' | '+' | '@')
    {
        let op = chars[0];
        if let Some(close) = find_extglob_close_pat(&chars, 2) {
            let suffix: String = chars[close + 1..].iter().collect();
            // Check whether the suffix starts with dot: if so, test the full
            // pattern (the extglob matches some prefix, suffix provides the dot).
            if !suffix.is_empty() && dotfile_pattern_matches(&suffix, name) {
                return crate::builtins::glob_match_pub(pat, name);
            }
            // Build a restricted pattern: keep only dot-starting alts
            let mut depth: usize = 0;
            let mut alt_start = 2usize;
            let mut dot_alts: Vec<String> = Vec::new();
            for idx in 2..close {
                match chars[idx] {
                    c if matches!(c, '?' | '*' | '+' | '@' | '!') && idx + 1 < chars.len() && chars[idx + 1] == '(' => {
                        depth += 1;
                    }
                    ')' if depth > 0 => {
                        depth -= 1;
                    }
                    '|' if depth == 0 => {
                        let alt: String = chars[alt_start..idx].iter().collect();
                        if pattern_component_starts_with_dot(&alt) {
                            dot_alts.push(alt);
                        }
                        alt_start = idx + 1;
                    }
                    _ => {}
                }
            }
            let last_alt: String = chars[alt_start..close].iter().collect();
            if pattern_component_starts_with_dot(&last_alt) {
                dot_alts.push(last_alt);
            }
            if dot_alts.is_empty() {
                return false;
            }
            let restricted = format!("{}({}){}", op, dot_alts.join("|"), suffix);
            return crate::builtins::glob_match_pub(&restricted, name);
        }
    }
    false
}

fn component_has_quoted_slash(component: &str) -> bool {
    let chars: Vec<char> = component.chars().collect();
    let mut i = 0;
    while i + 1 < chars.len() {
        if chars[i] == '\\' && chars[i + 1] == '/' {
            return true;
        }
        if chars[i] == '\\' {
            i += 2;
        } else {
            i += 1;
        }
    }
    false
}

fn unescape_glob_component(component: &str) -> String {
    let mut out = String::with_capacity(component.len());
    let mut chars = component.chars().peekable();
    while let Some(c) = chars.next() {
        if c == '\\' {
            if let Some(next) = chars.next() {
                out.push(next);
            } else {
                out.push('\\');
            }
        } else {
            out.push(c);
        }
    }
    out
}

fn join_display_path(base: &str, name: &str) -> String {
    if base.is_empty() {
        name.to_string()
    } else if base == "/" {
        format!("/{}", name)
    } else {
        format!("{}/{}", base, name)
    }
}

fn glob_match_component(pattern: &str, name: &str) -> bool {
    if component_has_invalid_bracket_slash(pattern) {
        return false;
    }
    if current_nocaseglob() {
        crate::builtins::glob_match_pub(&pattern.to_lowercase(), &name.to_lowercase())
    } else {
        crate::builtins::glob_match_pub(pattern, name)
    }
}

fn component_has_invalid_bracket_slash(component: &str) -> bool {
    let chars: Vec<char> = component.chars().collect();
    let mut i = 0;
    while i < chars.len() {
        if chars[i] == '[' && component_bracket_closes(&chars, i + 1) {
            let mut j = i + 1;
            if j < chars.len() && matches!(chars[j], '!' | '^') {
                j += 1;
            }
            if j < chars.len() && chars[j] == ']' {
                j += 1;
            }
            while j < chars.len() {
                match chars[j] {
                    ']' => break,
                    '/' => return true,
                    '\\' if j + 1 < chars.len() && chars[j + 1] == '/' => return true,
                    '\\' if j + 1 < chars.len() => j += 2,
                    _ => j += 1,
                }
            }
            i = j;
        }
        i += 1;
    }
    false
}

fn path_basename(path: &str) -> &str {
    path.rsplit('/').next().unwrap_or(path)
}

#[derive(Clone, Copy, PartialEq, Eq)]
enum GlobSortKey {
    Name,
    Atime,
    Mtime,
    Size,
}

fn parse_globsort() -> (GlobSortKey, bool) {
    let Some(spec) = current_globsort() else {
        return (GlobSortKey::Name, false);
    };
    if spec.is_empty() {
        return (GlobSortKey::Name, false);
    }
    let (reverse, key) = match spec.as_bytes()[0] {
        b'+' => (false, &spec[1..]),
        b'-' => (true, &spec[1..]),
        _ => (false, spec.as_str()),
    };
    match key {
        "name" => (GlobSortKey::Name, reverse),
        "atime" => (GlobSortKey::Atime, reverse),
        "mtime" => (GlobSortKey::Mtime, reverse),
        "size" => (GlobSortKey::Size, reverse),
        _ => (GlobSortKey::Name, false),
    }
}

fn glob_sort_metric(path: &str, key: GlobSortKey) -> i128 {
    if key == GlobSortKey::Name {
        return 0;
    }
    use std::os::unix::fs::MetadataExt;
    let Ok(meta) = std::fs::symlink_metadata(path) else {
        return 0;
    };
    match key {
        GlobSortKey::Name => 0,
        GlobSortKey::Atime => (meta.atime() as i128) * 1_000_000_000 + meta.atime_nsec() as i128,
        GlobSortKey::Mtime => (meta.mtime() as i128) * 1_000_000_000 + meta.mtime_nsec() as i128,
        GlobSortKey::Size => meta.size() as i128,
    }
}

fn sort_glob_results(results: &mut [String]) {
    let (key, reverse) = parse_globsort();
    results.sort_by(|a, b| {
        let ord = if key == GlobSortKey::Name {
            path_basename(a).cmp(path_basename(b)).then_with(|| a.cmp(b))
        } else {
            let primary = glob_sort_metric(a, key).cmp(&glob_sort_metric(b, key));
            if primary == std::cmp::Ordering::Equal {
                path_basename(a).cmp(path_basename(b)).then_with(|| a.cmp(b))
            } else {
                primary
            }
        };
        if reverse { ord.reverse() } else { ord }
    });
}

/// Split a `GLOBIGNORE` value into individual patterns.  Unlike a plain
/// `split(':')`, this respects extglob `(…)` and bracket `[…]`
/// expressions so that a `:` inside (e.g.) `@(-.,:; _)` doesn't act as
/// a separator.  bash 5.3 does the same — `+([^[:alnum:]])` and
/// `@([-.,:; _])` are each a single pattern even though they contain
/// internal colons.
fn split_globignore(s: &str) -> Vec<String> {
    let chars: Vec<char> = s.chars().collect();
    let n = chars.len();
    let mut out: Vec<String> = Vec::new();
    let mut current = String::new();
    let mut paren_depth: usize = 0;
    let mut bracket_depth: usize = 0;
    let mut i = 0usize;
    while i < n {
        let c = chars[i];
        if c == '\\' && i + 1 < n {
            current.push(c);
            current.push(chars[i + 1]);
            i += 2;
            continue;
        }
        if bracket_depth == 0 && (c == '?' || c == '*' || c == '+' || c == '@' || c == '!')
            && i + 1 < n && chars[i + 1] == '('
        {
            current.push(c);
            current.push('(');
            paren_depth += 1;
            i += 2;
            continue;
        }
        if c == '(' && bracket_depth == 0 {
            paren_depth += 1;
            current.push(c);
            i += 1;
            continue;
        }
        if c == ')' && paren_depth > 0 && bracket_depth == 0 {
            paren_depth -= 1;
            current.push(c);
            i += 1;
            continue;
        }
        if c == '[' && bracket_depth == 0 {
            bracket_depth += 1;
            current.push(c);
            i += 1;
            continue;
        }
        if c == ']' && bracket_depth > 0 {
            bracket_depth -= 1;
            current.push(c);
            i += 1;
            continue;
        }
        if c == ':' && paren_depth == 0 && bracket_depth == 0 {
            out.push(std::mem::take(&mut current));
            i += 1;
            continue;
        }
        current.push(c);
        i += 1;
    }
    out.push(current);
    out
}

fn apply_globignore(results: Vec<String>) -> Vec<String> {
    let Some(raw) = current_globignore() else {
        return results;
    };
    let patterns: Vec<String> = split_globignore(&raw)
        .into_iter()
        .filter(|s| !s.is_empty())
        .map(|s| normalize_pathname_pattern(s.as_str()))
        .collect();
    if patterns.is_empty() {
        return results;
    }
    results
        .into_iter()
        .filter(|path| {
            let base = path_basename(path);
            if base == "." || base == ".." {
                return false;
            }
            !patterns.iter().any(|pat| glob_match_component(pat, base))
        })
        .collect()
}

fn finalize_glob_results(mut results: Vec<String>, require_dir_suffix: bool) -> Vec<String> {
    results = apply_globignore(results);
    sort_glob_results(&mut results);
    if require_dir_suffix {
        for path in &mut results {
            if !path.ends_with('/') {
                path.push('/');
            }
        }
    }
    results
}

fn pathname_expand_no_match(field: &str) -> Vec<String> {
    let shopts = crate::exec::GLOB_SHOPTS.with(|c| c.get());
    if shopts.failglob {
        let prefix = crate::exec::CURRENT_ERR_PREFIX.with(|p| p.borrow().clone());
        if prefix.is_empty() {
            eprintln!("no match: {}", field);
        } else {
            eprintln!("{}: no match: {}", prefix, field);
        }
        return vec![format!("\x00EXPAND_ERROR\x00no match: {}\x00", field)];
    }
    if shopts.nullglob {
        Vec::new()
    } else {
        vec![field.to_string()]
    }
}

fn pathname_expand_recursive(pattern: &str) -> Vec<String> {
    use std::path::{Path, PathBuf};

    fn parent_dir(path: &Path) -> PathBuf {
        path.parent().unwrap_or_else(|| Path::new("/")).to_path_buf()
    }

    fn globstar_zero_display(base_display: &str, total_globstars: usize) -> String {
        if total_globstars == 1 && !base_display.is_empty() && base_display != "/" {
            format!("{}/", base_display.trim_end_matches('/'))
        } else {
            base_display.to_string()
        }
    }

    fn dir_display(path: &str) -> String {
        if path == "/" {
            "/".to_string()
        } else {
            format!("{}/", path.trim_end_matches('/'))
        }
    }

    fn entry_is_matchable_dir(path: &Path) -> bool {
        std::fs::metadata(path).map(|m| m.is_dir()).unwrap_or(false)
    }

    fn entry_is_recursive_dir(path: &Path) -> bool {
        std::fs::symlink_metadata(path).map(|m| m.file_type().is_dir()).unwrap_or(false)
    }

    fn list_entries(base_fs: &Path, component: &str) -> Vec<(String, PathBuf)> {
        let mut entries: Vec<(String, PathBuf)> = match std::fs::read_dir(base_fs) {
            Ok(iter) => iter
                .flatten()
                .map(|ent| (ent.file_name().to_string_lossy().into_owned(), ent.path()))
                .collect(),
            Err(_) => return Vec::new(),
        };

        if pattern_component_starts_with_dot(component) && !current_globskipdots() {
            entries.push((".".to_string(), base_fs.to_path_buf()));
            entries.push(("..".to_string(), parent_dir(base_fs)));
        }

        entries.sort_by(|a, b| a.0.cmp(&b.0));
        entries
    }

    fn should_skip_entry(name: &str, component: &str) -> bool {
        if current_globskipdots() && (name == "." || name == "..") {
            return true;
        }
        if name.starts_with('.')
            && name != "."
            && name != ".."
            && !pattern_component_starts_with_dot(component)
            && !current_dotglob()
        {
            return true;
        }
        false
    }

    fn walk_globstar_terminal(base_fs: &Path, base_display: &str, require_dir_suffix: bool, out: &mut Vec<String>) {
        for (name, path) in list_entries(base_fs, "**") {
            if should_skip_entry(&name, "**") {
                continue;
            }
            let is_dir_match = entry_is_matchable_dir(&path);
            if require_dir_suffix && !is_dir_match {
                continue;
            }
            let next_display = join_display_path(base_display, &name);
            if require_dir_suffix {
                out.push(dir_display(&next_display));
            } else {
                out.push(next_display.clone());
            }
            if entry_is_recursive_dir(&path) {
                walk_globstar_terminal(&path, &next_display, require_dir_suffix, out);
            }
        }
    }

    fn recurse(
        base_fs: &Path,
        base_display: &str,
        components: &[String],
        idx: usize,
        require_dir_suffix: bool,
        total_globstars: usize,
        out: &mut Vec<String>,
    ) {
        if idx >= components.len() {
            if !base_display.is_empty() {
                if !require_dir_suffix || base_fs.is_dir() {
                    out.push(base_display.to_string());
                }
            }
            return;
        }

        let component = &components[idx];
        if component.is_empty() {
            recurse(base_fs, base_display, components, idx + 1, require_dir_suffix, total_globstars, out);
            return;
        }

        let last = idx + 1 == components.len();
        if is_globstar_component(component) {
            if last {
                if !base_display.is_empty() {
                    let zero = globstar_zero_display(base_display, total_globstars);
                    if !zero.is_empty() {
                        out.push(zero);
                    }
                }
                walk_globstar_terminal(base_fs, base_display, require_dir_suffix, out);
                return;
            }

            recurse(base_fs, base_display, components, idx + 1, require_dir_suffix, total_globstars, out);
            for (name, path) in list_entries(base_fs, component) {
                if should_skip_entry(&name, component) {
                    continue;
                }
                if !entry_is_matchable_dir(&path) {
                    continue;
                }
                if !entry_is_recursive_dir(&path) {
                    continue;
                }
                let next_display = join_display_path(base_display, &name);
                recurse(&path, &next_display, components, idx, require_dir_suffix, total_globstars, out);
            }
            return;
        }

        if component_has_glob_meta(component) && component_has_quoted_slash(component) {
            return;
        }
        if !component_has_glob_meta(component) {
            let literal = unescape_glob_component(component);
            let next_fs = match literal.as_str() {
                "." => base_fs.to_path_buf(),
                ".." => parent_dir(base_fs),
                _ => base_fs.join(&literal),
            };
            if !next_fs.exists() {
                return;
            }
            if (!last || require_dir_suffix) && !next_fs.is_dir() {
                return;
            }
            if next_fs.is_dir()
                && ((!last || require_dir_suffix) || matches!(literal.as_str(), "." | ".."))
                && std::fs::metadata(next_fs.join(".")).is_err()
            {
                return;
            }
            let next_display = join_display_path(base_display, &literal);
            recurse(&next_fs, &next_display, components, idx + 1, require_dir_suffix, total_globstars, out);
            return;
        }

        for (name, path) in list_entries(base_fs, component) {
            if should_skip_entry(&name, component) {
                continue;
            }
            if !glob_match_component(component, &name) {
                continue;
            }
            if (!last || require_dir_suffix) && !entry_is_matchable_dir(&path) {
                continue;
            }
            if entry_is_matchable_dir(&path)
                && (!last || require_dir_suffix)
                && std::fs::metadata(path.join(".")).is_err()
            {
                continue;
            }
            let next_display = join_display_path(base_display, &name);
            if last {
                out.push(next_display);
            } else {
                if !entry_is_recursive_dir(&path) {
                    continue;
                }
                recurse(&path, &next_display, components, idx + 1, require_dir_suffix, total_globstars, out);
            }
        }
    }

    let require_dir_suffix = pattern.ends_with('/') && pattern != "/";
    let trimmed = if require_dir_suffix {
        pattern.trim_end_matches('/')
    } else {
        pattern
    };
    let raw_components = split_path_pattern(trimmed);
    let total_globstars = raw_components.iter().filter(|c| is_globstar_component(c)).count();
    let components = compress_adjacent_globstars(raw_components);
    let base_fs = if trimmed.starts_with('/') {
        std::path::PathBuf::from("/")
    } else {
        std::path::PathBuf::from(".")
    };
    let base_display = if trimmed.starts_with('/') { "/" } else { "" };
    let mut results = Vec::new();
    recurse(&base_fs, base_display, &components, 0, require_dir_suffix, total_globstars, &mut results);
    results
}

fn needs_recursive_pathname_expand(field: &str, normalized: &str) -> bool {
    if current_globstar() {
        let require_dir_suffix = normalized.ends_with('/') && normalized != "/";
        let trimmed = if require_dir_suffix {
            normalized.trim_end_matches('/')
        } else {
            normalized
        };
        if split_path_pattern(trimmed).into_iter().any(|component| is_globstar_component(&component)) {
            return true;
        }
    }
    if current_nocaseglob() {
        return true;
    }
    if field.contains('\\') || field.contains(CTLESC) {
        return true;
    }
    let require_dir_suffix = normalized.ends_with('/') && normalized != "/";
    let trimmed = if require_dir_suffix {
        normalized.trim_end_matches('/')
    } else {
        normalized
    };
    split_path_pattern(trimmed)
        .into_iter()
        .any(|component| !component_has_glob_meta(&component) && matches!(unescape_glob_component(&component).as_str(), "." | ".."))
}

pub fn pathname_expand(field: &str) -> Vec<String> {
    let normalized = normalize_pathname_pattern(field);
    let require_dir_suffix = normalized.ends_with('/') && normalized != "/";
    let trimmed = if require_dir_suffix {
        normalized.trim_end_matches('/')
    } else {
        normalized.as_str()
    };
    let components = split_path_pattern(trimmed);
    let has_globstar = current_globstar() && components.iter().any(|component| is_globstar_component(component));
    let has_component_meta = components
        .iter()
        .any(|component| component_has_glob_meta(component));
    let has_extglob = has_extglob_meta(&normalized);
    if !has_component_meta && !has_extglob {
        // No active glob metachars — strip CTLESC and return literal.
        return vec![field.replace(CTLESC, "")];
    }

    if needs_recursive_pathname_expand(field, &normalized) {
        let results = pathname_expand_recursive(&normalized);
        if results.is_empty() {
            return pathname_expand_no_match(field);
        }
        let finalized = if has_globstar {
            let mut results = apply_globignore(results);
            if require_dir_suffix {
                for path in &mut results {
                    if !path.ends_with('/') {
                        path.push('/');
                    }
                }
            }
            results.sort();
            results
        } else {
            finalize_glob_results(results, require_dir_suffix)
        };
        if finalized.is_empty() {
            return pathname_expand_no_match(field);
        }
        return finalized;
    }

    // Extglob: the `glob` crate doesn't understand ?(…)/*(…)/+(…)/
    // @(…)/!(…).  When the pattern contains any such prefix, fall
    // back to our own directory scanner + glob_match_rec (from
    // builtins.rs) that handles them.  Also fall back when the
    // pattern uses `[^...]` negation — the `glob` crate only honours
    // `[!...]`.
    if has_extglob || has_caret_bracket(&normalized) || has_posix_class(&normalized) {
        let results = extglob_pathname_expand(&normalized);
        if results.is_empty() {
            return pathname_expand_no_match(field);
        }
        let finalized = finalize_glob_results(results, require_dir_suffix);
        if finalized.is_empty() {
            return pathname_expand_no_match(field);
        }
        return finalized;
    }

    // Use the `glob` crate for actual filesystem globbing.
    // The crate normalises `./foo/bar/*` to `foo/bar/match` — strip
    // the leading `./` from results and we re-prefix below so bash's
    // convention is preserved.
    let leading_dot_slash = normalized.starts_with("./");
    match glob::glob(&normalized) {
        Ok(paths) => {
            let results: Vec<String> = paths
                .filter_map(|p| p.ok())
                .map(|p| {
                    let s = p.to_string_lossy().into_owned();
                    if leading_dot_slash && !s.starts_with("./") {
                        format!("./{}", s)
                    } else {
                        s
                    }
                })
                // `globskipdots` (bash 5.2+, on by default): when
                // enabled, the `.` and `..` directory entries are
                // skipped even for patterns like `.*`.  When the
                // shopt is unset (via `shopt -u globskipdots`),
                // include them — but as the plain names `.` / `..`
                // (matching bash), not the `./.` / `./..` paths the
                // `glob` crate produces.  Match on the trailing
                // basename since `Path::file_name` returns None for
                // paths ending in `.` / `..`.
                .filter(|p| {
                    if !current_globskipdots() { return true; }
                    let last = p.rsplit('/').next().unwrap_or(p.as_str());
                    last != "." && last != ".."
                })
                .map(|p| match p.as_str() {
                    "./." => ".".to_string(),
                    "./.." => "..".to_string(),
                    _ => p,
                })
                .filter(|p| {
                    // In bash, dotfiles are not matched by * unless the
                    // pattern starts with `.` or the `dotglob` shopt is on.
                    let last = std::path::Path::new(p).file_name()
                        .and_then(|n| n.to_str())
                        .unwrap_or("");
                    if !last.starts_with('.') { return true; }
                    if normalized.split('/').last().map(|s| s.starts_with('.')).unwrap_or(false) {
                        return true;
                    }
                    current_dotglob()
                })
                .collect();
            if results.is_empty() {
                pathname_expand_no_match(field)
            } else {
                let finalized = finalize_glob_results(results, require_dir_suffix);
                if finalized.is_empty() {
                    pathname_expand_no_match(field)
                } else {
                    finalized
                }
            }
        }
        Err(_) => vec![field.to_string()],
    }
}

// ─────────────────────────────────────────────────────────────────────────────
/// Strip shell quoting from a string: remove single-quote pairs, double-quote
/// pairs, and interpret backslash escapes outside of quotes.
pub fn remove_quotes(s: &str) -> String {
    let mut out = String::with_capacity(s.len());
    let chars: Vec<char> = s.chars().collect();
    let mut i = 0;
    while i < chars.len() {
        match chars[i] {
            '\'' => {
                // Skip opening quote, copy until closing quote
                i += 1;
                while i < chars.len() && chars[i] != '\'' {
                    out.push(chars[i]);
                    i += 1;
                }
                if i < chars.len() { i += 1; } // skip closing quote
            }
            '"' => {
                // Skip opening quote, copy until closing quote (handle backslash)
                i += 1;
                while i < chars.len() && chars[i] != '"' {
                    if chars[i] == '\\' && i + 1 < chars.len() {
                        i += 1;
                        out.push(chars[i]);
                    } else {
                        out.push(chars[i]);
                    }
                    i += 1;
                }
                if i < chars.len() { i += 1; } // skip closing quote
            }
            '\\' if i + 1 < chars.len() => {
                i += 1;
                out.push(chars[i]);
                i += 1;
            }
            c => {
                out.push(c);
                i += 1;
            }
        }
    }
    out
}

// Unit tests
// ─────────────────────────────────────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;

    /// Helper to create a Variables instance for testing.
    fn test_vars() -> Variables {
        Variables::new()
    }

    /// Helper to create a Variables with some values set.
    fn test_vars_with(pairs: &[(&str, &str)]) -> Variables {
        let mut v = Variables::new();
        for (k, val) in pairs {
            v.set(k, val);
        }
        v
    }

    #[test]
    fn test_brace_expand_comma() {
        let r = brace_expand("a{b,c,d}e");
        assert_eq!(r, vec!["abe", "ace", "ade"]);
    }

    #[test]
    fn test_brace_expand_numeric_seq() {
        let r = brace_expand("{1..5}");
        assert_eq!(r, vec!["1", "2", "3", "4", "5"]);
    }

    #[test]
    fn test_brace_expand_zero_padded() {
        let r = brace_expand("{01..05}");
        assert_eq!(r, vec!["01", "02", "03", "04", "05"]);
    }

    #[test]
    fn test_brace_expand_char_seq() {
        let r = brace_expand("{a..e}");
        assert_eq!(r, vec!["a", "b", "c", "d", "e"]);
    }

    #[test]
    fn test_brace_expand_decrement() {
        let r = brace_expand("{5..1}");
        assert_eq!(r, vec!["5", "4", "3", "2", "1"]);
    }

    #[test]
    fn test_brace_expand_increment() {
        let r = brace_expand("{0..10..3}");
        assert_eq!(r, vec!["0", "3", "6", "9"]);
    }

    #[test]
    fn test_brace_no_expand_empty() {
        // {} is not a valid brace expression
        let r = brace_expand("{}");
        assert_eq!(r, vec!["{}"]);
    }

    #[test]
    fn test_single_quote_no_expand() {
        let mut v = test_vars();
        v.set("FOO", "bar");
        let r = expand_word_nosplit("'$FOO'", &mut v);
        assert_eq!(r, "$FOO");
    }

    #[test]
    fn test_double_quote_expand() {
        let mut v = test_vars();
        v.set("FOO", "world");
        let r = expand_word_nosplit("\"hello $FOO\"", &mut v);
        assert_eq!(r, "hello world");
    }

    #[test]
    fn test_plain_var() {
        let mut v = test_vars();
        v.set("X", "42");
        let r = expand_word_nosplit("$X", &mut v);
        assert_eq!(r, "42");
    }

    #[test]
    fn test_param_default() {
        let mut v = test_vars();
        let r = expand_word_nosplit("${UNDEF:-hello}", &mut v);
        assert_eq!(r, "hello");
    }

    #[test]
    fn test_param_default_set() {
        let mut v = test_vars();
        v.set("X", "val");
        let r = expand_word_nosplit("${X:-hello}", &mut v);
        assert_eq!(r, "val");
    }

    #[test]
    fn test_parse_param_name_quoted_assoc_subscript_with_equals() {
        let chars: Vec<char> = "myarray[\"a]=test1;#a\"]".chars().collect();
        let (name, op_start) = parse_param_name(&chars);
        assert_eq!(name, "myarray[\"a]=test1;#a\"]");
        assert_eq!(op_start, chars.len());
    }

    #[test]
    fn test_assoc_lookup_with_equals_in_quoted_subscript_has_no_side_effect() {
        let mut v = test_vars();
        v.declare_assoc("myarray");
        v.set_assoc("myarray", "a]=test1;#a", "123");
        let r = expand_word_nosplit("${myarray[\"a]=test1;#a\"]}", &mut v);
        assert_eq!(r, "123");
        assert_eq!(v.get_assoc_entries("myarray"), vec![("a]=test1;#a".to_string(), "123".to_string())]);
    }

    #[test]
    fn test_param_alt() {
        let mut v = test_vars();
        v.set("X", "something");
        let r = expand_word_nosplit("${X:+alt}", &mut v);
        assert_eq!(r, "alt");
    }

    #[test]
    fn test_param_length() {
        let mut v = test_vars();
        v.set("X", "hello");
        let r = expand_word_nosplit("${#X}", &mut v);
        assert_eq!(r, "5");
    }

    #[test]
    fn test_param_prefix_remove_shortest() {
        let mut v = test_vars();
        v.set("X", "hello_world");
        let r = expand_word_nosplit("${X#*_}", &mut v);
        assert_eq!(r, "world");
    }

    #[test]
    fn test_param_prefix_remove_longest() {
        let mut v = test_vars();
        v.set("X", "a_b_c");
        let r = expand_word_nosplit("${X##*_}", &mut v);
        assert_eq!(r, "c");
    }

    #[test]
    fn test_param_suffix_remove() {
        let mut v = test_vars();
        v.set("X", "file.tar.gz");
        let r = expand_word_nosplit("${X%.gz}", &mut v);
        assert_eq!(r, "file.tar");
    }

    #[test]
    fn test_param_suffix_remove_greedy() {
        let mut v = test_vars();
        v.set("X", "file.tar.gz");
        let r = expand_word_nosplit("${X%%.*}", &mut v);
        assert_eq!(r, "file");
    }

    #[test]
    fn test_param_substitution() {
        let mut v = test_vars();
        v.set("X", "hello world");
        let r = expand_word_nosplit("${X/world/there}", &mut v);
        assert_eq!(r, "hello there");
    }

    #[test]
    fn test_param_substitution_all() {
        let mut v = test_vars();
        v.set("X", "aabbaa");
        let r = expand_word_nosplit("${X//a/x}", &mut v);
        assert_eq!(r, "xxbbxx");
    }

    #[test]
    fn test_param_substring() {
        let mut v = test_vars();
        v.set("X", "hello");
        let r = expand_word_nosplit("${X:1:3}", &mut v);
        assert_eq!(r, "ell");
    }

    #[test]
    fn test_param_substring_negative_offset() {
        let mut v = test_vars();
        v.set("X", "hello");
        let r = expand_word_nosplit("${X: -2}", &mut v);
        assert_eq!(r, "lo");
    }

    #[test]
    fn test_uppercase() {
        let mut v = test_vars();
        v.set("X", "hello");
        let r = expand_word_nosplit("${X^^}", &mut v);
        assert_eq!(r, "HELLO");
    }

    #[test]
    fn test_lowercase() {
        let mut v = test_vars();
        v.set("X", "HELLO");
        let r = expand_word_nosplit("${X,,}", &mut v);
        assert_eq!(r, "hello");
    }

    #[test]
    fn test_tilde_home() {
        let mut v = test_vars();
        v.set("HOME", "/home/user");
        v.refresh_home_cache();
        let r = expand_tilde("~/foo", &v);
        assert_eq!(r, "/home/user/foo");
    }

    #[test]
    fn test_tilde_plus() {
        let mut v = test_vars();
        v.set("PWD", "/current/dir");
        let r = expand_tilde("~+/foo", &v);
        assert_eq!(r, "/current/dir/foo");
    }

    #[test]
    fn test_word_split_basic() {
        let fields = word_split("a b c", " \t\n");
        assert_eq!(fields, vec!["a", "b", "c"]);
    }

    #[test]
    fn test_word_split_custom_ifs() {
        let fields = word_split("a:b:c", ":");
        assert_eq!(fields, vec!["a", "b", "c"]);
    }

    #[test]
    fn test_word_split_leading_trailing_ifs() {
        let fields = word_split("  a  b  ", " \t\n");
        assert_eq!(fields, vec!["a", "b"]);
    }

    #[test]
    fn test_ansi_escape_newline() {
        let mut v = test_vars();
        let r = expand_word_nosplit("$'hello\\nworld'", &mut v);
        assert_eq!(r, "hello\nworld");
    }

    #[test]
    fn test_ansi_escape_hex() {
        let mut v = test_vars();
        let r = expand_word_nosplit("$'\\x41'", &mut v);
        assert_eq!(r, "A");
    }

    #[test]
    fn test_ansi_escape_octal() {
        let mut v = test_vars();
        let r = expand_word_nosplit("$'\\101'", &mut v);
        assert_eq!(r, "A");
    }

    #[test]
    fn test_param_prefix_removal_with_locale_dquote_pattern() {
        let mut v = test_vars();
        v.set("x", "no\tOK");
        let r = expand_word_nosplit("${x#$\"no\t\"}", &mut v);
        assert_eq!(r, "OK");
    }

    #[test]
    fn test_backslash_escape_unquoted() {
        let mut v = test_vars();
        let r = expand_word_nosplit("a\\ b", &mut v);
        assert_eq!(r, "a b");
    }

    #[test]
    fn test_glob_matches_star() {
        assert!(glob_matches("*.rs", "foo.rs"));
        assert!(!glob_matches("*.rs", "foo.txt"));
    }

    #[test]
    fn test_glob_matches_question() {
        assert!(glob_matches("f?o", "foo"));
        assert!(!glob_matches("f?o", "fo"));
    }

    #[test]
    fn test_glob_matches_bracket() {
        assert!(glob_matches("[abc]", "b"));
        assert!(!glob_matches("[abc]", "d"));
    }

    #[test]
    fn test_glob_matches_bracket_range() {
        assert!(glob_matches("[a-z]", "m"));
        assert!(!glob_matches("[a-z]", "M"));
    }

    #[test]
    fn test_glob_remove_prefix_shortest() {
        assert_eq!(glob_remove_prefix("a/b/c", "*/", false), "b/c");
    }

    #[test]
    fn test_glob_remove_prefix_longest() {
        assert_eq!(glob_remove_prefix("a/b/c", "*/", true), "c");
    }

    #[test]
    fn test_brace_nested() {
        let r = brace_expand("{a,{b,c}}");
        assert_eq!(r, vec!["a", "b", "c"]);
    }
}
