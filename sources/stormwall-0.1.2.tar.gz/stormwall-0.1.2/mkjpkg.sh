#!/bin/sh
# mkjpkg.sh - Build a .jpkg package for stormwall
# Usage: ./mkjpkg.sh [arch]
#
# Expects the Rust binary to already be built:
#   cargo build --release
#
# Installs into /private/.jonerix/stormwall/ on jonerix systems.
set -e

ARCH="${1:-$(uname -m)}"
VERSION="0.1.0"
NAME="stormwall"
PREFIX="/private/.jonerix/stormwall"

# Find the built binary matching the target arch
BIN=""
case "$ARCH" in
    aarch64) BIN="target/aarch64-unknown-linux-musl/release/stormwall" ;;
    x86_64)  BIN="target/x86_64-unknown-linux-musl/release/stormwall" ;;
esac
[ -f "$BIN" ] || BIN="target/release/stormwall"
if [ ! -f "$BIN" ]; then
    echo "Error: binary not found. Run 'cargo build --release' first." >&2
    exit 1
fi

DESTDIR="$(mktemp -d)"
trap "rm -rf $DESTDIR" EXIT

# Install files into staging directory
install -Dm755 "$BIN" "$DESTDIR$PREFIX/bin/stormwall"
ln -sf stormwall "$DESTDIR$PREFIX/bin/nft"
install -Dm644 recipe.toml "$DESTDIR$PREFIX/share/doc/stormwall/recipe.toml"

# Strip if possible
llvm-strip --strip-all "$DESTDIR$PREFIX/bin/stormwall" 2>/dev/null || \
  strip "$DESTDIR$PREFIX/bin/stormwall" 2>/dev/null || true

# Create zstd-compressed tar payload
TARBALL="$(mktemp).zst"
(cd "$DESTDIR" && tar cf - .) | zstd -1 -f -o "$TARBALL"
PAYLOAD_SIZE=$(wc -c < "$TARBALL")
PAYLOAD_SHA=$(sha256sum "$TARBALL" | cut -d' ' -f1)

HEADER="
[package]
name = \"$NAME\"
version = \"$VERSION\"
license = \"MIT\"
description = \"Drop-in replacement for the nft CLI -- pure Rust, no C dependencies\"
arch = \"$ARCH\"

[depends]
runtime = [\"musl\"]

[files]
sha256 = \"$PAYLOAD_SHA\"
size = $PAYLOAD_SIZE
"

OUTPUT="$NAME-$VERSION-$ARCH.jpkg"

# Write JPKG format: magic(8) + header_len(4LE) + header(TOML) + zstd_payload
python3 -c "
import struct, sys
magic = b'JPKG\x00\x01\x00\x00'
hdr = '''$HEADER'''.encode()
hdr_len = struct.pack('<I', len(hdr))
sys.stdout.buffer.write(magic + hdr_len + hdr)
" > "$OUTPUT"

cat "$TARBALL" >> "$OUTPUT"
rm -f "$TARBALL"

echo "Built: $OUTPUT ($(wc -c < "$OUTPUT") bytes)"
echo "  installs to: $PREFIX"
echo "  sha256: $(sha256sum "$OUTPUT" | cut -d' ' -f1)"
