# stormwall Capability Matrix

**Date**: 2026-04-25  
**Version**: 0.1.0  
**Scope**: drop-in `nft` CLI replacement written in pure Rust, no libnftnl/libmnl.

This document is a honest summary of what stormwall can and cannot do.
It is updated as tests run. "traffic-tested" means real packets were sent
through kernel-installed rules and observed to behave correctly.

---

## 1. Coverage Matrix

Columns:
- **parse** -- parser accepts the syntax without error
- **encode** -- correct netlink bytes sent to the kernel
- **list** -- `list ruleset` reproduces the rule in nft text form
- **JSON list** -- `-j list ruleset` reproduces it correctly
- **traffic** -- real traffic test passes (accept/drop/NAT observed)

Symbols: Y = yes / N = no / P = partial / - = not applicable

### 1.1 Table families

| Feature          | parse | encode | list | JSON list | traffic |
|------------------|:-----:|:------:|:----:|:---------:|:-------:|
| table ip         |  Y    |   Y    |  Y   |    P      |    Y    |
| table ip6        |  Y    |   Y    |  Y   |    P      |    Y    |
| table inet       |  Y    |   Y    |  Y   |    P      |    Y    |
| table arp        |  Y    |   Y    |  Y   |    -      |    -    |
| table bridge     |  Y    |   Y    |  Y   |    -      |    P    |
| table netdev     |  Y    |   Y    |  P   |    -      |    -    |

Notes:
- bridge: 9/12 traffic cases pass; the 3 failures are not stormwall bugs
  (harness environment issue, see tests/traffic-parity-bridge.sh).
- netdev: ingress/egress hook types parse but the list formatter does not
  yet emit the `devices = { ... }` device-list clause correctly.

### 1.2 Chains

| Feature                        | parse | encode | list | JSON list | traffic |
|--------------------------------|:-----:|:------:|:----:|:---------:|:-------:|
| filter hook (input/fwd/output) |  Y    |   Y    |  Y   |    P      |    Y    |
| nat hook (prerouting/postrouting)|Y    |   Y    |  Y   |    P      |    Y    |
| route hook                     |  Y    |   Y    |  Y   |    -      |    -    |
| ingress hook (netdev)          |  Y    |   Y    |  N   |    N      |    -    |
| egress hook (netdev)           |  Y    |   Y    |  N   |    N      |    -    |
| default policy (accept/drop)   |  Y    |   Y    |  Y   |    P      |    -    |
| regular chain (no hook)        |  Y    |   Y    |  Y   |    P      |    Y    |
| chain priority (named + int)   |  Y    |   Y    |  P   |    -      |    -    |

Notes:
- ingress/egress list: device clause missing in formatter (listed in known gaps).
- chain priority: numeric form listed correctly; named constants (filter, mangle,
  srcnat, etc.) may render as integers rather than names on some kernel versions.

### 1.3 Rule expressions

| Expression                     | parse | encode | list | JSON list | traffic |
|--------------------------------|:-----:|:------:|:----:|:---------:|:-------:|
| cmp (==, !=, <, >, <=, >=)     |  Y    |   Y    |  Y   |    P      |    Y    |
| payload: ip saddr/daddr        |  Y    |   Y    |  Y   |    P      |    Y    |
| payload: ip6 saddr/daddr       |  Y    |   Y    |  Y   |    P      |    Y    |
| payload: tcp sport/dport       |  Y    |   Y    |  Y   |    P      |    Y    |
| payload: udp sport/dport       |  Y    |   Y    |  Y   |    P      |    Y    |
| payload: icmp type/code        |  Y    |   Y    |  Y   |    P      |    Y    |
| payload: icmpv6 type/code      |  Y    |   Y    |  Y   |    P      |    Y    |
| payload: ether saddr/daddr     |  Y    |   Y    |  Y   |    -      |    -    |
| payload: ether type            |  Y    |   Y    |  Y   |    -      |    -    |
| payload: th sport/dport        |  Y    |   Y    |  Y   |    -      |    -    |
| payload: ip dscp               |  Y    |   Y    |  Y   |    -      |    -    |
| meta iifname/oifname           |  Y    |   Y    |  Y   |    P      |    Y    |
| meta mark                      |  Y    |   Y    |  Y   |    P      |    Y    |
| meta l4proto                   |  Y    |   Y    |  Y   |    -      |    -    |
| meta skuid/skgid               |  Y    |   Y    |  Y   |    -      |    -    |
| meta length                    |  Y    |   Y    |  Y   |    -      |    -    |
| ct state                       |  Y    |   Y    |  Y   |    P      |    Y    |
| ct mark/status/zone            |  Y    |   Y    |  Y   |    -      |    -    |
| bitwise (mask/xor)             |  Y    |   Y    |  Y   |    P      |    -    |
| lookup (set/map reference)     |  Y    |   Y    |  Y   |    P      |    Y    |
| tcp flags (exact match)        |  Y    |   Y    |  Y   |    -      |    Y    |
| tcp flags (masked &)           |  N    |   N    |  -   |    -      |    -    |
| fib expression                 |  N    |   N    |  -   |    -      |    -    |
| hash / numgen                  |  N    |   N    |  -   |    -      |    -    |

### 1.4 Sets

| Feature                             | parse | encode | list | JSON list | traffic |
|-------------------------------------|:-----:|:------:|:----:|:---------:|:-------:|
| anonymous set (inline { })          |  Y    |   Y    |  Y   |    P      |    Y    |
| named set (add set)                 |  Y    |   Y    |  Y   |    P      |    Y    |
| interval set (flags interval)       |  Y    |   Y    |  Y   |    P      |    Y    |
| type ipv4_addr                      |  Y    |   Y    |  Y   |    P      |    Y    |
| type ipv6_addr                      |  Y    |   Y    |  Y   |    P      |    Y    |
| type inet_service                   |  Y    |   Y    |  Y   |    P      |    Y    |
| type inet_proto                     |  Y    |   Y    |  Y   |    P      |    -    |
| type ether_addr                     |  Y    |   Y    |  Y   |    -      |    -    |
| type ifname                         |  Y    |   Y    |  Y   |    -      |    -    |
| concatenated keys (type a . b)      |  N    |   N    |  -   |    -      |    -    |
| set with timeout                    |  N    |   N    |  -   |    -      |    -    |
| flags dynamic (dynset)              |  N    |   N    |  -   |    -      |    -    |
| set with set_expr (stateful elems)  |  N    |   N    |  -   |    -      |    -    |

### 1.5 Maps

| Feature                   | parse | encode | list | JSON list | traffic |
|---------------------------|:-----:|:------:|:----:|:---------:|:-------:|
| verdict-valued map (vmap) |  Y    |   Y    |  Y   |    P      |    Y    |
| data-valued map           |  Y    |   Y    |  Y   |    P      |    -    |
| interval map              |  Y    |   Y    |  Y   |    -      |    -    |
| anonymous map (inline)    |  Y    |   Y    |  Y   |    P      |    -    |

### 1.6 Verdicts

| Verdict    | parse | encode | list | JSON list | traffic |
|------------|:-----:|:------:|:----:|:---------:|:-------:|
| accept     |  Y    |   Y    |  Y   |    Y      |    Y    |
| drop       |  Y    |   Y    |  Y   |    Y      |    Y    |
| return     |  Y    |   Y    |  Y   |    P      |    Y    |
| continue   |  Y    |   Y    |  Y   |    P      |    -    |
| jump       |  Y    |   Y    |  Y   |    P      |    Y    |
| goto       |  Y    |   Y    |  Y   |    P      |    Y    |

### 1.7 Statements

| Statement                      | parse | encode | list | JSON list | traffic |
|--------------------------------|:-----:|:------:|:----:|:---------:|:-------:|
| counter (inline)               |  Y    |   Y    |  Y   |    N      |    Y    |
| counter (named object)         |  N    |   N    |  -   |    -      |    -    |
| log prefix "..."               |  Y    |   Y    |  Y   |    P      |    -    |
| log group N                    |  Y    |   Y    |  Y   |    -      |    -    |
| limit rate N/unit [burst N]    |  Y    |   Y    |  Y   |    P      |    -    |
| masquerade                     |  Y    |   Y    |  Y   |    P      |    Y    |
| snat to addr                   |  Y    |   Y    |  Y   |    P      |    Y    |
| dnat to addr                   |  Y    |   Y    |  Y   |    P      |    Y    |
| notrack                        |  Y    |   Y    |  Y   |    -      |    -    |
| reject                         |  Y    |   Y    |  Y   |    -      |    -    |
| quota (named object)           |  N    |   N    |  -   |    -      |    -    |
| limit (named object)           |  N    |   N    |  -   |    -      |    -    |

### 1.8 Special / protocol features

| Feature                              | Status  | Notes                                       |
|--------------------------------------|---------|---------------------------------------------|
| NFT_TEST_MODE / version impersonation|  Y      | STORMWALL_TEST_MODE=1 passes byte-for-byte   |
| --check (-c) flag                    |  Y      | 35-case corpus, ~18+ pass                    |
| JSON output (-j list ruleset)        |  P      | 6/12 cases pass; counter obj format wrong    |
| Atomic transactions (batch)          |  Y      | send/recv inside single NFNL_BATCH_BEGIN/END |
| NLM_F_EXCL on create                 |  Y      | `create` returns EEXIST correctly            |
| -f file input                        |  Y      | working                                      |
| -a show handles                      |  Y      | working                                      |
| -s stateless output                  |  Y      | working                                      |
| -nn numeric names                    |  N      | names not suppressed (1/13 cases pass)       |
| -y/-p numeric prio/proto             |  N      | not suppressed (see numeric-output-parity)   |
| JSON input (-j -f)                   |  N      | JSON input parser not implemented            |
| define variables                     |  N      | preprocessor $foo substitution not done      |
| ct helper objects                    |  N      | not implemented                              |
| ct timeout objects                   |  N      | not implemented                              |
| ct expectation objects               |  N      | not implemented                              |
| flowtable                            |  N      | not implemented                              |
| reset rules / reset counters         |  N      | not implemented                              |
| upstream nft shell suite             |  P      | ~31% pass rate on sampled categories         |

---

## 2. Test Inventory

All harnesses live under `tests/`. "PASS rate" reflects the latest known
run unless noted as TBD. Harnesses that require root, live network interfaces,
or specific tools are noted.

| Harness                            | What it covers                                                        | Latest PASS rate          |
|------------------------------------|-----------------------------------------------------------------------|---------------------------|
| tests/stormwall_test.sh            | ~25 core compatibility cases: -f, JSON -j, round-trip, ct, meta, NAT | 25/25 (TESTS.md: 24/24)   |
| tests/monitor-diff.sh              | 30 cases: NAT, log, tcp-flags, dscp, jump/goto, meta-skuid, replace   | 29/30                     |
| tests/traffic-parity.sh            | 16 ruleset shapes, real veth pair, accept/drop per rule               | 16/16                     |
| tests/traffic-parity-ipv6.sh       | 18 IPv6 cases, real packets                                           | 18/18                     |
| tests/traffic-parity-bridge.sh     | 12 bridge/L2 cases, 3-netns setup                                     | 9/12 (3 fails: env, not stormwall) |
| tests/traffic-nat.sh               | 4 NAT cases: masquerade, snat, dnat, negative                         | 4/4                       |
| tests/firewalld-smoke.sh           | 10 checks: firewalld/iptables-translate/fail2ban/ufw consumer compat  | 9/9 (1 SKIP)              |
| tests/consumer-matrix.sh           | ~9 tools: ufw, fail2ban, nerdctl, kubectl, conntrack, etc.            | mostly SKIP (tools absent)|
| tests/nft-check-parity.sh          | 35 cases incl. negative/expand (-c flag parity)                       | ~18+ pass                 |
| tests/json-parity.sh               | 12-case corpus for -j list ruleset JSON shape                         | 6/12                      |
| tests/fuzz-parity.sh               | 50 random rulesets apply+list compare vs nft at default seed          | 50/50                     |
| tests/iperf3-throughput.sh         | 6 scenarios: baseline, chain_10/100/1000, stateful, nat               | 6/6 (throughput 0.81-1.03x) |
| tests/perf-bench.sh                | 6 op classes: single-op, batch, list at 3 scales                      | 6/6 (timing — see sec. 4)|
| tests/list-perf-profile.sh         | 3 scales; confirms flat 5x ratio                                      | 3/3 (diagnostic)          |
| tests/ct-soak.sh                   | 5-min conntrack soak: throughput and drop-rate under conntrack load    | 4/5 (stateful 52% slower) |
| tests/concurrent-writers.sh        | 8-worker kernel contention: EBUSY/EAGAIN handling                     | 4/4                       |
| tests/iptables-translate-parity.sh | 10 common iptables rule shapes via iptables-translate wrapper          | 10/10                     |
| tests/concat-keys-parity.sh        | 10-case concat-key corpus; expected fail until concat lands            | 0/10 (known gap)          |
| tests/tunnel-rulesets.sh           | 8 VPN/tunnel ruleset shapes (WireGuard, GRE, VXLAN, etc.)             | TBD -- not yet executed   |
| tests/numeric-output-parity.sh     | 13 cases: -nn/-y/-p name suppression parity                           | 1/13                      |
| tests/upstream-nft-suite.sh        | Full upstream nftables shell suite battery runner                      | ~31% (sampled categories) |
| tests/churn-loop.sh                | 24h add/list/flush loop: stability under continuous churn              | ongoing (no failures logged) |
| tests/container-net-smoke.sh       | Container runtime bridge/NAT (nerdctl/podman transparent)             | TBD -- not yet executed   |
| tests/vm-init.sh                   | VM init helper (setup, not a test harness)                            | N/A                       |

---

## 3. Known Gaps

The following features are confirmed missing or broken. Each has at least one
failing test case or an explicit TODO entry.

- **Masked tcp flags (`tcp flags & syn == syn`)**: the `&` mask syntax is not
  parsed. Plain flag-set matching works; masked matching does not.

- **Concatenated keys** (`type ipv4_addr . inet_service`): no parser or
  netlink encoding. The concat-keys-parity harness exists to hold the corpus
  until this lands; all 10 cases fail.

- **ct helper / ct timeout / ct expectation objects**: stateful helper objects
  are not parsed or encoded. Rulesets that reference `ct helper set "ftp"` or
  define timeout policies will fail to load.

- **dynset** (`add @set { ip saddr }` -- dynamic set population from rules):
  `flags dynamic` is not wired. Rules using `update @set { ... }` are not
  supported.

- **Flowtable**: `add flowtable ... { ... }` is not implemented. Rules that
  offload to a flowtable via `flow add @ft` will fail.

- **Numeric output flags** (`-nn`, `-y`, `-p`): these flags are accepted but
  have no effect. Protocol names, interface names, and priority constants are
  always printed symbolically. Only 1/13 numeric-output-parity cases pass.

- **JSON renderer -- three known shape mismatches**:
  - Counter statement object format differs from upstream (extra wrapper key).
  - Map data-value pair shape: value key name differs.
  - inet ingress device chain: `devs` field missing from JSON chain object.

- **Stateful throughput regression**: ct-soak shows 52% throughput drop under
  iperf3 with `ct state` rules installed (stormwall rules path vs. nft rules
  path). Root cause under investigation; may be a counter-update path that
  serialises under contention.

- **List performance -- ~5x slower than nft**: `list ruleset` issues Netlink
  dump requests one at a time (stop-and-wait). With ~20 ms per round-trip on
  arfur, a 4-table ruleset requires ~30 sequential RTTs (~1560 ms) vs. nft's
  pipelined ~3 RTTs (~980 ms at that scale). The root cause is fully documented
  in tests/list-perf-investigation.md. Fix: pipeline the Netlink dump queue.

- **JSON input** (`-j -f file.json`): reading JSON-format rulesets is not
  implemented. Only JSON output is available. This blocks the upstream nft
  shell suite's per-test sanity loop.

- **`define` / variable substitution**: the declarative parser does not expand
  `$foo` references defined via `define foo = value`. Rulesets that use
  variables will fail to parse.

- **Named stateful objects** (`counter NAME`, `quota NAME`, `limit NAME`):
  only inline counters/limits work. Named objects with their own lifecycle
  are not parsed or encoded.

- **reset rules / reset counters**: `reset rule` and `reset counter` verbs
  are not implemented.

---

## 4. Performance Baseline

Measured on arfur (x86_64, kernel 6.x). "stormwall" = stormwall binary,
"nft" = system /usr/sbin/nft. Ratio = stormwall / nft (lower is better).

### 4.1 Operation latency (perf-bench.sh)

| Operation              | stormwall | nft    | Ratio | Note                            |
|------------------------|----------:|-------:|------:|---------------------------------|
| single op (add table)  |     80 ms |  88 ms |  0.9x | stormwall faster here           |
| 100-rule chain apply   |    254 ms |  94 ms |  2.7x | slow -- batch overhead          |
| list 200 sets          |    224 ms |  42 ms |  5.3x | slow -- sequential netlink RTTs |

### 4.2 Throughput under iperf3 (iperf3-throughput.sh)

| Scenario               | stormwall   | nft         | Ratio | Note                          |
|------------------------|------------:|------------:|------:|-------------------------------|
| baseline (no rules)    |   1960 Mbps |   1900 Mbps |  1.03x | equivalent                   |
| chain_100 (100 rules)  |   1073 Mbps |   1320 Mbps |  0.81x | data-path slower             |
| stateful ct state      |   ~940 Mbps |   ~1960 Mbps|  0.48x | 52% drop -- regression       |

### 4.3 List scalability (list-perf-profile.sh)

The list ratio is flat across scales (confirmed). The overhead is a fixed ~20 ms
per Netlink round-trip multiplied by the number of sequential dump calls, not an
O(N rules) cost. A pipelining fix would bring list latency in line with nft
regardless of ruleset size.

---

## 5. Drop-in Readiness

stormwall is ready to replace `nft` for single-user or small-team firewall
management tasks where the ruleset uses the common subset: ip/ip6/inet tables,
filter and nat hooks, standard payload matches (ip, tcp, udp, icmp, icmpv6),
meta and ct state checks, named and anonymous sets with ipv4/ipv6/inet_service
types, and NAT statements. The fuzz harness (50/50) and traffic harnesses
(16/16, 18/18, 4/4 NAT) give reasonable confidence that the implemented subset
is kernel-correct. Consumer wrappers including iptables-translate (10/10) and
firewalld (9/9) work transparently.

It is not yet ready for environments that rely on: flowtables, dynset, ct helper
objects, concatenated set keys, numeric output formatting (-nn/-y/-p), JSON
ruleset input, or variable-heavy rulesets. The 31% pass rate on the upstream nft
shell suite reflects these gaps. The list-performance regression (5x vs. nft)
and the stateful throughput regression (52%) are significant enough that
stormwall should not be dropped into a high-throughput or latency-sensitive
production path without those fixes in place. For read-heavy tooling (monitoring,
audit, config generators) the list latency may also be a practical obstacle on
rulesets with many tables or chains.
