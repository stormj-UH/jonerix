#!/bin/bash
# Traffic-parity-ipv6 harness: same shape as traffic-parity.sh but
# exercises the ip6 family.  A veth-connected netns pair (tp6_server /
# tp6_client) uses ULA addresses (fd99::1/64, fd99::2/64) so there are
# no link-local scoping problems with ncat or ping.
#
# Each test applies a ruleset to the server netns via both stormwall
# and nft, fires an IPv6 probe from the client, and asserts:
#   1. The verdict matches what the rule says it should be.
#   2. stormwall and nft agree on that verdict.
#
# 13 cases total.

set -u

SW=/tmp/stormwall
NFT=/usr/sbin/nft
NS_S=tp6_server
NS_C=tp6_client
VETH_S=tp6s0
VETH_C=tp6c0
IP_S=fd99::1
IP_C=fd99::2
PREFIX=fd99::/64

PASS=0
FAIL=0

# Pick whatever ping binary understands -6.
if command -v ping6 >/dev/null 2>&1; then
    PING6="ping6"
else
    PING6="ping -6"
fi

# ------------------------------------------------------------------ #
#  Topology management                                                 #
# ------------------------------------------------------------------ #

setup() {
    teardown 2>/dev/null

    sudo ip netns add "$NS_S"
    sudo ip netns add "$NS_C"
    sudo ip link add "$VETH_S" type veth peer name "$VETH_C"
    sudo ip link set "$VETH_S" netns "$NS_S"
    sudo ip link set "$VETH_C" netns "$NS_C"

    # Use nodad so the ULA address is immediately usable (no DAD delay).
    sudo ip -n "$NS_S" addr add "$IP_S/64" nodad dev "$VETH_S"
    sudo ip -n "$NS_C" addr add "$IP_C/64" nodad dev "$VETH_C"
    sudo ip -n "$NS_S" link set "$VETH_S" up
    sudo ip -n "$NS_C" link set "$VETH_C" up
    sudo ip -n "$NS_S" link set lo up
    sudo ip -n "$NS_C" link set lo up

    # Confirm baseline IPv6 reachability before running any test.
    if ! sudo ip netns exec "$NS_C" $PING6 -c1 -W2 "$IP_S" >/dev/null 2>&1; then
        echo "FATAL: IPv6 namespaces can't reach each other; bailing"
        exit 1
    fi

    # Pre-stand TCP listeners on the server side.  Without these, an
    # accepted SYN returns RST and ncat reports failure even when the
    # firewall correctly allowed the packet — every accept test would
    # report a false FAIL.
    LISTEN_PIDS=()
    for port in 22 80 2222 8080; do
        sudo ip netns exec "$NS_S" ncat -6 -lk -p "$port" >/dev/null 2>&1 &
        LISTEN_PIDS+=($!)
    done
    sleep 0.3
}

teardown() {
    if [ -n "${LISTEN_PIDS:-}" ]; then
        # shellcheck disable=SC2128
        sudo kill ${LISTEN_PIDS[@]} 2>/dev/null || true
    fi
    LISTEN_PIDS=()
    sudo ip netns del "$NS_S" 2>/dev/null || true
    sudo ip netns del "$NS_C" 2>/dev/null || true
    sudo ip link del "$VETH_S" 2>/dev/null || true
}

# ------------------------------------------------------------------ #
#  Rule application                                                    #
# ------------------------------------------------------------------ #

apply_rules() {
    local bin=$1 rules=$2
    sudo ip netns exec "$NS_S" "$bin" flush ruleset 2>/dev/null
    sudo ip netns exec "$NS_S" "$bin" -f "$rules"
}

# ------------------------------------------------------------------ #
#  Probe primitives (return 0 = accepted, 1 = dropped/denied)         #
# ------------------------------------------------------------------ #

probe_tcp6() {
    local port=$1
    sudo ip netns exec "$NS_C" timeout 2 ncat -6 -z -w1 "$IP_S" "$port" >/dev/null 2>&1
}

probe_udp6() {
    local port=$1
    sudo ip netns exec "$NS_S" timeout 2 ncat -6 -ul -w1 "$port" >/tmp/tp6_udp.out &
    local lpid=$!
    sleep 0.2
    printf 'ping' | sudo ip netns exec "$NS_C" timeout 1 ncat -6 -uw1 "$IP_S" "$port" \
        >/dev/null 2>&1 || true
    wait $lpid 2>/dev/null
    [ -s /tmp/tp6_udp.out ]
}

probe_icmp6() {
    sudo ip netns exec "$NS_C" $PING6 -c1 -W2 "$IP_S" >/dev/null 2>&1
}

# ------------------------------------------------------------------ #
#  Test runner                                                         #
# ------------------------------------------------------------------ #

# run_test label ruleset expected probe [args...]
# expected = "accept" | "drop"
run_test() {
    local label=$1 rules=$2 expected=$3
    shift 3
    local probe=$1; shift
    local nft_verdict sw_verdict expected_rc

    if [ "$expected" = "accept" ]; then expected_rc=0; else expected_rc=1; fi

    apply_rules "$NFT" "$rules"
    if "$probe" "$@"; then nft_verdict=0; else nft_verdict=1; fi

    apply_rules "$SW" "$rules"
    if "$probe" "$@"; then sw_verdict=0; else sw_verdict=1; fi

    local nft_word sw_word
    nft_word=$([ "$nft_verdict" = 0 ] && printf accept || printf drop)
    sw_word=$([ "$sw_verdict"  = 0 ] && printf accept || printf drop)

    if [ "$nft_verdict" = "$sw_verdict" ] && [ "$nft_verdict" = "$expected_rc" ]; then
        printf "  PASS: %-44s nft=%s sw=%s expected=%s\n" \
            "$label" "$nft_word" "$sw_word" "$expected"
        PASS=$((PASS+1))
    else
        printf "  FAIL: %-44s nft=%s sw=%s expected=%s\n" \
            "$label" "$nft_word" "$sw_word" "$expected"
        FAIL=$((FAIL+1))
    fi
}

# ------------------------------------------------------------------ #
#  Ruleset corpus generation                                           #
# ------------------------------------------------------------------ #

gen_rules() {
    local d=$1
    mkdir -p "$d"

    # 1. Empty ruleset — no input chain, everything gets through.
    cat > "$d/01_baseline.nft" <<'EOF'
add table ip6 filter
EOF

    # 2. Default-drop chain — every probe should fail.
    cat > "$d/02_default_drop.nft" <<'EOF'
add table ip6 filter
add chain ip6 filter input { type filter hook input priority 0; policy drop; }
EOF

    # 3. Allow tcp dport 22, drop other TCP.
    cat > "$d/03_allow_ssh.nft" <<'EOF'
add table ip6 filter
add chain ip6 filter input { type filter hook input priority 0; policy drop; }
add rule ip6 filter input tcp dport 22 accept
EOF

    # 4. Allow packets from the client's ULA address, drop all others.
    cat > "$d/04_saddr_allow.nft" <<EOF
add table ip6 filter
add chain ip6 filter input { type filter hook input priority 0; policy drop; }
add rule ip6 filter input ip6 saddr $IP_C accept
EOF

    # 5. Drop packets from the client's ULA address (negative / mirror of 4).
    cat > "$d/05_saddr_drop.nft" <<EOF
add table ip6 filter
add chain ip6 filter input { type filter hook input priority 0; policy drop; }
add rule ip6 filter input ip6 saddr $IP_C drop
EOF

    # 6. Anonymous set: tcp dport { 22, 80 } accept.
    cat > "$d/06_anon_set.nft" <<'EOF'
add table ip6 filter
add chain ip6 filter input { type filter hook input priority 0; policy drop; }
add rule ip6 filter input tcp dport { 22, 80 } accept
EOF

    # 7. Interval set: ip6 saddr fd99::/64 accept.
    cat > "$d/07_interval.nft" <<EOF
add table ip6 filter
add set ip6 filter range6 { type ipv6_addr; flags interval; }
add element ip6 filter range6 { $PREFIX }
add chain ip6 filter input { type filter hook input priority 0; policy drop; }
add rule ip6 filter input ip6 saddr @range6 accept
EOF

    # 8. Inverted named set: ip6 saddr != @blocklist accept.
    # blocklist contains an address the client is NOT; client should pass.
    cat > "$d/08_inv_set.nft" <<'EOF'
add table ip6 filter
add set ip6 filter blocklist { type ipv6_addr; }
add element ip6 filter blocklist { fd99::99 }
add chain ip6 filter input { type filter hook input priority 0; policy drop; }
add rule ip6 filter input ip6 saddr != @blocklist accept
EOF

    # 9. ICMPv6 echo-request accept, drop TCP.
    cat > "$d/09_icmpv6_only.nft" <<'EOF'
add table ip6 filter
add chain ip6 filter input { type filter hook input priority 0; policy drop; }
add rule ip6 filter input icmpv6 type echo-request accept
EOF

    # 10. Conntrack: established/related accept, new dropped.
    # The client can't complete a new TCP handshake, but ICMPv6 reply
    # packets arrive as "related" once the kernel sees the echo-request
    # going out; however the raw echo-request itself is "new" and will
    # be dropped.  We probe with TCP (new SYN) — it should be dropped.
    cat > "$d/10_ct_state.nft" <<'EOF'
add table ip6 filter
add chain ip6 filter input { type filter hook input priority 0; policy drop; }
add rule ip6 filter input ct state established,related accept
EOF

    # 11. Anonymous vmap on ip6 saddr.
    cat > "$d/11_anon_vmap.nft" <<EOF
add table ip6 filter
add chain ip6 filter input { type filter hook input priority 0; policy drop; }
add rule ip6 filter input ip6 saddr vmap { $IP_C : accept, fd99::99 : drop }
EOF

    # 12. Interval set with two disjoint ranges merged in one set.
    # fd99::2 falls in range fd99::0 - fd99::f (first /124).
    cat > "$d/12_two_ranges.nft" <<'EOF'
add table ip6 filter
add set ip6 filter ranges { type ipv6_addr; flags interval; }
add element ip6 filter ranges { fd99::/124, fd99::100/124 }
add chain ip6 filter input { type filter hook input priority 0; policy drop; }
add rule ip6 filter input ip6 saddr @ranges accept
EOF

    # 13. Allow all, then explicit drop of a foreign address (client
    # address is NOT in the drop list — this catches sign/invert bugs
    # in the interval-set path when the set is empty of matching addrs).
    cat > "$d/13_interval_miss.nft" <<'EOF'
add table ip6 filter
add set ip6 filter foreign { type ipv6_addr; flags interval; }
add element ip6 filter foreign { fd99::100/120 }
add chain ip6 filter input { type filter hook input priority 0; policy drop; }
add rule ip6 filter input ip6 saddr != @foreign accept
EOF
}

# ------------------------------------------------------------------ #
#  Main                                                                #
# ------------------------------------------------------------------ #

main() {
    local corpus=/tmp/traffic6-corpus
    gen_rules "$corpus"
    setup
    trap teardown EXIT

    echo "Traffic parity tests — IPv6 family (sw=stormwall, nft=upstream)"
    echo

    # Case 1: baseline — no input chain, TCP should be accepted.
    run_test "baseline-tcp22-accept" \
        "$corpus/01_baseline.nft" accept probe_tcp6 22

    # Case 2 & 3: default drop catches both TCP and ICMPv6.
    run_test "default-drop-tcp22" \
        "$corpus/02_default_drop.nft" drop probe_tcp6 22
    run_test "default-drop-icmpv6" \
        "$corpus/02_default_drop.nft" drop probe_icmp6

    # Case 4 & 5: allow-ssh — port 22 in, port 80 out.
    run_test "allow-ssh-tcp22-accept" \
        "$corpus/03_allow_ssh.nft" accept probe_tcp6 22
    run_test "allow-ssh-tcp80-drop" \
        "$corpus/03_allow_ssh.nft" drop probe_tcp6 80

    # Case 6: saddr allow — client address explicitly whitelisted.
    run_test "saddr-allow-accept" \
        "$corpus/04_saddr_allow.nft" accept probe_tcp6 22

    # Case 7: saddr drop — client address explicitly blocked.
    run_test "saddr-drop-drop" \
        "$corpus/05_saddr_drop.nft" drop probe_tcp6 22

    # Case 8 & 9: anon set — port 22 and 80 in, 8080 out.
    run_test "anon-set-tcp22-accept" \
        "$corpus/06_anon_set.nft" accept probe_tcp6 22
    run_test "anon-set-tcp80-accept" \
        "$corpus/06_anon_set.nft" accept probe_tcp6 80
    run_test "anon-set-tcp8080-drop" \
        "$corpus/06_anon_set.nft" drop probe_tcp6 8080

    # Case 10: interval set — fd99::2 falls inside fd99::/64.
    run_test "interval-saddr-accept" \
        "$corpus/07_interval.nft" accept probe_tcp6 22

    # Case 11: inverted set — client NOT in blocklist, should pass.
    run_test "inv-set-saddr-accept" \
        "$corpus/08_inv_set.nft" accept probe_tcp6 22

    # Case 12 & 13: icmpv6-only — echo-request accepted, TCP dropped.
    run_test "icmpv6-only-icmp-accept" \
        "$corpus/09_icmpv6_only.nft" accept probe_icmp6
    run_test "icmpv6-only-tcp-drop" \
        "$corpus/09_icmpv6_only.nft" drop probe_tcp6 22

    # Case 14: ct state — new TCP SYN dropped.
    run_test "ct-state-tcp-drop" \
        "$corpus/10_ct_state.nft" drop probe_tcp6 22

    # Case 15: anon vmap — client address → accept, foreign → drop.
    run_test "anon-vmap-accept-source" \
        "$corpus/11_anon_vmap.nft" accept probe_tcp6 22

    # Case 16: two disjoint interval ranges — client in first range.
    run_test "two-ranges-accept" \
        "$corpus/12_two_ranges.nft" accept probe_tcp6 22

    # Case 17: interval set miss — client NOT in drop range → accept.
    run_test "interval-miss-accept" \
        "$corpus/13_interval_miss.nft" accept probe_tcp6 22

    echo
    echo "===== traffic-parity-ipv6 totals: PASS=$PASS FAIL=$FAIL ====="
    return $FAIL
}

main "$@"
