#!/bin/bash
# firewalld + stormwall smoke test.
#
# Real test of the impersonation gate: replace /usr/sbin/nft with a
# wrapper that invokes stormwall under STORMWALL_TEST_MODE=1, then
# verify firewalld starts, configures basic zones, and rule lookups
# round-trip through the wrapper.
#
# firewalld primarily uses libnftables (python3-nftables), not the
# CLI, so this exercises only the CLI codepaths it does fall back
# to: --version probing, /etc/nftables.conf application, ruleset
# enumeration. Anything that goes through the C library bypasses
# us — that's a separate libnftables-compat project.
#
# Usage: firewalld-smoke.sh
#
# WARNING: replaces /usr/sbin/nft via symlink swap. Restored on exit.

set -u
SW=/tmp/stormwall
NFT_REAL=/usr/sbin/nft.real
NFT_LINK=/usr/sbin/nft

STEP=0
total_pass=0
total_fail=0

log_step()  { STEP=$((STEP+1)); echo "[$STEP] $*"; }
log_pass()  { echo "    PASS: $*"; total_pass=$((total_pass+1)); }
log_fail()  { echo "    FAIL: $*"; total_fail=$((total_fail+1)); }

# Restore the real nft binary on exit no matter what happens. The
# wrapper we install is a regular file, not a symlink — `-L` was a
# bug in the v0 of this script that made the trap a no-op and left
# /usr/sbin/nft pointing at our wrapper across runs.
restore() {
    if [ -e "$NFT_REAL" ]; then
        sudo rm -f "$NFT_LINK"
        sudo mv "$NFT_REAL" "$NFT_LINK"
        echo "    restored $NFT_LINK"
    fi
    sudo systemctl stop firewalld 2>/dev/null || true
}
trap restore EXIT

# Step 1: snapshot baseline — what does the real nft say?
log_step "Snapshot upstream nft baseline"
real_version=$(/usr/sbin/nft --version)
real_v_dash=$(/usr/sbin/nft -V)
echo "    real --version: $real_version"

# Step 2: install the wrapper
log_step "Install nft -> stormwall wrapper at $NFT_LINK"
sudo mv "$NFT_LINK" "$NFT_REAL"
sudo tee "$NFT_LINK" > /dev/null <<'WRAPPER'
#!/bin/sh
# Stormwall masquerading as nft for downstream consumers.
exec env STORMWALL_TEST_MODE=1 /tmp/stormwall "$@"
WRAPPER
sudo chmod +x "$NFT_LINK"

# Step 3: byte-identical --version
log_step "nft --version through wrapper matches real"
wrapped_version=$(/usr/sbin/nft --version)
if [ "$wrapped_version" = "$real_version" ]; then
    log_pass "version string identical"
else
    log_fail "version differs:"
    echo "      real:    $real_version"
    echo "      wrapped: $wrapped_version"
fi

# Step 4: byte-identical -V
log_step "nft -V through wrapper matches real"
wrapped_v_dash=$(/usr/sbin/nft -V)
if [ "$wrapped_v_dash" = "$real_v_dash" ]; then
    log_pass "-V output identical"
else
    log_fail "-V differs"
    diff <(echo "$real_v_dash") <(echo "$wrapped_v_dash") | head -20
fi

# Step 5: /etc/nftables.conf applies cleanly
log_step "nft -c -f /etc/nftables.conf (check mode)"
sudo /usr/sbin/nft -c -f /etc/nftables.conf 2>&1 | tee /tmp/firewalld-step5.log | head -3
if [ ! -s /tmp/firewalld-step5.log ]; then
    log_pass "system ruleset validated"
else
    log_fail "stderr non-empty (see /tmp/firewalld-step5.log)"
fi

# Step 6: list ruleset on empty kernel
log_step "list ruleset (empty kernel)"
sudo /usr/sbin/nft flush ruleset
out=$(sudo /usr/sbin/nft list ruleset 2>&1)
if [ -z "$out" ]; then
    log_pass "empty kernel listing is empty"
else
    log_fail "expected empty, got: $out"
fi

# Step 7: firewalld --reload-style smoke
log_step "firewalld start with stormwall as backend nft"
sudo systemctl reset-failed firewalld 2>/dev/null || true
if sudo systemctl start firewalld 2>&1 | tee /tmp/firewalld-start.log; then
    sleep 2
    if systemctl is-active --quiet firewalld; then
        log_pass "firewalld active"
    else
        log_fail "firewalld not active after start"
    fi
else
    log_fail "systemctl start firewalld returned non-zero"
fi

# Step 8: firewall-cmd basics
log_step "firewall-cmd default zone + add service"
if sudo firewall-cmd --get-default-zone > /tmp/firewalld-zone.log 2>&1; then
    log_pass "default zone: $(cat /tmp/firewalld-zone.log)"
else
    log_fail "get-default-zone failed: $(cat /tmp/firewalld-zone.log)"
fi
if sudo firewall-cmd --add-service=ssh --timeout=10 > /tmp/firewalld-add.log 2>&1; then
    log_pass "added ssh service for 10s"
else
    log_fail "add-service ssh failed: $(cat /tmp/firewalld-add.log)"
fi

# Step 9: list ruleset after firewalld populated it (doesn't matter who
# wrote it; we just verify the wrapper survives reading complex state)
log_step "list ruleset after firewalld populated state"
out=$(sudo /usr/sbin/nft list ruleset 2>&1)
table_count=$(echo "$out" | grep -c '^table ' || true)
if [ "$table_count" -gt 0 ]; then
    log_pass "wrapper reads $table_count table(s) from kernel"
else
    log_fail "no tables visible:"
    echo "$out" | head
fi

# Step 10: stop firewalld cleanly
log_step "stop firewalld"
if sudo systemctl stop firewalld; then
    log_pass "stopped"
else
    log_fail "stop returned non-zero"
fi

echo
echo "===== firewalld smoke totals: PASS=$total_pass FAIL=$total_fail ====="
