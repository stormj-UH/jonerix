#!/bin/sh
# Traffic-NAT harness: build a three-netns topology (client — router — server)
# and verify that NAT rules applied to the router via *both* nft and stormwall
# produce identical address/port rewriting visible on the wire.
#
# Topology
# --------
#   tn_client (10.99.1.2) <--veth tncr0/tnrc0--> tn_router (10.99.1.1 / 10.99.0.1)
#                                                       |
#                                             veth tnrs0/tnsr0
#                                                       |
#                                             tn_server (10.99.0.2)
#
# The router netns is where NAT rules live (postrouting on the client->server
# path, prerouting for DNAT).  The server netns is the final destination and
# runs TCP listeners on the relevant ports.
#
# Verification strategy
# ---------------------
# We snoop with tcpdump -n -c1 on the router->server veth (tnrs0).  tcpdump
# writes its one-line packet summary to a temp file; we grep that for the
# expected rewritten address / port.  Both the nft arm and the stormwall arm
# run the same probe and must agree.
#
# Cases
# -----
#   1. MASQUERADE in postrouting -- src IP of client (10.99.1.2) replaced by
#      router's egress IP (10.99.0.1) as seen on tnrs0.
#   2. SNAT to 10.99.99.9 -- src IP rewritten to a static alias on tnrs0.
#   3. DNAT: packet arriving at router:80 gets dst rewritten to server:8080;
#      we confirm a packet with dport 8080 appears on tnrs0.
#   4. Negative: rule only matches dport 443; traffic to port 9999 must
#      leave src address unchanged (still 10.99.1.2 on tnrs0).
#
# Naming: all netns/veth names start with "tn" to avoid colliding with
# traffic-parity.sh's "tp" names so both harnesses can run on the same host
# without interference.

set -u

SW=/tmp/stormwall
NFT=/usr/sbin/nft

# Netns names
NS_C=tn_client
NS_R=tn_router
NS_S=tn_server

# Veth pair names
VETH_CR=tncr0    # client side of client-router link
VETH_RC=tnrc0    # router side of client-router link
VETH_RS=tnrs0    # router side of router-server link
VETH_SR=tnsr0    # server side of router-server link

# Addresses
IP_C=10.99.1.2      # client address
IP_RC=10.99.1.1     # router address facing client
IP_RS=10.99.0.1     # router address facing server (masquerade source)
IP_S=10.99.0.2      # server address
IP_SNAT=10.99.99.9  # static SNAT target (alias on tnrs0)

PASS=0
FAIL=0

# Temp files for tcpdump capture output and PID tracking
SNOOP_OUT=/tmp/tn_snoop.out
SNOOP_PID=/tmp/tn_snoop.pid

# ---------------------------------------------------------------------------
# Setup / teardown
# ---------------------------------------------------------------------------

setup() {
    teardown 2>/dev/null

    # Three namespaces
    sudo ip netns add "$NS_C"
    sudo ip netns add "$NS_R"
    sudo ip netns add "$NS_S"

    # client <-> router veth pair
    sudo ip link add "$VETH_CR" type veth peer name "$VETH_RC"
    sudo ip link set "$VETH_CR" netns "$NS_C"
    sudo ip link set "$VETH_RC" netns "$NS_R"

    # router <-> server veth pair
    sudo ip link add "$VETH_RS" type veth peer name "$VETH_SR"
    sudo ip link set "$VETH_RS" netns "$NS_R"
    sudo ip link set "$VETH_SR" netns "$NS_S"

    # Client interface + default route via router
    sudo ip -n "$NS_C" addr add "10.99.1.2/24"  dev "$VETH_CR"
    sudo ip -n "$NS_C" link set "$VETH_CR" up
    sudo ip -n "$NS_C" link set lo up
    sudo ip -n "$NS_C" route add default via "$IP_RC"

    # Router -- two interfaces; ip_forward; SNAT alias on egress
    sudo ip -n "$NS_R" addr add "10.99.1.1/24"  dev "$VETH_RC"
    sudo ip -n "$NS_R" addr add "10.99.0.1/24"  dev "$VETH_RS"
    sudo ip -n "$NS_R" addr add "10.99.99.9/32" dev "$VETH_RS"
    sudo ip -n "$NS_R" link set "$VETH_RC" up
    sudo ip -n "$NS_R" link set "$VETH_RS" up
    sudo ip -n "$NS_R" link set lo up
    sudo ip netns exec "$NS_R" sysctl -qw net.ipv4.ip_forward=1

    # Server interface + default route back via router
    sudo ip -n "$NS_S" addr add "10.99.0.2/24"  dev "$VETH_SR"
    sudo ip -n "$NS_S" link set "$VETH_SR" up
    sudo ip -n "$NS_S" link set lo up
    sudo ip -n "$NS_S" route add default via "$IP_RS"

    # Confirm baseline end-to-end reachability before any rules go in
    if ! sudo ip netns exec "$NS_C" ping -c1 -W2 "$IP_S" >/dev/null 2>&1; then
        printf "FATAL: client cannot reach server; bailing\n" >&2
        exit 1
    fi

    # Pre-stand TCP listeners on the server so accepted SYNs get SYN-ACK.
    # Without listeners the kernel sends RST and ncat reports failure even
    # when the firewall/NAT processed the packet correctly.
    LISTEN_PIDS=""
    for _port in 80 8080; do
        sudo ip netns exec "$NS_S" ncat -lk -p "$_port" >/dev/null 2>&1 &
        _pid=$!
        LISTEN_PIDS="${LISTEN_PIDS:+$LISTEN_PIDS }$_pid"
    done
    sleep 0.3
}

teardown() {
    if [ -n "${LISTEN_PIDS:-}" ]; then
        # shellcheck disable=SC2086
        sudo kill $LISTEN_PIDS 2>/dev/null || true
    fi
    sudo ip netns del "$NS_C" 2>/dev/null || true
    sudo ip netns del "$NS_R" 2>/dev/null || true
    sudo ip netns del "$NS_S" 2>/dev/null || true
    # Veths are normally removed with their netns, but be explicit in case
    # a netns deletion failed mid-setup.
    sudo ip link del "$VETH_CR" 2>/dev/null || true
    sudo ip link del "$VETH_RS" 2>/dev/null || true
    rm -f "$SNOOP_OUT" "$SNOOP_PID"
}

# ---------------------------------------------------------------------------
# Rule management
# ---------------------------------------------------------------------------

apply_nat_rules() {
    local bin=$1 rules=$2
    sudo ip netns exec "$NS_R" "$bin" flush ruleset 2>/dev/null || true
    sudo ip netns exec "$NS_R" "$bin" -f "$rules"
}

# ---------------------------------------------------------------------------
# Packet-snoop helper
# ---------------------------------------------------------------------------
# snoop_start IFACE BPFFILTER
#   Start a background tcpdump (-c1) inside tn_router writing to SNOOP_OUT.
#   Records the PID in SNOOP_PID so snoop_wait can track it as a direct
#   child of the calling shell (avoids the "not a child" wait(1) failure that
#   occurs when the PID is captured via command-substitution subshell).
#   A 3-second timeout wrapper around tcpdump prevents an indefinite hang
#   when no matching packet arrives (e.g. if traffic was fired before the
#   BPF filter was installed).
snoop_start() {
    local iface=$1 bpf=$2
    : > "$SNOOP_OUT"
    sudo ip netns exec "$NS_R" \
        timeout 3 tcpdump -l -n -c 1 -i "$iface" "$bpf" > "$SNOOP_OUT" 2>/dev/null &
    printf '%s\n' "$!" > "$SNOOP_PID"
}

# snoop_wait
#   Wait for the background tcpdump started by snoop_start to exit.
#   Polls via kill -0 to avoid the POSIX restriction that wait(1) only
#   succeeds on direct children; falls back to a hard kill after 4 s.
snoop_wait() {
    local pid i=0
    pid=$(cat "$SNOOP_PID" 2>/dev/null) || return 0
    while kill -0 "$pid" 2>/dev/null && [ "$i" -lt 40 ]; do
        sleep 0.1
        i=$((i+1))
    done
    sudo kill "$pid" 2>/dev/null || true
}

# snoop_contains PATTERN
#   Return 0 if SNOOP_OUT contains PATTERN, 1 otherwise.
snoop_contains() {
    grep -q "$1" "$SNOOP_OUT"
}

# ---------------------------------------------------------------------------
# NAT verification primitives
# ---------------------------------------------------------------------------
# Each probe_nat_* function:
#   1. Arms a background tcpdump on tnrs0 (router->server veth).
#   2. Pauses briefly so tcpdump is ready before the first packet arrives.
#   3. Fires client traffic that should trigger the NAT rule.
#   4. Waits for tcpdump to finish (stops after -c1 or on timeout).
#   5. Greps SNOOP_OUT for the expected rewritten field.
#   Returns 0 if the expected value was observed, 1 otherwise.

# probe_nat_masq EXPECTED_SRC_IP
#   Client connects to server:80.  MASQUERADE rule rewrites src to the
#   router's egress IP.  Verify the rewritten src appears on tnrs0.
probe_nat_masq() {
    local expected_src=$1
    snoop_start "$VETH_RS" "tcp and dst port 80"
    sleep 0.3
    sudo ip netns exec "$NS_C" \
        timeout 2 ncat -z -w1 "$IP_S" 80 >/dev/null 2>&1 || true
    snoop_wait
    snoop_contains "$expected_src"
}

# probe_nat_snat EXPECTED_SRC_IP
#   Identical probe geometry to masquerade, but verifies the static SNAT
#   address rather than the interface's primary IP.
probe_nat_snat() {
    local expected_src=$1
    snoop_start "$VETH_RS" "tcp and dst port 80"
    sleep 0.3
    sudo ip netns exec "$NS_C" \
        timeout 2 ncat -z -w1 "$IP_S" 80 >/dev/null 2>&1 || true
    snoop_wait
    snoop_contains "$expected_src"
}

# probe_nat_dnat DST_IP DST_PORT
#   Client connects to router's egress IP at port 80.  A DNAT prerouting
#   rule rewrites the destination to DST_IP:DST_PORT.  We confirm by
#   snooping for a packet to DST_PORT on tnrs0 -- that packet only appears
#   if the kernel applied the rewrite and forwarded the packet onward.
#   DST_IP dots are matched literally in grep so we escape them.
probe_nat_dnat() {
    local dst_ip=$1 dst_port=$2
    # tcpdump prints "IP src > dst.port: ..." -- match dst IP and port
    # Escape dots in the IP for grep so "10.99.0.2" doesn't match "10X99Y0Z2"
    local escaped_ip
    escaped_ip=$(printf '%s\n' "$dst_ip" | sed 's/\./\\./g')
    snoop_start "$VETH_RS" "tcp and dst port ${dst_port}"
    sleep 0.3
    # Connect to the router's server-side IP:80; DNAT rewrites to dst_port
    sudo ip netns exec "$NS_C" \
        timeout 2 ncat -z -w1 "$IP_RS" 80 >/dev/null 2>&1 || true
    snoop_wait
    snoop_contains "${escaped_ip}\.${dst_port}"
}

# probe_nat_no_rewrite ORIGINAL_SRC_IP
#   Client connects to server:9999 (no NAT rule matches that port).
#   Verify the source IP on tnrs0 is still the original client IP, meaning
#   no translation was applied.
probe_nat_no_rewrite() {
    local original_src=$1
    # Bring up a transient listener so the SYN isn't RST'd immediately
    sudo ip netns exec "$NS_S" timeout 4 ncat -lk -p 9999 >/dev/null 2>&1 &
    local srv_pid=$!
    snoop_start "$VETH_RS" "tcp and dst port 9999"
    sleep 0.3
    sudo ip netns exec "$NS_C" \
        timeout 2 ncat -z -w1 "$IP_S" 9999 >/dev/null 2>&1 || true
    snoop_wait
    sudo kill "$srv_pid" 2>/dev/null || true
    snoop_contains "$original_src"
}

# ---------------------------------------------------------------------------
# Test runner
# ---------------------------------------------------------------------------
# run_nat_test LABEL RULES_FILE PROBE_FN PROBE_ARGS...
#   Apply rules via nft, run probe, record whether rewrite was observed.
#   Apply rules via stormwall, run probe, record.
#   Both arms must observe the rewrite (probe returns 0) for PASS.
run_nat_test() {
    local label=$1 rules=$2
    shift 2
    local probe=$1; shift

    local nft_rc sw_rc
    apply_nat_rules "$NFT" "$rules"
    if "$probe" "$@"; then nft_rc=0; else nft_rc=1; fi

    apply_nat_rules "$SW" "$rules"
    if "$probe" "$@"; then sw_rc=0; else sw_rc=1; fi

    if [ "$nft_rc" = "0" ] && [ "$sw_rc" = "0" ]; then
        printf "  PASS: %-48s nft=rewritten  sw=rewritten\n"  "$label"
        PASS=$((PASS+1))
    elif [ "$nft_rc" = "1" ] && [ "$sw_rc" = "1" ]; then
        printf "  FAIL: %-48s nft=no-rewrite sw=no-rewrite (both arms failed)\n" "$label"
        FAIL=$((FAIL+1))
    else
        printf "  FAIL: %-48s nft=%s sw=%s (drift)\n" "$label" \
            "$([ "$nft_rc" = 0 ] && printf rewritten || printf no-rewrite)" \
            "$([ "$sw_rc"  = 0 ] && printf rewritten || printf no-rewrite)"
        FAIL=$((FAIL+1))
    fi
}

# run_nat_neg_test LABEL RULES_FILE PROBE_FN PROBE_ARGS...
#   Like run_nat_test but the probe tests for *absence* of rewriting.
#   Both arms must confirm the expected field is unchanged (probe returns 0).
run_nat_neg_test() {
    local label=$1 rules=$2
    shift 2
    local probe=$1; shift

    local nft_rc sw_rc
    apply_nat_rules "$NFT" "$rules"
    if "$probe" "$@"; then nft_rc=0; else nft_rc=1; fi

    apply_nat_rules "$SW" "$rules"
    if "$probe" "$@"; then sw_rc=0; else sw_rc=1; fi

    if [ "$nft_rc" = "0" ] && [ "$sw_rc" = "0" ]; then
        printf "  PASS: %-48s nft=unchanged  sw=unchanged\n"  "$label"
        PASS=$((PASS+1))
    elif [ "$nft_rc" = "1" ] && [ "$sw_rc" = "1" ]; then
        printf "  FAIL: %-48s nft=rewritten  sw=rewritten (rule leaked through)\n" "$label"
        FAIL=$((FAIL+1))
    else
        printf "  FAIL: %-48s nft=%s sw=%s (drift)\n" "$label" \
            "$([ "$nft_rc" = 0 ] && printf unchanged || printf rewritten)" \
            "$([ "$sw_rc"  = 0 ] && printf unchanged || printf rewritten)"
        FAIL=$((FAIL+1))
    fi
}

# ---------------------------------------------------------------------------
# Ruleset generator
# ---------------------------------------------------------------------------
gen_nat_rules() {
    local d=$1
    mkdir -p "$d"

    # Case 1: MASQUERADE -- src IP replaced by tnrs0's primary IP (10.99.0.1).
    cat > "$d/nat01_masquerade.nft" <<'EOF'
add table ip nat
add chain ip nat postrouting { type nat hook postrouting priority srcnat; policy accept; }
add rule ip nat postrouting oif "tnrs0" masquerade
EOF

    # Case 2: SNAT to static alias 10.99.99.9 (assigned to tnrs0 in setup).
    cat > "$d/nat02_snat.nft" <<'EOF'
add table ip nat
add chain ip nat postrouting { type nat hook postrouting priority srcnat; policy accept; }
add rule ip nat postrouting oif "tnrs0" snat to 10.99.99.9
EOF

    # Case 3: DNAT -- incoming to router:80 rewritten to server:8080.
    # After DNAT the kernel forwards the packet because ip_forward=1; the
    # server's :8080 listener accepts it.
    cat > "$d/nat03_dnat.nft" <<'EOF'
add table ip nat
add chain ip nat prerouting { type nat hook prerouting priority dstnat; policy accept; }
add rule ip nat prerouting iif "tnrc0" tcp dport 80 dnat to 10.99.0.2:8080
EOF

    # Case 4: Negative -- postrouting only matches dport 443; traffic to port
    # 9999 passes through untranslated so src stays at 10.99.1.2 on tnrs0.
    cat > "$d/nat04_no_match.nft" <<'EOF'
add table ip nat
add chain ip nat postrouting { type nat hook postrouting priority srcnat; policy accept; }
add rule ip nat postrouting oif "tnrs0" tcp dport 443 masquerade
EOF
}

# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
main() {
    local corpus=/tmp/traffic-nat-corpus
    gen_nat_rules "$corpus"

    setup
    trap teardown EXIT

    printf "Traffic NAT parity tests (sw=stormwall, nft=upstream)\n"
    printf "\n"

    # Case 1: MASQUERADE -- src on tnrs0 must show the router's egress IP
    run_nat_test "masquerade-src-becomes-router-egress-ip" \
        "$corpus/nat01_masquerade.nft" \
        probe_nat_masq "$IP_RS"

    # Case 2: SNAT -- src on tnrs0 must show the static alias 10.99.99.9
    run_nat_test "snat-src-becomes-static-alias" \
        "$corpus/nat02_snat.nft" \
        probe_nat_snat "$IP_SNAT"

    # Case 3: DNAT -- packet to router:80 arrives at server:8080 (dport on tnrs0)
    run_nat_test "dnat-dst-port-rewritten-to-8080" \
        "$corpus/nat03_dnat.nft" \
        probe_nat_dnat "$IP_S" 8080

    # Case 4: Negative -- dport 9999 not matched; src IP on tnrs0 still client IP
    run_nat_neg_test "no-match-src-unchanged-at-9999" \
        "$corpus/nat04_no_match.nft" \
        probe_nat_no_rewrite "$IP_C"

    printf "\n"
    printf "===== traffic-nat totals: PASS=%s FAIL=%s =====\n" "$PASS" "$FAIL"
    return $FAIL
}

main "$@"
