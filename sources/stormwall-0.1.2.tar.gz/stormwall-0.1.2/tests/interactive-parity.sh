#!/bin/sh
# interactive-parity.sh -- byte-identity matrix for nft -i / --interactive.
#
# For each scripted REPL session we:
#   1. Create a fresh network namespace (isolates from churn-loop and any
#      other concurrent test).
#   2. Pipe the session through upstream nft -i inside the netns; capture
#      stdout/stderr/exit.
#   3. Recreate the netns (clean slate) and pipe the same session through
#      stormwall -i (TEST_MODE=1).
#   4. Sanitise both stdouts (strip kernel-assigned handles / set IDs).
#   5. Diff stdouts. Stderr is checked only for "errored when expected"
#      since parser-error wording is not yet byte-identical (out of scope
#      for this matrix).
#
# Reports PASS/FAIL totals at the end. Exit 0 iff all cases pass.
#
# Environment:
#   NFT     upstream nft path         (default: /usr/sbin/nft)
#   SW      stormwall binary          (default: /tmp/stormwall)
#   OUTDIR  scratch dir               (default: /tmp/interactive-parity)
#
# Usage:
#   tests/interactive-parity.sh             -- run all cases
#   tests/interactive-parity.sh <case_id>   -- run one case (e.g. 03_multi_table_then_list)

set -u

NFT=${NFT:-/usr/sbin/nft}
SW=${SW:-/tmp/stormwall}
OUTDIR=${OUTDIR:-/tmp/interactive-parity}

# nft's libedit prints a libedit/terminfo warning to stderr when TERM is
# unknown. xterm is a safe value present in any termcap.
TERM_VAL=xterm

mkdir -p "$OUTDIR"

# ---------------------------------------------------------------------------
# sanitize: drop kernel-assigned handles, set/map IDs, and live counter
# values. Mirrors the rules used by list-golden.sh.
# ---------------------------------------------------------------------------
sanitize() {
    sed -E \
        -e 's/handle [0-9]+/handle H/g' \
        -e 's/__set[0-9]+/__setN/g' \
        -e 's/__map[0-9]+/__mapN/g' \
        -e 's/packets [0-9]+ bytes [0-9]+/packets P bytes B/g' \
        -e 's/expires [0-9a-z]+/expires E/g'
}

# ---------------------------------------------------------------------------
# run_in_ns CMD < SCRIPT > OUT 2> ERR -- run CMD inside a fresh netns
# with TERM=xterm, reading the REPL script from stdin. Returns CMD's
# exit code. Caller is responsible for passing redirections.
# ---------------------------------------------------------------------------
run_in_ns() {
    ns=$1
    shift
    sudo ip netns del "$ns" 2>/dev/null || true
    sudo ip netns add "$ns"
    rc=0
    sudo ip netns exec "$ns" env TERM=$TERM_VAL "$@" || rc=$?
    sudo ip netns del "$ns" 2>/dev/null || true
    return $rc
}

# ---------------------------------------------------------------------------
# Cases. Each case_<id> writes a REPL script to stdout. Each
# expects_err_<id> echoes 1 if stderr is expected to be non-empty
# (parser/runtime errors), 0 otherwise.
# ---------------------------------------------------------------------------

case_01_simple_add_list_quit() {
    cat <<'EOF'
add table ip t1
list ruleset
quit
EOF
}
expects_err_01_simple_add_list_quit() { echo 0; }

case_02_apply_error_continue() {
    # The `delete table ip nonexistent` line triggers a kernel ENOENT.
    # Both nft -i and stormwall -i must print an error and KEEP GOING
    # (the final `list ruleset` must still render the table we added
    # on the first line). `add table` is idempotent in both tools, so
    # duplicate-add does NOT error — we use a delete instead.
    cat <<'EOF'
add table ip t2
delete table ip nonexistent
list ruleset
quit
EOF
}
expects_err_02_apply_error_continue() { echo 1; }

case_03_multi_table_then_list() {
    cat <<'EOF'
add table ip t3a
add table ip6 t3b
add table inet t3c
list tables
quit
EOF
}
expects_err_03_multi_table_then_list() { echo 0; }

case_04_atomic_block_style() {
    cat <<'EOF'
flush ruleset
add table ip t4
add chain ip t4 c { type filter hook input priority 0; policy accept; }
add rule ip t4 c ip saddr 1.1.1.1 drop
list ruleset
quit
EOF
}
expects_err_04_atomic_block_style() { echo 0; }

case_05_empty_input() {
    # No commands at all. EOF must terminate the REPL with exit 0
    # and produce no stdout in either tool.
    :
}
expects_err_05_empty_input() { echo 0; }

CASES="01_simple_add_list_quit \
       02_apply_error_continue \
       03_multi_table_then_list \
       04_atomic_block_style \
       05_empty_input"

if [ $# -ge 1 ]; then
    CASES="$1"
fi

PASS=0
FAIL=0
TOTAL=0

run_case() {
    id=$1
    TOTAL=$((TOTAL + 1))

    script="$OUTDIR/$id.in"
    nft_out="$OUTDIR/$id.nft.out"
    nft_err="$OUTDIR/$id.nft.err"
    sw_out="$OUTDIR/$id.sw.out"
    sw_err="$OUTDIR/$id.sw.err"
    ns="ipar_$id"

    "case_$id" > "$script"

    run_in_ns "$ns" "$NFT" -i \
        < "$script" > "$nft_out" 2> "$nft_err"
    nft_rc=$?

    run_in_ns "$ns" env STORMWALL_TEST_MODE=1 "$SW" -i \
        < "$script" > "$sw_out" 2> "$sw_err"
    sw_rc=$?

    sanitize < "$nft_out" > "$nft_out.s"
    sanitize < "$sw_out" > "$sw_out.s"

    expect_err=$("expects_err_$id")
    nft_err_lines=$(wc -l < "$nft_err")
    sw_err_lines=$(wc -l < "$sw_err")

    fail_reasons=""

    if ! diff -u "$nft_out.s" "$sw_out.s" > "$OUTDIR/$id.diff" 2>&1; then
        fail_reasons="$fail_reasons stdout-diff"
    fi
    if [ "$nft_rc" -ne "$sw_rc" ]; then
        fail_reasons="$fail_reasons exit-code(nft=$nft_rc sw=$sw_rc)"
    fi
    if [ "$expect_err" = "1" ]; then
        if [ "$nft_err_lines" -lt 1 ] || [ "$sw_err_lines" -lt 1 ]; then
            fail_reasons="$fail_reasons stderr-presence(nft=$nft_err_lines sw=$sw_err_lines)"
        fi
    else
        if [ "$nft_err_lines" -ne 0 ] || [ "$sw_err_lines" -ne 0 ]; then
            fail_reasons="$fail_reasons stderr-noise(nft=$nft_err_lines sw=$sw_err_lines)"
        fi
    fi

    if [ -z "$fail_reasons" ]; then
        printf 'PASS  %s\n' "$id"
        PASS=$((PASS + 1))
    else
        printf 'FAIL  %s --%s\n' "$id" "$fail_reasons"
        FAIL=$((FAIL + 1))
        if [ -s "$OUTDIR/$id.diff" ]; then
            sed 's/^/      /' < "$OUTDIR/$id.diff"
        fi
    fi
}

for id in $CASES; do
    run_case "$id"
done

printf '\n%s/%s passed (%s failed)\n' "$PASS" "$TOTAL" "$FAIL"
[ "$FAIL" -eq 0 ]
