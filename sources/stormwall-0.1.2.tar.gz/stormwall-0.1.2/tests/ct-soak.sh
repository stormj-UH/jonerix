#!/bin/bash
# Conntrack soak test: verify stormwall ct-state-based rulesets behave
# identically to nft under 5 minutes of sustained TCP load.
#
# Two arms run sequentially (nft then stormwall) so the same machine is
# never shared across arms.  Each arm:
#   1. Builds a two-netns topology (server tcs_server + client tcs_client)
#      linked by a veth pair.
#   2. Applies a stateful ruleset (ct state established,related accept +
#      tcp dport 5201 ct state new accept) inside the server netns.
#   3. Starts iperf3 -s in the server and iperf3 -c -t 300 from the client.
#   4. Samples conntrack count and rule counters every 30 s.
#   5. Reports throughput, counter monotonicity, and conntrack bounds.
#
# Pass criteria:
#   - iperf3 reports non-zero throughput under both backends.
#   - Both throughputs are within 5 % of each other (relative diff ≤ 0.05).
#   - Conntrack count never grows unboundedly (final count ≤ 2× peak).
#   - Rule counters advance in every 30-s window (never stall).
#
# Usage: sudo bash tests/ct-soak.sh
#
# Requires: ip(8), iperf3, nft, /tmp/stormwall (stormwall binary),
#           /proc/sys/net/netfilter/nf_conntrack_count

set -u

# ---------------------------------------------------------------------------
# Paths & constants
# ---------------------------------------------------------------------------
SW=/tmp/stormwall
NFT=/usr/sbin/nft
NS_S=tcs_server
NS_C=tcs_client
VETH_S=tcss0
VETH_C=tcsc0
IP_S=10.98.0.1
IP_C=10.98.0.2
IPERF_PORT=5201
SOAK_SECS=300          # 5 minutes per arm
SAMPLE_INTERVAL=30     # seconds between samples
LOG=/tmp/ct-soak.log
IPERF_LOG_NFT=/tmp/ct-soak-iperf-nft.json
IPERF_LOG_SW=/tmp/ct-soak-iperf-sw.json
TMPDIR_RULES=/tmp/ct-soak-rules

# ---------------------------------------------------------------------------
# Cleanup / teardown (idempotent — called by trap and explicitly)
# ---------------------------------------------------------------------------
teardown() {
    # Kill any iperf3 processes we spawned
    if [ -n "${SERVER_PID:-}" ]; then
        sudo kill "$SERVER_PID" 2>/dev/null || true
        unset SERVER_PID
    fi
    if [ -n "${CLIENT_PID:-}" ]; then
        sudo kill "$CLIENT_PID" 2>/dev/null || true
        unset CLIENT_PID
    fi
    # Flush any nftables rules in the server netns before deleting it so
    # we don't leave dangling hooks that confuse the next arm.
    sudo ip netns exec "$NS_S" "$NFT" flush ruleset 2>/dev/null || true
    # Remove namespaces; deleting the netns also tears down the veth pair.
    sudo ip netns del "$NS_S" 2>/dev/null || true
    sudo ip netns del "$NS_C" 2>/dev/null || true
    # Belt-and-suspenders veth cleanup (already gone when netns is deleted,
    # but harmless if not).
    sudo ip link del "$VETH_S" 2>/dev/null || true
}

trap teardown EXIT

# ---------------------------------------------------------------------------
# Ruleset file
# ---------------------------------------------------------------------------
setup_rules() {
    mkdir -p "$TMPDIR_RULES"
    cat > "$TMPDIR_RULES/ct_stateful.nft" <<'EOF'
flush ruleset
table ip filter {
    chain input {
        type filter hook input priority 0; policy drop;
        ct state established,related counter accept
        tcp dport 5201 ct state new counter accept
    }
}
EOF
}

# ---------------------------------------------------------------------------
# Topology setup
# ---------------------------------------------------------------------------
setup_netns() {
    teardown 2>/dev/null
    sudo ip netns add "$NS_S"
    sudo ip netns add "$NS_C"
    sudo ip link add "$VETH_S" type veth peer name "$VETH_C"
    sudo ip link set "$VETH_S" netns "$NS_S"
    sudo ip link set "$VETH_C" netns "$NS_C"
    sudo ip -n "$NS_S" addr add "$IP_S/24" dev "$VETH_S"
    sudo ip -n "$NS_C" addr add "$IP_C/24" dev "$VETH_C"
    sudo ip -n "$NS_S" link set "$VETH_S" up
    sudo ip -n "$NS_C" link set "$VETH_C" up
    sudo ip -n "$NS_S" link set lo up
    sudo ip -n "$NS_C" link set lo up
    # Confirm connectivity before applying any rules.
    if ! sudo ip netns exec "$NS_C" ping -c1 -W2 "$IP_S" >/dev/null 2>&1; then
        echo "FATAL: namespaces cannot reach each other; bailing" | tee -a "$LOG"
        exit 1
    fi
}

# ---------------------------------------------------------------------------
# Apply ruleset (flush first, then load)
# ---------------------------------------------------------------------------
apply_rules() {
    local bin=$1
    sudo ip netns exec "$NS_S" "$bin" -f "$TMPDIR_RULES/ct_stateful.nft" 2>>"$LOG"
}

# ---------------------------------------------------------------------------
# Read current counter bytes from the "established,related" rule.
# nft -a list chain ip filter input prints handle numbers; we grep for the
# counter keyword and extract the "packets X bytes Y" fields.
# Returns "<packets> <bytes>" on stdout, or "0 0" on parse failure.
# ---------------------------------------------------------------------------
read_counter() {
    sudo ip netns exec "$NS_S" "$NFT" -a list chain ip filter input 2>/dev/null \
        | grep 'established,related.*counter' \
        | grep -oE 'packets [0-9]+' | awk '{print $2}' \
        | { read -r p; printf '%s\n' "${p:-0}"; }
}

# ---------------------------------------------------------------------------
# Read conntrack count (global, not netns-scoped — conntrack lives in the
# host's init_net, but traffic inside a netns still populates it when
# connection tracking is enabled on the veth hooks).
# ---------------------------------------------------------------------------
read_ct_count() {
    cat /proc/sys/net/netfilter/nf_conntrack_count 2>/dev/null || printf '0\n'
}

# ---------------------------------------------------------------------------
# Extract bits-per-second from an iperf3 JSON result file.
# Uses the "sum_received" or "sum_sent" end summary.
# ---------------------------------------------------------------------------
iperf_bps() {
    local f=$1
    # The JSON structure: .end.sum_received.bits_per_second
    python3 -c "
import json, sys
d = json.load(open('$f'))
try:
    bps = d['end']['sum_received']['bits_per_second']
except KeyError:
    bps = d['end']['sum_sent']['bits_per_second']
print(int(bps))
" 2>/dev/null || printf '0\n'
}

# ---------------------------------------------------------------------------
# Run one arm of the soak.
# $1 = arm name ("nft" or "sw")
# $2 = binary path
# $3 = iperf3 JSON output file
# Sets globals: RESULT_<ARM>_BPS, RESULT_<ARM>_CT_PEAK, RESULT_<ARM>_CTR_STALL
# ---------------------------------------------------------------------------
run_arm() {
    local arm=$1 bin=$2 iperf_out=$3

    echo "" | tee -a "$LOG"
    echo "======================================================" | tee -a "$LOG"
    echo "ARM: $arm  binary: $bin  $(date)" | tee -a "$LOG"
    echo "======================================================" | tee -a "$LOG"

    setup_netns
    apply_rules "$bin"

    # Start iperf3 server inside the server netns.
    sudo ip netns exec "$NS_S" iperf3 -s -p "$IPERF_PORT" --one-off >/dev/null 2>>"$LOG" &
    SERVER_PID=$!
    sleep 1   # let iperf3 server bind

    # Start iperf3 client: 5-minute run, JSON output.
    sudo ip netns exec "$NS_C" \
        iperf3 -c "$IP_S" -p "$IPERF_PORT" -t "$SOAK_SECS" -J \
        > "$iperf_out" 2>>"$LOG" &
    CLIENT_PID=$!

    # -----------------------------------------------------------------------
    # Sample loop — runs while the client is alive.
    # -----------------------------------------------------------------------
    local deadline=$(( $(date +%s) + SOAK_SECS + 15 ))  # 15 s grace
    local ct_peak=0
    local prev_pkts=-1
    local ctr_stall=0
    local sample_num=0

    echo "ts,arm,sample,ct_count,rule_packets" >> "$LOG"

    while kill -0 "$CLIENT_PID" 2>/dev/null && [ "$(date +%s)" -lt "$deadline" ]; do
        sleep "$SAMPLE_INTERVAL"

        local ct_now
        ct_now=$(read_ct_count)
        local pkts_now
        pkts_now=$(read_counter)

        if [ "$ct_now" -gt "$ct_peak" ]; then
            ct_peak=$ct_now
        fi

        if [ "$prev_pkts" -ge 0 ] && [ "$pkts_now" -le "$prev_pkts" ]; then
            ctr_stall=$((ctr_stall + 1))
            echo "  [WARN] counter stall at sample $sample_num: pkts_now=$pkts_now prev=$prev_pkts" \
                | tee -a "$LOG"
        fi
        prev_pkts=$pkts_now

        echo "$(date +%s),$arm,$sample_num,$ct_now,$pkts_now" | tee -a "$LOG"
        sample_num=$((sample_num + 1))
    done

    # Wait for client to finish (it may have already exited cleanly).
    wait "$CLIENT_PID" 2>/dev/null || true
    unset CLIENT_PID

    # Stop the server too.
    sudo kill "$SERVER_PID" 2>/dev/null || true
    wait "$SERVER_PID" 2>/dev/null || true
    unset SERVER_PID

    # Read final conntrack count for the bounded check.
    local ct_final
    ct_final=$(read_ct_count)
    echo "[$arm] ct_peak=$ct_peak ct_final=$ct_final" | tee -a "$LOG"

    # Parse throughput.
    local bps
    bps=$(iperf_bps "$iperf_out")
    echo "[$arm] iperf3 bits/s = $bps" | tee -a "$LOG"

    # Export results into named globals (bash indirect assignment).
    # We store in global vars with sanitised arm name (sw/nft, already safe).
    eval "RESULT_${arm}_BPS=${bps}"
    eval "RESULT_${arm}_CT_PEAK=${ct_peak}"
    eval "RESULT_${arm}_CT_FINAL=${ct_final}"
    eval "RESULT_${arm}_CTR_STALL=${ctr_stall}"

    teardown
}

# ---------------------------------------------------------------------------
# Pass/fail evaluation
# ---------------------------------------------------------------------------
check_results() {
    local nft_bps=$1 sw_bps=$2
    local nft_ct_peak=$3 nft_ct_final=$4
    local sw_ct_peak=$5 sw_ct_final=$6
    local nft_stall=$7 sw_stall=$8

    local pass=0 fail=0

    printf '\n'
    printf '=== ct-soak results ==========================================\n'
    printf '  nft  throughput : %d bps\n'  "$nft_bps"
    printf '  sw   throughput : %d bps\n'  "$sw_bps"

    # --- Criterion 1: both arms had non-zero throughput ---
    if [ "$nft_bps" -gt 0 ] && [ "$sw_bps" -gt 0 ]; then
        printf '  PASS: both arms reported non-zero throughput\n'
        pass=$((pass + 1))
    else
        printf '  FAIL: one or both arms had zero throughput (nft=%d sw=%d)\n' \
            "$nft_bps" "$sw_bps"
        fail=$((fail + 1))
    fi

    # --- Criterion 2: throughput within 5 % ---
    # Avoid floating point; compute 100 * |a-b| / max(a,b) using integer math.
    if [ "$nft_bps" -gt 0 ] && [ "$sw_bps" -gt 0 ]; then
        local diff max_bps ratio_pct
        if [ "$nft_bps" -gt "$sw_bps" ]; then
            diff=$(( nft_bps - sw_bps ))
            max_bps=$nft_bps
        else
            diff=$(( sw_bps - nft_bps ))
            max_bps=$sw_bps
        fi
        ratio_pct=$(( diff * 100 / max_bps ))
        printf '  throughput diff: %d%% (nft=%d sw=%d)\n' \
            "$ratio_pct" "$nft_bps" "$sw_bps"
        if [ "$ratio_pct" -le 5 ]; then
            printf '  PASS: throughput within 5%%\n'
            pass=$((pass + 1))
        else
            printf '  FAIL: throughput diff exceeds 5%% (%d%%)\n' "$ratio_pct"
            fail=$((fail + 1))
        fi
    fi

    # --- Criterion 3: conntrack count bounded (final ≤ 2× peak) ---
    check_ct_bounded() {
        local arm=$1 peak=$2 final=$3
        local limit=$(( peak * 2 ))
        if [ "$peak" -gt 0 ] && [ "$final" -le "$limit" ]; then
            printf '  PASS: [%s] ct bounded — peak=%d final=%d\n' \
                "$arm" "$peak" "$final"
            pass=$((pass + 1))
        elif [ "$peak" -eq 0 ]; then
            # Peak of 0 may mean conntrack isn't counting at all — warn
            # but don't hard-fail (some kernels need nf_conntrack_count ≥ 0).
            printf '  WARN: [%s] ct_peak=0 — conntrack may not be loaded\n' "$arm"
        else
            printf '  FAIL: [%s] ct may be leaking — peak=%d final=%d limit=%d\n' \
                "$arm" "$peak" "$final" "$limit"
            fail=$((fail + 1))
        fi
    }
    check_ct_bounded nft "$nft_ct_peak" "$nft_ct_final"
    check_ct_bounded sw  "$sw_ct_peak"  "$sw_ct_final"

    # --- Criterion 4: rule counters never stalled ---
    if [ "$nft_stall" -eq 0 ] && [ "$sw_stall" -eq 0 ]; then
        printf '  PASS: rule counters advanced every 30-s window (both arms)\n'
        pass=$((pass + 1))
    else
        printf '  FAIL: counter stalls — nft_stall=%d sw_stall=%d\n' \
            "$nft_stall" "$sw_stall"
        fail=$((fail + 1))
    fi

    printf '==============================================================\n'
    printf 'TOTAL: PASS=%d FAIL=%d\n' "$pass" "$fail"
    printf '==============================================================\n'
    return "$fail"
}

# ---------------------------------------------------------------------------
# Preflight checks
# ---------------------------------------------------------------------------
preflight() {
    local ok=1

    if ! command -v iperf3 >/dev/null 2>&1; then
        echo "FATAL: iperf3 not found" >&2; ok=0
    fi
    if ! command -v "$NFT" >/dev/null 2>&1; then
        echo "FATAL: nft not found at $NFT" >&2; ok=0
    fi
    if [ ! -x "$SW" ]; then
        echo "FATAL: stormwall binary not found/executable at $SW" >&2; ok=0
    fi
    if [ ! -f /proc/sys/net/netfilter/nf_conntrack_count ]; then
        echo "WARN: /proc/sys/net/netfilter/nf_conntrack_count missing — " \
             "conntrack module may not be loaded; ct checks will show zeros" >&2
    fi
    if [ "$(id -u)" -ne 0 ] && ! sudo -n true 2>/dev/null; then
        echo "FATAL: must run as root or have passwordless sudo" >&2; ok=0
    fi
    if [ "$ok" -eq 0 ]; then
        exit 1
    fi
}

# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
main() {
    : > "$LOG"
    echo "ct-soak started at $(date) pid=$$" | tee -a "$LOG"
    echo "soak=$SOAK_SECS s/arm, sample_interval=${SAMPLE_INTERVAL}s" \
        | tee -a "$LOG"
    echo "estimated wall time: $(( SOAK_SECS * 2 / 60 )) min" | tee -a "$LOG"

    preflight
    setup_rules

    # ARM 1: nft
    run_arm nft "$NFT" "$IPERF_LOG_NFT"

    # ARM 2: stormwall
    run_arm sw "$SW" "$IPERF_LOG_SW"

    # Evaluate
    check_results \
        "$RESULT_nft_BPS" "$RESULT_sw_BPS" \
        "$RESULT_nft_CT_PEAK" "$RESULT_nft_CT_FINAL" \
        "$RESULT_sw_CT_PEAK"  "$RESULT_sw_CT_FINAL" \
        "$RESULT_nft_CTR_STALL" "$RESULT_sw_CTR_STALL"
}

main "$@"
