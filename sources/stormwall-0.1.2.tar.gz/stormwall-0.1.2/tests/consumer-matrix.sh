#!/bin/sh
# consumer-matrix.sh — smoke-test common nft-consumer tools against stormwall.
#
# For each tool we:
#   1. Detect whether it is installed (SKIP cleanly if not).
#   2. Swap /usr/sbin/nft for a stormwall wrapper (STORMWALL_TEST_MODE=1).
#   3. Run a minimal smoke interaction.
#   4. Report PASS / FAIL / SKIP.
#
# The wrapper is installed once at the top and torn down on exit.
# The restore() trap uses mv-back, not symlink removal — mirrors the
# bug-fix from firewalld-smoke.sh where `-L` made the trap a no-op.
#
# Usage: sudo tests/consumer-matrix.sh
#        (root needed for nft wrapper swap and service management)
#
# STORMWALL binary: /tmp/stormwall  (same assumption as other test scripts)

set -u

SW=/tmp/stormwall
NFT_REAL=/usr/sbin/nft.real
NFT_LINK=/usr/sbin/nft

total_pass=0
total_fail=0
total_skip=0

###############################################################################
# Output helpers
###############################################################################

log_tool()  { printf '\n[tool: %s]\n' "$1"; }
log_pass()  { printf '    PASS: %s\n' "$1"; total_pass=$((total_pass + 1)); }
log_fail()  { printf '    FAIL: %s\n' "$1"; total_fail=$((total_fail + 1)); }
log_skip()  { printf '    SKIP: %s\n' "$1"; total_skip=$((total_skip + 1)); }
log_info()  { printf '    info: %s\n' "$1"; }

###############################################################################
# Wrapper install / restore
###############################################################################

restore() {
    # Unconditional restore — wrapper is a regular file, not a symlink,
    # so the -e test is reliable.  (Using -L here was the v0 bug.)
    if [ -e "$NFT_REAL" ]; then
        rm -f "$NFT_LINK"
        mv "$NFT_REAL" "$NFT_LINK"
        printf '    restored %s\n' "$NFT_LINK"
    fi
    # Stop any services we may have started.
    systemctl stop fail2ban 2>/dev/null || true
}
trap restore EXIT

# Install wrapper
printf '[setup] installing nft -> stormwall wrapper at %s\n' "$NFT_LINK"
mv "$NFT_LINK" "$NFT_REAL"
tee "$NFT_LINK" > /dev/null <<'WRAPPER'
#!/bin/sh
exec env STORMWALL_TEST_MODE=1 /tmp/stormwall "$@"
WRAPPER
chmod +x "$NFT_LINK"
printf '[setup] wrapper installed\n'

###############################################################################
# Sample iptables ruleset used by translate tests
###############################################################################

SAMPLE_IPTABLES=$(cat <<'RULES'
*filter
:INPUT ACCEPT [0:0]
:FORWARD DROP [0:0]
:OUTPUT ACCEPT [0:0]
-A INPUT -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT
-A INPUT -p tcp --dport 22 -j ACCEPT
-A INPUT -j DROP
COMMIT
RULES
)

###############################################################################
# 1. iptables-translate / iptables-restore-translate
###############################################################################

log_tool "iptables-translate + iptables-restore-translate"

if command -v iptables-translate > /dev/null 2>&1 && \
   command -v iptables-restore-translate > /dev/null 2>&1; then

    # iptables-translate: translate a single rule to nft syntax
    translated=$(iptables-translate -A INPUT -p tcp --dport 80 -j ACCEPT 2>&1)
    rc=$?
    if [ $rc -ne 0 ]; then
        log_fail "iptables-translate returned $rc"
    else
        log_info "iptables-translate output: $translated"
        # Feed the translated snippet through the wrapper in check mode
        printf '%s\n' "$translated" | /usr/sbin/nft -c -f - 2>/tmp/cm-iptables-trans.log
        if [ $? -eq 0 ]; then
            log_pass "iptables-translate: wrapper accepts translated rule in -c mode"
        else
            log_fail "iptables-translate: wrapper rejected translated rule (see /tmp/cm-iptables-trans.log)"
        fi
    fi

    # iptables-restore-translate: translate a full ruleset file
    nft_ruleset=$(printf '%s\n' "$SAMPLE_IPTABLES" | iptables-restore-translate 2>/tmp/cm-ipt-restore.log)
    rc=$?
    if [ $rc -ne 0 ]; then
        log_fail "iptables-restore-translate returned $rc (see /tmp/cm-ipt-restore.log)"
    else
        log_info "iptables-restore-translate: $(printf '%s\n' "$nft_ruleset" | wc -l) lines of nft syntax"
        printf '%s\n' "$nft_ruleset" | /usr/sbin/nft -c -f - 2>/tmp/cm-ipt-nft-check.log
        if [ $? -eq 0 ]; then
            log_pass "iptables-restore-translate: wrapper accepts full translated ruleset in -c mode"
        else
            log_fail "iptables-restore-translate: wrapper rejected translated ruleset (see /tmp/cm-ipt-nft-check.log)"
        fi
    fi

else
    log_skip "iptables-translate / iptables-restore-translate not installed"
    log_skip "iptables-restore-translate (same package, skip together)"
fi

###############################################################################
# 2. fail2ban
###############################################################################

log_tool "fail2ban"

if command -v fail2ban-client > /dev/null 2>&1; then

    # Start fail2ban fresh under the wrapper
    systemctl stop fail2ban 2>/dev/null || true
    systemctl start fail2ban 2>/tmp/cm-fail2ban-start.log
    rc=$?
    if [ $rc -ne 0 ]; then
        log_fail "fail2ban start returned $rc (see /tmp/cm-fail2ban-start.log)"
    else
        # Give the daemon a moment to settle
        sleep 2

        if ! systemctl is-active --quiet fail2ban; then
            log_fail "fail2ban not active after start"
        else
            log_pass "fail2ban started under wrapper"

            # Reload config via client
            fail2ban-client reload > /tmp/cm-fail2ban-reload.log 2>&1
            if [ $? -eq 0 ]; then
                log_pass "fail2ban-client reload succeeded"
            else
                log_fail "fail2ban-client reload failed (see /tmp/cm-fail2ban-reload.log)"
            fi

            # Check sshd jail if it exists; degrade gracefully if not
            if fail2ban-client status sshd > /tmp/cm-fail2ban-sshd.log 2>&1; then
                log_pass "fail2ban-client status sshd: OK"
            else
                status_out=$(cat /tmp/cm-fail2ban-sshd.log)
                case "$status_out" in
                    *"No such jail"*|*"does not exist"*)
                        log_skip "fail2ban sshd jail not configured on this host"
                        ;;
                    *)
                        log_fail "fail2ban-client status sshd: $status_out"
                        ;;
                esac
            fi

            systemctl stop fail2ban 2>/dev/null || true
        fi
    fi

else
    log_skip "fail2ban not installed"
fi

###############################################################################
# 3. ufw
###############################################################################

log_tool "ufw"

if command -v ufw > /dev/null 2>&1; then

    ufw status numbered > /tmp/cm-ufw-status.log 2>&1
    rc=$?
    if [ $rc -eq 0 ]; then
        log_pass "ufw status numbered: OK"
    else
        log_fail "ufw status numbered returned $rc (see /tmp/cm-ufw-status.log)"
    fi

    # ufw reload if it is currently active (avoid inadvertently enabling it)
    ufw_state=$(ufw status 2>/dev/null | head -1)
    case "$ufw_state" in
        *active*)
            ufw reload > /tmp/cm-ufw-reload.log 2>&1
            if [ $? -eq 0 ]; then
                log_pass "ufw reload: OK"
            else
                log_fail "ufw reload failed (see /tmp/cm-ufw-reload.log)"
            fi
            ;;
        *)
            log_skip "ufw reload (ufw inactive — skipping reload to avoid side-effects)"
            ;;
    esac

else
    log_skip "ufw not installed"
fi

###############################################################################
# 4. firewalld (minimal subset — see tests/firewalld-smoke.sh for full suite)
###############################################################################

log_tool "firewalld (basic start/zone/stop)"

if command -v firewall-cmd > /dev/null 2>&1; then

    systemctl stop firewalld 2>/dev/null || true
    systemctl reset-failed firewalld 2>/dev/null || true

    systemctl start firewalld > /tmp/cm-firewalld-start.log 2>&1
    if [ $? -ne 0 ]; then
        log_fail "firewalld start returned non-zero (see /tmp/cm-firewalld-start.log)"
    else
        sleep 2
        if systemctl is-active --quiet firewalld; then
            log_pass "firewalld started under wrapper"

            firewall-cmd --get-default-zone > /tmp/cm-firewalld-zone.log 2>&1
            if [ $? -eq 0 ]; then
                log_pass "firewall-cmd --get-default-zone: $(cat /tmp/cm-firewalld-zone.log)"
            else
                log_fail "firewall-cmd --get-default-zone failed (see /tmp/cm-firewalld-zone.log)"
            fi

            systemctl stop firewalld 2>/dev/null || true
            log_pass "firewalld stopped"
        else
            log_fail "firewalld not active after start"
        fi
    fi

else
    log_skip "firewalld / firewall-cmd not installed"
fi

###############################################################################
# 5. conntrack (conntrack-tools)
###############################################################################

log_tool "conntrack"

if command -v conntrack > /dev/null 2>&1; then

    # conntrack uses libnetfilter_conntrack, NOT the nft CLI.  This test
    # verifies the wrapper doesn't disturb conntrack by running in the same
    # environment — conntrack -L should exit 0 (or 1 for "empty table").
    conntrack -L > /tmp/cm-conntrack.log 2>&1
    rc=$?
    case $rc in
        0|1)
            # rc=1 just means the conntrack table is empty — not an error.
            log_pass "conntrack -L exited $rc (wrapper environment did not break conntrack)"
            ;;
        *)
            log_fail "conntrack -L exited $rc (see /tmp/cm-conntrack.log)"
            ;;
    esac

else
    log_skip "conntrack not installed"
fi

###############################################################################
# 6. nerdctl / podman — container bridge networking
###############################################################################

log_tool "nerdctl / podman (container bridge networking)"

if command -v nerdctl > /dev/null 2>&1; then
    CTOOL=nerdctl
elif command -v podman > /dev/null 2>&1; then
    CTOOL=podman
else
    CTOOL=""
fi

if [ -n "$CTOOL" ]; then
    log_info "using container tool: $CTOOL"

    # Ensure a tiny image is available; alpine is far smaller than nginx.
    $CTOOL pull alpine:latest > /tmp/cm-ctool-pull.log 2>&1
    if [ $? -ne 0 ]; then
        log_fail "$CTOOL pull alpine failed (see /tmp/cm-ctool-pull.log)"
    else
        log_pass "$CTOOL pull alpine: OK"

        # Run detached container with bridge networking
        cid=$($CTOOL run --rm -d alpine:latest sleep 30 2>/tmp/cm-ctool-run.log)
        if [ $? -ne 0 ] || [ -z "$cid" ]; then
            log_fail "$CTOOL run alpine failed (see /tmp/cm-ctool-run.log)"
        else
            log_info "container id: $cid"

            # Verify the container appears in ps
            $CTOOL ps 2>/tmp/cm-ctool-ps.log | grep -q "$cid"
            if [ $? -eq 0 ]; then
                log_pass "$CTOOL ps lists running container"
            else
                log_fail "$CTOOL ps did not show container (see /tmp/cm-ctool-ps.log)"
            fi

            # Tear down
            $CTOOL stop "$cid" > /dev/null 2>&1 || true
            log_info "container stopped"
        fi
    fi

else
    log_skip "nerdctl and podman not installed"
fi

###############################################################################
# 7. kubectl — client version probe (kube-proxy uses nft; client is harmless)
###############################################################################

log_tool "kubectl"

if command -v kubectl > /dev/null 2>&1; then

    kubectl version --client > /tmp/cm-kubectl.log 2>&1
    if [ $? -eq 0 ]; then
        ver=$(head -1 /tmp/cm-kubectl.log)
        log_pass "kubectl version --client: $ver"
    else
        log_fail "kubectl version --client failed (see /tmp/cm-kubectl.log)"
    fi

else
    log_skip "kubectl not installed"
fi

###############################################################################
# 8. nft -f /etc/nftables.conf (ruleset file consumer)
###############################################################################

log_tool "nft -f /etc/nftables.conf (nftables-restore-style)"

if [ -f /etc/nftables.conf ]; then
    /usr/sbin/nft -c -f /etc/nftables.conf > /tmp/cm-nftables-conf.log 2>&1
    if [ $? -eq 0 ]; then
        log_pass "nft -c -f /etc/nftables.conf: OK"
    else
        log_fail "nft -c -f /etc/nftables.conf: failed (see /tmp/cm-nftables-conf.log)"
    fi
else
    log_skip "/etc/nftables.conf not present on this host"
fi

###############################################################################
# Summary
###############################################################################

printf '\n'
printf '===== consumer-matrix totals: PASS=%d  FAIL=%d  SKIP=%d =====\n' \
    "$total_pass" "$total_fail" "$total_skip"

if [ "$total_fail" -gt 0 ]; then
    exit 1
fi
exit 0
