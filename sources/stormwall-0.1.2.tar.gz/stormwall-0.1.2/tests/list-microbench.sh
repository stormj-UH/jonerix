#!/bin/bash
# list-microbench.sh — focused micro-benchmark for "list ruleset" latency
#
# Loads a single fixed ruleset (4 tables, ~20 chains, named set with 100
# prefixes, named map with 10 verdicts, ~50 rules) and times N=100 consecutive
# "list ruleset" calls for each backend.  Apply, flush, and sleep are excluded
# from every timing sample.
#
# Reports p50 / p90 / p99 in milliseconds and a ratio-to-nft column.  Also
# checks whether the constant overhead (sw_sample - nft_sample per rank) is
# flat across the run to detect warmup effects.
#
# Usage: list-microbench.sh [--nft PATH] [--sw PATH] [--n COUNT]
#
#   --nft PATH   path to nft binary     (default: /usr/sbin/nft)
#   --sw  PATH   path to stormwall      (default: /tmp/stormwall)
#   --n   COUNT  number of list samples (default: 100)

set -eu

NFT=/usr/sbin/nft
SW=/tmp/stormwall
N=100

while [ $# -gt 0 ]; do
    case "$1" in
        --nft) NFT=$2; shift 2 ;;
        --sw)  SW=$2;  shift 2 ;;
        --n)   N=$2;   shift 2 ;;
        --help|-h)
            grep '^#' "$0" | sed 's/^# \{0,1\}//'
            exit 0
            ;;
        *) printf 'Unknown option: %s\n' "$1" >&2; exit 1 ;;
    esac
done

# ── sanity ────────────────────────────────────────────────────────────────────
fail() { printf 'ERROR: %s\n' "$1" >&2; exit 1; }
[ -x "$NFT" ] || fail "nft not found or not executable: $NFT"
[ -x "$SW"  ] || fail "stormwall not found or not executable: $SW"

# ── temp dir + cleanup ────────────────────────────────────────────────────────
TMPDIR_MB=$(mktemp -d /tmp/list-microbench.XXXXXX)
cleanup() {
    "$NFT" flush ruleset >/dev/null 2>&1 || true
    "$SW"  flush ruleset >/dev/null 2>&1 || true
    rm -rf "$TMPDIR_MB"
}
trap cleanup EXIT INT TERM

# ── nanosecond clock ──────────────────────────────────────────────────────────
ns_now() { date +%s%N; }

# ── fixed ruleset ─────────────────────────────────────────────────────────────
# 4 tables, ~20 chains, named set with 100 /24 prefixes,
# named map with 10 ip→verdict entries, ~50 rules total.
# Hardcoded so every run sees an identical kernel object graph.
RULESET_FILE="$TMPDIR_MB/fixed.nft"
cat > "$RULESET_FILE" << 'RULESET_EOF'
flush ruleset

# ── table 1: filter (input/forward/output, ~20 rules) ────────────────────────
add table ip mb_filter
add set ip mb_filter blocklist { type ipv4_addr; flags interval; }
add element ip mb_filter blocklist { 10.0.0.0/24, 10.0.1.0/24, 10.0.2.0/24, 10.0.3.0/24, 10.0.4.0/24 }
add element ip mb_filter blocklist { 10.0.5.0/24, 10.0.6.0/24, 10.0.7.0/24, 10.0.8.0/24, 10.0.9.0/24 }
add element ip mb_filter blocklist { 10.0.10.0/24, 10.0.11.0/24, 10.0.12.0/24, 10.0.13.0/24, 10.0.14.0/24 }
add element ip mb_filter blocklist { 10.0.15.0/24, 10.0.16.0/24, 10.0.17.0/24, 10.0.18.0/24, 10.0.19.0/24 }
add element ip mb_filter blocklist { 10.0.20.0/24, 10.0.21.0/24, 10.0.22.0/24, 10.0.23.0/24, 10.0.24.0/24 }
add element ip mb_filter blocklist { 10.0.25.0/24, 10.0.26.0/24, 10.0.27.0/24, 10.0.28.0/24, 10.0.29.0/24 }
add element ip mb_filter blocklist { 10.0.30.0/24, 10.0.31.0/24, 10.0.32.0/24, 10.0.33.0/24, 10.0.34.0/24 }
add element ip mb_filter blocklist { 10.0.35.0/24, 10.0.36.0/24, 10.0.37.0/24, 10.0.38.0/24, 10.0.39.0/24 }
add element ip mb_filter blocklist { 10.0.40.0/24, 10.0.41.0/24, 10.0.42.0/24, 10.0.43.0/24, 10.0.44.0/24 }
add element ip mb_filter blocklist { 10.0.45.0/24, 10.0.46.0/24, 10.0.47.0/24, 10.0.48.0/24, 10.0.49.0/24 }
add element ip mb_filter blocklist { 10.0.50.0/24, 10.0.51.0/24, 10.0.52.0/24, 10.0.53.0/24, 10.0.54.0/24 }
add element ip mb_filter blocklist { 10.0.55.0/24, 10.0.56.0/24, 10.0.57.0/24, 10.0.58.0/24, 10.0.59.0/24 }
add element ip mb_filter blocklist { 10.0.60.0/24, 10.0.61.0/24, 10.0.62.0/24, 10.0.63.0/24, 10.0.64.0/24 }
add element ip mb_filter blocklist { 10.0.65.0/24, 10.0.66.0/24, 10.0.67.0/24, 10.0.68.0/24, 10.0.69.0/24 }
add element ip mb_filter blocklist { 10.0.70.0/24, 10.0.71.0/24, 10.0.72.0/24, 10.0.73.0/24, 10.0.74.0/24 }
add element ip mb_filter blocklist { 10.0.75.0/24, 10.0.76.0/24, 10.0.77.0/24, 10.0.78.0/24, 10.0.79.0/24 }
add element ip mb_filter blocklist { 10.0.80.0/24, 10.0.81.0/24, 10.0.82.0/24, 10.0.83.0/24, 10.0.84.0/24 }
add element ip mb_filter blocklist { 10.0.85.0/24, 10.0.86.0/24, 10.0.87.0/24, 10.0.88.0/24, 10.0.89.0/24 }
add element ip mb_filter blocklist { 10.0.90.0/24, 10.0.91.0/24, 10.0.92.0/24, 10.0.93.0/24, 10.0.94.0/24 }
add element ip mb_filter blocklist { 10.0.95.0/24, 10.0.96.0/24, 10.0.97.0/24, 10.0.98.0/24, 10.0.99.0/24 }
add map ip mb_filter verdicts { type ipv4_addr : verdict; }
add element ip mb_filter verdicts { 192.168.1.1 : accept, 192.168.1.2 : drop, 192.168.1.3 : accept, 192.168.1.4 : drop, 192.168.1.5 : accept }
add element ip mb_filter verdicts { 192.168.1.6 : drop, 192.168.1.7 : accept, 192.168.1.8 : drop, 192.168.1.9 : accept, 192.168.1.10 : drop }
add chain ip mb_filter input     { type filter hook input     priority 0;    policy drop;   }
add chain ip mb_filter forward   { type filter hook forward   priority 0;    policy drop;   }
add chain ip mb_filter output    { type filter hook output    priority 0;    policy accept; }
add chain ip mb_filter prerouting  { type filter hook prerouting  priority -100; }
add chain ip mb_filter postrouting { type filter hook postrouting priority 100;  }
add rule ip mb_filter input ip saddr @blocklist drop
add rule ip mb_filter input ip saddr vmap @verdicts
add rule ip mb_filter input ct state established,related accept
add rule ip mb_filter input ct state invalid drop
add rule ip mb_filter input icmp type echo-request limit rate 10/second accept
add rule ip mb_filter input tcp dport 22 accept
add rule ip mb_filter input tcp dport 80 accept
add rule ip mb_filter input tcp dport 443 accept
add rule ip mb_filter input tcp dport 8080 counter drop
add rule ip mb_filter input tcp dport 8443 counter drop
add rule ip mb_filter input udp dport 53 accept
add rule ip mb_filter input udp dport 123 accept
add rule ip mb_filter input tcp flags syn limit rate 100/second accept
add rule ip mb_filter input tcp flags & (fin|syn|rst|psh|ack|urg) == fin|psh|urg drop
add rule ip mb_filter forward ct state established,related accept
add rule ip mb_filter forward ip saddr 10.0.0.0/8 ip daddr 10.0.0.0/8 accept
add rule ip mb_filter output ct state established,related accept
add rule ip mb_filter output ip protocol tcp accept
add rule ip mb_filter output ip protocol udp accept
add rule ip mb_filter output ip protocol icmp accept

# ── table 2: nat ──────────────────────────────────────────────────────────────
add table ip mb_nat
add chain ip mb_nat prerouting  { type nat hook prerouting  priority -100; }
add chain ip mb_nat postrouting { type nat hook postrouting priority 100;  }
add chain ip mb_nat output      { type nat hook output      priority -100; }
add rule ip mb_nat prerouting  tcp dport 80  dnat to 10.0.0.1:8080
add rule ip mb_nat prerouting  tcp dport 443 dnat to 10.0.0.1:8443
add rule ip mb_nat postrouting ip saddr 10.0.0.0/8 masquerade
add rule ip mb_nat postrouting ip saddr 172.16.0.0/12 masquerade
add rule ip mb_nat postrouting ip daddr 8.8.8.8 snat to 203.0.113.1
add rule ip mb_nat postrouting ip daddr 8.8.4.4 snat to 203.0.113.1

# ── table 3: mangle ───────────────────────────────────────────────────────────
add table ip mb_mangle
add chain ip mb_mangle prerouting  { type filter hook prerouting  priority -150; }
add chain ip mb_mangle postrouting { type filter hook postrouting priority 150;  }
add chain ip mb_mangle input       { type filter hook input       priority -150; }
add chain ip mb_mangle output      { type route  hook output      priority -150; }
add chain ip mb_mangle forward     { type filter hook forward     priority -150; }
add rule ip mb_mangle prerouting tcp dport 80  meta mark set 0x00000001
add rule ip mb_mangle prerouting tcp dport 443 meta mark set 0x00000002
add rule ip mb_mangle prerouting udp dport 53  meta mark set 0x00000003
add rule ip mb_mangle prerouting ip protocol icmp meta mark set 0x00000004
add rule ip mb_mangle output     meta mark 0x00000001 meta priority set 0x00100010
add rule ip mb_mangle output     meta mark 0x00000002 meta priority set 0x00100020
add rule ip mb_mangle forward    ip ttl < 5 drop
add rule ip mb_mangle forward    ip ttl > 128 ip ttl set 128

# ── table 4: security ─────────────────────────────────────────────────────────
add table ip mb_security
add set ip mb_security trusted_hosts { type ipv4_addr; }
add element ip mb_security trusted_hosts { 203.0.113.10, 203.0.113.11, 203.0.113.12, 203.0.113.13, 203.0.113.14 }
add element ip mb_security trusted_hosts { 203.0.113.15, 198.51.100.1, 198.51.100.2, 198.51.100.3, 198.51.100.4 }
add chain ip mb_security input  { type filter hook input  priority 10; }
add chain ip mb_security output { type filter hook output priority 10; }
add rule ip mb_security input ip saddr @trusted_hosts accept
add rule ip mb_security input tcp dport { 22, 80, 443, 8080, 8443, 9090, 9443 } counter
add rule ip mb_security input tcp flags syn tcp dport != 0 limit rate 500/second accept
add rule ip mb_security input limit rate 10/second accept
add rule ip mb_security output ip daddr @trusted_hosts accept
add rule ip mb_security output tcp sport { 80, 443, 8080, 8443 } counter
RULESET_EOF

# ── apply the fixed ruleset under a given binary ─────────────────────────────
apply_ruleset() {
    local bin=$1
    "$bin" flush ruleset >/dev/null 2>&1 || true
    "$bin" -f "$RULESET_FILE" >/dev/null 2>&1
}

# ── time one "list ruleset" call, prints nanoseconds ─────────────────────────
time_list() {
    local bin=$1
    local t0 t1
    t0=$(ns_now)
    "$bin" list ruleset >/dev/null 2>&1
    t1=$(ns_now)
    printf '%s\n' "$((t1 - t0))"
}

# ── collect N timings with ruleset already loaded, newline-separated ns ints ──
collect_timings() {
    local bin=$1 count=$2
    local i=0
    while [ $i -lt "$count" ]; do
        time_list "$bin"
        i=$((i + 1))
    done
}

# ── statistics: p50/p90/p99 from newline-separated ns integers ───────────────
# Prints: p50_ms p90_ms p99_ms
stats_ms() {
    printf '%s\n' "$1" | grep -v '^$' | sort -n | awk '
    BEGIN { n = 0 }
    { samples[n++] = $1 }
    END {
        if (n == 0) { print "0 0 0"; exit }
        # p50 (median)
        if (n % 2 == 1) { p50 = samples[int(n/2)] }
        else            { p50 = (samples[n/2-1] + samples[n/2]) / 2 }
        # p90
        idx90 = int(n * 90 / 100)
        if (idx90 >= n) idx90 = n - 1
        p90 = samples[idx90]
        # p99
        idx99 = int(n * 99 / 100)
        if (idx99 >= n) idx99 = n - 1
        p99 = samples[idx99]
        printf "%d %d %d\n",
            int(p50/1000000),
            int(p90/1000000),
            int(p99/1000000)
    }'
}

# ── flatness check: compare first-quarter vs last-quarter median overhead ─────
# Prints a one-line verdict to stdout.
# $1 = newline-separated nft ns timings (sorted order preserved as-collected)
# $2 = newline-separated sw  ns timings
check_warmup() {
    local nft_raw=$1 sw_raw=$2
    printf '%s\n' "$nft_raw" "$sw_raw" | grep -v '^$' | awk -v n="$N" '
    BEGIN { ni = 0; si = 0 }
    NR <= n { nft[ni++] = $1; next }
    NR >  n { sw[si++]  = $1; next }
    END {
        if (ni == 0 || si == 0) { print "flatness: insufficient data"; exit }
        # quarter size
        q = int(ni / 4)
        if (q < 1) q = 1
        # first-quarter mean overhead
        sum_early = 0
        for (i = 0; i < q; i++) sum_early += (sw[i] - nft[i])
        mean_early = sum_early / q
        # last-quarter mean overhead
        sum_late = 0
        for (i = ni - q; i < ni; i++) sum_late += (sw[i] - nft[i])
        mean_late = sum_late / q
        # ratio: late/early
        if (mean_early <= 0) { print "flatness: early-mean=0, cannot compute"; exit }
        drift_pct = int(100 * (mean_late - mean_early) / mean_early)
        if (drift_pct < 0) drift_pct = -drift_pct
        if (drift_pct <= 15) {
            printf "overhead drift early->late: %d%% (FLAT — no warmup effect)\n", drift_pct
        } else {
            printf "overhead drift early->late: %d%% (NON-FLAT — warmup or jitter present)\n", drift_pct
        }
    }'
}

# ── ratio formatting (one decimal, e.g. "5.3x") ──────────────────────────────
fmt_ratio() {
    local nft_val=$1 sw_val=$2
    if [ "$nft_val" -le 0 ]; then
        printf '?.?x'
        return
    fi
    local rx
    rx=$(( (sw_val * 10) / nft_val ))
    printf '%d.%dx' "$((rx / 10))" "$((rx % 10))"
}

# ── ruleset description string ────────────────────────────────────────────────
RULESET_DESC="4tables/100setelems/50rules"

# ── main ─────────────────────────────────────────────────────────────────────
printf 'list-microbench: stormwall vs nft — list ruleset only\n'
printf 'nft=%s  sw=%s  N=%d\n' "$NFT" "$SW" "$N"
printf 'date=%s\n' "$(date -u '+%Y-%m-%dT%H:%M:%SZ')"
printf 'ruleset: %s\n' "$RULESET_DESC"
printf 'Timing window: list call only (apply+flush excluded)\n'
printf '\n'

# ── collect nft samples ───────────────────────────────────────────────────────
printf 'Collecting %d samples from nft...\n' "$N"
apply_ruleset "$NFT"
NFT_RAW=$(collect_timings "$NFT" "$N")
"$NFT" flush ruleset >/dev/null 2>&1 || true

read -r nft_p50 nft_p90 nft_p99 << EOF
$(stats_ms "$NFT_RAW")
EOF

# ── collect stormwall samples ─────────────────────────────────────────────────
printf 'Collecting %d samples from stormwall...\n' "$N"
apply_ruleset "$SW"
SW_RAW=$(collect_timings "$SW" "$N")
"$SW" flush ruleset >/dev/null 2>&1 || true

read -r sw_p50 sw_p90 sw_p99 << EOF
$(stats_ms "$SW_RAW")
EOF

# ── ratio columns ─────────────────────────────────────────────────────────────
ratio_p50=$(fmt_ratio "$nft_p50" "$sw_p50")
ratio_p90=$(fmt_ratio "$nft_p90" "$sw_p90")
ratio_p99=$(fmt_ratio "$nft_p99" "$sw_p99")

# ── output table ──────────────────────────────────────────────────────────────
printf '\n'
printf 'N=%-4d  ruleset: %s\n' "$N" "$RULESET_DESC"
printf '%-12s  %8s  %8s  %8s  %12s\n' \
    "binary" "p50_ms" "p90_ms" "p99_ms" "ratio_to_nft"
printf '%s\n' \
    "------------  --------  --------  --------  ------------"
printf '%-12s  %8d  %8d  %8d  %12s\n' \
    "nft" "$nft_p50" "$nft_p90" "$nft_p99" "1.00x"
printf '%-12s  %8d  %8d  %8d  %12s\n' \
    "stormwall" "$sw_p50" "$sw_p90" "$sw_p99" "$ratio_p50"

# ── constant-overhead flatness check ─────────────────────────────────────────
printf '\n--- constant-overhead analysis ---\n'
printf 'sw_p50 - nft_p50 = %dms per call\n' "$((sw_p50 - nft_p50))"
check_warmup "$NFT_RAW" "$SW_RAW"

printf '\ndone.\n'
