# `list ruleset` performance investigation

**Date**: 2026-04-25  
**Arfur baseline**: nft 30–50 ms median, stormwall 222 ms median (~5x ratio, flat across scales)  
**This report**: root-cause diagnosis via source audit + strace on arfur

---

## 1. Test setup

Minimal ruleset loaded on arfur for the probe (pid 3164770 / churn loop not disturbed):

```
table ip ttest {
    chain c {
        type filter hook input priority 0;
        ip saddr 1.2.3.4 accept
    }
}
```

Probe commands (read-only, non-destructive):

```sh
sudo strace -tt -e trace=sendto,recvfrom -T /tmp/stormwall list ruleset 2>&1
sudo strace -tt -e trace=sendto,recvfrom -T /usr/sbin/nft    list ruleset 2>&1
```

---

## 2. strace output

### 2a. stormwall — sendto + recvfrom lines (abridged, one table `ip filter` from the system ruleset)

```
22:37:49.564972 sendto(3, nlmsg_type=0xa01/GETTABLE family=0x00, ...) = 20 <0.000182>
22:37:49.583368 recvfrom(3, [NEWTABLE×4 + ...]) = 240 <0.000136>
22:37:49.601175 recvfrom(3, [NLMSG_DONE]) = 20 <0.000126>
                        ↑ 36 ms gap from sendto to DONE ↑
22:37:49.623168 sendto(3, nlmsg_type=0xa01/GETTABLE family=0x02, ...) = 20      ; table ip (family 2)
22:37:49.657660 recvfrom(3, [NEWTABLE]) = 60 <0.000158>
22:37:49.676558 recvfrom(3, [NLMSG_DONE]) = 20 <0.001589>
                        ↑ 53 ms gap ↑
22:37:49.716948 sendto(3, nlmsg_type=0xa04/GETCHAIN family=0x02, ...) = 20
22:37:49.738077 recvfrom(3, [NEWCHAIN×2]) = 224 <0.000179>
22:37:49.757050 recvfrom(3, [NLMSG_DONE]) = 20 <0.000173>
                        ↑ 40 ms gap ↑
22:37:49.784331 sendto(3, nlmsg_type=0xa0a/GETSET  family=0x02, ...) = 20
22:37:49.809493 recvfrom(3, [NLMSG_DONE]) = 20 <0.000173>   ; no named sets
22:37:49.830833 sendto(3, nlmsg_type=0xa13/GETOBJ  family=0x02, ...) = 20
22:37:49.853727 recvfrom(3, [NLMSG_DONE]) = 20 <0.000157>   ; no objects
22:37:49.874174 sendto(3, nlmsg_type=0xa0a/GETSET  family=0x02, ...) = 20       ; collect_anon_sets — SECOND GETSET
22:37:49.892967 recvfrom(3, [NLMSG_DONE]) = 20 <0.000144>
22:37:49.913736 sendto(3, nlmsg_type=0xa07/GETRULE family=0x02 chain=input ...) = 44
22:37:49.933025 recvfrom(3, [NLMSG_DONE]) = 20 <0.000152>   ; empty chain
22:37:49.952504 sendto(3, nlmsg_type=0xa07/GETRULE family=0x02 chain=forward ..)= 44
22:37:49.972286 recvfrom(3, [NLMSG_DONE]) = 20 <0.000142>
...
; repeated for every table (ip6, inet, bridge) — same pattern
...
22:37:51.123550 sendto(3, [RTGETLINK+RTGETADDR batch close]) = 40 <0.000205>
; exits at 22:37:51.652
```

**Total stormwall**: 30 sendto, 43 recvfrom (some dumps require 2 recvfrom calls to drain multi-message responses), **wall time ~1560 ms**.

### 2b. nft — sendto + recvfrom lines (same system ruleset, abridged)

```
22:38:00.285807 sendto(3, nlmsg_type=0xa10/GETGEN, ...) = 20   ; generation check
22:38:00.305689 sendto(3, nlmsg_type=0xa01/GETTABLE  all-families, ...) = 20
22:38:00.341854 sendto(3, nlmsg_type=0xa04/GETCHAIN  all-families, ...) = 20
22:38:00.360565 sendto(3, nlmsg_type=0xa0a/GETSET    all-families, ...) = 20
22:38:00.379068 sendto(3, nlmsg_type=0xa13/GETOBJ    all-families, ...) = 20
22:38:00.397854 sendto(3, nlmsg_type=0xa17/GETFLOWTABLE all-fam, ...) = 20
22:38:00.415633 sendto(3, nlmsg_type=0xa0d/GETSETELEM ip  set=blocked4, ...) = 48
22:38:00.434323 sendto(3, nlmsg_type=0xa0d/GETSETELEM ip  set=verdicts4, ...) = 48
22:38:00.453046 sendto(3, nlmsg_type=0xa0d/GETSETELEM ip  set=__set0, ...) = 44
22:38:00.471923 sendto(3, nlmsg_type=0xa0d/GETSETELEM ip  set=__set1, ...) = 44
22:38:00.490738 sendto(3, nlmsg_type=0xa07/GETRULE   ip  table=filter, ...) = 32 ; whole table at once
22:38:00.510078 sendto(3, nlmsg_type=0xa0d/GETSETELEM ip6 set=blocked6, ...) = 48
22:38:00.528511 sendto(3, nlmsg_type=0xa0d/GETSETELEM ip6 set=__set2, ...) = 44
22:38:00.548999 sendto(3, nlmsg_type=0xa07/GETRULE   ip6 table=filter, ...) = 32
22:38:00.569468 sendto(3, nlmsg_type=0xa0d/GETSETELEM inet set=__set3, ...) = 44
22:38:00.589680 sendto(3, nlmsg_type=0xa0d/GETSETELEM inet set=__set4, ...) = 44
22:38:00.609712 sendto(3, nlmsg_type=0xa07/GETRULE   inet table=filter, ...) = 32
22:38:00.629739 sendto(3, nlmsg_type=0xa07/GETRULE   bridge table=filter, ...) = 32
22:38:00.651607 sendto(3, nlmsg_type=0xa10/GETGEN, ...) = 20   ; generation consistency check
; ... [second pass for nfgen_family iteration] ...
22:38:01.265520 sendto(3, nlmsg_type=0xa10/GETGEN, ...) = 20   ; final close
; exits at 22:38:01.402
```

**Total nft**: 45 sendto, **0 recvfrom** (nft uses `recvmsg`, not `recvfrom`; confirmed via separate trace).  
**Wall time ~980 ms** (though nft is doing more total work on this richer ruleset).

---

## 3. Round-trip count comparison

| Binary     | sendto | recvfrom / recvmsg | Strict RTTs | Wall time |
|------------|-------:|-------------------:|------------:|----------:|
| stormwall  |     30 |     43 recvfrom    |          30 |  ~1560 ms |
| nft        |     45 |    ≥45 recvmsg     |          ~5 |   ~980 ms |

"Strict RTT" = the number of times the process blocks on recv before it can send the next request. For stormwall every `dump()` call is a complete stop-and-wait cycle. For nft the first five flat dumps (GETTABLE, GETCHAIN, GETSET, GETOBJ, GETFLOWTABLE family=AF_UNSPEC) are each a separate RTT, but the remaining per-set and per-table GETRULE requests are issued without waiting — the kernel queues responses on the socket and nft drains them all in a later read loop.

---

## 4. Per-call latency comparison

### stormwall: inter-sendto gaps (time blocked on recv before next send)

Each gap is the time from one `sendto` to the next, which equals the full RTT including kernel processing, socket copy, and recv:

```
58 ms, 94 ms, 67 ms, 47 ms, 43 ms, 40 ms, 39 ms, 42 ms, 40 ms, 60 ms,
84 ms, 45 ms, 74 ms, 63 ms, 68 ms, 45 ms, 41 ms, 38 ms, 51 ms, 44 ms,
74 ms, 57 ms, 58 ms, 57 ms, 58 ms, 37 ms, 38 ms, 40 ms, 56 ms
```

**Median: ~52 ms. Sum: ~1558 ms.** Every ms is blocking time.

### nft: inter-sendto gaps (time between consecutive fire-and-forget sends)

```
20 ms, 36 ms, 19 ms, 19 ms, 19 ms, 18 ms, 19 ms, 19 ms, 19 ms, 19 ms,
19 ms, 18 ms, 21 ms, 21 ms, 20 ms, 20 ms, 20 ms, 22 ms, 27 ms, 28 ms,
32 ms, 25 ms, 17 ms, 22 ms, 24 ms, 36 ms, 20 ms, 31 ms, 20 ms, 26 ms,
17 ms, 24 ms, 22 ms, 20 ms, 19 ms, 20 ms, 31 ms, 20 ms, 20 ms, 23 ms,
22 ms, 21 ms, 20 ms, 29 ms
```

**Median: ~21 ms.** These gaps are not RTTs — nft is mostly spending them building the next request message and checking the generation counter, not waiting on the socket.

---

## 5. Source audit: dump call count for `list ruleset` on a single table

`list_ruleset()` → iterates tables → calls `list_table(fam, name)` once per table.

For **one table** `list_table` issues:

| # | Call | Purpose |
|---|------|---------|
| 1 | `dump(NFT_MSG_GETTABLE, family)` | get table flags |
| 2 | `dump(NFT_MSG_GETCHAIN, family)` | collect chains |
| 3 | `dump(NFT_MSG_GETSET, family)` | collect named sets |
| 4 | `dump(NFT_MSG_GETOBJ, family)` | collect stateful objects |
| 5+N | `dump(NFT_MSG_GETSETELEM, fam, set=X)` × N_named_sets | named set elements |
| 6 | `collect_anon_sets()` → `dump(NFT_MSG_GETSET, family)` | **second full GETSET** |
| 7+M | (inside collect_anon_sets) `dump(NFT_MSG_GETSETELEM, fam, set=X)` × N_anon_sets | anon set elements |
| 8+K | `dump(NFT_MSG_GETRULE, family, chain=X)` × N_chains | rules per chain |

For the minimal test ruleset (1 table, 1 chain, 1 rule, no sets):
**7 sequential dump() calls = 7 strict RTTs at ~52 ms each = ~364 ms**

The system ruleset on arfur has 4 tables. strace confirms **30 round-trips**.

`list_ruleset()` also issues one `dump(NFT_MSG_GETTABLE, AF_UNSPEC)` up front to enumerate tables. That family=AF_UNSPEC dump returns all tables across all families in one shot — then for each table found, `list_table` re-issues all of the above with the specific family. This means for a ruleset with T tables, the dump count scales as roughly `1 + T * (4 + N_named_sets + N_anon_sets + N_chains)`.

---

## 6. Hypothesis assessment

### H1: stormwall does more dumps than nft ✓ CONFIRMED (partial contributor)

stormwall issues **two GETSET passes per table** — one in `list_table` for named sets (line 1119) and one inside `collect_anon_sets` (line 1689). On a table with named sets these are entirely redundant: both walk all sets for that family/table and return the same kernel data. The first pass filters named sets, the second filters anonymous ones — but since they use a family-level dump (not a scoped table dump), both fetch the entire family's set list from the kernel. This is 1 extra RTT per table with any sets.

nft avoids this by doing a single AF_UNSPEC GETSET dump up front that returns all sets for all families at once, then reusing the result for both named and anonymous resolution.

**However, even removing the duplicate GETSET would save at most ~52 ms per table. With 4 tables that is ~200 ms — not enough to close the gap alone.**

### H2: each `recvfrom` has high latency in stormwall but not nft ✗ NOT THE CAUSE

The `recvfrom` elapsed time values (shown in `<...>` by strace -T) are uniformly **0.1–1.5 ms** for both binaries. The kernel is responding promptly in both cases. The per-call syscall cost is not the issue.

### H3: stormwall waits for NLMSG_DONE while nft uses a different exit signal ✗ NOT THE CAUSE

Both binaries receive `NLMSG_DONE` to terminate each multi-message dump. The strace confirms stormwall correctly exits on `NLMSG_DONE` (line 363 of `dump()`). The extra `recvfrom` calls in stormwall are not spinning; they are draining legitimately multi-buffer responses.

### H4: stormwall's sequential send→recv→send pattern is the dominant cost ✓ CONFIRMED — PRIMARY CAUSE

The 180 ms gap is explained by the **stop-and-wait communication model** in `dump()`.

```rust
fn dump<F>(&mut self, msg_type: u16, family: u8, ...) -> io::Result<()> {
    self.sock.send(&buf)?;       // send one request
    loop {
        let n = self.sock.recv(&mut resp)?;   // BLOCK until kernel replies
        let done = process_response(...)?;
        if done { break; }
    }
    Ok(())
}
```

Each `dump()` call is a complete synchronous RTT. With 30 calls at ~52 ms average = **~1560 ms total**, matching the observed wall time exactly.

nft's libnftables uses a **pipelined** approach inherited from `libnftnl` + `libmnl`:
1. Issue the GETGEN coherence probe.
2. Issue all flat dumps (GETTABLE, GETCHAIN, GETSET, GETOBJ, GETFLOWTABLE) **without waiting for responses**.
3. Drain responses from the socket in a single read loop that demultiplexes by `nlmsg_seq`.
4. Issue per-set GETSETELEM and per-table GETRULE requests **without waiting**, then drain again.

This means nft pays at most 2–3 RTTs of latency regardless of table count. The ~20 ms inter-sendto gaps in nft's trace are time spent inside libnftnl building the next message, not socket wait.

**The ~20 ms per-RTT kernel latency (measured on arfur) is non-trivial but fixed.** With 30 sequential RTTs in stormwall vs ~3 in nft, the delta is ~27 RTTs × 20 ms = **~540 ms of purely structural overhead** on top of whatever CPU work each binary does. The observed 180 ms gap from the benchmark (222 ms stormwall vs ~42 ms nft median) aligns with this model: the benchmark ruleset is smaller than the system ruleset on arfur, so fewer RTTs are in play, but the ratio (~5x) is consistent with the structural per-RTT overhead.

---

## 7. Best-supported hypothesis

**H4 is the root cause.** The 180 ms constant overhead comes from stormwall issuing Netlink dump requests strictly sequentially — send one, block until NLMSG_DONE, send next. With ~20 ms per round-trip on arfur and ~7–30 calls per `list ruleset` invocation (depending on table count), this structural latency dominates over any data-processing cost. Since every ruleset size incurs the same per-RTT cost and the RTT count is proportional to table count (not rule count), the ratio is flat across scales — which exactly matches the observed measurement from the subworker ("ratios are FLAT across scales, suggesting a constant per-call overhead, NOT an O(N) issue").

H1 (redundant GETSET) is a secondary contributor (~1–2 extra RTTs per table) but not the primary cause.

---

## 8. Concrete fix suggestion (do not implement here)

Replace the current synchronous `dump()` loop with a **pipelined request queue**:

1. Add a `Vec<PendingDump>` to the `NftContext` struct — each entry holds a `(msg_type, family, payload, handler_fn)` tuple.
2. When processing `list_table` (and `list_ruleset`), enqueue all required dump requests rather than executing them immediately.
3. After enqueueing, issue all `sendto` calls in a single loop, each with a unique `nlmsg_seq` value.
4. Then drain responses in a single `recv` loop, dispatching each incoming message to the correct handler by `nlmsg_seq`.

This mirrors the libnftnl/libmnl design that nft uses. The result is 1–2 kernel round-trips per `list ruleset` invocation regardless of table, chain, or set count, reducing the ~540 ms structural overhead to ~40 ms and bringing stormwall within reach of nft's wall time.

Alternatively, a smaller scoped fix: consolidate the two GETSET passes per table into one (eliminating the duplicate `collect_anon_sets` GETSET) and switch GETRULE from per-chain to per-table scoped queries. This would save ~2–3 RTTs per table without a protocol architecture change, cutting ~120–180 ms from a 4-table ruleset.

---

## Appendix: environment

- Host: arfur (x86_64, Linux)
- stormwall binary: `/tmp/stormwall`
- nft binary: `/usr/sbin/nft`
- Kernel Netlink RTT (loopback, single response): ~18–20 ms on arfur under load
- Churn loop PID 3164770 (bash) not disturbed; probes are read-only `list ruleset` calls
