#!/bin/sh
# Exercise stormwall (via /usr/bin/nft symlink) as a drop-in nft replacement.
# Uses a dedicated `inet stormwall_test` table so the live tailscale rules
# aren't disturbed; cleans up at end. Each test prints PASS / FAIL /
# PARTIAL with the command tried.
set +e
PASS=0; FAIL=0; PARTIAL=0
NFT=/usr/bin/nft
TABLE="inet stormwall_test"

ok()   { printf "PASS: %s\n"    "$1"; PASS=$((PASS+1)); }
nope() { printf "FAIL: %s\n"    "$1"; FAIL=$((FAIL+1)); }
part() { printf "PART: %s\n"    "$1"; PARTIAL=$((PARTIAL+1)); }
hdr()  { printf "\n=== %s ===\n" "$1"; }

cleanup() { sudo $NFT "delete table $TABLE" >/dev/null 2>&1 || true; }
trap cleanup EXIT

cleanup  # in case a prior run left things

hdr "1. Version, help, dry-run"
$NFT --version 2>&1 | head -1
$NFT -V       2>&1 | head -3
sudo $NFT -c "add table $TABLE" && ok "-c dry-run for add table" || nope "-c dry-run for add table"
$NFT list tables >/dev/null 2>&1 | grep -q stormwall_test && nope "dry-run should not commit" || ok "dry-run did not commit"

hdr "2. Create table / chain / rule"
sudo $NFT "add table $TABLE"                                   && ok "add table"      || nope "add table"
sudo $NFT "add chain $TABLE c1 { type filter hook input priority 0 ; policy accept ; }" \
    && ok "add base chain" || nope "add base chain"
sudo $NFT "add rule $TABLE c1 ip saddr 10.0.0.99 counter accept" \
    && ok "add rule with counter" || nope "add rule with counter"

hdr "3. Check rule actually installed (round-trip readability)"
OUT=$(sudo $NFT list table $TABLE 2>&1)
echo "$OUT" | sed -n '1,20p'
echo "$OUT" | grep -q "ip saddr 10.0.0.99" && ok "saddr formatted correctly" || nope "saddr formatted correctly"
echo "$OUT" | grep -q "counter"           && ok "counter shown"             || nope "counter shown"

hdr "4. Numeric output (-n)"
sudo $NFT -n list table $TABLE 2>&1 | grep -q "10.0.0.99" && ok "-n output" || nope "-n output"

hdr "5. JSON output (-j)"
sudo $NFT -j list table $TABLE 2>&1 > /tmp/sw.json
if command -v python3 >/dev/null 2>&1; then
  python3 -c "import json,sys; json.load(open('/tmp/sw.json'))" 2>/dev/null \
    && ok "json valid" || nope "json valid"
else
  part "json valid (no python3 to verify)"
fi
grep -q '"chain"'                /tmp/sw.json && ok "json has chain key"  || nope "json has chain key"
grep -Eq '"nftables"|"rules"'    /tmp/sw.json && ok "json top-level"       || nope "json top-level"

hdr "6. Rule handles (-a)"
sudo $NFT -a list table $TABLE 2>&1 | grep -Eq "# handle [0-9]+" \
    && ok "rule handles" || nope "rule handles"

hdr "7. Sets"
sudo $NFT "add set $TABLE blocked { type ipv4_addr ; flags interval ; }" \
    && ok "add set with interval" || nope "add set with interval"
sudo $NFT "add element $TABLE blocked { 10.0.0.5, 10.0.0.6-10.0.0.8 }" \
    && ok "add set elements" || nope "add set elements"
sudo $NFT "add rule $TABLE c1 ip saddr @blocked counter drop" \
    && ok "rule references set" || nope "rule references set"

hdr "8. Interface-name match (KNOWN GAP from ruleset output)"
sudo $NFT "add rule $TABLE c1 iifname \"lo\" counter accept" 2>&1
sudo $NFT list table $TABLE 2>&1 | grep -q 'iifname "lo"' \
    && ok "iifname formatted" || nope "iifname formatted"

hdr "9. ct state match"
sudo $NFT "add rule $TABLE c1 ct state established,related counter accept" \
    && ok "ct state add"    || nope "ct state add"
sudo $NFT list table $TABLE 2>&1 | grep -q "ct state" \
    && ok "ct state listed" || nope "ct state listed"

hdr "10. Atomic transaction via -f"
cat > /tmp/sw-trans.nft <<'EOF'
flush table inet stormwall_test
table inet stormwall_test {
    chain c1 {
        type filter hook input priority 0; policy accept;
        ip saddr 10.1.1.1 drop
        ip saddr 10.1.1.2 drop
    }
}
EOF
sudo $NFT -f /tmp/sw-trans.nft && ok "nft -f script load" || nope "nft -f script load"
sudo $NFT list table $TABLE 2>&1 | grep -q "10.1.1.2" && ok "script applied" || nope "script applied"

hdr "11. Save-restore round trip"
sudo $NFT list table $TABLE > /tmp/sw-save.nft
sudo $NFT "flush table $TABLE"
sudo $NFT -f /tmp/sw-save.nft && ok "round-trip -f own output" || nope "round-trip -f own output"

hdr "12. Delete chain / rule by handle"
sudo $NFT "add rule $TABLE c1 ip saddr 10.1.1.2 drop" >/dev/null 2>&1
HANDLE=$(sudo $NFT -a list table $TABLE 2>&1 | grep "ip saddr 10.1.1.2" | \
         grep -oE "handle [0-9]+" | awk "{print \$2; exit}")
if [ -n "$HANDLE" ]; then
  sudo $NFT "delete rule $TABLE c1 handle $HANDLE" \
      && ok "delete rule by handle" || nope "delete rule by handle"
else
  nope "delete rule by handle (handle not found)"
fi

hdr "13. Flush / delete table"
sudo $NFT "flush table $TABLE"  && ok "flush table"  || nope "flush table"
sudo $NFT "delete table $TABLE" && ok "delete table" || nope "delete table"

hdr "14. JSON input (round-trip)"
sudo $NFT "add table $TABLE"                                     > /dev/null 2>&1
sudo $NFT "add chain $TABLE c1 { type filter hook input priority 0 ; }" > /dev/null 2>&1
sudo $NFT "add rule $TABLE c1 ip saddr 9.9.9.9 accept"           > /dev/null 2>&1
sudo $NFT -j list ruleset > /tmp/sw-rt.json
sudo $NFT -c -f /tmp/sw-rt.json 2>&1
if [ "$?" -eq 0 ]; then ok "nft -c -f <own json>"; else nope "nft -c -f <own json>"; fi
sudo $NFT "delete table $TABLE" > /dev/null 2>&1

hdr "RESULTS"
echo "PASS=$PASS FAIL=$FAIL PART=$PARTIAL"
