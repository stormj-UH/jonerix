#!/bin/bash
# container-net-smoke.sh — container runtime bridge/NAT smoke test against stormwall.
#
# Verifies that nerdctl/podman/docker continue to work when /usr/sbin/nft is
# replaced with a stormwall wrapper running under STORMWALL_TEST_MODE=1.
# Exercises the bridge-family nftables rules and DNAT-based port publishing that
# container runtimes rely on for veth-pair filtering and host-port forwarding.
#
# The test runs in two arms:
#   ARM A — wrapped: nft -> stormwall (STORMWALL_TEST_MODE=1)
#   ARM B — bare:    real nft, no wrapper
# Both arms must produce identical pass/fail outcomes, proving stormwall is
# byte-compatible enough that the container runtime does not notice the swap.
#
# Each step is PASS / FAIL / SKIP.  Totals are printed at the end.
# Exit code: 0 if every executed step passed, 1 otherwise.
#
# Usage: sudo tests/container-net-smoke.sh
#        (root needed for /usr/sbin/nft swap and container networking)
#
# Stormwall binary assumed at /tmp/stormwall (same as other test scripts).

set -u

SW=/tmp/stormwall
NFT_REAL=/usr/sbin/nft.real
NFT_LINK=/usr/sbin/nft

total_pass=0
total_fail=0
total_skip=0

# Containers started during the run — stopped on exit regardless of outcome.
STARTED_CONTAINERS=""

###############################################################################
# Output helpers
###############################################################################

log_step() { printf '\n[step] %s\n' "$1"; }
log_pass() { printf '    PASS: %s\n' "$1"; total_pass=$((total_pass + 1)); }
log_fail() { printf '    FAIL: %s\n' "$1"; total_fail=$((total_fail + 1)); }
log_skip() { printf '    SKIP: %s\n' "$1"; total_skip=$((total_skip + 1)); }
log_info() { printf '    info: %s\n' "$1"; }

###############################################################################
# Cleanup — runs on EXIT, INT, and TERM
#
# Stops any containers we started and restores the real nft binary.
# The wrapper is a regular file, not a symlink — so -e is the correct
# guard.  (Using -L was the v0 bug in firewalld-smoke.sh that made the
# trap a no-op and left /usr/sbin/nft pointing at the wrapper across runs.)
###############################################################################

cleanup() {
    # Stop containers we started, ignoring errors.
    for cname in $STARTED_CONTAINERS; do
        "$CTOOL" stop "$cname" > /dev/null 2>&1 || true
        "$CTOOL" rm -f "$cname" > /dev/null 2>&1 || true
    done

    # Restore the real nft binary if the wrapper is in place.
    if [ -e "$NFT_REAL" ]; then
        rm -f "$NFT_LINK"
        mv "$NFT_REAL" "$NFT_LINK"
        printf '    restored %s\n' "$NFT_LINK"
    fi
}
trap cleanup EXIT INT TERM

###############################################################################
# Step 0: detect container runtime
###############################################################################

log_step "Detect available container runtime"

if command -v nerdctl > /dev/null 2>&1; then
    CTOOL=nerdctl
elif command -v podman > /dev/null 2>&1; then
    CTOOL=podman
elif command -v docker > /dev/null 2>&1; then
    CTOOL=docker
else
    log_skip "no container runtime (nerdctl/podman/docker) found — nothing to test"
    printf '\n===== container-net-smoke totals: PASS=%d  FAIL=%d  SKIP=%d =====\n' \
        "$total_pass" "$total_fail" "$total_skip"
    exit 0
fi

log_info "runtime: $CTOOL ($(command -v "$CTOOL"))"

# Verify stormwall binary exists.
if [ ! -x "$SW" ]; then
    printf 'FATAL: stormwall binary not found at %s\n' "$SW" >&2
    exit 1
fi

# For nerdctl we need containerd to be running.
if [ "$CTOOL" = "nerdctl" ]; then
    if ! systemctl is-active --quiet containerd 2>/dev/null; then
        log_skip "nerdctl selected but containerd is not active — cannot run containers"
        printf '\n===== container-net-smoke totals: PASS=%d  FAIL=%d  SKIP=%d =====\n' \
            "$total_pass" "$total_fail" "$total_skip"
        exit 0
    fi
fi

###############################################################################
# install_wrapper / remove_wrapper helpers
###############################################################################

install_wrapper() {
    mv "$NFT_LINK" "$NFT_REAL"
    tee "$NFT_LINK" > /dev/null <<'WRAPPER'
#!/bin/sh
exec env STORMWALL_TEST_MODE=1 /tmp/stormwall "$@"
WRAPPER
    chmod +x "$NFT_LINK"
    log_info "wrapper installed at $NFT_LINK"
}

remove_wrapper() {
    if [ -e "$NFT_REAL" ]; then
        rm -f "$NFT_LINK"
        mv "$NFT_REAL" "$NFT_LINK"
        log_info "wrapper removed — real nft restored"
    fi
}

###############################################################################
# run_arm — execute the container smoke steps.
#
# Arguments:
#   $1  arm label string ("WRAPPED" or "BARE")
#
# Uses CTOOL from outer scope.
# Returns the number of failures recorded during this arm via arm_fail.
###############################################################################

arm_pass=0
arm_fail=0
arm_skip=0

arm_log_pass() { printf '    PASS: %s\n' "$1"; arm_pass=$((arm_pass + 1)); }
arm_log_fail() { printf '    FAIL: %s\n' "$1"; arm_fail=$((arm_fail + 1)); }
arm_log_skip() { printf '    SKIP: %s\n' "$1"; arm_skip=$((arm_skip + 1)); }

run_arm() {
    arm_label=$1
    arm_pass=0
    arm_fail=0
    arm_skip=0

    printf '\n########## ARM: %s ##########\n' "$arm_label"

    # --- Step A1: pull nginx:alpine (used for port-publish and exec tests) ---
    log_step "[$arm_label] A1: pull nginx:alpine"
    if "$CTOOL" pull nginx:alpine > /tmp/cns-pull.log 2>&1; then
        arm_log_pass "pulled nginx:alpine"
    else
        arm_log_fail "pull nginx:alpine failed (see /tmp/cns-pull.log)"
        # Nothing to test without the image — skip remaining arm steps.
        total_pass=$((total_pass + arm_pass))
        total_fail=$((total_fail + arm_fail))
        total_skip=$((total_skip + arm_skip))
        return
    fi

    # --- Step A2: run nginx:alpine with host-port publish (-p 8080:80) ---
    log_step "[$arm_label] A2: run tcs1 nginx:alpine -p 8080:80"
    # Use a unique per-arm name suffix to avoid collisions between the two arms.
    C1="tcs1_${arm_label}"
    STARTED_CONTAINERS="$STARTED_CONTAINERS $C1"

    "$CTOOL" run --rm -d --name "$C1" -p 8080:80 nginx:alpine \
        > /tmp/cns-run-c1.log 2>&1
    run_rc=$?
    if [ "$run_rc" -ne 0 ]; then
        arm_log_fail "run $C1 returned $run_rc (see /tmp/cns-run-c1.log)"
    else
        arm_log_pass "tcs1 started with -p 8080:80"

        # --- Step A3: probe host-port forwarding via curl ---
        log_step "[$arm_label] A3: curl http://127.0.0.1:8080 (DNAT port-publish)"
        # Give nginx a moment to be ready.
        sleep 2
        if command -v curl > /dev/null 2>&1; then
            curl_out=$(curl -s --max-time 3 http://127.0.0.1:8080 2>/tmp/cns-curl.log)
            curl_rc=$?
            if [ "$curl_rc" -eq 0 ] && printf '%s' "$curl_out" | grep -qi '<html\|nginx\|welcome'; then
                arm_log_pass "curl returned HTTP content from port-forwarded container"
            elif [ "$curl_rc" -eq 0 ]; then
                # Got a response; show first line for diagnostic but still pass —
                # the port-publish path is what we care about.
                first=$(printf '%s' "$curl_out" | head -1)
                arm_log_pass "curl got a response (first line: $first)"
            else
                arm_log_fail "curl failed (rc=$curl_rc, see /tmp/cns-curl.log)"
            fi
        else
            arm_log_skip "curl not installed — skipping port-publish probe"
        fi
    fi

    # --- Step A4: run a second container (no published port) ---
    log_step "[$arm_label] A4: run tcs2 nginx:alpine (bridge only)"
    C2="tcs2_${arm_label}"
    STARTED_CONTAINERS="$STARTED_CONTAINERS $C2"

    "$CTOOL" run --rm -d --name "$C2" nginx:alpine \
        > /tmp/cns-run-c2.log 2>&1
    run_rc=$?
    if [ "$run_rc" -ne 0 ]; then
        arm_log_fail "run $C2 returned $run_rc (see /tmp/cns-run-c2.log)"
    else
        arm_log_pass "tcs2 started"

        # --- Step A5: get tcs2 bridge IP via inspect ---
        log_step "[$arm_label] A5: inspect tcs2 bridge IP"

        # Different runtimes expose the IP at slightly different JSON paths.
        # Try the common Docker/nerdctl path first, then the podman network path.
        c2_ip=""
        if c2_ip=$("$CTOOL" inspect "$C2" \
            --format '{{range .NetworkSettings.Networks}}{{.IPAddress}}{{end}}' \
            2>/tmp/cns-inspect.log) && [ -n "$c2_ip" ]; then
            arm_log_pass "tcs2 IP: $c2_ip"
        elif c2_ip=$("$CTOOL" inspect "$C2" \
            --format '{{.NetworkSettings.IPAddress}}' \
            2>/tmp/cns-inspect2.log) && [ -n "$c2_ip" ]; then
            arm_log_pass "tcs2 IP (flat): $c2_ip"
        else
            arm_log_fail "could not determine tcs2 IP (see /tmp/cns-inspect.log)"
            c2_ip=""
        fi

        # --- Step A6: container-to-container reachability via exec + wget ---
        if [ -n "$c2_ip" ] && [ -n "$(printf '%s' "$C1" | grep -v '^$')" ]; then
            # Only meaningful if tcs1 is still running.
            if "$CTOOL" ps --format '{{.Names}}' 2>/dev/null | grep -q "$C1"; then
                log_step "[$arm_label] A6: exec tcs1 wget -> tcs2 ($c2_ip)"
                wget_out=$("$CTOOL" exec "$C1" \
                    wget -qO- "http://${c2_ip}/" 2>/tmp/cns-wget.log)
                wget_rc=$?
                if [ "$wget_rc" -eq 0 ] && printf '%s' "$wget_out" | grep -qi '<html\|nginx\|welcome'; then
                    arm_log_pass "container-to-container wget succeeded (bridge routing works)"
                elif [ "$wget_rc" -eq 0 ]; then
                    first=$(printf '%s' "$wget_out" | head -1)
                    arm_log_pass "container-to-container wget got a response (first: $first)"
                else
                    arm_log_fail "exec wget c2c failed rc=$wget_rc (see /tmp/cns-wget.log)"
                fi
            else
                arm_log_skip "tcs1 not running — skipping c2c exec step"
            fi
        else
            arm_log_skip "tcs2 IP unavailable — skipping c2c exec step"
        fi
    fi

    # --- Step A7: stop both containers ---
    log_step "[$arm_label] A7: stop tcs1 and tcs2"
    stop_ok=1
    for cname in "$C1" "$C2"; do
        if "$CTOOL" ps --format '{{.Names}}' 2>/dev/null | grep -q "$cname"; then
            "$CTOOL" stop "$cname" > /dev/null 2>&1
            stop_rc=$?
            "$CTOOL" rm -f "$cname" > /dev/null 2>&1 || true
            if [ "$stop_rc" -ne 0 ]; then
                stop_ok=0
            fi
        fi
        # Remove from STARTED_CONTAINERS so the EXIT trap doesn't double-stop.
        STARTED_CONTAINERS=$(printf '%s' "$STARTED_CONTAINERS" | \
            tr ' ' '\n' | grep -v "^${cname}$" | tr '\n' ' ')
    done
    if [ "$stop_ok" -eq 1 ]; then
        arm_log_pass "containers stopped and removed"
    else
        arm_log_fail "one or more containers failed to stop cleanly"
    fi

    # Accumulate into outer totals.
    total_pass=$((total_pass + arm_pass))
    total_fail=$((total_fail + arm_fail))
    total_skip=$((total_skip + arm_skip))
}

###############################################################################
# Snapshot real nft version (for parity comparison header)
###############################################################################

log_step "Snapshot real nft version before any swap"
real_nft_ver=$(/usr/sbin/nft --version 2>&1 || true)
log_info "real nft: $real_nft_ver"

###############################################################################
# ARM A — wrapped: nft -> stormwall STORMWALL_TEST_MODE=1
###############################################################################

log_step "Install nft -> stormwall wrapper"
install_wrapper

run_arm "WRAPPED"

wrapped_fail=$arm_fail

log_step "Remove wrapper after WRAPPED arm"
remove_wrapper

###############################################################################
# ARM B — bare: real nft, no wrapper
###############################################################################

run_arm "BARE"

bare_fail=$arm_fail

###############################################################################
# Parity assertion
#
# If both arms produced the same number of failures, stormwall is transparent.
###############################################################################

printf '\n########## PARITY CHECK ##########\n'
if [ "$wrapped_fail" -eq "$bare_fail" ]; then
    printf '    PASS: wrapped arm failures (%d) == bare arm failures (%d) — stormwall transparent\n' \
        "$wrapped_fail" "$bare_fail"
    total_pass=$((total_pass + 1))
else
    printf '    FAIL: wrapped arm failures (%d) != bare arm failures (%d) — stormwall introduced divergence\n' \
        "$wrapped_fail" "$bare_fail"
    total_fail=$((total_fail + 1))
fi

###############################################################################
# Summary
###############################################################################

printf '\n===== container-net-smoke totals: PASS=%d  FAIL=%d  SKIP=%d =====\n' \
    "$total_pass" "$total_fail" "$total_skip"

if [ "$total_fail" -gt 0 ]; then
    exit 1
fi
exit 0
