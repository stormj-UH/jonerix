#!/bin/bash
# iperf3-throughput.sh — throughput comparison harness: stormwall vs nft
#
# Pairs two network namespaces via a veth, applies identical rulesets to
# the server's input chain via each backend, runs a 10-second iperf3 TCP
# stream, and reports bits_per_second for both backends plus the ratio.
#
# The goal is to catch cases where stormwall's encoded ruleset generates a
# different kernel data-path (e.g. different set lookup strategy, incorrect
# interval flags) that results in material per-packet overhead even though
# the listed ruleset looks identical.
#
# Topology
#   tt_server  (10.97.0.1)  — receives traffic, holds nftables rules
#   tt_client  (10.97.0.2)  — generates traffic with iperf3 -c
#
# Prefix tt_* is fresh — tp_* = traffic-parity, tn_* = traffic-nat,
#                               tb_* = traffic-parity-bridge.
#
# Scenarios
#   1. baseline        — no rules; raw veth throughput ceiling
#   2. allow_ssh       — single tcp dport 22 accept rule (≈ traffic-parity 03)
#   3. interval_set    — 1000-element /24 interval set, ip saddr @set accept
#   4. vmap_50         — 50-entry named vmap, ip saddr vmap @vm
#   5. ct_state        — ct state established,related accept
#   6. chain_100       — 100-rule linear chain; accept only on last rule
#
# Usage: iperf3-throughput.sh [--nft PATH] [--sw PATH] [--duration SECS]
#        --nft      PATH   path to nft binary    (default: /usr/sbin/nft)
#        --sw       PATH   path to stormwall      (default: /tmp/stormwall)
#        --duration SECS   iperf3 test duration   (default: 10)
#
# Output shape (one line per scenario):
#   SCENARIO          nft_mbps=NNNN  sw_mbps=NNNN  ratio=N.NN [WARN]
#
# A WARN tag appears when the ratio deviates more than 5 % from 1.00 in
# either direction, indicating a measurable kernel-path difference.
#
# Prerequisites: iperf3, ip, nft, stormwall binary all present on the host.

set -u

# ── defaults ──────────────────────────────────────────────────────────────────
NFT=/usr/sbin/nft
SW=/tmp/stormwall
DURATION=10

# ── topology constants ────────────────────────────────────────────────────────
NS_S=tt_server
NS_C=tt_client
VETH_S=tts0
VETH_C=ttc0
IP_S=10.97.0.1
IP_C=10.97.0.2
IPERF_PORT=15201        # pick a port unlikely to conflict with other harnesses

# ── working dirs ──────────────────────────────────────────────────────────────
TMPDIR_TP=$(mktemp -d /tmp/iperf3-throughput.XXXXXX)

# ── parse args ────────────────────────────────────────────────────────────────
while [ $# -gt 0 ]; do
    case "$1" in
        --nft)      NFT=$2;      shift 2 ;;
        --sw)       SW=$2;       shift 2 ;;
        --duration) DURATION=$2; shift 2 ;;
        --help|-h)
            grep '^#' "$0" | sed 's/^# \{0,1\}//'
            exit 0
            ;;
        *) printf 'Unknown option: %s\n' "$1" >&2; exit 1 ;;
    esac
done

# ── teardown ──────────────────────────────────────────────────────────────────
teardown() {
    # kill any iperf3 server we started inside the server netns
    if [ -n "${IPERF_SERVER_PID:-}" ]; then
        sudo kill "$IPERF_SERVER_PID" 2>/dev/null || true
        unset IPERF_SERVER_PID
    fi
    sudo ip netns del "$NS_S" 2>/dev/null || true
    sudo ip netns del "$NS_C" 2>/dev/null || true
    # The veth root end is removed automatically when the netns is deleted,
    # but be defensive in case setup failed partway through.
    sudo ip link del "$VETH_S" 2>/dev/null || true
    rm -rf "$TMPDIR_TP"
}
trap teardown EXIT

# ── setup ─────────────────────────────────────────────────────────────────────
setup() {
    teardown 2>/dev/null || true
    # teardown removes TMPDIR_TP; recreate it so the pidfile path is valid.
    mkdir -p "$TMPDIR_TP"

    sudo ip netns add "$NS_S"
    sudo ip netns add "$NS_C"

    sudo ip link add "$VETH_S" type veth peer name "$VETH_C"
    sudo ip link set "$VETH_S" netns "$NS_S"
    sudo ip link set "$VETH_C" netns "$NS_C"

    sudo ip -n "$NS_S" addr add "$IP_S/24" dev "$VETH_S"
    sudo ip -n "$NS_C" addr add "$IP_C/24" dev "$VETH_C"
    sudo ip -n "$NS_S" link set "$VETH_S" up
    sudo ip -n "$NS_C" link set "$VETH_C" up
    sudo ip -n "$NS_S" link set lo up
    sudo ip -n "$NS_C" link set lo up

    # Confirm baseline reachability before going any further.
    if ! sudo ip netns exec "$NS_C" ping -c1 -W2 "$IP_S" >/dev/null 2>&1; then
        printf 'FATAL: tt_client cannot reach tt_server; bailing\n' >&2
        exit 1
    fi

    # Start a persistent iperf3 server inside the server netns.
    # -s -D forks to background; we capture the PID via the wrapper below.
    sudo ip netns exec "$NS_S" iperf3 -s -p "$IPERF_PORT" -D \
        --pidfile "$TMPDIR_TP/iperf3-server.pid" >/dev/null 2>&1
    # Give the daemon a moment to bind.
    sleep 0.4
    # Read back the PID so teardown can kill it cleanly.
    # The pidfile is written by iperf3 running as root, so read it with sudo.
    if sudo test -f "$TMPDIR_TP/iperf3-server.pid"; then
        IPERF_SERVER_PID=$(sudo cat "$TMPDIR_TP/iperf3-server.pid")
    fi
}

# ── ruleset generation ────────────────────────────────────────────────────────
gen_rules() {
    local d=$1
    mkdir -p "$d"

    # 1. Baseline — empty table, no input chain.  All traffic passes.
    cat > "$d/01_baseline.nft" <<'EOF'
add table ip filter
EOF

    # 2. Allow-SSH — single tcp dport 22 accept, policy drop.
    #    Traffic from tt_client hits iperf3 port, not 22, so the rule never
    #    matches; every iperf3 packet falls to the policy and is dropped.
    #    That is intentional: we want the firewall overhead of a rule that
    #    is evaluated but never matches, which is the common production case
    #    for rules that don't cover bulk-data ports.
    #    NOTE: to actually let iperf3 through we add an explicit accept for
    #    the iperf3 port so the test doesn't measure a fully-black-holed flow.
    cat > "$d/02_allow_ssh.nft" <<EOF
add table ip filter
add chain ip filter input { type filter hook input priority 0; policy drop; }
add rule ip filter input tcp dport 22 accept
add rule ip filter input tcp dport $IPERF_PORT accept
EOF

    # 3. 1000-element interval set.
    #    Build a /16 (10.0.0.0/16) decomposed into 1000 non-overlapping /24s
    #    (10.0.0.0/24 … 10.0.3.231/24 + gap, then 10.0.4.0/24 …).
    #    The client source is 10.97.0.2 — deliberately outside the set —
    #    so the lookup must walk the entire interval tree before falling
    #    through.  The explicit accept for the iperf3 source follows the set
    #    rule so all iperf3 traffic still passes.
    {
        printf 'add table ip filter\n'
        printf 'add set ip filter bigrange { type ipv4_addr; flags interval; }\n'
        # Generate 1000 /24 elements in the 10.0.0.0 – 10.3.231.0 space.
        local i=0 a b
        while [ "$i" -lt 1000 ]; do
            a=$(( i / 256 ))
            b=$(( i % 256 ))
            printf 'add element ip filter bigrange { 10.%d.%d.0/24 }\n' "$a" "$b"
            i=$((i + 1))
        done
        printf 'add chain ip filter input { type filter hook input priority 0; policy drop; }\n'
        printf 'add rule ip filter input ip saddr @bigrange accept\n'
        printf 'add rule ip filter input tcp dport %s accept\n' "$IPERF_PORT"
    } > "$d/03_interval_set.nft"

    # 4. 50-entry named vmap.
    #    Map 50 IP addresses (10.1.0.1–10.1.0.50) to accept; everything else
    #    falls through to the iperf3 explicit accept.  Client 10.97.0.2 is
    #    not in the vmap, so every packet does a full vmap lookup with no hit.
    {
        printf 'add table ip filter\n'
        printf 'add map ip filter verdict_map { type ipv4_addr : verdict; }\n'
        local j=1
        while [ "$j" -le 50 ]; do
            printf 'add element ip filter verdict_map { 10.1.0.%d : accept }\n' "$j"
            j=$((j + 1))
        done
        printf 'add chain ip filter input { type filter hook input priority 0; policy drop; }\n'
        printf 'add rule ip filter input ip saddr vmap @verdict_map\n'
        printf 'add rule ip filter input tcp dport %s accept\n' "$IPERF_PORT"
    } > "$d/04_vmap_50.nft"

    # 5. ct state established,related accept — canonical production first rule.
    #    The iperf3 flow is established after the first packet, so subsequent
    #    packets hit the ct state rule and are accepted there.  This exercises
    #    the conntrack lookup hot path, not chain traversal.
    cat > "$d/05_ct_state.nft" <<EOF
add table ip filter
add chain ip filter input { type filter hook input priority 0; policy drop; }
add rule ip filter input ct state established,related accept
add rule ip filter input tcp dport $IPERF_PORT ct state new accept
EOF

    # 6. 100-rule linear chain — nothing matches until the last rule.
    #    Rules 1–99 each test a distinct tcp dport that is never sent.
    #    Rule 100 accepts iperf3 traffic.  This is the worst case for chain
    #    traversal: every packet must evaluate 99 miss rules before accepting.
    {
        printf 'add table ip filter\n'
        printf 'add chain ip filter input { type filter hook input priority 0; policy drop; }\n'
        # Ports 10000–10098 are the 99 never-matching rules.
        local k=0
        while [ "$k" -lt 99 ]; do
            printf 'add rule ip filter input tcp dport %d accept\n' "$((10000 + k))"
            k=$((k + 1))
        done
        # Rule 100: the one that actually matches.
        printf 'add rule ip filter input tcp dport %s accept\n' "$IPERF_PORT"
    } > "$d/06_chain_100.nft"
}

# ── apply ruleset via a backend ───────────────────────────────────────────────
# Usage: apply_rules BIN RULES_FILE
apply_rules() {
    local bin=$1 rules=$2
    sudo ip netns exec "$NS_S" "$bin" flush ruleset 2>/dev/null || true
    sudo ip netns exec "$NS_S" "$bin" -f "$rules"
}

# ── run one iperf3 stream; prints bits_per_second as integer ──────────────────
# Usage: run_iperf  →  echoes throughput in bits/s
run_iperf() {
    local json out bps
    out=$(sudo ip netns exec "$NS_C" \
        iperf3 -c "$IP_S" -p "$IPERF_PORT" -t "$DURATION" -J 2>/dev/null)
    # iperf3 JSON: .end.sum_received.bits_per_second
    # Use awk to avoid requiring jq.
    bps=$(printf '%s\n' "$out" | awk '
        /"bits_per_second"/ {
            # The last occurrence is in .end.sum_received
            split($0, a, ":"); gsub(/[^0-9.]/, "", a[2]); last = a[2]
        }
        END { printf "%d\n", int(last + 0.5) }
    ')
    printf '%s\n' "${bps:-0}"
}

# ── bits/s → Mbps string ──────────────────────────────────────────────────────
to_mbps() {
    printf '%d\n' "$(( ${1:-0} / 1000000 ))"
}

# ── floating-point ratio via awk (no bc required) ─────────────────────────────
ratio_str() {
    local nft_bps=$1 sw_bps=$2
    awk -v n="$nft_bps" -v s="$sw_bps" 'BEGIN {
        if (n == 0) { printf "N/A"; exit }
        printf "%.2f", s / n
    }'
}

# ── print one result row ──────────────────────────────────────────────────────
print_result() {
    local label=$1 nft_bps=$2 sw_bps=$3
    local nft_m sw_m ratio warn=""

    nft_m=$(to_mbps "$nft_bps")
    sw_m=$(to_mbps  "$sw_bps")
    ratio=$(ratio_str "$nft_bps" "$sw_bps")

    # Warn if ratio deviates more than 5 % from 1.00 in either direction.
    warn=$(awk -v r="$ratio" 'BEGIN {
        if (r == "N/A") { print ""; exit }
        d = r - 1.0; if (d < 0) d = -d
        if (d > 0.05) print " [WARN]"
        else          print ""
    }')

    printf '%-20s  nft_mbps=%-6s  sw_mbps=%-6s  ratio=%s%s\n' \
        "$label" "$nft_m" "$sw_m" "$ratio" "$warn"
}

# ── main ──────────────────────────────────────────────────────────────────────
main() {
    local corpus="$TMPDIR_TP/rules"
    setup
    gen_rules "$corpus"

    printf 'iperf3 throughput comparison  nft vs stormwall  (duration=%ds)\n' \
        "$DURATION"
    printf 'netns: %s (%s) <-> %s (%s)\n\n' \
        "$NS_S" "$IP_S" "$NS_C" "$IP_C"

    # Column headers
    printf '%-20s  %-18s  %-16s  %s\n' \
        "scenario" "nft_mbps" "sw_mbps" "ratio"
    printf '%s\n' "$(printf '%0.s-' $(seq 1 72))"

    for scenario_def in \
        "01_baseline:baseline" \
        "02_allow_ssh:allow_ssh" \
        "03_interval_set:interval_set_1000" \
        "04_vmap_50:vmap_50" \
        "05_ct_state:ct_state" \
        "06_chain_100:chain_100"
    do
        rules_base="${scenario_def%%:*}"
        label="${scenario_def##*:}"
        rules_file="$corpus/${rules_base}.nft"

        # ---- nft run ----
        apply_rules "$NFT" "$rules_file"
        nft_bps=$(run_iperf)

        # ---- stormwall run ----
        apply_rules "$SW" "$rules_file"
        sw_bps=$(run_iperf)

        # Flush ruleset so no rules linger between scenarios.
        sudo ip netns exec "$NS_S" "$NFT" flush ruleset 2>/dev/null || true

        print_result "$label" "$nft_bps" "$sw_bps"
    done

    printf '\n'
    printf 'ratio = sw_mbps / nft_mbps.  Values outside [0.95, 1.05] are flagged [WARN].\n'
    printf 'A regression means stormwall'\''s encoded ruleset generates a different\n'
    printf 'kernel data-path even when the listing appears identical.\n'
}

main "$@"
