#!/bin/bash
# concurrent-writers.sh — concurrent-writer stress test for stormwall.
#
# Real production environments have multiple processes writing to nftables
# simultaneously (firewalld, fail2ban, kube-proxy, ufw, admin shells).
# The kernel netlink subsystem serialises writes, but the binary must handle
# EBUSY/EAGAIN gracefully rather than silently corrupting state or panicking.
#
# Two arms run sequentially (nft then stormwall) so the host kernel state
# is not shared across arms.  Each arm:
#   1. Spawns N_WORKERS (default 8) background worker processes.
#   2. Each worker runs ITERS_PER_WORKER (default 50) iterations of:
#        apply (5-rule chain) -> list -> flush
#      using a uniquely named table per worker per iteration:  tcw_w<WID>_<ITER>
#      so workers never conflict on the same object, exposing only the
#      genuine netlink-level serialisation contention.
#   3. Workers sleep a random 0-50 ms between iterations (via $RANDOM).
#   4. Each worker writes rc per iteration to /tmp/cw-<WID>.log for post-mortem.
#   5. After all workers finish the arm aggregates:
#        total ops, successes, EBUSY hits, other errors, timeouts
# The final report compares the two distributions.
#
# Error classification:
#   success  — exit 0
#   ebusy    — stderr contains "EBUSY" or "Resource busy" (errno 16)
#   eagain   — stderr contains "EAGAIN" or "try again" (errno 11)
#   timeout  — worker iteration exceeded OP_TIMEOUT_S seconds
#   other    — any other non-zero exit
#
# Namespace prefix: tcw_*  (no collision with tp_/tn_/tb_/tt_/tcs_)
#
# Usage: sudo bash tests/concurrent-writers.sh [n_workers [iters]]
#   n_workers  number of concurrent workers  (default 8)
#   iters      iterations per worker         (default 50)
#
# Requires: nft, /tmp/stormwall, bash ≥ 4 (process substitution + $RANDOM)

set -u

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
N_WORKERS=${1:-8}
ITERS_PER_WORKER=${2:-50}
OP_TIMEOUT_S=10         # wall-clock seconds before an iteration is declared hung
NFT=/usr/sbin/nft
SW=/tmp/stormwall
LOG=/tmp/cw-main.log
SUMMARY_CSV=/tmp/cw-summary.csv

# ---------------------------------------------------------------------------
# Cleanup
# ---------------------------------------------------------------------------
cleanup() {
    # Kill any workers that are still running (best-effort).
    local pids
    pids=$(jobs -p 2>/dev/null) || true
    if [ -n "$pids" ]; then
        # shellcheck disable=SC2086
        kill $pids 2>/dev/null || true
        # shellcheck disable=SC2086
        wait $pids 2>/dev/null || true
    fi
    # Flush any tables we may have left behind (pattern tcw_*).
    _nft_cleanup_tables "$NFT"  2>/dev/null || true
    _nft_cleanup_tables "$SW"   2>/dev/null || true
}

_nft_cleanup_tables() {
    local bin=$1
    # List table names matching tcw_, then delete each.
    sudo "$bin" list tables 2>/dev/null \
        | awk '/tcw_/{print $2, $3}' \
        | while read -r fam tbl; do
            sudo "$bin" delete table "$fam" "$tbl" 2>/dev/null || true
          done
}

trap cleanup EXIT

# ---------------------------------------------------------------------------
# Preflight
# ---------------------------------------------------------------------------
preflight() {
    local ok=1
    if ! command -v "$NFT" >/dev/null 2>&1; then
        printf 'FATAL: nft not found at %s\n' "$NFT" >&2; ok=0
    fi
    if [ ! -x "$SW" ]; then
        printf 'FATAL: stormwall binary not found/executable at %s\n' "$SW" >&2; ok=0
    fi
    if [ "$(id -u)" -ne 0 ] && ! sudo -n true 2>/dev/null; then
        printf 'FATAL: must run as root or have passwordless sudo\n' >&2; ok=0
    fi
    if [ "$ok" -eq 0 ]; then exit 1; fi
}

# ---------------------------------------------------------------------------
# Classify stderr output of a failed invocation.
# Prints one of: ebusy  eagain  timeout  other
# ---------------------------------------------------------------------------
classify_error() {
    local stderr_text=$1
    local timed_out=${2:-0}
    if [ "$timed_out" -eq 1 ]; then
        printf 'timeout'
        return
    fi
    case "$stderr_text" in
        *EBUSY*|*"Resource busy"*|*"resource busy"*)
            printf 'ebusy' ;;
        *EAGAIN*|*"try again"*|*"Try again"*)
            printf 'eagain' ;;
        *)
            printf 'other' ;;
    esac
}

# ---------------------------------------------------------------------------
# Single worker function — run inside a subshell via ( worker_fn ... ) &
#
# Arguments:
#   $1  WID      — worker index (0-based)
#   $2  BIN      — binary path (nft or stormwall)
#   $3  ARM      — arm label ("nft" or "sw") — used only in log messages
#   $4  WLOG     — per-worker log file path
# ---------------------------------------------------------------------------
worker_fn() {
    local WID=$1
    local BIN=$2
    local ARM=$3
    local WLOG=$4

    : > "$WLOG"
    printf '# worker %d  arm=%s  bin=%s  iters=%d\n' \
        "$WID" "$ARM" "$BIN" "$ITERS_PER_WORKER" >> "$WLOG"
    printf '# iter,op,rc,class,table\n' >> "$WLOG"

    local iter=0
    while [ "$iter" -lt "$ITERS_PER_WORKER" ]; do
        local TABLE="tcw_w${WID}_${iter}"

        # ----- apply --------------------------------------------------------
        local RULESET
        RULESET=$(printf 'table ip %s {
    chain input {
        type filter hook input priority 0; policy accept;
        ct state established,related counter accept
        tcp dport 22 counter accept
        tcp dport 80 counter accept
        tcp dport 443 counter accept
        udp dport 53 accept
    }
}' "$TABLE")

        local apply_err apply_rc timed_out apply_class
        apply_err=$(mktemp /tmp/cw-err-XXXXXX)

        # Run apply under a timeout; capture stderr for classification.
        timeout "$OP_TIMEOUT_S" \
            sudo "$BIN" -f - <<<"$RULESET" 2>"$apply_err"
        apply_rc=$?
        timed_out=0
        if [ "$apply_rc" -eq 124 ]; then timed_out=1; fi

        if [ "$apply_rc" -eq 0 ]; then
            apply_class=success
        else
            apply_class=$(classify_error "$(cat "$apply_err")" "$timed_out")
        fi
        printf '%d,apply,%d,%s,%s\n' "$iter" "$apply_rc" "$apply_class" "$TABLE" >> "$WLOG"
        rm -f "$apply_err"

        # Only list/flush if apply succeeded (table exists in kernel).
        if [ "$apply_rc" -eq 0 ]; then

            # ----- list -------------------------------------------------
            local list_err list_rc list_class
            list_err=$(mktemp /tmp/cw-err-XXXXXX)
            timeout "$OP_TIMEOUT_S" \
                sudo "$BIN" list table ip "$TABLE" 2>"$list_err"
            list_rc=$?
            timed_out=0
            if [ "$list_rc" -eq 124 ]; then timed_out=1; fi
            if [ "$list_rc" -eq 0 ]; then
                list_class=success
            else
                list_class=$(classify_error "$(cat "$list_err")" "$timed_out")
            fi
            printf '%d,list,%d,%s,%s\n' "$iter" "$list_rc" "$list_class" "$TABLE" >> "$WLOG"
            rm -f "$list_err"

            # ----- flush ------------------------------------------------
            local flush_err flush_rc flush_class
            flush_err=$(mktemp /tmp/cw-err-XXXXXX)
            timeout "$OP_TIMEOUT_S" \
                sudo "$BIN" delete table ip "$TABLE" 2>"$flush_err"
            flush_rc=$?
            timed_out=0
            if [ "$flush_rc" -eq 124 ]; then timed_out=1; fi
            if [ "$flush_rc" -eq 0 ]; then
                flush_class=success
            else
                flush_class=$(classify_error "$(cat "$flush_err")" "$timed_out")
            fi
            printf '%d,flush,%d,%s,%s\n' "$iter" "$flush_rc" "$flush_class" "$TABLE" >> "$WLOG"
            rm -f "$flush_err"
        fi

        # Random delay 0-50 ms between iterations.
        local delay_ms=$(( RANDOM % 51 ))
        if [ "$delay_ms" -gt 0 ]; then
            sleep "0.0${delay_ms}"
        fi

        iter=$((iter + 1))
    done

    printf '# done\n' >> "$WLOG"
}

# ---------------------------------------------------------------------------
# Aggregate per-worker logs for one arm into totals.
# Prints a summary block to stdout and appends a CSV row to SUMMARY_CSV.
# $1 = ARM label, $2 = array of log file paths (space-separated string)
# ---------------------------------------------------------------------------
aggregate_arm() {
    local arm=$1
    shift
    local logs="$*"

    local total_ops=0 total_success=0 total_ebusy=0 total_eagain=0
    local total_timeout=0 total_other=0

    for wlog in $logs; do
        [ -f "$wlog" ] || continue
        while IFS=, read -r _iter _op rc class _tbl; do
            # Skip comment/header lines
            case "$_iter" in
                '#'*) continue ;;
            esac
            total_ops=$((total_ops + 1))
            case "$class" in
                success) total_success=$((total_success + 1)) ;;
                ebusy)   total_ebusy=$((total_ebusy + 1))   ;;
                eagain)  total_eagain=$((total_eagain + 1)) ;;
                timeout) total_timeout=$((total_timeout + 1));;
                *)       total_other=$((total_other + 1))   ;;
            esac
        done < "$wlog"
    done

    printf '\n'
    printf '=== arm: %-6s =============================================\n' "$arm"
    printf '  total ops      : %d\n'  "$total_ops"
    printf '  success        : %d\n'  "$total_success"
    printf '  ebusy          : %d\n'  "$total_ebusy"
    printf '  eagain         : %d\n'  "$total_eagain"
    printf '  timeout        : %d\n'  "$total_timeout"
    printf '  other error    : %d\n'  "$total_other"
    if [ "$total_ops" -gt 0 ]; then
        local pct_ok=$(( total_success * 100 / total_ops ))
        printf '  success rate   : %d%%\n' "$pct_ok"
    fi
    printf '=========================================================\n'

    # Append CSV row for final comparison.
    printf '%s,%d,%d,%d,%d,%d,%d\n' \
        "$arm" \
        "$total_ops" "$total_success" "$total_ebusy" \
        "$total_eagain" "$total_timeout" "$total_other" \
        >> "$SUMMARY_CSV"
}

# ---------------------------------------------------------------------------
# Run one arm: spawn N_WORKERS in parallel, wait for all, aggregate.
# $1 = arm label ("nft" or "sw")
# $2 = binary path
# ---------------------------------------------------------------------------
run_arm() {
    local arm=$1
    local bin=$2

    printf '\n'
    printf '##############################################################\n'
    printf '## ARM: %-6s  binary: %s\n' "$arm" "$bin"
    printf '## workers=%d  iters_each=%d  timeout_per_op=%ds\n' \
        "$N_WORKERS" "$ITERS_PER_WORKER" "$OP_TIMEOUT_S"
    printf '## started: %s\n' "$(date)"
    printf '##############################################################\n'

    local wid=0
    local worker_pids=""
    local worker_logs=""

    while [ "$wid" -lt "$N_WORKERS" ]; do
        local wlog="/tmp/cw-${arm}-${wid}.log"
        worker_logs="$worker_logs $wlog"
        # Export worker_fn and its helpers into a subshell.
        ( worker_fn "$wid" "$bin" "$arm" "$wlog" ) &
        local wpid=$!
        worker_pids="$worker_pids $wpid"
        printf '[%s] spawned worker %d (pid %d) -> %s\n' \
            "$arm" "$wid" "$wpid" "$wlog" | tee -a "$LOG"
        wid=$((wid + 1))
    done

    # Wait for every worker; collect any non-zero exits for a summary.
    local failed_workers=0
    for pid in $worker_pids; do
        if ! wait "$pid"; then
            failed_workers=$((failed_workers + 1))
        fi
    done

    if [ "$failed_workers" -gt 0 ]; then
        printf '[%s] WARNING: %d worker process(es) exited non-zero\n' \
            "$arm" "$failed_workers" | tee -a "$LOG"
    fi

    printf '[%s] all workers done at %s\n' "$arm" "$(date)" | tee -a "$LOG"

    aggregate_arm "$arm" "$worker_logs" | tee -a "$LOG"

    # Flush any tables that survived (workers that timed out on flush).
    _nft_cleanup_tables "$bin" 2>/dev/null || true
}

# ---------------------------------------------------------------------------
# Final cross-arm comparison
# ---------------------------------------------------------------------------
compare_arms() {
    printf '\n'
    printf '##############################################################\n'
    printf '## CROSS-ARM COMPARISON\n'
    printf '##############################################################\n'
    printf 'arm,total_ops,success,ebusy,eagain,timeout,other\n'
    cat "$SUMMARY_CSV"
    printf '\n'

    # Parse both rows from the CSV.
    local nft_row sw_row
    nft_row=$(grep '^nft,' "$SUMMARY_CSV" | tail -1)
    sw_row=$(grep '^sw,'  "$SUMMARY_CSV" | tail -1)

    if [ -z "$nft_row" ] || [ -z "$sw_row" ]; then
        printf 'WARN: missing arm data in %s — skipping comparison\n' "$SUMMARY_CSV"
        return
    fi

    # IFS-split each row.
    IFS=, read -r _a1 nft_total nft_ok nft_busy nft_again nft_to nft_oth <<< "$nft_row"
    IFS=, read -r _a2  sw_total  sw_ok  sw_busy  sw_again  sw_to  sw_oth <<< "$sw_row"

    local pass=0 fail=0

    # --- Criterion 1: both arms processed the same number of apply ops ---
    # Expected: N_WORKERS * ITERS_PER_WORKER apply + list + flush = 3 * total
    # (list/flush skipped when apply fails, so sw_total ≤ nft_total is fine;
    #  we just verify neither is zero.)
    if [ "${nft_total:-0}" -gt 0 ] && [ "${sw_total:-0}" -gt 0 ]; then
        printf 'PASS: both arms recorded non-zero ops (nft=%d sw=%d)\n' \
            "$nft_total" "$sw_total"
        pass=$((pass + 1))
    else
        printf 'FAIL: one or both arms recorded zero ops (nft=%s sw=%s)\n' \
            "${nft_total:-0}" "${sw_total:-0}"
        fail=$((fail + 1))
    fi

    # --- Criterion 2: stormwall success rate >= nft success rate * 0.95 ---
    # Under contention stormwall may do marginally worse, but not catastrophically.
    if [ "${nft_total:-0}" -gt 0 ] && [ "${sw_total:-0}" -gt 0 ]; then
        local nft_pct sw_pct
        nft_pct=$(( nft_ok * 100 / nft_total ))
        sw_pct=$(( sw_ok * 100 / sw_total ))
        local threshold=$(( nft_pct * 95 / 100 ))
        printf 'success rate: nft=%d%%  sw=%d%%  threshold=%d%%\n' \
            "$nft_pct" "$sw_pct" "$threshold"
        if [ "$sw_pct" -ge "$threshold" ]; then
            printf 'PASS: stormwall success rate within 5%% of nft\n'
            pass=$((pass + 1))
        else
            printf 'FAIL: stormwall success rate (%d%%) more than 5%% below nft (%d%%)\n' \
                "$sw_pct" "$nft_pct"
            fail=$((fail + 1))
        fi
    fi

    # --- Criterion 3: no timeouts in either arm ---
    if [ "${nft_to:-0}" -eq 0 ] && [ "${sw_to:-0}" -eq 0 ]; then
        printf 'PASS: no hung operations in either arm\n'
        pass=$((pass + 1))
    else
        printf 'FAIL: hung operations detected — nft_timeout=%s sw_timeout=%s\n' \
            "${nft_to:-0}" "${sw_to:-0}"
        fail=$((fail + 1))
    fi

    # --- Criterion 4: stormwall EBUSY rate <= nft EBUSY rate + 5% of total ---
    # If stormwall is retrying internally (good), we see fewer EBUSY than nft.
    # If it is leaking them to the caller, we see more.
    if [ "${nft_total:-0}" -gt 0 ] && [ "${sw_total:-0}" -gt 0 ]; then
        local sw_busy_pct=$(( sw_busy * 100 / sw_total ))
        local nft_busy_pct=$(( nft_busy * 100 / nft_total ))
        local allowed_extra=5
        printf 'ebusy rate: nft=%d%%  sw=%d%%\n' "$nft_busy_pct" "$sw_busy_pct"
        if [ "$sw_busy_pct" -le $(( nft_busy_pct + allowed_extra )) ]; then
            printf 'PASS: stormwall EBUSY rate not materially higher than nft\n'
            pass=$((pass + 1))
        else
            printf 'FAIL: stormwall EBUSY rate (%d%%) exceeds nft (%d%%) by more than %d%%\n' \
                "$sw_busy_pct" "$nft_busy_pct" "$allowed_extra"
            fail=$((fail + 1))
        fi
    fi

    printf '\n'
    printf '=== TOTAL: PASS=%d  FAIL=%d ===\n' "$pass" "$fail"
    printf '\n'
    printf 'Per-worker logs: /tmp/cw-<arm>-<worker>.log\n'
    printf 'Main log:        %s\n' "$LOG"
    printf 'Summary CSV:     %s\n' "$SUMMARY_CSV"

    return "$fail"
}

# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
main() {
    : > "$LOG"
    printf 'arm,total_ops,success,ebusy,eagain,timeout,other\n' > "$SUMMARY_CSV"

    printf 'concurrent-writers started at %s  pid=%d\n' "$(date)" "$$" | tee -a "$LOG"
    printf 'config: workers=%d  iters_each=%d  op_timeout=%ds\n' \
        "$N_WORKERS" "$ITERS_PER_WORKER" "$OP_TIMEOUT_S" | tee -a "$LOG"
    printf 'estimated worst-case wall time: ~%d min\n' \
        $(( (ITERS_PER_WORKER * OP_TIMEOUT_S * 2) / 60 + 1 )) | tee -a "$LOG"

    preflight

    # ARM 1: nft (reference)
    run_arm nft "$NFT"

    # ARM 2: stormwall
    run_arm sw "$SW"

    # Cross-arm comparison and exit status
    compare_arms
}

main "$@"
