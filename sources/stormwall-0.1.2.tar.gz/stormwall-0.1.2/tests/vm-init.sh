#!/bin/sh
/bin/mount -t proc proc /proc
/bin/mount -t sysfs sys /sys
/bin/mount -t devtmpfs devtmpfs /dev 2>/dev/null
export PATH=/usr/bin:/usr/sbin:/bin:/sbin
export LD_LIBRARY_PATH=/lib:/usr/lib

KVER=$(uname -r)
MD=/lib/modules/$KVER
echo "Loading modules..."
load_mod() {
  f=$(busybox find $MD -name "$1.ko.gz" 2>/dev/null | busybox head -1)
  if [ -n "$f" ]; then busybox gunzip -c "$f" > /tmp/$1.ko 2>/dev/null; /bin/insmod /tmp/$1.ko 2>/dev/null && echo "  + $1" || echo "  x $1"; busybox rm -f /tmp/$1.ko; fi
}
load_mod nf_defrag_ipv4; load_mod nf_defrag_ipv6; load_mod nfnetlink
load_mod nf_conntrack; load_mod nf_nat; load_mod nf_tables
load_mod nft_ct; load_mod nft_counter; load_mod nft_chain_nat; load_mod nft_nat
load_mod nft_log; load_mod nft_limit; load_mod nft_masq
load_mod nf_reject_ipv4; load_mod nf_reject_ipv6; load_mod nft_reject; load_mod nft_reject_inet
echo ""

PASS=0; FAIL=0
ok() { echo "  PASS: $1"; PASS=$((PASS+1)); }
fail() { echo "  FAIL: $1 (exit $2)"; FAIL=$((FAIL+1)); }
run() { eval "$2" >/dev/null 2>&1; r=$?; [ $r -eq 0 ] && ok "$1" || fail "$1" $r; }

echo "=== stormwall Test Suite ==="
echo "Kernel: $KVER"
echo ""

# Table operations
echo "--- Tables ---"
run "add table"           "stormwall add table inet filter"
run "list tables"         "stormwall list tables"
echo ""

# Chain operations
echo "--- Chains ---"
run "add base chain"      "stormwall add chain inet filter input '{ type filter hook input priority filter; policy accept; }'"
run "add regular chain"   "stormwall add chain inet filter mychain"
run "rename chain"        "stormwall rename chain inet filter mychain newchain"
run "delete chain"        "stormwall delete chain inet filter newchain"
echo ""

# Rule expressions
echo "--- Rules ---"
run "ct state"            "stormwall add rule inet filter input ct state established,related accept"
run "ct state new"        "stormwall add rule inet filter input ct state new accept"
run "tcp dport"           "stormwall add rule inet filter input tcp dport 22 accept"
run "tcp dport 80"        "stormwall add rule inet filter input tcp dport 80 accept"
run "tcp dport 443"       "stormwall add rule inet filter input tcp dport 443 accept"
run "ip saddr CIDR"       "stormwall add rule inet filter input ip saddr 10.0.0.0/8 drop"
run "counter drop"        "stormwall add rule inet filter input counter drop"
run "insert rule"         "stormwall insert rule inet filter input tcp dport 8080 accept"
run "log prefix"          "stormwall add rule inet filter input log prefix 'test: ' accept"
echo ""

# Set operations
echo "--- Sets ---"
run "add set"             "stormwall add set inet filter blocklist '{ type ipv4_addr; }'"
run "add elements"        "stormwall add element inet filter blocklist '{ 192.168.1.1, 10.0.0.1 }'"
run "delete element"      "stormwall delete element inet filter blocklist '{ 10.0.0.1 }'"
run "delete set"          "stormwall delete set inet filter blocklist"
echo ""

# List operations
echo "--- List ---"
run "list ruleset"        "stormwall list ruleset"
run "list table"          "stormwall list table inet filter"
run "list chain"          "stormwall list chain inet filter input"
run "list chains"         "stormwall list chains"
run "list with handles"   "stormwall -a list ruleset"
run "stateless list"      "stormwall -s list ruleset"
echo ""

# Verify with real nft if available
if command -v nft >/dev/null 2>&1; then
  echo "--- Cross-verify with nft ---"
  run "nft list ruleset"  "nft list ruleset"
  echo ""
fi

# Show final ruleset
echo "--- Final ruleset ---"
stormwall list ruleset
echo ""

# Flush operations
echo "--- Flush ---"
run "flush chain"         "stormwall flush chain inet filter input"
run "flush table"         "stormwall flush table inet filter"
run "flush ruleset"       "stormwall flush ruleset"
echo ""

echo "=== RESULTS: $PASS passed, $FAIL failed ==="
[ $FAIL -eq 0 ] && echo "ALL TESTS PASSED" || echo "SOME TESTS FAILED"
/bin/poweroff -f
