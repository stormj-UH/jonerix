#!/bin/bash
# Fuzz parity harness: generate N random nftables rulesets, apply each
# through both nft and stormwall, and report any divergence in:
#   - apply return code  (one accepts, the other rejects)
#   - post-apply listing (round-trip text differs after sanitising)
#
# Usage:
#   fuzz-parity.sh [--count N] [--seed S]
#
# Defaults: 100 iterations, seed = current epoch.
#
# For each FAIL the ruleset is saved to /tmp/fuzz-parity/fail-{n}.nft
# and a unified diff to /tmp/fuzz-parity/fail-{n}.diff.

set -u

NFT=/usr/sbin/nft
SW=/tmp/stormwall
OUTDIR=/tmp/fuzz-parity
COUNT=100
SEED=

# ---------------------------------------------------------------------------
# Argument parsing
# ---------------------------------------------------------------------------
while [ $# -gt 0 ]; do
    case "$1" in
        --count) COUNT=$2; shift 2 ;;
        --seed)  SEED=$2;  shift 2 ;;
        *) printf 'fuzz-parity: unknown option: %s\n' "$1" >&2; exit 1 ;;
    esac
done

[ -z "$SEED" ] && SEED=$(date +%s)

# ---------------------------------------------------------------------------
# Seeded PRNG (lcg — no bashism, pure arithmetic)
# ---------------------------------------------------------------------------
_RNG_STATE=$SEED

rng() {
    # Returns a pseudo-random integer in [0, $1).
    # LCG constants from Knuth vol 2.
    _RNG_STATE=$(( (_RNG_STATE * 6364136223846793005 + 1442695040888963407) & 0x7fffffffffffffff ))
    printf '%d\n' $(( _RNG_STATE % $1 ))
}

pick() {
    # pick <array_element>...  — print one element at random.
    local n=$#
    local i
    i=$(rng "$n")
    shift "$i"
    printf '%s\n' "$1"
}

# ---------------------------------------------------------------------------
# Random-value generators
# ---------------------------------------------------------------------------

rand_ipv4() {
    local a b c d
    a=$(rng 256); b=$(rng 256); c=$(rng 256); d=$(rng 256)
    printf '%d.%d.%d.%d\n' "$a" "$b" "$c" "$d"
}

rand_port() {
    # Avoid privileged ports to reduce noise from dport-0 edge cases.
    printf '%d\n' $(( $(rng 64511) + 1024 ))
}

rand_hex8() {
    printf '0x%08x\n' "$(rng 4294967295)"
}

# ---------------------------------------------------------------------------
# Ruleset generator
#
# Variables used as "registers" between generator functions:
#   _TBL_LIST   — space-separated "family:name" pairs for tables created
#   _SET_LIST   — space-separated "family:table:setname" triples
#   _CHAIN_LIST — space-separated "family:table:chainname" triples
# ---------------------------------------------------------------------------

gen_ruleset() {
    # Accumulate the ruleset text in $_RS
    _RS=''
    _TBL_LIST=''
    _SET_LIST=''
    _CHAIN_LIST=''

    # 1-3 tables
    local ntables
    ntables=$(( $(rng 3) + 1 ))
    local ti
    for ti in $(seq 1 "$ntables"); do
        _gen_table
    done
}

_gen_table() {
    local family
    family=$(pick ip ip6 inet)
    # Table names t1..t9; reuse avoidance not required — kernel merges them.
    local tname
    tname="t$(( $(rng 9) + 1 ))"

    _RS="${_RS}add table ${family} ${tname}
"
    _TBL_LIST="${_TBL_LIST} ${family}:${tname}"

    # 0-2 named sets (must come before rules that reference them)
    local nsets
    nsets=$(rng 3)
    local si
    for si in $(seq 1 "$nsets"); do
        _gen_named_set "$family" "$tname"
    done

    # 0-3 chains
    local nchains
    nchains=$(rng 4)
    local ci
    for ci in $(seq 1 "$nchains"); do
        _gen_chain "$family" "$tname"
    done
}

_gen_named_set() {
    local family=$1 tname=$2
    # Only ip/inet sets for ipv4_addr to keep rule grammar consistent.
    [ "$family" = "ip6" ] && return 0

    local sname
    sname="s$(( $(rng 9) + 1 ))"
    _RS="${_RS}add set ${family} ${tname} ${sname} { type ipv4_addr; }
"
    # Seed 1-3 random elements
    local nelems
    nelems=$(( $(rng 3) + 1 ))
    local elem_list=''
    local ei
    for ei in $(seq 1 "$nelems"); do
        local ip
        ip=$(rand_ipv4)
        if [ -z "$elem_list" ]; then
            elem_list="$ip"
        else
            elem_list="${elem_list}, ${ip}"
        fi
    done
    _RS="${_RS}add element ${family} ${tname} ${sname} { ${elem_list} }
"
    _SET_LIST="${_SET_LIST} ${family}:${tname}:${sname}"
}

_gen_chain() {
    local family=$1 tname=$2
    local cname
    cname="c$(( $(rng 9) + 1 ))"

    # Decide: base chain or regular chain?
    local is_base
    is_base=$(rng 2)

    if [ "$is_base" -eq 1 ]; then
        local hook priority
        hook=$(pick input forward output)
        # nat hook only for ip/ip6, and nat chains need type nat.
        # Keep it simple: only type filter for fuzz purposes.
        priority=$(pick "0" "filter" "-200" "100")
        _RS="${_RS}add chain ${family} ${tname} ${cname} { type filter hook ${hook} priority ${priority}; }
"
    else
        _RS="${_RS}add chain ${family} ${tname} ${cname}
"
    fi

    _CHAIN_LIST="${_CHAIN_LIST} ${family}:${tname}:${cname}"

    # 0-5 rules
    local nrules
    nrules=$(rng 6)
    local ri
    for ri in $(seq 1 "$nrules"); do
        _gen_rule "$family" "$tname" "$cname"
    done
}

_gen_rule() {
    local family=$1 tname=$2 cname=$3

    local match
    match=$(_gen_match "$family" "$tname")
    local verdict
    verdict=$(_gen_verdict)

    _RS="${_RS}add rule ${family} ${tname} ${cname} ${match} ${verdict}
"
}

_gen_match() {
    local family=$1 tname=$2

    # For ip6 tables, limit to non-ipv4 matches to avoid syntax errors.
    local choice
    if [ "$family" = "ip6" ]; then
        choice=$(rng 4)   # 0-3: tcp dport / udp dport / icmp(v6) type / ct state
    else
        choice=$(rng 8)   # 0-7: full vocabulary
    fi

    case "$choice" in
        0)
            local port
            port=$(rand_port)
            printf 'tcp dport %d' "$port"
            ;;
        1)
            local port
            port=$(rand_port)
            printf 'udp dport %d' "$port"
            ;;
        2)
            if [ "$family" = "ip6" ]; then
                printf 'icmpv6 type echo-request'
            else
                printf 'icmp type echo-request'
            fi
            ;;
        3)
            printf 'ct state established,related'
            ;;
        4)
            # ip saddr single address
            local ip
            ip=$(rand_ipv4)
            printf 'ip saddr %s' "$ip"
            ;;
        5)
            # meta mark
            local h
            h=$(rand_hex8)
            printf 'meta mark %s' "$h"
            ;;
        6)
            # ip saddr anon set (2-5 entries)
            local n
            n=$(( $(rng 4) + 2 ))
            local entries=''
            local ei
            for ei in $(seq 1 "$n"); do
                local ip
                ip=$(rand_ipv4)
                if [ -z "$entries" ]; then
                    entries="$ip"
                else
                    entries="${entries}, ${ip}"
                fi
            done
            printf 'ip saddr { %s }' "$entries"
            ;;
        7)
            # ip saddr @named_set — only if one exists for this table
            local candidate=''
            local tok
            for tok in $_SET_LIST; do
                local sf st ss
                sf=$(printf '%s' "$tok" | cut -d: -f1)
                st=$(printf '%s' "$tok" | cut -d: -f2)
                ss=$(printf '%s' "$tok" | cut -d: -f3)
                if [ "$sf" = "$family" ] && [ "$st" = "$tname" ]; then
                    candidate="$ss"
                    break
                fi
            done
            if [ -n "$candidate" ]; then
                printf 'ip saddr @%s' "$candidate"
            else
                # Fallback: plain tcp dport match
                local port
                port=$(rand_port)
                printf 'tcp dport %d' "$port"
            fi
            ;;
    esac
}

_gen_verdict() {
    pick "accept" "drop" "counter accept" "log accept"
}

# ---------------------------------------------------------------------------
# Apply + list helpers
# ---------------------------------------------------------------------------

_apply_and_list() {
    local bin=$1 rulefile=$2 rc_var=$3 listing_var=$4

    sudo "$bin" flush ruleset 2>/dev/null || true

    local apply_out
    apply_out=$(sudo "$bin" -f "$rulefile" 2>&1)
    local rc=$?

    local listing=''
    if [ "$rc" -eq 0 ]; then
        listing=$(sudo "$bin" list ruleset 2>&1)
    fi

    sudo "$bin" flush ruleset 2>/dev/null || true

    # Use indirect assignment via printf + eval (bash, so eval is fine here)
    eval "${rc_var}=$rc"
    # Store listing in a temp file path passed back — use nameref workaround
    # via a global temp dir slot instead.
    printf '%s' "$listing" > "${_TMPDIR}/${listing_var}"
}

# Sanitise a listing for comparison — strip handle numbers and kernel-assigned
# anonymous set names so only structural differences trigger a FAIL.
_sanitise() {
    sed -E \
        -e 's/__set[0-9]+/__setN/g' \
        -e 's/__map[0-9]+/__mapN/g' \
        -e 's/ handle [0-9]+//g' \
        -e 's/# handle [0-9]+//g' \
        "$1"
}

# ---------------------------------------------------------------------------
# Churn-loop pause/resume (mirror monitor-diff.sh)
# ---------------------------------------------------------------------------

_pause_churn() {
    _CHURN_PIDS=$(pgrep -x -f "bash /tmp/churn-loop.sh 86400" 2>/dev/null || true)
    if [ -n "$_CHURN_PIDS" ]; then
        printf 'fuzz-parity: pausing churn loop pids: %s\n' "$_CHURN_PIDS"
        # shellcheck disable=SC2086
        sudo kill -STOP $_CHURN_PIDS 2>/dev/null || true
    fi
}

_resume_churn() {
    if [ -n "${_CHURN_PIDS:-}" ]; then
        # shellcheck disable=SC2086
        sudo kill -CONT $_CHURN_PIDS 2>/dev/null || true
    fi
}

# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

main() {
    mkdir -p "$OUTDIR"
    _TMPDIR=$(mktemp -d /tmp/fuzz-parity-work.XXXXXX)
    trap 'rm -rf "$_TMPDIR"; _resume_churn' EXIT

    _pause_churn

    printf 'fuzz-parity: %d iterations, seed=%s\n' "$COUNT" "$SEED"

    local pass=0 fail=0 fail_n=0

    local i
    for i in $(seq 1 "$COUNT"); do
        # Generate a fresh ruleset
        gen_ruleset
        local rulefile="${_TMPDIR}/iter-${i}.nft"
        printf '%s' "$_RS" > "$rulefile"

        # --- nft arm ---
        local nft_rc sw_rc
        _apply_and_list "$NFT" "$rulefile" nft_rc nft_listing

        # --- stormwall arm ---
        _apply_and_list "$SW" "$rulefile" sw_rc sw_listing

        # Sanitise listings for comparison
        local nft_norm="${_TMPDIR}/nft-${i}.norm"
        local sw_norm="${_TMPDIR}/sw-${i}.norm"
        _sanitise "${_TMPDIR}/nft_listing" > "$nft_norm"
        _sanitise "${_TMPDIR}/sw_listing"  > "$sw_norm"

        # Check for divergence
        local rc_mismatch=0 listing_mismatch=0 diff_out=''
        [ "$nft_rc" -ne "$sw_rc" ] && rc_mismatch=1

        if [ "$nft_rc" -eq 0 ] && [ "$sw_rc" -eq 0 ]; then
            diff_out=$(diff -u "$nft_norm" "$sw_norm" 2>&1 || true)
            [ -n "$diff_out" ] && listing_mismatch=1
        fi

        if [ "$rc_mismatch" -eq 1 ] || [ "$listing_mismatch" -eq 1 ]; then
            fail=$((fail + 1))
            fail_n=$((fail_n + 1))

            local fail_nft="${OUTDIR}/fail-${fail_n}.nft"
            local fail_diff="${OUTDIR}/fail-${fail_n}.diff"
            cp "$rulefile" "$fail_nft"

            {
                printf '# iter=%d  nft_rc=%d  sw_rc=%d\n' "$i" "$nft_rc" "$sw_rc"
                if [ "$rc_mismatch" -eq 1 ]; then
                    printf '# RC MISMATCH: nft=%d stormwall=%d\n' "$nft_rc" "$sw_rc"
                fi
                if [ "$listing_mismatch" -eq 1 ]; then
                    printf '# LISTING MISMATCH (nft vs stormwall):\n'
                    printf '%s\n' "$diff_out"
                fi
            } > "$fail_diff"

            printf '  FAIL iter=%-4d nft_rc=%d sw_rc=%d%s  -> %s\n' \
                "$i" "$nft_rc" "$sw_rc" \
                "$([ "$listing_mismatch" -eq 1 ] && printf ' listing_diff' || printf '')" \
                "$fail_nft"
        else
            pass=$((pass + 1))
        fi
    done

    printf '\n'
    printf 'fuzz-parity: %d iterations, seed=%d\n' "$COUNT" "$SEED"
    printf '  PASS=%-4d FAIL=%-4d divergent_rulesets in %s/\n' \
        "$pass" "$fail" "$OUTDIR"

    [ "$fail" -eq 0 ]
}

main "$@"
