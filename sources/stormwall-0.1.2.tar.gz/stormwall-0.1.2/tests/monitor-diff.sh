#!/bin/bash
# Compare `nft monitor` output between stormwall and upstream nft for
# a given ruleset. Anything that changes the kernel state shows up as
# an event; if both binaries produce the same kernel state, the events
# should match line-for-line.
#
# Skips the parts that legitimately differ run-to-run (handle numbers,
# anon-set names like __set17, timestamps).
#
# Usage: monitor-diff.sh <ruleset-file>     compare one ruleset
#        monitor-diff.sh suite              run the bundled corpus

set -u
NFT=/usr/sbin/nft
SW=/tmp/stormwall

run_one() {
    local label=$1
    local rules=$2
    local outdir=$3

    mkdir -p "$outdir"

    for arm in nft sw; do
        local bin
        if [ "$arm" = sw ]; then bin=$SW; else bin=$NFT; fi
        sudo "$bin" flush ruleset 2>/dev/null

        # Start monitor; give it a moment to establish the netlink subscription.
        sudo "$NFT" monitor > "$outdir/$label.$arm.raw" 2>&1 &
        local mon_pid=$!
        sleep 0.3

        sudo "$bin" -f "$rules" > "$outdir/$label.$arm.applyout" 2>&1
        local rc=$?

        # Let buffered events flush before we kill the monitor. 200 ms is
        # plenty for ~100 events on this kernel.
        sleep 0.3
        sudo kill "$mon_pid" 2>/dev/null
        wait "$mon_pid" 2>/dev/null

        sudo "$bin" flush ruleset 2>/dev/null

        # Sanitize away values that legitimately differ between runs
        # but don't reflect a real parity gap:
        #   * anon-set/map ids        (kernel-assigned counter)
        #   * rule/chain handle nums  (kernel-assigned)
        #   * generation footer       (e.g. `# new generation 739 by
        #     process 3166119 (nft)` — process pid + binary name)
        sed -E \
            -e 's/__set[0-9]+/__setN/g' \
            -e 's/__map[0-9]+/__mapN/g' \
            -e 's/handle [0-9]+/handle H/g' \
            -e 's/# handle [0-9]+//g' \
            -e '/^# new generation [0-9]+ by process [0-9]+ \(/d' \
            -e 's/expires [0-9]+[a-z0-9]*/expires E/g' \
            "$outdir/$label.$arm.raw" > "$outdir/$label.$arm.norm"

        echo "  [$arm] apply rc=$rc  events=$(wc -l < $outdir/$label.$arm.norm)"
    done

    if diff -u "$outdir/$label.nft.norm" "$outdir/$label.sw.norm" > "$outdir/$label.diff" 2>&1; then
        echo "  PASS: $label  monitor output identical"
        rm -f "$outdir/$label.diff"
        return 0
    else
        local n=$(grep -cE '^[+-][^+-]' "$outdir/$label.diff")
        echo "  FAIL: $label  $n lines diverge  (see $outdir/$label.diff)"
        return 1
    fi
}

# A diverse corpus designed to exercise distinct codepaths. Each entry
# is one focused ruleset — keeping them small makes diffs readable.
gen_corpus() {
    local d=$1
    mkdir -p "$d"

    cat > "$d/01_table_only.nft" <<'EOF'
add table ip t1
add table inet t2
add table ip6 t3
EOF

    cat > "$d/02_chain_basic.nft" <<'EOF'
add table ip t
add chain ip t input { type filter hook input priority 0; policy accept; }
add chain ip t forward { type filter hook forward priority 0; policy drop; }
EOF

    cat > "$d/03_rule_simple.nft" <<'EOF'
add table ip t
add chain ip t c { type filter hook input priority 0; }
add rule ip t c ip saddr 1.1.1.1 drop
add rule ip t c ip daddr 2.2.2.2 accept
add rule ip t c counter
EOF

    cat > "$d/04_anon_set.nft" <<'EOF'
add table ip t
add chain ip t c { type filter hook input priority 0; }
add rule ip t c tcp dport { 22, 80, 443 } accept
add rule ip t c ip saddr { 10.0.0.0/8, 192.168.0.0/16 } drop
EOF

    cat > "$d/05_named_set.nft" <<'EOF'
add table ip t
add set ip t allowed { type ipv4_addr; }
add element ip t allowed { 1.1.1.1, 2.2.2.2 }
add chain ip t c { type filter hook input priority 0; }
add rule ip t c ip saddr @allowed accept
EOF

    cat > "$d/06_interval_set.nft" <<'EOF'
add table ip t
add set ip t blocked { type ipv4_addr; flags interval; }
add element ip t blocked { 10.0.0.0/8, 172.16.0.0-172.31.255.255 }
add chain ip t c { type filter hook input priority 0; }
add rule ip t c ip saddr @blocked drop
EOF

    cat > "$d/07_inv_lookup.nft" <<'EOF'
add table ip t
add set ip t ok { type ipv4_addr; }
add element ip t ok { 1.1.1.1 }
add chain ip t c { type filter hook input priority 0; }
add rule ip t c ip saddr != @ok drop
EOF

    cat > "$d/08_anon_vmap.nft" <<'EOF'
add table ip t
add chain ip t c { type filter hook input priority 0; }
add rule ip t c ip daddr vmap { 1.1.1.1 : drop, 2.2.2.2 : accept }
EOF

    cat > "$d/09_named_vmap.nft" <<'EOF'
add table ip t
add chain ip t c1
add chain ip t c2
add map ip t v { type ipv4_addr : verdict; }
add element ip t v { 1.1.1.1 : jump c1, 2.2.2.2 : jump c2 }
add chain ip t c { type filter hook input priority 0; }
add rule ip t c ip saddr vmap @v
EOF

    cat > "$d/10_data_map.nft" <<'EOF'
add table ip t
add map ip t m { type ipv4_addr : ipv4_addr; }
add element ip t m { 1.1.1.1 : 10.0.0.1, 2.2.2.2 : 10.0.0.2 }
EOF

    cat > "$d/11_interval_map.nft" <<'EOF'
add table ip t
add map ip t m { type ipv4_addr : ipv4_addr; flags interval; }
add element ip t m { 10.1.1.0/24 : 10.0.1.1, 10.1.2.0/24 : 10.0.1.2 }
EOF

    cat > "$d/12_ipv6_set.nft" <<'EOF'
add table ip6 t
add set ip6 t s6 { type ipv6_addr; flags interval; }
add element ip6 t s6 { fe00::/64, fe11::-fe22:: }
add chain ip6 t c { type filter hook input priority 0; }
add rule ip6 t c ip6 saddr @s6 drop
EOF

    cat > "$d/13_inet_ingress.nft" <<'EOF'
add table inet t
add chain inet t ingress { type filter hook ingress device "lo" priority filter; }
add chain inet t input { type filter hook input priority filter; }
EOF

    cat > "$d/14_ct_state.nft" <<'EOF'
add table ip t
add chain ip t c { type filter hook input priority 0; }
add rule ip t c ct state established,related counter accept
add rule ip t c ct state new tcp dport 22 counter accept
EOF

    cat > "$d/15_counter_obj.nft" <<'EOF'
add table ip t
add counter ip t cnt
add chain ip t c { type filter hook input priority 0; }
add rule ip t c counter name cnt
EOF

    cat > "$d/16_quota_obj.nft" <<'EOF'
add table ip t
add quota ip t q 25 mbytes
EOF

    cat > "$d/17_meta_match.nft" <<'EOF'
add table inet t
add chain inet t c { type filter hook input priority 0; }
add rule inet t c iifname "lo" accept
add rule inet t c meta mark 0x10 drop
EOF

    cat > "$d/18_replace_rule.nft" <<'EOF'
add table ip t
add chain ip t c { type filter hook input priority 0; }
add rule ip t c ip saddr 1.1.1.1 drop
add rule ip t c ip saddr 2.2.2.2 drop
EOF

    cat > "$d/19_rich_inet.nft" <<'EOF'
add table inet filter
add chain inet filter input { type filter hook input priority filter; policy accept; }
add chain inet filter forward { type filter hook forward priority filter; policy drop; }
add rule inet filter input ct state established,related accept
add rule inet filter input iifname "lo" accept
add rule inet filter input meta l4proto { tcp, udp } th dport 53 accept
add rule inet filter input tcp dport { 22, 80, 443 } counter accept
add rule inet filter input icmp type echo-request limit rate 5/second accept
EOF

    cat > "$d/20_delete_path.nft" <<'EOF'
add table ip t
add chain ip t c { type filter hook input priority 0; }
add rule ip t c counter
delete table ip t
EOF

    # Case 21: replace rule — add a rule, then replace it by handle.
    # The handle is stable within a single flush/apply cycle; we sanitize
    # handle numbers in the diff so the exact value doesn't matter.
    cat > "$d/21_replace_rule.nft" <<'EOF'
add table ip t
add chain ip t c { type filter hook input priority 0; }
add rule ip t c ip saddr 1.2.3.4 accept
replace rule ip t c handle 4 drop
EOF

    cat > "$d/22_jump_chain.nft" <<'EOF'
add table ip t
add chain ip t c0 { type filter hook input priority 0; }
add chain ip t c1
add rule ip t c1 counter accept
add rule ip t c0 ip saddr 10.0.0.0/8 jump c1
add rule ip t c0 accept
EOF

    cat > "$d/23_goto_chain.nft" <<'EOF'
add table ip t
add chain ip t c0 { type filter hook input priority 0; }
add chain ip t c1
add rule ip t c1 counter accept
add rule ip t c0 ip saddr 10.0.0.0/8 goto c1
add rule ip t c0 accept
EOF

    cat > "$d/24_log_prefix.nft" <<'EOF'
add table ip t
add chain ip t c { type filter hook input priority 0; }
add rule ip t c log prefix "hello: "
add rule ip t c accept
EOF

    cat > "$d/25_dscp_match.nft" <<'EOF'
add table ip t
add chain ip t c { type filter hook input priority 0; }
add rule ip t c ip dscp 10 accept
add rule ip t c drop
EOF

    cat > "$d/26_tcp_flags.nft" <<'EOF'
add table ip t
add chain ip t c { type filter hook input priority 0; }
add rule ip t c tcp flags syn,ack accept
add rule ip t c tcp flags syn / syn,ack,rst drop
EOF

    cat > "$d/27_masquerade.nft" <<'EOF'
add table ip nat
add chain ip nat postrouting { type nat hook postrouting priority srcnat; }
add rule ip nat postrouting ip saddr 10.0.0.0/8 masquerade
EOF

    cat > "$d/28_snat_to.nft" <<'EOF'
add table ip nat
add chain ip nat postrouting { type nat hook postrouting priority srcnat; }
add rule ip nat postrouting ip saddr 10.0.0.0/8 snat to 1.2.3.4
EOF

    cat > "$d/29_dnat_to.nft" <<'EOF'
add table ip nat
add chain ip nat prerouting { type nat hook prerouting priority dstnat; }
add rule ip nat prerouting tcp dport 80 dnat to 10.0.0.1:8080
EOF

    cat > "$d/30_meta_skuid.nft" <<'EOF'
add table ip t
add chain ip t c { type filter hook output priority 0; }
add rule ip t c meta skuid 1000 accept
add rule ip t c drop
EOF

    # Case 31: dynset rules — `add @s { ip saddr }` and friends. The
    # set declarations carry the `dynamic` and `dynamic,timeout`
    # flags the kernel requires before accepting dynset mutations,
    # plus `size 65535` to match what `nft list ruleset` echoes back
    # so the round-trip diff is byte-identical.
    cat > "$d/31_dynset.nft" <<'EOF'
add table ip t
add set ip t s { type ipv4_addr; size 65535; flags dynamic; }
add set ip t st { type ipv4_addr; size 65535; flags dynamic,timeout; timeout 1m; }
add chain ip t c { type filter hook input priority 0; }
add rule ip t c add @s { ip saddr }
add rule ip t c add @st { ip saddr timeout 10s }
add rule ip t c update @st { ip saddr }
EOF

    # Case 32: a `dynamic,timeout` set populated by `add element` with
    # per-element timeouts. Exercises the NFTA_SET_ELEM_TIMEOUT round-trip
    # through nft's monitor stream — both arms apply via nft -f so the
    # NEWSETELEM events should be byte-identical (we only diff sanitised
    # event text; expires would tick between runs but monitor reports the
    # configured timeout, not the live expiration).
    cat > "$d/32_dynset_populated.nft" <<'EOF'
add table ip t
add set ip t s { type ipv4_addr; size 65535; flags dynamic,timeout; timeout 1m; }
add element ip t s { 1.2.3.4 timeout 10s }
add element ip t s { 5.6.7.8 timeout 30s }
EOF

    # Case 33: ct helper named object plus a rule that references it.
    # Exercises the NFT_OBJECT_CT_HELPER add path and the objref
    # expression in a rule body. The kernel emits NEWOBJ events for the
    # helper and a NEWRULE event whose objref attribute carries
    # NFTA_OBJREF_IMM_TYPE=3 — the monitor diff catches any drift in
    # either encoding.
    cat > "$d/33_ct_helper.nft" <<'EOF'
add table ip t
add ct helper ip t myftp { type "ftp" protocol tcp; }
add chain ip t c { type filter hook prerouting priority -200; }
add rule ip t c tcp dport 21 ct helper set "myftp"
EOF

    # Case 34: flowtable plus a rule that pushes flows into it.
    # Exercises NFT_MSG_NEWFLOWTABLE wire format (TABLE / NAME /
    # HOOK { NUM, PRIO, DEVS } / FLAGS) and the flow_offload rule
    # expression. The match is `ct state new` so neither encoder
    # has to inject an `ip protocol` dependency that would render
    # symbolically on one side and as a raw payload load on the
    # other.  `lo` is the only device guaranteed to exist on every
    # test target.
    cat > "$d/34_flowtable.nft" <<'EOF'
add table inet t
add flowtable inet t ft { hook ingress priority filter; devices = { lo }; }
add chain inet t fc { type filter hook forward priority 0; }
add rule inet t fc ct state new flow add @ft
EOF

    # Case 37: socket expression — local-socket attribute match.
    # Exercises NFTA_SOCKET_KEY+DREG (kernel uapi: KEY=1, DREG=2)
    # and the 1-byte register-store width for `transparent`. The
    # text round-trip is `socket transparent 1 accept` with bare
    # decimal — same on both arms.
    cat > "$d/37_socket.nft" <<'EOF'
add table inet t
add chain inet t in { type filter hook input priority 0; }
add rule inet t in socket transparent 1 accept
EOF

    # Case 38: meta cpu — packet-processing CPU number match.
    # Exercises NFT_META_CPU = 20 (kernel uapi). Host-order u32
    # cmp value, rendered as decimal in text.
    cat > "$d/38_meta_cpu.nft" <<'EOF'
add table inet t
add chain inet t in { type filter hook input priority 0; }
add rule inet t in meta cpu 0 counter
EOF

    # Case 39: rt classid — egress routing classid match.
    # Exercises NFTA_RT_KEY+DREG and host-order u32 classid. Lives
    # on an output chain because the rt expression only fires once
    # the destination route (and its classid attribute) is resolved.
    cat > "$d/39_rt_classid.nft" <<'EOF'
add table inet t
add chain inet t out { type filter hook output priority 0; }
add rule inet t out rt classid 0x10 counter
EOF

    # Case 35: jhash — `meta mark set jhash ip saddr mod 2`.
    # Exercises the "hash" expression with NFT_HASH_JENKINS, plus
    # the source-side payload load that feeds it (DREG=NFT_REG_2,
    # not the usual NFT_REG32_00) and a trailing `meta mark` sink
    # with NFTA_META_SREG=NFT_REG_1. Byte-identity required in the
    # kernel's monitor stream.
    cat > "$d/35_jhash.nft" <<'EOF'
add table ip t
add chain ip t in { type filter hook input priority 0; }
add rule ip t in meta mark set jhash ip saddr mod 2
EOF

    # Case 36: numgen — `meta mark set numgen inc mod 8`.
    # Exercises the "numgen" expression (NFT_NG_INCREMENTAL),
    # storing into NFT_REG_1, with the trailing `meta mark` sink
    # reading from the same register. NG_OFFSET=0 must still be
    # emitted for byte parity with upstream nft.
    cat > "$d/36_numgen.nft" <<'EOF'
add table ip t
add chain ip t in { type filter hook input priority 0; }
add rule ip t in meta mark set numgen inc mod 8
EOF

    # Case 40: dup to ADDR device "DEV" — exercises the dup
    # expression with both immediates (NFT_REG_1 holds the addr,
    # NFT_REG_2 holds the device index). lo is the only nic
    # always present on test hosts.
    cat > "$d/40_dup.nft" <<'EOF'
add table ip t
add chain ip t pre { type filter hook prerouting priority -150; }
add rule ip t pre dup to 192.168.99.99 device "lo"
EOF

    # Case 41: fwd to "DEV" — netdev family. Loads the device
    # ifindex into NFT_REG_1 and references it via NFTA_FWD_SREG_DEV.
    cat > "$d/41_fwd.nft" <<'EOF'
add table netdev t
add chain netdev t c { type filter hook ingress device "lo" priority 0; }
add rule netdev t c fwd to "lo"
EOF

    # Case 42: synproxy mss/wscale + timestamp + sack-perm.
    # Exercises the synproxy expression's u16 BE MSS, u8 WSCALE,
    # and BE u32 FLAGS bitmask (MSS|WSCALE|TS|SACK_PERM = 0x0f).
    cat > "$d/42_synproxy.nft" <<'EOF'
add table inet t
add chain inet t c { type filter hook input priority 0; }
add rule inet t c tcp dport 22 ct state invalid,untracked synproxy mss 1460 wscale 7 timestamp sack-perm
EOF

    # Case 43: snat with the `random` modifier. Exercises
    # NFTA_NAT_FLAGS=NF_NAT_RANGE_PROTO_RANDOM (0x4) on a single-
    # address SNAT. Both arms must apply the same flag bit; the
    # kernel echoes the rule back identically in monitor.
    cat > "$d/43_snat_random.nft" <<'EOF'
add table ip nat
add chain ip nat post { type nat hook postrouting priority srcnat; }
add rule ip nat post oifname "lo" snat to 1.2.3.4 random
EOF

    # Case 44: snat to an address range with `persistent`. Pushes
    # two immediates (REG32_01 / REG32_02) and points
    # NFTA_NAT_REG_ADDR_{MIN,MAX} at them, plus
    # NFTA_NAT_FLAGS=NF_NAT_RANGE_PERSISTENT (0x8).
    cat > "$d/44_snat_persistent.nft" <<'EOF'
add table ip nat
add chain ip nat post { type nat hook postrouting priority srcnat; }
add rule ip nat post oifname "lo" snat to 1.2.3.4-1.2.3.10 persistent
EOF

    # Case 45: bare masquerade with `random`. Exercises
    # NFTA_MASQ_FLAGS (attr 1) inside the `masq` expression's
    # NFTA_EXPR_DATA, distinct from the nat-expr flags codepath.
    cat > "$d/45_masq_random.nft" <<'EOF'
add table ip nat
add chain ip nat post { type nat hook postrouting priority srcnat; }
add rule ip nat post oifname "lo" masquerade random
EOF
}

main() {
    local target=${1:-}
    local outdir=${2:-/tmp/monitor-diff}
    local corpus=/tmp/monitor-corpus

    # Always (re)generate the corpus so single-file mode can dispatch
    # against any of the canonical labels by basename.
    gen_corpus "$corpus"

    # Pause any concurrent ruleset churn — it pollutes nft monitor's
    # event stream. Resume on exit. We match the *exact* command line
    # of the churn loop, not the substring `churn-loop.sh`, because
    # pgrep -f also matches our own bash invocation when it contains
    # those characters — the script then SIGSTOPs itself and hangs.
    local churn_pids
    churn_pids=$(pgrep -x -f "bash /tmp/churn-loop.sh 86400" 2>/dev/null || true)
    if [ -n "$churn_pids" ]; then
        echo "Pausing churn loop pids: $churn_pids"
        # shellcheck disable=SC2086
        sudo kill -STOP $churn_pids
        # shellcheck disable=SC2064
        trap "sudo kill -CONT $churn_pids 2>/dev/null" EXIT
    fi

    case "$target" in
        suite|"")
            local pass=0 fail=0
            for r in "$corpus"/*.nft; do
                local label=$(basename "$r" .nft)
                echo "[$label]"
                if run_one "$label" "$r" "$outdir"; then
                    pass=$((pass+1))
                else
                    fail=$((fail+1))
                fi
            done
            echo
            echo "===== monitor-diff totals: PASS=$pass FAIL=$fail ====="
            return $fail
            ;;
        *)
            local label
            if [ -f "$target" ]; then
                label=$(basename "$target" .nft)
                run_one "$label" "$target" "$outdir"
            else
                # Allow naming a corpus entry directly: `monitor-diff.sh 03_rule_simple`.
                label=$target
                run_one "$label" "$corpus/$label.nft" "$outdir"
            fi
            ;;
    esac
}
main "$@"
