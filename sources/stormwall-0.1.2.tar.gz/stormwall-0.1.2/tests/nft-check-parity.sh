#!/bin/bash
# nft-check-parity.sh — syntax-acceptance parity harness for stormwall.
#
# Runs each .nft file in tests/check-corpus/ through both upstream `nft -c -f`
# and `stormwall -c -f`, and verifies they agree on accept vs reject.
#
# Pass criteria:
#   PASS          — both accepted (rc==0) or both rejected (rc!=0)
#   FAIL          — one accepted, one rejected (asymmetric outcome)
#
# For rejections we do NOT require identical error text — only that BOTH
# produced a non-zero exit code AND non-empty stderr.  The harness is
# intentionally tracking which validation gaps remain so they can be fixed
# incrementally.
#
# Usage:
#   nft-check-parity.sh              run full corpus
#   nft-check-parity.sh suite        same
#   nft-check-parity.sh <file.nft>   run one file
#   nft-check-parity.sh <NN_label>   run one corpus entry by label
#
# Environment:
#   NFT      path to upstream nft binary   (default: /usr/sbin/nft)
#   SW       path to stormwall binary       (default: /tmp/stormwall)
#   OUTDIR   scratch directory for captures (default: /tmp/nft-check-parity)

set -u

NFT=${NFT:-/usr/sbin/nft}
SW=${SW:-/tmp/stormwall}

SCRIPT_DIR=$(cd "$(dirname "$0")" && pwd)
CORPUS="$SCRIPT_DIR/check-corpus"

OUTDIR=${OUTDIR:-/tmp/nft-check-parity}

# ---------------------------------------------------------------------------
# Cleanup on exit — remove scratch files but leave $OUTDIR itself so callers
# can inspect failure details after the run.
# ---------------------------------------------------------------------------
_TMPFILES=""
cleanup() {
    # shellcheck disable=SC2086
    rm -f $_TMPFILES 2>/dev/null || true
}
trap cleanup EXIT

# mktemp_tracked — create a temp file and register it for cleanup
mktemp_tracked() {
    local f
    f=$(mktemp)
    _TMPFILES="$_TMPFILES $f"
    printf '%s' "$f"
}

# ---------------------------------------------------------------------------
# run_one <label> <rules-file>
#
# Runs <rules-file> through nft -c -f and stormwall -c -f, captures rc and
# stderr for each, then classifies the outcome.
#
# Returns:
#   0  PASS    (both accept or both reject)
#   1  FAIL    (asymmetric outcome)
# ---------------------------------------------------------------------------
run_one() {
    local label=$1
    local rules=$2

    mkdir -p "$OUTDIR"

    local nft_rc=0
    local sw_rc=0
    local nft_stderr=""
    local sw_stderr=""

    # --- upstream nft -------------------------------------------------------
    local nft_stderr_f
    nft_stderr_f=$(mktemp_tracked)
    "$NFT" -c -f "$rules" 2>"$nft_stderr_f" >/dev/null
    nft_rc=$?
    nft_stderr=$(cat "$nft_stderr_f")

    # --- stormwall ----------------------------------------------------------
    local sw_stderr_f
    sw_stderr_f=$(mktemp_tracked)
    STORMWALL_TEST_MODE=1 "$SW" -c -f "$rules" 2>"$sw_stderr_f" >/dev/null
    sw_rc=$?
    sw_stderr=$(cat "$sw_stderr_f")

    # Persist stderr for post-run inspection
    cp "$nft_stderr_f" "$OUTDIR/$label.nft.stderr"
    cp "$sw_stderr_f"  "$OUTDIR/$label.sw.stderr"

    # --- classify -----------------------------------------------------------

    # Both accepted
    if [ "$nft_rc" -eq 0 ] && [ "$sw_rc" -eq 0 ]; then
        printf '  PASS (both accept): %s\n' "$label"
        return 0
    fi

    # Both rejected — require both produced non-empty stderr as a sanity check
    if [ "$nft_rc" -ne 0 ] && [ "$sw_rc" -ne 0 ]; then
        # Warn if either produced empty stderr (diagnostic quality issue, not
        # a parity failure — still counts as PASS for accept/reject parity).
        if [ -z "$nft_stderr" ]; then
            printf '  PASS (both reject) [WARN: nft produced empty stderr]: %s\n' "$label"
        elif [ -z "$sw_stderr" ]; then
            printf '  PASS (both reject) [WARN: stormwall produced empty stderr]: %s\n' "$label"
        else
            printf '  PASS (both reject): %s\n' "$label"
        fi
        return 0
    fi

    # Asymmetric: nft rejected, stormwall accepted
    if [ "$nft_rc" -ne 0 ] && [ "$sw_rc" -eq 0 ]; then
        printf '  FAIL [nft rejected, stormwall accepted]: %s\n' "$label"
        printf '    nft stderr:       %s\n' "$(printf '%s' "$nft_stderr" | head -1)"
        printf '    stormwall stderr: (empty — it accepted)\n'
        return 1
    fi

    # Asymmetric: nft accepted, stormwall rejected
    if [ "$nft_rc" -eq 0 ] && [ "$sw_rc" -ne 0 ]; then
        printf '  FAIL [nft accepted, stormwall rejected]: %s\n' "$label"
        printf '    nft stderr:       (empty — it accepted)\n'
        printf '    stormwall stderr: %s\n' "$(printf '%s' "$sw_stderr" | head -1)"
        return 1
    fi
}

# ---------------------------------------------------------------------------
main() {
    local target=${1:-}
    local pass=0
    local fail=0

    case "$target" in
        suite|"")
            for f in "$CORPUS"/*.nft; do
                local label
                label=$(basename "$f" .nft)
                printf '[%s]\n' "$label"
                if run_one "$label" "$f"; then
                    pass=$((pass + 1))
                else
                    fail=$((fail + 1))
                fi
            done
            printf '\n===== nft-check-parity totals: PASS=%d FAIL=%d =====\n' \
                "$pass" "$fail"
            printf '\nNOTE: FAIL means stormwall and nft disagree on accept/reject.\n'
            printf '      Stderr captures in %s/\n' "$OUTDIR"
            return $fail
            ;;
        *)
            local label rules
            if [ -f "$target" ]; then
                label=$(basename "$target" .nft)
                rules=$target
            else
                # Allow bare label e.g. `nft-check-parity.sh 01_simple_table.valid`
                label=$target
                # Try exact match first, then glob
                if [ -f "$CORPUS/$label.nft" ]; then
                    rules="$CORPUS/$label.nft"
                else
                    # label might omit the .valid/.invalid suffix
                    local matches
                    matches=$(ls "$CORPUS/$label"*.nft 2>/dev/null | head -1)
                    if [ -z "$matches" ]; then
                        printf 'error: no corpus file matching "%s" in %s\n' \
                            "$label" "$CORPUS" >&2
                        return 2
                    fi
                    rules=$matches
                    label=$(basename "$rules" .nft)
                fi
            fi
            printf '[%s]\n' "$label"
            run_one "$label" "$rules"
            ;;
    esac
}

main "$@"
