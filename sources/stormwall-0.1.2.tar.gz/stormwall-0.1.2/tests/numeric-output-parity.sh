#!/bin/bash
# numeric-output-parity.sh — numeric flag output parity harness for stormwall.
#
# For each ruleset in tests/numeric-corpus/ the harness loads the rules via
# upstream nft, then captures `list ruleset` output from both nft and stormwall
# under three flag combinations:
#
#   default  — no numeric flags (names resolved as usual)
#   -nn      — double-numeric: ports, protocols, and service names as numbers
#   -y -p    — numeric priority (-y) + numeric protocol (-p)
#
# The kernel state is set once (via upstream nft -f) and shared across all
# three captures per ruleset so any difference is purely renderer output, not
# kernel state drift.
#
# Sanitisation (same rules as monitor-diff.sh and json-parity.sh):
#   * handle N       → handle H
#   * # handle N     → removed
#   * __set<N>       → __setN
#   * __map<N>       → __mapN
#
# Output format:
#   [01_ports]
#     default      PASS
#     -nn          FAIL (3 lines diverge)
#     -y -p        PASS
#   [02_protocols]
#     ...
#
# Usage:
#   numeric-output-parity.sh           run full corpus
#   numeric-output-parity.sh suite     same
#   numeric-output-parity.sh <file>    single ruleset file
#   numeric-output-parity.sh <label>   single corpus entry by label
#
# Environment:
#   NFT      path to upstream nft binary   (default: /usr/sbin/nft)
#   SW       path to stormwall binary       (default: /tmp/stormwall)
#   OUTDIR   scratch directory for captures (default: /tmp/numeric-output-parity)

set -u

NFT=${NFT:-/usr/sbin/nft}
SW=${SW:-/tmp/stormwall}

SCRIPT_DIR=$(cd "$(dirname "$0")" && pwd)
CORPUS="$SCRIPT_DIR/numeric-corpus"

OUTDIR=${OUTDIR:-/tmp/numeric-output-parity}

# ---------------------------------------------------------------------------
# sanitize_text <infile> <outfile>
#
# Strip kernel-assigned ephemeral IDs that legitimately differ between runs:
#   - handle numbers
#   - anonymous set/map counter suffixes
# ---------------------------------------------------------------------------
sanitize_text() {
    local infile=$1
    local outfile=$2

    sed \
        -e 's/__set[0-9][0-9]*/__setN/g' \
        -e 's/__map[0-9][0-9]*/__mapN/g' \
        -e 's/handle [0-9][0-9]*/handle H/g' \
        -e 's/# handle [0-9][0-9]*//' \
        "$infile" > "$outfile"
}

# ---------------------------------------------------------------------------
# capture_one <outfile> <bin> [flags...]
#
# Run <bin> [flags...] list ruleset, writing stdout+stderr to <outfile>.
# Returns the exit code of <bin>.
# ---------------------------------------------------------------------------
capture_one() {
    local outfile=$1
    local bin=$2
    shift 2
    # "$@" are the optional flags (e.g. -nn, or -y -p, or nothing)
    sudo "$bin" "$@" list ruleset > "$outfile" 2>&1
}

# ---------------------------------------------------------------------------
# compare_mode <label> <mode-tag> <nft-raw> <sw-raw>
#
# Sanitise both raw captures, diff them, and print a one-line PASS/FAIL.
# Returns 0 on PASS, 1 on FAIL.
# ---------------------------------------------------------------------------
compare_mode() {
    local label=$1
    local tag=$2
    local nft_raw=$3
    local sw_raw=$4

    local nft_norm="$OUTDIR/$label.$tag.nft.norm"
    local sw_norm="$OUTDIR/$label.$tag.sw.norm"
    local diff_out="$OUTDIR/$label.$tag.diff"

    sanitize_text "$nft_raw" "$nft_norm"
    sanitize_text "$sw_raw"  "$sw_norm"

    if diff -u "$nft_norm" "$sw_norm" > "$diff_out" 2>&1; then
        printf '  %-12s PASS\n' "$tag"
        rm -f "$diff_out"
        return 0
    else
        local n
        n=$(grep -cE '^[+-][^+-]' "$diff_out" || true)
        printf '  %-12s FAIL (%d lines diverge)\n' "$tag" "$n"
        return 1
    fi
}

# ---------------------------------------------------------------------------
# run_one <label> <rules-file>
#
# Apply <rules-file> via upstream nft, then run three capture+compare cycles.
# Returns 0 only when all three modes PASS; returns number of failing modes
# otherwise.
# ---------------------------------------------------------------------------
run_one() {
    local label=$1
    local rules=$2

    mkdir -p "$OUTDIR"

    # Flush any leftover state.
    sudo "$NFT" flush ruleset 2>/dev/null

    # Load the ruleset via upstream nft so the kernel state is identical for
    # both backends.
    if ! sudo "$NFT" -f "$rules" > "$OUTDIR/$label.apply.out" 2>&1; then
        printf '  SKIP (nft -f failed; see %s/%s.apply.out)\n' "$OUTDIR" "$label"
        sudo "$NFT" flush ruleset 2>/dev/null
        return 0
    fi

    local fail=0

    # --- mode: default (no flags) -------------------------------------------
    capture_one "$OUTDIR/$label.default.nft.raw" "$NFT"
    capture_one "$OUTDIR/$label.default.sw.raw"  "$SW"
    compare_mode "$label" "default" \
        "$OUTDIR/$label.default.nft.raw" \
        "$OUTDIR/$label.default.sw.raw"  || fail=$((fail + 1))

    # --- mode: -nn (double-numeric) -----------------------------------------
    capture_one "$OUTDIR/$label.nn.nft.raw" "$NFT" -nn
    capture_one "$OUTDIR/$label.nn.sw.raw"  "$SW"  -nn
    compare_mode "$label" "-nn" \
        "$OUTDIR/$label.nn.nft.raw" \
        "$OUTDIR/$label.nn.sw.raw"  || fail=$((fail + 1))

    # --- mode: -y -p (numeric priority + numeric protocol) ------------------
    capture_one "$OUTDIR/$label.yp.nft.raw" "$NFT" -y -p
    capture_one "$OUTDIR/$label.yp.sw.raw"  "$SW"  -y -p
    compare_mode "$label" "-y -p" \
        "$OUTDIR/$label.yp.nft.raw" \
        "$OUTDIR/$label.yp.sw.raw"  || fail=$((fail + 1))

    sudo "$NFT" flush ruleset 2>/dev/null

    return $fail
}

# ---------------------------------------------------------------------------
main() {
    local target=${1:-}

    # Pause arfur's churn loop (exact command-line match, same technique as
    # monitor-diff.sh) so it does not pollute kernel state mid-capture.
    local churn_pids
    churn_pids=$(pgrep -x -f "bash /tmp/churn-loop.sh 86400" 2>/dev/null || true)
    if [ -n "$churn_pids" ]; then
        printf 'Pausing churn loop pids: %s\n' "$churn_pids"
        # shellcheck disable=SC2086
        sudo kill -STOP $churn_pids
        # shellcheck disable=SC2064
        trap "sudo kill -CONT $churn_pids 2>/dev/null" EXIT
    fi

    case "$target" in
        suite|"")
            local pass=0 fail=0
            for f in "$CORPUS"/*.nft; do
                local label
                label=$(basename "$f" .nft)
                printf '[%s]\n' "$label"
                local rc=0
                run_one "$label" "$f" || rc=$?
                if [ "$rc" -eq 0 ]; then
                    pass=$((pass + 1))
                else
                    fail=$((fail + rc))
                fi
            done
            printf '\n===== numeric-output-parity totals: PASS=%d FAIL=%d =====\n' \
                "$pass" "$fail"
            printf 'Captures in %s/\n' "$OUTDIR"
            return $(( fail > 0 ? 1 : 0 ))
            ;;
        *)
            local label rules
            if [ -f "$target" ]; then
                label=$(basename "$target" .nft)
                rules=$target
            else
                label=$target
                if [ -f "$CORPUS/$label.nft" ]; then
                    rules="$CORPUS/$label.nft"
                else
                    local matches
                    matches=$(ls "$CORPUS/$label"*.nft 2>/dev/null | head -1)
                    if [ -z "$matches" ]; then
                        printf 'error: no corpus file matching "%s" in %s\n' \
                            "$label" "$CORPUS" >&2
                        return 2
                    fi
                    rules=$matches
                    label=$(basename "$rules" .nft)
                fi
            fi
            printf '[%s]\n' "$label"
            run_one "$label" "$rules"
            ;;
    esac
}

main "$@"
