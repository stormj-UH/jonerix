#!/bin/bash
# Traffic-parity harness: build two netns linked by a veth pair,
# apply each test's ruleset to the server side via *both* stormwall
# and nft, and verify that the same probe traffic gets the same
# verdict (accept/drop) under either backend.
#
# This is the strongest drop-in test: monitor-diff says the wire
# format is identical, the upstream test suite says basic encoding
# is correct, but only a real packet round-trip catches off-by-one
# offsets, wrong SREG numbers, or value-byte-order bugs that the
# kernel auto-coerces but mis-evaluates.
#
# Each test case answers two questions:
#   1. Does stormwall produce the verdict the rule says it should?
#   2. Does it produce the *same* verdict nft produces for identical
#      input?
# A drift in either gates the binary as not-drop-in.

set -u
SW=/tmp/stormwall
NFT=/usr/sbin/nft
NS_S=tp_server         # netns hosting the rules (receiver)
NS_C=tp_client         # netns acting as origin (sender)
VETH_S=tps0            # veth on server side
VETH_C=tpc0            # veth on client side
IP_S=10.99.0.1
IP_C=10.99.0.2

PASS=0
FAIL=0

setup() {
    teardown 2>/dev/null
    sudo ip netns add "$NS_S"
    sudo ip netns add "$NS_C"
    sudo ip link add "$VETH_S" type veth peer name "$VETH_C"
    sudo ip link set "$VETH_S" netns "$NS_S"
    sudo ip link set "$VETH_C" netns "$NS_C"
    sudo ip -n "$NS_S" addr add "$IP_S/24" dev "$VETH_S"
    sudo ip -n "$NS_C" addr add "$IP_C/24" dev "$VETH_C"
    sudo ip -n "$NS_S" link set "$VETH_S" up
    sudo ip -n "$NS_C" link set "$VETH_C" up
    sudo ip -n "$NS_S" link set lo up
    sudo ip -n "$NS_C" link set lo up
    # Confirm baseline reachability — if this fails, every test
    # ahead is meaningless because nothing's getting through.
    if ! sudo ip netns exec "$NS_C" ping -c1 -W1 "$IP_S" >/dev/null 2>&1; then
        echo "FATAL: namespaces can't reach each other; bailing"
        exit 1
    fi
    # Stand up TCP listeners on the ports our tests probe so an
    # accepted SYN actually gets a SYN-ACK back. Without a listener
    # the kernel sends RST and ncat reports failure even when the
    # firewall allowed the SYN through, so every "accept" test
    # would FAIL regardless of correctness.
    LISTEN_PIDS=()
    for port in 22 80 2222 8080; do
        sudo ip netns exec "$NS_S" ncat -lk -p "$port" >/dev/null 2>&1 &
        LISTEN_PIDS+=($!)
    done
    sleep 0.3
}

teardown() {
    if [ -n "${LISTEN_PIDS:-}" ]; then
        # shellcheck disable=SC2128
        sudo kill ${LISTEN_PIDS[@]} 2>/dev/null || true
    fi
    sudo ip netns del "$NS_S" 2>/dev/null || true
    sudo ip netns del "$NS_C" 2>/dev/null || true
    sudo ip link del "$VETH_S" 2>/dev/null || true
}

# Apply a ruleset file inside the server netns using `bin`.
apply_rules() {
    local bin=$1 rules=$2
    sudo ip netns exec "$NS_S" "$bin" flush ruleset 2>/dev/null
    sudo ip netns exec "$NS_S" "$bin" -f "$rules"
}

# --- Probe primitives. Each returns 0 for "accepted/passed" and 1
# for "denied/dropped/no response" so the test framework can compare
# verdicts without parsing tool-specific output. Each runs from the
# client netns toward the server, with a 1-second timeout so a
# stalled connection doesn't wedge the suite. ---

probe_tcp() {
    local port=$1
    # `ncat -z` is a connect-only probe: complete the 3-way handshake
    # (or fail). With a listener up on the server side, an accepted
    # SYN ends in SYN-ACK and ncat exits 0; a dropped/blocked SYN
    # times out, ncat exits non-zero. -w1 caps that at one second.
    sudo ip netns exec "$NS_C" timeout 2 ncat -z -w1 "$IP_S" "$port" >/dev/null 2>&1
}

probe_udp() {
    # UDP has no handshake; fire a packet and see if conntrack lets a
    # follow-up reply through. We listen on the server briefly, then
    # send. Match = listener got the packet.
    local port=$1
    sudo ip netns exec "$NS_S" timeout 2 ncat -ul -w1 "$port" >/tmp/tp_udp.out &
    local lpid=$!
    sleep 0.2
    echo "ping" | sudo ip netns exec "$NS_C" timeout 1 ncat -uw1 "$IP_S" "$port" >/dev/null 2>&1 || true
    wait $lpid 2>/dev/null
    [ -s /tmp/tp_udp.out ]
}

probe_icmp() {
    sudo ip netns exec "$NS_C" ping -c1 -W1 "$IP_S" >/dev/null 2>&1
}

# Run a test case. $1 = label, $2 = ruleset file, $3 = probe command
# (one of the probe_* names), $4..= probe args, $expected_verdict env
# var = "accept" or "drop".
run_test() {
    local label=$1 rules=$2 expected=$3
    shift 3
    local probe="$1"; shift
    local nft_verdict sw_verdict expected_rc

    if [ "$expected" = "accept" ]; then expected_rc=0; else expected_rc=1; fi

    apply_rules "$NFT" "$rules"
    if "$probe" "$@"; then nft_verdict=0; else nft_verdict=1; fi

    apply_rules "$SW" "$rules"
    if "$probe" "$@"; then sw_verdict=0; else sw_verdict=1; fi

    if [ "$nft_verdict" = "$sw_verdict" ] && [ "$nft_verdict" = "$expected_rc" ]; then
        printf "  PASS: %-40s nft=%s sw=%s expected=%s\n" "$label" \
            "$([ $nft_verdict = 0 ] && echo accept || echo drop)" \
            "$([ $sw_verdict = 0 ] && echo accept || echo drop)" \
            "$expected"
        PASS=$((PASS+1))
    else
        printf "  FAIL: %-40s nft=%s sw=%s expected=%s\n" "$label" \
            "$([ $nft_verdict = 0 ] && echo accept || echo drop)" \
            "$([ $sw_verdict = 0 ] && echo accept || echo drop)" \
            "$expected"
        FAIL=$((FAIL+1))
    fi
}

gen_rules() {
    local d=$1
    mkdir -p "$d"

    # 1. Empty ruleset (no input chain) — everything gets through.
    cat > "$d/01_baseline.nft" <<'EOF'
add table ip filter
EOF

    # 2. Default-drop chain — every probe should fail.
    cat > "$d/02_default_drop.nft" <<'EOF'
add table ip filter
add chain ip filter input { type filter hook input priority 0; policy drop; }
EOF

    # 3. Allow ssh, drop everything else.
    cat > "$d/03_allow_ssh.nft" <<'EOF'
add table ip filter
add chain ip filter input { type filter hook input priority 0; policy drop; }
add rule ip filter input tcp dport 22 accept
EOF

    # 4. Anonymous set membership.
    cat > "$d/04_anon_set.nft" <<'EOF'
add table ip filter
add chain ip filter input { type filter hook input priority 0; policy drop; }
add rule ip filter input tcp dport { 22, 2222 } accept
EOF

    # 5. IP source filtering with named set.
    cat > "$d/05_named_set.nft" <<'EOF'
add table ip filter
add set ip filter allowed { type ipv4_addr; }
add element ip filter allowed { 10.99.0.2 }
add chain ip filter input { type filter hook input priority 0; policy drop; }
add rule ip filter input ip saddr @allowed accept
EOF

    # 6. Inverted set lookup (the FLAGS-bit bug area).
    cat > "$d/06_inv_set.nft" <<'EOF'
add table ip filter
add set ip filter blocklist { type ipv4_addr; }
add element ip filter blocklist { 10.99.0.99 }
add chain ip filter input { type filter hook input priority 0; policy drop; }
add rule ip filter input ip saddr != @blocklist accept
EOF

    # 7. ICMP only.
    cat > "$d/07_icmp_only.nft" <<'EOF'
add table ip filter
add chain ip filter input { type filter hook input priority 0; policy drop; }
add rule ip filter input icmp type echo-request accept
EOF

    # 8. Conntrack — established/related accept, new dropped.
    cat > "$d/08_ct_state.nft" <<'EOF'
add table ip filter
add chain ip filter input { type filter hook input priority 0; policy drop; }
add rule ip filter input ct state established,related accept
EOF

    # 9. Anon vmap — exercises the verdict-map encoding.
    cat > "$d/09_anon_vmap.nft" <<'EOF'
add table ip filter
add chain ip filter input { type filter hook input priority 0; policy drop; }
add rule ip filter input ip saddr vmap { 10.99.0.2 : accept, 10.99.0.99 : drop }
EOF

    # 10. Interval set on source — exercises range encoding.
    cat > "$d/10_interval.nft" <<'EOF'
add table ip filter
add set ip filter range { type ipv4_addr; flags interval; }
add element ip filter range { 10.99.0.0/24 }
add chain ip filter input { type filter hook input priority 0; policy drop; }
add rule ip filter input ip saddr @range accept
EOF
}

main() {
    local corpus=/tmp/traffic-corpus
    gen_rules "$corpus"
    setup
    trap teardown EXIT

    echo "Traffic parity tests (sw=stormwall, nft=upstream)"
    echo

    # Each test: (label, file, expected, probe, args)
    run_test "baseline-tcp22-accept"        "$corpus/01_baseline.nft"     accept probe_tcp 22
    run_test "default-drop-tcp22"           "$corpus/02_default_drop.nft" drop   probe_tcp 22
    run_test "default-drop-icmp"            "$corpus/02_default_drop.nft" drop   probe_icmp
    run_test "allow-ssh-tcp22-accept"       "$corpus/03_allow_ssh.nft"    accept probe_tcp 22
    run_test "allow-ssh-tcp80-drop"         "$corpus/03_allow_ssh.nft"    drop   probe_tcp 80
    run_test "allow-ssh-icmp-drop"          "$corpus/03_allow_ssh.nft"    drop   probe_icmp
    run_test "anon-set-tcp22-accept"        "$corpus/04_anon_set.nft"     accept probe_tcp 22
    run_test "anon-set-tcp2222-accept"      "$corpus/04_anon_set.nft"     accept probe_tcp 2222
    run_test "anon-set-tcp80-drop"          "$corpus/04_anon_set.nft"     drop   probe_tcp 80
    run_test "named-set-saddr-accept"       "$corpus/05_named_set.nft"    accept probe_tcp 22
    run_test "inv-set-saddr-accept"         "$corpus/06_inv_set.nft"      accept probe_tcp 22
    run_test "icmp-only-icmp-accept"        "$corpus/07_icmp_only.nft"    accept probe_icmp
    run_test "icmp-only-tcp-drop"           "$corpus/07_icmp_only.nft"    drop   probe_tcp 22
    run_test "ct-state-icmp-drop"           "$corpus/08_ct_state.nft"     drop   probe_icmp
    run_test "anon-vmap-accept-source"      "$corpus/09_anon_vmap.nft"    accept probe_tcp 22
    run_test "interval-saddr-accept"        "$corpus/10_interval.nft"     accept probe_tcp 22

    echo
    echo "===== traffic-parity totals: PASS=$PASS FAIL=$FAIL ====="
    return $FAIL
}
main "$@"
