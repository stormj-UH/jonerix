#!/bin/bash
# Traffic-parity-bridge harness: spin up a Linux bridge with two veth
# pairs across three network namespaces, apply bridge-family filter
# rules in the forward chain via both stormwall and nft, and verify
# that forwarding verdicts (accept/drop) match between the two backends.
#
# Topology:
#
#   [tb_a] tba0 (10.98.0.10/24) <--veth--> tba_h --+
#                                                   tb_br  (bridge, L2 only)  [tb_test]
#   [tb_b] tbb0 (10.98.0.20/24) <--veth--> tbb_h --+
#
# tba0/tbb0 are the "endpoint" interfaces living in their own namespaces
# (tb_a / tb_b) so the kernel treats each IP as belonging exclusively to
# one endpoint.  tba_h/tbb_h are the bridge-attached peers in tb_test.
# nft/stormwall rules are applied in tb_test (the bridge namespace).
# Probes run from tb_a; listeners run in tb_b.
#
# This complements traffic-parity.sh (L3/input hook, ip family) with
# L2/bridge-family coverage that container runtimes rely on heavily.

set -u

SW=/tmp/stormwall
NFT=/usr/sbin/nft

NS=tb_test           # bridge netns
NS_A=tb_a            # endpoint-A netns (source)
NS_B=tb_b            # endpoint-B netns (destination)
BR=tb_br             # bridge (lives in NS)
VETHA_EP=tba0        # endpoint veth — lives in NS_A
VETHA_BR=tba_h       # bridge-attached peer — lives in NS
VETHB_EP=tbb0        # endpoint veth — lives in NS_B
VETHB_BR=tbb_h       # bridge-attached peer — lives in NS

IP_A=10.98.0.10      # IP on tba0
IP_B=10.98.0.20      # IP on tbb0

# Populated by setup(), used by rule generators and probe functions.
MAC_A=                # MAC of tba0
MAC_B=                # MAC of tbb0

LISTEN_PIDS=()
PASS=0
FAIL=0

# ---------------------------------------------------------------------------
# Topology setup / teardown
# ---------------------------------------------------------------------------

teardown() {
    if [ "${#LISTEN_PIDS[@]}" -gt 0 ]; then
        sudo kill "${LISTEN_PIDS[@]}" 2>/dev/null || true
    fi
    sudo ip netns del "$NS_A" 2>/dev/null || true
    sudo ip netns del "$NS_B" 2>/dev/null || true
    sudo ip netns del "$NS"   2>/dev/null || true
    # Belt-and-suspenders: remove any host-side link that leaked.
    sudo ip link del "$VETHA_EP" 2>/dev/null || true
    sudo ip link del "$VETHB_EP" 2>/dev/null || true
    sudo ip link del "$VETHA_BR" 2>/dev/null || true
    sudo ip link del "$VETHB_BR" 2>/dev/null || true
}

setup() {
    teardown 2>/dev/null

    # Three namespaces: bridge host + two endpoint hosts.
    sudo ip netns add "$NS"
    sudo ip netns add "$NS_A"
    sudo ip netns add "$NS_B"

    # Bridge lives in NS — disable STP and multicast snooping so broadcasts
    # are forwarded immediately without any learning/listening delay.
    sudo ip -n "$NS" link add "$BR" type bridge
    sudo ip -n "$NS" link set "$BR" type bridge stp_state 0
    sudo ip -n "$NS" link set "$BR" type bridge mcast_snooping 0
    sudo ip -n "$NS" link set "$BR" up

    # veth pair A: tba0 in NS_A <-> tba_h in NS (bridge port).
    sudo ip link add "$VETHA_EP" netns "$NS_A" type veth peer name "$VETHA_BR" netns "$NS"
    sudo ip -n "$NS" link set "$VETHA_BR" master "$BR"
    sudo ip -n "$NS_A" addr add "$IP_A/24" dev "$VETHA_EP"
    sudo ip -n "$NS_A" link set "$VETHA_EP" up
    sudo ip -n "$NS" link set "$VETHA_BR" up

    # veth pair B: tbb0 in NS_B <-> tbb_h in NS (bridge port).
    sudo ip link add "$VETHB_EP" netns "$NS_B" type veth peer name "$VETHB_BR" netns "$NS"
    sudo ip -n "$NS" link set "$VETHB_BR" master "$BR"
    sudo ip -n "$NS_B" addr add "$IP_B/24" dev "$VETHB_EP"
    sudo ip -n "$NS_B" link set "$VETHB_EP" up
    sudo ip -n "$NS" link set "$VETHB_BR" up

    # Capture the MACs now (used by rule generators below).
    MAC_A=$(sudo ip -n "$NS_A" link show "$VETHA_EP" \
            | awk '/link\/ether/{print $2}')
    MAC_B=$(sudo ip -n "$NS_B" link show "$VETHB_EP" \
            | awk '/link\/ether/{print $2}')

    if [ -z "$MAC_A" ] || [ -z "$MAC_B" ]; then
        echo "FATAL: could not read MACs from interfaces; bailing"
        exit 1
    fi

    # Confirm baseline reachability — every frame traverses the bridge.
    if ! sudo ip netns exec "$NS_A" \
            ping -c1 -W2 -I "$VETHA_EP" "$IP_B" >/dev/null 2>&1; then
        echo "FATAL: baseline ping tba0->tbb0 failed; check bridge setup"
        exit 1
    fi

    # Pre-stand TCP listeners on tbb0 so an accepted SYN gets a SYN-ACK.
    # Without this, the kernel RSTs and ncat reports failure even when the
    # bridge accepted the frame.
    LISTEN_PIDS=()
    for port in 80 8080; do
        sudo ip netns exec "$NS_B" ncat -lk -p "$port" \
            -s "$IP_B" >/dev/null 2>&1 &
        LISTEN_PIDS+=($!)
    done
    sleep 0.3
}

# ---------------------------------------------------------------------------
# Rule application
# ---------------------------------------------------------------------------

apply_rules() {
    local bin=$1 rules=$2
    # Rules are applied in the bridge namespace (NS).
    sudo ip netns exec "$NS" "$bin" flush ruleset 2>/dev/null || true
    sudo ip netns exec "$NS" "$bin" -f "$rules"
}

# ---------------------------------------------------------------------------
# Probe primitives — all run inside $NS, source tba0, destination tbb0.
# Return 0 = frame accepted/forwarded, 1 = dropped/blocked.
# ---------------------------------------------------------------------------

probe_icmp() {
    # Probe runs from NS_A (tba0's namespace); every frame must cross the
    # bridge in NS to reach tbb0 in NS_B.
    sudo ip netns exec "$NS_A" \
        ping -c1 -W1 -I "$VETHA_EP" "$IP_B" >/dev/null 2>&1
}

probe_tcp() {
    local port=$1
    sudo ip netns exec "$NS_A" \
        timeout 2 ncat -z -w1 -s "$IP_A" "$IP_B" "$port" >/dev/null 2>&1
}

# Confirm a frame actually traversed the bridge by checking the RX counter
# on tbb0 goes up.  Used optionally in case definitions; not called from
# run_test directly to keep the framework simple.
rx_count_tbb0() {
    sudo ip -n "$NS_B" -s link show "$VETHB_EP" \
        | awk '/RX:/{getline; print $1}'
}

# ---------------------------------------------------------------------------
# Ruleset corpus
# ---------------------------------------------------------------------------

gen_rules() {
    local d=$1
    mkdir -p "$d"

    # 1. No bridge chain — kernel default forwards everything.
    cat > "$d/01_baseline.nft" <<'EOF'
add table bridge filter
EOF

    # 2. Default-drop forward chain — no frame gets through.
    cat > "$d/02_default_drop.nft" <<'EOF'
add table bridge filter
add chain bridge filter forward { type filter hook forward priority filter; policy drop; }
EOF

    # 3. Allow only ARP + TCP/8080 between the two specific MACs.
    #    (MACs substituted at gen time.)
    cat > "$d/03_arp_tcp_macs.nft" <<EOF
add table bridge filter
add chain bridge filter forward { type filter hook forward priority filter; policy drop; }
add rule bridge filter forward ether type arp accept
add rule bridge filter forward ether saddr ${MAC_A} ether daddr ${MAC_B} tcp dport 8080 accept
EOF

    # 4. ether saddr / ether daddr matching — only the known pair passes.
    cat > "$d/04_ether_addr.nft" <<EOF
add table bridge filter
add chain bridge filter forward { type filter hook forward priority filter; policy drop; }
add rule bridge filter forward ether saddr ${MAC_A} ether daddr ${MAC_B} accept
EOF

    # 5. ether type ip allow — IPv4 frames pass, nothing else.
    cat > "$d/05_etype_ip.nft" <<'EOF'
add table bridge filter
add chain bridge filter forward { type filter hook forward priority filter; policy drop; }
add rule bridge filter forward ether type ip accept
EOF

    # 6. Allow ARP but drop IPv4 — ARP resolves, but pings/TCP fail.
    cat > "$d/06_arp_allow_ip_drop.nft" <<'EOF'
add table bridge filter
add chain bridge filter forward { type filter hook forward priority filter; policy drop; }
add rule bridge filter forward ether type arp accept
EOF

    # 7. Named MAC set — frames whose saddr is in the set are dropped.
    cat > "$d/07_mac_set_drop.nft" <<EOF
add table bridge filter
add set bridge filter blocked_macs { type ether_addr; }
add element bridge filter blocked_macs { ${MAC_A} }
add chain bridge filter forward { type filter hook forward priority filter; policy accept; }
add rule bridge filter forward ether saddr @blocked_macs drop
EOF

    # 8. Conntrack-based — established/related accepted, new dropped.
    #    Requires bridge conntrack to be enabled on the host
    #    (nf_conntrack_bridge or sysctl net.bridge.bridge-nf-call-iptables).
    #    New connections (SYN) are dropped; probes that test "accept" here
    #    must already be established — we use ICMP which has no handshake
    #    and is tracked as a "new" flow, so this tests that new ICMP is
    #    dropped.
    cat > "$d/08_ct_state.nft" <<'EOF'
add table bridge filter
add chain bridge filter forward { type filter hook forward priority filter; policy drop; }
add rule bridge filter forward ct state established,related accept
EOF

    # 9. Inverted MAC set — frames from MACs *not* in the set are accepted.
    #    Block list contains a decoy MAC, not MAC_A, so tba0 gets through.
    cat > "$d/09_inv_mac_set.nft" <<'EOF'
add table bridge filter
add set bridge filter decoy_macs { type ether_addr; }
add element bridge filter decoy_macs { de:ad:be:ef:00:01 }
add chain bridge filter forward { type filter hook forward priority filter; policy drop; }
add rule bridge filter forward ether saddr != @decoy_macs accept
EOF
}

# ---------------------------------------------------------------------------
# Test runner — mirrors traffic-parity.sh run_test()
# ---------------------------------------------------------------------------

run_test() {
    local label=$1 rules=$2 expected=$3
    shift 3
    local probe="$1"; shift
    local nft_verdict sw_verdict expected_rc

    if [ "$expected" = "accept" ]; then expected_rc=0; else expected_rc=1; fi

    apply_rules "$NFT" "$rules"
    if "$probe" "$@"; then nft_verdict=0; else nft_verdict=1; fi

    apply_rules "$SW" "$rules"
    if "$probe" "$@"; then sw_verdict=0; else sw_verdict=1; fi

    if [ "$nft_verdict" = "$sw_verdict" ] && [ "$nft_verdict" = "$expected_rc" ]; then
        printf "  PASS: %-50s nft=%s sw=%s expected=%s\n" "$label" \
            "$([ "$nft_verdict" = 0 ] && echo accept || echo drop)" \
            "$([ "$sw_verdict"  = 0 ] && echo accept || echo drop)" \
            "$expected"
        PASS=$((PASS+1))
    else
        printf "  FAIL: %-50s nft=%s sw=%s expected=%s\n" "$label" \
            "$([ "$nft_verdict" = 0 ] && echo accept || echo drop)" \
            "$([ "$sw_verdict"  = 0 ] && echo accept || echo drop)" \
            "$expected"
        FAIL=$((FAIL+1))
    fi
}

# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

main() {
    local corpus=/tmp/traffic-bridge-corpus
    setup
    trap teardown EXIT
    gen_rules "$corpus"   # gen_rules after setup so MAC_A/MAC_B are set

    echo "Traffic parity — bridge family (sw=stormwall, nft=upstream)"
    echo "  Bridge: ${NS}/${BR}  [${NS_A}]tba0=${IP_A}(${MAC_A})  [${NS_B}]tbb0=${IP_B}(${MAC_B})"
    echo

    # 1. Baseline — no bridge chain; forwarding is kernel-default accept.
    run_test "baseline-icmp-accept" \
        "$corpus/01_baseline.nft" accept probe_icmp

    # 2. Default-drop forward chain — all frames dropped.
    run_test "default-drop-icmp" \
        "$corpus/02_default_drop.nft" drop probe_icmp
    run_test "default-drop-tcp80" \
        "$corpus/02_default_drop.nft" drop probe_tcp 80

    # 3. ARP allow + TCP/8080 allow between specific MACs.
    #    ARP itself passes (policy drop, arp rule hits first); TCP/8080 passes.
    run_test "arp-tcp8080-macs-tcp-accept" \
        "$corpus/03_arp_tcp_macs.nft" accept probe_tcp 8080
    #    TCP/80 not in the whitelist — dropped.
    run_test "arp-tcp8080-macs-tcp80-drop" \
        "$corpus/03_arp_tcp_macs.nft" drop probe_tcp 80

    # 4. ether saddr/daddr exact match — source pair accepted, ICMP passes.
    run_test "ether-addr-match-accept" \
        "$corpus/04_ether_addr.nft" accept probe_icmp

    # 5. ether type ip — IPv4 frames accepted.
    run_test "etype-ip-icmp-accept" \
        "$corpus/05_etype_ip.nft" accept probe_icmp

    # 6. ARP allow / IPv4 drop — ICMP (IPv4) must be dropped.
    run_test "arp-allow-ip-drop-icmp-drop" \
        "$corpus/06_arp_allow_ip_drop.nft" drop probe_icmp
    run_test "arp-allow-ip-drop-tcp-drop" \
        "$corpus/06_arp_allow_ip_drop.nft" drop probe_tcp 80

    # 7. Named MAC set drop — tba0's MAC is in the blocked set.
    run_test "mac-set-drop-icmp-drop" \
        "$corpus/07_mac_set_drop.nft" drop probe_icmp

    # 8. ct state established/related — new ICMP flow is "new", gets dropped.
    run_test "ct-state-new-icmp-drop" \
        "$corpus/08_ct_state.nft" drop probe_icmp

    # 9. Inverted MAC set — tba0 not in decoy set, should be accepted.
    run_test "inv-mac-set-icmp-accept" \
        "$corpus/09_inv_mac_set.nft" accept probe_icmp

    echo
    echo "===== traffic-parity-bridge totals: PASS=$PASS FAIL=$FAIL ====="
    return "$FAIL"
}

main "$@"
