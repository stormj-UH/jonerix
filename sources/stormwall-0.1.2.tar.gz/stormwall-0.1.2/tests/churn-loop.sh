#!/bin/bash
# 24-hour add/list/flush churn loop with kernel-state sampling.
#
# Each iteration applies a representative ruleset (~50 rules across
# ip/inet/bridge, with named sets/maps, vmaps, ipv6), lists it both
# text and JSON, then flushes. We sample iteration time on every
# pass and slab/netlink/conntrack/handle counters every 10 passes.
#
# Two arms run alternately so kernel-side leaks attributable to
# stormwall vs nft show up as a slope difference, not just absolute
# growth.
#
# Usage: churn-loop.sh [seconds]   (default 86400 = 24h)

set -u
SECONDS_TOTAL=${1:-86400}
DEADLINE=$(( $(date +%s) + SECONDS_TOTAL ))

NFT=/usr/sbin/nft
SW=/tmp/stormwall
LOG=/tmp/churn-loop.log
SAMPLE_LOG=/tmp/churn-samples.log
ITER_LOG=/tmp/churn-iters.csv

: > "$LOG"
: > "$SAMPLE_LOG"
echo "ts,arm,iter,wall_ms" > "$ITER_LOG"

# A diverse ruleset: ip + inet + bridge tables, named sets/maps,
# anonymous sets, vmaps, ipv4 + ipv6 elements, intervals, counters.
read -r -d '' RULESET <<'EOF' || true
flush ruleset
table ip filter {
    set blocked4 {
        type ipv4_addr
        flags interval
        elements = { 10.0.0.0/8, 172.16.0.0/12, 192.168.0.0/16 }
    }
    map verdicts4 {
        type ipv4_addr : verdict
        elements = { 1.1.1.1 : drop, 8.8.8.8 : accept, 9.9.9.9 : drop }
    }
    chain input {
        type filter hook input priority 0; policy accept;
        ct state established,related counter accept
        ip saddr @blocked4 drop
        ip saddr vmap @verdicts4
        tcp dport { 22, 80, 443, 8080 } counter accept
        udp dport { 53, 67, 68, 123 } accept
        icmp type echo-request counter accept
    }
    chain forward {
        type filter hook forward priority 0; policy drop;
        ct state established,related accept
        ip saddr 10.0.0.0/8 ip daddr 10.0.0.0/8 counter accept
    }
}
table ip6 filter {
    set blocked6 {
        type ipv6_addr
        flags interval
        elements = { fe80::/10, fc00::/7 }
    }
    chain input {
        type filter hook input priority 0; policy accept;
        ct state established,related accept
        ip6 saddr @blocked6 drop
        tcp dport { 22, 80, 443 } accept
    }
}
table inet filter {
    chain input {
        type filter hook input priority filter; policy accept;
        meta l4proto { tcp, udp } th dport 53 accept
        ct state new tcp dport { 22, 80, 443 } counter accept
    }
}
table bridge filter {
    chain forward {
        type filter hook forward priority 0; policy accept;
        ether type ip counter
    }
}
EOF

sample_kernel_state() {
    local tag=$1
    local now=$(date +%s)
    # /proc/slabinfo is root-only; we run sample_kernel_state via sudo
    # so the awk inherits permission. Sum the active-objects column
    # (field 2) for every nft-prefixed slab cache.
    local nft_slab=$(sudo awk '/^nft_/{n+=$2} END{print n+0}' /proc/slabinfo 2>/dev/null)
    local nl_socks=$(awk 'NR>1{n++} END{print n+0}' /proc/net/netlink)
    local ct_count=$(cat /proc/sys/net/netfilter/nf_conntrack_count 2>/dev/null || echo 0)
    local mem_avail=$(awk '/MemAvailable/{print $2}' /proc/meminfo)
    echo "$now,$tag,nft_slab=$nft_slab,nl_socks=$nl_socks,ct=$ct_count,mem_kb_avail=$mem_avail" >> "$SAMPLE_LOG"
}

run_iteration() {
    local arm=$1   # "sw" or "nft"
    local bin
    if [ "$arm" = "sw" ]; then bin=$SW; else bin=$NFT; fi
    local start=$(date +%s%N)
    if ! echo "$RULESET" | sudo "$bin" -f - >/dev/null 2>>"$LOG"; then
        echo "[$arm] apply failed at $(date)" >> "$LOG"
        return 1
    fi
    sudo "$bin" list ruleset >/dev/null 2>>"$LOG"
    sudo "$bin" -j list ruleset >/dev/null 2>>"$LOG"
    sudo "$bin" flush ruleset >/dev/null 2>>"$LOG"
    local end=$(date +%s%N)
    local ms=$(( (end - start) / 1000000 ))
    echo "$(date +%s),$arm,$2,$ms" >> "$ITER_LOG"
}

iter=0
sample_kernel_state baseline
echo "Starting churn loop, deadline $(date -d @$DEADLINE), pid $$" | tee -a "$LOG"

while [ "$(date +%s)" -lt "$DEADLINE" ]; do
    # Alternate arms so leaks correlate with whichever apply path
    # owns them, not background drift.
    run_iteration sw   "$iter" || true
    run_iteration nft  "$iter" || true
    iter=$((iter + 1))
    if [ $((iter % 10)) -eq 0 ]; then
        sample_kernel_state "iter=$iter"
        # Print a heartbeat every 100 iters so a tail -f doesn't go
        # silent for hours.
        if [ $((iter % 100)) -eq 0 ]; then
            echo "[$(date)] iter=$iter" | tee -a "$LOG"
        fi
    fi
done

sample_kernel_state final
echo "Done at $(date), $iter iterations" | tee -a "$LOG"
