#!/bin/sh
# perf-bench.sh — latency/throughput comparison: stormwall vs nft
#
# Runs a fixed set of nftables operations under both backends and prints
# a side-by-side table showing median and p99 wall-clock times.  No
# accept/drop verdicts are tested here; this is purely a perf harness.
#
# Usage: perf-bench.sh [--help] [--nft PATH] [--sw PATH] [--filter BENCH]
#
# --nft PATH      path to nft binary   (default: /usr/sbin/nft)
# --sw  PATH      path to stormwall    (default: /tmp/stormwall)
# --filter BENCH  run only benchmarks matching BENCH (substring)
#
# Benchmarks (each hermetic: flush before, flush after):
#   single_op       N=20   add table ip btest_X; flush ruleset
#   chain_100       N=10   100-rule input chain via -f, then list, then flush
#   interval_1000   N=5    1000-element /24 interval set via -f, then list, then flush
#   vmap_50         N=10   anon vmap with 50 ip saddr entries, then flush
#   list_large      N=100  list ruleset on a large pre-loaded ruleset (100 list calls)
#   json_list       N=100  JSON list ruleset on the same pre-loaded ruleset
#
# Timing is done with date +%s%N (nanosecond resolution).  Median and p99
# are computed in-shell using a pure POSIX sort/awk pipeline — no bc, no
# python, no external statistics tool required.
#
# Regression signal: ratio = stormwall_median / nft_median.
# A ratio > 1.20 is flagged with " [WARN]" in the output.

set -u

NFT=/usr/sbin/nft
SW=/tmp/stormwall
FILTER=

# ── parse args ────────────────────────────────────────────────────────────────
show_help() {
    grep '^#' "$0" | sed 's/^# \{0,1\}//' | sed '1d'
    exit 0
}

while [ $# -gt 0 ]; do
    case "$1" in
        --help|-h) show_help ;;
        --nft)  NFT=$2;    shift 2 ;;
        --sw)   SW=$2;     shift 2 ;;
        --filter) FILTER=$2; shift 2 ;;
        *) printf 'Unknown option: %s\n' "$1" >&2; exit 1 ;;
    esac
done

# ── temp-file management ──────────────────────────────────────────────────────
TMPDIR_BENCH=$(mktemp -d /tmp/perf-bench.XXXXXX)
cleanup() { rm -rf "$TMPDIR_BENCH"; }
trap cleanup EXIT INT TERM

# ── helper: nanosecond timestamp ──────────────────────────────────────────────
ns_now() { date +%s%N; }

# ── helper: run one timed block; prints elapsed_ns to stdout ─────────────────
# Usage: time_cmd cmd [args...]
time_cmd() {
    local t0 t1
    t0=$(ns_now)
    "$@" >/dev/null 2>&1
    t1=$(ns_now)
    printf '%s\n' "$((t1 - t0))"
}

# ── helper: compute median + p99 from a whitespace-separated list of ns ints ─
# Prints two values: median_ms p99_ms
stats_ms() {
    # $1 = newline-separated list of nanosecond integers
    printf '%s\n' "$1" | sort -n | awk '
    BEGIN { n = 0 }
    { samples[n++] = $1 }
    END {
        # median
        if (n % 2 == 1) { med = samples[int(n/2)] }
        else            { med = (samples[n/2 - 1] + samples[n/2]) / 2 }
        # p99 — index of the 99th percentile (ceiling)
        idx = int(n * 0.99 + 0.5)
        if (idx >= n) idx = n - 1
        p99 = samples[idx]
        printf "%d %d\n", int(med / 1000000), int(p99 / 1000000)
    }'
}

# ── helper: print one benchmark result row ────────────────────────────────────
# Usage: print_row label median_ms p99_ms [ratio_x10 warn]
# ratio_x10 is ratio*10 as integer (absent for the nft row)
print_row() {
    local label=$1 med=$2 p99=$3
    if [ $# -ge 4 ]; then
        local ratio_x10=$4 warn=${5:-}
        # format ratio to 2 decimal places without bc: ratio_x10 / 10
        local int_part frac_part
        int_part=$((ratio_x10 / 10))
        frac_part=$((ratio_x10 % 10))
        printf "  %-12s median=%-6sms  p99=%-6sms  ratio=%d.%dx%s\n" \
            "$label" "$med" "$p99" "$int_part" "$frac_part" "$warn"
    else
        printf "  %-12s median=%-6sms  p99=%-6sms\n" \
            "$label" "$med" "$p99"
    fi
}

# ── helper: run N iterations of a shell function, collect timings ─────────────
# Usage: run_bench N func [args...]
# Prints newline-separated ns timings to stdout
run_bench() {
    local n=$1; shift
    local func=$1; shift
    local i=0 elapsed
    while [ $i -lt $n ]; do
        elapsed=$("$func" "$@")
        printf '%s\n' "$elapsed"
        i=$((i + 1))
    done
}

# ── helper: flush ruleset safely (ignore errors if already empty) ─────────────
flush_all() {
    local bin=$1
    "$bin" flush ruleset >/dev/null 2>&1 || true
}

# ── helper: compare two backends and print the section ───────────────────────
# Usage: bench_section title N bench_func [args...]
bench_section() {
    local title=$1 n=$2 func=$3; shift 3

    # skip if filter is set and does not match
    if [ -n "$FILTER" ]; then
        case "$title" in *"$FILTER"*) ;; *) return ;; esac
    fi

    printf '\n=== %s (N=%d) ===\n' "$title" "$n"

    # nft
    local nft_raw nft_med nft_p99
    nft_raw=$(run_bench "$n" "$func" "$NFT" "$@")
    read -r nft_med nft_p99 <<EOF
$(stats_ms "$nft_raw")
EOF
    print_row "nft" "$nft_med" "$nft_p99"

    # stormwall
    local sw_raw sw_med sw_p99
    sw_raw=$(run_bench "$n" "$func" "$SW" "$@")
    read -r sw_med sw_p99 <<EOF
$(stats_ms "$sw_raw")
EOF

    # ratio = sw_med / nft_med (avoid div-by-zero; if nft=0 use 1)
    local ratio_x10 warn
    if [ "$nft_med" -le 0 ]; then
        ratio_x10=10   # treat as 1.0x if nft was instantaneous
    else
        # integer arithmetic: (sw_med * 10) / nft_med  → one decimal place
        ratio_x10=$(( (sw_med * 10) / nft_med ))
    fi
    if [ "$ratio_x10" -gt 12 ]; then
        warn=" [WARN: regression]"
    else
        warn=""
    fi

    print_row "stormwall" "$sw_med" "$sw_p99" "$ratio_x10" "$warn"
}

# ═══════════════════════════════════════════════════════════════════════════════
# Benchmark 1: single_op  (N=20)
#   add table ip btest_X; flush ruleset
#   Exercises the minimal round-trip: one netlink add + one flush.
# ═══════════════════════════════════════════════════════════════════════════════
bench_single_op() {
    local bin=$1
    local t0 t1
    flush_all "$bin"
    t0=$(ns_now)
    "$bin" add table ip btest_single >/dev/null 2>&1
    "$bin" flush ruleset >/dev/null 2>&1
    t1=$(ns_now)
    printf '%s\n' "$((t1 - t0))"
}

# ═══════════════════════════════════════════════════════════════════════════════
# Benchmark 2: chain_100  (N=10)
#   Load a 100-rule input chain via -f, then list ruleset, then flush.
#   Exercises batch-write + kernel-side list serialisation.
# ═══════════════════════════════════════════════════════════════════════════════

# Generate the 100-rule ruleset file once into TMPDIR_BENCH
_gen_chain100() {
    local f="$TMPDIR_BENCH/chain100.nft"
    if [ -f "$f" ]; then printf '%s\n' "$f"; return; fi
    {
        printf 'flush ruleset\n'
        printf 'add table ip bench_chain\n'
        printf 'add chain ip bench_chain input { type filter hook input priority 0; policy accept; }\n'
        i=1
        while [ $i -le 100 ]; do
            # rules that differ so the kernel doesn't collapse them
            printf 'add rule ip bench_chain input tcp dport %d counter\n' "$((1024 + i))"
            i=$((i + 1))
        done
    } > "$f"
    printf '%s\n' "$f"
}

bench_chain100() {
    local bin=$1
    local rulefile
    rulefile=$(_gen_chain100)
    flush_all "$bin"
    local t0 t1
    t0=$(ns_now)
    "$bin" -f "$rulefile" >/dev/null 2>&1
    "$bin" list ruleset  >/dev/null 2>&1
    "$bin" flush ruleset >/dev/null 2>&1
    t1=$(ns_now)
    printf '%s\n' "$((t1 - t0))"
}

# ═══════════════════════════════════════════════════════════════════════════════
# Benchmark 3: interval_1000  (N=5)
#   Load a named interval set containing 1000 /24 prefixes (from 10.0.0.0/16
#   decomposed as individual /24s), then list ruleset, then flush.
#   Exercises interval-tree construction + netlink batch encoding.
# ═══════════════════════════════════════════════════════════════════════════════
_gen_interval1000() {
    local f="$TMPDIR_BENCH/interval1000.nft"
    if [ -f "$f" ]; then printf '%s\n' "$f"; return; fi
    {
        printf 'flush ruleset\n'
        printf 'add table ip bench_interval\n'
        printf 'add set ip bench_interval prefixes { type ipv4_addr; flags interval; }\n'
        # 1000 non-overlapping /24s: 10.0.0.0/24 … 10.3.231.0/24
        # lay them out as 10.A.B.0/24 iterating A=0..3, B=0..255 (1024 total, take 1000)
        local count=0 a=0 b=0
        while [ $count -lt 1000 ]; do
            printf 'add element ip bench_interval prefixes { 10.%d.%d.0/24 }\n' "$a" "$b"
            count=$((count + 1))
            b=$((b + 1))
            if [ $b -eq 256 ]; then b=0; a=$((a + 1)); fi
        done
    } > "$f"
    printf '%s\n' "$f"
}

bench_interval1000() {
    local bin=$1
    local rulefile
    rulefile=$(_gen_interval1000)
    flush_all "$bin"
    local t0 t1
    t0=$(ns_now)
    "$bin" -f "$rulefile"  >/dev/null 2>&1
    "$bin" list ruleset    >/dev/null 2>&1
    "$bin" flush ruleset   >/dev/null 2>&1
    t1=$(ns_now)
    printf '%s\n' "$((t1 - t0))"
}

# ═══════════════════════════════════════════════════════════════════════════════
# Benchmark 4: vmap_50  (N=10)
#   Build a single rule containing an anonymous verdict-map with 50 ip saddr
#   entries (alternating accept/drop), then flush.
#   Exercises anon-vmap encoding — the area fixed in dfd9744.
# ═══════════════════════════════════════════════════════════════════════════════
_gen_vmap50() {
    local f="$TMPDIR_BENCH/vmap50.nft"
    if [ -f "$f" ]; then printf '%s\n' "$f"; return; fi
    {
        printf 'flush ruleset\n'
        printf 'add table ip bench_vmap\n'
        printf 'add chain ip bench_vmap input { type filter hook input priority 0; policy accept; }\n'
        # build the vmap inline: 50 entries
        printf 'add rule ip bench_vmap input ip saddr vmap { '
        local i=1
        while [ $i -le 50 ]; do
            # 192.0.2.0/24 is TEST-NET-1 (RFC 5737) — safe for benchmarks
            local octet=$i
            local verdict
            if [ $((i % 2)) -eq 0 ]; then verdict=accept; else verdict=drop; fi
            if [ $i -lt 50 ]; then
                printf '192.0.2.%d : %s, ' "$octet" "$verdict"
            else
                printf '192.0.2.%d : %s' "$octet" "$verdict"
            fi
            i=$((i + 1))
        done
        printf ' }\n'
    } > "$f"
    printf '%s\n' "$f"
}

bench_vmap50() {
    local bin=$1
    local rulefile
    rulefile=$(_gen_vmap50)
    flush_all "$bin"
    local t0 t1
    t0=$(ns_now)
    "$bin" -f "$rulefile"  >/dev/null 2>&1
    "$bin" flush ruleset   >/dev/null 2>&1
    t1=$(ns_now)
    printf '%s\n' "$((t1 - t0))"
}

# ═══════════════════════════════════════════════════════════════════════════════
# Benchmark 5: list_large  (N=100 list calls)
#   Apply a large diverse ruleset once, then time 100 consecutive
#   "list ruleset" calls.  Tests how fast the kernel serialises the
#   existing state; apply/flush are NOT included in the timing window.
# ═══════════════════════════════════════════════════════════════════════════════
_gen_large_ruleset() {
    local f="$TMPDIR_BENCH/large.nft"
    if [ -f "$f" ]; then printf '%s\n' "$f"; return; fi
    {
        printf 'flush ruleset\n'
        # ip table with a named set, named map, named vmap, and 50 rules
        printf 'add table ip bench_large\n'
        printf 'add set ip bench_large allowed { type ipv4_addr; flags interval; }\n'
        # populate the set with 200 prefixes
        local i=0
        while [ $i -lt 200 ]; do
            printf 'add element ip bench_large allowed { 10.%d.0.0/16 }\n' "$i"
            i=$((i + 1))
        done
        printf 'add map ip bench_large portmap { type inet_proto . inet_service : verdict; }\n'
        printf 'add chain ip bench_large input { type filter hook input priority 0; policy drop; }\n'
        printf 'add chain ip bench_large forward { type filter hook forward priority 0; policy drop; }\n'
        printf 'add chain ip bench_large output { type filter hook output priority 0; policy accept; }\n'
        # 50 rules of various kinds
        j=1
        while [ $j -le 50 ]; do
            printf 'add rule ip bench_large input tcp dport %d counter accept\n' "$((1023 + j))"
            j=$((j + 1))
        done
        printf 'add rule ip bench_large input ip saddr @allowed accept\n'
        printf 'add rule ip bench_large input ct state established,related accept\n'
        printf 'add rule ip bench_large input icmp type echo-request limit rate 10/second accept\n'
    } > "$f"
    printf '%s\n' "$f"
}

# Apply the large ruleset under a given binary; returns elapsed ns
_apply_large() {
    local bin=$1
    local rulefile
    rulefile=$(_gen_large_ruleset)
    flush_all "$bin"
    "$bin" -f "$rulefile" >/dev/null 2>&1
}

# Time a single "list ruleset" call; $bin must already have rules loaded
_time_list() {
    local bin=$1
    local t0 t1
    t0=$(ns_now)
    "$bin" list ruleset >/dev/null 2>&1
    t1=$(ns_now)
    printf '%s\n' "$((t1 - t0))"
}

bench_list_large() {
    local bin=$1
    _apply_large "$bin"
    _time_list "$bin"
}

# ═══════════════════════════════════════════════════════════════════════════════
# Benchmark 6: json_list  (N=100 list calls)
#   Same large ruleset, but list via "nft -j list ruleset" (JSON output).
#   Tests JSON serialisation path overhead vs plain text.
# ═══════════════════════════════════════════════════════════════════════════════
bench_json_list() {
    local bin=$1
    local t0 t1
    t0=$(ns_now)
    "$bin" -j list ruleset >/dev/null 2>&1
    t1=$(ns_now)
    printf '%s\n' "$((t1 - t0))"
}

# ═══════════════════════════════════════════════════════════════════════════════
# Wrapper for list_large and json_list: apply once per backend, then N lists
# ═══════════════════════════════════════════════════════════════════════════════
_run_list_bench() {
    local title=$1 n=$2 list_func=$3

    if [ -n "$FILTER" ]; then
        case "$title" in *"$FILTER"*) ;; *) return ;; esac
    fi

    printf '\n=== %s (N=%d) ===\n' "$title" "$n"

    local bin raw med p99

    for bin in "$NFT" "$SW"; do
        _apply_large "$bin"
        raw=""
        local i=0
        while [ $i -lt $n ]; do
            elapsed=$("$list_func" "$bin")
            raw=$(printf '%s\n%s' "$raw" "$elapsed")
            i=$((i + 1))
        done
        flush_all "$bin"
        read -r med p99 <<EOF
$(stats_ms "$raw")
EOF
        if [ "$bin" = "$NFT" ]; then
            _nft_med=$med; _nft_p99=$p99
            print_row "nft" "$med" "$p99"
        else
            local ratio_x10 warn
            if [ "${_nft_med:-0}" -le 0 ]; then
                ratio_x10=10
            else
                ratio_x10=$(( (med * 10) / _nft_med ))
            fi
            if [ "$ratio_x10" -gt 12 ]; then warn=" [WARN: regression]"; else warn=""; fi
            print_row "stormwall" "$med" "$p99" "$ratio_x10" "$warn"
        fi
    done
}

# ── sanity checks ─────────────────────────────────────────────────────────────
fail() { printf 'ERROR: %s\n' "$1" >&2; exit 1; }

[ -x "$NFT" ] || fail "nft binary not found or not executable: $NFT"
[ -x "$SW"  ] || fail "stormwall binary not found or not executable: $SW"

# ── main ─────────────────────────────────────────────────────────────────────
printf 'perf-bench: stormwall vs nft latency/throughput\n'
printf 'nft=%s  sw=%s\n' "$NFT" "$SW"
printf 'date=%s\n' "$(date -u '+%Y-%m-%dT%H:%M:%SZ')"

# Ensure we start clean regardless of previous test runs
flush_all "$NFT"
flush_all "$SW"

bench_section "single_op"     20  bench_single_op
bench_section "chain_100"     10  bench_chain100
bench_section "interval_1000"  5  bench_interval1000
bench_section "vmap_50"       10  bench_vmap50
_run_list_bench "list_large"  100 _time_list
_run_list_bench "json_list"   100 bench_json_list

# Final flush — leave the kernel clean
flush_all "$NFT"
flush_all "$SW"

printf '\ndone.\n'
