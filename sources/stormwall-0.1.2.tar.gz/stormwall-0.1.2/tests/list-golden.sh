#!/bin/bash
# list-golden.sh -- regression-shield golden-file test for `stormwall list ruleset`.
#
# Captures TEXT and JSON output of `stormwall list ruleset` for a set of
# representative rulesets and compares them against committed golden files.
#
# Each case runs in an isolated network namespace so the test is not affected
# by the churn loop, concurrent agents, or any other kernel ruleset activity.
#
# Usage:
#   tests/list-golden.sh            -- compare all cases against golden files
#   tests/list-golden.sh --update   -- rewrite golden files from current output
#   tests/list-golden.sh <case_id>  -- run / update a single case (e.g. 01_two_tables)
#
# Workflow:
#   1. Run with --update BEFORE the perf refactor to capture current behaviour.
#   2. Run WITHOUT --update AFTER the refactor to assert no behaviour change.
#
# Environment:
#   SW      path to stormwall binary  (default: /tmp/stormwall)
#   NFT     path to nft binary        (default: /usr/sbin/nft)

set -u

SW=${SW:-/tmp/stormwall}
NFT=${NFT:-/usr/sbin/nft}

SCRIPT_DIR=$(cd "$(dirname "$0")" && pwd)
GOLDEN_DIR="$SCRIPT_DIR/list-golden"
SCRATCH=/tmp/list-golden-scratch

# ---------------------------------------------------------------------------
# Sanitisation: strip kernel-assigned ephemeral values that legitimately
# differ between runs.
#   handle [0-9]+        -> handle H
#   __set[0-9]+          -> __setN
#   __map[0-9]+          -> __mapN
#   packets N bytes N    -> packets P bytes B   (counters accumulate traffic)
#   "handle": N          -> "handle": H         (JSON)
#   "id": N              -> "id": I             (JSON)
#   "packets": N         -> "packets": P        (JSON)
#   "bytes": N           -> "bytes": B          (JSON)
# ---------------------------------------------------------------------------
sanitize_text() {
    sed -E \
        -e 's/handle [0-9]+/handle H/g' \
        -e 's/__set[0-9]+/__setN/g' \
        -e 's/__map[0-9]+/__mapN/g' \
        -e 's/packets [0-9]+ bytes [0-9]+/packets P bytes B/g' \
        -e 's/expires [0-9a-z]+/expires E/g'
}

sanitize_json() {
    sed -E \
        -e 's/"handle": [0-9]+/"handle": H/g' \
        -e 's/"id": [0-9]+/"id": I/g' \
        -e 's/__set[0-9]+/__setN/g' \
        -e 's/__map[0-9]+/__mapN/g' \
        -e 's/"packets": [0-9]+/"packets": P/g' \
        -e 's/"bytes": [0-9]+/"bytes": B/g' \
        -e 's/"expires": [0-9]+/"expires": E/g'
}

# ---------------------------------------------------------------------------
# Corpus: 8 representative rulesets as here-docs.
# Each entry is a function named corpus_<id> that writes the ruleset to stdout.
# ---------------------------------------------------------------------------

corpus_01_two_tables() {
    cat <<'EOF'
add table ip t1
add table inet t2
add table ip6 t3
EOF
}

corpus_02_chain_with_rules() {
    cat <<'EOF'
add table ip t
add chain ip t input { type filter hook input priority 0; policy accept; }
add rule ip t input ip saddr 1.1.1.1 drop
add rule ip t input ip daddr 2.2.2.2 accept
add rule ip t input ct state established,related accept
add rule ip t input tcp dport 22 counter accept
add rule ip t input counter
EOF
}

corpus_03_named_set_ipv4() {
    cat <<'EOF'
add table ip t
add set ip t allowed { type ipv4_addr; }
add element ip t allowed { 1.1.1.1, 8.8.8.8, 9.9.9.9 }
add chain ip t input { type filter hook input priority 0; policy accept; }
add rule ip t input ip saddr @allowed accept
EOF
}

corpus_04_named_set_intervals() {
    cat <<'EOF'
add table ip t
add set ip t blocked { type ipv4_addr; flags interval; }
add element ip t blocked { 10.0.0.0/8, 172.16.0.0/12, 192.168.0.0/16 }
add chain ip t input { type filter hook input priority 0; policy drop; }
add rule ip t input ip saddr @blocked drop
add rule ip t input accept
EOF
}

corpus_05_named_vmap() {
    cat <<'EOF'
add table ip t
add chain ip t c1
add chain ip t c2
add map ip t v { type ipv4_addr : verdict; }
add element ip t v { 1.1.1.1 : jump c1, 2.2.2.2 : jump c2 }
add chain ip t input { type filter hook input priority 0; }
add rule ip t input ip saddr vmap @v
EOF
}

corpus_06_anon_set_in_rule() {
    cat <<'EOF'
add table ip t
add chain ip t input { type filter hook input priority 0; policy accept; }
add rule ip t input tcp dport { 22, 80, 443 } accept
add rule ip t input ip saddr { 10.0.0.0/8, 192.168.0.0/16 } drop
EOF
}

corpus_07_ipv6_table() {
    cat <<'EOF'
add table ip6 t6
add set ip6 t6 addrs { type ipv6_addr; flags interval; }
add element ip6 t6 addrs { fe80::/10, ::1/128 }
add chain ip6 t6 input { type filter hook input priority 0; policy accept; }
add chain ip6 t6 forward { type filter hook forward priority 0; policy drop; }
add rule ip6 t6 input ip6 saddr @addrs accept
add rule ip6 t6 input ip6 nexthdr icmpv6 accept
add rule ip6 t6 input drop
EOF
}

corpus_08_multi_table_complex() {
    cat <<'EOF'
add table ip filter
add chain ip filter input { type filter hook input priority 0; policy accept; }
add chain ip filter forward { type filter hook forward priority 0; policy drop; }
add set ip filter trusted { type ipv4_addr; }
add element ip filter trusted { 10.0.0.1, 10.0.0.2 }
add rule ip filter input ip saddr @trusted accept
add rule ip filter input ct state established,related accept
add rule ip filter input tcp dport { 22, 443 } counter accept
add rule ip filter input drop
add table ip nat
add chain ip nat prerouting { type nat hook prerouting priority dstnat; }
add chain ip nat postrouting { type nat hook postrouting priority srcnat; }
add rule ip nat prerouting tcp dport 80 dnat to 10.0.0.1:8080
add rule ip nat postrouting ip saddr 10.0.0.0/8 masquerade
add table inet monitor
add counter ip filter ctr_drop
add chain inet monitor input { type filter hook input priority 0; }
add rule inet monitor input meta l4proto { tcp, udp } counter
EOF
}

# Case 09: dynset rule mutates a named dynamic set at packet time.
# Covers `add @s { ip saddr }` (no timeout, NFT_DYNSET_OP_ADD), the
# `add @st { ip saddr timeout 10s }` per-element-timeout form, and
# `update @st { ip saddr }` (NFT_DYNSET_OP_UPDATE). The two sets
# carry NFT_SET_EVAL ("dynamic") and NFT_SET_TIMEOUT flags so the
# kernel accepts dynset additions; `size 65535` matches what nft's
# own dynamic-set declaration emits.
corpus_09_dynset_rule() {
    cat <<'EOF'
add table ip t
add set ip t s { type ipv4_addr; size 65535; flags dynamic; }
add set ip t st { type ipv4_addr; size 65535; flags dynamic,timeout; timeout 1m; }
add chain ip t c { type filter hook input priority 0; }
add rule ip t c add @s { ip saddr }
add rule ip t c add @st { ip saddr timeout 10s }
add rule ip t c update @st { ip saddr }
EOF
}

# Case 10: a populated `dynamic,timeout` set — exercises the per-element
# `timeout` and `expires` decorators in `nft list ruleset` output.
# Inserted via plain `add element` (not via dynset packet-time mutation)
# so the elements are present immediately and their timeout/expiration
# round-trip through both text and JSON. The harness sanitises the
# `expires` value to a sentinel because it ticks down between captures.
corpus_10_dynset_populated() {
    cat <<'EOF'
add table ip t
add set ip t s { type ipv4_addr; size 65535; flags dynamic,timeout; timeout 1m; }
add element ip t s { 1.2.3.4 timeout 10s }
add element ip t s { 5.6.7.8 timeout 30s }
EOF
}

# Case 11: ct helper named object referenced from a rule. The body
# carries the kernel helper module name ("ftp"), L4 transport (tcp)
# and L3 protocol (ip — defaulted from the table family). The rule
# fires `ct helper set "myftp"`, encoded as an objref expression
# whose IMM_TYPE is NFT_OBJECT_CT_HELPER (3).
corpus_11_ct_helper() {
    cat <<'EOF'
add table ip t
add ct helper ip t myftp { type "ftp" protocol tcp; }
add chain ip t c { type filter hook prerouting priority -200; }
add rule ip t c tcp dport 21 ct helper set "myftp"
EOF
}

# Case 12: flowtable plus a rule that pushes new connections into it.
# Exercises:
#   * NFT_MSG_NEWFLOWTABLE encoding (TABLE / NAME / HOOK { NUM, PRIO,
#     DEVS } / FLAGS).
#   * The `flow_offload` rule expression (NFTA_FLOW_TABLE_NAME).
#   * Listing both forms (text body order and JSON shape).
# The device is `lo` because it is the only interface guaranteed to
# exist on every host the tests run against.
corpus_12_flowtable() {
    cat <<'EOF'
add table inet t
add flowtable inet t ft { hook ingress priority filter; devices = { lo }; }
add chain inet t fc { type filter hook forward priority 0; }
add rule inet t fc ct state new flow add @ft
EOF
}

# Case 15: socket / meta cpu / meta cgroup / rt classid match
# expressions — the policy-routing and container-aware load family.
# Exercises:
#   * socket transparent / mark — NFTA_SOCKET_KEY+DREG with the
#     1-byte vs 4-byte register-store split (transparent is u8,
#     mark is u32).
#   * meta cpu / meta cgroup — kernel uapi values 20 / 23. The task
#     spec gave 14/18, but those slots are SECMARK and BRI_OIFNAME
#     in the actual enum and the kernel rejects them with EOPNOTSUPP.
#   * rt classid — NFTA_RT_KEY=NFT_RT_CLASSID with a host-order u32
#     classid value, rendered as decimal in text and as a JSON
#     string ("16") to mirror libnftables' realm_type printer.
# Two chains so the egress-only `rt classid` lives on a hook that
# actually fires (output), while the ingress-side socket / cpu /
# cgroup matches stay on the input chain.
corpus_15_socket_meta_rt() {
    cat <<'EOF'
add table inet t
add chain inet t in { type filter hook input priority 0; }
add chain inet t out { type filter hook output priority 0; }
add rule inet t in socket transparent 1 accept
add rule inet t in socket mark 0x100 accept
add rule inet t in meta cpu 0 counter
add rule inet t in meta cgroup 1024 accept
add rule inet t out rt classid 0x10 counter
EOF
}

# Case 13: jhash — exercises the `hash` expression with
# NFT_HASH_JENKINS, the NFT_REG_2 source-payload load, and the
# trailing `meta mark set` sink reading NFT_REG_1.
corpus_13_jhash() {
    cat <<'EOF'
add table ip t
add chain ip t in { type filter hook input priority 0; }
add rule ip t in meta mark set jhash ip saddr mod 2
EOF
}

# Case 14: numgen — `meta mark set numgen inc mod 8`. Covers the
# bare numgen-INC + `meta mark set` round-trip, including the
# always-emitted NG_OFFSET=0 attribute upstream sends.
corpus_14_numgen() {
    cat <<'EOF'
add table ip t
add chain ip t in { type filter hook input priority 0; }
add rule ip t in meta mark set numgen inc mod 8
EOF
}

# Case 16: dup + fwd + synproxy round-trip in one ruleset. Exercises
# the new forwarding/redirection statements end-to-end: the ip table
# carries the `dup` (with both addr and device immediates), the
# netdev table carries the `fwd` (single device immediate), and the
# inet table carries `synproxy` with all four optional flag bits.
# Each rule round-trips through `stormwall list ruleset` text + JSON
# so the immediate-stash + format-expr renderers stay honest.
corpus_16_dup_fwd_synproxy() {
    cat <<'EOF'
add table ip td
add chain ip td pre { type filter hook prerouting priority -150; }
add rule ip td pre dup to 192.168.99.99 device "lo"
add table netdev tf
add chain netdev tf c { type filter hook ingress device "lo" priority 0; }
add rule netdev tf c fwd to "lo"
add table inet ts
add chain inet ts c { type filter hook input priority 0; }
add rule inet ts c tcp dport 22 ct state invalid,untracked synproxy mss 1460 wscale 7 timestamp sack-perm
EOF
}

# Case 17: NAT modifier flags — `random`, `persistent`, and
# `fully-random`, plus a bare `masquerade random`. Exercises the
# round-trip of NFTA_NAT_FLAGS (NF_NAT_RANGE_PROTO_RANDOM=0x4,
# NF_NAT_RANGE_PERSISTENT=0x8, NF_NAT_RANGE_PROTO_RANDOM_FULLY=0x10)
# and NFTA_MASQ_FLAGS through stormwall's list-renderer pipeline.
corpus_17_nat_flags() {
    cat <<'EOF'
add table ip nat
add chain ip nat post { type nat hook postrouting priority srcnat; }
add rule ip nat post oifname "lo" snat to 1.2.3.4 random
add rule ip nat post oifname "lo" snat to 1.2.3.4-1.2.3.10 persistent
add rule ip nat post oifname "lo" masquerade random
add rule ip nat post oifname "lo" snat to 1.2.3.4 fully-random
EOF
}

# ---------------------------------------------------------------------------
# List of all case IDs in order.
# ---------------------------------------------------------------------------
ALL_CASES="
01_two_tables
02_chain_with_rules
03_named_set_ipv4
04_named_set_intervals
05_named_vmap
06_anon_set_in_rule
07_ipv6_table
08_multi_table_complex
09_dynset_rule
10_dynset_populated
11_ct_helper
12_flowtable
13_jhash
14_numgen
15_socket_meta_rt
16_dup_fwd_synproxy
17_nat_flags
"

# ---------------------------------------------------------------------------
# run_case <case_id> <update>
#
# Creates a throwaway network namespace, applies the ruleset for <case_id>
# inside it, captures TEXT and JSON outputs from stormwall, sanitises, then
# either writes golden files (update=1) or diffs against them (update=0).
# The namespace is deleted on exit regardless of outcome.
#
# Returns 0 on PASS, 1 on FAIL.
# ---------------------------------------------------------------------------
run_case() {
    local case_id=$1
    local update=$2

    local ns="lg_$$_${case_id}"
    local rules_file="$SCRATCH/$case_id.nft"
    local txt_raw="$SCRATCH/$case_id.txt.raw"
    local json_raw="$SCRATCH/$case_id.json.raw"
    local txt_norm="$SCRATCH/$case_id.txt.norm"
    local json_norm="$SCRATCH/$case_id.json.norm"
    local golden_txt="$GOLDEN_DIR/$case_id.txt"
    local golden_json="$GOLDEN_DIR/$case_id.json"

    mkdir -p "$SCRATCH" "$GOLDEN_DIR"

    # Write ruleset to file (outside the netns — filesystem is shared).
    corpus_"$case_id" > "$rules_file"

    # Create a fresh network namespace — isolated nftables state, zero
    # interference from churn loop or other agents.
    if ! sudo ip netns add "$ns" 2>/dev/null; then
        printf '  ERROR: failed to create netns %s\n' "$ns" >&2
        return 1
    fi
    # Clean up the netns on function exit.
    # shellcheck disable=SC2064
    trap "sudo ip netns del '$ns' 2>/dev/null" RETURN

    # Apply via stormwall -f inside the namespace.
    if ! sudo ip netns exec "$ns" "$SW" -f "$rules_file" \
            > "$SCRATCH/$case_id.apply.out" 2>&1; then
        printf '  ERROR: stormwall -f failed for %s (see %s/%s.apply.out)\n' \
            "$case_id" "$SCRATCH" "$case_id" >&2
        return 1
    fi

    # Capture TEXT output.
    sudo ip netns exec "$ns" "$SW" list ruleset > "$txt_raw" 2>&1
    local txt_rc=$?

    # Capture JSON output.
    sudo ip netns exec "$ns" "$SW" -j list ruleset > "$json_raw" 2>&1
    local json_rc=$?

    # netns is deleted by the RETURN trap — no explicit flush needed.

    if [ "$txt_rc" -ne 0 ]; then
        printf '  ERROR: stormwall list ruleset returned rc=%d\n' "$txt_rc" >&2
        return 1
    fi
    if [ "$json_rc" -ne 0 ]; then
        printf '  ERROR: stormwall -j list ruleset returned rc=%d\n' "$json_rc" >&2
        return 1
    fi

    # Sanitise.
    sanitize_text  < "$txt_raw"  > "$txt_norm"
    sanitize_json  < "$json_raw" > "$json_norm"

    if [ "$update" -eq 1 ]; then
        cp "$txt_norm"  "$golden_txt"
        cp "$json_norm" "$golden_json"
        printf '  UPDATED: %s.txt  %s.json\n' "$case_id" "$case_id"
        return 0
    fi

    # Compare mode.
    local rc=0

    if [ ! -f "$golden_txt" ]; then
        printf '  FAIL: golden file missing: %s\n' "$golden_txt" >&2
        rc=1
    elif ! diff -u "$golden_txt" "$txt_norm" > "$SCRATCH/$case_id.txt.diff" 2>&1; then
        local n
        n=$(grep -cE '^[+-][^+-]' "$SCRATCH/$case_id.txt.diff" || true)
        printf '  FAIL (TEXT): %d lines diverge\n' "$n"
        cat "$SCRATCH/$case_id.txt.diff"
        rc=1
    fi

    if [ ! -f "$golden_json" ]; then
        printf '  FAIL: golden file missing: %s\n' "$golden_json" >&2
        rc=1
    elif ! diff -u "$golden_json" "$json_norm" > "$SCRATCH/$case_id.json.diff" 2>&1; then
        local n
        n=$(grep -cE '^[+-][^+-]' "$SCRATCH/$case_id.json.diff" || true)
        printf '  FAIL (JSON): %d lines diverge\n' "$n"
        cat "$SCRATCH/$case_id.json.diff"
        rc=1
    fi

    if [ "$rc" -eq 0 ]; then
        printf '  PASS\n'
    fi

    return "$rc"
}

# ---------------------------------------------------------------------------
# main
# ---------------------------------------------------------------------------
main() {
    local update=0
    local target=

    for arg in "$@"; do
        case "$arg" in
            --update) update=1 ;;
            *)        target=$arg ;;
        esac
    done

    if [ -n "$target" ]; then
        # Single-case mode: strip optional .nft / .txt / .json suffix.
        target=$(basename "$target" .nft)
        target=$(basename "$target" .txt)
        target=$(basename "$target" .json)
        printf '[%s]\n' "$target"
        run_case "$target" "$update"
        return $?
    fi

    # Suite mode.
    local pass=0 fail=0

    for case_id in $ALL_CASES; do
        [ -z "$case_id" ] && continue
        printf '[%s]\n' "$case_id"
        if run_case "$case_id" "$update"; then
            pass=$((pass + 1))
        else
            fail=$((fail + 1))
        fi
    done

    printf '\n===== list-golden totals: PASS=%d FAIL=%d =====\n' "$pass" "$fail"
    if [ "$update" -eq 1 ]; then
        printf 'Golden files written to %s/\n' "$GOLDEN_DIR"
    fi
    return "$fail"
}

main "$@"
