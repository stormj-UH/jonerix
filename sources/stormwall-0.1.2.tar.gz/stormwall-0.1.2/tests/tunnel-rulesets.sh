#!/bin/bash
# tunnel-rulesets.sh -- VPN/tunnel-shape ruleset parity harness.
#
# Applies (~8) typical VPN/tunnel nftables rule shapes through upstream nft,
# then compares `nft -j list ruleset` vs `stormwall -j list ruleset` against
# the same kernel state.  Reports PASS / FAIL / SKIP per case.
#
# Cases:
#   01_wireguard_basic          wg0 forwarding (filter inet)
#   02_wireguard_with_nat       wg0 + masquerade (nat ip)
#   03_tailscale_subnet_router  tailscale0 + CGNAT source (100.64.0.0/10)
#   04_ipsec_marker             ESP + IKE/NAT-T ports
#   05_wireguard_split_tunnel   named interval set + iifname+daddr rule
#   06_mtu_clamp                SKIP -- tcp option maxseg size set rt mtu not yet implemented
#   07_per_peer_mark            SKIP -- meta mark set (setter) not yet implemented
#   08_dnat_to_local_via_wg     DNAT to 127.0.0.1 from tunnel
#
# Sanitisation follows json-parity.sh exactly:
#   a) top-level metainfo elements stripped
#   b) "handle" keys dropped
#   c) "index" keys dropped
#   d) __set<N>/__map<N> normalised to __setN/__mapN
#   e) re-serialised with sorted keys + 4-space indent
#
# Usage:
#   tunnel-rulesets.sh              -- run all cases
#   tunnel-rulesets.sh suite        -- same
#   tunnel-rulesets.sh <NN_label>   -- single case by label or file
#
# Environment:
#   NFT     path to upstream nft binary   (default: /usr/sbin/nft)
#   SW      path to stormwall binary       (default: /tmp/stormwall)
#   OUTDIR  scratch directory              (default: /tmp/tunnel-rulesets)

set -u

NFT=${NFT:-/usr/sbin/nft}
SW=${SW:-/tmp/stormwall}

SCRIPT_DIR=$(cd "$(dirname "$0")" && pwd)
CORPUS="$SCRIPT_DIR/tunnel-corpus"

OUTDIR=${OUTDIR:-/tmp/tunnel-rulesets}

# ---------------------------------------------------------------------------
# _SANITIZE_PY: inline Python3 normaliser (identical logic to json-parity.sh).
#
# Called as:  python3 -c "$_SANITIZE_PY" <infile> > <outfile>
# Exits non-zero when <infile> is not valid JSON.
# ---------------------------------------------------------------------------
_SANITIZE_PY='
import json, re, sys

def clean(node):
    if isinstance(node, dict):
        out = {}
        for k, v in node.items():
            if k in ("handle", "index"):
                # (b)(c) drop kernel-assigned ephemeral IDs
                continue
            out[k] = clean(v)
        return out
    if isinstance(node, list):
        return [clean(i) for i in node]
    if isinstance(node, str):
        # (d) anonymise anonymous set/map counter suffixes
        node = re.sub(r"__set\d+", "__setN", node)
        node = re.sub(r"__map\d+", "__mapN", node)
        return node
    return node

try:
    data = json.load(open(sys.argv[1]))
except Exception as e:
    sys.stderr.write("json parse error: " + str(e) + "\n")
    sys.exit(1)

# (a) drop top-level nftables array elements that are pure metainfo wrappers
if isinstance(data, dict) and "nftables" in data:
    data["nftables"] = [
        obj for obj in data["nftables"]
        if not (isinstance(obj, dict) and list(obj.keys()) == ["metainfo"])
    ]

data = clean(data)
# (e) re-serialise with sorted keys + stable indent
print(json.dumps(data, indent=4, sort_keys=True))
'

# ---------------------------------------------------------------------------
# sanitize_json <infile> <outfile>
# Returns 0 on success, 1 when the input is not valid JSON.
# ---------------------------------------------------------------------------
sanitize_json() {
    local infile=$1
    local outfile=$2

    if ! python3 -c "$_SANITIZE_PY" "$infile" > "$outfile" 2>/dev/null; then
        printf '' > "$outfile"
        return 1
    fi
}

# ---------------------------------------------------------------------------
# assert_metainfo <nft-raw> <sw-raw>
#
# Soft check: metainfo mismatch is reported as a warning but does NOT
# increment FAIL.  Mirrors the same function in json-parity.sh.
# ---------------------------------------------------------------------------
assert_metainfo() {
    local nft_raw=$1
    local sw_raw=$2

    local meta_py='
import json, sys
try:
    d = json.load(open(sys.argv[1]))
    for obj in d.get("nftables", []):
        if "metainfo" in obj:
            print(json.dumps(obj["metainfo"], sort_keys=True))
            break
except Exception:
    pass
'
    local nft_meta sw_meta
    nft_meta=$(python3 -c "$meta_py" "$nft_raw" 2>/dev/null)
    sw_meta=$(python3  -c "$meta_py" "$sw_raw"  2>/dev/null)

    if [ -z "$nft_meta" ] && [ -z "$sw_meta" ]; then
        printf '    metainfo: both absent\n'
        return 0
    fi
    if [ "$nft_meta" = "$sw_meta" ]; then
        printf '    metainfo: identical (%s)\n' "$nft_meta"
        return 0
    fi
    printf '    metainfo MISMATCH (soft warning):\n'
    printf '      nft: %s\n' "$nft_meta"
    printf '       sw: %s\n' "$sw_meta"
    return 1
}

# ---------------------------------------------------------------------------
# run_one <label> <rules-file>
#
# Apply <rules-file> via upstream nft, capture both JSON outputs, sanitise,
# diff.  Returns 0 (PASS), 1 (FAIL), 2 (SKIP).
# ---------------------------------------------------------------------------
run_one() {
    local label=$1
    local rules=$2

    mkdir -p "$OUTDIR"

    # Flush any leftover state from a previous case.
    sudo "$NFT" flush ruleset 2>/dev/null

    # Apply via upstream nft so kernel state is canonical regardless of how
    # complete stormwall's -f path is.
    if ! sudo "$NFT" -f "$rules" > "$OUTDIR/$label.apply.out" 2>&1; then
        printf '  SKIP: (nft -f failed; see %s/%s.apply.out)\n' \
            "$OUTDIR" "$label"
        sudo "$NFT" flush ruleset 2>/dev/null
        return 2
    fi

    # Capture both JSON list-ruleset outputs against the same kernel state.
    sudo "$NFT"                        -j list ruleset > "$OUTDIR/$label.nft.json" 2>&1
    local nft_rc=$?
    sudo STORMWALL_TEST_MODE=1 "$SW"   -j list ruleset > "$OUTDIR/$label.sw.json"  2>&1
    local sw_rc=$?

    sudo "$NFT" flush ruleset 2>/dev/null

    if [ "$nft_rc" -ne 0 ]; then
        printf '  FAIL: nft returned rc=%d\n' "$nft_rc"
        return 1
    fi
    if [ "$sw_rc" -ne 0 ]; then
        printf '  FAIL: stormwall returned rc=%d\n' "$sw_rc"
        return 1
    fi

    # Sanitise both captures.
    if ! sanitize_json "$OUTDIR/$label.nft.json" "$OUTDIR/$label.nft.norm"; then
        printf '  FAIL: nft output is not valid JSON\n'
        return 1
    fi
    if ! sanitize_json "$OUTDIR/$label.sw.json" "$OUTDIR/$label.sw.norm"; then
        printf '  FAIL: stormwall output is not valid JSON\n'
        return 1
    fi

    # Metainfo assertion (soft -- informational only, no FAIL penalty).
    assert_metainfo "$OUTDIR/$label.nft.json" "$OUTDIR/$label.sw.json"

    # Primary diff.
    if diff -u "$OUTDIR/$label.nft.norm" "$OUTDIR/$label.sw.norm" \
            > "$OUTDIR/$label.diff" 2>&1; then
        printf '  PASS: outputs identical\n'
        rm -f "$OUTDIR/$label.diff"
        return 0
    else
        local n
        n=$(grep -cE '^[+-][^+-]' "$OUTDIR/$label.diff" || true)
        printf '  FAIL: %d lines diverge (see %s/%s.diff)\n' \
            "$n" "$OUTDIR" "$label"
        return 1
    fi
}

# ---------------------------------------------------------------------------
# skip_known_gap <label> <reason>
# ---------------------------------------------------------------------------
skip_known_gap() {
    local label=$1
    local reason=$2
    printf '  SKIP: known gap -- %s\n' "$reason"
}

# ---------------------------------------------------------------------------
# KNOWN_GAPS: labels that are unconditionally skipped.
#
#   06_mtu_clamp   -- `tcp option maxseg size set rt mtu` requires the
#                     SYNPROXY/TCPOPTSTRIP path; stormwall does not yet
#                     render the "mss clamp to route MTU" expression.
#
#   07_per_peer_mark -- `meta mark set <value>` is a meta SETTER, not a
#                     match expression.  stormwall's meta renderer covers
#                     the match side; the immediate/payload-set codepath
#                     for meta.mark assignment is not yet wired up.
# ---------------------------------------------------------------------------
KNOWN_GAPS="06_mtu_clamp 07_per_peer_mark"

is_known_gap() {
    local label=$1
    local g
    for g in $KNOWN_GAPS; do
        [ "$label" = "$g" ] && return 0
    done
    return 1
}

# Reason text indexed by label (bash associative array).
declare -A GAP_REASON
GAP_REASON[06_mtu_clamp]="tcp option maxseg size set rt mtu not yet implemented"
GAP_REASON[07_per_peer_mark]="meta mark set (setter expression) not yet implemented"

# ---------------------------------------------------------------------------
# run_suite -- iterate over all corpus files in label order.
# ---------------------------------------------------------------------------
run_suite() {
    local pass=0 fail=0 skip=0

    for f in "$CORPUS"/*.nft; do
        local label
        label=$(basename "$f" .nft)
        printf '[case]  %s\n' "$label"

        if is_known_gap "$label"; then
            skip_known_gap "$label" "${GAP_REASON[$label]}"
            skip=$((skip + 1))
            continue
        fi

        local rc
        run_one "$label" "$f"
        rc=$?
        case $rc in
            0) pass=$((pass + 1)) ;;
            2) skip=$((skip + 1)) ;;
            *) fail=$((fail + 1)) ;;
        esac
    done

    printf '\n===== tunnel-rulesets totals: PASS=%d FAIL=%d SKIP=%d =====\n' \
        "$pass" "$fail" "$skip"
    printf 'Captures in %s/\n' "$OUTDIR"
    return $fail
}

# ---------------------------------------------------------------------------
# main
# ---------------------------------------------------------------------------
main() {
    local target=${1:-}

    # Pause arfur's churn loop so it does not pollute kernel state mid-capture
    # (same technique as json-parity.sh / monitor-diff.sh).
    local churn_pids
    churn_pids=$(pgrep -x -f "bash /tmp/churn-loop.sh 86400" 2>/dev/null || true)
    if [ -n "$churn_pids" ]; then
        printf 'Pausing churn loop pids: %s\n' "$churn_pids"
        # shellcheck disable=SC2086
        sudo kill -STOP $churn_pids
        # shellcheck disable=SC2064
        trap "sudo kill -CONT $churn_pids 2>/dev/null" EXIT
    fi

    case "$target" in
        suite|"")
            run_suite
            ;;
        *)
            local label rules
            if [ -f "$target" ]; then
                label=$(basename "$target" .nft)
                rules=$target
            else
                label=$target
                if [ -f "$CORPUS/$label.nft" ]; then
                    rules="$CORPUS/$label.nft"
                else
                    local matches
                    matches=$(ls "$CORPUS/$label"*.nft 2>/dev/null | head -1)
                    if [ -z "$matches" ]; then
                        printf 'error: no corpus file matching "%s" in %s\n' \
                            "$label" "$CORPUS" >&2
                        return 2
                    fi
                    rules=$matches
                    label=$(basename "$rules" .nft)
                fi
            fi

            printf '[case]  %s\n' "$label"

            if is_known_gap "$label"; then
                skip_known_gap "$label" "${GAP_REASON[$label]}"
                return 0
            fi

            run_one "$label" "$rules"
            ;;
    esac
}

main "$@"
