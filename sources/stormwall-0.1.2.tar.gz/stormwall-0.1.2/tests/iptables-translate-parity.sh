#!/bin/bash
# iptables-translate-parity.sh — verify stormwall accepts everything
# iptables-translate emits, identically to upstream nft.
#
# For each iptables rule in the built-in corpus:
#   1. Run iptables-translate to get nft syntax.
#   2. Feed that nft text through both `nft -c -f -` and `stormwall -c -f -`.
#   3. Compare accept/reject outcome.
#
# Output format per case:
#
#   [case_label]
#     iptables in:     <the iptables -A line>
#     nft out:         <the translation (first rule line)>
#     nft -c rc:       0
#     stormwall -c rc: 0
#     PASS  or  FAIL [stormwall rejected what nft accepted]
#
# Pass criteria: both tools return the same rc class (0 vs non-0).
#
# Usage:
#   iptables-translate-parity.sh        run all cases
#   iptables-translate-parity.sh <N>    run case number N (1-based)
#
# Environment:
#   NFT          path to upstream nft binary     (default: /usr/sbin/nft)
#   SW           path to stormwall binary         (default: /tmp/stormwall)
#   OUTDIR       scratch dir for captures         (default: /tmp/ipt-xlat-parity)
#   IPTR         path to iptables-translate       (default: auto-detect)

set -u

NFT=${NFT:-/usr/sbin/nft}
SW=${SW:-/tmp/stormwall}
OUTDIR=${OUTDIR:-/tmp/ipt-xlat-parity}

# ---------------------------------------------------------------------------
# Locate iptables-translate
# ---------------------------------------------------------------------------
if [ -n "${IPTR:-}" ]; then
    IPTABLES_TRANSLATE=$IPTR
else
    IPTABLES_TRANSLATE=""
    for candidate in \
        /usr/sbin/iptables-translate \
        /sbin/iptables-translate \
        /usr/bin/iptables-translate
    do
        if [ -x "$candidate" ]; then
            IPTABLES_TRANSLATE=$candidate
            break
        fi
    done
    if [ -z "$IPTABLES_TRANSLATE" ] && command -v iptables-translate >/dev/null 2>&1; then
        IPTABLES_TRANSLATE=$(command -v iptables-translate)
    fi
fi

if [ -z "$IPTABLES_TRANSLATE" ]; then
    printf 'SKIP: iptables-translate not found.\n'
    printf '      Install: apt install iptables (Debian) or iptables-nftables-compat.\n'
    exit 0
fi

# ---------------------------------------------------------------------------
# Corpus: each entry is "label|iptables_args..."
# The iptables_args are passed verbatim to iptables-translate.
# ---------------------------------------------------------------------------
CORPUS="
01_basic_accept|-A INPUT -j ACCEPT
02_tcp_dport_22|-A INPUT -p tcp --dport 22 -j ACCEPT
03_src_drop|-A INPUT -s 10.0.0.0/8 -j DROP
04_ct_state_estab_related|-A INPUT -m state --state ESTABLISHED,RELATED -j ACCEPT
05_icmp_echo_req|-A INPUT -p icmp --icmp-type 8 -j ACCEPT
06_forward_iif_oif|-A FORWARD -i eth0 -o eth1 -j ACCEPT
07_masquerade_postrouting|-A POSTROUTING -t nat -o eth0 -j MASQUERADE
08_dnat_prerouting|-A PREROUTING -t nat -p tcp --dport 80 -j DNAT --to-destination 10.0.0.5:8080
09_multiport_dports|-A INPUT -m multiport --dports 22,80,443 -j ACCEPT
10_tcp_flags_syn|-A INPUT -p tcp --tcp-flags SYN,ACK SYN -j ACCEPT
"

# ---------------------------------------------------------------------------
# Cleanup on exit
# ---------------------------------------------------------------------------
_TMPFILES=""
cleanup() {
    # shellcheck disable=SC2086
    rm -f ${_TMPFILES:-} 2>/dev/null || true
}
trap cleanup EXIT

mktemp_tracked() {
    local f
    f=$(mktemp)
    _TMPFILES="$_TMPFILES $f"
    printf '%s' "$f"
}

# ---------------------------------------------------------------------------
# run_case <label> <iptables_args...>
#
# Returns 0 on PASS, 1 on FAIL.
# ---------------------------------------------------------------------------
run_case() {
    local label=$1
    shift
    local ipt_args="$*"

    printf '[%s]\n' "$label"
    printf '  iptables in:     %s\n' "$ipt_args"

    # --- run iptables-translate ---------------------------------------------
    local xlat_out xlat_rc
    local xlat_f
    xlat_f=$(mktemp_tracked)
    # iptables-translate writes to stdout; stderr goes to /dev/null (some
    # versions emit warnings about missing kernel modules which are harmless).
    "$IPTABLES_TRANSLATE" $ipt_args >"$xlat_f" 2>/dev/null
    xlat_rc=$?

    if [ "$xlat_rc" -ne 0 ]; then
        printf '  nft out:         (iptables-translate failed rc=%d — case skipped)\n' "$xlat_rc"
        printf '  SKIP\n\n'
        return 0
    fi

    xlat_out=$(cat "$xlat_f")

    if [ -z "$xlat_out" ]; then
        printf '  nft out:         (empty — iptables-translate produced nothing)\n'
        printf '  SKIP\n\n'
        return 0
    fi

    # Show first non-blank line of translation (the rest is context lines)
    local first_rule
    first_rule=$(printf '%s\n' "$xlat_out" | grep -v '^[[:space:]]*$' | head -1)
    printf '  nft out:         %s\n' "$first_rule"

    mkdir -p "$OUTDIR"

    # Persist the full translation for post-run inspection
    printf '%s\n' "$xlat_out" > "$OUTDIR/$label.nft"

    # --- run nft -c -f - ----------------------------------------------------
    local nft_rc=0
    local nft_stderr_f
    nft_stderr_f=$(mktemp_tracked)
    printf '%s\n' "$xlat_out" | "$NFT" -c -f - 2>"$nft_stderr_f" >/dev/null
    nft_rc=$?
    cp "$nft_stderr_f" "$OUTDIR/$label.nft.stderr"

    printf '  nft -c rc:       %d\n' "$nft_rc"

    # --- run stormwall -c -f - ----------------------------------------------
    local sw_rc=0
    local sw_stderr_f
    sw_stderr_f=$(mktemp_tracked)
    printf '%s\n' "$xlat_out" | STORMWALL_TEST_MODE=1 "$SW" -c -f - 2>"$sw_stderr_f" >/dev/null
    sw_rc=$?
    cp "$sw_stderr_f" "$OUTDIR/$label.sw.stderr"

    printf '  stormwall -c rc: %d\n' "$sw_rc"

    # --- classify -----------------------------------------------------------
    local outcome=0

    if [ "$nft_rc" -eq 0 ] && [ "$sw_rc" -eq 0 ]; then
        printf '  PASS\n'
    elif [ "$nft_rc" -ne 0 ] && [ "$sw_rc" -ne 0 ]; then
        printf '  PASS (both reject)\n'
    elif [ "$nft_rc" -eq 0 ] && [ "$sw_rc" -ne 0 ]; then
        printf '  FAIL [stormwall rejected what nft accepted]\n'
        printf '    stormwall stderr: %s\n' \
            "$(cat "$sw_stderr_f" | head -1)"
        outcome=1
    else
        # nft rejected, stormwall accepted — stormwall is more permissive
        printf '  FAIL [nft rejected what stormwall accepted]\n'
        printf '    nft stderr:      %s\n' \
            "$(cat "$nft_stderr_f" | head -1)"
        outcome=1
    fi

    printf '\n'
    return "$outcome"
}

# ---------------------------------------------------------------------------
# main
# ---------------------------------------------------------------------------
main() {
    local target_n=${1:-}
    local pass=0 fail=0
    local n=0

    printf 'iptables-translate: %s\n' "$IPTABLES_TRANSLATE"
    printf 'nft:                %s\n' "$NFT"
    printf 'stormwall:          %s\n' "$SW"
    printf 'scratch:            %s\n\n' "$OUTDIR"

    # Iterate over corpus lines.  IFS newline to preserve spaces in args.
    local IFS_SAVE=$IFS
    IFS='
'
    for entry in $CORPUS; do
        IFS=$IFS_SAVE
        # Skip blank/whitespace-only lines: valid entries always contain '|'
        case "$entry" in
            *'|'*) ;;
            *) continue ;;
        esac

        n=$((n + 1))

        # Split on first '|'
        local label rest
        label=${entry%%|*}
        rest=${entry#*|}

        # If a specific case number was requested, skip others
        if [ -n "$target_n" ] && [ "$n" != "$target_n" ]; then
            IFS='
'
            continue
        fi

        IFS=$IFS_SAVE
        # run_case receives the iptables args as a single string; we need
        # word-splitting here so pass them unquoted.
        # shellcheck disable=SC2086
        if run_case "$label" $rest; then
            # Check whether the case was skipped (SKIP printed inside run_case;
            # we count it separately by inspecting the last output line — but
            # simpler to let PASS cover it; only FAILs matter for rc).
            pass=$((pass + 1))
        else
            fail=$((fail + 1))
        fi

        IFS='
'
    done
    IFS=$IFS_SAVE

    printf '===== iptables-translate-parity totals: PASS=%d FAIL=%d =====\n' \
        "$pass" "$fail"
    if [ "$fail" -gt 0 ]; then
        printf '\nNOTE: FAIL means stormwall and nft disagree on accept/reject.\n'
        printf '      Full nft text and stderr captures in %s/\n' "$OUTDIR"
    fi

    return "$fail"
}

main "$@"
