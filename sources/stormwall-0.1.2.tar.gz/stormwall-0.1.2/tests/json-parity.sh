#!/bin/bash
# json-parity.sh -- JSON output parity harness for stormwall vs upstream nft.
#
# For each ruleset in tests/json-corpus/ the harness:
#   1. Flushes the kernel ruleset and applies the corpus file via nft.
#   2. Captures `nft -j list ruleset` and `stormwall -j list ruleset`.
#   3. Sanitises both through a Python3 normaliser (parse, strip ephemeral
#      fields, re-serialise with sorted keys + stable indent) so diff noise
#      from serialisation order and kernel-assigned IDs does not mask real
#      renderer gaps.
#   4. Diffs the two sanitised streams and reports PASS / FAIL.
#
# Sanitisation rules (all applied in a single Python3 pass):
#   a) Top-level nftables array elements whose sole key is "metainfo" are
#      removed -- metainfo is tested separately by assert_metainfo().
#   b) "handle" keys are dropped wherever they appear (kernel-assigned,
#      monotonically increasing across flush/apply cycles).
#   c) "index" keys are dropped wherever they appear (kernel-assigned,
#      present in some set/map element objects).
#   d) String values matching __set<N> or __map<N> are normalised to
#      __setN / __mapN (anonymous-set IDs are kernel counters).
#   e) The cleaned tree is re-serialised with sorted keys and 4-space
#      indent so key-ordering differences between the two renderers vanish.
#
# Usage:
#   json-parity.sh              -- run full corpus
#   json-parity.sh suite        -- same
#   json-parity.sh <file.nft>   -- single file
#   json-parity.sh <NN_label>   -- single corpus entry by label
#
# Environment:
#   NFT      path to upstream nft binary    (default: /usr/sbin/nft)
#   SW       path to stormwall binary        (default: /tmp/stormwall)
#   OUTDIR   scratch directory for captures  (default: /tmp/json-parity)

set -u

NFT=${NFT:-/usr/sbin/nft}
SW=${SW:-/tmp/stormwall}

SCRIPT_DIR=$(cd "$(dirname "$0")" && pwd)
CORPUS="$SCRIPT_DIR/json-corpus"

OUTDIR=${OUTDIR:-/tmp/json-parity}

# ---------------------------------------------------------------------------
# _SANITIZE_PY: inline Python3 normaliser.
#
# Kept in-line so the test directory ships as two files (harness + corpus)
# with no extra interpreter scripts.  Called as:
#   python3 -c "$_SANITIZE_PY" <infile> > <outfile>
# Exits non-zero when <infile> is not valid JSON.
# ---------------------------------------------------------------------------
_SANITIZE_PY='
import json, re, sys

def clean(node, parent_key=None):
    if isinstance(node, dict):
        out = {}
        for k, v in node.items():
            if k in ("handle", "index"):
                # (b)(c) drop kernel-assigned ephemeral IDs
                continue
            # (f) normalise live counter packets/bytes — both nft and stormwall
            # emit raw kernel values, which drift between the two captures
            # because the harness flushes traffic in-flight. Replace with
            # sentinels so we test JSON SHAPE, not packet drift.
            if parent_key in ("counter", "quota") and k in ("packets", "bytes", "used"):
                out[k] = "__N__"
                continue
            # (g) per-element `expires` (and `expiration`) is the time
            # remaining on a set elements TTL; the kernel ticks it down
            # between the two captures, so mask it like counter values.
            # Per-element `timeout` is stable (set at insert) and stays.
            if k in ("expires", "expiration"):
                out[k] = "__N__"
                continue
            out[k] = clean(v, k)
        return out
    if isinstance(node, list):
        return [clean(i, parent_key) for i in node]
    if isinstance(node, str):
        # (d) anonymise anonymous set/map counter suffixes
        node = re.sub(r"__set\d+", "__setN", node)
        node = re.sub(r"__map\d+", "__mapN", node)
        return node
    return node

try:
    data = json.load(open(sys.argv[1]))
except Exception as e:
    sys.stderr.write("json parse error: " + str(e) + "\n")
    sys.exit(1)

# (a) drop top-level nftables array elements that are pure metainfo wrappers
if isinstance(data, dict) and "nftables" in data:
    data["nftables"] = [
        obj for obj in data["nftables"]
        if not (isinstance(obj, dict) and list(obj.keys()) == ["metainfo"])
    ]

data = clean(data)
# (e) re-serialise with sorted keys + stable indent
print(json.dumps(data, indent=4, sort_keys=True))
'

# ---------------------------------------------------------------------------
# sanitize_json <infile> <outfile>
# Returns 0 on success, 1 when the input is not valid JSON.
# ---------------------------------------------------------------------------
sanitize_json() {
    local infile=$1
    local outfile=$2

    if ! python3 -c "$_SANITIZE_PY" "$infile" > "$outfile" 2>/dev/null; then
        printf '' > "$outfile"
        return 1
    fi
}

# ---------------------------------------------------------------------------
# assert_metainfo <nft-raw> <sw-raw> <label>
#
# Under STORMWALL_TEST_MODE=1 stormwall impersonates nft and must emit an
# identical metainfo block.  This is a soft check: a failure is reported
# as a warning but does NOT increment the FAIL counter.  The JSON renderer
# completeness is the primary concern tracked here; metainfo impersonation
# is secondary.
# ---------------------------------------------------------------------------
assert_metainfo() {
    local nft_raw=$1
    local sw_raw=$2

    local meta_py='
import json, sys
try:
    d = json.load(open(sys.argv[1]))
    for obj in d.get("nftables", []):
        if "metainfo" in obj:
            print(json.dumps(obj["metainfo"], sort_keys=True))
            break
except Exception:
    pass
'
    local nft_meta sw_meta
    nft_meta=$(python3 -c "$meta_py" "$nft_raw" 2>/dev/null)
    sw_meta=$(python3  -c "$meta_py" "$sw_raw"  2>/dev/null)

    if [ -z "$nft_meta" ] && [ -z "$sw_meta" ]; then
        printf '    metainfo: both absent\n'
        return 0
    fi
    if [ "$nft_meta" = "$sw_meta" ]; then
        printf '    metainfo: identical (%s)\n' "$nft_meta"
        return 0
    fi
    printf '    metainfo MISMATCH (soft warning):\n'
    printf '      nft: %s\n' "$nft_meta"
    printf '       sw: %s\n' "$sw_meta"
    return 1
}

# ---------------------------------------------------------------------------
# run_one <label> <rules-file>
#
# Apply <rules-file> via upstream nft, capture both JSON outputs, sanitise,
# diff.  Returns 0 (PASS), 1 (FAIL), 2 (SKIP -- nft -f itself failed).
# ---------------------------------------------------------------------------
run_one() {
    local label=$1
    local rules=$2

    mkdir -p "$OUTDIR"

    # Flush any leftover state from a previous case.
    sudo "$NFT" flush ruleset 2>/dev/null

    # Apply the corpus ruleset via upstream nft so the kernel state is
    # identical regardless of how complete stormwall's -f path is.
    if ! sudo "$NFT" -f "$rules" > "$OUTDIR/$label.apply.out" 2>&1; then
        printf '  SKIP: (nft -f failed; see %s/%s.apply.out)\n' \
            "$OUTDIR" "$label"
        sudo "$NFT" flush ruleset 2>/dev/null
        return 2
    fi

    # Capture both JSON list-ruleset outputs against the same kernel state.
    sudo "$NFT"                        -j list ruleset > "$OUTDIR/$label.nft.json" 2>&1
    local nft_rc=$?
    sudo STORMWALL_TEST_MODE=1 "$SW"   -j list ruleset > "$OUTDIR/$label.sw.json"  2>&1
    local sw_rc=$?

    sudo "$NFT" flush ruleset 2>/dev/null

    if [ "$nft_rc" -ne 0 ]; then
        printf '  FAIL: nft returned rc=%d\n' "$nft_rc"
        return 1
    fi
    if [ "$sw_rc" -ne 0 ]; then
        printf '  FAIL: stormwall returned rc=%d\n' "$sw_rc"
        return 1
    fi

    # Sanitise both captures.
    if ! sanitize_json "$OUTDIR/$label.nft.json" "$OUTDIR/$label.nft.norm"; then
        printf '  FAIL: nft output is not valid JSON\n'
        return 1
    fi
    if ! sanitize_json "$OUTDIR/$label.sw.json" "$OUTDIR/$label.sw.norm"; then
        printf '  FAIL: stormwall output is not valid JSON\n'
        return 1
    fi

    # Metainfo assertion (soft -- informational only, no FAIL penalty).
    assert_metainfo "$OUTDIR/$label.nft.json" "$OUTDIR/$label.sw.json"

    # Primary diff.
    if diff -u "$OUTDIR/$label.nft.norm" "$OUTDIR/$label.sw.norm" \
            > "$OUTDIR/$label.diff" 2>&1; then
        printf '  PASS: outputs identical\n'
        rm -f "$OUTDIR/$label.diff"
        return 0
    else
        local n
        n=$(grep -cE '^[+-][^+-]' "$OUTDIR/$label.diff" || true)
        printf '  FAIL: %d lines diverge (see %s/%s.diff)\n' \
            "$n" "$OUTDIR" "$label"
        return 1
    fi
}

# ---------------------------------------------------------------------------
main() {
    local target=${1:-}

    # Pause arfur's churn loop (exact command-line match, same technique as
    # monitor-diff.sh) so it does not pollute kernel state mid-capture.
    local churn_pids
    churn_pids=$(pgrep -x -f "bash /tmp/churn-loop.sh 86400" 2>/dev/null || true)
    if [ -n "$churn_pids" ]; then
        printf 'Pausing churn loop pids: %s\n' "$churn_pids"
        # shellcheck disable=SC2086
        sudo kill -STOP $churn_pids
        # shellcheck disable=SC2064
        trap "sudo kill -CONT $churn_pids 2>/dev/null" EXIT
    fi

    case "$target" in
        suite|"")
            local pass=0 fail=0 skip=0
            for f in "$CORPUS"/*.nft; do
                local label
                label=$(basename "$f" .nft)
                printf '[case]  %s\n' "$label"
                local rc
                run_one "$label" "$f"
                rc=$?
                case $rc in
                    0) pass=$((pass + 1)) ;;
                    2) skip=$((skip + 1)) ;;
                    *) fail=$((fail + 1)) ;;
                esac
            done
            printf '\n===== json-parity totals: PASS=%d FAIL=%d SKIP=%d =====\n' \
                "$pass" "$fail" "$skip"
            printf 'Captures in %s/\n' "$OUTDIR"
            return $fail
            ;;
        *)
            local label rules
            if [ -f "$target" ]; then
                label=$(basename "$target" .nft)
                rules=$target
            else
                label=$target
                if [ -f "$CORPUS/$label.nft" ]; then
                    rules="$CORPUS/$label.nft"
                else
                    local matches
                    matches=$(ls "$CORPUS/$label"*.nft 2>/dev/null | head -1)
                    if [ -z "$matches" ]; then
                        printf 'error: no corpus file matching "%s" in %s\n' \
                            "$label" "$CORPUS" >&2
                        return 2
                    fi
                    rules=$matches
                    label=$(basename "$rules" .nft)
                fi
            fi
            printf '[case]  %s\n' "$label"
            run_one "$label" "$rules"
            ;;
    esac
}

main "$@"
