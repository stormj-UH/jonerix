#!/bin/sh
# list-perf-profile.sh — fine-grained scaling profile for "list ruleset"
#
# Isolates WHERE the 5.3x list_large regression lives by sweeping three
# ruleset scales and measuring both text and JSON output paths.
#
# Usage: list-perf-profile.sh [--nft PATH] [--sw PATH]
#
# --nft PATH    path to nft binary     (default: /usr/sbin/nft)
# --sw  PATH    path to stormwall      (default: /tmp/stormwall)
#
# What it tests
# ─────────────
# Three scales — chosen so N doubles sharply and stays in O(N) vs O(N²)
# distinguishable territory without multi-minute runtimes:
#
#   SMALL   10 prefixes  + 10 chain rules
#   MEDIUM  200 prefixes + 50 chain rules   (matches list_large in perf-bench)
#   LARGE   1000 prefixes + 100 chain rules
#
# For each scale and each binary:
#   (a)  stormwall/nft  list ruleset      (text path)
#   (b)  stormwall/nft  -j list ruleset   (JSON path)
#
# Each cell is 30 timed calls on an already-loaded ruleset (apply/flush
# are NOT in the timing window).  Median and p99 are computed via a pure
# POSIX sort/awk pipeline — no bc, no python.
#
# Interpretation guide
# ────────────────────
# If stormwall median scales O(N²) relative to nft:
#   → per-set GETSETELEM round-trips in collect_anon_sets() (src/ops.rs
#     around line 1713): one netlink dump per set per collect_anon_sets
#     call, instead of a single batched dump.
#
# If stormwall median is a fixed offset above nft at all scales:
#   → constant-cost overhead (recv_timeout, socket setup, etc.).
#
# If text and JSON paths diverge at large scale:
#   → rendering/serialisation cost (string building, allocator churn).
#
# Output shape
# ────────────
# A table like:
#
#   scale      path    nft_med  nft_p99  sw_med   sw_p99   ratio  note
#   SMALL      text    ...
#   SMALL      json    ...
#   MEDIUM     text    ...
#   ...
#
# followed by a short per-scale ratio column to let you spot the bend.

set -u

NFT=/usr/sbin/nft
SW=/tmp/stormwall
N=30        # iterations per cell

# ── parse args ────────────────────────────────────────────────────────────────
show_help() {
    grep '^#' "$0" | sed 's/^# \{0,1\}//'
    exit 0
}

while [ $# -gt 0 ]; do
    case "$1" in
        --help|-h) show_help ;;
        --nft) NFT=$2; shift 2 ;;
        --sw)  SW=$2;  shift 2 ;;
        *) printf 'Unknown option: %s\n' "$1" >&2; exit 1 ;;
    esac
done

# ── sanity checks ─────────────────────────────────────────────────────────────
fail() { printf 'ERROR: %s\n' "$1" >&2; exit 1; }
[ -x "$NFT" ] || fail "nft binary not found or not executable: $NFT"
[ -x "$SW"  ] || fail "stormwall binary not found or not executable: $SW"

# ── temp dir + cleanup ────────────────────────────────────────────────────────
TMPDIR_PROFILE=$(mktemp -d /tmp/list-perf-profile.XXXXXX)
cleanup() { rm -rf "$TMPDIR_PROFILE"; }
trap cleanup EXIT INT TERM

# ── nanosecond clock ──────────────────────────────────────────────────────────
ns_now() { date +%s%N; }

# ── flush ruleset safely ──────────────────────────────────────────────────────
flush_all() { "$1" flush ruleset >/dev/null 2>&1 || true; }

# ── stats: median + p99 from newline-separated ns integers ───────────────────
# Prints: median_ms p99_ms
stats_ms() {
    printf '%s\n' "$1" | sort -n | awk '
    BEGIN { n = 0 }
    { samples[n++] = $1 }
    END {
        if (n == 0) { print "0 0"; exit }
        if (n % 2 == 1) { med = samples[int(n/2)] }
        else            { med = (samples[n/2-1] + samples[n/2]) / 2 }
        idx = int(n * 99 / 100)
        if (idx >= n) idx = n - 1
        p99 = samples[idx]
        printf "%d %d\n", int(med/1000000), int(p99/1000000)
    }'
}

# ── ratio (integer arithmetic, one decimal place) ─────────────────────────────
# ratio_str nft_med sw_med  →  prints "N.Mx" string + optional [WARN]
ratio_str() {
    local nft_med=$1 sw_med=$2
    local rx warn
    if [ "$nft_med" -le 0 ]; then
        rx=10
    else
        rx=$(( (sw_med * 10) / nft_med ))
    fi
    if [ "$rx" -gt 12 ]; then warn=" [WARN]"; else warn=""; fi
    printf '%d.%dx%s' "$((rx / 10))" "$((rx % 10))" "$warn"
}

# ── ruleset generators ────────────────────────────────────────────────────────
# Each writes a file to TMPDIR_PROFILE and prints the path.
# Called at most once per scale (idempotent via existence check).

_gen_ruleset() {
    local tag=$1 npfx=$2 nrules=$3
    local f="$TMPDIR_PROFILE/ruleset_${tag}.nft"
    [ -f "$f" ] && { printf '%s\n' "$f"; return; }
    {
        printf 'flush ruleset\n'
        printf 'add table ip bench_%s\n' "$tag"

        # Named interval set with npfx prefixes
        printf 'add set ip bench_%s prefixes { type ipv4_addr; flags interval; }\n' "$tag"
        local i=0 a=0 b=0
        while [ $i -lt "$npfx" ]; do
            printf 'add element ip bench_%s prefixes { 10.%d.%d.0/24 }\n' \
                "$tag" "$a" "$b"
            i=$((i + 1))
            b=$((b + 1))
            if [ $b -eq 256 ]; then b=0; a=$((a + 1)); fi
        done

        # Three hooked chains
        printf 'add chain ip bench_%s input  { type filter hook input  priority 0; policy drop; }\n' "$tag"
        printf 'add chain ip bench_%s forward { type filter hook forward priority 0; policy drop; }\n' "$tag"
        printf 'add chain ip bench_%s output { type filter hook output priority 0; policy accept; }\n' "$tag"

        # nrules tcp-dport rules so chain walk scales with nrules
        local j=1
        while [ $j -le "$nrules" ]; do
            printf 'add rule ip bench_%s input tcp dport %d counter accept\n' \
                "$tag" "$((1023 + j))"
            j=$((j + 1))
        done

        # One set-match rule and a few common expression types
        printf 'add rule ip bench_%s input ip saddr @prefixes accept\n' "$tag"
        printf 'add rule ip bench_%s input ct state established,related accept\n' "$tag"
        printf 'add rule ip bench_%s input icmp type echo-request limit rate 10/second accept\n' "$tag"
    } > "$f"
    printf '%s\n' "$f"
}

# SMALL: 10 prefixes, 10 rules
gen_small()  { _gen_ruleset small  10   10; }
# MEDIUM: 200 prefixes, 50 rules  (matches list_large in perf-bench)
gen_medium() { _gen_ruleset medium 200  50; }
# LARGE: 1000 prefixes, 100 rules
gen_large()  { _gen_ruleset large  1000 100; }

# ── apply a ruleset into kernel under a given binary ─────────────────────────
apply_ruleset() {
    local bin=$1 rulefile=$2
    flush_all "$bin"
    "$bin" -f "$rulefile" >/dev/null 2>&1
}

# ── time one "list ruleset" call (text or JSON) ───────────────────────────────
# Usage: time_list bin [json]   → prints elapsed ns
time_list() {
    local bin=$1 mode=${2:-text}
    local t0 t1
    t0=$(ns_now)
    if [ "$mode" = "json" ]; then
        "$bin" -j list ruleset >/dev/null 2>&1
    else
        "$bin" list ruleset >/dev/null 2>&1
    fi
    t1=$(ns_now)
    printf '%s\n' "$((t1 - t0))"
}

# ── run N list calls and return newline-separated ns timings ─────────────────
collect_timings() {
    local bin=$1 mode=$2 n=$3
    local i=0
    while [ $i -lt "$n" ]; do
        time_list "$bin" "$mode"
        i=$((i + 1))
    done
}

# ── one cell of the result table ─────────────────────────────────────────────
# measure_cell scale_label gen_func path_mode
# Fills globals: _nft_med _nft_p99 _sw_med _sw_p99
measure_cell() {
    local scale=$1 gen_func=$2 mode=$3
    local rulefile
    rulefile=$("$gen_func")

    local raw med p99

    # nft
    apply_ruleset "$NFT" "$rulefile"
    raw=$(collect_timings "$NFT" "$mode" "$N")
    flush_all "$NFT"
    read -r med p99 <<EOF
$(stats_ms "$raw")
EOF
    _nft_med=$med
    _nft_p99=$p99

    # stormwall
    apply_ruleset "$SW" "$rulefile"
    raw=$(collect_timings "$SW" "$mode" "$N")
    flush_all "$SW"
    read -r med p99 <<EOF
$(stats_ms "$raw")
EOF
    _sw_med=$med
    _sw_p99=$p99
}

# ── print table header ────────────────────────────────────────────────────────
print_header() {
    printf '\n%-8s  %-5s  %8s  %8s  %8s  %8s  %10s\n' \
        "scale" "path" "nft_med" "nft_p99" "sw_med" "sw_p99" "ratio"
    printf '%s\n' \
        "--------  -----  --------  --------  --------  --------  ----------"
}

# ── print one row ─────────────────────────────────────────────────────────────
print_row() {
    local scale=$1 mode=$2
    local ratio
    ratio=$(ratio_str "$_nft_med" "$_sw_med")
    printf '%-8s  %-5s  %6dms  %6dms  %6dms  %6dms  %s\n' \
        "$scale" "$mode" \
        "$_nft_med" "$_nft_p99" \
        "$_sw_med"  "$_sw_p99" \
        "$ratio"
}

# ── scaling summary ───────────────────────────────────────────────────────────
# Collect ratio_x10 values per (scale, mode) for the summary block
_ratios_text=""   # space-separated "scale:rx10" entries
_ratios_json=""

record_ratio() {
    local scale=$1 mode=$2
    local rx
    if [ "$_nft_med" -le 0 ]; then rx=10
    else rx=$(( (_sw_med * 10) / _nft_med )); fi
    if [ "$mode" = "text" ]; then
        _ratios_text=$(printf '%s %s:%d' "$_ratios_text" "$scale" "$rx")
    else
        _ratios_json=$(printf '%s %s:%d' "$_ratios_json" "$scale" "$rx")
    fi
}

# ── run all cells ─────────────────────────────────────────────────────────────
run_all() {
    printf 'list-perf-profile: stormwall vs nft  —  list ruleset scaling\n'
    printf 'nft=%s  sw=%s\n' "$NFT" "$SW"
    printf 'date=%s  N=%d\n' "$(date -u '+%Y-%m-%dT%H:%M:%SZ')" "$N"
    printf '\nScales:  SMALL=10pfx+10rules  MEDIUM=200pfx+50rules  LARGE=1000pfx+100rules\n'
    printf 'Timing window: list call only (apply+flush excluded)\n'

    print_header

    for scale in small medium large; do
        case "$scale" in
            small)  gf=gen_small  ;;
            medium) gf=gen_medium ;;
            large)  gf=gen_large  ;;
        esac

        for mode in text json; do
            measure_cell "$scale" "$gf" "$mode"
            print_row "$scale" "$mode"
            record_ratio "$scale" "$mode"
        done
    done

    # ── scaling interpretation ────────────────────────────────────────────────
    printf '\n--- scaling ratios (sw_median / nft_median) ---\n'
    printf '%-8s  %-5s  %s\n' "scale" "path" "ratio"
    printf '%s\n' "--------  -----  -----"

    for mode in text json; do
        if [ "$mode" = "text" ]; then entries=$_ratios_text
        else                         entries=$_ratios_json; fi
        for scale in small medium large; do
            rx=""
            for entry in $entries; do
                case "$entry" in "${scale}:"*) rx="${entry#*:}" ;; esac
            done
            if [ -n "$rx" ]; then
                printf '%-8s  %-5s  %d.%dx\n' \
                    "$scale" "$mode" "$((rx / 10))" "$((rx % 10))"
            fi
        done
    done

    # ── interpretation hint ───────────────────────────────────────────────────
    printf '\n--- interpretation ---\n'
    printf 'O(N) with high constant : sw ratios stay flat across scales\n'
    printf 'O(N^2) / per-set RTT    : ratio grows with scale (bend in small->large)\n'
    printf 'Render/JSON divergence  : text ratio differs significantly from json ratio\n'
    printf '                          at the same scale\n'
    printf '\nHypothesis map:\n'
    printf '  H1 per-set GETSETELEM  -> ratio grows with prefix count (large >> medium >> small)\n'
    printf '     src/ops.rs ~L1713: one dump(NFT_MSG_GETSETELEM) per set per collect_anon_sets()\n'
    printf '  H2 fixed overhead      -> ratio is roughly constant across scales\n'
    printf '  H3 render cost (text)  -> text ratio > json ratio at large scale\n'
    printf '  H4 JSON alloc cost     -> json ratio > text ratio at large scale\n'
}

run_all

# Final cleanup — leave the kernel in a known state
flush_all "$NFT"
flush_all "$SW"

printf '\ndone.\n'
