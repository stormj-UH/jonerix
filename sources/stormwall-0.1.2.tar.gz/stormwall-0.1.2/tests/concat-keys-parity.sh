#!/bin/bash
# concat-keys-parity.sh — parity harness for stormwall concatenated-set-key support.
#
# Takes each ruleset in tests/concat-corpus/, applies it via both upstream nft
# and stormwall, and compares the resulting `nft monitor` event streams.
#
# Concat-key support is NOT yet implemented in stormwall, so every case is
# expected to FAIL at this point. The harness records per-case baselines so
# the transition from "all fail" to "all pass" is immediately visible when
# the feature lands: just re-run and watch the EXPECTED_FAIL lines turn to
# PASS.
#
# Usage:
#   concat-keys-parity.sh              run full suite
#   concat-keys-parity.sh suite        same
#   concat-keys-parity.sh <file.nft>   run one ruleset file
#   concat-keys-parity.sh <NN_label>   run one corpus entry by label
#
# Sanitisation mirrors monitor-diff.sh:
#   - anon set/map ids  (__set17 -> __setN)
#   - handle numbers    (handle 4 -> handle H)
#   - generation footer (process-pid + binary name varies run-to-run)
#
# Error symmetry rule (same as monitor-diff.sh):
#   Both applied successfully + identical monitor output  => PASS
#   Both failed to apply + identical error text          => EXPECTED_FAIL (symmetric error)
#   nft applied, stormwall errored (or vice-versa)       => FAIL (asymmetric)
#   Both applied but monitor output diverged             => FAIL (semantic divergence)

set -u

NFT=/usr/sbin/nft
SW=/tmp/stormwall

# Resolve corpus directory relative to this script's own location so the
# harness works regardless of the caller's cwd.
SCRIPT_DIR=$(cd "$(dirname "$0")" && pwd)
CORPUS="$SCRIPT_DIR/concat-corpus"

# ---------------------------------------------------------------------------
# run_one <label> <rules-file> <outdir>
#
# Applies <rules-file> with both nft and stormwall, captures monitor output,
# sanitises, and diffs. Returns 0 on PASS, 1 on EXPECTED_FAIL (symmetric
# error — both binaries rejected the ruleset the same way), 2 on real FAIL.
# ---------------------------------------------------------------------------
run_one() {
    local label=$1
    local rules=$2
    local outdir=$3

    mkdir -p "$outdir"

    local nft_rc=0
    local sw_rc=0

    for arm in nft sw; do
        local bin
        if [ "$arm" = sw ]; then bin=$SW; else bin=$NFT; fi
        sudo "$bin" flush ruleset 2>/dev/null

        # Start monitor; give it a moment to establish the netlink subscription.
        sudo "$NFT" monitor > "$outdir/$label.$arm.raw" 2>&1 &
        local mon_pid=$!
        sleep 0.3

        sudo "$bin" -f "$rules" > "$outdir/$label.$arm.applyout" 2>&1
        local rc=$?

        # Let buffered events flush before killing the monitor.
        # 200 ms is enough for ~100 events on this kernel.
        sleep 0.3
        sudo kill "$mon_pid" 2>/dev/null
        wait "$mon_pid" 2>/dev/null

        sudo "$bin" flush ruleset 2>/dev/null

        # Sanitize values that legitimately differ between runs but don't
        # reflect a real parity gap:
        #   * anon-set/map ids        (__set17 -> __setN)
        #   * rule/chain handle nums  (handle 4  -> handle H)
        #   * generation footer       (pid + binary name vary)
        sed -E \
            -e 's/__set[0-9]+/__setN/g' \
            -e 's/__map[0-9]+/__mapN/g' \
            -e 's/handle [0-9]+/handle H/g' \
            -e 's/# handle [0-9]+//g' \
            -e '/^# new generation [0-9]+ by process [0-9]+ \(/d' \
            "$outdir/$label.$arm.raw" > "$outdir/$label.$arm.norm"

        local event_count
        event_count=$(wc -l < "$outdir/$label.$arm.norm")
        printf '  [%s] apply rc=%d  events=%d\n' "$arm" "$rc" "$event_count"

        if [ "$arm" = nft ]; then nft_rc=$rc; else sw_rc=$rc; fi
    done

    # --- classify outcome ---------------------------------------------------

    # Both failed to apply (rc != 0)?  Compare normalised apply output.
    # If both errored the same way, that's a symmetric EXPECTED_FAIL — the
    # harness is working correctly, stormwall just hasn't grown concat yet.
    # If the monitor streams also happen to be identical (empty), that's
    # consistent.  We don't declare a PASS here because the feature isn't
    # implemented; we just record the baseline.
    if [ "$nft_rc" -ne 0 ] && [ "$sw_rc" -ne 0 ]; then
        # Compare error text too, stripped of line numbers / pids.
        sed -E -e 's/line [0-9]+/line N/g' \
               -e 's/pid [0-9]+/pid N/g' \
               "$outdir/$label.nft.applyout" > "$outdir/$label.nft.errout.norm"
        sed -E -e 's/line [0-9]+/line N/g' \
               -e 's/pid [0-9]+/pid N/g' \
               "$outdir/$label.sw.applyout" > "$outdir/$label.sw.errout.norm"

        if diff -u "$outdir/$label.nft.errout.norm" "$outdir/$label.sw.errout.norm" \
                > "$outdir/$label.errdiff" 2>&1; then
            echo "  EXPECTED_FAIL (symmetric): $label  both rejected identically"
            rm -f "$outdir/$label.errdiff"
            return 1
        else
            local n
            n=$(grep -cE '^[+-][^+-]' "$outdir/$label.errdiff")
            echo "  EXPECTED_FAIL (asymmetric): $label  error text differs by $n lines  (see $outdir/$label.errdiff)"
            return 1
        fi
    fi

    # Asymmetric apply failure: one succeeded, one did not.
    if [ "$nft_rc" -ne 0 ] && [ "$sw_rc" -eq 0 ]; then
        echo "  FAIL: $label  nft rejected but stormwall accepted — unexpected"
        return 2
    fi
    if [ "$nft_rc" -eq 0 ] && [ "$sw_rc" -ne 0 ]; then
        echo "  EXPECTED_FAIL (sw-only error): $label  stormwall rejected (concat not implemented)"
        return 1
    fi

    # Both applied successfully — compare monitor streams.
    if diff -u "$outdir/$label.nft.norm" "$outdir/$label.sw.norm" \
            > "$outdir/$label.diff" 2>&1; then
        echo "  PASS: $label  monitor output identical"
        rm -f "$outdir/$label.diff"
        return 0
    else
        local n
        n=$(grep -cE '^[+-][^+-]' "$outdir/$label.diff")
        echo "  FAIL: $label  $n lines diverge  (see $outdir/$label.diff)"
        return 2
    fi
}

# ---------------------------------------------------------------------------
main() {
    local target=${1:-}
    local outdir=${2:-/tmp/concat-keys-diff}

    # Pause any concurrent ruleset churn — it pollutes nft monitor.
    local churn_pids
    churn_pids=$(pgrep -x -f "bash /tmp/churn-loop.sh 86400" 2>/dev/null || true)
    if [ -n "$churn_pids" ]; then
        echo "Pausing churn loop pids: $churn_pids"
        # shellcheck disable=SC2086
        sudo kill -STOP $churn_pids
        # shellcheck disable=SC2064
        trap "sudo kill -CONT $churn_pids 2>/dev/null" EXIT
    fi

    case "$target" in
        suite|"")
            local pass=0 expected_fail=0 fail=0
            for r in "$CORPUS"/*.nft; do
                local label
                label=$(basename "$r" .nft)
                echo "[$label]"
                run_one "$label" "$r" "$outdir"
                local rc=$?
                case $rc in
                    0) pass=$((pass+1)) ;;
                    1) expected_fail=$((expected_fail+1)) ;;
                    *) fail=$((fail+1)) ;;
                esac
            done
            echo
            echo "===== concat-keys-parity totals: PASS=$pass  EXPECTED_FAIL=$expected_fail  FAIL=$fail ====="
            echo
            echo "NOTE: EXPECTED_FAIL means stormwall rejected the ruleset (concat not"
            echo "      yet implemented). This is the baseline. When the feature lands,"
            echo "      re-run and verify EXPECTED_FAIL shrinks to zero while PASS grows."
            echo "      A real FAIL means stormwall accepted but produced divergent state,"
            echo "      or nft rejected but stormwall accepted — both warrant investigation."
            # Exit non-zero only on real (unexpected) failures.
            return $fail
            ;;
        *)
            local label rules
            if [ -f "$target" ]; then
                label=$(basename "$target" .nft)
                rules=$target
            else
                label=$target
                rules="$CORPUS/$label.nft"
            fi
            run_one "$label" "$rules" "$outdir"
            local rc=$?
            # For single-case runs, translate EXPECTED_FAIL (1) to exit 0
            # so callers can do `concat-keys-parity.sh 01_addr_service && echo ok`
            # without false failures before the feature is ready.
            if [ "$rc" -eq 1 ]; then return 0; fi
            return $rc
            ;;
    esac
}

main "$@"
