//! Output formatting - kernel data to nft syntax. 100% safe Rust.

use crate::netlink::*;
use std::net::Ipv4Addr;

/// `if_indextoname(3)` — turn an interface index back into a name.
/// Used by the dup / fwd / tproxy renderers: the kernel echoes back
/// the immediate that loaded the device-index register, and we want
/// the rule listing to show `device "lo"` rather than `device 1`.
/// Returns `None` for index 0 or when the interface no longer exists.
pub(crate) fn if_indextoname(idx: u32) -> Option<String> {
    if idx == 0 { return None; }
    let mut buf = [0u8; libc::IF_NAMESIZE];
    let p = unsafe { libc::if_indextoname(idx, buf.as_mut_ptr() as *mut libc::c_char) };
    if p.is_null() { return None; }
    let nul = buf.iter().position(|&b| b == 0).unwrap_or(buf.len());
    std::str::from_utf8(&buf[..nul]).ok().map(|s| s.to_string())
}

pub fn print_table_line(family: u8, attrs: &[(u16, Vec<u8>)]) {
    let name = attrs.iter().find(|(t, _)| *t == NFTA_TABLE_NAME).map(|(_, v)| attr_str(v)).unwrap_or("?");
    println!("table {} {}", family_str(family), name);
}

pub fn print_chain_header(family: u8, attrs: &[(u16, Vec<u8>)], show_handle: bool) {
    let name = attrs.iter().find(|(t, _)| *t == NFTA_CHAIN_NAME).map(|(_, v)| attr_str(v)).unwrap_or("?");
    let handle = attrs.iter().find(|(t, _)| *t == NFTA_CHAIN_HANDLE).map(|(_, v)| attr_u64_be(v));

    print!("\tchain {} {{", name);
    if show_handle { if let Some(h) = handle { print!(" # handle {}", h); } }
    println!();

    // Base chain properties: look for HOOK nested attribute
    if let Some((_, hook_data)) = attrs.iter().find(|(t, _)| *t == NFTA_CHAIN_HOOK) {
        let hook_attrs = parse_attrs(hook_data);
        let hooknum = hook_attrs.iter().find(|(t, _)| *t == NFTA_HOOK_HOOKNUM).map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
        let priority = hook_attrs.iter().find(|(t, _)| *t == NFTA_HOOK_PRIORITY).map(|(_, v)| attr_i32_be(v)).unwrap_or(0);

        let chain_type = attrs.iter().find(|(t, _)| *t == NFTA_CHAIN_TYPE).map(|(_, v)| attr_str(v)).unwrap_or("filter");
        let policy = attrs.iter().find(|(t, _)| *t == NFTA_CHAIN_POLICY).map(|(_, v)| attr_u32_be(v));

        print!("\t\ttype {} hook {} ", chain_type, hook_str_family(hooknum, family));
        // Ingress/egress chains carry a device attribute — render
        // it just before `priority` so the output matches upstream's
        // `type filter hook ingress device "lo" priority filter`.
        if let Some((_, devv)) = hook_attrs.iter().find(|(t, _)| *t == NFTA_HOOK_DEV) {
            print!("device \"{}\" ", attr_str(devv));
        }
        print!("priority ");
        print_priority(priority, family);
        print!(";");

        if let Some(p) = policy {
            print!(" policy {};", if p == NF_DROP as u32 { "drop" } else { "accept" });
        }
        println!();
    }
}

pub fn print_chain_footer() { println!("\t}}"); }

/// Render a flowtable inside its enclosing `table {}` body. Mirrors
/// upstream's three-line layout:
///
///     flowtable ft {
///             hook ingress priority filter
///             devices = { lo }
///     }
///
/// Priority decodes through the same keyword set chain headers use
/// (`filter`, `raw + N`, …). Devices is always brace-wrapped, even
/// when there's only one — that's how nft prints them.
pub fn print_flowtable(family: u8, attrs: &[(u16, Vec<u8>)]) {
    let name = attrs.iter().find(|(t, _)| *t == NFTA_FLOWTABLE_NAME)
        .map(|(_, v)| attr_str(v)).unwrap_or("?");
    println!("\tflowtable {} {{", name);

    let hook_data = attrs.iter().find(|(t, _)| *t == NFTA_FLOWTABLE_HOOK).map(|(_, v)| v);
    if let Some(hd) = hook_data {
        let ha = parse_attrs(hd);
        let hooknum = ha.iter().find(|(t, _)| *t == NFTA_FLOWTABLE_HOOK_NUM)
            .map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
        let priority = ha.iter().find(|(t, _)| *t == NFTA_FLOWTABLE_HOOK_PRIORITY)
            .map(|(_, v)| attr_i32_be(v)).unwrap_or(0);
        // Flowtables only run on the netdev/ingress hook today, but
        // pass through hook_str_family so a future kernel-side
        // expansion gets a consistent name.
        let hook_name = match hooknum {
            0 => "ingress",
            _ => "ingress",
        };
        print!("\t\thook {} priority ", hook_name);
        print_priority(priority, family);
        println!();

        // Devices nest: list of NFTA_DEVICE_NAME strings.
        let mut devs: Vec<String> = Vec::new();
        if let Some((_, dvb)) = ha.iter().find(|(t, _)| *t == NFTA_FLOWTABLE_HOOK_DEVS) {
            for (_, dv) in parse_attrs(dvb) {
                devs.push(attr_str(&dv).to_string());
            }
        }
        if !devs.is_empty() {
            print!("\t\tdevices = {{ ");
            for (i, d) in devs.iter().enumerate() {
                if i > 0 { print!(", "); }
                print!("{}", d);
            }
            println!(" }}");
        }
    }

    let flags = attrs.iter().find(|(t, _)| *t == NFTA_FLOWTABLE_FLAGS)
        .map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
    if flags & 0x1 != 0 {
        println!("\t\tflags offload");
    }
    println!("\t}}");
}

pub fn print_object(attrs: &[(u16, Vec<u8>)]) {
    let name = attrs.iter().find(|(t, _)| *t == NFTA_OBJ_NAME)
        .map(|(_, v)| attr_str(v)).unwrap_or("?");
    let kind = attrs.iter().find(|(t, _)| *t == NFTA_OBJ_TYPE)
        .map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
    let data = attrs.iter().find(|(t, _)| *t == NFTA_OBJ_DATA)
        .map(|(_, v)| parse_attrs(v)).unwrap_or_default();

    match kind {
        1 /* NFT_OBJECT_COUNTER */ => {
            let pkts = data.iter().find(|(t, _)| *t == NFTA_COUNTER_PACKETS)
                .map(|(_, v)| attr_u64_be(v)).unwrap_or(0);
            let bytes = data.iter().find(|(t, _)| *t == NFTA_COUNTER_BYTES)
                .map(|(_, v)| attr_u64_be(v)).unwrap_or(0);
            println!("\tcounter {} {{", name);
            println!("\t\tpackets {} bytes {}", pkts, bytes);
            println!("\t}}");
        }
        2 /* NFT_OBJECT_QUOTA */ => {
            let bytes = data.iter().find(|(t, _)| *t == NFTA_QUOTA_BYTES)
                .map(|(_, v)| attr_u64_be(v)).unwrap_or(0);
            let flags = data.iter().find(|(t, _)| *t == NFTA_QUOTA_FLAGS)
                .map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
            // Scale bytes back to the coarsest exact unit. Input form
            // `25 mbytes` encodes 26_214_400 bytes; we want to print
            // `25 mbytes`, not the raw value.
            let (val, unit) = if bytes >= 1 << 30 && bytes % (1 << 30) == 0 {
                (bytes >> 30, "gbytes")
            } else if bytes >= 1 << 20 && bytes % (1 << 20) == 0 {
                (bytes >> 20, "mbytes")
            } else if bytes >= 1 << 10 && bytes % (1 << 10) == 0 {
                (bytes >> 10, "kbytes")
            } else {
                (bytes, "bytes")
            };
            println!("\tquota {} {{", name);
            if flags & NFT_QUOTA_F_INV != 0 {
                println!("\t\tover {} {}", val, unit);
            } else {
                println!("\t\t{} {}", val, unit);
            }
            println!("\t}}");
        }
        4 /* NFT_OBJECT_LIMIT */ => {
            let rate = data.iter().find(|(t, _)| *t == NFTA_LIMIT_RATE)
                .map(|(_, v)| attr_u64_be(v)).unwrap_or(0);
            let unit = data.iter().find(|(t, _)| *t == NFTA_LIMIT_UNIT)
                .map(|(_, v)| attr_u64_be(v)).unwrap_or(1);
            let burst = data.iter().find(|(t, _)| *t == NFTA_LIMIT_BURST)
                .map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
            let unit_str = match unit {
                1 => "second", 60 => "minute", 3600 => "hour",
                86400 => "day", 604800 => "week", _ => "second",
            };
            println!("\tlimit {} {{", name);
            if burst > 0 {
                println!("\t\trate {}/{} burst {} packets", rate, unit_str, burst);
            } else {
                println!("\t\trate {}/{}", rate, unit_str);
            }
            println!("\t}}");
        }
        3 /* NFT_OBJECT_CT_HELPER */ => {
            // NFTA_CT_HELPER_NAME holds the helper *module* name (the
            // user-facing `type "ftp"` field). The user object name
            // was already pulled out of NFTA_OBJ_NAME above.
            let htype = data.iter().find(|(t, _)| *t == NFTA_CT_HELPER_NAME)
                .map(|(_, v)| attr_str(v).to_string()).unwrap_or_default();
            let proto = data.iter().find(|(t, _)| *t == NFTA_CT_HELPER_L4PROTO)
                .map(|(_, v)| v.first().copied().unwrap_or(0)).unwrap_or(0);
            let l3 = data.iter().find(|(t, _)| *t == NFTA_CT_HELPER_L3PROTO)
                .map(|(_, v)| {
                    if v.len() >= 2 { u16::from_be_bytes([v[0], v[1]]) } else { 0 }
                }).unwrap_or(0);
            let proto_str = match proto {
                6   => "tcp",
                17  => "udp",
                33  => "dccp",
                132 => "sctp",
                _   => "unknown",
            };
            let l3_str = match l3 as u8 {
                NFPROTO_IPV4 => "ip",
                NFPROTO_IPV6 => "ip6",
                NFPROTO_INET => "inet",
                _            => "inet",
            };
            println!("\tct helper {} {{", name);
            println!("\t\ttype \"{}\" protocol {}", htype, proto_str);
            println!("\t\tl3proto {}", l3_str);
            println!("\t}}");
        }
        _ => {}
    }
}

/// Emit a set body including its elements. Mirrors `nft list
/// ruleset` where each named set is followed by an `elements = { ... }`
/// line when non-empty.
pub fn print_set_with_elements(
    _family: u8,
    attrs: &[(u16, Vec<u8>)],
    elements: &[Vec<(u16, Vec<u8>)>],
    terse: bool,
) {
    let name = attrs.iter().find(|(t, _)| *t == NFTA_SET_NAME).map(|(_, v)| attr_str(v)).unwrap_or("?");
    let key_type = attrs.iter().find(|(t, _)| *t == NFTA_SET_KEY_TYPE).map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
    let flags = attrs.iter().find(|(t, _)| *t == NFTA_SET_FLAGS).map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
    let key_len = attrs.iter().find(|(t, _)| *t == NFTA_SET_KEY_LEN).map(|(_, v)| attr_u32_be(v)).unwrap_or(0);

    if flags & 0x1 != 0 { return; } // anonymous

    // `map` blocks render with the `map` keyword in real nft; only
    // plain sets use `set`. The kernel marks maps with NFT_SET_MAP.
    let kind = if flags & NFT_SET_MAP != 0 { "map" } else { "set" };
    println!("\t{} {} {{", kind, name);
    if flags & NFT_SET_MAP != 0 {
        let data_type = attrs.iter().find(|(t, _)| *t == NFTA_SET_DATA_TYPE).map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
        println!("\t\ttype {} : {}", set_type_name(key_type), set_type_name(data_type));
    } else {
        println!("\t\ttype {}", set_type_name(key_type));
    }

    // `size N` from NFTA_SET_DESC.NFTA_SET_DESC_SIZE — only present
    // when the user wrote `size N` in the source; nft list emits
    // it before flags and timeout.
    let desc_size = attrs.iter().find(|(t, _)| *t == NFTA_SET_DESC).and_then(|(_, v)| {
        let inner = parse_attrs(v);
        inner.iter().find(|(t, _)| *t == NFTA_SET_DESC_SIZE)
            .map(|(_, x)| attr_u32_be(x))
    });
    if let Some(sz) = desc_size {
        println!("\t\tsize {}", sz);
    }

    let mut flag_strs = Vec::new();
    if flags & NFT_SET_CONSTANT != 0 { flag_strs.push("constant"); }
    if flags & NFT_SET_INTERVAL != 0 { flag_strs.push("interval"); }
    // nft renders the EVAL ("dynamic") flag before TIMEOUT — see
    // src/expression/set.c set_eval_print_flags(), which emits
    // dynamic first, then timeout. Stormwall mirrors that order so
    // `flags dynamic,timeout` round-trips byte-for-byte.
    if flags & NFT_SET_EVAL     != 0 { flag_strs.push("dynamic"); }
    if flags & NFT_SET_TIMEOUT  != 0 { flag_strs.push("timeout"); }
    if !flag_strs.is_empty() {
        println!("\t\tflags {}", flag_strs.join(","));
    }
    // Default per-element timeout — nft renders this as a single
    // human duration (`timeout 1m`).
    let set_timeout_ms = attrs.iter().find(|(t, _)| *t == NFTA_SET_TIMEOUT)
        .map(|(_, v)| attr_u64_be(v)).unwrap_or(0);
    if set_timeout_ms > 0 {
        println!("\t\ttimeout {}", format_duration_ms(set_timeout_ms));
    }

    // Render elements. Terse mode (-t) omits them entirely.
    // For interval sets, pair up each start with its trailing
    // INTERVAL_END sentinel so ranges round-trip as `a-b` (or as
    // `addr/prefix` when they happen to span a CIDR boundary).
    if !terse {
        let is_interval = flags & NFT_SET_INTERVAL != 0;
        let is_map = flags & NFT_SET_MAP != 0;
        let data_type = attrs.iter().find(|(t, _)| *t == NFTA_SET_DATA_TYPE)
            .map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
        let data_len = attrs.iter().find(|(t, _)| *t == NFTA_SET_DATA_LEN)
            .map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
        // (key_bytes, is_end, verdict, data_value, timeout_ms, expires_ms).
        // timeout_ms / expires_ms come from NFTA_SET_ELEM_TIMEOUT and
        // NFTA_SET_ELEM_EXPIRATION; both render only on dynamic/timeout
        // sets and only when present (a 0 timeout means "no per-element
        // override"; the kernel still ships the attribute, which we
        // squash via Option<NonZero> semantics here).
        let mut raw: Vec<(Vec<u8>, bool, Option<(i32, String)>, Option<Vec<u8>>, u64, u64)> = Vec::new();
        for eattrs in elements {
            let eflags = eattrs.iter().find(|(t, _)| *t == NFTA_SET_ELEM_FLAGS)
                .map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
            let is_end = eflags & NFT_SET_ELEM_INTERVAL_END != 0;
            // Map element DATA is either NFTA_DATA_VERDICT (verdict
            // map) or NFTA_DATA_VALUE (data-valued map). Pull whichever
            // is present; both are exclusive on a given element.
            let (vd, data_val) = eattrs.iter().find(|(t, _)| *t == NFTA_SET_ELEM_DATA)
                .map(|(_, d)| {
                    let inner = parse_attrs(d);
                    let verdict = inner.iter().find(|(t, _)| *t == NFTA_DATA_VERDICT).map(|(_, vd)| {
                        let v = parse_attrs(vd);
                        let code = v.iter().find(|(t, _)| *t == NFTA_VERDICT_CODE)
                            .map(|(_, x)| attr_u32_be(x) as i32).unwrap_or(0);
                        let chain = v.iter().find(|(t, _)| *t == NFTA_VERDICT_CHAIN)
                            .map(|(_, x)| attr_str(x).to_string()).unwrap_or_default();
                        (code, chain)
                    });
                    let dv = inner.iter().find(|(t, _)| *t == NFTA_DATA_VALUE)
                        .map(|(_, v)| v.clone());
                    (verdict, dv)
                }).unwrap_or((None, None));
            let etimeout = eattrs.iter().find(|(t, _)| *t == NFTA_SET_ELEM_TIMEOUT)
                .map(|(_, v)| attr_u64_be(v)).unwrap_or(0);
            let eexpires = eattrs.iter().find(|(t, _)| *t == NFTA_SET_ELEM_EXPIRATION)
                .map(|(_, v)| attr_u64_be(v)).unwrap_or(0);
            let key = eattrs.iter().find(|(t, _)| *t == NFTA_SET_ELEM_KEY)
                .map(|(_, v)| parse_attrs(v));
            if let Some(k) = key {
                if let Some((_, data)) = k.iter().find(|(t, _)| *t == NFTA_DATA_VALUE) {
                    raw.push((data.clone(), is_end, vd, data_val, etimeout, eexpires));
                }
            }
        }
        let mut rendered: Vec<String> = Vec::new();
        if is_interval && is_map {
            // Interval-keyed map: pair start with end+1 sentinel, then
            // render `key : value` where value is either a verdict or
            // a data-valued map entry (e.g. ipv4_addr : ipv4_addr). The
            // kernel emits the END record with the same DATA value as
            // the start record; we keep the start's data. When two
            // ranges touch (end of one == start of next), the shared
            // value appears twice in the dump — put the END record
            // first so our start/end pairing doesn't misread them.
            raw.sort_by(|a, b| a.0.cmp(&b.0).then(b.1.cmp(&a.1)));
            let mut i = 0;
            while i < raw.len() {
                let (start, end_flag, vd, dv, _, _) = raw[i].clone();
                if end_flag { i += 1; continue; }
                let mut end: Option<Vec<u8>> = None;
                if i + 1 < raw.len() && raw[i + 1].1 {
                    let mut v = raw[i + 1].0.clone();
                    for byte in v.iter_mut().rev() {
                        if *byte == 0 { *byte = 0xff; } else { *byte -= 1; break; }
                    }
                    if v != start { end = Some(v); }
                    i += 2;
                } else { i += 1; }
                let key_str = format_interval_key(key_type, key_len, &start, end.as_deref());
                let value_str = if let Some((code, chain)) = vd {
                    verdict_str(code, &chain)
                } else if let Some(bytes) = dv {
                    format_set_key(data_type, data_len, &bytes)
                } else { String::new() };
                rendered.push(format!("{} : {}", key_str, value_str));
            }
        } else if is_interval {
            // Sort by (value, end_flag-desc) so touching intervals
            // pair up correctly — the end sentinel for the previous
            // range must sit immediately before the start of the
            // next range even when they share a value.
            raw.sort_by(|a, b| a.0.cmp(&b.0).then(b.1.cmp(&a.1)));
            let mut i = 0;
            while i < raw.len() {
                let (start, end_flag, _, _, _, _) = &raw[i];
                if *end_flag { i += 1; continue; }
                let mut end: Option<Vec<u8>> = None;
                if i + 1 < raw.len() && raw[i + 1].1 {
                    let mut v = raw[i + 1].0.clone();
                    for byte in v.iter_mut().rev() {
                        if *byte == 0 { *byte = 0xff; } else { *byte -= 1; break; }
                    }
                    if v != *start { end = Some(v); }
                    i += 2;
                } else { i += 1; }
                rendered.push(format_interval_key(key_type, key_len, start, end.as_deref()));
            }
        } else if is_map {
            let mut items: Vec<(Vec<u8>, Option<(i32, String)>, Option<Vec<u8>>, u64, u64)> = raw.into_iter()
                .filter_map(|(k, f, v, d, t, e)| if !f { Some((k, v, d, t, e)) } else { None })
                .collect();
            items.sort_by(|a, b| a.0.cmp(&b.0));
            for (k, v, d, t, e) in items {
                let key_str = format_set_key(key_type, key_len, &k);
                let value_str = if let Some((code, chain)) = v {
                    verdict_str(code, &chain)
                } else if let Some(bytes) = d {
                    format_set_key(data_type, data_len, &bytes)
                } else { String::new() };
                let mut deco = String::new();
                if t > 0 { deco.push_str(&format!(" timeout {}", format_duration_compound_ms(t))); }
                if e > 0 { deco.push_str(&format!(" expires {}",  format_duration_compound_ms(e))); }
                rendered.push(format!("{}{} : {}", key_str, deco, value_str));
            }
        } else {
            let mut starts: Vec<(Vec<u8>, u64, u64)> = raw.into_iter()
                .filter_map(|(k, f, _, _, t, e)| if !f { Some((k, t, e)) } else { None })
                .collect();
            starts.sort_by(|a, b| a.0.cmp(&b.0));
            for (d, t, e) in starts {
                let mut s = format_set_key(key_type, key_len, &d);
                if t > 0 { s.push_str(&format!(" timeout {}", format_duration_compound_ms(t))); }
                if e > 0 { s.push_str(&format!(" expires {}",  format_duration_compound_ms(e))); }
                rendered.push(s);
            }
        }
        if !rendered.is_empty() {
            println!("\t\telements = {{ {} }}", rendered.join(", "));
        }
    }

    println!("\t}}");
}

/// Decode a ct-state bitmask into its JSON representation. The
/// kernel stores the mask as a 4-byte BE u32 where each bit maps
/// to a state keyword (1=new, 2=related, 4=established, 8=untracked,
/// 16=invalid). Single bit → bare string; multiple bits → array.
fn format_ct_state_json(mask: &[u8]) -> String {
    // nft stores ct state masks in host byte order (the register is
    // also host-order), so decode as native-endian, not BE.
    let v: u32 = if mask.len() >= 4 {
        u32::from_ne_bytes([mask[0], mask[1], mask[2], mask[3]])
    } else { 0 };
    let names: &[(&str, u32)] = &[
        ("invalid", 1),
        ("established", 2),
        ("related", 4),
        ("new", 8),
        ("untracked", 64),
    ];
    let mut set: Vec<&str> = Vec::new();
    for (n, bit) in names {
        if v & *bit != 0 { set.push(*n); }
    }
    if set.len() == 1 {
        format!("\"{}\"", set[0])
    } else if set.is_empty() {
        format!("\"0x{:08x}\"", v)
    } else {
        let inner: Vec<String> = set.iter().map(|s| format!("\"{}\"", s)).collect();
        format!("[{}]", inner.join(", "))
    }
}

/// Render an interval set element — either a single value (when
/// end is None), a CIDR if the [start, end] range spans a power-of-two
/// prefix-aligned block, else `start-end`.
fn format_interval_key(key_type: u32, key_len: u32, start: &[u8], end: Option<&[u8]>) -> String {
    match end {
        None => format_set_key(key_type, key_len, start),
        Some(e) => {
            // Try CIDR detection for IPv4 (key_type 7) and IPv6 (8).
            if let Some(prefix) = try_cidr_prefix(start, e) {
                if key_type == 7 && start.len() == 4 {
                    return format!("{}.{}.{}.{}/{}", start[0], start[1], start[2], start[3], prefix);
                }
                if key_type == 8 && start.len() == 16 {
                    let mut octets = [0u8; 16];
                    octets.copy_from_slice(start);
                    let addr = std::net::Ipv6Addr::from(octets);
                    return format!("{}/{}", addr, prefix);
                }
            }
            format!("{}-{}", format_set_key(key_type, key_len, start),
                              format_set_key(key_type, key_len, e))
        }
    }
}

/// If `[start, end]` spans exactly a power-of-two prefix-aligned
/// block, return the prefix length. `end` is inclusive. Returns None
/// if the range isn't a clean CIDR.
fn try_cidr_prefix(start: &[u8], end: &[u8]) -> Option<u32> {
    if start.len() != end.len() { return None; }
    let bits = (start.len() * 8) as u32;
    // Compute size = end - start + 1. If size is a power of 2 and
    // start is aligned to size, prefix = bits - log2(size).
    // Work with u128 so 16-byte IPv6 fits.
    let mut s: u128 = 0;
    let mut e: u128 = 0;
    for &b in start { s = (s << 8) | b as u128; }
    for &b in end   { e = (e << 8) | b as u128; }
    if e < s { return None; }
    let size = e - s + 1;
    if !size.is_power_of_two() { return None; }
    if s & (size - 1) != 0 { return None; }
    let hostbits = size.trailing_zeros();
    Some(bits - hostbits)
}

/// Render an anon-set element list as the `{ a, b-c, ... }` body
/// that goes inside an inline lookup. Matches upstream's spacing —
/// comma+space between entries, `start-end` for ranges.
/// Text-form verdict for use inside vmap element renderings:
/// `accept` / `drop` / `return` / `continue` or `jump chain` /
/// `goto chain` for chain-targeted verdicts.
/// Render a millisecond duration the way `nft list` does — pick the
/// largest single unit that divides cleanly. Stormwall only feeds
/// this round numbers (`10s`, `1m`, `1h`, `1d`); composite forms
/// like `1m30s` aren't generated here because nft itself never round-
/// trips a per-element timeout in that shape.
pub fn format_duration_ms(ms: u64) -> String {
    if ms == 0 { return "0s".to_string(); }
    if ms % (24 * 3600 * 1000) == 0 { return format!("{}d", ms / (24 * 3600 * 1000)); }
    if ms % (3600 * 1000) == 0 { return format!("{}h", ms / (3600 * 1000)); }
    if ms % (60 * 1000) == 0 { return format!("{}m", ms / (60 * 1000)); }
    if ms % 1000 == 0 { return format!("{}s", ms / 1000); }
    format!("{}ms", ms)
}

/// Compound duration in nft's `time_print` form (lib/utils.c):
/// concatenated `<d>d<h>h<m>m<s>s<ms>ms` components, each only
/// emitted when non-zero. Examples: `5912ms` → `5s912ms`, `10000`
/// → `10s`, `90061500` → `1d1h1m1s500ms`. Used for per-element
/// `timeout`/`expires` decorators where nft mixes seconds and
/// milliseconds rather than collapsing to a single unit.
pub fn format_duration_compound_ms(ms: u64) -> String {
    if ms == 0 { return "0s".to_string(); }
    let day = 24u64 * 3600 * 1000;
    let hour = 3600u64 * 1000;
    let minute = 60u64 * 1000;
    let second = 1000u64;
    let mut rem = ms;
    let mut out = String::new();
    let d = rem / day; rem %= day;
    if d > 0 { out.push_str(&format!("{}d", d)); }
    let h = rem / hour; rem %= hour;
    if h > 0 { out.push_str(&format!("{}h", h)); }
    let m = rem / minute; rem %= minute;
    if m > 0 { out.push_str(&format!("{}m", m)); }
    let s = rem / second; rem %= second;
    if s > 0 { out.push_str(&format!("{}s", s)); }
    if rem > 0 { out.push_str(&format!("{}ms", rem)); }
    out
}

fn verdict_str(code: i32, chain: &str) -> String {
    match code {
        1 => "accept".to_string(),
        0 => "drop".to_string(),
        -1 => "continue".to_string(),
        -5 => "return".to_string(),
        -3 => format!("jump {}", chain),
        -4 => format!("goto {}", chain),
        _ => "accept".to_string(),
    }
}

/// Render a verdict code + chain pair as a libnftables-style JSON
/// value, matching the shape used inside vmap element tuples and
/// in `immediate` expressions. Unrecognised codes fall through to
/// `{"accept": null}` so the result is always valid JSON.
fn json_verdict(code: i32, chain: &str) -> String {
    match code {
        1 => "{\"accept\": null}".to_string(),
        0 => "{\"drop\": null}".to_string(),
        -1 => "{\"continue\": null}".to_string(),
        -5 => "{\"return\": null}".to_string(),
        -3 => format!("{{\"jump\": {{\"target\": \"{}\"}}}}", json_escape(chain)),
        -4 => format!("{{\"goto\": {{\"target\": \"{}\"}}}}", json_escape(chain)),
        _ => "{\"accept\": null}".to_string(),
    }
}

fn format_anon_set_elems(info: &AnonSetInfo) -> String {
    let mut parts: Vec<String> = Vec::new();
    for (start, end) in &info.elements {
        match end {
            Some(e) if e != start => parts.push(
                format_interval_key(info.key_type, info.key_len, start, Some(e))
            ),
            _ => parts.push(format_set_key(info.key_type, info.key_len, start)),
        }
    }
    parts.join(", ")
}

/// Like `format_anon_set_elems`, but emits `key : verdict` pairs for
/// anonymous verdict maps. Upstream formats these as
/// `{ 1.1.1.1 : accept, 2.2.2.2 : drop }`, with `jump chain` /
/// `goto chain` for chain-targeted verdicts.
fn format_anon_vmap_elems(info: &AnonSetInfo) -> String {
    let mut parts: Vec<String> = Vec::new();
    for (i, (start, _)) in info.elements.iter().enumerate() {
        let key = format_set_key(info.key_type, info.key_len, start);
        let (code, chain) = info.verdicts.get(i).cloned().unwrap_or((0, String::new()));
        let verdict = match code {
            1 => "accept".to_string(),
            0 => "drop".to_string(),
            -1 => "continue".to_string(),
            -5 => "return".to_string(),
            -3 if !chain.is_empty() => format!("jump {}", chain),
            -4 if !chain.is_empty() => format!("goto {}", chain),
            _ => "accept".to_string(),
        };
        parts.push(format!("{} : {}", key, verdict));
    }
    parts.join(", ")
}

fn format_set_key(key_type: u32, _key_len: u32, data: &[u8]) -> String {
    match key_type {
        7 /* ipv4_addr */ if data.len() == 4 => {
            format!("{}.{}.{}.{}", data[0], data[1], data[2], data[3])
        }
        8 /* ipv6_addr */ if data.len() == 16 => {
            let mut octets = [0u8; 16];
            octets.copy_from_slice(data);
            let addr = std::net::Ipv6Addr::from(octets);
            format!("{}", addr)
        }
        9 /* ether_addr */ if data.len() == 6 => {
            format!("{:02x}:{:02x}:{:02x}:{:02x}:{:02x}:{:02x}",
                data[0], data[1], data[2], data[3], data[4], data[5])
        }
        12 /* inet_proto */ if data.len() == 1 => {
            match data[0] {
                6  => "tcp".to_string(),
                17 => "udp".to_string(),
                1  => "icmp".to_string(),
                58 => "icmpv6".to_string(),
                2  => "igmp".to_string(),
                47 => "gre".to_string(),
                50 => "esp".to_string(),
                51 => "ah".to_string(),
                89 => "ospf".to_string(),
                132 => "sctp".to_string(),
                n  => format!("{}", n),
            }
        }
        13 /* inet_service */ if data.len() == 2 => {
            format!("{}", u16::from_be_bytes([data[0], data[1]]))
        }
        15 /* mark */ if data.len() == 4 => {
            format!("0x{:08x}", u32::from_be_bytes([data[0], data[1], data[2], data[3]]))
        }
        16 /* ifname */ => {
            let s = data.iter().take_while(|&&b| b != 0).copied().collect::<Vec<u8>>();
            format!("\"{}\"", String::from_utf8_lossy(&s))
        }
        _ => {
            // Fallback: show as a decimal integer when it fits.
            if data.len() == 1 { format!("{}", data[0]) }
            else if data.len() == 2 { format!("{}", u16::from_be_bytes([data[0], data[1]])) }
            else if data.len() == 4 { format!("{}", u32::from_be_bytes([data[0], data[1], data[2], data[3]])) }
            else {
                data.iter().map(|b| format!("{:02x}", b)).collect::<Vec<_>>().join(":")
            }
        }
    }
}

pub fn print_set_header(_family: u8, attrs: &[(u16, Vec<u8>)]) {
    let table = attrs.iter().find(|(t, _)| *t == NFTA_SET_TABLE).map(|(_, v)| attr_str(v)).unwrap_or("?");
    let name = attrs.iter().find(|(t, _)| *t == NFTA_SET_NAME).map(|(_, v)| attr_str(v)).unwrap_or("?");
    let key_type = attrs.iter().find(|(t, _)| *t == NFTA_SET_KEY_TYPE).map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
    let flags = attrs.iter().find(|(t, _)| *t == NFTA_SET_FLAGS).map(|(_, v)| attr_u32_be(v)).unwrap_or(0);

    // Skip anonymous sets (kernel-internal)
    if flags & 0x1 != 0 { return; }

    let kind = if flags & NFT_SET_MAP != 0 { "map" } else { "set" };
    println!("\t{} {} {{", kind, name);
    if flags & NFT_SET_MAP != 0 {
        let data_type = attrs.iter().find(|(t, _)| *t == NFTA_SET_DATA_TYPE).map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
        println!("\t\ttype {} : {}", set_type_name(key_type), set_type_name(data_type));
    } else {
        println!("\t\ttype {}", set_type_name(key_type));
    }

    let mut flag_strs = Vec::new();
    if flags & NFT_SET_CONSTANT != 0 { flag_strs.push("constant"); }
    if flags & NFT_SET_INTERVAL != 0 { flag_strs.push("interval"); }
    if !flag_strs.is_empty() {
        println!("\t\tflags {}", flag_strs.join(","));
    }
    let _ = table;
    println!("\t}}");
}

fn print_priority(prio: i32, family: u8) {
    let names: &[(&str, i32)] = if family == NFPROTO_BRIDGE {
        &[("dstnat", -300), ("filter", -200), ("out", 100), ("srcnat", 300)]
    } else {
        &[("raw", -300), ("mangle", -150), ("dstnat", -100), ("filter", 0), ("security", 50), ("srcnat", 100)]
    };

    for &(name, val) in names {
        if prio == val { print!("{}", name); return; }
        let diff = prio - val;
        if diff.abs() <= 10 && diff != 0 {
            print!("{} {} {}", name, if diff > 0 { "+" } else { "-" }, diff.abs());
            return;
        }
    }
    print!("{}", prio);
}

/// Bundle of per-set metadata needed to render rules in a table.
/// When a rule's `lookup` expression names an anonymous set we have
/// to inline its elements — upstream `nft list ruleset` does that
/// too, and the test framework's diff is sensitive to the keyword
/// vs. `@__setN` distinction. The registry maps set name ->
/// (key_type, key_len, element keys in INTERVAL_END-aware order,
/// range_ends parallel to the keys).
#[derive(Default, Clone)]
pub struct AnonSetRegistry {
    pub sets: std::collections::HashMap<String, AnonSetInfo>,
}
#[derive(Clone)]
pub struct AnonSetInfo {
    pub key_type: u32,
    pub key_len: u32,
    pub is_interval: bool,
    /// Element list with optional range ends. For an interval set
    /// the kernel stores [start, end+1|INTERVAL_END] pairs; the
    /// caller collapses those back into (start, Some(end)) here.
    pub elements: Vec<(Vec<u8>, Option<Vec<u8>>)>,
    /// `true` if this set is a verdict map (NFT_SET_MAP flag), in
    /// which case `verdicts` holds the per-element (code, chain)
    /// pairs parallel to `elements`.
    pub is_map: bool,
    pub verdicts: Vec<(i32, String)>,
}

pub fn print_rule(attrs: &[(u16, Vec<u8>)], show_handle: bool, stateless: bool) {
    print_rule_with_sets(attrs, show_handle, stateless, &AnonSetRegistry::default())
}

pub fn print_rule_with_sets(attrs: &[(u16, Vec<u8>)], show_handle: bool, stateless: bool, registry: &AnonSetRegistry) {
    print!("\t\t");

    if let Some((_, exprs_data)) = attrs.iter().find(|(t, _)| *t == NFTA_RULE_EXPRESSIONS) {
        let elems = parse_attrs(exprs_data);

        // Pre-scan the expression stream so we can elide
        // implicit `meta l4proto X` deps that precede a
        // transport-header payload load on the same proto
        // — upstream `nft list` hides them. We also still
        // use the proto to pick "tcp sport" vs "udp sport".
        let decoded: Vec<(String, Vec<(u16, Vec<u8>)>)> = elems.iter().map(|(_, ed)| {
            let a = parse_attrs(ed);
            let n = a.iter().find(|(t, _)| *t == NFTA_EXPR_NAME)
                .map(|(_, v)| attr_str(v).to_string()).unwrap_or_default();
            let d = a.iter().find(|(t, _)| *t == NFTA_EXPR_DATA)
                .map(|(_, v)| parse_attrs(v)).unwrap_or_default();
            (n, d)
        }).collect();
        let (skip, proto_hint) = compute_l4proto_elision(&decoded);

        let mut ctx = RuleCtx::new();
        if let Some(p) = proto_hint { ctx.proto_ctx = p; }
        let mut first = true;
        for (i, (name, data_attrs)) in decoded.iter().enumerate() {
            if skip[i] { continue; }
            format_expr(name, data_attrs, &mut ctx, &mut first, stateless, registry);
        }
    }

    // Rule comment lives in NFTA_RULE_USERDATA as a TLV blob. Format:
    //   [u8 type][u8 len][len bytes (NUL-terminated string)]
    // type 0 = NFTNL_UDATA_RULE_COMMENT. Walk the blob; the first comment
    // wins.
    if let Some((_, ud)) = attrs.iter().find(|(t, _)| *t == NFTA_RULE_USERDATA) {
        let mut i = 0usize;
        while i + 2 <= ud.len() {
            let ty = ud[i];
            let ln = ud[i + 1] as usize;
            i += 2;
            if i + ln > ud.len() { break; }
            if ty == 0 {
                let s = &ud[i..i + ln];
                let trimmed = s.iter().take_while(|&&b| b != 0).copied().collect::<Vec<u8>>();
                if let Ok(txt) = std::str::from_utf8(&trimmed) {
                    print!(" comment \"{}\"", txt);
                }
                break;
            }
            i += ln;
        }
    }

    if show_handle {
        if let Some((_, v)) = attrs.iter().find(|(t, _)| *t == NFTA_RULE_HANDLE) {
            print!(" # handle {}", attr_u64_be(v));
        }
    }
    println!();
}

// ── Rule expression formatting ──────────────────────────────────

#[derive(Clone, Copy, PartialEq)]
enum FieldId { IpSaddr, IpDaddr, IpProto, IpDscp, Ip6Saddr, Ip6Daddr,
               TcpSport, TcpDport, TcpFlags, UdpSport, UdpDport,
               IcmpType, IcmpCode, EtherType, Unknown }

/// Decide which positions in the expression stream should be
/// elided from text output because they're implicit transport
/// dependencies. Input is the (name, data) pair list. Returns a
/// parallel Vec<bool> — true means "don't format this one".
fn compute_l4proto_elision(exprs: &[(String, Vec<(u16, Vec<u8>)>)]) -> (Vec<bool>, Option<u8>) {
    let mut skip = vec![false; exprs.len()];
    let mut proto_hint: Option<u8> = None;
    let mut i = 0;
    while i < exprs.len() {
        // Look for a `meta` with NFTA_META_KEY == NFT_META_L4PROTO.
        if exprs[i].0 == "meta" {
            let key = exprs[i].1.iter().find(|(t, _)| *t == NFTA_META_KEY)
                .map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
            if key == NFT_META_L4PROTO && i + 1 < exprs.len() && exprs[i + 1].0 == "cmp" {
                let op = exprs[i + 1].1.iter().find(|(t, _)| *t == NFTA_CMP_OP)
                    .map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
                let d = exprs[i + 1].1.iter().find(|(t, _)| *t == NFTA_CMP_DATA)
                    .map(|(_, v)| {
                        let inner = parse_attrs(v);
                        inner.iter().find(|(t, _)| *t == NFTA_DATA_VALUE).map(|(_, v)| v.clone()).unwrap_or_default()
                    }).unwrap_or_default();
                if op == NFT_CMP_EQ && d.len() == 1 {
                    let proto = d[0];
                    // Look ahead for a transport-header payload in the
                    // rest of the rule. If found on matching proto,
                    // elide the meta + cmp pair.
                    let mut found = false;
                    for (n, da) in exprs[i + 2..].iter() {
                        if n == "payload" {
                            let base = da.iter().find(|(t, _)| *t == NFTA_PAYLOAD_BASE)
                                .map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
                            if base == NFT_PAYLOAD_TRANSPORT_HEADER && matches!(proto, 1 | 6 | 17 | 58) {
                                found = true; break;
                            }
                        }
                    }
                    if found {
                        skip[i] = true;
                        skip[i + 1] = true;
                        proto_hint = Some(proto);
                        i += 2;
                        continue;
                    }
                }
            }
            // Elide `meta nfproto` + `cmp(eq, AF)` when the next expression
            // is a network-header payload load. In inet+ingress rules the
            // kernel inserts an implicit nfproto guard; upstream `nft list`
            // suppresses it.
            if key == NFT_META_NFPROTO && i + 1 < exprs.len() && exprs[i + 1].0 == "cmp" {
                let op = exprs[i + 1].1.iter().find(|(t, _)| *t == NFTA_CMP_OP)
                    .map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
                let d = exprs[i + 1].1.iter().find(|(t, _)| *t == NFTA_CMP_DATA)
                    .map(|(_, v)| {
                        let inner = parse_attrs(v);
                        inner.iter().find(|(t, _)| *t == NFTA_DATA_VALUE).map(|(_, v)| v.clone()).unwrap_or_default()
                    }).unwrap_or_default();
                // The kernel sends nfproto as a 1-byte or 4-byte big-endian
                // value (NFPROTO_IPV4=2, NFPROTO_IPV6=10).
                let af: u32 = match d.len() {
                    1 => d[0] as u32,
                    4 => u32::from_be_bytes([d[0], d[1], d[2], d[3]]),
                    _ => 0,
                };
                if op == NFT_CMP_EQ && (af == 2 || af == 10) && i + 2 < exprs.len() {
                    let mut found = false;
                    for (n, da) in exprs[i + 2..].iter() {
                        if n == "bitwise" { continue; }
                        if n == "payload" {
                            let base = da.iter().find(|(t, _)| *t == NFTA_PAYLOAD_BASE)
                                .map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
                            if base == NFT_PAYLOAD_NETWORK_HEADER { found = true; }
                        }
                        break;
                    }
                    if found {
                        skip[i] = true;
                        skip[i + 1] = true;
                        i += 2;
                        continue;
                    }
                }
            }
        }
        i += 1;
    }
    (skip, proto_hint)
}

struct RuleCtx {
    field: FieldId,
    meta_key: Option<u32>,
    ct_key: Option<u32>,
    socket_key: Option<u32>,
    rt_key: Option<u32>,
    has_bitwise: bool,
    bw_mask: Vec<u8>,
    proto_ctx: u8,
    /// Pending value for a `meta KEY set <expr>` mangle. The producing
    /// numgen / jhash / symhash expression renders nothing on its own;
    /// it stashes its right-hand-side text here, and the trailing meta
    /// expression with NFTA_META_SREG flushes it together with the
    /// `meta KEY set` prefix. Plain meta read-side matches see this
    /// field as None and behave as before.
    pending_set_value: Option<String>,
    /// Cached payload field for a payload-load that fed a jhash. The
    /// hash arm consumes it to compose the rendered `jhash <field>`
    /// text. Cleared by the trailing meta-set or by any non-hash
    /// expression that takes its place.
    hash_key_field: Option<FieldId>,
    /// Stashed immediate-loaded values keyed by destination register.
    /// Two consumers share this map:
    ///   - dup / fwd / tproxy renderers, which pull the SREG_*-named
    ///     register to recover the address / ifindex / port bytes;
    ///   - the nat / snat / dnat / masquerade renderer, which reads
    ///     NFT_REG32_01 (and _02 for ranges) so `snat to 1.2.3.4` and
    ///     `snat to 1.2.3.4-1.2.3.10` round-trip through `list ruleset`.
    /// Filled by the `immediate` arm; the consumer interprets the
    /// raw bytes as IPv4 vs ifindex vs port from context.
    pending_imm: std::collections::HashMap<u32, Vec<u8>>,
}

impl RuleCtx {
    fn new() -> Self {
        RuleCtx {
            field: FieldId::Unknown, meta_key: None, ct_key: None, socket_key: None,
            rt_key: None, has_bitwise: false, bw_mask: Vec::new(), proto_ctx: 0,
            pending_set_value: None, hash_key_field: None,
            pending_imm: std::collections::HashMap::new(),
        }
    }
    fn clear(&mut self) {
        self.field = FieldId::Unknown; self.meta_key = None; self.ct_key = None;
        self.socket_key = None; self.rt_key = None; self.has_bitwise = false;
    }
}

fn identify_payload(base: u32, offset: u32, len: u32) -> FieldId {
    match (base, offset, len) {
        // ip saddr/daddr: nft may emit a 1-, 2-, or 3-byte payload load
        // as an optimisation for /8, /16, /24 prefix matches (no bitwise
        // needed when the mask aligns to a byte boundary).  Accept any
        // len 1-4 at the saddr/daddr offsets.
        (1, 12, 1..=4) => FieldId::IpSaddr,
        (1, 16, 1..=4) => FieldId::IpDaddr,
        (1, 9, 1) => FieldId::IpProto,
        // DSCP: upper 6 bits of the TOS byte (network header offset 1).
        // Identified only when followed by a bitwise mask=0xfc — the
        // bitwise arm will confirm this; identify_payload marks it
        // tentatively and the cmp arm renders it.
        (1, 1, 1) => FieldId::IpDscp,
        (1, 8, 16) => FieldId::Ip6Saddr, (1, 24, 16) => FieldId::Ip6Daddr,
        (2, 0, 2) => FieldId::TcpSport, (2, 2, 2) => FieldId::TcpDport,
        (2, 13, 1) => FieldId::TcpFlags,
        (2, 0, 1) => FieldId::IcmpType, (2, 1, 1) => FieldId::IcmpCode,
        // ether type: link-layer header offset 12, 2 bytes
        (0, 12, 2) => FieldId::EtherType,
        _ => FieldId::Unknown,
    }
}

fn field_name(f: FieldId, proto: u8) -> &'static str {
    match f {
        FieldId::IpSaddr => "ip saddr", FieldId::IpDaddr => "ip daddr",
        FieldId::IpProto => "ip protocol",
        FieldId::IpDscp => "ip dscp",
        FieldId::Ip6Saddr => "ip6 saddr", FieldId::Ip6Daddr => "ip6 daddr",
        // proto==0 means the rule didn't pin a specific layer-4
        // protocol — typically `meta l4proto { tcp, udp } th dport 53`
        // matches both, so upstream renders the transport-agnostic
        // `th sport/dport` form rather than guessing tcp.
        FieldId::TcpSport => match proto { 17 => "udp sport", 6 => "tcp sport", _ => "th sport" },
        FieldId::TcpDport => match proto { 17 => "udp dport", 6 => "tcp dport", _ => "th dport" },
        FieldId::TcpFlags => "tcp flags",
        FieldId::UdpSport => "udp sport", FieldId::UdpDport => "udp dport",
        FieldId::IcmpType => "icmp type", FieldId::IcmpCode => "icmp code",
        FieldId::EtherType => "ether type",
        FieldId::Unknown => "unknown",
    }
}

fn meta_key_name(key: u32) -> &'static str {
    match key {
        NFT_META_IIFNAME => "iifname", NFT_META_OIFNAME => "oifname",
        NFT_META_IIF => "meta iif", NFT_META_OIF => "meta oif",
        NFT_META_MARK => "meta mark", NFT_META_L4PROTO => "meta l4proto",
        NFT_META_NFPROTO => "meta nfproto", NFT_META_PKTTYPE => "meta pkttype",
        NFT_META_SKUID => "meta skuid", NFT_META_SKGID => "meta skgid",
        NFT_META_LEN => "meta length",
        NFT_META_CPU => "meta cpu",
        NFT_META_CGROUP => "meta cgroup",
        _ => "meta unknown",
    }
}

fn socket_key_name(key: u32) -> &'static str {
    match key {
        NFT_SOCKET_TRANSPARENT => "socket transparent",
        NFT_SOCKET_MARK        => "socket mark",
        NFT_SOCKET_WILDCARD    => "socket wildcard",
        NFT_SOCKET_CGROUPV2    => "socket cgroupv2",
        _ => "socket unknown",
    }
}

fn rt_key_name(key: u32) -> &'static str {
    match key {
        NFT_RT_CLASSID  => "rt classid",
        NFT_RT_NEXTHOP4 => "rt nexthop",
        NFT_RT_NEXTHOP6 => "rt nexthop",
        NFT_RT_TCPMSS   => "rt mtu",
        _ => "rt unknown",
    }
}

fn ct_key_name(key: u32) -> &'static str {
    match key {
        NFT_CT_STATE => "ct state", NFT_CT_MARK => "ct mark",
        NFT_CT_STATUS => "ct status", NFT_CT_DIRECTION => "ct direction",
        NFT_CT_ZONE => "ct zone", NFT_CT_HELPER => "ct helper",
        NFT_CT_L3PROTOCOL => "ct l3proto", NFT_CT_PROTOCOL => "ct protocol",
        NFT_CT_PKTS => "ct packets", NFT_CT_BYTES => "ct bytes",
        NFT_CT_EXPIRATION => "ct expiration",
        _ => "ct unknown",
    }
}

fn format_expr(name: &str, data: &[(u16, Vec<u8>)], ctx: &mut RuleCtx, first: &mut bool, stateless: bool, registry: &AnonSetRegistry) {
    match name {
        "payload" => {
            let base = data.iter().find(|(t, _)| *t == NFTA_PAYLOAD_BASE).map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
            let offset = data.iter().find(|(t, _)| *t == NFTA_PAYLOAD_OFFSET).map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
            let len = data.iter().find(|(t, _)| *t == NFTA_PAYLOAD_LEN).map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
            ctx.field = identify_payload(base, offset, len);
            ctx.has_bitwise = false;
        }
        "meta" => {
            ctx.meta_key = data.iter().find(|(t, _)| *t == NFTA_META_KEY).map(|(_, v)| attr_u32_be(v));
            ctx.field = FieldId::Unknown; ctx.ct_key = None; ctx.socket_key = None; ctx.rt_key = None; ctx.has_bitwise = false;
            // `meta KEY set <expr>` mangle sink: kernel UAPI signals
            // the write side by carrying NFTA_META_SREG (3) instead
            // of NFTA_META_DREG (1). When the prior numgen / hash
            // expression stashed its rendered RHS in pending_set_value
            // we flush the combined statement here and clear ctx so
            // the rule line continues from the next expression.
            let has_sreg = data.iter().any(|(t, _)| *t == NFTA_META_SREG);
            if has_sreg {
                if let (Some(k), Some(v)) = (ctx.meta_key, ctx.pending_set_value.take()) {
                    if !*first { print!(" "); } *first = false;
                    print!("{} set {}", meta_key_name(k), v);
                    ctx.hash_key_field = None;
                    ctx.clear();
                }
            }
        }
        "numgen" => {
            // `numgen` produces a value in NFT_REG_1 for the next
            // expression to consume. Render nothing now; stash the
            // text so the following meta-SREG (or other consumer)
            // can emit a single combined statement.
            let ng_type = data.iter().find(|(t, _)| *t == NFTA_NG_TYPE).map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
            let modulus = data.iter().find(|(t, _)| *t == NFTA_NG_MODULUS).map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
            let offset  = data.iter().find(|(t, _)| *t == NFTA_NG_OFFSET).map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
            let mode = if ng_type == NFT_NG_RANDOM { "random" } else { "inc" };
            let s = if offset != 0 {
                format!("numgen {} mod {} offset {}", mode, modulus, offset)
            } else {
                format!("numgen {} mod {}", mode, modulus)
            };
            ctx.pending_set_value = Some(s);
        }
        "hash" => {
            // `hash` covers both jhash (NFT_HASH_JENKINS) and symhash
            // (NFT_HASH_SYM). Same combinator pattern as numgen — we
            // stash the rendered RHS for the trailing meta-SREG to
            // flush. jhash needs a key-field name; the preceding
            // payload load wrote into ctx.field.
            let hash_type = data.iter().find(|(t, _)| *t == NFTA_HASH_TYPE).map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
            let modulus = data.iter().find(|(t, _)| *t == NFTA_HASH_MODULUS).map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
            let offset  = data.iter().find(|(t, _)| *t == NFTA_HASH_OFFSET).map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
            let seed    = data.iter().find(|(t, _)| *t == NFTA_HASH_SEED).map(|(_, v)| attr_u32_be(v));
            let s = if hash_type == NFT_HASH_SYM {
                if offset != 0 {
                    format!("symhash mod {} offset {}", modulus, offset)
                } else {
                    format!("symhash mod {}", modulus)
                }
            } else {
                let key_text = field_name(ctx.field, ctx.proto_ctx);
                let mut t = format!("jhash {} mod {}", key_text, modulus);
                if let Some(s) = seed {
                    t = format!("{} seed 0x{:08x}", t, s);
                }
                if offset != 0 {
                    t = format!("{} offset {}", t, offset);
                }
                t
            };
            ctx.pending_set_value = Some(s);
            // Clear the payload-derived field so a subsequent cmp
            // doesn't accidentally consume it as a match target.
            ctx.field = FieldId::Unknown;
        }
        "ct" => {
            ctx.ct_key = data.iter().find(|(t, _)| *t == NFTA_CT_KEY).map(|(_, v)| attr_u32_be(v));
            ctx.field = FieldId::Unknown; ctx.meta_key = None; ctx.socket_key = None; ctx.rt_key = None; ctx.has_bitwise = false;
        }
        "socket" => {
            ctx.socket_key = data.iter().find(|(t, _)| *t == NFTA_SOCKET_KEY).map(|(_, v)| attr_u32_be(v));
            ctx.field = FieldId::Unknown; ctx.meta_key = None; ctx.ct_key = None; ctx.rt_key = None; ctx.has_bitwise = false;
        }
        "rt" => {
            ctx.rt_key = data.iter().find(|(t, _)| *t == NFTA_RT_KEY).map(|(_, v)| attr_u32_be(v));
            ctx.field = FieldId::Unknown; ctx.meta_key = None; ctx.ct_key = None; ctx.socket_key = None; ctx.has_bitwise = false;
        }
        "bitwise" => {
            ctx.has_bitwise = true;
            if let Some((_, v)) = data.iter().find(|(t, _)| *t == NFTA_BITWISE_MASK) {
                let inner = parse_attrs(v);
                if let Some((_, mask_data)) = inner.iter().find(|(t, _)| *t == NFTA_DATA_VALUE) {
                    ctx.bw_mask = mask_data.clone();
                }
            }
        }
        "cmp" => {
            let op = data.iter().find(|(t, _)| *t == NFTA_CMP_OP).map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
            let cmp_data = data.iter().find(|(t, _)| *t == NFTA_CMP_DATA).map(|(_, v)| {
                let inner = parse_attrs(v);
                inner.iter().find(|(t, _)| *t == NFTA_DATA_VALUE).map(|(_, d)| d.clone()).unwrap_or_default()
            }).unwrap_or_default();

            if !*first { print!(" "); } *first = false;

            // Print context
            if ctx.field != FieldId::Unknown { print!("{} ", field_name(ctx.field, ctx.proto_ctx)); }
            else if let Some(k) = ctx.meta_key { print!("{} ", meta_key_name(k)); }
            else if let Some(k) = ctx.ct_key { print!("{} ", ct_key_name(k)); }
            else if let Some(k) = ctx.socket_key { print!("{} ", socket_key_name(k)); }
            else if let Some(k) = ctx.rt_key { print!("{} ", rt_key_name(k)); }

            // tcp flags — masked form: bitwise(mask) + cmp(eq, val).
            // Render as `tcp flags & (<mask_names>) == <val_names>`.
            // Example: mask=0x16 val=0x02 → `tcp flags & (syn | rst | ack) == syn`
            if ctx.has_bitwise && ctx.field == FieldId::TcpFlags
                && op == NFT_CMP_EQ && cmp_data.len() == 1
            {
                let mask_byte = ctx.bw_mask.first().copied().unwrap_or(0);
                let val_byte = cmp_data[0];
                print!("& ({}) == {}", tcp_mask_names(mask_byte), tcp_flags_names(val_byte));
            // tcp flags — simple form: payload + cmp(eq, val).
            // Render as `tcp flags <names>` (comma-separated).
            } else if !ctx.has_bitwise && ctx.field == FieldId::TcpFlags
                && op == NFT_CMP_EQ && cmp_data.len() == 1
            {
                print!("{}", tcp_flags_names(cmp_data[0]));
            // ct state bitmask: bitwise(mask) + cmp(neq|eq, 0).
            // `neq 0` → `ct state NAME`  (any bit set)
            // `eq 0`  → `ct state != NAME` (no bit set)
            } else if ctx.has_bitwise && ctx.ct_key == Some(NFT_CT_STATE)
                && (op == NFT_CMP_NEQ || op == NFT_CMP_EQ)
            {
                if op == NFT_CMP_EQ { print!("!= "); }
                format_value(&ctx.bw_mask, ctx.field, ctx.meta_key, ctx.ct_key, ctx.proto_ctx);
            } else if ctx.has_bitwise && ctx.field == FieldId::IpDscp
                && ctx.bw_mask.first().copied() == Some(0xfc)
                && cmp_data.len() == 1
            {
                // DSCP: the stored cmp byte is (user_value << 2); decode
                // back to the 6-bit codepoint and print as a plain integer.
                if op == NFT_CMP_NEQ { print!("!= "); }
                print!("{}", cmp_data[0] >> 2);
            } else if !ctx.has_bitwise
                && matches!(ctx.field, FieldId::IpSaddr | FieldId::IpDaddr)
                && cmp_data.len() < 4
            {
                // nft byte-boundary CIDR optimisation: the kernel loads
                // only the significant bytes of the address and compares
                // directly — no bitwise mask needed.  Reconstruct the
                // full /8, /16, or /24 prefix from the payload length.
                if op == NFT_CMP_NEQ { print!("!= "); }
                let mut padded = [0u8; 4];
                padded[..cmp_data.len()].copy_from_slice(&cmp_data);
                print!("{}/{}", Ipv4Addr::new(padded[0], padded[1], padded[2], padded[3]),
                       cmp_data.len() * 8);
            } else {
                if op == NFT_CMP_NEQ { print!("!= "); }

                // Print value with CIDR if bitwise
                if ctx.has_bitwise && (ctx.field == FieldId::IpSaddr || ctx.field == FieldId::IpDaddr) {
                    format_value_ex(&cmp_data, ctx.field, ctx.meta_key, ctx.ct_key, ctx.socket_key, ctx.rt_key, ctx.proto_ctx);
                    let prefix = mask_to_prefix(&ctx.bw_mask);
                    print!("/{}", prefix);
                } else {
                    format_value_ex(&cmp_data, ctx.field, ctx.meta_key, ctx.ct_key, ctx.socket_key, ctx.rt_key, ctx.proto_ctx);
                }
            }

            if ctx.field == FieldId::IpProto && cmp_data.len() == 1 { ctx.proto_ctx = cmp_data[0]; }
            if ctx.meta_key == Some(NFT_META_L4PROTO) && cmp_data.len() == 1 { ctx.proto_ctx = cmp_data[0]; }
            ctx.clear();
        }
        "immediate" => {
            let dreg = data.iter().find(|(t, _)| *t == NFTA_IMM_DREG).map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
            if dreg != NFT_REG_VERDICT {
                // Non-verdict immediate: stash the loaded bytes by
                // destination-register number for a downstream
                // dup / fwd / tproxy consumer to reinterpret. We
                // can't classify here (the same 4 bytes could be an
                // IPv4 or an ifindex) — leave that to the consumer
                // which knows what its SREG_* references mean.
                if let Some((_, raw)) = data.iter().find(|(t, _)| *t == NFTA_IMM_DATA) {
                    let inner = parse_attrs(raw);
                    if let Some((_, v)) = inner.iter().find(|(t, _)| *t == NFTA_DATA_VALUE) {
                        ctx.pending_imm.insert(dreg, v.to_vec());
                    }
                }
                return;
            }
            if dreg == NFT_REG_VERDICT {
                if let Some((_, imm_data)) = data.iter().find(|(t, _)| *t == NFTA_IMM_DATA) {
                    let inner = parse_attrs(imm_data);
                    if let Some((_, verdict_data)) = inner.iter().find(|(t, _)| *t == NFTA_DATA_VERDICT) {
                        let vattrs = parse_attrs(verdict_data);
                        let code = vattrs.iter().find(|(t, _)| *t == NFTA_VERDICT_CODE).map(|(_, v)| attr_i32_be(v)).unwrap_or(0);
                        let chain = vattrs.iter().find(|(t, _)| *t == NFTA_VERDICT_CHAIN).map(|(_, v)| attr_str(v).to_string());

                        if !*first { print!(" "); } *first = false;
                        // Use unified verdict renderer; for jump/goto it
                        // already appends the chain name, so don't print
                        // the chain twice.
                        let chain_str = chain.unwrap_or_default();
                        print!("{}", verdict_str(code, &chain_str));
                    }
                }
            } else {
                // Non-verdict immediate: stash the raw value bytes by
                // destination register. The next `nat` arm picks them
                // up to render `snat to <addr>` / `snat to <a>-<b>`.
                if let Some((_, imm_data)) = data.iter().find(|(t, _)| *t == NFTA_IMM_DATA) {
                    let inner = parse_attrs(imm_data);
                    if let Some((_, val)) = inner.iter().find(|(t, _)| *t == NFTA_DATA_VALUE) {
                        ctx.pending_imm.insert(dreg, val.clone());
                    }
                }
            }
        }
        "objref" => {
            let kind = data.iter().find(|(t, _)| *t == NFTA_OBJREF_IMM_TYPE)
                .map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
            let name = data.iter().find(|(t, _)| *t == NFTA_OBJREF_IMM_NAME)
                .map(|(_, v)| attr_str(v).to_string()).unwrap_or_default();
            if !*first { print!(" "); } *first = false;
            // ct helper renders with a different surface form: the rule
            // text is `ct helper set "name"`, not `helper name "name"`.
            // Stateful counter/quota/limit references keep the legacy
            // `<word> name "..."` syntax.
            if kind == NFT_OBJECT_CT_HELPER {
                print!("ct helper set \"{}\"", name);
            } else {
                let word = match kind {
                    1 => "counter", 2 => "quota", 4 => "limit",
                    _ => "objref",
                };
                print!("{} name \"{}\"", word, name);
            }
        }
        "flow_offload" => {
            // `flow add @ft` — the kernel's flow_offload expression
            // carries a single NFTA_FLOW_TABLE_NAME string naming the
            // target flowtable. nft only spells the verb `add` in
            // text, so we hard-code it here.
            let name = data.iter().find(|(t, _)| *t == NFTA_FLOW_TABLE_NAME)
                .map(|(_, v)| attr_str(v).to_string()).unwrap_or_default();
            if !*first { print!(" "); } *first = false;
            print!("flow add @{}", name);
            ctx.clear();
        }
        "dynset" => {
            // `add @s { ip saddr [timeout 10s] }` / `update @s { ... }`.
            // The preceding payload/meta/ct load already populated
            // ctx, so we recover the key textual form the same way
            // the cmp / lookup arms do.
            let set_name = data.iter().find(|(t, _)| *t == NFTA_DYNSET_SET_NAME)
                .map(|(_, v)| attr_str(v).to_string()).unwrap_or_default();
            let op = data.iter().find(|(t, _)| *t == NFTA_DYNSET_OP)
                .map(|(_, v)| attr_u32_be(v)).unwrap_or(NFT_DYNSET_OP_ADD);
            let timeout_ms = data.iter().find(|(t, _)| *t == NFTA_DYNSET_TIMEOUT)
                .map(|(_, v)| attr_u64_be(v)).unwrap_or(0);
            if !*first { print!(" "); } *first = false;
            let verb = match op {
                NFT_DYNSET_OP_UPDATE => "update",
                NFT_DYNSET_OP_DELETE => "delete",
                _ => "add",
            };
            let key_str = if ctx.field != FieldId::Unknown {
                field_name(ctx.field, ctx.proto_ctx).to_string()
            } else if let Some(k) = ctx.meta_key {
                meta_key_name(k).to_string()
            } else if let Some(k) = ctx.ct_key {
                ct_key_name(k).to_string()
            } else if let Some(k) = ctx.socket_key {
                socket_key_name(k).to_string()
            } else if let Some(k) = ctx.rt_key {
                rt_key_name(k).to_string()
            } else {
                String::new()
            };
            if timeout_ms > 0 {
                print!("{} @{} {{ {} timeout {} }}", verb, set_name, key_str, format_duration_ms(timeout_ms));
            } else {
                print!("{} @{} {{ {} }}", verb, set_name, key_str);
            }
            ctx.clear();
        }
        "lookup" => {
            let set_name = data.iter().find(|(t, _)| *t == NFTA_LOOKUP_SET)
                .map(|(_, v)| attr_str(v).to_string()).unwrap_or_default();
            let flags = data.iter().find(|(t, _)| *t == NFTA_LOOKUP_FLAGS)
                .map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
            let dreg = data.iter().find(|(t, _)| *t == NFTA_LOOKUP_DREG)
                .map(|(_, v)| attr_u32_be(v));
            // DREG=NFT_REG_VERDICT marks a verdict-map lookup. Upstream
            // renders these as `<key> vmap <rhs>`, never as a bare set
            // membership. A lookup without DREG is a plain set-membership
            // check.
            let is_vmap = matches!(dreg, Some(r) if r == NFT_REG_VERDICT);
            if !*first { print!(" "); } *first = false;
            // Preceding context (ip saddr / meta mark / etc.) is already
            // set by earlier expressions; print it too so the output
            // reads `ip saddr @blocked`.
            if ctx.field != FieldId::Unknown { print!("{} ", field_name(ctx.field, ctx.proto_ctx)); }
            else if let Some(k) = ctx.meta_key { print!("{} ", meta_key_name(k)); }
            else if let Some(k) = ctx.ct_key { print!("{} ", ct_key_name(k)); }
            else if let Some(k) = ctx.socket_key { print!("{} ", socket_key_name(k)); }
            else if let Some(k) = ctx.rt_key { print!("{} ", rt_key_name(k)); }
            if flags & NFT_LOOKUP_F_INV != 0 { print!("!= "); }
            if is_vmap { print!("vmap "); }
            // Anonymous sets render inline — upstream `nft list` prints
            // the element literal the rule contained, not the synthetic
            // `__setN` / `__mapN` name. Named sets stay as `@name`. A
            // single-value anon set drops the braces — that's how
            // upstream prints it and the test framework's diff is
            // sensitive to the bare form.
            let is_anon = set_name.starts_with("__set") || set_name.starts_with("__map");
            match registry.sets.get(&set_name) {
                Some(info) if is_anon => {
                    if info.is_map {
                        print!("{{ {} }}", format_anon_vmap_elems(info));
                    } else if info.elements.len() == 1 && info.elements[0].1.is_none() {
                        let (k, _) = &info.elements[0];
                        print!("{}", format_set_key(info.key_type, info.key_len, k));
                    } else {
                        print!("{{ {} }}", format_anon_set_elems(info));
                    }
                }
                _ => { print!("@{}", set_name); }
            }
            ctx.clear();
        }
        "counter" => {
            if stateless { return; }
            let pkts = data.iter().find(|(t, _)| *t == NFTA_COUNTER_PACKETS).map(|(_, v)| attr_u64_be(v)).unwrap_or(0);
            let bytes = data.iter().find(|(t, _)| *t == NFTA_COUNTER_BYTES).map(|(_, v)| attr_u64_be(v)).unwrap_or(0);
            if !*first { print!(" "); } *first = false;
            print!("counter packets {} bytes {}", pkts, bytes);
        }
        "log" => {
            if !*first { print!(" "); } *first = false;
            print!("log");
            if let Some((_, v)) = data.iter().find(|(t, _)| *t == NFTA_LOG_PREFIX) {
                print!(" prefix \"{}\"", attr_str(v));
            }
        }
        "limit" => {
            let rate = data.iter().find(|(t, _)| *t == NFTA_LIMIT_RATE).map(|(_, v)| attr_u64_be(v)).unwrap_or(0);
            let unit = data.iter().find(|(t, _)| *t == NFTA_LIMIT_UNIT).map(|(_, v)| attr_u64_be(v)).unwrap_or(1);
            let flags = data.iter().find(|(t, _)| *t == NFTA_LIMIT_FLAGS).map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
            let burst = data.iter().find(|(t, _)| *t == NFTA_LIMIT_BURST).map(|(_, v)| attr_u32_be(v)).unwrap_or(5);
            if !*first { print!(" "); } *first = false;
            let unit_str = match unit { 1 => "second", 60 => "minute", 3600 => "hour", 86400 => "day", 604800 => "week", _ => "second" };
            let over_str = if flags & NFT_LIMIT_F_INV != 0 { " over" } else { "" };
            print!("limit rate{} {}/{} burst {} packets", over_str, rate, unit_str, burst);
        }
        "nat" => {
            let nat_type = data.iter().find(|(t, _)| *t == NFTA_NAT_TYPE).map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
            let flags = data.iter().find(|(t, _)| *t == NFTA_NAT_FLAGS).map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
            let reg_min = data.iter().find(|(t, _)| *t == NFTA_NAT_REG_ADDR_MIN).map(|(_, v)| attr_u32_be(v));
            let reg_max = data.iter().find(|(t, _)| *t == NFTA_NAT_REG_ADDR_MAX).map(|(_, v)| attr_u32_be(v));
            let proto_min = data.iter().find(|(t, _)| *t == NFTA_NAT_REG_PROTO_MIN).map(|(_, v)| attr_u32_be(v));
            if !*first { print!(" "); } *first = false;
            print!("{}", if nat_type == NFT_NAT_SNAT { "snat" } else { "dnat" });
            // Recover the loaded address(es) from preceding immediates
            // and render in the upstream `to <addr>[-<addr>][:<port>]`
            // shape. Single-byte addrs would mean IPv6 (16 bytes) —
            // not yet covered; the IPv4 4-byte form is what tests use.
            let render_v4 = |b: &[u8]| -> Option<String> {
                if b.len() == 4 { Some(format!("{}.{}.{}.{}", b[0], b[1], b[2], b[3])) } else { None }
            };
            if let Some(rmin) = reg_min {
                let lo = ctx.pending_imm.get(&rmin).cloned();
                let hi = match reg_max {
                    Some(rm) if rm != rmin => ctx.pending_imm.get(&rm).cloned(),
                    _ => None,
                };
                let lo_s = lo.as_deref().and_then(render_v4);
                let hi_s = hi.as_deref().and_then(render_v4);
                match (lo_s, hi_s) {
                    (Some(a), Some(b)) => print!(" to {}-{}", a, b),
                    (Some(a), None) => print!(" to {}", a),
                    _ => {}
                }
            }
            if let Some(preg) = proto_min {
                if let Some(bytes) = ctx.pending_imm.get(&preg) {
                    if bytes.len() == 2 {
                        let port = u16::from_be_bytes([bytes[0], bytes[1]]);
                        print!(":{}", port);
                    }
                }
            }
            // Render NF_NAT_RANGE_* modifiers exactly as nft does.
            // Order matches upstream so list output is round-trip
            // stable: random, fully-random, persistent.
            if flags & NF_NAT_RANGE_PROTO_RANDOM_FULLY != 0 {
                print!(" fully-random");
            } else if flags & NF_NAT_RANGE_PROTO_RANDOM != 0 {
                print!(" random");
            }
            if flags & NF_NAT_RANGE_PERSISTENT != 0 {
                print!(" persistent");
            }
            ctx.pending_imm.clear();
        }
        "masq" => {
            if !*first { print!(" "); } *first = false;
            print!("masquerade");
            let flags = data.iter().find(|(t, _)| *t == NFTA_MASQ_FLAGS).map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
            if flags & NF_NAT_RANGE_PROTO_RANDOM_FULLY != 0 {
                print!(" fully-random");
            } else if flags & NF_NAT_RANGE_PROTO_RANDOM != 0 {
                print!(" random");
            }
            if flags & NF_NAT_RANGE_PERSISTENT != 0 {
                print!(" persistent");
            }
            ctx.pending_imm.clear();
        }
        "notrack" => { if !*first { print!(" "); } *first = false; print!("notrack"); }
        "reject" => { if !*first { print!(" "); } *first = false; print!("reject"); }
        "dup" => {
            // `dup to ADDR [device "DEV"]` — read SREG_ADDR / SREG_DEV
            // out of the expression, then look the named register up
            // in the pending-immediate stash. ADDR is 4-byte raw IPv4
            // bytes; DEV is a 4-byte native-endian ifindex we resolve
            // back to a name via if_indextoname.
            if !*first { print!(" "); } *first = false;
            print!("dup");
            let addr_reg = data.iter().find(|(t, _)| *t == NFTA_DUP_SREG_ADDR)
                .map(|(_, v)| attr_u32_be(v));
            let dev_reg = data.iter().find(|(t, _)| *t == NFTA_DUP_SREG_DEV)
                .map(|(_, v)| attr_u32_be(v));
            if let Some(r) = addr_reg {
                if let Some(a) = ctx.pending_imm.get(&r) {
                    if a.len() == 4 {
                        print!(" to {}.{}.{}.{}", a[0], a[1], a[2], a[3]);
                    }
                }
            }
            if let Some(r) = dev_reg {
                if let Some(d) = ctx.pending_imm.get(&r) {
                    if d.len() == 4 {
                        let idx = u32::from_ne_bytes([d[0], d[1], d[2], d[3]]);
                        if let Some(name) = if_indextoname(idx) {
                            print!(" device \"{}\"", name);
                        }
                    }
                }
            }
            ctx.pending_imm.clear();
        }
        "fwd" => {
            // `fwd to "DEV"` — netdev family. SREG_DEV references
            // the register a preceding immediate populated with the
            // ifindex.
            if !*first { print!(" "); } *first = false;
            print!("fwd");
            let dev_reg = data.iter().find(|(t, _)| *t == NFTA_FWD_SREG_DEV)
                .map(|(_, v)| attr_u32_be(v));
            if let Some(r) = dev_reg {
                if let Some(d) = ctx.pending_imm.get(&r) {
                    if d.len() == 4 {
                        let idx = u32::from_ne_bytes([d[0], d[1], d[2], d[3]]);
                        if let Some(name) = if_indextoname(idx) {
                            print!(" to \"{}\"", name);
                        }
                    }
                }
            }
            ctx.pending_imm.clear();
        }
        "tproxy" => {
            // `tproxy to [ADDR]:PORT` — address optional. REG_ADDR
            // and REG_PORT name the registers preceding immediates
            // populated; we look both up and stitch them into the
            // upstream `[addr]:port` form.
            if !*first { print!(" "); } *first = false;
            print!("tproxy to ");
            let addr_reg = data.iter().find(|(t, _)| *t == NFTA_TPROXY_REG_ADDR)
                .map(|(_, v)| attr_u32_be(v));
            let port_reg = data.iter().find(|(t, _)| *t == NFTA_TPROXY_REG_PORT)
                .map(|(_, v)| attr_u32_be(v));
            if let Some(r) = addr_reg {
                if let Some(a) = ctx.pending_imm.get(&r) {
                    if a.len() == 4 {
                        print!("{}.{}.{}.{}", a[0], a[1], a[2], a[3]);
                    }
                }
            }
            if let Some(r) = port_reg {
                if let Some(p) = ctx.pending_imm.get(&r) {
                    if p.len() == 2 {
                        print!(":{}", u16::from_be_bytes([p[0], p[1]]));
                    }
                }
            }
            ctx.pending_imm.clear();
        }
        "synproxy" => {
            // `synproxy mss N wscale N [timestamp] [sack-perm]` —
            // recover from the wire attributes. The `timestamp` /
            // `sack-perm` keywords appear iff their bits are set.
            let mss = data.iter().find(|(t, _)| *t == NFTA_SYNPROXY_MSS)
                .and_then(|(_, v)| v.get(0..2).map(|b| u16::from_be_bytes([b[0], b[1]])))
                .unwrap_or(0);
            let wscale = data.iter().find(|(t, _)| *t == NFTA_SYNPROXY_WSCALE)
                .and_then(|(_, v)| v.get(0).copied()).unwrap_or(0);
            let flags = data.iter().find(|(t, _)| *t == NFTA_SYNPROXY_FLAGS)
                .map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
            if !*first { print!(" "); } *first = false;
            print!("synproxy");
            if flags & NF_SYNPROXY_OPT_MSS != 0 { print!(" mss {}", mss); }
            if flags & NF_SYNPROXY_OPT_WSCALE != 0 { print!(" wscale {}", wscale); }
            if flags & NF_SYNPROXY_OPT_TIMESTAMP != 0 { print!(" timestamp"); }
            if flags & NF_SYNPROXY_OPT_SACK_PERM != 0 { print!(" sack-perm"); }
        }
        _ => {} // skip unknown
    }
}

fn format_value(data: &[u8], field: FieldId, meta_key: Option<u32>, ct_key: Option<u32>, proto_ctx: u8) {
    format_value_ex(data, field, meta_key, ct_key, None, None, proto_ctx)
}

fn format_value_ex(data: &[u8], field: FieldId, meta_key: Option<u32>, ct_key: Option<u32>, socket_key: Option<u32>, rt_key: Option<u32>, proto_ctx: u8) {
    // IPv4 address (full 4-byte form; short-payload CIDR is handled
    // earlier in the cmp arm before calling format_value)
    if matches!(field, FieldId::IpSaddr | FieldId::IpDaddr) && data.len() == 4 {
        print!("{}", Ipv4Addr::new(data[0], data[1], data[2], data[3]));
        return;
    }
    // Port
    if matches!(field, FieldId::TcpSport | FieldId::TcpDport | FieldId::UdpSport | FieldId::UdpDport) && data.len() == 2 {
        print!("{}", u16::from_be_bytes([data[0], data[1]]));
        return;
    }
    // ICMP type — symbolic names.  proto_ctx distinguishes ICMPv4 (1)
    // from ICMPv6 (58); when unknown fall back to ICMPv4 names because
    // the icmpv6 type payload is typically preceded by an explicit
    // `meta l4proto 58` that sets proto_ctx.
    if field == FieldId::IcmpType && data.len() == 1 {
        let name = if proto_ctx == 58 {
            icmpv6_type_name(data[0])
        } else {
            icmp_type_name(data[0])
        };
        if let Some(n) = name {
            print!("{}", n);
        } else {
            print!("{}", data[0]);
        }
        return;
    }
    // EtherType — symbolic names for the common values
    if field == FieldId::EtherType && data.len() == 2 {
        let et = u16::from_be_bytes([data[0], data[1]]);
        print!("{}", ether_type_name_str(et));
        return;
    }
    // Protocol
    if field == FieldId::IpProto || meta_key == Some(NFT_META_L4PROTO) {
        if data.len() == 1 {
            print!("{}", match data[0] { 6 => "tcp", 17 => "udp", 1 => "icmp", 58 => "icmpv6", _ => { print!("{}", data[0]); return; } });
            return;
        }
    }
    // CT state
    if ct_key == Some(NFT_CT_STATE) && data.len() >= 4 {
        let state = u32::from_ne_bytes([data[0], data[1], data[2], data[3]]);
        let mut parts = Vec::new();
        if state & 1 != 0 { parts.push("invalid"); }
        if state & 2 != 0 { parts.push("established"); }
        if state & 4 != 0 { parts.push("related"); }
        if state & 8 != 0 { parts.push("new"); }
        if state & 64 != 0 { parts.push("untracked"); }
        print!("{}", parts.join(","));
        return;
    }
    // Interface name
    if meta_key == Some(NFT_META_IIFNAME) || meta_key == Some(NFT_META_OIFNAME) {
        print!("\"{}\"", attr_str(data));
        return;
    }
    // socket mark renders as a host-order hex `0x{08x}` like meta mark.
    // socket transparent / wildcard / cgroupv2, meta cpu, meta cgroup,
    // and rt classid are stored host-order in the register slot but
    // upstream prints them as plain decimal — so split host-order-hex
    // from host-order-decimal here.
    let host_order_hex = matches!(meta_key,
        Some(NFT_META_MARK) | Some(NFT_META_IIF) | Some(NFT_META_OIF) |
        Some(NFT_META_SKUID) | Some(NFT_META_SKGID) | Some(NFT_META_LEN) |
        Some(NFT_META_PRIORITY))
        || matches!(ct_key,
        Some(NFT_CT_MARK) | Some(NFT_CT_SECMARK) | Some(NFT_CT_EXPIRATION) |
        Some(NFT_CT_PKTS) | Some(NFT_CT_BYTES) | Some(NFT_CT_AVGPKT))
        || matches!(socket_key, Some(NFT_SOCKET_MARK));
    if host_order_hex && data.len() == 4 {
        let v = u32::from_ne_bytes([data[0], data[1], data[2], data[3]]);
        print!("0x{:08x}", v);
        return;
    }
    // host-order decimal: cpu / cgroup / rt classid / socket transparent
    // & wildcard. The kernel store is CPU-native; the user-facing
    // printout is bare decimal (no `0x` prefix).
    let host_order_dec = matches!(meta_key, Some(NFT_META_CPU) | Some(NFT_META_CGROUP))
        || matches!(rt_key, Some(NFT_RT_CLASSID) | Some(NFT_RT_TCPMSS))
        || matches!(socket_key, Some(NFT_SOCKET_TRANSPARENT) | Some(NFT_SOCKET_WILDCARD));
    if host_order_dec && data.len() == 4 {
        let v = u32::from_ne_bytes([data[0], data[1], data[2], data[3]]);
        print!("{}", v);
        return;
    }
    if host_order_dec && data.len() == 2 {
        let v = u16::from_ne_bytes([data[0], data[1]]);
        print!("{}", v);
        return;
    }
    // Generic
    if data.len() == 1 { print!("{}", data[0]); }
    else if data.len() == 2 { print!("{}", u16::from_be_bytes([data[0], data[1]])); }
    else if data.len() == 4 { print!("{}", u32::from_be_bytes([data[0], data[1], data[2], data[3]])); }
    else { for b in data { print!("{:02x}", b); } }
}

/// ICMPv4 type number → symbolic name (mirrors parser's icmp_type_num table).
fn icmp_type_name(v: u8) -> Option<&'static str> {
    match v {
        0  => Some("echo-reply"),
        3  => Some("destination-unreachable"),
        4  => Some("source-quench"),
        5  => Some("redirect"),
        8  => Some("echo-request"),
        9  => Some("router-advertisement"),
        10 => Some("router-solicitation"),
        11 => Some("time-exceeded"),
        12 => Some("parameter-problem"),
        13 => Some("timestamp-request"),
        14 => Some("timestamp-reply"),
        15 => Some("info-request"),
        16 => Some("info-reply"),
        17 => Some("address-mask-request"),
        18 => Some("address-mask-reply"),
        _  => None,
    }
}

/// ICMPv6 type number → symbolic name (mirrors parser's icmpv6_type_num table).
fn icmpv6_type_name(v: u8) -> Option<&'static str> {
    match v {
        1   => Some("destination-unreachable"),
        2   => Some("packet-too-big"),
        3   => Some("time-exceeded"),
        4   => Some("parameter-problem"),
        128 => Some("echo-request"),
        129 => Some("echo-reply"),
        130 => Some("mld-listener-query"),
        131 => Some("mld-listener-report"),
        132 => Some("mld-listener-done"),
        133 => Some("nd-router-solicit"),
        134 => Some("nd-router-advert"),
        135 => Some("nd-neighbor-solicit"),
        136 => Some("nd-neighbor-advert"),
        137 => Some("nd-redirect"),
        138 => Some("router-renumbering"),
        141 => Some("ind-neighbor-solicit"),
        142 => Some("ind-neighbor-advert"),
        143 => Some("mld2-listener-report"),
        _   => None,
    }
}

/// EtherType (big-endian u16) → symbolic name or hex string for unknowns.
fn ether_type_name_str(et: u16) -> String {
    match et {
        0x0800 => "ip".to_string(),
        0x0806 => "arp".to_string(),
        0x86dd => "ip6".to_string(),
        0x8100 => "vlan".to_string(),
        0x880b => "ppp".to_string(),
        0x88a8 => "8021q".to_string(),
        0x88c7 => "wlan".to_string(),
        n      => format!("0x{:04x}", n),
    }
}

fn mask_to_prefix(mask: &[u8]) -> u32 {
    let mut bits = 0u32;
    for &b in mask {
        for i in (0..8).rev() {
            if b & (1 << i) != 0 { bits += 1; } else { return bits; }
        }
    }
    bits
}

/// Convert a TCP flags byte into a comma-separated string of symbolic
/// flag names in the order nft uses: fin,syn,rst,psh,ack,urg,ecn,cwr.
/// Unknown bits (none expected in practice) are appended as `0x{:02x}`.
/// Returns `"0"` when the byte is zero (used in mask rendering).
fn tcp_flags_names(byte: u8) -> String {
    const FLAGS: &[(&str, u8)] = &[
        ("fin", 0x01), ("syn", 0x02), ("rst", 0x04), ("psh", 0x08),
        ("ack", 0x10), ("urg", 0x20), ("ecn", 0x40), ("cwr", 0x80),
    ];
    let mut parts: Vec<&str> = Vec::new();
    let mut remaining = byte;
    for &(name, bit) in FLAGS {
        if remaining & bit != 0 { parts.push(name); remaining &= !bit; }
    }
    if parts.is_empty() { return "0".to_string(); }
    parts.join(",")
}

/// Same as tcp_flags_names but uses ` | ` as separator, for the mask
/// side of `tcp flags & (syn | rst | ack) == syn`.
fn tcp_mask_names(byte: u8) -> String {
    const FLAGS: &[(&str, u8)] = &[
        ("fin", 0x01), ("syn", 0x02), ("rst", 0x04), ("psh", 0x08),
        ("ack", 0x10), ("urg", 0x20), ("ecn", 0x40), ("cwr", 0x80),
    ];
    let mut parts: Vec<&str> = Vec::new();
    let mut remaining = byte;
    for &(name, bit) in FLAGS {
        if remaining & bit != 0 { parts.push(name); remaining &= !bit; }
    }
    if parts.is_empty() { return "0".to_string(); }
    parts.join(" | ")
}

// ── JSON output ─────────────────────────────────────────────────
//
// Emit a cut-down but spec-shaped nftables JSON envelope. Tables,
// chains, and sets render as real JSON records; rules carry a "raw"
// string field with the text-rendered form (a truly compliant
// `expr` array would require a second full serializer for every
// expression type, which is a separate project). Tools that only
// want to enumerate tables/chains work out of the box; tools that
// introspect rule internals still need text parsing, but at least
// `-j` produces valid JSON now instead of a parse error.

// Render one set element's key bytes as the JSON scalar libnftables
// uses: IPv4 as dotted-quad, TCP/UDP service as integer, inet_proto
// as a protocol name, everything else as an integer literal.
fn format_set_elem_value(key_type: u32, data: &[u8]) -> String {
    match key_type {
        7 /* ipv4_addr */ if data.len() == 4 =>
            format!("\"{}.{}.{}.{}\"", data[0], data[1], data[2], data[3]),
        13 /* inet_service */ if data.len() == 2 =>
            format!("{}", u16::from_be_bytes([data[0], data[1]])),
        12 /* inet_proto */ if data.len() == 1 => match data[0] {
            6 => "\"tcp\"".into(), 17 => "\"udp\"".into(),
            1 => "\"icmp\"".into(), 58 => "\"icmpv6\"".into(),
            n => format!("{}", n),
        },
        _ => {
            // Fallback: integer from whatever byte width we got.
            let mut v: u64 = 0;
            for b in data.iter().take(8) { v = (v << 8) | *b as u64; }
            format!("{}", v)
        }
    }
}

fn json_escape(s: &str) -> String {
    let mut out = String::with_capacity(s.len() + 2);
    for c in s.chars() {
        match c {
            '"'  => out.push_str("\\\""),
            '\\' => out.push_str("\\\\"),
            '\n' => out.push_str("\\n"),
            '\r' => out.push_str("\\r"),
            '\t' => out.push_str("\\t"),
            c if (c as u32) < 0x20 => out.push_str(&format!("\\u{:04x}", c as u32)),
            c => out.push(c),
        }
    }
    out
}

/// Walks the expression stream inside a rule and emits JSON
/// fragments. Upstream libnftables fuses the `payload`/`meta`/`ct`
/// load + optional `bitwise` mask + `cmp` triple into a single
/// `{"match": {"left": ..., "right": ..., "op": "=="}}` object;
/// standalone expressions (verdict, counter, log, masquerade) emit
/// one fragment each. This is the small state machine that keeps
/// track of the load-side of a pending match.
struct ExprJsonCtx {
    // Left side of the pending match, if a payload/meta/ct load has
    // been seen. Stored as a JSON fragment (e.g.
    // `"left": {"payload": {"protocol": "ip", "field": "saddr"}}`).
    pending_left: Option<String>,
    field: FieldId,
    proto_ctx: u8,
    meta_key: Option<u32>,
    ct_key: Option<u32>,
    socket_key: Option<u32>,
    rt_key: Option<u32>,
    bw_mask: Option<Vec<u8>>,
    anon_sets: AnonSetRegistry,
    /// JSON value-fragment produced by a numgen / hash expression
    /// while waiting for the trailing `meta KEY set` consumer to
    /// fold both into a single `{"mangle": {...}}` object — the
    /// shape libnftables emits.
    pending_set_value: Option<String>,
    /// Stashed JSON for the source-payload of a jhash, e.g.
    /// `{"payload": {"protocol": "ip", "field": "saddr"}}`. Captured
    /// when the `payload` arm runs and consumed when the `hash` arm
    /// composes its `{"jhash": {...}}` fragment.
    hash_key_left: Option<String>,
    /// Raw bytes of the most recent non-verdict immediates, keyed by
    /// destination register. Two consumers share this map:
    ///   - dup / fwd / tproxy each reference one or two of these
    ///     via SREG_* attributes when they encode their JSON shape;
    ///   - the nat / masquerade arms read NFT_REG32_01 / _02 to
    ///     recover the address (and address-range upper bound) the
    ///     rule loaded just before us, so the JSON renderer produces
    ///     libnftables' shape:
    ///       {"snat": {"addr": "1.2.3.4", "flags": "random"}}
    ///       {"snat": {"addr": {"range": ["1.2.3.4", "1.2.3.10"]}, ...}}
    pending_imm: std::collections::HashMap<u32, Vec<u8>>,
}

impl ExprJsonCtx {
    fn new() -> Self {
        ExprJsonCtx {
            pending_left: None, field: FieldId::Unknown, proto_ctx: 0,
            meta_key: None, ct_key: None, socket_key: None, rt_key: None, bw_mask: None,
            anon_sets: AnonSetRegistry::default(),
            pending_set_value: None, hash_key_left: None,
            pending_imm: std::collections::HashMap::new(),
        }
    }

    fn clear(&mut self) {
        self.pending_left = None; self.field = FieldId::Unknown;
        self.meta_key = None; self.ct_key = None;
        self.socket_key = None; self.rt_key = None; self.bw_mask = None;
    }

    /// Consume one netlink expression. Returns zero or more JSON
    /// object fragments to push to the rule's expr array.
    fn consume(&mut self, name: &str, data: &[(u16, Vec<u8>)]) -> Vec<String> {
        match name {
            "payload" => {
                let base = data.iter().find(|(t, _)| *t == NFTA_PAYLOAD_BASE).map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
                let off = data.iter().find(|(t, _)| *t == NFTA_PAYLOAD_OFFSET).map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
                let len = data.iter().find(|(t, _)| *t == NFTA_PAYLOAD_LEN).map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
                self.field = identify_payload(base, off, len);
                self.meta_key = None; self.ct_key = None; self.bw_mask = None;
                let (proto, field) = match self.field {
                    FieldId::IpSaddr => ("ip", "saddr"),
                    FieldId::IpDaddr => ("ip", "daddr"),
                    FieldId::IpProto => ("ip", "protocol"),
                    FieldId::IpDscp => ("ip", "dscp"),
                    FieldId::Ip6Saddr => ("ip6", "saddr"),
                    FieldId::Ip6Daddr => ("ip6", "daddr"),
                    FieldId::TcpSport if self.proto_ctx == 17 => ("udp", "sport"),
                    FieldId::TcpSport => ("tcp", "sport"),
                    FieldId::TcpDport if self.proto_ctx == 17 => ("udp", "dport"),
                    FieldId::TcpDport => ("tcp", "dport"),
                    FieldId::TcpFlags => ("tcp", "flags"),
                    FieldId::UdpSport => ("udp", "sport"),
                    FieldId::UdpDport => ("udp", "dport"),
                    FieldId::IcmpType => ("icmp", "type"),
                    FieldId::IcmpCode => ("icmp", "code"),
                    FieldId::EtherType => ("ether", "type"),
                    FieldId::Unknown => { self.pending_left = None; return Vec::new(); }
                };
                let frag = format!(
                    "{{\"payload\": {{\"protocol\": \"{}\", \"field\": \"{}\"}}}}",
                    proto, field
                );
                // Also capture the load fragment as the candidate
                // jhash key — if the next expression is `hash`, it
                // pops this and folds it into its own JSON value.
                self.hash_key_left = Some(frag.clone());
                self.pending_left = Some(frag);
                Vec::new()
            }
            "meta" => {
                self.meta_key = data.iter().find(|(t, _)| *t == NFTA_META_KEY).map(|(_, v)| attr_u32_be(v));
                self.field = FieldId::Unknown; self.ct_key = None;
                self.socket_key = None; self.rt_key = None; self.bw_mask = None;
                if let Some(k) = self.meta_key {
                    let key = match k {
                        NFT_META_IIFNAME => "iifname", NFT_META_OIFNAME => "oifname",
                        NFT_META_IIF => "iif", NFT_META_OIF => "oif",
                        NFT_META_MARK => "mark", NFT_META_L4PROTO => "l4proto",
                        NFT_META_NFPROTO => "nfproto", NFT_META_PKTTYPE => "pkttype",
                        NFT_META_SKUID => "skuid", NFT_META_SKGID => "skgid",
                        NFT_META_LEN => "length", NFT_META_PROTOCOL => "protocol",
                        NFT_META_CPU => "cpu", NFT_META_CGROUP => "cgroup",
                        _ => { self.pending_left = None; return Vec::new(); }
                    };
                    let key_frag = format!("{{\"meta\": {{\"key\": \"{}\"}}}}", key);
                    // `meta KEY set <expr>` — kernel signals the
                    // mangle direction with NFTA_META_SREG. Pair it
                    // with the value fragment the prior numgen / hash
                    // stashed and emit one `{"mangle": ...}` object.
                    let has_sreg = data.iter().any(|(t, _)| *t == NFTA_META_SREG);
                    if has_sreg {
                        if let Some(v) = self.pending_set_value.take() {
                            self.clear();
                            return vec![format!(
                                "{{\"mangle\": {{\"key\": {}, \"value\": {}}}}}",
                                key_frag, v
                            )];
                        }
                    }
                    self.pending_left = Some(key_frag);
                }
                Vec::new()
            }
            "numgen" => {
                let ng_type = data.iter().find(|(t, _)| *t == NFTA_NG_TYPE).map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
                let modulus = data.iter().find(|(t, _)| *t == NFTA_NG_MODULUS).map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
                let offset  = data.iter().find(|(t, _)| *t == NFTA_NG_OFFSET).map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
                let mode = if ng_type == NFT_NG_RANDOM { "random" } else { "inc" };
                // Upstream libnftables always emits the offset key,
                // even at 0 — match that exactly so the parity diff
                // is empty.
                self.pending_set_value = Some(format!(
                    "{{\"numgen\": {{\"mode\": \"{}\", \"mod\": {}, \"offset\": {}}}}}",
                    mode, modulus, offset
                ));
                Vec::new()
            }
            "hash" => {
                let hash_type = data.iter().find(|(t, _)| *t == NFTA_HASH_TYPE).map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
                let modulus = data.iter().find(|(t, _)| *t == NFTA_HASH_MODULUS).map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
                let offset  = data.iter().find(|(t, _)| *t == NFTA_HASH_OFFSET).map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
                let seed    = data.iter().find(|(t, _)| *t == NFTA_HASH_SEED).map(|(_, v)| attr_u32_be(v));
                let frag = if hash_type == NFT_HASH_SYM {
                    let mut s = format!("{{\"symhash\": {{\"mod\": {}", modulus);
                    if offset != 0 { s.push_str(&format!(", \"offset\": {}", offset)); }
                    s.push_str("}}");
                    s
                } else {
                    let key_frag = self.hash_key_left.take()
                        .unwrap_or_else(|| "null".to_string());
                    let mut s = format!("{{\"jhash\": {{\"mod\": {}, \"expr\": {}", modulus, key_frag);
                    if let Some(sd) = seed {
                        s.push_str(&format!(", \"seed\": {}", sd));
                    }
                    if offset != 0 {
                        s.push_str(&format!(", \"offset\": {}", offset));
                    }
                    s.push_str("}}");
                    s
                };
                self.pending_set_value = Some(frag);
                self.pending_left = None;
                Vec::new()
            }
            "socket" => {
                self.socket_key = data.iter().find(|(t, _)| *t == NFTA_SOCKET_KEY).map(|(_, v)| attr_u32_be(v));
                self.field = FieldId::Unknown; self.meta_key = None;
                self.ct_key = None; self.rt_key = None; self.bw_mask = None;
                if let Some(k) = self.socket_key {
                    let key = match k {
                        NFT_SOCKET_TRANSPARENT => "transparent",
                        NFT_SOCKET_MARK        => "mark",
                        NFT_SOCKET_WILDCARD    => "wildcard",
                        NFT_SOCKET_CGROUPV2    => "cgroupv2",
                        _ => { self.pending_left = None; return Vec::new(); }
                    };
                    self.pending_left = Some(format!("{{\"socket\": {{\"key\": \"{}\"}}}}", key));
                }
                Vec::new()
            }
            "rt" => {
                self.rt_key = data.iter().find(|(t, _)| *t == NFTA_RT_KEY).map(|(_, v)| attr_u32_be(v));
                self.field = FieldId::Unknown; self.meta_key = None;
                self.ct_key = None; self.socket_key = None; self.bw_mask = None;
                if let Some(k) = self.rt_key {
                    let key = match k {
                        NFT_RT_CLASSID  => "classid",
                        NFT_RT_NEXTHOP4 => "nexthop",
                        NFT_RT_NEXTHOP6 => "nexthop",
                        NFT_RT_TCPMSS   => "mtu",
                        _ => { self.pending_left = None; return Vec::new(); }
                    };
                    self.pending_left = Some(format!("{{\"rt\": {{\"key\": \"{}\"}}}}", key));
                }
                Vec::new()
            }
            "ct" => {
                self.ct_key = data.iter().find(|(t, _)| *t == NFTA_CT_KEY).map(|(_, v)| attr_u32_be(v));
                self.field = FieldId::Unknown; self.meta_key = None; self.bw_mask = None;
                if let Some(k) = self.ct_key {
                    let key = match k {
                        NFT_CT_STATE => "state", NFT_CT_MARK => "mark",
                        NFT_CT_STATUS => "status", NFT_CT_DIRECTION => "direction",
                        NFT_CT_PROTOCOL => "protocol", NFT_CT_L3PROTOCOL => "l3proto",
                        NFT_CT_BYTES => "bytes", NFT_CT_PKTS => "packets",
                        NFT_CT_EXPIRATION => "expiration",
                        _ => { self.pending_left = None; return Vec::new(); }
                    };
                    self.pending_left = Some(format!("{{\"ct\": {{\"key\": \"{}\"}}}}", key));
                }
                Vec::new()
            }
            "bitwise" => {
                if let Some((_, v)) = data.iter().find(|(t, _)| *t == NFTA_BITWISE_MASK) {
                    let inner = parse_attrs(v);
                    if let Some((_, m)) = inner.iter().find(|(t, _)| *t == NFTA_DATA_VALUE) {
                        self.bw_mask = Some(m.clone());
                    }
                }
                Vec::new()
            }
            "dynset" => {
                let set_name = data.iter().find(|(t, _)| *t == NFTA_DYNSET_SET_NAME)
                    .map(|(_, v)| attr_str(v).to_string()).unwrap_or_default();
                let op = data.iter().find(|(t, _)| *t == NFTA_DYNSET_OP)
                    .map(|(_, v)| attr_u32_be(v)).unwrap_or(NFT_DYNSET_OP_ADD);
                let timeout_ms = data.iter().find(|(t, _)| *t == NFTA_DYNSET_TIMEOUT)
                    .map(|(_, v)| attr_u64_be(v)).unwrap_or(0);
                let left = self.pending_left.take();
                self.clear();
                let op_str = match op {
                    NFT_DYNSET_OP_UPDATE => "update",
                    NFT_DYNSET_OP_DELETE => "delete",
                    _ => "add",
                };
                let key_json = match left {
                    Some(l) => l,
                    None => "null".to_string(),
                };
                // libnftables wraps the key in {"elem": {"val": ..., "timeout": N}}
                // when a per-element timeout was attached; otherwise the key
                // appears bare under "elem".
                let elem_json = if timeout_ms > 0 {
                    let secs = timeout_ms / 1000;
                    format!("{{\"elem\": {{\"val\": {}, \"timeout\": {}}}}}", key_json, secs)
                } else {
                    key_json
                };
                vec![format!(
                    "{{\"set\": {{\"op\": \"{}\", \"elem\": {}, \"set\": \"@{}\"}}}}",
                    op_str, elem_json, json_escape(&set_name)
                )]
            }
            "lookup" => {
                let set_name = data.iter().find(|(t, _)| *t == NFTA_LOOKUP_SET)
                    .map(|(_, v)| attr_str(v).to_string()).unwrap_or_default();
                let flags = data.iter().find(|(t, _)| *t == NFTA_LOOKUP_FLAGS)
                    .map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
                let dreg = data.iter().find(|(t, _)| *t == NFTA_LOOKUP_DREG)
                    .map(|(_, v)| attr_u32_be(v));
                let is_vmap = matches!(dreg, Some(r) if r == NFT_REG_VERDICT);
                let left = self.pending_left.take();
                self.clear();
                let op = if flags & NFT_LOOKUP_F_INV != 0 { "!=" } else { "==" };
                let is_anon = set_name.starts_with("__set") || set_name.starts_with("__map");
                // Anonymous sets inline as {"set": [...]} per
                // libnftables; named sets stay as `@name`. Vmaps
                // wrap the `vmap` verb around whichever rhs form.
                let rhs_inline = if is_anon {
                    self.anon_sets.sets.get(&set_name).map(|info| {
                        if info.is_map {
                            let mut parts: Vec<String> = Vec::new();
                            for (i, (start, _)) in info.elements.iter().enumerate() {
                                let k = format_set_elem_value(info.key_type, start);
                                let (code, chain) = info.verdicts.get(i).cloned()
                                    .unwrap_or((0, String::new()));
                                let v = json_verdict(code, &chain);
                                parts.push(format!("[{}, {}]", k, v));
                            }
                            format!("{{\"set\": [{}]}}", parts.join(", "))
                        } else if info.elements.len() == 1 && info.elements[0].1.is_none() {
                            // Single-value anon set drops the `{"set": []}`
                            // wrapper — upstream renders `"right": "1.1.1.1"`
                            // for `ip saddr { 1.1.1.1 }`.
                            format_set_elem_value(info.key_type, &info.elements[0].0)
                        } else {
                            let mut parts: Vec<String> = Vec::new();
                            for (start, end) in &info.elements {
                                let s_str = format_set_elem_value(info.key_type, start);
                                match end {
                                    Some(e) if e != start => {
                                        let e_str = format_set_elem_value(info.key_type, e);
                                        parts.push(format!("{{\"range\": [{}, {}]}}", s_str, e_str));
                                    }
                                    _ => parts.push(s_str),
                                }
                            }
                            format!("{{\"set\": [{}]}}", parts.join(", "))
                        }
                    }).unwrap_or_else(|| format!("\"@{}\"", json_escape(&set_name)))
                } else {
                    format!("\"@{}\"", json_escape(&set_name))
                };
                let right = if is_vmap {
                    // Upstream emits {"vmap": {"key": <left>, "data": <rhs>}}
                    // as the full match object. We assemble both halves
                    // below because we already have the left in hand.
                    rhs_inline
                } else { rhs_inline };
                match (left, is_vmap) {
                    (Some(l), true) => vec![format!(
                        "{{\"vmap\": {{\"key\": {}, \"data\": {}}}}}",
                        l, right
                    )],
                    (Some(l), false) => vec![format!(
                        "{{\"match\": {{\"op\": \"{}\", \"left\": {}, \"right\": {}}}}}",
                        op, l, right
                    )],
                    (None, _) => Vec::new(),
                }
            }
            "cmp" => {
                let op = data.iter().find(|(t, _)| *t == NFTA_CMP_OP).map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
                let cmp_data = data.iter().find(|(t, _)| *t == NFTA_CMP_DATA).map(|(_, v)| {
                    let inner = parse_attrs(v);
                    inner.iter().find(|(t, _)| *t == NFTA_DATA_VALUE).map(|(_, d)| d.clone()).unwrap_or_default()
                }).unwrap_or_default();
                let left = self.pending_left.take();
                let mut proto_update = None;
                if self.field == FieldId::IpProto && cmp_data.len() == 1 {
                    proto_update = Some(cmp_data[0]);
                }

                // Capture state snapshot BEFORE clearing so the
                // bitmask/ct-state fusion and json_right can still see
                // the payload/meta/ct context.
                let had_bitwise = self.bw_mask.is_some();
                let bw_mask = self.bw_mask.clone();
                let ct_key = self.ct_key;
                let meta_key = self.meta_key;

                let op_str = match op {
                    NFT_CMP_EQ => "==", NFT_CMP_NEQ => "!=",
                    NFT_CMP_LT => "<", NFT_CMP_LTE => "<=",
                    NFT_CMP_GT => ">", NFT_CMP_GTE => ">=",
                    _ => "==",
                };

                // Compute right side using the current ctx (before we
                // clear) so payload/meta/ct fields resolve correctly.
                let right = self.json_right(&cmp_data);

                self.clear();
                if let Some(p) = proto_update { self.proto_ctx = p; }
                if meta_key == Some(NFT_META_L4PROTO) && cmp_data.len() == 1 {
                    self.proto_ctx = cmp_data[0];
                }

                // ct state bitmask triple: `ct` load + bitwise(mask) +
                // cmp(neq|eq, 0). `neq 0` matches "any bit of mask
                // set" → `op: in`; `eq 0` matches "no bit set" → the
                // negation, rendered as `op: !=`.
                if had_bitwise && ct_key == Some(NFT_CT_STATE)
                    && (op == NFT_CMP_NEQ || op == NFT_CMP_EQ)
                {
                    if let (Some(l), Some(mask)) = (left, bw_mask) {
                        let r = format_ct_state_json(&mask);
                        let json_op = if op == NFT_CMP_NEQ { "in" } else { "!=" };
                        return vec![format!(
                            "{{\"match\": {{\"op\": \"{}\", \"left\": {}, \"right\": {}}}}}",
                            json_op, l, r
                        )];
                    }
                    return Vec::new();
                }

                match (left, right) {
                    (Some(l), Some(r)) => vec![format!(
                        "{{\"match\": {{\"op\": \"{}\", \"left\": {}, \"right\": {}}}}}",
                        op_str, l, r
                    )],
                    _ => Vec::new(),
                }
            }
            "immediate" => {
                let dreg = data.iter().find(|(t, _)| *t == NFTA_IMM_DREG).map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
                if dreg != NFT_REG_VERDICT {
                    // Non-verdict immediate: stash bytes by dst-reg
                    // so two consumers can recover them later —
                    //   - dup / fwd / tproxy via SREG_* attributes,
                    //   - snat / dnat / masquerade via REG32_01 / _02
                    //     to recover the address (and range upper).
                    if let Some((_, raw)) = data.iter().find(|(t, _)| *t == NFTA_IMM_DATA) {
                        let inner = parse_attrs(raw);
                        if let Some((_, v)) = inner.iter().find(|(t, _)| *t == NFTA_DATA_VALUE) {
                            self.pending_imm.insert(dreg, v.to_vec());
                        }
                    }
                    return Vec::new();
                }
                let imm_data = match data.iter().find(|(t, _)| *t == NFTA_IMM_DATA) { Some((_, v)) => v, None => return Vec::new() };
                let inner = parse_attrs(imm_data);
                let verdict_data = match inner.iter().find(|(t, _)| *t == NFTA_DATA_VERDICT) { Some((_, v)) => v, None => return Vec::new() };
                let vattrs = parse_attrs(verdict_data);
                let code = vattrs.iter().find(|(t, _)| *t == NFTA_VERDICT_CODE)
                    .map(|(_, v)| attr_i32_be(v)).unwrap_or(0);
                let chain = vattrs.iter().find(|(t, _)| *t == NFTA_VERDICT_CHAIN)
                    .map(|(_, v)| attr_str(v).to_string());
                let v = match code {
                    NF_ACCEPT => "accept", NF_DROP => "drop",
                    NFT_RETURN => "return", NFT_CONTINUE => "continue",
                    NFT_JUMP => "jump", NFT_GOTO => "goto",
                    _ => return Vec::new(),
                };
                if code == NFT_JUMP || code == NFT_GOTO {
                    if let Some(c) = chain {
                        return vec![format!("{{\"{}\": {{\"target\": \"{}\"}}}}", v, json_escape(&c))];
                    }
                    return Vec::new();
                }
                vec![format!("{{\"{}\": null}}", v)]
            }
            "counter" => {
                let pkts = data.iter().find(|(t, _)| *t == NFTA_COUNTER_PACKETS)
                    .map(|(_, v)| attr_u64_be(v)).unwrap_or(0);
                let bytes = data.iter().find(|(t, _)| *t == NFTA_COUNTER_BYTES)
                    .map(|(_, v)| attr_u64_be(v)).unwrap_or(0);
                vec![format!("{{\"counter\": {{\"packets\": {}, \"bytes\": {}}}}}", pkts, bytes)]
            }
            "log" => {
                let prefix = data.iter().find(|(t, _)| *t == NFTA_LOG_PREFIX)
                    .map(|(_, v)| attr_str(v).to_string());
                match prefix {
                    Some(p) => vec![format!("{{\"log\": {{\"prefix\": \"{}\"}}}}", json_escape(&p))],
                    None => vec!["{\"log\": null}".to_string()],
                }
            }
            "objref" => {
                // Named stateful object reference — emits {"counter": "name"}
                // (or "quota"/"limit"/"ct helper") matching libnftables
                // JSON shape. The space inside `ct helper` is preserved
                // verbatim — that's the upstream tag.
                let kind = data.iter().find(|(t, _)| *t == NFTA_OBJREF_IMM_TYPE)
                    .map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
                let name = data.iter().find(|(t, _)| *t == NFTA_OBJREF_IMM_NAME)
                    .map(|(_, v)| attr_str(v).to_string()).unwrap_or_default();
                let word = match kind {
                    NFT_OBJECT_COUNTER   => "counter",
                    NFT_OBJECT_QUOTA     => "quota",
                    NFT_OBJECT_LIMIT     => "limit",
                    NFT_OBJECT_CT_HELPER => "ct helper",
                    _ => return Vec::new(),
                };
                vec![format!("{{\"{}\": \"{}\"}}", word, json_escape(&name))]
            }
            "nat" => {
                // libnftables shape:
                //   {"snat": {"addr": "1.2.3.4"}}
                //   {"snat": {"addr": "1.2.3.4", "flags": "random"}}
                //   {"snat": {"addr": {"range": ["a", "b"]}, "flags": "persistent"}}
                //   {"dnat": {"addr": "10.0.0.1", "port": 8080}}
                let nat_type = data.iter().find(|(t, _)| *t == NFTA_NAT_TYPE)
                    .map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
                let flags = data.iter().find(|(t, _)| *t == NFTA_NAT_FLAGS)
                    .map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
                let key = if nat_type == NFT_NAT_SNAT { "snat" } else { "dnat" };

                let reg_min = data.iter().find(|(t, _)| *t == NFTA_NAT_REG_ADDR_MIN)
                    .map(|(_, v)| attr_u32_be(v));
                let reg_max = data.iter().find(|(t, _)| *t == NFTA_NAT_REG_ADDR_MAX)
                    .map(|(_, v)| attr_u32_be(v));
                let proto_min = data.iter().find(|(t, _)| *t == NFTA_NAT_REG_PROTO_MIN)
                    .map(|(_, v)| attr_u32_be(v));

                // Stitch together the inner JSON object piece by piece.
                let mut parts: Vec<String> = Vec::new();
                if let Some(rmin) = reg_min {
                    let lo = self.pending_imm.get(&rmin).cloned();
                    let hi = match reg_max {
                        Some(rm) if rm != rmin => self.pending_imm.get(&rm).cloned(),
                        _ => None,
                    };
                    let render_addr = |bytes: &[u8]| -> Option<String> {
                        if bytes.len() == 4 {
                            Some(format!("\"{}.{}.{}.{}\"", bytes[0], bytes[1], bytes[2], bytes[3]))
                        } else { None }
                    };
                    match (lo.as_deref().and_then(render_addr), hi.as_deref().and_then(render_addr)) {
                        (Some(a), Some(b)) => {
                            parts.push(format!("\"addr\": {{\"range\": [{}, {}]}}", a, b));
                        }
                        (Some(a), None) => {
                            parts.push(format!("\"addr\": {}", a));
                        }
                        _ => {}
                    }
                }
                if let Some(preg) = proto_min {
                    if let Some(bytes) = self.pending_imm.get(&preg) {
                        if bytes.len() == 2 {
                            let port = u16::from_be_bytes([bytes[0], bytes[1]]);
                            parts.push(format!("\"port\": {}", port));
                        }
                    }
                }
                if flags != 0 {
                    let mut names: Vec<&str> = Vec::new();
                    if flags & NF_NAT_RANGE_PROTO_RANDOM_FULLY != 0 { names.push("fully-random"); }
                    else if flags & NF_NAT_RANGE_PROTO_RANDOM != 0 { names.push("random"); }
                    if flags & NF_NAT_RANGE_PERSISTENT != 0 { names.push("persistent"); }
                    if names.len() == 1 {
                        parts.push(format!("\"flags\": \"{}\"", names[0]));
                    } else if names.len() > 1 {
                        let arr = names.iter().map(|n| format!("\"{}\"", n)).collect::<Vec<_>>().join(", ");
                        parts.push(format!("\"flags\": [{}]", arr));
                    }
                }
                self.pending_imm.clear();
                if parts.is_empty() {
                    vec![format!("{{\"{}\": null}}", key)]
                } else {
                    vec![format!("{{\"{}\": {{{}}}}}", key, parts.join(", "))]
                }
            }
            "masq" | "masquerade" => {
                let flags = data.iter().find(|(t, _)| *t == NFTA_MASQ_FLAGS)
                    .map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
                self.pending_imm.clear();
                if flags == 0 {
                    vec!["{\"masquerade\": null}".to_string()]
                } else {
                    let mut names: Vec<&str> = Vec::new();
                    if flags & NF_NAT_RANGE_PROTO_RANDOM_FULLY != 0 { names.push("fully-random"); }
                    else if flags & NF_NAT_RANGE_PROTO_RANDOM != 0 { names.push("random"); }
                    if flags & NF_NAT_RANGE_PERSISTENT != 0 { names.push("persistent"); }
                    let frag = if names.len() == 1 {
                        format!("\"flags\": \"{}\"", names[0])
                    } else {
                        let arr = names.iter().map(|n| format!("\"{}\"", n)).collect::<Vec<_>>().join(", ");
                        format!("\"flags\": [{}]", arr)
                    };
                    vec![format!("{{\"masquerade\": {{{}}}}}", frag)]
                }
            }
            "notrack" => vec!["{\"notrack\": null}".to_string()],
            "reject" => vec!["{\"reject\": null}".to_string()],
            "dup" => {
                // libnftables JSON shape:
                //   {"dup": {"addr": "1.2.3.4", "dev": "lo"}}
                // SREG_ADDR / SREG_DEV name the registers a preceding
                // immediate filled. We can't classify by 4-byte width
                // alone (ifindex and IPv4 are both 4 bytes), so the
                // expression's own attributes drive interpretation.
                let addr_reg = data.iter().find(|(t, _)| *t == NFTA_DUP_SREG_ADDR)
                    .map(|(_, v)| attr_u32_be(v));
                let dev_reg = data.iter().find(|(t, _)| *t == NFTA_DUP_SREG_DEV)
                    .map(|(_, v)| attr_u32_be(v));
                let mut s = String::from("{\"dup\": {");
                let mut first = true;
                if let Some(r) = addr_reg {
                    if let Some(a) = self.pending_imm.get(&r) {
                        if a.len() == 4 {
                            s.push_str(&format!(
                                "\"addr\": \"{}.{}.{}.{}\"",
                                a[0], a[1], a[2], a[3]
                            ));
                            first = false;
                        }
                    }
                }
                if let Some(r) = dev_reg {
                    if let Some(d) = self.pending_imm.get(&r) {
                        if d.len() == 4 {
                            let idx = u32::from_ne_bytes([d[0], d[1], d[2], d[3]]);
                            if let Some(name) = if_indextoname(idx) {
                                if !first { s.push_str(", "); }
                                s.push_str(&format!("\"dev\": \"{}\"", json_escape(&name)));
                            }
                        }
                    }
                }
                s.push_str("}}");
                self.pending_imm.clear();
                vec![s]
            }
            "fwd" => {
                // libnftables JSON shape: {"fwd": {"dev": "lo"}}.
                let dev_reg = data.iter().find(|(t, _)| *t == NFTA_FWD_SREG_DEV)
                    .map(|(_, v)| attr_u32_be(v));
                let mut dev = String::new();
                if let Some(r) = dev_reg {
                    if let Some(d) = self.pending_imm.get(&r) {
                        if d.len() == 4 {
                            let idx = u32::from_ne_bytes([d[0], d[1], d[2], d[3]]);
                            if let Some(n) = if_indextoname(idx) { dev = n; }
                        }
                    }
                }
                self.pending_imm.clear();
                vec![format!("{{\"fwd\": {{\"dev\": \"{}\"}}}}", json_escape(&dev))]
            }
            "tproxy" => {
                // {"tproxy": {"family": "ip", "port": 8080[, "addr": "1.2.3.4"]}}.
                let family = data.iter().find(|(t, _)| *t == NFTA_TPROXY_FAMILY)
                    .map(|(_, v)| attr_u32_be(v)).unwrap_or(NFPROTO_IPV4 as u32);
                let fam_str = if family == NFPROTO_IPV6 as u32 { "ip6" } else { "ip" };
                let addr_reg = data.iter().find(|(t, _)| *t == NFTA_TPROXY_REG_ADDR)
                    .map(|(_, v)| attr_u32_be(v));
                let port_reg = data.iter().find(|(t, _)| *t == NFTA_TPROXY_REG_PORT)
                    .map(|(_, v)| attr_u32_be(v));
                let mut s = format!("{{\"tproxy\": {{\"family\": \"{}\"", fam_str);
                if let Some(r) = addr_reg {
                    if let Some(a) = self.pending_imm.get(&r) {
                        if a.len() == 4 {
                            s.push_str(&format!(
                                ", \"addr\": \"{}.{}.{}.{}\"",
                                a[0], a[1], a[2], a[3]
                            ));
                        }
                    }
                }
                if let Some(r) = port_reg {
                    if let Some(p) = self.pending_imm.get(&r) {
                        if p.len() == 2 {
                            s.push_str(&format!(", \"port\": {}", u16::from_be_bytes([p[0], p[1]])));
                        }
                    }
                }
                s.push_str("}}");
                self.pending_imm.clear();
                vec![s]
            }
            "synproxy" => {
                // libnftables shape: mss/wscale are own keys, the
                // boolean timestamp / sack-perm flags fold into a
                // "flags": [...] array. The array is omitted entirely
                // when neither bit is set — matching upstream's
                // emit-only-if-present rule.
                let mss = data.iter().find(|(t, _)| *t == NFTA_SYNPROXY_MSS)
                    .and_then(|(_, v)| v.get(0..2).map(|b| u16::from_be_bytes([b[0], b[1]])))
                    .unwrap_or(0);
                let wscale = data.iter().find(|(t, _)| *t == NFTA_SYNPROXY_WSCALE)
                    .and_then(|(_, v)| v.get(0).copied()).unwrap_or(0);
                let flags = data.iter().find(|(t, _)| *t == NFTA_SYNPROXY_FLAGS)
                    .map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
                let mut parts = Vec::new();
                if flags & NF_SYNPROXY_OPT_MSS != 0 { parts.push(format!("\"mss\": {}", mss)); }
                if flags & NF_SYNPROXY_OPT_WSCALE != 0 { parts.push(format!("\"wscale\": {}", wscale)); }
                let mut flag_strs: Vec<&str> = Vec::new();
                if flags & NF_SYNPROXY_OPT_TIMESTAMP != 0 { flag_strs.push("\"timestamp\""); }
                if flags & NF_SYNPROXY_OPT_SACK_PERM != 0 { flag_strs.push("\"sack-perm\""); }
                if !flag_strs.is_empty() {
                    parts.push(format!("\"flags\": [{}]", flag_strs.join(", ")));
                }
                vec![format!("{{\"synproxy\": {{{}}}}}", parts.join(", "))]
            }
            "flow_offload" => {
                // libnftables shape: {"flow": {"op": "add", "flowtable": "@ft"}}.
                // The flowtable name attribute is bare (no `@`), but the
                // JSON value carries the `@` prefix to mirror the symbolic
                // form rules use elsewhere.
                let n = data.iter().find(|(t, _)| *t == NFTA_FLOW_TABLE_NAME)
                    .map(|(_, v)| attr_str(v).to_string()).unwrap_or_default();
                vec![format!(
                    "{{\"flow\": {{\"op\": \"add\", \"flowtable\": \"@{}\"}}}}",
                    json_escape(&n)
                )]
            }
            _ => Vec::new(),
        }
    }

    /// Format the right-hand side of a `match` based on what kind of
    /// left was seen. IPv4 addresses get printed as `"10.0.0.1"`,
    /// ports as bare integers, interface names as quoted strings, and
    /// numeric keys (mark, skuid, etc.) as decimal integers.
    fn json_right(&self, data: &[u8]) -> Option<String> {
        if matches!(self.field, FieldId::IpSaddr | FieldId::IpDaddr) && data.len() == 4 {
            // If a bitwise mask was seen it's a CIDR; render as
            // {"prefix": {"addr": "x.x.x.x", "len": N}}.
            if let Some(mask) = &self.bw_mask {
                let len = mask_to_prefix(mask);
                return Some(format!(
                    "{{\"prefix\": {{\"addr\": \"{}.{}.{}.{}\", \"len\": {}}}}}",
                    data[0], data[1], data[2], data[3], len
                ));
            }
            return Some(format!("\"{}.{}.{}.{}\"", data[0], data[1], data[2], data[3]));
        }
        // Short-payload CIDR optimisation: 1-, 2-, or 3-byte saddr/daddr.
        if matches!(self.field, FieldId::IpSaddr | FieldId::IpDaddr)
            && data.len() >= 1 && data.len() < 4
        {
            let mut padded = [0u8; 4];
            padded[..data.len()].copy_from_slice(data);
            let prefix = data.len() * 8;
            return Some(format!(
                "{{\"prefix\": {{\"addr\": \"{}.{}.{}.{}\", \"len\": {}}}}}",
                padded[0], padded[1], padded[2], padded[3], prefix
            ));
        }
        if matches!(self.field, FieldId::TcpSport | FieldId::TcpDport | FieldId::UdpSport | FieldId::UdpDport) && data.len() == 2 {
            return Some(format!("{}", u16::from_be_bytes([data[0], data[1]])));
        }
        if self.field == FieldId::IpProto || self.meta_key == Some(NFT_META_L4PROTO) {
            if data.len() == 1 {
                return Some(match data[0] {
                    6 => "\"tcp\"".into(), 17 => "\"udp\"".into(),
                    1 => "\"icmp\"".into(), 58 => "\"icmpv6\"".into(),
                    n => format!("{}", n),
                });
            }
        }
        if self.meta_key == Some(NFT_META_IIFNAME) || self.meta_key == Some(NFT_META_OIFNAME) {
            let s = attr_str(data);
            return Some(format!("\"{}\"", json_escape(s)));
        }
        if self.ct_key == Some(NFT_CT_STATE) && data.len() >= 4 {
            let state = u32::from_ne_bytes([data[0], data[1], data[2], data[3]]);
            let mut parts: Vec<&str> = Vec::new();
            if state & 1 != 0 { parts.push("invalid"); }
            if state & 2 != 0 { parts.push("established"); }
            if state & 4 != 0 { parts.push("related"); }
            if state & 8 != 0 { parts.push("new"); }
            if state & 64 != 0 { parts.push("untracked"); }
            if parts.len() == 1 {
                return Some(format!("\"{}\"", parts[0]));
            }
            let items: Vec<String> = parts.iter().map(|s| format!("\"{}\"", s)).collect();
            return Some(format!("[{}]", items.join(", ")));
        }
        // socket / meta cpu / meta cgroup ride in CPU-native register
        // slots, so the cmp data arrives in host byte order. JSON
        // emits them as bare decimal integers (no `0x` prefix).
        if matches!(self.socket_key,
            Some(NFT_SOCKET_TRANSPARENT) | Some(NFT_SOCKET_MARK) |
            Some(NFT_SOCKET_WILDCARD))
            || matches!(self.meta_key, Some(NFT_META_CPU) | Some(NFT_META_CGROUP))
        {
            if data.len() == 4 {
                let v = u32::from_ne_bytes([data[0], data[1], data[2], data[3]]);
                return Some(format!("{}", v));
            }
        }
        // rt classid: host-order u32, but upstream libnftables wraps
        // the value as a JSON string ("16") rather than a bare integer
        // — that's the libnftables `realm_type` printer.
        if self.rt_key == Some(NFT_RT_CLASSID) && data.len() == 4 {
            let v = u32::from_ne_bytes([data[0], data[1], data[2], data[3]]);
            return Some(format!("\"{}\"", v));
        }
        if self.rt_key == Some(NFT_RT_TCPMSS) && data.len() == 2 {
            let v = u16::from_ne_bytes([data[0], data[1]]);
            return Some(format!("{}", v));
        }
        // Generic numeric fallback.
        match data.len() {
            1 => Some(format!("{}", data[0])),
            2 => Some(format!("{}", u16::from_be_bytes([data[0], data[1]]))),
            4 => Some(format!("{}", u32::from_be_bytes([data[0], data[1], data[2], data[3]]))),
            _ => None,
        }
    }
}

fn family_name(fam: u8) -> &'static str {
    // Kernel NFPROTO_* values — keep in sync with netlink.rs.
    // UNSPEC=0 INET=1 IPV4=2 ARP=3 NETDEV=5 BRIDGE=7 IPV6=10.
    match fam {
        2 => "ip",
        10 => "ip6",
        1 => "inet",
        3 => "arp",
        5 => "netdev",
        7 => "bridge",
        _ => "unknown",
    }
}

pub struct JsonOut { first: bool }

impl JsonOut {
    pub fn begin() -> Self {
        // Match upstream libnftables-json's spacing: a single space after
        // every ':' and ',' on the single-line form. The test framework's
        // json-sanitize-ruleset.sh regex anchors on that spacing and on a
        // purely-numeric version string ([0-9.]+), so version gets just
        // "0.1.2" with no "stormwall-" prefix.
        //
        // STORMWALL_TEST_MODE=1 swaps in the impersonated nft version
        // and release_name so libnftables JSON consumers can't tell us
        // apart from nft of the same version. json_schema_version stays
        // at 1 in either mode (kernel ABI is the same).
        let (ver, name) = if crate::test_mode() {
            (crate::NFT_IMPERSONATED_VERSION, crate::NFT_IMPERSONATED_RELEASE_NAME)
        } else {
            ("0.1.2", "stormwall")
        };
        print!("{{\"nftables\": [");
        print!("{{\"metainfo\": {{\"version\": \"{}\", \"release_name\": \"{}\", \"json_schema_version\": 1}}}}",
            ver, name);
        JsonOut { first: false }
    }

    fn sep(&mut self) {
        if self.first { self.first = false; } else { print!(", "); }
    }

    pub fn table(&mut self, family: u8, attrs: &[(u16, Vec<u8>)]) {
        let name = attrs.iter().find(|(t, _)| *t == NFTA_TABLE_NAME)
            .map(|(_, v)| attr_str(v)).unwrap_or("");
        let handle = attrs.iter().find(|(t, _)| *t == NFTA_TABLE_HANDLE)
            .map(|(_, v)| attr_u64_be(v)).unwrap_or(0);
        let flags = attrs.iter().find(|(t, _)| *t == NFTA_TABLE_FLAGS)
            .map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
        self.sep();
        print!(
            "{{\"table\": {{\"family\": \"{}\", \"name\": \"{}\", \"handle\": {}",
            family_name(family), json_escape(name), handle
        );
        // libnftables emits a single flag as a bare string; only
        // when more than one is set does it switch to an array.
        // Today DORMANT is the only commonly-reported table flag.
        if flags & NFT_TABLE_F_DORMANT != 0 {
            print!(", \"flags\": [\"dormant\"]");
        }
        print!("}}}}");
    }

    pub fn chain(&mut self, family: u8, table: &str, attrs: &[(u16, Vec<u8>)]) {
        let name = attrs.iter().find(|(t, _)| *t == NFTA_CHAIN_NAME)
            .map(|(_, v)| attr_str(v)).unwrap_or("");
        let handle = attrs.iter().find(|(t, _)| *t == NFTA_CHAIN_HANDLE)
            .map(|(_, v)| attr_u64_be(v)).unwrap_or(0);
        self.sep();
        print!(
            "{{\"chain\": {{\"family\": \"{}\", \"table\": \"{}\", \"name\": \"{}\", \"handle\": {}",
            family_name(family), json_escape(table), json_escape(name), handle
        );
        // Upstream libnftables base-chain order (as emitted by
        // json_chain.c for NFT_CHAIN_BASE): dev, type, hook, prio,
        // policy. dev appears before type when an ingress/egress
        // chain has NFTA_HOOK_DEV.
        let hook_data = attrs.iter().find(|(t, _)| *t == NFTA_CHAIN_HOOK).map(|(_, v)| v);
        let hattrs = hook_data.map(|hd| parse_attrs(hd));
        if let Some(ref ha) = hattrs {
            if let Some((_, v)) = ha.iter().find(|(t, _)| *t == NFTA_HOOK_DEV) {
                print!(", \"dev\": \"{}\"", json_escape(attr_str(v)));
            }
        }
        if let Some((_, v)) = attrs.iter().find(|(t, _)| *t == NFTA_CHAIN_TYPE) {
            print!(", \"type\": \"{}\"", json_escape(attr_str(v)));
        }
        if let Some(ref ha) = hattrs {
            if let Some((_, v)) = ha.iter().find(|(t, _)| *t == NFTA_HOOK_HOOKNUM) {
                let h = attr_u32_be(v);
                let hn = hook_str_family(h, family);
                print!(", \"hook\": \"{}\"", hn);
            }
            if let Some((_, v)) = ha.iter().find(|(t, _)| *t == NFTA_HOOK_PRIORITY) {
                print!(", \"prio\": {}", attr_i32_be(v));
            }
        }
        if let Some((_, v)) = attrs.iter().find(|(t, _)| *t == NFTA_CHAIN_POLICY) {
            let p = attr_u32_be(v);
            let name = if p == 1 { "accept" } else { "drop" };
            print!(", \"policy\": \"{}\"", name);
        }
        print!("}}}}");
    }

    /// Emit a flowtable as JSON, matching libnftables's
    ///   {"flowtable": {"family": "inet", "name": "ft", "table": "t",
    ///                  "handle": N, "hook": "ingress", "prio": 0,
    ///                  "dev": "lo"}}
    /// shape. `dev` is a bare string when the flowtable carries a single
    /// device, an array of strings when it carries several (matching
    /// nft's `dev` polymorphism).
    pub fn flowtable(&mut self, family: u8, table: &str, attrs: &[(u16, Vec<u8>)]) {
        let name = attrs.iter().find(|(t, _)| *t == NFTA_FLOWTABLE_NAME)
            .map(|(_, v)| attr_str(v)).unwrap_or("");
        let handle = attrs.iter().find(|(t, _)| *t == NFTA_FLOWTABLE_HANDLE)
            .map(|(_, v)| attr_u64_be(v)).unwrap_or(0);
        self.sep();
        print!(
            "{{\"flowtable\": {{\"family\": \"{}\", \"name\": \"{}\", \"table\": \"{}\", \"handle\": {}",
            family_name(family), json_escape(name), json_escape(table), handle
        );
        if let Some((_, hd)) = attrs.iter().find(|(t, _)| *t == NFTA_FLOWTABLE_HOOK) {
            let ha = parse_attrs(hd);
            let hooknum = ha.iter().find(|(t, _)| *t == NFTA_FLOWTABLE_HOOK_NUM)
                .map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
            let priority = ha.iter().find(|(t, _)| *t == NFTA_FLOWTABLE_HOOK_PRIORITY)
                .map(|(_, v)| attr_i32_be(v)).unwrap_or(0);
            let hook_name = match hooknum { 0 => "ingress", _ => "ingress" };
            print!(", \"hook\": \"{}\", \"prio\": {}", hook_name, priority);

            let mut devs: Vec<String> = Vec::new();
            if let Some((_, dvb)) = ha.iter().find(|(t, _)| *t == NFTA_FLOWTABLE_HOOK_DEVS) {
                for (_, dv) in parse_attrs(dvb) {
                    devs.push(attr_str(&dv).to_string());
                }
            }
            match devs.len() {
                0 => {}
                1 => print!(", \"dev\": \"{}\"", json_escape(&devs[0])),
                _ => {
                    print!(", \"dev\": [");
                    for (i, d) in devs.iter().enumerate() {
                        if i > 0 { print!(", "); }
                        print!("\"{}\"", json_escape(d));
                    }
                    print!("]");
                }
            }
        }
        let flags = attrs.iter().find(|(t, _)| *t == NFTA_FLOWTABLE_FLAGS)
            .map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
        if flags & 0x1 != 0 {
            print!(", \"flags\": [\"offload\"]");
        }
        print!("}}}}");
    }

    /// Emit a named stateful object (counter/quota/limit) as JSON,
    /// matching libnftables's `{"counter": {"family":..., "name":...,
    /// "table":..., "packets": N, "bytes": N}}` shape.
    pub fn object(&mut self, family: u8, table: &str, attrs: &[(u16, Vec<u8>)]) {
        let name = attrs.iter().find(|(t, _)| *t == NFTA_OBJ_NAME)
            .map(|(_, v)| attr_str(v)).unwrap_or("");
        let kind = attrs.iter().find(|(t, _)| *t == NFTA_OBJ_TYPE)
            .map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
        let data = attrs.iter().find(|(t, _)| *t == NFTA_OBJ_DATA)
            .map(|(_, v)| parse_attrs(v)).unwrap_or_default();
        let word = match kind {
            NFT_OBJECT_COUNTER   => "counter",
            NFT_OBJECT_QUOTA     => "quota",
            NFT_OBJECT_LIMIT     => "limit",
            NFT_OBJECT_CT_HELPER => "ct helper",
            _ => return,
        };
        self.sep();
        match kind {
            NFT_OBJECT_COUNTER => {
                let pkts = data.iter().find(|(t, _)| *t == NFTA_COUNTER_PACKETS)
                    .map(|(_, v)| attr_u64_be(v)).unwrap_or(0);
                let bytes = data.iter().find(|(t, _)| *t == NFTA_COUNTER_BYTES)
                    .map(|(_, v)| attr_u64_be(v)).unwrap_or(0);
                print!(
                    "{{\"{}\": {{\"family\": \"{}\", \"name\": \"{}\", \"table\": \"{}\", \"packets\": {}, \"bytes\": {}}}}}",
                    word, family_name(family), json_escape(name), json_escape(table), pkts, bytes
                );
            }
            NFT_OBJECT_QUOTA => {
                let bytes = data.iter().find(|(t, _)| *t == NFTA_QUOTA_BYTES)
                    .map(|(_, v)| attr_u64_be(v)).unwrap_or(0);
                let flags = data.iter().find(|(t, _)| *t == NFTA_QUOTA_FLAGS)
                    .map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
                let used = data.iter().find(|(t, _)| *t == NFTA_QUOTA_CONSUMED)
                    .map(|(_, v)| attr_u64_be(v)).unwrap_or(0);
                let inv = (flags & NFT_QUOTA_F_INV) != 0;
                print!(
                    "{{\"{}\": {{\"family\": \"{}\", \"name\": \"{}\", \"table\": \"{}\", \"bytes\": {}, \"inv\": {}, \"used\": {}}}}}",
                    word, family_name(family), json_escape(name), json_escape(table),
                    bytes, inv, used
                );
            }
            NFT_OBJECT_CT_HELPER => {
                let htype = data.iter().find(|(t, _)| *t == NFTA_CT_HELPER_NAME)
                    .map(|(_, v)| attr_str(v).to_string()).unwrap_or_default();
                let proto = data.iter().find(|(t, _)| *t == NFTA_CT_HELPER_L4PROTO)
                    .map(|(_, v)| v.first().copied().unwrap_or(0)).unwrap_or(0);
                let l3 = data.iter().find(|(t, _)| *t == NFTA_CT_HELPER_L3PROTO)
                    .map(|(_, v)| {
                        if v.len() >= 2 { u16::from_be_bytes([v[0], v[1]]) } else { 0 }
                    }).unwrap_or(0);
                let proto_str = match proto {
                    6   => "tcp",
                    17  => "udp",
                    33  => "dccp",
                    132 => "sctp",
                    _   => "unknown",
                };
                let l3_str = match l3 as u8 {
                    NFPROTO_IPV4 => "ip",
                    NFPROTO_IPV6 => "ip6",
                    NFPROTO_INET => "inet",
                    _            => "inet",
                };
                print!(
                    "{{\"{}\": {{\"family\": \"{}\", \"name\": \"{}\", \"table\": \"{}\", \"type\": \"{}\", \"protocol\": \"{}\", \"l3proto\": \"{}\"}}}}",
                    word, family_name(family), json_escape(name), json_escape(table),
                    json_escape(&htype), proto_str, l3_str
                );
            }
            _ => {
                // Limit: minimal shape for now.
                print!(
                    "{{\"{}\": {{\"family\": \"{}\", \"name\": \"{}\", \"table\": \"{}\"}}}}",
                    word, family_name(family), json_escape(name), json_escape(table)
                );
            }
        }
    }

    /// Emit a rule as JSON. Renders the rule skeleton plus an `expr`
    /// array where each expression gets its own structured object for
    /// the kinds we recognise (verdict, counter, log). More complex
    /// expressions (payload/meta comparisons, set lookups, bitwise ops)
    /// are still pending a full serializer; for now they contribute a
    /// `{}` placeholder so the array shape matches upstream.
    pub fn rule(&mut self, family: u8, table: &str, chain: &str,
                attrs: &[(u16, Vec<u8>)], _show_handles: bool, _stateless: bool) {
        self.rule_with_sets(family, table, chain, attrs, _show_handles, _stateless, &AnonSetRegistry::default());
    }

    pub fn rule_with_sets(&mut self, family: u8, table: &str, chain: &str,
                attrs: &[(u16, Vec<u8>)], _show_handles: bool, _stateless: bool,
                registry: &AnonSetRegistry) {
        let handle = attrs.iter().find(|(t, _)| *t == NFTA_RULE_HANDLE)
            .map(|(_, v)| attr_u64_be(v)).unwrap_or(0);
        self.sep();
        print!(
            "{{\"rule\": {{\"family\": \"{}\", \"table\": \"{}\", \"chain\": \"{}\", \"handle\": {}",
            family_name(family), json_escape(table), json_escape(chain), handle
        );

        if let Some((_, ud)) = attrs.iter().find(|(t, _)| *t == NFTA_RULE_USERDATA) {
            let mut i = 0usize;
            while i + 2 <= ud.len() {
                let ty = ud[i]; let ln = ud[i + 1] as usize; i += 2;
                if i + ln > ud.len() { break; }
                if ty == 0 {
                    let s = &ud[i..i + ln];
                    let t = s.iter().take_while(|&&b| b != 0).copied().collect::<Vec<u8>>();
                    if let Ok(txt) = std::str::from_utf8(&t) {
                        print!(", \"comment\": \"{}\"", json_escape(txt));
                    }
                    break;
                }
                i += ln;
            }
        }

        if let Some((_, exprs_data)) = attrs.iter().find(|(t, _)| *t == NFTA_RULE_EXPRESSIONS) {
            print!(", \"expr\": [");
            let elems = parse_attrs(exprs_data);
            let decoded: Vec<(String, Vec<(u16, Vec<u8>)>)> = elems.iter().map(|(_, ed)| {
                let a = parse_attrs(ed);
                let n = a.iter().find(|(t, _)| *t == NFTA_EXPR_NAME)
                    .map(|(_, v)| attr_str(v).to_string()).unwrap_or_default();
                let d = a.iter().find(|(t, _)| *t == NFTA_EXPR_DATA)
                    .map(|(_, v)| parse_attrs(v)).unwrap_or_default();
                (n, d)
            }).collect();
            let (skip, proto_hint) = compute_l4proto_elision(&decoded);

            let mut ctx = ExprJsonCtx::new();
            ctx.anon_sets = registry.clone();
            if let Some(p) = proto_hint { ctx.proto_ctx = p; }
            let mut first_expr = true;
            for (i, (name, data_attrs)) in decoded.iter().enumerate() {
                if skip[i] { continue; }
                let out = ctx.consume(name, data_attrs);
                for frag in out {
                    if !first_expr { print!(", "); }
                    first_expr = false;
                    print!("{}", frag);
                }
            }
            print!("]");
        }

        print!("}}}}");
    }

    pub fn set_pairs(&mut self, family: u8, table: &str, attrs: &[(u16, Vec<u8>)],
                     pairs: &[(Vec<u8>, Option<Vec<u8>>, Option<Vec<u8>>, Option<(i32, String)>, u64, u64)]) {
        let name = attrs.iter().find(|(t, _)| *t == NFTA_SET_NAME)
            .map(|(_, v)| attr_str(v)).unwrap_or("");
        let key_type = attrs.iter().find(|(t, _)| *t == NFTA_SET_KEY_TYPE)
            .map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
        let data_type = attrs.iter().find(|(t, _)| *t == NFTA_SET_DATA_TYPE)
            .map(|(_, v)| attr_u32_be(v));
        let handle = attrs.iter().find(|(t, _)| *t == NFTA_SET_HANDLE)
            .map(|(_, v)| attr_u64_be(v)).unwrap_or(0);
        let flags = attrs.iter().find(|(t, _)| *t == NFTA_SET_FLAGS)
            .map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
        self.sep();
        let kind = if flags & NFT_SET_MAP != 0 { "map" } else { "set" };
        print!(
            "{{\"{}\": {{\"family\": \"{}\", \"name\": \"{}\", \"table\": \"{}\", \"type\": \"{}\"",
            kind, family_name(family), json_escape(name), json_escape(table),
            set_type_name(key_type)
        );
        print!(", \"handle\": {}", handle);
        if flags & NFT_SET_MAP != 0 {
            if let Some(dt) = data_type {
                print!(", \"map\": \"{}\"", set_type_name(dt));
            }
        }
        // `size N` from NFTA_SET_DESC.NFTA_SET_DESC_SIZE — nft places
        // it between "handle" and "flags". Only emitted when the set
        // declaration spelled `size N`.
        let desc_size = attrs.iter().find(|(t, _)| *t == NFTA_SET_DESC).and_then(|(_, v)| {
            let inner = parse_attrs(v);
            inner.iter().find(|(t, _)| *t == NFTA_SET_DESC_SIZE)
                .map(|(_, x)| attr_u32_be(x))
        });
        if let Some(sz) = desc_size {
            print!(", \"size\": {}", sz);
        }
        let mut flag_names: Vec<&str> = Vec::new();
        if flags & NFT_SET_CONSTANT != 0 { flag_names.push("constant"); }
        if flags & NFT_SET_INTERVAL != 0 { flag_names.push("interval"); }
        if flags & NFT_SET_TIMEOUT  != 0 { flag_names.push("timeout"); }
        if flags & NFT_SET_EVAL     != 0 { flag_names.push("dynamic"); }
        if !flag_names.is_empty() {
            print!(", \"flags\": [");
            for (i, n) in flag_names.iter().enumerate() {
                if i > 0 { print!(", "); }
                print!("\"{}\"", n);
            }
            print!("]");
        }
        // Default per-element timeout — libnftables emits it as an
        // integer number of seconds (`"timeout": 60` for `timeout 1m`).
        let set_timeout_ms = attrs.iter().find(|(t, _)| *t == NFTA_SET_TIMEOUT)
            .map(|(_, v)| attr_u64_be(v)).unwrap_or(0);
        if set_timeout_ms > 0 {
            print!(", \"timeout\": {}", set_timeout_ms / 1000);
        }
        let is_map = flags & NFT_SET_MAP != 0;
        let dty = data_type.unwrap_or(0);
        if !pairs.is_empty() {
            print!(", \"elem\": [");
            for (i, (start, end, dval, dvrd, timeout_ms, expires_ms)) in pairs.iter().enumerate() {
                if i > 0 { print!(", "); }
                // libnftables wraps a key in {"elem": {"val": ..., "timeout": N, "expires": N}}
                // when per-element timeout / expiration are present. Both are
                // emitted as integer seconds (rounded). The wrapper is omitted
                // when both are zero, leaving the bare key for back-compat.
                let mut deco = String::new();
                if *timeout_ms > 0 { deco.push_str(&format!(", \"timeout\": {}", timeout_ms / 1000)); }
                if *expires_ms > 0 { deco.push_str(&format!(", \"expires\": {}", expires_ms / 1000)); }
                if is_map {
                    if let Some(d) = dval.as_deref() {
                        // Data-valued map: emit [key, value] tuple per libnftables spec.
                        let k = format_set_elem_value(key_type, start);
                        let v = format_set_elem_value(dty, d);
                        if deco.is_empty() {
                            print!("[{}, {}]", k, v);
                        } else {
                            print!("[{{\"elem\": {{\"val\": {}{}}}}}, {}]", k, deco, v);
                        }
                    } else if let Some((code, chain)) = dvrd.as_ref() {
                        // Verdict map: emit [key, verdict_obj] tuple, where
                        // verdict_obj is e.g. {"jump": {"target": "c1"}} or
                        // {"accept": null} matching libnftables shape.
                        let k = format_set_elem_value(key_type, start);
                        if deco.is_empty() {
                            print!("[{}, {}]", k, json_verdict(*code, chain));
                        } else {
                            print!("[{{\"elem\": {{\"val\": {}{}}}}}, {}]",
                                k, deco, json_verdict(*code, chain));
                        }
                    } else {
                        // Map with no data: emit just the key.
                        let k = format_set_elem_value(key_type, start);
                        if deco.is_empty() {
                            print!("{}", k);
                        } else {
                            print!("{{\"elem\": {{\"val\": {}{}}}}}", k, deco);
                        }
                    }
                } else {
                    match end {
                        Some(e) if e != start => {
                            // Emit CIDR form when aligned, else a range tuple.
                            if let Some(prefix) = try_cidr_prefix(start, e) {
                                if key_type == 7 && start.len() == 4 {
                                    print!(
                                        "{{\"prefix\": {{\"addr\": \"{}.{}.{}.{}\", \"len\": {}}}}}",
                                        start[0], start[1], start[2], start[3], prefix
                                    );
                                    continue;
                                }
                            }
                            print!("{{\"range\": [{}, {}]}}",
                                format_set_elem_value(key_type, start),
                                format_set_elem_value(key_type, e));
                        }
                        _ => {
                            let k = format_set_elem_value(key_type, start);
                            if deco.is_empty() {
                                print!("{}", k);
                            } else {
                                print!("{{\"elem\": {{\"val\": {}{}}}}}", k, deco);
                            }
                        }
                    }
                }
            }
            print!("]");
        }
        print!("}}}}");
    }

    pub fn set(&mut self, family: u8, table: &str, attrs: &[(u16, Vec<u8>)], elems: &[Vec<u8>]) {
        let name = attrs.iter().find(|(t, _)| *t == NFTA_SET_NAME)
            .map(|(_, v)| attr_str(v)).unwrap_or("");
        let key_type = attrs.iter().find(|(t, _)| *t == NFTA_SET_KEY_TYPE)
            .map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
        let data_type = attrs.iter().find(|(t, _)| *t == NFTA_SET_DATA_TYPE)
            .map(|(_, v)| attr_u32_be(v));
        let handle = attrs.iter().find(|(t, _)| *t == NFTA_SET_HANDLE)
            .map(|(_, v)| attr_u64_be(v)).unwrap_or(0);
        let flags = attrs.iter().find(|(t, _)| *t == NFTA_SET_FLAGS)
            .map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
        self.sep();
        // libnftables JSON envelope is `"map"` for NFT_SET_MAP, else
        // `"set"`. Field order: family, name, table, type, [map],
        // handle, [flags], [elem].
        let kind = if flags & NFT_SET_MAP != 0 { "map" } else { "set" };
        print!(
            "{{\"{}\": {{\"family\": \"{}\", \"name\": \"{}\", \"table\": \"{}\", \"type\": \"{}\"",
            kind, family_name(family), json_escape(name), json_escape(table),
            set_type_name(key_type)
        );
        print!(", \"handle\": {}", handle);
        if flags & NFT_SET_MAP != 0 {
            if let Some(dt) = data_type {
                print!(", \"map\": \"{}\"", set_type_name(dt));
            }
        }
        // Human-readable flag names; upstream orders them
        // constant, interval, timeout, dynamic — match that.
        let mut flag_names: Vec<&str> = Vec::new();
        if flags & NFT_SET_CONSTANT != 0 { flag_names.push("constant"); }
        if flags & NFT_SET_INTERVAL != 0 { flag_names.push("interval"); }
        if flags & NFT_SET_TIMEOUT  != 0 { flag_names.push("timeout"); }
        if flags & NFT_SET_EVAL     != 0 { flag_names.push("dynamic"); }
        if !flag_names.is_empty() {
            print!(", \"flags\": [");
            for (i, n) in flag_names.iter().enumerate() {
                if i > 0 { print!(", "); }
                print!("\"{}\"", n);
            }
            print!("]");
        }
        if !elems.is_empty() {
            print!(", \"elem\": [");
            let mut first = true;
            for data in elems {
                if !first { print!(", "); }
                first = false;
                print!("{}", format_set_elem_value(key_type, data));
            }
            print!("]");
        }
        print!("}}}}");
    }

    pub fn end(self) {
        println!("]}}");
    }
}
