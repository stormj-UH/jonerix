# stormwall

Drop-in replacement for the Linux `nft` CLI. Pure Rust, no C dependencies.

Talks directly to the kernel's nf_tables subsystem via netlink. No libnftnl, no libmnl, no wrappers. Just raw netlink sockets and 398K of statically-linked binary.

## Usage

```sh
stormwall add table inet filter
stormwall add chain inet filter input '{ type filter hook input priority filter; policy accept; }'
stormwall add rule inet filter input tcp dport 22 accept
stormwall add rule inet filter input tcp dport 80 accept
stormwall add rule inet filter input counter drop
stormwall list ruleset
stormwall flush ruleset
```

Same syntax as `nft`. The binary also installs as `nft` symlink for compatibility.

## Install on jonerix

```sh
jpkg install stormwall-0.1.0-aarch64.jpkg
```

Installs to `/private/.jonerix/stormwall/bin/stormwall` with an `nft` symlink.

Pre-built packages for aarch64 and x86_64 are available on the [releases page](https://castle.great-morpho.ts.net:3000/jonerik/stormwall/releases).

## Build from source

Requires Rust toolchain.

```sh
cargo build --release
```

Binary lands at `target/release/stormwall`.

### Cross-compile for aarch64

```sh
RUSTFLAGS="-C linker=rust-lld" cargo build --release --target aarch64-unknown-linux-musl
```

### Build .jpkg package

```sh
cargo build --release
./mkjpkg.sh x86_64    # or aarch64
```

## Supported operations

| Command | Status |
|---------|--------|
| `add/create/delete/destroy table` | Working |
| `add/create/delete chain` (base + regular) | Working |
| `add/insert/delete rule` | Working |
| `list table/tables/chain/chains/ruleset` | Working |
| `flush table/chain/ruleset` | Working |
| `rename chain` | Working |
| `add/delete set` | Working |
| `add/delete element` | Working |

### Rule expressions

| Expression | Status |
|-----------|--------|
| `ip saddr/daddr` | Working |
| `ip6 saddr/daddr` | Working |
| `tcp/udp sport/dport` | Working |
| `tcp flags` | Working |
| `icmp type/code` | Working |
| `ether saddr/daddr/type` | Working |
| `meta iifname/oifname/mark/l4proto/...` | Working |
| `ct state/mark/status/zone/...` | Working |
| `counter` | Working |
| `log [prefix "..."]` | Working |
| `limit rate N/unit` | Working |
| `accept/drop/return/jump/goto` | Working |
| `masquerade/snat/dnat` | Working |
| `notrack` | Working |
| `reject` | Working |
| CIDR matching (`ip saddr 10.0.0.0/8`) | Working |
| `-f` file input | Working |
| `-i` interactive mode | Working |
| `-a` show handles | Working |
| `-s` stateless output | Working |

## Testing

```sh
# Unit tests (parser, no root needed)
cargo test

# Integration tests (requires root + Linux kernel with nf_tables)
cargo test -- --ignored
```

79 parser unit tests + 25 integration tests that exercise every operation against the real kernel via netlink.

## Architecture

```
src/
  main.rs      CLI entry point, option parsing
  netlink.rs   Raw netlink socket, message builder, response parser
  parser.rs    Tokenizer + nft command parser
  ops.rs       nftables CRUD operations via netlink batches
  output.rs    Format kernel data back to nft syntax
```

Single dependency: `libc` for socket syscalls. Everything else is implemented from scratch against the nf_tables netlink protocol.

Unsafe code is confined to 5 libc calls in `netlink.rs` (socket, bind, getsockname, send, recv, close). All message construction, parsing, and output formatting is safe Rust.

## License

MIT
