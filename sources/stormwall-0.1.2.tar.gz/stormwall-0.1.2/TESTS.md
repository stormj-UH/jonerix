# Test coverage

## In-tree battery (tests/stormwall_test.sh)

24 focused nft compatibility scenarios that exercise the common path:
declarative `-f`, JSON `-j`, ruleset round-trip, iifname/oifname,
ct state, meta mark, named set references, interval elements, rule
handles, comments, NAT chains.

**24 / 24 pass** on a Pi 5 (aarch64, kernel 6.18) with the
post-2026-04-18 netlink fix set (`cc5a64b`).

## Upstream nftables shell suite

Run against `tests/shell/testcases/` from the upstream `nftables.git`
tree (`NFT=/path/to/stormwall NFT_REAL=/path/to/stormwall
NFT_TEST_HAVE_json=n bash run-tests.sh …`).
The `NFT_TEST_HAVE_json=n` flag is required today because the
framework's per-test sanity step runs `$NFT -j --check -f <json>`
against its own emitted JSON, which requires a full JSON *input*
parser — not yet implemented (only JSON output is).

Pass rates from the first run:

| Category         | OK | FAIL | DUMP FAIL | SKIP | Total | Pass rate |
| ---              | -- | --   | --        | --   | --    | --        |
| chains           | 16 | 29   | –         | 7    | 52    | 36% |
| rule_management  | 6  | 6    | 1         | 2    | 15    | 46% |
| comments         | 1  | 2    | –         | 1    | 4     | 33% |
| transactions     | 15 | 20   | 12        | 3    | 50    | 32% |
| nft-f            | 8  | 21   | 6         | 4    | 39    | 22% |
| parsing          | 1  | 5    | –         | 2    | 8     | 14% |
| **total (sampled)** | **47** | **83** | **19** | **19** | **168** | **~31%** |

The rest of `tests/shell/testcases/` (sets/, maps/, flowtable/,
include/, owner/, packetpath/, optionals/, optimizations/, bitwise/,
trace/, bogons/, cache/, listing/, netns/, nft-i/, json/) is not
yet sampled.

### What the failures mean

Most DUMP FAILs are rendering differences: stormwall's text formatter
diverges in small ways from upstream's (whitespace, stateful counter
placement, priority-value string form). The rules themselves are
encoded correctly on the netlink wire — `$NFT list ruleset` just
prints differently.

Most FAILs fall in a few predictable buckets:

- **JSON input (`-j -f` reading)** — not implemented. Blocks the
  framework's own sanity loop, masked by `NFT_TEST_HAVE_json=n`.
- **Variables (`define foo = bar`)** — the declarative parser does
  not yet substitute `$foo`. Blocks `*_variable_*` tests.
- **Stateful objects (`counter NAME`, `quota`, `limit NAME`)** —
  only in-rule counters exist today; named objects aren't parsed.
- **netdev ingress/egress chains** — hook types beyond
  filter/nat/route not handled.
- **fib / hash / numgen expressions** — parser entries missing.
- **set with `timeout` / stateful expr inside set** —
  `flags dynamic` not yet wired.

None of these are kernel-correctness issues; they're feature gaps
in the parser and formatter.

## Reproducing

Quick in-tree:

```sh
scp tests/stormwall_test.sh <pi>:/tmp/
ssh <pi> bash /tmp/stormwall_test.sh
```

Upstream:

```sh
git clone --depth 1 https://git.netfilter.org/nftables.git
cd nftables/tests/shell
sudo NFT=$(pwd)/../../../stormwall/target/release/stormwall \
     NFT_REAL=$(pwd)/../../../stormwall/target/release/stormwall \
     NFT_TEST_HAVE_json=n \
     bash run-tests.sh testcases/chains
```
