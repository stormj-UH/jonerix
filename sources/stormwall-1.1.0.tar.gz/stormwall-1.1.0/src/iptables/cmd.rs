// (c) 2026 Jon-Erik G. Storm, Inc., a California Corporation,
// doing business as LAVA GOAT SOFTWARE.  MIT license.
//
// IptCmd: parsed representation of one `iptables`-style invocation.
//
// We keep the surface deliberately flat: a single struct that holds
// every option an iptables command can carry. The parser fills in
// what was given, the lowerer translates that into one or more nft
// commands. This mirrors the way iptables(8) is documented as a flat
// flag set in the manpage and the way real iptables internally does
// `do_command4 -> command_match` — one giant struct, lots of optional
// fields, dispatch in the lowerer.
//
// Clean room: types and field names follow the iptables(8) manpage
// (e.g. `--src`, `--sport`) and the kernel's xt_match/xt_target ABI
// names that are public API. No source code from xtables-addons or
// iptables itself was consulted.

use std::fmt;

/// The top-level operation: append, insert, delete, etc.
///
/// One `IptCmd` carries exactly one operation. Multi-rule invocations
/// (e.g. `iptables -F` flushing every chain) decompose into a sequence
/// of `IptCmd`s before lowering — keeping the per-command shape simple.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum IptOp {
    /// `-A <chain>` — append rule to end of chain.
    Append,
    /// `-I <chain> [<n>]` — insert rule at 1-based position N (default 1).
    Insert(u32),
    /// `-D <chain> <n>` — delete by 1-based rule number.
    DeleteNum(u32),
    /// `-D <chain> <rule-spec>` — delete first rule matching the spec.
    DeleteMatch,
    /// `-R <chain> <n>` — replace 1-based rule N with the new spec.
    Replace(u32),
    /// `-L [<chain>]` — list rules. `chain` is empty when no chain given.
    List,
    /// `-S [<chain>]` — print rules in restore format.
    Save,
    /// `-F [<chain>]` — flush. `chain` empty means flush every chain in the table.
    Flush,
    /// `-X [<chain>]` — delete user-defined chain. Empty means every empty user chain.
    DeleteChain,
    /// `-N <chain>` — create a new user-defined chain.
    NewChain,
    /// `-Z [<chain>]` — zero packet/byte counters.
    Zero,
    /// `-C <chain>` — check if rule matching the spec exists.
    Check,
    /// `-P <chain> <target>` — set policy on a built-in chain.
    Policy,
}

/// The five built-in iptables tables. Each maps 1:1 to an nft table
/// of the same name in family `ip` (iptables) or `ip6` (ip6tables).
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum IptTable {
    Filter,
    Nat,
    Mangle,
    Raw,
    Security,
}

impl IptTable {
    pub fn from_str_opt(s: &str) -> Option<Self> {
        Some(match s {
            "filter"   => IptTable::Filter,
            "nat"      => IptTable::Nat,
            "mangle"   => IptTable::Mangle,
            "raw"      => IptTable::Raw,
            "security" => IptTable::Security,
            _ => return None,
        })
    }
    pub fn name(self) -> &'static str {
        match self {
            IptTable::Filter   => "filter",
            IptTable::Nat      => "nat",
            IptTable::Mangle   => "mangle",
            IptTable::Raw      => "raw",
            IptTable::Security => "security",
        }
    }
}

impl fmt::Display for IptTable {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{}", self.name())
    }
}

impl Default for IptTable {
    fn default() -> Self { IptTable::Filter }
}

/// L3 family. `Ip` for `iptables`, `Ip6` for `ip6tables`. Affects
/// table family in the lowering and a few payload offsets (the
/// per-protocol header parser).
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Family {
    Ip,
    Ip6,
}

impl Family {
    pub fn nft_family(self) -> &'static str {
        match self { Family::Ip => "ip", Family::Ip6 => "ip6" }
    }
}

/// A network address with optional prefix length. Used for `-s` /
/// `-d` and SNAT/DNAT/`--to-source` etc. We carry the original string
/// alongside the parsed bytes so the renderer (iptables-save output,
/// `-L` output) can reproduce the user's input verbatim — iptables
/// itself behaves that way and the framework round-trip tests rely on
/// it.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct AddrSpec {
    pub raw: String,
    pub family: Family,
    /// Negated with leading `!`.
    pub neg: bool,
}

/// Parsed `--sport` / `--dport` value: a single port or a range.
/// iptables accepts `start:end`, omitted-start (`:end` = 0..end),
/// omitted-end (`start:` = start..65535) and bare `port`.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct PortRange { pub start: u16, pub end: u16 }

impl PortRange {
    pub fn single(p: u16) -> Self { PortRange { start: p, end: p } }
}

/// A multiport list — `-m multiport --dports 22,80,443,1000:2000`.
/// Each entry is either a single port or a range.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct MultiportList {
    pub items: Vec<PortRange>,
    pub neg: bool,
}

/// Conntrack state set: NEW, ESTABLISHED, RELATED, INVALID,
/// UNTRACKED, DNAT, SNAT. We store as a vector of strings to round-
/// trip exactly; the lowerer maps them to nft `ct state` keywords.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct StateSet {
    pub names: Vec<String>,
    pub neg: bool,
}

/// `-m limit --limit RATE --limit-burst N`.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct LimitOpt {
    pub rate: u64,        // numerator
    pub unit: String,     // "second", "minute", "hour", "day"
    pub burst: u32,
}

/// `-j TARGET [args...]` — terminal action.
///
/// We split the well-known iptables targets into named variants so the
/// lowerer can produce the exact nft form. Anything else (including
/// jumps to user chains) lands in `Jump(name)` — the lowerer treats
/// it as `jump <name>` if the chain exists, otherwise emits an error.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum Target {
    Accept,
    Drop,
    Return,
    /// Jump to a user chain or another built-in. Stores the raw name.
    Jump(String),
    /// REJECT, optionally with `--reject-with <type>`. Type strings
    /// pass through to the lowerer untouched (e.g. "icmp-port-unreachable").
    Reject(Option<String>),
    /// LOG, with optional `--log-prefix <s>` / `--log-level <n>`.
    Log { prefix: Option<String>, level: Option<u8> },
    /// MASQUERADE [--to-ports START[-END]].
    Masquerade { to_ports: Option<PortRange> },
    /// SNAT --to-source ADDR[-ADDR][:PORT[-PORT]] [--random] [--persistent].
    Snat { to_source: String, random: bool, persistent: bool },
    /// DNAT --to-destination ADDR[-ADDR][:PORT[-PORT]] [--random] [--persistent].
    Dnat { to_destination: String, random: bool, persistent: bool },
    /// REDIRECT --to-ports START[-END] [--random].
    Redirect { to_ports: Option<PortRange>, random: bool },
    /// MARK --set-mark VALUE[/MASK] / --set-xmark / --or-mark / --and-mark / --xor-mark.
    Mark { kind: MarkKind, value: u32, mask: Option<u32> },
    /// CONNMARK --set-mark / --save-mark / --restore-mark / --and-mark / --or-mark / --xor-mark.
    Connmark(ConnmarkOp),
    /// TPROXY --on-port <p> [--on-ip <a>] [--tproxy-mark v[/m]].
    Tproxy { on_port: Option<u16>, on_ip: Option<String>, mark: Option<(u32, Option<u32>)> },
    /// NFLOG [--nflog-prefix s] [--nflog-group n].
    Nflog { prefix: Option<String>, group: Option<u32> },
    /// TRACE.
    Trace,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum MarkKind { Set, Xset, And, Or, Xor }

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum ConnmarkOp {
    SetMark { value: u32, mask: Option<u32> },
    SaveMark { nfmask: Option<u32>, ctmask: Option<u32> },
    RestoreMark { nfmask: Option<u32>, ctmask: Option<u32> },
    And(u32),
    Or(u32),
    Xor(u32),
}

/// A parsed `-m <module> [args...]` clause that we don't have a first-
/// class home for. Used for `-m comment --comment ...` (consumed but
/// ignored at the netlink layer) and for stub modules that warn rather
/// than fail.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum MatchModule {
    /// Already-folded into `RuleSpec` fields; kept as a marker so
    /// renderers can re-emit `-m state`/`-m conntrack` etc.
    Stateful(String),
    /// `-m comment --comment "<s>"`.
    Comment(String),
    /// `-m addrtype --src-type LOCAL` / `--dst-type LOCAL` (etc.).
    Addrtype { src: Option<String>, dst: Option<String> },
    /// `-m mark --mark VALUE[/MASK]`.
    Mark { value: u32, mask: Option<u32>, neg: bool },
    /// `-m physdev --physdev-in IF` / `--physdev-out IF` / `--physdev-is-bridged`.
    Physdev { iin: Option<String>, oout: Option<String>, is_bridged: bool },
    /// `-m owner --uid-owner UID` / `--gid-owner GID`.
    Owner { uid: Option<u32>, gid: Option<u32> },
    /// `-m set --match-set NAME src/dst[,src/dst...]`.
    Set { name: String, dirs: Vec<String>, neg: bool },
    /// `-m mac --mac-source AA:BB:...`.
    Mac { source: String, neg: bool },
    /// `-m string --string S --algo bm|kmp` — punted; lowerer warns.
    String { s: String, algo: String },
    /// Unsupported / not-yet-implemented module. The lowerer rejects
    /// these by default; verbose mode lists them explicitly.
    Unsupported(String),
}

/// One iptables rule spec: a bag of optional matches + a target.
///
/// All `Option`s are populated only when the corresponding flag was
/// given on the command line. The lowerer reads each in turn and
/// builds an nft `add rule` with the equivalent match clauses.
///
/// Negation (`!`) is tracked per-field. iptables grammar puts `!`
/// before the flag (e.g. `! -s 1.2.3.4`); we capture that by storing
/// `(value, negated)` for fields that support negation.
#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct RuleSpec {
    /// `-p tcp` etc. Lowercased, kept as the user wrote it.
    pub protocol: Option<String>,
    pub protocol_neg: bool,
    /// `-s ADDR[/CIDR]`.
    pub src: Option<AddrSpec>,
    /// `-d ADDR[/CIDR]`.
    pub dst: Option<AddrSpec>,
    /// `-i IFACE`.
    pub iif: Option<String>,
    pub iif_neg: bool,
    /// `-o IFACE`.
    pub oif: Option<String>,
    pub oif_neg: bool,
    /// `-f` — fragments-only.
    pub fragment: bool,
    /// `--sport`/`--dport` (after `-p tcp` or `-p udp`).
    pub sport: Option<PortRange>,
    pub sport_neg: bool,
    pub dport: Option<PortRange>,
    pub dport_neg: bool,
    /// `--icmp-type` / `--icmpv6-type`.
    pub icmp_type: Option<String>,
    pub icmp_type_neg: bool,
    /// TCP flags from `-m tcp --tcp-flags MASK COMP` or the legacy `--tcp-flags`.
    /// `(mask, comp)` — both comma-separated lists like "SYN,ACK".
    pub tcp_flags: Option<(String, String)>,
    pub tcp_flags_neg: bool,
    /// `-m tcp --syn` shorthand: equivalent to `--tcp-flags FIN,SYN,RST,ACK SYN`.
    pub tcp_syn: bool,
    /// Folded conntrack state set (from `-m state` or `-m conntrack`).
    pub state: Option<StateSet>,
    /// `-m multiport --sports`.
    pub multiport_sports: Option<MultiportList>,
    /// `-m multiport --dports`.
    pub multiport_dports: Option<MultiportList>,
    /// `-m limit --limit ...`.
    pub limit: Option<LimitOpt>,
    /// All other `-m ...` modules in source order. The lowerer iterates
    /// and emits the right nft clause for each.
    pub modules: Vec<MatchModule>,
    /// `-j TARGET` — terminal action. `None` is a valid (non-terminal)
    /// rule under iptables: matches accumulate into the chain's policy
    /// path, no jump. Real iptables accepts this and so do we.
    pub target: Option<Target>,
    /// `--goto NAME` — like jump but with a different return semantic
    /// (no implicit return at end of target chain). nft equivalent:
    /// `goto <name>`.
    pub goto: Option<String>,
    /// User-supplied comment via `-m comment --comment "<s>"`. Stored
    /// once even if multiple `-m comment` clauses appear; the lowerer
    /// emits an nft `comment "..."` clause from this field directly.
    pub comment: Option<String>,
}

/// One full iptables invocation.
#[derive(Debug, Clone)]
pub struct IptCmd {
    pub family: Family,
    pub table: IptTable,
    pub op: IptOp,
    /// Chain name. Empty for table-level operations like `-S` / `-F`
    /// without a chain argument.
    pub chain: String,
    /// For `-P <chain> <target>`: the target name (ACCEPT|DROP).
    pub policy_target: Option<String>,
    /// Rule spec for ops that carry one (-A/-I/-D-by-match/-R/-C).
    pub spec: RuleSpec,
    /// Display flags from `-L`: numeric (`-n`), verbose (`-v`),
    /// line-numbers (`--line-numbers`), exact counts (`-x`).
    pub list_numeric: bool,
    pub list_verbose: bool,
    pub list_linenums: bool,
    pub list_exact: bool,
    /// `-w` / `-W`: lock-wait knobs. Accepted for compat; ignored.
    /// Set so the renderer can re-emit them on save when carrying a
    /// fully-faithful round-trip is desired.
    pub wait: Option<u32>,
    pub wait_interval_us: Option<u32>,
}

impl IptCmd {
    pub fn new(family: Family) -> Self {
        IptCmd {
            family,
            table: IptTable::default(),
            op: IptOp::List,
            chain: String::new(),
            policy_target: None,
            spec: RuleSpec::default(),
            list_numeric: false,
            list_verbose: false,
            list_linenums: false,
            list_exact: false,
            wait: None,
            wait_interval_us: None,
        }
    }
}

/// The standard set of built-in chains per table. Matches xtables_chain_lookup
/// from the public iptables sources but the layout is dictated by
/// netfilter's hook API (`netfilter_ipv4.h`) which is the public ABI.
pub const FILTER_BUILTINS:   &[&str] = &["INPUT", "OUTPUT", "FORWARD"];
pub const NAT_BUILTINS:      &[&str] = &["PREROUTING", "INPUT", "OUTPUT", "POSTROUTING"];
pub const MANGLE_BUILTINS:   &[&str] = &["PREROUTING", "INPUT", "FORWARD", "OUTPUT", "POSTROUTING"];
pub const RAW_BUILTINS:      &[&str] = &["PREROUTING", "OUTPUT"];
pub const SECURITY_BUILTINS: &[&str] = &["INPUT", "OUTPUT", "FORWARD"];

pub fn builtins_for(table: IptTable) -> &'static [&'static str] {
    match table {
        IptTable::Filter   => FILTER_BUILTINS,
        IptTable::Nat      => NAT_BUILTINS,
        IptTable::Mangle   => MANGLE_BUILTINS,
        IptTable::Raw      => RAW_BUILTINS,
        IptTable::Security => SECURITY_BUILTINS,
    }
}

/// Iptables built-in chain → (nft hook, nft priority constant) for the
/// matching netfilter hook. Priorities follow the kernel's
/// `linux/netfilter_ipv4.h` `NF_IP_PRI_*` (which iptables itself wires
/// up via xtables_init_ipv4). We pick the same numeric values nft uses
/// (filter=0, raw=-300, mangle=-150, dstnat=-100, srcnat=100, security=50).
pub fn hook_for_chain(table: IptTable, chain: &str) -> Option<(&'static str, &'static str)> {
    let chain_upper: &str = chain;
    Some(match (table, chain_upper) {
        (IptTable::Filter,   "INPUT")        => ("input",       "filter"),
        (IptTable::Filter,   "OUTPUT")       => ("output",      "filter"),
        (IptTable::Filter,   "FORWARD")      => ("forward",     "filter"),

        (IptTable::Nat,      "PREROUTING")   => ("prerouting",  "dstnat"),
        (IptTable::Nat,      "INPUT")        => ("input",       "100"),
        (IptTable::Nat,      "OUTPUT")       => ("output",      "-100"),
        (IptTable::Nat,      "POSTROUTING")  => ("postrouting", "srcnat"),

        (IptTable::Mangle,   "PREROUTING")   => ("prerouting",  "mangle"),
        (IptTable::Mangle,   "INPUT")        => ("input",       "mangle"),
        (IptTable::Mangle,   "FORWARD")      => ("forward",     "mangle"),
        (IptTable::Mangle,   "OUTPUT")       => ("output",      "mangle"),
        (IptTable::Mangle,   "POSTROUTING")  => ("postrouting", "mangle"),

        (IptTable::Raw,      "PREROUTING")   => ("prerouting",  "raw"),
        (IptTable::Raw,      "OUTPUT")       => ("output",      "raw"),

        (IptTable::Security, "INPUT")        => ("input",       "security"),
        (IptTable::Security, "OUTPUT")       => ("output",      "security"),
        (IptTable::Security, "FORWARD")      => ("forward",     "security"),
        _ => return None,
    })
}

/// Returns true iff `chain` is a built-in for `table` (case-sensitive,
/// matching iptables behaviour: "INPUT" is built-in, "input" isn't).
pub fn is_builtin(table: IptTable, chain: &str) -> bool {
    builtins_for(table).iter().any(|b| *b == chain)
}
