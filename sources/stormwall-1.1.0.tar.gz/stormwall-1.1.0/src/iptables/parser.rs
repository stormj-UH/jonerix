// (c) 2026 Jon-Erik G. Storm, Inc., a California Corporation,
// doing business as LAVA GOAT SOFTWARE.  MIT license.
//
// argv → IptCmd. Hand-written recursive-descent over a flat argv
// vector, modelled on iptables(8). The flag set is documented in
// `man iptables`, `man iptables-extensions`, and the table of match
// modules in <https://netfilter.org/projects/iptables/>. We did not
// look at iptables source — every parse choice falls out of the
// observable CLI behaviour and the manpage prose.
//
// Two grammar quirks worth calling out:
//
// 1. `! -s 1.2.3.4` puts the negation BEFORE the flag, but `-s !
//    1.2.3.4` (legacy form) puts it after. Real iptables 1.6+ deprecates
//    the legacy form but still accepts it; we accept both.
// 2. `--dport 22` is only valid AFTER `-p tcp` or `-p udp` (or
//    inside `-m tcp` / `-m udp`). The match-module clause acts as a
//    "switch" that enables more flags. We don't enforce that strictly —
//    we just consume `--dport` whenever we see it. This matches
//    real iptables which, for example, accepts `iptables -A INPUT -p
//    tcp -m tcp --dport 22` and `iptables -A INPUT -p tcp --dport 22`
//    interchangeably.

use super::cmd::*;

pub struct Parsed {
    pub cmd: IptCmd,
}

#[derive(Debug)]
pub struct ParseError(pub String);

impl std::fmt::Display for ParseError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "{}", self.0)
    }
}

impl std::error::Error for ParseError {}

type Res<T> = Result<T, ParseError>;

fn err(s: impl Into<String>) -> ParseError { ParseError(s.into()) }

/// Family inferred from the binary basename (after stripping `-save` /
/// `-restore`). `iptables`, `iptables-save`, `iptables-restore` →
/// `Family::Ip`. `ip6tables*` → `Family::Ip6`. Anything else is
/// rejected here so the dispatcher can produce a clean error.
pub fn family_from_argv0(argv0: &str) -> Res<Family> {
    let base = std::path::Path::new(argv0)
        .file_name()
        .map(|s| s.to_string_lossy().into_owned())
        .unwrap_or_else(|| argv0.to_string());
    // Strip suffixes for save/restore variants: we just need the family.
    let core = base
        .strip_suffix("-save")
        .or_else(|| base.strip_suffix("-restore"))
        .unwrap_or(&base);
    match core {
        "iptables"          => Ok(Family::Ip),
        "ip6tables"         => Ok(Family::Ip6),
        // Compatibility aliases. Some distros symlink the legacy
        // names (`iptables-legacy`, `iptables-nft`) at the same path;
        // accept both since we are the only backend here.
        "iptables-legacy"   => Ok(Family::Ip),
        "iptables-nft"      => Ok(Family::Ip),
        "ip6tables-legacy"  => Ok(Family::Ip6),
        "ip6tables-nft"     => Ok(Family::Ip6),
        other => Err(err(format!("unknown iptables binary: {}", other))),
    }
}

/// Returns true if `argv0`'s basename is one of the *-save variants.
pub fn is_save_variant(argv0: &str) -> bool {
    let base = std::path::Path::new(argv0)
        .file_name()
        .map(|s| s.to_string_lossy().into_owned())
        .unwrap_or_else(|| argv0.to_string());
    base.ends_with("-save")
}

/// Returns true if `argv0`'s basename is one of the *-restore variants.
pub fn is_restore_variant(argv0: &str) -> bool {
    let base = std::path::Path::new(argv0)
        .file_name()
        .map(|s| s.to_string_lossy().into_owned())
        .unwrap_or_else(|| argv0.to_string());
    base.ends_with("-restore")
}

/// Parse a single iptables invocation.
///
/// `argv` should NOT include argv[0] — pass `&args[1..]`. The family
/// (ip / ip6) is determined separately by the dispatcher from argv[0].
pub fn parse(family: Family, argv: &[String]) -> Res<Parsed> {
    let mut p = Parser::new(family, argv);
    p.parse()?;
    Ok(Parsed { cmd: p.into_cmd() })
}

struct Parser<'a> {
    argv: &'a [String],
    i: usize,
    cmd: IptCmd,
    /// Toggled by a leading `!` token; consumed by the next flag and
    /// reset. iptables documents the modern form (`! -s 1.2.3.4`)
    /// here; legacy `-s ! 1.2.3.4` is handled per-flag below.
    pending_neg: bool,
    /// Track which match modules have been "enabled" by a `-m`
    /// invocation. We don't enforce strict ordering (iptables itself is
    /// sloppy) but we use this to disambiguate `--mark` (the mark
    /// match) from MARK target args.
    in_module: Option<String>,
    /// Set when `-j ` was just seen and the next token is the target
    /// name. After that, `--reject-with`, `--to-source`, `--set-mark`
    /// etc. attach to the target rather than to a match.
    have_target: bool,
}

impl<'a> Parser<'a> {
    fn new(family: Family, argv: &'a [String]) -> Self {
        Parser {
            argv,
            i: 0,
            cmd: IptCmd::new(family),
            pending_neg: false,
            in_module: None,
            have_target: false,
        }
    }

    fn into_cmd(self) -> IptCmd { self.cmd }

    fn peek(&self) -> Option<&'a str> { self.argv.get(self.i).map(|s| s.as_str()) }

    fn next_str(&mut self) -> Res<&'a str> {
        let s = self.argv.get(self.i)
            .ok_or_else(|| err("missing argument"))?;
        self.i += 1;
        Ok(s.as_str())
    }

    fn take_value(&mut self, flag: &str) -> Res<String> {
        match self.argv.get(self.i) {
            Some(s) => {
                self.i += 1;
                // Legacy `-s ! 1.2.3.4`: a literal "!" between flag and
                // value flips the negation.
                if s == "!" {
                    self.pending_neg = !self.pending_neg;
                    self.take_value(flag)
                } else {
                    Ok(s.clone())
                }
            }
            None => Err(err(format!("{} requires a value", flag))),
        }
    }

    fn take_neg(&mut self) -> bool {
        let n = self.pending_neg;
        self.pending_neg = false;
        n
    }

    fn parse(&mut self) -> Res<()> {
        // First pass: pick up table override (`-t TABLE`) and global
        // flags. iptables accepts `-t` anywhere on the command line, so
        // we just walk through.
        let mut have_op = false;
        while self.i < self.argv.len() {
            let tok = self.argv[self.i].clone();
            match tok.as_str() {
                "!" => { self.pending_neg = !self.pending_neg; self.i += 1; }
                "-t" | "--table" => {
                    self.i += 1;
                    let v = self.take_value("-t")?;
                    self.cmd.table = IptTable::from_str_opt(&v)
                        .ok_or_else(|| err(format!("unknown table: {}", v)))?;
                }
                // Operations. Each consumes its mandatory chain arg
                // (and, where applicable, a numeric position).
                "-A" | "--append" => {
                    self.i += 1;
                    self.cmd.op = IptOp::Append;
                    self.cmd.chain = self.take_value("-A")?;
                    have_op = true;
                }
                "-I" | "--insert" => {
                    self.i += 1;
                    self.cmd.chain = self.take_value("-I")?;
                    // Optional position argument. If the next token
                    // parses as a positive integer, it's the position.
                    let pos = match self.peek() {
                        Some(s) if s.chars().all(|c| c.is_ascii_digit()) => {
                            let n: u32 = s.parse().unwrap_or(1);
                            self.i += 1;
                            n
                        }
                        _ => 1,
                    };
                    self.cmd.op = IptOp::Insert(pos);
                    have_op = true;
                }
                "-D" | "--delete" => {
                    self.i += 1;
                    self.cmd.chain = self.take_value("-D")?;
                    // Either a 1-based rule number, or the rule-spec
                    // begins immediately. Heuristic: if the next token
                    // is an unsigned integer AND no further flags
                    // follow, treat as rule number; otherwise as match.
                    if let Some(s) = self.peek() {
                        if s.chars().all(|c| c.is_ascii_digit())
                            && !s.is_empty()
                            && (self.argv.get(self.i + 1).is_none()
                                || self.argv.get(self.i + 1).map(|v| v.starts_with('-') || v == "!").unwrap_or(false))
                        {
                            // Bare numeric — but only treat as N when
                            // there are no more rule-spec tokens AFTER
                            // the number. If a flag follows, fall
                            // through into rule-spec parsing.
                            let only_num = self.argv.get(self.i + 1).is_none();
                            if only_num {
                                let n: u32 = s.parse().unwrap_or(1);
                                self.i += 1;
                                self.cmd.op = IptOp::DeleteNum(n);
                                have_op = true;
                                continue;
                            }
                        }
                    }
                    self.cmd.op = IptOp::DeleteMatch;
                    have_op = true;
                }
                "-R" | "--replace" => {
                    self.i += 1;
                    self.cmd.chain = self.take_value("-R")?;
                    let n: u32 = self.take_value("-R")?.parse()
                        .map_err(|_| err("-R requires a numeric position"))?;
                    self.cmd.op = IptOp::Replace(n);
                    have_op = true;
                }
                "-L" | "--list" => {
                    self.i += 1;
                    self.cmd.op = IptOp::List;
                    if let Some(s) = self.peek() {
                        if !s.starts_with('-') && s != "!" {
                            self.cmd.chain = self.next_str()?.to_string();
                        }
                    }
                    have_op = true;
                }
                "-S" | "--list-rules" => {
                    self.i += 1;
                    self.cmd.op = IptOp::Save;
                    if let Some(s) = self.peek() {
                        if !s.starts_with('-') && s != "!" {
                            self.cmd.chain = self.next_str()?.to_string();
                        }
                    }
                    have_op = true;
                }
                "-F" | "--flush" => {
                    self.i += 1;
                    self.cmd.op = IptOp::Flush;
                    if let Some(s) = self.peek() {
                        if !s.starts_with('-') && s != "!" {
                            self.cmd.chain = self.next_str()?.to_string();
                        }
                    }
                    have_op = true;
                }
                "-X" | "--delete-chain" => {
                    self.i += 1;
                    self.cmd.op = IptOp::DeleteChain;
                    if let Some(s) = self.peek() {
                        if !s.starts_with('-') && s != "!" {
                            self.cmd.chain = self.next_str()?.to_string();
                        }
                    }
                    have_op = true;
                }
                "-N" | "--new-chain" => {
                    self.i += 1;
                    self.cmd.op = IptOp::NewChain;
                    self.cmd.chain = self.take_value("-N")?;
                    have_op = true;
                }
                "-Z" | "--zero" => {
                    self.i += 1;
                    self.cmd.op = IptOp::Zero;
                    if let Some(s) = self.peek() {
                        if !s.starts_with('-') && s != "!" {
                            self.cmd.chain = self.next_str()?.to_string();
                        }
                    }
                    have_op = true;
                }
                "-C" | "--check" => {
                    self.i += 1;
                    self.cmd.op = IptOp::Check;
                    self.cmd.chain = self.take_value("-C")?;
                    have_op = true;
                }
                "-P" | "--policy" => {
                    self.i += 1;
                    self.cmd.op = IptOp::Policy;
                    self.cmd.chain = self.take_value("-P")?;
                    self.cmd.policy_target = Some(self.take_value("-P")?);
                    have_op = true;
                }
                // Display / wait flags — modify behaviour without changing op.
                "-n" | "--numeric"      => { self.i += 1; self.cmd.list_numeric = true; }
                "-v" | "--verbose"      => { self.i += 1; self.cmd.list_verbose = true; }
                "-x" | "--exact"        => { self.i += 1; self.cmd.list_exact = true; }
                "--line-numbers"        => { self.i += 1; self.cmd.list_linenums = true; }
                "-w" | "--wait"         => {
                    self.i += 1;
                    // -w takes an optional integer. Probe.
                    if let Some(s) = self.peek() {
                        if s.chars().all(|c| c.is_ascii_digit()) {
                            self.cmd.wait = Some(s.parse().unwrap_or(0));
                            self.i += 1;
                            continue;
                        }
                    }
                    self.cmd.wait = Some(0);
                }
                "-W" | "--wait-interval" => {
                    self.i += 1;
                    self.cmd.wait_interval_us = Some(self.take_value("-W")?.parse().unwrap_or(0));
                }
                // Compat / ignored.
                "--ipv4" | "-4" => { self.i += 1; }
                "--ipv6" | "-6" => { self.i += 1; }
                "-h" | "--help" => { return Err(err("__help__")); }
                "-V" | "--version" => { return Err(err("__version__")); }
                "-m" | "--match" => {
                    self.i += 1;
                    let name = self.take_value("-m")?;
                    self.in_module = Some(name.clone());
                    // Some modules carry implicit consumption (e.g.
                    // `-m comment` always followed by `--comment`).
                    // Most modules have a marker effect only — they
                    // enable additional flags that follow.
                    // Append a placeholder Stateful entry for renderers
                    // that want to re-emit `-m <name>` literally.
                    self.cmd.spec.modules.push(MatchModule::Stateful(name));
                }
                "-j" | "--jump" => {
                    self.i += 1;
                    let name = self.take_value("-j")?;
                    self.have_target = true;
                    self.cmd.spec.target = Some(parse_target_name(&name));
                }
                "--goto" | "-g" => {
                    self.i += 1;
                    self.cmd.spec.goto = Some(self.take_value("--goto")?);
                }
                // Match-side flags. Each calls into a helper below.
                _ => self.parse_match_flag(&tok)?,
            }
        }
        if !have_op {
            return Err(err("no operation specified (use -A/-I/-D/-L/-S/-F/-X/-N/-Z/-C/-P)"));
        }
        Ok(())
    }

    fn parse_match_flag(&mut self, tok: &str) -> Res<()> {
        match tok {
            "-p" | "--protocol" => {
                self.i += 1;
                let neg = self.take_neg();
                let v = self.take_value("-p")?;
                self.cmd.spec.protocol = Some(v.to_lowercase());
                self.cmd.spec.protocol_neg = neg;
                Ok(())
            }
            "-s" | "--source" | "--src" => {
                self.i += 1;
                let neg = self.take_neg();
                let v = self.take_value("-s")?;
                self.cmd.spec.src = Some(AddrSpec { raw: v, family: self.cmd.family, neg });
                Ok(())
            }
            "-d" | "--destination" | "--dst" => {
                self.i += 1;
                let neg = self.take_neg();
                let v = self.take_value("-d")?;
                self.cmd.spec.dst = Some(AddrSpec { raw: v, family: self.cmd.family, neg });
                Ok(())
            }
            "-i" | "--in-interface" => {
                self.i += 1;
                let neg = self.take_neg();
                self.cmd.spec.iif = Some(self.take_value("-i")?);
                self.cmd.spec.iif_neg = neg;
                Ok(())
            }
            "-o" | "--out-interface" => {
                self.i += 1;
                let neg = self.take_neg();
                self.cmd.spec.oif = Some(self.take_value("-o")?);
                self.cmd.spec.oif_neg = neg;
                Ok(())
            }
            "-f" | "--fragment" => { self.i += 1; self.cmd.spec.fragment = true; Ok(()) }
            "--sport" | "--source-port" | "--source-ports" => {
                self.i += 1;
                let neg = self.take_neg();
                let v = self.take_value("--sport")?;
                if matches!(self.in_module.as_deref(), Some("multiport")) && v.contains(',') {
                    self.cmd.spec.multiport_sports = Some(parse_multiport(&v, neg)?);
                } else {
                    self.cmd.spec.sport = Some(parse_port_range(&v)?);
                    self.cmd.spec.sport_neg = neg;
                }
                Ok(())
            }
            "--dport" | "--destination-port" | "--destination-ports" => {
                self.i += 1;
                let neg = self.take_neg();
                let v = self.take_value("--dport")?;
                if matches!(self.in_module.as_deref(), Some("multiport")) && v.contains(',') {
                    self.cmd.spec.multiport_dports = Some(parse_multiport(&v, neg)?);
                } else {
                    self.cmd.spec.dport = Some(parse_port_range(&v)?);
                    self.cmd.spec.dport_neg = neg;
                }
                Ok(())
            }
            "--dports" => {
                self.i += 1;
                let neg = self.take_neg();
                let v = self.take_value("--dports")?;
                self.cmd.spec.multiport_dports = Some(parse_multiport(&v, neg)?);
                Ok(())
            }
            "--sports" => {
                self.i += 1;
                let neg = self.take_neg();
                let v = self.take_value("--sports")?;
                self.cmd.spec.multiport_sports = Some(parse_multiport(&v, neg)?);
                Ok(())
            }
            "--icmp-type" | "--icmpv6-type" => {
                self.i += 1;
                let neg = self.take_neg();
                self.cmd.spec.icmp_type = Some(self.take_value("--icmp-type")?);
                self.cmd.spec.icmp_type_neg = neg;
                Ok(())
            }
            "--syn" => { self.i += 1; self.cmd.spec.tcp_syn = true; Ok(()) }
            "--tcp-flags" => {
                self.i += 1;
                let neg = self.take_neg();
                let mask = self.take_value("--tcp-flags")?;
                let comp = self.take_value("--tcp-flags")?;
                self.cmd.spec.tcp_flags = Some((mask, comp));
                self.cmd.spec.tcp_flags_neg = neg;
                Ok(())
            }
            "--state" | "--ctstate" => {
                self.i += 1;
                let neg = self.take_neg();
                let v = self.take_value("--state")?;
                let names = v.split(',').map(|s| s.trim().to_string()).collect();
                self.cmd.spec.state = Some(StateSet { names, neg });
                Ok(())
            }
            "--limit" => {
                self.i += 1;
                let v = self.take_value("--limit")?;
                let (rate, unit) = match v.find('/') {
                    Some(i) => (v[..i].parse::<u64>().unwrap_or(0), v[i+1..].to_string()),
                    None    => (v.parse::<u64>().unwrap_or(0), "second".to_string()),
                };
                let burst = if matches!(self.peek(), Some("--limit-burst")) {
                    self.i += 1;
                    self.take_value("--limit-burst")?.parse().unwrap_or(5)
                } else { 5 };
                self.cmd.spec.limit = Some(LimitOpt { rate, unit, burst });
                Ok(())
            }
            "--limit-burst" => {
                // Standalone (no preceding --limit). Apply to existing
                // limit if any; otherwise build a default 1/second limit.
                self.i += 1;
                let burst: u32 = self.take_value("--limit-burst")?.parse().unwrap_or(5);
                if let Some(ref mut l) = self.cmd.spec.limit {
                    l.burst = burst;
                } else {
                    self.cmd.spec.limit = Some(LimitOpt {
                        rate: 1, unit: "second".to_string(), burst,
                    });
                }
                Ok(())
            }
            "--comment" => {
                self.i += 1;
                let s = self.take_value("--comment")?;
                self.cmd.spec.comment = Some(s.clone());
                self.cmd.spec.modules.push(MatchModule::Comment(s));
                Ok(())
            }
            "--src-type" => {
                self.i += 1;
                let v = self.take_value("--src-type")?;
                self.cmd.spec.modules.push(MatchModule::Addrtype { src: Some(v), dst: None });
                Ok(())
            }
            "--dst-type" => {
                self.i += 1;
                let v = self.take_value("--dst-type")?;
                self.cmd.spec.modules.push(MatchModule::Addrtype { src: None, dst: Some(v) });
                Ok(())
            }
            "--mark" => {
                self.i += 1;
                let neg = self.take_neg();
                let v = self.take_value("--mark")?;
                let (val, mask) = parse_mark_mask(&v)?;
                if self.have_target {
                    // Belongs to MARK target — reroute.
                    if let Some(Target::Jump(name)) = self.cmd.spec.target.clone() {
                        if name.eq_ignore_ascii_case("MARK") {
                            self.cmd.spec.target = Some(Target::Mark { kind: MarkKind::Set, value: val, mask });
                            return Ok(());
                        }
                    }
                }
                self.cmd.spec.modules.push(MatchModule::Mark { value: val, mask, neg });
                Ok(())
            }
            "--set-mark" => {
                self.i += 1;
                let v = self.take_value("--set-mark")?;
                let (val, mask) = parse_mark_mask(&v)?;
                self.have_target = true;
                self.cmd.spec.target = Some(promote_mark_target(&self.cmd.spec.target, MarkKind::Set, val, mask));
                Ok(())
            }
            "--set-xmark" => {
                self.i += 1;
                let v = self.take_value("--set-xmark")?;
                let (val, mask) = parse_mark_mask(&v)?;
                self.have_target = true;
                self.cmd.spec.target = Some(promote_mark_target(&self.cmd.spec.target, MarkKind::Xset, val, mask));
                Ok(())
            }
            "--and-mark" => {
                self.i += 1;
                let v = self.take_value("--and-mark")?;
                let (val, mask) = parse_mark_mask(&v)?;
                self.have_target = true;
                self.cmd.spec.target = Some(promote_mark_target(&self.cmd.spec.target, MarkKind::And, val, mask));
                Ok(())
            }
            "--or-mark" => {
                self.i += 1;
                let v = self.take_value("--or-mark")?;
                let (val, mask) = parse_mark_mask(&v)?;
                self.have_target = true;
                self.cmd.spec.target = Some(promote_mark_target(&self.cmd.spec.target, MarkKind::Or, val, mask));
                Ok(())
            }
            "--xor-mark" => {
                self.i += 1;
                let v = self.take_value("--xor-mark")?;
                let (val, mask) = parse_mark_mask(&v)?;
                self.have_target = true;
                self.cmd.spec.target = Some(promote_mark_target(&self.cmd.spec.target, MarkKind::Xor, val, mask));
                Ok(())
            }
            "--save-mark" => {
                self.i += 1;
                self.have_target = true;
                self.cmd.spec.target = Some(Target::Connmark(ConnmarkOp::SaveMark { nfmask: None, ctmask: None }));
                Ok(())
            }
            "--restore-mark" => {
                self.i += 1;
                self.have_target = true;
                self.cmd.spec.target = Some(Target::Connmark(ConnmarkOp::RestoreMark { nfmask: None, ctmask: None }));
                Ok(())
            }
            "--reject-with" => {
                self.i += 1;
                let v = self.take_value("--reject-with")?;
                self.cmd.spec.target = Some(Target::Reject(Some(v)));
                Ok(())
            }
            "--log-prefix" => {
                self.i += 1;
                let v = self.take_value("--log-prefix")?;
                merge_log(&mut self.cmd.spec.target, |l| l.prefix = Some(v));
                Ok(())
            }
            "--log-level" => {
                self.i += 1;
                let v = self.take_value("--log-level")?;
                let lvl: u8 = v.parse().unwrap_or(0);
                merge_log(&mut self.cmd.spec.target, |l| l.level = Some(lvl));
                Ok(())
            }
            "--to-source" => {
                self.i += 1;
                let v = self.take_value("--to-source")?;
                self.cmd.spec.target = Some(Target::Snat { to_source: v, random: false, persistent: false });
                Ok(())
            }
            "--to-destination" => {
                self.i += 1;
                let v = self.take_value("--to-destination")?;
                self.cmd.spec.target = Some(Target::Dnat { to_destination: v, random: false, persistent: false });
                Ok(())
            }
            "--to-ports" => {
                self.i += 1;
                let v = self.take_value("--to-ports")?;
                let r = parse_port_range(&v)?;
                // Could be MASQUERADE --to-ports or REDIRECT --to-ports.
                match self.cmd.spec.target.clone() {
                    Some(Target::Masquerade { .. }) =>
                        self.cmd.spec.target = Some(Target::Masquerade { to_ports: Some(r) }),
                    Some(Target::Redirect { random, .. }) =>
                        self.cmd.spec.target = Some(Target::Redirect { to_ports: Some(r), random }),
                    _ => self.cmd.spec.target = Some(Target::Redirect { to_ports: Some(r), random: false }),
                }
                Ok(())
            }
            "--random" => {
                self.i += 1;
                match self.cmd.spec.target.clone() {
                    Some(Target::Masquerade { to_ports }) => {
                        self.cmd.spec.target = Some(Target::Masquerade { to_ports });
                    }
                    Some(Target::Snat { to_source, persistent, .. }) =>
                        self.cmd.spec.target = Some(Target::Snat { to_source, random: true, persistent }),
                    Some(Target::Dnat { to_destination, persistent, .. }) =>
                        self.cmd.spec.target = Some(Target::Dnat { to_destination, random: true, persistent }),
                    Some(Target::Redirect { to_ports, .. }) =>
                        self.cmd.spec.target = Some(Target::Redirect { to_ports, random: true }),
                    _ => {} // Ignore on other targets.
                }
                Ok(())
            }
            "--persistent" => {
                self.i += 1;
                match self.cmd.spec.target.clone() {
                    Some(Target::Snat { to_source, random, .. }) =>
                        self.cmd.spec.target = Some(Target::Snat { to_source, random, persistent: true }),
                    Some(Target::Dnat { to_destination, random, .. }) =>
                        self.cmd.spec.target = Some(Target::Dnat { to_destination, random, persistent: true }),
                    _ => {}
                }
                Ok(())
            }
            // -m physdev family.
            "--physdev-in" => {
                self.i += 1;
                let v = self.take_value("--physdev-in")?;
                self.merge_physdev(|p| p.iin = Some(v));
                Ok(())
            }
            "--physdev-out" => {
                self.i += 1;
                let v = self.take_value("--physdev-out")?;
                self.merge_physdev(|p| p.oout = Some(v));
                Ok(())
            }
            "--physdev-is-bridged" => {
                self.i += 1;
                self.merge_physdev(|p| p.is_bridged = true);
                Ok(())
            }
            "--uid-owner" => {
                self.i += 1;
                let v = self.take_value("--uid-owner")?.parse().unwrap_or(0);
                self.merge_owner(|o| o.uid = Some(v));
                Ok(())
            }
            "--gid-owner" => {
                self.i += 1;
                let v = self.take_value("--gid-owner")?.parse().unwrap_or(0);
                self.merge_owner(|o| o.gid = Some(v));
                Ok(())
            }
            "--match-set" => {
                self.i += 1;
                let neg = self.take_neg();
                let name = self.take_value("--match-set")?;
                let dirs_raw = self.take_value("--match-set")?;
                let dirs = dirs_raw.split(',').map(|s| s.trim().to_string()).collect();
                self.cmd.spec.modules.push(MatchModule::Set { name, dirs, neg });
                Ok(())
            }
            "--mac-source" => {
                self.i += 1;
                let neg = self.take_neg();
                let s = self.take_value("--mac-source")?;
                self.cmd.spec.modules.push(MatchModule::Mac { source: s, neg });
                Ok(())
            }
            "--string" => {
                self.i += 1;
                let s = self.take_value("--string")?;
                let algo = if matches!(self.peek(), Some("--algo")) {
                    self.i += 1; self.take_value("--algo")?
                } else { "bm".to_string() };
                self.cmd.spec.modules.push(MatchModule::String { s, algo });
                Ok(())
            }
            // NFLOG fields.
            "--nflog-prefix" => {
                self.i += 1;
                let v = self.take_value("--nflog-prefix")?;
                merge_nflog(&mut self.cmd.spec.target, |t| t.prefix = Some(v));
                Ok(())
            }
            "--nflog-group" => {
                self.i += 1;
                let v = self.take_value("--nflog-group")?.parse().unwrap_or(0);
                merge_nflog(&mut self.cmd.spec.target, |t| t.group = Some(v));
                Ok(())
            }
            // TPROXY fields.
            "--on-port" => {
                self.i += 1;
                let v: u16 = self.take_value("--on-port")?.parse().unwrap_or(0);
                merge_tproxy(&mut self.cmd.spec.target, |t| t.on_port = Some(v));
                Ok(())
            }
            "--on-ip" => {
                self.i += 1;
                let v = self.take_value("--on-ip")?;
                merge_tproxy(&mut self.cmd.spec.target, |t| t.on_ip = Some(v));
                Ok(())
            }
            "--tproxy-mark" => {
                self.i += 1;
                let v = self.take_value("--tproxy-mark")?;
                let (val, mask) = parse_mark_mask(&v)?;
                merge_tproxy(&mut self.cmd.spec.target, |t| t.mark = Some((val, mask)));
                Ok(())
            }
            other => {
                // Unrecognised. iptables treats unknown long options as
                // hard errors; we mirror that. Stop with a clean message.
                Err(err(format!("unknown flag: {}", other)))
            }
        }
    }

    fn merge_physdev<F: FnOnce(&mut PhysdevAcc)>(&mut self, f: F) {
        // Walk modules backwards looking for an existing Physdev to
        // update; otherwise push a fresh one.
        for m in self.cmd.spec.modules.iter_mut().rev() {
            if let MatchModule::Physdev { iin, oout, is_bridged } = m {
                let mut acc = PhysdevAcc {
                    iin: iin.clone(), oout: oout.clone(), is_bridged: *is_bridged
                };
                f(&mut acc);
                *iin = acc.iin;
                *oout = acc.oout;
                *is_bridged = acc.is_bridged;
                return;
            }
        }
        let mut acc = PhysdevAcc::default();
        f(&mut acc);
        self.cmd.spec.modules.push(MatchModule::Physdev {
            iin: acc.iin, oout: acc.oout, is_bridged: acc.is_bridged,
        });
    }

    fn merge_owner<F: FnOnce(&mut OwnerAcc)>(&mut self, f: F) {
        for m in self.cmd.spec.modules.iter_mut().rev() {
            if let MatchModule::Owner { uid, gid } = m {
                let mut acc = OwnerAcc { uid: *uid, gid: *gid };
                f(&mut acc);
                *uid = acc.uid;
                *gid = acc.gid;
                return;
            }
        }
        let mut acc = OwnerAcc::default();
        f(&mut acc);
        self.cmd.spec.modules.push(MatchModule::Owner { uid: acc.uid, gid: acc.gid });
    }
}

#[derive(Default)]
struct PhysdevAcc { iin: Option<String>, oout: Option<String>, is_bridged: bool }

#[derive(Default)]
struct OwnerAcc { uid: Option<u32>, gid: Option<u32> }

/// Map a target name to the right `Target` variant. Names with extra
/// arguments (REJECT, MARK, MASQUERADE, SNAT, DNAT, ...) get filled in
/// later when their `--*` flags appear; default to the no-arg form.
fn parse_target_name(name: &str) -> Target {
    match name {
        "ACCEPT"     => Target::Accept,
        "DROP"       => Target::Drop,
        "RETURN"     => Target::Return,
        "REJECT"     => Target::Reject(None),
        "LOG"        => Target::Log { prefix: None, level: None },
        "MASQUERADE" => Target::Masquerade { to_ports: None },
        "SNAT"       => Target::Snat { to_source: String::new(), random: false, persistent: false },
        "DNAT"       => Target::Dnat { to_destination: String::new(), random: false, persistent: false },
        "REDIRECT"   => Target::Redirect { to_ports: None, random: false },
        "MARK"       => Target::Mark { kind: MarkKind::Set, value: 0, mask: None },
        "CONNMARK"   => Target::Connmark(ConnmarkOp::SetMark { value: 0, mask: None }),
        "TPROXY"     => Target::Tproxy { on_port: None, on_ip: None, mark: None },
        "NFLOG"      => Target::Nflog { prefix: None, group: None },
        "TRACE"      => Target::Trace,
        // Anything else: treat as a chain jump. Real iptables resolves
        // this against the table's user-chain set; we punt that to the
        // lowerer so the message matches iptables' error text exactly.
        _ => Target::Jump(name.to_string()),
    }
}

fn promote_mark_target(cur: &Option<Target>, kind: MarkKind, val: u32, mask: Option<u32>) -> Target {
    match cur {
        Some(Target::Connmark(_)) => Target::Connmark(match kind {
            MarkKind::Set | MarkKind::Xset => ConnmarkOp::SetMark { value: val, mask },
            MarkKind::And => ConnmarkOp::And(val),
            MarkKind::Or  => ConnmarkOp::Or(val),
            MarkKind::Xor => ConnmarkOp::Xor(val),
        }),
        _ => Target::Mark { kind, value: val, mask },
    }
}

fn merge_log<F: FnOnce(&mut LogAcc)>(target: &mut Option<Target>, f: F) {
    match target {
        Some(Target::Log { prefix, level }) => {
            let mut acc = LogAcc { prefix: prefix.clone(), level: *level };
            f(&mut acc);
            *prefix = acc.prefix;
            *level = acc.level;
        }
        _ => {
            let mut acc = LogAcc::default();
            f(&mut acc);
            *target = Some(Target::Log { prefix: acc.prefix, level: acc.level });
        }
    }
}

#[derive(Default)]
struct LogAcc { prefix: Option<String>, level: Option<u8> }

fn merge_nflog<F: FnOnce(&mut NflogAcc)>(target: &mut Option<Target>, f: F) {
    match target {
        Some(Target::Nflog { prefix, group }) => {
            let mut acc = NflogAcc { prefix: prefix.clone(), group: *group };
            f(&mut acc);
            *prefix = acc.prefix;
            *group = acc.group;
        }
        _ => {
            let mut acc = NflogAcc::default();
            f(&mut acc);
            *target = Some(Target::Nflog { prefix: acc.prefix, group: acc.group });
        }
    }
}

#[derive(Default)]
struct NflogAcc { prefix: Option<String>, group: Option<u32> }

fn merge_tproxy<F: FnOnce(&mut TproxyAcc)>(target: &mut Option<Target>, f: F) {
    match target {
        Some(Target::Tproxy { on_port, on_ip, mark }) => {
            let mut acc = TproxyAcc { on_port: *on_port, on_ip: on_ip.clone(), mark: mark.clone() };
            f(&mut acc);
            *on_port = acc.on_port;
            *on_ip = acc.on_ip;
            *mark = acc.mark;
        }
        _ => {
            let mut acc = TproxyAcc::default();
            f(&mut acc);
            *target = Some(Target::Tproxy { on_port: acc.on_port, on_ip: acc.on_ip, mark: acc.mark });
        }
    }
}

#[derive(Default)]
struct TproxyAcc { on_port: Option<u16>, on_ip: Option<String>, mark: Option<(u32, Option<u32>)> }

/// Parse `value[/mask]` for mark-style flags. Both are u32 written in
/// hex (`0x100`), decimal, or octal (with `0` prefix). We honour the
/// `0x` prefix for hex and otherwise decimal; the kernel does the same.
pub fn parse_mark_mask(v: &str) -> Res<(u32, Option<u32>)> {
    let parse = |s: &str| -> Res<u32> {
        if let Some(rest) = s.strip_prefix("0x") {
            u32::from_str_radix(rest, 16).map_err(|_| err(format!("bad mark value: {}", s)))
        } else if let Some(rest) = s.strip_prefix("0X") {
            u32::from_str_radix(rest, 16).map_err(|_| err(format!("bad mark value: {}", s)))
        } else {
            s.parse::<u32>().map_err(|_| err(format!("bad mark value: {}", s)))
        }
    };
    if let Some(i) = v.find('/') {
        Ok((parse(&v[..i])?, Some(parse(&v[i+1..])?)))
    } else {
        Ok((parse(v)?, None))
    }
}

/// Parse a `start[:end]` port range. iptables also accepts `:end`
/// (start defaults to 0) and `start:` (end defaults to 65535).
pub fn parse_port_range(v: &str) -> Res<PortRange> {
    if let Some(i) = v.find(':') {
        let lo = if i == 0 { 0 } else { v[..i].parse::<u16>().map_err(|_| err(format!("bad port: {}", v)))? };
        let hi = if i + 1 == v.len() { 65535 } else { v[i+1..].parse::<u16>().map_err(|_| err(format!("bad port: {}", v)))? };
        Ok(PortRange { start: lo, end: hi })
    } else if let Some(i) = v.find('-') {
        // SNAT/DNAT-style port range uses '-' instead of ':'.
        let lo: u16 = v[..i].parse().map_err(|_| err(format!("bad port: {}", v)))?;
        let hi: u16 = v[i+1..].parse().map_err(|_| err(format!("bad port: {}", v)))?;
        Ok(PortRange { start: lo, end: hi })
    } else {
        let p: u16 = v.parse().map_err(|_| err(format!("bad port: {}", v)))?;
        Ok(PortRange { start: p, end: p })
    }
}

/// Parse `--dports 22,80,443,1000:2000` into a list of port ranges.
pub fn parse_multiport(v: &str, neg: bool) -> Res<MultiportList> {
    let mut items = Vec::new();
    for part in v.split(',') {
        let p = part.trim();
        if p.is_empty() { continue; }
        items.push(parse_port_range(p)?);
    }
    Ok(MultiportList { items, neg })
}

#[cfg(test)]
mod tests {
    use super::*;

    fn parse_argv(family: Family, args: &[&str]) -> IptCmd {
        let argv: Vec<String> = args.iter().map(|s| s.to_string()).collect();
        parse(family, &argv).unwrap().cmd
    }

    #[test]
    fn family_strips_save_suffix() {
        assert!(matches!(family_from_argv0("iptables-save"), Ok(Family::Ip)));
        assert!(matches!(family_from_argv0("ip6tables-restore"), Ok(Family::Ip6)));
        assert!(matches!(family_from_argv0("/usr/sbin/ip6tables"), Ok(Family::Ip6)));
    }

    #[test]
    fn append_basic() {
        let c = parse_argv(Family::Ip, &["-A", "INPUT", "-j", "ACCEPT"]);
        assert!(matches!(c.op, IptOp::Append));
        assert_eq!(c.chain, "INPUT");
        assert_eq!(c.spec.target, Some(Target::Accept));
    }

    #[test]
    fn append_with_dport() {
        let c = parse_argv(Family::Ip, &["-A", "INPUT", "-p", "tcp", "--dport", "22", "-j", "ACCEPT"]);
        assert_eq!(c.spec.protocol.as_deref(), Some("tcp"));
        assert_eq!(c.spec.dport, Some(PortRange::single(22)));
    }

    #[test]
    fn negation_modern() {
        let c = parse_argv(Family::Ip, &["-A", "FORWARD", "!", "-i", "eth0", "-j", "ACCEPT"]);
        assert_eq!(c.spec.iif.as_deref(), Some("eth0"));
        assert!(c.spec.iif_neg);
    }

    #[test]
    fn negation_legacy() {
        let c = parse_argv(Family::Ip, &["-A", "FORWARD", "-s", "!", "10.0.0.0/8", "-j", "DROP"]);
        assert!(c.spec.src.unwrap().neg);
    }

    #[test]
    fn nat_masquerade() {
        let c = parse_argv(Family::Ip, &[
            "-t", "nat", "-A", "POSTROUTING", "-s", "172.17.0.0/16", "!", "-o", "docker0", "-j", "MASQUERADE"
        ]);
        assert_eq!(c.table, IptTable::Nat);
        assert!(c.spec.oif_neg);
        assert_eq!(c.spec.oif.as_deref(), Some("docker0"));
        assert!(matches!(c.spec.target, Some(Target::Masquerade { .. })));
    }

    #[test]
    fn dnat_to_destination() {
        let c = parse_argv(Family::Ip, &[
            "-t", "nat", "-A", "PREROUTING", "-p", "tcp", "--dport", "8080",
            "-j", "DNAT", "--to-destination", "172.17.0.2:80"
        ]);
        match c.spec.target.unwrap() {
            Target::Dnat { to_destination, .. } => assert_eq!(to_destination, "172.17.0.2:80"),
            _ => panic!("expected DNAT"),
        }
    }

    #[test]
    fn conntrack_state() {
        let c = parse_argv(Family::Ip, &[
            "-A", "FORWARD", "-m", "conntrack", "--ctstate", "RELATED,ESTABLISHED", "-j", "ACCEPT"
        ]);
        let st = c.spec.state.unwrap();
        assert_eq!(st.names, vec!["RELATED", "ESTABLISHED"]);
    }

    #[test]
    fn comment_consumed() {
        let c = parse_argv(Family::Ip, &[
            "-A", "INPUT", "-m", "comment", "--comment", "hello world", "-j", "ACCEPT"
        ]);
        assert_eq!(c.spec.comment.as_deref(), Some("hello world"));
    }

    #[test]
    fn new_chain_op() {
        let c = parse_argv(Family::Ip, &["-N", "DOCKER"]);
        assert!(matches!(c.op, IptOp::NewChain));
        assert_eq!(c.chain, "DOCKER");
    }

    #[test]
    fn policy_set() {
        let c = parse_argv(Family::Ip, &["-P", "FORWARD", "DROP"]);
        assert!(matches!(c.op, IptOp::Policy));
        assert_eq!(c.policy_target.as_deref(), Some("DROP"));
    }

    #[test]
    fn delete_by_num() {
        let c = parse_argv(Family::Ip, &["-D", "INPUT", "3"]);
        assert!(matches!(c.op, IptOp::DeleteNum(3)));
    }

    #[test]
    fn delete_by_match() {
        let c = parse_argv(Family::Ip, &["-D", "INPUT", "-p", "tcp", "--dport", "22", "-j", "ACCEPT"]);
        assert!(matches!(c.op, IptOp::DeleteMatch));
    }

    #[test]
    fn multiport_dports() {
        let c = parse_argv(Family::Ip, &[
            "-A", "INPUT", "-p", "tcp", "-m", "multiport", "--dports", "22,80,443", "-j", "ACCEPT"
        ]);
        let mp = c.spec.multiport_dports.unwrap();
        assert_eq!(mp.items.len(), 3);
        assert_eq!(mp.items[0], PortRange::single(22));
    }

    #[test]
    fn addrtype_dst_local() {
        let c = parse_argv(Family::Ip, &[
            "-t", "nat", "-A", "PREROUTING", "-m", "addrtype", "--dst-type", "LOCAL", "-j", "ACCEPT"
        ]);
        let mut found = false;
        for m in &c.spec.modules {
            if let MatchModule::Addrtype { dst: Some(d), .. } = m {
                if d == "LOCAL" { found = true; }
            }
        }
        assert!(found);
    }

    #[test]
    fn list_with_chain() {
        let c = parse_argv(Family::Ip, &["-L", "FORWARD", "-n", "-v", "--line-numbers"]);
        assert!(matches!(c.op, IptOp::List));
        assert_eq!(c.chain, "FORWARD");
        assert!(c.list_numeric);
        assert!(c.list_verbose);
        assert!(c.list_linenums);
    }

    #[test]
    fn reject_with_type() {
        let c = parse_argv(Family::Ip, &[
            "-A", "INPUT", "-j", "REJECT", "--reject-with", "icmp-port-unreachable"
        ]);
        assert_eq!(c.spec.target, Some(Target::Reject(Some("icmp-port-unreachable".into()))));
    }

    #[test]
    fn limit_burst() {
        let c = parse_argv(Family::Ip, &[
            "-A", "INPUT", "-m", "limit", "--limit", "10/second", "--limit-burst", "5", "-j", "ACCEPT"
        ]);
        let l = c.spec.limit.unwrap();
        assert_eq!(l.rate, 10);
        assert_eq!(l.unit, "second");
        assert_eq!(l.burst, 5);
    }
}
