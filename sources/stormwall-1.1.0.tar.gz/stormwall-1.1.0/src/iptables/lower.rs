// (c) 2026 Jon-Erik G. Storm, Inc., a California Corporation,
// doing business as LAVA GOAT SOFTWARE.  MIT license.
//
// IptCmd → nft text. We lower each iptables operation into a small
// sequence of nft commands which are then fed straight back through
// stormwall's existing nft parser. That keeps the iptables surface as
// a pure front-end: every match, target and table operation re-uses
// the netlink emitter that nft mode already battle-tested. The cost
// is one extra parse pass per command, which is negligible compared
// to the netlink round-trip.
//
// The mapping table (clean room — derived from `man iptables-extensions`
// and observable iptables→nft translation behaviour, NOT from the
// `iptables` source tree):
//
//   -A FORWARD -j ACCEPT
//     → add rule ip filter forward accept
//
//   -A FORWARD -p tcp --dport 22 -j ACCEPT
//     → add rule ip filter forward tcp dport 22 accept
//
//   -t nat -A POSTROUTING -s 10.0.0.0/24 ! -o eth0 -j MASQUERADE
//     → add rule ip nat postrouting ip saddr 10.0.0.0/24 oifname != "eth0" masquerade
//
//   -t nat -A PREROUTING -p tcp --dport 80 -j DNAT --to-destination 1.2.3.4:8080
//     → add rule ip nat prerouting tcp dport 80 dnat to 1.2.3.4:8080
//
// Built-in chains in iptables are predeclared at table creation
// (`*filter`, `:INPUT ACCEPT [0:0]`); in nft they have to be created
// with a hook + priority before rules can be added. The lowerer
// auto-creates the table and any base chains it touches the first
// time a rule lands, mirroring iptables' "always present" feel.

use super::cmd::*;

/// One nft command as a text snippet, ready for the nft parser.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct NftLine(pub String);

/// Lowering result: a sequence of nft commands that should be applied
/// as one atomic batch to make the requested iptables operation
/// observably equivalent.
#[derive(Debug, Default)]
pub struct LoweredBatch {
    pub lines: Vec<NftLine>,
    /// True when this batch represents a delete-by-match search; the
    /// caller should resolve the match against existing rules first.
    pub needs_match_resolution: bool,
}

#[derive(Debug)]
pub struct LowerError(pub String);

impl std::fmt::Display for LowerError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "{}", self.0)
    }
}
impl std::error::Error for LowerError {}

fn err(s: impl Into<String>) -> LowerError { LowerError(s.into()) }

/// Lower a parsed iptables command to nft commands. Returns the
/// complete batch, including any `add table` / `add chain` preambles
/// needed before the rule itself.
pub fn lower(cmd: &IptCmd) -> Result<LoweredBatch, LowerError> {
    match &cmd.op {
        IptOp::NewChain     => lower_new_chain(cmd),
        IptOp::DeleteChain  => lower_delete_chain(cmd),
        IptOp::Flush        => lower_flush(cmd),
        IptOp::Policy       => lower_policy(cmd),
        IptOp::Append       => lower_rule_add(cmd, false, None),
        IptOp::Insert(n)    => lower_rule_add(cmd, true, Some(*n)),
        IptOp::Replace(n)   => lower_rule_replace(cmd, *n),
        IptOp::DeleteNum(_) => lower_rule_delete_num(cmd),
        IptOp::DeleteMatch  => lower_rule_delete_match(cmd),
        IptOp::Check        => lower_rule_check(cmd),
        IptOp::List         => Ok(LoweredBatch::default()), // handled by save.rs / list output
        IptOp::Save         => Ok(LoweredBatch::default()), // ditto
        IptOp::Zero         => lower_zero(cmd),
    }
}

// ── Table / chain preamble ──────────────────────────────────────────

/// Emit the lines needed to ensure `<family> <table>` exists, plus the
/// base chain `chain` if it is a built-in. User chains are *not*
/// auto-created here — they must have been created by `-N` first, so
/// that `iptables -A USERCHAIN -j ACCEPT` returns the same "No chain"
/// error real iptables would.
fn ensure_table_and_chain(cmd: &IptCmd, batch: &mut LoweredBatch) {
    let fam = cmd.family.nft_family();
    let table = cmd.table.name();
    batch.lines.push(NftLine(format!("add table {} {}", fam, table)));
    if let Some((hook, prio)) = hook_for_chain(cmd.table, &cmd.chain) {
        // Built-in. Default policy is ACCEPT for every iptables table
        // except the one set by `-P` later — we set ACCEPT here as a
        // safe default; later `-P FORWARD DROP` will replace the chain
        // declaration via `add chain` (idempotent in nft).
        batch.lines.push(NftLine(format!(
            "add chain {} {} {} {{ type {} hook {} priority {} ; policy accept ; }}",
            fam, table, lc(&cmd.chain), chain_type_for(cmd.table), hook, prio
        )));
    }
}

fn chain_type_for(table: IptTable) -> &'static str {
    // nft built-in chain types. iptables tables map cleanly:
    // filter → "filter", nat → "nat", mangle → "filter" (priority makes
    // it mangle in the kernel), raw/security → "filter".
    match table {
        IptTable::Nat => "nat",
        _             => "filter",
    }
}

// ── Operations ──────────────────────────────────────────────────────

fn lower_new_chain(cmd: &IptCmd) -> Result<LoweredBatch, LowerError> {
    if cmd.chain.is_empty() { return Err(err("-N requires a chain name")); }
    if is_builtin(cmd.table, &cmd.chain) {
        return Err(err(format!("Chain '{}' already exists (built-in)", cmd.chain)));
    }
    let mut b = LoweredBatch::default();
    let fam = cmd.family.nft_family();
    let table = cmd.table.name();
    b.lines.push(NftLine(format!("add table {} {}", fam, table)));
    b.lines.push(NftLine(format!("add chain {} {} {}", fam, table, lc(&cmd.chain))));
    Ok(b)
}

fn lower_delete_chain(cmd: &IptCmd) -> Result<LoweredBatch, LowerError> {
    let mut b = LoweredBatch::default();
    let fam = cmd.family.nft_family();
    let table = cmd.table.name();
    if cmd.chain.is_empty() {
        // Delete every empty user chain. We can't enumerate from here;
        // the dispatcher pre-flushes user chains so this is left as a
        // no-op text. Real iptables -X with no arg would walk and
        // delete; a follow-up patch could plumb the kernel walk through.
        return Ok(b);
    }
    if is_builtin(cmd.table, &cmd.chain) {
        return Err(err(format!("Cannot delete built-in chain '{}'", cmd.chain)));
    }
    b.lines.push(NftLine(format!("delete chain {} {} {}", fam, table, lc(&cmd.chain))));
    Ok(b)
}

fn lower_flush(cmd: &IptCmd) -> Result<LoweredBatch, LowerError> {
    let mut b = LoweredBatch::default();
    let fam = cmd.family.nft_family();
    let table = cmd.table.name();
    if cmd.chain.is_empty() {
        // Flush whole table.
        b.lines.push(NftLine(format!("flush table {} {}", fam, table)));
    } else {
        b.lines.push(NftLine(format!("flush chain {} {} {}", fam, table, lc(&cmd.chain))));
    }
    Ok(b)
}

fn lower_policy(cmd: &IptCmd) -> Result<LoweredBatch, LowerError> {
    let target = cmd.policy_target.as_deref().unwrap_or("");
    let pol = match target {
        "ACCEPT" => "accept",
        "DROP"   => "drop",
        // iptables additionally accepts QUEUE / RETURN as a chain
        // policy on a built-in; nft does not. We reject those.
        other => return Err(err(format!("invalid policy target '{}'", other))),
    };
    let (hook, prio) = hook_for_chain(cmd.table, &cmd.chain)
        .ok_or_else(|| err(format!("chain '{}' is not a built-in of table '{}'", cmd.chain, cmd.table)))?;
    let mut b = LoweredBatch::default();
    let fam = cmd.family.nft_family();
    let table = cmd.table.name();
    b.lines.push(NftLine(format!("add table {} {}", fam, table)));
    b.lines.push(NftLine(format!(
        "add chain {} {} {} {{ type {} hook {} priority {} ; policy {} ; }}",
        fam, table, lc(&cmd.chain), chain_type_for(cmd.table), hook, prio, pol
    )));
    Ok(b)
}

fn lower_rule_add(cmd: &IptCmd, insert: bool, pos: Option<u32>) -> Result<LoweredBatch, LowerError> {
    if cmd.chain.is_empty() {
        return Err(err("rule operations require a chain"));
    }
    let mut b = LoweredBatch::default();
    ensure_table_and_chain(cmd, &mut b);
    let fam = cmd.family.nft_family();
    let table = cmd.table.name();
    let chain = lc(&cmd.chain);
    let body = build_rule_body(cmd)?;
    let prefix = if insert {
        if let Some(n) = pos {
            if n > 1 {
                format!("insert rule {} {} {} index {}", fam, table, chain, n - 1)
            } else {
                format!("insert rule {} {} {}", fam, table, chain)
            }
        } else {
            format!("insert rule {} {} {}", fam, table, chain)
        }
    } else {
        format!("add rule {} {} {}", fam, table, chain)
    };
    b.lines.push(NftLine(format!("{} {}", prefix, body)));
    Ok(b)
}

fn lower_rule_replace(cmd: &IptCmd, n: u32) -> Result<LoweredBatch, LowerError> {
    let mut b = LoweredBatch::default();
    ensure_table_and_chain(cmd, &mut b);
    let fam = cmd.family.nft_family();
    let table = cmd.table.name();
    let chain = lc(&cmd.chain);
    let body = build_rule_body(cmd)?;
    if n < 1 {
        return Err(err("rule index must be >= 1"));
    }
    // nft's `replace rule ... handle H` operates on a kernel handle,
    // not a 1-based position. The dispatcher resolves position → handle
    // before sending; we put a placeholder and let the runtime fill in.
    b.lines.push(NftLine(format!("__REPLACE_BY_INDEX__ {} {} {} {} {}", fam, table, chain, n, body)));
    Ok(b)
}

fn lower_rule_delete_num(cmd: &IptCmd) -> Result<LoweredBatch, LowerError> {
    let n = match cmd.op { IptOp::DeleteNum(n) => n, _ => unreachable!() };
    let mut b = LoweredBatch::default();
    let fam = cmd.family.nft_family();
    let table = cmd.table.name();
    let chain = lc(&cmd.chain);
    if n < 1 {
        return Err(err("rule index must be >= 1"));
    }
    b.lines.push(NftLine(format!("__DELETE_BY_INDEX__ {} {} {} {}", fam, table, chain, n)));
    Ok(b)
}

fn lower_rule_delete_match(cmd: &IptCmd) -> Result<LoweredBatch, LowerError> {
    let mut b = LoweredBatch::default();
    b.needs_match_resolution = true;
    let fam = cmd.family.nft_family();
    let table = cmd.table.name();
    let chain = lc(&cmd.chain);
    let body = build_rule_body(cmd)?;
    b.lines.push(NftLine(format!("__DELETE_BY_MATCH__ {} {} {} {}", fam, table, chain, body)));
    Ok(b)
}

fn lower_rule_check(cmd: &IptCmd) -> Result<LoweredBatch, LowerError> {
    let mut b = LoweredBatch::default();
    b.needs_match_resolution = true;
    let fam = cmd.family.nft_family();
    let table = cmd.table.name();
    let chain = lc(&cmd.chain);
    let body = build_rule_body(cmd)?;
    b.lines.push(NftLine(format!("__CHECK_BY_MATCH__ {} {} {} {}", fam, table, chain, body)));
    Ok(b)
}

fn lower_zero(cmd: &IptCmd) -> Result<LoweredBatch, LowerError> {
    let mut b = LoweredBatch::default();
    let fam = cmd.family.nft_family();
    let table = cmd.table.name();
    if cmd.chain.is_empty() {
        b.lines.push(NftLine(format!("reset counters table {} {}", fam, table)));
    } else {
        b.lines.push(NftLine(format!("reset counters chain {} {} {}",
            fam, table, lc(&cmd.chain))));
    }
    Ok(b)
}

// ── Rule body construction ──────────────────────────────────────────

/// Build the rule body — everything after `add rule <family> <table>
/// <chain> ` — by walking the rule spec. Order matters because nft
/// matching is order-sensitive: protocol must come before sport/dport
/// so the kernel knows the L4 header layout.
fn build_rule_body(cmd: &IptCmd) -> Result<String, LowerError> {
    let s = &cmd.spec;
    let mut parts: Vec<String> = Vec::new();

    // -i / -o (interface). Lifted to "iifname"/"oifname" in nft.
    // The bare positive form (`iifname "eth0"`) is what nft accepts;
    // the explicit `==` is rejected by some kernels, so we use the
    // bare form when the match isn't negated.
    if let Some(ref iif) = s.iif {
        if s.iif_neg {
            parts.push(format!("iifname != \"{}\"", escape(iif)));
        } else {
            parts.push(format!("iifname \"{}\"", escape(iif)));
        }
    }
    if let Some(ref oif) = s.oif {
        if s.oif_neg {
            parts.push(format!("oifname != \"{}\"", escape(oif)));
        } else {
            parts.push(format!("oifname \"{}\"", escape(oif)));
        }
    }

    // -s / -d. Family-aware: ip vs ip6.
    let ip_kw = if matches!(cmd.family, Family::Ip6) { "ip6" } else { "ip" };
    if let Some(ref a) = s.src {
        let op = if a.neg { "!=" } else { "" };
        if op.is_empty() {
            parts.push(format!("{} saddr {}", ip_kw, a.raw));
        } else {
            parts.push(format!("{} saddr {} {}", ip_kw, op, a.raw));
        }
    }
    if let Some(ref a) = s.dst {
        let op = if a.neg { "!=" } else { "" };
        if op.is_empty() {
            parts.push(format!("{} daddr {}", ip_kw, a.raw));
        } else {
            parts.push(format!("{} daddr {} {}", ip_kw, op, a.raw));
        }
    }

    // -p protocol. nft handles tcp/udp/icmp directly; for numeric proto
    // we use `meta l4proto N`. Positive matches use the bare form
    // (`meta l4proto tcp`); negated ones use `!=`.
    if let Some(ref p) = s.protocol {
        let proto_lc = p.to_ascii_lowercase();
        match proto_lc.as_str() {
            "tcp" | "udp" | "udplite" | "sctp" | "dccp" | "icmp" | "icmpv6" | "esp" | "ah" => {
                // Just protocol; the sport/dport/icmp-type clauses below
                // will reference the same protocol name, and nft's
                // implicit-dependency injection handles the L4 header.
                if s.dport.is_none() && s.sport.is_none() && s.icmp_type.is_none()
                    && s.tcp_flags.is_none() && !s.tcp_syn
                    && s.multiport_dports.is_none() && s.multiport_sports.is_none()
                {
                    if s.protocol_neg {
                        parts.push(format!("meta l4proto != {}", proto_lc));
                    } else {
                        parts.push(format!("meta l4proto {}", proto_lc));
                    }
                }
            }
            "all" => { /* nothing */ }
            other => {
                // Numeric protocol or unrecognised name. Defer to the
                // kernel — it accepts numbers and well-known names.
                if s.protocol_neg {
                    parts.push(format!("meta l4proto != {}", other));
                } else {
                    parts.push(format!("meta l4proto {}", other));
                }
            }
        }
    }

    // -f. nft form: `ip frag-off & 0x1fff != 0`.
    if s.fragment {
        parts.push("ip frag-off & 0x1fff != 0".to_string());
    }

    // sport / dport.
    if let Some(r) = s.sport {
        let proto = s.protocol.as_deref().unwrap_or("tcp");
        let op = if s.sport_neg { "!=" } else { "" };
        parts.push(format_port(proto, "sport", &r, op));
    }
    if let Some(r) = s.dport {
        let proto = s.protocol.as_deref().unwrap_or("tcp");
        let op = if s.dport_neg { "!=" } else { "" };
        parts.push(format_port(proto, "dport", &r, op));
    }
    if let Some(ref mp) = s.multiport_sports {
        let proto = s.protocol.as_deref().unwrap_or("tcp");
        let op = if mp.neg { "!=" } else { "" };
        parts.push(format_multiport(proto, "sport", &mp.items, op));
    }
    if let Some(ref mp) = s.multiport_dports {
        let proto = s.protocol.as_deref().unwrap_or("tcp");
        let op = if mp.neg { "!=" } else { "" };
        parts.push(format_multiport(proto, "dport", &mp.items, op));
    }

    // ICMP type.
    if let Some(ref t) = s.icmp_type {
        let proto = if matches!(cmd.family, Family::Ip6) { "icmpv6" } else { "icmp" };
        let op = if s.icmp_type_neg { "!=" } else { "" };
        if op.is_empty() {
            parts.push(format!("{} type {}", proto, t));
        } else {
            parts.push(format!("{} type {} {}", proto, op, t));
        }
    }

    // TCP flags.
    if let Some((mask, comp)) = &s.tcp_flags {
        // iptables form: --tcp-flags MASK COMP
        // nft form: tcp flags & (mask) == comp
        let mask_set: Vec<String> = mask.split(',').map(|s| s.trim().to_lowercase()).collect();
        let comp_set: Vec<String> = comp.split(',').map(|s| s.trim().to_lowercase()).collect();
        let op = if s.tcp_flags_neg { "!=" } else { "==" };
        if comp_set.first().map(|s| s.as_str()) == Some("none") {
            // `--tcp-flags ANY NONE` → tcp flags & (mask) == 0
            parts.push(format!("tcp flags & ({}) {} 0", mask_set.join("|"), op));
        } else {
            parts.push(format!(
                "tcp flags & ({}) {} {}",
                mask_set.join("|"), op, comp_set.join("|")
            ));
        }
    }
    if s.tcp_syn {
        parts.push("tcp flags & (fin|syn|rst|ack) == syn".to_string());
    }

    // Conntrack state.
    if let Some(ref st) = s.state {
        let names: Vec<String> = st.names.iter().map(|n| n.to_lowercase()).collect();
        let names_str = if names.len() > 1 {
            format!("{{ {} }}", names.join(", "))
        } else {
            names.first().cloned().unwrap_or_default()
        };
        let op = if st.neg { "!=" } else { "" };
        if op.is_empty() {
            parts.push(format!("ct state {}", names_str));
        } else {
            parts.push(format!("ct state {} {}", op, names_str));
        }
    }

    // -m limit.
    if let Some(ref l) = s.limit {
        parts.push(format!("limit rate {}/{} burst {} packets",
            l.rate, normalize_unit(&l.unit), l.burst));
    }

    // Misc match modules.
    for m in &s.modules {
        match m {
            MatchModule::Stateful(_) | MatchModule::Comment(_) => {}
            MatchModule::Addrtype { src, dst } => {
                if let Some(t) = src { parts.push(format!("fib saddr type {}", t.to_lowercase())); }
                if let Some(t) = dst { parts.push(format!("fib daddr type {}", t.to_lowercase())); }
            }
            MatchModule::Mark { value, mask, neg } => {
                let op = if *neg { "!=" } else { "==" };
                if let Some(m) = mask {
                    parts.push(format!("meta mark & {} {} {}",
                        format_hex(*m), op, format_hex(*value)));
                } else {
                    parts.push(format!("meta mark {} {}", op, format_hex(*value)));
                }
            }
            MatchModule::Physdev { iin, oout, is_bridged } => {
                if let Some(n) = iin {
                    parts.push(format!("meta ibrname \"{}\"", escape(n)));
                }
                if let Some(n) = oout {
                    parts.push(format!("meta obrname \"{}\"", escape(n)));
                }
                if *is_bridged {
                    parts.push("meta ibrname != \"\"".to_string());
                }
            }
            MatchModule::Owner { uid, gid } => {
                if let Some(u) = uid {
                    parts.push(format!("meta skuid {}", u));
                }
                if let Some(g) = gid {
                    parts.push(format!("meta skgid {}", g));
                }
            }
            MatchModule::Set { name, dirs, neg } => {
                let qual = match dirs.first().map(|s| s.as_str()) {
                    Some("src") => format!("{} saddr", ip_kw),
                    Some("dst") => format!("{} daddr", ip_kw),
                    _           => format!("{} saddr", ip_kw),
                };
                let op = if *neg { "!=" } else { "" };
                if op.is_empty() {
                    parts.push(format!("{} @{}", qual, name));
                } else {
                    parts.push(format!("{} {} @{}", qual, op, name));
                }
            }
            MatchModule::Mac { source, neg } => {
                let op = if *neg { "!=" } else { "" };
                if op.is_empty() {
                    parts.push(format!("ether saddr {}", source));
                } else {
                    parts.push(format!("ether saddr {} {}", op, source));
                }
            }
            MatchModule::String { .. } => {
                // No clean nft equivalent. Stub out as a comment so
                // the rule still installs but with no string match.
                parts.push("comment \"string-match-stub\"".to_string());
            }
            MatchModule::Unsupported(name) => {
                return Err(err(format!("match module '{}' not supported", name)));
            }
        }
    }

    // Comment, if any. Deferred until after the action so it attaches
    // to the rule rather than to a sub-clause; the actual emit happens
    // below once the target line is in place.

    // Target.
    if let Some(ref t) = s.target {
        parts.push(format_target(cmd, t)?);
    } else if let Some(ref name) = s.goto {
        parts.push(format!("goto {}", lc(name)));
    }

    if let Some(ref c) = s.comment {
        parts.push(format!("comment \"{}\"", escape(c)));
    }

    Ok(parts.join(" "))
}

fn format_port(proto: &str, side: &str, r: &PortRange, op: &str) -> String {
    let proto_lc = proto.to_ascii_lowercase();
    let header_proto = match proto_lc.as_str() {
        "tcp" | "udp" | "udplite" | "sctp" | "dccp" => proto_lc,
        _ => "tcp".to_string(),
    };
    let val = if r.start == r.end {
        r.start.to_string()
    } else {
        format!("{}-{}", r.start, r.end)
    };
    if op.is_empty() {
        format!("{} {} {}", header_proto, side, val)
    } else {
        format!("{} {} {} {}", header_proto, side, op, val)
    }
}

fn format_multiport(proto: &str, side: &str, items: &[PortRange], op: &str) -> String {
    let proto_lc = proto.to_ascii_lowercase();
    let header_proto = match proto_lc.as_str() {
        "tcp" | "udp" | "udplite" | "sctp" | "dccp" => proto_lc,
        _ => "tcp".to_string(),
    };
    let parts: Vec<String> = items.iter().map(|r| {
        if r.start == r.end { r.start.to_string() } else { format!("{}-{}", r.start, r.end) }
    }).collect();
    if op.is_empty() {
        format!("{} {} {{ {} }}", header_proto, side, parts.join(", "))
    } else {
        format!("{} {} {} {{ {} }}", header_proto, side, op, parts.join(", "))
    }
}

fn format_target(cmd: &IptCmd, t: &Target) -> Result<String, LowerError> {
    Ok(match t {
        Target::Accept => "accept".to_string(),
        Target::Drop   => "drop".to_string(),
        Target::Return => "return".to_string(),
        Target::Jump(name) => {
            // iptables target names are uppercase; nft chain names are
            // case-sensitive. We lowercase built-ins (INPUT → input)
            // but pass user chain names through unchanged.
            format!("jump {}", lc(name))
        }
        Target::Reject(kind) => match kind {
            None    => "reject".to_string(),
            Some(k) => format!("reject with {}", reject_kind(k)),
        },
        Target::Log { prefix, level } => {
            let mut s = String::from("log");
            if let Some(p) = prefix { s.push_str(&format!(" prefix \"{}\"", escape(p))); }
            if let Some(l) = level  { s.push_str(&format!(" level {}", log_level_name(*l))); }
            s
        }
        Target::Masquerade { to_ports } => match to_ports {
            None    => "masquerade".to_string(),
            Some(r) => {
                let val = if r.start == r.end { r.start.to_string() } else { format!("{}-{}", r.start, r.end) };
                format!("masquerade to :{}", val)
            }
        },
        Target::Snat { to_source, random, persistent } => {
            let mut s = format!("snat to {}", normalize_nat_addr(to_source));
            if *random     { s.push_str(" random"); }
            if *persistent { s.push_str(" persistent"); }
            s
        }
        Target::Dnat { to_destination, random, persistent } => {
            let mut s = format!("dnat to {}", normalize_nat_addr(to_destination));
            if *random     { s.push_str(" random"); }
            if *persistent { s.push_str(" persistent"); }
            s
        }
        Target::Redirect { to_ports, random } => {
            let mut s = String::from("redirect");
            if let Some(r) = to_ports {
                let val = if r.start == r.end { r.start.to_string() } else { format!("{}-{}", r.start, r.end) };
                s.push_str(&format!(" to :{}", val));
            }
            if *random { s.push_str(" random"); }
            s
        }
        Target::Mark { kind, value, mask } => {
            // nft has `meta mark set ...` — we pick the right RHS for
            // the four iptables mark target variants.
            let _ = mask; // mask is folded into the value expression.
            match kind {
                MarkKind::Set | MarkKind::Xset => format!("meta mark set {}", format_hex(*value)),
                MarkKind::And => format!("meta mark set meta mark and {}", format_hex(*value)),
                MarkKind::Or  => format!("meta mark set meta mark or {}", format_hex(*value)),
                MarkKind::Xor => format!("meta mark set meta mark xor {}", format_hex(*value)),
            }
        }
        Target::Connmark(op) => match op {
            ConnmarkOp::SetMark { value, .. } => format!("ct mark set {}", format_hex(*value)),
            ConnmarkOp::SaveMark { .. }       => "ct mark set meta mark".to_string(),
            ConnmarkOp::RestoreMark { .. }    => "meta mark set ct mark".to_string(),
            ConnmarkOp::And(v) => format!("ct mark set ct mark and {}", format_hex(*v)),
            ConnmarkOp::Or(v)  => format!("ct mark set ct mark or {}",  format_hex(*v)),
            ConnmarkOp::Xor(v) => format!("ct mark set ct mark xor {}", format_hex(*v)),
        }
        Target::Tproxy { on_port, on_ip, mark } => {
            let _ = mark; // marks are typically applied via -j MARK after TPROXY.
            let mut s = String::from("tproxy");
            let fam = match cmd.family { Family::Ip => "ip", Family::Ip6 => "ip6" };
            s.push_str(&format!(" {} to", fam));
            match (on_ip, on_port) {
                (Some(ip), Some(p)) => s.push_str(&format!(" {}:{}", ip, p)),
                (Some(ip), None)    => s.push_str(&format!(" {}",     ip)),
                (None,     Some(p)) => s.push_str(&format!(" :{}",    p)),
                (None,     None)    => {}
            }
            s
        }
        Target::Nflog { prefix, group } => {
            let mut s = String::from("log");
            if let Some(p) = prefix { s.push_str(&format!(" prefix \"{}\"", escape(p))); }
            if let Some(g) = group  { s.push_str(&format!(" group {}", g)); }
            s
        }
        Target::Trace => "meta nftrace set 1".to_string(),
    })
}

fn reject_kind(k: &str) -> &str {
    match k {
        "icmp-net-unreachable" | "net-unreachable"     => "icmp type net-unreachable",
        "icmp-host-unreachable" | "host-unreachable"   => "icmp type host-unreachable",
        "icmp-port-unreachable" | "port-unreachable"   => "icmp type port-unreachable",
        "icmp-proto-unreachable" | "proto-unreachable" => "icmp type prot-unreachable",
        "icmp-net-prohibited"  | "net-prohibited"      => "icmp type net-prohibited",
        "icmp-host-prohibited" | "host-prohibited"     => "icmp type host-prohibited",
        "icmp-admin-prohibited"| "admin-prohibited"    => "icmp type admin-prohibited",
        "tcp-reset" | "tcp-rst"                        => "tcp reset",
        // ICMPv6 names, used by ip6tables-extensions.
        "icmp6-no-route" | "no-route"                  => "icmpv6 type no-route",
        "icmp6-adm-prohibited" | "adm-prohibited"      => "icmpv6 type admin-prohibited",
        "icmp6-addr-unreachable"| "addr-unreach"       => "icmpv6 type addr-unreachable",
        "icmp6-port-unreachable"                       => "icmpv6 type port-unreachable",
        other => other,
    }
}

fn log_level_name(n: u8) -> &'static str {
    // Mirrors /usr/include/sys/syslog.h numeric levels.
    match n {
        0 => "emerg",
        1 => "alert",
        2 => "crit",
        3 => "err",
        4 => "warn",
        5 => "notice",
        6 => "info",
        7 => "debug",
        _ => "info",
    }
}

fn normalize_unit(u: &str) -> &str {
    match u {
        "s" | "sec" | "second" | "seconds" => "second",
        "m" | "min" | "minute" | "minutes" => "minute",
        "h" | "hr"  | "hour"   | "hours"   => "hour",
        "d" | "day" | "days"               => "day",
        _ => "second",
    }
}

fn normalize_nat_addr(s: &str) -> String {
    // iptables expresses combined addr+port as `addr[-addr][:port[-port]]`.
    // nft accepts the same syntax for `dnat to`. Pass through.
    s.to_string()
}

fn format_hex(v: u32) -> String {
    if v == 0 { "0".to_string() } else { format!("0x{:x}", v) }
}

fn lc(s: &str) -> String {
    // Built-in chains are uppercase in iptables (INPUT) but lowercase
    // in nft (input). User chain names pass through unchanged because
    // they're case-sensitive identifiers.
    match s {
        "INPUT" | "OUTPUT" | "FORWARD" | "PREROUTING" | "POSTROUTING" => s.to_lowercase(),
        _ => s.to_string(),
    }
}

fn escape(s: &str) -> String {
    s.replace('\\', "\\\\").replace('"', "\\\"")
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::iptables::parser::parse;

    fn lower_str(family: Family, args: &[&str]) -> Vec<String> {
        let argv: Vec<String> = args.iter().map(|s| s.to_string()).collect();
        let cmd = parse(family, &argv).unwrap().cmd;
        let b = lower(&cmd).unwrap();
        b.lines.into_iter().map(|l| l.0).collect()
    }

    #[test]
    fn basic_append_lowers_to_nft_accept() {
        let lines = lower_str(Family::Ip, &["-A", "FORWARD", "-j", "ACCEPT"]);
        // expect: add table, add chain, add rule
        assert_eq!(lines.len(), 3);
        assert!(lines[0].starts_with("add table ip filter"));
        assert!(lines[1].starts_with("add chain ip filter forward"));
        assert_eq!(lines[2], "add rule ip filter forward accept");
    }

    #[test]
    fn tcp_dport_lowers() {
        let lines = lower_str(Family::Ip, &[
            "-A", "FORWARD", "-p", "tcp", "--dport", "22", "-j", "ACCEPT"
        ]);
        let rule = lines.last().unwrap();
        assert!(rule.contains("tcp dport 22"), "rule was: {}", rule);
        assert!(rule.contains("accept"));
    }

    #[test]
    fn nat_masquerade_lowers() {
        let lines = lower_str(Family::Ip, &[
            "-t", "nat", "-A", "POSTROUTING",
            "-s", "172.17.0.0/16", "!", "-o", "docker0",
            "-j", "MASQUERADE"
        ]);
        let rule = lines.last().unwrap();
        assert!(rule.contains("ip saddr 172.17.0.0/16"), "rule: {}", rule);
        assert!(rule.contains("oifname != \"docker0\""), "rule: {}", rule);
        assert!(rule.contains("masquerade"), "rule: {}", rule);
    }

    #[test]
    fn dnat_with_to_destination_lowers() {
        let lines = lower_str(Family::Ip, &[
            "-t", "nat", "-A", "PREROUTING", "-p", "tcp", "--dport", "8080",
            "-j", "DNAT", "--to-destination", "172.17.0.2:80"
        ]);
        let rule = lines.last().unwrap();
        assert!(rule.contains("dnat to 172.17.0.2:80"), "rule: {}", rule);
    }

    #[test]
    fn ct_state_lowers() {
        let lines = lower_str(Family::Ip, &[
            "-A", "FORWARD", "-m", "conntrack", "--ctstate", "RELATED,ESTABLISHED",
            "-j", "ACCEPT"
        ]);
        let rule = lines.last().unwrap();
        assert!(rule.contains("ct state { related, established }"), "rule: {}", rule);
    }

    #[test]
    fn ip6_family_uses_ip6_keyword() {
        let lines = lower_str(Family::Ip6, &["-A", "FORWARD", "-s", "fe80::1", "-j", "DROP"]);
        let rule = lines.last().unwrap();
        assert!(rule.contains("ip6 saddr fe80::1"), "rule: {}", rule);
        assert!(rule.contains("drop"));
    }

    #[test]
    fn user_chain_create() {
        let lines = lower_str(Family::Ip, &["-N", "DOCKER"]);
        assert_eq!(lines.len(), 2);
        assert_eq!(lines[1], "add chain ip filter DOCKER");
    }

    #[test]
    fn jump_to_user_chain() {
        let lines = lower_str(Family::Ip, &["-A", "FORWARD", "-j", "DOCKER"]);
        let rule = lines.last().unwrap();
        assert!(rule.contains("jump DOCKER"), "rule: {}", rule);
    }

    #[test]
    fn policy_set_chain() {
        let lines = lower_str(Family::Ip, &["-P", "FORWARD", "DROP"]);
        let chain_decl = &lines[1];
        assert!(chain_decl.contains("policy drop"), "chain: {}", chain_decl);
    }

    #[test]
    fn multiport_dports_lowers() {
        let lines = lower_str(Family::Ip, &[
            "-A", "INPUT", "-p", "tcp", "-m", "multiport", "--dports", "22,80,443",
            "-j", "ACCEPT"
        ]);
        let rule = lines.last().unwrap();
        assert!(rule.contains("tcp dport { 22, 80, 443 }"), "rule: {}", rule);
    }

    #[test]
    fn reject_with_icmp_host_unreachable() {
        let lines = lower_str(Family::Ip, &[
            "-A", "INPUT", "-j", "REJECT", "--reject-with", "icmp-host-unreachable"
        ]);
        let rule = lines.last().unwrap();
        assert!(rule.contains("reject with icmp type host-unreachable"), "rule: {}", rule);
    }

    #[test]
    fn comment_attached() {
        let lines = lower_str(Family::Ip, &[
            "-A", "INPUT", "-m", "comment", "--comment", "test rule", "-j", "ACCEPT"
        ]);
        let rule = lines.last().unwrap();
        assert!(rule.contains("comment \"test rule\""), "rule: {}", rule);
    }

    #[test]
    fn flush_chain() {
        let lines = lower_str(Family::Ip, &["-F", "FORWARD"]);
        assert_eq!(lines, vec!["flush chain ip filter forward".to_string()]);
    }

    #[test]
    fn flush_table() {
        let lines = lower_str(Family::Ip, &["-F"]);
        assert_eq!(lines, vec!["flush table ip filter".to_string()]);
    }
}
