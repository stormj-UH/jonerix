// (c) 2026 Jon-Erik G. Storm, Inc., a California Corporation,
// doing business as LAVA GOAT SOFTWARE.  MIT license.
//
// Integration tests for the iptables shim.
//
// These exercise the parser → lowerer → nft-text path end-to-end,
// asserting on the textual nft commands the lowerer emits. No kernel
// or netlink socket is touched, so they run on any host with a Rust
// toolchain — no #[ignore], no #[cfg(target_os = "linux")] gate.
//
// A separate set of "kernel-real" integration tests lives in the
// `tests/iptables-shim.sh` shell harness; those are gated on Linux +
// CAP_NET_ADMIN and only run from the package CI runner.

use super::cmd::*;
use super::lower::lower;
use super::parser::parse;
use super::save::{parse_restore_stream, render_rule_save};

fn lower_argv(family: Family, args: &[&str]) -> Vec<String> {
    let argv: Vec<String> = args.iter().map(|s| s.to_string()).collect();
    let cmd = parse(family, &argv).unwrap().cmd;
    lower(&cmd).unwrap().lines.into_iter().map(|l| l.0).collect()
}

fn last_rule(family: Family, args: &[&str]) -> String {
    lower_argv(family, args).into_iter().last().unwrap()
}

// ── 1. iptables_basic_append ─────────────────────────────────────────

#[test]
fn iptables_basic_append() {
    // iptables -A FORWARD -j ACCEPT
    //   → add rule ip filter forward accept
    let lines = lower_argv(Family::Ip, &["-A", "FORWARD", "-j", "ACCEPT"]);
    assert!(lines.iter().any(|l| l == "add rule ip filter forward accept"),
        "lines: {:?}", lines);
    // Plus the implicit table+chain preamble.
    assert!(lines.iter().any(|l| l.starts_with("add table ip filter")));
    assert!(lines.iter().any(|l| l.contains("hook forward") && l.contains("policy accept")));
}

// ── 2. iptables_with_match ───────────────────────────────────────────

#[test]
fn iptables_with_match() {
    // iptables -A FORWARD -p tcp --dport 22 -j ACCEPT
    //   → add rule ip filter forward tcp dport 22 accept
    let rule = last_rule(Family::Ip, &[
        "-A", "FORWARD", "-p", "tcp", "--dport", "22", "-j", "ACCEPT",
    ]);
    assert!(rule.contains("tcp dport 22"), "rule: {}", rule);
    assert!(rule.ends_with("accept"), "rule: {}", rule);
}

// ── 3. iptables_nat_masquerade — Docker first-start sequence ─────────

#[test]
fn iptables_nat_masquerade() {
    // iptables -t nat -N DOCKER
    let r = lower_argv(Family::Ip, &["-t", "nat", "-N", "DOCKER"]);
    assert!(r.iter().any(|l| l == "add chain ip nat DOCKER"), "{:?}", r);

    // iptables -t nat -A POSTROUTING -s 172.17.0.0/16 ! -o docker0 -j MASQUERADE
    let rule = last_rule(Family::Ip, &[
        "-t", "nat", "-A", "POSTROUTING",
        "-s", "172.17.0.0/16", "!", "-o", "docker0",
        "-j", "MASQUERADE",
    ]);
    assert!(rule.contains("ip saddr 172.17.0.0/16"), "rule: {}", rule);
    assert!(rule.contains("oifname != \"docker0\""), "rule: {}", rule);
    assert!(rule.contains("masquerade"), "rule: {}", rule);

    // iptables -t nat -A PREROUTING -m addrtype --dst-type LOCAL -j DOCKER
    let rule = last_rule(Family::Ip, &[
        "-t", "nat", "-A", "PREROUTING",
        "-m", "addrtype", "--dst-type", "LOCAL",
        "-j", "DOCKER",
    ]);
    assert!(rule.contains("fib daddr type local"), "rule: {}", rule);
    assert!(rule.contains("jump DOCKER"), "rule: {}", rule);
}

// ── 4. iptables_dnat_port_publish — Docker -p 8080:80 case ───────────

#[test]
fn iptables_dnat_port_publish() {
    // iptables -t nat -A DOCKER ! -i docker0 -p tcp --dport 8080
    //          -j DNAT --to-destination 172.17.0.2:80
    //
    // Note: this uses a USER chain (DOCKER), so we first need to
    // -N DOCKER to declare it. The lowerer doesn't auto-create user
    // chains; that's by design — real iptables errors if the chain
    // doesn't exist. We verify both pieces below.
    let create_lines = lower_argv(Family::Ip, &["-t", "nat", "-N", "DOCKER"]);
    assert!(create_lines.iter().any(|l| l == "add chain ip nat DOCKER"));

    // Now the rule itself.
    let rule = last_rule(Family::Ip, &[
        "-t", "nat", "-A", "DOCKER",
        "!", "-i", "docker0",
        "-p", "tcp", "--dport", "8080",
        "-j", "DNAT", "--to-destination", "172.17.0.2:80",
    ]);
    assert!(rule.contains("iifname != \"docker0\""), "rule: {}", rule);
    assert!(rule.contains("tcp dport 8080"), "rule: {}", rule);
    assert!(rule.contains("dnat to 172.17.0.2:80"), "rule: {}", rule);
}

// ── 5. iptables_save_round_trip ──────────────────────────────────────

#[test]
fn iptables_save_round_trip() {
    // Build a small ruleset, dump via iptables-save format, parse
    // back, verify every rule survives the round-trip semantically.
    let inputs: &[&[&str]] = &[
        &["-A", "INPUT", "-p", "tcp", "--dport", "22", "-j", "ACCEPT"],
        &["-A", "FORWARD", "-m", "conntrack", "--ctstate", "RELATED,ESTABLISHED", "-j", "ACCEPT"],
        &["-t", "nat", "-A", "POSTROUTING", "-s", "172.17.0.0/16", "-j", "MASQUERADE"],
    ];
    let mut save_text = String::from("# Generated by stormwall iptables-save\n");
    let mut tables: std::collections::BTreeMap<&str, Vec<&'static [&'static str]>> =
        std::collections::BTreeMap::new();
    for spec in inputs {
        let table = if spec.iter().any(|t| *t == "-t") {
            spec[spec.iter().position(|t| *t == "-t").unwrap() + 1]
        } else { "filter" };
        tables.entry(table).or_default().push(*spec);
    }
    for (table, specs) in &tables {
        save_text.push_str(&format!("*{}\n", table));
        save_text.push_str(":INPUT ACCEPT [0:0]\n");
        save_text.push_str(":FORWARD ACCEPT [0:0]\n");
        save_text.push_str(":OUTPUT ACCEPT [0:0]\n");
        if *table == "nat" {
            save_text.push_str(":PREROUTING ACCEPT [0:0]\n");
            save_text.push_str(":POSTROUTING ACCEPT [0:0]\n");
        }
        for spec in specs {
            // Build a one-shot IptCmd to render in save format.
            let mut argv: Vec<String> = spec.iter().map(|s| s.to_string()).collect();
            // Drop the "-t TABLE" prefix because render_rule_save
            // doesn't include it (the *table line above scopes it).
            if argv.first().map(|s| s.as_str()) == Some("-t") {
                argv.drain(0..2);
            }
            let cmd = parse(Family::Ip, &argv).unwrap().cmd;
            save_text.push_str(&render_rule_save(&cmd));
            save_text.push('\n');
        }
        save_text.push_str("COMMIT\n");
    }

    // Round-trip: parse the save text and compare rule count / chain set.
    let stream = parse_restore_stream(Family::Ip, &save_text).unwrap();
    let total_rules: usize = stream.tables.iter().map(|t| t.rules.len()).sum();
    assert_eq!(total_rules, inputs.len(),
        "round-trip lost rules: {}", save_text);

    // Each parsed rule should re-lower cleanly.
    for t in &stream.tables {
        for r in &t.rules {
            let _ = lower(&r.cmd).expect("re-lower failed");
        }
    }
}

// ── 6. iptables_user_chain_lifecycle ─────────────────────────────────

#[test]
fn iptables_user_chain_lifecycle() {
    // -N DOCKER creates the user chain.
    let r = lower_argv(Family::Ip, &["-N", "DOCKER"]);
    assert!(r.iter().any(|l| l == "add chain ip filter DOCKER"));

    // -A DOCKER -j RETURN appends a rule to it.
    let rule = last_rule(Family::Ip, &["-A", "DOCKER", "-j", "RETURN"]);
    assert!(rule.contains("return"), "rule: {}", rule);

    // -X DOCKER deletes the user chain.
    let r = lower_argv(Family::Ip, &["-X", "DOCKER"]);
    assert!(r.iter().any(|l| l == "delete chain ip filter DOCKER"), "{:?}", r);
}

// ── 7. iptables_check ────────────────────────────────────────────────

#[test]
fn iptables_check_lowering_emits_check_token() {
    // -C is special: the lowerer emits a __CHECK_BY_MATCH__ marker
    // that the dispatcher turns into a GETRULE walk + match. We
    // assert here only that the lowering reaches the right marker.
    let argv: Vec<String> = ["-C", "FORWARD", "-p", "tcp", "--dport", "22", "-j", "ACCEPT"]
        .iter().map(|s| s.to_string()).collect();
    let cmd = parse(Family::Ip, &argv).unwrap().cmd;
    assert!(matches!(cmd.op, IptOp::Check));
    let lines = lower(&cmd).unwrap().lines;
    assert!(lines.iter().any(|l| l.0.starts_with("__CHECK_BY_MATCH__ ")), "{:?}", lines);
}

// ── 8. ip6tables_smoke ───────────────────────────────────────────────

#[test]
fn ip6tables_smoke() {
    // ip6tables -A FORWARD -j ACCEPT
    //   → add rule ip6 filter forward accept
    let lines = lower_argv(Family::Ip6, &["-A", "FORWARD", "-j", "ACCEPT"]);
    assert!(lines.iter().any(|l| l == "add rule ip6 filter forward accept"),
        "lines: {:?}", lines);
    // Family-aware: source address keyword must be ip6.
    let rule = last_rule(Family::Ip6, &[
        "-A", "FORWARD", "-s", "fe80::1", "-j", "DROP",
    ]);
    assert!(rule.contains("ip6 saddr fe80::1"), "rule: {}", rule);
}

// ── 9. iptables_restore_atomic ───────────────────────────────────────

#[test]
fn iptables_restore_atomic_rejects_bad_syntax() {
    // A mid-stream syntax error should fail the entire parse so
    // nothing downstream gets applied. The dispatcher's apply path
    // calls parse_restore_stream first; if it errors, no nft batch
    // is sent. We verify the parser refuses the broken stream.
    let txt = "*filter
:INPUT ACCEPT [0:0]
-A INPUT -p tcp --dport 22 -j ACCEPT
-A INPUT --frobnicate-the-flux 12 -j ACCEPT
COMMIT
";
    let r = parse_restore_stream(Family::Ip, txt);
    assert!(r.is_err(), "expected parse failure, got {:?}", r);
}

#[test]
fn iptables_restore_accepts_clean_stream() {
    let txt = "*filter
:INPUT ACCEPT [0:0]
:FORWARD DROP [0:0]
:OUTPUT ACCEPT [0:0]
-A INPUT -p tcp --dport 22 -j ACCEPT
-A FORWARD -m conntrack --ctstate RELATED,ESTABLISHED -j ACCEPT
COMMIT
*nat
:POSTROUTING ACCEPT [0:0]
-A POSTROUTING -s 172.17.0.0/16 -j MASQUERADE
COMMIT
";
    let s = parse_restore_stream(Family::Ip, txt).expect("parse ok");
    assert_eq!(s.tables.len(), 2);
    let f = &s.tables[0];
    assert_eq!(f.table, IptTable::Filter);
    assert_eq!(f.chains.len(), 3);
    assert_eq!(f.rules.len(), 2);
    let n = &s.tables[1];
    assert_eq!(n.table, IptTable::Nat);
    assert_eq!(n.rules.len(), 1);
}

// ── 10. iptables_drop_and_reject ─────────────────────────────────────

#[test]
fn iptables_drop_target() {
    let rule = last_rule(Family::Ip, &["-A", "INPUT", "-j", "DROP"]);
    assert!(rule.ends_with("drop"), "rule: {}", rule);
}

#[test]
fn iptables_reject_with_icmp_host_unreachable() {
    let rule = last_rule(Family::Ip, &[
        "-A", "INPUT", "-j", "REJECT", "--reject-with", "icmp-host-unreachable",
    ]);
    assert!(rule.contains("reject with icmp type host-unreachable"),
        "rule: {}", rule);
}

// ── Docker first-start corpus ────────────────────────────────────────
//
// These mirror the calls libnetwork makes when dockerd boots (taken
// from `iptables -S` after a clean dockerd start, on a 6.x kernel).
// Every line below is something Docker actually issues; if all pass,
// Docker's bridge networking should "just work" through the shim.

#[test]
fn docker_first_start_filter_chains() {
    // -N DOCKER
    // -N DOCKER-USER
    // -N DOCKER-ISOLATION-STAGE-1
    // -A FORWARD -j DOCKER-USER
    // -A FORWARD -j DOCKER-ISOLATION-STAGE-1
    // -A FORWARD -m conntrack --ctstate RELATED,ESTABLISHED -j ACCEPT
    let cases: &[(&[&str], &str)] = &[
        (&["-N", "DOCKER"], "add chain ip filter DOCKER"),
        (&["-N", "DOCKER-USER"], "add chain ip filter DOCKER-USER"),
        (&["-N", "DOCKER-ISOLATION-STAGE-1"], "add chain ip filter DOCKER-ISOLATION-STAGE-1"),
    ];
    for (argv, expected) in cases {
        let lines = lower_argv(Family::Ip, argv);
        assert!(lines.iter().any(|l| l == expected), "{:?} → {:?}", argv, lines);
    }

    let rule = last_rule(Family::Ip, &["-A", "FORWARD", "-j", "DOCKER-USER"]);
    assert!(rule.contains("jump DOCKER-USER"), "rule: {}", rule);

    let rule = last_rule(Family::Ip, &[
        "-A", "FORWARD", "-m", "conntrack",
        "--ctstate", "RELATED,ESTABLISHED", "-j", "ACCEPT",
    ]);
    assert!(rule.contains("ct state { related, established }"), "rule: {}", rule);
    assert!(rule.contains("accept"));
}

#[test]
fn docker_first_start_nat_chains() {
    // -t nat -N DOCKER
    // -t nat -A PREROUTING -m addrtype --dst-type LOCAL -j DOCKER
    // -t nat -A OUTPUT ! -d 127.0.0.0/8 -m addrtype --dst-type LOCAL -j DOCKER
    // -t nat -A POSTROUTING -s 172.17.0.0/16 ! -o docker0 -j MASQUERADE
    let r = lower_argv(Family::Ip, &["-t", "nat", "-N", "DOCKER"]);
    assert!(r.iter().any(|l| l == "add chain ip nat DOCKER"));

    let rule = last_rule(Family::Ip, &[
        "-t", "nat", "-A", "PREROUTING",
        "-m", "addrtype", "--dst-type", "LOCAL", "-j", "DOCKER",
    ]);
    assert!(rule.contains("fib daddr type local"), "rule: {}", rule);
    assert!(rule.contains("jump DOCKER"));

    let rule = last_rule(Family::Ip, &[
        "-t", "nat", "-A", "OUTPUT",
        "!", "-d", "127.0.0.0/8",
        "-m", "addrtype", "--dst-type", "LOCAL", "-j", "DOCKER",
    ]);
    assert!(rule.contains("ip daddr != 127.0.0.0/8"), "rule: {}", rule);
    assert!(rule.contains("fib daddr type local"));
    assert!(rule.contains("jump DOCKER"));

    let rule = last_rule(Family::Ip, &[
        "-t", "nat", "-A", "POSTROUTING",
        "-s", "172.17.0.0/16", "!", "-o", "docker0", "-j", "MASQUERADE",
    ]);
    assert!(rule.contains("ip saddr 172.17.0.0/16"));
    assert!(rule.contains("oifname != \"docker0\""));
    assert!(rule.contains("masquerade"));
}

#[test]
fn docker_port_publish_pair() {
    // The two rules dockerd writes when you `docker run -p 8080:80`:
    //   1. -t nat -A DOCKER ! -i docker0 -p tcp --dport 8080 -j DNAT --to-destination 172.17.0.2:80
    //   2. -A DOCKER -d 172.17.0.2/32 ! -i docker0 -o docker0 -p tcp --dport 80 -j ACCEPT

    // Need to predeclare DOCKER chains in both tables for the rules
    // to make sense, but the lowerer just emits text — it doesn't
    // verify chain existence. So we only assert the rule shape.
    let rule = last_rule(Family::Ip, &[
        "-t", "nat", "-A", "DOCKER",
        "!", "-i", "docker0",
        "-p", "tcp", "--dport", "8080",
        "-j", "DNAT", "--to-destination", "172.17.0.2:80",
    ]);
    assert!(rule.contains("iifname != \"docker0\""), "{}", rule);
    assert!(rule.contains("tcp dport 8080"), "{}", rule);
    assert!(rule.contains("dnat to 172.17.0.2:80"), "{}", rule);

    let rule = last_rule(Family::Ip, &[
        "-A", "DOCKER",
        "-d", "172.17.0.2/32",
        "!", "-i", "docker0",
        "-o", "docker0",
        "-p", "tcp", "--dport", "80",
        "-j", "ACCEPT",
    ]);
    assert!(rule.contains("ip daddr 172.17.0.2/32"), "{}", rule);
    assert!(rule.contains("iifname != \"docker0\""), "{}", rule);
    assert!(rule.contains("oifname \"docker0\""), "{}", rule);
    assert!(rule.contains("tcp dport 80"), "{}", rule);
    assert!(rule.contains("accept"), "{}", rule);
}

// ── Save renderer fidelity ───────────────────────────────────────────

#[test]
fn save_render_negation_preserved() {
    let argv: Vec<String> = ["-A", "FORWARD", "!", "-i", "eth0", "-j", "DROP"]
        .iter().map(|s| s.to_string()).collect();
    let cmd = parse(Family::Ip, &argv).unwrap().cmd;
    let s = render_rule_save(&cmd);
    assert!(s.contains("! -i eth0"), "{}", s);
    assert!(s.contains("-j DROP"));
}

#[test]
fn save_render_dnat_to_destination() {
    let argv: Vec<String> = [
        "-t", "nat", "-A", "PREROUTING",
        "-p", "tcp", "--dport", "80",
        "-j", "DNAT", "--to-destination", "1.2.3.4:8080",
    ].iter().map(|s| s.to_string()).collect();
    // strip the -t and table prefix for save (table scope is from *nat).
    let cmd = parse(Family::Ip, &argv).unwrap().cmd;
    let s = render_rule_save(&cmd);
    assert!(s.contains("-A PREROUTING"), "{}", s);
    assert!(s.contains("-p tcp"));
    assert!(s.contains("--dport 80"));
    assert!(s.contains("--to-destination 1.2.3.4:8080"));
}
