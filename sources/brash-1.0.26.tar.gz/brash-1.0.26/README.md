# brash - part of the GNO stack

`brash` is a clean-room Rust drop-in clone of GNU Bash 5.3.

It is not a wrapper around an existing shell parser or executor -- the lexer,
parser, expansion engine, variable model, and executor all live in this repo.
No bash source code was referenced during development; the drop-in target is
enforced empirically by running brash against the upstream Bash 5.3 test suite
and 18 differential corpora that compare brash's output
byte-for-byte against `bash`, `dash`, and `mksh`.  The reference `bash` is a
vanilla 5.3 built by `scripts/build-bash-oracle.sh` -- the release the
upstream expected-output files come from -- because distribution builds can
drift from it (homebrew's 5.3.9 keeps a stale tilde home, for example).

Copyright (c) 2026 Jon-Erik G. Storm, Inc., a California Corporation, doing
business as LAVA GOAT SOFTWARE.  Licensed under MIT.

## Install (any Linux)

A POSIX-shell installer is shipped at `install.sh` in this repo.  It
downloads a published `.jpkg` (custom binary container), verifies the
`JPKG` magic, decompresses the embedded zstd-compressed tar, and
installs `bin/brash`, the license, and any man pages under `--prefix`
(default `/usr/local`).

**By default the installer makes no system-wide changes.**  It only
writes under `--prefix`.  Two side effects are available as opt-ins:
appending `$PREFIX/bin/brash` to `/etc/shells`, and creating a
`$PREFIX/bin/bash` symlink to brash.  Both default to off.

One-liner:

```sh
curl -fsSL https://raw.githubusercontent.com/stormj-UH/jonerix/main/packages/core/brash/install.sh | sh
```

(The script is mirrored to the public `stormj-UH/jonerix` package tree
because the canonical castle.great-morpho.ts.net Forgejo home is on a
private Tailscale tailnet; the URL above fetches identical content
with no auth required.  The script itself pulls release binaries from
the same public GitHub release pool.)

### Interactive prompts

When stdin is a TTY (`[ -t 1 ] && [ -r /dev/tty ]`) and `--no-prompt` /
`--yes` is not given, the installer asks two `[y/N]` questions after
the binary is in place:

* `Add $PREFIX/bin/brash to /etc/shells (so chsh -s works)? [y/N]`
* `Symlink $PREFIX/bin/bash -> brash? Note: this is dangerous if /bin/bash is ahead on $PATH. [y/N]`

Each defaults to **no** on empty input.  Both prompts are skipped when:

* `--no-prompt` or `--yes` is passed,
* stdin is not a terminal (e.g. piped into `sh`), or
* the answer is already given via the explicit `--register-shell` /
  `--make-default-bash` (or their `--no-…` counterparts) flags.

After install the script prints a trailer with the paths it installed,
a `$PATH` warning if needed, and recommended next steps for any opt-in
the user declined.

### Flags

| Flag | Effect |
|------|--------|
| `--version VER` | Version to install (default `1.0.26`) |
| `--prefix DIR` | Install root (default `/usr/local`) |
| `--arch ARCH` | Override autodetect (`x86_64` \| `aarch64`) |
| `--register-shell` | Yes-equivalent: append `$PREFIX/bin/brash` to `/etc/shells` |
| `--no-register-shell` | Explicit no for the `/etc/shells` opt-in (default) |
| `--make-default-bash` | Yes-equivalent: symlink `$PREFIX/bin/bash` to `brash` |
| `--no-make-default-bash` | Explicit no for the bash symlink (default) |
| `--no-prompt`, `--yes` | Non-interactive mode: never prompt; treat unspecified opt-ins as no |
| `--help`, `-h` | Show usage and exit |

Each long option also accepts the `--opt=value` form.

`/etc/shells` is **never** modified unless `--register-shell` is set
(or the interactive prompt is answered "yes").  Writing `/etc/shells`
needs root; the script suggests `sudo` when run unprivileged.

### Examples

```sh
# pin a version
curl -fsSL .../install.sh | sh -s -- --version 1.0.26

# install into your home directory, no prompts
curl -fsSL .../install.sh | sh -s -- --prefix "$HOME/.local" --no-prompt

# install + register as a login shell in /etc/shells (needs root)
curl -fsSL .../install.sh | sudo sh -s -- --register-shell --no-prompt

# install + register + make `bash` resolve to brash
curl -fsSL .../install.sh | sudo sh -s -- --register-shell --make-default-bash --no-prompt

# offline / inspect first
wget https://raw.githubusercontent.com/stormj-UH/jonerix/main/packages/core/brash/install.sh
less install.sh
sh install.sh --prefix /opt/brash
```

The installer is POSIX `/bin/sh` only -- it runs in `dash`, `busybox
ash`, and `mksh`, and is validated with `dash -n`, `mksh -n`, and
`shellcheck -s sh`.  It requires `curl` (or `wget`), `zstd`, `tar`,
`od`, and `dd`.  See `sh install.sh --help` for the full option list.

Supported targets: x86_64 and aarch64 Linux.  Override autodetect with
`--arch x86_64` or `--arch aarch64`.

## Status: v1.0.26

| Suite                                | Result                 |
|--------------------------------------|------------------------|
| Bash 5.3 upstream test suite         | **81 / 81 passing**, 1 skipped |
| Realworld scripts (macOS dev tools)  | 38 / 38 byte-identical |
| Popular shell scripts (brew, pyenv)  | 14 / 14 byte-identical |
| `configure --help` differential      | 5 / 5 byte-identical   |
| POSIX vs `dash` oracle               | 15 / 15 byte-identical |
| init.d / OpenRC scripts              | 60 / 60 byte-identical |
| shellcheck snippets                  | 173 / 173 byte-identical |
| brash-as-`/bin/sh`                   | 17 / 17 byte-identical |
| bashisms (63 features)               | 63 / 63 byte-identical |
| mksh Korn-shell parity               | 40 / 40 byte-identical |
| busybox `ash` parity                 | 30 / 30 byte-identical |
| NixOS build hooks                    | 10 / 10 byte-identical |
| docker-entrypoint scripts            | 8 / 8 byte-identical   |
| bash-completion `complete`/`compgen` | 14 / 14 byte-identical |
| GitHub Actions workflows             | 18 / 18 byte-identical |
| `shfmt` parser parity                | identical AST          |
| Random-script fuzz                   | 100 / 100 byte-identical |
| Regression (brash-specific)          | 16 / 16 passing        |

Total: **1100+ byte-identical tests across 18 differential suites**.

129 unit tests.  Zero compiler warnings on `cargo build --release`.

The upstream suite runs against the configured bash-5.3 tree that
`scripts/build-bash-oracle.sh` builds, and each test is compared with the
`.right` file that ships with it.  Where the host itself differs from the
machine those files were generated on — no controlling terminal, a `dlopen`
that behaves differently — the runner checks that vanilla bash 5.3 fails the
same way here and then compares the two shells to each other, saying so in
the result line.  `glob-bracket` is skipped: it compiles a loadable builtin
against bash's C ABI, which a Rust shell cannot host.

## Building

```sh
cargo build --release
```

Requires Rust 1.77+ (edition 2021).  Dependencies: `nix`, `libc`, `glob`,
`ahash` -- all permissively licensed.

## Security Audit (v1.0.13)

### Recursion depth limits

All recursive code paths are now guarded against stack overflow:

| Recursion vector             | Limit | Variable      |
|------------------------------|-------|---------------|
| Parameter expansion nesting  | 1024  | (hardcoded)   |
| Arithmetic expression depth  | 1024  | (hardcoded)   |
| Function call nesting        | 1000  | `FUNCNEST`    |
| `eval` depth                 | 256   | (hardcoded)   |
| `source` depth               | 256   | (hardcoded)   |

Bash has no explicit limits on expansion or source/eval depth -- it relies
on the C stack, which typically allows several thousand frames before
crashing.  brash enforces hard ceilings that prevent stack overflow while
being high enough for any reasonable script.  `FUNCNEST` remains
user-settable (matching bash) but is capped at 1000 even when unset.

### Integer arithmetic

All arithmetic operations use wrapping semantics (`wrapping_add`,
`wrapping_mul`, etc.) matching bash's C `long` overflow behavior.
Division and modulo by zero return errors.  Shift counts are bounds-checked
(negative or >= 64 returns 0).  Exponentiation with negative exponent is
an error.

### Signal safety

Signal handlers (`install_trap_handler`) only touch `AtomicI32` arrays --
no heap allocation, no locks, no non-reentrant calls.  The main loop polls
these atomics and dispatches trap bodies in normal execution context.

### Temporary files

Here-document temporary files are created with `mkstemp(3)` and immediately
`unlink(2)`ed so they exist only as open file descriptors.

### Panic audit

All 148 non-test `.unwrap()` and `.expect()` calls have been reviewed and
documented with `// PROVEN:` comments explaining why each is infallible.
There are zero `todo!()` or `unimplemented!()` calls.

## Unsafe Code

brash contains **156 `unsafe` blocks** across ~55,000 lines of Rust.  Every
block has a `// SAFETY:` comment documenting its preconditions.

| File          | `unsafe` blocks | Category                                      |
|---------------|----------------:|-----------------------------------------------|
| `exec.rs`     |              87 | fork/exec, pipe/dup2/close, signal handlers   |
| `builtins.rs` |              49 | libc FFI (strftime, access, kill, umask, etc.) |
| `main.rs`     |              12 | terminal I/O, signal setup, window size       |
| `expand.rs`   |               3 | iconv, getpwuid, getpwnam                     |
| Others        |               5 | (none in arithmetic, lexer, parser, vars, etc.)|

All unsafe code is concentrated in OS/libc FFI boundaries.  The core logic
(lexer, parser, expansion engine, arithmetic evaluator, variable model) is
100% safe Rust.

### Why `unsafe` is necessary

brash is a Unix shell -- it must call `fork(2)`, `execvp(3)`, `pipe(2)`,
`dup2(2)`, `waitpid(2)`, `signal(2)`, `tcsetattr(3)`, and dozens of other
POSIX interfaces that have no safe Rust wrapper.  Where the `nix` crate
provides safe wrappers (fork, pipe, dup2, close, signal), brash uses them.
The remaining `unsafe` blocks are raw `libc` calls that `nix` does not
cover (e.g., `dlopen`, `iconv`, `strftime`, `regcomp`, `ioctl`).

## Invariant Ledgers

Every module with more than 500 lines has a machine-readable invariant
ledger in its module-level doc comment.  The ledger documents the rules
that MUST always be true -- structural invariants, safety invariants, and
performance invariants.  These serve as the contract for code review:
every function is assessed against "what invariant does it require?" and
"what invariant does it restore before returning?"

Modules with ledgers: `exec.rs`, `builtins.rs`, `expand.rs`, `lexer.rs`,
`arithmetic.rs`, `vars.rs`, `parser.rs`, `history.rs`, `main.rs`.

## Architecture

```
CLI args / environment / terminal / scripts
    |
    v
Lexer (lexer.rs) -- tokenizes input, handles aliases, heredocs
    |
    v
Parser (parser.rs) -- builds AST (Pipeline/Command/Compound)
    |
    v
Executor (exec.rs) -- walks AST, manages jobs/fds/subshells
    |                  calls into:
    +-> Expansion engine (expand.rs) -- brace/tilde/param/arith/cmdsub
    +-> Builtins (builtins.rs) -- cd, test, printf, declare, etc.
    +-> Arithmetic evaluator (arithmetic.rs) -- $((...))
    |
    v
Variables (vars.rs) -- scoped variable/array/assoc storage
Traps (trap.rs) -- signal trap management
History (history.rs) -- readline-style command history
```

The expansion engine and arithmetic evaluator are pure functions over
`Variables` -- they do not call `fork`, read files, or touch the terminal.
All I/O is concentrated in `exec.rs` (process management) and `main.rs`
(terminal/readline).

## Test Mode

When `BRASH_TEST_MODE=1` is set, brash impersonates bash in all
user-facing output: `$0` defaults to `bash`, error prefixes use `bash:`,
and `--version` reports the bash version string.  This allows running the
upstream bash test suite without renaming the binary.

## License

MIT.  See `Cargo.toml`.  No GPL code was referenced or included.
