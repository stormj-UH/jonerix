# lsusb-rs

Permissive-license `lsusb` drop-in. Written for the jonerix
distribution's no-GPL-runtime rule — replaces the GPL-2.0
`usbutils` package with something under MIT.

Zero dependencies. The whole tool reads the kernel's stable
sysfs USB interface at `/sys/bus/usb/devices/`, which gives us
everything the default-mode `lsusb` output needs.

## Build

    cargo build --release

## Usage

    $ lsusb
    Bus 001 Device 001: ID 1d6b:0002 Linux Foundation 2.0 root hub
    Bus 002 Device 001: ID 1d6b:0003 Linux Foundation 3.0 root hub

    $ lsusb -t            # tree view
    $ lsusb -v            # verbose — annotated hex descriptor dump
    $ lsusb -s 1:2        # filter by bus:dev
    $ lsusb -d 046d:c52b  # filter by vendor:product

## Vendor / product names

Looked up from `usb.ids` at one of:

    /usr/share/hwdata/usb.ids
    /usr/share/misc/usb.ids
    /usr/share/usb.ids

If none of those exist the tool falls back to the kernel-supplied
`manufacturer` / `product` string descriptors from sysfs.

## Scope

 * Default `lsusb` output — matches the one-line-per-device
   format upstream produces.
 * `-t` tree view — root hub per bus plus indented children.
 * `-v` verbose — dumps the raw `descriptors` file as annotated
   hex. Full pretty-printed descriptor decoding (config →
   interface → endpoint with per-field labels) is a follow-up.
 * `-s BUS:DEV` / `-d VID:PID` filters.

## License

MIT. See [LICENSE](LICENSE).

`usb.ids` is a separate project maintained by the linux-usb
community and distributed independently — this tool reads it at
runtime but doesn't bundle it.
