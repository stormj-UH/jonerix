#!/bin/bash
# upstream-nft-suite.sh — structured per-test driver for the upstream nftables
# shell test suite against stormwall.
#
# Usage:
#   upstream-nft-suite.sh [OPTIONS]
#
# Options:
#   --basedir DIR         Root of the unpacked nftables shell tests.
#                         Default: /tmp/nft-tests/tests/shell
#   --cats CAT[,CAT...]   Comma-separated list of test categories to run.
#                         Default: listing,chains,rule_management,sets,maps,nft-f,transactions
#   --skip-pattern REGEX  ERE applied to each test filename; matching tests are
#                         skipped without running.
#                         Default: (stress|huge|validation_recursion|concat_range_abort|0011manydefines|large_|pknock|nfqueue|0049)
#   --bail                Stop at the first FAILED test.
#   --ratio               Also run each test against the real nft binary
#                         (NFT_REAL or /usr/sbin/nft) and report parity ratio.
#   --nft PATH            Path to the stormwall binary under test.
#                         Default: /tmp/stormwall
#   --nft-real PATH       Path to the real nft binary for --ratio mode.
#                         Default: /usr/sbin/nft
#   --csv PATH            Path for the per-test CSV output.
#                         Default: /tmp/upstream-nft-suite.csv
#
# Exit status:
#   0   All tests passed (or were skipped).
#   1   One or more tests failed.
#
# Protocol for nftables' run-tests.sh:
#   Each testcase is an executable shell script.  run-tests.sh wraps it by
#   setting NFT and (optionally) NFT_REAL, then exec-ing the testcase.
#   Exit codes: 0 = OK, 77 = SKIPPED, anything else = FAILED.
#   The framework also prints a final "[OK]", "[SKIPPED]", or "[FAILED]" line
#   to stdout/stderr; we capture both and grep for it to determine the verdict.
#
# CSV columns: category,test,rc,verdict

set -u

# ---------------------------------------------------------------------------
# Defaults
# ---------------------------------------------------------------------------
BASEDIR=/tmp/nft-tests/tests/shell
CATS=listing,chains,rule_management,sets,maps,nft-f,transactions,parsing,bitwise,cache,comments,flowtable,json,include,optimizations
SKIP_PAT='(stress|huge|validation_recursion|concat_range_abort|0011manydefines|large_|pknock|nfqueue|0049)'
BAIL=0
RATIO=0
NFT_BIN=/tmp/stormwall
NFT_REAL_BIN=/usr/sbin/nft
CSV_OUT=/tmp/upstream-nft-suite.csv

# ---------------------------------------------------------------------------
# Argument parsing
# ---------------------------------------------------------------------------
while [ $# -gt 0 ]; do
    case "$1" in
        --basedir)    BASEDIR=$2;     shift 2 ;;
        --cats)       CATS=$2;        shift 2 ;;
        --skip-pattern) SKIP_PAT=$2; shift 2 ;;
        --bail)       BAIL=1;         shift   ;;
        --ratio)      RATIO=1;        shift   ;;
        --nft)        NFT_BIN=$2;     shift 2 ;;
        --nft-real)   NFT_REAL_BIN=$2; shift 2 ;;
        --csv)        CSV_OUT=$2;     shift 2 ;;
        -h|--help)
            sed -n '/^# upstream-nft-suite/,/^[^#]/{ /^[^#]/d; s/^# \{0,1\}//p }' "$0"
            exit 0 ;;
        *)
            printf 'unknown option: %s\n' "$1" >&2
            exit 1 ;;
    esac
done

# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------
if [ ! -d "$BASEDIR" ]; then
    printf 'upstream-nft-suite: basedir not found: %s\n' "$BASEDIR" >&2
    printf 'Hint: clone nftables and point --basedir at tests/shell/\n' >&2
    exit 1
fi
if [ ! -f "$BASEDIR/run-tests.sh" ]; then
    printf 'upstream-nft-suite: run-tests.sh not found in %s\n' "$BASEDIR" >&2
    exit 1
fi
if [ ! -x "$NFT_BIN" ]; then
    printf 'upstream-nft-suite: nft binary not executable: %s\n' "$NFT_BIN" >&2
    exit 1
fi

# ---------------------------------------------------------------------------
# Trap / cleanup
# ---------------------------------------------------------------------------
_TMPDIR=""
cleanup() {
    [ -n "$_TMPDIR" ] && rm -rf "$_TMPDIR"
}
trap cleanup EXIT INT TERM HUP

_TMPDIR=$(mktemp -d /tmp/upstream-nft-suite.XXXXXX)

# ---------------------------------------------------------------------------
# CSV header
# ---------------------------------------------------------------------------
printf 'category,test,rc,verdict\n' > "$CSV_OUT"

# ---------------------------------------------------------------------------
# Helper: run one test against one binary, return verdict + rc
# ---------------------------------------------------------------------------
# Outputs two lines to stdout:
#   RC=<n>
#   VERDICT=<OK|SKIPPED|FAILED>
run_one_binary() {
    local testpath=$1   # path to the testcase script (relative to BASEDIR)
    local nft_bin=$2    # binary to test
    local nft_real=$3   # real nft path (may be same as nft_bin)
    local logfile=$4    # file to capture combined output

    # Each test runs in its own subshell so any `set -e` inside the test
    # framework or the testcase itself cannot abort the harness.
    # Stdin is redirected from /dev/null so run-tests.sh cannot consume
    # the find pipe that feeds the outer while-read loop.
    (
        cd "$BASEDIR"
        export NFT="$nft_bin"
        export NFT_REAL="$nft_real"
        # run-tests.sh expects a path relative to the tests/shell/ directory.
        bash run-tests.sh "$testpath" >"$logfile" 2>&1
        exit $?
    ) </dev/null
    local rc=$?

    local verdict
    # Parse the per-test verdict line emitted by run-tests.sh.
    # Per-test lines:  "I: [OK]    1/1 testcases/..."
    # Summary line:    "I: results: [OK] 0 [SKIPPED] 1 ..."
    # Exclude summary lines (contain "results:") so we only match
    # the actual per-test verdict. Check FAILED first, then SKIPPED.
    if grep -v 'results:' "$logfile" 2>/dev/null | grep -qE '\[FAILED\]'; then
        verdict=FAILED
    elif grep -v 'results:' "$logfile" 2>/dev/null | grep -qE '\[SKIPPED\]'; then
        verdict=SKIPPED
    elif grep -v 'results:' "$logfile" 2>/dev/null | grep -qE '\[OK\]'; then
        verdict=OK
    else
        # Fall back to exit-code semantics when framework line is absent.
        case $rc in
            0)  verdict=OK ;;
            77) verdict=SKIPPED ;;
            *)  verdict=FAILED ;;
        esac
    fi

    printf 'RC=%d\n' "$rc"
    printf 'VERDICT=%s\n' "$verdict"
}

# ---------------------------------------------------------------------------
# Per-category accumulators
# ---------------------------------------------------------------------------
TOTAL_OK=0
TOTAL_SKIPPED=0
TOTAL_FAILED=0
TOTAL_TESTS=0

# We'll build the per-category summary lines and print them after the run.
CAT_SUMMARY=""

# ---------------------------------------------------------------------------
# Main loop
# ---------------------------------------------------------------------------
# Split CATS on commas.
IFS=',' read -ra CAT_LIST <<< "$CATS"

printf 'upstream-nft-suite: %d categories, basedir=%s\n' "${#CAT_LIST[@]}" "$BASEDIR"
if [ "$RATIO" -eq 1 ]; then
    printf '  --ratio mode: also running against real nft (%s)\n' "$NFT_REAL_BIN"
fi
printf '\n'

GLOBAL_BAIL=0   # set to 1 if --bail triggered

for cat in "${CAT_LIST[@]}"; do
    catdir="$BASEDIR/testcases/$cat"
    if [ ! -d "$catdir" ]; then
        printf '[%s]  directory not found, skipping\n' "$cat"
        CAT_SUMMARY="${CAT_SUMMARY}[${cat}]  directory not found\n"
        continue
    fi

    cat_ok=0
    cat_skipped=0
    cat_failed=0
    cat_total=0

    # Collect and sort testcase files.
    # nftables testcases are executable files; many have no .sh extension.
    while IFS= read -r -d '' testfile; do
        [ -f "$testfile" ] || continue
        [ -x "$testfile" ] || continue

        testname=$(basename "$testfile")

        # Skip-pattern check (ERE).
        if printf '%s' "$testname" | grep -qE "$SKIP_PAT"; then
            cat_skipped=$((cat_skipped + 1))
            cat_total=$((cat_total + 1))
            printf '%s,%s,,%s\n' "$cat" "$testname" "SKIPPED(pattern)" >> "$CSV_OUT"
            continue
        fi

        cat_total=$((cat_total + 1))
        logfile="$_TMPDIR/${cat}_${testname}.log"
        # Relative path as run-tests.sh expects it (from tests/shell/).
        rel_testpath="testcases/${cat}/${testname}"

        # Run test against stormwall.
        sw_info=$(run_one_binary "$rel_testpath" "$NFT_BIN" "$NFT_REAL_BIN" "$logfile")
        sw_rc=$(printf '%s\n' "$sw_info" | grep '^RC=' | cut -d= -f2)
        sw_verdict=$(printf '%s\n' "$sw_info" | grep '^VERDICT=' | cut -d= -f2)

        if [ "$RATIO" -eq 1 ] && [ -x "$NFT_REAL_BIN" ]; then
            rlogfile="$_TMPDIR/${cat}_${testname}.real.log"
            real_info=$(run_one_binary "$rel_testpath" "$NFT_REAL_BIN" "$NFT_REAL_BIN" "$rlogfile")
            real_verdict=$(printf '%s\n' "$real_info" | grep '^VERDICT=' | cut -d= -f2)
            parity_tag="(real=$real_verdict)"
        else
            parity_tag=""
        fi

        # Accumulate.
        case "$sw_verdict" in
            OK)      cat_ok=$((cat_ok + 1)) ;;
            SKIPPED) cat_skipped=$((cat_skipped + 1)) ;;
            FAILED)  cat_failed=$((cat_failed + 1)) ;;
        esac

        # CSV row.
        printf '%s,%s,%s,%s\n' "$cat" "$testname" "$sw_rc" "$sw_verdict" >> "$CSV_OUT"

        # Verbose per-test line (failures are always shown).
        if [ "$sw_verdict" = "FAILED" ]; then
            printf '  FAIL  %s/%s  rc=%s %s\n' "$cat" "$testname" "$sw_rc" "$parity_tag"
            if [ "$BAIL" -eq 1 ]; then
                GLOBAL_BAIL=1
                # Flush accumulators for the in-progress category before stopping.
                TOTAL_OK=$((TOTAL_OK + cat_ok))
                TOTAL_SKIPPED=$((TOTAL_SKIPPED + cat_skipped))
                TOTAL_FAILED=$((TOTAL_FAILED + cat_failed))
                TOTAL_TESTS=$((TOTAL_TESTS + cat_total))
                line=$(printf '[%-20s]  OK=%-4d SKIPPED=%-4d FAILED=%-4d (%d of %d) [bailed]' \
                    "$cat" "$cat_ok" "$cat_skipped" "$cat_failed" "$cat_failed" "$cat_total")
                CAT_SUMMARY="${CAT_SUMMARY}${line}\n"
                break 2
            fi
        fi

    done < <(find "$catdir" -maxdepth 1 -type f -print0 | sort -z)

    # Category total.
    TOTAL_OK=$((TOTAL_OK + cat_ok))
    TOTAL_SKIPPED=$((TOTAL_SKIPPED + cat_skipped))
    TOTAL_FAILED=$((TOTAL_FAILED + cat_failed))
    TOTAL_TESTS=$((TOTAL_TESTS + cat_total))

    line=$(printf '[%-20s]  OK=%-4d SKIPPED=%-4d FAILED=%-4d (%d of %d)' \
        "$cat" "$cat_ok" "$cat_skipped" "$cat_failed" "$cat_failed" "$cat_total")
    CAT_SUMMARY="${CAT_SUMMARY}${line}\n"
done

# ---------------------------------------------------------------------------
# Print per-category summary
# ---------------------------------------------------------------------------
printf '%b' "$CAT_SUMMARY"
printf '\n'

# ---------------------------------------------------------------------------
# Top-level summary
# ---------------------------------------------------------------------------
if [ "$TOTAL_TESTS" -gt 0 ]; then
    pass_pct=$(( (TOTAL_OK * 100) / TOTAL_TESTS ))
else
    pass_pct=0
fi

printf '%-22s OK=%-6d SKIPPED=%-6d FAILED=%-6d  (~%d%% PASS rate)\n' \
    "TOTAL" "$TOTAL_OK" "$TOTAL_SKIPPED" "$TOTAL_FAILED" "$pass_pct"

# ---------------------------------------------------------------------------
# --ratio parity report (printed after main tally)
# ---------------------------------------------------------------------------
if [ "$RATIO" -eq 1 ] && [ -x "$NFT_REAL_BIN" ]; then
    # Count lines where stormwall verdict matches real-nft verdict.
    # We re-read the CSV and compare stormwall verdict vs real-nft verdict
    # which we stored in a parallel CSV.
    # (We already have per-test real verdicts in the per-test loop above;
    #  for the ratio summary we need to cross-reference the logs we saved.)
    total_comparable=0
    total_matching=0
    while IFS=, read -r rcat rtest rrc rverdict; do
        [ "$rcat" = "category" ] && continue   # header
        rlogfile="$_TMPDIR/${rcat}_${rtest}.log"
        reallogfile="$_TMPDIR/${rcat}_${rtest}.real.log"
        [ -f "$reallogfile" ] || continue
        total_comparable=$((total_comparable + 1))
        # Parse real verdict from log.
        if grep -qE '\[OK\]' "$reallogfile" 2>/dev/null; then
            real_v=OK
        elif grep -qE '\[SKIPPED\]' "$reallogfile" 2>/dev/null; then
            real_v=SKIPPED
        else
            real_v=FAILED
        fi
        [ "$rverdict" = "$real_v" ] && total_matching=$((total_matching + 1))
    done < "$CSV_OUT"

    if [ "$total_comparable" -gt 0 ]; then
        parity_pct=$(( (total_matching * 100) / total_comparable ))
        printf '\nparity-ratio (stormwall vs real nft): %d/%d tests match (%d%%)\n' \
            "$total_matching" "$total_comparable" "$parity_pct"
    fi
fi

printf '\nCSV written to %s\n' "$CSV_OUT"

# ---------------------------------------------------------------------------
# Exit status
# ---------------------------------------------------------------------------
if [ "$GLOBAL_BAIL" -eq 1 ] || [ "$TOTAL_FAILED" -gt 0 ]; then
    exit 1
fi
exit 0
