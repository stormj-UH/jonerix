//! pfctl-shim: CLI-compatible wrapper around stormwall's pf parser.
//!
//! Mimics FreeBSD pfctl(8) for the subset of commands that pfSense's
//! PHP web UI invokes. Translates pf syntax to nftables via
//! stormwall's pf_parser module and drives the kernel through the
//! same netlink ops path.

mod json;
mod netlink;
mod ops;
mod output;
mod parser;
mod pf_parser;
mod tc;
mod templates;

// Required by ops.rs / output.rs — mirrors the constants in main.rs.
pub const NFT_IMPERSONATED_VERSION: &str = "1.1.3";
pub const NFT_IMPERSONATED_RELEASE_NAME: &str = "Commodore Bullmoose #4";
pub fn test_mode() -> bool {
    std::env::var("STORMWALL_TEST_MODE").map(|v| v == "1").unwrap_or(false)
}

use std::env;
use std::fs;
use std::process;
use std::sync::atomic::{AtomicI32, Ordering};

// ── Daemon signal state ───────────────────────────────────────────
//
// Signal handlers may only touch async-signal-safe state.  We use a
// plain AtomicI32 to record which signal fired; the main loop reads it
// after pause()/sigsuspend() returns and acts accordingly.
//
// Values: 0 = none, SIGHUP = reload, SIGTERM/SIGINT = shutdown.

static SIGNAL_RECEIVED: AtomicI32 = AtomicI32::new(0);

extern "C" fn handle_signal(sig: libc::c_int) {
    SIGNAL_RECEIVED.store(sig, Ordering::Relaxed);
}

// ── Daemon mode ───────────────────────────────────────────────────

/// Write our PID to the PID file.  Returns the path used.
fn write_pid_file(pid_path: &str) -> Result<(), String> {
    let pid = unsafe { libc::getpid() };
    fs::write(pid_path, format!("{}\n", pid))
        .map_err(|e| format!("cannot write PID file {}: {}", pid_path, e))
}

/// Remove the PID file, ignoring errors (best-effort cleanup).
fn remove_pid_file(pid_path: &str) {
    let _ = fs::remove_file(pid_path);
}

/// Install a libc signal handler for `sig`.
///
/// # Safety
/// Calls `libc::signal()`, which is unsafe.  The handler itself only
/// stores to an AtomicI32, which is async-signal-safe.
fn install_signal_handler(sig: libc::c_int) {
    unsafe {
        libc::signal(sig, handle_signal as libc::sighandler_t);
    }
}

/// Enter daemon mode: stay resident, reload ruleset on SIGHUP, exit
/// cleanly on SIGTERM or SIGINT.
///
/// `file` is the ruleset path to reload on SIGHUP.
/// `quiet` is forwarded to `cmd_load_file`.
/// `pid_path` is where the PID file is written.
fn run_daemon(file: &str, quiet: bool, pid_path: &str) {
    if let Err(e) = write_pid_file(pid_path) {
        eprintln!("pfctl: {}", e);
        process::exit(1);
    }

    install_signal_handler(libc::SIGHUP);
    install_signal_handler(libc::SIGTERM);
    install_signal_handler(libc::SIGINT);

    if !quiet {
        eprintln!("pfctl: daemon mode, pid={}, ruleset={}, pid_file={}",
            unsafe { libc::getpid() }, file, pid_path);
    }

    // Initial load.
    cmd_load_file(file, false, quiet);

    loop {
        // Block until any signal arrives.
        unsafe { libc::pause() };

        let sig = SIGNAL_RECEIVED.swap(0, Ordering::Relaxed);
        match sig {
            s if s == libc::SIGHUP => {
                if !quiet { eprintln!("pfctl: SIGHUP — reloading {}", file); }
                cmd_load_file(file, false, quiet);
            }
            s if s == libc::SIGTERM || s == libc::SIGINT => {
                if !quiet { eprintln!("pfctl: signal {} — shutting down", sig); }
                remove_pid_file(pid_path);
                process::exit(0);
            }
            _ => {
                // Spurious wakeup (pause() interrupted by an unhandled signal
                // or by a signal that fired before we swapped).  Loop again.
            }
        }
    }
}

/// Apply a batch of parsed commands via the netlink ops path.
#[cfg(target_os = "linux")]
fn apply_commands(cmds: &[parser::Command]) -> Result<(), String> {
    let mut ctx = ops::NftCtx::new()
        .map_err(|e| format!("netlink init: {}", e))?;
    ctx.begin_txn();
    for cmd in cmds {
        if let Err(e) = ctx.exec(cmd) {
            ctx.abort_txn();
            return Err(format!("{}", e));
        }
    }
    ctx.commit_txn().map_err(|e| format!("{}", e))
}

/// Apply tc queueing infrastructure: root qdisc + classes + filters.
#[cfg(target_os = "linux")]
fn apply_tc_queues(
    root: &pf_parser::AltqRoot,
    decls: &[pf_parser::QueueDecl],
) -> Result<(), String> {
    let ifindex = tc::ifindex_for_name(&root.iface)
        .map_err(|e| format!("interface {}: {}", root.iface, e))?;

    let mut tc_sock = tc::TcSocket::open()
        .map_err(|e| format!("tc socket: {}", e))?;

    // Delete any existing root qdisc (ignore errors — may not exist)
    let _ = tc::del_root_qdisc(&mut tc_sock, ifindex);

    // Find the default class (first child queue)
    let default_minor = if !root.child_queues.is_empty() {
        // Minor number for first child — the queue_priority allocator
        // starts at 0x10, so the first child is 0x10.
        0x10u16
    } else {
        0x10u16
    };

    // Create root qdisc based on discipline
    match root.discipline.as_str() {
        "hfsc" => {
            let r = tc::add_hfsc_root(&mut tc_sock, ifindex, default_minor);
            if let Err(ref e) = r {
                if e.raw_os_error() == Some(2) {
                    // ENOENT — module not loaded
                    eprintln!("pfctl: loading sch_hfsc module");
                    tc::try_modprobe("sch_hfsc");
                    tc::add_hfsc_root(&mut tc_sock, ifindex, default_minor)
                        .map_err(|e| format!("hfsc root: {}", e))?;
                } else {
                    return Err(format!("hfsc root: {}", e));
                }
            }

            // Create HFSC classes for each declared queue
            for decl in decls {
                let bw = decl.bandwidth_bps.unwrap_or(root.bandwidth_bps / 10);
                let fsc = tc::ServiceCurve { m1: 0, d: 0, m2: bw as u32 };
                let classid = decl.marker; // already TC_H_MAKE form
                let parent = tc::tc_handle(tc::SW_TC_MAJOR, 0);
                tc::add_hfsc_class(&mut tc_sock, ifindex, parent, classid,
                    Some(fsc), Some(fsc), None)
                    .map_err(|e| format!("hfsc class {}: {}", decl.name, e))?;
            }
        }
        "htb" => {
            let r = tc::add_htb_root(&mut tc_sock, ifindex, default_minor);
            if let Err(ref e) = r {
                if e.raw_os_error() == Some(2) {
                    eprintln!("pfctl: loading sch_htb module");
                    tc::try_modprobe("sch_htb");
                    tc::add_htb_root(&mut tc_sock, ifindex, default_minor)
                        .map_err(|e| format!("htb root: {}", e))?;
                } else {
                    return Err(format!("htb root: {}", e));
                }
            }

            // Create HTB classes
            for decl in decls {
                let bw = decl.bandwidth_bps.unwrap_or(root.bandwidth_bps / 10);
                let classid = decl.marker;
                let parent = tc::tc_handle(tc::SW_TC_MAJOR, 0);
                tc::add_htb_class(&mut tc_sock, ifindex, parent, classid, bw, bw)
                    .map_err(|e| format!("htb class {}: {}", decl.name, e))?;
            }
        }
        "priq" | "prio" => {
            // PRIO qdisc with default priomap
            let bands = 16i32.min(decls.len().max(3) as i32);
            let priomap = [1u8, 2, 2, 2, 1, 2, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1];
            let r = tc::add_prio_root(&mut tc_sock, ifindex, bands, &priomap);
            if let Err(ref e) = r {
                if e.raw_os_error() == Some(2) {
                    eprintln!("pfctl: loading sch_prio module");
                    tc::try_modprobe("sch_prio");
                    tc::add_prio_root(&mut tc_sock, ifindex, bands, &priomap)
                        .map_err(|e| format!("prio root: {}", e))?;
                } else {
                    return Err(format!("prio root: {}", e));
                }
            }
        }
        "cbq" => {
            // CBQ removed from Linux ≥6.5 — fall back to HFSC
            let fallback = env::var("STORMWALL_PF_CBQ_FALLBACK")
                .unwrap_or_else(|_| "hfsc".to_string());
            eprintln!("pfctl: cbq removed from Linux ≥6.5, falling back to {}", fallback);
            match fallback.as_str() {
                "hfsc" => {
                    tc::add_hfsc_root(&mut tc_sock, ifindex, default_minor)
                        .map_err(|e| format!("hfsc fallback: {}", e))?;
                    for decl in decls {
                        let bw = decl.bandwidth_bps.unwrap_or(root.bandwidth_bps / 10);
                        let fsc = tc::ServiceCurve { m1: 0, d: 0, m2: bw as u32 };
                        let classid = decl.marker;
                        let parent = tc::tc_handle(tc::SW_TC_MAJOR, 0);
                        tc::add_hfsc_class(&mut tc_sock, ifindex, parent, classid,
                            Some(fsc), Some(fsc), None)
                            .map_err(|e| format!("hfsc class {}: {}", decl.name, e))?;
                    }
                }
                "htb" => {
                    tc::add_htb_root(&mut tc_sock, ifindex, default_minor)
                        .map_err(|e| format!("htb fallback: {}", e))?;
                    for decl in decls {
                        let bw = decl.bandwidth_bps.unwrap_or(root.bandwidth_bps / 10);
                        let classid = decl.marker;
                        let parent = tc::tc_handle(tc::SW_TC_MAJOR, 0);
                        tc::add_htb_class(&mut tc_sock, ifindex, parent, classid, bw, bw)
                            .map_err(|e| format!("htb class {}: {}", decl.name, e))?;
                    }
                }
                "error" => return Err("cbq not supported; set STORMWALL_PF_CBQ_FALLBACK".into()),
                _ => return Err(format!("unknown cbq fallback: {}", fallback)),
            }
        }
        other => return Err(format!("unsupported qdisc discipline: {}", other)),
    }

    // Create pfifo leaf qdiscs with qlimit for classes that specify one
    for decl in decls {
        if let Some(qlimit) = decl.qlimit {
            let leaf_handle = tc::tc_handle(tc::SW_TC_MAJOR + 1, 0);
            let _ = tc::add_pfifo_leaf(&mut tc_sock, ifindex, decl.marker, leaf_handle, qlimit);
        }
    }

    // Install a catch-all basic filter that routes unmarked traffic to
    // the default class.  Packets WITH a priority marker set by nftables
    // `meta priority set <handle>` bypass filters entirely — both HTB
    // and HFSC do native priority-based class lookup before consulting
    // the filter chain.  This filter only catches traffic that never
    // hit an nftables queue rule.
    let root_handle = tc::tc_handle(tc::SW_TC_MAJOR, 0);
    let default_classid = tc::tc_handle(tc::SW_TC_MAJOR, default_minor);
    if let Err(e) = tc::add_basic_filter(&mut tc_sock, ifindex, root_handle, default_classid, 1) {
        // Non-fatal — the qdisc's defcls already handles this case.
        // The filter is a belt-and-suspenders fallback.  cls_basic.ko
        // might not be loaded.
        if e.raw_os_error() == Some(2) {
            tc::try_modprobe("cls_basic");
            let _ = tc::add_basic_filter(&mut tc_sock, ifindex, root_handle, default_classid, 1);
        }
    }

    Ok(())
}

/// List a specific nftables object (table, set, etc.) by building a
/// list command and executing it.
#[cfg(target_os = "linux")]
fn list_object(obj: parser::CmdObj, family: u8, table: &str, extra: &str) {
    let mut ctx = match ops::NftCtx::new() {
        Ok(c) => c,
        Err(_) => return,
    };
    let mut cmd = parser::Command::default();
    cmd.op = parser::CmdOp::List;
    cmd.obj = obj;
    cmd.family = family;
    cmd.table = table.to_string();
    if !extra.is_empty() {
        // For sets, the set name goes in set_name or chain.
        match cmd.obj {
            parser::CmdObj::Set => cmd.set_name = extra.to_string(),
            _ => cmd.chain = extra.to_string(),
        }
    }
    let _ = ctx.exec(&cmd);
}

fn main() {
    let args: Vec<String> = env::args().collect();
    if args.len() < 2 {
        usage();
        process::exit(1);
    }

    let mut i = 1;
    let mut quiet = false;
    let mut verbose = 0u8;
    let mut check_only = false;
    let mut file: Option<String> = None;
    let mut anchor: Option<String> = None;
    let mut table_name: Option<String> = None;
    let mut table_cmd: Option<String> = None;
    let mut table_args: Vec<String> = Vec::new();
    let mut show_what: Option<String> = None;
    let mut flush_what: Option<String> = None;
    let mut enable = false;
    let mut disable = false;
    let mut kill_args: Vec<String> = Vec::new();
    let mut kill_multi = false; // -M flag
    let mut daemon_mode = false;

    // First pass: parse all flags.
    while i < args.len() {
        let arg = args[i].as_str();
        match arg {
            "-h" | "--help" => { usage(); process::exit(0); }
            "--version" => {
                println!("pfctl (stormwall) {}", VERSION);
                println!("Copyright (c) 2025-2026 Jon-Erik G. Storm, Inc. DBA Lava Goat Software");
                println!("License: MIT <https://opensource.org/licenses/MIT>");
                process::exit(0);
            }
            "-q" => { quiet = true; }
            "-v" => { verbose += 1; }
            "-vv" => { verbose += 2; }
            "-vvv" => { verbose += 3; }
            "-n" => { check_only = true; }
            "-e" => { enable = true; }
            "-d" => { disable = true; }
            "-D" => { daemon_mode = true; }
            "-M" => { kill_multi = true; }
            "-o" => {
                // Optimization level — consumed and ignored.
                i += 1;
            }
            "-nf" => {
                // Combined -n -f: check-only + file.
                check_only = true;
                i += 1;
                if i < args.len() { file = Some(args[i].clone()); }
            }
            "-Of" => {
                // Combined -O <level> -f: skip the optimization level
                // that pfSense embeds before the filename. The next arg
                // is the opt level (e.g. "basic"), then the filename.
                i += 1; // skip optimization level
                i += 1;
                if i < args.len() { file = Some(args[i].clone()); }
            }
            "-f" | "-f-" => {
                if arg == "-f" {
                    i += 1;
                    if i < args.len() {
                        file = Some(args[i].clone());
                    }
                } else {
                    file = Some("-".to_string()); // stdin
                }
            }
            "-a" => {
                i += 1;
                if i < args.len() { anchor = Some(args[i].clone()); }
            }
            "-t" => {
                i += 1;
                if i < args.len() { table_name = Some(args[i].clone()); }
            }
            "-T" => {
                i += 1;
                if i < args.len() {
                    table_cmd = Some(args[i].clone());
                    // Remaining args after -T <cmd> are addresses.
                    i += 1;
                    while i < args.len() {
                        table_args.push(args[i].clone());
                        i += 1;
                    }
                    break;
                }
            }
            "-k" => {
                i += 1;
                if i < args.len() { kill_args.push(args[i].clone()); }
            }
            "-F" => {
                i += 1;
                if i < args.len() { flush_what = Some(args[i].clone()); }
            }
            // Combined show flags: -sr, -sn, -ss, -si, -sa, -sT, -st, -sm, -sI
            _ if arg.starts_with("-s") && arg.len() > 2 => {
                show_what = Some(arg[2..].to_string());
            }
            // Combined verbose show: -vvsi, -vvsm, etc.
            _ if arg.starts_with("-vvs") => {
                verbose += 2;
                show_what = Some(arg[4..].to_string());
            }
            // Combined flush: -Fs, -Fn, etc.
            _ if arg.starts_with("-F") && arg.len() > 2 => {
                flush_what = Some(arg[2..].to_string());
            }
            "-s" => {
                i += 1;
                if i < args.len() { show_what = Some(args[i].clone()); }
            }
            _ => {
                // Unknown flags are ignored for pfSense compat.
            }
        }
        i += 1;
    }

    let _ = (verbose, kill_multi, anchor);

    // Dispatch.
    if enable {
        if !quiet { eprintln!("pf enabled"); }
        process::exit(0);
    }
    if disable {
        cmd_disable(quiet);
        process::exit(0);
    }
    if let Some(what) = flush_what {
        cmd_flush(&what, quiet);
        process::exit(0);
    }
    if let Some(tbl) = table_name {
        if let Some(cmd) = table_cmd {
            cmd_table(&tbl, &cmd, &table_args);
        } else if let Some(ref s) = show_what {
            if s == "T" {
                cmd_show_tables();
            }
        }
        process::exit(0);
    }
    if let Some(ref s) = show_what {
        cmd_show(s, verbose);
        process::exit(0);
    }
    if let Some(ref path) = file {
        if daemon_mode && !check_only {
            let pid_path = env::var("PFCTL_PID_FILE")
                .unwrap_or_else(|_| "/var/run/pfctl.pid".to_string());
            run_daemon(path, quiet, &pid_path);
            // run_daemon() never returns.
        }
        cmd_load_file(path, check_only, quiet);
        process::exit(0);
    }
    if !kill_args.is_empty() {
        cmd_kill_states(&kill_args);
        process::exit(0);
    }

    usage();
    process::exit(1);
}

const VERSION: &str = "1.0.2";

fn usage() {
    eprintln!("usage: pfctl [-f file] [-nf file] [-e|-d] [-D] [-sr|-sn|-ss|-si|-sa|-sT|-st|-sm]");
    eprintln!("             [-t table -T show|add|delete|flush|kill [addr ...]]");
    eprintln!("             [-F states|Sources|all] [-k host] [-M -k label -k str]");
    eprintln!("             [-a anchor -f file] [-o basic] [-q] [-v] [--version]");
    eprintln!();
    eprintln!("stormwall pfctl shim — FreeBSD-compatible pfctl(8) backed by Linux nftables.");
    eprintln!();
    eprintln!("  -f file        Load and apply pf rules from file");
    eprintln!("  -nf file       Parse-check only (do not apply)");
    eprintln!("  -e / -d        Enable / disable the packet filter");
    eprintln!("  -D             Daemon mode: stay resident, SIGHUP reload, SIGTERM exit");
    eprintln!("                 PID written to /var/run/pfctl.pid (override: PFCTL_PID_FILE)");
    eprintln!("  -s<x>          Show: r=rules n=NAT s=state i=info a=all T=tables t=timeouts");
    eprintln!("  -F <what>      Flush: states, Sources, all");
    eprintln!("  -t T -T <cmd>  Table operations: show, add, delete, flush, kill");
    eprintln!("  -k host        Kill states matching host");
    eprintln!("  -q             Quiet — suppress non-error output");
    eprintln!("  -v             Verbose (repeat for more detail)");
    eprintln!("  --version      Show version and exit");
}

// ── Rule loading ──────────────────────────────────────────────────

fn cmd_load_file(path: &str, check_only: bool, quiet: bool) {
    let content = if path == "-" {
        use std::io::Read;
        let mut buf = String::new();
        std::io::stdin().read_to_string(&mut buf).unwrap_or_default();
        buf
    } else {
        match fs::read_to_string(path) {
            Ok(c) => c,
            Err(e) => {
                eprintln!("pfctl: cannot read {}: {}", path, e);
                process::exit(1);
            }
        }
    };

    let result = match pf_parser::parse_file_full(&content) {
        Ok(r) => r,
        Err(e) => {
            eprintln!("pfctl: parse error: {}", e);
            process::exit(1);
        }
    };

    if check_only {
        if !quiet { eprintln!("rules ok"); }
        return;
    }

    #[cfg(target_os = "linux")]
    {
        // Apply nftables commands
        if let Err(e) = apply_commands(&result.commands) {
            eprintln!("pfctl: apply error: {}", e);
            process::exit(1);
        }

        // Apply tc queueing infrastructure if any altq/queue declarations exist
        if let Some(ref root) = result.altq_root {
            if let Err(e) = apply_tc_queues(root, &result.queue_decls) {
                eprintln!("pfctl: tc error: {}", e);
                // Non-fatal — nftables rules are already applied
            }
        }
    }
    #[cfg(not(target_os = "linux"))]
    { let _ = &result; }

    if !quiet { eprintln!("rules loaded from {}", path); }
}

// ── Enable / disable ──────────────────────────────────────────────

fn cmd_disable(quiet: bool) {
    #[cfg(target_os = "linux")]
    {
        let mut cmd = parser::Command::default();
        cmd.op = parser::CmdOp::Flush;
        cmd.obj = parser::CmdObj::Table;
        cmd.family = netlink::NFPROTO_IPV4;
        cmd.table = "pf".to_string();
        if let Err(e) = apply_commands(&[cmd]) {
            eprintln!("pfctl: disable error: {}", e);
            process::exit(1);
        }
    }
    if !quiet { eprintln!("pf disabled"); }
}

// ── Flush ─────────────────────────────────────────────────────────

fn cmd_flush(what: &str, quiet: bool) {
    match what {
        "s" | "states" => {
            // Flush conntrack — on Linux: conntrack -F
            #[cfg(target_os = "linux")]
            {
                let _ = std::process::Command::new("conntrack")
                    .args(["-F"])
                    .output();
            }
            if !quiet { eprintln!("states cleared"); }
        }
        "Sources" => {
            // Flush source-tracking nodes — on Linux no direct
            // equivalent; flush conntrack as approximation.
            #[cfg(target_os = "linux")]
            {
                let _ = std::process::Command::new("conntrack")
                    .args(["-F"])
                    .output();
            }
            if !quiet { eprintln!("source tracking entries cleared"); }
        }
        "all" => {
            cmd_disable(quiet);
        }
        _ => {
            eprintln!("pfctl: unknown -F target: {}", what);
        }
    }
}

// ── Show ──────────────────────────────────────────────────────────

fn cmd_show(what: &str, verbose: u8) {
    let _ = verbose;
    match what {
        "r" | "rules" => cmd_show_rules(),
        "n" | "nat" => cmd_show_rules(),
        "s" | "state" | "states" => cmd_show_states(),
        "i" | "info" => cmd_show_info(),
        "I" => cmd_show_interface_stats(),
        "a" | "all" => {
            cmd_show_rules();
            cmd_show_states();
            cmd_show_info();
        }
        "T" | "Tables" => cmd_show_tables(),
        "t" | "timeouts" => cmd_show_timeouts(),
        "m" | "memory" => cmd_show_memory(),
        "osfp" => { println!("No OS fingerprints loaded."); }
        _ if what.starts_with("queue") => cmd_show_queue(),
        _ => {
            eprintln!("pfctl: unknown -s target: {}", what);
            process::exit(1);
        }
    }
}

fn cmd_show_rules() {
    #[cfg(target_os = "linux")]
    { list_object(parser::CmdObj::Table, netlink::NFPROTO_IPV4, "pf", ""); }
}

fn cmd_show_states() {
    // Read /proc/net/nf_conntrack and format as pfctl -ss output.
    #[cfg(target_os = "linux")]
    {
        if let Ok(content) = fs::read_to_string("/proc/net/nf_conntrack") {
            for line in content.lines() {
                // Format: ipvN proto_num proto_name timeout ...
                // Convert to pf format: proto src:sport -> dst:dport STATE
                let fields: Vec<&str> = line.split_whitespace().collect();
                if fields.len() < 10 { continue; }
                let proto = fields[2];
                let mut src = "";
                let mut dst = "";
                let mut sport = "";
                let mut dport = "";
                for f in &fields[4..] {
                    if let Some(v) = f.strip_prefix("src=") {
                        if src.is_empty() { src = v; } else { dst = v; }
                    }
                    if let Some(v) = f.strip_prefix("sport=") {
                        if sport.is_empty() { sport = v; }
                    }
                    if let Some(v) = f.strip_prefix("dst=") {
                        if dst.is_empty() { dst = v; }
                    }
                    if let Some(v) = f.strip_prefix("dport=") {
                        if dport.is_empty() { dport = v; }
                    }
                }
                println!("all {} {}:{} -> {}:{} ESTABLISHED:ESTABLISHED",
                    proto, src, sport, dst, dport);
            }
        }
    }
    #[cfg(not(target_os = "linux"))]
    { println!("No states"); }
}

fn cmd_show_info() {
    // pfSense parses this for "current entries" at awk field $3.
    println!("Status: Enabled for 0 days 00:00:00");
    println!("State Table                          Total             Rate");
    println!("  current entries                        0");
    println!("  searches                               0            0.0/s");
    println!("  inserts                                0            0.0/s");
    println!("  removals                               0            0.0/s");
    println!("Counters");
    println!("  match                                  0            0.0/s");
    println!("  bad-offset                             0            0.0/s");
    println!("  fragment                               0            0.0/s");
    println!("  short                                  0            0.0/s");
    println!("  normalize                              0            0.0/s");
    println!("  memory                                 0            0.0/s");
}

/// pfctl -vvsI — per-interface stats. pfSense parses lines 3-10
/// by fixed index, splitting on whitespace; field[3]=packets, [5]=bytes.
fn cmd_show_interface_stats() {
    // Format matches FreeBSD pfctl output: one block per interface.
    // pfSense reads:  line 4: "Passed" in, line 5: "Passed" out, etc.
    println!("all");
    println!("  Cleared:     Thu Jan  1 00:00:00 1970");
    println!("  References:  [ States:  0, Rules: 0 ]");
    println!("  In4/Pass:    [ Packets: 0                    Bytes: 0                    ]");
    println!("  In4/Block:   [ Packets: 0                    Bytes: 0                    ]");
    println!("  Out4/Pass:   [ Packets: 0                    Bytes: 0                    ]");
    println!("  Out4/Block:  [ Packets: 0                    Bytes: 0                    ]");
    println!("  In6/Pass:    [ Packets: 0                    Bytes: 0                    ]");
    println!("  In6/Block:   [ Packets: 0                    Bytes: 0                    ]");
    println!("  Out6/Pass:   [ Packets: 0                    Bytes: 0                    ]");
    println!("  Out6/Block:  [ Packets: 0                    Bytes: 0                    ]");
}

fn cmd_show_tables() {
    // List all named sets in the pf table.
    #[cfg(target_os = "linux")]
    { list_object(parser::CmdObj::Sets, netlink::NFPROTO_IPV4, "pf", ""); }
}

/// pfctl -st — show timeouts. pfSense parses each line with
/// regex `([a-z]+)\.([a-z]+)\s+([0-9]+)`.
fn cmd_show_timeouts() {
    println!("tcp.first                   120");
    println!("tcp.opening                  30");
    println!("tcp.established           86400");
    println!("tcp.closing                 900");
    println!("tcp.finwait                  45");
    println!("tcp.closed                   90");
    println!("tcp.tsdiff                   30");
    println!("udp.first                    60");
    println!("udp.single                   30");
    println!("udp.multiple                 60");
    println!("icmp.first                   20");
    println!("icmp.error                   10");
    println!("other.first                  60");
    println!("other.single                 30");
    println!("other.multiple               60");
    println!("frag                         30");
    println!("interval                     10");
    println!("adaptive.start             6000");
    println!("adaptive.end              12000");
    println!("src.track                     0");
}

/// pfctl -sm — show memory limits. pfSense parses for "tables"
/// and "table-entries" with awk field $4.
fn cmd_show_memory() {
    println!("states        hard limit    10000");
    println!("src-nodes     hard limit    10000");
    println!("frags         hard limit     5000");
    println!("tables        hard limit     1000");
    println!("table-entries hard limit   200000");
}

fn cmd_show_queue() {
    #[cfg(target_os = "linux")]
    {
        // Enumerate all network interfaces and dump their tc state
        let ifaces = match std::fs::read_dir("/sys/class/net") {
            Ok(rd) => rd,
            Err(_) => { println!("No ALTQ support in kernel"); return; }
        };

        let mut found_any = false;
        for entry in ifaces.flatten() {
            let ifname = entry.file_name().to_string_lossy().to_string();

            let ifindex = match tc::ifindex_for_name(&ifname) {
                Ok(i) => i,
                Err(_) => continue,
            };

            let mut tc_sock = match tc::TcSocket::open() {
                Ok(s) => s,
                Err(_) => { println!("No ALTQ support in kernel"); return; }
            };

            // Dump qdiscs
            let qdisc_data = match tc::dump_qdiscs(&mut tc_sock, ifindex) {
                Ok(d) => d,
                Err(_) => continue,
            };

            let mut qdiscs: Vec<(String, u32, u32)> = Vec::new(); // (kind, handle, parent)
            let _ = tc::process_tc_response(&qdisc_data, |_mtype, _ifidx, handle, parent, _info, attrs| {
                let tca = tc::parse_tca_attrs(attrs);
                let kind = tca.iter()
                    .find(|(t, _)| *t == tc::TCA_KIND)
                    .and_then(|(_, v)| {
                        let s = std::str::from_utf8(v).ok()?;
                        Some(s.trim_end_matches('\0').to_string())
                    })
                    .unwrap_or_default();
                // Only show stormwall-managed root qdiscs (major == SW_TC_MAJOR)
                if parent == tc::TC_H_ROOT && (handle >> 16) == tc::SW_TC_MAJOR as u32 {
                    qdiscs.push((kind, handle, parent));
                }
            });

            if qdiscs.is_empty() { continue; }
            found_any = true;

            // Print root qdisc info in pfctl -s queue format
            for (kind, handle, _parent) in &qdiscs {
                println!("queue root_{} on {} {} {}",
                    ifname, ifname, kind, tc::format_handle(*handle));
            }

            // Dump classes
            let class_data = match tc::dump_classes(&mut tc_sock, ifindex) {
                Ok(d) => d,
                Err(_) => continue,
            };

            let _ = tc::process_tc_response(&class_data, |_mtype, _ifidx, handle, parent, _info, attrs| {
                // Only show classes under our managed root (major == SW_TC_MAJOR)
                if (parent >> 16) != tc::SW_TC_MAJOR as u32 && (handle >> 16) != tc::SW_TC_MAJOR as u32 {
                    return;
                }
                let tca = tc::parse_tca_attrs(attrs);
                let kind = tca.iter()
                    .find(|(t, _)| *t == tc::TCA_KIND)
                    .and_then(|(_, v)| {
                        let s = std::str::from_utf8(v).ok()?;
                        Some(s.trim_end_matches('\0').to_string())
                    })
                    .unwrap_or_default();

                let minor = handle & 0xFFFF;
                println!("  queue class_{:x} on {} {} handle {} parent {}",
                    minor, ifname, kind,
                    tc::format_handle(handle), tc::format_handle(parent));
            });
        }

        if !found_any {
            println!("No ALTQ support in kernel");
        }
    }
    #[cfg(not(target_os = "linux"))]
    { println!("No ALTQ support in kernel"); }
}

// ── Table operations ──────────────────────────────────────────────

fn cmd_table(table: &str, subcmd: &str, addrs: &[String]) {
    #[cfg(not(target_os = "linux"))]
    let _ = (table, addrs);
    match subcmd {
        "show" => {
            #[cfg(target_os = "linux")]
            { list_object(parser::CmdObj::Set, netlink::NFPROTO_IPV4, "pf", table); }
        }
        "add" => {
            if addrs.is_empty() {
                eprintln!("pfctl: -T add requires addresses");
                process::exit(1);
            }
            #[cfg(target_os = "linux")]
            {
                let mut cmds = Vec::new();
                for addr_str in addrs {
                    if let Ok(addr) = parse_ipv4_simple(addr_str) {
                        let mut cmd = parser::Command::default();
                        cmd.op = parser::CmdOp::Add;
                        cmd.obj = parser::CmdObj::Element;
                        cmd.family = netlink::NFPROTO_IPV4;
                        cmd.table = "pf".to_string();
                        cmd.set_name = table.to_string();
                        cmd.elements = vec![(addr.to_vec(), None)];
                        cmds.push(cmd);
                    } else {
                        eprintln!("pfctl: invalid address: {}", addr_str);
                    }
                }
                if let Err(e) = apply_commands(&cmds) {
                    eprintln!("pfctl: table add error: {}", e);
                    process::exit(1);
                }
            }
            println!("{}/{} addresses added.", addrs.len(), addrs.len());
        }
        "delete" => {
            if addrs.is_empty() {
                eprintln!("pfctl: -T delete requires addresses");
                process::exit(1);
            }
            #[cfg(target_os = "linux")]
            {
                let mut cmds = Vec::new();
                for addr_str in addrs {
                    if let Ok(addr) = parse_ipv4_simple(addr_str) {
                        let mut cmd = parser::Command::default();
                        cmd.op = parser::CmdOp::Delete;
                        cmd.obj = parser::CmdObj::Element;
                        cmd.family = netlink::NFPROTO_IPV4;
                        cmd.table = "pf".to_string();
                        cmd.set_name = table.to_string();
                        cmd.elements = vec![(addr.to_vec(), None)];
                        cmds.push(cmd);
                    }
                }
                if let Err(e) = apply_commands(&cmds) {
                    eprintln!("pfctl: table delete error: {}", e);
                    process::exit(1);
                }
            }
            println!("{}/{} addresses deleted.", addrs.len(), addrs.len());
        }
        "flush" => {
            #[cfg(target_os = "linux")]
            {
                let mut cmd = parser::Command::default();
                cmd.op = parser::CmdOp::Flush;
                cmd.obj = parser::CmdObj::Set;
                cmd.family = netlink::NFPROTO_IPV4;
                cmd.table = "pf".to_string();
                cmd.set_name = table.to_string();
                if let Err(e) = apply_commands(&[cmd]) {
                    eprintln!("pfctl: table flush error: {}", e);
                    process::exit(1);
                }
            }
            println!("0 addresses deleted.");
        }
        "kill" => {
            // Destroy a table entirely.
            #[cfg(target_os = "linux")]
            {
                let mut cmd = parser::Command::default();
                cmd.op = parser::CmdOp::Delete;
                cmd.obj = parser::CmdObj::Set;
                cmd.family = netlink::NFPROTO_IPV4;
                cmd.table = "pf".to_string();
                cmd.set_name = table.to_string();
                if let Err(e) = apply_commands(&[cmd]) {
                    eprintln!("pfctl: table kill error: {}", e);
                    process::exit(1);
                }
            }
            println!("1 table destroyed.");
        }
        other => {
            eprintln!("pfctl: unknown -T subcommand: {}", other);
            process::exit(1);
        }
    }
}

// ── Kill states ───────────────────────────────────────────────────
//
// pfSense calls us in three main forms:
//   pfctl -k <host>                    — kill all states for a host
//   pfctl -M -k label -k <label>       — kill by label (no-op on Linux)
//   pfctl -M -k gateway -k <ip>        — kill by gateway (treated as host)
//
// On Linux we translate "kill states for <ip>" into:
//   1. conntrack -D -s <ip>  +  conntrack -D -d <ip>   (preferred)
//   2. /proc/net/nf_conntrack scan + count (fallback when conntrack(8)
//      is absent — reports the match count but cannot delete without
//      a raw netlink socket)

fn cmd_kill_states(kill_args: &[String]) {
    // Determine which IP(s) to kill.
    // kill_args comes from repeated -k flags; each -k consumes one value.
    // Forms we handle:
    //   ["label", "<str>"]   — no host to kill; ignore silently
    //   ["gateway", "<ip>"]  — treat <ip> as the host to kill
    //   ["<ip>"]             — direct host kill
    //   ["<ip1>", "<ip2>"]   — two -k flags: src=<ip1>, dst=<ip2>
    let targets: Vec<String> = extract_kill_targets(kill_args);

    if targets.is_empty() {
        // label-based kill or unrecognised form — nothing to do on Linux.
        println!("killed 0 states from 0 sources and 0 destinations");
        return;
    }

    // Try conntrack(8) first; fall back to /proc counting.
    let killed = if conntrack_available() {
        kill_via_conntrack(&targets)
    } else {
        count_via_proc(&targets)
    };

    println!("killed {} states from {} sources and {} destinations",
        killed, targets.len(), targets.len());
}

/// Extract the target IP addresses from kill_args.
fn extract_kill_targets(kill_args: &[String]) -> Vec<String> {
    // "label" and "gateway" are keyword qualifiers in pfSense.
    // ["label", <str>]  -> no IP target
    // ["gateway", <ip>] -> target is <ip>
    // everything else   -> each element is an IP target
    if kill_args.is_empty() {
        return Vec::new();
    }
    if kill_args[0] == "label" {
        return Vec::new();
    }
    if kill_args[0] == "gateway" {
        return kill_args.get(1).cloned().into_iter().collect();
    }
    kill_args.to_vec()
}

/// Return true when conntrack(8) is in PATH and executable.
fn conntrack_available() -> bool {
    process::Command::new("conntrack")
        .arg("--version")
        .stdout(process::Stdio::null())
        .stderr(process::Stdio::null())
        .status()
        .map(|s| s.success())
        .unwrap_or(false)
}

/// Kill conntrack entries matching each target via conntrack(8).
/// Returns the total number of flows destroyed.
fn kill_via_conntrack(targets: &[String]) -> u64 {
    let mut total: u64 = 0;
    for ip in targets {
        // Kill flows where this IP is the source.
        total += run_conntrack_delete(&["-D", "-s", ip]);
        // Kill flows where this IP is the destination.
        total += run_conntrack_delete(&["-D", "-d", ip]);
    }
    total
}

/// Run one `conntrack <args>` invocation and return the destroyed count
/// parsed from its output ("N flows destroyed, M could not be destroyed").
fn run_conntrack_delete(args: &[&str]) -> u64 {
    let result = process::Command::new("conntrack")
        .args(args)
        .output();
    let out = match result {
        Ok(o) => o,
        Err(_) => return 0,
    };
    // conntrack(8) prints to stderr: "N flows destroyed, M could not be destroyed."
    let text = String::from_utf8_lossy(&out.stderr).into_owned()
        + &String::from_utf8_lossy(&out.stdout);
    parse_conntrack_destroyed(&text)
}

/// Parse "N flows destroyed" from conntrack output.
fn parse_conntrack_destroyed(text: &str) -> u64 {
    // Expected: "3 flows destroyed, 0 could not be destroyed."
    // Grab the first whitespace-delimited token that parses as a u64.
    for token in text.split_whitespace() {
        if let Ok(n) = token.parse::<u64>() {
            return n;
        }
    }
    0
}

/// Fallback when conntrack(8) is absent: read /proc/net/nf_conntrack and
/// count entries that mention the target IP as src or dst.  We cannot
/// delete entries here (that requires a raw netlink socket), so we report
/// the count so pfSense logs a meaningful number.
fn count_via_proc(targets: &[String]) -> u64 {
    let content = match fs::read_to_string("/proc/net/nf_conntrack") {
        Ok(c) => c,
        Err(_) => return 0,
    };
    let mut count: u64 = 0;
    for line in content.lines() {
        for ip in targets {
            let src_pat = format!("src={}", ip);
            let dst_pat = format!("dst={}", ip);
            if line.contains(src_pat.as_str()) || line.contains(dst_pat.as_str()) {
                count += 1;
                break; // count the line once even if ip appears twice
            }
        }
    }
    count
}

// ── Helpers ───────────────────────────────────────────────────────

fn parse_ipv4_simple(s: &str) -> Result<[u8; 4], String> {
    let parts: Vec<&str> = s.split('.').collect();
    if parts.len() != 4 {
        return Err(format!("invalid IPv4: {}", s));
    }
    let mut out = [0u8; 4];
    for (i, p) in parts.iter().enumerate() {
        out[i] = p.parse::<u8>().map_err(|e| format!("invalid octet: {}", e))?;
    }
    Ok(out)
}
