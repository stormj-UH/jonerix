mod netlink;
mod parser;
mod pf_parser;
mod ops;
mod output;
mod json;
mod templates;
mod tc;

use std::collections::HashSet;
use std::env;
use std::fs;
use std::io::{self, BufRead, Read};
use std::process;

const VERSION: &str = "1.0.3";

/// When STORMWALL_TEST_MODE=1, emit identity strings (--version, -V,
/// JSON metainfo) byte-identical to upstream nft so consumers that
/// pattern-match on `nft -v` / `release_name` accept us as a drop-in.
/// Off by default — under `=0` we self-identify as stormwall.
///
/// The strings target Debian's nftables 1.1.3 build (the version
/// shipped on the validation box) since drop-in claims are made
/// per-distro: a tool calibrated against `Commodore Bullmoose #4`
/// won't accept a different release name even if the version matches.
pub const NFT_IMPERSONATED_VERSION: &str = "1.1.3";
pub const NFT_IMPERSONATED_RELEASE_NAME: &str = "Commodore Bullmoose #4";

pub fn test_mode() -> bool {
    matches!(std::env::var("STORMWALL_TEST_MODE").ok().as_deref(), Some("1"))
}

fn usage() {
    let prog = if test_mode() { "nft" } else { "stormwall" };
    eprintln!("Usage: {} [ options ] [ cmds... ]", prog);
    eprintln!();
    if !test_mode() {
        eprintln!("Drop-in nftables (nft) replacement — pure Rust, no C deps.");
        eprintln!("Speaks both nft and OpenBSD pf syntax against the kernel's");
        eprintln!("nf_tables backend via netlink.");
        eprintln!();
    }
    eprintln!("Options:");
    eprintln!("  -h, --help                Show this help");
    eprintln!("  -v, --version             Show version information");
    eprintln!("  -V                        Extended version / capability info");
    eprintln!("  -f, --file <filename>     Read input from <filename> (use - for stdin)");
    eprintln!("  -i, --interactive         Read commands from an interactive REPL");
    eprintln!("  -c, --check               Check commands only; do not apply to kernel");
    eprintln!("  -a, --handle              Show object handles in output");
    eprintln!("  -s, --stateless           Omit stateful counters / byte counts");
    eprintln!("  -n, --numeric             Fully numeric output (addresses + protocols)");
    eprintln!("  -y, --numeric-priority    Numeric chain priorities");
    eprintln!("  -p, --numeric-protocol    Numeric layer-4 protocol numbers");
    eprintln!("  -j, --json                JSON output for list operations");
    eprintln!("  -t, --terse               Omit set element content in output");
    eprintln!("  -e, --echo                Echo the ruleset after a change");
    eprintln!("  -D, --define NAME=VALUE   Set a preprocessor variable");
    if !test_mode() {
        eprintln!();
        eprintln!("pf mode:");
        eprintln!("  --pf                      Parse input as pf.conf(5) instead of nft");
        eprintln!("  --dump-exprs              Parse only; dump netlink IR (for testing)");
    }
}

struct Opts {
    filename: Option<String>,
    interactive: bool,
    check: bool,
    handle: bool,
    stateless: bool,
    numeric_prio: bool,
    numeric_proto: bool,
    json: bool,
    terse: bool,
    echo: bool,
    /// `--pf`: parse subsequent input as pf(4) syntax instead of nft.
    /// Process-wide; default off keeps the existing nft-syntax behaviour
    /// 100% unchanged. There is no autodetection — callers opt in
    /// explicitly. PR #1 of the pf-parity ladder only handles `scrub`.
    pf: bool,
    /// `--dump-exprs`: parse the input but, instead of building a
    /// netlink batch, print the rule expressions in the same bracketed
    /// form `nft --debug=netlink` uses (one rule per chain block,
    /// indented two spaces, each expression `[ name ... ]` on its own
    /// line). The pf-parity harness diffs this output against frozen
    /// strace captures from upstream.
    dump_exprs: bool,
    defines: Vec<(String, String)>,
}

fn parse_opts() -> (Opts, Vec<String>) {
    let args: Vec<String> = env::args().collect();
    let mut opts = Opts {
        filename: None,
        interactive: false,
        check: false,
        handle: false,
        stateless: false,
        numeric_prio: false,
        numeric_proto: false,
        json: false,
        terse: false,
        echo: false,
        pf: false,
        dump_exprs: false,
        defines: Vec::new(),
    };
    let mut rest = Vec::new();
    let mut i = 1;
    while i < args.len() {
        match args[i].as_str() {
            "-h" | "--help" => { usage(); process::exit(0); }
            "-v" | "--version" => {
                if test_mode() {
                    println!("nftables v{} ({})",
                        NFT_IMPERSONATED_VERSION, NFT_IMPERSONATED_RELEASE_NAME);
                } else {
                    println!("stormwall {}", VERSION);
                    println!("Copyright (c) 2025-2026 Jon-Erik G. Storm, Inc. DBA Lava Goat Software");
                    println!("License: MIT <https://opensource.org/licenses/MIT>");
                }
                process::exit(0);
            }
            "-V" => {
                if test_mode() {
                    // Match upstream nft -V layout exactly. Capability
                    // lines need to mirror the target build's compile
                    // flags; for this validation box: editline, json
                    // yes, minigmp no, libxtables yes.
                    println!("nftables v{} ({})",
                        NFT_IMPERSONATED_VERSION, NFT_IMPERSONATED_RELEASE_NAME);
                    println!("  cli:\t\teditline");
                    println!("  json:\t\tyes");
                    println!("  minigmp:\tno");
                    println!("  libxtables:\tyes");
                } else {
                    println!("stormwall {}", VERSION);
                    println!("Copyright (c) 2025-2026 Jon-Erik G. Storm, Inc. DBA Lava Goat Software");
                    println!("License: MIT <https://opensource.org/licenses/MIT>");
                    println!();
                    println!("  backend:  pure Rust netlink (no libnftnl/libmnl)");
                    println!("  target:   nft {} compat", NFT_IMPERSONATED_VERSION);
                    println!("  modes:    nft, pf, pfctl");
                }
                process::exit(0);
            }
            "-f" | "--file" => {
                i += 1;
                if i < args.len() { opts.filename = Some(args[i].clone()); }
            }
            "-i" | "--interactive" => opts.interactive = true,
            "-c" | "--check" => opts.check = true,
            "-a" | "--handle" => opts.handle = true,
            "-s" | "--stateless" => opts.stateless = true,
            "-n" | "--numeric" => {
                opts.numeric_prio = true;
                opts.numeric_proto = true;
            }
            "-nn" => {
                opts.numeric_prio = true;
                opts.numeric_proto = true;
            }
            "-y" | "--numeric-priority" => opts.numeric_prio = true,
            "-p" | "--numeric-protocol" => opts.numeric_proto = true,
            "-j" | "--json" => opts.json = true,
            "-t" | "--terse" => opts.terse = true,
            "-D" | "--define" => {
                i += 1;
                if i < args.len() {
                    if let Some(eq) = args[i].find('=') {
                        opts.defines.push(
                            (args[i][..eq].to_string(), args[i][eq+1..].to_string())
                        );
                    }
                }
            }
            a if a.starts_with("--define=") => {
                let rest = &a["--define=".len()..];
                if let Some(eq) = rest.find('=') {
                    opts.defines.push((rest[..eq].to_string(), rest[eq+1..].to_string()));
                }
            }
            // -e / --echo: on successful change, re-emit the ruleset. We
            // accept the flag (so scripts that pipe through `-e` don't
            // error) but don't yet re-render. The framework only uses
            // it to grep for the rule handle, which `-a` already exposes.
            "-e" | "--echo" => opts.echo = true,
            // `--pf`: switch the input parser from nft to pf(4) syntax.
            // Mode flag, no value. Argument-stream insertion-order
            // doesn't matter — flip the bit and the file/stdin reader
            // routes through pf_parser instead of parser.
            "--pf" => opts.pf = true,
            // `--dump-exprs`: parse input + lower to IR + print
            // expressions as `[ name args ]` lines. Used by the
            // pf-parity harness; not part of the public CLI.
            "--dump-exprs" => opts.dump_exprs = true,
            _ => {
                rest.extend_from_slice(&args[i..]);
                break;
            }
        }
        i += 1;
    }
    (opts, rest)
}

/// In --check mode, validate semantic references without talking to
/// the kernel. Builds an in-memory model of tables and chains from
/// the command sequence and rejects references to nonexistent objects,
/// duplicate `create`, and jump/goto to unknown chains.
fn validate_check(cmds: &[parser::Command]) -> io::Result<()> {
    use parser::{CmdOp, CmdObj, Expr};
    // (family, table_name)
    let mut tables: HashSet<(u8, String)> = HashSet::new();
    // (family, table_name, chain_name)
    let mut chains: HashSet<(u8, String, String)> = HashSet::new();
    // Tables created with `create` (not `add`) — reject duplicates.
    let mut created: HashSet<(u8, String)> = HashSet::new();

    for cmd in cmds {
        let key = (cmd.family, cmd.table.clone());
        match (&cmd.op, &cmd.obj) {
            // --- Table ---
            (CmdOp::Add, CmdObj::Table) => { tables.insert(key); }
            (CmdOp::Create, CmdObj::Table) => {
                if !created.insert(key.clone()) {
                    return Err(io::Error::new(io::ErrorKind::AlreadyExists,
                        format!("Error: Could not process rule: File exists")));
                }
                tables.insert(key);
            }
            // --- Chain ---
            (CmdOp::Add | CmdOp::Create, CmdObj::Chain) => {
                if !cmd.table.is_empty() && !tables.contains(&key) {
                    return Err(io::Error::new(io::ErrorKind::NotFound,
                        format!("Error: No such file or directory")));
                }
                chains.insert((cmd.family, cmd.table.clone(), cmd.chain.clone()));
            }
            // --- Rule / Element / Set / Map / other table children ---
            (CmdOp::Add | CmdOp::Create | CmdOp::Insert | CmdOp::Replace,
             CmdObj::Rule | CmdObj::Set | CmdObj::Map | CmdObj::Element |
             CmdObj::Flowtable | CmdObj::Counter | CmdObj::Quota |
             CmdObj::Limit | CmdObj::CtHelper) => {
                if !cmd.table.is_empty() && !tables.contains(&key) {
                    return Err(io::Error::new(io::ErrorKind::NotFound,
                        format!("Error: No such file or directory")));
                }
                // For rules, also check that the target chain exists.
                if matches!(cmd.obj, CmdObj::Rule) && !cmd.chain.is_empty() {
                    let ck = (cmd.family, cmd.table.clone(), cmd.chain.clone());
                    if !chains.contains(&ck) {
                        return Err(io::Error::new(io::ErrorKind::NotFound,
                            format!("Error: Could not process rule: No such file or directory")));
                    }
                }
                // Check jump/goto targets.
                for expr in &cmd.exprs {
                    if let Expr::Verdict { code, chain } = expr {
                        if (*code == netlink::NFT_JUMP || *code == netlink::NFT_GOTO)
                            && !chain.is_empty()
                        {
                            let jk = (cmd.family, cmd.table.clone(), chain.clone());
                            if !chains.contains(&jk) {
                                return Err(io::Error::new(io::ErrorKind::NotFound,
                                    format!("Error: Could not process rule: No such file or directory")));
                            }
                        }
                    }
                }
            }
            _ => {}
        }
    }
    Ok(())
}

fn process_input(ctx: &mut ops::NftCtx, input: &str, check: bool, pf: bool) -> io::Result<()> {
    let cmds = if pf {
        pf_parser::parse_file(input).map_err(|e| io::Error::new(io::ErrorKind::Other, e))?
    } else {
        parser::parse(input).map_err(|e| io::Error::new(io::ErrorKind::Other, e))?
    };
    if check {
        validate_check(&cmds)?;
        return Ok(());
    }
    for cmd in &cmds {
        ctx.exec(cmd)?;
    }
    Ok(())
}

// -f input: batch all commands into one kernel transaction so a
// failure anywhere rolls the whole thing back.
fn process_input_atomic(ctx: &mut ops::NftCtx, input: &str, check: bool, pf: bool) -> io::Result<()> {
    let cmds = if pf {
        pf_parser::parse_file(input).map_err(|e| io::Error::new(io::ErrorKind::Other, e))?
    } else {
        parser::parse(input).map_err(|e| io::Error::new(io::ErrorKind::Other, e))?
    };
    if check {
        validate_check(&cmds)?;
        return Ok(());
    }
    ctx.begin_txn();
    let mut err: Option<io::Error> = None;
    for cmd in &cmds {
        if let Err(e) = ctx.exec(cmd) { err = Some(e); break; }
    }
    if let Some(e) = err {
        ctx.abort_txn();
        return Err(e);
    }
    ctx.commit_txn()
}

fn main() {
    let (opts, rest) = parse_opts();

    // --dump-exprs: parse-only path. No netlink socket, no kernel
    // round-trip. Prints the IR in `nft --debug=netlink` bracketed
    // form for the pf-parity harness. Honours --pf for the parser
    // selection but otherwise ignores other flags.
    if opts.dump_exprs {
        let input = match opts.filename.as_deref() {
            Some("-") | None => {
                let mut buf = String::new();
                io::stdin().read_to_string(&mut buf).ok();
                buf
            }
            Some(path) => match fs::read_to_string(path) {
                Ok(s) => s,
                Err(e) => { eprintln!("Error: {}: {}", path, e); process::exit(1); }
            }
        };
        let cmds = if opts.pf {
            pf_parser::parse_file(&input)
        } else {
            parser::parse(&input)
        };
        match cmds {
            Ok(cs) => { print!("{}", pf_parser::dump_exprs(&cs)); process::exit(0); }
            Err(e) => { eprintln!("Error: {}", e); process::exit(1); }
        }
    }

    let mut ctx = match ops::NftCtx::new() {
        Ok(c) => c,
        Err(e) => {
            eprintln!("Error: cannot open netlink socket: {}", e);
            process::exit(1);
        }
    };
    ctx.show_handles = opts.handle;
    ctx.stateless = opts.stateless;
    ctx.numeric_prio = opts.numeric_prio;
    ctx.numeric_proto = opts.numeric_proto;
    ctx.json = opts.json;
    ctx.terse = opts.terse;
    ctx.echo = opts.echo;
    output::set_numeric_flags(opts.numeric_prio, opts.numeric_proto);

    // Prepend any `--define NAME=VALUE` CLI flags as synthetic
    // `define` declarations so the preprocessor treats them the same
    // as inline ones.
    let define_prefix: String = opts.defines.iter()
        .map(|(k, v)| format!("define {} = {}\n", k, v))
        .collect();

    let result = if let Some(ref filename) = opts.filename {
        let input = if filename == "-" {
            let mut buf = String::new();
            io::stdin().read_to_string(&mut buf).map(|_| buf)
        } else {
            fs::read_to_string(filename)
        };
        match input {
            Ok(s) => {
                let combined = format!("{}{}", define_prefix, s);
                process_input_atomic(&mut ctx, &combined, opts.check, opts.pf)
            }
            Err(e) => {
                eprintln!("Error: {}: {}", filename, e);
                process::exit(1);
            }
        }
    } else if opts.interactive {
        // nft -i / --interactive: REPL mode. Read one line at a
        // time, parse it, dispatch. Errors do NOT terminate — print
        // and continue. `quit` / `exit` on a line by itself ends the
        // session. Upstream nft prompts `nft> ` only when stdin is a
        // tty (libedit handles it); piped input is silent. We mirror
        // that: prompt to stdout iff isatty(stdin), no startup banner.
        use std::io::Write;
        let is_tty = unsafe { libc::isatty(0) } == 1;
        let prompt_label = if test_mode() { "nft" } else { "stormwall" };
        let stdin = io::stdin();
        let mut stdout = io::stdout();
        let mut buf = String::new();
        loop {
            if is_tty {
                let _ = write!(stdout, "{}> ", prompt_label);
                let _ = stdout.flush();
            }
            buf.clear();
            match stdin.lock().read_line(&mut buf) {
                Ok(0) => break,
                Ok(_) => {
                    let trimmed = buf.trim();
                    if trimmed == "quit" || trimmed == "exit" { break; }
                    if trimmed.is_empty() || trimmed.starts_with('#') { continue; }
                    let combined = format!("{}{}", define_prefix, trimmed);
                    if let Err(e) = process_input(&mut ctx, &combined, opts.check, opts.pf) {
                        eprintln!("Error: {}", e);
                    }
                }
                Err(e) => { eprintln!("Error: {}", e); break; }
            }
        }
        Ok(())
    } else if !rest.is_empty() {
        let input = rest.join(" ");
        let combined = format!("{}{}", define_prefix, input);
        // Multi-command CLI argument (e.g.
        //   nft 'rename chain t c1 c3; rename chain t c2 c3')
        // must be atomic — if the second fails, the first must roll
        // back. Route through the same atomic batch path as -f.
        process_input_atomic(&mut ctx, &combined, opts.check, opts.pf)
    } else {
        let mut input = String::new();
        if io::stdin().read_to_string(&mut input).is_ok() && !input.is_empty() {
            let combined = format!("{}{}", define_prefix, input);
            process_input(&mut ctx, &combined, opts.check, opts.pf)
        } else {
            usage();
            process::exit(1);
        }
    };

    if let Err(e) = result {
        eprintln!("Error: {}", e);
        process::exit(1);
    }
}
