//! Traffic-control (tc) netlink client for NETLINK_ROUTE.
//!
//! This module talks the rtnetlink tc protocol — a separate netlink
//! family from NETLINK_NETFILTER.  It reuses the generic NlSocket and
//! MsgBuilder primitives from netlink.rs but writes tcmsg headers
//! instead of nfgenmsg, and uses RTM_* message types directly
//! instead of packing an NFNL subsystem byte.
//!
//! ## Class-ID convention
//!
//! stormwall allocates one root qdisc per egress interface with major
//! handle 0x0001 (displayed as `1:` by iproute2).  Named queues from
//! pf declarations get minor numbers starting at 0x0010:
//!
//!     +------------------+---------------------+
//!     | root qdisc  1:0  | (hfsc / htb / prio) |
//!     +------------------+---------------------+
//!              |
//!     +--------+--------+---------+
//!     | class 1:10      | class 1:11      | ...
//!     | "bulk"          | "urgent"        |
//!     | bw 10mbit       | bw 50mbit       |
//!     +-----------------+-----------------+
//!
//! skb->priority is set by the nftables rule via
//! `meta priority set TC_H_MAKE(1, minor)` = `0x0001_00xx`.
//! A `tc filter` of kind `basic` matches this and dispatches to the
//! correct class.

use std::io;

use crate::netlink::{
    self, align4, MsgBuilder, NlSocket,
    NLM_F_REQUEST, NLM_F_ACK, NLM_F_CREATE, NLM_F_EXCL, NLM_F_DUMP,
};

// ── rtnetlink message types for tc ─────────────────────────────
pub const NETLINK_ROUTE: i32 = 0;

pub const RTM_NEWQDISC:   u16 = 36;
pub const RTM_DELQDISC:   u16 = 37;
pub const RTM_GETQDISC:   u16 = 38;
pub const RTM_NEWTCLASS:  u16 = 40;
pub const RTM_DELTCLASS:  u16 = 41;
pub const RTM_GETTCLASS:  u16 = 42;
pub const RTM_NEWTFILTER: u16 = 44;
pub const RTM_DELTFILTER: u16 = 45;
pub const RTM_GETTFILTER: u16 = 46;

// ── TCA attributes ─────────────────────────────────────────────
pub const TCA_UNSPEC:  u16 = 0;
pub const TCA_KIND:    u16 = 1;
pub const TCA_OPTIONS: u16 = 2;
pub const TCA_STATS:   u16 = 3;
pub const TCA_XSTATS:  u16 = 4;
pub const TCA_RATE:    u16 = 5;
pub const TCA_FCNT:    u16 = 6;
pub const TCA_STATS2:  u16 = 7;
pub const TCA_STAB:    u16 = 8;

// ── tc handle helpers ──────────────────────────────────────────
/// Compose a tc handle from major:minor.  tc uses `(major << 16) | minor`.
pub const fn tc_handle(major: u16, minor: u16) -> u32 {
    ((major as u32) << 16) | (minor as u32)
}

/// Root qdisc handle.
pub const TC_H_ROOT: u32 = 0xFFFF_FFFF;
pub const TC_H_UNSPEC: u32 = 0;
pub const TC_H_INGRESS: u32 = 0xFFFF_FFF1;

// stormwall's default major for managed root qdiscs.
pub const SW_TC_MAJOR: u16 = 1;

// ── HTB constants ──────────────────────────────────────────────
pub const TCA_HTB_UNSPEC:  u16 = 0;
pub const TCA_HTB_PARMS:   u16 = 1;
pub const TCA_HTB_INIT:    u16 = 2;
pub const TCA_HTB_CTAB:    u16 = 3;
pub const TCA_HTB_RTAB:    u16 = 4;
pub const TCA_HTB_DIRECT_QLEN: u16 = 5;
pub const TCA_HTB_RATE64:  u16 = 6;
pub const TCA_HTB_CEIL64:  u16 = 7;

/// Size of tc_htb_opt on the wire (48 bytes).
pub const TC_HTB_OPT_SIZE: usize = 48;

/// Size of tc_htb_glob on the wire (20 bytes).
pub const TC_HTB_GLOB_SIZE: usize = 20;

// ── HFSC constants ─────────────────────────────────────────────
pub const TCA_HFSC_RSC: u16 = 1; // realtime service curve
pub const TCA_HFSC_FSC: u16 = 2; // fair/linkshare service curve
pub const TCA_HFSC_USC: u16 = 3; // upperlimit service curve

/// tc_service_curve: { m1: u32, d: u32, m2: u32 } = 12 bytes.
pub const TC_SERVICE_CURVE_SIZE: usize = 12;

// ── PRIO constants ─────────────────────────────────────────────
/// tc_prio_qopt: { bands: i32, priomap: [u8; 16] } = 20 bytes.
pub const TC_PRIO_QOPT_SIZE: usize = 20;

// ── pfifo / bfifo constants ────────────────────────────────────
/// tc_fifo_qopt: { limit: u32 } = 4 bytes (inside TCA_OPTIONS).
pub const TC_FIFO_QOPT_SIZE: usize = 4;

// ── tc_ratespec (shared by HTB/TBF/CBQ) ────────────────────────
/// struct tc_ratespec { cell_log, linklayer, overhead, cell_align,
///   mpu, rate } = 12 bytes.
pub const TC_RATESPEC_SIZE: usize = 12;

// ── basic filter constants ─────────────────────────────────────
pub const TCA_BASIC_UNSPEC:  u16 = 0;
pub const TCA_BASIC_CLASSID: u16 = 1;
pub const TCA_BASIC_EMATCHES: u16 = 2;
pub const TCA_BASIC_ACT:     u16 = 3;
pub const TCA_BASIC_POLICE:  u16 = 4;

// ── TcSocket ───────────────────────────────────────────────────

/// Thin wrapper around NlSocket opened for NETLINK_ROUTE.
pub struct TcSocket {
    sock: NlSocket,
}

impl TcSocket {
    pub fn open() -> io::Result<Self> {
        let sock = NlSocket::open_protocol(NETLINK_ROUTE)?;
        Ok(TcSocket { sock })
    }

    /// Send a fully-built tc message buffer and check for ACK.
    /// When STORMWALL_NLDUMP is set, the send is short-circuited to
    /// the dump file just like the nftables path.
    pub fn send_and_ack(&mut self, buf: &[u8]) -> io::Result<()> {
        self.sock.send(buf)?;

        // Under NLDUMP mode, send() short-circuits — no recv needed.
        if std::env::var("STORMWALL_NLDUMP").is_ok() {
            return Ok(());
        }

        let mut recv_buf = vec![0u8; 65536];
        let n = self.sock.recv(&mut recv_buf)?;
        netlink::check_ack(&recv_buf[..n])
    }

    /// Raw send without ACK check (for dump requests).
    pub fn send_raw(&mut self, buf: &[u8]) -> io::Result<()> {
        self.sock.send(buf)?;
        Ok(())
    }

    /// Recv into a caller-owned buffer.
    pub fn recv(&mut self, buf: &mut [u8]) -> io::Result<usize> {
        self.sock.recv(buf)
    }
}

// ── TcMsgBuilder ───────────────────────────────────────────────

/// Builds rtnetlink tc messages.  Wraps MsgBuilder for NLA encoding
/// and adds tcmsg header writing.  Unlike nftables, tc does not use
/// batch wrappers — each message is its own transaction.
pub struct TcMsgBuilder {
    pub mb: MsgBuilder,
}

impl TcMsgBuilder {
    pub fn new() -> Self {
        TcMsgBuilder { mb: MsgBuilder::new() }
    }

    /// Begin a tc message.  Returns position of nlmsghdr for end_msg fixup.
    ///
    /// Writes nlmsghdr (16 bytes) + tcmsg (20 bytes) = 36 bytes of header.
    /// The caller then appends NLA attributes via self.mb.put_* and calls
    /// end_msg(pos) to fix the nlmsghdr length.
    pub fn begin_msg(
        &mut self,
        msg_type: u16,
        flags: u16,
        ifindex: i32,
        handle: u32,
        parent: u32,
        info: u32,
    ) -> usize {
        let pos = self.mb.buf.len();
        self.mb.write_nlmsghdr(0, msg_type, NLM_F_REQUEST | flags);
        // tcmsg: 20 bytes
        self.mb.buf.push(0);                                        // tcm_family (AF_UNSPEC)
        self.mb.buf.push(0);                                        // __pad1
        self.mb.buf.extend_from_slice(&0u16.to_ne_bytes());         // __pad2
        self.mb.buf.extend_from_slice(&ifindex.to_ne_bytes());      // tcm_ifindex
        self.mb.buf.extend_from_slice(&handle.to_ne_bytes());       // tcm_handle
        self.mb.buf.extend_from_slice(&parent.to_ne_bytes());       // tcm_parent
        self.mb.buf.extend_from_slice(&info.to_ne_bytes());         // tcm_info
        pos
    }

    /// Fix up the nlmsghdr length at a position returned by begin_msg.
    pub fn end_msg(&mut self, pos: usize) {
        self.mb.end_msg(pos);
    }

    /// Finish and return the raw buffer.
    pub fn finish(self) -> Vec<u8> {
        self.mb.finish()
    }
}

// ── High-level tc operations ───────────────────────────────────

/// Queueing discipline variant.
#[derive(Debug, Clone, Copy, PartialEq)]
pub enum QdiscKind {
    Htb,
    Hfsc,
    Prio,
    Pfifo,
    Bfifo,
    FqCodel,
}

impl QdiscKind {
    pub fn as_str(&self) -> &'static str {
        match self {
            QdiscKind::Htb => "htb",
            QdiscKind::Hfsc => "hfsc",
            QdiscKind::Prio => "prio",
            QdiscKind::Pfifo => "pfifo",
            QdiscKind::Bfifo => "bfifo",
            QdiscKind::FqCodel => "fq_codel",
        }
    }
}

/// HFSC service curve: { m1, d, m2 }.
///  - m1: initial slope (bytes/sec), 0 for single-rate
///  - d:  delay before switching to m2 (microseconds)
///  - m2: long-term slope (bytes/sec)
#[derive(Debug, Clone, Copy, Default)]
pub struct ServiceCurve {
    pub m1: u32,
    pub d: u32,
    pub m2: u32,
}

impl ServiceCurve {
    /// Encode as 12 bytes in kernel wire format.
    pub fn encode(&self) -> [u8; 12] {
        let mut buf = [0u8; 12];
        buf[0..4].copy_from_slice(&self.m1.to_ne_bytes());
        buf[4..8].copy_from_slice(&self.d.to_ne_bytes());
        buf[8..12].copy_from_slice(&self.m2.to_ne_bytes());
        buf
    }
}

/// tc_ratespec used by HTB.
#[derive(Debug, Clone, Copy, Default)]
pub struct RateSpec {
    pub cell_log: u8,
    pub linklayer: u8,
    pub overhead: u16,
    pub cell_align: i16,
    pub mpu: u16,
    pub rate: u32,
}

impl RateSpec {
    /// Encode as 12 bytes.
    pub fn encode(&self) -> [u8; 12] {
        let mut buf = [0u8; 12];
        buf[0] = self.cell_log;
        buf[1] = self.linklayer;
        buf[2..4].copy_from_slice(&self.overhead.to_ne_bytes());
        buf[4..6].copy_from_slice(&self.cell_align.to_ne_bytes());
        buf[6..8].copy_from_slice(&self.mpu.to_ne_bytes());
        buf[8..12].copy_from_slice(&self.rate.to_ne_bytes());
        buf
    }
}

// ── Qdisc add/delete operations ────────────────────────────────

/// Add a root HTB qdisc on an interface.
///
/// `default_class` is the minor number of the default class (e.g. 0x10).
/// Packets that don't match any filter land here.
pub fn add_htb_root(tc: &mut TcSocket, ifindex: i32, default_class: u16) -> io::Result<()> {
    let mut b = TcMsgBuilder::new();
    let pos = b.begin_msg(
        RTM_NEWQDISC,
        NLM_F_ACK | NLM_F_CREATE | NLM_F_EXCL,
        ifindex,
        tc_handle(SW_TC_MAJOR, 0), // handle 1:0
        TC_H_ROOT,                 // parent = root
        0,                         // info
    );

    b.mb.put_str(TCA_KIND, "htb");

    // TCA_OPTIONS nest: tc_htb_glob (TCA_HTB_INIT)
    let opts = b.mb.begin_nested(TCA_OPTIONS);
    {
        // tc_htb_glob: { version: u32, rate2quantum: u32, defcls: u32,
        //                debug: u32, direct_pkts: u32 } = 20 bytes
        let mut glob = [0u8; TC_HTB_GLOB_SIZE];
        // version = 3 (current HTB version)
        glob[0..4].copy_from_slice(&3u32.to_ne_bytes());
        // rate2quantum = 10 (default)
        glob[4..8].copy_from_slice(&10u32.to_ne_bytes());
        // defcls = default class minor
        glob[8..12].copy_from_slice(&(default_class as u32).to_ne_bytes());
        // debug = 0, direct_pkts = 0
        b.mb.put_bytes(TCA_HTB_INIT, &glob);
    }
    b.mb.end_nested(opts);

    b.end_msg(pos);
    tc.send_and_ack(&b.finish())
}

/// Add an HTB class under a parent.
///
/// `rate_bps` and `ceil_bps` are in bytes/sec.  Both the legacy 32-bit
/// tc_ratespec and the 64-bit TCA_HTB_RATE64/CEIL64 attributes are
/// emitted for kernel compatibility (see design doc §6.4).
pub fn add_htb_class(
    tc: &mut TcSocket,
    ifindex: i32,
    parent: u32,
    classid: u32,
    rate_bps: u64,
    ceil_bps: u64,
) -> io::Result<()> {
    let mut b = TcMsgBuilder::new();
    let pos = b.begin_msg(
        RTM_NEWTCLASS,
        NLM_F_ACK | NLM_F_CREATE | NLM_F_EXCL,
        ifindex,
        classid,
        parent,
        0,
    );

    b.mb.put_str(TCA_KIND, "htb");

    // TCA_OPTIONS nest
    let opts = b.mb.begin_nested(TCA_OPTIONS);
    {
        // tc_htb_opt: { rate: tc_ratespec(12), ceil: tc_ratespec(12),
        //   buffer: u32, cbuffer: u32, quantum: u32, level: u32,
        //   prio: u32 } — but kernel only reads the first 48 bytes
        // tc_htb_opt = rate_ratespec(12) + ceil_ratespec(12) + 6*u32(24) = 48
        let rate32 = if rate_bps > u32::MAX as u64 { u32::MAX } else { rate_bps as u32 };
        let ceil32 = if ceil_bps > u32::MAX as u64 { u32::MAX } else { ceil_bps as u32 };

        let rate_spec = RateSpec { rate: rate32, ..Default::default() };
        let ceil_spec = RateSpec { rate: ceil32, ..Default::default() };

        let mut htb_opt = [0u8; TC_HTB_OPT_SIZE];
        htb_opt[0..12].copy_from_slice(&rate_spec.encode());
        htb_opt[12..24].copy_from_slice(&ceil_spec.encode());
        // buffer, cbuffer: kernel computes from rate if zero
        // quantum: 0 = auto
        // level: 0 = leaf
        // prio: 0 = default

        b.mb.put_bytes(TCA_HTB_PARMS, &htb_opt);

        // 64-bit rate overrides for > 4 Gbps links
        if rate_bps > u32::MAX as u64 {
            b.mb.put_u64(TCA_HTB_RATE64, rate_bps);
        }
        if ceil_bps > u32::MAX as u64 {
            b.mb.put_u64(TCA_HTB_CEIL64, ceil_bps);
        }
    }
    b.mb.end_nested(opts);

    b.end_msg(pos);
    tc.send_and_ack(&b.finish())
}

/// Add a root HFSC qdisc on an interface.
///
/// `default_class` is the minor number of the default class.
pub fn add_hfsc_root(tc: &mut TcSocket, ifindex: i32, default_class: u16) -> io::Result<()> {
    let mut b = TcMsgBuilder::new();
    let pos = b.begin_msg(
        RTM_NEWQDISC,
        NLM_F_ACK | NLM_F_CREATE | NLM_F_EXCL,
        ifindex,
        tc_handle(SW_TC_MAJOR, 0),
        TC_H_ROOT,
        0,
    );

    b.mb.put_str(TCA_KIND, "hfsc");

    // TCA_OPTIONS: tc_hfsc_qopt { defcls: u16 } — 2 bytes, padded to 4.
    let opts = b.mb.begin_nested(TCA_OPTIONS);
    {
        let mut qopt = [0u8; 4];
        qopt[0..2].copy_from_slice(&default_class.to_ne_bytes());
        b.mb.put_bytes(TCA_UNSPEC + 1, &qopt); // raw option blob, no nested attr
    }
    b.mb.end_nested(opts);

    b.end_msg(pos);
    tc.send_and_ack(&b.finish())
}

/// Add an HFSC class with service curves.
///
/// Any of rsc/fsc/usc may be None.  At least one must be Some.
pub fn add_hfsc_class(
    tc: &mut TcSocket,
    ifindex: i32,
    parent: u32,
    classid: u32,
    rsc: Option<ServiceCurve>,
    fsc: Option<ServiceCurve>,
    usc: Option<ServiceCurve>,
) -> io::Result<()> {
    let mut b = TcMsgBuilder::new();
    let pos = b.begin_msg(
        RTM_NEWTCLASS,
        NLM_F_ACK | NLM_F_CREATE | NLM_F_EXCL,
        ifindex,
        classid,
        parent,
        0,
    );

    b.mb.put_str(TCA_KIND, "hfsc");

    let opts = b.mb.begin_nested(TCA_OPTIONS);
    {
        if let Some(curve) = rsc {
            b.mb.put_bytes(TCA_HFSC_RSC, &curve.encode());
        }
        if let Some(curve) = fsc {
            b.mb.put_bytes(TCA_HFSC_FSC, &curve.encode());
        }
        if let Some(curve) = usc {
            b.mb.put_bytes(TCA_HFSC_USC, &curve.encode());
        }
    }
    b.mb.end_nested(opts);

    b.end_msg(pos);
    tc.send_and_ack(&b.finish())
}

/// Add a root PRIO qdisc.
///
/// `bands` is the number of priority bands (typically 3).
/// `priomap` is a 16-element array mapping skb priority (0..15) to band.
pub fn add_prio_root(
    tc: &mut TcSocket,
    ifindex: i32,
    bands: i32,
    priomap: &[u8; 16],
) -> io::Result<()> {
    let mut b = TcMsgBuilder::new();
    let pos = b.begin_msg(
        RTM_NEWQDISC,
        NLM_F_ACK | NLM_F_CREATE | NLM_F_EXCL,
        ifindex,
        tc_handle(SW_TC_MAJOR, 0),
        TC_H_ROOT,
        0,
    );

    b.mb.put_str(TCA_KIND, "prio");

    // TCA_OPTIONS: tc_prio_qopt { bands: i32, priomap: [u8; 16] }
    let opts = b.mb.begin_nested(TCA_OPTIONS);
    {
        let mut qopt = [0u8; TC_PRIO_QOPT_SIZE];
        qopt[0..4].copy_from_slice(&bands.to_ne_bytes());
        qopt[4..20].copy_from_slice(priomap);
        // prio qopt is the raw body, not a nested attr
        b.mb.buf.extend_from_slice(&qopt);
    }
    b.mb.end_nested(opts);

    b.end_msg(pos);
    tc.send_and_ack(&b.finish())
}

/// Add a pfifo leaf qdisc under a class.
pub fn add_pfifo_leaf(
    tc: &mut TcSocket,
    ifindex: i32,
    parent: u32,
    handle: u32,
    limit: u32,
) -> io::Result<()> {
    let mut b = TcMsgBuilder::new();
    let pos = b.begin_msg(
        RTM_NEWQDISC,
        NLM_F_ACK | NLM_F_CREATE | NLM_F_EXCL,
        ifindex,
        handle,
        parent,
        0,
    );

    b.mb.put_str(TCA_KIND, "pfifo");

    // TCA_OPTIONS: tc_fifo_qopt { limit: u32 }
    let opts = b.mb.begin_nested(TCA_OPTIONS);
    {
        b.mb.buf.extend_from_slice(&limit.to_ne_bytes());
    }
    b.mb.end_nested(opts);

    b.end_msg(pos);
    tc.send_and_ack(&b.finish())
}

/// Delete the root qdisc on an interface (removes all classes and
/// filters underneath it).
pub fn del_root_qdisc(tc: &mut TcSocket, ifindex: i32) -> io::Result<()> {
    let mut b = TcMsgBuilder::new();
    let pos = b.begin_msg(
        RTM_DELQDISC,
        NLM_F_ACK,
        ifindex,
        0,
        TC_H_ROOT,
        0,
    );
    b.end_msg(pos);
    tc.send_and_ack(&b.finish())
}

/// Add a `basic` tc filter as a catch-all fallback dispatcher.
///
/// ## Why filters are usually unnecessary
///
/// Both HTB and HFSC do **native priority-based class lookup**: their
/// `htb_classify()` / `hfsc_classify()` functions check `skb->priority`
/// before consulting any filter chain.  If `skb->priority` is set to a
/// handle whose major matches the root qdisc (e.g. `0x0001_0010` for
/// class `1:10`), the packet goes directly to that class — no filter
/// needed.  Since nftables `meta priority set <handle>` writes exactly
/// that value into `skb->priority`, the data path works end-to-end
/// without any `RTM_NEWTFILTER` messages.
///
/// ## When this function IS useful
///
/// Call it to install a catch-all fallback for traffic that does NOT
/// have a priority marker set (i.e. packets that bypass the nftables
/// rules).  The filter routes them to `classid` unconditionally.
/// Use `filter_prio` to order multiple catch-all filters.
///
/// Protocol is ETH_P_ALL (0x0003) so it matches all L3 families.
pub fn add_basic_filter(
    tc: &mut TcSocket,
    ifindex: i32,
    parent: u32,
    classid: u32,
    filter_prio: u16,
) -> io::Result<()> {
    let mut b = TcMsgBuilder::new();
    let pos = b.begin_msg(
        RTM_NEWTFILTER,
        NLM_F_ACK | NLM_F_CREATE | NLM_F_EXCL,
        ifindex,
        0,
        parent,
        // info encodes: (prio << 16) | protocol. ETH_P_ALL=3.
        ((filter_prio as u32) << 16) | 3,
    );

    b.mb.put_str(TCA_KIND, "basic");

    let opts = b.mb.begin_nested(TCA_OPTIONS);
    b.mb.put_u32(TCA_BASIC_CLASSID, classid);
    b.mb.end_nested(opts);

    b.end_msg(pos);
    tc.send_and_ack(&b.finish())
}

/// Dump all qdiscs on an interface (RTM_GETQDISC with NLM_F_DUMP).
///
/// Returns the raw response bytes.  Caller parses with
/// `process_tc_response`.
pub fn dump_qdiscs(tc: &mut TcSocket, ifindex: i32) -> io::Result<Vec<u8>> {
    let mut b = TcMsgBuilder::new();
    let pos = b.begin_msg(
        RTM_GETQDISC,
        netlink::NLM_F_DUMP,
        ifindex,
        0,
        0,
        0,
    );
    b.end_msg(pos);
    tc.send_raw(&b.finish())?;

    let mut all = Vec::new();
    let mut buf = vec![0u8; 65536];
    loop {
        let n = tc.recv(&mut buf)?;
        let chunk = &buf[..n];
        all.extend_from_slice(chunk);
        // Check for NLMSG_DONE in this chunk
        let mut done = false;
        let mut p = 0;
        while p + 16 <= n {
            let len = u32::from_ne_bytes([chunk[p], chunk[p+1], chunk[p+2], chunk[p+3]]) as usize;
            let mtype = u16::from_ne_bytes([chunk[p+4], chunk[p+5]]);
            if mtype == netlink::NLMSG_DONE { done = true; break; }
            if len < 16 || p + len > n { break; }
            p += align4(len);
        }
        if done { break; }
    }
    Ok(all)
}

/// Dump all classes on an interface.
pub fn dump_classes(tc: &mut TcSocket, ifindex: i32) -> io::Result<Vec<u8>> {
    let mut b = TcMsgBuilder::new();
    let pos = b.begin_msg(
        RTM_GETTCLASS,
        netlink::NLM_F_DUMP,
        ifindex,
        0,
        0,
        0,
    );
    b.end_msg(pos);
    tc.send_raw(&b.finish())?;

    let mut all = Vec::new();
    let mut buf = vec![0u8; 65536];
    loop {
        let n = tc.recv(&mut buf)?;
        let chunk = &buf[..n];
        all.extend_from_slice(chunk);
        let mut done = false;
        let mut p = 0;
        while p + 16 <= n {
            let len = u32::from_ne_bytes([chunk[p], chunk[p+1], chunk[p+2], chunk[p+3]]) as usize;
            let mtype = u16::from_ne_bytes([chunk[p+4], chunk[p+5]]);
            if mtype == netlink::NLMSG_DONE { done = true; break; }
            if len < 16 || p + len > n { break; }
            p += align4(len);
        }
        if done { break; }
    }
    Ok(all)
}

/// Parse TCA attributes from a tc message payload.  Returns a Vec of
/// (type, data) pairs.
pub fn parse_tca_attrs(data: &[u8]) -> Vec<(u16, Vec<u8>)> {
    let mut attrs = Vec::new();
    let mut pos = 0;
    while pos + 4 <= data.len() {
        let nla_len = u16::from_ne_bytes([data[pos], data[pos+1]]) as usize;
        let nla_type = u16::from_ne_bytes([data[pos+2], data[pos+3]]);
        if nla_len < 4 || pos + nla_len > data.len() { break; }
        let payload = &data[pos+4..pos+nla_len];
        attrs.push((nla_type, payload.to_vec()));
        pos += align4(nla_len);
    }
    attrs
}

/// Format a tc handle as `major:minor` text.
pub fn format_handle(handle: u32) -> String {
    let major = handle >> 16;
    let minor = handle & 0xFFFF;
    if major == 0 && minor == 0 {
        "0:".to_string()
    } else if minor == 0 {
        format!("{}:", major)
    } else {
        format!("{}:{}", major, minor)
    }
}

// ── Process tc dump responses ──────────────────────────────────

/// Parse a tc dump response.  Handler receives (msg_type, ifindex,
/// handle, parent, info, attrs_data) for each tc message.
pub fn process_tc_response<F>(
    data: &[u8],
    mut handler: F,
) -> io::Result<bool>
where F: FnMut(u16, i32, u32, u32, u32, &[u8])
{
    let mut pos = 0;
    while pos + 16 <= data.len() {
        let nlmsg_len = u32::from_ne_bytes([data[pos], data[pos+1], data[pos+2], data[pos+3]]) as usize;
        let nlmsg_type = u16::from_ne_bytes([data[pos+4], data[pos+5]]);

        if nlmsg_len < 16 || pos + nlmsg_len > data.len() { break; }

        if nlmsg_type == netlink::NLMSG_DONE {
            return Ok(true);
        }

        if nlmsg_type == netlink::NLMSG_ERROR {
            if nlmsg_len >= 20 {
                let err = i32::from_ne_bytes([data[pos+16], data[pos+17], data[pos+18], data[pos+19]]);
                if err < 0 {
                    return Err(io::Error::from_raw_os_error(-err));
                }
            }
            pos += align4(nlmsg_len);
            continue;
        }

        // tc message: nlmsghdr(16) + tcmsg(20) + attrs
        if nlmsg_len >= 36 {
            let ifindex = i32::from_ne_bytes([data[pos+20], data[pos+21], data[pos+22], data[pos+23]]);
            let handle  = u32::from_ne_bytes([data[pos+24], data[pos+25], data[pos+26], data[pos+27]]);
            let parent  = u32::from_ne_bytes([data[pos+28], data[pos+29], data[pos+30], data[pos+31]]);
            let info    = u32::from_ne_bytes([data[pos+32], data[pos+33], data[pos+34], data[pos+35]]);
            let payload_start = pos + 36;
            let payload_end = pos + nlmsg_len;
            if payload_start <= payload_end && payload_end <= data.len() {
                handler(nlmsg_type, ifindex, handle, parent, info, &data[payload_start..payload_end]);
            }
        }

        pos += align4(nlmsg_len);
    }
    Ok(false)
}

// ── Modprobe helper ────────────────────────────────────────────

/// Try to load a kernel tc module via modprobe.  Called when a qdisc
/// add fails with ENOENT — the module might just not be auto-loaded.
/// Returns true if modprobe succeeded (or if the module was already
/// loaded), false otherwise.
pub fn try_modprobe(module: &str) -> bool {
    use std::process::Command;
    Command::new("modprobe")
        .arg(module)
        .status()
        .map(|s| s.success())
        .unwrap_or(false)
}

/// Resolve a network interface name to its ifindex.
pub fn ifindex_for_name(name: &str) -> io::Result<i32> {
    // Read /sys/class/net/<name>/ifindex
    let path = format!("/sys/class/net/{}/ifindex", name);
    let s = std::fs::read_to_string(&path)
        .map_err(|e| io::Error::new(e.kind(), format!("{}: {}", path, e)))?;
    s.trim().parse::<i32>()
        .map_err(|e| io::Error::new(io::ErrorKind::InvalidData, format!("{}: {}", path, e)))
}

// ── Unit tests ─────────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn tc_handle_encoding() {
        assert_eq!(tc_handle(1, 0), 0x0001_0000);
        assert_eq!(tc_handle(1, 0x10), 0x0001_0010);
        assert_eq!(tc_handle(0xFFFF, 0xFFFF), 0xFFFF_FFFF);
    }

    #[test]
    fn service_curve_encode() {
        let sc = ServiceCurve { m1: 0, d: 0, m2: 1_250_000 }; // 10 Mbit/s
        let enc = sc.encode();
        assert_eq!(u32::from_ne_bytes([enc[0], enc[1], enc[2], enc[3]]), 0);
        assert_eq!(u32::from_ne_bytes([enc[4], enc[5], enc[6], enc[7]]), 0);
        assert_eq!(u32::from_ne_bytes([enc[8], enc[9], enc[10], enc[11]]), 1_250_000);
    }

    #[test]
    fn ratespec_encode() {
        let rs = RateSpec { rate: 1_250_000, ..Default::default() };
        let enc = rs.encode();
        assert_eq!(enc.len(), 12);
        assert_eq!(u32::from_ne_bytes([enc[8], enc[9], enc[10], enc[11]]), 1_250_000);
    }

    #[test]
    fn tcmsg_builder_header() {
        let mut b = TcMsgBuilder::new();
        let pos = b.begin_msg(RTM_NEWQDISC, NLM_F_ACK, 3, tc_handle(1, 0), TC_H_ROOT, 0);
        b.mb.put_str(TCA_KIND, "htb");
        b.end_msg(pos);

        let buf = b.finish();
        // nlmsghdr: 16 bytes + tcmsg: 20 bytes + TCA_KIND attr
        assert!(buf.len() >= 36, "message too short: {} bytes", buf.len());

        // Check nlmsg_type = RTM_NEWQDISC
        let msg_type = u16::from_ne_bytes([buf[4], buf[5]]);
        assert_eq!(msg_type, RTM_NEWQDISC);

        // Check tcm_ifindex = 3
        let ifindex = i32::from_ne_bytes([buf[20], buf[21], buf[22], buf[23]]);
        assert_eq!(ifindex, 3);

        // Check tcm_handle = 1:0
        let handle = u32::from_ne_bytes([buf[24], buf[25], buf[26], buf[27]]);
        assert_eq!(handle, tc_handle(1, 0));

        // Check tcm_parent = TC_H_ROOT
        let parent = u32::from_ne_bytes([buf[28], buf[29], buf[30], buf[31]]);
        assert_eq!(parent, TC_H_ROOT);
    }

    #[test]
    fn nldump_htb_root_message() {
        // Build a HTB root qdisc message without sending — verify
        // the wire format matches what tc would emit.
        let mut b = TcMsgBuilder::new();
        let pos = b.begin_msg(
            RTM_NEWQDISC,
            NLM_F_ACK | NLM_F_CREATE | NLM_F_EXCL,
            1, // lo
            tc_handle(SW_TC_MAJOR, 0),
            TC_H_ROOT,
            0,
        );
        b.mb.put_str(TCA_KIND, "htb");

        let opts = b.mb.begin_nested(TCA_OPTIONS);
        let mut glob = [0u8; TC_HTB_GLOB_SIZE];
        glob[0..4].copy_from_slice(&3u32.to_ne_bytes());
        glob[4..8].copy_from_slice(&10u32.to_ne_bytes());
        glob[8..12].copy_from_slice(&0x10u32.to_ne_bytes());
        b.mb.put_bytes(TCA_HTB_INIT, &glob);
        b.mb.end_nested(opts);

        b.end_msg(pos);
        let buf = b.finish();

        // Verify TCA_KIND is "htb\0"
        // After 36 bytes of header, first NLA is TCA_KIND
        let nla_len = u16::from_ne_bytes([buf[36], buf[37]]) as usize;
        let nla_type = u16::from_ne_bytes([buf[38], buf[39]]);
        assert_eq!(nla_type, TCA_KIND);
        assert_eq!(nla_len, 4 + 4); // hdr + "htb\0"
        assert_eq!(&buf[40..43], b"htb");
        assert_eq!(buf[43], 0); // NUL terminator
    }

    #[test]
    fn process_tc_response_ack() {
        // Simulate a zero-error ACK (NLMSG_ERROR with error=0)
        let mut ack = [0u8; 36];
        // nlmsg_len = 36
        ack[0..4].copy_from_slice(&36u32.to_ne_bytes());
        // nlmsg_type = NLMSG_ERROR
        ack[4..6].copy_from_slice(&netlink::NLMSG_ERROR.to_ne_bytes());
        // flags
        ack[6..8].copy_from_slice(&0u16.to_ne_bytes());
        // seq
        ack[8..12].copy_from_slice(&1u32.to_ne_bytes());
        // pid
        ack[12..16].copy_from_slice(&0u32.to_ne_bytes());
        // error = 0 (success)
        ack[16..20].copy_from_slice(&0i32.to_ne_bytes());
        // rest is echoed header (don't care)

        let result = process_tc_response(&ack, |_, _, _, _, _, _| {
            panic!("should not call handler on ACK");
        });
        assert!(result.is_ok());
    }

    #[test]
    fn process_tc_response_error() {
        // Simulate ENOENT error
        let mut err_msg = [0u8; 36];
        err_msg[0..4].copy_from_slice(&36u32.to_ne_bytes());
        err_msg[4..6].copy_from_slice(&netlink::NLMSG_ERROR.to_ne_bytes());
        err_msg[6..8].copy_from_slice(&0u16.to_ne_bytes());
        err_msg[8..12].copy_from_slice(&1u32.to_ne_bytes());
        err_msg[12..16].copy_from_slice(&0u32.to_ne_bytes());
        // error = -ENOENT (-2)
        err_msg[16..20].copy_from_slice(&(-2i32).to_ne_bytes());

        let result = process_tc_response(&err_msg, |_, _, _, _, _, _| {});
        assert!(result.is_err());
        let e = result.unwrap_err();
        assert_eq!(e.raw_os_error(), Some(2)); // ENOENT
    }

    #[test]
    fn ifindex_for_lo() {
        // lo exists on every Linux box; skip if not present
        // (e.g. running tests on macOS)
        if let Ok(idx) = ifindex_for_name("lo") {
            assert!(idx > 0, "lo ifindex should be positive");
        }
    }

    #[test]
    fn format_handle_cases() {
        assert_eq!(format_handle(0), "0:");
        assert_eq!(format_handle(tc_handle(1, 0)), "1:");
        assert_eq!(format_handle(tc_handle(1, 0x10)), "1:16");
        assert_eq!(format_handle(tc_handle(0xFFFF, 0xFFFF)), "65535:65535");
    }

    #[test]
    fn parse_tca_attrs_roundtrip() {
        // Build a small NLA sequence and parse it back
        let mut buf = Vec::new();
        // NLA: type=TCA_KIND, value="htb\0"
        let len: u16 = 4 + 4; // hdr + "htb\0"
        buf.extend_from_slice(&len.to_ne_bytes());
        buf.extend_from_slice(&TCA_KIND.to_ne_bytes());
        buf.extend_from_slice(b"htb\0");
        // NLA: type=TCA_STATS, value=4 zero bytes
        let len2: u16 = 4 + 4;
        buf.extend_from_slice(&len2.to_ne_bytes());
        buf.extend_from_slice(&TCA_STATS.to_ne_bytes());
        buf.extend_from_slice(&[0u8; 4]);

        let attrs = parse_tca_attrs(&buf);
        assert_eq!(attrs.len(), 2);
        assert_eq!(attrs[0].0, TCA_KIND);
        assert_eq!(&attrs[0].1, b"htb\0");
        assert_eq!(attrs[1].0, TCA_STATS);
    }

    #[test]
    fn basic_filter_message_structure() {
        // Build a basic filter message without sending and verify structure
        let mut b = TcMsgBuilder::new();
        let pos = b.begin_msg(
            RTM_NEWTFILTER,
            NLM_F_ACK | NLM_F_CREATE | NLM_F_EXCL,
            1, // lo
            0,
            tc_handle(SW_TC_MAJOR, 0),
            (1u32 << 16) | 3, // prio=1, proto=ETH_P_ALL
        );
        b.mb.put_str(TCA_KIND, "basic");
        let opts = b.mb.begin_nested(TCA_OPTIONS);
        b.mb.put_u32(TCA_BASIC_CLASSID, tc_handle(1, 0x10));
        b.mb.end_nested(opts);
        b.end_msg(pos);

        let buf = b.finish();
        // Verify nlmsg_type = RTM_NEWTFILTER
        let msg_type = u16::from_ne_bytes([buf[4], buf[5]]);
        assert_eq!(msg_type, RTM_NEWTFILTER);
        // Verify tcm_parent = 1:0
        let parent = u32::from_ne_bytes([buf[28], buf[29], buf[30], buf[31]]);
        assert_eq!(parent, tc_handle(SW_TC_MAJOR, 0));
    }
}
