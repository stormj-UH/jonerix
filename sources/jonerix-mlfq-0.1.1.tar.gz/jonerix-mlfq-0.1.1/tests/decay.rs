//! Integration tests for periodic decay.
//!
//! Covers:
//! - Decay reduces `cpu_usage_ns`.
//! - Decay halves `latency_credit` (with default 1/2 multiplier).
//! - When `latency_credit` decays below `boost_credit/4`,
//!   `is_latency_sensitive` is cleared.
//! - Decay does NOT run before `decay_tick_ns` has elapsed.
//! - Decay applies to every tracked task, not only the running one.

use jonerix_mlfq::{ManualClock, Policy, Scheduler, TaskId};

fn fresh() -> Scheduler<ManualClock> {
    Scheduler::new(ManualClock::new(), Policy::desktop())
}

#[test]
fn decay_reduces_cpu_usage_ns() {
    let mut s = fresh();
    s.add_task(TaskId(1), 4);

    // Build up some cpu_usage by running then yielding.
    assert_eq!(s.pick_next(), Some(TaskId(1)));
    s.clock().advance_ms(10);
    s.on_yield(TaskId(1));
    let cpu_before = s.task_ctx(TaskId(1)).expect("tracked").cpu_usage_ns;
    assert!(cpu_before > 0, "task must have accumulated cpu_usage");

    // Advance past a decay tick boundary.
    s.clock().advance(s.policy().decay_tick_ns + 1);
    let tick = s.on_tick();
    assert!(tick.decayed, "decay should have run after decay_tick_ns");

    let cpu_after = s.task_ctx(TaskId(1)).expect("tracked").cpu_usage_ns;
    assert!(
        cpu_after < cpu_before,
        "cpu_usage_ns should shrink after decay ({cpu_before} → {cpu_after})"
    );
}

#[test]
fn decay_halves_latency_credit_by_default() {
    let mut s = fresh();
    s.add_task(TaskId(1), 4);

    // Interactive wakeup to install latency_credit = boost_credit.
    s.on_sleep(TaskId(1));
    s.clock().advance_ms(5);
    s.on_wakeup(TaskId(1), None);
    let before = s.task_ctx(TaskId(1)).expect("tracked").latency_credit;
    assert_eq!(
        before,
        s.policy().boost_credit,
        "first interactive wakeup gives exactly boost_credit"
    );

    // One decay tick.
    s.clock().advance(s.policy().decay_tick_ns + 1);
    let tick = s.on_tick();
    assert!(tick.decayed);

    // Default desktop policy: credit_decay_num=1, credit_decay_den=2 → halve.
    let after = s.task_ctx(TaskId(1)).expect("tracked").latency_credit;
    let expected = before * s.policy().credit_decay_num as i32 / s.policy().credit_decay_den as i32;
    assert_eq!(
        after, expected,
        "decay should halve credit ({before} → {after}, expected {expected})"
    );
}

#[test]
fn decay_clears_sensitivity_when_credit_drops_below_quarter_boost() {
    let mut s = fresh();
    s.add_task(TaskId(1), 4);

    // Boost via interactive wakeup.
    s.on_sleep(TaskId(1));
    s.clock().advance_ms(5);
    s.on_wakeup(TaskId(1), None);
    assert!(
        s.task_ctx(TaskId(1)).expect("tracked").is_latency_sensitive,
        "should be sensitive right after boost"
    );

    // After two decay ticks credit is boost_credit * (1/2)^2 = boost_credit/4
    // which equals boost_credit/4. The clear condition in task.rs is
    // `latency_credit <= boost_credit / 4`, so by the second tick we clear it.
    s.clock().advance(s.policy().decay_tick_ns + 1);
    let t1 = s.on_tick();
    assert!(t1.decayed);

    s.clock().advance(s.policy().decay_tick_ns + 1);
    let t2 = s.on_tick();
    assert!(t2.decayed);

    let ctx = s.task_ctx(TaskId(1)).expect("tracked");
    assert!(
        ctx.latency_credit <= s.policy().boost_credit / 4,
        "credit ({}) should be at or below quarter-boost ({})",
        ctx.latency_credit,
        s.policy().boost_credit / 4,
    );
    assert!(
        !ctx.is_latency_sensitive,
        "is_latency_sensitive should be cleared once credit decays below threshold"
    );
}

#[test]
fn decay_does_not_run_before_decay_tick_ns() {
    let mut s = fresh();
    s.add_task(TaskId(1), 4);

    // Build credit so we can observe the no-decay case.
    s.on_sleep(TaskId(1));
    s.clock().advance_ms(5);
    s.on_wakeup(TaskId(1), None);
    let before = s.task_ctx(TaskId(1)).expect("tracked").latency_credit;

    // Advance less than a full decay tick.
    let half = s.policy().decay_tick_ns / 2;
    s.clock().advance(half);
    let tick = s.on_tick();
    assert!(
        !tick.decayed,
        "decay must NOT run before decay_tick_ns has elapsed"
    );
    let after = s.task_ctx(TaskId(1)).expect("tracked").latency_credit;
    assert_eq!(
        before, after,
        "credit should be untouched when decay didn't fire"
    );
}

#[test]
fn decay_applies_to_all_tasks_not_just_running() {
    let mut s = fresh();
    s.add_task(TaskId(1), 4);
    s.add_task(TaskId(2), 4);
    s.add_task(TaskId(3), 4);

    // Give each task some latency credit but never pick them.
    for tid in [TaskId(1), TaskId(2), TaskId(3)] {
        s.on_sleep(tid);
        s.clock().advance_ms(5);
        s.on_wakeup(tid, None);
    }
    let before: Vec<i32> = [TaskId(1), TaskId(2), TaskId(3)]
        .iter()
        .map(|t| s.task_ctx(*t).expect("tracked").latency_credit)
        .collect();
    for c in &before {
        assert!(*c > 0, "all tasks should start with positive credit");
    }

    // None of them are running.
    assert!(s.running().is_none());
    s.clock().advance(s.policy().decay_tick_ns + 1);
    let tick = s.on_tick();
    assert!(tick.decayed);

    let after: Vec<i32> = [TaskId(1), TaskId(2), TaskId(3)]
        .iter()
        .map(|t| s.task_ctx(*t).expect("tracked").latency_credit)
        .collect();
    for (b, a) in before.iter().zip(after.iter()) {
        assert!(
            a < b,
            "every tracked task's credit must decay even when not running ({b} → {a})"
        );
    }
}

#[test]
fn second_tick_in_same_window_does_not_re_decay() {
    let mut s = fresh();
    s.add_task(TaskId(1), 4);

    // Boost.
    s.on_sleep(TaskId(1));
    s.clock().advance_ms(5);
    s.on_wakeup(TaskId(1), None);

    // Cross a tick boundary → decay.
    s.clock().advance(s.policy().decay_tick_ns + 1);
    let first = s.on_tick();
    assert!(first.decayed);
    let after_first = s.task_ctx(TaskId(1)).expect("tracked").latency_credit;

    // Advance only a tiny bit — should NOT decay again.
    s.clock().advance(1_000);
    let second = s.on_tick();
    assert!(
        !second.decayed,
        "back-to-back ticks within one decay window should NOT re-decay"
    );
    let after_second = s.task_ctx(TaskId(1)).expect("tracked").latency_credit;
    assert_eq!(
        after_first, after_second,
        "credit must not change when decay did not fire"
    );

    // For the unused-import-style lint suppression on `Policy`.
    let _ = Policy::desktop();
}
