//! Integration tests for sleep-duration classification and boost logic.
//!
//! Covers:
//! - Spin-class sleeps (`< spin_threshold_ns`) do not boost.
//! - Interactive-class sleeps (`[spin_threshold_ns, interactive_threshold_ns]`)
//!   boost via `boost_credit`.
//! - Background-class sleeps (`> interactive_threshold_ns`) get a smaller boost
//!   than interactive.
//! - Behaviour exactly at the boundary nanoseconds (`spin_threshold_ns`,
//!   `interactive_threshold_ns`).

use jonerix_mlfq::{ManualClock, Policy, Scheduler, SleepClass, TaskId};

fn fresh() -> Scheduler<ManualClock> {
    Scheduler::new(ManualClock::new(), Policy::desktop())
}

#[test]
fn spin_class_sleep_does_not_boost() {
    let mut s = fresh();
    s.add_task(TaskId(1), 4);

    // Sleep for less than spin_threshold_ns (default 2 ms) — half a millisecond.
    s.on_sleep(TaskId(1));
    s.clock().advance_us(500);
    let out = s.on_wakeup(TaskId(1), None);

    assert_eq!(out.class, SleepClass::Spin);
    assert!(!out.boosted, "spin-class wakeup must not boost");
    assert!(
        !out.damped_periodic,
        "spin-class wakeup cannot trigger damped-periodic path"
    );
    // No credit gained.
    let ctx = s.task_ctx(TaskId(1)).expect("task tracked");
    assert_eq!(ctx.latency_credit, 0);
    assert!(!ctx.is_latency_sensitive);
}

#[test]
fn interactive_class_sleep_boosts_with_full_credit() {
    let mut s = fresh();
    let boost = s.policy().boost_credit;
    s.add_task(TaskId(1), 4);

    // Sleep 5 ms — squarely in interactive range.
    s.on_sleep(TaskId(1));
    s.clock().advance_ms(5);
    let out = s.on_wakeup(TaskId(1), None);

    assert_eq!(out.class, SleepClass::Interactive);
    assert!(out.boosted, "interactive wakeup must boost");
    let ctx = s.task_ctx(TaskId(1)).expect("task tracked");
    // First boost should give exactly boost_credit (no prior credit, not periodic).
    assert_eq!(ctx.latency_credit, boost);
    assert!(
        ctx.is_latency_sensitive,
        "interactive boost makes task latency-sensitive"
    );
}

#[test]
fn background_class_sleep_gives_smaller_boost() {
    let mut s = fresh();
    let boost = s.policy().boost_credit;
    let chain = s.policy().chain_credit;
    s.add_task(TaskId(1), 4);

    // Sleep 500 ms — well past interactive_threshold_ns (50 ms default).
    s.on_sleep(TaskId(1));
    s.clock().advance_ms(500);
    let out = s.on_wakeup(TaskId(1), None);

    assert_eq!(out.class, SleepClass::Background);
    // Per scheduler.rs, background gives chain_credit/2 as the boost.
    let ctx = s.task_ctx(TaskId(1)).expect("task tracked");
    let expected = chain / 2;
    assert_eq!(
        ctx.latency_credit, expected,
        "background boost should equal chain_credit/2"
    );
    assert!(
        ctx.latency_credit < boost,
        "background boost ({}) should be smaller than interactive boost ({})",
        ctx.latency_credit,
        boost,
    );
}

#[test]
fn exactly_spin_threshold_is_interactive() {
    // The classifier uses `< spin_threshold_ns` ⇒ Spin and
    // `<= interactive_threshold_ns` ⇒ Interactive, so exactly
    // spin_threshold_ns falls into Interactive.
    let mut s = fresh();
    let spin_thr = s.policy().spin_threshold_ns;
    s.add_task(TaskId(1), 4);

    s.on_sleep(TaskId(1));
    s.clock().advance(spin_thr);
    let out = s.on_wakeup(TaskId(1), None);
    assert_eq!(
        out.class,
        SleepClass::Interactive,
        "exactly spin_threshold_ns is interactive (inclusive lower bound)"
    );
    assert!(out.boosted);
}

#[test]
fn just_below_spin_threshold_is_spin() {
    let mut s = fresh();
    let spin_thr = s.policy().spin_threshold_ns;
    s.add_task(TaskId(1), 4);

    s.on_sleep(TaskId(1));
    s.clock().advance(spin_thr - 1);
    let out = s.on_wakeup(TaskId(1), None);
    assert_eq!(out.class, SleepClass::Spin);
    assert!(!out.boosted);
}

#[test]
fn exactly_interactive_threshold_is_interactive() {
    // Inclusive upper bound on Interactive.
    let mut s = fresh();
    let int_thr = s.policy().interactive_threshold_ns;
    s.add_task(TaskId(1), 4);

    s.on_sleep(TaskId(1));
    s.clock().advance(int_thr);
    let out = s.on_wakeup(TaskId(1), None);
    assert_eq!(out.class, SleepClass::Interactive);
    assert!(out.boosted);
}

#[test]
fn just_past_interactive_threshold_is_background() {
    let mut s = fresh();
    let int_thr = s.policy().interactive_threshold_ns;
    s.add_task(TaskId(1), 4);

    s.on_sleep(TaskId(1));
    s.clock().advance(int_thr + 1);
    let out = s.on_wakeup(TaskId(1), None);
    assert_eq!(out.class, SleepClass::Background);
}
