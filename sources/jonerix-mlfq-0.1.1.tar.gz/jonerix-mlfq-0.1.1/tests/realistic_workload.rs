//! End-to-end soak: a CPU hog, an interactive UI thread (≈5 ms sleep / 1 ms
//! work with light jitter), and a periodic poller (exactly 10 ms sleep) run
//! together for 5000 scheduler ticks of simulated time.
//!
//! Asserts:
//! - The interactive UI thread accumulates at least 50× more *undamped* boost
//!   events than the periodic poller.
//! - The poller ends the simulation flagged `is_periodic`.
//! - The CPU hog ends up on a lower-priority (higher numeric) queue than the
//!   interactive task.
//! - `stats().preempt_events > 0`.
//! - `stats().chain_propagated == 0` since we never pass a `waker` argument.
//! - The aggregate `SchedulerStats` counters are internally consistent.

use jonerix_mlfq::{Clock, ManualClock, Policy, Scheduler, TaskId};

const HOG: TaskId = TaskId(1);
const UI: TaskId = TaskId(2);
const POLLER: TaskId = TaskId(3);

/// A simple xorshift32 PRNG so the test stays deterministic without
/// pulling in any crates.
struct Xorshift32(u32);
impl Xorshift32 {
    fn new(seed: u32) -> Self {
        Self(seed.max(1))
    }
    fn next_u32(&mut self) -> u32 {
        let mut x = self.0;
        x ^= x << 13;
        x ^= x >> 17;
        x ^= x << 5;
        self.0 = x;
        x
    }
}

/// Per-task observability data collected during the soak loop.
#[derive(Default)]
struct BoostObs {
    ui_boosts: u64,
    poller_boosts: u64,
    ui_damped: u64,
    poller_damped: u64,
}

/// Run the soak loop and return per-task boost observations.
fn run_soak(s: &mut Scheduler<ManualClock>) -> BoostObs {
    let mut rng = Xorshift32::new(0x00C0_FFEE);
    let mut obs = BoostObs::default();

    // Pre-seed both non-hog tasks as "sleeping" so their first wakeup has a
    // well-defined sleep duration.
    s.on_sleep(UI);
    s.on_sleep(POLLER);

    let tick_ns: u64 = 1_000_000;
    let total_ticks: u32 = 5000;
    let mut ui_wake_at: u64 = jitter(&mut rng, 5_000_000, 1_500_000);
    let mut poller_wake_at: u64 = 10_000_000;

    for _ in 0..total_ticks {
        s.clock().advance(tick_ns);
        let now = s.clock().now_ns();

        if now >= ui_wake_at {
            let out = s.on_wakeup(UI, None);
            if out.boosted {
                obs.ui_boosts += 1;
                if out.damped_periodic {
                    obs.ui_damped += 1;
                }
            }
            ui_wake_at = u64::MAX;
        }
        if now >= poller_wake_at {
            let out = s.on_wakeup(POLLER, None);
            if out.boosted {
                obs.poller_boosts += 1;
                if out.damped_periodic {
                    obs.poller_damped += 1;
                }
            }
            poller_wake_at = u64::MAX;
        }

        let tick_out = s.on_tick();
        if s.running().is_none() {
            let _ = s.pick_next();
        }
        if tick_out.long_slice_expired {
            if let Some(r) = s.running() {
                s.on_long_slice(r);
            }
        } else if tick_out.outranked {
            if let Some(r) = s.running() {
                s.on_yield(r);
            }
        }

        if let Some(r) = s.running() {
            if r == UI {
                s.on_sleep(UI);
                let sleep_ns = jitter(&mut rng, 5_000_000, 1_500_000);
                ui_wake_at = s.clock().now_ns().saturating_add(sleep_ns);
            } else if r == POLLER {
                s.on_sleep(POLLER);
                poller_wake_at = s.clock().now_ns().saturating_add(10_000_000);
            }
            // r == HOG: do nothing — let cpu_usage_ns accumulate naturally.
        }
    }

    obs
}

#[test]
#[allow(clippy::too_many_lines)]
fn realistic_workload_5000_ticks() {
    let mut s = Scheduler::new(ManualClock::new(), Policy::desktop());
    s.add_task(HOG, 4);
    s.add_task(UI, 4);
    s.add_task(POLLER, 4);

    let obs = run_soak(&mut s);
    let (ui_boosts, poller_boosts, ui_damped, poller_damped) = (
        obs.ui_boosts,
        obs.poller_boosts,
        obs.ui_damped,
        obs.poller_damped,
    );

    // Final assertions.
    let stats = s.stats();

    // 1. UI thread gets >= 50× more undamped boosts than the poller.
    let ui_undamped = ui_boosts - ui_damped;
    let poller_undamped = poller_boosts - poller_damped;
    // Guard against division by zero — but require concrete activity.
    assert!(
        ui_undamped > 0,
        "UI thread should record undamped boosts (got {ui_undamped})"
    );
    let ratio_floor = poller_undamped.saturating_mul(50);
    assert!(
        ui_undamped >= ratio_floor.max(50),
        "UI undamped boosts ({ui_undamped}) should be at least 50× poller's ({poller_undamped})"
    );

    // 2. Poller ends flagged periodic.
    assert!(
        s.task_ctx(POLLER).expect("poller tracked").is_periodic,
        "fixed-10ms-cadence poller should end flagged as periodic"
    );

    // 3. CPU hog ends up at a worse queue level than UI thread.
    let hog_q = s.task_ctx(HOG).expect("hog tracked").current_queue;
    let ui_q = s.task_ctx(UI).expect("ui tracked").current_queue;
    assert!(
        hog_q > ui_q,
        "CPU hog ({hog_q}) should end up at higher (worse) queue than UI thread ({ui_q})"
    );

    // 4. preempt_events > 0.
    assert!(
        stats.preempt_events > 0,
        "soak should record some preempt_events (got {})",
        stats.preempt_events,
    );

    // 5. chain_propagated == 0 when no waker is ever passed.
    assert_eq!(
        stats.chain_propagated, 0,
        "no waker arg means no chain credit should propagate"
    );

    // 6. Internal consistency of SchedulerStats.
    assert_eq!(stats.tasks, 3, "we added exactly 3 tasks");
    assert!(
        stats.boosts_granted + stats.boosts_rate_limited >= stats.interactive_wakeups,
        "every interactive wakeup must be either granted or rate-limited \
         (granted {} + limited {} vs interactive {})",
        stats.boosts_granted,
        stats.boosts_rate_limited,
        stats.interactive_wakeups,
    );
    assert!(
        stats.boosts_damped_periodic <= stats.boosts_granted,
        "damped-periodic count ({}) is a subset of granted ({})",
        stats.boosts_damped_periodic,
        stats.boosts_granted,
    );
    assert!(
        stats.interactive_wakeups <= stats.wakeups,
        "interactive wakeups ({}) cannot exceed total wakeups ({})",
        stats.interactive_wakeups,
        stats.wakeups,
    );
}

/// Return `base ± up_to_jitter` in nanoseconds. Ensures result is at least
/// `spin_threshold_ns + 1` so the sleep classifies as interactive.
fn jitter(rng: &mut Xorshift32, base: u64, up_to_jitter: u64) -> u64 {
    let span = up_to_jitter.saturating_mul(2);
    let pick = u64::from(rng.next_u32()) % span.max(1);
    let signed = i64::try_from(pick).unwrap_or(0) - i64::try_from(up_to_jitter).unwrap_or(0);
    let result = i64::try_from(base).unwrap_or(0).saturating_add(signed);
    // Floor at 2.5 ms so we stay safely inside the interactive band.
    u64::try_from(result.max(2_500_000)).unwrap_or(2_500_000)
}
