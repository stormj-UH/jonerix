//! Integration tests for long-slice demotion and CPU-usage penalty.
//!
//! Covers:
//! - A task that hits `long_slice_ns` gets demoted exactly one queue level.
//! - Demotion clears `is_latency_sensitive`.
//! - Demotion clears positive `latency_credit` (i.e. credit is capped to 0).
//! - A CPU hog accumulates enough `cpu_usage_ns` to eventually score worse
//!   than an interactive task.
//! - After a long-slice demote, the task lands on a higher (worse) queue
//!   index than where it started.

use jonerix_mlfq::{ManualClock, Policy, Scheduler, TaskId};

fn fresh() -> Scheduler<ManualClock> {
    Scheduler::new(ManualClock::new(), Policy::desktop())
}

#[test]
fn long_slice_demotes_at_least_one_level() {
    // Note: the library implements demotion as `target_queue + 1`, i.e. the
    // current scored level + 1. Because running for `long_slice_ns` also
    // accumulates `cpu_usage_ns`, the score-driven target_queue often jumps
    // by more than +1 before the explicit demote adds another. The
    // documented contract is therefore "at least one level lower (higher
    // numeric)" — the unit test in scheduler.rs makes the same assertion.
    let mut s = fresh();
    s.add_task(TaskId(1), 4);

    let initial = s.task_ctx(TaskId(1)).expect("tracked").current_queue;
    assert_eq!(s.pick_next(), Some(TaskId(1)));

    // Run past long_slice_ns.
    s.clock().advance(s.policy().long_slice_ns + 1);
    let demoted_level = s.on_long_slice(TaskId(1));

    assert!(
        demoted_level.0 > initial,
        "long-slice should demote at least one level (initial {initial}, post {})",
        demoted_level.0,
    );
    let ctx = s.task_ctx(TaskId(1)).expect("tracked");
    assert_eq!(ctx.current_queue, demoted_level.0);
}

#[test]
fn long_slice_clears_latency_sensitive_flag() {
    let mut s = fresh();
    s.add_task(TaskId(1), 4);

    // First, sensitise the task via an interactive wakeup.
    s.on_sleep(TaskId(1));
    s.clock().advance_ms(5);
    s.on_wakeup(TaskId(1), None);
    assert!(
        s.task_ctx(TaskId(1)).expect("tracked").is_latency_sensitive,
        "task should be latency-sensitive after interactive wakeup"
    );

    // Now run it past long_slice and demote.
    assert_eq!(s.pick_next(), Some(TaskId(1)));
    s.clock().advance(s.policy().long_slice_ns + 1);
    s.on_long_slice(TaskId(1));

    assert!(
        !s.task_ctx(TaskId(1)).expect("tracked").is_latency_sensitive,
        "long-slice demotion must clear is_latency_sensitive"
    );
}

#[test]
fn long_slice_clears_positive_latency_credit() {
    let mut s = fresh();
    s.add_task(TaskId(1), 4);

    // Earn some positive credit via interactive wakeup.
    s.on_sleep(TaskId(1));
    s.clock().advance_ms(5);
    s.on_wakeup(TaskId(1), None);
    let before = s.task_ctx(TaskId(1)).expect("tracked").latency_credit;
    assert!(before > 0, "should have positive credit pre-demote");

    // Run past long_slice and demote.
    assert_eq!(s.pick_next(), Some(TaskId(1)));
    s.clock().advance(s.policy().long_slice_ns + 1);
    s.on_long_slice(TaskId(1));

    let after = s.task_ctx(TaskId(1)).expect("tracked").latency_credit;
    assert!(
        after <= 0,
        "long-slice demotion must cap positive credit (was {before}, now {after})"
    );
}

#[test]
fn cpu_hog_eventually_scores_worse_than_interactive_peer() {
    let mut s = fresh();
    // Both start at the same base priority.
    s.add_task(TaskId(1), 4); // CPU hog
    s.add_task(TaskId(2), 4); // Interactive peer

    let initial_hog_score = s.task_ctx(TaskId(1)).expect("tracked").score(s.policy());
    let initial_int_score = s.task_ctx(TaskId(2)).expect("tracked").score(s.policy());
    assert_eq!(
        initial_hog_score, initial_int_score,
        "identical base priority → identical initial score"
    );

    // Hog runs for many long slices, accumulating cpu_usage_ns.
    // Each cycle: pick → advance → yield (so cpu_usage accumulates).
    for _ in 0..10 {
        let next = s.pick_next();
        if next == Some(TaskId(1)) {
            s.clock().advance(s.policy().long_slice_ns);
            s.on_yield(TaskId(1));
        } else if let Some(other) = next {
            // Just yield other tasks so they don't accumulate CPU.
            s.on_yield(other);
        } else {
            break;
        }
    }

    // Interactive task wakes — boost it.
    s.on_sleep(TaskId(2));
    s.clock().advance_ms(5);
    s.on_wakeup(TaskId(2), None);

    let hog_score = s.task_ctx(TaskId(1)).expect("tracked").score(s.policy());
    let int_score = s.task_ctx(TaskId(2)).expect("tracked").score(s.policy());

    assert!(
        int_score < hog_score,
        "after CPU accumulation + boost, interactive task ({int_score}) should outrank hog ({hog_score})"
    );
    assert!(
        s.task_ctx(TaskId(1)).expect("tracked").cpu_usage_ns > 0,
        "hog must have accumulated CPU usage"
    );
}

#[test]
fn long_slice_lands_on_higher_queue_index_than_start() {
    let mut s = fresh();
    s.add_task(TaskId(1), 4);

    let initial = s.task_ctx(TaskId(1)).expect("tracked").current_queue;
    assert_eq!(s.pick_next(), Some(TaskId(1)));
    s.clock().advance(s.policy().long_slice_ns + 1);
    let post = s.on_long_slice(TaskId(1));

    assert!(
        post.0 > initial,
        "post-demote queue index ({}) must be higher (worse) than initial ({initial})",
        post.0,
    );
}

#[test]
fn repeated_long_slices_demote_further_but_clamp_at_bottom() {
    // Hardcoded NUM_QUEUES = 8 per the public docs.
    const NUM_QUEUES_U8: u8 = 8;

    let mut s = fresh();
    s.add_task(TaskId(1), 0); // start at TOP

    let mut last = 0u8;
    for _ in 0..20 {
        let picked = s.pick_next();
        if picked != Some(TaskId(1)) {
            // Some other ordering scenario — just stop early.
            break;
        }
        s.clock().advance(s.policy().long_slice_ns + 1);
        let lvl = s.on_long_slice(TaskId(1));
        assert!(lvl.0 >= last, "demote must be monotonic non-decreasing");
        last = lvl.0;
        assert!(lvl.0 < NUM_QUEUES_U8, "queue index must stay in range");
    }
    assert_eq!(
        last,
        NUM_QUEUES_U8 - 1,
        "after enough demotes, task should land at BOTTOM"
    );
}

#[test]
fn cpu_penalty_increases_target_queue() {
    // Pure cpu_usage_ns → cpu_penalty → score → target_queue.
    let mut s = fresh();
    s.add_task(TaskId(1), 2);

    let initial_target = s
        .task_ctx(TaskId(1))
        .expect("tracked")
        .target_queue(s.policy());

    // Run the task for many slices to accumulate cpu_usage.
    for _ in 0..6 {
        if s.pick_next() != Some(TaskId(1)) {
            break;
        }
        s.clock().advance(s.policy().long_slice_ns);
        s.on_yield(TaskId(1));
    }

    let final_target = s
        .task_ctx(TaskId(1))
        .expect("tracked")
        .target_queue(s.policy());
    assert!(
        final_target >= initial_target,
        "target queue should not improve under pure CPU load"
    );
    // And the CPU penalty should be strictly positive.
    let penalty = s
        .task_ctx(TaskId(1))
        .expect("tracked")
        .cpu_penalty(s.policy());
    assert!(
        penalty > 0,
        "cpu_usage accumulation must yield a positive penalty"
    );
    // Suppress dead-code on the Policy type we didn't otherwise need.
    let _ = Policy::server();
}
