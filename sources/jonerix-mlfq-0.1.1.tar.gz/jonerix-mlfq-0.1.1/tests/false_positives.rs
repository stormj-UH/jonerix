//! Integration tests for boost rate limit and periodic-wakeup detection.
//!
//! Covers:
//! - 5+ identical-cadence sleeps flag `is_periodic`.
//! - The boost on a periodic task is damped (≤ `boost_credit / 4`).
//! - Irregular sleeps do NOT flag periodic.
//! - The boost rate limit fires once a task exceeds `max_boosts_per_sec`.
//! - The rate-limit window refreshes after a 1-second boundary.

use jonerix_mlfq::{ManualClock, Policy, Scheduler, TaskId};

fn fresh() -> Scheduler<ManualClock> {
    Scheduler::new(ManualClock::new(), Policy::desktop())
}

#[test]
fn five_identical_cadence_sleeps_flag_periodic() {
    let mut s = fresh();
    s.add_task(TaskId(1), 4);

    // Exactly identical-cadence sleeps to force the variance check positive.
    // We need `periodic_window` (default 5) samples.
    for _ in 0..s.policy().periodic_window {
        s.on_sleep(TaskId(1));
        s.clock().advance_ms(10);
        s.on_wakeup(TaskId(1), None);
    }
    assert!(
        s.task_ctx(TaskId(1)).expect("tracked").is_periodic,
        "5 identical 10ms cadence sleeps should flag as periodic"
    );
}

#[test]
fn periodic_boost_is_damped_to_at_most_quarter_credit() {
    let mut s = fresh();
    s.add_task(TaskId(1), 4);

    // Force periodic flag via 5 identical sleeps.
    for _ in 0..s.policy().periodic_window {
        s.on_sleep(TaskId(1));
        s.clock().advance_ms(10);
        s.on_wakeup(TaskId(1), None);
    }
    assert!(s.task_ctx(TaskId(1)).expect("tracked").is_periodic);

    // Now record the latency credit before the next boost, fire one more
    // interactive wakeup, and assert the delta is bounded by boost_credit/4.
    let before = s.task_ctx(TaskId(1)).expect("tracked").latency_credit;
    s.on_sleep(TaskId(1));
    s.clock().advance_ms(10);
    let out = s.on_wakeup(TaskId(1), None);

    let after = s.task_ctx(TaskId(1)).expect("tracked").latency_credit;
    let delta = after - before;
    let boost = s.policy().boost_credit;

    // The task is periodic so the damped scale is boost / 4.
    if out.boosted {
        assert!(
            delta <= boost / 4,
            "periodic boost delta ({delta}) must be at most boost_credit/4 ({})",
            boost / 4,
        );
        assert!(
            out.damped_periodic,
            "outcome should flag damped_periodic for a periodic boost"
        );
    } else {
        // Rate limit could fire after many sleeps; allow that as the
        // alternative path but make sure no credit slipped through.
        assert!(out.rate_limited);
        assert_eq!(delta, 0);
    }
}

#[test]
fn irregular_sleeps_do_not_flag_periodic() {
    let mut s = fresh();
    s.add_task(TaskId(1), 4);

    // Highly varied (interactive-range) sleeps.
    let cadences = [3u64, 25, 7, 40, 12];
    for &ms in &cadences {
        s.on_sleep(TaskId(1));
        s.clock().advance_ms(ms);
        s.on_wakeup(TaskId(1), None);
    }
    assert!(
        !s.task_ctx(TaskId(1)).expect("tracked").is_periodic,
        "irregular cadence sleeps must not be flagged periodic"
    );
}

#[test]
fn rate_limit_fires_past_max_boosts_per_sec() {
    let mut s = fresh();
    let cap = s.policy().max_boosts_per_sec;
    s.add_task(TaskId(1), 4);

    // Each wakeup advances the clock by 5 ms (interactive). Keep the
    // window tight enough that we never roll into a second second within
    // the test (5 ms × ~55 < 1000 ms).
    let mut limited = 0u32;
    let attempts = cap + 5;
    for _ in 0..attempts {
        s.on_sleep(TaskId(1));
        s.clock().advance_ms(5);
        let out = s.on_wakeup(TaskId(1), None);
        if out.rate_limited {
            limited += 1;
        }
    }

    assert!(
        limited >= 5,
        "at least 5 wakeups past max_boosts_per_sec should be rate-limited (saw {limited})"
    );
    let stats = s.stats();
    assert!(
        stats.boosts_rate_limited >= u64::from(limited),
        "stats.boosts_rate_limited ({}) must reflect rate-limited boosts ({limited})",
        stats.boosts_rate_limited,
    );
}

#[test]
fn rate_limit_quota_refreshes_after_one_second_boundary() {
    // Build a fresh policy with a small periodic_window so we don't
    // accidentally flag periodic (which would also damp boosts).
    let mut policy = Policy::desktop();
    policy.periodic_window = 2; // 2 samples won't trip variance reliably
    let mut s = Scheduler::new(ManualClock::new(), policy);
    s.add_task(TaskId(1), 4);

    let cap = s.policy().max_boosts_per_sec;

    // Burn through the quota with 5 ms interactive sleeps. We need to keep
    // the total elapsed wall-time under one second so the boost-window
    // doesn't reset prematurely. 5 ms × ~55 < 1 s for the default cap of 50.
    let mut granted = 0u32;
    for _ in 0..cap {
        s.on_sleep(TaskId(1));
        s.clock().advance_ms(5);
        let out = s.on_wakeup(TaskId(1), None);
        if out.boosted {
            granted += 1;
        }
    }
    assert!(
        granted >= 1,
        "should have granted at least one boost initially"
    );

    // Now one more wakeup in the same second — should be rate-limited.
    s.on_sleep(TaskId(1));
    s.clock().advance_ms(5);
    let limited_out = s.on_wakeup(TaskId(1), None);
    assert!(
        limited_out.rate_limited,
        "wakeup past quota in same second should be rate-limited"
    );

    // Jump well past the 1-second boundary from when the window started
    // (boost_window_start_ns was set on the first try_boost call at t≈0).
    s.clock().advance_ms(1_500);

    // The next wakeup should boost again — quota refreshed.
    s.on_sleep(TaskId(1));
    s.clock().advance_ms(5);
    let refreshed = s.on_wakeup(TaskId(1), None);
    assert!(
        refreshed.boosted && !refreshed.rate_limited,
        "after crossing 1-second boundary, boosts should resume (boosted={}, rate_limited={})",
        refreshed.boosted,
        refreshed.rate_limited,
    );
}

#[test]
fn periodic_stat_counter_increments() {
    let mut s = fresh();
    s.add_task(TaskId(1), 4);

    for _ in 0..s.policy().periodic_window {
        s.on_sleep(TaskId(1));
        s.clock().advance_ms(10);
        s.on_wakeup(TaskId(1), None);
    }

    let stats_pre = s.stats();
    // One more interactive wakeup while periodic — increments
    // boosts_damped_periodic if the boost is granted.
    s.on_sleep(TaskId(1));
    s.clock().advance_ms(10);
    let out = s.on_wakeup(TaskId(1), None);
    let stats_post = s.stats();

    if out.boosted {
        assert!(
            stats_post.boosts_damped_periodic > stats_pre.boosts_damped_periodic,
            "damped-periodic stat counter must increment ({} → {})",
            stats_pre.boosts_damped_periodic,
            stats_post.boosts_damped_periodic,
        );
    }
}
