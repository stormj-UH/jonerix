//! Integration tests for wakeup-chain credit propagation.
//!
//! Covers:
//! - Latency-sensitive waker propagates chain credit to wakee.
//! - Non-sensitive waker does NOT propagate.
//! - Chain credit is strictly smaller than a direct interactive boost.
//! - Chain credit still fires when the wakee's sleep was spin-class (because
//!   the waker is latency-sensitive — this is intentional per scheduler.rs).
//! - Three-deep chain (A wakes B; B wakes C) propagates all the way.

use jonerix_mlfq::{ManualClock, Policy, Scheduler, SleepClass, TaskId};

fn fresh() -> Scheduler<ManualClock> {
    Scheduler::new(ManualClock::new(), Policy::desktop())
}

/// Sleep `tid` for `ms` milliseconds and wake it with the given waker.
fn cycle(s: &mut Scheduler<ManualClock>, tid: TaskId, ms: u64, waker: Option<TaskId>) {
    s.on_sleep(tid);
    s.clock().advance_ms(ms);
    s.on_wakeup(tid, waker);
}

#[test]
fn sensitive_waker_propagates_chain_credit() {
    let mut s = fresh();
    s.add_task(TaskId(1), 4);
    s.add_task(TaskId(2), 4);

    // Make tid=1 latency-sensitive by sleeping/waking in the interactive range.
    cycle(&mut s, TaskId(1), 5, None);
    assert!(
        s.task_ctx(TaskId(1))
            .expect("waker tracked")
            .is_latency_sensitive,
        "waker should be latency-sensitive after interactive wakeup"
    );

    // tid=2's sleep is short (spin) — direct boost won't fire — but the
    // waker is sensitive so chain credit should propagate.
    s.on_sleep(TaskId(2));
    s.clock().advance_us(500);
    let out = s.on_wakeup(TaskId(2), Some(TaskId(1)));

    assert_eq!(out.class, SleepClass::Spin, "wakee's own sleep was spin");
    assert!(
        out.chain_inherited,
        "chain credit should propagate from latency-sensitive waker"
    );
    let chain = s.policy().chain_credit;
    let ctx = s.task_ctx(TaskId(2)).expect("wakee tracked");
    assert_eq!(ctx.latency_credit, chain);
}

#[test]
fn non_sensitive_waker_does_not_propagate() {
    let mut s = fresh();
    s.add_task(TaskId(1), 4);
    s.add_task(TaskId(2), 4);

    // tid=1 has not had any interactive activity — it's not latency-sensitive.
    assert!(
        !s.task_ctx(TaskId(1))
            .expect("waker tracked")
            .is_latency_sensitive
    );

    // tid=2 has a short sleep, woken by tid=1.
    s.on_sleep(TaskId(2));
    s.clock().advance_us(500);
    let out = s.on_wakeup(TaskId(2), Some(TaskId(1)));

    assert!(
        !out.chain_inherited,
        "non-sensitive waker must not propagate chain credit"
    );
    let ctx = s.task_ctx(TaskId(2)).expect("wakee tracked");
    assert_eq!(ctx.latency_credit, 0);
}

#[test]
fn chain_credit_is_smaller_than_direct_boost() {
    let policy = Policy::desktop();
    assert!(
        policy.chain_credit < policy.boost_credit,
        "chain_credit ({}) must be strictly smaller than boost_credit ({})",
        policy.chain_credit,
        policy.boost_credit,
    );

    // And confirm it through behaviour: a chain-only inheritance should give
    // strictly less credit than a direct interactive wakeup.
    let mut s = fresh();
    s.add_task(TaskId(1), 4); // waker
    s.add_task(TaskId(2), 4); // chain inheritor
    s.add_task(TaskId(3), 4); // direct interactive wakee

    cycle(&mut s, TaskId(1), 5, None);

    // tid=2: chain only (spin sleep, sensitive waker).
    s.on_sleep(TaskId(2));
    s.clock().advance_us(500);
    s.on_wakeup(TaskId(2), Some(TaskId(1)));
    let chain_credit = s.task_ctx(TaskId(2)).expect("tracked").latency_credit;

    // tid=3: direct interactive boost (no waker).
    cycle(&mut s, TaskId(3), 5, None);
    let direct_credit = s.task_ctx(TaskId(3)).expect("tracked").latency_credit;

    assert!(
        chain_credit < direct_credit,
        "chain credit ({chain_credit}) must be smaller than direct interactive boost ({direct_credit})"
    );
}

#[test]
fn chain_fires_on_spin_class_wakeup_when_waker_is_sensitive() {
    // This is the documented intentional behaviour: a UI thread holding a
    // lock that releases to a worker is still a meaningful dependency chain
    // even though the worker's sleep was short.
    let mut s = fresh();
    s.add_task(TaskId(1), 4);
    s.add_task(TaskId(2), 4);

    // Sensitise tid=1.
    cycle(&mut s, TaskId(1), 5, None);
    assert!(s.task_ctx(TaskId(1)).expect("tracked").is_latency_sensitive);

    // Wake tid=2 from a spin-class sleep with tid=1 as waker.
    s.on_sleep(TaskId(2));
    s.clock().advance_us(100); // 0.1 ms — solidly spin range
    let out = s.on_wakeup(TaskId(2), Some(TaskId(1)));

    assert_eq!(out.class, SleepClass::Spin);
    assert!(
        !out.boosted,
        "spin classification must not produce a direct boost"
    );
    assert!(
        out.chain_inherited,
        "chain credit fires even on spin-class wakeup when waker is sensitive"
    );
}

#[test]
fn three_deep_chain_all_inherit() {
    // A wakes B wakes C. After each step, the woken task should itself become
    // latency-sensitive and so propagate to the next.
    let mut s = fresh();
    s.add_task(TaskId(1), 4); // A
    s.add_task(TaskId(2), 4); // B
    s.add_task(TaskId(3), 4); // C

    // Sensitise A directly.
    cycle(&mut s, TaskId(1), 5, None);
    assert!(s.task_ctx(TaskId(1)).expect("tracked").is_latency_sensitive);

    // A wakes B from an interactive sleep — B gets a direct boost AND a chain.
    s.on_sleep(TaskId(2));
    s.clock().advance_ms(5);
    let b_out = s.on_wakeup(TaskId(2), Some(TaskId(1)));
    assert_eq!(b_out.class, SleepClass::Interactive);
    assert!(b_out.boosted, "B should boost directly from its own sleep");
    assert!(
        b_out.chain_inherited,
        "B should also inherit chain credit from A"
    );
    assert!(
        s.task_ctx(TaskId(2)).expect("tracked").is_latency_sensitive,
        "B must be sensitive to propagate further"
    );

    // B now wakes C from an interactive sleep.
    s.on_sleep(TaskId(3));
    s.clock().advance_ms(5);
    let c_out = s.on_wakeup(TaskId(3), Some(TaskId(2)));
    assert_eq!(c_out.class, SleepClass::Interactive);
    assert!(c_out.boosted);
    assert!(
        c_out.chain_inherited,
        "C should inherit chain credit from B"
    );

    // All three should have positive latency credit.
    for tid in [TaskId(1), TaskId(2), TaskId(3)] {
        let ctx = s.task_ctx(tid).expect("tracked");
        assert!(
            ctx.latency_credit > 0,
            "task {tid:?} should have positive credit after chain ({})",
            ctx.latency_credit,
        );
    }
}
