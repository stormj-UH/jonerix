//! Monotonic clock abstraction.
//!
//! All scheduler time-keeping is in nanoseconds since some arbitrary epoch.
//! Tests use [`ManualClock`] to drive time deterministically; production code
//! uses [`StdClock`], which is backed by [`std::time::Instant`] (monotonic on
//! Linux).

use core::cell::Cell;
use std::time::Instant;

/// Monotonic clock abstraction. All scheduler decisions are derived from
/// `now_ns()` deltas — never wall-clock time.
pub trait Clock {
    /// Current monotonic timestamp in nanoseconds. Must never go backwards.
    fn now_ns(&self) -> u64;
}

/// Production clock — wraps [`std::time::Instant`].
#[derive(Debug)]
pub struct StdClock {
    origin: Instant,
}

impl StdClock {
    /// Construct a new clock anchored at the current `Instant`.
    #[must_use]
    pub fn new() -> Self {
        Self {
            origin: Instant::now(),
        }
    }
}

impl Default for StdClock {
    fn default() -> Self {
        Self::new()
    }
}

impl Clock for StdClock {
    fn now_ns(&self) -> u64 {
        // Instant::elapsed() is monotonic on Linux; saturating cast to u64
        // is safe for any conceivable uptime (584 years at nanosecond resolution).
        self.origin.elapsed().as_nanos() as u64
    }
}

/// Deterministic clock for tests. Time advances only when `advance` is called.
#[derive(Debug)]
pub struct ManualClock {
    now: Cell<u64>,
}

impl ManualClock {
    /// Construct a manual clock at t=0.
    #[must_use]
    pub fn new() -> Self {
        Self { now: Cell::new(0) }
    }

    /// Construct a manual clock at a specific starting timestamp.
    #[must_use]
    pub fn at(ns: u64) -> Self {
        Self { now: Cell::new(ns) }
    }

    /// Advance the clock by `ns` nanoseconds.
    pub fn advance(&self, ns: u64) {
        self.now.set(self.now.get().saturating_add(ns));
    }

    /// Convenience: advance the clock by `ms` milliseconds.
    pub fn advance_ms(&self, ms: u64) {
        self.advance(ms.saturating_mul(1_000_000));
    }

    /// Convenience: advance the clock by `us` microseconds.
    pub fn advance_us(&self, us: u64) {
        self.advance(us.saturating_mul(1_000));
    }
}

impl Default for ManualClock {
    fn default() -> Self {
        Self::new()
    }
}

impl Clock for ManualClock {
    fn now_ns(&self) -> u64 {
        self.now.get()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn manual_clock_starts_at_zero() {
        let c = ManualClock::new();
        assert_eq!(c.now_ns(), 0);
    }

    #[test]
    fn manual_clock_advances() {
        let c = ManualClock::new();
        c.advance(1_000);
        assert_eq!(c.now_ns(), 1_000);
        c.advance_ms(5);
        assert_eq!(c.now_ns(), 5_001_000);
    }

    #[test]
    fn std_clock_is_monotonic() {
        let c = StdClock::new();
        let t1 = c.now_ns();
        let t2 = c.now_ns();
        assert!(t2 >= t1);
    }
}
