// jonerix-mlfq — Multi-Level Feedback Queue scheduler with macOS-style
// interactivity heuristics, designed for Linux sched_ext.
//
// PRIME DIRECTIVE: This is a clean-room implementation. No source code from
// the XNU/Mach scheduler, sched_ext example schedulers (scx_simple, scx_rusty,
// scx_lavd), or any other scheduler was consulted while authoring this code.
// The algorithm is derived from a behavioural specification only.
//
// On macOS, Mach IPC implicitly carries "this thread depends on that thread"
// hints. Linux has no equivalent signal. This crate compensates by inferring
// interactivity statistically from sleep duration, wakeup chains, and CPU
// burst length — see DESIGN.md for the full rationale.
//
// SAFETY: this crate contains zero `unsafe` blocks. `#![forbid(unsafe_code)]`
// is enforced at the crate root, and the `unsafe_code = "deny"` lint in
// Cargo.toml backstops it. All clock access goes through `std::time::Instant`,
// which is monotonic on Linux. The userland implementation does not call into
// libc. A future BPF/sched_ext binding crate would necessarily introduce
// unsafe blocks, but those would live in a separate `jonerix-mlfq-scx` crate.
#![forbid(unsafe_code)]
#![warn(missing_docs)]

//! Multi-Level Feedback Queue scheduler with interactivity heuristics
//! designed to compensate for the absence of Mach-IPC-style dependency
//! signals on Linux.
//!
//! See `README.md` and `DESIGN.md` for the algorithm overview.
//!
//! # Quick start
//!
//! ```
//! use jonerix_mlfq::{Scheduler, Policy, TaskId, ManualClock};
//!
//! let mut sched = Scheduler::new(ManualClock::new(), Policy::default());
//! sched.add_task(TaskId(1), 4);
//! sched.add_task(TaskId(2), 4);
//! let next = sched.pick_next();
//! assert!(next.is_some());
//! ```

pub mod clock;
pub mod policy;
pub mod queue;
pub mod scheduler;
pub mod task;

pub use clock::{Clock, ManualClock, StdClock};
pub use policy::Policy;
pub use queue::QueueLevel;
pub use scheduler::{PickReason, Scheduler, SchedulerStats, TickOutcome, WakeupOutcome};
pub use task::{SleepClass, TaskCtx, TaskId};
