// jonerix-mlfq — CLI front-end for the scheduler library.
//
// Two modes:
//   simulate          Run a synthetic workload (CPU hog + interactive UI
//                     thread + periodic poller) and print decisions made by
//                     the scheduler. Used for manual sanity-checking and
//                     regression demos.
//   inspect-policy    Print the active policy and exit.
//
// No FFI, no `unsafe`. The binary is a thin shell over the library.

use std::env;
use std::io::{self, Write};
use std::process::ExitCode;

use std::time::Instant;

use jonerix_mlfq::{ManualClock, Policy, Scheduler, SleepClass, StdClock, TaskId};

const VERSION: &str = env!("CARGO_PKG_VERSION");

fn usage(name: &str) {
    eprintln!("jonerix-mlfq {VERSION} — MLFQ scheduler with macOS-style heuristics");
    eprintln!();
    eprintln!("usage: {name} <subcommand>");
    eprintln!();
    eprintln!("subcommands:");
    eprintln!("  simulate              run a synthetic workload and print decisions");
    eprintln!("  bench [N]             real-clock micro-benchmark; N = task count (default 1024)");
    eprintln!("  inspect-policy        print active policy");
    eprintln!("  version               print version and exit");
    eprintln!("  help                  print this help");
}

fn main() -> ExitCode {
    let args: Vec<String> = env::args().collect();
    let name = args.first().map_or("jonerix-mlfq", String::as_str);
    let sub = args.get(1).map_or("help", String::as_str);

    match sub {
        "simulate" => simulate(),
        "bench" => {
            let n: u32 = args.get(2).and_then(|s| s.parse().ok()).unwrap_or(1024);
            bench(n)
        }
        "inspect-policy" => inspect_policy(),
        "version" | "--version" | "-V" => {
            println!("jonerix-mlfq {VERSION}");
            ExitCode::SUCCESS
        }
        "help" | "--help" | "-h" => {
            usage(name);
            ExitCode::SUCCESS
        }
        other => {
            eprintln!("jonerix-mlfq: unknown subcommand: {other}");
            usage(name);
            ExitCode::FAILURE
        }
    }
}

fn inspect_policy() -> ExitCode {
    let p = Policy::desktop();
    let out = io::stdout();
    let mut out = out.lock();
    let _ = writeln!(out, "spin_threshold_ns        = {}", p.spin_threshold_ns);
    let _ = writeln!(
        out,
        "interactive_threshold_ns = {}",
        p.interactive_threshold_ns
    );
    let _ = writeln!(out, "slice_ns                 = {}", p.slice_ns);
    let _ = writeln!(out, "long_slice_ns            = {}", p.long_slice_ns);
    let _ = writeln!(out, "boost_credit             = {}", p.boost_credit);
    let _ = writeln!(out, "chain_credit             = {}", p.chain_credit);
    let _ = writeln!(
        out,
        "cpu_decay                = {}/{}",
        p.cpu_decay_num, p.cpu_decay_den
    );
    let _ = writeln!(
        out,
        "credit_decay             = {}/{}",
        p.credit_decay_num, p.credit_decay_den
    );
    let _ = writeln!(out, "decay_tick_ns            = {}", p.decay_tick_ns);
    let _ = writeln!(out, "max_boosts_per_sec       = {}", p.max_boosts_per_sec);
    let _ = writeln!(out, "periodic_window          = {}", p.periodic_window);
    let _ = writeln!(out, "max_latency_credit       = {}", p.max_latency_credit);
    ExitCode::SUCCESS
}

fn simulate() -> ExitCode {
    let policy = Policy::desktop();
    let clock = ManualClock::new();
    let mut sched = Scheduler::new(clock, policy);

    // Three synthetic tasks:
    //   1 = CPU hog (never sleeps voluntarily)
    //   2 = interactive UI thread (5 ms sleep / 1 ms run cycle)
    //   3 = periodic poller (10 ms sleep, exactly, every loop)
    sched.add_task(TaskId(1), 4);
    sched.add_task(TaskId(2), 4);
    sched.add_task(TaskId(3), 4);

    let mut log = io::BufWriter::new(io::stdout().lock());
    let _ = writeln!(
        log,
        "# tick    event              tid    class           boost  chain  preempt"
    );

    for iter in 0..200 {
        // Tick the scheduler periodically (every 10 ms of sim time).
        sched.clock().advance_ms(1);
        let tick = sched.on_tick();
        if tick.long_slice_expired {
            if let Some(running) = sched.running() {
                let _ = writeln!(log, "{iter:>6}  long-slice-demote  {}", running.0);
                sched.on_long_slice(running);
            }
        }

        // Interactive UI thread cycle.
        if iter % 6 == 0 {
            sched.on_sleep(TaskId(2));
            sched.clock().advance_ms(5);
            let out = sched.on_wakeup(TaskId(2), None);
            let _ = writeln!(
                log,
                "{iter:>6}  wakeup             {:>3}    {:<14}  {:>3}    {:>3}    {}",
                2,
                sleep_class_name(out.class),
                if out.boosted { "yes" } else { "no" },
                if out.chain_inherited { "yes" } else { "no" },
                out.should_preempt,
            );
        }

        // Periodic poller — same cadence every time, should get flagged.
        if iter % 10 == 0 {
            sched.on_sleep(TaskId(3));
            sched.clock().advance_ms(10);
            let out = sched.on_wakeup(TaskId(3), None);
            let _ = writeln!(
                log,
                "{iter:>6}  wakeup             {:>3}    {:<14}  {:>3}    {:>3}    {}",
                3,
                sleep_class_name(out.class),
                if out.boosted { "yes" } else { "no" },
                if out.chain_inherited { "yes" } else { "no" },
                out.should_preempt,
            );
        }

        if sched.running().is_none() {
            if let Some(tid) = sched.pick_next() {
                let _ = writeln!(log, "{iter:>6}  pick-next          {:>3}", tid.0);
            }
        }
    }

    let s = sched.stats();
    let _ = writeln!(log);
    let _ = writeln!(log, "# summary");
    let _ = writeln!(log, "tasks                : {}", s.tasks);
    let _ = writeln!(log, "wakeups              : {}", s.wakeups);
    let _ = writeln!(log, "interactive_wakeups  : {}", s.interactive_wakeups);
    let _ = writeln!(log, "boosts_granted       : {}", s.boosts_granted);
    let _ = writeln!(log, "boosts_rate_limited  : {}", s.boosts_rate_limited);
    let _ = writeln!(log, "boosts_damped_periodic: {}", s.boosts_damped_periodic);
    let _ = writeln!(log, "chain_propagated     : {}", s.chain_propagated);
    let _ = writeln!(log, "preempt_events       : {}", s.preempt_events);
    let _ = writeln!(log, "long_slice_demotions : {}", s.long_slice_demotions);
    let _ = log.flush();
    ExitCode::SUCCESS
}

/// Real-clock micro-benchmark.
///
/// Drives the scheduler with N synthetic tasks using `StdClock` (monotonic
/// wall clock). Measures decisions/sec, ns per on_wakeup, ns per on_tick,
/// and p50/p99 latency for on_wakeup. Output is fixed-format `key = value`
/// lines so two runs (macOS vs Linux) can be diffed cleanly.
fn bench(n_tasks: u32) -> ExitCode {
    let policy = Policy::desktop();
    let clock = StdClock::new();
    let mut sched = Scheduler::new(clock, policy);

    // Bound the bench so it returns in a few hundred milliseconds.
    let iters: u32 = 50_000;

    for tid in 0..n_tasks {
        sched.add_task(TaskId(tid), 4);
    }

    let mut wakeup_samples: Vec<u64> = Vec::with_capacity(iters as usize);
    let mut tick_samples: Vec<u64> = Vec::with_capacity(iters as usize);

    // pick_next + tick + wakeup loop, measured with std::time::Instant.
    let bench_start = Instant::now();
    for i in 0..iters {
        let tid = TaskId(i % n_tasks);

        let t0 = Instant::now();
        let _ = sched.on_tick();
        tick_samples.push(t0.elapsed().as_nanos() as u64);

        // Every 4 iters, simulate a sleep+wake cycle on one task.
        if i % 4 == 0 {
            sched.on_sleep(tid);
            let t1 = Instant::now();
            let _ = sched.on_wakeup(tid, None);
            wakeup_samples.push(t1.elapsed().as_nanos() as u64);
        }

        if sched.running().is_none() {
            let _ = sched.pick_next();
        } else if i % 8 == 0 {
            if let Some(r) = sched.running() {
                sched.on_yield(r);
            }
        }
    }
    let elapsed = bench_start.elapsed();

    wakeup_samples.sort_unstable();
    tick_samples.sort_unstable();
    let p = |v: &[u64], pct: f64| -> u64 {
        if v.is_empty() {
            0
        } else {
            let idx = ((v.len() as f64 - 1.0) * pct).round() as usize;
            v[idx.min(v.len() - 1)]
        }
    };

    let stats = sched.stats();
    let decisions_per_sec = (iters as f64) / elapsed.as_secs_f64();

    let out = io::stdout();
    let mut o = io::BufWriter::new(out.lock());
    let _ = writeln!(o, "jonerix_mlfq_version    = {VERSION}");
    let _ = writeln!(o, "platform_os             = {}", std::env::consts::OS);
    let _ = writeln!(o, "platform_arch           = {}", std::env::consts::ARCH);
    let _ = writeln!(o, "tasks                   = {n_tasks}");
    let _ = writeln!(o, "iterations              = {iters}");
    let nanos = elapsed.as_nanos();
    let _ = writeln!(o, "wall_elapsed_ns         = {nanos}");
    let _ = writeln!(o, "decisions_per_sec       = {decisions_per_sec:.0}");
    let _ = writeln!(o, "on_tick_p50_ns          = {}", p(&tick_samples, 0.50));
    let _ = writeln!(o, "on_tick_p99_ns          = {}", p(&tick_samples, 0.99));
    let _ = writeln!(o, "on_wakeup_p50_ns        = {}", p(&wakeup_samples, 0.50));
    let _ = writeln!(o, "on_wakeup_p99_ns        = {}", p(&wakeup_samples, 0.99));
    let _ = writeln!(o, "wakeups_total           = {}", stats.wakeups);
    let _ = writeln!(o, "boosts_granted          = {}", stats.boosts_granted);
    let _ = writeln!(o, "boosts_rate_limited     = {}", stats.boosts_rate_limited);
    let _ = writeln!(o, "preempt_events          = {}", stats.preempt_events);
    let _ = o.flush();
    ExitCode::SUCCESS
}

fn sleep_class_name(c: SleepClass) -> &'static str {
    match c {
        SleepClass::None => "none",
        SleepClass::Spin => "spin",
        SleepClass::Interactive => "interactive",
        SleepClass::Background => "background",
    }
}
