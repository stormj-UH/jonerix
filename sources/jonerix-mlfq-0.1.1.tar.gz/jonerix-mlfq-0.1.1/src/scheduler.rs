//! Core MLFQ scheduler.
//!
//! Implements the algorithm described in `DESIGN.md`:
//!
//! 1. Sleep-duration-based interactive classification (no Mach IPC).
//! 2. Wakeup boost: tasks that wake from an interactive-range sleep are
//!    promoted to the top queue, marked latency-sensitive, and the running
//!    task is preempted.
//! 3. Wakeup chains: when a latency-sensitive task wakes another task, a
//!    smaller chain credit is propagated. This approximates "UI thread →
//!    worker → render thread" dependency tracking that Mach IPC does
//!    implicitly.
//! 4. Aggressive CPU-usage decay so a CPU-bound task can't permanently lock
//!    out interactive work after a one-shot priority boost.
//! 5. CPU-bound penalty: any task that runs `>= long_slice_ns` without
//!    sleeping is demoted one level. This is the explicit fallback for the
//!    decay-based implicit penalty.
//! 6. Latency credit replaces explicit priority donation. Credit is awarded
//!    on interactive wakeup or long-idle wakeup; effective priority =
//!    base + cpu_penalty − credit_levels.
//! 7. Aggressive preemption: if a wakeup produces a task whose effective
//!    priority strictly outranks the running task, the running task is
//!    preempted immediately. No fairness damping.
//! 8. False-positive mitigation: per-task boost-frequency cap (max
//!    `policy.max_boosts_per_sec`) and periodic-wakeup detection both
//!    prevent a polling daemon from holding the interactive band.

use std::collections::HashMap;

use crate::clock::Clock;
use crate::policy::{Policy, NUM_QUEUES};
use crate::queue::{MultiQueue, QueueLevel};
use crate::task::{SleepClass, TaskCtx, TaskId, TaskState};

/// What happened on a wakeup. Returned from
/// [`Scheduler::on_wakeup`] so callers (or kernel-side BPF dispatch) can
/// preempt the current CPU or schedule an IPI.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct WakeupOutcome {
    /// Classification of the sleep that just ended.
    pub class: SleepClass,
    /// Whether the wakee was boosted (placed near the top queue).
    pub boosted: bool,
    /// Whether the boost was damped because the task is periodic.
    pub damped_periodic: bool,
    /// Whether the boost-frequency cap fired (no credit awarded).
    pub rate_limited: bool,
    /// Whether a chain credit was propagated from a latency-sensitive waker.
    pub chain_inherited: bool,
    /// Whether the currently-running task should be preempted.
    pub should_preempt: bool,
}

/// Result of [`Scheduler::on_tick`].
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub struct TickOutcome {
    /// Whether decay was applied to all tasks this tick.
    pub decayed: bool,
    /// Whether the running task should be preempted because it exceeded
    /// its long-slice budget.
    pub long_slice_expired: bool,
    /// Whether the running task should be preempted because someone with a
    /// better score is now runnable.
    pub outranked: bool,
}

/// Why a particular task was picked.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum PickReason {
    /// Picked because it had the lowest queue index.
    Highest,
    /// Idle — no runnable task.
    Idle,
}

/// Aggregate scheduler counters for introspection / Prometheus export.
#[derive(Debug, Clone, Copy, Default)]
pub struct SchedulerStats {
    /// Number of tasks tracked.
    pub tasks: u64,
    /// Total wakeups handled.
    pub wakeups: u64,
    /// Interactive-class wakeups (i.e. boost-eligible by sleep duration).
    pub interactive_wakeups: u64,
    /// Boosts actually granted.
    pub boosts_granted: u64,
    /// Boosts denied by rate limit.
    pub boosts_rate_limited: u64,
    /// Boosts damped because the waker was flagged periodic.
    pub boosts_damped_periodic: u64,
    /// Chain credits propagated from latency-sensitive waker → wakee.
    pub chain_propagated: u64,
    /// Total preempt events emitted.
    pub preempt_events: u64,
    /// Long-slice demotions.
    pub long_slice_demotions: u64,
}

/// The scheduler itself.
#[derive(Debug)]
pub struct Scheduler<C: Clock> {
    clock: C,
    policy: Policy,
    tasks: HashMap<TaskId, TaskCtx>,
    queues: MultiQueue,
    /// Currently-running task, if any.
    running: Option<TaskId>,
    /// Monotonic timestamp of the last decay tick.
    last_decay_ns: u64,
    /// Aggregate counters.
    stats: SchedulerStats,
}

impl<C: Clock> Scheduler<C> {
    /// Construct a new scheduler.
    pub fn new(clock: C, policy: Policy) -> Self {
        let now = clock.now_ns();
        Self {
            clock,
            policy,
            tasks: HashMap::new(),
            queues: MultiQueue::new(),
            running: None,
            last_decay_ns: now,
            stats: SchedulerStats::default(),
        }
    }

    /// Borrow the policy.
    #[must_use]
    pub fn policy(&self) -> &Policy {
        &self.policy
    }

    /// Borrow the inner clock.
    #[must_use]
    pub fn clock(&self) -> &C {
        &self.clock
    }

    /// Currently-running task, if any.
    #[must_use]
    pub fn running(&self) -> Option<TaskId> {
        self.running
    }

    /// Aggregate counters.
    #[must_use]
    pub fn stats(&self) -> SchedulerStats {
        let mut s = self.stats;
        s.tasks = self.tasks.len() as u64;
        s
    }

    /// Borrow a task context (for introspection / tests).
    #[must_use]
    pub fn task_ctx(&self, tid: TaskId) -> Option<&TaskCtx> {
        self.tasks.get(&tid)
    }

    /// Add a new task at `base_priority` and enqueue it.
    pub fn add_task(&mut self, tid: TaskId, base_priority: u8) {
        let now = self.clock.now_ns();
        let ctx = TaskCtx::new(tid, base_priority, now, &self.policy);
        let level = QueueLevel(ctx.current_queue);
        self.tasks.insert(tid, ctx);
        self.queues.enqueue(level, tid);
    }

    /// Remove a task. Returns true if it was tracked.
    pub fn remove_task(&mut self, tid: TaskId) -> bool {
        if let Some(ctx) = self.tasks.remove(&tid) {
            if matches!(ctx.state, TaskState::Runnable) {
                self.queues.remove_any(tid);
            }
            if self.running == Some(tid) {
                self.running = None;
            }
            true
        } else {
            false
        }
    }

    /// Iterate all tracked task IDs (for stats / introspection / tests).
    pub fn task_ids(&self) -> impl Iterator<Item = TaskId> + '_ {
        self.tasks.keys().copied()
    }

    /// Handle a wakeup. `waker` is the task that performed the wakeup, if
    /// known — used for chain-boost propagation.
    pub fn on_wakeup(&mut self, tid: TaskId, waker: Option<TaskId>) -> WakeupOutcome {
        let now = self.clock.now_ns();
        self.stats.wakeups += 1;

        // Pull the waker's latency-sensitive flag now, before we mutably
        // borrow the wakee context.
        let waker_sensitive = waker
            .and_then(|w| self.tasks.get(&w))
            .is_some_and(|t| t.is_latency_sensitive);

        let Some(ctx) = self.tasks.get_mut(&tid) else {
            return WakeupOutcome {
                class: SleepClass::None,
                boosted: false,
                damped_periodic: false,
                rate_limited: false,
                chain_inherited: false,
                should_preempt: false,
            };
        };

        let sleep_ns = now.saturating_sub(ctx.last_sleep_ns);
        let class = TaskCtx::classify(sleep_ns, &self.policy);
        ctx.last_sleep_class = class;
        ctx.record_sleep(sleep_ns, &self.policy);

        // Default outcome — adjusted below.
        let mut boosted = false;
        let mut damped_periodic = false;
        let mut rate_limited = false;
        let mut chain_inherited = false;

        match class {
            SleepClass::Interactive => {
                self.stats.interactive_wakeups += 1;
                let was_periodic = ctx.is_periodic;
                let granted = ctx.try_boost(self.policy.boost_credit, now, &self.policy);
                if granted {
                    self.stats.boosts_granted += 1;
                    boosted = true;
                    if was_periodic {
                        damped_periodic = true;
                        self.stats.boosts_damped_periodic += 1;
                    }
                } else {
                    rate_limited = true;
                    self.stats.boosts_rate_limited += 1;
                }
            }
            SleepClass::Background => {
                // Long sleep — give a small bump so the task isn't starved when
                // it returns from disk I/O, but don't boost to interactive.
                let granted = ctx.try_boost(self.policy.chain_credit / 2, now, &self.policy);
                if granted {
                    self.stats.boosts_granted += 1;
                    boosted = true;
                }
            }
            // Spin and None: no boost.
            SleepClass::Spin | SleepClass::None => {}
        }

        // Wakeup-chain propagation: if the waker is latency-sensitive, the
        // wakee inherits a smaller chain credit. This approximates the
        // implicit dependency tracking that Mach IPC carries on every send.
        // We DO propagate on spin wakeups: a UI thread holding a lock that
        // releases to a worker is still a meaningful dependency chain even
        // though the worker's sleep was short.
        if waker_sensitive && !matches!(class, SleepClass::None) {
            let granted = ctx.try_boost(self.policy.chain_credit, now, &self.policy);
            if granted {
                chain_inherited = true;
                self.stats.chain_propagated += 1;
            }
        }

        ctx.state = TaskState::Runnable;
        let target = QueueLevel(ctx.target_queue(&self.policy));
        ctx.current_queue = target.0;

        // Enqueue. If boosted, jump the queue (push to front of target queue).
        if boosted || chain_inherited {
            self.queues.enqueue_front(target, tid);
        } else {
            self.queues.enqueue(target, tid);
        }

        // Decide whether the running task should be preempted.
        let should_preempt = self.compute_should_preempt(tid);
        if should_preempt {
            self.stats.preempt_events += 1;
        }

        WakeupOutcome {
            class,
            boosted,
            damped_periodic,
            rate_limited,
            chain_inherited,
            should_preempt,
        }
    }

    /// Internal: should the wakeup of `wakee` preempt the running task?
    fn compute_should_preempt(&self, wakee: TaskId) -> bool {
        let Some(running) = self.running else {
            // CPU is idle — yes, run the wakee.
            return true;
        };
        if running == wakee {
            return false;
        }
        let Some(rctx) = self.tasks.get(&running) else {
            return false;
        };
        let Some(wctx) = self.tasks.get(&wakee) else {
            return false;
        };
        // Lower score = higher priority.
        wctx.score(&self.policy) < rctx.score(&self.policy)
    }

    /// Handle a task going to sleep (off-CPU, blocked).
    pub fn on_sleep(&mut self, tid: TaskId) {
        let now = self.clock.now_ns();
        let was_running = self.running == Some(tid);
        if was_running {
            self.running = None;
        }
        if let Some(ctx) = self.tasks.get_mut(&tid) {
            if was_running {
                // Only charge cpu_usage for time the task was actually on-CPU.
                // A task that was merely Runnable (queued) hasn't consumed CPU.
                let ran_ns = now.saturating_sub(ctx.last_run_in_ns);
                ctx.cpu_usage_ns = ctx.cpu_usage_ns.saturating_add(ran_ns);
                ctx.last_run_out_ns = now;
            }
            ctx.last_sleep_ns = now;
            ctx.state = TaskState::Sleeping;
            // Sleeping tasks aren't on a run queue.
            self.queues.remove_any(tid);
        }
    }

    /// Handle a task yielding the CPU but remaining runnable (e.g. slice
    /// exhausted, voluntary yield). Returns the level the task was
    /// re-enqueued at.
    pub fn on_yield(&mut self, tid: TaskId) -> QueueLevel {
        let now = self.clock.now_ns();
        let was_running = self.running == Some(tid);
        if was_running {
            self.running = None;
        }
        // Default level in case the task disappears mid-yield (shouldn't, but).
        let mut level = QueueLevel(Self::policy_base_default());
        if let Some(ctx) = self.tasks.get_mut(&tid) {
            if was_running {
                let ran_ns = now.saturating_sub(ctx.last_run_in_ns);
                ctx.cpu_usage_ns = ctx.cpu_usage_ns.saturating_add(ran_ns);
                ctx.last_run_out_ns = now;
            }
            ctx.state = TaskState::Runnable;
            level = QueueLevel(ctx.target_queue(&self.policy));
            ctx.current_queue = level.0;
        }
        self.queues.enqueue(level, tid);
        level
    }

    /// Handle the slice expiring for a task that has run for `>= long_slice_ns`
    /// without sleeping. Demotes one queue level.
    pub fn on_long_slice(&mut self, tid: TaskId) -> QueueLevel {
        let now = self.clock.now_ns();
        self.stats.long_slice_demotions += 1;
        let was_running = self.running == Some(tid);
        if was_running {
            self.running = None;
        }
        let mut level = QueueLevel(Self::policy_base_default());
        if let Some(ctx) = self.tasks.get_mut(&tid) {
            if was_running {
                let ran_ns = now.saturating_sub(ctx.last_run_in_ns);
                ctx.cpu_usage_ns = ctx.cpu_usage_ns.saturating_add(ran_ns);
                ctx.last_run_out_ns = now;
            }
            ctx.state = TaskState::Runnable;
            // Demote one level from where the task was last queued. The
            // cpu_penalty contribution to score() handles the "how far off
            // the interactive band did this task get" — long-slice is an
            // explicit, *visible* additional step that says "you ran past
            // your budget right now". On the next voluntary yield the task
            // will be re-evaluated via target_queue() and may sink further
            // if cpu_usage_ns has grown.
            let demoted = ctx
                .current_queue
                .saturating_add(1)
                .min(NUM_QUEUES as u8 - 1);
            ctx.current_queue = demoted;
            ctx.is_latency_sensitive = false;
            // CPU-bound tasks shouldn't carry interactive credit.
            ctx.latency_credit = ctx.latency_credit.min(0);
            level = QueueLevel(demoted);
        }
        self.queues.enqueue(level, tid);
        level
    }

    fn policy_base_default() -> u8 {
        (NUM_QUEUES as u8 - 1) / 2
    }

    /// Pick the next task to run. Removes the picked task from its queue
    /// and marks it `Running`.
    pub fn pick_next(&mut self) -> Option<TaskId> {
        let now = self.clock.now_ns();
        let (_, tid) = self.queues.pop_min()?;
        if let Some(ctx) = self.tasks.get_mut(&tid) {
            ctx.state = TaskState::Running;
            ctx.last_run_in_ns = now;
        }
        self.running = Some(tid);
        Some(tid)
    }

    /// Periodic tick (e.g. every scheduler tick or 1 ms timer). Applies
    /// decay when due, and reports whether the running task should be
    /// preempted because it exceeded its long-slice budget or got
    /// outranked by a wakeup.
    pub fn on_tick(&mut self) -> TickOutcome {
        let now = self.clock.now_ns();
        let mut outcome = TickOutcome::default();

        // Long-slice check — has the running task been on-CPU for at least
        // `long_slice_ns` continuous nanoseconds since dispatch? cpu_usage_ns
        // is charged on the next on_long_slice / on_yield / on_sleep call,
        // and decay keeps the bound stable.
        if let Some(running) = self.running {
            if let Some(ctx) = self.tasks.get(&running) {
                let dispatch_age_ns = now.saturating_sub(ctx.last_run_in_ns);
                if dispatch_age_ns >= self.policy.long_slice_ns {
                    outcome.long_slice_expired = true;
                }
            }
        }

        // Decay tick.
        if now.saturating_sub(self.last_decay_ns) >= self.policy.decay_tick_ns {
            for ctx in self.tasks.values_mut() {
                ctx.decay(&self.policy);
            }
            self.last_decay_ns = now;
            outcome.decayed = true;
        }

        if let Some(running) = self.running {
            // Outranked check — is the head of the highest-priority queue
            // strictly better than the running task?
            if let Some((_, head)) = self.queues.peek_min() {
                if head != running {
                    if let (Some(r), Some(h)) = (self.tasks.get(&running), self.tasks.get(&head)) {
                        if h.score(&self.policy) < r.score(&self.policy) {
                            outcome.outranked = true;
                        }
                    }
                }
            }
        }

        outcome
    }

    /// Update the policy. Existing queued tasks keep their current level
    /// until the next pick / wakeup.
    pub fn set_policy(&mut self, policy: Policy) {
        self.policy = policy;
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::clock::ManualClock;

    fn fresh() -> Scheduler<ManualClock> {
        Scheduler::new(ManualClock::new(), Policy::desktop())
    }

    #[test]
    fn add_and_pick_one_task() {
        let mut s = fresh();
        s.add_task(TaskId(1), 4);
        assert_eq!(s.pick_next(), Some(TaskId(1)));
        assert_eq!(s.pick_next(), None);
    }

    #[test]
    fn interactive_wakeup_promotes_above_running_cpu_bound() {
        let mut s = fresh();
        s.add_task(TaskId(1), 4); // cpu hog
        s.add_task(TaskId(2), 4); // interactive

        // tid=1 starts running; advance time to accumulate cpu_usage.
        assert_eq!(s.pick_next(), Some(TaskId(1)));
        s.clock().advance_ms(50);
        // tid=2 goes to sleep then wakes after 5 ms (interactive range).
        s.on_sleep(TaskId(2));
        s.clock().advance_ms(5);
        let out = s.on_wakeup(TaskId(2), None);

        assert!(matches!(out.class, SleepClass::Interactive));
        assert!(out.boosted, "interactive wakeup should boost");
        assert!(
            out.should_preempt,
            "interactive wakeup should preempt cpu hog"
        );
    }

    #[test]
    fn spin_wakeup_does_not_boost() {
        let mut s = fresh();
        s.add_task(TaskId(1), 4);
        s.on_sleep(TaskId(1));
        s.clock().advance_us(500); // 0.5 ms — spin range
        let out = s.on_wakeup(TaskId(1), None);
        assert!(matches!(out.class, SleepClass::Spin));
        assert!(!out.boosted);
    }

    #[test]
    fn background_wakeup_gives_small_boost() {
        let mut s = fresh();
        s.add_task(TaskId(1), 4);
        s.on_sleep(TaskId(1));
        s.clock().advance_ms(500);
        let out = s.on_wakeup(TaskId(1), None);
        assert!(matches!(out.class, SleepClass::Background));
        // Small boost is fine; the contract is only "boosted, not interactive class"
        let _ = out.boosted;
    }

    #[test]
    fn wakeup_chain_propagates_credit() {
        let mut s = fresh();
        s.add_task(TaskId(1), 4);
        s.add_task(TaskId(2), 4);
        // Make tid=1 latency-sensitive by sleeping/waking once.
        s.on_sleep(TaskId(1));
        s.clock().advance_ms(5);
        s.on_wakeup(TaskId(1), None);
        assert!(s.task_ctx(TaskId(1)).unwrap().is_latency_sensitive);

        // tid=2 had only a spin sleep (no boost from that), but waker tid=1 is
        // latency-sensitive — chain credit should fire.
        s.on_sleep(TaskId(2));
        s.clock().advance_us(500);
        let out = s.on_wakeup(TaskId(2), Some(TaskId(1)));
        assert!(
            out.chain_inherited,
            "chain credit should propagate from latency-sensitive waker"
        );
    }

    #[test]
    fn rate_limit_kicks_in_on_burst_wakeups() {
        let mut s = fresh();
        s.add_task(TaskId(1), 4);

        let mut limited = 0;
        for _ in 0..(s.policy().max_boosts_per_sec + 5) {
            s.on_sleep(TaskId(1));
            s.clock().advance_ms(5); // interactive class
            let out = s.on_wakeup(TaskId(1), None);
            if out.rate_limited {
                limited += 1;
            }
        }
        assert!(limited >= 5);
    }

    #[test]
    fn long_slice_demotes() {
        let mut s = fresh();
        s.add_task(TaskId(1), 4);
        let initial = s.task_ctx(TaskId(1)).unwrap().current_queue;
        assert_eq!(s.pick_next(), Some(TaskId(1)));
        s.clock().advance_ms(25);
        let level = s.on_long_slice(TaskId(1));
        assert!(
            level.0 > initial,
            "long-slice should demote at least 1 level"
        );
    }

    #[test]
    fn decay_runs_on_tick() {
        let mut s = fresh();
        s.add_task(TaskId(1), 4);
        // Give a big cpu_usage manually so decay has something to shrink.
        let ctx = s.task_ctx(TaskId(1)).unwrap().clone();
        let _ = ctx; // borrow check appeasement; mutate via on_yield path
        s.clock().advance_ms(50);
        // Move to running, then advance and yield to accumulate cpu_usage.
        s.pick_next();
        s.clock().advance_ms(5);
        s.on_yield(TaskId(1));
        let cpu_before = s.task_ctx(TaskId(1)).unwrap().cpu_usage_ns;
        assert!(cpu_before > 0);
        s.clock().advance_ms(150);
        let tick = s.on_tick();
        assert!(tick.decayed);
        let cpu_after = s.task_ctx(TaskId(1)).unwrap().cpu_usage_ns;
        assert!(cpu_after < cpu_before, "decay should shrink cpu_usage");
    }

    #[test]
    fn fifo_preserved_within_a_level_after_yield() {
        let mut s = fresh();
        s.add_task(TaskId(1), 4);
        s.add_task(TaskId(2), 4);
        s.add_task(TaskId(3), 4);
        let a = s.pick_next().unwrap();
        s.on_yield(a);
        let b = s.pick_next().unwrap();
        let c = s.pick_next().unwrap();
        let d = s.pick_next().unwrap();
        // All three rotate through.
        assert_eq!([a, b, c, d], [TaskId(1), TaskId(2), TaskId(3), TaskId(1)]);
    }

    #[test]
    fn idle_picks_none() {
        let mut s = fresh();
        assert_eq!(s.pick_next(), None);
    }

    #[test]
    fn wakeup_into_idle_cpu_preempts() {
        let mut s = fresh();
        s.add_task(TaskId(1), 4);
        s.on_sleep(TaskId(1));
        s.clock().advance_ms(5);
        let out = s.on_wakeup(TaskId(1), None);
        assert!(
            out.should_preempt,
            "wakeup onto idle CPU should preempt (i.e. dispatch)"
        );
    }
}
