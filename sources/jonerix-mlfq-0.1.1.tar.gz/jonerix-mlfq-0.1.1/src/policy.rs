//! Tunable scheduler constants.
//!
//! Defaults are tuned for desktop workloads on contemporary laptop hardware
//! (compositor at 60–144 Hz, audio in 5–10 ms callbacks). For server or
//! batch workloads, lower `boost_credit` and raise `cpu_decay_tick_ns` to
//! reduce false-positive boosting of polling-style daemons.

/// Number of run queues. Index 0 is the highest priority.
///
/// Eight levels gives 3 bits of dynamic range for priority adjustments,
/// matching XNU's eight scheduler "bands" without claiming behavioural parity.
pub const NUM_QUEUES: usize = 8;

/// Tunable scheduler constants. See module docs for tuning notes.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Policy {
    /// Sleeps shorter than this are treated as spin/contention, not interactive sleep.
    /// Tasks that "sleep" for <2 ms are usually contending on a lock or short
    /// futex — they should NOT be promoted to the interactive band.
    pub spin_threshold_ns: u64,

    /// Sleeps in `[spin_threshold_ns, interactive_threshold_ns]` are
    /// classified as interactive. This window is where UI, audio, and
    /// network event loops live on a desktop system.
    pub interactive_threshold_ns: u64,

    /// Default time slice (preemption budget) per pick_next decision.
    pub slice_ns: u64,

    /// A task that runs `>=long_slice_ns` continuously without sleeping is
    /// demoted toward CPU-bound. This is the "ran too long" tripwire.
    pub long_slice_ns: u64,

    /// Credit awarded for an interactive-range wakeup.
    pub boost_credit: i32,

    /// Credit propagated along a wakeup chain to the wakee when the waker
    /// is currently latency-sensitive.
    pub chain_credit: i32,

    /// Multiplicative decay applied to `cpu_usage` each decay tick. Stored
    /// as numerator/denominator to avoid floating point in the hot path.
    /// Default 7/10 = 0.7 (aggressive).
    pub cpu_decay_num: u32,
    /// Multiplicative decay applied to `cpu_usage` each decay tick.
    pub cpu_decay_den: u32,

    /// Multiplicative decay applied to `latency_credit` each decay tick.
    /// Stored as numerator/denominator. Default 1/2 = 0.5 (very fast).
    pub credit_decay_num: u32,
    /// Multiplicative decay applied to `latency_credit` each decay tick.
    pub credit_decay_den: u32,

    /// Period at which decay runs.
    pub decay_tick_ns: u64,

    /// Max wakeup boosts a single task can earn per second. Prevents a
    /// high-frequency network daemon from holding the interactive band.
    pub max_boosts_per_sec: u32,

    /// Number of recent sleep durations a task remembers (for periodic
    /// wakeup detection — see [`crate::task::TaskCtx::is_periodic`]).
    pub periodic_window: usize,

    /// If the relative variance of the recent sleep window is below this
    /// fraction (numerator/1000), the task is considered periodic and
    /// loses interactive credit. Default 100/1000 = 10%.
    pub periodic_variance_num: u32,
    /// Periodic-detection denominator. Variance numerator is over this base.
    pub periodic_variance_den: u32,

    /// Base CPU-usage penalty exponent — `cpu_usage` is shifted right by
    /// this before being subtracted from priority. Larger = gentler.
    pub cpu_penalty_shift: u32,

    /// Cap on absolute latency_credit, so a task that wakes interactively
    /// for hours can't accumulate unbounded priority.
    pub max_latency_credit: i32,
}

impl Policy {
    /// Default policy tuned for desktop/laptop workloads.
    #[must_use]
    pub const fn desktop() -> Self {
        Self {
            spin_threshold_ns: 2_000_000,         // 2 ms
            interactive_threshold_ns: 50_000_000, // 50 ms
            slice_ns: 5_000_000,                  // 5 ms slice
            long_slice_ns: 20_000_000,            // 20 ms = "ran too long"
            boost_credit: 100,
            chain_credit: 50,
            cpu_decay_num: 7,
            cpu_decay_den: 10,
            credit_decay_num: 1,
            credit_decay_den: 2,
            decay_tick_ns: 100_000_000, // 100 ms decay tick
            max_boosts_per_sec: 50,
            periodic_window: 5,
            periodic_variance_num: 100,
            periodic_variance_den: 1000,
            cpu_penalty_shift: 20, // cpu_usage_ns >> 20 ≈ ms-scale penalty
            max_latency_credit: 1_000,
        }
    }

    /// Server/batch policy — gentler interactive boosts, slower decay.
    #[must_use]
    pub const fn server() -> Self {
        Self {
            spin_threshold_ns: 2_000_000,
            interactive_threshold_ns: 20_000_000, // tighter interactive window
            slice_ns: 10_000_000,
            long_slice_ns: 100_000_000,
            boost_credit: 40,
            chain_credit: 20,
            cpu_decay_num: 9,
            cpu_decay_den: 10,
            credit_decay_num: 2,
            credit_decay_den: 3,
            decay_tick_ns: 250_000_000,
            max_boosts_per_sec: 20,
            periodic_window: 5,
            periodic_variance_num: 100,
            periodic_variance_den: 1000,
            cpu_penalty_shift: 18,
            max_latency_credit: 400,
        }
    }
}

impl Default for Policy {
    fn default() -> Self {
        Self::desktop()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn desktop_invariants() {
        let p = Policy::desktop();
        assert!(p.spin_threshold_ns < p.interactive_threshold_ns);
        assert!(p.slice_ns < p.long_slice_ns);
        assert!(p.cpu_decay_num <= p.cpu_decay_den);
        assert!(p.credit_decay_num <= p.credit_decay_den);
        assert!(p.boost_credit > 0);
        assert!(p.chain_credit > 0);
        assert!(p.chain_credit <= p.boost_credit);
    }

    #[test]
    fn server_invariants() {
        let p = Policy::server();
        assert!(p.spin_threshold_ns < p.interactive_threshold_ns);
        assert!(p.slice_ns < p.long_slice_ns);
        // Server boost should be ≤ desktop boost (less aggressive)
        assert!(p.boost_credit <= Policy::desktop().boost_credit);
    }
}
