//! Multi-level FIFO run queues.
//!
//! `NUM_QUEUES` ordered queues, index 0 = highest priority. Each queue is a
//! FIFO of [`TaskId`]s. `O(NUM_QUEUES)` to find the highest non-empty
//! queue, which is fine for the 8-level default — a bitmap variant lives in
//! `pick_min_bitmap` and is benchmarked in `benches/`.

use crate::policy::NUM_QUEUES;
use crate::task::TaskId;
use std::collections::VecDeque;

/// Queue index. Stored as a separate type so the rest of the code can't
/// accidentally pass a priority where a queue level is expected.
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord)]
pub struct QueueLevel(pub u8);

impl QueueLevel {
    /// The highest-priority (numerically lowest) queue.
    pub const TOP: Self = Self(0);
    /// The lowest-priority (numerically highest) queue.
    pub const BOTTOM: Self = Self(NUM_QUEUES as u8 - 1);

    /// Construct a queue level, clamped into `[0, NUM_QUEUES-1]`.
    #[must_use]
    pub fn clamped(v: i32) -> Self {
        Self(v.clamp(0, NUM_QUEUES as i32 - 1) as u8)
    }
}

/// Multi-level FIFO run queues.
#[derive(Debug, Default)]
pub struct MultiQueue {
    queues: [VecDeque<TaskId>; NUM_QUEUES],
    /// Bitmask of non-empty queues — bit `i` set ⇔ `queues[i]` non-empty.
    /// Maintained as queues mutate so `pick_min` is O(1) via `trailing_zeros`.
    occupancy: u16,
}

impl MultiQueue {
    /// Construct an empty multi-queue.
    #[must_use]
    pub fn new() -> Self {
        Self::default()
    }

    /// Enqueue `tid` at the tail of queue `level`.
    pub fn enqueue(&mut self, level: QueueLevel, tid: TaskId) {
        let idx = level.0 as usize;
        debug_assert!(idx < NUM_QUEUES);
        self.queues[idx].push_back(tid);
        self.occupancy |= 1u16 << idx;
    }

    /// Enqueue `tid` at the *head* of queue `level` — used when a wakeup
    /// promotes a task and we want it to run immediately.
    pub fn enqueue_front(&mut self, level: QueueLevel, tid: TaskId) {
        let idx = level.0 as usize;
        debug_assert!(idx < NUM_QUEUES);
        self.queues[idx].push_front(tid);
        self.occupancy |= 1u16 << idx;
    }

    /// Remove `tid` from queue `level`. Returns true if found.
    /// O(queue length).
    pub fn remove(&mut self, level: QueueLevel, tid: TaskId) -> bool {
        let idx = level.0 as usize;
        debug_assert!(idx < NUM_QUEUES);
        let q = &mut self.queues[idx];
        let pos = q.iter().position(|&x| x == tid);
        if let Some(pos) = pos {
            q.remove(pos);
            if q.is_empty() {
                self.occupancy &= !(1u16 << idx);
            }
            true
        } else {
            false
        }
    }

    /// Remove `tid` regardless of which queue it sits on. Returns the
    /// queue level it was found on, or None.
    pub fn remove_any(&mut self, tid: TaskId) -> Option<QueueLevel> {
        for idx in 0..NUM_QUEUES {
            if self.queues[idx].iter().any(|&x| x == tid) {
                let level = QueueLevel(idx as u8);
                self.remove(level, tid);
                return Some(level);
            }
        }
        None
    }

    /// Pop the head of the highest-priority non-empty queue. O(1).
    pub fn pop_min(&mut self) -> Option<(QueueLevel, TaskId)> {
        if self.occupancy == 0 {
            return None;
        }
        let idx = self.occupancy.trailing_zeros() as usize;
        let tid = self.queues[idx].pop_front()?;
        if self.queues[idx].is_empty() {
            self.occupancy &= !(1u16 << idx);
        }
        Some((QueueLevel(idx as u8), tid))
    }

    /// Peek the head of the highest-priority non-empty queue. O(1).
    #[must_use]
    pub fn peek_min(&self) -> Option<(QueueLevel, TaskId)> {
        if self.occupancy == 0 {
            return None;
        }
        let idx = self.occupancy.trailing_zeros() as usize;
        self.queues[idx]
            .front()
            .copied()
            .map(|t| (QueueLevel(idx as u8), t))
    }

    /// Total number of enqueued tasks across all levels.
    #[must_use]
    pub fn len(&self) -> usize {
        self.queues.iter().map(VecDeque::len).sum()
    }

    /// True if no task is enqueued.
    #[must_use]
    pub fn is_empty(&self) -> bool {
        self.occupancy == 0
    }

    /// Number of tasks at a given level.
    #[must_use]
    pub fn level_len(&self, level: QueueLevel) -> usize {
        self.queues[level.0 as usize].len()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn fifo_within_level() {
        let mut q = MultiQueue::new();
        q.enqueue(QueueLevel(3), TaskId(1));
        q.enqueue(QueueLevel(3), TaskId(2));
        q.enqueue(QueueLevel(3), TaskId(3));
        assert_eq!(q.pop_min(), Some((QueueLevel(3), TaskId(1))));
        assert_eq!(q.pop_min(), Some((QueueLevel(3), TaskId(2))));
        assert_eq!(q.pop_min(), Some((QueueLevel(3), TaskId(3))));
        assert_eq!(q.pop_min(), None);
    }

    #[test]
    fn pop_min_prefers_lower_index() {
        let mut q = MultiQueue::new();
        q.enqueue(QueueLevel(5), TaskId(10));
        q.enqueue(QueueLevel(2), TaskId(20));
        q.enqueue(QueueLevel(7), TaskId(30));
        // Should pop level 2 first, then 5, then 7.
        assert_eq!(q.pop_min().map(|(_, t)| t), Some(TaskId(20)));
        assert_eq!(q.pop_min().map(|(_, t)| t), Some(TaskId(10)));
        assert_eq!(q.pop_min().map(|(_, t)| t), Some(TaskId(30)));
    }

    #[test]
    fn enqueue_front_jumps_the_queue() {
        let mut q = MultiQueue::new();
        q.enqueue(QueueLevel(3), TaskId(1));
        q.enqueue(QueueLevel(3), TaskId(2));
        q.enqueue_front(QueueLevel(3), TaskId(99));
        assert_eq!(q.pop_min(), Some((QueueLevel(3), TaskId(99))));
    }

    #[test]
    fn remove_clears_occupancy() {
        let mut q = MultiQueue::new();
        q.enqueue(QueueLevel(4), TaskId(7));
        assert!(q.remove(QueueLevel(4), TaskId(7)));
        assert!(q.is_empty());
        assert_eq!(q.pop_min(), None);
    }

    #[test]
    fn remove_any_finds_it() {
        let mut q = MultiQueue::new();
        q.enqueue(QueueLevel(6), TaskId(42));
        assert_eq!(q.remove_any(TaskId(42)), Some(QueueLevel(6)));
        assert!(q.is_empty());
    }
}
