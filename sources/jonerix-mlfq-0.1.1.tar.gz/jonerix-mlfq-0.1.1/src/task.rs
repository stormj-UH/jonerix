//! Per-task scheduler context.

use crate::policy::{Policy, NUM_QUEUES};
use std::collections::VecDeque;

/// Opaque task identifier. Maps 1:1 to a kernel TID in sched_ext deployments
/// and to any unique numeric handle in userland simulations.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord)]
pub struct TaskId(pub u32);

/// Classification of the most recent sleep duration. Drives the wakeup
/// boost decision in [`crate::scheduler::Scheduler::on_wakeup`].
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum SleepClass {
    /// New task or no prior sleep recorded.
    None,
    /// `<spin_threshold_ns` — contention/spin, no boost.
    Spin,
    /// `[spin_threshold_ns, interactive_threshold_ns]` — interactive, boost.
    Interactive,
    /// `>interactive_threshold_ns` — background/I/O, small boost.
    Background,
}

/// Per-task scheduler state.
///
/// `base_priority` is the static nice-level analogue. `effective_priority`
/// adds dynamic latency credit and subtracts a CPU-usage penalty.
#[derive(Debug, Clone)]
pub struct TaskCtx {
    /// Task identifier.
    pub tid: TaskId,
    /// Static priority. Lower numeric value = higher priority. Range
    /// `[0, NUM_QUEUES-1]`.
    pub base_priority: u8,
    /// Current queue this task is enqueued on (or was last on, if running).
    pub current_queue: u8,
    /// Whether the task is currently enqueued, running, or sleeping.
    pub state: TaskState,
    /// Accumulated CPU usage in nanoseconds. Decayed each tick.
    pub cpu_usage_ns: u64,
    /// Monotonic timestamp when this task was last scheduled in.
    pub last_run_in_ns: u64,
    /// Monotonic timestamp when this task was last scheduled out (or last slept).
    pub last_run_out_ns: u64,
    /// Monotonic timestamp when this task last went to sleep (off-CPU and blocked).
    pub last_sleep_ns: u64,
    /// Most recent sleep classification.
    pub last_sleep_class: SleepClass,
    /// Dynamic credit added to effective priority. Decayed each tick.
    pub latency_credit: i32,
    /// Whether the task is currently considered latency-sensitive
    /// (set true on interactive wakeup, cleared by long run / demotion).
    pub is_latency_sensitive: bool,
    /// Number of boosts this task has earned in the current 1-second window
    /// (rolling — see `boost_window_start_ns`).
    pub boosts_in_window: u32,
    /// Start of the current 1-second boost-accounting window.
    pub boost_window_start_ns: u64,
    /// Ring buffer of recent sleep durations (newest at back).
    pub recent_sleeps: VecDeque<u64>,
    /// Was the task most recently classified as periodic?
    pub is_periodic: bool,
}

/// Task state in the scheduler.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum TaskState {
    /// Sitting in a run queue, eligible to be picked.
    Runnable,
    /// Currently on-CPU.
    Running,
    /// Off-CPU, blocked on I/O / lock / sleep.
    Sleeping,
}

impl TaskCtx {
    /// Construct a fresh task context at time `now_ns`.
    #[must_use]
    pub fn new(tid: TaskId, base_priority: u8, now_ns: u64, policy: &Policy) -> Self {
        let base = base_priority.min(NUM_QUEUES as u8 - 1);
        Self {
            tid,
            base_priority: base,
            current_queue: base,
            state: TaskState::Runnable,
            cpu_usage_ns: 0,
            last_run_in_ns: now_ns,
            last_run_out_ns: now_ns,
            last_sleep_ns: now_ns,
            last_sleep_class: SleepClass::None,
            latency_credit: 0,
            is_latency_sensitive: false,
            boosts_in_window: 0,
            boost_window_start_ns: now_ns,
            recent_sleeps: VecDeque::with_capacity(policy.periodic_window),
            is_periodic: false,
        }
    }

    /// Classify a sleep duration relative to the policy.
    #[must_use]
    pub fn classify(sleep_ns: u64, policy: &Policy) -> SleepClass {
        if sleep_ns < policy.spin_threshold_ns {
            SleepClass::Spin
        } else if sleep_ns <= policy.interactive_threshold_ns {
            SleepClass::Interactive
        } else {
            SleepClass::Background
        }
    }

    /// Record a sleep duration in the rolling window and update `is_periodic`.
    ///
    /// Periodic detection: when the window is full and the relative variance
    /// (population stddev / mean) is below `policy.periodic_variance_*`, the
    /// task is flagged as periodic and loses interactive credit. This
    /// catches polling daemons that wake on a fixed cadence.
    pub fn record_sleep(&mut self, sleep_ns: u64, policy: &Policy) {
        if self.recent_sleeps.len() == policy.periodic_window {
            self.recent_sleeps.pop_front();
        }
        self.recent_sleeps.push_back(sleep_ns);

        if self.recent_sleeps.len() < policy.periodic_window || policy.periodic_window < 2 {
            self.is_periodic = false;
            return;
        }

        // Integer relative-variance: stddev * den < mean * num where den is
        // policy.periodic_variance_den and num is policy.periodic_variance_num.
        let n = self.recent_sleeps.len() as u64;
        let sum: u64 = self.recent_sleeps.iter().sum();
        let mean = sum / n;
        if mean == 0 {
            self.is_periodic = false;
            return;
        }
        // sum of squared deviations
        let mut ssd: u128 = 0;
        for &s in &self.recent_sleeps {
            let d = (s as i128) - (mean as i128);
            ssd += (d * d) as u128;
        }
        let var = ssd / (n as u128);
        // stddev² < (num/den * mean)²  ⇔  var * den² < num² * mean²
        let num = policy.periodic_variance_num as u128;
        let den = policy.periodic_variance_den as u128;
        let mean128 = mean as u128;
        let lhs = var.saturating_mul(den * den);
        let rhs = (num * num).saturating_mul(mean128.saturating_mul(mean128));
        self.is_periodic = lhs < rhs;
    }

    /// Apply periodic decay to cpu_usage and latency_credit. Called by the
    /// scheduler at each decay tick.
    pub fn decay(&mut self, policy: &Policy) {
        // cpu_usage_ns *= num/den (integer, saturating)
        let cpu = self.cpu_usage_ns as u128;
        let new_cpu =
            cpu.saturating_mul(policy.cpu_decay_num as u128) / (policy.cpu_decay_den as u128);
        self.cpu_usage_ns = new_cpu.min(u64::MAX as u128) as u64;

        // latency_credit *= num/den, preserving sign
        let lc = self.latency_credit as i64;
        let new_lc =
            lc.saturating_mul(policy.credit_decay_num as i64) / (policy.credit_decay_den as i64);
        let clamped = new_lc.clamp(i32::MIN as i64, policy.max_latency_credit as i64);
        self.latency_credit = clamped as i32;

        // If credit decayed near zero, drop latency-sensitive flag.
        if self.latency_credit <= policy.boost_credit / 4 {
            self.is_latency_sensitive = false;
        }
    }

    /// Compute the CPU-usage penalty in priority units. Larger penalty =
    /// lower effective priority = larger numeric "queue index".
    #[must_use]
    pub fn cpu_penalty(&self, policy: &Policy) -> i32 {
        // Right-shift cpu_usage_ns to bring it into priority-unit range.
        let shifted = self.cpu_usage_ns >> policy.cpu_penalty_shift;
        // Cap so a single CPU-bound task doesn't underflow the queue space.
        shifted.min(NUM_QUEUES as u64) as i32
    }

    /// Effective scheduling score. **Lower score = higher priority** (matches
    /// queue index direction so the scheduler can `pick_min`).
    ///
    /// `score = base_priority + cpu_penalty - (latency_credit / boost_credit)`
    ///
    /// The latency credit is normalised by `policy.boost_credit` so each
    /// boost moves a task ~1 queue level up.
    #[must_use]
    pub fn score(&self, policy: &Policy) -> i32 {
        let base = i32::from(self.base_priority);
        let penalty = self.cpu_penalty(policy);
        let credit_levels = if policy.boost_credit > 0 {
            self.latency_credit / policy.boost_credit
        } else {
            0
        };
        base + penalty - credit_levels
    }

    /// Compute the queue index this task should sit on, clamped to
    /// `[0, NUM_QUEUES-1]`.
    #[must_use]
    pub fn target_queue(&self, policy: &Policy) -> u8 {
        let s = self.score(policy);
        s.clamp(0, NUM_QUEUES as i32 - 1) as u8
    }

    /// Try to award a boost credit, respecting the per-second cap.
    /// Returns true if the boost was granted, false if the cap fired.
    pub fn try_boost(&mut self, amount: i32, now_ns: u64, policy: &Policy) -> bool {
        // Rotate the boost-accounting window if a full second has elapsed.
        if now_ns.saturating_sub(self.boost_window_start_ns) >= 1_000_000_000 {
            self.boost_window_start_ns = now_ns;
            self.boosts_in_window = 0;
        }
        if self.boosts_in_window >= policy.max_boosts_per_sec {
            return false;
        }
        self.boosts_in_window += 1;
        // Periodic tasks get a damped boost (1/4) — they look interactive but
        // aren't UI-driven, so we don't want them holding the interactive band.
        let scaled = if self.is_periodic { amount / 4 } else { amount };
        self.latency_credit = self
            .latency_credit
            .saturating_add(scaled)
            .min(policy.max_latency_credit);
        self.is_latency_sensitive = scaled >= policy.boost_credit / 2;
        true
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn p() -> Policy {
        Policy::desktop()
    }

    #[test]
    fn classification_boundaries() {
        let p = p();
        assert_eq!(TaskCtx::classify(0, &p), SleepClass::Spin);
        assert_eq!(
            TaskCtx::classify(p.spin_threshold_ns - 1, &p),
            SleepClass::Spin
        );
        assert_eq!(
            TaskCtx::classify(p.spin_threshold_ns, &p),
            SleepClass::Interactive
        );
        assert_eq!(
            TaskCtx::classify(p.interactive_threshold_ns, &p),
            SleepClass::Interactive
        );
        assert_eq!(
            TaskCtx::classify(p.interactive_threshold_ns + 1, &p),
            SleepClass::Background
        );
        assert_eq!(TaskCtx::classify(1_000_000_000, &p), SleepClass::Background);
    }

    #[test]
    fn score_responds_to_credit() {
        let p = p();
        let mut t = TaskCtx::new(TaskId(1), 4, 0, &p);
        let s0 = t.score(&p);
        t.latency_credit = p.boost_credit * 2;
        let s1 = t.score(&p);
        assert!(
            s1 < s0,
            "more credit should mean lower score (higher priority)"
        );
    }

    #[test]
    fn score_responds_to_cpu_usage() {
        let p = p();
        let mut t = TaskCtx::new(TaskId(1), 4, 0, &p);
        let s0 = t.score(&p);
        t.cpu_usage_ns = 1u64 << 25; // generate a penalty
        let s1 = t.score(&p);
        assert!(
            s1 > s0,
            "more CPU usage should raise score (lower priority)"
        );
    }

    #[test]
    fn try_boost_caps_per_second() {
        let p = p();
        let mut t = TaskCtx::new(TaskId(1), 4, 0, &p);
        let mut granted = 0;
        for _ in 0..(p.max_boosts_per_sec + 10) {
            if t.try_boost(p.boost_credit, 0, &p) {
                granted += 1;
            }
        }
        assert_eq!(granted, p.max_boosts_per_sec);

        // Cross the 1-second boundary; quota refreshes.
        let g2 = t.try_boost(p.boost_credit, 1_500_000_000, &p);
        assert!(g2, "quota should refresh after 1 second");
    }

    #[test]
    fn periodic_detection_flags_regular_wakers() {
        let p = p();
        let mut t = TaskCtx::new(TaskId(1), 4, 0, &p);
        // Five sleeps of essentially-the-same duration → periodic.
        for s in [10_000_000, 10_010_000, 10_020_000, 9_990_000, 10_005_000] {
            t.record_sleep(s, &p);
        }
        assert!(
            t.is_periodic,
            "uniform-cadence sleeps should be flagged periodic"
        );
    }

    #[test]
    fn periodic_detection_skips_random_wakers() {
        let p = p();
        let mut t = TaskCtx::new(TaskId(1), 4, 0, &p);
        for s in [3_000_000, 25_000_000, 8_000_000, 40_000_000, 1_500_000] {
            t.record_sleep(s, &p);
        }
        assert!(
            !t.is_periodic,
            "irregular sleeps should not be flagged periodic"
        );
    }

    #[test]
    fn decay_shrinks_cpu_usage_and_credit() {
        let p = p();
        let mut t = TaskCtx::new(TaskId(1), 4, 0, &p);
        t.cpu_usage_ns = 1_000_000;
        t.latency_credit = 200;
        t.decay(&p);
        assert!(t.cpu_usage_ns < 1_000_000);
        assert!(t.latency_credit < 200);
    }

    #[test]
    fn periodic_boost_is_damped() {
        let p = p();
        let mut t = TaskCtx::new(TaskId(1), 4, 0, &p);
        // Flag as periodic.
        for s in [10_000_000, 10_000_000, 10_000_000, 10_000_000, 10_000_000] {
            t.record_sleep(s, &p);
        }
        assert!(t.is_periodic);
        let before = t.latency_credit;
        t.try_boost(p.boost_credit, 0, &p);
        assert!(
            t.latency_credit - before < p.boost_credit,
            "periodic task should get damped boost"
        );
    }
}
