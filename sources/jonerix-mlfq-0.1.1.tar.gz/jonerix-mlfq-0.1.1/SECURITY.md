# jonerix-mlfq — Security

This document is a deliberate audit of `jonerix-mlfq` v0.1.0 as a userspace
Rust library plus thin CLI. It is not a kernel-side audit; that scope belongs
to the future `jonerix-mlfq-scx` binding crate.

## 1. Scope

In scope:

- `src/lib.rs`, `src/clock.rs`, `src/policy.rs`, `src/task.rs`, `src/queue.rs`,
  `src/scheduler.rs` — the library.
- `src/main.rs` — the `jonerix-mlfq` CLI binary.
- `Cargo.toml` — build-time configuration and lint posture.

Out of scope:

- The `target/` build artefacts.
- Future `jonerix-mlfq-scx` BPF binding (will get its own audit).
- The kernel itself — `sched_ext`, libbpf, BPF verifier behaviour.
- Side-channel attacks on shared hardware (timing, cache).
- Supply-chain attacks on rustc/cargo themselves.

What the artefact actually does, end-to-end: parses up to one argv keyword,
runs an in-memory scheduler simulation or prints a policy dump, writes lines
to stdout/stderr, and exits. No daemon, no listener, no persistence.

## 2. Threat model

The adversary considered:

- An unprivileged local user who can invoke the `jonerix-mlfq` binary with
  arbitrary argv and environment, but who runs it without elevated
  privileges. The expectation is that the binary cannot be coerced to do
  anything beyond what an unprivileged user could already do (read its own
  stdout, observe its own exit code).
- A downstream Rust crate that links `jonerix-mlfq` as a library and feeds
  attacker-influenced inputs (task IDs, base priorities, sleep timings) into
  the public API. The expectation is that no API call can panic, leak
  memory, or trigger undefined behaviour for any combination of arguments
  that compile against the public signatures.

Out of scope:

- A root-equivalent attacker on the same machine. They can do anything
  regardless.
- A kernel-side adversary. The scheduler runs entirely in userspace today.
- An attacker with physical access.

## 3. Findings — input handling

The CLI's only input surface is `env::args()`. Argv is matched against an
exact set of static string keywords:

```rust
match sub {
    "simulate"          => simulate(),
    "inspect-policy"    => inspect_policy(),
    "version" | "--version" | "-V" => { ... }
    "help"    | "--help"    | "-h" => { ... }
    other => { eprintln!("jonerix-mlfq: unknown subcommand: {other}"); ... }
}
```

There is no flag parser, no file-path argument, no shell expansion. The
unknown-subcommand branch interpolates the unknown keyword into a single
error message; the interpolation goes through Rust's macro substitution
(not a runtime format-string evaluator) and the `{other}` token is
substituted as a value, not as a format specifier. There is no way for an
attacker-supplied string to alter the format expression.

`argv[0]` is similarly interpolated into `usage` as `{name}`, with the same
property.

The library API takes typed inputs: `TaskId(u32)`, `u8` for priority,
`u64` for nanosecond timestamps. There is no string parsing in the
library.

## 4. Findings — environment

The crate reads exactly one piece of environment at compile time
(`CARGO_PKG_VERSION` via `env!`) and zero at runtime. Verified by grep:

```
$ grep -rn "env::var\|env!\|env::args" src/
src/main.rs:18:const VERSION: &str = env!("CARGO_PKG_VERSION");
src/main.rs:33:    let args: Vec<String> = env::args().collect();
```

No `std::env::var`. No `std::env::vars`. Setting any environment variable
when invoking `jonerix-mlfq` has no effect on its behaviour.

## 5. Findings — arithmetic

The hot path is on the wakeup, sleep, tick, and decay paths. Every
arithmetic operation that touches a u64 timestamp or i32 credit uses an
overflow-safe variant.

Time-delta computations (`now - last_sleep_ns`, `now - last_run_in_ns`)
all go through `saturating_sub`. In normal operation `now` is monotonic
and these can never produce a wrap, but `saturating_sub` makes the
out-of-order case (a hypothetical clock skew during testing) defined
behaviour rather than wrap to a huge positive duration.

Credit math:

- `latency_credit.saturating_add(scaled)` in `try_boost`, immediately
  clamped to `policy.max_latency_credit`.
- `latency_credit.saturating_mul(num) / den` in `decay`, with intermediate
  widening to `i64` to avoid overflow when `latency_credit` is near `i32::MAX`.
  The result is clamped into `i32` range.

CPU-usage math:

- `cpu_usage_ns.saturating_add(ran_ns)` on schedule-out.
- `(cpu_usage_ns as u128) * num / den` for decay, with widening to `u128`
  to prevent any overflow even at `cpu_usage_ns = u64::MAX`. The result
  is `.min(u64::MAX as u128) as u64`.

Shift counts: `cpu_usage_ns >> policy.cpu_penalty_shift`. The shift count
is a `u32` Policy field. Since `cpu_usage_ns` is `u64`, the shift is
well-defined for any `cpu_penalty_shift < 64`. Policy is set by the
embedder; a downstream crate that constructs `Policy { cpu_penalty_shift:
64, .. }` would trigger a debug-mode panic on the shift in any Rust
version. There is no out-of-bound shift trigger from user argv or runtime
input — only from a programmer constructing a policy. We do not validate
the field; the public `Policy::desktop()` and `Policy::server()` set
sensible values and downstream constructors are expected to as well.

Multiplications in periodic-variance detection use `u128` intermediates
and `saturating_mul`:

```rust
let lhs = var.saturating_mul(den * den);
let rhs = (num * num).saturating_mul(mean128.saturating_mul(mean128));
```

`den * den` and `num * num` could overflow `u128` only if `den` or `num`
exceed `2^64`, which is impossible for the `u32` Policy fields.

Timestamp rollover: `u64` nanoseconds gives ~584 years of monotonic time
before rollover. `StdClock` is built on `std::time::Instant`, which on
Linux is backed by `CLOCK_MONOTONIC`. Realistic uptime cannot trigger
rollover. The single saturating cast `Instant::elapsed().as_nanos() as
u64` is a saturating truncation of `u128 → u64`, which for any plausible
uptime is identity.

## 6. Findings — unsafe

Zero `unsafe` blocks. Two enforcement mechanisms:

- `src/lib.rs` line 20: `#![forbid(unsafe_code)]` — `forbid` cannot be
  overridden by inner attributes the way `deny` can, so a child module
  cannot lower the level.
- `Cargo.toml` line 43: `unsafe_code = "deny"` — belt-and-suspenders at the
  workspace lint level.

Grep evidence:

```
$ grep -rn "unsafe" src/ tests/ Cargo.toml
src/lib.rs:14:// SAFETY: this crate contains zero `unsafe` blocks. `#![forbid(unsafe_code)]`
src/lib.rs:15:// is enforced at the crate root, and the `unsafe_code = "deny"` lint in
src/lib.rs:19:// unsafe blocks, but those would live in a separate `jonerix-mlfq-scx` crate.
src/lib.rs:20:#![forbid(unsafe_code)]
src/main.rs:10:// No FFI, no `unsafe`. The binary is a thin shell over the library.
Cargo.toml:43:unsafe_code = "deny"
```

Every hit is a declaration, a `forbid` attribute, or a comment. No
`unsafe { ... }` block exists.

## 7. Findings — panics in library code

`.unwrap()` / `.expect()` outside test modules: **none** in library or
binary code. Grep:

```
$ grep -n "\.unwrap\(\)\|\.expect(" src/lib.rs src/clock.rs src/policy.rs \
    src/task.rs src/queue.rs src/scheduler.rs src/main.rs
(no matches outside #[cfg(test)] modules)
```

The matches in `src/scheduler.rs` are all inside the `#[cfg(test)] mod
tests` block beginning at line 454; they do not appear in shipped binaries
or in downstream consumers' linked code.

`debug_assert!` invariants in `src/queue.rs`:

```rust
debug_assert!(idx < NUM_QUEUES);
```

These exist in `enqueue`, `enqueue_front`, and `remove`. They guard the
`queues[idx]` index. Since `idx = level.0 as usize` and `QueueLevel` is
constructed only via `QueueLevel::clamped(...)` (which clamps to
`[0, NUM_QUEUES-1]`) or via direct construction by the scheduler (which
also clamps via `target_queue`), the invariant cannot be violated by
external input. `debug_assert!` compiles out of `--release` builds, so
the field bounds are enforced by Rust's normal panic-on-out-of-bounds
behaviour in release as a backstop.

`assert!` in library code: none in non-test paths. The `Policy` invariants
tested in `policy::tests::desktop_invariants` (e.g. `spin_threshold_ns <
interactive_threshold_ns`) are *test assertions*, not runtime checks.

**No panic in the library can be triggered by external input.** All
remaining panic sites (slice index out of bounds, integer overflow on a
shift) are internal invariants protected by the type system or by clamping
at construction.

## 8. Findings — denial of service

`add_task` inserts into a `HashMap<TaskId, TaskCtx>`. A caller that
inserts billions of distinct `TaskId`s will exhaust memory. This is
expected behaviour for a library API and is bounded only by available RAM;
the kernel-side BPF dispatcher, which is the realistic caller, sizes its
TID space by the number of kernel threads it manages.

Rust's `std::collections::HashMap` is `SipHash-1-3` keyed with per-process
random seed since Rust 1.7, which mitigates hash-flooding from
attacker-controlled keys. No custom hasher is in use here. `TaskId` is a
`u32` — the keyspace is bounded.

The CLI's `simulate` mode runs a fixed-iteration (200-tick) simulation;
there is no caller-controlled iteration count. `inspect-policy` writes a
fixed-size dump.

There is no time limit, slot count, or queue depth limit imposed by the
library — the embedder is expected to enforce these. A pathological
caller can enqueue an unbounded number of tasks to a single level, and
`MultiQueue::remove` is `O(level_len)`. This is a known characteristic of
the data structure, not a vulnerability.

## 9. Findings — information leakage

`SchedulerStats` exposes monotonic counters (tasks, wakeups,
interactive_wakeups, boosts_granted, boosts_rate_limited,
boosts_damped_periodic, chain_propagated, preempt_events,
long_slice_demotions). No per-task identity is exposed in `stats()` —
only counts.

Per-task introspection is available via `Scheduler::task_ctx(tid)` and
`Scheduler::task_ids()`, both of which require the caller already know or
iterate the IDs they own. Since `TaskId` is `pub` and constructed by the
caller, there is no secret to leak — IDs come from the caller.

The CLI's `simulate` mode prints synthetic task IDs (1, 2, 3) and event
descriptions. `inspect-policy` prints only Policy constants, all of which
are also visible in `src/policy.rs`. Neither subcommand reads or prints
host-system state.

## 10. Cryptography

None. The crate contains no cryptographic primitives, no random-number
generation, no hashing beyond `std::collections::HashMap`'s internal
SipHash.

## 11. Dependencies

Zero runtime dependencies. Verified by inspecting `Cargo.toml`:

```toml
[dependencies]

[dev-dependencies]
```

Both blocks are present and both are empty. The crate compiles against
`std` only. There is therefore no supply-chain attack surface beyond
rustc, the Rust standard library, and the `cargo` toolchain itself.

`Cargo.lock` is committed (the `Cargo.lock` file is the auto-generated
nine-line `# This file is automatically @generated by Cargo` artefact for
a crate with no dependencies). Builds are reproducible at the Cargo level;
reproducibility at the binary level additionally depends on the toolchain
version.

## 12. Build-time considerations

Release profile in `Cargo.toml`:

```toml
[profile.release]
opt-level = 3
lto = "thin"
codegen-units = 1
strip = true
panic = "abort"
debug-assertions = false
overflow-checks = false
```

`panic = "abort"` means a panic terminates the process immediately —
no unwinding, no destructors, no possibility of a partially-recovered
stack containing scheduler state. For a process whose only job is to
print numbers and exit, this is desirable.

`overflow-checks = false` in release is the standard Rust release default
and is the reason the arithmetic findings above explicitly use
`saturating_*` rather than the unchecked operators. With
`overflow-checks = true` (the `dev` profile), an overflow would panic;
with `false`, it would wrap. The `saturating_*` calls are correct under
both.

`strip = true` removes debug symbols, reducing on-disk size and providing
modest information-hiding against an unsophisticated attacker who has a
copy of the binary. It does not affect runtime behaviour.

No `build.rs`. No procedural macros. No code generation. The crate's
compiled output is determined entirely by the in-tree source.

## 13. CI security

The current repository does not ship a CI workflow. When CI is added in
the future, the recommended posture is:

- Untrusted PR runs (e.g. from non-collaborators) must not have access to
  secrets — set `secrets: false` or split workflows by event type
  (`pull_request` for tests, `push` to `main` for release).
- Tokens used for the GitHub mirror's source-tarball release upload should
  be the run-scoped `GITHUB_TOKEN`, not a long-lived `PAT`. The Forgejo
  origin is on a private Tailscale tailnet and is not reachable from
  GitHub Actions, so no Forgejo credentials need leave the local machine.
- The build itself should be reproducible from `cargo build --release` with
  `RUSTFLAGS="-D warnings"` — this is the "zero warnings" target stated in
  `Cargo.toml`'s comment block and is the gate for accepting a PR.

## 14. Reporting a vulnerability

Please report vulnerabilities privately, *not* in a public issue.

- Email: `jonerik@gmail.com`
- Forgejo (private Tailscale tailnet): file an issue on
  `https://castle.great-morpho.ts.net:3000/jonerik/jonerix-mlfq` if you
  have access.
- GitHub mirror: open a private security advisory on
  `https://github.com/stormj-UH/jonerix`.

Please allow up to 30 days for an initial response. Embargo timing can be
discussed; the project is not on a fixed disclosure schedule.

## 15. Audit history

| Date | Auditor | Version | Commit | Notes |
|---|---|---|---|---|
| 2026-05-16 | Claude Code | 0.1.0 | `<short-hash>` | Initial audit. All findings are clean; no `unsafe`, no panics on external input, no dependencies, no network/FS/FFI. |
