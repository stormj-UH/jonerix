# jonerix-mlfq

An 8-level multi-level feedback queue scheduler for Linux `sched_ext`, with
macOS-style interactivity heuristics inferred statistically — no Mach IPC
required.

`v0.1.1 · 0 unsafe blocks · 69 tests (29 unit + 39 integration + 1 doc) · zero warnings on cargo build --release · bench subcommand for real-clock comparison`

## What it is

`jonerix-mlfq` is a Rust scheduler core that aims to make a Linux desktop feel
more like macOS without copying any line of XNU/Mach code. macOS achieves a
large part of its perceived responsiveness because Mach IPC carries an implicit
"this thread is waiting on that thread" hint on every message send. The
scheduler turns those hints directly into priority. Linux has no equivalent
signal: futex wakeups, pipe writes, and socket reads do not announce which
thread is blocked on whom.

This crate compensates by inferring interactivity from observable behaviour —
how long a task slept, who woke it, and how long it has run since it last
slept. The output is a per-task score that an MLFQ dispatcher can use to pick
the next runnable thread.

Today the crate is a userspace library and CLI: useful as a simulator, as a
reference for what the algorithm decides on a synthetic workload, and as the
priority-policy half of a planned `sched_ext` BPF binding (target crate name
`jonerix-mlfq-scx`). The library has zero runtime dependencies, zero `unsafe`
blocks, and a deterministic `ManualClock` for property testing.

## Algorithm at a glance

| Heuristic | Trigger | Action | Constant (desktop preset) |
|---|---|---|---|
| Sleep classification | task wakes | bucket sleep duration into Spin / Interactive / Background | `spin_threshold_ns=2 ms`, `interactive_threshold_ns=50 ms` |
| Interactive boost | Interactive-class wakeup | award `boost_credit`, mark latency-sensitive, jump to top of target queue, preempt running | `boost_credit=100` |
| Background bump | Background-class wakeup (>50 ms sleep) | small credit so I/O return doesn't starve | `chain_credit/2 = 25` |
| Wakeup chain | latency-sensitive task wakes another | propagate `chain_credit` to wakee | `chain_credit=50` |
| CPU usage decay | every `decay_tick_ns` | `cpu_usage *= num/den` for every task | `0.7` every `100 ms` |
| Latency credit decay | every `decay_tick_ns` | `latency_credit *= num/den` | `0.5` every `100 ms` |
| Long-slice demotion | task runs `>= long_slice_ns` without sleeping | demote one queue level, drop sensitive flag | `long_slice_ns=20 ms` |
| Boost rate cap | per-task | refuse boosts beyond `max_boosts_per_sec` per rolling 1 s | `50/s` |
| Periodic damping | last `N` sleep durations have <10 % relative variance | flag periodic, scale boost to `1/4` | `periodic_window=5`, `variance < 10 %` |

Effective score is `base_priority + cpu_penalty − credit_levels`. Lower score =
higher priority, which directly indexes into one of the 8 FIFO queues.

## Quick start

Build and test:

```sh
cargo build --release
cargo test
```

Run the simulator:

```sh
./target/release/jonerix-mlfq simulate
```

Inspect the active policy:

```sh
./target/release/jonerix-mlfq inspect-policy
```

Excerpt of `simulate` output:

```
# tick    event              tid    class           boost  chain  preempt
     0  wakeup               2    interactive     yes    no     true
     0  pick-next            2
     6  wakeup               2    interactive     yes    no     true
    10  wakeup               3    interactive     yes    no     true
...
# summary
tasks                : 3
wakeups              : 53
interactive_wakeups  : 53
boosts_granted       : 50
boosts_rate_limited  : 3
boosts_damped_periodic: 10
chain_propagated     : 0
preempt_events       : 50
long_slice_demotions : 0
```

Subcommand index:

| Subcommand | Effect |
|---|---|
| `simulate` | run a synthetic 200-tick workload and print decisions |
| `inspect-policy` | print every `Policy::desktop()` constant |
| `version`, `--version`, `-V` | print version and exit |
| `help`, `--help`, `-h` | print usage |

## Library usage

```rust,no_run
use jonerix_mlfq::{ManualClock, Policy, Scheduler, TaskId};

// Construct a scheduler with the deterministic test clock and desktop policy.
let mut sched = Scheduler::new(ManualClock::new(), Policy::desktop());

// Register two tasks at base priority 4 (middle of the 0..=7 range).
sched.add_task(TaskId(1), 4);
sched.add_task(TaskId(2), 4);

// Task 2 sleeps briefly and wakes — an "interactive" sleep duration.
sched.on_sleep(TaskId(2));
sched.clock().advance_ms(5);
let outcome = sched.on_wakeup(TaskId(2), /* waker */ None);
assert!(outcome.boosted);
assert!(outcome.should_preempt);

// Pick the next task to run.
let next = sched.pick_next();
assert_eq!(next, Some(TaskId(2)));

// Periodic tick — applies decay and reports whether the running task
// should be preempted because of a long slice or an outranking wakeup.
let _tick = sched.on_tick();

// Aggregate counters for stats / Prometheus export.
let stats = sched.stats();
println!("interactive_wakeups = {}", stats.interactive_wakeups);
```

The example is marked `no_run` because it advances time on a `ManualClock`
that only exists in the test build path; the real binary's `simulate`
subcommand exercises the same API.

## Policy tuning

Every field on `Policy`. Numbers shown are the `desktop()` preset defaults.

| Field | Default | Units | Raising it... | Lowering it... |
|---|---|---|---|---|
| `spin_threshold_ns` | `2_000_000` | ns | treats more short sleeps as spin (no boost) | classifies finer-grained futex contention as interactive |
| `interactive_threshold_ns` | `50_000_000` | ns | widens the interactive band (more boosts) | tightens it (closer to UI-frame-only) |
| `slice_ns` | `5_000_000` | ns | longer time slice between rotations | shorter slice, more rotation |
| `long_slice_ns` | `20_000_000` | ns | tolerates longer CPU bursts before demotion | demotes CPU-bound tasks faster |
| `boost_credit` | `100` | credit | each boost moves a task farther up | gentler boosts |
| `chain_credit` | `50` | credit | wakeup chains carry more weight | chains are weaker |
| `cpu_decay_num / cpu_decay_den` | `7 / 10` | ratio | slower decay → CPU penalty lingers | faster decay → CPU hogs recover sooner |
| `credit_decay_num / credit_decay_den` | `1 / 2` | ratio | slower decay → boosts last longer | faster decay (more transient interactivity) |
| `decay_tick_ns` | `100_000_000` | ns | decay runs less often | decay runs more often (less responsive but cheaper math) |
| `max_boosts_per_sec` | `50` | /s | more tolerant of bursty wakers | quicker to throttle polling daemons |
| `periodic_window` | `5` | samples | needs more history to flag periodic | flags periodic sooner |
| `periodic_variance_num / _den` | `100 / 1000` | ratio (10 %) | more lenient — more tasks pass as periodic | stricter — only very regular tasks get flagged |
| `cpu_penalty_shift` | `20` | bits | gentler CPU penalty (smaller shift result) | harsher CPU penalty |
| `max_latency_credit` | `1_000` | credit | higher ceiling on boost accumulation | lower ceiling |

Two presets ship in the box:

- `Policy::desktop()` — the values above. Tuned for 60–144 Hz compositors and
  5–10 ms audio callbacks.
- `Policy::server()` — tighter interactive window (`20 ms`), gentler boosts
  (`boost_credit=40`), slower decay (`9/10`), lower per-second cap (`20/s`),
  larger `long_slice_ns` (`100 ms`). Polling-style daemons get less help and
  long-running batch jobs are less penalised.

## Project layout

```
jonerix-mlfq/
├── Cargo.toml          # zero runtime deps; unsafe_code = "deny"; release profile
├── LICENSE             # MIT
├── src/
│   ├── lib.rs          # crate root; #![forbid(unsafe_code)]; re-exports
│   ├── main.rs         # CLI: simulate / inspect-policy / version / help
│   ├── clock.rs        # Clock trait, StdClock (Instant-backed), ManualClock
│   ├── policy.rs       # Policy struct + desktop()/server() presets
│   ├── task.rs         # TaskCtx, TaskId, SleepClass, TaskState, classify/decay/score
│   ├── queue.rs        # 8-level FIFO MultiQueue; bitmap-indexed O(1) pick_min
│   └── scheduler.rs    # Scheduler<C: Clock>; on_wakeup / on_sleep / on_yield /
│                       #   on_long_slice / on_tick / pick_next / SchedulerStats
└── tests/
    ├── interactivity.rs # integration: sleep-class boundaries and boost behaviour
    └── wakeup_chain.rs  # integration: chain propagation, rate-limit, periodic damping
```

## SAFETY

The crate contains **zero `unsafe` blocks.** This is enforced two ways:

- `#![forbid(unsafe_code)]` at the crate root in `src/lib.rs`.
- `unsafe_code = "deny"` in `Cargo.toml` under `[lints.rust]`.

The output of grepping for `unsafe` in the entire tree:

```
$ grep -rn "unsafe" src/ tests/ Cargo.toml
src/lib.rs:14:// SAFETY: this crate contains zero `unsafe` blocks. `#![forbid(unsafe_code)]`
src/lib.rs:15:// is enforced at the crate root, and the `unsafe_code = "deny"` lint in
src/lib.rs:19:// unsafe blocks, but those would live in a separate `jonerix-mlfq-scx` crate.
src/lib.rs:20:#![forbid(unsafe_code)]
src/main.rs:10:// No FFI, no `unsafe`. The binary is a thin shell over the library.
Cargo.toml:43:unsafe_code = "deny"
```

Every match is either the lint declaration, the `forbid` attribute, or a
comment stating that the file contains none. No `unsafe { ... }` block exists
in the crate.

A planned future crate, `jonerix-mlfq-scx`, will provide the BPF/`sched_ext`
binding and will necessarily contain `unsafe`. Its scope will be:

- FFI shims into `libbpf-rs` (or `rustix`) to load the BPF dispatcher object.
- Raw-pointer kernel object dispatch through the `sched_ext` ABI.
- One-time allocation of per-CPU run queues exposed to BPF.

Each of those would carry its own `SAFETY` comment in that crate and would not
appear in this crate. The userspace `jonerix-mlfq` core stays `unsafe`-free
regardless.

## Security audit

A full audit lives in `SECURITY.md`. High-level findings:

- No untrusted input parsing — argv is matched against a fixed set of
  static string keywords (`simulate`, `inspect-policy`, `version`, `help`).
- No network listener, no filesystem access beyond stdout/stderr, no FFI.
- Arithmetic in the hot path uses `saturating_add` / `saturating_sub` /
  `saturating_mul`, and the decay multiply widens to `u128` to avoid overflow.
- No environment variables are read at runtime; the only `env!` is a
  compile-time `CARGO_PKG_VERSION` lookup.
- No `.unwrap()` / `.expect()` outside `#[cfg(test)]` code. Library
  invariants are guarded with `debug_assert!`, which compiles out of release
  builds.
- Zero runtime dependencies — the `[dependencies]` and `[dev-dependencies]`
  blocks in `Cargo.toml` are empty.

See `SECURITY.md` for the full threat model and per-finding detail.

## Comparison to other schedulers

**CFS (Linux Completely Fair Scheduler).** Fairness-first: every runnable
task is given proportional CPU based on vruntime and weight. CFS does not
detect interactivity per se — it relies on sleepers naturally accumulating
less vruntime and therefore running first when they wake. There is no
explicit "this sleep was interactive-shaped" classification, no wakeup-chain
inheritance, and no boost rate cap.

**BFS / MuQSS (Con Kolivas).** A single skip-list run queue with a
deadline-based pick. Sleepers get a small interactivity bonus, but the design
emphasises low latency on small core counts rather than aggressive
short-sleep boosting. Long sleeps and short sleeps are treated more
uniformly than in `jonerix-mlfq`.

**scx_lavd (`sched_ext` example).** The closest behavioural cousin: LAVD's
"latency criticality" score uses recent sleep behaviour to bias dispatch.
LAVD computes its score differently (its lookback window and weighting math
differ from this crate) and lives kernel-side as a BPF scheduler. The two
designs share a core insight — sleep duration carries interactivity
information — but implement it with different math.

**XNU / Mach (macOS).** Mach IPC explicitly carries dependency information.
A thread blocking on a Mach port `mach_msg_receive` records who it is
waiting for; the scheduler propagates priority along that edge. This is
strictly more information than Linux exposes, and `jonerix-mlfq` does not
attempt to replicate it. The wakeup-chain heuristic in this crate is the
statistical approximation: if a latency-sensitive task wakes another task,
that edge is a candidate dependency edge.

## Limitations and known false-positive modes

- **High-frequency network daemons.** A DHCP client, mDNS responder, or
  packet-capture filter that wakes every few milliseconds looks
  interactive-shaped because the sleeps fall inside the
  `[2 ms, 50 ms]` band. Mitigations: the periodic detector flags
  fixed-cadence wakers (variance < 10 %) and the per-task
  `max_boosts_per_sec=50` cap throttles bursts.
- **Audio mixing threads in tight cycles.** A 10 ms audio callback loop
  may either be desirable (real interactive work) or a runaway. The
  scheduler boosts both. Workloads that need true real-time audio should
  use `SCHED_FIFO` — `jonerix-mlfq` is not a real-time scheduler.
- **Periodic GC threads.** A garbage collector that wakes every 50 ms to
  scan will be flagged periodic after `periodic_window=5` samples and have
  its boost damped to `1/4`. If the GC's cadence varies sleep-to-sleep, the
  damping won't fire.
- **Workloads with very uniform compositor frames.** A perfectly
  60 Hz-locked compositor (`16.67 ms` sleeps) is also "periodic" by the
  variance test. The default 10 % threshold is chosen so that real
  compositor jitter (frame-pacing, vsync wobble) keeps variance above 10 %,
  but a synthetic test harness with `sleep(16ms)` exactly might trip the
  damping. Tune `periodic_variance_num` if relevant.
- **No fairness guarantees under load.** Aggressive preemption (no fairness
  damping) trades long-term throughput predictability for short-term
  responsiveness. A CPU-bound task running alongside a chatty interactive
  task will receive less CPU than a CFS allocation would give it.

## Roadmap

- `jonerix-mlfq-scx` — the BPF/`sched_ext` binding crate. Picks up
  per-CPU run queues, kernel-side wakeup hooks, and the `libbpf-rs` (or
  `rustix`) FFI surface. All `unsafe` lives there.
- Per-CPU run queues. The current `MultiQueue` is single-instance; a real
  kernel deployment needs one per CPU plus a steal policy.
- Load balancing across CPUs. Currently no cross-CPU migration.
- cgroup integration. Today, cgroup hierarchy is invisible to the
  scheduler; a future hierarchy-aware variant would scale weights from
  cgroup `cpu.weight`.

## License

MIT. See `LICENSE` for the full text.

## Building from source on jonerix

Once the recipe lands in the `stormj-UH/jonerix` package tree:

```sh
jpkg install jonerix-mlfq
```

This installs `bin/jonerix-mlfq` (the simulator/CLI) and the library
artefacts under the active `--prefix`. The source tarball is mirrored on
GitHub (`stormj-UH/jonerix`) and the canonical repository is at
`https://castle.great-morpho.ts.net:3000/jonerik/jonerix-mlfq` on a private
Tailscale tailnet; the GitHub mirror serves anonymous fetches with no
authentication.
