# jonerix-mlfq — Design

This document describes the algorithm and the reasoning behind each constant.
The user-facing summary lives in `README.md`; this file is for someone
modifying the scheduler.

## 1. Problem statement

Linux's stock schedulers (CFS until 6.6, EEVDF since) are fairness-first.
They allocate CPU time proportionally and rely on a few small heuristics to
nudge sleepers ahead of CPU-bound tasks — primarily by letting sleepers
accumulate less `vruntime` and therefore reach the head of the run queue
sooner when they wake. The result is excellent throughput and well-bounded
latency under contention, but a noticeably less "snappy" desktop feel than
macOS on similar hardware, particularly when a CPU-bound process is also
running.

Why does macOS feel different? On macOS, Mach IPC is the substrate for most
inter-process communication. When thread A sends a Mach message to thread B,
the kernel records that B is the receiver and that A is the sender. When A
later blocks waiting for B's reply, the scheduler knows A → B is a real
dependency edge and propagates A's priority along it (priority donation
through Mach voucher/ulock infrastructure). The interactive experience —
"click button → IPC to window server → IPC to compositor → IPC back" — gets
priority-boosted along its entire chain.

The "obvious" port — BSD's `cpu_decay` — doesn't capture this. `cpu_decay`
just lowers the priority of long-running tasks, which is roughly what the
Linux scheduler already does. The macOS-feel comes from the *positive*
direction: short-burst, latency-sensitive tasks get *promoted*, with
information that the kernel only has because IPC tells it.

Linux does not have that information. Futex wakeups, pipe writes, epoll
events — none of them announce "X is waiting on me". So we have to infer.

## 2. The big conceptual shift

Mach-style scheduling: **explicit dependency observation**. The kernel
*knows* who depends on whom; priority follows that graph.

This crate: **statistical inference of interactivity from behaviour**. We do
not know who depends on whom. We do know:

- how long each task slept,
- which task performed each wakeup,
- how long each task has run continuously since it last slept,
- how often each task wakes per second,
- how regular each task's sleep cadence is.

From those signals we build a probabilistic model of what the user cares
about right now. A task that sleeps for 5 ms and wakes — the shape of a UI
event loop — is *probably* responding to an interactive input. A task that
runs for 20 ms straight without sleeping is *probably* a worker. A task
that wakes every 10 ms on the dot is *probably* a polling daemon, not a
user-driven thread.

Each of those is a probability, not a fact, and the algorithm is designed
around that — boosts are bounded, damped when evidence weakens, and decayed
quickly so phantom boosts don't accumulate.

## 3. State model

Per-task state is the `TaskCtx` struct (`src/task.rs`):

| Field | Type | Meaning |
|---|---|---|
| `tid` | `TaskId(u32)` | identifier |
| `base_priority` | `u8` | static nice-level analogue, `[0, 7]` |
| `current_queue` | `u8` | level currently sitting on |
| `state` | `TaskState` | Runnable / Running / Sleeping |
| `cpu_usage_ns` | `u64` | accumulated CPU time, decayed periodically |
| `last_run_in_ns` | `u64` | when task was last scheduled in |
| `last_run_out_ns` | `u64` | when task was last scheduled out |
| `last_sleep_ns` | `u64` | when task last went off-CPU |
| `last_sleep_class` | `SleepClass` | most recent classification |
| `latency_credit` | `i32` | dynamic priority bonus, decayed periodically |
| `is_latency_sensitive` | `bool` | sticky flag set by recent boosts |
| `boosts_in_window` | `u32` | counter for per-second rate cap |
| `boost_window_start_ns` | `u64` | start of the current 1 s accounting window |
| `recent_sleeps` | `VecDeque<u64>` | last `periodic_window` sleep durations |
| `is_periodic` | `bool` | last classification by the variance test |

The score formula is, in math:

```
score = base_priority + ⌊cpu_usage_ns / 2^cpu_penalty_shift⌋
                     − ⌊latency_credit / boost_credit⌋
```

and in Rust (`TaskCtx::score`):

```rust
let base = i32::from(self.base_priority);
let penalty = self.cpu_penalty(policy); // cpu_usage_ns >> shift, capped at NUM_QUEUES
let credit_levels = if policy.boost_credit > 0 {
    self.latency_credit / policy.boost_credit
} else {
    0
};
base + penalty - credit_levels
```

**Lower score is higher priority**, so the score directly indexes a queue
level via `target_queue`, which clamps to `[0, NUM_QUEUES-1]`.

Two things are worth noting:

1. The score is symmetric in shape — penalty adds, credit subtracts —
   making each unit of credit roughly cancel one unit of penalty. This
   keeps a freshly-boosted task above a CPU hog of equal `base_priority`.
2. The `credit_levels = latency_credit / boost_credit` normalisation means
   one full `boost_credit` is exactly one queue level. That makes the
   choice of `boost_credit=100` arbitrary — what matters is its ratio to
   `max_latency_credit` (the cap, set to 10 boosts' worth).

## 4. Sleep classification

```
sleep_ns                            → class
─────────────────────────────────── ────────────
[0, spin_threshold_ns)              → Spin           (no boost)
[spin_threshold_ns, interactive_threshold_ns] → Interactive (full boost)
(interactive_threshold_ns, ∞)       → Background     (small boost)
```

Defaults: `spin_threshold_ns = 2 ms`, `interactive_threshold_ns = 50 ms`.

**Why `< 2 ms` is "spin/contention", not interactive.** A futex wait that
resolves in under a millisecond is overwhelmingly likely to be lock
contention — adaptive mutexes, glibc's `pthread_mutex_lock`, the early-acquire
path in `parking_lot`, or short-held spinlock fallbacks. Boosting these
would amplify lock convoys. Real interactive sleeps are bounded below by
the minimum scheduling latency for the wake event, which on contemporary
Linux is reliably above 1–2 ms.

**Why `[2 ms, 50 ms]` is "interactive".** 50 ms is roughly three frames at
60 Hz (one frame ≈ 16.67 ms). A task that sleeps for less than three
frames is almost certainly part of an event-loop cycle: the UI thread that
woke for a click, the network thread that finished a request, the audio
mixer's callback. 50 ms is also longer than every common animation
inter-frame interval (16.67 ms, 11.1 ms at 90 Hz, 8.3 ms at 120 Hz) and
shorter than any plausible disk-read or network round-trip wait.

**Why `> 50 ms` is "background".** Disk reads on contemporary SSDs land in
the 100–500 µs range when the request hits the device, but the *scheduling*
latency for a disk-bound wakeup is dominated by the I/O scheduler and easily
runs to tens of milliseconds. Network round trips to anything off-host are
typically >1 ms and frequently 10–100 ms. We give these a small boost
(`chain_credit/2 = 25` by default) so they're not starved on return, but we
do not promote them to the interactive band.

## 5. Wakeup boost

In pseudocode:

```
on_wakeup(wakee, waker_opt):
    sleep_ns = now - wakee.last_sleep_ns
    class = classify(sleep_ns, policy)
    wakee.record_sleep(sleep_ns)         # updates is_periodic via variance

    if class == Interactive:
        granted = wakee.try_boost(boost_credit)
        if granted:
            mark wakee.is_latency_sensitive
    elif class == Background:
        wakee.try_boost(chain_credit / 2)

    if waker_opt is latency-sensitive AND class != None:
        wakee.try_boost(chain_credit)         # chain credit

    enqueue wakee at front of target queue if boosted, else at tail
    return WakeupOutcome { ... should_preempt: score(wakee) < score(running) }
```

In Rust this is `Scheduler::on_wakeup` (`src/scheduler.rs:192`). The
implementation returns a `WakeupOutcome` struct with five bool signals
(`boosted`, `damped_periodic`, `rate_limited`, `chain_inherited`,
`should_preempt`) plus the `class`. The kernel-side dispatcher can choose
to act on `should_preempt` by issuing an IPI; the userspace simulator
prints it.

## 6. Wakeup chains

Mach IPC tracks dependency edges directly. Without that, we treat the
wakeup edge itself as a candidate dependency edge — if task A wakes task B
and A is latency-sensitive, B inherits a smaller credit (`chain_credit`,
default 50, half of `boost_credit`). This is one of the few places where
the scheduler crosses task boundaries.

```
A ── wakes ──▶ B ── wakes ──▶ C
└─────────────┴──────────────┴─── all three end up latency-sensitive if
                                  A was, and each carries chain_credit.
```

The propagation is **not gated on sleep class**. A short sleep that would
otherwise be classified as Spin still propagates the chain credit, because
"UI thread releases lock → worker resumes" is a meaningful dependency edge
even though the worker's sleep was sub-millisecond. The chain credit is the
*only* path by which a Spin-class wakeup contributes to the wakee's
priority.

Why the chain credit is `≤ boost_credit / 2`: a chain edge is weaker
evidence than a direct interactive sleep. A 5 ms sleep is a strong signal
that the wakee was doing event-loop work. Being woken by a recently-boosted
task is only suggestive — the waker might be holding a lock, might be
batching work, might be a noisy neighbour. Lower weight, but non-zero.

The credit is given to the wakee without subtracting anything from the
waker. Priority donation in the Mach sense is bidirectional in the formal
model but the giver's priority doesn't drop — they're not paying for the
boost, they're propagating information. Decay handles the cleanup: the
chain credit halves every `decay_tick_ns = 100 ms`, so even runaway chains
clear within a few hundred milliseconds.

## 7. CPU decay and penalty

Decay is multiplicative:

```
cpu_usage_ns      ← cpu_usage_ns * cpu_decay_num / cpu_decay_den
latency_credit    ← latency_credit * credit_decay_num / credit_decay_den
```

Defaults: `0.7` for cpu_usage, `0.5` for latency_credit, both every 100 ms.
This is deliberately faster than typical Linux schedulers — `vruntime`
doesn't decay at all; it just grows slower for sleepers. The aggressive
decay here is necessary because without explicit IPC dependency tracking
we have no way to *confirm* a task is still latency-sensitive; we can only
observe that it stopped being so. Fast decay turns "absence of recent
interactivity evidence" into "rapid de-prioritisation".

The decay is implemented in integer arithmetic (numerator/denominator,
widened to `u128` for the multiply) for two reasons:

1. The hot path runs on every decay tick across every task. Floating-point
   in a kernel-side BPF scheduler is awkward (BPF has no fpu) and the
   userspace version benefits from staying portable to the BPF variant.
2. Determinism. Property tests on `ManualClock` need bit-exact reproducibility.

The decay invariant is that `cpu_usage_ns` is bounded: it grows by at most
`ran_ns` per scheduling-out event (a 64-bit value with no realistic
overflow risk in a single decay window) and shrinks by a factor of `7/10`
every 100 ms when decay fires. A task that runs nonstop for one second
accumulates roughly `1e9` ns of cpu_usage; after one second of decay this
becomes `1e9 * (0.7)^10 ≈ 2.8e7` ns — about 28 ms of penalty's worth, or
~28 right-shifted by 20 to `~27` priority levels, which is clamped down to
`NUM_QUEUES = 8` by `cpu_penalty`.

`cpu_penalty_shift = 20` converts cpu_usage_ns (in nanoseconds) into a
priority-level penalty: `1 << 20 ≈ 1 ms` of cpu_usage gives one penalty
level. A task that has been running for 8 ms of accumulated post-decay
time fills the priority space.

## 8. Latency credit as priority-donation replacement

Mach-style priority donation transfers priority along the dependency
graph. Our `latency_credit` is the inverse: each task accumulates its own
credit from its own behaviour. The credit is *added* to the wakee on a
chain edge but *not subtracted* from the waker.

This is asymmetric on purpose. In the Mach model, the waker is blocked
waiting for the wakee, so donating priority makes sense — they're a single
logical work unit. In our model we cannot prove the waker is blocked; we
just know they recently performed a wakeup. They might still be runnable
themselves. Stealing their credit would discourage exactly the kind of
producer–consumer pipelines we want to optimise.

The fast credit decay (`0.5` every 100 ms) is what keeps this from
unbounded growth. Even if every waker boosts every wakee, the credit
half-life is 100 ms, so a chain of N boosts decays to `boost_credit *
0.5^N` quickly.

`max_latency_credit = 1000 = 10 * boost_credit` caps the absolute boost so
no task can accumulate "ten queue levels' worth of priority" no matter how
chatty.

## 9. Preemption policy

When a wakeup produces a task whose `score()` is strictly less than the
running task's `score()`, the running task is preempted **immediately**,
with no fairness damping. Same when a tick observes that the head of the
top non-empty queue outranks the running task.

The cost of this design is that under sustained interactive load, a
CPU-bound task receives strictly less CPU than a CFS allocation would
give it. There is no "minimum slice" guarantee, no anti-starvation
intervention beyond the per-task boost cap.

Practically, the boost cap, the aggressive decay, and the long-slice
demotion together provide *something* that looks like fairness on the
medium term: a chatty wakeup-spammer hits its 50/s cap, its credit decays
between bursts, and a CPU-bound task it was preempting catches back up
during the next 100 ms decay tick. But this is emergent, not guaranteed.
Workloads that need fairness guarantees should run on EEVDF/CFS, not here.

## 10. False positives

Two independent mechanisms backstop bad boosts.

**Boost rate cap.** `try_boost` keeps a sliding 1 s window counter
(`boosts_in_window`) and a window start (`boost_window_start_ns`). When
the elapsed time since window start exceeds 1 s, the window rotates. If
`boosts_in_window >= max_boosts_per_sec`, the boost is denied. At
`max_boosts_per_sec=50`, a task waking every 5 ms (a tight 200 Hz event
loop) gets boosted 50 times in the first 250 ms of its rolling window,
then nothing until the next rotation. That's enough to give it real
interactive priority during a burst but not enough to dominate
indefinitely.

**Periodic detection.** Every `try_boost` checks `is_periodic`, set by
`record_sleep` from the variance of the last `periodic_window=5` sleep
durations:

```
mean = Σ s_i / N
var  = Σ (s_i − mean)² / N
flagged if  var * den² < num² * mean²       (mathematically: stddev / mean < num/den)
```

Defaults `num=100, den=1000` mean a flag fires when relative stddev is
below 10 %. If flagged, the boost amount is scaled by `1/4` (in
`try_boost`).

Both mechanisms are needed because they target different failure modes:

- A high-rate **bursty** waker (e.g. a brief flood of interrupts) is caught
  by the rate cap. Variance can be high in a burst, so periodic detection
  won't help.
- A low-rate **uniform** waker (e.g. a 10 Hz poller) doesn't hit the rate
  cap (10/s ≪ 50/s) but is caught by periodic detection.

The combination gives a defence against both shapes.

## 11. Constants table — full rationale

Every constant in `Policy::desktop()` with its empirical anchor.

| Constant | Value | Where it comes from |
|---|---|---|
| `spin_threshold_ns` | 2 ms | shortest plausible non-spin scheduling latency on contemporary Linux; under this, sleeps are dominated by lock contention |
| `interactive_threshold_ns` | 50 ms | three 60 Hz compositor frames; covers UI event loops, audio callbacks (5–10 ms), most non-blocked network handlers |
| `slice_ns` | 5 ms | default time slice — long enough to make meaningful progress, short enough to rotate quickly on a busy run queue |
| `long_slice_ns` | 20 ms | tripwire for "ran too long without sleeping"; longer than the worst-case worker burst but shorter than 60 Hz frame deadline |
| `boost_credit` | 100 | unitless; with `max_latency_credit=1000` this gives a 10-boost cap, and with `cpu_penalty_shift=20` it cleanly maps to one queue level per boost |
| `chain_credit` | 50 | half a boost — chains are weaker evidence than direct interactive sleep |
| `cpu_decay_num / cpu_decay_den` | 7 / 10 | aggressive but not punishing; cpu_usage halves in roughly 200 ms |
| `credit_decay_num / credit_decay_den` | 1 / 2 | very fast — credit halves every decay tick, fully clears in ~300–500 ms of idle |
| `decay_tick_ns` | 100 ms | matches typical desktop interactivity windows; faster than that costs CPU per tick across all tasks |
| `max_boosts_per_sec` | 50 | high enough that real interactive tasks don't hit it (UI loops at 60–144 Hz, but only some frames sleep through the interactive band); low enough that a 1 kHz waker is heavily throttled |
| `periodic_window` | 5 | smallest window where variance is statistically meaningful; larger windows delay detection |
| `periodic_variance_num / _den` | 100 / 1000 (10 %) | chosen so real compositor jitter (~5–8 %) doesn't trip but a uniform poller does |
| `cpu_penalty_shift` | 20 | `1 << 20 ≈ 1 ms` of cpu_usage gives one priority level — matches the queue spacing |
| `max_latency_credit` | 1000 | 10 × boost_credit; caps the accumulator at 10 queue levels' worth (more than the 8-level queue space, so it's a soft cap) |

The `server()` preset varies these as follows: tighter
`interactive_threshold_ns=20 ms`, gentler `boost_credit=40`, slower
`cpu_decay=9/10`, slower `credit_decay=2/3`, larger
`long_slice_ns=100 ms`, lower `max_boosts_per_sec=20`, harsher
`cpu_penalty_shift=18`, lower `max_latency_credit=400`. The net effect is
that polling daemons get much less boost, batch jobs get penalised more
slowly, and the scheduler approaches CFS-like proportionality.

## 12. Testability

The `Clock` trait abstracts time. `StdClock` wraps `std::time::Instant`.
`ManualClock` is a `Cell<u64>` advanced by `advance` / `advance_ms` /
`advance_us`. The scheduler is generic over `C: Clock`, so every test runs
on `ManualClock` with deterministic time.

The scheduler holds no synchronisation primitives — no `Mutex`, no
`RwLock`, no atomics in the hot path. This makes property testing trivial
(one thread, one scheduler, advance the clock by hand, observe outputs).
The kernel-side BPF variant will introduce per-CPU locking, but at that
layer, not here.

`SchedulerStats` exposes monotonic counters that can be diffed across
test steps to assert "this transition caused exactly one new boost" or
"this burst hit the rate limit twice".

## 13. What we explicitly do NOT do

- **No kernel-side BPF in this crate.** The `sched_ext` binding lives in
  the planned `jonerix-mlfq-scx` crate. This crate is pure userspace.
- **No CPU pinning.** Affinity is not a concept the scheduler tracks.
- **No NUMA awareness.** All run queues are flat.
- **No cgroup interaction.** Tasks are independent; cgroup hierarchy is
  invisible.
- **No real-time priority handling.** Real-time tasks (`SCHED_FIFO`,
  `SCHED_RR`) should run under those kernel policies, not under
  `jonerix-mlfq`. This scheduler is for `SCHED_NORMAL`-style workloads.
- **No I/O priority hints.** Tasks don't tell us they're blocked on disk;
  we infer from sleep duration.
- **No `SCHED_DEADLINE`-style admission control.** No deadlines, no
  bandwidth reservations.

## 14. References

- Linux `sched_ext` documentation —
  `https://docs.kernel.org/scheduler/sched-ext.html` (verify the URL
  before linking from external sites; the kernel.org docs URL scheme has
  changed historically).
- XNU scheduler — `https://github.com/apple-oss-distributions/xnu` for the
  conceptual reference (the prime directive of this crate forbids consulting
  XNU's actual scheduler source; the conceptual model — Mach IPC carries
  dependency hints — is public knowledge documented in WWDC sessions and
  Apple's developer docs).
- Con Kolivas, BFS / MuQSS write-ups — `http://ck.kolivas.org/patches/bfs/`
  (public design notes; the algorithm is independent of this crate's).
- `scx_lavd` — one of the `scx` example schedulers, similar idea
  (sleep-derived latency criticality), different math. The
  `scx_lavd` source was not consulted while authoring this crate.
