// Behaviour autoconf's GNU M4 probe depends on. autoconf rejects an m4
// unless each of these runs print nothing (stdout and stderr together,
// trailing newlines stripped):
//
//   m4 -F conftest.m4f </dev/null
//   echo "$ac_snippet" | m4 --trace=mac
//
// These run the built binary directly and need no GNU m4 oracle.

use std::io::Write;
use std::path::PathBuf;
use std::process::{Command, Stdio};

fn run(args: &[&str], stdin_data: &[u8]) -> (i32, Vec<u8>, Vec<u8>) {
    let mut child = Command::new(env!("CARGO_BIN_EXE_m4oxide"))
        .args(args)
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn()
        .expect("spawn m4oxide");
    child.stdin.as_mut().unwrap().write_all(stdin_data).unwrap();
    let out = child.wait_with_output().unwrap();
    (out.status.code().unwrap_or(-1), out.stdout, out.stderr)
}

fn scratch_path(tag: &str) -> PathBuf {
    std::env::temp_dir().join(format!("m4oxide-{}-{}", tag, std::process::id()))
}

#[test]
fn empty_stdin_is_not_an_error() {
    // 0.1.2 panicked (exit 134) on empty input.
    assert_eq!(run(&[], b""), (0, Vec::new(), Vec::new()));
}

#[test]
fn freeze_with_empty_stdin_is_silent() {
    let path = scratch_path("probe.m4f");
    let _ = std::fs::remove_file(&path);
    let result = run(&["-F", path.to_str().unwrap()], b"");
    let created = path.exists();
    let _ = std::fs::remove_file(&path);
    assert_eq!(result, (0, Vec::new(), Vec::new()));
    assert!(created, "-F must create the freeze file");
}

#[test]
fn trace_probe_snippet_is_silent() {
    let snippet: &[u8] =
        b"changequote(<,>)indir(<ifdef>,mac,bug)patsubst(a,\\(b\\)\\|\\(a\\),\\1)dnl\n\
ifelse(index(..wi.d.,.d.),-1,bug)\n\
ifelse(index(;:,:),-1,bug)\n";
    let (code, out, err) = run(&["--trace=mac"], snippet);
    assert_eq!(code, 0);
    assert_eq!(out, b"\n\n");
    assert!(err.is_empty(), "stderr: {}", String::from_utf8_lossy(&err));
}

#[test]
fn including_an_empty_file_is_not_an_error() {
    let path = scratch_path("empty.m4");
    std::fs::write(&path, b"").unwrap();
    let input = format!("include(`{}')x\n", path.display());
    let result = run(&[], input.as_bytes());
    let _ = std::fs::remove_file(&path);
    assert_eq!(result, (0, b"x\n".to_vec(), Vec::new()));
}
