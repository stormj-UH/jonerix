# m4oxide - part of the GNO stack

Clean-room Rust implementation of `m4`, a macro expander, for jonerix.

The implementation is developed from public documentation, black-box behavior
of compiled `m4` binaries, Ghidra/disassembly observations, and test suites.
GNU m4 implementation source code is not used.

Zero runtime dependencies — `Cargo.toml` declares no third-party crates, the
binary is built against the Rust standard library only. The regex engine, eval
parser, and macro engine are all hand-rolled.

## Install (any Linux)

m4oxide ships as a self-contained, musl-static `.jpkg` artifact. The repo
includes a POSIX-shell installer that fetches it, verifies the JPKG header,
and lays the binary down under a prefix you choose.

```sh
curl -fsSL https://raw.githubusercontent.com/stormj-UH/jonerix/main/packages/develop/m4oxide/install.sh | sh
```

Or clone and run locally:

```sh
sh install.sh                      # install to /usr/local/bin/m4oxide
sh install.sh --prefix "$HOME/.local"
sh install.sh --make-default       # also link $PREFIX/bin/m4 -> m4oxide
sh install.sh --no-prompt          # non-interactive; skip the m4 symlink prompt
sh install.sh --version 0.1.3-r0 --arch x86_64
sh install.sh --help
```

A default install lays down only:

- `$PREFIX/bin/m4oxide`
- `$PREFIX/share/licenses/m4oxide/LICENSE` (if shipped in the payload)
- `$PREFIX/share/man/manN/m4oxide.N` (if shipped in the payload)

The `$PREFIX/bin/m4` symlink is **strictly opt-in** — either pass
`--make-default`, or accept the interactive prompt. The installer never
touches `/usr/bin/m4` or any other system binary.

Options:

- `--version VER` — package version (default: `0.1.3-r0`).
- `--prefix DIR` — install prefix (default: `/usr/local`). Binary goes to
  `$PREFIX/bin/m4oxide`, license to `$PREFIX/share/licenses/m4oxide/`,
  man pages to `$PREFIX/share/man/manN/`.
- `--arch ARCH` — override autodetection (`uname -m`); `x86_64` and
  `aarch64` are published.
- `--make-default` — also install `$PREFIX/bin/m4` as a symlink to
  `m4oxide`. The installer warns loudly if an existing `m4` earlier on
  `$PATH` (commonly `/usr/bin/m4`) would shadow the new symlink.
- `--no-make-default` — skip the symlink (this is the default; the flag
  is mostly useful to suppress the interactive prompt).
- `--no-prompt` / `--yes` — non-interactive mode. Equivalent to answering
  the prompt with its default ("N"). Useful for `curl | sh` and CI.

After install, the script prints a summary trailer covering what landed,
whether `$PREFIX/bin` is on `$PATH`, and (when `--make-default` was used)
whether another `m4` ahead on `$PATH` would shadow the new symlink.

The installer is strict POSIX `#!/bin/sh`, validated under `dash`, `mksh`,
and `shellcheck -s sh`. It depends only on `curl` (or `wget`), `tar`,
`zstd`, plus standard coreutils (`od`, `dd`, `install`, `mktemp`,
`find`, `awk`). It writes nothing outside `$PREFIX` and a
`mktemp`-managed working directory.

## Build & install

```sh
cargo build --release
cargo install --path .
```

Or install via jonerix once the package is published:

```sh
jpkg install m4oxide
```

The jonerix package installs both `/bin/m4oxide` and a `/bin/m4` symlink so
existing tools that look for `m4` find m4oxide.

## Performance

m4oxide uses an `InputStack` cursor model — macro expansion pushes a new frame
on top of the input stack rather than rebuilding a flat byte stream on each
call. The previous prepend-and-rescan model was O(M·N) in macro count × input
size; the cursor model is O(1) per push.

Measured on macOS arm64 (this Mac), GNU m4 1.4.21 from Homebrew as the oracle:

| Workload                                | m4oxide  | GNU m4 1.4.21 | Ratio        |
| ----------------------------------------| -------- | ------------- | ------------ |
| 248-file extracted upstream check corpus| ~1.1 s   | ~1.4 s        | **1.27× faster** |
| `tools/stress.m4` (770 KB, 5000 macros) | ~42 ms   | ~42 ms        | parity       |
| Binary size (release, fat-LTO, stripped)| 487 KiB  | 296 KiB       | +64% (static) |
| Peak RSS (Makefile.in from corpus)      | 2.2 MiB  | —             | —            |

The `tools/bench.sh` script reproduces these numbers against any candidate
binary; `tools/stress.m4` is shipped in-tree as a synthetic macro-heavy
workload.

The release build uses fat LTO + single codegen unit + `panic = "abort"` +
symbol stripping (see `Cargo.toml`). Release builds with no third-party
dependencies make this essentially free at compile time.

## Security

### Audit summary

The codebase has been audited end-to-end for command injection, path
traversal, recursion bombs, integer overflow, and `unsafe` soundness. No P0
vulnerabilities were found. P1 hardening landed in v0.1.2:

- **`--safe` flag.** Disables `syscmd`, `esyscmd`, `include`, `sinclude` for
  use with untrusted input. Default behavior is unchanged from GNU m4 (these
  builtins remain enabled) so `--safe` is opt-in.
- **No more `unsafe extern "C"` block.** v0.1.1 and earlier had a hand-rolled
  libc `write(2)` loop. It was sound (the `written < 0` guard preceded the
  `as usize` cast) but pointless — `io::stdout().write_all()` handles partial
  writes identically. Removed.

Recursion bombs (e.g. `define(\`a',\`a\`'a')a`) and m4wrap loops hang under
the default `-L 0` (unlimited) just as GNU m4 does. For untrusted input use
`--safe -L 8192` plus a process-level timeout.

### `unsafe` inventory

Two `unsafe` blocks total. Both are at the same idiom and both are sound by
the call site's own ASCII guarantee:

```rust
// src/main.rs:968 and src/main.rs:2405
// Safety: name bytes are ASCII (is_name_start/is_name_char).
let name_str = unsafe { std::str::from_utf8_unchecked(&name_bytes) }.to_string();
```

Macro names are scanned by `is_name_start` (matches `[A-Za-z_]`) followed by
`is_name_char` (matches `[A-Za-z0-9_]`). Both predicates only accept ASCII
bytes, which are by definition valid UTF-8. The `_unchecked` skips a
redundant validation pass on a hot loop.

There is no `unsafe extern "C"`, no `unsafe impl`, no raw-pointer arithmetic,
no `transmute`. `forbid(unsafe_code)` could be enabled crate-wide if these
two sites were converted to `from_utf8(...).unwrap()` (the cost is one extra
ASCII validation pass per macro name).

## autoconf

v0.1.3 fixes two things autoconf's GNU M4 probe (`AC_PROG_GNU_M4`)
trips over, so m4oxide is accepted as the `m4` for autoconf-generated
configure scripts:

- **Empty input no longer panics.** An empty stdin or an empty
  `include`d file aborted with an index-out-of-bounds panic (exit 134);
  the probe runs `m4 -F conftest.m4f </dev/null`.
- **Backreferences to groups that did not take part in the match are
  silent.** `patsubst(a,\(b\)\|\(a\),\1)` expands `\1` to nothing
  without the "sub-expression 1 not present" warning, as GNU m4 does.
  A reference past the last group in the regex still warns.

## Compatibility Mode

Set `M4OXIDE_TEST_MODE=1` to make diagnostics and identity strings emit the
exact same bytes as GNU m4. This is the only mode under which black-box
oracle tests can pass — without it, `--version`, `--help`, and error
prefixes all identify as `m4oxide`.

```sh
M4OXIDE_TEST_MODE=1 cargo test
```

Without `M4OXIDE_TEST_MODE`, `m4oxide --version` reports `m4oxide <version>`
and error prefixes are `m4oxide:` rather than `m4:`.

## Testing

Local tests include Rust unit tests, oracle-comparison tests, and a fuzz
harness. The oracle defaults to `m4` from `$PATH`; set `M4_ORACLE` to point
at a specific binary.

```sh
M4_ORACLE=/usr/bin/m4 cargo test
cargo build --release
./tools/oracle_sweep.py    --candidate target/release/m4oxide
./tools/practical_check.py --candidate target/release/m4oxide
./tools/fuzz.py            --candidate target/release/m4oxide --seed 42 --count 200
./tools/bench.sh           target/release/m4oxide
```

Test surface at v0.1.3:

- 11 Rust unit tests + 5 oracle-parity tests (`tests/oracle_basic.rs`) +
  17 oracle-parity tests (`tests/practical.rs`) + 4 autoconf-probe tests
  (`tests/autoconf_probe.rs`, no oracle needed) — 37 cargo tests total.
- 27-case `tools/oracle_sweep.py` covering the core builtins.
- 25-file `practical-corpus/` covering autoconf-style quoting, sendmail-style
  define heavy chains, generator macros, regex/patsubst, divert, eval,
  changequote/changecom, plus two adversarial-but-real autoconf patterns.
- 200-input fuzzer (`tools/fuzz.py`) generating valid m4 across `define`,
  `ifdef`, `ifelse`, `eval`, `translit`, `changequote`, `divert`/`undivert`,
  `dnl`, `patsubst`, `regexp`, `pushdef`/`popdef`, `indir`, `incr`/`decr`,
  `m4wrap`, `format` and diffing against the oracle.
- 248/248 extracted upstream GNU m4 1.4.21 check inputs (`tools/run_upstream_checks.py`).

Upstream GNU m4 check inputs can be downloaded into `cleanroom/private/`,
which is intentionally ignored by git:

```sh
mkdir -p cleanroom/private/upstream
cd cleanroom/private/upstream
curl -fsSLO https://ftp.gnu.org/gnu/m4/m4-1.4.21.tar.xz
mkdir -p m4-1.4.21-checks
tar -xf m4-1.4.21.tar.xz -C m4-1.4.21-checks --strip-components=1 \
  m4-1.4.21/checks m4-1.4.21/examples
cd ../../..
./tools/run_upstream_checks.py cleanroom/private/upstream/m4-1.4.21-checks/checks
```

Do not extract or inspect GNU m4 implementation source files.

## Repository layout

- `src/main.rs` — single-file binary crate (engine, eval, regex, builtins).
- `tests/` — Rust integration tests (`oracle_basic.rs`, `practical.rs`,
  `autoconf_probe.rs`).
- `tools/` — runtime developer tools.
  - `oracle_sweep.py` — 27-case core-builtin sweep.
  - `practical_check.py` — runs the 25-file practical corpus.
  - `run_upstream_checks.py` — runs GNU m4's 248-file check corpus.
  - `fuzz.py` — random-valid-m4 generator + oracle differ.
  - `bench.sh` — reproducible perf measurement.
  - `stress.m4` — 770 KB synthetic macro-heavy workload.
- `practical-corpus/` — 25 real-world-style `.m4` inputs.
- `cleanroom/` — clean-room provenance: notes, binary-analysis tools, and
  `cleanroom/private/` (gitignored) for downloaded upstream archives and
  generated traces.
- `.forgejo/workflows/ci.yml` — fmt, clippy, unit tests, oracle sweep against
  Debian's GNU m4.

## Lint policy

`#![deny(warnings)]` is in effect at the crate root, and CI also passes
`RUSTFLAGS=-D warnings`. Any rustc warning is a hard error. CI additionally
runs `cargo clippy --all-targets -- -D warnings` and `cargo fmt --check`.

## License

MIT — see [`LICENSE`](LICENSE).
