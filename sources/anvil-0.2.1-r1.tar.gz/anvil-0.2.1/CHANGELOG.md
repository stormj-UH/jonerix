# Changelog

All notable changes to anvil are recorded here. anvil is a clean-room,
MIT-licensed reimplementation of the ext2/3/4 userland toolchain. The
project has no tagged releases yet, so everything to date lives under
the single `Unreleased` section below.

Scores quoted against the upstream e2fsprogs v1.47.3 test suite come
from `docs/ROADMAP.md`.

## Unreleased

### Added

#### `mkfs.ext4`
- Baseline ext4 writer: superblock, GDT, block/inode bitmaps, inode
  table, root + `lost+found`; kernel mounts read-write and upstream
  `e2fsck -fn` passes clean.
- Standard option set: `-L`, `-U`, `-b`, `-I`, `-N`, `-m`, `-q`, `-F`.
- JBD2 journal: inode 8 + journal superblock + `HAS_JOURNAL` compat
  bit; journal is skipped on filesystems smaller than 8 MiB to match
  mke2fs defaults.
- `-O metadata_csum`: finalization pass that walks every structure
  after it is placed on disk and patches inode, block-bitmap,
  inode-bitmap, directory-tail, GDT, and superblock checksums in
  place; upstream `e2fsck -fn` accepts the result with zero
  `IGNORED` or mismatch lines.
- JBD2 `CSUM_V3` on the journal superblock when `metadata_csum` is
  enabled.
- `-t ext2` and `-t ext3` emit the correct feature-bit subsets (no
  extents / no journal respectively).
- `-J size=N` and `-G <groups-per-flex>` parsing, plus a group-0
  clamp on the journal inode that closes the last 4-case gap against
  upstream (`225/225` overall).

#### `e2fsck`
- Read-only 5-pass structure (passes 1 through 5) built on
  `anvil_core`; agreement with the upstream corrupt-fs suite moved
  from an initial batch of structural checks through to `149/149`
  corruption detection with zero false-positives on the 44 clean-fs
  fixtures.
- Pass 1 / pass 5 cross-checks: extent-size vs `i_size`, GDT-vs-bitmap
  free-block accounting, per-group `bg_free_blocks` vs bitmap
  population, EOF-tolerant block reads, `BLOCK_UNINIT` gating, and
  interior-node extent errors.
- Pass 2 directory walk: htree-aware (first-block-only `.` / `..`
  checks), duplicate-name and duplicate-dot detection, double and
  triple indirect block maps for pre-ext4 images, and encrypted-
  directory short-dirent sanity.
- Pass 4 unattached-inode detection with explicit exemptions for
  `s_orphan_file_inum` and `EA_INODE` helper inodes.
- Superblock invariants + sparse-super backup failover; `ORPHAN_FS`
  state bit handling; root-inode `i_dtime`, `EXTENTS_FL` on short
  symlinks, `i_file_acl_hi` on non-64BIT filesystems, and xattr
  block-range sanity.
- Clean-room port of the libext2fs dirhash (legacy v0 rolling hash
  and v2 TEA), with black-box oracle vectors checked in at
  `crates/fsck/tests/dirhash_vectors.txt`; htree hash recomputation
  in pass 2 catches the `f_h_reindex` corruption where the
  superblock seed has been retroactively changed.
- htree structural checks: `dx_root` sanity, `dx_node` duplicate-
  block detection, and hash-order verification.
- Checksum verify surface for `metadata_csum` filesystems: inode
  csum with the `i_checksum_hi` gate on `i_extra_isize > 2`,
  GDT descriptor csum (warning-only when mismatched, matching
  upstream's `IGNORED`), external extent-block tail csum, dir-block
  tail csum, xattr block csum, and block + inode bitmap csums.
- Deleted-inode csum scrutiny: every bitmap-free inode slot is
  verified against its stored csum (`f_deleted_inode_bad_csum`).
- Bad-blocks inode walker: content walk, overlap with filesystem
  metadata, self-reference, and mode/links invariants; filesystem
  metadata blocks and xattr blocks are pre-marked in `block_in_use`
  so overlap detection has the right baseline.
- Journal sanity: JBD2 superblock magic, V1/V2 SB mismatch, journal
  walk errors, journal hole detection, V2 `nr_users` range, and
  refusal of external-journal filesystems.
- Quota: QFMT_V2 walker with correct reserved-inode exclusion
  (`f_quota_invalid_inum`).
- Miscellaneous detectors: symlink target content validation,
  symlink extent-coverage vs `i_size`, `EA_INODE` flag on
  non-regular-file, EA-inode referenced from directory, dir entries
  landing in the unused-inodes region, `i_size` vs extent end-of-
  range, strict `bg_itable_unused`, per-group pointer range, and
  multiply-claimed-block promotion to hard error when
  `SHARED_BLOCKS` / `BIGALLOC` are off.
- bigalloc-aware passes: pass 1 and pass 5 tuned so the cluster-
  allocator images go through without false positives while the
  `f_holedir4` and extent-overlap dup-block cases still fire.
- `-y` repair queue drained after the read-only passes:
  superblock `s_free_blocks_count` / `s_free_inodes_count`,
  per-group `bg_free_blocks` / `bg_free_inodes` / `bg_used_dirs`,
  root-inode `i_dtime` clear (`f_mke2fs2b`), `EXTENTS_FL` clear on
  short symlinks (`f_invalid_extent_symlink`), `i_file_acl_hi` clear
  on non-64BIT filesystems, `ORPHAN_FS` bit clear, and `ERROR_FS`
  state-bit clear on a clean repair round. Exit codes match upstream
  (`0` clean / `1` repaired / `4` uncorrected) and repairs round-
  trip through upstream `e2fsck`.
- `-p` preen mode rides the same queue as `-y` for the repairs
  listed above.

#### `dumpe2fs`
- Read-only SB + GDT printer built on `anvil_core::fs::Fs`, with
  standard per-field summary and optional per-group listing; `-h`
  for header-only output.
- `-x` hex-dump mode for SB and GDT.
- `-b` prints the bad-blocks list from inode 1.

#### `tune2fs`
- Narrow field-level edits: label (`-L`), UUID (`-U`), max-mount-
  count (`-c`), check-interval (`-i`), errors behaviour (`-e`),
  reserved-% (`-m`), state (`-l`). Feature-bit toggles remain
  deferred.

#### `debugfs`
- Non-interactive inspection: `-R "cmd"` one-shot and a line REPL.
- Commands: `stats`, `stat <inode>`, `ls <path>` (with `-R` for
  recursive listing), `clri <inode>`, and `icheck <block>`.

#### `resize2fs`
- `-P` read-only minimum-size printer.
- `-M` shrinks the filesystem by dropping trailing empty groups.

#### Infrastructure
- MIT licence declared at the repo root.
- `docs/ROADMAP.md` tracking per-phase progress and upstream-suite
  agreement numbers.
- GitHub Actions workflow for the build + unit-test matrix.
- `tests/upstream.sh` harness that diffs anvil against upstream
  e2fsprogs on the same fixtures; `ANVIL_STRICT=1` gates the
  zero-false-positive budget.
- Clean-room methodology: dirhash was ported from black-box
  oracle vectors captured against upstream, with disassembly notes
  checked in under `docs/`.

### Changed
- `fsck/ctx`: inode-slot patch operations consolidated behind a
  single `patch_inode_slot` helper.
- Release build is warning-free at the 225/225 milestone.
- GDT descriptor csum mismatches are emitted as warnings rather
  than errors, matching upstream's `IGNORED` wording.

### Fixed
- GDT block offset computation on bigalloc filesystems; the
  per-group pointer range check now runs cleanly on bigalloc.
- Device-inode and journaled-SB-drift false positives that were
  polluting the clean-fs run.
- Short-symlink extent walk and EA-inode block-map walks are
  skipped so they no longer trip unattached-inode heuristics.
- `s_checksum_type` is gated before checksum verification runs,
  and `EOFBLOCKS_FL` is tolerated where upstream tolerates it.
