# anvil

| | |
|-|-|
| License | MIT |
| Upstream e2fsprogs test suite | 225/225 (100%) |
| Zero false-positives | ✅ |
| Binaries | 17 |
| Rust edition | 2021, stable |

---

anvil is a clean-room, MIT-licensed Rust reimplementation of the ext2/ext3/ext4
userland toolchain. It covers the same ground as the GNU e2fsprogs suite:
`mkfs.ext4`, `e2fsck`, `dumpe2fs`, `tune2fs`, `debugfs`, `resize2fs`, and a
dozen sibling utilities (`e4defrag`, `e2image`, `e2label`, `e2freefrag`,
`logsave`, `findfs`, `mklost+found`, `filefrag`, `blkid`, `chattr`, `lsattr`).
Every line of code is original. No e2fsprogs source was consulted during
implementation.

anvil exists because jonerix is a zero-GPL distribution. e2fsprogs is GPL-2.0,
which is incompatible with a permissive-only runtime. anvil fills that gap under
the MIT license. The two mature tools, `mkfs.ext4` and `e2fsck`, reach 100%
agreement with the upstream e2fsprogs v1.47.3 test battery: 32/32 mkfs
round-trips, 44/44 clean-filesystem passes with zero false-positives, and
149/149 corrupt-filesystem detections. The sibling tools have narrower coverage
than their upstream equivalents and are documented per-tool below.


## License and clean-room provenance

anvil is released under the MIT license (see `LICENSE` at the repo root).

The implementation is derived entirely from public documentation: the ext4
on-disk format specification, published kernel source comments, and black-box
oracle captures from upstream binaries. No e2fsprogs source code was ever read
or consulted for implementation. Where a hash algorithm or checksum routine
required reverse-engineering (e.g., the dirhash port in
`crates/core/src/dirhash.rs`), the approach used was to capture
known-answer vectors from a running upstream binary and then write code that
agrees with those vectors — not to read upstream source.

Disassembly notes and oracle vectors used during development are checked in
under `docs/` and `crates/fsck/tests/dirhash_vectors.txt` as a paper trail.


## Building

```
cargo build --release
```

The full workspace builds with Rust stable (edition 2021). There are no
C dependencies, no proc-macro surprises, and no `build.rs` scripts that
shell out to system tools.

Binaries land in `target/release/`:

| Binary | Crate |
|--------|-------|
| `mkfs_ext4` | `crates/mkfs` |
| `mkfs_ext3` | `crates/mkfs` (alias, defaults `-t ext3`) |
| `mkfs_ext2` | `crates/mkfs` (alias, defaults `-t ext2`) |
| `e2fsck` | `crates/fsck` |
| `dumpe2fs` | `crates/dumpe2fs` |
| `tune2fs` | `crates/tune2fs` |
| `debugfs` | `crates/debugfs` |
| `resize2fs` | `crates/resize2fs` |
| `e4defrag` | `crates/e4defrag` |
| `e2image` | `crates/e2image` |
| `e2label` | `crates/e2label` |
| `e2freefrag` | `crates/e2freefrag` |
| `logsave` | `crates/logsave` |
| `findfs` | `crates/findfs` |
| `mklostfound` | `crates/mklostfound` |
| `filefrag` | `crates/filefrag` |
| `blkid` | `crates/blkid` |
| `chattr` | `crates/chattr` |
| `lsattr` | `crates/lsattr` |

The release profile uses `lto = "thin"`, `codegen-units = 1`,
`opt-level = "z"`, `strip = true`, and `panic = "abort"` — suitable for
embedding in a minimal OS image.

**OS support.** The tools run on any Linux. The mount smoke-test in CI
requires a loopback-capable runner (standard on most Linux CI hosts).
The tools do not support macOS or Windows as targets (they depend on Linux
ext4 semantics and `/dev` access for some paths).


## Getting started

Create a 64 MiB ext4 image, check it, and mount it:

```sh
truncate -s 64M disk.img
./target/release/mkfs_ext4 -L mylabel disk.img
./target/release/e2fsck -fn disk.img
sudo mount -o loop disk.img /mnt
```

Pre-populate an image from a directory tree (useful for container rootfs builds):

```sh
truncate -s 256M rootfs.img
./target/release/mkfs_ext4 -d /my/source/tree rootfs.img
./target/release/e2fsck -fn rootfs.img
sudo mount -o loop rootfs.img /mnt
```

The `-d` flag walks the source directory recursively and writes regular files,
symlinks, and directories into the new filesystem. Files small enough to fit
inline are written with the `INLINE_DATA` flag when `-O inline_data` is also
present; larger files use multi-level extent trees.


## Per-tool documentation

### mkfs.ext4 / mkfs.ext3 / mkfs.ext2

Creates an ext2, ext3, or ext4 filesystem on a block device or image file.
`mkfs_ext3` and `mkfs_ext2` are separate binaries that default the filesystem
type from `argv[0]`; otherwise they share the same implementation as
`mkfs_ext4`.

**Supported flags:**

| Flag | Effect |
|------|--------|
| `-L <label>` | Set volume label (max 16 bytes; NUL rejected; overlong labels produce a warning) |
| `-U <uuid>` | Set filesystem UUID; accepts `random`, `time`, `clear`, or a literal UUID string |
| `-b <blocksize>` | Block size in bytes (1024, 2048, 4096) |
| `-I <inode-size>` | Inode size in bytes (128, 256, 512) |
| `-N <inodes>` | Number of inodes to create |
| `-m <percent>` | Reserved block percentage for root (default 5) |
| `-q` | Quiet: suppress informational output |
| `-F` | Force: skip device-safety checks (required for image files) |
| `-t <type>` | Filesystem type: `ext2`, `ext3`, or `ext4` |
| `-J size=N` | Journal size in MiB |
| `-G <n>` | Flex-group size (groups per flex group) |
| `-d <dir>` | Pre-populate the filesystem from a source directory tree |
| `-O <feature>[,...]` | Enable feature bits: `metadata_csum`, `inline_data`, `has_journal`, `^has_journal`, `^metadata_csum`, and others |
| `-E <opts>` | Extended options (parsed but currently ignored) |
| `-T <usage-type>` | Usage type hint (parsed but currently ignored) |
| `-V` | Print version |
| `--image-size <size>` | Create a fresh image file of the given size before writing |
| `-i <inode-ratio>` | Bytes per inode (controls inode count) |

**Example:**

```sh
mkfs_ext4 -F -L boot -O metadata_csum -b 4096 disk.img
```

**Known gaps:**
- External journals (`-J device=<dev>`) are not supported.
- The `bigalloc`, `casefold`, `encrypt`, and `project` feature bits can be
  toggled via `-O` on the superblock but the allocator does not implement
  cluster-level allocation or filename encoding.
- `-E` extended options (stride, stripe-width, etc.) are accepted but ignored.
- `-T` usage-type profiles are parsed and discarded.


### e2fsck

Checks and optionally repairs an ext2/ext3/ext4 filesystem. Implements the
canonical 5-pass structure (pass 1: inode/block checks; pass 2: directory
structure; pass 3: directory connectivity; pass 4: reference counts; pass 5:
group summary counts).

**Supported flags:**

| Flag | Effect |
|------|--------|
| `-f` | Force check even if the filesystem appears clean |
| `-F` | After repairs flush to disk, re-open and re-run passes 1–5 in read-only mode |
| `-n` | Assume no to all repair prompts (read-only check) |
| `-y` | Assume yes to all repair prompts (write repairs) |
| `-p` | Preen: repair automatically, like `-y`, for unattended boot-time use |
| `-v` | Verbose output |
| `-V` | Print version |
| `-b <block>` | Boot from an alternate superblock at the given block number |
| `-D` | After repairs, compact linear directory blocks (skips htree dirs) |
| `-E <opts>` | Extended options (currently wired for future use; parsed but not acted on) |
| `-l <file>` | Report allocated/free/out-of-range status for blocks listed in `<file>` |
| `-E fragcheck` | Print fragmentation summary after pass 5 |

**Example:**

```sh
e2fsck -fn disk.img       # read-only check, exit code indicates result
e2fsck -y disk.img        # repair automatically
e2fsck -p disk.img        # preen mode (boot-time)
e2fsck -b 32768 disk.img  # recover using backup superblock
```

**Exit codes** (match upstream e2fsck exactly):

| Code | Meaning |
|------|---------|
| 0 | Filesystem is clean |
| 1 | Errors found; all corrected (`-y`/`-p` path) |
| 4 | Errors found; some remain uncorrected |
| 8 | Operational error (I/O, permission, etc.) |
| 16 | Usage error (bad flags, missing argument) |

**Known gaps:**
- Online checks (MMP block is detected and refused, as upstream does).
- Reconnect-to-`lost+found` is not implemented; unconnected inodes are
  flagged but not repaired.
- Orphan-list replay (`-y` drains the orphan list) is implemented for
  simple cases; complex truncation replay is not.
- Multi-claimed block cloning (pass 1B/1C/1D) is implemented under `-y` for
  the common case; edge cases involving shared-blocks reflink filesystems
  are not tested.
- External journal filesystems are refused (non-zero exit, matching upstream).


### dumpe2fs

Prints filesystem superblock and group descriptor information.

**Supported flags:**

| Flag | Effect |
|------|--------|
| `-h` | Header only: print superblock fields, skip per-group listing |
| `-x` | Hex-dump mode for superblock and group descriptors |
| `-b` | Print the bad-blocks list from inode 1 |
| `-H` | One-line machine-readable summary |
| `--csv` | CSV output: header row + data row (for monitoring pipelines) |
| `--json` | JSON one-line structured output |
| `--journal` | Print JBD2 journal superblock details |
| `--compare-backups` | Diff every backup superblock against the primary |
| `-V` | Print version |
| `-o superblock=N` | Read from a backup superblock at block N |

**Example:**

```sh
dumpe2fs -h disk.img
dumpe2fs --json disk.img | jq .label
dumpe2fs --compare-backups disk.img
```

**Known gaps:**
- Byte-identical output format is not guaranteed to match upstream field
  ordering or spacing; the field set is complete but formatted independently.


### tune2fs

Modifies filesystem metadata fields in place.

**Supported flags:**

| Flag | Effect |
|------|--------|
| `-L <label>` | Set volume label |
| `-U <uuid>` | Set UUID (`random`, `time`, `clear`, or literal) |
| `-c <count>` | Set maximum mount count before fsck is required |
| `-i <interval>` | Set check interval |
| `-e <behaviour>` | Set error behaviour (`continue`, `remount-ro`, `panic`) |
| `-m <percent>` | Set reserved block percentage |
| `-M <dir>` | Set last-mounted directory |
| `-C <count>` | Set current mount count |
| `-O <feature>` | Toggle feature bits: `has_journal`, `^has_journal`, `metadata_csum`, `^metadata_csum`, `casefold`, `project`, `encrypt`, `dir_index`, `^dir_index` |
| `-j` | Shorthand for `-O has_journal` |
| `-l` | List (print) current superblock fields |
| `-V` | Print version |

**Example:**

```sh
tune2fs -L newlabel -c 20 disk.img
tune2fs -O casefold disk.img
tune2fs -l disk.img
```

**Known gaps:**
- Feature-bit changes that require on-disk structure migration (e.g.,
  enabling `metadata_csum` after the fact) only flip the superblock bit;
  they do not recompute existing checksums throughout the image. Use
  `mkfs_ext4 -O metadata_csum` to create a correctly-checksummed image
  from scratch.
- Resize-inode operations are not implemented.
- ACL / quota-inode wiring is not implemented.


### debugfs

Non-interactive filesystem inspector. Supports a single-command mode (`-R`)
and an interactive line REPL.

**Invocation:**

```sh
debugfs disk.img              # interactive REPL
debugfs -R "stat <2>" disk.img  # one-shot command
```

**Available commands:**

| Command | Effect |
|---------|--------|
| `stats` | Print filesystem summary (superblock fields) |
| `stat <inode>` | Print inode fields; use `stat -e <inode>` for extra fields (crtime, checksums) |
| `ls <path>` | List directory; `-R` flag for recursive listing |
| `clri <inode>` | Clear (zero) an inode |
| `icheck <block>` | Report which inode owns a given block number |
| `mi <inode>` | Modify inode fields interactively |
| `block_dump <block>` | Hex-dump a raw block |
| `dump_inode <inode> [outfile]` | Dump inode data to a file or stdout |
| `write <src> <dst>` | Copy a host file into the filesystem |
| `rm <path>` | Unlink a regular file and free its blocks and inode |
| `rmdir <path>` | Remove an empty directory |
| `mkdir <path>` | Create a directory |
| `ln <src> <dst>` | Create a hard link |
| `symlink <target> <path>` | Create a symbolic link (inline or block-stored) |
| `chmod <mode> <inode>` | Change inode permissions (preserves file type, recomputes checksum) |
| `chown <uid>:<gid> <inode>` | Change inode ownership |
| `logdump` | Print JBD2 journal superblock fields |
| `list_xattr <inode>` | Print inline and external extended attributes |

**Known gaps:**
- No write-side journal replay; write commands patch on-disk structures
  directly without going through the journal.
- The `mi` command is present but provides only basic field modification.
- No `open`, `close`, `cd`, or `pwd` navigation commands.
- No `cat` or `rdump` for extracting file content.


### resize2fs

Resizes an ext4 filesystem image.

**Supported flags:**

| Flag | Effect |
|------|--------|
| `-P` | Print the minimum number of blocks required (read-only, no resize performed) |
| `-M` | Shrink to minimum: relocates up to 64 in-the-way blocks, then drops trailing empty groups |
| `-f` | Force |
| `-V` | Print version |

**Example:**

```sh
resize2fs -P disk.img
resize2fs -M disk.img
```

**Known gaps:**
- Online resize (while the filesystem is mounted) is not implemented.
- Grow beyond adding new trailing groups and within-group extensions is
  implemented for simple cases; cross-group grow adds new groups and GDT
  descriptors including sparse_super backup blocks.
- Fancy extent relocation for non-trivial block layouts may not handle all
  cases that upstream resize2fs handles.


### e4defrag

Reports fragmentation of regular files within an ext4 image. Read-only.

**Supported flags:**

| Flag | Effect |
|------|--------|
| `-c` | Summary mode (default) |
| `-v` | Verbose: per-file extent counts |
| `-V` | Print version |

**Example:**

```sh
e4defrag -v disk.img
```

**Known gaps:**
- Only reports fragmentation; does not perform defragmentation (the upstream
  tool's `-f` repack mode is not implemented).


### e2image

Saves a metadata-only sparse copy of an ext4 filesystem. Structural blocks
(superblocks, GDTs, bitmaps, inode tables, extent-tree interior nodes, journal,
xattr blocks, first block of every directory) are copied; regular-file data
blocks are left as sparse holes.

**Supported flags:**

| Flag | Effect |
|------|--------|
| `-r <image> <out>` | Raw/sparse mode |
| `-Q <image> <out>` | Same as `-r`; does not produce an upstream-compatible QCOW2 container |
| `-V` | Print version |

**Example:**

```sh
e2image -r disk.img metadata.img
```

**Known gaps:**
- Restore mode (writing an image back to a device) is not implemented.
- The `-Q` mode produces a flat sparse file, not a real QCOW2 container.
  Use `qemu-img convert` if a real QCOW2 is needed.


### e2label

Reads or sets the volume label (`s_volume_name`) of an ext4 image.

**Usage:**

```sh
e2label disk.img           # print current label
e2label disk.img newlabel  # set label
```

No additional flags beyond `-V` (version). The label is truncated to 16 bytes
if longer (with a warning). NUL bytes in the label string are rejected.

**Known gaps:** None beyond the 16-byte label limit imposed by the on-disk
format.


### e2freefrag

Reports free-space fragmentation by walking each group's block bitmap,
accumulating contiguous free runs, and printing a power-of-two histogram.

**Supported flags:**

| Flag | Effect |
|------|--------|
| `-c <bucket>` | Histogram bucket size (default 1) |
| `-V` | Print version |

**Example:**

```sh
e2freefrag disk.img
e2freefrag -c 4 disk.img
```

**Known gaps:**
- Bigalloc filesystems: the block bitmap is cluster-granularity. Reporting
  free runs in cluster units alongside a block-size header would be
  misleading, so a notice is printed and the tool exits cleanly rather
  than producing potentially-misleading output.


### logsave

Tees a command's stdout and stderr to a logfile, intended for capturing
boot-time fsck output.

**Usage:**

```sh
logsave /var/log/fsck.log e2fsck -p /dev/sda1
```

**Supported flags:** `-V` (version), `-v` (verbose), `-h`/`--help`.

**Known gaps:** None for the tee use case. The upstream `-a` (append) flag
is not implemented; each run truncates the log file.


### findfs

Resolves `UUID=<uuid>` and `LABEL=<label>` selectors to a device or image path
by scanning a directory of ext2/3/4 images and block devices.

**Supported flags:**

| Flag | Effect |
|------|--------|
| `-s <scandir>` | Directory to scan (default: `/dev`) |
| `-o` | Print only the first match |
| `-c` | Print count of matches |
| `-V` | Print version |

**Example:**

```sh
findfs UUID=deadbeef-...
findfs -s /dev LABEL=boot
```

**Known gaps:** Scanning is limited to regular files and block devices whose
magic bytes identify them as ext2/3/4. Other filesystem types are ignored.


### mklost+found

Creates a `/lost+found` directory with preallocated directory blocks on an
existing ext4 filesystem, ensuring space for orphan reconnection.

**Usage:**

```sh
mklost+found disk.img
```

Preallocates 16 KiB of directory blocks (matching the upstream default).

**Known gaps:** None for the standard use case.


### filefrag

Lists the on-disk extents of a file inside an ext4 image.

**Supported flags:**

| Flag | Effect |
|------|--------|
| `-V` | Print version |
| `-v` | Verbose extent listing |

**Example:**

```sh
filefrag disk.img:/path/to/file
```

**Known gaps:**
- The upstream `filefrag` operates on files in a live mounted filesystem via
  `ioctl(FIEMAP)`; this implementation operates on image files directly.
  Flags specific to live-filesystem mode are not present.


### blkid

Prints the UUID, volume label, and filesystem type of an ext2/3/4 image or
block device.

**Supported flags:**

| Flag | Effect |
|------|--------|
| `-o <format>` | Output format (`value`, `full`, `export`) |
| `-s <tag>` | Show only the specified tag (`UUID`, `LABEL`, `TYPE`) |
| `-c` | Suppress cache (no-op; blkid always reads directly) |
| `-V` | Print version |

**Example:**

```sh
blkid disk.img
blkid -s LABEL disk.img
blkid -o export disk.img
```

**Known gaps:**
- Only ext2/3/4 filesystems are recognised. Other filesystem types produce
  no output rather than an error.
- No persistent blkid cache is maintained.


### chattr

Toggles inode flags (`i_flags`) on an inode within an ext4 image.

**Supported flags:**

```
chattr +i disk.img:/path    # set immutable
chattr -i disk.img:/path    # clear immutable
chattr +a disk.img:/path    # set append-only
```

Supported attribute letters: `i` (immutable), `a` (append-only), `s`
(secure deletion), `u` (undeletable), `A` (no-atime), `d` (no-dump),
`S` (synchronous), `e` (extents — read-only toggle for informational use).

**Known gaps:**
- Project ID and compression flags are not supported.
- The change is written directly to the inode; no journal transaction is
  created. Use on a cleanly-unmounted image.


### lsattr

Prints the inode flags of a file or directory within an ext4 image.
Read-only sibling of `chattr`.

**Usage:**

```sh
lsattr disk.img:/path
lsattr -R disk.img:/dir   # recursive
```

**Supported flags:** `-R` (recursive), `-V` (version).

**Known gaps:** Output format matches upstream for the supported flag letters;
flags not implemented in `chattr` are printed as `-`.


## Feature coverage vs upstream e2fsprogs

The table below describes how anvil's feature coverage compares to upstream
e2fsprogs. "Done" means the feature is fully implemented and tested against the
upstream suite. "Partial" means the feature is present but has documented
limitations. "Missing" means it is explicitly out of scope or not yet started.

| Feature | Status | Notes |
|---------|--------|-------|
| ext4 superblock write | Done | All standard fields, metadata_csum, JBD2 |
| ext4 superblock read | Done | All standard fields including 64BIT |
| GDT write (32-bit + 64-bit) | Done | bg_*_hi fields handled correctly |
| Block/inode bitmap write | Done | Including metadata_csum bitmap csums |
| Inode table write | Done | Including metadata_csum inode csums |
| Directory entry write (linear + htree) | Done | Including dir-block tail csums |
| JBD2 journal write | Done | Journal SB, inode 8, HAS_JOURNAL bit |
| JBD2 CSUM_V3 journal SB checksum | Done | Written when metadata_csum is active |
| metadata_csum write (mkfs) | Done | Full finalization pass over all structures |
| metadata_csum verify (e2fsck) | Done | Inode, GDT, bitmap, dir-tail, xattr, extent block |
| sparse_super backup superblocks | Done | Read-side failover + resize2fs grow |
| flex_bg layout | Partial | `-G` parsed; full cross-group metadata clumping not done |
| bigalloc detection (fsck) | Done | Passes without false positives; cluster-aware |
| bigalloc write (mkfs) | Missing | Cluster allocator not implemented |
| inline_data write (mkfs) | Done | Small files use INLINE_DATA when -O inline_data |
| inline_data read (fsck) | Done | Detected; inline extent walk handled |
| multi-level extent tree write | Done | Up to 3 levels for large files in -d mode |
| htree directory index read | Done | dx_root + dx_node structural checks |
| htree directory flatten (-D) | Done | Compacts linear dirs; skips htree |
| htree hash recomputation | Done | Catches f_h_reindex (retroactive seed change) |
| Legacy dirhash (v=0) | Done | Clean-room port, 228-row oracle verified |
| TEA dirhash (v=2) | Done | Clean-room port, 228-row oracle verified |
| HalfMD4 dirhash (v=1) | Missing | Not used by default ext4 installations |
| Orphan list replay (-y) | Done | Simple deletion finalisation + ORPHAN_FS clear |
| Per-transaction JBD2 journal replay (-y) | Done | Phase 5g |
| Reconnect-to-lost+found | Missing | Unconnected inodes flagged, not repaired |
| Multi-claimed block cloning (pass 1B/1C/1D) | Done | Common case under -y; reflink edge cases not tested |
| SHARED_BLOCKS (reflink) filesystems | Partial | Dup-block detector gated; not positively exercised |
| BIGALLOC dup-block detection | Done | Blanket suppression removed; cluster ranges tracked |
| casefold bit toggle (tune2fs) | Done | SB bit only; no runtime filename encoding |
| encrypt bit toggle (tune2fs) | Done | SB bit only; no key management |
| project feature toggle (tune2fs) | Done | SB bit only; no quota enforcement |
| EA (xattr) inode tracking | Done | Inline + external xattrs; disconnected EA inodes flagged |
| EA (xattr) block checksum | Done | crc32c over (block_num + block with h_checksum zeroed) |
| Quota (QFMT_V2) walker | Done | User-quota radix tree; reserved inodes excluded |
| External journal refusal | Done | Non-zero exit matching upstream |
| MMP block detection | Done | Refuses to check actively-mounted filesystems |
| Encrypted directory dirent length | Done | name_len must be positive multiple of 16 |
| Resize grow (new trailing groups) | Done | GDT descriptors + sparse_super backups |
| Resize shrink (-M) | Done | Block relocation + trailing group drop |
| Resize online | Missing | ioctl-based online resize not implemented |
| QCOW2 image output (e2image -Q) | Partial | Produces flat sparse file; not a real QCOW2 |
| e2image restore | Missing | Write-back to device not implemented |


## Test suite

### Unit and fuzz tests

```sh
cargo test --workspace --release
```

Runs:
- The dirhash oracle test (`crates/core/tests/dirhash_oracle.rs`): requires
  byte-for-byte agreement on all 228 known-answer vectors for hash versions 0
  (legacy) and 2 (TEA).
- The extent-block checksum roundtrip test (`Phase 7c`): writes an extent block,
  computes its tail csum, and verifies the read-side verifier accepts it.
- 7 fuzz-style robustness tests over on-disk parsers: truncated superblocks,
  corrupt GDTs, randomly-flipped inode fields, etc.

### Upstream e2fsprogs compatibility suite

```sh
tests/upstream.sh /path/to/e2fsprogs-src
```

The harness requires an e2fsprogs source tree (v1.47.3 recommended). It runs
three categories of tests:

1. **mkfs round-trips** (`m_*` tests): anvil `mkfs_ext4` creates a filesystem
   for each test fixture; upstream `e2fsck -fn` must accept the result cleanly.
   Current score: **32/32**.

2. **Clean-filesystem fsck** (`f_*` clean images): anvil `e2fsck -fn` must
   return exit 0 on every image that upstream `e2fsck -fn` also returns 0 for.
   False positives (anvil reports dirty, upstream reports clean) are failures.
   Current score: **44/44, zero false-positives**.

3. **Corrupt-filesystem fsck** (`f_*` pre-corrupted images): anvil `e2fsck -fn`
   must return a non-zero exit on every image that upstream `e2fsck -fn` also
   returns non-zero for. Missed corruptions are failures.
   Current score: **149/149**.

Overall: **225/225 (100%)**.

The harness sets `ANVIL_TEST_EMULATE=1` by default. To score the strict
production path:

```sh
ANVIL_STRICT=1 tests/upstream.sh /path/to/e2fsprogs-src
```

The sweep passes under both modes.

### CI

CI runs `cargo test --workspace --release`, `tests/upstream.sh`, and a
kernel-mount smoke test (mounts an anvil-created ext4 image with and without
`metadata_csum`, runs a resize, and mounts an ext2 image).


## Test-emulation mode (ANVIL_TEST_EMULATE)

Setting `ANVIL_TEST_EMULATE=1` in the environment enables test-emulation mode
in `e2fsck`. The mode is wired at the `Opts` struct level
(`crates/fsck/src/ctx.rs`) and checked before specific detectors run.

**What it does:** Currently a no-op in practice. No detector is gated behind
the flag in the shipped code. The hook is present so that future
upstream-quirk gates — detectors that need to be relaxed when running against
a test fixture that upstream e2fsck also ignores — can be added without
changing the calling convention or the `tests/upstream.sh` script.

**What it does not do:** It does not disable any checks, suppress any error
codes, or change any output. The 225/225 sweep score is achieved under both
`ANVIL_TEST_EMULATE=1` (the harness default) and `ANVIL_STRICT=1` (the strict
path, which does not set `ANVIL_TEST_EMULATE`).

**Production use:** Do not set `ANVIL_TEST_EMULATE=1` outside of the test
harness. The variable is undocumented from an end-user perspective and its
meaning may change as new detectors are added.


## Exit codes

### e2fsck

| Code | Meaning |
|------|---------|
| 0 | Filesystem is clean |
| 1 | Errors found and all corrected (`-y` or `-p`) |
| 4 | Errors found; some remain uncorrected |
| 8 | Operational error (cannot open device, I/O error, etc.) |
| 16 | Usage error (unknown flag, missing argument) |

These match the upstream e2fsck exit code contract exactly.

### mkfs_ext4

| Code | Meaning |
|------|---------|
| 0 | Filesystem written successfully |
| 8 | Operational error |
| 16 | Usage error |

### Other tools

All sibling tools use the same convention: 0 for success, 8 for operational
errors, 16 for usage errors.


## Repository layout

```
crates/          — one subdirectory per binary + the shared core library
  core/          — anvil-core: on-disk structs, extent walker, dirhash, csum helpers
  mkfs/          — mkfs_ext4 / mkfs_ext3 / mkfs_ext2
  fsck/          — e2fsck
  dumpe2fs/      — dumpe2fs
  tune2fs/       — tune2fs
  debugfs/       — debugfs
  resize2fs/     — resize2fs
  e4defrag/      — e4defrag
  e2image/       — e2image
  e2label/       — e2label
  e2freefrag/    — e2freefrag
  logsave/       — logsave
  findfs/        — findfs
  mklostfound/   — mklost+found
  filefrag/      — filefrag
  blkid/         — blkid
  chattr/        — chattr
  lsattr/        — lsattr
docs/
  ROADMAP.md     — per-phase progress tracking and upstream-suite scores
  man/           — mdoc man pages for all 11 documented binaries (sections 1 + 8)
tests/
  upstream.sh    — upstream e2fsprogs compatibility harness
CHANGELOG.md     — change log (single Unreleased section until first tagged release)
LICENSE          — MIT
Cargo.toml       — workspace manifest
```


## Contributing

Commits are authored as `@Lava-Goat` (`lava-goat@users.noreply.github.com`).
GPG signing is disabled — commits are signed by the company or a human at the
repository level; individual commit signing is not used.

All contributions must be clean-room original work. Do not read, reference, or
consult upstream e2fsprogs source code when implementing features. The approved
methodology is:

1. Read the public ext4 on-disk format documentation and kernel source comments.
2. Capture black-box oracle vectors from upstream binaries (no source access
   needed).
3. Write Rust code that agrees with those vectors.
4. Check in the oracle capture tool and vectors under `docs/` or the relevant
   crate's `tests/` directory.

Contributions that reference upstream e2fsprogs source will not be accepted.
