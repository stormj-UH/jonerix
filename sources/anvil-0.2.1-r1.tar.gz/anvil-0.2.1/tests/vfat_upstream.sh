#!/bin/sh
# Run anvil's mkfs_vfat against the dosfstools `.xxd` reference
# corpus. For each `.mkfs` test descriptor we:
#   * create a zeroed image of the declared size
#   * translate the upstream flags onto our binary's CLI
#   * run mkfs_vfat
#   * check the image with /usr/bin/fsck.vfat -n  (fsck-valid)
#   * render the first CMP_LIMIT bytes as xxd and diff against the
#     reference .xxd to tally byte-identity.
#
# Reference data lives in a .gitignore-excluded cache that is
# fetched on first run; dosfstools source files are NOT read.
#
# Usage: tests/vfat_upstream.sh
set -u

ROOT=${ROOT:-/tmp/anvil_vfattest}
CACHE=${VFAT_UPSTREAM_CACHE:-$ROOT/.vfat-upstream-cache}
ANVIL_MKFS=${ANVIL_MKFS_VFAT:-$ROOT/target/release/mkfs_vfat}
REAL_FSCK=${REAL_FSCK_VFAT:-/usr/bin/fsck.vfat}

if [ ! -x "$ANVIL_MKFS" ]; then
    echo "anvil mkfs_vfat not found at $ANVIL_MKFS" >&2; exit 1
fi
if [ ! -x "$REAL_FSCK" ]; then
    echo "fsck.vfat not found at $REAL_FSCK" >&2; exit 1
fi

# ---- bootstrap: fetch .mkfs / .xxd files on first run ----
mkdir -p "$CACHE"
if ! ls "$CACHE"/*.mkfs >/dev/null 2>&1; then
    echo "fetching dosfstools test descriptors into $CACHE ..."
    python3 - "$CACHE" <<'PY'
import json, sys, urllib.request
cache = sys.argv[1]
url = "https://api.github.com/repos/dosfstools/dosfstools/contents/tests"
for e in json.load(urllib.request.urlopen(url)):
    n = e["name"]
    if n.endswith(".mkfs") or n.endswith(".xxd"):
        urllib.request.urlretrieve(e["download_url"], cache + "/" + n)
        print("  " + n)
PY
fi

TMP=$(mktemp -d)
trap "rm -rf $TMP" EXIT

# xxd emulator matching `xxd -a` (autoskip): 16-byte rows, hex + ASCII,
# consecutive all-zero rows collapsed to a single `*`.
xxd_a() {
    python3 - "$1" "$2" <<'PY'
import sys
path, limit = sys.argv[1], int(sys.argv[2])
with open(path, "rb") as f:
    data = f.read(limit)
out = sys.stdout.write
off = 0
n = len(data)
while off < n:
    row = data[off:off+16]
    hex_part = " ".join(row[i:i+2].hex() for i in range(0, 16, 2))
    hex_part = hex_part.ljust(39)
    ascii_part = "".join(chr(b) if 32 <= b < 127 else "." for b in row)
    out(f"{off:08x}: {hex_part}  {ascii_part}\n")
    if row == b"\x00" * 16:
        j = off + 16
        while j + 16 <= n and data[j:j+16] == b"\x00" * 16:
            j += 16
        if j > off + 16:
            out("*\n")
            off = j
            continue
    off += 16
PY
}

# Extract KEY="value" (or KEY=value) from a .mkfs descriptor.
mkfs_get() {
    awk -v k="$1" -F= '$1 == k { s = substr($0, index($0, "=") + 1); gsub(/^"|"$/, "", s); print s; exit }' "$2"
}

total=0
byte_identical=0
fsck_valid=0
fsck_broken=0
layout_diff=0

for desc in "$CACHE"/*.mkfs; do
    [ -f "$desc" ] || continue
    name=$(basename "$desc" .mkfs)
    xxd_ref="$CACHE/$name.xxd"
    [ -f "$xxd_ref" ] || continue

    args=$(mkfs_get ARGS "$desc")
    size_kib=$(mkfs_get SIZE "$desc")
    cmp_limit_str=$(mkfs_get CMP_LIMIT "$desc")

    case "$size_kib" in
        ""|*[!0-9]*) echo "  SKIP $name: bad SIZE"; continue ;;
    esac

    # CMP_LIMIT is e.g. "10M", "1M", or empty → whole file.
    case "$cmp_limit_str" in
        "") cmp_limit=$((size_kib * 1024)) ;;
        *M) cmp_limit=$(( ${cmp_limit_str%M} * 1024 * 1024 )) ;;
        *K) cmp_limit=$(( ${cmp_limit_str%K} * 1024 )) ;;
        *)  cmp_limit=$cmp_limit_str ;;
    esac
    img_bytes=$((size_kib * 1024))
    [ "$cmp_limit" -gt "$img_bytes" ] && cmp_limit=$img_bytes

    # Translate upstream ARGS onto our binary's CLI.
    # Supported on ours: -F -n -i -s -S -R -f -M
    # Strip unsupported flags:
    #   -a           (alignment-off)
    #   -l <file>    (bad-block list)
    #   --mbr        (force MBR partition)
    #   --invariant  (deterministic-output override)
    translated=""
    # shellcheck disable=SC2086
    set -- $args
    skip_next=0
    for a in "$@"; do
        if [ "$skip_next" = 1 ]; then skip_next=0; continue; fi
        case "$a" in
            -a|--mbr|--invariant|--offset) ;;
            -l) skip_next=1 ;;
            *)  translated="$translated $a" ;;
        esac
    done

    total=$((total + 1))
    img="$TMP/$name.img"
    rm -f "$img"
    truncate -s "${size_kib}K" "$img"

    # shellcheck disable=SC2086
    if ! $ANVIL_MKFS $translated "$img" >/dev/null 2>&1; then
        echo "  HARD_FAIL $name: mkfs_vfat exited nonzero"
        fsck_broken=$((fsck_broken + 1))
        continue
    fi

    if ! $REAL_FSCK -n "$img" >/dev/null 2>&1; then
        echo "  HARD_FAIL $name: fsck.vfat rejected image"
        fsck_broken=$((fsck_broken + 1))
        continue
    fi
    fsck_valid=$((fsck_valid + 1))

    ours="$TMP/$name.ours.xxd"
    xxd_a "$img" "$cmp_limit" > "$ours"
    if diff -q "$ours" "$xxd_ref" >/dev/null 2>&1; then
        byte_identical=$((byte_identical + 1))
        echo "  IDENTICAL  $name"
    else
        layout_diff=$((layout_diff + 1))
        n_difflines=$(diff "$ours" "$xxd_ref" 2>/dev/null | grep -c '^[<>]')
        echo "  LAYOUT     $name ($n_difflines differing rows)"
    fi
done

echo
echo "=== anvil mkfs_vfat vs dosfstools reference corpus ==="
echo "total tests:          $total"
echo "byte-identical:       $byte_identical / $total"
echo "fsck-valid:           $fsck_valid / $total"
echo "layout-different:     $layout_diff / $total (fsck-valid but bytes differ)"
echo "broken/unreadable:    $fsck_broken / $total"
[ "$fsck_broken" -eq 0 ]
