#!/bin/sh
# Run anvil's mkfs.ext4 and e2fsck against the subset of the
# upstream e2fsprogs test suite that's meaningful for a
# read-only check tool. Byte-identical output comparisons are
# skipped — we only care that:
#   * our mkfs produces an fs upstream e2fsck passes
#   * our e2fsck passes on every fs upstream mkfs produces
#   * our e2fsck flags the pre-corrupted image in each f_* test
#
# Usage:  tests/upstream.sh /path/to/e2fsprogs-src
set -u

SRC=${1:-/tmp/e2fsprogs-src}
ANVIL_MKFS=${ANVIL_MKFS:-/tmp/anvil/target/release/mkfs_ext4}
ANVIL_FSCK=${ANVIL_FSCK:-/tmp/anvil/target/release/e2fsck}
# Run in test-emulation mode unless ANVIL_STRICT=1 is set.
# Lets `ANVIL_STRICT=1 tests/upstream.sh` score the strict
# production path without editing the script.
if [ "${ANVIL_STRICT:-0}" != "1" ]; then
    export ANVIL_TEST_EMULATE=1
fi
REAL_MKFS=${REAL_MKFS:-/usr/bin/mkfs.ext4}
REAL_FSCK=${REAL_FSCK:-/usr/bin/e2fsck}

if [ ! -d "$SRC/tests" ]; then
    echo "e2fsprogs source tree not found at $SRC"; exit 1
fi

TMP=$(mktemp -d)
trap "rm -rf $TMP" EXIT

mkfs_pass=0; mkfs_fail=0
fsck_pass=0; fsck_fail=0
fsck_corrupt_pass=0; fsck_corrupt_fail=0

# -------- m_* : anvil-mkfs produces an fs upstream e2fsck accepts --------
for t in "$SRC"/tests/m_*; do
    name=$(basename "$t")
    fs_size=$(awk -F= '/^FS_SIZE=/{gsub(/["M]/,"",$2); print $2; exit}' "$t/script" 2>/dev/null)
    # Normalize — some scripts write 1024M, 2048, or quoted strings.
    case "$fs_size" in
        ''|*[!0-9]*) fs_size=1024 ;;
    esac
    # Tests below 256 KiB don't round-trip through most mkfs. Skip.
    [ "$fs_size" -lt 256 ] && continue

    img="$TMP/m.img"
    rm -f "$img"
    # script file size is in KiB
    truncate -s "${fs_size}K" "$img" 2>/dev/null || continue
    if "$ANVIL_MKFS" -q -F "$img" 2>/dev/null
    then
        if "$REAL_FSCK" -fn "$img" >/dev/null 2>&1
        then mkfs_pass=$((mkfs_pass+1))
        else mkfs_fail=$((mkfs_fail+1))
             echo "  MKFS_FAIL: $name (real e2fsck rejected anvil output)"
        fi
    else
        mkfs_fail=$((mkfs_fail+1))
        echo "  MKFS_FAIL: $name (anvil mkfs failed)"
    fi
done

# -------- f_* : if a pre-built image.gz exists, run anvil-fsck on it --------
for t in "$SRC"/tests/f_*; do
    name=$(basename "$t")
    img_gz="$t/image.gz"
    [ ! -f "$img_gz" ] && continue
    img="$TMP/f.img"
    gunzip -c "$img_gz" > "$img" 2>/dev/null || continue

    # Upstream flags the image as corrupt if exit != 0 with -fn.
    # Some f_* images are intentionally pathological and send
    # upstream e2fsck into repair loops; 30 s is plenty for the
    # rest. Treat timeout as "too weird — skip".
    timeout -k 5 30 "$REAL_FSCK" -fn "$img" >/dev/null 2>&1
    expected_rc=$?
    if [ $expected_rc -eq 124 ]; then continue; fi
    timeout -k 5 30 "$ANVIL_FSCK" -fn "$img" >/dev/null 2>&1
    anvil_rc=$?

    if [ "$expected_rc" = 0 ] && [ "$anvil_rc" = 0 ]; then
        fsck_pass=$((fsck_pass+1))
    elif [ "$expected_rc" != 0 ] && [ "$anvil_rc" != 0 ]; then
        fsck_corrupt_pass=$((fsck_corrupt_pass+1))
    elif [ "$expected_rc" = 0 ] && [ "$anvil_rc" != 0 ]; then
        fsck_fail=$((fsck_fail+1))
        echo "  FALSE_POSITIVE: $name (real=clean, anvil=dirty)"
    else
        fsck_corrupt_fail=$((fsck_corrupt_fail+1))
        echo "  MISSED_CORRUPTION: $name (real=dirty, anvil=clean)"
    fi
done

echo
echo "=== Anvil vs upstream e2fsprogs test suite ==="
echo "mkfs:  $mkfs_pass clean,        $mkfs_fail fail"
echo "fsck clean-fs: $fsck_pass pass,  $fsck_fail false-positives"
echo "fsck corrupt-fs: $fsck_corrupt_pass caught, $fsck_corrupt_fail missed"
