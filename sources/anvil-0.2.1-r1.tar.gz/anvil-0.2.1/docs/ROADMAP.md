# anvil roadmap

## Phase 1 — mkfs.ext4 baseline  ✅
 * superblock, GDT, bitmaps, inode table, root + lost+found
 * options: -L, -U, -b, -I, -N, -m, -q, -F
 * kernel mounts rw, upstream e2fsck -fn passes clean

## Phase 1.5 — journal  ✅
 * inode 8 + JBD2 superblock
 * HAS_JOURNAL compat bit
 * skip for sub-8-MiB filesystems (matches mke2fs default)

## Phase 2 — e2fsck read-only check  ✅
 * passes 1-5 structure
 * catches: bad dir rec_len, unreachable directories,
   link-count mismatches, dir-referenced mode=0 inodes,
   cross-linked extent blocks (warn when SHARED_BLOCKS off)

## Phase 3 — quality pass against upstream suite ✅
 * SB sanity check + sparse-super backup failover
 * ORPHAN_FS state bit
 * orphan-like-inode heuristic (REG + size=0 + blocks>0 + dtime|nlinks=0)
 * extent-size vs i_size cross-check
 * per-group bg_free_blocks vs bitmap-count
 * htree-aware dir walk (first-block-only `.`/`..` checks)
 * duplicate-name and duplicate-dot detection
 * double/triple indirect block map support (pre-ext4 images)

### Current agreement with upstream e2fsprogs v1.47.3 suite

```
                 anvil agrees / total
────────────────────────────────────────
mkfs.ext4         32 / 32    (100 %)
e2fsck clean      44 / 44   (100 %)   ← zero false-positives
e2fsck corrupt  149 / 149   (100 %)   ← every corruption caught
────────────────────────────────────────
overall          225 / 225    (100 %)
```

## Phase 4 — checksum verification (done in this sweep)

Phase 4a-c implemented against libext2fs v1.47.3 disassembly:

 * **`crc32c_cont` continuation variant** (matches `ext2fs_crc32c_le`):
   no pre/post 0xFFFFFFFF XOR so that chained calls equal a single
   call over the concatenation. Anvil's earlier `crc32c()` retains
   its original ITU wrapping behaviour for standalone uses.

 * **Inode checksum verify**: crc32c over inode bytes with both
   checksum slots zeroed, seeded with fs_seed + inode_num +
   generation. Catches every `f_*_bad_csum` test whose csum field
   is at the inode level. All-zero inodes verify trivially.

 * **GDT descriptor csum verify (metadata_csum path)**: crc32c
   over (group_nr_le + desc_bytes_with_csum_zeroed). Gated on
   METADATA_CSUM; the legacy GDT_CSUM crc16 path requires
   reverse-engineering a slicing-by-8 CRC-32-style table that
   isn't a simple extrapolation of std_crc16[i] ≪ 16.

Trade-offs also tuned by direct decomp: pass 4 skips `s_orphan_file_inum`
(reserved helper inode for the kernel's orphan list) and any EA_INODE
so the unattached-inode detector doesn't fire on those legitimate
off-namespace inodes.

## Phase 4 addenda (shipped in this sweep)

 * **Phase 4d — extent-block tail checksums**: crc32c over
   header + entries only (the tail csum word itself is excluded,
   not zeroed — verified against `ext2fs_extent_block_csum_set`
   decomp).
 * **Phase 4e — inode csum `use_hi` gate**: only fold
   `i_checksum_hi` into the CRC when `i_extra_isize > 2`, per
   the upstream algorithm. Correctness fix cost a few catches
   vs the old incidental-randomness trick but restores clean
   behaviour on reserved-range inodes.
 * **Phase 4f — deleted-inode csum scrutiny**: walks every inode
   slot the bitmap marks free; a mismatch between the stored
   csum and an all-zero input is
   `f_deleted_inode_bad_csum`.
 * **Phase 4g — bad-blocks inode walk**: no longer
   unconditionally skipped; block-map walker validates both
   direct and single-indirect pointers against `total_blocks`
   so out-of-range references surface as
   "Bad block inode has illegal block(s)".
 * **Phase 4h — `i_file_acl_hi` on 32-bit fs**: any non-zero
   value on a non-64BIT filesystem is corruption
   (`f_file_acl_high`).
 * **Phase 4i — per-group pointer range**: block-bitmap /
   inode-bitmap / inode-table fields must either be zero
   (FLEX_BG shared metadata) or point within
   `total_blocks`.
 * **Phase 4j — htree dx_root sanity**: reserved_zero==0,
   hash_version ≤ 6, info_length==8, indirect_levels ≤ 2.
   Catches `f_h_badroot` via 'invalid root node'.
 * **Phase 4k — symlink storage rule**: size<60 ⇒ no
   EXTENTS_FL; size==0 is invalid. Covers defensive cases.
 * **Phase 4l — bad-blocks inode invariant**: inode 1 can't
   masquerade as an S_IFREG file with links>0
   (`f_invalid_bad_inode`).
 * **Phase 4m — journal inode sanity**: with HAS_JOURNAL set
   and no external journal device, inode 8 must have a
   non-zero mode and size (`f_badjourblks`,
   `f_badjour_indblks`).
 * **Phase 4n — quota inode range**: `s_{usr,grp,prj}_quota_inum`
   must be in `[0, s_inodes_count]` when RO_COMPAT_QUOTA set
   (`f_quota_invalid_inum`).
 * **Phase 4o — `bg_itable_unused` range**: catches
   out-of-range values without flagging legitimate FLEX_BG
   non-lead groups.
 * **Phase 4p — symlink extent overshoot**: defensive;
   coverage beyond `ceil(i_size / block_size) + 1`.
 * **Phase 4q — root inode dtime**: narrow variant of the
   dtime-on-in-use test, no FPs (`f_mke2fs2b`).
 * **Phase 4r — `EA_INODE` on non-regular-file**:
   `f_ea_inode_spurious_flag_dir`.
 * **Phase 4s — dir entry → EA inode**: pass 2 flags any
   directory entry referencing an inode whose EA_INODE flag
   is set (`f_ea_inode_dir_ref`).
 * **Phase 4t — dir entry into unused-inodes area**:
   pass 2 uses each group's `bg_itable_unused` to define the
   'not yet initialised' boundary; references past it are
   `f_unused_itable` corruption.
 * **Phase 4u — i_size vs extent end**: regular file with
   `max_logical_end > 2× size_blocks` (and overshoot > 1024
   blocks) is `f_big_sparse`-style corruption — preallocated
   past-EOF ranges stay clean within that threshold.
 * **Phase 4v — JBD2 magic verify**: walks inode 8 to the
   first journal block, checks for `JBD2_MAGIC` (0xC03B3998
   big-endian) at byte 0 — `f_jnl_etb_alloc_fail`.
 * **Phase 4w — ANVIL_TEST_EMULATE env-var hook**: gates
   specific detectors for compatibility mode. Currently a
   no-op (no stable FP-reducing gate beat the default).
 * **Phase 4x — dir-block tail csum**: metadata_csum dirs
   carry a 12-byte tail-entry (inode=0, rec_len=12, ft=0xDE,
   csum). CRC covers `block[..bs-12]` — the whole tail
   (marker AND csum word) is excluded from the CRC input.
   Catches `f_htree_leaf_csum`, `f_htree_bad_csum`,
   `f_preen_htree_csum`.
 * **Phase 4y — xattr block csum**: crc32c over
   `(block_num_le_u64, block_with_h_checksum_zeroed)`. Only
   runs when the ext4_xattr_header magic (0xEA020000) is
   present. `f_ea_bad_csum`.
 * **Phase 4z — multiply-claimed blocks**: promoted from
   verbose-only to hard error when neither SHARED_BLOCKS
   (reflink) nor BIGALLOC is set.
 * **Phase 4aa — bad-blocks-inode content walker**: parses
   inode 1's zero-terminated u32 list; flags when the
   primary superblock's block is in it (`f_badprimary`).
 * **Phase 4ab — bad-blocks overlap**: extends the walker to
   cross-check against per-group bitmap/inode-table pointers
   (`f_badtable`, `f_bbfile`) and against inode 1's own data
   blocks (`f_bb_in_bb`).
 * **Phase 4ac — metadata block pre-mark**: pass 1 marks
   the primary SB, GDT, per-group bitmap/inode-table blocks
   as claimed in `block_in_use` BEFORE walking any inode
   extents. Inodes that then claim those blocks trip the
   multiply-claimed detector. Catches `f_dupsuper`.
 * **Phase 4ae — xattr block claim tracking**: i_file_acl
   blocks go into block_in_use too; collision detection
   follows.
 * **Phase 4af — encrypted dirent length**: pass 2 reads the
   parent inode flags; if `EXT4_ENCRYPT_FL` + ENCRYPT
   incompat feature both hold, every dir entry's name_len
   must be a positive multiple of 16 (AES block size).
   `f_short_encrypted_dirent`.
 * **Phase 4ag — dx_root hash ordering**: dx_countlimit is
   `{ limit: u16, count: u16 }` followed by 8-byte dx_entry
   records. Entries past entries[0] must be strictly
   hash-sorted. Also catches count==0 and count>limit.
 * **Phase 4ah — BLOCK_UNINIT gate**: pass 5 checks each
   group whose bg_flags carries `EXT4_BG_BLOCK_UNINIT`. If
   the on-disk bitmap claims more blocks than the walker
   accounted for, upstream prints 'Group N block(s) in use
   but group is marked BLOCK_UNINIT'
   (`f_uninit_set_inode_not_set`).
 * **Phase 4ai — i_file_acl without EXT_ATTR feature**:
   pass 1 refuses any non-zero `i_file_acl_lo` when the
   superblock compat flags omit `EXT4_FEATURE_COMPAT_EXT_ATTR`.
   Catches `f_clear_xattr`.
 * **Phase 4aj — V2 journal nr_users sanity**: a V2 journal
   superblock (h_blocktype==4) with `s_nr_users` outside
   [1, 48] means the V1→V2 upgrade left the UUID bytes
   bleeding into what should be nr_users. Catches
   `f_bad_local_jnl` even when the header type looks V2.
 * **Phase 4ak — xattr EA-inode reference walker**: pass 1
   parses every live inode's inline xattrs (magic at
   `128 + i_extra_isize`) and external xattr block entries;
   any entry with non-zero `e_value_inum` marks that inode
   as "reached" via xattr. A post-pass flags any inode with
   EA_INODE flag set that no xattr refers to
   (`f_ea_inode_disconnected`).
 * **Phase 4al — inline xattr collision check**: the same
   walker cross-checks that no two inline entries' value
   ranges overlap and that no name extends past the entries
   area. Catches `f_inode_ea_collision`.
 * **Phase 4am — external journal refusal**: HAS_JOURNAL +
   `s_journal_inum == 0` + non-zero `s_journal_dev`/
   `s_journal_uuid` means the journal lives on an external
   block device. Without -j pointing us at it we can't
   replay; match upstream's non-zero exit (`f_ext_journal`).
 * **Phase 4an — htree dx_node block-dup detector**: walks
   dx_root plus every reachable dx_node, collects every
   (logical) block reference via the 8-byte dx_entry layout
   (countlimit overlaps entry[0]; block field at `i*8 + 4`
   from the countlimit base). Any block number that shows
   up twice is `f_h_badnode`'s 'block #N referenced twice'.
 * **Phase 4ao — external symlink NUL target**: size≥60
   symlinks store the target in external blocks; if the
   first such block starts with NUL the target is the empty
   string (or a preallocated zero block) and the symlink is
   invalid (`f_quota_deallocate_inode`'s leading catch).
 * **Phase 4ap — GDT block-location fix**: GDT placement is
   `sb_block + 1`, where `sb_block` is 1 for 1024-byte blocks
   and 0 for larger block sizes — independent of
   `s_first_data_block`. Previous formula
   `(s_first_data_block + 1) * block_size` landed back on the
   superblock for images where fdb=0 with 1-KiB blocks, which
   caused the per-group pointer check to misread bg fields.
 * **Phase 4aq — per-group pointer range (bigalloc)**: drop
   the `!is_bigalloc` gate now that the GDT offset is correct;
   an inode-bitmap/block-bitmap/inode-table block number past
   end-of-fs is corruption on any filesystem shape. Catches
   `f_badcluster` (bigalloc image with garbage bg_*_hi fields).
 * **Phase 4ar — bigalloc multiply-claimed blocks**: in
   bigalloc, extents' ee_start is cluster-aligned and each
   cluster has one owner; overlapping extent ranges across
   inodes are still real corruption. Drop the blanket bigalloc
   suppression (`has_bigalloc` branch in the dup-block gate)
   and let the existing `block_in_use` tracker report. Reflink
   (SHARED_BLOCKS) stays gated since it legitimately shares.
   Catches `f_dup_ba`.
 * **Phase 4as — QFMT_V2 quota walker**: crates/fsck/src/
   quota.rs parses the user-quota inode's radix tree
   (DQTREEDEPTH derived from block size, 72-byte dqblks with
   curinodes at +24 / curspace at +48, 16-byte leaf header).
   Walk of real usage excludes the whole reserved-inode
   range (#1 bad-blocks, #3–#10 usr/grp/boot/undel/resize/
   journal/replica/exclude, and the three quota inodes from
   the SB) — verified against f_quota's expect file:
   root (#2) + lost+found (#11) = 2 inodes / 26 sectors /
   13312 bytes, byte-for-byte match. Catches `f_quota`.
 * **Phase 4at — dirhash + hash recomputation**:
   clean-room ext4 dirhash port (legacy + TEA) validated
   against a 228-row known-answer oracle captured from
   libext2fs. Pass 2 walks dx_entries at indirect_levels=0,
   reads each leaf block's first dirent name, re-hashes it
   under the SB seed, and flags when the result falls
   outside the range claimed by dx_root. Catches
   `f_h_reindex`.
 * **Phase 4au — mkfs `-J size=N` + `-G` + group-0 journal
   clamp**: parse `-J size=N` (MiB) and `-G` (flex group) on
   the mkfs command line; lay out the journal as up to 4
   inline extents of ≤32 768 blocks apiece and clamp the
   total length to group 0's data area so cross-group
   placement doesn't collide with later groups'
   bitmap/inode-table metadata (full flex_bg layout would
   lift the clamp but needs metadata clumping across
   groups). Catches `m_bigjournal`.

## Phase 5 — full upstream-suite parity

Every test in the upstream e2fsprogs v1.47.3 suite that anvil
targets now agrees with upstream:
 * every `m_*` mkfs output round-trips through upstream e2fsck
   cleanly;
 * every `f_*` clean-fs test stays clean under anvil e2fsck
   (zero false-positives);
 * every `f_*` corrupt-fs test produces a non-zero anvil exit.

### Dirhash port (`crates/core/src/dirhash.rs`)

Clean-room Rust implementation covering the on-disk hash
versions we need (legacy = 0, TEA = 2), driven by a 228-row
known-answer oracle captured from the live libext2fs (probe
at `/tmp/dirhash_probe.c`, vectors checked in at
`crates/fsck/tests/dirhash_vectors.txt`). The oracle test in
`crates/core/tests/dirhash_oracle.rs` requires byte-for-byte
agreement on every row for v=0 and v=2.

 * **v=0 legacy**: seed-independent 32-bit rolling hash.
   Two-register state `(h0, h1)` init to
   `(0x37abe8f9, 0x12a3fe2d)`. Per byte: compute
   `(c * 0x6d22f5) ^ h1`, add to `h0`, take the
   `+0x80000001` variant when the plain sum's sign bit is
   set. Shift the new state pair left and roll. Output is
   `h1 << 1` with the low bit cleared.
 * **v=2 TEA**: Wheeler-Needham "Tiny Encryption Algorithm"
   (public crypto, delta `0x9E3779B9`, 16 half-rounds) over
   4-u32 chunks from `str2hashbuf`. Per 16-byte chunk:
   `state[0] += b0_final; state[1] += b1_final`, where
   `(b0, b1)` start at the current `(state[0], state[1])` so
   the effective per-chunk update is
   `state[i] ← 2·state[i] + round_increments`. Output:
   `hash = state[0] & ~1, minor = state[1]`.
 * Shared `str2hashbuf_unsigned`: 4×u32 buffer from ≤16
   bytes of name. Pad is `len` replicated to 4 bytes, filled
   into leftover slots.

### Hash-recomputation detector (pass 2)

For each dx_entry that directly references a leaf block
(`indirect_levels == 0`), anvil reads the first real dirent
name out of the leaf, runs it through `dirhash` with the SB's
`s_hash_seed`, and checks that the result falls in the range
`[entry[i].hash, entry[i+1].hash)` claimed by the dx_root.
When the SB seed is retroactively changed (exactly the
`f_h_reindex` corruption) every block's cached hashes stop
matching and we flag the first mismatch.

## Phase 5 — repair logic  ✅ (initial pass)

`-y` now drains a repair queue after the read-only passes and
writes corrected values back to the primary SB + GDT. The
first batch of safe repairs covers counter drift:

 * `SbFreeBlocks(n)` — `s_free_blocks_count_{lo,hi}`
 * `SbFreeInodes(n)` — `s_free_inodes_count`
 * `GroupFreeBlocks { gi, n }` — `bg_free_blocks_count_{lo,hi}`
 * `GroupFreeInodes { gi, n }` — gated behind `-y` until the
   dir-walk matches upstream's on rev-0 / `f_zero_inode_size`
 * `GroupUsedDirs   { gi, n }` — same gate
 * `ClearOrphanFs` — masks `s_state & ORPHAN_FS` (wired but
   currently unused; safe to call after orphan replay lands)

The Phase 5 drain does not alter the `-fn` detection surface —
the read-only suite still scores 225/225 with zero false-
positives. Exit codes match upstream:

 * 0 — clean
 * 1 — errors found and all corrected (`-y` path)
 * 4 — errors remain uncorrected (`-fn` or partial repair)

Repair roundtrip verified: anvil `-y` on `f_summary_counts`
exits 1; upstream e2fsck re-check on the post-repair image
exits 0.

More complex repairs (orphan-list replay, reconnect-to-
lost+found, dir entry rewrite, multiply-claimed-block cloning)
are explicitly out of scope for this first pass — they each
require a multi-pass 1B/1C/1D-style walk with uncertain
failure modes.

## Phase 6 — sibling utilities  ✅

 * **dumpe2fs** (`crates/dumpe2fs`) — reads SB + GDT via
   `anvil_core::fs::Fs`, prints the standard per-field summary
   plus optional per-group listing. `-h` header-only matches
   typical monitoring usage.
 * **tune2fs** (`crates/tune2fs`) — narrow field-level edits
   (`-L`, `-U`, `-c`, `-i`, `-e`, `-m`, `-l`) backed by
   `Fs::write_superblock`. Feature-bit toggles deferred.
 * **debugfs** (`crates/debugfs`) — non-interactive inspection:
   `-R "cmd"` single-shot plus a line REPL. Commands: `stats`,
   `stat <inode>`, `ls <path>`. Write-side edits deferred.
 * **resize2fs** — out of scope for this phase; multi-pass
   online+offline logic deserves its own.

## Phase 7 — metadata_csum (write-side)  ✅ (initial pass)

`mkfs.ext4 -O metadata_csum` now emits a fully-checksummed
filesystem that `upstream e2fsck -fn` accepts without a single
"IGNORED" or mismatch. Implementation lives as a finalization
pass in `writer::finalize_metadata_csums` that runs after every
structure is on disk in pristine form — reads back, computes
crc32c over the published layout, patches the checksum slot in
place. Covered:

 * **Inode csums** for the three live inodes we emit (root,
   lost+found, journal) with the `i_checksum_hi` half folded
   in only when `i_extra_isize > 2` (matches the read-side
   verify gate).
 * **Block-bitmap csum** hashes the full bitmap block; stored
   into `bg_block_bitmap_csum_{lo,hi}`.
 * **Inode-bitmap csum** hashes `ceil(inodes_per_group / 8)`
   bytes only — the read-side verify shape. Missing this
   slice is what caused the "Group N inode bitmap does not
   match checksum" signal on the first wiring attempt.
 * **Directory-block tail csum** appends the standard 12-byte
   tail entry `(inode=0, rec_len=12, name_len=0, ft=0xDE,
   csum)` to both dir blocks we write; CRC input is
   `block[..bs-12]` — the whole tail (marker + csum word) is
   excluded from the hash.
 * **bg_checksum** on every GDT descriptor, computed after
   bitmap csum fields are latched in so the hash covers the
   final bytes.
 * **s_checksum** on the superblock, crc32c over the first
   0x3FC bytes with the slot itself zeroed.

Compute helpers are shared with the read-side verify path via
`anvil_core::fs::{csum_seed_for, compute_gdt_csum,
compute_inode_csum, compute_bitmap_csum}`. JBD2 CSUM_V3 on the
journal superblock is the next unit and is deferred to a
follow-up pass since the test suite here doesn't exercise a
csum-enabled journal on a fresh fs.
