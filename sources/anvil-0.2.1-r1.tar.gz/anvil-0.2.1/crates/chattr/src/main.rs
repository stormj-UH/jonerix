//! chattr — toggle i_flags bits on an inode inside an
//! ext4 image. Offline counterpart to `/usr/bin/chattr`,
//! useful for rootfs plumbing and debugging.
//!
//! Usage:
//!   chattr +<letters> <image> <path>
//!   chattr -<letters> <image> <path>
//!   chattr =<letters> <image> <path>
//!   chattr -l <image> <path>
//!   chattr -V
//!
//! Exit codes:
//!   0   success
//!   8   operational error
//!   16  usage error

use std::path::PathBuf;
use std::process::ExitCode;

use anvil_core::consts::{EXT4_ROOT_INO, S_IFDIR, S_IFMT};
use anvil_core::extent::walk_extents;
use anvil_core::fs::{compute_inode_csum, Fs};

const VERSION_LINE: &str = "anvil-chattr 1.47.3-anvil (MIT)";

// Upstream chattr-compatible flag letter subset. Kernel-managed
// "internal" bits (0xFF000000) are preserved across an `=` set.
const FLAG_MAP: &[(char, u32)] = &[
    ('i', 0x0000_0010), // EXT4_IMMUTABLE_FL
    ('a', 0x0000_0020), // EXT4_APPEND_FL
    ('s', 0x0000_0001), // EXT4_SECRM_FL
    ('u', 0x0000_0002), // EXT4_UNRM_FL
    ('S', 0x0000_0008), // EXT4_SYNC_FL
    ('A', 0x0000_0080), // EXT4_NOATIME_FL
    ('d', 0x0000_0040), // EXT4_NODUMP_FL
    ('j', 0x0000_4000), // EXT4_JOURNAL_DATA_FL
    ('t', 0x0000_8000), // EXT4_NOTAIL_FL
];

const HIGH_INTERNAL_MASK: u32 = 0xFF00_0000;

enum Op {
    Add(u32, String),
    Remove(u32, String),
    Set(u32, String),
    List,
}

fn parse_letters(s: &str) -> Result<u32, String> {
    let mut mask = 0u32;
    for c in s.chars() {
        match FLAG_MAP.iter().find(|(l, _)| *l == c) {
            Some((_, bit)) => mask |= *bit,
            None => return Err(format!("unknown flag letter: {c}")),
        }
    }
    Ok(mask)
}

fn bits_to_letters(flags: u32) -> String {
    // `-l` prints nothing at all when no known bits are set.
    // Letters are emitted in ASCII-sorted order so the output
    // is stable regardless of FLAG_MAP declaration order.
    let mut letters: Vec<char> = FLAG_MAP
        .iter()
        .filter_map(|(l, b)| if flags & *b != 0 { Some(*l) } else { None })
        .collect();
    letters.sort();
    let mut out = String::new();
    for c in letters {
        if !out.is_empty() {
            out.push(' ');
        }
        out.push(c);
    }
    out
}

fn main() -> ExitCode {
    let args: Vec<String> = std::env::args().skip(1).collect();
    if args.is_empty() {
        eprintln!("usage: chattr {{+|-|=}}<letters> <image> <path>");
        eprintln!("       chattr -l <image> <path>");
        eprintln!("       chattr -V");
        return ExitCode::from(16);
    }
    if args[0] == "-V" {
        println!("{VERSION_LINE}");
        return ExitCode::from(0);
    }

    let (op, image, inside) = match parse_args(&args) {
        Ok(v) => v,
        Err(e) => {
            eprintln!("chattr: {e}");
            return ExitCode::from(16);
        }
    };

    let mut fs = match Fs::open(&image) {
        Ok(fs) => fs,
        Err(e) => {
            eprintln!("chattr: open {}: {}", image.display(), e);
            return ExitCode::from(8);
        }
    };

    let ino_num = match resolve_path(&mut fs, &inside) {
        Ok(n) => n,
        Err(e) => {
            eprintln!("chattr: {inside}: {e}");
            return ExitCode::from(8);
        }
    };

    match op {
        Op::List => match read_flags(&mut fs, ino_num) {
            Ok(flags) => {
                let letters = bits_to_letters(flags);
                if !letters.is_empty() {
                    println!("{letters}");
                }
                ExitCode::from(0)
            }
            Err(e) => {
                eprintln!("chattr: read inode {ino_num}: {e}");
                ExitCode::from(8)
            }
        },
        Op::Add(mask, letters) => {
            apply(&mut fs, ino_num, &inside, '+', &letters, |old| old | mask)
        }
        Op::Remove(mask, letters) => {
            apply(&mut fs, ino_num, &inside, '-', &letters, |old| old & !mask)
        }
        Op::Set(mask, letters) => apply(&mut fs, ino_num, &inside, '=', &letters, |old| {
            (old & HIGH_INTERNAL_MASK) | (mask & !HIGH_INTERNAL_MASK)
        }),
    }
}

fn parse_args(args: &[String]) -> Result<(Op, PathBuf, String), String> {
    let first = &args[0];
    if first == "-l" {
        if args.len() != 3 {
            return Err("usage: chattr -l <image> <path>".into());
        }
        return Ok((Op::List, PathBuf::from(&args[1]), args[2].clone()));
    }
    if args.len() != 3 {
        return Err("usage: chattr {+|-|=}<letters> <image> <path>".into());
    }
    let (sign, letters_str) = match first.chars().next() {
        Some(c) if c == '+' || c == '-' || c == '=' => (c, &first[1..]),
        _ => return Err(format!("operator must start with + - or = (got {first})")),
    };
    if letters_str.is_empty() {
        return Err("no flag letters given".into());
    }
    let mask = parse_letters(letters_str)?;
    let image = PathBuf::from(&args[1]);
    let path = args[2].clone();
    let op = match sign {
        '+' => Op::Add(mask, letters_str.to_string()),
        '-' => Op::Remove(mask, letters_str.to_string()),
        '=' => Op::Set(mask, letters_str.to_string()),
        _ => unreachable!(),
    };
    Ok((op, image, path))
}

fn apply(
    fs: &mut Fs,
    ino_num: u32,
    inside: &str,
    sign: char,
    letters: &str,
    compute_new: impl FnOnce(u32) -> u32,
) -> ExitCode {
    let byte = match inode_byte_offset(fs, ino_num) {
        Ok(b) => b,
        Err(e) => {
            eprintln!("chattr: {e}");
            return ExitCode::from(8);
        }
    };
    let inode_size = fs.inode_size as usize;
    let mut buf = vec![0u8; inode_size];
    if let Err(e) = fs.dev.read_at(byte, &mut buf) {
        eprintln!("chattr: read inode {ino_num}: {e}");
        return ExitCode::from(8);
    }
    let old_flags = u32::from_le_bytes(buf[0x20..0x24].try_into().unwrap());
    let new_flags = compute_new(old_flags);
    buf[0x20..0x24].copy_from_slice(&new_flags.to_le_bytes());

    if fs.has_metadata_csum() {
        let generation = u32::from_le_bytes(buf[0x64..0x68].try_into().unwrap());
        let extra_isize = if buf.len() >= 0x82 {
            u16::from_le_bytes(buf[0x80..0x82].try_into().unwrap())
        } else {
            0
        };
        if buf.len() >= 0x7E {
            buf[0x7C..0x7E].copy_from_slice(&0u16.to_le_bytes());
        }
        let has_hi = extra_isize >= 4 && buf.len() >= 0x84;
        if has_hi {
            buf[0x82..0x84].copy_from_slice(&0u16.to_le_bytes());
        }
        let csum = compute_inode_csum(&fs.sb, ino_num, generation, &buf);
        if buf.len() >= 0x7E {
            buf[0x7C..0x7E].copy_from_slice(&(csum as u16).to_le_bytes());
        }
        if has_hi {
            buf[0x82..0x84].copy_from_slice(&((csum >> 16) as u16).to_le_bytes());
        }
    }

    if let Err(e) = fs.dev.write_at(byte, &buf) {
        eprintln!("chattr: write inode {ino_num}: {e}");
        return ExitCode::from(8);
    }

    println!("chattr: {sign}{letters} {inside} (0x{old_flags:08X} -> 0x{new_flags:08X})");
    ExitCode::from(0)
}

fn inode_byte_offset(fs: &Fs, ino: u32) -> std::io::Result<u64> {
    if ino == 0 || ino as u64 > fs.sb.s_inodes_count as u64 {
        return Err(std::io::Error::new(
            std::io::ErrorKind::InvalidInput,
            "inode out of range",
        ));
    }
    let group = (ino as u64 - 1) / fs.inodes_per_group;
    let idx = (ino as u64 - 1) % fs.inodes_per_group;
    let table = fs.group_inode_table(group);
    Ok(table * fs.block_size + idx * fs.inode_size)
}

fn read_flags(fs: &mut Fs, ino_num: u32) -> std::io::Result<u32> {
    let ino = fs.read_inode(ino_num)?;
    Ok(ino.i_flags)
}

// --- path resolution (same walk pattern as filefrag) ---

fn resolve_path(fs: &mut Fs, path: &str) -> std::io::Result<u32> {
    let clean = path.trim();
    if clean.is_empty() || clean == "/" {
        return Ok(EXT4_ROOT_INO);
    }
    let mut cur = EXT4_ROOT_INO;
    for comp in clean.split('/').filter(|s| !s.is_empty()) {
        cur = lookup_in_dir(fs, cur, comp.as_bytes())?;
    }
    Ok(cur)
}

fn lookup_in_dir(fs: &mut Fs, dir_ino: u32, name: &[u8]) -> std::io::Result<u32> {
    let inode = fs.read_inode(dir_ino)?;
    if inode.i_mode & S_IFMT != S_IFDIR {
        return Err(std::io::Error::new(
            std::io::ErrorKind::NotFound,
            "not a directory",
        ));
    }
    let mut blocks: Vec<u64> = Vec::new();
    walk_extents(fs, &inode, |r| {
        for off in 0..r.length as u64 {
            blocks.push(r.physical + off);
        }
    })?;

    let bs = fs.block_size as usize;
    for blk in blocks {
        let mut buf = vec![0u8; bs];
        fs.read_block(blk, &mut buf)?;
        let mut off = 0usize;
        while off + 8 <= buf.len() {
            let entry_ino = u32::from_le_bytes([
                buf[off], buf[off + 1], buf[off + 2], buf[off + 3],
            ]);
            let rec_len = u16::from_le_bytes([buf[off + 4], buf[off + 5]]) as usize;
            let name_len = buf[off + 6] as usize;
            if rec_len < 8 || off + rec_len > bs {
                break;
            }
            if entry_ino != 0 && off + 8 + name_len <= buf.len() {
                let entry_name = &buf[off + 8..off + 8 + name_len];
                if entry_name == name {
                    return Ok(entry_ino);
                }
            }
            off += rec_len;
        }
    }
    Err(std::io::Error::new(
        std::io::ErrorKind::NotFound,
        format!("no such entry: {}", String::from_utf8_lossy(name)),
    ))
}
