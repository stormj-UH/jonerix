//! blkid — identify filesystem UUID / LABEL / TYPE on an image
//! or block device. Narrowly scoped to ext2/ext3/ext4: we read
//! the 1024-byte superblock at byte offset 1024, verify the
//! magic (0xEF53) at offset 0x38, then pick the fs type from
//! feature bits.
//!
//! Flags:
//!   <device>                       one-line pretty output
//!   -o value -s UUID  <device>     bare UUID value
//!   -o value -s LABEL <device>     bare label value
//!   -V                             version
//!
//! Exit codes:
//!   0   recognised filesystem, printed
//!   2   unrecognised filesystem (prints "<path>: unrecognized filesystem")
//!   8   I/O or open error
//!   16  usage error

use std::fs::File;
use std::io::{Read, Seek, SeekFrom};
use std::path::Path;
use std::process::ExitCode;

const VERSION_LINE: &str = "anvil-blkid 1.47.3-anvil (MIT)";

// Superblock offsets (relative to the 1024-byte SB record, which itself
// lives at byte 1024 of the device).
const SB_OFF: u64 = 1024;
const SB_LEN: usize = 1024;

const OFF_MAGIC: usize          = 0x38;  // u16
const OFF_FEAT_COMPAT: usize    = 0x5c;  // u32
const OFF_FEAT_INCOMPAT: usize  = 0x60;  // u32
// s_uuid at byte 104 of the SB, s_volume_name at byte 120.
const OFF_UUID: usize           = 0x68;  // 16 bytes
const OFF_LABEL: usize          = 0x78;  // 16 bytes

const EXT_MAGIC: u16            = 0xEF53;
const FEATURE_COMPAT_HAS_JOURNAL: u32   = 0x0004;
const FEATURE_INCOMPAT_EXTENTS:   u32   = 0x0040;
const FEATURE_INCOMPAT_64BIT:     u32   = 0x0080;

#[derive(Clone, Copy)]
enum Field {
    Uuid,
    Label,
}

fn main() -> ExitCode {
    let args: Vec<String> = std::env::args().skip(1).collect();

    // -V
    if args.iter().any(|a| a == "-V") {
        println!("{VERSION_LINE}");
        return ExitCode::from(0);
    }

    // Compact flag parsing: support the exact shapes the task spec
    // requires. We accept "-o value" and "-s FIELD" in any order,
    // plus a single positional device argument.
    let mut output_value_only = false;
    let mut field: Option<Field> = None;
    let mut positional: Vec<String> = Vec::new();
    let mut i = 0;
    while i < args.len() {
        let a = &args[i];
        match a.as_str() {
            "-o" => {
                let Some(v) = args.get(i + 1) else {
                    eprintln!("blkid: -o requires an argument");
                    return ExitCode::from(16);
                };
                if v != "value" {
                    eprintln!("blkid: only -o value is supported, got -o {v}");
                    return ExitCode::from(16);
                }
                output_value_only = true;
                i += 2;
            }
            "-s" => {
                let Some(v) = args.get(i + 1) else {
                    eprintln!("blkid: -s requires an argument");
                    return ExitCode::from(16);
                };
                field = Some(match v.as_str() {
                    "UUID" => Field::Uuid,
                    "LABEL" => Field::Label,
                    other => {
                        eprintln!("blkid: unsupported -s field: {other}");
                        return ExitCode::from(16);
                    }
                });
                i += 2;
            }
            s if s.starts_with('-') => {
                eprintln!("blkid: unknown option {s}");
                return ExitCode::from(16);
            }
            _ => {
                positional.push(a.clone());
                i += 1;
            }
        }
    }

    if positional.len() != 1 {
        eprintln!("usage: blkid <device>");
        eprintln!("       blkid -o value -s UUID|LABEL <device>");
        eprintln!("       blkid -V");
        return ExitCode::from(16);
    }
    let device = positional.into_iter().next().unwrap();

    let sb = match read_sb(Path::new(&device)) {
        Ok(b) => b,
        Err(e) => {
            eprintln!("blkid: {}: {}", device, e);
            return ExitCode::from(8);
        }
    };

    let magic = u16::from_le_bytes([sb[OFF_MAGIC], sb[OFF_MAGIC + 1]]);
    if magic != EXT_MAGIC {
        println!("{}: unrecognized filesystem", device);
        return ExitCode::from(2);
    }

    let feat_compat = read_u32_le(&sb, OFF_FEAT_COMPAT);
    let feat_incompat = read_u32_le(&sb, OFF_FEAT_INCOMPAT);
    let uuid_bytes: [u8; 16] = sb[OFF_UUID..OFF_UUID + 16].try_into().unwrap();
    let label_bytes = &sb[OFF_LABEL..OFF_LABEL + 16];
    let uuid = format_uuid(&uuid_bytes);
    let label = decode_label(label_bytes);
    let fs_type = pick_fs_type(feat_compat, feat_incompat);

    if output_value_only {
        match field {
            Some(Field::Uuid) => println!("{}", uuid),
            Some(Field::Label) => println!("{}", label),
            None => {
                eprintln!("blkid: -o value requires -s UUID or -s LABEL");
                return ExitCode::from(16);
            }
        }
    } else {
        println!(
            "{}: UUID=\"{}\" LABEL=\"{}\" TYPE=\"{}\"",
            device, uuid, label, fs_type,
        );
    }
    ExitCode::from(0)
}

fn read_sb(path: &Path) -> std::io::Result<[u8; SB_LEN]> {
    let mut f = File::open(path)?;
    f.seek(SeekFrom::Start(SB_OFF))?;
    let mut buf = [0u8; SB_LEN];
    f.read_exact(&mut buf)?;
    Ok(buf)
}

fn read_u32_le(sb: &[u8; SB_LEN], off: usize) -> u32 {
    u32::from_le_bytes([sb[off], sb[off + 1], sb[off + 2], sb[off + 3]])
}

fn pick_fs_type(compat: u32, incompat: u32) -> &'static str {
    let has_journal = compat & FEATURE_COMPAT_HAS_JOURNAL != 0;
    let has_extents = incompat & FEATURE_INCOMPAT_EXTENTS != 0;
    let has_64bit   = incompat & FEATURE_INCOMPAT_64BIT != 0;
    if has_extents || has_64bit {
        "ext4"
    } else if has_journal {
        "ext3"
    } else {
        "ext2"
    }
}

fn format_uuid(b: &[u8; 16]) -> String {
    format!(
        "{:02x}{:02x}{:02x}{:02x}-{:02x}{:02x}-{:02x}{:02x}-{:02x}{:02x}-{:02x}{:02x}{:02x}{:02x}{:02x}{:02x}",
        b[0], b[1], b[2], b[3],
        b[4], b[5],
        b[6], b[7],
        b[8], b[9],
        b[10], b[11], b[12], b[13], b[14], b[15],
    )
}

fn decode_label(raw: &[u8]) -> String {
    // Drop trailing NULs then render as lossy UTF-8. ext label is
    // conventionally ASCII but the field is raw bytes.
    let end = raw.iter().position(|&c| c == 0).unwrap_or(raw.len());
    String::from_utf8_lossy(&raw[..end]).into_owned()
}
