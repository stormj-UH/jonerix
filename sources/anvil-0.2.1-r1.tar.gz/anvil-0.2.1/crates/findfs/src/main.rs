//! findfs — resolve a UUID=<uuid> or LABEL=<label> selector to a
//! device path by scanning a directory (defaulting to /dev) and
//! reading each entry's ext-family superblock.
//!
//! Flags:
//!   findfs UUID=<uuid>           print first device whose fs has this UUID
//!   findfs LABEL=<label>         print first device with this label
//!   findfs -d <dir> <selector>   scan <dir> instead of /dev
//!   findfs -V                    version
//!
//! Exit codes:
//!   0   match found, path printed on stdout
//!   1   no match
//!   8   scan dir unreadable / arg parse error

use std::ffi::OsString;
use std::fs::{self, File};
use std::io::{Read, Seek, SeekFrom};
use std::path::{Path, PathBuf};
use std::process::ExitCode;

const VERSION_LINE: &str = "anvil-findfs 1.47.3-anvil (MIT)";

const SB_OFF: u64 = 1024;
const SB_LEN: usize = 1024;
const OFF_MAGIC: usize = 0x38;
const OFF_UUID: usize  = 0x68;
const OFF_LABEL: usize = 0x78;
const EXT_MAGIC: u16   = 0xEF53;

enum Selector {
    Uuid(String),
    Label(String),
}

fn main() -> ExitCode {
    let args: Vec<OsString> = std::env::args_os().skip(1).collect();

    // -V short-circuit (any position).
    for a in &args {
        if a == "-V" {
            println!("{VERSION_LINE}");
            return ExitCode::from(0);
        }
    }

    let mut dir: PathBuf = PathBuf::from("/dev");
    let mut positional: Vec<OsString> = Vec::new();
    let mut i = 0;
    while i < args.len() {
        let a = &args[i];
        if a == "-d" {
            let Some(v) = args.get(i + 1) else {
                eprintln!("findfs: -d requires a directory argument");
                return ExitCode::from(8);
            };
            dir = PathBuf::from(v);
            i += 2;
        } else {
            positional.push(a.clone());
            i += 1;
        }
    }

    if positional.len() != 1 {
        eprintln!("usage: findfs [-d <dir>] UUID=<uuid> | LABEL=<label>");
        eprintln!("       findfs -V");
        return ExitCode::from(8);
    }

    let sel_str = match positional[0].clone().into_string() {
        Ok(s) => s,
        Err(_) => {
            eprintln!("findfs: selector must be UTF-8");
            return ExitCode::from(8);
        }
    };

    let selector = if let Some(rest) = sel_str.strip_prefix("UUID=") {
        // Normalise UUID to lowercase for case-insensitive compare.
        Selector::Uuid(rest.to_ascii_lowercase())
    } else if let Some(rest) = sel_str.strip_prefix("LABEL=") {
        Selector::Label(rest.to_string())
    } else {
        eprintln!("findfs: selector must start with UUID= or LABEL=");
        return ExitCode::from(8);
    };

    let entries = match fs::read_dir(&dir) {
        Ok(it) => it,
        Err(e) => {
            eprintln!("findfs: cannot read {}: {}", dir.display(), e);
            return ExitCode::from(8);
        }
    };

    // Collect, sort for deterministic "first match" ordering — readdir
    // order is filesystem-dependent and we want reproducible results.
    let mut paths: Vec<PathBuf> = Vec::new();
    for ent in entries {
        let Ok(ent) = ent else { continue };
        let Ok(md) = ent.metadata() else { continue };
        let ft = md.file_type();
        // Regular file (image) or block device. We deliberately skip
        // symlinks, dirs, char devices, fifos, sockets.
        let is_block = {
            #[cfg(unix)]
            { std::os::unix::fs::FileTypeExt::is_block_device(&ft) }
            #[cfg(not(unix))]
            { false }
        };
        if !(ft.is_file() || is_block) {
            continue;
        }
        paths.push(ent.path());
    }
    paths.sort();

    for p in &paths {
        let Ok(sb) = read_sb(p) else { continue };
        let magic = u16::from_le_bytes([sb[OFF_MAGIC], sb[OFF_MAGIC + 1]]);
        if magic != EXT_MAGIC {
            continue;
        }
        match &selector {
            Selector::Uuid(want) => {
                let uuid_bytes: [u8; 16] = sb[OFF_UUID..OFF_UUID + 16].try_into().unwrap();
                let got = format_uuid(&uuid_bytes);
                if got == *want {
                    println!("{}", p.display());
                    return ExitCode::from(0);
                }
            }
            Selector::Label(want) => {
                let got = decode_label(&sb[OFF_LABEL..OFF_LABEL + 16]);
                if got == *want {
                    println!("{}", p.display());
                    return ExitCode::from(0);
                }
            }
        }
    }

    ExitCode::from(1)
}

fn read_sb(path: &Path) -> std::io::Result<[u8; SB_LEN]> {
    let mut f = File::open(path)?;
    f.seek(SeekFrom::Start(SB_OFF))?;
    let mut buf = [0u8; SB_LEN];
    f.read_exact(&mut buf)?;
    Ok(buf)
}

fn format_uuid(b: &[u8; 16]) -> String {
    format!(
        "{:02x}{:02x}{:02x}{:02x}-{:02x}{:02x}-{:02x}{:02x}-{:02x}{:02x}-{:02x}{:02x}{:02x}{:02x}{:02x}{:02x}",
        b[0], b[1], b[2], b[3],
        b[4], b[5],
        b[6], b[7],
        b[8], b[9],
        b[10], b[11], b[12], b[13], b[14], b[15],
    )
}

fn decode_label(raw: &[u8]) -> String {
    let end = raw.iter().position(|&c| c == 0).unwrap_or(raw.len());
    String::from_utf8_lossy(&raw[..end]).into_owned()
}
