//! lsattr — read-only sibling of chattr. Prints the
//! inode flag letters for one or many paths inside an
//! ext4 image, in the same 20-column shape as upstream
//! /usr/bin/lsattr.
//!
//! Usage:
//!   lsattr <image> <path> [<path>...]
//!   lsattr -R <image> <dir>
//!   lsattr -l <image> <path> [<path>...]
//!   lsattr -V
//!
//! Exit codes:
//!   0   success
//!   8   operational error
//!   16  usage error

use std::path::PathBuf;
use std::process::ExitCode;

use anvil_core::consts::{EXT4_ROOT_INO, S_IFDIR, S_IFMT};
use anvil_core::extent::walk_extents;
use anvil_core::fs::Fs;

const VERSION_LINE: &str = "anvil-lsattr 1.47.3-anvil (MIT)";

// 20-column field, order matches upstream e2fsprogs
// lsattr flags_array. Each entry maps a flag bit to the
// letter printed at that column (or '-' if clear).
// Upstream uses lowercase 'e' for EXTENTS_FL at col 14.
const FLAG_COLS: &[(u32, char, &str)] = &[
    (0x0000_0001, 's', "Secure deletion"),
    (0x0000_0002, 'u', "Undelete"),
    (0x0000_0008, 'S', "Synchronous updates"),
    (0x0001_0000, 'D', "Synchronous directory updates"),
    (0x0000_0010, 'i', "Immutable"),
    (0x0000_0020, 'a', "Append-only"),
    (0x0000_0040, 'd', "No dump"),
    (0x0000_0080, 'A', "No atime updates"),
    (0x0000_0004, 'c', "Compression requested"),
    (0x0080_0000, 'E', "Encrypted"),
    (0x0000_4000, 'j', "Journaled data"),
    (0x0000_1000, 'I', "Indexed directory"),
    (0x0000_8000, 't', "No tail-merging"),
    (0x0002_0000, 'T', "Top of directory hierarchy"),
    (0x0008_0000, 'e', "Extents"),
    (0x0004_0000, 'h', "Huge file"),
    (0x0010_0000, 'C', "No COW"),
    (0x0100_0000, 'x', "DAX"),
    (0x2000_0000, 'V', "Verity"),
    (0x1000_0000, 'N', "Inline data"),
];

fn main() -> ExitCode {
    let args: Vec<String> = std::env::args().skip(1).collect();
    if args.is_empty() {
        usage();
        return ExitCode::from(16);
    }
    if args[0] == "-V" {
        println!("{VERSION_LINE}");
        return ExitCode::from(0);
    }

    let mut recurse = false;
    let mut verbose = false;
    let mut idx = 0usize;
    while idx < args.len() {
        match args[idx].as_str() {
            "-R" => {
                recurse = true;
                idx += 1;
            }
            "-l" => {
                verbose = true;
                idx += 1;
            }
            _ => break,
        }
    }
    if args.len() - idx < 2 {
        usage();
        return ExitCode::from(16);
    }
    let image = PathBuf::from(&args[idx]);
    let paths: Vec<String> = args[idx + 1..].to_vec();

    let mut fs = match Fs::open(&image) {
        Ok(fs) => fs,
        Err(e) => {
            eprintln!("lsattr: open {}: {}", image.display(), e);
            return ExitCode::from(8);
        }
    };

    let mut any_err = false;
    for p in &paths {
        if recurse {
            if let Err(e) = print_recursive(&mut fs, p, verbose, true) {
                eprintln!("lsattr: {p}: {e}");
                any_err = true;
            }
        } else {
            match resolve_and_read_flags(&mut fs, p) {
                Ok(flags) => print_one(flags, p, verbose),
                Err(e) => {
                    eprintln!("lsattr: {p}: {e}");
                    any_err = true;
                }
            }
        }
    }
    if any_err {
        ExitCode::from(8)
    } else {
        ExitCode::from(0)
    }
}

fn usage() {
    eprintln!("usage: lsattr [-R] [-l] <image> <path> [<path>...]");
    eprintln!("       lsattr -V");
}

fn print_one(flags: u32, path: &str, verbose: bool) {
    if verbose {
        // Verbose: "<path> <comma-sep full names>"
        let names: Vec<&str> = FLAG_COLS
            .iter()
            .filter_map(|(bit, _, name)| if flags & *bit != 0 { Some(*name) } else { None })
            .collect();
        let joined = if names.is_empty() {
            "---".to_string()
        } else {
            names.join(", ")
        };
        println!("{path:<28} {joined}");
    } else {
        println!("{} {}", bits_to_columns(flags), path);
    }
}

fn bits_to_columns(flags: u32) -> String {
    let mut s = String::with_capacity(FLAG_COLS.len());
    for (bit, letter, _) in FLAG_COLS {
        if flags & *bit != 0 {
            s.push(*letter);
        } else {
            s.push('-');
        }
    }
    s
}

fn resolve_and_read_flags(fs: &mut Fs, path: &str) -> std::io::Result<u32> {
    let ino_num = resolve_path(fs, path)?;
    let ino = fs.read_inode(ino_num)?;
    Ok(ino.i_flags)
}

fn print_recursive(fs: &mut Fs, path: &str, verbose: bool, top: bool) -> std::io::Result<()> {
    let start_ino = resolve_path(fs, path)?;
    let start = fs.read_inode(start_ino)?;
    // Only print self for the user-supplied top entry; when we
    // descend into a subdir we've already printed it at the
    // parent level.
    if top {
        print_one(start.i_flags, path, verbose);
    }
    if start.i_mode & S_IFMT != S_IFDIR {
        return Ok(());
    }
    let entries = read_dir_entries(fs, start_ino)?;
    for (name, child_ino) in entries {
        if name == b"." || name == b".." {
            continue;
        }
        let name_str = String::from_utf8_lossy(&name).into_owned();
        let child_path = join_path(path, &name_str);
        match fs.read_inode(child_ino) {
            Ok(child) => {
                print_one(child.i_flags, &child_path, verbose);
                if child.i_mode & S_IFMT == S_IFDIR {
                    print_recursive(fs, &child_path, verbose, false)?;
                }
            }
            Err(e) => {
                eprintln!("lsattr: {child_path}: {e}");
            }
        }
    }
    Ok(())
}

fn join_path(parent: &str, name: &str) -> String {
    if parent == "/" {
        format!("/{name}")
    } else {
        format!("{}/{}", parent.trim_end_matches('/'), name)
    }
}

// --- path resolution + dir reader (same walk as chattr) ---

fn resolve_path(fs: &mut Fs, path: &str) -> std::io::Result<u32> {
    let clean = path.trim();
    if clean.is_empty() || clean == "/" {
        return Ok(EXT4_ROOT_INO);
    }
    let mut cur = EXT4_ROOT_INO;
    for comp in clean.split('/').filter(|s| !s.is_empty()) {
        cur = lookup_in_dir(fs, cur, comp.as_bytes())?;
    }
    Ok(cur)
}

fn lookup_in_dir(fs: &mut Fs, dir_ino: u32, name: &[u8]) -> std::io::Result<u32> {
    for (entry_name, entry_ino) in read_dir_entries(fs, dir_ino)? {
        if entry_name == name {
            return Ok(entry_ino);
        }
    }
    Err(std::io::Error::new(
        std::io::ErrorKind::NotFound,
        format!("no such entry: {}", String::from_utf8_lossy(name)),
    ))
}

fn read_dir_entries(fs: &mut Fs, dir_ino: u32) -> std::io::Result<Vec<(Vec<u8>, u32)>> {
    let inode = fs.read_inode(dir_ino)?;
    if inode.i_mode & S_IFMT != S_IFDIR {
        return Err(std::io::Error::new(
            std::io::ErrorKind::NotFound,
            "not a directory",
        ));
    }
    let mut blocks: Vec<u64> = Vec::new();
    walk_extents(fs, &inode, |r| {
        for off in 0..r.length as u64 {
            blocks.push(r.physical + off);
        }
    })?;

    let bs = fs.block_size as usize;
    let mut out: Vec<(Vec<u8>, u32)> = Vec::new();
    for blk in blocks {
        let mut buf = vec![0u8; bs];
        fs.read_block(blk, &mut buf)?;
        let mut off = 0usize;
        while off + 8 <= buf.len() {
            let entry_ino = u32::from_le_bytes([
                buf[off], buf[off + 1], buf[off + 2], buf[off + 3],
            ]);
            let rec_len = u16::from_le_bytes([buf[off + 4], buf[off + 5]]) as usize;
            let name_len = buf[off + 6] as usize;
            if rec_len < 8 || off + rec_len > bs {
                break;
            }
            if entry_ino != 0 && off + 8 + name_len <= buf.len() {
                let entry_name = buf[off + 8..off + 8 + name_len].to_vec();
                out.push((entry_name, entry_ino));
            }
            off += rec_len;
        }
    }
    Ok(out)
}
