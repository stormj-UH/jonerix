//! filefrag — list the physical extents of a single file
//! inside an ext4 image.
//!
//! Sibling to `e4defrag -v` but scoped to one path. Read-only;
//! never writes to the device.
//!
//! Flags:
//!   <image> <path>         extents of <path> inside <image>
//!   -v <image> <path>      verbose: inode/size/total-extents header
//!   -V                     version
//!
//! Exit codes follow the anvil family:
//!   0   ran to completion
//!   8   operational error (open / read / resolve)
//!   16  usage error

use std::path::{Path, PathBuf};
use std::process::ExitCode;

use anvil_core::consts::{EXT4_ROOT_INO, S_IFDIR, S_IFMT};
use anvil_core::extent::{walk_extents, ExtentRun};
use anvil_core::fs::Fs;

const VERSION_LINE: &str = "anvil-filefrag 1.47.3-anvil (MIT)";

fn main() -> ExitCode {
    let args: Vec<String> = std::env::args().skip(1).collect();
    let mut verbose = false;
    let mut positional: Vec<String> = Vec::new();
    for a in args {
        match a.as_str() {
            "-v" => verbose = true,
            "-V" => {
                println!("{VERSION_LINE}");
                return ExitCode::from(0);
            }
            s if s.starts_with('-') => {
                eprintln!("filefrag: unknown option {s} (ignored)");
            }
            _ => positional.push(a),
        }
    }
    if positional.len() != 2 {
        eprintln!("usage: filefrag [-v] <image> <path>");
        eprintln!("       filefrag -V");
        return ExitCode::from(16);
    }
    let image = PathBuf::from(&positional[0]);
    let inside = positional[1].clone();

    let mut fs = match Fs::open(&image) {
        Ok(fs) => fs,
        Err(e) => {
            eprintln!("filefrag: open {}: {}", image.display(), e);
            return ExitCode::from(8);
        }
    };

    let ino_num = match resolve_path(&mut fs, &inside) {
        Ok(n) => n,
        Err(e) => {
            eprintln!("filefrag: {}: {}", inside, e);
            return ExitCode::from(8);
        }
    };

    let ino = match fs.read_inode(ino_num) {
        Ok(i) => i,
        Err(e) => {
            eprintln!("filefrag: read inode {ino_num}: {e}");
            return ExitCode::from(8);
        }
    };

    let mut runs: Vec<ExtentRun> = Vec::new();
    if let Err(e) = walk_extents(&mut fs, &ino, |r| runs.push(r)) {
        eprintln!("filefrag: walk extents for inode {ino_num}: {e}");
        return ExitCode::from(8);
    }

    print_report(&image, &inside, ino_num, ino.size(), &runs, verbose);
    ExitCode::from(0)
}

fn print_report(
    image: &Path,
    inside: &str,
    ino_num: u32,
    size: u64,
    runs: &[ExtentRun],
    verbose: bool,
) {
    let n = runs.len();
    let extent_word = if n == 1 { "extent" } else { "extents" };
    if verbose {
        println!(
            "{}: {}: inode {}, size {} bytes, {} {}",
            image.display(),
            inside,
            ino_num,
            size,
            n,
            extent_word,
        );
    } else {
        println!(
            "{}: {}: {} {} found",
            image.display(),
            inside,
            n,
            if n == 1 { "extent" } else { "extents" },
        );
    }
    println!("   ext    logical  physical   length  flags");
    for (i, r) in runs.iter().enumerate() {
        println!(
            "{:>6} {:>10} {:>9} {:>8}",
            i, r.logical, r.physical, r.length,
        );
    }
}

/// Walk from the root inode one component at a time. Literal
/// name lookups only — no hash-tree acceleration. Matches the
/// shape of `debugfs::resolve_path` but written fresh.
fn resolve_path(fs: &mut Fs, path: &str) -> std::io::Result<u32> {
    let clean = path.trim();
    if clean.is_empty() || clean == "/" {
        return Ok(EXT4_ROOT_INO);
    }
    let mut cur = EXT4_ROOT_INO;
    for comp in clean.split('/').filter(|s| !s.is_empty()) {
        cur = lookup_in_dir(fs, cur, comp.as_bytes())?;
    }
    Ok(cur)
}

fn lookup_in_dir(fs: &mut Fs, dir_ino: u32, name: &[u8]) -> std::io::Result<u32> {
    let inode = fs.read_inode(dir_ino)?;
    if inode.i_mode & S_IFMT != S_IFDIR {
        return Err(std::io::Error::new(
            std::io::ErrorKind::NotFound,
            "not a directory",
        ));
    }
    // Collect the directory's physical blocks first so the
    // borrow on `fs` from `walk_extents` releases before we
    // start `read_block`ing.
    let mut blocks: Vec<u64> = Vec::new();
    walk_extents(fs, &inode, |r| {
        for off in 0..r.length as u64 {
            blocks.push(r.physical + off);
        }
    })?;

    let bs = fs.block_size as usize;
    for blk in blocks {
        let mut buf = vec![0u8; bs];
        fs.read_block(blk, &mut buf)?;
        let mut off = 0usize;
        while off + 8 <= buf.len() {
            let entry_ino = u32::from_le_bytes([
                buf[off], buf[off + 1], buf[off + 2], buf[off + 3],
            ]);
            let rec_len = u16::from_le_bytes([buf[off + 4], buf[off + 5]]) as usize;
            let name_len = buf[off + 6] as usize;
            if rec_len < 8 || off + rec_len > bs {
                break;
            }
            if entry_ino != 0 && off + 8 + name_len <= buf.len() {
                let entry_name = &buf[off + 8..off + 8 + name_len];
                if entry_name == name {
                    return Ok(entry_ino);
                }
            }
            off += rec_len;
        }
    }
    Err(std::io::Error::new(
        std::io::ErrorKind::NotFound,
        format!("no such entry: {}", String::from_utf8_lossy(name)),
    ))
}
