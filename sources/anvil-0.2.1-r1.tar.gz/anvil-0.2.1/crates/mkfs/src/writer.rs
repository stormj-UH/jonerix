//! Low-level emit routines. Nothing here knows *what* the
//! filesystem looks like — it just flattens structures to on-disk
//! bytes and writes them at the right offsets.

use crate::geometry::Geometry;
use crate::layout::{GroupPlan, build_root_inode, build_lf_inode};
use anvil_core::bitmap;
use anvil_core::consts::*;
use anvil_core::dir::{append_dir_entry};
use anvil_core::group_desc::GroupDesc64;
use anvil_core::inode::Inode;
use anvil_core::superblock::Superblock;
use std::io;

/// Superblock + full GDT backup at a given group. Group 0 is the
/// primary location (superblock at absolute byte 1024); later backup
/// groups sit at group_start * block_size.
pub fn write_sb_and_gdt(
    dev: &mut anvil_core::io::Device,
    g: &Geometry,
    sb: &Superblock,
    gdt: &[GroupDesc64],
    group: u32,
) -> io::Result<()> {
    let mut sb_for_group = *sb;
    sb_for_group.s_block_group_nr = group as u16;

    let (sb_byte_offset, gdt_block_offset) = if group == 0 {
        // Primary: SB at byte 1024, GDT starts at next block.
        let gdt_start_block = if g.block_size == 1024 { 2 } else { 1 };
        (1024u64, gdt_start_block as u64)
    } else {
        // Backup: SB at block_group_nr * blocks_per_group, GDT in
        // the following blocks.
        let group_start = g.first_data_block as u64 + group as u64 * g.blocks_per_group as u64;
        let sb_byte = group_start * g.block_size as u64;
        (sb_byte, group_start + 1)
    };

    dev.write_at(sb_byte_offset, &sb_for_group.to_bytes())?;

    // GDT: `ceil(groups * desc_size / block_size)` blocks of descriptors.
    let desc_size = g.desc_size as usize;
    let descs_per_block = g.block_size as usize / desc_size;
    let gdt_blocks = gdt.len().div_ceil(descs_per_block);
    for bi in 0..gdt_blocks {
        let mut blk = vec![0u8; g.block_size as usize];
        for di in 0..descs_per_block {
            let gi = bi * descs_per_block + di;
            if gi >= gdt.len() { break; }
            let bytes = gdt[gi].to_bytes(desc_size);
            let off = di * desc_size;
            blk[off..off + desc_size].copy_from_slice(&bytes);
        }
        let blk_idx = gdt_block_offset + bi as u64;
        dev.write_at(blk_idx * g.block_size as u64, &blk)?;
    }

    Ok(())
}

/// Write block bitmap, inode bitmap, and zero the inode table area
/// for one group.
pub fn write_group_metadata(
    dev: &mut anvil_core::io::Device,
    g: &Geometry,
    plan: &GroupPlan,
    group: u32,
) -> io::Result<()> {
    let bs = g.block_size as usize;
    let group_start = g.first_data_block as u64 + group as u64 * g.blocks_per_group as u64;
    let group_end_block = if group + 1 == g.groups_count as u32 {
        g.blocks_count
    } else {
        group_start + g.blocks_per_group as u64
    };

    // --- block bitmap ---
    let mut bb = vec![0u8; bs];
    // Mark every metadata block in this group as used. The metadata
    // range runs [group_start, plan.first_data_block_in_group).
    let meta_bits = (plan.first_data_block_in_group - group_start) as usize;
    bitmap::mark_range(&mut bb, 0, meta_bits);
    // Mark any unused bits past the end of the filesystem as used so
    // the allocator never hands them out.
    let group_blocks = (group_end_block - group_start) as usize;
    if group_blocks < bs * 8 {
        bitmap::mark_range(&mut bb, group_blocks, bs * 8);
    }
    // For group 0, the root-directory block is the first data block;
    // for group 0 also lost+found's block sits at first_data + 1.
    // We mark those two below in write_root_and_lost_found since
    // this function runs first. Pre-reserve them here.
    if group == 0 {
        let rel_root = (plan.first_data_block_in_group - group_start) as usize;
        bitmap::set_bit(&mut bb, rel_root);
        bitmap::set_bit(&mut bb, rel_root + 1);
    }
    // Mark the journal portion that falls inside this group. The
    // range was pre-computed in layout::format and stored in
    // plan.journal_in_group; those blocks are absolute, so convert
    // back to bitmap-local indices here.
    if let Some((lo, hi)) = plan.journal_in_group {
        let rel_lo = (lo - group_start) as usize;
        let rel_hi = (hi - group_start) as usize;
        bitmap::mark_range(&mut bb, rel_lo, rel_hi);
    }
    dev.write_at(plan.block_bitmap_block * g.block_size as u64, &bb)?;

    // --- inode bitmap ---
    let mut ib = vec![0u8; bs];
    if group == 0 {
        // Reserve inodes 1..=EXT4_FIRST_NON_RSV_INO.
        for i in 0..EXT4_FIRST_NON_RSV_INO as usize {
            bitmap::set_bit(&mut ib, i);
        }
    }
    // Mark out-of-range inodes past inodes_per_group.
    let ipg = g.inodes_per_group as usize;
    if ipg < bs * 8 {
        bitmap::mark_range(&mut ib, ipg, bs * 8);
    }
    dev.write_at(plan.inode_bitmap_block * g.block_size as u64, &ib)?;

    // --- inode table: zeroed, then root / lf inodes written in the
    //     follow-up pass. Zero explicitly so a fresh image of a
    //     sparse file still has predictable contents here.
    let it_blocks = (g.inodes_per_group as u64 * g.inode_size as u64)
        .div_ceil(g.block_size as u64);
    let it_start_byte = plan.inode_table_block * g.block_size as u64;
    let it_end_byte   = it_start_byte + it_blocks * g.block_size as u64;
    dev.zero_range(it_start_byte, it_end_byte)?;

    Ok(())
}

/// Write the root directory (inode 2) + lost+found (inode 11).
/// Their data blocks sit at the beginning of group 0's data area.
pub fn write_root_and_lost_found(
    dev: &mut anvil_core::io::Device,
    g: &Geometry,
    groups: &[GroupPlan],
    use_extents: bool,
) -> io::Result<()> {
    let g0 = &groups[0];
    let root_block = g0.first_data_block_in_group;
    let lf_block   = root_block + 1;

    // Root dir block: "." / ".." / "lost+found"
    let mut buf: Vec<u8> = Vec::with_capacity(g.block_size as usize);
    append_dir_entry(&mut buf, EXT4_ROOT_INO, EXT4_FT_DIR, b".", false, g.block_size as usize);
    append_dir_entry(&mut buf, EXT4_ROOT_INO, EXT4_FT_DIR, b"..", false, g.block_size as usize);
    append_dir_entry(&mut buf, EXT4_FIRST_NON_RSV_INO, EXT4_FT_DIR, b"lost+found", true, g.block_size as usize);
    dev.write_at(root_block * g.block_size as u64, &buf)?;

    // lost+found dir block: "." / ".."
    let mut buf: Vec<u8> = Vec::with_capacity(g.block_size as usize);
    append_dir_entry(&mut buf, EXT4_FIRST_NON_RSV_INO, EXT4_FT_DIR, b".", false, g.block_size as usize);
    append_dir_entry(&mut buf, EXT4_ROOT_INO, EXT4_FT_DIR, b"..", true, g.block_size as usize);
    dev.write_at(lf_block * g.block_size as u64, &buf)?;

    // Write inode 2 (root) and inode 11 (lost+found) into the
    // inode table. Inode N lives at table_block + ((N-1) * inode_size)
    // / block_size, offset (N-1) * inode_size mod block_size.
    let itb = g0.inode_table_block;
    write_inode(dev, g, itb, EXT4_ROOT_INO, &build_root_inode(g, root_block, use_extents))?;
    write_inode(dev, g, itb, EXT4_FIRST_NON_RSV_INO, &build_lf_inode(g, lf_block, use_extents))?;
    Ok(())
}

fn write_inode(
    dev: &mut anvil_core::io::Device,
    g: &Geometry,
    table_block: u64,
    ino_num: u32,
    ino: &Inode,
) -> io::Result<()> {
    let byte = table_block * g.block_size as u64
        + (ino_num as u64 - 1) * g.inode_size as u64;
    dev.write_at(byte, &ino.to_bytes(g.inode_size as usize))
}

/// Write the journal:
///   * inode 8 with an EXTENTS tree covering [start, start+len)
///   * JBD2 superblock at block 0 of the journal
///   * zero the body (the kernel is happy to see an empty journal)
pub fn write_journal(
    dev: &mut anvil_core::io::Device,
    g: &Geometry,
    groups: &[GroupPlan],
    want_csum_v3: bool,
    use_extents: bool,
) -> io::Result<()> {
    let journal_start = groups[0].first_data_block_in_group + 2;
    let journal_len   = g.journal_blocks as u64;

    // 1. Inode 8. Same shape as root/lost+found but pointing to
    //    the journal blocks. size = journal_blocks * block_size.
    let mut ino = Inode::default();
    ino.i_mode = S_IFREG | 0o600;
    ino.i_uid = 0; ino.i_gid = 0;
    ino.i_links_count = 1;
    ino.set_size(journal_len * g.block_size as u64);
    ino.i_blocks_lo = (journal_len * g.block_size as u64 / 512) as u32;
    let now = crate::layout::now_u32();
    ino.i_atime = now; ino.i_ctime = now; ino.i_mtime = now;
    if use_extents {
        ino.i_flags = EXT4_EXTENTS_FL;
        write_journal_extents(&mut ino, journal_start, journal_len);
        ino.i_extra_isize = 32;
        ino.i_crtime = now;
    } else {
        // ext3 journal inode uses the classic block-map layout:
        // 12 direct pointers in i_block[0..12], then i_block[12]
        // = single-indirect, [13] = double-indirect, [14] =
        // triple-indirect. The extra blocks needed to hold those
        // pointer pages were reserved contiguously after the
        // journal body by layout::format (see
        // GroupPlan::journal_indirect_blocks); we consume them
        // here without any further bitmap bookkeeping.
        ino.i_flags = 0;
        let ind_start = journal_start + journal_len;
        let ind_count = groups[0].journal_indirect_blocks as u64;
        let total_blocks_sectors = (journal_len + ind_count) * g.block_size as u64 / 512;
        ino.i_blocks_lo = total_blocks_sectors as u32;
        write_journal_block_map(
            dev, g, &mut ino, journal_start, journal_len, ind_start, ind_count,
        )?;
    }
    write_inode(dev, g, groups[0].inode_table_block, EXT4_JOURNAL_INO, &ino)?;

    // 2. JBD2 superblock at journal_start. The rest of the journal
    //    area was already zeroed by write_group_metadata's
    //    zero_range of the inode table and will be lazily zeroed
    //    by the kernel on first mount — we only need to ensure the
    //    body doesn't contain stale magic numbers that would look
    //    like transaction headers. zero_range the whole span to be
    //    safe.
    let mut jbd = anvil_core::jbd2::JournalSuperblock::new_ext4(
        g.block_size,
        g.journal_blocks as u32,
        g.uuid,
    );
    // When the ext4 side is running with metadata_csum, stamp the
    // journal SB with JBD2 CSUM_V3 (incompat bit + checksum_type
    // CRC32C + s_checksum). The journal then carries its own
    // checksum and upstream e2fsck / the kernel see a consistent
    // picture between the ext4 SB feature flags and the journal.
    if want_csum_v3 {
        anvil_core::jbd2::set_csum_v3(&mut jbd, &g.uuid);
    }
    let start_byte = journal_start * g.block_size as u64;
    dev.zero_range(start_byte, start_byte + journal_len * g.block_size as u64)?;
    // The JBD2 SB occupies exactly 1024 bytes and lives at the
    // front of the first journal block.
    dev.write_at(start_byte, &jbd.to_bytes())?;

    Ok(())
}

/// Emit the ext2/3 block-map for the journal inode. `data_start`
/// is the first physical block of the journal body; `data_len`
/// is the journal length in blocks; `ind_start` is the first
/// physical block of the reservation we use to host indirect
/// pointer pages (allocated by layout::format right after the
/// body). `ind_count` is the total number of metadata blocks
/// available there. We walk logical block 0..data_len and build
/// exactly the same 12-direct + single + double + triple indirect
/// tree the ext2 kernel reads.
fn write_journal_block_map(
    dev: &mut anvil_core::io::Device,
    g: &Geometry,
    ino: &mut Inode,
    data_start: u64,
    data_len: u64,
    ind_start: u64,
    ind_count: u64,
) -> io::Result<()> {
    let bs = g.block_size as usize;
    let ptrs_per_block = bs / 4;
    let p = ptrs_per_block as u64;

    // Simple allocator over the indirect-block reservation. We
    // hand out blocks in order and zero-fill unused slots.
    let mut next_ind = ind_start;
    let ind_end = ind_start + ind_count;
    let mut alloc_ind = || -> io::Result<u64> {
        if next_ind >= ind_end {
            return Err(io::Error::new(
                io::ErrorKind::Other,
                "journal indirect reservation exhausted",
            ));
        }
        let b = next_ind;
        next_ind += 1;
        Ok(b)
    };

    // Track the pointer writes we need to flush to each indirect
    // block. Map: indirect_block_phys -> Vec<u32> of pointers.
    // We build the map logically, then zero each indirect block
    // and overwrite the slots we populated.
    //
    // Because ee writes are in logical order and we never revisit
    // a slot, a straightforward single-pass flush works.
    struct IndBlock {
        phys: u64,
        ptrs: Vec<u32>, // length = ptrs_per_block, zero-init
    }
    let mut ind_blocks: Vec<IndBlock> = Vec::new();
    let mut ind_phys_to_idx = std::collections::HashMap::<u64, usize>::new();
    let mut touch_ind = |phys: u64,
                        slot: usize,
                        val: u32,
                        ind_blocks: &mut Vec<IndBlock>,
                        map: &mut std::collections::HashMap<u64, usize>|
     -> () {
        let idx = *map.entry(phys).or_insert_with(|| {
            ind_blocks.push(IndBlock {
                phys,
                ptrs: vec![0u32; ptrs_per_block],
            });
            ind_blocks.len() - 1
        });
        ind_blocks[idx].ptrs[slot] = val;
    };

    // 12 direct
    let mut logical: u64 = 0;
    while logical < data_len && logical < 12 {
        ino.i_block[logical as usize] = (data_start + logical) as u32;
        logical += 1;
    }

    // Single indirect: i_block[12]
    if logical < data_len {
        let ind1 = alloc_ind()?;
        ino.i_block[12] = ind1 as u32;
        let mut slot: u64 = 0;
        while logical < data_len && slot < p {
            touch_ind(
                ind1,
                slot as usize,
                (data_start + logical) as u32,
                &mut ind_blocks,
                &mut ind_phys_to_idx,
            );
            logical += 1;
            slot += 1;
        }
    }

    // Double indirect: i_block[13]
    if logical < data_len {
        let dind = alloc_ind()?;
        ino.i_block[13] = dind as u32;
        let mut outer_slot: u64 = 0;
        while logical < data_len && outer_slot < p {
            let inner = alloc_ind()?;
            touch_ind(
                dind,
                outer_slot as usize,
                inner as u32,
                &mut ind_blocks,
                &mut ind_phys_to_idx,
            );
            let mut slot: u64 = 0;
            while logical < data_len && slot < p {
                touch_ind(
                    inner,
                    slot as usize,
                    (data_start + logical) as u32,
                    &mut ind_blocks,
                    &mut ind_phys_to_idx,
                );
                logical += 1;
                slot += 1;
            }
            outer_slot += 1;
        }
    }

    // Triple indirect: i_block[14]
    if logical < data_len {
        let tind = alloc_ind()?;
        ino.i_block[14] = tind as u32;
        let mut t_slot: u64 = 0;
        while logical < data_len && t_slot < p {
            let dind = alloc_ind()?;
            touch_ind(
                tind,
                t_slot as usize,
                dind as u32,
                &mut ind_blocks,
                &mut ind_phys_to_idx,
            );
            let mut outer_slot: u64 = 0;
            while logical < data_len && outer_slot < p {
                let inner = alloc_ind()?;
                touch_ind(
                    dind,
                    outer_slot as usize,
                    inner as u32,
                    &mut ind_blocks,
                    &mut ind_phys_to_idx,
                );
                let mut slot: u64 = 0;
                while logical < data_len && slot < p {
                    touch_ind(
                        inner,
                        slot as usize,
                        (data_start + logical) as u32,
                        &mut ind_blocks,
                        &mut ind_phys_to_idx,
                    );
                    logical += 1;
                    slot += 1;
                }
                outer_slot += 1;
            }
            t_slot += 1;
        }
    }

    // Flush every touched indirect block. Unused pointers stay
    // zero (match the kernel's "hole" encoding for sparse files;
    // harmless here since the journal body is fully populated).
    for ib in &ind_blocks {
        let mut buf = vec![0u8; bs];
        for (i, &ptr) in ib.ptrs.iter().enumerate() {
            let off = i * 4;
            buf[off..off + 4].copy_from_slice(&ptr.to_le_bytes());
        }
        dev.write_at(ib.phys * g.block_size as u64, &buf)?;
    }

    Ok(())
}

fn write_journal_extents(ino: &mut Inode, start: u64, len: u64) {
    use anvil_core::inode::{ExtentHeader, Extent};
    // One Extent's ee_len is a u16, so a single extent can cover
    // at most 32 768 blocks of initialised data (values 32769–
    // 65535 mark the range "uninitialised"). Big-journal requests
    // (`-J size=N` where N spills past ~128 MiB on 4-KiB blocks)
    // force us to split across the 4 inline extent slots. Clamp
    // the journal length to what actually fits in 4 extents so we
    // never produce an i_block[] that silently truncates u16 and
    // leaves the filesystem pointing at extent-invisible data
    // blocks (the failure mode on `m_bigjournal`).
    const MAX_EXT_LEN: u64 = 32_768;
    const MAX_INLINE_EXTENTS: usize = 4;
    let cap = MAX_EXT_LEN * MAX_INLINE_EXTENTS as u64;
    let len = core::cmp::min(len, cap);

    // Split into consecutive runs of up to MAX_EXT_LEN each.
    let mut extents: Vec<Extent> = Vec::new();
    let mut logical: u32 = 0;
    let mut remaining = len;
    let mut phys = start;
    while remaining > 0 && extents.len() < MAX_INLINE_EXTENTS {
        let take = core::cmp::min(remaining, MAX_EXT_LEN) as u16;
        let mut e = Extent {
            ee_block: logical,
            ee_len: take,
            ee_start_hi: 0,
            ee_start_lo: 0,
        };
        e.set_start(phys);
        extents.push(e);
        logical = logical.wrapping_add(take as u32);
        phys = phys.wrapping_add(take as u64);
        remaining -= take as u64;
    }

    let hdr = ExtentHeader {
        eh_magic: EXT4_EXT_MAGIC,
        eh_entries: extents.len() as u16,
        eh_max: MAX_INLINE_EXTENTS as u16,
        eh_depth: 0,
        eh_generation: 0,
    };
    unsafe {
        let base = core::ptr::addr_of_mut!(ino.i_block) as *mut u8;
        core::ptr::write_unaligned(base as *mut ExtentHeader, hdr);
        for (i, e) in extents.iter().enumerate() {
            let off = 12 + i * 12;
            core::ptr::write_unaligned(base.add(off) as *mut Extent, *e);
        }
    }
}



/// Walk `source_dir` and populate the filesystem with its tree.
///
/// Regular files and directories are copied; symlinks / devices /
/// sockets / fifos are skipped with a warning. Every new inode is
/// owned by uid/gid 0; regular files get mode 0644, directories
/// get 0755.
///
/// Inode numbers are bumped from `s_first_ino + 1` (12). Data
/// blocks are drawn contiguously starting just past the journal
/// reservation. Both bookkeeping counters in the superblock and
/// group 0's GDT entry are updated to match.
pub fn populate_from_dir(
    dev: &mut anvil_core::io::Device,
    g: &crate::geometry::Geometry,
    sb: &mut Superblock,
    gdt: &mut [GroupDesc64],
    groups: &[crate::layout::GroupPlan],
    source_dir: &std::path::Path,
) -> io::Result<PopulateResult> {
    let bs = g.block_size as u64;
    let use_extents = (sb.s_feature_incompat & EXT4_FEATURE_INCOMPAT_EXTENTS) != 0;
    let use_inline_data = (sb.s_feature_incompat & EXT4_FEATURE_INCOMPAT_INLINE_DATA) != 0;
    let want_csum = sb.s_feature_ro_compat & EXT4_FEATURE_RO_COMPAT_METADATA_CSUM != 0;

    // --- Pre-flight: compute where data blocks can start. Past the
    //     journal reservation, or past the root/lf data blocks if
    //     no journal. ---
    let root_block = groups[0].first_data_block_in_group;
    let lf_block   = root_block + 1;
    let alloc_start: u64 = if g.journal_blocks > 0 {
        root_block + 2 + g.journal_blocks + groups[0].journal_indirect_blocks as u64
    } else {
        lf_block + 1
    };
    let mut next_block: u64 = alloc_start;
    let group0_end = g.first_data_block as u64 + g.blocks_per_group as u64;

    // Inode allocator: start at first_ino + 1 = 12.
    let mut next_inode: u32 = EXT4_FIRST_NON_RSV_INO + 1;

    // Root-level entries we will inject into the existing root dir
    // block. (name, inode, file_type).
    let mut root_new_entries: Vec<(Vec<u8>, u32, u8)> = Vec::new();

    struct PendingDir {
        inode_no: u32,
        path: std::path::PathBuf,
        parent_inode: u32,
        children: Vec<(Vec<u8>, u32, u8)>,
    }

    let mut dir_queue: Vec<PendingDir> = Vec::new();
    let mut file_writes: Vec<(u64, Vec<u8>)> = Vec::new();
    let mut inode_writes: Vec<(u32, Inode, bool)> = Vec::new();
    let mut inline_data_inodes: Vec<u32> = Vec::new();
    let mut root_extra_links: u16 = 0;

    // Extent-tree leaf blocks we have to emit (one physical
    // block per leaf). Populated by emit_multilevel_extents for
    // regular files > 4 inline extents. Tracked as a flat
    // (phys, bytes) list for the data-write pass and as
    // (inode, vec<phys>) per inode for the csum stamp pass.
    let mut extent_leaf_writes: Vec<(u64, Vec<u8>)> = Vec::new();
    let mut extent_leaf_by_inode: Vec<(u32, Vec<u64>)> = Vec::new();

    // Scan a directory and classify each entry.
    fn scan_dir(path: &std::path::Path) -> io::Result<Vec<(Vec<u8>, std::path::PathBuf, u8)>> {
        let mut out = Vec::new();
        for entry in std::fs::read_dir(path)? {
            let entry = entry?;
            let name_os = entry.file_name();
            let name_bytes: Vec<u8> = name_os.as_encoded_bytes().to_vec();
            if name_bytes.is_empty() || name_bytes.len() > 255
                || name_bytes.contains(&0) || name_bytes.contains(&b'/')
            {
                eprintln!("mkfs: skipping unsupported entry name in {:?}", path);
                continue;
            }
            let ft = entry.file_type()?;
            let kind = if ft.is_file() { 0u8 }
                       else if ft.is_dir() { 1u8 }
                       else {
                           eprintln!("mkfs: skipping unsupported entry {:?} (not regular file or directory)",
                                     entry.path());
                           continue;
                       };
            out.push((name_bytes, entry.path(), kind));
        }
        Ok(out)
    }

    // Seed the queue with the root-of-source directory's children.
    let top_entries = scan_dir(source_dir)?;
    for (name, path, kind) in top_entries {
        if next_inode > g.inodes_count as u32 {
            return Err(io::Error::new(io::ErrorKind::Other, "mkfs -d: out of inodes"));
        }
        let ino_no = next_inode;
        next_inode += 1;
        if kind == 1 {
            root_new_entries.push((name.clone(), ino_no, EXT4_FT_DIR));
            root_extra_links += 1;
            dir_queue.push(PendingDir {
                inode_no: ino_no,
                path,
                parent_inode: EXT4_ROOT_INO,
                children: Vec::new(),
            });
        } else {
            root_new_entries.push((name, ino_no, EXT4_FT_REG_FILE));
            let bytes = std::fs::read(&path)?;
            if use_inline_data && bytes.len() <= 60 {
                let ino = build_inline_data_inode(g, &bytes);
                inode_writes.push((ino_no, ino, false));
                inline_data_inodes.push(ino_no);
            } else {
                let nblocks = bytes.len().div_ceil(bs as usize) as u64;
                let start = if nblocks > 0 {
                    if next_block + nblocks > group0_end {
                        return Err(io::Error::new(io::ErrorKind::Other,
                            "mkfs -d: out of group-0 data blocks"));
                    }
                    let s = next_block; next_block += nblocks; s
                } else { 0 };
                if nblocks > 0 {
                    file_writes.push((start, bytes.clone()));
                }
                let mut this_file_leaves: Vec<u64> = Vec::new();
                let mut leaf_alloc = |count: u64| -> io::Result<Vec<u64>> {
                    let mut out = Vec::with_capacity(count as usize);
                    for _ in 0..count {
                        if next_block + 1 > group0_end {
                            return Err(io::Error::new(io::ErrorKind::Other,
                                "mkfs -d: out of group-0 data blocks for extent leaf"));
                        }
                        out.push(next_block);
                        next_block += 1;
                    }
                    Ok(out)
                };
                let ino = build_regular_file_inode(
                    g, bytes.len() as u64, start, nblocks, use_extents,
                    &mut leaf_alloc, &mut extent_leaf_writes, &mut this_file_leaves)?;
                if !this_file_leaves.is_empty() {
                    extent_leaf_by_inode.push((ino_no, this_file_leaves));
                }
                inode_writes.push((ino_no, ino, false));
            }
        }
    }

    // BFS the directory queue.
    let mut qi = 0usize;
    while qi < dir_queue.len() {
        let (inode_no, path, parent_inode) = {
            let d = &dir_queue[qi];
            (d.inode_no, d.path.clone(), d.parent_inode)
        };
        let entries = scan_dir(&path)?;
        let mut children: Vec<(Vec<u8>, u32, u8)> = Vec::new();
        for (name, cpath, kind) in entries {
            if next_inode > g.inodes_count as u32 {
                return Err(io::Error::new(io::ErrorKind::Other, "mkfs -d: out of inodes"));
            }
            let cino = next_inode;
            next_inode += 1;
            if kind == 1 {
                children.push((name.clone(), cino, EXT4_FT_DIR));
                dir_queue.push(PendingDir {
                    inode_no: cino,
                    path: cpath,
                    parent_inode: inode_no,
                    children: Vec::new(),
                });
            } else {
                children.push((name, cino, EXT4_FT_REG_FILE));
                let bytes = std::fs::read(&cpath)?;
                if use_inline_data && bytes.len() <= 60 {
                    let ino = build_inline_data_inode(g, &bytes);
                    inode_writes.push((cino, ino, false));
                    inline_data_inodes.push(cino);
                } else {
                    let nblocks = bytes.len().div_ceil(bs as usize) as u64;
                    let start = if nblocks > 0 {
                        if next_block + nblocks > group0_end {
                            return Err(io::Error::new(io::ErrorKind::Other,
                                "mkfs -d: out of group-0 data blocks"));
                        }
                        let s = next_block; next_block += nblocks; s
                    } else { 0 };
                    if nblocks > 0 {
                        file_writes.push((start, bytes.clone()));
                    }
                    let mut this_file_leaves: Vec<u64> = Vec::new();
                    let mut leaf_alloc = |count: u64| -> io::Result<Vec<u64>> {
                        let mut out = Vec::with_capacity(count as usize);
                        for _ in 0..count {
                            if next_block + 1 > group0_end {
                                return Err(io::Error::new(io::ErrorKind::Other,
                                    "mkfs -d: out of group-0 data blocks for extent leaf"));
                            }
                            out.push(next_block);
                            next_block += 1;
                        }
                        Ok(out)
                    };
                    let ino = build_regular_file_inode(
                        g, bytes.len() as u64, start, nblocks, use_extents,
                        &mut leaf_alloc, &mut extent_leaf_writes, &mut this_file_leaves)?;
                    if !this_file_leaves.is_empty() {
                        extent_leaf_by_inode.push((cino, this_file_leaves));
                    }
                    inode_writes.push((cino, ino, false));
                }
            }
        }
        dir_queue[qi].children = children;
        // Allocate dir block and emit content.
        if next_block + 1 > group0_end {
            return Err(io::Error::new(io::ErrorKind::Other,
                "mkfs -d: out of group-0 data blocks for dir"));
        }
        let dir_block = next_block;
        next_block += 1;
        let dir_children = &dir_queue[qi].children;
        let mut subdir_links: u16 = 0;
        let mut buf: Vec<u8> = Vec::with_capacity(g.block_size as usize);
        let block_end = g.block_size as usize;
        append_dir_entry(&mut buf, inode_no, EXT4_FT_DIR, b".", false, block_end);
        let last_idx = dir_children.len();
        if last_idx == 0 {
            append_dir_entry(&mut buf, parent_inode, EXT4_FT_DIR, b"..", true, block_end);
        } else {
            append_dir_entry(&mut buf, parent_inode, EXT4_FT_DIR, b"..", false, block_end);
            for (i, (name, cino, ft)) in dir_children.iter().enumerate() {
                let last = i + 1 == last_idx;
                append_dir_entry(&mut buf, *cino, *ft, name, last, block_end);
                if *ft == EXT4_FT_DIR { subdir_links += 1; }
            }
        }
        if buf.len() > block_end {
            return Err(io::Error::new(io::ErrorKind::Other,
                "mkfs -d: directory has too many entries to fit in one block"));
        }
        while buf.len() < g.block_size as usize { buf.push(0); }
        dev.write_at(dir_block * bs, &buf)?;
        let ino = build_dir_inode(g, dir_block, use_extents, subdir_links)?;
        inode_writes.push((inode_no, ino, true));
        qi += 1;
    }

    // --- Re-write the root directory block. ---
    let mut new_dir_blocks: Vec<(u32, u64)> = Vec::new();
    if !root_new_entries.is_empty() {
        let block_end = g.block_size as usize;
        let mut buf: Vec<u8> = Vec::with_capacity(g.block_size as usize);
        append_dir_entry(&mut buf, EXT4_ROOT_INO, EXT4_FT_DIR, b".", false, block_end);
        append_dir_entry(&mut buf, EXT4_ROOT_INO, EXT4_FT_DIR, b"..", false, block_end);
        append_dir_entry(&mut buf, EXT4_FIRST_NON_RSV_INO, EXT4_FT_DIR, b"lost+found", false, block_end);
        let last_idx = root_new_entries.len();
        for (i, (name, cino, ft)) in root_new_entries.iter().enumerate() {
            let last = i + 1 == last_idx;
            append_dir_entry(&mut buf, *cino, *ft, name, last, block_end);
        }
        if buf.len() > block_end {
            return Err(io::Error::new(io::ErrorKind::Other,
                "mkfs -d: root directory has too many top-level entries to fit in one block"));
        }
        while buf.len() < g.block_size as usize { buf.push(0); }
        dev.write_at(root_block * bs, &buf)?;

        if root_extra_links > 0 {
            bump_inode_link_count(dev, g, EXT4_ROOT_INO, root_extra_links)?;
        }
    }

    // --- Emit all file data. ---
    for (start, bytes) in &file_writes {
        dev.write_at(*start * bs, bytes)?;
        let end = start * bs + bytes.len() as u64;
        let block_end_byte = (start + (bytes.len() as u64).div_ceil(bs)) * bs;
        if end < block_end_byte {
            dev.zero_range(end, block_end_byte)?;
        }
    }
    // --- Emit extent-tree leaf blocks. ---
    for (phys, blk) in &extent_leaf_writes {
        dev.write_at(*phys * bs, blk)?;
    }

    // --- Emit all inodes. ---
    let itb0 = groups[0].inode_table_block;
    let mut new_dirs: u32 = 0;
    let mut new_inodes: Vec<u32> = Vec::new();
    for (ino_no, ino, is_dir) in &inode_writes {
        write_inode(dev, g, itb0, *ino_no, ino)?;
        if *is_dir {
            new_dirs += 1;
            // Recover the directory's data block for tail-csum later.
            let dir_block = unsafe {
                let base = core::ptr::addr_of!(ino.i_block) as *const u8;
                if use_extents {
                    let hdr: anvil_core::inode::ExtentHeader =
                        core::ptr::read_unaligned(base as *const anvil_core::inode::ExtentHeader);
                    if hdr.eh_magic == EXT4_EXT_MAGIC && hdr.eh_entries >= 1 {
                        let e: anvil_core::inode::Extent =
                            core::ptr::read_unaligned(base.add(12) as *const anvil_core::inode::Extent);
                        ((e.ee_start_hi as u64) << 32) | e.ee_start_lo as u64
                    } else { 0 }
                } else {
                    ino.i_block[0] as u64
                }
            };
            new_dir_blocks.push((*ino_no, dir_block));
        }
        new_inodes.push(*ino_no);
    }

    // --- Stamp the inline `system.data` xattr stub for any
    //     inline-data inodes. e2fsck demands it even when the
    //     payload fits in i_block alone. ---
    for &ino_no in &inline_data_inodes {
        write_inline_data_xattr_stub(dev, g, itb0, ino_no)?;
    }

    // --- Bitmap updates for group 0. ---
    let mut bb = vec![0u8; g.block_size as usize];
    dev.read_at(groups[0].block_bitmap_block * bs, &mut bb)?;
    let group_start = g.first_data_block as u64;
    for b in alloc_start..next_block {
        let rel = (b - group_start) as usize;
        anvil_core::bitmap::set_bit(&mut bb, rel);
    }
    dev.write_at(groups[0].block_bitmap_block * bs, &bb)?;

    let mut ib = vec![0u8; g.block_size as usize];
    dev.read_at(groups[0].inode_bitmap_block * bs, &mut ib)?;
    for n in (EXT4_FIRST_NON_RSV_INO + 1)..next_inode {
        anvil_core::bitmap::set_bit(&mut ib, (n - 1) as usize);
    }
    dev.write_at(groups[0].inode_bitmap_block * bs, &ib)?;

    // --- GDT descriptor updates. ---
    let consumed_blocks = (next_block - alloc_start) as u32;
    let consumed_inodes = next_inode - (EXT4_FIRST_NON_RSV_INO + 1);
    let cur_free_blocks = (gdt[0].bg_free_blocks_count_lo as u32)
        | ((gdt[0].bg_free_blocks_count_hi as u32) << 16);
    let cur_free_inodes = (gdt[0].bg_free_inodes_count_lo as u32)
        | ((gdt[0].bg_free_inodes_count_hi as u32) << 16);
    let cur_used_dirs = (gdt[0].bg_used_dirs_count_lo as u32)
        | ((gdt[0].bg_used_dirs_count_hi as u32) << 16);
    gdt[0].set_free_blocks(cur_free_blocks.saturating_sub(consumed_blocks));
    gdt[0].set_free_inodes(cur_free_inodes.saturating_sub(consumed_inodes));
    gdt[0].set_used_dirs(cur_used_dirs + new_dirs);

    // --- Superblock free counts. ---
    let sb_free_blocks = sb.free_blocks();
    sb.set_free_blocks(sb_free_blocks.saturating_sub(consumed_blocks as u64));
    sb.s_free_inodes_count = sb.s_free_inodes_count.saturating_sub(consumed_inodes);

    Ok(PopulateResult { new_inodes, new_dir_blocks, file_leaf_blocks: extent_leaf_by_inode })
}

/// Summary of what populate_from_dir touched, so the csum
/// finalization pass can stamp the right inodes and dir blocks.
pub struct PopulateResult {
    pub new_inodes: Vec<u32>,
    pub new_dir_blocks: Vec<(u32, u64)>,
    /// For every regular file that needed a multi-level extent
    /// tree, record (inode_num, list-of-leaf-physical-blocks).
    /// `finalize_metadata_csums` walks this list to stamp each
    /// leaf blocks tail csum.
    pub file_leaf_blocks: Vec<(u32, Vec<u64>)>,
}

/// Build an inode that holds its file contents directly inside
/// i_block[] (60 bytes total). No data blocks are allocated and
/// no extent tree is emitted. Requires the
/// EXT4_FEATURE_INCOMPAT_INLINE_DATA superblock feature.
///
/// The kernel reads such inodes by checking EXT4_INLINE_DATA_FL
/// in i_flags and copying min(i_size_lo, 60) bytes from i_block[].
/// Read-modify-write the inline xattr area of an already-written
/// inode to install a minimal `system.data` xattr stub. e2fsprogs
/// requires this entry to be present whenever EXT4_INLINE_DATA_FL
/// is set; for files <= 60 bytes the value is empty (data lives
/// entirely in i_block[]).
///
/// Inline xattr area starts at byte 128 + i_extra_isize of the
/// inode slot and is bounded by `inode_size`. Layout:
///   u32 magic = 0xEA020000
///   ext4_xattr_entry { name_len=4, name_index=7, value_offs=0,
///                       value_inum=0, value_size=0, hash=H }
///   name = b"data"
///   u32 terminator = 0
/// where H is the kernel xattr name hash for "data" (0x338AE1).
fn write_inline_data_xattr_stub(
    dev: &mut anvil_core::io::Device,
    g: &crate::geometry::Geometry,
    inode_table_block: u64,
    ino_num: u32,
) -> io::Result<()> {
    let inode_size = g.inode_size as usize;
    if inode_size <= 128 {
        // No room for an inline xattr area; inline_data feature
        // is incompatible with 128-byte inodes anyway. Skip.
        return Ok(());
    }
    let byte = inode_table_block * g.block_size as u64
        + (ino_num as u64 - 1) * g.inode_size as u64;
    let mut ibuf = vec![0u8; inode_size];
    dev.read_at(byte, &mut ibuf)?;
    let extra_isize = u16::from_le_bytes([ibuf[0x80], ibuf[0x81]]) as usize;
    let start = 128 + extra_isize;
    // Need at least magic(4) + entry(16) + name(4) + terminator(4) = 28 bytes.
    if start + 28 > inode_size {
        return Ok(());
    }
    // Magic
    ibuf[start..start+4].copy_from_slice(&0xEA020000u32.to_le_bytes());
    // Entry at start+4
    let e = start + 4;
    ibuf[e + 0] = 4;       // e_name_len
    ibuf[e + 1] = 7;       // e_name_index = EXT4_XATTR_INDEX_SYSTEM
    ibuf[e + 2] = 0; ibuf[e + 3] = 0;             // e_value_offs
    ibuf[e + 4..e + 8].copy_from_slice(&0u32.to_le_bytes());   // e_value_inum
    ibuf[e + 8..e + 12].copy_from_slice(&0u32.to_le_bytes());  // e_value_size
    ibuf[e + 12..e + 16].copy_from_slice(&0x338AE1u32.to_le_bytes()); // e_hash for "data"
    // Name immediately after the 16-byte entry header.
    ibuf[e + 16..e + 20].copy_from_slice(b"data");
    // 4-byte zero terminator after the (entry + padded name).
    // Entry header(16) + name(4) = 20; terminator at e+20.
    ibuf[e + 20..e + 24].copy_from_slice(&0u32.to_le_bytes());
    dev.write_at(byte, &ibuf)
}

fn build_inline_data_inode(
    g: &crate::geometry::Geometry,
    bytes: &[u8],
) -> Inode {
    debug_assert!(bytes.len() <= 60);
    let mut ino = Inode::default();
    ino.i_mode = S_IFREG | 0o644;
    ino.i_uid = 0;
    ino.i_gid = 0;
    ino.i_links_count = 1;
    ino.set_size(bytes.len() as u64);
    // No data blocks allocated; i_blocks counts 512-byte sectors
    // of allocated storage, which is zero for a pure-inline file.
    ino.i_blocks_lo = 0;
    let now = crate::layout::now_u32();
    ino.i_atime = now;
    ino.i_ctime = now;
    ino.i_mtime = now;
    // Only the inline flag — explicitly NOT EXT4_EXTENTS_FL.
    ino.i_flags = EXT4_INLINE_DATA_FL;
    // Pack bytes into i_block[] (15 * u32 = 60 bytes), little-endian.
    let mut raw = [0u8; 60];
    raw[..bytes.len()].copy_from_slice(bytes);
    for (i, chunk) in raw.chunks_exact(4).enumerate() {
        ino.i_block[i] = u32::from_le_bytes([chunk[0], chunk[1], chunk[2], chunk[3]]);
    }
    if g.inode_size >= 256 {
        ino.i_extra_isize = 32;
        ino.i_crtime = now;
    }
    ino
}

fn build_regular_file_inode(
    g: &crate::geometry::Geometry,
    size: u64,
    start_block: u64,
    nblocks: u64,
    use_extents: bool,
    leaf_allocator: &mut dyn FnMut(u64) -> io::Result<Vec<u64>>,
    leaf_writes: &mut Vec<(u64, Vec<u8>)>,
    leaf_blocks_out: &mut Vec<u64>,
) -> io::Result<Inode> {
    let mut ino = Inode::default();
    ino.i_mode = S_IFREG | 0o644;
    ino.i_uid = 0;
    ino.i_gid = 0;
    ino.i_links_count = 1;
    ino.set_size(size);
    // i_blocks counts the data blocks *and* any extent-tree leaf
    // blocks attached to the inode, in 512-byte sectors.
    // leaf_blocks_out is populated by emit_multilevel_extents.
    let now = crate::layout::now_u32();
    ino.i_atime = now; ino.i_ctime = now; ino.i_mtime = now;
    if use_extents {
        ino.i_flags = EXT4_EXTENTS_FL;
        if nblocks == 0 {
            write_empty_extent_header(&mut ino);
            ino.i_blocks_lo = 0;
        } else {
            // Build the list of extent records (each at most
            // MAX_EXT_LEN blocks). If it fits inline keep the
            // existing fast path; otherwise emit a depth-1 tree.
            const MAX_EXT_LEN: u64 = 32_768;
            const MAX_INLINE_EXTENTS: usize = 4;
            let mut extents: Vec<anvil_core::inode::Extent> = Vec::new();
            let mut logical: u32 = 0;
            let mut remaining = nblocks;
            let mut phys = start_block;
            while remaining > 0 {
                let take = core::cmp::min(remaining, MAX_EXT_LEN) as u16;
                let mut e = anvil_core::inode::Extent {
                    ee_block: logical,
                    ee_len: take,
                    ee_start_hi: 0,
                    ee_start_lo: 0,
                };
                e.set_start(phys);
                extents.push(e);
                logical = logical.wrapping_add(take as u32);
                phys = phys.wrapping_add(take as u64);
                remaining -= take as u64;
            }
            let nleaf_blocks: u64 = if extents.len() <= MAX_INLINE_EXTENTS {
                write_inline_extents_into(&mut ino, &extents)?;
                0
            } else {
                emit_multilevel_extents(
                    &mut ino, &extents, g.block_size,
                    leaf_allocator, leaf_writes, leaf_blocks_out,
                )?
            };
            let total_blocks_sectors =
                (nblocks + nleaf_blocks) * g.block_size as u64 / 512;
            ino.i_blocks_lo = total_blocks_sectors as u32;
        }
        if g.inode_size >= 256 {
            ino.i_extra_isize = 32;
            ino.i_crtime = now;
        }
    } else {
        ino.i_flags = 0;
        ino.i_blocks_lo = (nblocks * g.block_size as u64 / 512) as u32;
        if nblocks > 12 {
            return Err(io::Error::new(io::ErrorKind::Other,
                "mkfs -d: file too large for ext2 direct block map (max 12 blocks)"));
        }
        for i in 0..nblocks as usize {
            ino.i_block[i] = (start_block + i as u64) as u32;
        }
    }
    Ok(ino)
}

fn build_dir_inode(
    g: &crate::geometry::Geometry,
    dir_block: u64,
    use_extents: bool,
    subdir_extra_links: u16,
) -> io::Result<Inode> {
    let mut ino = Inode::default();
    ino.i_mode = S_IFDIR | 0o755;
    ino.i_uid = 0;
    ino.i_gid = 0;
    ino.i_links_count = 2 + subdir_extra_links;
    ino.set_size(g.block_size as u64);
    ino.i_blocks_lo = (g.block_size / 512) as u32;
    let now = crate::layout::now_u32();
    ino.i_atime = now; ino.i_ctime = now; ino.i_mtime = now;
    if use_extents {
        ino.i_flags = EXT4_EXTENTS_FL;
        write_single_extent_into(&mut ino, dir_block, 1)?;
        if g.inode_size >= 256 {
            ino.i_extra_isize = 32;
            ino.i_crtime = now;
        }
    } else {
        ino.i_flags = 0;
        ino.i_block[0] = dir_block as u32;
    }
    Ok(ino)
}

/// Single extent for a dir block / small region. Used by
/// directory inode building and test harnesses that need a
/// one-extent file. Keeps the old inline-only semantics.
fn write_single_extent_into(ino: &mut Inode, start: u64, len: u64) -> io::Result<()> {
    use anvil_core::inode::Extent;
    const MAX_EXT_LEN: u64 = 32_768;
    const MAX_INLINE_EXTENTS: usize = 4;
    let cap = MAX_EXT_LEN * MAX_INLINE_EXTENTS as u64;
    if len > cap {
        return Err(io::Error::new(io::ErrorKind::Other,
            "mkfs -d: file too large for 4 inline extents"));
    }
    let mut extents: Vec<Extent> = Vec::new();
    let mut logical: u32 = 0;
    let mut remaining = len;
    let mut phys = start;
    while remaining > 0 && extents.len() < MAX_INLINE_EXTENTS {
        let take = core::cmp::min(remaining, MAX_EXT_LEN) as u16;
        let mut e = Extent {
            ee_block: logical,
            ee_len: take,
            ee_start_hi: 0,
            ee_start_lo: 0,
        };
        e.set_start(phys);
        extents.push(e);
        logical = logical.wrapping_add(take as u32);
        phys = phys.wrapping_add(take as u64);
        remaining -= take as u64;
    }
    write_inline_extents_into(ino, &extents)
}

/// Write a prebuilt list of up to 4 Extent records inline in
/// i_block[]. Header has depth=0, entries=extents.len(),
/// eh_max=4. Used for both the dir-inode fast path and the
/// regular-file inline path in populate_from_dir.
fn write_inline_extents_into(
    ino: &mut Inode,
    extents: &[anvil_core::inode::Extent],
) -> io::Result<()> {
    use anvil_core::inode::ExtentHeader;
    const MAX_INLINE_EXTENTS: usize = 4;
    if extents.len() > MAX_INLINE_EXTENTS {
        return Err(io::Error::new(io::ErrorKind::Other,
            "write_inline_extents_into: more than 4 extents"));
    }
    let hdr = ExtentHeader {
        eh_magic: EXT4_EXT_MAGIC,
        eh_entries: extents.len() as u16,
        eh_max: MAX_INLINE_EXTENTS as u16,
        eh_depth: 0,
        eh_generation: 0,
    };
    unsafe {
        let base = core::ptr::addr_of_mut!(ino.i_block) as *mut u8;
        core::ptr::write_unaligned(base as *mut ExtentHeader, hdr);
        for (i, e) in extents.iter().enumerate() {
            let off = 12 + i * 12;
            core::ptr::write_unaligned(base.add(off) as *mut anvil_core::inode::Extent, *e);
        }
    }
    Ok(())
}

/// Depth-1 extent tree. The inline i_block[] gets an
/// ExtentHeader with eh_depth=1 and one ExtentIdx per leaf
/// block. Each leaf block is a full filesystem block holding
/// its own ExtentHeader + up to `max_leaf` Extent records.
/// The tail csum slot at offset 12 * (eh_entries + 1) is left
/// zero here; finalize_metadata_csums stamps it after the
/// writer pass when metadata_csum is in play.
///
/// Returns the number of leaf blocks emitted so the caller
/// can fold them into i_blocks_lo.
fn emit_multilevel_extents(
    ino: &mut Inode,
    extents: &[anvil_core::inode::Extent],
    block_size: u32,
    leaf_allocator: &mut dyn FnMut(u64) -> io::Result<Vec<u64>>,
    leaf_writes: &mut Vec<(u64, Vec<u8>)>,
    leaf_blocks_out: &mut Vec<u64>,
) -> io::Result<u64> {
    use anvil_core::inode::{ExtentHeader, Extent, ExtentIdx};
    const MAX_INLINE_IDX: usize = 4;
    // Cap leaf fill at 340 for 4 KiB blocks (fits 4096-12 byte
    // payload) or the block-size-derived limit for smaller
    // blocks (1 KiB -> 84, 2 KiB -> 170). Reserve one slot
    // past the last record for the tail csum.
    let max_leaf = ((block_size as usize - 12) / 12) as usize;
    let n_extents = extents.len();
    let n_leaves = n_extents.div_ceil(max_leaf);
    if n_leaves > MAX_INLINE_IDX {
        return Err(io::Error::new(io::ErrorKind::Other,
            "mkfs -d: file needs deeper than depth=1 extent tree"));
    }
    let leaf_phys_blocks = leaf_allocator(n_leaves as u64)?;
    if leaf_phys_blocks.len() != n_leaves {
        return Err(io::Error::new(io::ErrorKind::Other,
            "mkfs -d: leaf allocator returned wrong count"));
    }

    // Inline interior: ExtentHeader { depth=1 } + ExtentIdx per leaf.
    let hdr = ExtentHeader {
        eh_magic: EXT4_EXT_MAGIC,
        eh_entries: n_leaves as u16,
        eh_max: MAX_INLINE_IDX as u16,
        eh_depth: 1,
        eh_generation: 0,
    };
    unsafe {
        let base = core::ptr::addr_of_mut!(ino.i_block) as *mut u8;
        core::ptr::write_unaligned(base as *mut ExtentHeader, hdr);
        for (i, phys) in leaf_phys_blocks.iter().enumerate() {
            let first_ext_in_leaf = &extents[i * max_leaf];
            let mut idx = ExtentIdx {
                ei_block: first_ext_in_leaf.ee_block,
                ei_leaf_lo: *phys as u32,
                ei_leaf_hi: (*phys >> 32) as u16,
                ei_unused: 0,
            };
            // touch idx to avoid unused-write-packed warnings
            let _ = &mut idx;
            let off = 12 + i * 12;
            core::ptr::write_unaligned(base.add(off) as *mut ExtentIdx, idx);
        }
    }

    // Build each leaf block.
    for (leaf_i, phys) in leaf_phys_blocks.iter().enumerate() {
        let lo = leaf_i * max_leaf;
        let hi = core::cmp::min(lo + max_leaf, n_extents);
        let entries_in_leaf = (hi - lo) as u16;
        let leaf_hdr = ExtentHeader {
            eh_magic: EXT4_EXT_MAGIC,
            eh_entries: entries_in_leaf,
            eh_max: max_leaf as u16,
            eh_depth: 0,
            eh_generation: 0,
        };
        let mut blk = vec![0u8; block_size as usize];
        unsafe {
            core::ptr::write_unaligned(blk.as_mut_ptr() as *mut ExtentHeader, leaf_hdr);
            for (i, e) in extents[lo..hi].iter().enumerate() {
                let off = 12 + i * 12;
                core::ptr::write_unaligned(blk.as_mut_ptr().add(off) as *mut Extent, *e);
            }
        }
        leaf_writes.push((*phys, blk));
        leaf_blocks_out.push(*phys);
    }

    Ok(n_leaves as u64)
}

fn write_empty_extent_header(ino: &mut Inode) {
    use anvil_core::inode::ExtentHeader;
    let hdr = ExtentHeader {
        eh_magic: EXT4_EXT_MAGIC,
        eh_entries: 0,
        eh_max: 4,
        eh_depth: 0,
        eh_generation: 0,
    };
    unsafe {
        let base = core::ptr::addr_of_mut!(ino.i_block) as *mut u8;
        core::ptr::write_unaligned(base as *mut ExtentHeader, hdr);
    }
}

fn bump_inode_link_count(
    dev: &mut anvil_core::io::Device,
    g: &crate::geometry::Geometry,
    ino_num: u32,
    delta: u16,
) -> io::Result<()> {
    let group = (ino_num as u64 - 1) / g.inodes_per_group as u64;
    let idx   = (ino_num as u64 - 1) % g.inodes_per_group as u64;
    let inode_table = crate::layout::plan_group_inode_table(g, group);
    let byte = inode_table * g.block_size as u64 + idx * g.inode_size as u64;
    // i_links_count is at offset 0x1A (after i_mode/i_uid/i_size_lo/
    // i_atime/i_ctime/i_mtime/i_dtime/i_gid).
    let link_off = byte + 0x1A;
    let mut b = [0u8; 2];
    dev.read_at(link_off, &mut b)?;
    let cur = u16::from_le_bytes(b);
    let new = cur.saturating_add(delta);
    dev.write_at(link_off, &new.to_le_bytes())
}

/// Phase 7 metadata_csum finalization. Runs after every
/// structure has been written once in pristine form; we read
/// each block back, compute the crc32c, and patch the checksum
/// slot in place. Handles:
///   * inode csums for every allocated inode in the fresh image
///     (root, lost+found, journal)
///   * block-bitmap / inode-bitmap csums into each GDT entry
///   * dir-block tail csum on root and lost+found dir blocks
///   * bg_checksum on every GDT descriptor
///   * s_checksum on the superblock
/// Once those are in place we re-emit SB + GDT everywhere so
/// every backup reflects the final bytes.
pub fn finalize_metadata_csums(
    dev: &mut anvil_core::io::Device,
    g: &Geometry,
    sb: &mut Superblock,
    gdt: &mut [GroupDesc64],
    groups: &[GroupPlan],
    extra: Option<&PopulateResult>,
) -> io::Result<()> {
    let bs = g.block_size as usize;

    // --- Inode csums for the three live inodes we emitted. ---
    //
    // For a freshly-minted fs the rest of each inode table is
    // all zeros, and the read-side verifier treats all-zero
    // inodes as trivially valid; skipping them keeps the pass
    // cheap and sidesteps touching the deleted-inode slots.
    for ino_num in [EXT4_ROOT_INO, EXT4_FIRST_NON_RSV_INO, EXT4_JOURNAL_INO] {
        if (ino_num == EXT4_JOURNAL_INO) && g.journal_blocks == 0 { continue; }
        stamp_inode_csum(dev, g, sb, ino_num)?;
    }
    if let Some(ex) = extra {
        for ino_num in &ex.new_inodes {
            stamp_inode_csum(dev, g, sb, *ino_num)?;
        }
    }

    // --- Bitmap csums per group, written into the GDT entries
    //     in memory so the GDT-csum pass below sees the final
    //     field values.
    for gi in 0..g.groups_count {
        let plan = &groups[gi as usize];
        let mut bb = vec![0u8; bs];
        dev.read_at(plan.block_bitmap_block * g.block_size as u64, &mut bb)?;
        let bbc = anvil_core::fs::compute_bitmap_csum(sb, &bb);
        gdt[gi as usize].bg_block_bitmap_csum_lo = bbc as u16;
        if g.desc_size as usize >= 0x3A {
            gdt[gi as usize].bg_block_bitmap_csum_hi = (bbc >> 16) as u16;
        }
        // Inode bitmap csum only hashes the bytes covering the
        // actual inodes (ceil(inodes_per_group / 8)), matching
        // the read-side verify. Block bitmap hashes the whole
        // block regardless.
        let mut ib = vec![0u8; bs];
        dev.read_at(plan.inode_bitmap_block * g.block_size as u64, &mut ib)?;
        let ipg_bytes = ((g.inodes_per_group + 7) / 8) as usize;
        let ib_sz = core::cmp::min(ipg_bytes, ib.len());
        let ibc = anvil_core::fs::compute_bitmap_csum(sb, &ib[..ib_sz]);
        gdt[gi as usize].bg_inode_bitmap_csum_lo = ibc as u16;
        if g.desc_size as usize >= 0x3A {
            gdt[gi as usize].bg_inode_bitmap_csum_hi = (ibc >> 16) as u16;
        }
    }

    // --- Directory block tail csum on the two dir blocks we
    //     wrote (root + lost+found). The read verifier only
    //     fires when the block ends in the 12-byte tail entry
    //     marker; append that marker with the crc32c payload
    //     so the kernel + upstream e2fsck see a valid tail.
    stamp_dir_block_tail_csum(dev, g, sb, EXT4_ROOT_INO,
                              groups[0].first_data_block_in_group)?;
    stamp_dir_block_tail_csum(dev, g, sb, EXT4_FIRST_NON_RSV_INO,
                              groups[0].first_data_block_in_group + 1)?;
    if let Some(ex) = extra {
        for (ino_num, dir_block) in &ex.new_dir_blocks {
            stamp_dir_block_tail_csum(dev, g, sb, *ino_num, *dir_block)?;
        }
    }

    // --- Extent-tree leaf tail csum. Each emitted leaf block
    //     carries the standard crc32c over its header + records;
    //     stamp it past the last entry at offset 12*(entries+1).
    if let Some(ex) = extra {
        for (ino_num, leaves) in &ex.file_leaf_blocks {
            for leaf_blk in leaves {
                stamp_extent_leaf_csum(dev, g, sb, *ino_num, *leaf_blk)?;
            }
        }
    }

    // --- GDT descriptor csums. Compute after bitmap csums are
    //     already latched in so the hash covers the final
    //     descriptor bytes.
    for gi in 0..g.groups_count {
        let desc_bytes = gdt[gi as usize].to_bytes(g.desc_size as usize);
        let csum = anvil_core::fs::compute_gdt_csum(sb, gi as u32, &desc_bytes);
        gdt[gi as usize].bg_checksum = csum as u16;
    }

    // --- Superblock csum (crc32c over the first 0x3FC bytes of
    //     the SB with s_checksum zeroed). s_checksum itself
    //     lives at offset 0x3FC of the 1024-byte SB.
    sb.s_checksum = 0;
    let sb_bytes = sb.to_bytes();
    sb.s_checksum = anvil_core::crc::crc32c_cont(0xFFFFFFFF, &sb_bytes[..0x3FC]);

    // --- Re-emit SB + GDT to primary and every backup group so
    //     on-disk bytes match the in-memory checksums.
    write_sb_and_gdt(dev, g, sb, gdt, 0)?;
    for gi in 1..g.groups_count as u32 {
        if crate::layout::is_backup_group(gi) {
            write_sb_and_gdt(dev, g, sb, gdt, gi)?;
        }
    }
    Ok(())
}

fn stamp_extent_leaf_csum(
    dev: &mut anvil_core::io::Device,
    g: &Geometry,
    sb: &Superblock,
    ino_num: u32,
    leaf_block: u64,
) -> io::Result<()> {
    use anvil_core::inode::ExtentHeader;
    let bs = g.block_size as usize;
    let mut buf = vec![0u8; bs];
    dev.read_at(leaf_block * g.block_size as u64, &mut buf)?;
    let hdr: ExtentHeader = unsafe {
        core::ptr::read_unaligned(buf.as_ptr() as *const ExtentHeader)
    };
    let entries = hdr.eh_entries;
    // Zero the csum slot before hashing; keeps final stored
    // bytes aligned with what the read-side verifier hashes past.
    let csum_off = 12usize * (entries as usize + 1);
    if csum_off + 4 > bs { return Ok(()); }
    for b in &mut buf[csum_off..csum_off + 4] { *b = 0; }
    let generation = extent_owner_generation(dev, g, ino_num)?;
    let csum = anvil_core::fs::compute_extent_block_csum(
        sb, ino_num, generation, &buf, entries);
    buf[csum_off]   = csum as u8;
    buf[csum_off+1] = (csum >> 8)  as u8;
    buf[csum_off+2] = (csum >> 16) as u8;
    buf[csum_off+3] = (csum >> 24) as u8;
    dev.write_at(leaf_block * g.block_size as u64, &buf)
}

fn extent_owner_generation(
    dev: &mut anvil_core::io::Device,
    g: &Geometry,
    ino_num: u32,
) -> io::Result<u32> {
    let group = (ino_num as u64 - 1) / g.inodes_per_group as u64;
    let idx   = (ino_num as u64 - 1) % g.inodes_per_group as u64;
    let inode_table = crate::layout::plan_group_inode_table(g, group);
    let byte = inode_table * g.block_size as u64
        + idx * g.inode_size as u64
        + 0x64;
    let mut b = [0u8; 4];
    dev.read_at(byte, &mut b)?;
    Ok(u32::from_le_bytes(b))
}

fn stamp_inode_csum(
    dev: &mut anvil_core::io::Device,
    g: &Geometry,
    sb: &Superblock,
    ino_num: u32,
) -> io::Result<()> {
    let group = (ino_num as u64 - 1) / g.inodes_per_group as u64;
    let idx   = (ino_num as u64 - 1) % g.inodes_per_group as u64;
    let plan_bit_block = g.first_data_block as u64
        + group * g.blocks_per_group as u64;
    let _ = plan_bit_block;
    // The caller passed groups already; easier to recompute
    // the inode-table block from the GDT directly. Do it via
    // the Geometry plan_group output rather than reading the
    // on-disk GDT (we may not have flushed the updated GDT
    // yet).
    let inode_table = crate::layout::plan_group_inode_table(g, group);
    let byte = inode_table * g.block_size as u64 + idx * g.inode_size as u64;
    let mut ibuf = vec![0u8; g.inode_size as usize];
    dev.read_at(byte, &mut ibuf)?;
    let generation = u32::from_le_bytes([ibuf[0x64], ibuf[0x65], ibuf[0x66], ibuf[0x67]]);
    let extra_isize = if g.inode_size >= 256 {
        u16::from_le_bytes([ibuf[0x80], ibuf[0x81]])
    } else { 0 };
    let use_hi = g.inode_size >= 256 && extra_isize > 2;
    // Zero the checksum fields before computing.
    ibuf[0x7C] = 0; ibuf[0x7D] = 0;
    if use_hi { ibuf[0x82] = 0; ibuf[0x83] = 0; }
    let csum = anvil_core::fs::compute_inode_csum(sb, ino_num, generation, &ibuf);
    let lo = csum as u16;
    ibuf[0x7C] = lo as u8;
    ibuf[0x7D] = (lo >> 8) as u8;
    if use_hi {
        let hi = (csum >> 16) as u16;
        ibuf[0x82] = hi as u8;
        ibuf[0x83] = (hi >> 8) as u8;
    }
    dev.write_at(byte, &ibuf)
}

fn stamp_dir_block_tail_csum(
    dev: &mut anvil_core::io::Device,
    g: &Geometry,
    sb: &Superblock,
    ino_num: u32,
    dir_block: u64,
) -> io::Result<()> {
    let bs = g.block_size as usize;
    let mut buf = vec![0u8; bs];
    dev.read_at(dir_block * g.block_size as u64, &mut buf)?;
    // Walk the dir entries and shrink the last one's rec_len by
    // 12 so the 12-byte tail entry fits. The tail is
    //   {inode=0, rec_len=12, name_len=0, file_type=0xDE,
    //    checksum:u32}
    // with the crc32c payload spanning block[..bs-12] +
    // fake_tail_header (inode=0, rec_len=12, name_len=0,
    // file_type=0xDE) with csum zeroed.
    let mut off = 0usize;
    let mut last = 0usize;
    while off + 8 <= bs {
        let rec_len = u16::from_le_bytes([buf[off+4], buf[off+5]]) as usize;
        if rec_len < 8 || off + rec_len > bs { return Ok(()); }
        if off + rec_len == bs { last = off; break; }
        off += rec_len;
    }
    if last == 0 && off != 0 { return Ok(()); }
    let last_rec_len = u16::from_le_bytes([buf[last+4], buf[last+5]]) as usize;
    if last_rec_len <= 12 { return Ok(()); }
    let new_rec_len = (last_rec_len - 12) as u16;
    buf[last+4] = new_rec_len as u8;
    buf[last+5] = (new_rec_len >> 8) as u8;
    // Tail header (inode=0, rec_len=12, name_len=0, ft=0xDE,
    // csum=0) — csum filled in below. The CRC input is
    // block[..bs-12]: the whole 12-byte tail (marker + csum
    // word) is excluded from the hash, matching
    // verify_dir_block_checksum and the ext2fs_dir_block_csum_set
    // shape seen in the library decomp.
    let tail_off = bs - 12;
    buf[tail_off..tail_off+8].copy_from_slice(&[0, 0, 0, 0, 0x0C, 0, 0, 0xDE]);
    for b in &mut buf[tail_off+8..tail_off+12] { *b = 0; }
    let generation = dir_inode_generation(dev, g, ino_num)?;
    let seed = anvil_core::fs::csum_seed_for(sb);
    let num_le = ino_num.to_le_bytes();
    let gen_le = generation.to_le_bytes();
    let s1 = anvil_core::crc::crc32c_cont(seed, &num_le);
    let s2 = anvil_core::crc::crc32c_cont(s1, &gen_le);
    let csum = anvil_core::crc::crc32c_cont(s2, &buf[..bs - 12]);
    buf[bs-4] = csum as u8;
    buf[bs-3] = (csum >> 8) as u8;
    buf[bs-2] = (csum >> 16) as u8;
    buf[bs-1] = (csum >> 24) as u8;
    dev.write_at(dir_block * g.block_size as u64, &buf)
}

fn dir_inode_generation(
    dev: &mut anvil_core::io::Device,
    g: &Geometry,
    ino_num: u32,
) -> io::Result<u32> {
    let group = (ino_num as u64 - 1) / g.inodes_per_group as u64;
    let idx   = (ino_num as u64 - 1) % g.inodes_per_group as u64;
    let inode_table = crate::layout::plan_group_inode_table(g, group);
    let byte = inode_table * g.block_size as u64
        + idx * g.inode_size as u64
        + 0x64;
    let mut b = [0u8; 4];
    dev.read_at(byte, &mut b)?;
    Ok(u32::from_le_bytes(b))
}
