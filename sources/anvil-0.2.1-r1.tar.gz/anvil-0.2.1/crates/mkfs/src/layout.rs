//! The actual format pass: walks each block group, deciding where
//! the block/inode bitmaps and inode table sit, emits all the
//! metadata, and writes the root directory + lost+found.
//!
//! Per-group layout, legacy "non-flex" style (good enough for
//! Phase 1; flex_bg is a later optimisation):
//!
//!   [super + GDT (groups with backup)]
//!   [block bitmap]     1 block
//!   [inode bitmap]     1 block
//!   [inode table]      inodes_per_group * inode_size / block_size blocks
//!   [data blocks]      rest
//!
//! Group 0 additionally reserves blocks at the front for the
//! primary superblock and GDT + reserved GDT.

use crate::args::Opts;
use crate::geometry::Geometry;
use crate::writer;
use anvil_core::consts::*;
use anvil_core::group_desc::GroupDesc64;
use anvil_core::inode::{Inode, Extent, ExtentHeader};
use anvil_core::superblock::Superblock;
use std::io;

pub fn format(dev: &mut anvil_core::io::Device, g: &mut Geometry, opts: &Opts) -> io::Result<()> {
    // Pre-zero the first few MiB so no stale boot sector / partition
    // header fools the kernel probe.
    dev.zero_range(0, core::cmp::min(dev.size, 2 * 1024 * 1024))?;

    let per_group = per_group_overhead(g);

    // Decide the on-disk location of the bitmap / inode table for
    // each group up front.
    let mut groups = Vec::with_capacity(g.groups_count as usize);
    for gi in 0..g.groups_count {
        groups.push(plan_group(g, gi as u32, &per_group));
    }

    // Allocate the journal run, starting right after the two
    // root-dir data blocks. Clamp the length so the whole journal
    // lives inside group 0's data area — extending past the group
    // boundary would collide with group 1+'s block-bitmap / inode-
    // bitmap / inode-table blocks, which sit at the start of each
    // group. Supporting larger (cross-group) journals needs
    // flex_bg-style metadata clumping, which we don't emit yet.
    //
    // For ext3 (classic block-map journal inode) we also need to
    // reserve space for indirect blocks: each journal data block
    // needs a 32-bit pointer, and the inode's 12 inline direct
    // slots are nowhere near enough for a normal-sized journal.
    // We place the indirect blocks contiguously right after the
    // journal body inside group 0's data area, and fold them into
    // the same `journal_in_group` reservation the bitmap writer
    // already honours.
    let use_extents = opts.fs_type == "ext4";
    let journal_start = groups[0].first_data_block_in_group + 2;
    let group0_end = g.first_data_block as u64 + g.blocks_per_group as u64;
    let journal_cap_in_g0 = group0_end.saturating_sub(journal_start);
    // With a block-map inode every data block past the first 12
    // draws from an indirect block. Cap the journal so body +
    // metadata fit before the group boundary.
    let mut journal_len = core::cmp::min(g.journal_blocks, journal_cap_in_g0);
    let mut indirect_blocks: u64 = 0;
    if !use_extents && journal_len > 0 {
        // Shrink until body + indirect metadata fit.
        let bs = g.block_size as u64;
        loop {
            let need = count_indirect_blocks(journal_len, bs);
            if journal_len + need <= journal_cap_in_g0 {
                indirect_blocks = need;
                break;
            }
            if journal_len == 0 { break; }
            journal_len -= 1;
        }
    }
    // Publish the effective journal length back into the geometry
    // so the writer (inode 8 size / i_blocks / extents / JBD2 SB
    // maxlen) agrees with the bitmap reservation above.
    g.journal_blocks = journal_len;
    if journal_len > 0 {
        let j_end = journal_start + journal_len + indirect_blocks;
        // All of the journal sits in group 0 now, but the loop
        // stays general so the writer still sees a journal_in_group
        // entry for group 0.
        for (gi, plan) in groups.iter_mut().enumerate() {
            let gs = g.first_data_block as u64 + gi as u64 * g.blocks_per_group as u64;
            let ge = if gi as u64 + 1 == g.groups_count { g.blocks_count }
                     else { gs + g.blocks_per_group as u64 };
            let lo = core::cmp::max(journal_start, gs);
            let hi = core::cmp::min(j_end, ge);
            if lo < hi {
                let span = (hi - lo) as u32;
                plan.free_blocks = plan.free_blocks.saturating_sub(span);
                plan.journal_in_group = Some((lo, hi));
            }
        }
        groups[0].journal_indirect_blocks = indirect_blocks as u32;
    }

    // Build the superblock now that the group plan is known so
    // we can set s_free_blocks_count / s_free_inodes_count to
    // the totals across all groups.
    let total_free_blocks: u64 = groups.iter().map(|p| p.free_blocks as u64).sum();
    let total_free_inodes: u64 = groups.iter().map(|p| p.free_inodes as u64).sum();
    let mut sb = build_superblock(g, opts);
    sb.set_free_blocks(total_free_blocks);
    sb.s_free_inodes_count = total_free_inodes as u32;

    // Build the block-group descriptor table once; it's identical at
    // every backup location.
    let mut gdt = build_gdt(g, &groups);

    // Emit superblock + GDT at group 0 and backup groups.
    writer::write_sb_and_gdt(dev, g, &sb, &gdt, 0)?;
    for gi in 1..g.groups_count as u32 {
        if is_backup_group(gi) {
            writer::write_sb_and_gdt(dev, g, &sb, &gdt, gi)?;
        }
    }

    // Emit per-group bitmaps + zeroed inode tables.
    for gi in 0..g.groups_count as u32 {
        writer::write_group_metadata(dev, g, &groups[gi as usize], gi)?;
    }

    // Root directory (inode 2) + lost+found (inode 11).
    writer::write_root_and_lost_found(dev, g, &groups, use_extents)?;

    // --- Phase 7: metadata_csum finalization ---
    // If the caller enabled metadata_csum, every bitmap /
    // descriptor / inode / superblock needs its crc32c field
    // populated. We run a single finalization pass that reads
    // each structure back, computes the csum, and rewrites the
    // checksum slot in place. This lets the main format flow
    // above stay csum-agnostic: all the compute happens here at
    // the end, against freshly-written bytes.
    let want_csum = sb.s_feature_ro_compat
        & EXT4_FEATURE_RO_COMPAT_METADATA_CSUM != 0;

    // Journal (inode 8). Writing this last is safe because the
    // bitmaps in write_group_metadata already reserved the journal
    // blocks — see the `journal_start_block` computation in
    // plan_group / write_group_metadata.
    if g.journal_blocks > 0 {
        writer::write_journal(dev, g, &groups, want_csum, use_extents)?;
    }

    // If the caller passed `-d <source>`, populate the fresh
    // filesystem with that tree before the csum pass so every
    // new inode / dir block gets checksummed alongside the built-in
    // structures.
    let populate = if let Some(src) = opts.source_dir.as_ref() {
        Some(writer::populate_from_dir(dev, g, &mut sb, &mut gdt, &groups, src)?)
    } else {
        None
    };

    if want_csum {
        writer::finalize_metadata_csums(
            dev, g, &mut sb, &mut gdt, &groups, populate.as_ref())?;
    } else if populate.is_some() {
        // Even without metadata_csum we still need to re-emit the
        // superblock + GDT because populate_from_dir updated the
        // in-memory free-blocks / free-inodes counters and the new
        // used_dirs value.
        writer::write_sb_and_gdt(dev, g, &sb, &gdt, 0)?;
        for gi in 1..g.groups_count as u32 {
            if is_backup_group(gi) {
                writer::write_sb_and_gdt(dev, g, &sb, &gdt, gi)?;
            }
        }
    }

    Ok(())
}

pub struct GroupPlan {
    pub block_bitmap_block: u64,
    pub inode_bitmap_block: u64,
    pub inode_table_block:  u64,
    pub free_blocks:        u32,
    pub free_inodes:        u32,
    pub used_dirs:          u32,
    pub first_data_block_in_group: u64,  // first block available to file data
    // Range of blocks inside this group that belong to the journal
    // (half-open, absolute block numbers). None if the journal
    // doesn't cross this group.
    pub journal_in_group:   Option<(u64, u64)>,
    /// How many of the tail blocks in `journal_in_group` are
    /// inode-8 indirect pointers rather than journal body. Used
    /// by writer::write_journal on the classic block-map path to
    /// split the reservation into body + metadata. Always zero
    /// on the ext4 (extents) path.
    pub journal_indirect_blocks: u32,
}

pub struct PerGroupOverhead {
    pub gdt_blocks:          u64,
    pub reserved_gdt_blocks: u64,
    pub inode_table_blocks:  u64,
}

pub fn per_group_overhead(g: &Geometry) -> PerGroupOverhead {
    let descs_per_block = g.block_size as u64 / g.desc_size as u64;
    let gdt_blocks = g.groups_count.div_ceil(descs_per_block);
    let inode_table_blocks = (g.inodes_per_group as u64 * g.inode_size as u64)
        .div_ceil(g.block_size as u64);
    PerGroupOverhead {
        gdt_blocks,
        reserved_gdt_blocks: g.reserved_gdt_blocks as u64,
        inode_table_blocks,
    }
}

fn plan_group(g: &Geometry, gi: u32, pg: &PerGroupOverhead) -> GroupPlan {
    let group_start = g.first_data_block as u64 + gi as u64 * g.blocks_per_group as u64;
    let group_blocks = if gi == (g.groups_count - 1) as u32 {
        g.blocks_count - group_start
    } else {
        g.blocks_per_group as u64
    };

    let has_sb_backup = gi == 0 || is_backup_group(gi);
    let sb_gdt_blocks = if has_sb_backup {
        1 /* sb */ + pg.gdt_blocks + pg.reserved_gdt_blocks
    } else {
        0
    };

    // On a 1024-block-size filesystem group 0's superblock sits in
    // block 1, so the reservation starts at block 1 and fills 1 +
    // gdt + reserved. On larger block sizes the superblock shares
    // block 0 with the boot block area and sb_gdt_blocks counts from
    // block 0 of the group.
    let meta_base = group_start + sb_gdt_blocks;
    let block_bitmap_block = meta_base;
    let inode_bitmap_block = meta_base + 1;
    let inode_table_block  = meta_base + 2;
    let first_data         = inode_table_block + pg.inode_table_blocks;

    let used_meta = first_data - group_start;
    // Group 0 burns two extra data blocks on the root directory
    // and lost+found; the bitmap writer marks both as used.
    let used_dirs_blocks = if gi == 0 { 2 } else { 0 };
    let free_blocks = (group_blocks - used_meta - used_dirs_blocks) as u32;
    let free_inodes = g.inodes_per_group;
    // Reserve inode 0 (unused), 1..10 (reserved), and inode 11
    // (lost+found) in group 0. Elsewhere all inodes are free.
    let used_inodes = if gi == 0 { EXT4_FIRST_NON_RSV_INO } else { 0 };

    GroupPlan {
        block_bitmap_block,
        inode_bitmap_block,
        inode_table_block,
        free_blocks,
        free_inodes: free_inodes - used_inodes,
        used_dirs: if gi == 0 { 2 } else { 0 }, // /, /lost+found
        first_data_block_in_group: first_data,
        journal_in_group: None,
        journal_indirect_blocks: 0,
    }
}

/// Reconstruct the inode-table block for a given group without
/// touching the in-memory GDT. Used by the Phase-7 csum
/// finalization when it needs to locate an inode slot directly.
pub fn plan_group_inode_table(g: &Geometry, gi: u64) -> u64 {
    let per_group = per_group_overhead(g);
    let group_start = g.first_data_block as u64 + gi * g.blocks_per_group as u64;
    let has_sb_backup = gi == 0 || is_backup_group(gi as u32);
    let sb_gdt_blocks = if has_sb_backup {
        1 + per_group.gdt_blocks + per_group.reserved_gdt_blocks
    } else {
        0
    };
    let meta_base = group_start + sb_gdt_blocks;
    meta_base + 2 // block bitmap + inode bitmap, then inode table
}

pub fn is_backup_group(gi: u32) -> bool {
    // With SPARSE_SUPER, groups 0, 1, and powers of 3/5/7 get a
    // superblock backup. We always include SPARSE_SUPER.
    if gi == 0 || gi == 1 { return true; }
    let mut p: u64 = 3;
    while p <= gi as u64 {
        if p == gi as u64 { return true; }
        p *= 3;
    }
    let mut p: u64 = 5;
    while p <= gi as u64 {
        if p == gi as u64 { return true; }
        p *= 5;
    }
    let mut p: u64 = 7;
    while p <= gi as u64 {
        if p == gi as u64 { return true; }
        p *= 7;
    }
    false
}

fn build_superblock(g: &Geometry, opts: &Opts) -> Superblock {
    let now = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_secs() as u32)
        .unwrap_or(0);

    let mut sb = Superblock::zeroed();
    sb.s_inodes_count = g.inodes_count as u32;
    sb.set_blocks_count(g.blocks_count);
    sb.set_reserved_blocks(g.reserved_blocks);
    // free-blocks / free-inodes are refined below after subtracting
    // per-group overhead; for a fresh fs they equal the sum across
    // groups of the plan's free counts.
    sb.s_first_data_block = g.first_data_block;
    sb.s_log_block_size = g.log_block_size;
    sb.s_log_cluster_size = g.log_block_size;
    sb.s_blocks_per_group = g.blocks_per_group;
    sb.s_clusters_per_group = g.blocks_per_group;
    sb.s_inodes_per_group = g.inodes_per_group;
    sb.s_mtime = 0;
    sb.s_wtime = now;
    sb.s_mnt_count = 0;
    sb.s_max_mnt_count = u16::MAX;
    sb.s_magic = EXT4_SUPER_MAGIC;
    sb.s_state = EXT4_VALID_FS;
    sb.s_errors = EXT4_ERRORS_CONTINUE;
    sb.s_creator_os = EXT4_OS_LINUX;
    sb.s_rev_level = EXT4_DYNAMIC_REV;
    sb.s_first_ino = EXT4_FIRST_NON_RSV_INO;
    sb.s_inode_size = g.inode_size;
    sb.s_uuid = g.uuid;
    let label = opts.label.as_bytes();
    let n = core::cmp::min(label.len(), 16);
    sb.s_volume_name[..n].copy_from_slice(&label[..n]);
    sb.s_hash_seed = g.hash_seed;
    sb.s_def_hash_version = 1; // half-md4
    sb.s_desc_size = g.desc_size;
    sb.s_mkfs_time = now;
    sb.s_lastcheck = now;
    sb.s_checkinterval = 0;
    // s_reserved_gdt_blocks is only meaningful when RESIZE_INODE
    // is enabled (e2fsck errors otherwise). Phase 1 has no resize
    // inode so keep it zero.
    // extra_isize fields only make sense for 256-byte inodes with
    // the EXTRA_ISIZE ro-compat bit. ext2/ext3 default to 128-byte
    // inodes (no slack), so keep these zero there.
    let ext4_extras = opts.fs_type == "ext4";
    if ext4_extras {
        sb.s_reserved_gdt_blocks = 0;
        sb.s_min_extra_isize = 32;
        sb.s_want_extra_isize = 32;
    } else {
        sb.s_reserved_gdt_blocks = 0;
        sb.s_min_extra_isize = 0;
        sb.s_want_extra_isize = 0;
    }

    // Feature bit selection is fs_type-gated. ext2 advertises only
    // SPARSE_SUPER (RO_COMPAT) + FILETYPE (INCOMPAT); ext3 is ext2
    // plus HAS_JOURNAL. ext4 keeps the full modern set — EXTENTS,
    // 64BIT, HUGE_FILE, DIR_NLINK, EXTRA_ISIZE, LARGE_FILE.
    // Values come straight from the public kernel docs.
    match opts.fs_type.as_str() {
        "ext2" => {
            sb.s_feature_compat = 0;
            sb.s_feature_incompat = EXT4_FEATURE_INCOMPAT_FILETYPE;
            sb.s_feature_ro_compat = EXT4_FEATURE_RO_COMPAT_SPARSE_SUPER;
        }
        "ext3" => {
            sb.s_feature_compat = 0;
            sb.s_feature_incompat = EXT4_FEATURE_INCOMPAT_FILETYPE;
            sb.s_feature_ro_compat = EXT4_FEATURE_RO_COMPAT_SPARSE_SUPER;
            if opts.journal && g.journal_blocks > 0 {
                sb.s_feature_compat |= EXT4_FEATURE_COMPAT_HAS_JOURNAL;
                sb.s_journal_inum = EXT4_JOURNAL_INO;
            }
        }
        _ => {
            // ext4 baseline. HAS_JOURNAL flips on when the caller
            // opts in; s_journal_inum is filled in after the
            // journal chunk has been allocated. Only advertise
            // HAS_JOURNAL if we actually reserved room for the
            // journal — on very small images geometry::compute
            // drops the journal to 0 blocks, and an SB claiming
            // HAS_JOURNAL with no reserved space would fail
            // upstream e2fsck.
            sb.s_feature_compat =
                EXT4_FEATURE_COMPAT_EXT_ATTR |
                EXT4_FEATURE_COMPAT_DIR_INDEX;
            if opts.journal && g.journal_blocks > 0 {
                sb.s_feature_compat |= EXT4_FEATURE_COMPAT_HAS_JOURNAL;
                sb.s_journal_inum = EXT4_JOURNAL_INO;
            }
            sb.s_feature_incompat =
                EXT4_FEATURE_INCOMPAT_FILETYPE |
                EXT4_FEATURE_INCOMPAT_EXTENTS |
                EXT4_FEATURE_INCOMPAT_64BIT;
            sb.s_feature_ro_compat =
                EXT4_FEATURE_RO_COMPAT_SPARSE_SUPER |
                EXT4_FEATURE_RO_COMPAT_LARGE_FILE |
                EXT4_FEATURE_RO_COMPAT_HUGE_FILE |
                EXT4_FEATURE_RO_COMPAT_DIR_NLINK |
                EXT4_FEATURE_RO_COMPAT_EXTRA_ISIZE;
        }
    }

    // Opt-in metadata_csum feature: flips on
    // EXT4_FEATURE_RO_COMPAT_METADATA_CSUM + CRC32C checksum
    // type. Every written descriptor / bitmap / inode then gets
    // its crc32c field filled so upstream e2fsck re-verifies
    // cleanly. Caller asks via `-O metadata_csum` on the mkfs
    // command line.
    if opts.features_on.iter().any(|f| f == "metadata_csum") {
        sb.s_feature_ro_compat |= EXT4_FEATURE_RO_COMPAT_METADATA_CSUM;
        sb.s_checksum_type = EXT4_CRC32C_CHKSUM;
    }

    // Opt-in inline_data feature: stores small file contents
    // directly in i_block[] (and inline xattr area), no data
    // block allocation. Caller asks via -O inline_data.
    if opts.features_on.iter().any(|f| f == "inline_data") {
        sb.s_feature_incompat |= EXT4_FEATURE_INCOMPAT_INLINE_DATA;
    }


    sb.s_lpf_ino = EXT4_FIRST_NON_RSV_INO; // lost+found inode 11
    sb.s_default_mount_opts = 0;
    sb.s_first_meta_bg = 0;

    // free counts filled in by caller after plan_group sweep
    sb
}

fn build_gdt(_g: &Geometry, groups: &[GroupPlan]) -> Vec<GroupDesc64> {
    let mut out = Vec::with_capacity(groups.len());
    for p in groups {
        let mut d = GroupDesc64::default();
        d.set_block_bitmap(p.block_bitmap_block);
        d.set_inode_bitmap(p.inode_bitmap_block);
        d.set_inode_table(p.inode_table_block);
        d.set_free_blocks(p.free_blocks);
        d.set_free_inodes(p.free_inodes);
        d.set_used_dirs(p.used_dirs);
        // itable_unused is an optimisation backed by the GDT_CSUM
        // feature. Without that feature set, e2fsck treats any
        // non-zero value as "descriptor marked uninitialized" and
        // errors. We leave it at zero — the whole inode table is
        // zeroed by write_group_metadata so the kernel sees every
        // slot as a valid free inode.
        d.set_itable_unused(0);
        out.push(d);
    }
    out
}

pub fn build_root_inode(g: &Geometry, block: u64, use_extents: bool) -> Inode {
    let mut ino = Inode::default();
    ino.i_mode = S_IFDIR | 0o755;
    ino.i_uid = 0;
    ino.i_gid = 0;
    ino.i_links_count = 3; // ., .., /lost+found
    ino.set_size(g.block_size as u64);
    ino.i_blocks_lo = (g.block_size / 512) as u32;
    let now = now_u32();
    ino.i_atime = now; ino.i_ctime = now; ino.i_mtime = now;
    if use_extents {
        ino.i_flags = EXT4_EXTENTS_FL;
        write_single_extent(&mut ino, block, 1);
        ino.i_extra_isize = 32;
        ino.i_crtime = now;
    } else {
        // Classic ext2/ext3 block-map layout: i_block[0] holds the
        // (32-bit) physical block number of the one data block
        // we allocated. The rest of i_block stays zero — no
        // indirect blocks needed for a one-block directory.
        ino.i_flags = 0;
        ino.i_block[0] = block as u32;
    }
    ino
}

pub fn build_lf_inode(g: &Geometry, block: u64, use_extents: bool) -> Inode {
    let mut ino = Inode::default();
    ino.i_mode = S_IFDIR | 0o700;
    ino.i_links_count = 2;
    ino.set_size(g.block_size as u64);
    ino.i_blocks_lo = (g.block_size / 512) as u32;
    let now = now_u32();
    ino.i_atime = now; ino.i_ctime = now; ino.i_mtime = now;
    if use_extents {
        ino.i_flags = EXT4_EXTENTS_FL;
        write_single_extent(&mut ino, block, 1);
        ino.i_extra_isize = 32;
        ino.i_crtime = now;
    } else {
        ino.i_flags = 0;
        ino.i_block[0] = block as u32;
    }
    ino
}

/// Fill i_block with a one-entry extent tree pointing to
/// [physical_start, physical_start+len). This is the simplest valid
/// ext4 extent layout.
fn write_single_extent(ino: &mut Inode, physical_start: u64, len: u16) {
    let hdr = ExtentHeader {
        eh_magic: EXT4_EXT_MAGIC,
        eh_entries: 1,
        eh_max: 4,
        eh_depth: 0,
        eh_generation: 0,
    };
    let mut ext = Extent {
        ee_block: 0,
        ee_len: len,
        ee_start_hi: 0,
        ee_start_lo: 0,
    };
    ext.set_start(physical_start);

    // i_block is [u32; 15] = 60 bytes. Layout: 12-byte header, 4
    // 12-byte extents. We use one extent. i_block is inside a
    // packed struct so we must go through a raw pointer to avoid
    // materialising an unaligned reference.
    unsafe {
        let base = core::ptr::addr_of_mut!(ino.i_block) as *mut u8;
        core::ptr::write_unaligned(base as *mut ExtentHeader, hdr);
        core::ptr::write_unaligned(base.add(12) as *mut Extent, ext);
    }
}

pub fn now_u32() -> u32 {
    std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_secs() as u32)
        .unwrap_or(0)
}

/// How many indirect / double-indirect / triple-indirect blocks
/// a classic block-map inode needs to reach `data_blocks` data
/// blocks on a filesystem with `bs`-byte blocks. Matches the
/// scheme the ext2/3 kernel reads — 12 direct pointers, then a
/// single-indirect block covering `p = bs/4` pointers, then a
/// double-indirect (1 L1 + ⌈r/p⌉ L2 blocks), then a triple-
/// indirect (1 L1 + ⌈r/p⌉ L2 + ⌈r/(p*p)⌉ L3).
pub fn count_indirect_blocks(data_blocks: u64, bs: u64) -> u64 {
    let p = bs / 4;
    let mut remaining = data_blocks;
    let mut meta = 0u64;
    // direct
    let take = core::cmp::min(remaining, 12);
    remaining -= take;
    if remaining == 0 { return meta; }
    // single indirect
    meta += 1;
    let take = core::cmp::min(remaining, p);
    remaining -= take;
    if remaining == 0 { return meta; }
    // double indirect: 1 L1 + per-L2
    meta += 1;
    let take = core::cmp::min(remaining, p * p);
    let l2 = take.div_ceil(p);
    meta += l2;
    remaining -= take;
    if remaining == 0 { return meta; }
    // triple indirect: 1 L1 + per-L2 + per-L3
    meta += 1;
    let l2 = remaining.div_ceil(p * p);
    meta += l2;
    let l3 = remaining.div_ceil(p);
    meta += l3;
    meta
}
