//! mkfs.ext4 — anvil's ext4 formatter. Writes a minimal but
//! kernel-mountable and `e2fsck -fn`-clean ext4 filesystem.
//!
//! Phase 1 scope: no journal (ext2-clean layout tagged as ext4 via
//! incompat features EXTENTS|FILETYPE|64BIT). The kernel will mount
//! this read-write and e2fsck will pass. Journal support and
//! metadata_csum come in Phase 1.5 once the no-journal path is
//! verified end-to-end.

use std::process::ExitCode;

mod geometry;
mod layout;
mod writer;
mod args;

fn main() -> ExitCode {
    // The same binary is installed as mkfs.ext2 / mkfs.ext3 /
    // mkfs.ext4 (with Cargo bin names mkfs_ext2/3/4 -- '.' is not
    // legal in a Cargo target name). Pick the default fs_type from
    // argv[0] so that invoking via the ext2 or ext3 name yields
    // the right on-disk feature set. An explicit `-t` on the command
    // line still wins because the user's args come after ours and
    // the last `-t` assignment takes effect.
    let argv0 = std::env::args().next().unwrap_or_default();
    let basename = std::path::Path::new(&argv0)
        .file_name()
        .map(|s| s.to_string_lossy().into_owned())
        .unwrap_or_default();
    let default_fs_type = if basename.ends_with("ext2") {
        Some("ext2")
    } else if basename.ends_with("ext3") {
        Some("ext3")
    } else if basename.ends_with("ext4") {
        Some("ext4")
    } else {
        None
    };

    let mut raw: Vec<String> = Vec::new();
    if let Some(t) = default_fs_type {
        raw.push("-t".into());
        raw.push(t.into());
    }
    raw.extend(std::env::args().skip(1));

    let opts = match args::parse(raw) {
        Ok(o) => o,
        Err(msg) => {
            eprintln!("mkfs.ext4: {msg}");
            return ExitCode::from(1);
        }
    };

    match run(opts) {
        Ok(()) => ExitCode::from(0),
        Err(e) => {
            eprintln!("mkfs.ext4: {e}");
            ExitCode::from(1)
        }
    }
}

fn run(opts: args::Opts) -> std::io::Result<()> {
    // When --image-size is set and the target is a regular file,
    // ensure it exists and is at least the requested size. If the
    // file already exists and is >= the requested size, leave its
    // contents alone (Device::open will read the actual length).
    // If it doesn't exist, create it; if it's too small, extend it.
    // Block devices are never truncated — a size mismatch there is
    // a configuration error, not something we should silently "fix".
    if let Some(want) = opts.image_size {
        match std::fs::metadata(&opts.device) {
            Ok(md) if md.file_type().is_file() => {
                if md.len() < want {
                    let f = std::fs::OpenOptions::new()
                        .write(true)
                        .open(&opts.device)?;
                    f.set_len(want)?;
                }
            }
            Ok(_) => {
                // Block device / char device / etc. — leave alone.
            }
            Err(e) if e.kind() == std::io::ErrorKind::NotFound => {
                let f = std::fs::OpenOptions::new()
                    .write(true)
                    .create(true)
                    .truncate(false)
                    .open(&opts.device)?;
                f.set_len(want)?;
            }
            Err(e) => return Err(e),
        }
    }

    let mut dev = anvil_core::io::Device::open(&opts.device)?;

    let mut geom = geometry::compute(&opts, dev.size)?;
    if !opts.quiet {
        print_banner(&opts, &geom);
    }

    layout::format(&mut dev, &mut geom, &opts)?;
    dev.sync()?;

    if !opts.quiet {
        println!("Writing superblocks: done");
    }
    Ok(())
}

fn print_banner(opts: &args::Opts, g: &geometry::Geometry) {
    println!("mke2fs 1.47.3-anvil");
    println!();
    println!("Creating filesystem with {} {}-byte blocks and {} inodes",
             g.blocks_count, g.block_size, g.inodes_count);
    if !opts.label.is_empty() {
        println!("Filesystem label={}", opts.label);
    }
    println!("Filesystem UUID: {}", anvil_core::uuid::format(&g.uuid));
    println!();
}

