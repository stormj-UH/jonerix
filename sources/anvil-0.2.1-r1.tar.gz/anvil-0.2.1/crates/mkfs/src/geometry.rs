//! Filesystem geometry — block size, group count, inode count. All
//! choices here mirror the mke2fs defaults so the result is
//! byte-compatible with the reference implementation for typical
//! inputs.

use crate::args::Opts;
use std::io;

pub struct Geometry {
    pub block_size:         u32,
    pub log_block_size:     u32,     // log2(block_size / 1024)
    pub blocks_count:       u64,
    pub inodes_count:       u64,
    pub blocks_per_group:   u32,
    pub inodes_per_group:   u32,
    pub groups_count:       u64,
    pub inode_size:         u16,
    pub reserved_blocks:    u64,
    pub uuid:               [u8; 16],
    pub hash_seed:          [u32; 4],
    pub first_data_block:   u32,
    pub desc_size:          u16,     // 64 if 64BIT feature on
    pub reserved_gdt_blocks: u16,
    pub journal_blocks:      u64,    // 0 = no journal — u64 so large journals don't overflow
}

pub fn compute(opts: &Opts, device_bytes: u64) -> io::Result<Geometry> {
    // 1. Block size: default is 4 KiB on anything ≥ 512 MiB. Smaller
    //    devices step down to 1 KiB. User `-b` wins.
    let block_size = opts.block_size.unwrap_or_else(|| {
        if device_bytes < 512 * 1024 * 1024 { 1024 } else { 4096 }
    });
    if !block_size.is_power_of_two() || !(1024..=65536).contains(&block_size) {
        return Err(io::Error::new(io::ErrorKind::InvalidInput, "bad block size"));
    }
    let log_block_size = (block_size / 1024).trailing_zeros();

    // 2. Total blocks on the device, rounded down.
    let blocks_count = device_bytes / block_size as u64;

    // 3. Group layout. Each block group covers blocks_per_group = 8 *
    //    block_size (one block's worth of bitmap bits). Inodes per
    //    group fall out of the inode_ratio / num_inodes choice.
    let blocks_per_group: u32 = block_size * 8;
    let groups_count = blocks_count.div_ceil(blocks_per_group as u64);

    // 4. Inode count. Default ratio = 1 inode per 16 KiB (mke2fs
    //    default for the "default" usage type). User `-N` and `-i`
    //    override.
    let inodes_total = if let Some(n) = opts.num_inodes {
        n
    } else {
        let ratio = opts.inode_ratio.unwrap_or(16384) as u64;
        core::cmp::max(groups_count * 16, device_bytes / ratio)
    };

    // Round up inodes-per-group so (ipg * groups) >= inodes_total,
    // then also align to a multiple of (block_size / inode_size) so
    // the inode table fits on whole blocks.
    let inode_size = opts.inode_size;
    let inodes_per_block = block_size as u64 / inode_size as u64;
    let mut ipg = inodes_total.div_ceil(groups_count) as u32;
    let ipg_align = inodes_per_block as u32;
    ipg = (ipg + ipg_align - 1) / ipg_align * ipg_align;
    // Cap at 8 * block_size so bitmap fits in one block.
    if ipg > blocks_per_group { ipg = blocks_per_group; }

    let inodes_count = ipg as u64 * groups_count;

    // 5. Reserved blocks — default 5%.
    let reserved_blocks = blocks_count * opts.reserved_pct as u64 / 100;

    // 6. UUID + hash seed: random unless -U given.
    let uuid = opts.uuid.unwrap_or_else(anvil_core::uuid::v4);
    let mut seed = [0u32; 4];
    for s in &mut seed {
        let r = anvil_core::uuid::v4();
        *s = u32::from_le_bytes([r[0], r[1], r[2], r[3]]);
    }

    // 7. 64BIT feature is on by default for ext4 → desc_size = 64.
    //    ext2/ext3 do NOT set INCOMPAT_64BIT, so they must use the
    //    legacy 32-byte descriptor. Emitting 64-byte descriptors
    //    without the 64BIT feature makes e2fsck read bg_block_bitmap_lo
    //    for group 1+ out of the (zero) _hi tail of the previous
    //    descriptor.
    let desc_size: u16 = match opts.fs_type.as_str() {
        "ext2" | "ext3" => 32,
        _ => 64,
    };

    // 8. first_data_block: 1 if block_size == 1024, else 0. Because
    //    the superblock at byte 1024 consumes block 0 on 1K-block
    //    filesystems and block-0's upper half on larger blocks.
    let first_data_block = if block_size == 1024 { 1 } else { 0 };

    // 9. Reserved GDT blocks for future online resize. mke2fs
    //    computes this as min(nr_groups * 256 / 32, block_size / 4
    //    * 256) — we match the common-case value.
    // Phase 1 skips RESIZE_INODE, so there's no point reserving
    // GDT slots we can never fill. Keep at zero until resize works.
    let _ = compute_reserved_gdt;
    let reserved_gdt_blocks = 0u16;

    // 10. Journal sizing. mke2fs' formula:
    //      min( max(1024, filesystem_blocks / 64), 32768 * 4096 / block_size )
    //    which gives ~1/64 the filesystem, clamped to [4 MiB, 128 MiB
    //    on 4 K blocks]. Zero out if --no-journal.
    // Journals only make sense on filesystems big enough to spare
    // the reservation. mke2fs refuses below ~8 MiB; match that and
    // silently drop to ext2 layout otherwise so tiny loopback
    // images still mkfs cleanly.
    let min_journal_fs_bytes = 8 * 1024 * 1024;
    // Hard ceiling: the inode's inline extent tree holds 4 extents
    // max and each extent covers at most 32 768 blocks. Anything
    // bigger would need a two-level extent tree on inode 8, which
    // we don't emit yet. On 4-KiB blocks that's 512 MiB of journal.
    let extent_cap_blocks: u64 = 4 * 32_768;
    let journal_blocks: u64 = if opts.journal && device_bytes >= min_journal_fs_bytes {
        let raw = if opts.journal_size_mib > 0 {
            // Explicit `-J size=N` (MiB).
            (opts.journal_size_mib as u64) * 1024 * 1024 / block_size as u64
        } else {
            let one_64th = blocks_count / 64;
            let min: u64 = 1024;
            let max: u64 = ((131_072u64 * 1024) / block_size as u64) * 4;
            one_64th.clamp(min, max)
        };
        let quarter = blocks_count / 4;
        raw.min(quarter).min(extent_cap_blocks)
    } else {
        0
    };

    Ok(Geometry {
        block_size,
        log_block_size,
        blocks_count,
        inodes_count,
        blocks_per_group,
        inodes_per_group: ipg,
        groups_count,
        inode_size,
        reserved_blocks,
        uuid,
        hash_seed: seed,
        first_data_block,
        desc_size,
        reserved_gdt_blocks,
        journal_blocks,
    })
}

fn compute_reserved_gdt(blocks_count: u64, block_size: u32, groups: u64, desc_size: u16) -> u16 {
    // Room to grow the filesystem by ~1024x without needing meta_bg.
    // Bounded by the number of GDT entries that fit in a single block
    // minus the ones already in use.
    let descs_per_block = block_size as u64 / desc_size as u64;
    let current_gdt_blocks = groups.div_ceil(descs_per_block);
    let max_gdt_blocks = (blocks_count.saturating_mul(1024) / blocks_count.max(1))
        .div_ceil(descs_per_block);
    let rsv = max_gdt_blocks.saturating_sub(current_gdt_blocks);
    core::cmp::min(rsv, u16::MAX as u64) as u16
}
