//! Command-line option parsing. Mirrors the subset of mke2fs(8)
//! options the real-world callers (debootstrap, installers,
//! `systemd-repart`) actually use.

use std::path::PathBuf;

pub struct Opts {
    pub device: PathBuf,
    pub label: String,
    pub uuid: Option<[u8; 16]>,
    pub block_size: Option<u32>,
    pub inode_size: u16,
    /// Whether the user passed `-I` explicitly. When false,
    /// build_superblock is free to pick an fs_type-appropriate
    /// default (128 for ext2/ext3, 256 for ext4).
    pub inode_size_explicit: bool,
    pub inode_ratio: Option<u32>,   // bytes per inode
    pub num_inodes: Option<u64>,
    pub reserved_pct: u32,
    pub quiet: bool,
    pub force: bool,
    pub image_size: Option<u64>,    // for regular-file images
    pub fs_type: String,            // "ext4", "ext2", "ext3"
    pub journal: bool,
    pub features_on: Vec<String>,
    pub features_off: Vec<String>,
    /// Explicit journal size in MiB (`-J size=N`). Zero means
    /// "pick the default based on fs size".
    pub journal_size_mib: u32,
    /// Blocks-per-flex-group (`-G`). 0 keeps our default.
    pub flex_group: u32,
    /// When set, populate the freshly-formatted fs from this
    /// local directory tree (`-d <path>`).
    pub source_dir: Option<PathBuf>,
}

impl Default for Opts {
    fn default() -> Self {
        Opts {
            device: PathBuf::new(),
            label: String::new(),
            uuid: None,
            block_size: None,
            inode_size: 256,
            inode_size_explicit: false,
            inode_ratio: None,
            num_inodes: None,
            reserved_pct: 5,
            quiet: false,
            force: false,
            image_size: None,
            fs_type: "ext4".into(),
            journal: true,
            features_on: Vec::new(),
            features_off: Vec::new(),
            journal_size_mib: 0,
            flex_group: 0,
            source_dir: None,
        }
    }
}

pub fn parse(args: Vec<String>) -> Result<Opts, String> {
    let mut o = Opts::default();
    let mut i = 0;
    while i < args.len() {
        let a = &args[i];
        match a.as_str() {
            "-L" => {
                i += 1;
                let v = next(&args, i)?;
                if v.as_bytes().contains(&0u8) {
                    eprintln!("mkfs.ext4: error: label contains NUL byte");
                    return Err("label contains NUL byte".to_string());
                }
                if v.as_bytes().len() > 16 {
                    eprintln!("mkfs.ext4: warning: label truncated to 16 bytes");
                    o.label = String::from_utf8_lossy(&v.as_bytes()[..16]).into_owned();
                } else {
                    o.label = v;
                }
            }
            "-U" => {
                i += 1;
                o.uuid = Some(parse_uuid(&next(&args, i)?)?);
            }
            "-b" => {
                i += 1;
                o.block_size = Some(next(&args, i)?.parse().map_err(|_| "bad -b".to_string())?);
            }
            "-I" => {
                i += 1;
                o.inode_size = next(&args, i)?.parse().map_err(|_| "bad -I".to_string())?;
                o.inode_size_explicit = true;
            }
            "-i" => {
                i += 1;
                o.inode_ratio = Some(next(&args, i)?.parse().map_err(|_| "bad -i".to_string())?);
            }
            "-N" => {
                i += 1;
                o.num_inodes = Some(next(&args, i)?.parse().map_err(|_| "bad -N".to_string())?);
            }
            "-m" => {
                i += 1;
                o.reserved_pct = next(&args, i)?.parse().map_err(|_| "bad -m".to_string())?;
            }
            "-q" => { o.quiet = true; }
            "-F" => { o.force = true; }
            "-t" => { i += 1; o.fs_type = next(&args, i)?; }
            "-J" => {
                // Parse the comma-separated key=value pairs and
                // honour `size=N` (MiB). Silently ignore anything
                // else so installers passing `device=external` etc.
                // don't break.
                i += 1;
                for kv in next(&args, i)?.split(',') {
                    if let Some(v) = kv.strip_prefix("size=") {
                        o.journal_size_mib = v.parse().map_err(|_| "bad -J size".to_string())?;
                    }
                }
            }
            "-d" => {
                i += 1;
                o.source_dir = Some(PathBuf::from(next(&args, i)?));
            }
            "-G" => {
                i += 1;
                o.flex_group = next(&args, i)?.parse()
                    .map_err(|_| "bad -G".to_string())?;
            }
            "-O" => {
                i += 1;
                for f in next(&args, i)?.split(',') {
                    let f = f.trim();
                    if let Some(name) = f.strip_prefix('^') {
                        o.features_off.push(name.to_string());
                    } else {
                        o.features_on.push(f.to_string());
                    }
                }
            }
            "-E" => { i += 1; let _ = next(&args, i); /* extended opts, ignored */ }
            "-T" => { i += 1; let _ = next(&args, i); /* usage-type, ignored */ }
            "-V" => {
                println!("mke2fs 1.47.3-anvil (MIT)");
                std::process::exit(0);
            }
            "--image-size" => {
                i += 1;
                o.image_size = Some(parse_size(&next(&args, i)?)
                    .map_err(|_| "bad --image-size".to_string())?);
            }
            _ if a.starts_with('-') => {
                return Err(format!("unknown option {a}"));
            }
            _ => {
                if o.device.as_os_str().is_empty() {
                    o.device = PathBuf::from(a);
                } else if o.image_size.is_none() {
                    // second positional: block-count, convert to bytes later
                    let blocks: u64 = a.parse().map_err(|_| format!("bad block count {a}"))?;
                    o.image_size = Some(blocks * 1024);
                }
            }
        }
        i += 1;
    }

    if o.device.as_os_str().is_empty() {
        return Err("missing device".into());
    }

    // fs_type gate
    if matches!(o.fs_type.as_str(), "ext2") {
        o.journal = false;
    }
    // ext2/ext3 default to a 128-byte inode (the pre-EXTRA_ISIZE
    // on-disk size) unless the user explicitly chose one with -I.
    // ext4 keeps the 256-byte default because it needs room for
    // i_extra_isize + i_crtime + checksum fields.
    if !o.inode_size_explicit
        && matches!(o.fs_type.as_str(), "ext2" | "ext3")
    {
        o.inode_size = 128;
    }
    Ok(o)
}

fn next(a: &[String], i: usize) -> Result<String, String> {
    a.get(i).cloned().ok_or_else(|| "missing argument".into())
}

/// Parse a byte count with optional K/M/G suffix (case-insensitive,
/// powers of 1024). No suffix = raw bytes.
pub(crate) fn parse_size(s: &str) -> Result<u64, String> {
    let s = s.trim();
    if s.is_empty() {
        return Err("empty size".into());
    }
    let (num, mult): (&str, u64) = match s.as_bytes().last().copied() {
        Some(b'K') | Some(b'k') => (&s[..s.len() - 1], 1024),
        Some(b'M') | Some(b'm') => (&s[..s.len() - 1], 1024 * 1024),
        Some(b'G') | Some(b'g') => (&s[..s.len() - 1], 1024 * 1024 * 1024),
        _ => (s, 1),
    };
    let n: u64 = num.parse().map_err(|_| format!("bad size {s}"))?;
    n.checked_mul(mult).ok_or_else(|| format!("size overflow {s}"))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parse_size_bytes_and_suffixes() {
        assert_eq!(parse_size("0").unwrap(), 0);
        assert_eq!(parse_size("1024").unwrap(), 1024);
        assert_eq!(parse_size("8M").unwrap(), 8 * 1024 * 1024);
        assert_eq!(parse_size("8m").unwrap(), 8 * 1024 * 1024);
        assert_eq!(parse_size("2K").unwrap(), 2048);
        assert_eq!(parse_size("1G").unwrap(), 1024 * 1024 * 1024);
        assert!(parse_size("nope").is_err());
        assert!(parse_size("").is_err());
    }

    #[test]
    fn block_size_override_always_wins_over_geometry_default() {
        // The user passing `-b 1024` on a big image must survive
        // parsing so geometry::compute uses 1 KiB — not the 4 KiB
        // the default picker would choose on a >= 512 MiB image.
        let argv = vec!["-b".into(), "1024".into(), "/tmp/x.img".into()];
        let o = parse(argv).unwrap();
        assert_eq!(o.block_size, Some(1024));
        assert_eq!(o.device, std::path::PathBuf::from("/tmp/x.img"));
    }

    #[test]
    fn image_size_with_suffix_parses() {
        let argv = vec!["--image-size".into(), "8M".into(), "/tmp/x.img".into()];
        let o = parse(argv).unwrap();
        assert_eq!(o.image_size, Some(8 * 1024 * 1024));
    }
}

fn parse_uuid(s: &str) -> Result<[u8; 16], String> {
    match s {
        "random" => return Ok(anvil_core::uuid::v4()),
        "time" => return Ok(anvil_core::uuid::v1_like()),
        "clear" => return Ok(anvil_core::uuid::zero()),
        _ => {}
    }
    let clean: String = s.chars().filter(|c| c.is_ascii_hexdigit()).collect();
    if clean.len() != 32 {
        return Err("UUID must have 32 hex digits".into());
    }
    let mut out = [0u8; 16];
    for k in 0..16 {
        out[k] = u8::from_str_radix(&clean[k * 2..k * 2 + 2], 16)
            .map_err(|_| "bad UUID".to_string())?;
    }
    Ok(out)
}
