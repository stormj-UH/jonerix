//! tune2fs — toggle superblock settings on a mounted-or-unmounted
//! ext2/3/4 filesystem.
//!
//! Supported flags:
//!   -L label          set `s_volume_name`   (up to 16 bytes)
//!   -U uuid           set `s_uuid`          (32 hex digits, dashes ignored)
//!   -c max_mnt        set `s_max_mnt_count` (0 disables)
//!   -i interval       set `s_checkinterval` (seconds; accepts Ns/Nd/Nw/Nm)
//!   -e behavior       set `s_errors`        (continue|remount-ro|panic)
//!   -m pct            set reserved-blocks % (recomputes `s_r_blocks_count_lo`)
//!   -M dir            set `s_last_mounted` (up to 64 bytes, null-padded)
//!   -C count          set `s_mnt_count` (u16)
//!   -O feat[,...]     toggle feature bits; only `has_journal`,
//!                     `^has_journal`, `^metadata_csum`,
//!                     `dir_index`, `^dir_index`, `casefold`,
//!                     `^casefold`, `project`, `^project`,
//!                     `encrypt`, and `^encrypt` are
//!                     implemented. Any other feature name is rejected.
//!   -j                shorthand for `-O has_journal` (ext2 -> ext3 upgrade)
//!   -l                print header (dumpe2fs -h output)
//!   -V                version
//!
//! All edits go through the primary superblock; sparse-super
//! backups are intentionally not propagated yet.

use std::path::PathBuf;
use std::process::ExitCode;

use anvil_core::consts::*;
use anvil_core::fs::Fs;
use anvil_core::inode::{Extent, ExtentHeader, Inode};
use anvil_core::jbd2::JournalSuperblock;
use anvil_core::bitmap;

struct Changes {
    label: Option<[u8; 16]>,
    uuid: Option<[u8; 16]>,
    max_mnt_count: Option<u16>,
    check_interval: Option<u32>,
    errors: Option<u16>,
    reserved_pct: Option<u32>,
    last_mounted: Option<[u8; 64]>,
    mnt_count: Option<u16>,
    features: Vec<(String, bool)>, // (name, enable)
    add_journal_flag: bool, // -j shorthand
    list: bool,
}

fn main() -> ExitCode {
    let mut args = std::env::args().skip(1);
    let mut ch = Changes {
        label: None, uuid: None, max_mnt_count: None, check_interval: None,
        errors: None, reserved_pct: None, last_mounted: None, mnt_count: None,
        features: Vec::new(), add_journal_flag: false, list: false,
    };
    let mut path: Option<PathBuf> = None;
    while let Some(a) = args.next() {
        match a.as_str() {
            "-L" => {
                let v = match args.next() { Some(s) => s, None => return usage_err("missing -L value") };
                if v.as_bytes().contains(&0u8) {
                    eprintln!("tune2fs: error: label contains NUL byte");
                    return ExitCode::from(1);
                }
                let bytes = v.as_bytes();
                let n = if bytes.len() > 16 {
                    eprintln!("tune2fs: warning: label truncated to 16 bytes");
                    16
                } else {
                    bytes.len()
                };
                let mut buf = [0u8; 16];
                buf[..n].copy_from_slice(&bytes[..n]);
                ch.label = Some(buf);
            }
            "-U" => {
                let v = match args.next() { Some(s) => s, None => return usage_err("missing -U value") };
                match parse_uuid(&v) {
                    Ok(u) => ch.uuid = Some(u),
                    Err(e) => return usage_err(&e),
                }
            }
            "-c" => {
                let v = match args.next() { Some(s) => s, None => return usage_err("missing -c value") };
                match v.parse::<u16>() {
                    Ok(n) => ch.max_mnt_count = Some(n),
                    Err(_) => return usage_err("bad -c value"),
                }
            }
            "-i" => {
                let v = match args.next() { Some(s) => s, None => return usage_err("missing -i value") };
                match parse_interval(&v) {
                    Ok(n) => ch.check_interval = Some(n),
                    Err(e) => return usage_err(&e),
                }
            }
            "-e" => {
                let v = match args.next() { Some(s) => s, None => return usage_err("missing -e value") };
                let code = match v.as_str() {
                    "continue" => 1,
                    "remount-ro" | "remount-read-only" => 2,
                    "panic" => 3,
                    _ => return usage_err("unknown error behavior"),
                };
                ch.errors = Some(code);
            }
            "-m" => {
                let v = match args.next() { Some(s) => s, None => return usage_err("missing -m value") };
                match v.parse::<u32>() {
                    Ok(n) if n <= 100 => ch.reserved_pct = Some(n),
                    _ => return usage_err("bad -m percentage"),
                }
            }
            "-M" => {
                let v = match args.next() { Some(s) => s, None => return usage_err("missing -M value") };
                if v.as_bytes().len() > 64 {
                    return usage_err("last-mounted path exceeds 64 bytes");
                }
                let mut buf = [0u8; 64];
                buf[..v.as_bytes().len()].copy_from_slice(v.as_bytes());
                ch.last_mounted = Some(buf);
            }
            "-C" => {
                let v = match args.next() { Some(s) => s, None => return usage_err("missing -C value") };
                match v.parse::<u16>() {
                    Ok(n) => ch.mnt_count = Some(n),
                    Err(_) => return usage_err("bad -C value"),
                }
            }
            "-O" => {
                let v = match args.next() { Some(s) => s, None => return usage_err("missing -O value") };
                // Parse comma-separated feature list. Leading '^'
                // means remove; otherwise add. Same convention as
                // mke2fs / upstream tune2fs.
                for item in v.split(',') {
                    let item = item.trim();
                    if item.is_empty() { continue; }
                    let (name, enable) = if let Some(rest) = item.strip_prefix('^') {
                        (rest.to_string(), false)
                    } else {
                        (item.to_string(), true)
                    };
                    ch.features.push((name, enable));
                }
            }
            "-j" => ch.add_journal_flag = true,
            "-l" => ch.list = true,
            "-V" => {
                println!("tune2fs 1.47.3-anvil (MIT)");
                return ExitCode::from(0);
            }
            s if s.starts_with('-') => {
                eprintln!("tune2fs: unknown option {s} (ignored)");
            }
            _ => path = Some(PathBuf::from(a)),
        }
    }
    let Some(path) = path else { return usage_err("missing device"); };

    // Reject any feature other than has_journal / ^has_journal /
    // ^metadata_csum up front, before we open the device. Keeps
    // the error ordering deterministic regardless of -O position
    // in argv.
    for (name, enable) in &ch.features {
        let ok = name == "has_journal"
            || (name == "metadata_csum" && !*enable)
            || name == "dir_index"
            || name == "casefold"
            || name == "project"
            || name == "encrypt";
        if !ok {
            eprintln!(
                "tune2fs: unsupported feature '{name}' — only has_journal, ^has_journal, ^metadata_csum, dir_index, ^dir_index, casefold, ^casefold, project, ^project, encrypt, ^encrypt are implemented"
            );
            return ExitCode::from(16);
        }
    }

    // -j is shorthand for -O has_journal. Combining it with
    // -O ^has_journal is contradictory.
    if ch.add_journal_flag {
        for (name, enable) in &ch.features {
            if name == "has_journal" && !*enable {
                eprintln!("tune2fs: -j conflicts with -O ^has_journal");
                return ExitCode::from(16);
            }
        }
    }

    let mut fs = match Fs::open(&path) {
        Ok(fs) => fs,
        Err(e) => {
            eprintln!("tune2fs: open {}: {}", path.display(), e);
            return ExitCode::from(8);
        }
    };
    println!("tune2fs 1.47.3-anvil (MIT)");

    let mut modified = false;
    let mut gdt_modified = false;
    if let Some(l) = ch.label {
        fs.sb.s_volume_name = l;
        modified = true;
    }
    if let Some(u) = ch.uuid {
        fs.sb.s_uuid = u;
        modified = true;
    }
    if let Some(n) = ch.max_mnt_count {
        fs.sb.s_max_mnt_count = n;
        modified = true;
    }
    if let Some(n) = ch.check_interval {
        fs.sb.s_checkinterval = n;
        modified = true;
    }
    if let Some(e) = ch.errors {
        fs.sb.s_errors = e;
        modified = true;
    }
    if let Some(pct) = ch.reserved_pct {
        let total = fs.total_blocks();
        let r = total.saturating_mul(pct as u64) / 100;
        fs.sb.s_r_blocks_count_lo = r as u32;
        if fs.has_64bit {
            fs.sb.s_r_blocks_count_hi = (r >> 32) as u32;
        }
        modified = true;
    }
    if let Some(dir) = ch.last_mounted {
        fs.sb.s_last_mounted = dir;
        modified = true;
    }
    if let Some(n) = ch.mnt_count {
        fs.sb.s_mnt_count = n;
        modified = true;
    }

    // --- Feature toggles. We validated above that every entry
    //     is one of has_journal (add/remove) or ^metadata_csum
    //     (remove only); dispatch by (name, enable).
    for (name, enable) in &ch.features {
        match (name.as_str(), *enable) {
            ("has_journal", true) => {
                match add_journal(&mut fs) {
                    Ok(()) => { modified = true; gdt_modified = true; }
                    Err(e) => {
                        eprintln!("tune2fs: adding journal: {e}");
                        return ExitCode::from(8);
                    }
                }
            }
            ("has_journal", false) => {
                if let Err(e) = remove_journal(&mut fs) {
                    eprintln!("tune2fs: removing journal: {e}");
                    return ExitCode::from(8);
                }
                modified = true;
                gdt_modified = true;
            }
            ("metadata_csum", false) => {
                match remove_metadata_csum(&mut fs) {
                    Ok(true) => { modified = true; gdt_modified = true; }
                    Ok(false) => {
                        // Already cleared — leave SB/GDT alone so
                        // the no-op case doesn't rewrite bytes.
                        println!("tune2fs: metadata_csum not set");
                        return ExitCode::from(0);
                    }
                    Err(e) => {
                        eprintln!("tune2fs: removing metadata_csum: {e}");
                        return ExitCode::from(8);
                    }
                }
            }
            ("dir_index", true) => {
                // COMPAT feature: flip the bit. Existing directories
                // stay as plain linear dirs; the kernel builds htree
                // indexes lazily on modification. e2fsck -fn is happy
                // with a dir_index-enabled fs that has no indexed
                // directories yet.
                if fs.sb.s_feature_compat & EXT4_FEATURE_COMPAT_DIR_INDEX == 0 {
                    fs.sb.s_feature_compat |= EXT4_FEATURE_COMPAT_DIR_INDEX;
                    modified = true;
                }
            }
            ("dir_index", false) => {
                // Walk every inode slot; if EXT4_INDEX_FL (0x1000)
                // is set in i_flags, clear it and recompute the
                // inode csum. The htree dx_root metadata in the
                // first dir block is left as-is — with the flag
                // cleared the kernel treats it as trailing padding
                // inside an ordinary linear directory.
                if let Err(e) = clear_dir_index_flags(&mut fs) {
                    eprintln!("tune2fs: clearing dir_index flags: {e}");
                    return ExitCode::from(8);
                }
                if fs.sb.s_feature_compat & EXT4_FEATURE_COMPAT_DIR_INDEX != 0 {
                    fs.sb.s_feature_compat &= !EXT4_FEATURE_COMPAT_DIR_INDEX;
                    modified = true;
                }
            }
            ("casefold", true) => {
                if fs.sb.s_feature_incompat & EXT4_FEATURE_INCOMPAT_CASEFOLD == 0 {
                    fs.sb.s_feature_incompat |= EXT4_FEATURE_INCOMPAT_CASEFOLD;
                    // UTF-8-12.1 encoding (id 1) — the only encoding
                    // e2fsprogs currently accepts with CASEFOLD on.
                    if fs.sb.s_encoding == 0 {
                        fs.sb.s_encoding = 1;
                        fs.sb.s_encoding_flags = 0;
                    }
                    modified = true;
                }
            }
            ("casefold", false) => {
                if fs.sb.s_feature_incompat & EXT4_FEATURE_INCOMPAT_CASEFOLD != 0 {
                    fs.sb.s_feature_incompat &= !EXT4_FEATURE_INCOMPAT_CASEFOLD;
                    fs.sb.s_encoding = 0;
                    fs.sb.s_encoding_flags = 0;
                    modified = true;
                }
            }
            ("project", true) => {
                if fs.sb.s_feature_ro_compat & EXT4_FEATURE_RO_COMPAT_PROJECT == 0 {
                    fs.sb.s_feature_ro_compat |= EXT4_FEATURE_RO_COMPAT_PROJECT;
                    modified = true;
                }
            }
            ("project", false) => {
                if fs.sb.s_feature_ro_compat & EXT4_FEATURE_RO_COMPAT_PROJECT != 0 {
                    fs.sb.s_feature_ro_compat &= !EXT4_FEATURE_RO_COMPAT_PROJECT;
                    modified = true;
                }
            }
            ("encrypt", true) => {
                eprintln!("tune2fs: WARNING: enabling 'encrypt' on a filesystem without per-file encryption keys will break existing files. Proceeding anyway.");
                if fs.sb.s_feature_incompat & EXT4_FEATURE_INCOMPAT_ENCRYPT == 0 {
                    fs.sb.s_feature_incompat |= EXT4_FEATURE_INCOMPAT_ENCRYPT;
                    modified = true;
                }
            }
            ("encrypt", false) => {
                if fs.sb.s_feature_incompat & EXT4_FEATURE_INCOMPAT_ENCRYPT != 0 {
                    fs.sb.s_feature_incompat &= !EXT4_FEATURE_INCOMPAT_ENCRYPT;
                    modified = true;
                }
            }
            _ => unreachable!("validated above"),
        }
    }

    // -j shorthand: add a journal if one is not already present.
    // Idempotent -- a no-op print + exit 0 when HAS_JOURNAL is
    // already set. Matches upstream tune2fs -j behavior for
    // ext2 -> ext3 upgrades that may get re-run by scripts.
    if ch.add_journal_flag {
        if fs.sb.s_feature_compat & EXT4_FEATURE_COMPAT_HAS_JOURNAL != 0 {
            println!("tune2fs: has_journal already set, leaving alone");
            return ExitCode::from(0);
        }
        match add_journal(&mut fs) {
            Ok(()) => { modified = true; gdt_modified = true; }
            Err(e) => {
                eprintln!("tune2fs: adding journal: {e}");
                return ExitCode::from(8);
            }
        }
    }

    if modified {
        if let Err(e) = fs.write_superblock() {
            eprintln!("tune2fs: writing superblock: {e}");
            return ExitCode::from(8);
        }
    }
    if gdt_modified {
        if let Err(e) = fs.write_gdt() {
            eprintln!("tune2fs: writing GDT: {e}");
            return ExitCode::from(8);
        }
    }

    if ch.list {
        print_list(&fs);
    }

    ExitCode::from(0)
}

/// Remove the HAS_JOURNAL feature. The journal data blocks are
/// left on disk as-is — the kernel stops consulting them once
/// the compat bit is clear, and reclaiming would require walking
/// the extent tree of inode 8. Upstream e2fsck is happy with a
/// leftover journal body that no superblock bit points at.
fn remove_journal(fs: &mut Fs) -> std::io::Result<()> {
    // Read inode 8 before we zero it so we can free the blocks
    // it referenced. Upstream e2fsck -fn otherwise reports
    // "Block bitmap differences" for every block the ex-journal
    // used to hold — the bitmap bits stay set but no inode
    // claims them. Reclaiming the range keeps the fs clean
    // without a follow-up e2fsck -y pass.
    let ino = fs.read_inode(EXT4_JOURNAL_INO)?;
    free_inline_extent_blocks(fs, &ino)?;

    fs.sb.s_feature_compat &= !EXT4_FEATURE_COMPAT_HAS_JOURNAL;
    fs.sb.s_journal_inum = 0;
    // RECOVER only makes sense alongside HAS_JOURNAL.
    fs.sb.s_feature_incompat &= !EXT4_FEATURE_INCOMPAT_RECOVER;
    // Zero the saved backup of the journal inode in the SB;
    // stale i_block data confuses dumpe2fs' journal-info printout.
    fs.sb.s_jnl_blocks = [0u32; 17];
    fs.sb.s_jnl_backup_type = 0;

    // Zero inode 8 itself. Upstream e2fsck otherwise flags
    // "Journal inode is not in use, but contains data" because
    // the old extent pointers still live in the slot. Blanking
    // the whole inode slot turns it back into a reserved-but-
    // unused inode.
    let inode_table = fs.group_inode_table(0);
    let idx = (EXT4_JOURNAL_INO - 1) as u64;
    let byte = inode_table * fs.block_size + idx * fs.inode_size;
    let zeroed = vec![0u8; fs.inode_size as usize];
    fs.dev.write_at(byte, &zeroed)?;

    refresh_sb_csum(fs);
    Ok(())
}

/// Remove EXT4_FEATURE_RO_COMPAT_METADATA_CSUM. Returns Ok(true)
/// if the feature was set and we cleared it; Ok(false) if it was
/// already clear (caller treats that as a no-op).
///
/// We don't rewrite per-object csums — we zero them. The kernel
/// and e2fsck both ignore the crc32c fields once the feature bit
/// is clear; leaving stale values on disk just makes a later
/// re-enable (tune2fs -O metadata_csum) more awkward. The fields
/// we zero are:
///   * per-inode: i_checksum_lo (osd2 @ inode+0x7C) and, when
///     i_extra_isize > 2, i_checksum_hi (inode+0x82)
///   * per-GDT: bg_checksum (2B), bg_block_bitmap_csum_lo/_hi,
///     bg_inode_bitmap_csum_lo/_hi
///   * SB: s_checksum, s_checksum_type
///
/// Per-dir-block tail-entries (the inode=0 / rec_len=12 /
/// file_type=0xDE marker) are not rewritten here. Upstream
/// e2fsck -fn tolerates them — it tries to verify the tail csum,
/// sees the feature bit is off, and moves on. Leaving them lets
/// us skip a full dir-block rewrite pass and a htree-index teardown.
fn remove_metadata_csum(fs: &mut Fs) -> std::io::Result<bool> {
    if fs.sb.s_feature_ro_compat & EXT4_FEATURE_RO_COMPAT_METADATA_CSUM == 0 {
        return Ok(false);
    }

    let bs = fs.block_size;
    let inode_size = fs.inode_size as usize;
    let inodes_per_group = fs.inodes_per_group;

    // --- Zero per-inode checksum fields in every inode slot. We
    //     rewrite only the two checksum words (2 bytes each),
    //     leaving the rest of the slot untouched. Works whether
    //     the slot is in-use or free — a zero field in a free
    //     slot is still zero.
    for gi in 0..fs.groups_count {
        let table = fs.group_inode_table(gi);
        for idx in 0..inodes_per_group {
            let byte = table * bs + idx * inode_size as u64;
            // i_checksum_lo @ inode+0x7C (2 bytes, inside osd2).
            fs.dev.write_at(byte + 0x7C, &[0u8, 0u8])?;
            // i_checksum_hi @ inode+0x82 only exists when
            // inode_size >= 256 AND i_extra_isize > 2. For
            // inode_size < 256 the byte isn't part of the slot,
            // so don't touch it. We don't inspect i_extra_isize
            // per slot — writing zero over a reserved-zero word
            // is a no-op on unused slots, and used slots always
            // have extra_isize >= 32 in an ext4 image that ever
            // carried metadata_csum.
            if inode_size >= 256 {
                fs.dev.write_at(byte + 0x82, &[0u8, 0u8])?;
            }
        }
    }

    // --- Zero per-GDT csum fields in the in-memory GDT. The
    //     caller flushes via fs.write_gdt().
    for d in fs.gdt.iter_mut() {
        d.bg_checksum = 0;
        d.bg_block_bitmap_csum_lo = 0;
        d.bg_inode_bitmap_csum_lo = 0;
        d.bg_block_bitmap_csum_hi = 0;
        d.bg_inode_bitmap_csum_hi = 0;
    }

    // --- Clear the feature bit + SB csum fields. write_superblock
    //     in the caller flushes the whole 1024-byte SB, so the
    //     cleared bytes land on disk.
    fs.sb.s_feature_ro_compat &= !EXT4_FEATURE_RO_COMPAT_METADATA_CSUM;
    fs.sb.s_checksum_type = 0;
    fs.sb.s_checksum = 0;

    Ok(true)
}

/// Walk the inline-extent tree of an inode and clear every
/// referenced physical block in the appropriate group's block
/// bitmap. Updates the GDT free_blocks counter per touched
/// group and the SB total. Only supports single-level (depth=0)
/// extent trees — which is all mkfs ever emits for the journal
/// inode. Non-extent (block-map) inodes and multi-level trees
/// are out of scope for this pass.
fn free_inline_extent_blocks(fs: &mut Fs, ino: &Inode) -> std::io::Result<()> {
    if ino.i_flags & EXT4_EXTENTS_FL == 0 {
        // Block-map layout (ext3-style journal inode). Not
        // supported here — leaving the bitmap alone means
        // e2fsck will report differences, but we don't risk
        // corrupting a tree we haven't validated. The task
        // scope is the extent case.
        return Ok(());
    }
    let raw: [u8; 60] = unsafe {
        *(core::ptr::addr_of!(ino.i_block) as *const [u8; 60])
    };
    let magic = u16::from_le_bytes([raw[0], raw[1]]);
    if magic != EXT4_EXT_MAGIC { return Ok(()); }
    let entries = u16::from_le_bytes([raw[2], raw[3]]) as usize;
    let depth   = u16::from_le_bytes([raw[6], raw[7]]);
    if depth != 0 {
        // We never emit depth>0 for the journal, and walking an
        // on-disk idx tree would pull in external blocks. Skip
        // gracefully.
        return Ok(());
    }
    for i in 0..entries {
        let off = 12 + i * 12;
        if off + 12 > 60 { break; }
        let _ee_block = u32::from_le_bytes([raw[off], raw[off+1], raw[off+2], raw[off+3]]);
        let ee_len    = u16::from_le_bytes([raw[off+4], raw[off+5]]);
        let ee_hi     = u16::from_le_bytes([raw[off+6], raw[off+7]]);
        let ee_lo     = u32::from_le_bytes([raw[off+8], raw[off+9], raw[off+10], raw[off+11]]);
        let len = ee_len as u64;
        if len == 0 { continue; }
        let start = ((ee_hi as u64) << 32) | ee_lo as u64;
        free_block_range(fs, start, len)?;
    }
    Ok(())
}

/// Clear `len` bitmap bits starting at absolute block `start`,
/// updating the per-group free_blocks counters and the SB total.
/// Splits the range across group boundaries.
fn free_block_range(fs: &mut Fs, start: u64, len: u64) -> std::io::Result<()> {
    let bpg = fs.blocks_per_group;
    let first_data = fs.sb.s_first_data_block as u64;
    let bs = fs.block_size;
    let mut blk = start;
    let end = start + len;
    while blk < end {
        // Which group does `blk` belong to?
        let gi = if blk >= first_data {
            (blk - first_data) / bpg
        } else {
            0
        };
        let group_start = first_data + gi * bpg;
        let group_end = core::cmp::min(group_start + bpg, fs.total_blocks());
        let chunk_end = core::cmp::min(end, group_end);

        let bb_blk = fs.group_block_bitmap(gi);
        let mut bb = vec![0u8; bs as usize];
        fs.read_block(bb_blk, &mut bb)?;

        let mut freed_in_chunk = 0u32;
        for b in blk..chunk_end {
            let rel = (b - group_start) as usize;
            if rel / 8 < bb.len() && bitmap::test_bit(&bb, rel) {
                bitmap::clear_bit(&mut bb, rel);
                freed_in_chunk += 1;
            }
        }
        fs.dev.write_at(bb_blk * bs, &bb)?;

        if freed_in_chunk > 0 {
            let d = &mut fs.gdt[gi as usize];
            let cur = ((d.bg_free_blocks_count_hi as u32) << 16)
                | d.bg_free_blocks_count_lo as u32;
            d.set_free_blocks(cur.saturating_add(freed_in_chunk));
            let new_total = fs.sb.free_blocks().saturating_add(freed_in_chunk as u64);
            fs.sb.set_free_blocks(new_total);
        }

        blk = chunk_end;
    }
    Ok(())
}

/// Add the HAS_JOURNAL feature to a journal-less filesystem.
/// Preconditions checked inside:
///   * HAS_JOURNAL not already set
///   * inode 8 currently unused (mode == 0)
///   * contiguous free block run large enough in group 0
fn add_journal(fs: &mut Fs) -> std::io::Result<()> {
    if fs.sb.s_feature_compat & EXT4_FEATURE_COMPAT_HAS_JOURNAL != 0 {
        return Err(io_err("filesystem already has a journal"));
    }
    // Check inode 8 is free-enough: mode == 0. That's the
    // fresh-mkfs state for a reserved inode — the bitmap bit may
    // or may not already be set, but the inode slot itself must
    // not contain a live file.
    let existing = fs.read_inode(EXT4_JOURNAL_INO)?;
    let mode = existing.i_mode;
    if mode != 0 {
        return Err(io_err(
            "inode 8 (EXT4_JOURNAL_INO) is already allocated; cannot repurpose as journal",
        ));
    }
    // We emit inode 8 with an inline extent tree. If the
    // filesystem doesn't already advertise EXTENTS, turn the
    // feature on alongside HAS_JOURNAL — otherwise the kernel
    // would mis-read i_block[] as block pointers and e2fsck
    // would flag EXTENTS_FL-on-non-extents-fs. Upstream
    // tune2fs-j does the same escalation when adding a journal
    // to an ext2 image.
    fs.sb.s_feature_incompat |= EXT4_FEATURE_INCOMPAT_EXTENTS;

    let bs = fs.block_size;
    let bpg = fs.blocks_per_group;
    let total = fs.total_blocks();
    let free_blocks = fs.free_blocks();

    // Per spec: min(1024, free_blocks/4). The upper bound keeps
    // the pass from chewing through a small filesystem's entire
    // reserve, while 1024 blocks is the default mkfs sizing on
    // mid-size fs.
    let journal_len = core::cmp::min(1024u64, free_blocks / 4);
    if journal_len < 8 {
        return Err(io_err("not enough free space to create a journal"));
    }

    // Find a contiguous free run in group 0's block bitmap. The
    // run is expressed as an absolute block number.
    let bb_blk = fs.group_block_bitmap(0);
    let mut bb = vec![0u8; bs as usize];
    fs.read_block(bb_blk, &mut bb)?;

    let first = fs.sb.s_first_data_block as u64;
    let last_in_g0 = core::cmp::min(first + bpg, total);
    let group_blocks_in_bitmap = (last_in_g0 - first) as usize;

    let journal_start = match find_free_run(&bb, group_blocks_in_bitmap, journal_len as usize) {
        Some(rel) => first + rel as u64,
        None => return Err(io_err("no contiguous free run for journal in group 0")),
    };

    // Mark the journal blocks as used in the in-memory bitmap,
    // then write the bitmap back.
    let rel_start = (journal_start - first) as usize;
    let rel_end = rel_start + journal_len as usize;
    bitmap::mark_range(&mut bb, rel_start, rel_end);
    fs.dev.write_at(bb_blk * bs, &bb)?;

    // Inode-8 bitmap bit. For ext2/ext3 mkfs output inode 8 is
    // already marked in-use (as a reserved inode); for ext4 it
    // may or may not be. If it was already set we must NOT
    // decrement the free-inode counter.
    let ib_blk = fs.group_inode_bitmap(0);
    let mut ib = vec![0u8; bs as usize];
    fs.read_block(ib_blk, &mut ib)?;
    let ino_rel = (EXT4_JOURNAL_INO - 1) as usize;
    let was_set = bitmap::test_bit(&ib, ino_rel);
    if !was_set {
        bitmap::set_bit(&mut ib, ino_rel);
        fs.dev.write_at(ib_blk * bs, &ib)?;
    }

    // Build inode 8: regular file, root-owned, 0o600, one extent
    // covering the journal range. This matches what mkfs emits
    // when it allocates the journal up front.
    let now = now_u32();
    let mut ino = Inode::default();
    ino.i_mode = S_IFREG | 0o600;
    ino.i_uid = 0;
    ino.i_gid = 0;
    ino.i_links_count = 1;
    ino.set_size(journal_len * bs);
    ino.i_blocks_lo = (journal_len * bs / 512) as u32;
    ino.i_atime = now;
    ino.i_ctime = now;
    ino.i_mtime = now;
    ino.i_flags = EXT4_EXTENTS_FL;
    write_inline_extent(&mut ino, journal_start, journal_len);

    if fs.inode_size >= 256 {
        ino.i_extra_isize = 32;
        ino.i_crtime = now;
    }

    let inode_table = fs.group_inode_table(0);
    let idx = (EXT4_JOURNAL_INO - 1) as u64;
    let ino_byte = inode_table * bs + idx * fs.inode_size;
    let ino_bytes = ino.to_bytes(fs.inode_size as usize);
    fs.dev.write_at(ino_byte, &ino_bytes)?;

    // Zero the journal body then stamp the JBD2 superblock at
    // block 0 of the journal. The kernel is happy with an empty
    // journal; the bytes past the SB just need to not look like
    // stale transaction headers.
    let j_byte_start = journal_start * bs;
    let j_byte_end = j_byte_start + journal_len * bs;
    fs.dev.zero_range(j_byte_start, j_byte_end)?;
    let mut jbd = JournalSuperblock::new_ext4(bs as u32, journal_len as u32, fs.sb.s_uuid);
    fs.dev.write_at(j_byte_start, &jbd.to_bytes())?;
    // Silence unused-mut warning on `jbd` even when CSUM_V3 is off.
    let _ = &mut jbd;

    // Update group 0 descriptor counters. Use get/set helpers so
    // the hi halves stay consistent on 64BIT filesystems.
    let d = &mut fs.gdt[0];
    let old_free_blk = (d.bg_free_blocks_count_hi as u32) << 16
        | d.bg_free_blocks_count_lo as u32;
    let new_free_blk = old_free_blk.saturating_sub(journal_len as u32);
    d.set_free_blocks(new_free_blk);
    if !was_set {
        let old_free_ino = (d.bg_free_inodes_count_hi as u32) << 16
            | d.bg_free_inodes_count_lo as u32;
        d.set_free_inodes(old_free_ino.saturating_sub(1));
    }
    // Clearing BLOCK_UNINIT / INODE_UNINIT is important — the
    // kernel refuses to touch a group flagged UNINIT even if the
    // bitmap is valid. Fresh mkfs on small fs usually has these
    // cleared for group 0 anyway.
    d.bg_flags &= !(anvil_core::group_desc::EXT4_BG_BLOCK_UNINIT
        | anvil_core::group_desc::EXT4_BG_INODE_UNINIT);

    // Update SB totals + feature + journal inum.
    let new_free_sb = fs.sb.free_blocks().saturating_sub(journal_len);
    fs.sb.set_free_blocks(new_free_sb);
    if !was_set {
        fs.sb.s_free_inodes_count = fs.sb.s_free_inodes_count.saturating_sub(1);
    }
    fs.sb.s_feature_compat |= EXT4_FEATURE_COMPAT_HAS_JOURNAL;
    fs.sb.s_journal_inum = EXT4_JOURNAL_INO;

    refresh_sb_csum(fs);
    Ok(())
}

/// Scan a bitmap for the first run of `need` contiguous clear
/// bits, returning the relative index of the start. `total` is
/// the number of valid bitmap slots (groups smaller than the
/// bitmap block have trailing padding marked in-use).
fn find_free_run(bitmap: &[u8], total: usize, need: usize) -> Option<usize> {
    if need == 0 { return Some(0); }
    let mut run_start: Option<usize> = None;
    let mut run_len: usize = 0;
    for i in 0..total {
        let used = (bitmap[i / 8] >> (i % 8)) & 1 != 0;
        if used {
            run_start = None;
            run_len = 0;
        } else {
            if run_start.is_none() { run_start = Some(i); }
            run_len += 1;
            if run_len >= need {
                return run_start;
            }
        }
    }
    None
}

/// Write a single 4-entry inline extent header + one Extent into
/// the inode's i_block[] area. Journal runs of up to 32 768 blocks
/// fit in a single Extent record — big enough for the capped
/// journal_len we emit here (<= 1024).
fn write_inline_extent(ino: &mut Inode, start: u64, len: u64) {
    let hdr = ExtentHeader {
        eh_magic: EXT4_EXT_MAGIC,
        eh_entries: 1,
        eh_max: 4,
        eh_depth: 0,
        eh_generation: 0,
    };
    let mut e = Extent {
        ee_block: 0,
        ee_len: len as u16,
        ee_start_hi: 0,
        ee_start_lo: 0,
    };
    e.set_start(start);
    unsafe {
        let base = core::ptr::addr_of_mut!(ino.i_block) as *mut u8;
        core::ptr::write_unaligned(base as *mut ExtentHeader, hdr);
        core::ptr::write_unaligned(base.add(12) as *mut Extent, e);
    }
}

/// Walk every inode slot in every group and clear EXT4_INDEX_FL
/// on any inode that has it set. Recomputes the metadata_csum
/// (when the feature is on) and writes the slot back. Only dirs
/// ever carry this flag, so the scan is harmless on non-dir
/// slots — but we gate on the bit itself to avoid rewriting a
/// slot we didn't actually change.
fn clear_dir_index_flags(fs: &mut Fs) -> std::io::Result<()> {
    let bs = fs.block_size;
    let inode_size = fs.inode_size as usize;
    let inodes_per_group = fs.inodes_per_group;
    let want_csum = fs.has_metadata_csum();
    let mut buf = vec![0u8; inode_size];

    for gi in 0..fs.groups_count {
        let table = fs.group_inode_table(gi);
        for idx in 0..inodes_per_group {
            let byte = table * bs + idx * inode_size as u64;
            fs.dev.read_at(byte, &mut buf)?;

            // i_flags @ offset 0x20 (4 bytes LE).
            let flags = u32::from_le_bytes(buf[0x20..0x24].try_into().unwrap());
            if flags & EXT4_INDEX_FL == 0 {
                continue;
            }
            let new_flags = flags & !EXT4_INDEX_FL;
            buf[0x20..0x24].copy_from_slice(&new_flags.to_le_bytes());

            if want_csum {
                let ino_num = (gi * inodes_per_group + idx + 1) as u32;
                let generation = u32::from_le_bytes(
                    buf[0x64..0x68].try_into().unwrap(),
                );
                let extra_isize = if buf.len() >= 0x82 {
                    u16::from_le_bytes(buf[0x80..0x82].try_into().unwrap())
                } else { 0 };
                if buf.len() >= 0x7E {
                    buf[0x7C..0x7E].copy_from_slice(&0u16.to_le_bytes());
                }
                let has_hi = extra_isize >= 4 && buf.len() >= 0x84;
                if has_hi {
                    buf[0x82..0x84].copy_from_slice(&0u16.to_le_bytes());
                }
                let csum = anvil_core::fs::compute_inode_csum(
                    &fs.sb, ino_num, generation, &buf,
                );
                if buf.len() >= 0x7E {
                    buf[0x7C..0x7E].copy_from_slice(&(csum as u16).to_le_bytes());
                }
                if has_hi {
                    buf[0x82..0x84]
                        .copy_from_slice(&((csum >> 16) as u16).to_le_bytes());
                }
            }

            fs.dev.write_at(byte, &buf)?;
        }
    }
    Ok(())
}

/// Recompute s_checksum when metadata_csum is on. The on-disk
/// layout is crc32c(seed=0xFFFFFFFF, sb_bytes[..0x3FC]) with
/// s_checksum itself zeroed before the hash. Filesystems without
/// metadata_csum don't store this field — leave it untouched so
/// we don't stamp a nonsense value into reserved space.
fn refresh_sb_csum(fs: &mut Fs) {
    if fs.sb.s_feature_ro_compat & EXT4_FEATURE_RO_COMPAT_METADATA_CSUM == 0 {
        return;
    }
    fs.sb.s_checksum = 0;
    let bytes = fs.sb.to_bytes();
    fs.sb.s_checksum = anvil_core::crc::crc32c_cont(0xFFFFFFFF, &bytes[..0x3FC]);
}

fn now_u32() -> u32 {
    std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_secs() as u32)
        .unwrap_or(0)
}

fn io_err(msg: &str) -> std::io::Error {
    std::io::Error::new(std::io::ErrorKind::Other, msg)
}

fn usage_err(msg: &str) -> ExitCode {
    eprintln!("tune2fs: {msg}\nusage: tune2fs [-L label] [-U uuid] [-c max_mnt] [-i interval] [-e behavior] [-m pct] [-M dir] [-C count] [-O feat[,feat,...]] [-l] <device>");
    ExitCode::from(16)
}

fn parse_uuid(s: &str) -> Result<[u8; 16], String> {
    match s {
        "random" => return Ok(anvil_core::uuid::v4()),
        "time" => return Ok(anvil_core::uuid::v1_like()),
        "clear" => return Ok(anvil_core::uuid::zero()),
        _ => {}
    }
    let clean: String = s.chars().filter(|c| c.is_ascii_hexdigit()).collect();
    if clean.len() != 32 {
        return Err("UUID must have 32 hex digits".into());
    }
    let mut out = [0u8; 16];
    for i in 0..16 {
        out[i] = u8::from_str_radix(&clean[i * 2..i * 2 + 2], 16)
            .map_err(|_| "bad UUID digit".to_string())?;
    }
    Ok(out)
}

fn parse_interval(s: &str) -> Result<u32, String> {
    let (num_str, mult) = match s.chars().last() {
        Some('s') => (&s[..s.len()-1], 1u64),
        Some('d') => (&s[..s.len()-1], 86_400u64),
        Some('w') => (&s[..s.len()-1], 604_800u64),
        Some('m') => (&s[..s.len()-1], 2_592_000u64),
        _         => (s, 1u64),
    };
    let n: u64 = num_str.parse().map_err(|_| "bad interval".to_string())?;
    let total = n.saturating_mul(mult);
    if total > u32::MAX as u64 { return Err("interval too large".into()); }
    Ok(total as u32)
}

fn print_list(fs: &Fs) {
    let sb = &fs.sb;
    let uuid = sb.s_uuid;
    let label = display_label(&sb.s_volume_name);
    let state = sb.s_state;
    let errors = sb.s_errors;
    let mnt = sb.s_mnt_count;
    let max_mnt = sb.s_max_mnt_count;
    let interval = sb.s_checkinterval;
    let r_blocks = sb.s_r_blocks_count_lo;
    let blocks = sb.blocks_count();
    let last_mounted = display_last_mounted(&sb.s_last_mounted);
    println!("Filesystem volume name:   {label}");
    println!("Last mount point:         {last_mounted}");
    println!("Filesystem UUID:          {}", format_uuid(&uuid));
    println!("Filesystem state:         0x{state:04x}");
    println!("Errors behavior:          {}", match errors {
        1 => "Continue", 2 => "Remount read-only", 3 => "Panic", _ => "Unknown"
    });
    println!("Mount count:              {mnt}");
    println!("Maximum mount count:      {max_mnt}");
    println!("Check interval:           {interval} sec");
    let pct = if blocks == 0 { 0 } else { (r_blocks as u64 * 100) / blocks };
    println!("Reserved block count:     {r_blocks} ({pct}%)");
}

fn display_last_mounted(raw: &[u8; 64]) -> String {
    let end = raw.iter().position(|&b| b == 0).unwrap_or(raw.len());
    if end == 0 { return "<not available>".into(); }
    String::from_utf8_lossy(&raw[..end]).into_owned()
}

fn display_label(raw: &[u8; 16]) -> String {
    let end = raw.iter().position(|&b| b == 0).unwrap_or(raw.len());
    if end == 0 { return "<none>".into(); }
    String::from_utf8_lossy(&raw[..end]).into_owned()
}

fn format_uuid(bytes: &[u8; 16]) -> String {
    if bytes.iter().all(|&b| b == 0) { return "<none>".into(); }
    let b = bytes;
    format!(
        "{:02x}{:02x}{:02x}{:02x}-{:02x}{:02x}-{:02x}{:02x}-{:02x}{:02x}-{:02x}{:02x}{:02x}{:02x}{:02x}{:02x}",
        b[0],b[1],b[2],b[3], b[4],b[5], b[6],b[7], b[8],b[9],
        b[10],b[11],b[12],b[13],b[14],b[15])
}
