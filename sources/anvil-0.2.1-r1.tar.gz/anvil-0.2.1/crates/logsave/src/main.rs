//! logsave — run a command and tee its stdout+stderr to a log file.
//!
//! Used by initramfs / boot scripts to capture e2fsck output even
//! when the root filesystem is not yet writable in the usual way.
//!
//! Usage:
//!   logsave <logfile> <cmd> [args...]
//!   logsave -a <logfile> <cmd> [args...]   # append instead of truncate
//!   logsave -s <logfile> <cmd> [args...]   # skip-if-already-logged (no-op)
//!   logsave -V                             # print version and exit
//!
//! Exit code: the command's exit code (or 128+signal if it died from a signal).

use std::env;
use std::fs::OpenOptions;
use std::io::{Read, Write};
use std::os::unix::process::ExitStatusExt;
use std::process::{Command, ExitCode, Stdio};
use std::sync::{Arc, Mutex};
use std::thread;

const VERSION: &str = "anvil-logsave 0.1.0 (clean-room MIT reimplementation)";

fn usage() -> ! {
    eprintln!(
        "Usage: logsave [-asV] <logfile> <command> [args...]\n  \
         -a   append to logfile instead of truncating\n  \
         -s   skip-if-already-in-log (treated same as default)\n  \
         -V   print version and exit"
    );
    std::process::exit(16);
}

fn main() -> ExitCode {
    let argv: Vec<String> = env::args().collect();
    let mut append = false;
    let mut idx = 1;

    while idx < argv.len() {
        let a = &argv[idx];
        if a == "-V" || a == "--version" {
            println!("{}", VERSION);
            return ExitCode::from(0);
        }
        if a == "-a" {
            append = true;
            idx += 1;
            continue;
        }
        if a == "-s" {
            // upstream: skip if we're already inside a log capture.
            // We have no such mechanism; behave the same as plain mode.
            idx += 1;
            continue;
        }
        if a == "--" {
            idx += 1;
            break;
        }
        if a.starts_with('-') && a.len() > 1 {
            eprintln!("logsave: unknown option: {}", a);
            usage();
        }
        break;
    }

    if idx + 1 >= argv.len() {
        usage();
    }

    let logfile_path = &argv[idx];
    let cmd_name = &argv[idx + 1];
    let cmd_args = &argv[idx + 2..];

    let mut open_opts = OpenOptions::new();
    open_opts.write(true).create(true);
    if append {
        open_opts.append(true);
    } else {
        open_opts.truncate(true);
    }
    let logfile = match open_opts.open(logfile_path) {
        Ok(f) => f,
        Err(e) => {
            eprintln!("logsave: cannot open {}: {}", logfile_path, e);
            return ExitCode::from(8);
        }
    };

    // Shared, lock-protected handle so out + err writes don't interleave
    // mid-line within the file itself.
    let log = Arc::new(Mutex::new(logfile));

    let mut child = match Command::new(cmd_name)
        .args(cmd_args)
        .stdin(Stdio::inherit())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn()
    {
        Ok(c) => c,
        Err(e) => {
            eprintln!("logsave: cannot exec {}: {}", cmd_name, e);
            let mut g = log.lock().unwrap();
            let _ = writeln!(*g, "logsave: cannot exec {}: {}", cmd_name, e);
            return ExitCode::from(8);
        }
    };

    let child_out = child.stdout.take().expect("piped stdout");
    let child_err = child.stderr.take().expect("piped stderr");

    let log_out = Arc::clone(&log);
    let t_out = thread::spawn(move || tee(child_out, log_out, false));

    let log_err = Arc::clone(&log);
    let t_err = thread::spawn(move || tee(child_err, log_err, true));

    let status = match child.wait() {
        Ok(s) => s,
        Err(e) => {
            eprintln!("logsave: wait failed: {}", e);
            return ExitCode::from(8);
        }
    };
    let _ = t_out.join();
    let _ = t_err.join();

    // Make sure log hits disk before we return.
    if let Ok(mut g) = log.lock() {
        let _ = g.flush();
    }

    if let Some(code) = status.code() {
        // Rust ExitCode only takes u8; clamp.
        ExitCode::from((code & 0xff) as u8)
    } else if let Some(sig) = status.signal() {
        ExitCode::from(((128 + sig) & 0xff) as u8)
    } else {
        ExitCode::from(1)
    }
}

fn tee<R: Read>(mut src: R, log: Arc<Mutex<std::fs::File>>, is_err: bool) {
    let mut buf = [0u8; 4096];
    loop {
        match src.read(&mut buf) {
            Ok(0) => return,
            Ok(n) => {
                let chunk = &buf[..n];
                if is_err {
                    let stderr = std::io::stderr();
                    let mut h = stderr.lock();
                    let _ = h.write_all(chunk);
                    let _ = h.flush();
                } else {
                    let stdout = std::io::stdout();
                    let mut h = stdout.lock();
                    let _ = h.write_all(chunk);
                    let _ = h.flush();
                }
                if let Ok(mut g) = log.lock() {
                    let _ = g.write_all(chunk);
                }
            }
            Err(e) => {
                if e.kind() == std::io::ErrorKind::Interrupted {
                    continue;
                }
                return;
            }
        }
    }
}
