//! mkfs.vfat / mkfs.fat — anvil's FAT12/16/32 formatter.
//!
//! Clean-room implementation from the public FAT on-disk format spec
//! (Microsoft fatgen103 and ECMA-107). No code or tables were taken
//! from dosfstools or mtools, both of which are GPL.
//!
//! Produces a filesystem that the Linux `vfat` kernel driver mounts
//! read-write and that dosfstools `fsck.vfat -n` considers clean.

use std::fs::{File, OpenOptions};
use std::io::{Seek, SeekFrom, Write};
use std::path::PathBuf;
use std::process::ExitCode;
use std::time::{SystemTime, UNIX_EPOCH};

const VERSION: &str = "0.1.0";

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum FatType {
    Fat12,
    Fat16,
    Fat32,
}

#[derive(Debug)]
struct Options {
    device: PathBuf,
    block_count: Option<u64>,     // in units of 1024 bytes (dosfstools convention)
    fat_bits: Option<u8>,          // 12, 16, 32
    label: Option<String>,
    volume_id: Option<u32>,
    sectors_per_cluster: Option<u8>,
    sector_size: u32,
    reserved_sectors: Option<u16>,
    num_fats: u8,
    media: u8,
    verbose: bool,
}

impl Default for Options {
    fn default() -> Self {
        Self {
            device: PathBuf::new(),
            block_count: None,
            fat_bits: None,
            label: None,
            volume_id: None,
            sectors_per_cluster: None,
            sector_size: 512,
            reserved_sectors: None,
            num_fats: 2,
            media: 0xF8,
            verbose: false,
        }
    }
}

fn usage() -> &'static str {
    "usage: mkfs.vfat [-F 12|16|32] [-n label] [-i volume-id] [-s spc] \
     [-S sector-size] [-R reserved] [-f num-fats] [-M media] [-v] [-V] \
     <device> [block-count]"
}

fn parse_args(argv: Vec<String>) -> Result<Options, String> {
    let mut opts = Options::default();
    let mut positional: Vec<String> = Vec::new();
    let mut i = 0;
    while i < argv.len() {
        let a = &argv[i];
        let take_val = |name: &str, i: &mut usize| -> Result<String, String> {
            *i += 1;
            argv.get(*i)
                .cloned()
                .ok_or_else(|| format!("option {name} requires an argument"))
        };
        match a.as_str() {
            "-F" => {
                let v = take_val("-F", &mut i)?;
                let n: u8 = v.parse().map_err(|_| format!("bad -F value: {v}"))?;
                if n != 12 && n != 16 && n != 32 {
                    return Err(format!("-F must be 12, 16, or 32 (got {n})"));
                }
                opts.fat_bits = Some(n);
            }
            "-n" => {
                opts.label = Some(take_val("-n", &mut i)?);
            }
            "-i" => {
                let v = take_val("-i", &mut i)?;
                let id = u32::from_str_radix(&v, 16)
                    .map_err(|_| format!("bad -i hex value: {v}"))?;
                opts.volume_id = Some(id);
            }
            "-s" => {
                let v = take_val("-s", &mut i)?;
                let n: u32 = v.parse().map_err(|_| format!("bad -s value: {v}"))?;
                if !matches!(n, 1 | 2 | 4 | 8 | 16 | 32 | 64 | 128) {
                    return Err(format!("-s must be a power of two in 1..=128 (got {n})"));
                }
                opts.sectors_per_cluster = Some(n as u8);
            }
            "-S" => {
                let v = take_val("-S", &mut i)?;
                let n: u32 = v.parse().map_err(|_| format!("bad -S value: {v}"))?;
                if !matches!(n, 512 | 1024 | 2048 | 4096) {
                    return Err(format!("-S must be 512/1024/2048/4096 (got {n})"));
                }
                opts.sector_size = n;
            }
            "-R" => {
                let v = take_val("-R", &mut i)?;
                let n: u16 = v.parse().map_err(|_| format!("bad -R value: {v}"))?;
                if n == 0 {
                    return Err("-R must be >= 1".into());
                }
                opts.reserved_sectors = Some(n);
            }
            "-f" => {
                let v = take_val("-f", &mut i)?;
                let n: u8 = v.parse().map_err(|_| format!("bad -f value: {v}"))?;
                if n != 1 && n != 2 {
                    return Err(format!("-f must be 1 or 2 (got {n})"));
                }
                opts.num_fats = n;
            }
            "-M" => {
                let v = take_val("-M", &mut i)?;
                let n = u16::from_str_radix(v.trim_start_matches("0x"), 16)
                    .or_else(|_| v.parse::<u16>())
                    .map_err(|_| format!("bad -M value: {v}"))?;
                if n > 0xFF {
                    return Err(format!("-M must fit in a byte (got {n})"));
                }
                opts.media = n as u8;
            }
            "-v" => opts.verbose = true,
            "-V" | "--version" => {
                println!("mkfs.vfat (anvil) {VERSION}");
                std::process::exit(0);
            }
            "-h" | "--help" => {
                println!("{}", usage());
                std::process::exit(0);
            }
            s if s.starts_with('-') => {
                return Err(format!("unknown option: {s}"));
            }
            _ => positional.push(a.clone()),
        }
        i += 1;
    }
    if positional.is_empty() {
        return Err(usage().into());
    }
    opts.device = PathBuf::from(&positional[0]);
    if let Some(bc) = positional.get(1) {
        let n: u64 = bc.parse().map_err(|_| format!("bad block-count: {bc}"))?;
        opts.block_count = Some(n);
    }
    Ok(opts)
}

/// Derived FAT geometry.
#[derive(Debug)]
struct Geometry {
    fat_type: FatType,
    bytes_per_sector: u32,
    sectors_per_cluster: u32,
    reserved_sectors: u32,
    num_fats: u32,
    root_entries: u32, // FAT12/16 only, 0 for FAT32
    total_sectors: u64,
    sectors_per_fat: u32,
    root_cluster: u32, // FAT32 only (always 2)
    data_clusters: u32,
}

impl Geometry {

    fn first_data_sector(&self) -> u64 {
        let root_dir_sectors = ((self.root_entries * 32) + (self.bytes_per_sector - 1))
            / self.bytes_per_sector;
        self.reserved_sectors as u64
            + (self.num_fats as u64 * self.sectors_per_fat as u64)
            + root_dir_sectors as u64
    }

    fn root_dir_first_sector(&self) -> u64 {
        // For FAT12/16, the root dir is a fixed region just after the FATs.
        // For FAT32, the root dir lives at cluster 2 in the data region.
        match self.fat_type {
            FatType::Fat32 => {
                self.first_data_sector()
                    + (self.root_cluster as u64 - 2) * self.sectors_per_cluster as u64
            }
            _ => self.reserved_sectors as u64 + self.num_fats as u64 * self.sectors_per_fat as u64,
        }
    }
}

/// Pick a sensible cluster size for FAT32. Values derived from the
/// thresholds documented in the FAT32 spec (Table 5-5-ish).
fn default_spc_fat32(total_sectors: u64, bytes_per_sector: u32) -> u32 {
    // Total size in MiB
    let total_bytes = total_sectors * bytes_per_sector as u64;
    let mib = total_bytes / (1024 * 1024);
    let spc = if mib <= 64 {
        // Below the FAT32 minimum, but allow the caller to force -F 32.
        1
    } else if mib <= 8 * 1024 {
        8
    } else if mib <= 16 * 1024 {
        16
    } else if mib <= 32 * 1024 {
        32
    } else {
        64
    };
    // Clamp so cluster size <= 32 KiB (Windows limit, avoids edge cases).
    let max_spc = (32 * 1024) / bytes_per_sector;
    spc.min(max_spc).max(1)
}

fn default_spc_fat16(total_sectors: u64, bytes_per_sector: u32) -> u32 {
    let total_bytes = total_sectors * bytes_per_sector as u64;
    let mib = total_bytes / (1024 * 1024);
    let spc = if mib <= 16 {
        1
    } else if mib <= 128 {
        4
    } else if mib <= 256 {
        8
    } else {
        16
    };
    let max_spc = (32 * 1024) / bytes_per_sector;
    spc.min(max_spc).max(1)
}

fn default_spc_fat12(_total_sectors: u64, _bytes_per_sector: u32) -> u32 {
    // Keep it simple for tiny filesystems.
    1
}

fn pick_fat_type(total_bytes: u64, forced: Option<u8>) -> FatType {
    if let Some(n) = forced {
        return match n {
            12 => FatType::Fat12,
            16 => FatType::Fat16,
            _ => FatType::Fat32,
        };
    }
    let mib = total_bytes / (1024 * 1024);
    if mib < 4 {
        FatType::Fat12
    } else if mib < 512 {
        FatType::Fat16
    } else {
        FatType::Fat32
    }
}

/// Cluster-count thresholds from the FAT spec:
///   < 4085    -> FAT12
///   < 65525   -> FAT16
///   otherwise -> FAT32
/// These are the ONLY values that unambiguously define the FAT type.
const FAT12_MAX_CLUSTERS: u32 = 4084;
const FAT16_MAX_CLUSTERS: u32 = 65524;

fn compute_geometry(opts: &Options, file_size: u64) -> Result<Geometry, String> {
    let bps = opts.sector_size;
    if file_size < (bps as u64) * 8 {
        return Err(format!(
            "device/image too small ({file_size} bytes) for sector size {bps}"
        ));
    }
    let total_sectors = file_size / bps as u64;
    let total_bytes = total_sectors * bps as u64;

    let fat_type = pick_fat_type(total_bytes, opts.fat_bits);

    let spc = opts.sectors_per_cluster.map(|v| v as u32).unwrap_or_else(|| {
        match fat_type {
            FatType::Fat12 => default_spc_fat12(total_sectors, bps),
            FatType::Fat16 => default_spc_fat16(total_sectors, bps),
            FatType::Fat32 => default_spc_fat32(total_sectors, bps),
        }
    });

    // Reserved sectors: default is 1 for FAT12/16, 32 for FAT32
    // (enough room for FSInfo at LBA 1 and the backup boot sector
    // at LBA 6 plus a little padding). A user-supplied `-R N` is
    // honoured even when it's too small to host the backup boot
    // sector — upstream dosfstools does the same; fsck.vfat then
    // reports "no backup boot sector" but the image is still valid.
    let reserved = opts.reserved_sectors.unwrap_or(match fat_type {
        FatType::Fat32 => 32,
        _ => 1,
    }) as u32;

    let root_entries: u32 = match fat_type {
        FatType::Fat32 => 0,
        _ => 512,
    };
    let root_dir_sectors = ((root_entries * 32) + (bps - 1)) / bps;

    let num_fats = opts.num_fats as u32;

    // Iteratively size the FAT: start with the whole region and shrink
    // until the FAT holds every cluster. Formula derived directly from
    // fatgen103 §3.5 (logical equivalent; we compute it ourselves).
    let fat_bits = match fat_type {
        FatType::Fat12 => 12u64,
        FatType::Fat16 => 16,
        FatType::Fat32 => 32,
    };
    // Solve for sectors_per_fat (spf):
    //   data_sectors   = total - reserved - root_dir - num_fats*spf
    //   data_clusters  = data_sectors / spc
    //   bits_needed    = (data_clusters + 2) * fat_bits   (+2 for reserved entries)
    //   spf            = ceil(bits_needed / 8 / bps)
    // Use a conservative upper bound, iterate to convergence.
    let mut spf: u32 = 1;
    for _ in 0..64 {
        let used =
            reserved as u64 + root_dir_sectors as u64 + num_fats as u64 * spf as u64;
        if used >= total_sectors {
            return Err("filesystem metadata would exceed device size".into());
        }
        let data_sectors = total_sectors - used;
        let data_clusters = (data_sectors / spc as u64) as u64;
        // Reserve entries 0 and 1, so the FAT must describe data_clusters + 2 entries.
        let bits_needed = (data_clusters + 2) * fat_bits;
        let bytes_needed = (bits_needed + 7) / 8;
        let new_spf = ((bytes_needed + bps as u64 - 1) / bps as u64) as u32;
        if new_spf == spf {
            break;
        }
        spf = new_spf.max(1);
    }

    let used = reserved as u64 + root_dir_sectors as u64 + num_fats as u64 * spf as u64;
    if used >= total_sectors {
        return Err("filesystem does not fit (fat metadata >= total)".into());
    }
    let data_sectors = total_sectors - used;
    let data_clusters = (data_sectors / spc as u64) as u32;

    // Sanity: verify the cluster count matches the forced FAT type if any.
    if opts.fat_bits.is_none() {
        // Autodetected — verify type still matches cluster-count thresholds.
        // If not, fix it up.
        let effective_type = if data_clusters <= FAT12_MAX_CLUSTERS {
            FatType::Fat12
        } else if data_clusters <= FAT16_MAX_CLUSTERS {
            FatType::Fat16
        } else {
            FatType::Fat32
        };
        if effective_type != fat_type {
            // Recurse once with the corrected type forced.
            let bits = match effective_type {
                FatType::Fat12 => 12,
                FatType::Fat16 => 16,
                FatType::Fat32 => 32,
            };
            let mut opts2 = Options {
                device: opts.device.clone(),
                block_count: opts.block_count,
                fat_bits: Some(bits),
                label: opts.label.clone(),
                volume_id: opts.volume_id,
                sectors_per_cluster: opts.sectors_per_cluster,
                sector_size: opts.sector_size,
                reserved_sectors: opts.reserved_sectors,
                num_fats: opts.num_fats,
                media: opts.media,
                verbose: opts.verbose,
            };
            // Drop manual spc so defaults for the corrected type apply.
            if opts.sectors_per_cluster.is_none() {
                opts2.sectors_per_cluster = None;
            }
            return compute_geometry(&opts2, file_size);
        }
    } else {
        // Explicit type — cluster count must fit the range.
        match fat_type {
            FatType::Fat12 if data_clusters > FAT12_MAX_CLUSTERS => {
                return Err(format!(
                    "too many clusters ({data_clusters}) for FAT12 — use a larger -s"
                ));
            }
            FatType::Fat16 if data_clusters > FAT16_MAX_CLUSTERS => {
                return Err(format!(
                    "too many clusters ({data_clusters}) for FAT16 — use a larger -s"
                ));
            }
            FatType::Fat16 if data_clusters <= FAT12_MAX_CLUSTERS => {
                // Allowed but unusual; vfat will still mount.
            }
            FatType::Fat32 if data_clusters <= FAT16_MAX_CLUSTERS => {
                // vfat kernel driver allows this; keep going.
            }
            _ => {}
        }
    }

    Ok(Geometry {
        fat_type,
        bytes_per_sector: bps,
        sectors_per_cluster: spc,
        reserved_sectors: reserved,
        num_fats,
        root_entries,
        total_sectors,
        sectors_per_fat: spf,
        root_cluster: 2,
        data_clusters,
    })
}

/// Format a volume label to 11 bytes: uppercase ASCII, space-padded,
/// truncated if too long. Non-ASCII bytes are replaced with '_'.
fn format_label(label: &str) -> [u8; 11] {
    let mut out = [0x20u8; 11]; // space
    let mut i = 0;
    for b in label.bytes() {
        if i >= 11 {
            break;
        }
        let c = if b.is_ascii() { b } else { b'_' };
        let c = if c.is_ascii_lowercase() { c - 32 } else { c };
        // Disallow control chars.
        let c = if c < 0x20 { b'_' } else { c };
        out[i] = c;
        i += 1;
    }
    out
}

fn derive_volume_id() -> u32 {
    let d = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_secs())
        .unwrap_or(0);
    let nanos = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.subsec_nanos())
        .unwrap_or(0);
    // Mix seconds and nanoseconds; any 32-bit value is fine.
    ((d as u32).wrapping_mul(0x9E3779B1)) ^ nanos
}

struct Writer {
    f: File,
    bps: u32,
}

impl Writer {
    fn write_sector(&mut self, lba: u64, data: &[u8]) -> std::io::Result<()> {
        assert!(data.len() <= self.bps as usize);
        self.f.seek(SeekFrom::Start(lba * self.bps as u64))?;
        self.f.write_all(data)?;
        if data.len() < self.bps as usize {
            let pad = vec![0u8; self.bps as usize - data.len()];
            self.f.write_all(&pad)?;
        }
        Ok(())
    }

    fn write_at(&mut self, offset: u64, data: &[u8]) -> std::io::Result<()> {
        self.f.seek(SeekFrom::Start(offset))?;
        self.f.write_all(data)
    }
}

/// Build the boot sector (first `bps` bytes of the volume).
fn build_boot_sector(g: &Geometry, opts: &Options, label: &[u8; 11], volume_id: u32) -> Vec<u8> {
    let mut b = vec![0u8; g.bytes_per_sector as usize];

    // Jump instruction. For FAT32 the BPB is longer, so the standard
    // jump is EB 58 90 (jmp +0x58 / nop). For FAT12/16 we use EB 3C 90.
    let jmp = if g.fat_type == FatType::Fat32 {
        [0xEB, 0x58, 0x90]
    } else {
        [0xEB, 0x3C, 0x90]
    };
    b[0..3].copy_from_slice(&jmp);

    // OEM name. Microsoft's spec calls out "MSWIN4.1" as the value that
    // maximum-compatibility implementations use; Linux vfat and various
    // firmware parsers check the first byte against a small set.
    b[3..11].copy_from_slice(b"MSWIN4.1");

    // Common BPB (offset 11..).
    let bps = g.bytes_per_sector as u16;
    b[11..13].copy_from_slice(&bps.to_le_bytes());
    b[13] = g.sectors_per_cluster as u8;
    b[14..16].copy_from_slice(&(g.reserved_sectors as u16).to_le_bytes());
    b[16] = g.num_fats as u8;
    let root_entries_16 = g.root_entries as u16;
    b[17..19].copy_from_slice(&root_entries_16.to_le_bytes());
    let total16 = if g.total_sectors < 0x10000 && g.fat_type != FatType::Fat32 {
        g.total_sectors as u16
    } else {
        0
    };
    b[19..21].copy_from_slice(&total16.to_le_bytes());
    b[21] = opts.media;
    let spf16 = if g.fat_type == FatType::Fat32 {
        0
    } else {
        g.sectors_per_fat as u16
    };
    b[22..24].copy_from_slice(&spf16.to_le_bytes());
    b[24..26].copy_from_slice(&63u16.to_le_bytes()); // sectors per track
    b[26..28].copy_from_slice(&255u16.to_le_bytes()); // num heads
    b[28..32].copy_from_slice(&0u32.to_le_bytes()); // hidden sectors
    let total32 = if total16 == 0 { g.total_sectors as u32 } else { 0 };
    b[32..36].copy_from_slice(&total32.to_le_bytes());

    match g.fat_type {
        FatType::Fat32 => {
            // FAT32-specific BPB (offset 36..).
            b[36..40].copy_from_slice(&g.sectors_per_fat.to_le_bytes());
            b[40..42].copy_from_slice(&0u16.to_le_bytes()); // ext_flags (mirrored)
            b[42..44].copy_from_slice(&0u16.to_le_bytes()); // fs_version
            b[44..48].copy_from_slice(&g.root_cluster.to_le_bytes());
            b[48..50].copy_from_slice(&1u16.to_le_bytes()); // fs_info sector
            b[50..52].copy_from_slice(&6u16.to_le_bytes()); // backup boot sector
            // 12 bytes reserved at 52..64 already zero.
            b[64] = 0x80; // drive number
            b[65] = 0; // reserved
            b[66] = 0x29; // extended boot signature
            b[67..71].copy_from_slice(&volume_id.to_le_bytes());
            b[71..82].copy_from_slice(label);
            b[82..90].copy_from_slice(b"FAT32   ");
        }
        _ => {
            // FAT12/16 extended BPB at offset 36.
            b[36] = 0x80; // drive number
            b[37] = 0; // reserved
            b[38] = 0x29; // extended boot signature
            b[39..43].copy_from_slice(&volume_id.to_le_bytes());
            b[43..54].copy_from_slice(label);
            let fs_str: &[u8; 8] = match g.fat_type {
                FatType::Fat12 => b"FAT12   ",
                FatType::Fat16 => b"FAT16   ",
                FatType::Fat32 => unreachable!(),
            };
            b[54..62].copy_from_slice(fs_str);
        }
    }

    // Signature at offset 510.
    b[510] = 0x55;
    b[511] = 0xAA;
    b
}

fn build_fsinfo_sector(g: &Geometry) -> Vec<u8> {
    let mut b = vec![0u8; g.bytes_per_sector as usize];
    b[0..4].copy_from_slice(&0x41615252u32.to_le_bytes()); // "RRaA"
    // 480 bytes reserved (all zero)
    b[484..488].copy_from_slice(&0x61417272u32.to_le_bytes()); // "rrAa"
    // free cluster count — all clusters free except the root dir cluster
    let free = g.data_clusters.saturating_sub(1);
    b[488..492].copy_from_slice(&free.to_le_bytes());
    // next free cluster — 3 (root dir sits in cluster 2)
    b[492..496].copy_from_slice(&3u32.to_le_bytes());
    // 12 bytes reserved
    // Trailing signature
    b[508..512].copy_from_slice(&0xAA550000u32.to_le_bytes());
    b
}

/// Build the first sector of a FAT. The rest of the FAT is zero
/// (all clusters free) and we write only the first sector, leaving
/// the remainder as sparse zeros via set_len.
fn build_fat_first_sector(g: &Geometry, opts: &Options) -> Vec<u8> {
    let mut b = vec![0u8; g.bytes_per_sector as usize];
    match g.fat_type {
        FatType::Fat12 => {
            // Entry 0: 0xF?8 in low 12 bits -> 3 bytes encode entries 0 and 1:
            //   byte 0 = media | 0xF0 (low 8 bits of entry 0)
            //   byte 1 = 0xFF          (high 4 bits of entry 0 | low 4 bits of entry 1)
            //   byte 2 = 0xFF          (high 8 bits of entry 1)
            // Entry 0 = 0xF?? with low byte = media byte.
            b[0] = opts.media;
            b[1] = 0xFF;
            b[2] = 0xFF;
            // Entry 2 (root dir cluster for FAT12 is a fixed region, so there is
            // no cluster-2 root; clusters are data-only. Leave 0).
        }
        FatType::Fat16 => {
            // Entry 0 = 0xFFF8 (low byte = media desc)
            b[0] = opts.media;
            b[1] = 0xFF;
            b[2] = 0xFF;
            b[3] = 0xFF;
        }
        FatType::Fat32 => {
            // Entry 0 = 0x0FFFFFF8 (low byte = media)
            let e0: u32 = 0x0FFFFF00 | opts.media as u32;
            b[0..4].copy_from_slice(&e0.to_le_bytes());
            // Entry 1 = 0x0FFFFFFF (and reserved dirty/hard-error bits = 1)
            let e1: u32 = 0x0FFFFFFF;
            b[4..8].copy_from_slice(&e1.to_le_bytes());
            // Entry 2 = 0x0FFFFFFF (end of chain — root dir occupies just this cluster)
            let e2: u32 = 0x0FFFFFFF;
            b[8..12].copy_from_slice(&e2.to_le_bytes());
        }
    }
    b
}

fn build_root_volume_label_entry(label: &[u8; 11]) -> [u8; 32] {
    let mut e = [0u8; 32];
    e[0..11].copy_from_slice(label);
    e[11] = 0x08; // ATTR_VOLUME_ID
    // Everything else (times etc.) zero — Linux accepts this.
    e
}

fn run(opts: Options) -> Result<(), String> {
    // Open target (create if missing and block-count given, else must exist).
    let mut open = OpenOptions::new();
    open.read(true).write(true);
    // For regular files, we'll honor block_count via set_len.
    if opts.block_count.is_some() {
        open.create(true);
    }
    let mut f = open
        .open(&opts.device)
        .map_err(|e| format!("cannot open {}: {e}", opts.device.display()))?;

    // Determine target size.
    let metadata = f
        .metadata()
        .map_err(|e| format!("stat failed: {e}"))?;
    let is_regular = metadata.file_type().is_file();
    let mut size = if let Some(blocks) = opts.block_count {
        // dosfstools block-count is in KiB.
        let bytes = blocks * 1024;
        if is_regular {
            f.set_len(bytes)
                .map_err(|e| format!("set_len failed: {e}"))?;
        }
        bytes
    } else if is_regular {
        metadata.len()
    } else {
        // Block device: ask the kernel via BLKGETSIZE64 (0x80081272).
        block_device_size(&f)?
    };
    if size == 0 {
        return Err("target is zero-sized — pass a block-count or size the image first".into());
    }
    // Round down to a multiple of the sector size.
    size -= size % opts.sector_size as u64;

    let geom = compute_geometry(&opts, size)?;

    let label_bytes = format_label(opts.label.as_deref().unwrap_or("NO NAME    "));
    let volume_id = opts.volume_id.unwrap_or_else(derive_volume_id);

    if opts.verbose {
        eprintln!(
            "mkfs.vfat: {:?}, {} total sectors × {} bytes, spc={} reserved={} spf={} clusters={}",
            geom.fat_type,
            geom.total_sectors,
            geom.bytes_per_sector,
            geom.sectors_per_cluster,
            geom.reserved_sectors,
            geom.sectors_per_fat,
            geom.data_clusters,
        );
    }

    // Before writing, zero out the metadata region: reserved + FATs + (root dir
    // for FAT12/16) + first data cluster. File::set_len gives us sparse zeros
    // for the whole file; for a block device we need to overwrite explicitly
    // since the device may contain stale data that would confuse probes.
    let meta_sectors = geom.reserved_sectors as u64
        + geom.num_fats as u64 * geom.sectors_per_fat as u64
        + {
            let rde = ((geom.root_entries * 32) + (geom.bytes_per_sector - 1))
                / geom.bytes_per_sector;
            rde as u64
        }
        + match geom.fat_type {
            FatType::Fat32 => geom.sectors_per_cluster as u64,
            _ => 0,
        };
    let meta_bytes = meta_sectors * geom.bytes_per_sector as u64;
    // Zero the metadata region (works for both regular files and block devs).
    zero_region(&mut f, 0, meta_bytes)
        .map_err(|e| format!("zeroing metadata region: {e}"))?;

    let mut w = Writer { f, bps: geom.bytes_per_sector };

    // 1. Boot sector at LBA 0.
    let boot = build_boot_sector(&geom, &opts, &label_bytes, volume_id);
    w.write_sector(0, &boot)
        .map_err(|e| format!("writing boot sector: {e}"))?;

    // 2. FSInfo sector + backup boot sector (FAT32 only).
    //
    // The canonical FAT32 layout puts FSInfo at LBA 1 and a backup
    // boot sector at LBA 6, with a backup FSInfo at LBA 7. Both
    // backups live inside the reserved region — if the user asked
    // for fewer reserved sectors than 8 (via `-R N` with N < 8)
    // those writes would land inside the FAT region and corrupt it
    // ("Cluster N out of range" from fsck.vfat at runtime).
    // When there's no room, skip the backup writes; fsck.vfat
    // prints a cosmetic "no backup boot sector" warning but
    // accepts the filesystem. This mirrors what upstream
    // dosfstools does for small -R values.
    if geom.fat_type == FatType::Fat32 {
        let fsinfo = build_fsinfo_sector(&geom);
        w.write_sector(1, &fsinfo)
            .map_err(|e| format!("writing fsinfo: {e}"))?;
        if geom.reserved_sectors >= 8 {
            w.write_sector(6, &boot)
                .map_err(|e| format!("writing backup boot: {e}"))?;
            w.write_sector(7, &fsinfo)
                .map_err(|e| format!("writing backup fsinfo: {e}"))?;
        }
    }

    // 3. FAT regions.
    let fat_first_sector = build_fat_first_sector(&geom, &opts);
    for fat_idx in 0..geom.num_fats {
        let fat_lba = geom.reserved_sectors as u64 + fat_idx as u64 * geom.sectors_per_fat as u64;
        w.write_sector(fat_lba, &fat_first_sector)
            .map_err(|e| format!("writing FAT #{fat_idx}: {e}"))?;
        // The remaining FAT sectors stay zero (already zeroed above).
    }

    // 4. Root directory — write the volume label entry.
    let root_sector = geom.root_dir_first_sector();
    let label_entry = build_root_volume_label_entry(&label_bytes);
    // Write just the first 32 bytes of the root cluster/area; rest is zero.
    let offset = root_sector * geom.bytes_per_sector as u64;
    w.write_at(offset, &label_entry)
        .map_err(|e| format!("writing root dir label: {e}"))?;

    w.f.sync_all()
        .map_err(|e| format!("fsync failed: {e}"))?;

    if opts.verbose {
        eprintln!(
            "mkfs.vfat: wrote {:?} filesystem, label={:?}, volume-id={:08X}",
            geom.fat_type,
            String::from_utf8_lossy(&label_bytes).trim_end(),
            volume_id
        );
    }
    Ok(())
}

/// Write zeros to [offset, offset+len) on the given file in chunks.
fn zero_region(f: &mut File, offset: u64, len: u64) -> std::io::Result<()> {
    const CHUNK: usize = 64 * 1024;
    let zeros = vec![0u8; CHUNK];
    f.seek(SeekFrom::Start(offset))?;
    let mut remaining = len;
    while remaining > 0 {
        let n = remaining.min(CHUNK as u64) as usize;
        f.write_all(&zeros[..n])?;
        remaining -= n as u64;
    }
    Ok(())
}

/// Query a block device's byte size via ioctl(BLKGETSIZE64).
fn block_device_size(f: &File) -> Result<u64, String> {
    #[cfg(target_os = "linux")]
    {
        use std::os::unix::io::AsRawFd;
        // BLKGETSIZE64 = _IOR(0x12, 114, size_t) on Linux
        // Decoded: dir=2 (READ), size=8, type=0x12, nr=114 -> 0x80081272
        const BLKGETSIZE64: libc_ulong = 0x80081272;
        let mut sz: u64 = 0;
        let rc = unsafe { ioctl(f.as_raw_fd(), BLKGETSIZE64, &mut sz as *mut u64) };
        if rc < 0 {
            return Err("BLKGETSIZE64 ioctl failed".into());
        }
        return Ok(sz);
    }
    #[cfg(not(target_os = "linux"))]
    {
        let _ = f;
        Err("block device sizing is only supported on Linux".into())
    }
}

#[cfg(target_os = "linux")]
#[allow(non_camel_case_types)]
type libc_ulong = core::ffi::c_ulong;

#[cfg(target_os = "linux")]
extern "C" {
    fn ioctl(fd: i32, request: libc_ulong, ...) -> i32;
}

fn main() -> ExitCode {
    let argv: Vec<String> = std::env::args().skip(1).collect();
    let opts = match parse_args(argv) {
        Ok(o) => o,
        Err(msg) => {
            eprintln!("mkfs.vfat: {msg}");
            return ExitCode::from(1);
        }
    };
    match run(opts) {
        Ok(()) => ExitCode::from(0),
        Err(e) => {
            eprintln!("mkfs.vfat: {e}");
            ExitCode::from(1)
        }
    }
}
