//! dumpe2fs — read-only superblock + GDT printer.
//!
//! Phase 6 scope: enough to drive shell scripts / monitoring
//! that parse the common `Label: value` lines. The output shape
//! mirrors what other ext-filesystem tools emit (a `Label:
//! value` line per field + an optional per-group section), but
//! each field is formatted from our own on-disk structs — no
//! upstream code is reused.
//!
//! Flags:
//!   -h    header-only (skip the per-group listing)
//!   -b    also print the bad-blocks list stored in inode 1
//!   -x    also print the SB + each GDT entry as a hex/ASCII
//!         dump before the decoded output; useful for ops /
//!         on-disk debugging workflows that want the raw bytes
//!   -H    single-line `key=value` summary for shell / monitoring
//!         consumption; suppresses the -h / -x long-form output
//!   --csv two-line CSV (header + data row) for monitoring
//!         pipelines; takes precedence over -H / -h / -x
//!   --json one-line compact JSON object for machine-readable
//!         output; mutually exclusive with -H (first one wins)
//!         and suppresses SB/GDT dump when set
//!   --journal
//!         after the SB/GDT sections, decode the JBD2 internal
//!         journal superblock stored at the first block of
//!         inode 8. Combines with -h / -x / -b; suppressed by
//!         -H / --csv.
//!   --compare-backups
//!         byte-compare every sparse_super backup SB against
//!         the primary (ignoring s_block_group_nr and
//!         s_checksum, which are expected to differ). Suppresses
//!         -h / -x / -H / --csv / --json long-form output.
//!   -o K=V[,K=V...]  extended options. Currently recognised:
//!         `superblock=N` — read the backup superblock at
//!         block N instead of the primary at byte 1024.
//!         Useful when the primary SB is corrupt and you want
//!         to inspect one of the sparse_super backups.
//!   -V    version
//!   any other leading `-X` is ignored with a warning

use std::path::PathBuf;
use std::process::ExitCode;

fn main() -> ExitCode {
    let args: Vec<String> = std::env::args().skip(1).collect();
    let mut header_only = false;
    let mut hex_mode = false;
    let mut bad_blocks = false;
    let mut oneline = false;
    let mut csv_mode = false;
    let mut json_mode = false;
    let mut journal_mode = false;
    let mut compare_backups = false;
    let mut path: Option<PathBuf> = None;
    // `-o superblock=N` override. When set we skip the
    // byte-1024 primary read and use the backup at block N
    // instead. Matches the shape fsck's `-E` uses: comma-
    // separated key=value pairs, unknown keys warn.
    let mut sb_override: Option<u64> = None;
    let mut iter = args.into_iter();
    while let Some(a) = iter.next() {
        match a.as_str() {
            "-h" => header_only = true,
            "-x" => hex_mode = true,
            "-b" => bad_blocks = true,
            "-H" => oneline = true,
            "--csv" => csv_mode = true,
            "--json" => json_mode = true,
            "--journal" => journal_mode = true,
            "--compare-backups" => compare_backups = true,
            "-V" => {
                println!("dumpe2fs 1.47.3-anvil (MIT)");
                return ExitCode::from(0);
            }
            "-o" => {
                let Some(arg) = iter.next() else {
                    eprintln!("dumpe2fs: -o requires an argument");
                    return ExitCode::from(16);
                };
                match parse_o_opts(&arg) {
                    Ok(o) => {
                        if let Some(n) = o.superblock { sb_override = Some(n); }
                    }
                    Err(e) => {
                        eprintln!("dumpe2fs: {e}");
                        return ExitCode::from(16);
                    }
                }
            }
            s if s.starts_with('-') => {
                eprintln!("dumpe2fs: unknown option {s} (ignored)");
            }
            _ => { path = Some(PathBuf::from(a)); }
        }
    }
    let Some(path) = path else {
        eprintln!("usage: dumpe2fs [-h] [-x] [-b] [-H] [--csv] [--json] [--journal] [--compare-backups] [-o opts] [-V] <device>");
        return ExitCode::from(16);
    };

    let mut fs = match open_fs(&path, sb_override) {
        Ok(fs) => fs,
        Err(e) => {
            eprintln!("dumpe2fs: open {}: {}", path.display(), e);
            return ExitCode::from(8);
        }
    };

    if compare_backups {
        // `--compare-backups` suppresses -h / -x / -H / --csv /
        // --json: callers using this mode only want the diff
        // report. Matches the exclusive-mode pattern already
        // used by --csv / --json / -H above.
        if let Err(e) = print_compare_backups(&mut fs) {
            eprintln!("dumpe2fs: {e}");
            return ExitCode::from(8);
        }
        return ExitCode::from(0);
    }

    if csv_mode {
        // `--csv` takes precedence over -H / -h / -x: monitoring
        // pipelines that asked for CSV shouldn't also get the
        // verbose / hex / oneline output mixed into stdout.
        print_csv(&fs);
        return ExitCode::from(0);
    }

    if json_mode {
        // `--json` suppresses the SB/GDT dump entirely. Mutually
        // exclusive with `-H`; if both were passed, `--json` wins
        // (documented above).
        print_json(&fs);
        return ExitCode::from(0);
    }

    if oneline {
        // `-H` takes precedence over -h / -x: shell scripts and
        // monitoring agents parsing one line shouldn't also get
        // the verbose / hex dump mixed into stdout.
        print_oneline(&fs);
        return ExitCode::from(0);
    }

    println!("dumpe2fs 1.47.3-anvil (MIT)");
    if hex_mode {
        if let Err(e) = dump_superblock_hex(&mut fs) {
            eprintln!("dumpe2fs: {e}");
            return ExitCode::from(8);
        }
    }
    print_superblock(&fs);
    if !header_only {
        if let Err(e) = print_groups(&mut fs, hex_mode) {
            eprintln!("dumpe2fs: {e}");
            return ExitCode::from(8);
        }
    }
    if bad_blocks {
        if let Err(e) = print_bad_blocks(&mut fs) {
            eprintln!("dumpe2fs: {e}");
            return ExitCode::from(8);
        }
    }
    if journal_mode {
        if let Err(e) = print_journal(&mut fs) {
            eprintln!("dumpe2fs: {e}");
            return ExitCode::from(8);
        }
    }
    ExitCode::from(0)
}

/// Emit a single whitespace-separated line of `key=value` pairs
/// describing the filesystem, in the shape:
///
///   uuid=... label=... block_size=N total_blocks=N free_blocks=N
///   total_inodes=N free_inodes=N groups=N state=... features=a,b,c
///
/// The field set is fixed so shell scripts can rely on the order;
/// `features` uses comma-join (not space) so the whole line still
/// splits cleanly on whitespace. `label=<none>` when absent.
/// Emit a two-line CSV (header + data row) describing the
/// filesystem, suitable for piping to monitoring systems:
///
///   uuid,label,block_size,total_blocks,free_blocks,total_inodes,
///       free_inodes,groups,state,features
///
/// Features are `|`-joined inside the cell so no feature list
/// ever contains a comma — keeps the CSV parseable without
/// quoting the features cell. The label cell is quoted only if
/// it would otherwise break the row (contains `,` or `"`); all
/// other cells are bare ASCII by construction.
fn print_csv(fs: &anvil_core::fs::Fs) {
    let sb = &fs.sb;
    let uuid = format_uuid(&sb.s_uuid);
    let label_raw = {
        let raw = &sb.s_volume_name;
        let end = raw.iter().position(|&b| b == 0).unwrap_or(raw.len());
        if end == 0 {
            String::new()
        } else {
            String::from_utf8_lossy(&raw[..end]).into_owned()
        }
    };
    let label = csv_quote(&label_raw);
    let log_block = sb.s_log_block_size;
    let block_size = 1024u64 << log_block;
    let total_blocks = sb.blocks_count();
    let free_blocks = sb.free_blocks();
    let total_inodes = sb.s_inodes_count;
    let free_inodes = sb.s_free_inodes_count;
    let groups = fs.groups_count;
    let state = oneline_state(sb.s_state);
    let features = decode_features_joined(
        sb.s_feature_compat,
        sb.s_feature_incompat,
        sb.s_feature_ro_compat,
        "|",
    );
    println!("uuid,label,block_size,total_blocks,free_blocks,total_inodes,free_inodes,groups,state,features");
    println!(
        "{uuid},{label},{block_size},{total_blocks},{free_blocks},{total_inodes},{free_inodes},{groups},{state},{features}"
    );
}

/// Quote a CSV cell per RFC 4180: bare if it contains neither
/// `,` nor `"`; otherwise wrap in double quotes and double any
/// interior `"`.
fn csv_quote(s: &str) -> String {
    if s.contains(',') || s.contains('"') {
        let escaped = s.replace('"', "\"\"");
        format!("\"{escaped}\"")
    } else {
        s.to_string()
    }
}

fn print_oneline(fs: &anvil_core::fs::Fs) {
    let sb = &fs.sb;
    let uuid = format_uuid(&sb.s_uuid);
    let label = {
        let raw = &sb.s_volume_name;
        let end = raw.iter().position(|&b| b == 0).unwrap_or(raw.len());
        if end == 0 {
            "<none>".into()
        } else {
            String::from_utf8_lossy(&raw[..end]).into_owned()
        }
    };
    let log_block = sb.s_log_block_size;
    let block_size = 1024u64 << log_block;
    let total_blocks = sb.blocks_count();
    let free_blocks = sb.free_blocks();
    let total_inodes = sb.s_inodes_count;
    let free_inodes = sb.s_free_inodes_count;
    let groups = fs.groups_count;
    let state = oneline_state(sb.s_state);
    let features = decode_features_joined(
        sb.s_feature_compat,
        sb.s_feature_incompat,
        sb.s_feature_ro_compat,
        ",",
    );
    println!(
        "uuid={uuid} label={label} block_size={block_size} total_blocks={total_blocks} \
         free_blocks={free_blocks} total_inodes={total_inodes} free_inodes={free_inodes} \
         groups={groups} state={state} features={features}"
    );
}

/// Emit a single-line compact JSON object describing the
/// filesystem. Hand-rolled (no serde dep) because the shape is
/// flat and well-known. String values have `"` and `\` escaped;
/// control characters are \uXXXX-escaped; non-UTF-8 label bytes
/// are lossy-decoded (U+FFFD replacement char) before escaping.
/// `features` is a JSON array of short tokens. Output ends with
/// a single newline (compact, no pretty-printing).
fn print_json(fs: &anvil_core::fs::Fs) {
    let sb = &fs.sb;
    let uuid = format_uuid(&sb.s_uuid);
    let label_raw = {
        let raw = &sb.s_volume_name;
        let end = raw.iter().position(|&b| b == 0).unwrap_or(raw.len());
        if end == 0 {
            String::new()
        } else {
            String::from_utf8_lossy(&raw[..end]).into_owned()
        }
    };
    let log_block = sb.s_log_block_size;
    let block_size = 1024u64 << log_block;
    let total_blocks = sb.blocks_count();
    let free_blocks = sb.free_blocks();
    let total_inodes = sb.s_inodes_count;
    let free_inodes = sb.s_free_inodes_count;
    let groups = fs.groups_count;
    let state = oneline_state(sb.s_state);
    let features_list = decode_features_list(
        sb.s_feature_compat,
        sb.s_feature_incompat,
        sb.s_feature_ro_compat,
    );

    let mut features_json = String::with_capacity(features_list.len() * 16 + 2);
    features_json.push('[');
    for (i, f) in features_list.iter().enumerate() {
        if i > 0 { features_json.push(','); }
        features_json.push('"');
        features_json.push_str(&json_escape_str(f));
        features_json.push('"');
    }
    features_json.push(']');

    // Single compact line, println! gives the trailing newline.
    let uuid_e = json_escape_str(&uuid);
    let label_e = json_escape_str(&label_raw);
    println!(
        "{{\"uuid\":\"{uuid_e}\",\"label\":\"{label_e}\",\"block_size\":{block_size},\"total_blocks\":{total_blocks},\"free_blocks\":{free_blocks},\"total_inodes\":{total_inodes},\"free_inodes\":{free_inodes},\"groups\":{groups},\"state\":\"{state}\",\"features\":{features_json}}}"
    );
}

/// Minimal JSON string-body escaper: doubles `\`, `"`, common
/// whitespace controls (`\n`/`\r`/`\t`), and \uXXXX-escapes any
/// other C0 control char. Non-ASCII code points pass through
/// as UTF-8, which RFC 8259 permits unescaped.
fn json_escape_str(s: &str) -> String {
    let mut out = String::with_capacity(s.len());
    for c in s.chars() {
        match c {
            '\\' => out.push_str("\\\\"),
            '"' => out.push_str("\\\""),
            '\n' => out.push_str("\\n"),
            '\r' => out.push_str("\\r"),
            '\t' => out.push_str("\\t"),
            c if (c as u32) < 0x20 => {
                out.push_str(&format!("\\u{:04x}", c as u32));
            }
            c => out.push(c),
        }
    }
    out
}

/// Feature-list variant: returns a Vec<String> of short tokens
/// for JSON array construction. Mirrors the bit tables used by
/// `decode_features_joined` so the decoded surface stays in sync.
fn decode_features_list(compat: u32, incompat: u32, ro: u32) -> Vec<String> {
    let mut out: Vec<String> = Vec::new();
    let compat_names: &[(u32, &str)] = &[
        (0x0001, "dir_prealloc"),
        (0x0002, "imagic_inodes"),
        (0x0004, "has_journal"),
        (0x0008, "ext_attr"),
        (0x0010, "resize_inode"),
        (0x0020, "dir_index"),
        (0x0040, "lazy_bg"),
        (0x0100, "sparse_super2"),
    ];
    let incompat_names: &[(u32, &str)] = &[
        (0x0001, "compression"),
        (0x0002, "filetype"),
        (0x0004, "recover"),
        (0x0008, "journal_dev"),
        (0x0010, "meta_bg"),
        (0x0040, "extents"),
        (0x0080, "64bit"),
        (0x0100, "mmp"),
        (0x0200, "flex_bg"),
        (0x0400, "ea_inode"),
        (0x1000, "dirdata"),
        (0x2000, "csum_seed"),
        (0x4000, "largedir"),
        (0x8000, "inline_data"),
        (0x10000, "encrypt"),
        (0x20000, "casefold"),
    ];
    let ro_names: &[(u32, &str)] = &[
        (0x0001, "sparse_super"),
        (0x0002, "large_file"),
        (0x0004, "btree_dir"),
        (0x0008, "huge_file"),
        (0x0010, "gdt_csum"),
        (0x0020, "dir_nlink"),
        (0x0040, "extra_isize"),
        (0x0100, "quota"),
        (0x0200, "bigalloc"),
        (0x0400, "metadata_csum"),
        (0x0800, "replica"),
        (0x1000, "readonly"),
        (0x2000, "project"),
        (0x8000, "verity"),
    ];
    let mut unknown = compat;
    for &(bit, name) in compat_names {
        if compat & bit != 0 { out.push(name.to_string()); unknown &= !bit; }
    }
    if unknown != 0 { out.push(format!("compat_unknown:0x{unknown:x}")); }
    let mut unknown = incompat;
    for &(bit, name) in incompat_names {
        if incompat & bit != 0 { out.push(name.to_string()); unknown &= !bit; }
    }
    if unknown != 0 { out.push(format!("incompat_unknown:0x{unknown:x}")); }
    let mut unknown = ro;
    for &(bit, name) in ro_names {
        if ro & bit != 0 { out.push(name.to_string()); unknown &= !bit; }
    }
    if unknown != 0 { out.push(format!("ro_compat_unknown:0x{unknown:x}")); }
    out
}

/// Single-token state for `-H`: `clean`, `with_errors`, or
/// `not_clean`. Underscored so the whole `state=...` token is
/// one shell-safe word.
fn oneline_state(s: u16) -> &'static str {
    if s & 0x0002 != 0 { "with_errors" }
    else if s & 0x0001 != 0 { "clean" }
    else { "not_clean" }
}

/// Walk inode 1 (EXT4_BAD_INO), treat each data block it owns as
/// a flat packed array of little-endian u32 block numbers, and
/// print every entry until the first zero terminator.
///
/// The bad-blocks inode is an ordinary file layout-wise: on ext4
/// it uses the extent tree (EXT4_EXTENTS_FL), on ext2/ext3 it
/// falls through to the legacy block map — `walk_extents` picks
/// the right path for us. Each data block is read in full and
/// scanned 4 bytes at a time; the list is null-terminated per
/// the upstream on-disk layout notes.
fn print_bad_blocks(fs: &mut anvil_core::fs::Fs) -> std::io::Result<()> {
    println!();
    let ino = match fs.read_inode(1) {
        Ok(i) => i,
        Err(_) => {
            // No readable inode 1 means no bad-blocks list to
            // report. Upstream tools print "(none)" here too.
            println!("Bad blocks: (none)");
            return Ok(());
        }
    };
    let mut runs: Vec<(u64, u16)> = Vec::new();
    anvil_core::extent::walk_extents(fs, &ino, |r| {
        runs.push((r.physical, r.length));
    })?;

    let bs = fs.block_size as usize;
    let mut out: Vec<u32> = Vec::new();
    let mut buf = vec![0u8; bs];
    'outer: for (phys, len) in runs {
        for off in 0..len as u64 {
            fs.read_block(phys + off, &mut buf)?;
            let mut i = 0;
            while i + 4 <= bs {
                let v = u32::from_le_bytes([buf[i], buf[i+1], buf[i+2], buf[i+3]]);
                if v == 0 {
                    break 'outer;
                }
                out.push(v);
                i += 4;
            }
        }
    }

    if out.is_empty() {
        println!("Bad blocks: (none)");
    } else {
        println!("Bad blocks:");
        for blk in out {
            println!("{blk}");
        }
    }
    Ok(())
}

/// Decode the on-disk JBD2 journal superblock of an internal
/// journal (inode 8) and print the subset of fields most often
/// asked about in monitoring / ops workflows.
///
/// This is a clean-room implementation distinct from debugfs's
/// `logdump` — we only need the SB fields, not a transaction
/// walk, and the output shape matches the `Journal <field>:` key
/// convention the rest of dumpe2fs uses so the whole run stays
/// scriptable with a single `grep Journal` pass.
///
/// Layout notes:
/// - The journal SB lives at logical block 0 of inode 8, which
///   on ext4 resolves through the extent tree.
/// - Every multi-byte field is big-endian on disk (JBD2
///   convention inherited from ext3).
fn print_journal(fs: &mut anvil_core::fs::Fs) -> std::io::Result<()> {
    println!();
    if fs.sb.s_feature_compat & anvil_core::consts::EXT4_FEATURE_COMPAT_HAS_JOURNAL == 0 {
        println!("Journal: (none)");
        return Ok(());
    }

    let jino = fs.read_inode(anvil_core::consts::EXT4_JOURNAL_INO)?;
    let jsize_bytes = jino.size();
    let bs = fs.block_size;

    // Locate logical block 0 of the journal inode via the extent
    // tree — that is where the JBD2 SB lives.
    let mut first_phys: Option<u64> = None;
    anvil_core::extent::walk_extents(fs, &jino, |r| {
        if first_phys.is_none() && r.logical == 0 {
            first_phys = Some(r.physical);
        }
    })?;
    let Some(first_phys) = first_phys else {
        return Err(std::io::Error::new(
            std::io::ErrorKind::InvalidData,
            "journal inode has no extents",
        ));
    };

    let mut buf = vec![0u8; bs as usize];
    fs.read_block(first_phys, &mut buf)?;

    if buf.len() < core::mem::size_of::<anvil_core::jbd2::JournalSuperblock>() {
        return Err(std::io::Error::new(
            std::io::ErrorKind::InvalidData,
            "block too small to hold JBD2 superblock",
        ));
    }
    let jsb: anvil_core::jbd2::JournalSuperblock =
        unsafe { *(buf.as_ptr() as *const anvil_core::jbd2::JournalSuperblock) };

    let sequence  = u32::from_be(jsb.s_header.h_sequence);
    let blocksize = u32::from_be(jsb.s_blocksize);
    let maxlen    = u32::from_be(jsb.s_maxlen);
    let first     = u32::from_be(jsb.s_first);
    let fincompat = u32::from_be(jsb.s_feature_incompat);
    let csum      = u32::from_be(jsb.s_checksum);

    // Feature string: the shape we surface today is "(none)" or
    // a single "checksum_v3" token. Other JBD2 incompat bits are
    // decoded but not surfaced — matches the task spec, and keeps
    // the output stable for grep-based monitoring.
    let features = if fincompat & anvil_core::jbd2::JBD2_FEATURE_INCOMPAT_CSUM_V3 != 0 {
        "checksum_v3"
    } else {
        "(none)"
    };

    println!("Journal size:         {} bytes", jsize_bytes);
    println!("Journal inode:        {}", anvil_core::consts::EXT4_JOURNAL_INO);
    println!("Journal sequence:     {}", sequence);
    println!("Journal features:     {}", features);
    println!("Journal blocksize:    {}", blocksize);
    println!("Journal maxlen:       {}", maxlen);
    println!("Journal first:        {}", first);
    if csum != 0 {
        println!("Journal checksum:     0x{:08X}", csum);
    }
    Ok(())
}

/// Hex/ASCII dump of a byte slice, "xxd-style": 4-digit hex
/// offset, 16 bytes per row as space-separated pairs, then a
/// printable-ASCII column (0x20..0x7e kept, anything else
/// replaced with ".").
///
/// We roll our own instead of pulling in a crate so dumpe2fs
/// stays dependency-light, and so the formatting is clearly
/// ours — not lifted from any upstream helper.
fn hex_dump(bytes: &[u8]) {
    for (row_idx, chunk) in bytes.chunks(16).enumerate() {
        let offset = row_idx * 16;
        let mut hex_part = String::with_capacity(16 * 3);
        for (i, b) in chunk.iter().enumerate() {
            if i > 0 { hex_part.push(' '); }
            hex_part.push_str(&format!("{:02x}", b));
        }
        // Pad the hex column to a fixed width so short final
        // rows (if any) still line up the ASCII gutter.
        let hex_width = 16 * 3 - 1;
        let mut ascii_part = String::with_capacity(16);
        for &b in chunk {
            if (0x20..=0x7e).contains(&b) {
                ascii_part.push(b as char);
            } else {
                ascii_part.push('.');
            }
        }
        println!("{:04x}:  {:<width$}   {}",
                 offset, hex_part, ascii_part, width = hex_width);
    }
}

fn dump_superblock_hex(fs: &mut anvil_core::fs::Fs) -> std::io::Result<()> {
    // Re-read the 1024-byte SB from disk rather than trying to
    // reserialise the in-memory `Superblock` struct — packed
    // layouts + native-endian fields make that fragile, and the
    // on-disk bytes are what ops actually want to see.
    let mut buf = [0u8; 1024];
    fs.dev.read_at(1024, &mut buf)?;
    println!("Superblock raw bytes (offset 1024):");
    hex_dump(&buf);
    println!();
    Ok(())
}

fn print_superblock(fs: &anvil_core::fs::Fs) {
    let sb = &fs.sb;
    // Pre-copy packed fields to locals so `println!` can reach
    // them by reference without tripping the align-of rule.
    let magic = sb.s_magic;
    let inodes = sb.s_inodes_count;
    let blocks = sb.blocks_count();
    let r_blocks = sb.s_r_blocks_count_lo;
    let free_blocks = sb.free_blocks();
    let free_inodes = sb.s_free_inodes_count;
    let first_block = sb.s_first_data_block;
    let log_block = sb.s_log_block_size;
    let blocks_per_group = sb.s_blocks_per_group;
    let inodes_per_group = sb.s_inodes_per_group;
    let inode_size = fs.inode_size;
    let mkfs_time = sb.s_mkfs_time;
    let mtime = sb.s_mtime;
    let wtime = sb.s_wtime;
    let mnt_count = sb.s_mnt_count;
    let max_mnt = sb.s_max_mnt_count;
    let lastcheck = sb.s_lastcheck;
    let rev_level = sb.s_rev_level;
    let state = sb.s_state;
    let compat = sb.s_feature_compat;
    let incompat = sb.s_feature_incompat;
    let ro_compat = sb.s_feature_ro_compat;
    let uuid = sb.s_uuid;
    let volume_name = &sb.s_volume_name;
    let errors = sb.s_errors;
    let minor_rev = sb.s_minor_rev_level;
    let creator_os = sb.s_creator_os;
    let checksum_type = sb.s_checksum_type;
    let default_mnt_opts = sb.s_default_mount_opts;
    let journal_inum = sb.s_journal_inum;

    row("Filesystem volume name",  display_label(volume_name));
    row("Last mount point",        display_last_mounted(&sb.s_last_mounted));
    row("Filesystem UUID",         format_uuid(&uuid));
    row("Filesystem magic number", format!("0x{magic:04X}"));
    row("Filesystem revision #",   rev_level.to_string());
    row("Filesystem features",     decode_features(compat, incompat, ro_compat));
    row("Filesystem state",        decode_state(state));
    row("Errors behavior",         decode_errors(errors));
    row("Filesystem OS type",      decode_os(creator_os));
    row("Inode count",             inodes.to_string());
    row("Block count",             blocks.to_string());
    row("Reserved block count",    r_blocks.to_string());
    row("Free blocks",             free_blocks.to_string());
    row("Free inodes",             free_inodes.to_string());
    row("First block",             first_block.to_string());
    row("Block size",              (1024u64 << log_block).to_string());
    row("Blocks per group",        blocks_per_group.to_string());
    row("Inodes per group",        inodes_per_group.to_string());
    row("Inode size",              inode_size.to_string());
    row("Minor rev",               minor_rev.to_string());
    row("Filesystem created",      format_time(mkfs_time));
    row("Last write time",         format_time(wtime));
    row("Last mount time",         format_time(mtime));
    row("Mount count",             mnt_count.to_string());
    row("Maximum mount count",     max_mnt.to_string());
    row("Last checked",            format_time(lastcheck));
    row("Default mount opts",      format!("0x{default_mnt_opts:x}"));
    row("Journal inode",           journal_inum.to_string());
    if checksum_type != 0 {
        row("Checksum type", checksum_type.to_string());
    }
}

fn print_groups(fs: &mut anvil_core::fs::Fs, hex_mode: bool) -> std::io::Result<()> {
    println!();
    let desc_size = fs.desc_size as usize;
    for gi in 0..fs.groups_count {
        let d = fs.gdt[gi as usize];
        let bb = fs.group_block_bitmap(gi);
        let ib = fs.group_inode_bitmap(gi);
        let it = fs.group_inode_table(gi);
        let free_blocks_lo = d.bg_free_blocks_count_lo as u32;
        let free_blocks_hi = if fs.has_64bit { d.bg_free_blocks_count_hi as u32 } else { 0 };
        let free_blocks = (free_blocks_hi << 16) | free_blocks_lo;
        let free_inodes_lo = d.bg_free_inodes_count_lo as u32;
        let free_inodes_hi = if fs.has_64bit { d.bg_free_inodes_count_hi as u32 } else { 0 };
        let free_inodes = (free_inodes_hi << 16) | free_inodes_lo;
        let used_dirs_lo = d.bg_used_dirs_count_lo as u32;
        let used_dirs_hi = if fs.has_64bit { d.bg_used_dirs_count_hi as u32 } else { 0 };
        let used_dirs = (used_dirs_hi << 16) | used_dirs_lo;
        let flags = d.bg_flags;
        if hex_mode {
            // Use the already-present serializer rather than
            // re-reading from disk; for the GDT entry it's the
            // exact on-disk shape, and keeps us from caring
            // about descriptor-size packing in the dumper.
            let raw = d.to_bytes(desc_size);
            println!("Group {gi} descriptor raw (desc_size={desc_size}):");
            hex_dump(&raw);
            println!();
        }
        println!("Group {gi}:");
        println!("  block bitmap : {bb}");
        println!("  inode bitmap : {ib}");
        println!("  inode table  : {it}");
        println!("  free blocks  : {free_blocks}");
        println!("  free inodes  : {free_inodes}");
        println!("  used dirs    : {used_dirs}");
        println!("  flags        : 0x{flags:04x}{}",
                 decode_bg_flags(flags));
    }
    Ok(())
}

fn row(label: &str, value: impl AsRef<str>) {
    // Pad the label column to 26 chars so the colons line up
    // — typical "Label: value" layout used by most filesystem
    // dumping tools; keep it loose so short fields still fit.
    println!("{:<26}{}", format!("{label}:"), value.as_ref());
}

fn display_label(raw: &[u8; 16]) -> String {
    let end = raw.iter().position(|&b| b == 0).unwrap_or(raw.len());
    if end == 0 { return "<none>".into(); }
    String::from_utf8_lossy(&raw[..end]).into_owned()
}

fn display_last_mounted(raw: &[u8; 64]) -> String {
    let end = raw.iter().position(|&b| b == 0).unwrap_or(raw.len());
    if end == 0 { return "<not available>".into(); }
    String::from_utf8_lossy(&raw[..end]).into_owned()
}

fn format_uuid(bytes: &[u8; 16]) -> String {
    if bytes.iter().all(|&b| b == 0) { return "<none>".into(); }
    let b = bytes;
    format!(
        "{:02x}{:02x}{:02x}{:02x}-{:02x}{:02x}-{:02x}{:02x}-{:02x}{:02x}-{:02x}{:02x}{:02x}{:02x}{:02x}{:02x}",
        b[0],b[1],b[2],b[3], b[4],b[5], b[6],b[7], b[8],b[9],
        b[10],b[11],b[12],b[13],b[14],b[15])
}

fn format_time(t: u32) -> String {
    if t == 0 { return "n/a".into(); }
    // Simple epoch-seconds formatter. Avoids pulling in chrono
    // so the dumpe2fs binary stays dependency-light.
    format!("{} (epoch)", t)
}

fn decode_state(s: u16) -> String {
    let mut parts: Vec<&str> = Vec::new();
    if s & 0x0001 != 0 { parts.push("clean"); }
    if s & 0x0002 != 0 { parts.push("with errors"); }
    if s & 0x0004 != 0 { parts.push("orphans"); }
    if parts.is_empty() { "not clean".into() } else { parts.join(", ") }
}

fn decode_errors(e: u16) -> &'static str {
    match e {
        1 => "Continue",
        2 => "Remount read-only",
        3 => "Panic",
        _ => "Unknown",
    }
}

fn decode_os(o: u32) -> &'static str {
    match o {
        0 => "Linux",
        1 => "Hurd",
        2 => "Masix",
        3 => "FreeBSD",
        4 => "Lites",
        _ => "Unknown",
    }
}

fn decode_features(compat: u32, incompat: u32, ro: u32) -> String {
    decode_features_joined(compat, incompat, ro, " ")
}

/// Same decode as `decode_features`, but with a caller-chosen
/// separator so the `-H` one-liner can comma-join to keep the
/// whole field splittable as a single shell word.
fn decode_features_joined(compat: u32, incompat: u32, ro: u32, sep: &str) -> String {
    // Map the well-documented feature-bit names for each of the
    // three category words. Any bit we don't recognise shows up
    // as `0xNN` so output stays lossless.
    let mut out: Vec<String> = Vec::new();
    let compat_names: &[(u32, &str)] = &[
        (0x0001, "dir_prealloc"),
        (0x0002, "imagic_inodes"),
        (0x0004, "has_journal"),
        (0x0008, "ext_attr"),
        (0x0010, "resize_inode"),
        (0x0020, "dir_index"),
        (0x0040, "lazy_bg"),
        (0x0100, "sparse_super2"),
    ];
    let incompat_names: &[(u32, &str)] = &[
        (0x0001, "compression"),
        (0x0002, "filetype"),
        (0x0004, "recover"),
        (0x0008, "journal_dev"),
        (0x0010, "meta_bg"),
        (0x0040, "extents"),
        (0x0080, "64bit"),
        (0x0100, "mmp"),
        (0x0200, "flex_bg"),
        (0x0400, "ea_inode"),
        (0x1000, "dirdata"),
        (0x2000, "csum_seed"),
        (0x4000, "largedir"),
        (0x8000, "inline_data"),
        (0x10000, "encrypt"),
        (0x20000, "casefold"),
    ];
    // Public RO_COMPAT bit assignments from the ext4 on-disk
    // format doc (kernel Documentation/filesystems/ext4/).
    let ro_names: &[(u32, &str)] = &[
        (0x0001, "sparse_super"),
        (0x0002, "large_file"),
        (0x0004, "btree_dir"),
        (0x0008, "huge_file"),
        (0x0010, "gdt_csum"),
        (0x0020, "dir_nlink"),
        (0x0040, "extra_isize"),
        (0x0100, "quota"),
        (0x0200, "bigalloc"),
        (0x0400, "metadata_csum"),
        (0x0800, "replica"),
        (0x1000, "readonly"),
        (0x2000, "project"),
        (0x8000, "verity"),
    ];
    let mut unknown = compat;
    for &(bit, name) in compat_names {
        if compat & bit != 0 { out.push(name.to_string()); unknown &= !bit; }
    }
    if unknown != 0 { out.push(format!("compat_unknown:0x{unknown:x}")); }
    let mut unknown = incompat;
    for &(bit, name) in incompat_names {
        if incompat & bit != 0 { out.push(name.to_string()); unknown &= !bit; }
    }
    if unknown != 0 { out.push(format!("incompat_unknown:0x{unknown:x}")); }
    let mut unknown = ro;
    for &(bit, name) in ro_names {
        if ro & bit != 0 { out.push(name.to_string()); unknown &= !bit; }
    }
    if unknown != 0 { out.push(format!("ro_compat_unknown:0x{unknown:x}")); }
    if out.is_empty() { "(none)".into() } else { out.join(sep) }
}

fn decode_bg_flags(f: u16) -> String {
    let mut parts: Vec<&str> = Vec::new();
    if f & 0x0001 != 0 { parts.push("INODE_UNINIT"); }
    if f & 0x0002 != 0 { parts.push("BLOCK_UNINIT"); }
    if f & 0x0004 != 0 { parts.push("INODE_ZEROED"); }
    if parts.is_empty() { String::new() } else { format!(" [{}]", parts.join(",")) }
}

/// Parsed view of a `-o key=value[,key=value...]` argument.
/// Only `superblock=N` is currently consumed; any other key
/// warns but doesn't fail — matches how fsck's `-E` treats
/// unrecognised options.
struct OOpts {
    superblock: Option<u64>,
}

fn parse_o_opts(arg: &str) -> Result<OOpts, String> {
    let mut out = OOpts { superblock: None };
    for tok in arg.split(',') {
        let tok = tok.trim();
        if tok.is_empty() { continue; }
        let (k, v) = match tok.split_once('=') {
            Some(kv) => kv,
            None => {
                eprintln!("dumpe2fs: -o: unknown option {tok} (ignored)");
                continue;
            }
        };
        match k {
            "superblock" => {
                let n: u64 = v.parse()
                    .map_err(|_| format!("-o superblock=: not a number: {v}"))?;
                if n == 0 {
                    return Err("-o superblock=0 is not a valid backup block".into());
                }
                out.superblock = Some(n);
            }
            other => {
                eprintln!("dumpe2fs: -o: unknown option {other}= (ignored)");
            }
        }
    }
    Ok(out)
}

/// Open the fs either via the normal primary-SB path, or via
/// a backup at the caller-requested block number. For the
/// backup case we don't know the block size yet, so probe
/// both 1 KiB and 4 KiB offsets and pick whichever yields a
/// superblock with magic 0xEF53 at offset 56. Falls through
/// to an error if neither hits.
fn open_fs(path: &std::path::Path, sb_override: Option<u64>)
    -> std::io::Result<anvil_core::fs::Fs>
{
    let Some(n) = sb_override else {
        return anvil_core::fs::Fs::open(path);
    };
    let mut dev = anvil_core::io::Device::open(path)?;
    let mut buf = [0u8; 1024];
    // Probe order: 1 KiB first, then 4 KiB. Magic at offset
    // 56 (u16 LE, 0xEF53) is the cheapest on-disk signature.
    let candidates = [1024u64, 4096u64];
    let mut found: Option<(u64, [u8; 1024])> = None;
    for bs in candidates {
        let off = match n.checked_mul(bs) {
            Some(v) => v,
            None => continue,
        };
        if off + 1024 > dev.size { continue; }
        let mut tmp = [0u8; 1024];
        if dev.read_at(off, &mut tmp).is_err() { continue; }
        let magic = u16::from_le_bytes([tmp[56], tmp[57]]);
        if magic == 0xEF53 {
            buf = tmp;
            found = Some((bs, tmp));
            break;
        }
    }
    let Some((_, _)) = found else {
        return Err(std::io::Error::new(std::io::ErrorKind::InvalidData,
            format!("no valid backup superblock at block {n} (tried 1 KiB and 4 KiB offsets)")));
    };
    let sb: anvil_core::superblock::Superblock = unsafe {
        *(buf.as_ptr() as *const anvil_core::superblock::Superblock)
    };
    anvil_core::fs::Fs::from_raw_sb(dev, sb)
}


/// Decide whether group `gi` carries a sparse_super backup SB.
/// The placement rule is the public SPARSE_SUPER convention:
/// groups 0, 1, and every pure power of 3, 5, or 7 below the
/// total group count. Re-implemented here so dumpe2fs does not
/// depend on anvil_core's private helper.
fn is_sparse_backup_group(gi: u64) -> bool {
    if gi == 0 || gi == 1 { return true; }
    for &base in &[3u64, 5, 7] {
        let mut p: u64 = base;
        while p <= gi {
            if p == gi { return true; }
            p = match p.checked_mul(base) { Some(v) => v, None => break };
        }
    }
    false
}

/// Byte offset of the backup superblock for group `gi`.
///
/// Layout:
/// - `block_size == 1024`: the group's first block is the boot
///   block, so the backup SB lives one block later -
///   `group_start_block * 1024 + 1024`.
/// - `block_size  > 1024`: the SB lives inside the first block
///   of the group at an internal offset of 1024 -
///   `group_start_block * block_size + 1024`.
///
/// `group_start_block` here is `gi * blocks_per_group`, matching
/// the offset used by mkfs/e2fsck when they write the backups.
fn backup_sb_byte_offset(gi: u64, blocks_per_group: u64, block_size: u64) -> u64 {
    let group_start_block = gi * blocks_per_group;
    if block_size == 1024 {
        group_start_block * 1024 + 1024
    } else {
        group_start_block * block_size + 1024
    }
}

/// Mask out SB byte fields that are expected to differ between
/// primary and backups before the byte-compare:
/// - `s_block_group_nr` (u16) at offset 0x5A - each backup
///   stores its own group number.
/// - `s_checksum` (u32) at offset 0x3FC - each backup's
///   checksum is over its own bytes, not the primary's.
fn mask_volatile_sb_fields(buf: &mut [u8; 1024]) {
    buf[0x5A] = 0;
    buf[0x5B] = 0;
    buf[0x3FC] = 0;
    buf[0x3FD] = 0;
    buf[0x3FE] = 0;
    buf[0x3FF] = 0;
}

/// Human-readable name for the SB field that starts at
/// `offset`, used when labelling a differing byte range. Only
/// offsets we actually expect to see in a meaningful diff are
/// named; anything unrecognised falls through to the caller,
/// which prints a raw offset range instead.
fn sb_field_name(offset: usize) -> Option<&'static str> {
    const FIELDS: &[(usize, usize, &str)] = &[
        (0x00, 4,  "s_inodes_count"),
        (0x04, 4,  "s_blocks_count_lo"),
        (0x08, 4,  "s_r_blocks_count_lo"),
        (0x0C, 4,  "s_free_blocks_count_lo"),
        (0x10, 4,  "s_free_inodes_count"),
        (0x14, 4,  "s_first_data_block"),
        (0x18, 4,  "s_log_block_size"),
        (0x1C, 4,  "s_log_cluster_size"),
        (0x20, 4,  "s_blocks_per_group"),
        (0x24, 4,  "s_clusters_per_group"),
        (0x28, 4,  "s_inodes_per_group"),
        (0x2C, 4,  "s_mtime"),
        (0x30, 4,  "s_wtime"),
        (0x34, 2,  "s_mnt_count"),
        (0x36, 2,  "s_max_mnt_count"),
        (0x38, 2,  "s_magic"),
        (0x3A, 2,  "s_state"),
        (0x3C, 2,  "s_errors"),
        (0x3E, 2,  "s_minor_rev_level"),
        (0x40, 4,  "s_lastcheck"),
        (0x44, 4,  "s_checkinterval"),
        (0x48, 4,  "s_creator_os"),
        (0x4C, 4,  "s_rev_level"),
        (0x50, 2,  "s_def_resuid"),
        (0x52, 2,  "s_def_resgid"),
        (0x54, 4,  "s_first_ino"),
        (0x58, 2,  "s_inode_size"),
        (0x5C, 4,  "s_feature_compat"),
        (0x60, 4,  "s_feature_incompat"),
        (0x64, 4,  "s_feature_ro_compat"),
        (0x68, 16, "s_uuid"),
        (0x78, 16, "s_volume_name"),
        (0x88, 64, "s_last_mounted"),
        (0xC8, 4,  "s_algorithm_usage_bitmap"),
        (0xCC, 1,  "s_prealloc_blocks"),
        (0xCD, 1,  "s_prealloc_dir_blocks"),
        (0xCE, 2,  "s_reserved_gdt_blocks"),
        (0xD0, 16, "s_journal_uuid"),
        (0xE0, 4,  "s_journal_inum"),
        (0xE4, 4,  "s_journal_dev"),
        (0xE8, 4,  "s_last_orphan"),
        (0xEC, 16, "s_hash_seed"),
        (0xFC, 1,  "s_def_hash_version"),
        (0x100, 4, "s_default_mount_opts"),
        (0x104, 4, "s_first_meta_bg"),
        (0x108, 4, "s_mkfs_time"),
        (0x10C, 68,"s_jnl_blocks"),
        (0x150, 4, "s_blocks_count_hi"),
        (0x154, 4, "s_r_blocks_count_hi"),
        (0x158, 4, "s_free_blocks_count_hi"),
        (0x15C, 2, "s_min_extra_isize"),
        (0x15E, 2, "s_want_extra_isize"),
        (0x160, 4, "s_flags"),
        (0x164, 2, "s_raid_stride"),
        (0x166, 2, "s_mmp_interval"),
        (0x168, 8, "s_mmp_block"),
        (0x170, 4, "s_raid_stripe_width"),
        (0x174, 1, "s_log_groups_per_flex"),
        (0x175, 1, "s_checksum_type"),
        (0x178, 8, "s_kbytes_written"),
    ];
    for &(off, sz, name) in FIELDS {
        if offset >= off && offset < off + sz {
            return Some(name);
        }
    }
    None
}

/// Read 1024 bytes at `byte_offset`. Returns `None` if the
/// device is too short at that offset or the read fails -
/// callers treat that the same as "backup is missing" and
/// record it as a diff rather than aborting the whole run.
fn read_sb_block(dev: &mut anvil_core::io::Device, byte_offset: u64) -> Option<[u8; 1024]> {
    let end = byte_offset.checked_add(1024)?;
    if end > dev.size { return None; }
    let mut buf = [0u8; 1024];
    dev.read_at(byte_offset, &mut buf).ok()?;
    Some(buf)
}

/// Compare each sparse_super backup superblock against the
/// primary and print a one-line report per group:
///
///   Primary superblock (byte 1024): OK
///   Backup at group 1 (byte N): identical
///   Backup at group 3 (byte N): DIFFERS at offsets 0xAA-0xBB (s_volume_name)
///
/// `s_block_group_nr` and `s_checksum` are masked out of both
/// sides before the byte compare, since they are expected to
/// differ by design. If the filesystem does not have the
/// SPARSE_SUPER feature bit, we emit a single notice line and
/// return - there are no backups to diff.
fn print_compare_backups(fs: &mut anvil_core::fs::Fs) -> std::io::Result<()> {
    use anvil_core::consts::EXT4_FEATURE_RO_COMPAT_SPARSE_SUPER;

    if fs.sb.s_feature_ro_compat & EXT4_FEATURE_RO_COMPAT_SPARSE_SUPER == 0 {
        println!("filesystem does not use sparse_super; no backups to compare");
        return Ok(());
    }

    let mut primary = match read_sb_block(&mut fs.dev, 1024) {
        Some(b) => b,
        None => {
            println!("Primary superblock (byte 1024): UNREADABLE");
            return Ok(());
        }
    };
    println!("Primary superblock (byte 1024): OK");
    mask_volatile_sb_fields(&mut primary);

    let groups = fs.groups_count;
    let bpg = fs.blocks_per_group;
    let bs  = fs.block_size;

    for gi in 0..groups {
        if !is_sparse_backup_group(gi) { continue; }
        if gi == 0 { continue; }
        let off = backup_sb_byte_offset(gi, bpg, bs);
        let Some(mut backup) = read_sb_block(&mut fs.dev, off) else {
            println!("Backup at group {gi} (byte {off}): UNREADABLE");
            continue;
        };
        mask_volatile_sb_fields(&mut backup);

        let mut runs: Vec<(usize, usize)> = Vec::new();
        let mut i = 0usize;
        while i < 1024 {
            if primary[i] != backup[i] {
                let start = i;
                while i < 1024 && primary[i] != backup[i] { i += 1; }
                runs.push((start, i - 1));
            } else {
                i += 1;
            }
        }

        if runs.is_empty() {
            println!("Backup at group {gi} (byte {off}): identical");
        } else {
            for (s, e) in &runs {
                let label = match sb_field_name(*s) {
                    Some(n) => format!(" ({n})"),
                    None => String::new(),
                };
                println!(
                    "Backup at group {gi} (byte {off}): DIFFERS at offsets 0x{:X}-0x{:X}{}",
                    s, e, label
                );
            }
        }
    }
    Ok(())
}
