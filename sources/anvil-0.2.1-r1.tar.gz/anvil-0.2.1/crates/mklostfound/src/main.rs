//! mklost+found — ensure /lost+found exists on an ext4 image and
//! has at least 16 KiB of preallocated directory blocks. Mirrors
//! the upstream e2fsprogs binary of the same name: kept around so
//! that when fsck reconnects orphan inodes at runtime, the
//! reconnection step doesn't have to allocate fresh data blocks
//! (which would itself need extra free space — a chicken/egg
//! problem on a damaged or near-full fs).
//!
//! Invocation:
//!   mklost+found <device>
//!   mklost+found -V
//!
//! Implementation notes:
//!   * The on-disk binary is registered with Cargo as
//!     `mklostfound` because Cargo bin names disallow `+`. The
//!     packaging step installs a `mklost+found` symlink.
//!   * No code is derived from e2fsprogs. The on-disk layout
//!     comes from the public ext4 documentation in the Linux
//!     kernel tree (Documentation/filesystems/ext4/), and the
//!     allocator/csum sequencing follows the same shape that
//!     the in-tree debugfs `mkdir` already implements.

use std::path::PathBuf;
use std::process::ExitCode;

use anvil_core::consts::*;
use anvil_core::extent;
use anvil_core::fs::{
    compute_bitmap_csum, compute_gdt_csum, compute_inode_csum, csum_seed_for, Fs,
};

const PROG: &str = "mklost+found";
const TARGET_BYTES: u64 = 16 * 1024;

fn main() -> ExitCode {
    let mut path: Option<PathBuf> = None;
    for a in std::env::args().skip(1) {
        match a.as_str() {
            "-V" | "--version" => {
                println!("{PROG} 1.47.3-anvil (MIT)");
                return ExitCode::from(0);
            }
            "-h" | "--help" => {
                println!("usage: {PROG} <device>");
                return ExitCode::from(0);
            }
            s if s.starts_with('-') => {
                eprintln!("{PROG}: unknown option {s}");
                return ExitCode::from(16);
            }
            _ => {
                if path.is_some() {
                    eprintln!("{PROG}: only one device argument is allowed");
                    return ExitCode::from(16);
                }
                path = Some(PathBuf::from(a));
            }
        }
    }
    let path = match path {
        Some(p) => p,
        None => {
            eprintln!("usage: {PROG} <device>");
            return ExitCode::from(16);
        }
    };

    let mut fs = match Fs::open(&path) {
        Ok(f) => f,
        Err(e) => {
            eprintln!("{PROG}: {}: {e}", path.display());
            return ExitCode::from(8);
        }
    };

    match run(&mut fs) {
        Ok(blocks) => {
            let bs = fs.block_size;
            println!(
                "{PROG}: /lost+found now has {blocks} blocks ({} bytes preallocated)",
                blocks * bs
            );
            ExitCode::from(0)
        }
        Err(e) => {
            eprintln!("{PROG}: {e}");
            ExitCode::from(1)
        }
    }
}

fn run(fs: &mut Fs) -> std::io::Result<u64> {
    let bs = fs.block_size;
    let want_blocks = (TARGET_BYTES + bs - 1) / bs;

    // Step 1/2: locate or create /lost+found. Look it up by name
    // off the root rather than trusting s_lpf_ino — upstream
    // mklost+found does the same so it works on fs images that
    // never set s_lpf_ino.
    let lpf_ino = match lookup_in_root(fs, b"lost+found")? {
        Some(ino) => ino,
        None => create_lost_found(fs)?,
    };

    // Step 3/4/5/6: expand to >= TARGET_BYTES of dir blocks.
    let (final_blocks, _) = expand_lost_found(fs, lpf_ino, want_blocks)?;

    // Make sure the SB + GDT we mutated in expand_lost_found
    // actually hit disk.
    flush_metadata(fs)?;
    Ok(final_blocks)
}

// ---------------------------------------------------------------
// Lookup helpers (subset of debugfs::resolve_path / lookup_in_dir,
// duplicated here so this crate doesn't depend on debugfs).
// ---------------------------------------------------------------

fn lookup_in_root(fs: &mut Fs, name: &[u8]) -> std::io::Result<Option<u32>> {
    let root = fs.read_inode(EXT4_ROOT_INO)?;
    if root.i_mode & S_IFMT != S_IFDIR {
        return Err(std::io::Error::new(
            std::io::ErrorKind::InvalidData,
            "root inode is not a directory",
        ));
    }
    let mut blocks: Vec<u64> = Vec::new();
    extent::walk_extents(fs, &root, |r| {
        for off in 0..r.length as u64 {
            blocks.push(r.physical + off);
        }
    })?;
    let bs = fs.block_size as usize;
    for blk in blocks {
        let mut buf = vec![0u8; bs];
        fs.read_block(blk, &mut buf)?;
        let mut off = 0usize;
        while off + 8 <= buf.len() {
            let inode = u32::from_le_bytes([buf[off], buf[off + 1], buf[off + 2], buf[off + 3]]);
            let rec_len = u16::from_le_bytes([buf[off + 4], buf[off + 5]]) as usize;
            let name_len = buf[off + 6] as usize;
            if rec_len < 8 || off + rec_len > bs {
                break;
            }
            if inode != 0 && off + 8 + name_len <= buf.len() {
                let entry_name = &buf[off + 8..off + 8 + name_len];
                if entry_name == name {
                    return Ok(Some(inode));
                }
            }
            off += rec_len;
        }
    }
    Ok(None)
}

// ---------------------------------------------------------------
// Allocation helpers.
// ---------------------------------------------------------------

/// Allocate `count` consecutive free blocks in group 0. Returns
/// the absolute block number of the first one. The caller is
/// responsible for marking them used in the bitmap and updating
/// the GDT/SB free counters via `commit_block_alloc`.
fn alloc_contiguous_blocks(fs: &mut Fs, count: usize) -> std::io::Result<u64> {
    let bs = fs.block_size;
    let bb_block = fs.group_block_bitmap(0);
    let mut bb_buf = vec![0u8; bs as usize];
    fs.read_block(bb_block, &mut bb_buf)?;
    let bpg = fs.blocks_per_group as usize;
    let first_data_block = fs.sb.s_first_data_block as u64;

    let mut run_start: Option<usize> = None;
    let mut run_len: usize = 0;
    let mut found: Option<usize> = None;
    for bit in 0..bpg {
        if !anvil_core::bitmap::test_bit(&bb_buf, bit) {
            if run_start.is_none() {
                run_start = Some(bit);
                run_len = 1;
            } else {
                run_len += 1;
            }
            if run_len >= count {
                found = run_start;
                break;
            }
        } else {
            run_start = None;
            run_len = 0;
        }
    }
    let start = found.ok_or_else(|| {
        std::io::Error::new(
            std::io::ErrorKind::Other,
            format!("no run of {count} contiguous free blocks in group 0"),
        )
    })?;
    Ok(first_data_block + start as u64)
}

/// Mark blocks [first..first+count) as used in group 0's block
/// bitmap, restamp the bitmap csum if metadata_csum is set, and
/// decrement the GDT + SB free-blocks counters by `count`.
fn commit_block_alloc(fs: &mut Fs, first: u64, count: usize) -> std::io::Result<()> {
    let bs = fs.block_size;
    let bb_block = fs.group_block_bitmap(0);
    let mut bb_buf = vec![0u8; bs as usize];
    fs.read_block(bb_block, &mut bb_buf)?;
    let first_data_block = fs.sb.s_first_data_block as u64;
    let rel_start = (first - first_data_block) as usize;
    for i in 0..count {
        anvil_core::bitmap::set_bit(&mut bb_buf, rel_start + i);
    }
    fs.dev.write_at(bb_block * bs, &bb_buf)?;

    {
        let gd = &mut fs.gdt[0];
        let cur_fb = (gd.bg_free_blocks_count_lo as u32)
            | ((gd.bg_free_blocks_count_hi as u32) << 16);
        gd.set_free_blocks(cur_fb.saturating_sub(count as u32));
    }
    if fs.has_metadata_csum() {
        let bbc = compute_bitmap_csum(&fs.sb, &bb_buf);
        fs.gdt[0].bg_block_bitmap_csum_lo = bbc as u16;
        if fs.desc_size as usize >= 0x3A {
            fs.gdt[0].bg_block_bitmap_csum_hi = (bbc >> 16) as u16;
        }
    }
    let fb = fs.sb.free_blocks();
    fs.sb.set_free_blocks(fb.saturating_sub(count as u64));
    Ok(())
}

/// Allocate one free inode slot in group 0 past the reserved
/// range. Returns the 1-based inode number; caller is responsible
/// for `commit_inode_alloc`.
fn alloc_inode(fs: &mut Fs) -> std::io::Result<u32> {
    let bs = fs.block_size;
    let first_ino = fs.sb.s_first_ino.max(EXT4_FIRST_NON_RSV_INO);
    let ipg = fs.inodes_per_group as usize;
    let ib_block = fs.group_inode_bitmap(0);
    let mut ib_buf = vec![0u8; bs as usize];
    fs.read_block(ib_block, &mut ib_buf)?;
    let start_bit = first_ino as usize;
    for bit in start_bit..ipg {
        if !anvil_core::bitmap::test_bit(&ib_buf, bit) {
            return Ok((bit + 1) as u32);
        }
    }
    Err(std::io::Error::new(
        std::io::ErrorKind::Other,
        "no free inode slot in group 0",
    ))
}

fn commit_inode_alloc(fs: &mut Fs, ino_num: u32, is_dir: bool) -> std::io::Result<()> {
    let bs = fs.block_size;
    let ib_block = fs.group_inode_bitmap(0);
    let mut ib_buf = vec![0u8; bs as usize];
    fs.read_block(ib_block, &mut ib_buf)?;
    anvil_core::bitmap::set_bit(&mut ib_buf, (ino_num - 1) as usize);
    fs.dev.write_at(ib_block * bs, &ib_buf)?;

    {
        let gd = &mut fs.gdt[0];
        let cur_fi = (gd.bg_free_inodes_count_lo as u32)
            | ((gd.bg_free_inodes_count_hi as u32) << 16);
        gd.set_free_inodes(cur_fi.saturating_sub(1));
        if is_dir {
            let cur_ud = (gd.bg_used_dirs_count_lo as u32)
                | ((gd.bg_used_dirs_count_hi as u32) << 16);
            gd.set_used_dirs(cur_ud.saturating_add(1));
        }
    }
    if fs.has_metadata_csum() {
        let ipg_bytes = ((fs.inodes_per_group as usize + 7) / 8).min(ib_buf.len());
        let ibc = compute_bitmap_csum(&fs.sb, &ib_buf[..ipg_bytes]);
        fs.gdt[0].bg_inode_bitmap_csum_lo = ibc as u16;
        if fs.desc_size as usize >= 0x3A {
            fs.gdt[0].bg_inode_bitmap_csum_hi = (ibc >> 16) as u16;
        }
    }
    fs.sb.s_free_inodes_count = fs.sb.s_free_inodes_count.saturating_sub(1);
    Ok(())
}

// ---------------------------------------------------------------
// Dir-block construction.
// ---------------------------------------------------------------

/// Build the contents of a freshly-allocated *empty* dir block.
/// One inode=0 entry covers the entire usable area; with
/// metadata_csum the trailing 12 bytes hold the dir-tail marker
/// + csum.
fn build_empty_dir_block(fs: &Fs, owner_ino: u32, generation: u32) -> Vec<u8> {
    let bs = fs.block_size as usize;
    let want_csum = fs.has_metadata_csum();
    let block_end = if want_csum { bs - 12 } else { bs };

    let mut buf = vec![0u8; bs];
    // Single sentinel entry filling the whole usable area:
    //   inode=0, rec_len=block_end, name_len=0, file_type=0
    buf[0..4].copy_from_slice(&0u32.to_le_bytes());
    buf[4..6].copy_from_slice(&(block_end as u16).to_le_bytes());
    buf[6] = 0;
    buf[7] = 0;

    if want_csum {
        let tail_off = bs - 12;
        // det_reserved_zero1=0, det_rec_len=12, det_reserved_zero2=0,
        // det_reserved_ft=0xDE, then the 4-byte csum.
        buf[tail_off..tail_off + 8].copy_from_slice(&[0, 0, 0, 0, 0x0C, 0, 0, 0xDE]);
        let seed = csum_seed_for(&fs.sb);
        let s1 = anvil_core::crc::crc32c_cont(seed, &owner_ino.to_le_bytes());
        let s2 = anvil_core::crc::crc32c_cont(s1, &generation.to_le_bytes());
        let csum = anvil_core::crc::crc32c_cont(s2, &buf[..bs - 12]);
        buf[bs - 4..bs].copy_from_slice(&csum.to_le_bytes());
    }
    buf
}

/// Build a "." + ".." dir block for a brand-new directory inode.
fn build_dotdotdot_block(fs: &Fs, self_ino: u32, parent_ino: u32) -> Vec<u8> {
    let bs = fs.block_size as usize;
    let want_csum = fs.has_metadata_csum();
    let block_end = if want_csum { bs - 12 } else { bs };

    let mut buf: Vec<u8> = Vec::with_capacity(bs);
    anvil_core::dir::append_dir_entry(&mut buf, self_ino, EXT4_FT_DIR, b".", false, block_end);
    anvil_core::dir::append_dir_entry(&mut buf, parent_ino, EXT4_FT_DIR, b"..", true, block_end);
    buf.resize(bs, 0);
    if want_csum {
        let tail_off = bs - 12;
        buf[tail_off..tail_off + 8].copy_from_slice(&[0, 0, 0, 0, 0x0C, 0, 0, 0xDE]);
        // Generation is zero for a freshly-minted inode (debugfs
        // mkdir does the same), so seed the dir-tail csum with
        // generation=0.
        let seed = csum_seed_for(&fs.sb);
        let s1 = anvil_core::crc::crc32c_cont(seed, &self_ino.to_le_bytes());
        let s2 = anvil_core::crc::crc32c_cont(s1, &0u32.to_le_bytes());
        let csum = anvil_core::crc::crc32c_cont(s2, &buf[..bs - 12]);
        buf[bs - 4..bs].copy_from_slice(&csum.to_le_bytes());
    }
    buf
}

// ---------------------------------------------------------------
// Create /lost+found from scratch.
// ---------------------------------------------------------------

fn create_lost_found(fs: &mut Fs) -> std::io::Result<u32> {
    let bs = fs.block_size;
    let new_ino = alloc_inode(fs)?;
    let dir_block = alloc_contiguous_blocks(fs, 1)?;

    // Build the data block ("." + "..") and the inode itself.
    let dbuf = build_dotdotdot_block(fs, new_ino, EXT4_ROOT_INO);
    let ibuf = build_dir_inode(fs, new_ino, dir_block, 1, bs);

    // Commit in the same order debugfs::mkdir uses: data block,
    // inode slot, parent entry, parent link bump, then bitmaps +
    // GDT + SB counters.
    fs.dev.write_at(dir_block * bs, &dbuf)?;
    write_inode_slot(fs, new_ino, &ibuf)?;
    add_parent_dir_entry(fs, EXT4_ROOT_INO, new_ino, b"lost+found", EXT4_FT_DIR)?;
    bump_parent_link_count(fs, EXT4_ROOT_INO)?;

    commit_inode_alloc(fs, new_ino, true)?;
    commit_block_alloc(fs, dir_block, 1)?;
    Ok(new_ino)
}

/// Build the on-disk inode slot for a fresh directory whose
/// extent tree consists of a single contiguous extent of length
/// `len_blocks` starting at `dir_block`.
fn build_dir_inode(fs: &Fs, ino_num: u32, dir_block: u64, len_blocks: u16, bs: u64) -> Vec<u8> {
    let inode_size = fs.inode_size as usize;
    let mut ibuf = vec![0u8; inode_size];
    let now = now_u32();

    let mode: u16 = S_IFDIR | 0o755;
    ibuf[0x00..0x02].copy_from_slice(&mode.to_le_bytes());
    let size: u64 = bs * len_blocks as u64;
    ibuf[0x04..0x08].copy_from_slice(&((size & 0xFFFF_FFFF) as u32).to_le_bytes());
    ibuf[0x6C..0x70].copy_from_slice(&((size >> 32) as u32).to_le_bytes());
    ibuf[0x08..0x0C].copy_from_slice(&now.to_le_bytes()); // atime
    ibuf[0x0C..0x10].copy_from_slice(&now.to_le_bytes()); // ctime
    ibuf[0x10..0x14].copy_from_slice(&now.to_le_bytes()); // mtime
    ibuf[0x1A..0x1C].copy_from_slice(&2u16.to_le_bytes()); // links: . + ..
    let i_blocks_lo: u32 = ((bs * len_blocks as u64) / 512) as u32;
    ibuf[0x1C..0x20].copy_from_slice(&i_blocks_lo.to_le_bytes());
    ibuf[0x20..0x24].copy_from_slice(&EXT4_EXTENTS_FL.to_le_bytes());

    // i_block extent header + one extent of `len_blocks`.
    let iblock_off = 0x28usize;
    ibuf[iblock_off..iblock_off + 2].copy_from_slice(&EXT4_EXT_MAGIC.to_le_bytes());
    ibuf[iblock_off + 2..iblock_off + 4].copy_from_slice(&1u16.to_le_bytes()); // entries
    ibuf[iblock_off + 4..iblock_off + 6].copy_from_slice(&4u16.to_le_bytes()); // max
    let e_off = iblock_off + 12;
    ibuf[e_off..e_off + 4].copy_from_slice(&0u32.to_le_bytes()); // ee_block
    ibuf[e_off + 4..e_off + 6].copy_from_slice(&len_blocks.to_le_bytes()); // ee_len
    ibuf[e_off + 6..e_off + 8].copy_from_slice(&((dir_block >> 32) as u16).to_le_bytes());
    ibuf[e_off + 8..e_off + 12].copy_from_slice(&(dir_block as u32).to_le_bytes());

    if inode_size >= 256 {
        let extra_isize: u16 = 32;
        ibuf[0x80..0x82].copy_from_slice(&extra_isize.to_le_bytes());
        ibuf[0x90..0x94].copy_from_slice(&now.to_le_bytes()); // crtime
    }
    if fs.has_metadata_csum() {
        stamp_inode_csum_in(&mut ibuf, fs, ino_num, 0);
    }
    ibuf
}

/// Write `ibuf` into the on-disk inode table slot for `ino_num`.
fn write_inode_slot(fs: &mut Fs, ino_num: u32, ibuf: &[u8]) -> std::io::Result<()> {
    let bs = fs.block_size;
    let group = (ino_num as u64 - 1) / fs.inodes_per_group;
    let idx = (ino_num as u64 - 1) % fs.inodes_per_group;
    let table = fs.group_inode_table(group);
    let byte = table * bs + idx * fs.inode_size;
    fs.dev.write_at(byte, ibuf)
}

fn stamp_inode_csum_in(buf: &mut [u8], fs: &Fs, ino_num: u32, generation: u32) {
    let inode_size = buf.len();
    let extra_isize = if inode_size >= 0x82 {
        u16::from_le_bytes(buf[0x80..0x82].try_into().unwrap())
    } else {
        0
    };
    let use_hi = inode_size >= 256 && extra_isize > 2;
    if inode_size >= 0x7E {
        buf[0x7C..0x7E].copy_from_slice(&0u16.to_le_bytes());
    }
    if use_hi {
        buf[0x82..0x84].copy_from_slice(&0u16.to_le_bytes());
    }
    let csum = compute_inode_csum(&fs.sb, ino_num, generation, buf);
    if inode_size >= 0x7E {
        buf[0x7C..0x7E].copy_from_slice(&(csum as u16).to_le_bytes());
    }
    if use_hi {
        buf[0x82..0x84].copy_from_slice(&((csum >> 16) as u16).to_le_bytes());
    }
}

// ---------------------------------------------------------------
// Adding "lost+found" to the parent directory (root).
// ---------------------------------------------------------------

fn add_parent_dir_entry(
    fs: &mut Fs,
    parent_ino_num: u32,
    new_ino: u32,
    name_bytes: &[u8],
    file_type: u8,
) -> std::io::Result<()> {
    use anvil_core::dir::align4;
    let want = 8 + align4(name_bytes.len());
    let bs = fs.block_size as usize;

    let parent_inode = fs.read_inode(parent_ino_num)?;
    let mut blocks: Vec<u64> = Vec::new();
    extent::walk_extents(fs, &parent_inode, |r| {
        for off in 0..r.length as u64 {
            blocks.push(r.physical + off);
        }
    })?;
    if blocks.is_empty() {
        return Err(std::io::Error::new(
            std::io::ErrorKind::InvalidData,
            format!("parent inode {parent_ino_num} has no data blocks"),
        ));
    }

    let want_csum = fs.has_metadata_csum();
    let block_end = if want_csum { bs - 12 } else { bs };

    let mut buf = vec![0u8; bs];
    let mut chosen_block: Option<u64> = None;
    let mut chosen_split_off: usize = 0;
    let mut chosen_shrunk_rec_len: usize = 0;
    let mut chosen_new_rec_len: usize = 0;
    for &blk in &blocks {
        fs.read_block(blk, &mut buf)?;
        let mut off = 0usize;
        while off + 8 <= block_end {
            let inode = u32::from_le_bytes([buf[off], buf[off + 1], buf[off + 2], buf[off + 3]]);
            let rec_len = u16::from_le_bytes([buf[off + 4], buf[off + 5]]) as usize;
            let name_len = buf[off + 6] as usize;
            if rec_len < 8 || off + rec_len > block_end {
                break;
            }
            let min_here = if inode == 0 { 8 } else { 8 + align4(name_len) };
            let slack = rec_len.saturating_sub(min_here);
            if slack >= want {
                chosen_block = Some(blk);
                chosen_split_off = off;
                chosen_shrunk_rec_len = min_here;
                chosen_new_rec_len = rec_len - min_here;
                break;
            }
            off += rec_len;
        }
        if chosen_block.is_some() {
            break;
        }
    }
    let blk = chosen_block.ok_or_else(|| {
        std::io::Error::new(
            std::io::ErrorKind::Other,
            "parent directory has no free slot for new entry",
        )
    })?;

    fs.read_block(blk, &mut buf)?;
    buf[chosen_split_off + 4..chosen_split_off + 6]
        .copy_from_slice(&(chosen_shrunk_rec_len as u16).to_le_bytes());
    let new_off = chosen_split_off + chosen_shrunk_rec_len;
    buf[new_off..new_off + 4].copy_from_slice(&new_ino.to_le_bytes());
    buf[new_off + 4..new_off + 6].copy_from_slice(&(chosen_new_rec_len as u16).to_le_bytes());
    buf[new_off + 6] = name_bytes.len() as u8;
    buf[new_off + 7] = file_type;
    buf[new_off + 8..new_off + 8 + name_bytes.len()].copy_from_slice(name_bytes);
    for b in &mut buf[new_off + 8 + name_bytes.len()..new_off + chosen_new_rec_len] {
        *b = 0;
    }

    if want_csum {
        let tail_off = bs - 12;
        buf[tail_off..tail_off + 8].copy_from_slice(&[0, 0, 0, 0, 0x0C, 0, 0, 0xDE]);
        for b in &mut buf[tail_off + 8..tail_off + 12] {
            *b = 0;
        }
        let generation = parent_inode.i_generation;
        let seed = csum_seed_for(&fs.sb);
        let s1 = anvil_core::crc::crc32c_cont(seed, &parent_ino_num.to_le_bytes());
        let s2 = anvil_core::crc::crc32c_cont(s1, &generation.to_le_bytes());
        let csum = anvil_core::crc::crc32c_cont(s2, &buf[..bs - 12]);
        buf[bs - 4..bs].copy_from_slice(&csum.to_le_bytes());
    }
    fs.dev.write_at(blk * fs.block_size, &buf)?;
    Ok(())
}

fn bump_parent_link_count(fs: &mut Fs, parent_ino_num: u32) -> std::io::Result<()> {
    patch_inode_slot(fs, parent_ino_num, |buf| {
        let cur = u16::from_le_bytes(buf[0x1A..0x1C].try_into().unwrap());
        buf[0x1A..0x1C].copy_from_slice(&cur.saturating_add(1).to_le_bytes());
        // bump mtime/ctime too, mirroring debugfs::mkdir.
        let now = now_u32();
        buf[0x0C..0x10].copy_from_slice(&now.to_le_bytes());
        buf[0x10..0x14].copy_from_slice(&now.to_le_bytes());
        Ok(())
    })
}

fn patch_inode_slot<F>(fs: &mut Fs, ino_num: u32, mutate: F) -> std::io::Result<()>
where
    F: FnOnce(&mut [u8]) -> std::io::Result<()>,
{
    let bs = fs.block_size;
    let group = (ino_num as u64 - 1) / fs.inodes_per_group;
    let idx = (ino_num as u64 - 1) % fs.inodes_per_group;
    let table = fs.group_inode_table(group);
    let byte = table * bs + idx * fs.inode_size;
    let mut buf = vec![0u8; fs.inode_size as usize];
    fs.dev.read_at(byte, &mut buf)?;
    mutate(&mut buf)?;
    if fs.has_metadata_csum() {
        let generation = u32::from_le_bytes(buf[0x64..0x68].try_into().unwrap());
        stamp_inode_csum_in(&mut buf, fs, ino_num, generation);
    }
    fs.dev.write_at(byte, &buf)?;
    Ok(())
}

// ---------------------------------------------------------------
// Expand /lost+found to >= want_blocks.
// ---------------------------------------------------------------

/// Walk the lost+found inode's extent tree and extend it to at
/// least `want_blocks` total blocks. Returns the (final block
/// count, blocks added). Tries to grow the last extent contiguously
/// first; if the on-disk free blocks aren't contiguous with the
/// existing tail, falls back to inserting a fresh extent record
/// in the inode's inline `i_block` extent header (capped at
/// eh_max=4 — refuses gracefully past that, which is fine because
/// the target is only 16 KiB / 4 KiB = 4 blocks at the worst-case
/// block_size).
fn expand_lost_found(fs: &mut Fs, lpf_ino: u32, want_blocks: u64) -> std::io::Result<(u64, u64)> {
    let inode = fs.read_inode(lpf_ino)?;
    if inode.i_mode & S_IFMT != S_IFDIR {
        return Err(std::io::Error::new(
            std::io::ErrorKind::InvalidData,
            "/lost+found is not a directory",
        ));
    }
    if inode.i_flags & EXT4_EXTENTS_FL == 0 {
        return Err(std::io::Error::new(
            std::io::ErrorKind::Unsupported,
            "/lost+found uses block-map (legacy) format; not supported",
        ));
    }
    // Read the inline extent header from i_block.
    let mut iblock = [0u8; 60];
    unsafe {
        core::ptr::copy_nonoverlapping(
            core::ptr::addr_of!(inode.i_block) as *const u8,
            iblock.as_mut_ptr(),
            60,
        );
    }
    let eh_magic = u16::from_le_bytes([iblock[0], iblock[1]]);
    if eh_magic != EXT4_EXT_MAGIC {
        return Err(std::io::Error::new(
            std::io::ErrorKind::InvalidData,
            "/lost+found extent header has bad magic",
        ));
    }
    let eh_depth = u16::from_le_bytes([iblock[6], iblock[7]]);
    if eh_depth != 0 {
        return Err(std::io::Error::new(
            std::io::ErrorKind::Unsupported,
            "/lost+found has a multi-level extent tree; refusing to grow",
        ));
    }
    let mut eh_entries = u16::from_le_bytes([iblock[2], iblock[3]]) as usize;
    let eh_max = u16::from_le_bytes([iblock[4], iblock[5]]) as usize;

    // Sum existing extents to find current block count.
    let mut current_blocks: u64 = 0;
    for i in 0..eh_entries {
        let off = 12 + i * 12;
        let ee_len = u16::from_le_bytes([iblock[off + 4], iblock[off + 5]]);
        // Initialized extents have ee_len <= 32768; uninit (>32768)
        // shouldn't happen on a dir. Treat it conservatively.
        let real = if ee_len > 32768 { ee_len - 32768 } else { ee_len } as u64;
        current_blocks += real;
    }
    if current_blocks >= want_blocks {
        return Ok((current_blocks, 0));
    }
    let need = (want_blocks - current_blocks) as usize;

    let bs = fs.block_size;
    let new_first = alloc_contiguous_blocks(fs, need)?;

    // Initialize each new block as an empty dir block.
    let generation = inode.i_generation;
    for i in 0..need {
        let blk = new_first + i as u64;
        let dbuf = build_empty_dir_block(fs, lpf_ino, generation);
        fs.dev.write_at(blk * bs, &dbuf)?;
    }
    commit_block_alloc(fs, new_first, need)?;

    // Patch the inode's extent tree. Try to extend the last extent
    // if it's contiguous; otherwise append a new extent record.
    let mut extended_in_place = false;
    if eh_entries > 0 {
        let last = eh_entries - 1;
        let off = 12 + last * 12;
        let ee_block = u32::from_le_bytes([
            iblock[off], iblock[off + 1], iblock[off + 2], iblock[off + 3],
        ]);
        let ee_len = u16::from_le_bytes([iblock[off + 4], iblock[off + 5]]);
        let real = if ee_len > 32768 { ee_len - 32768 } else { ee_len };
        let ee_start_hi = u16::from_le_bytes([iblock[off + 6], iblock[off + 7]]);
        let ee_start_lo = u32::from_le_bytes([
            iblock[off + 8], iblock[off + 9], iblock[off + 10], iblock[off + 11],
        ]);
        let phys_start = ((ee_start_hi as u64) << 32) | ee_start_lo as u64;
        let phys_end = phys_start + real as u64;
        let new_total = real as u64 + need as u64;
        if phys_end == new_first && new_total <= 32768 {
            iblock[off + 4..off + 6]
                .copy_from_slice(&(new_total as u16).to_le_bytes());
            extended_in_place = true;
            let _ = ee_block; // silence unused
        }
    }
    if !extended_in_place {
        if eh_entries >= eh_max {
            return Err(std::io::Error::new(
                std::io::ErrorKind::Other,
                format!(
                    "/lost+found inline extent header is full ({}/{}); \
                     would need an interior extent block",
                    eh_entries, eh_max
                ),
            ));
        }
        let off = 12 + eh_entries * 12;
        // ee_block = current_blocks (next logical block).
        let ee_block: u32 = current_blocks as u32;
        let ee_len: u16 = need as u16;
        let ee_start_hi: u16 = (new_first >> 32) as u16;
        let ee_start_lo: u32 = new_first as u32;
        iblock[off..off + 4].copy_from_slice(&ee_block.to_le_bytes());
        iblock[off + 4..off + 6].copy_from_slice(&ee_len.to_le_bytes());
        iblock[off + 6..off + 8].copy_from_slice(&ee_start_hi.to_le_bytes());
        iblock[off + 8..off + 12].copy_from_slice(&ee_start_lo.to_le_bytes());
        eh_entries += 1;
        iblock[2..4].copy_from_slice(&(eh_entries as u16).to_le_bytes());
    }

    // Compute the new size + i_blocks (in 512-byte sectors).
    let new_blocks = current_blocks + need as u64;
    let new_size = new_blocks * bs;
    let new_i_blocks = (new_blocks * bs / 512) as u32;

    // Write back the inode slot: copy iblock back into i_block,
    // update size + i_blocks, then csum.
    patch_inode_slot(fs, lpf_ino, |buf| {
        // i_size_lo @ 0x04, i_size_hi @ 0x6C
        buf[0x04..0x08]
            .copy_from_slice(&((new_size & 0xFFFF_FFFF) as u32).to_le_bytes());
        buf[0x6C..0x70].copy_from_slice(&((new_size >> 32) as u32).to_le_bytes());
        // i_blocks_lo @ 0x1C
        buf[0x1C..0x20].copy_from_slice(&new_i_blocks.to_le_bytes());
        // i_block @ 0x28..0x64 (60 bytes).
        buf[0x28..0x28 + 60].copy_from_slice(&iblock);
        // bump mtime/ctime.
        let now = now_u32();
        buf[0x0C..0x10].copy_from_slice(&now.to_le_bytes());
        buf[0x10..0x14].copy_from_slice(&now.to_le_bytes());
        Ok(())
    })?;

    Ok((new_blocks, need as u64))
}

// ---------------------------------------------------------------
// Re-stamp every group descriptor's bg_checksum + the SB csum and
// flush both back to disk. Mirrors the tail of debugfs::cmd_mkdir.
// ---------------------------------------------------------------

fn flush_metadata(fs: &mut Fs) -> std::io::Result<()> {
    if fs.has_metadata_csum() {
        for gi in 0..fs.groups_count {
            let desc_bytes = fs.gdt[gi as usize].to_bytes(fs.desc_size as usize);
            let csum = compute_gdt_csum(&fs.sb, gi as u32, &desc_bytes);
            fs.gdt[gi as usize].bg_checksum = csum as u16;
        }
        fs.sb.s_checksum = 0;
        let sb_bytes = fs.sb.to_bytes();
        let new_sb_csum = anvil_core::crc::crc32c_cont(0xFFFFFFFF, &sb_bytes[..0x3FC]);
        fs.sb.s_checksum = new_sb_csum;
    }
    fs.write_superblock()?;
    fs.write_gdt()?;
    Ok(())
}

fn now_u32() -> u32 {
    use std::time::{SystemTime, UNIX_EPOCH};
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_secs() as u32)
        .unwrap_or(0)
}
