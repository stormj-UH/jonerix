//! resize2fs — `-P` printer, restricted `-M` shrink, and grow
//! (within-group + cross-group).
//!
//! `-P` reads back the estimated minimum shrinkable size.
//! `-M` drops whole trailing block groups that are entirely
//! empty. Bare `resize2fs device [new_size]` grows the fs to
//! the device size (or `new_size` blocks). The grow path first
//! extends the current last group up to its boundary, then
//! appends brand-new groups and re-stamps the GDT plus every
//! sparse_super backup.
//!
//! The design is clean-room: we work from the public ext4
//! on-disk format, not from upstream resize2fs.
//!
//! Flags:
//!   -P <device>             print estimated minimum shrinkable size
//!   -M <device>             shrink by dropping trailing empty groups
//!   -f                      force grow even if new <= current (no-op)
//!   -V                      version
//!   <device> [new_size]     grow fs to device size or new_size blocks

use std::path::PathBuf;
use std::process::ExitCode;

use anvil_core::consts::{
    EXT4_EXTENTS_FL, EXT4_EXT_MAGIC, EXT4_FEATURE_RO_COMPAT_METADATA_CSUM,
    EXT4_FEATURE_RO_COMPAT_SPARSE_SUPER, S_IFMT, S_IFREG,
};
use anvil_core::fs::{compute_bitmap_csum, compute_gdt_csum, compute_inode_csum, Fs};
use anvil_core::group_desc::GroupDesc64;
use anvil_core::inode::{Extent, ExtentHeader, ExtentIdx};
use anvil_core::superblock::Superblock;

const VERSION_LINE: &str = "resize2fs 1.47.3-anvil (MIT)";

fn main() -> ExitCode {
    let args: Vec<String> = std::env::args().skip(1).collect();

    let mut print_min = false;
    let mut shrink_min = false;
    let mut force = false;
    let mut path: Option<PathBuf> = None;
    let mut new_size_arg: Option<u64> = None;
    let mut iter = args.into_iter();
    while let Some(a) = iter.next() {
        match a.as_str() {
            "-V" => {
                println!("{VERSION_LINE}");
                return ExitCode::from(0);
            }
            "-P" => {
                print_min = true;
            }
            "-M" => {
                shrink_min = true;
            }
            "-f" => {
                force = true;
            }
            "-h" | "--help" => {
                println!("usage: resize2fs [-P] [-M] [-f] [-V] <device> [new_size]");
                println!("  -P <device>              print estimated minimum shrinkable size");
                println!("  -M <device>              shrink by dropping trailing empty groups");
                println!("  -f                       force (allow no-op shrink via default mode)");
                println!("  -V                       print version");
                println!("  <device> [new_size]      grow fs to device or new_size blocks");
                return ExitCode::from(0);
            }
            s if s.starts_with("-") => {
                eprintln!("resize2fs: unknown option {s} (ignored)");
            }
            _ => {
                if path.is_none() {
                    path = Some(PathBuf::from(a));
                } else if new_size_arg.is_none() {
                    match a.parse::<u64>() {
                        Ok(v) => new_size_arg = Some(v),
                        Err(_) => {
                            eprintln!("resize2fs: invalid new_size {a}");
                            return ExitCode::from(16);
                        }
                    }
                }
            }
        }
    }

    let Some(path) = path else {
        eprintln!("usage: resize2fs [-P] [-M] [-f] [-V] <device> [new_size]");
        return ExitCode::from(16);
    };

    let mut fs = match Fs::open(&path) {
        Ok(fs) => fs,
        Err(e) => {
            eprintln!("resize2fs: open {}: {}", path.display(), e);
            return ExitCode::from(8);
        }
    };

    if print_min {
        let min_blocks = estimate_minimum_blocks(&fs);
        let block_size = fs.block_size;
        let bytes = min_blocks.saturating_mul(block_size);
        println!("{VERSION_LINE}");
        println!(
            "Estimated minimum size of the filesystem: {min_blocks} blocks ({})",
            human_size(bytes)
        );
    }

    if shrink_min {
        match shrink_trailing_empty_groups(&mut fs, &path) {
            Ok(ShrinkOutcome::NoOp) => {
                println!("resize2fs: no safe shrink available");
            }
            Ok(ShrinkOutcome::Shrunk { from_blocks, to_blocks, dropped_groups }) => {
                let bs = fs.block_size;
                println!(
                    "resize2fs: dropped {dropped_groups} trailing empty group(s); \
                     {from_blocks} -> {to_blocks} blocks ({} -> {})",
                    human_size(from_blocks * bs),
                    human_size(to_blocks * bs),
                );
            }
            Err(e) => {
                eprintln!("resize2fs: shrink failed: {e}");
                return ExitCode::from(8);
            }
        }
    }

    if !print_min && !shrink_min {
        // Default mode: grow to device size (or new_size_arg).
        match grow(&mut fs, &path, new_size_arg, force) {
            Ok(GrowOutcome::NoOp) => {
                println!("resize2fs: filesystem already at or above requested size");
            }
            Ok(GrowOutcome::ReservedGdtExceeded) => {
                eprintln!(
                    "resize2fs: requested grow would exceed s_reserved_gdt_blocks; bailing"
                );
                return ExitCode::from(8);
            }
            Ok(GrowOutcome::Grown { from_blocks, to_blocks, added_groups }) => {
                let bs = fs.block_size;
                println!(
                    "resize2fs: grew {from_blocks} -> {to_blocks} blocks ({} -> {}); \
                     added {added_groups} group(s)",
                    human_size(from_blocks * bs),
                    human_size(to_blocks * bs),
                );
            }
            Err(e) => {
                eprintln!("resize2fs: grow failed: {e}");
                return ExitCode::from(8);
            }
        }
    }

    ExitCode::from(0)
}

enum ShrinkOutcome {
    NoOp,
    Shrunk {
        from_blocks: u64,
        to_blocks: u64,
        dropped_groups: u64,
    },
}

enum GrowOutcome {
    NoOp,
    ReservedGdtExceeded,
    Grown {
        from_blocks: u64,
        to_blocks: u64,
        added_groups: u64,
    },
}

/// Grow the filesystem. First extend the current last group's
/// tail-used bits up to its group boundary, then append brand-new
/// groups until `target` is reached. Each new group gets a fresh
/// block bitmap, inode bitmap, zeroed inode table, and a descriptor
/// appended to `fs.gdt`. Sparse_super backup groups inside the new
/// range also get a SB + GDT copy. The primary GDT is rewritten
/// every time and propagated to every existing backup.
fn grow(
    fs: &mut Fs,
    _path: &std::path::Path,
    new_size_arg: Option<u64>,
    _force: bool,
) -> std::io::Result<GrowOutcome> {
    let block_size = fs.block_size;
    let current_blocks = fs.total_blocks();
    let device_blocks = fs.dev.size / block_size;

    let target = match new_size_arg {
        Some(n) => core::cmp::min(n, device_blocks),
        None => device_blocks,
    };

    if target <= current_blocks {
        return Ok(GrowOutcome::NoOp);
    }

    let bpg = fs.blocks_per_group;
    if bpg == 0 {
        return Ok(GrowOutcome::NoOp);
    }

    let first_data_block = fs.sb.s_first_data_block as u64;
    let from_blocks = current_blocks;

    // Upfront: refuse grow if the new groups would push
    // gdt_blocks past (original gdt_blocks + reserved_gdt_blocks).
    // That mirrors the RESIZE_INODE requirement — without reserved
    // GDT slots, backup groups have no room for the enlarged
    // descriptor table.
    let groups_after = div_ceil_u64(target - first_data_block, bpg);
    let desc_size = fs.desc_size;
    let old_gdt_blocks = div_ceil_u64(fs.groups_count * desc_size, block_size);
    let new_gdt_blocks = div_ceil_u64(groups_after * desc_size, block_size);
    let reserved_gdt = fs.sb.s_reserved_gdt_blocks as u64;
    if new_gdt_blocks > old_gdt_blocks + reserved_gdt {
        return Ok(GrowOutcome::ReservedGdtExceeded);
    }

    // ---- Phase A. Extend current last group's bitmap tail. ----
    // The old last group may have had its tail blocks marked as
    // used (allocator reservation past the fs end). Clear those bits
    // up to either the new target or the group boundary, whichever
    // comes first.
    let mut added_groups: u64 = 0;
    let mut cur_total = current_blocks;
    if cur_total > first_data_block {
        let last_group = (cur_total - 1 - first_data_block) / bpg;
        let group_start = first_data_block + last_group * bpg;
        let group_end = group_start + bpg;
        let extend_to = core::cmp::min(target, group_end);
        if extend_to > cur_total && (last_group as usize) < fs.gdt.len() {
            extend_last_group_bitmap(fs, last_group, cur_total, extend_to)?;
            cur_total = extend_to;
        }
    }

    // ---- Phase B. Append new groups one at a time. ----
    while cur_total < target {
        // The next group index is fs.gdt.len() (also equals the
        // current groups_count).
        let gi = fs.gdt.len() as u64;
        let group_start = first_data_block + gi * bpg;
        let group_end_full = group_start + bpg;
        let group_end = core::cmp::min(group_end_full, target);
        let group_total = group_end - group_start;

        // Plan the new group's on-disk layout using the (new)
        // total group count post-add.
        let provisional_total_groups = gi + 1;
        let plan =
            plan_new_group(fs, gi, group_total, provisional_total_groups)?;

        // Write the block bitmap / inode bitmap / zero the inode
        // table. The bitmap csums are stamped after the descriptor
        // is in fs.gdt so we can update fields in place.
        write_new_group_bitmaps(fs, &plan, group_start, group_total)?;

        // Append the descriptor.
        let mut d = GroupDesc64::default();
        d.set_block_bitmap(plan.block_bitmap_block);
        d.set_inode_bitmap(plan.inode_bitmap_block);
        d.set_inode_table(plan.inode_table_block);
        d.set_free_blocks(plan.free_blocks);
        d.set_free_inodes(fs.inodes_per_group as u32);
        d.set_used_dirs(0);
        d.set_itable_unused(0);
        d.bg_flags = 0;
        fs.gdt.push(d);

        // Stamp bitmap csums now that the descriptor slot exists.
        stamp_new_group_bitmap_csums(fs, gi)?;

        // Update running superblock counters incrementally so the
        // helpers that recompute csums see the authoritative size.
        fs.sb.set_blocks_count(group_end);
        let old_free = fs.sb.free_blocks();
        fs.sb.set_free_blocks(old_free + plan.free_blocks as u64);
        let old_ino = fs.sb.s_inodes_count as u64;
        fs.sb.s_inodes_count = (old_ino + fs.inodes_per_group) as u32;
        let old_free_ino = fs.sb.s_free_inodes_count as u64;
        fs.sb.s_free_inodes_count = (old_free_ino + fs.inodes_per_group) as u32;
        fs.groups_count = provisional_total_groups;

        cur_total = group_end;
        added_groups += 1;
    }

    // ---- Phase C. Stamp metadata_csum on every GDT descriptor. ----
    let metadata_csum =
        (fs.sb.s_feature_ro_compat & EXT4_FEATURE_RO_COMPAT_METADATA_CSUM) != 0;
    if metadata_csum {
        for gi in 0..fs.gdt.len() {
            stamp_gdt_csum(fs, gi as u64);
        }
        // Re-stamp the SB checksum.
        fs.sb.s_checksum = 0;
        let bytes = fs.sb.to_bytes();
        fs.sb.s_checksum = anvil_core::crc::crc32c_cont(0xFFFFFFFF, &bytes[..0x3FC]);
    }

    // ---- Phase D. Flush. Primary SB + GDT first, then every
    //        sparse_super backup (including new ones). ----
    fs.write_gdt()?;
    fs.write_superblock()?;
    write_all_sb_gdt_backups(fs)?;
    fs.dev.sync()?;

    let _ = block_size;
    Ok(GrowOutcome::Grown {
        from_blocks,
        to_blocks: cur_total,
        added_groups,
    })
}

struct NewGroupPlan {
    block_bitmap_block: u64,
    inode_bitmap_block: u64,
    inode_table_block:  u64,
    first_data_in_group: u64,
    free_blocks: u32,
}

fn plan_new_group(
    fs: &Fs,
    gi: u64,
    group_total: u64,
    total_groups_after: u64,
) -> std::io::Result<NewGroupPlan> {
    let block_size = fs.block_size;
    let bpg = fs.blocks_per_group;
    let first_data_block = fs.sb.s_first_data_block as u64;
    let group_start = first_data_block + gi * bpg;

    let has_sparse =
        (fs.sb.s_feature_ro_compat & EXT4_FEATURE_RO_COMPAT_SPARSE_SUPER) != 0;
    let is_backup = !has_sparse || is_backup_group(gi);

    let gdt_blocks =
        div_ceil_u64(total_groups_after * fs.desc_size, block_size);
    let reserved_gdt = fs.sb.s_reserved_gdt_blocks as u64;
    let sb_gdt_blocks = if is_backup {
        1 /* sb */ + gdt_blocks + reserved_gdt
    } else {
        0
    };

    let inode_table_blocks =
        div_ceil_u64(fs.inodes_per_group * fs.inode_size, block_size);

    let meta_base = group_start + sb_gdt_blocks;
    let block_bitmap_block = meta_base;
    let inode_bitmap_block = meta_base + 1;
    let inode_table_block  = meta_base + 2;
    let first_data_in_group = inode_table_block + inode_table_blocks;

    if first_data_in_group > group_start + group_total {
        return Err(std::io::Error::new(
            std::io::ErrorKind::InvalidData,
            format!(
                "group {gi} too small for metadata (need {} blocks, have {})",
                first_data_in_group - group_start,
                group_total,
            ),
        ));
    }

    let used_meta = first_data_in_group - group_start;
    let free_blocks = (group_total - used_meta) as u32;

    Ok(NewGroupPlan {
        block_bitmap_block,
        inode_bitmap_block,
        inode_table_block,
        first_data_in_group,
        free_blocks,
    })
}

fn write_new_group_bitmaps(
    fs: &mut Fs,
    p: &NewGroupPlan,
    group_start: u64,
    group_total: u64,
) -> std::io::Result<()> {
    let block_size = fs.block_size;
    let bs = block_size as usize;

    // --- block bitmap ---
    let mut bb = vec![0u8; bs];
    // Mark every metadata block in this group as used. The metadata
    // range runs [group_start, first_data_in_group).
    let meta_bits = (p.first_data_in_group - group_start) as usize;
    anvil_core::bitmap::mark_range(&mut bb, 0, meta_bits);
    // Mark any bits past the end of the group (partial tail group)
    // as used so the allocator never hands them out.
    let group_blocks = group_total as usize;
    if group_blocks < bs * 8 {
        anvil_core::bitmap::mark_range(&mut bb, group_blocks, bs * 8);
    }
    fs.dev.write_at(p.block_bitmap_block * block_size, &bb)?;

    // --- inode bitmap ---
    let mut ib = vec![0u8; bs];
    // Mark out-of-range inodes past inodes_per_group as used.
    let ipg = fs.inodes_per_group as usize;
    if ipg < bs * 8 {
        anvil_core::bitmap::mark_range(&mut ib, ipg, bs * 8);
    }
    fs.dev.write_at(p.inode_bitmap_block * block_size, &ib)?;

    // --- zero the inode table region ---
    let it_start = p.inode_table_block * block_size;
    let it_blocks = div_ceil_u64(fs.inodes_per_group * fs.inode_size, block_size);
    let it_end = it_start + it_blocks * block_size;
    fs.dev.zero_range(it_start, it_end)?;
    Ok(())
}

/// After the descriptor for the new group is in `fs.gdt`, stamp
/// its block-bitmap and inode-bitmap csums (metadata_csum path).
fn stamp_new_group_bitmap_csums(fs: &mut Fs, gi: u64) -> std::io::Result<()> {
    let metadata_csum =
        (fs.sb.s_feature_ro_compat & EXT4_FEATURE_RO_COMPAT_METADATA_CSUM) != 0;
    if !metadata_csum {
        return Ok(());
    }
    let block_size = fs.block_size;
    let bs = block_size as usize;
    let bb_blk = fs.group_block_bitmap(gi);
    let ib_blk = fs.group_inode_bitmap(gi);
    let mut bb = vec![0u8; bs];
    let mut ib = vec![0u8; bs];
    fs.dev.read_at(bb_blk * block_size, &mut bb)?;
    fs.dev.read_at(ib_blk * block_size, &mut ib)?;

    let bbc = compute_bitmap_csum(&fs.sb, &bb);
    let bytes_used =
        core::cmp::min(((fs.inodes_per_group + 7) / 8) as usize, ib.len());
    let ibc = compute_bitmap_csum(&fs.sb, &ib[..bytes_used]);

    let d = &mut fs.gdt[gi as usize];
    d.bg_block_bitmap_csum_lo = bbc as u16;
    if fs.has_64bit && fs.desc_size >= 0x3A {
        d.bg_block_bitmap_csum_hi = (bbc >> 16) as u16;
    }
    d.bg_inode_bitmap_csum_lo = ibc as u16;
    if fs.has_64bit && fs.desc_size >= 0x3C {
        d.bg_inode_bitmap_csum_hi = (ibc >> 16) as u16;
    }
    Ok(())
}

/// Extend the tail of an existing last group's block bitmap:
/// clear the bits the allocator had reserved past the old fs end
/// up to `extend_to`. Also bump the group's free_blocks and
/// (under metadata_csum) re-stamp its bitmap csum.
fn extend_last_group_bitmap(
    fs: &mut Fs,
    gi: u64,
    old_total: u64,
    new_total: u64,
) -> std::io::Result<()> {
    let block_size = fs.block_size;
    let first_data_block = fs.sb.s_first_data_block as u64;
    let bpg = fs.blocks_per_group;
    let group_start = first_data_block + gi * bpg;
    let old_rel = (old_total - group_start) as usize;
    let new_rel = (new_total - group_start) as usize;

    let bb_block = fs.group_block_bitmap(gi);
    let mut bb = vec![0u8; block_size as usize];
    fs.dev.read_at(bb_block * block_size, &mut bb)?;
    for bit in old_rel..new_rel {
        anvil_core::bitmap::clear_bit(&mut bb, bit);
    }
    fs.dev.write_at(bb_block * block_size, &bb)?;

    let delta = new_total - old_total;
    let d = &mut fs.gdt[gi as usize];
    let free_lo = d.bg_free_blocks_count_lo as u32;
    let free_hi = if fs.has_64bit { d.bg_free_blocks_count_hi as u32 } else { 0 };
    let new_free_group = ((free_hi << 16) | free_lo) as u64 + delta;
    d.bg_free_blocks_count_lo = new_free_group as u16;
    if fs.has_64bit {
        d.bg_free_blocks_count_hi = (new_free_group >> 16) as u16;
    }

    // SB bookkeeping.
    fs.sb.set_blocks_count(new_total);
    let old_free = fs.sb.free_blocks();
    fs.sb.set_free_blocks(old_free + delta);

    // Stamp the bitmap csum if metadata_csum is on. GDT csum gets
    // stamped uniformly in the caller after all groups are in.
    let metadata_csum =
        (fs.sb.s_feature_ro_compat & EXT4_FEATURE_RO_COMPAT_METADATA_CSUM) != 0;
    if metadata_csum {
        let bbc = compute_bitmap_csum(&fs.sb, &bb);
        let d = &mut fs.gdt[gi as usize];
        d.bg_block_bitmap_csum_lo = bbc as u16;
        if fs.has_64bit && fs.desc_size >= 0x3A {
            d.bg_block_bitmap_csum_hi = (bbc >> 16) as u16;
        }
    }
    Ok(())
}

fn stamp_gdt_csum(fs: &mut Fs, gi: u64) {
    let ds = fs.desc_size as usize;
    let d_bytes: [u8; 64] = unsafe {
        *(&fs.gdt[gi as usize] as *const _ as *const [u8; 64])
    };
    let slice = &d_bytes[..ds.min(64)];
    let full = compute_gdt_csum(&fs.sb, gi as u32, slice);
    fs.gdt[gi as usize].bg_checksum = full as u16;
}

/// Write the SB + GDT at every sparse_super backup location
/// (groups 0, 1, and powers of 3/5/7). Group 0 is the primary
/// slot — we skip it here because `write_superblock` +
/// `write_gdt` already handled it.
fn write_all_sb_gdt_backups(fs: &mut Fs) -> std::io::Result<()> {
    let has_sparse =
        (fs.sb.s_feature_ro_compat & EXT4_FEATURE_RO_COMPAT_SPARSE_SUPER) != 0;
    let block_size = fs.block_size;
    let first_data_block = fs.sb.s_first_data_block as u64;
    let bpg = fs.blocks_per_group;
    let groups = fs.gdt.len() as u64;
    let ds = fs.desc_size as usize;

    // Serialize the GDT once.
    let mut gdt_buf = vec![0u8; fs.gdt.len() * ds];
    for (gi, d) in fs.gdt.iter().enumerate() {
        let raw: [u8; 64] =
            unsafe { *(d as *const GroupDesc64 as *const [u8; 64]) };
        let take = core::cmp::min(ds, 64);
        gdt_buf[gi * ds..gi * ds + take].copy_from_slice(&raw[..take]);
    }

    for gi in 1..groups {
        let is_backup = !has_sparse || is_backup_group(gi);
        if !is_backup {
            continue;
        }
        let mut sb_for_group: Superblock = fs.sb;
        sb_for_group.s_block_group_nr = gi as u16;

        let group_start = first_data_block + gi * bpg;
        let sb_byte = group_start * block_size;
        let gdt_block = group_start + 1;

        let sb_bytes: [u8; 1024] = unsafe {
            *(&sb_for_group as *const Superblock as *const [u8; 1024])
        };
        fs.dev.write_at(sb_byte, &sb_bytes)?;
        fs.dev.write_at(gdt_block * block_size, &gdt_buf)?;
    }
    Ok(())
}

/// Drop trailing groups that are entirely empty (no used data
/// blocks in the bitmap). We pick the longest trailing run of
/// empty groups (but never drop group 0 — single-group fs stays
/// unchanged), recompute the new size, update the superblock,
/// and truncate the backing file.
///
/// Extension: if the trailing groups are *mostly* empty but
/// contain a small handful (≤ MAX_RELOC) of in-the-way data
/// blocks, relocate them to the front of the fs first and then
/// drop. Only regular-file extent data blocks are eligible —
/// hitting any inode-table / bitmap / extent-tree / non-regular
/// block aborts the shrink.
fn shrink_trailing_empty_groups(
    fs: &mut Fs,
    path: &std::path::Path,
) -> std::io::Result<ShrinkOutcome> {
    const MAX_RELOC: usize = 64;

    let groups = fs.groups_count;
    if groups <= 1 {
        return Ok(ShrinkOutcome::NoOp);
    }

    let has_sparse = (fs.sb.s_feature_ro_compat & EXT4_FEATURE_RO_COMPAT_SPARSE_SUPER) != 0;
    let first_data_block = fs.sb.s_first_data_block as u64;
    let bpg = fs.blocks_per_group;
    let total_blocks = fs.total_blocks();

    // -------- Phase 1: pick the deepest drop_from we can afford. --------
    // Walk groups from the end inward. For each group, count how many
    // *data-area* bits are set in its block bitmap (the "in-the-way"
    // load if we drop this group). Sum them as we descend; stop the
    // moment the cumulative load would exceed MAX_RELOC.
    let mut drop_from: u64 = groups;
    let mut freed_data_blocks: u64 = 0;
    let mut inway_total: usize = 0;
    let mut inway_blocks: Vec<u64> = Vec::new();

    let mut g = groups;
    while g > 1 {
        let gi = g - 1;
        let group_start = first_data_block + gi * bpg;
        let group_end = core::cmp::min(group_start + bpg, total_blocks);
        let group_total = group_end.saturating_sub(group_start);
        if group_total == 0 {
            break;
        }
        let overhead = group_overhead(fs, gi, groups, has_sparse);
        let data_capacity = group_total.saturating_sub(overhead);

        // Enumerate any allocated bits in the *data area* of this group.
        // The data area starts at group_start + overhead.
        let used_in_group = enumerate_used_data_blocks(
            fs, gi, group_start, overhead, group_total,
        )?;

        if inway_total + used_in_group.len() > MAX_RELOC {
            // Past our budget — stop descending. The drop_from we
            // already settled on (one group above) is what we'll
            // commit to. If we never made any progress (drop_from
            // is still == groups, meaning even the very last group
            // overflows the budget by itself), report and bail.
            if drop_from >= groups {
                eprintln!(
                    "resize2fs: shrink would require relocating {} blocks; giving up",
                    inway_total + used_in_group.len(),
                );
                return Ok(ShrinkOutcome::NoOp);
            }
            break;
        }
        inway_total += used_in_group.len();
        inway_blocks.extend(used_in_group);

        // Free-blocks accounting for the SB update below counts
        // *data* free blocks (not metadata).
        let d = &fs.gdt[gi as usize];
        let bg_free = bg_free_blocks(d, fs.has_64bit) as u64;
        freed_data_blocks = freed_data_blocks.saturating_add(bg_free);

        drop_from = gi;
        g = gi;

        // Heuristic stop: don't keep descending past data_capacity ==
        // 0 groups indefinitely — those are pure overhead groups and
        // there's no win in dropping them past the first allocated
        // group above.
        let _ = data_capacity;
    }

    if drop_from >= groups {
        return Ok(ShrinkOutcome::NoOp);
    }

    // -------- Phase 2: relocate in-the-way blocks. --------
    if !inway_blocks.is_empty() {
        relocate_blocks(fs, &inway_blocks, drop_from, first_data_block, bpg)?;
        // After relocation, the dropped groups' bitmaps and bg_free
        // should reflect "all data free". Recount free_data_blocks
        // from the updated descriptors so the SB bookkeeping below
        // matches reality.
        freed_data_blocks = 0;
        for gi in drop_from..groups {
            let d = &fs.gdt[gi as usize];
            freed_data_blocks = freed_data_blocks
                .saturating_add(bg_free_blocks(d, fs.has_64bit) as u64);
        }
    }

    let new_total_blocks = first_data_block + drop_from * bpg;
    let new_byte_size = new_total_blocks * fs.block_size;
    let dropped = groups - drop_from;

    let mut dropped_inodes_total: u64 = 0;
    let mut dropped_inodes_free: u64 = 0;
    for gi in drop_from..groups {
        let d = &fs.gdt[gi as usize];
        let bg_free_ino = bg_free_inodes(d, fs.has_64bit) as u64;
        dropped_inodes_total = dropped_inodes_total.saturating_add(fs.inodes_per_group);
        dropped_inodes_free = dropped_inodes_free.saturating_add(bg_free_ino);
    }

    let old_total = total_blocks;
    let old_free = fs.free_blocks();
    let new_free = old_free.saturating_sub(freed_data_blocks);
    fs.sb.set_blocks_count(new_total_blocks);
    fs.sb.set_free_blocks(new_free);

    let old_inodes = fs.sb.s_inodes_count as u64;
    let old_free_inodes = fs.sb.s_free_inodes_count as u64;
    let new_inodes = old_inodes.saturating_sub(dropped_inodes_total);
    let new_free_inodes = old_free_inodes.saturating_sub(dropped_inodes_free);
    fs.sb.s_inodes_count = new_inodes as u32;
    fs.sb.s_free_inodes_count = new_free_inodes as u32;

    // If we relocated anything, the GDT bg_free_blocks counts on
    // group 0 (and any other touched group still inside the keep
    // range) changed. Persist the GDT and refresh GDT csums under
    // metadata_csum.
    let metadata_csum =
        (fs.sb.s_feature_ro_compat & EXT4_FEATURE_RO_COMPAT_METADATA_CSUM) != 0;
    if metadata_csum {
        // Truncate GDT csums to the keep range only — the dropped
        // groups' descriptors are about to be lopped off anyway.
        for gi in 0..drop_from {
            stamp_gdt_csum(fs, gi);
        }
        fs.sb.s_checksum = 0;
        let bytes = fs.sb.to_bytes();
        fs.sb.s_checksum =
            anvil_core::crc::crc32c_cont(0xFFFFFFFF, &bytes[..0x3FC]);
    }

    // Truncate the in-memory GDT to the keep range and flush.
    fs.gdt.truncate(drop_from as usize);
    fs.groups_count = drop_from;
    fs.write_gdt()?;
    fs.write_superblock()?;
    fs.dev.sync()?;

    let f = std::fs::OpenOptions::new().write(true).open(path)?;
    f.set_len(new_byte_size)?;
    f.sync_all()?;

    Ok(ShrinkOutcome::Shrunk {
        from_blocks: old_total,
        to_blocks: new_total_blocks,
        dropped_groups: dropped,
    })
}

/// Read group `gi`'s block bitmap and return the absolute block
/// numbers of every set bit in its data area
/// `[group_start + overhead, group_start + group_total)`.
fn enumerate_used_data_blocks(
    fs: &mut Fs,
    gi: u64,
    group_start: u64,
    overhead: u64,
    group_total: u64,
) -> std::io::Result<Vec<u64>> {
    let bs = fs.block_size as usize;
    let bb_blk = fs.group_block_bitmap(gi);
    let mut bb = vec![0u8; bs];
    fs.dev.read_at(bb_blk * fs.block_size, &mut bb)?;

    let data_start_rel = overhead as usize;
    let data_end_rel   = group_total as usize;
    let mut out = Vec::new();
    for bit in data_start_rel..data_end_rel {
        if anvil_core::bitmap::test_bit(&bb, bit) {
            out.push(group_start + bit as u64);
        }
    }
    Ok(out)
}

/// Relocate each block in `inway_blocks` to a fresh slot in group 0.
///
/// For every block we:
///   1. Reverse-lookup the owning inode via a brute extent scan
///      across all inodes in the keep range (groups 0..drop_from).
///   2. Refuse if the inode is not a regular file or if the block
///      is not reached via a depth-0 extent leaf entry whose
///      ee_start covers it (i.e. this is a regular file's data
///      block, not a journal page, xattr block, dir block, or
///      extent-tree interior node).
///   3. Allocate a fresh free block in group 0's data area.
///   4. Copy the bytes.
///   5. Rewrite the leaf extent's ee_start. The extent may be
///      multi-block — if so, we split it: the relocated block
///      becomes its own one-block extent and the original is
///      truncated / split around it.
///   6. Recompute inode csum (metadata_csum).
///   7. Clear the old bitmap bit; set the new bitmap bit.
///   8. Bump bg_free_blocks for the source/dest groups.
///   9. Restamp bitmap / GDT csums.
///
/// Bails on first failure — partial state is left on disk but
/// the SB hasn't been rewritten yet so the fs is still readable
/// (the relocated extents point at the new blocks but the old
/// blocks are still marked allocated; e2fsck would clean it up).
fn relocate_blocks(
    fs: &mut Fs,
    inway_blocks: &[u64],
    drop_from: u64,
    first_data_block: u64,
    bpg: u64,
) -> std::io::Result<()> {
    if inway_blocks.is_empty() {
        return Ok(());
    }
    // -- Resolve every in-the-way block to (inode, leaf, extent_idx). --
    // Refuse if any block isn't a regular-file leaf extent entry.
    let pre = build_block_to_inode_map(fs, drop_from, inway_blocks)?;
    for blk in inway_blocks {
        let Some(loc) = pre.get(blk) else {
            return Err(std::io::Error::new(
                std::io::ErrorKind::Other,
                format!(
                    "block {blk} is allocated in a to-drop group but no \
                     regular-file extent leaf claims it (likely metadata, \
                     directory, journal, or extent-tree node — bailing)"
                ),
            ));
        };
        if !loc.is_regular_file_data {
            return Err(std::io::Error::new(
                std::io::ErrorKind::Other,
                format!(
                    "block {blk} is owned by inode {} which is not a \
                     regular file — bailing", loc.inode_num,
                ),
            ));
        }
    }

    // Group blocks by (inode_num, parent_block, extent_idx). All
    // blocks belonging to the same leaf extent record share that
    // key; treating them as a single relocation unit avoids the
    // eh_max blowup that per-block splits would cause.
    use std::collections::BTreeMap;
    let mut all_dest_blocks: Vec<u64> = Vec::new();
    let mut by_extent: BTreeMap<(u32, u64, u16), Vec<u64>> = BTreeMap::new();
    for blk in inway_blocks {
        let loc = &pre[blk];
        by_extent
            .entry((loc.inode_num, loc.parent_block, loc.extent_idx))
            .or_default()
            .push(*blk);
    }

    // Each group must be the COMPLETE coverage of that leaf extent
    // (all its blocks must be in the to-drop range — partial
    // straddling extents are out of scope: would require a real
    // split and a new leaf-block allocation).
    let bs = fs.block_size as usize;
    let block_size = fs.block_size;
    let metadata_csum =
        (fs.sb.s_feature_ro_compat & EXT4_FEATURE_RO_COMPAT_METADATA_CSUM) != 0;

    for ((inode_num, parent_block, extent_idx), blks) in &by_extent {
        // Re-read the leaf from disk fresh — earlier iterations on
        // the same inode may have rewritten ee_start of other
        // entries, but the (parent_block, extent_idx) coordinate is
        // stable as long as we don't change entry counts (we don't).
        let mut leaf = read_leaf_buffer(fs, *inode_num, *parent_block)?;
        let off = 12 + (*extent_idx as usize) * 12;
        let e: Extent = unsafe {
            core::ptr::read_unaligned(leaf[off..].as_ptr() as *const Extent)
        };
        let len_field = e.ee_len;
        let raw_len = if len_field > 32768 { len_field - 32768 } else { len_field };
        let phys = e.start();
        if blks.len() != raw_len as usize {
            return Err(std::io::Error::new(std::io::ErrorKind::Other, format!(
                "extent for inode {inode_num} at leaf {parent_block} idx \
                 {extent_idx} only partially overlaps drop range ({} of {} \
                 blocks); partial-extent split not implemented",
                blks.len(), raw_len,
            )));
        }

        // Allocate raw_len contiguous blocks in group 0.
        let dst_run = allocate_in_group0(fs, raw_len as usize)?;
        all_dest_blocks.extend_from_slice(&dst_run);
        // Reserve them in the on-disk bitmap immediately so the
        // next allocate_in_group0 call (next extent) doesn't pick
        // the same range. This sets the bits and decrements
        // bg_free for group 0 — symmetric with the post-loop
        // bitmap flip the original design used.
        for &b in &dst_run {
            flip_bitmap_bit(fs, b, true)?;
        }
        // dst_run is contiguous when allocate_in_group0 finds a
        // big-enough run; verify.
        let contig = dst_run.windows(2).all(|w| w[1] == w[0] + 1);
        if !contig {
            return Err(std::io::Error::new(std::io::ErrorKind::Other, format!(
                "could not find a contiguous {} -block free run in group 0; \
                 fragmented in-place fallback not implemented", raw_len,
            )));
        }
        let dst_start = dst_run[0];

        // Copy each block.
        for k in 0..raw_len as u64 {
            let mut buf = vec![0u8; bs];
            fs.dev.read_at((phys + k) * block_size, &mut buf)?;
            fs.dev.write_at((dst_start + k) * block_size, &buf)?;
        }

        // Rewrite ee_start in the leaf.
        let mut e_new = e;
        e_new.set_start(dst_start);
        unsafe {
            core::ptr::copy_nonoverlapping(
                &e_new as *const Extent as *const u8,
                leaf[off..].as_mut_ptr(), 12,
            );
        }

        // Re-stamp external-leaf tail csum if applicable.
        if *parent_block != 0 {
            if metadata_csum {
                let inode = fs.read_inode(*inode_num)?;
                let entries_now = u16::from_le_bytes([leaf[2], leaf[3]]);
                let csum = anvil_core::fs::compute_extent_block_csum(
                    &fs.sb, *inode_num, inode.i_generation, &leaf, entries_now,
                );
                let csum_off = 12 * (entries_now as usize + 1);
                if csum_off + 4 <= leaf.len() {
                    leaf[csum_off..csum_off + 4]
                        .copy_from_slice(&csum.to_le_bytes());
                }
            }
            fs.dev.write_at(*parent_block * fs.block_size, &leaf)?;
        } else {
            // Inline: write 60 bytes back into i_block at offset 0x28.
            let group = (*inode_num as u64 - 1) / fs.inodes_per_group;
            let i_idx = (*inode_num as u64 - 1) % fs.inodes_per_group;
            let table = fs.group_inode_table(group);
            let inode_byte = table * fs.block_size + i_idx * fs.inode_size;
            const IBLOCK_OFFSET: u64 = 0x28;
            fs.dev.write_at(inode_byte + IBLOCK_OFFSET, &leaf[..60])?;
        }

        // Recompute inode csum.
        if metadata_csum {
            recompute_inode_csum(fs, *inode_num)?;
        }

        // Clear the bitmap bits of the source extent (dst was
        // already reserved via flip_bitmap_bit immediately after
        // allocation, above).
        for k in 0..raw_len as u64 {
            flip_bitmap_bit(fs, phys + k, false)?;
        }

        let _ = first_data_block;
        let _ = bpg;
    }

    // After all bitmap edits, restamp bitmap csums for any group
    // we touched (source groups + group 0). flip_bitmap_bit already
    // updated bg_free; csums are stamped here uniformly.
    if metadata_csum {
        let mut touched: std::collections::BTreeSet<u64> =
            std::collections::BTreeSet::new();
        let first_data_block = fs.sb.s_first_data_block as u64;
        let bpg = fs.blocks_per_group;
        for &b in inway_blocks { touched.insert((b - first_data_block) / bpg); }
        for &b in &all_dest_blocks { touched.insert((b - first_data_block) / bpg); }
        for gi in touched {
            stamp_block_bitmap_csum(fs, gi)?;
        }
    }

    Ok(())
}

/// Where in an inode's extent tree a given physical block lives.
struct LeafLoc {
    inode_num: u32,
    /// True iff i_mode says S_IFREG.
    is_regular_file_data: bool,
    /// Identifies which leaf extent record covers this block.
    /// `parent_block == 0` means the leaf is inline (in the
    /// inode's i_block[0..15]); otherwise it's the absolute block
    /// number of the external leaf.
    parent_block: u64,
    /// Index of the Extent record within that leaf.
    extent_idx: u16,
    /// Cached header entries for csum recomputation when an
    /// external leaf is rewritten.
    leaf_entries: u16,
}

/// Walk every used inode in groups `[0, drop_from)` and return
/// a map physical_block → LeafLoc for each requested `inway`
/// block. Inodes whose extent tree references one of the targets
/// are recorded; everything else is ignored.
fn build_block_to_inode_map(
    fs: &mut Fs,
    drop_from: u64,
    inway: &[u64],
) -> std::io::Result<std::collections::BTreeMap<u64, LeafLoc>> {
    let mut want: std::collections::BTreeSet<u64> =
        inway.iter().copied().collect();
    let mut out: std::collections::BTreeMap<u64, LeafLoc> =
        std::collections::BTreeMap::new();

    let last_inode_in_keep = (drop_from * fs.inodes_per_group) as u32;
    for ino_num in 1..=last_inode_in_keep {
        if want.is_empty() {
            break;
        }
        let inode = match fs.read_inode(ino_num) {
            Ok(i) => i,
            Err(_) => continue,
        };
        // Skip unused / deleted inodes (links == 0 and dtime != 0
        // means deleted; mode == 0 means never used).
        let mode = inode.i_mode;
        if mode == 0 { continue; }
        let links = inode.i_links_count;
        let dtime = inode.i_dtime;
        if links == 0 && dtime != 0 { continue; }

        // Only the extent path is supported. Pre-extents block-map
        // inodes (small ext2-compat fs) would need a different
        // rewrite path; we'd rather refuse than silently mishandle.
        let flags = inode.i_flags;
        if flags & EXT4_EXTENTS_FL == 0 {
            continue;
        }

        let is_reg = (mode & S_IFMT) == S_IFREG;

        // Walk the extent tree manually so we can record the
        // (parent_block, extent_idx) each found target lives in.
        let mut inline = vec![0u8; 60];
        unsafe {
            core::ptr::copy_nonoverlapping(
                core::ptr::addr_of!(inode.i_block) as *const u8,
                inline.as_mut_ptr(), 60,
            );
        }
        scan_extent_node(
            fs, &inline, 0, ino_num, is_reg, &mut want, &mut out,
        )?;
    }
    Ok(out)
}

fn scan_extent_node(
    fs: &mut Fs,
    node_buf: &[u8],
    parent_block: u64,
    inode_num: u32,
    is_regular_file_data: bool,
    want: &mut std::collections::BTreeSet<u64>,
    out: &mut std::collections::BTreeMap<u64, LeafLoc>,
) -> std::io::Result<()> {
    if node_buf.len() < 12 { return Ok(()); }
    let hdr: ExtentHeader = unsafe {
        core::ptr::read_unaligned(node_buf.as_ptr() as *const ExtentHeader)
    };
    if hdr.eh_magic != EXT4_EXT_MAGIC { return Ok(()); }
    let entries = hdr.eh_entries;
    let depth = hdr.eh_depth;

    if depth == 0 {
        for i in 0..entries as usize {
            let off = 12 + i * 12;
            if off + 12 > node_buf.len() { break; }
            let e: Extent = unsafe {
                core::ptr::read_unaligned(node_buf[off..].as_ptr() as *const Extent)
            };
            let len = e.ee_len;
            let real_len = if len > 32768 { len - 32768 } else { len } as u64;
            let phys = e.start();
            for b in phys..phys + real_len {
                if want.remove(&b) {
                    out.insert(b, LeafLoc {
                        inode_num,
                        is_regular_file_data,
                        parent_block,
                        extent_idx: i as u16,
                        leaf_entries: entries,
                    });
                }
            }
        }
    } else {
        for i in 0..entries as usize {
            let off = 12 + i * 12;
            if off + 12 > node_buf.len() { break; }
            let idx: ExtentIdx = unsafe {
                core::ptr::read_unaligned(node_buf[off..].as_ptr() as *const ExtentIdx)
            };
            let child_blk = ((idx.ei_leaf_hi as u64) << 32) | idx.ei_leaf_lo as u64;
            if child_blk == 0 || child_blk >= fs.total_blocks() { continue; }
            let mut child = vec![0u8; fs.block_size as usize];
            fs.read_block(child_blk, &mut child)?;
            scan_extent_node(
                fs, &child, child_blk, inode_num,
                is_regular_file_data, want, out,
            )?;
        }
    }
    Ok(())
}

/// Allocate `n` free blocks from group 0's data area. We prefer
/// a contiguous run but fall back to scattered slots if no
/// contiguous range that big exists.
fn allocate_in_group0(fs: &mut Fs, n: usize) -> std::io::Result<Vec<u64>> {
    let bs = fs.block_size as usize;
    let bb_blk = fs.group_block_bitmap(0);
    let mut bb = vec![0u8; bs];
    fs.dev.read_at(bb_blk * fs.block_size, &mut bb)?;

    let first_data_block = fs.sb.s_first_data_block as u64;
    let group_start = first_data_block; // group 0
    let bpg = fs.blocks_per_group as usize;
    let total = fs.total_blocks() as usize;
    let group_end_rel = core::cmp::min(bpg, total - first_data_block as usize);

    // Find the first contiguous free run >= n in [0, group_end_rel).
    let mut start: Option<usize> = None;
    let mut run_len = 0usize;
    let mut best_start: Option<usize> = None;
    for bit in 0..group_end_rel {
        if !anvil_core::bitmap::test_bit(&bb, bit) {
            if run_len == 0 { start = Some(bit); }
            run_len += 1;
            if run_len >= n {
                best_start = start;
                break;
            }
        } else {
            run_len = 0;
            start = None;
        }
    }

    if let Some(s) = best_start {
        let mut out = Vec::with_capacity(n);
        for k in 0..n { out.push(group_start + (s + k) as u64); }
        return Ok(out);
    }

    // Fallback: pick scattered free bits.
    let mut out = Vec::with_capacity(n);
    for bit in 0..group_end_rel {
        if !anvil_core::bitmap::test_bit(&bb, bit) {
            out.push(group_start + bit as u64);
            if out.len() == n { return Ok(out); }
        }
    }
    Err(std::io::Error::new(
        std::io::ErrorKind::Other,
        format!("group 0 has no room for {n} relocated blocks"),
    ))
}

/// Read the bytes of an extent leaf node identified by
/// `parent_block`. `parent_block == 0` means the leaf is inline
/// in the inode's `i_block` array (60 bytes); otherwise it's the
/// absolute block number of an external leaf (block_size bytes).
fn read_leaf_buffer(
    fs: &mut Fs,
    inode_num: u32,
    parent_block: u64,
) -> std::io::Result<Vec<u8>> {
    if parent_block == 0 {
        let inode = fs.read_inode(inode_num)?;
        let mut buf = vec![0u8; 60];
        unsafe {
            core::ptr::copy_nonoverlapping(
                core::ptr::addr_of!(inode.i_block) as *const u8,
                buf.as_mut_ptr(), 60,
            );
        }
        Ok(buf)
    } else {
        let mut buf = vec![0u8; fs.block_size as usize];
        fs.dev.read_at(parent_block * fs.block_size, &mut buf)?;
        Ok(buf)
    }
}

/// Rewrite the extent leaf entry that covers `src` so it points at
/// `dst`. If the leaf's extent record is multi-block, we need to
/// split it: the entry covering [phys..phys+len) gets re-laid as
///   * left:    [phys..src),         len = src - phys      (if non-empty)
///   * relocated: [dst..dst+1),       len = 1              (the moved one)
///   * right:   [src+1..phys+len),  len = phys+len-(src+1) (if non-empty)
///
/// Splitting a leaf can grow the entry count past eh_max for an
/// inline extent. We detect that and bail (out of scope: would
/// require allocating a fresh leaf block).
#[allow(dead_code)]
fn rewrite_extent_leaf_for_block(
    fs: &mut Fs,
    loc: &LeafLoc,
    src: u64,
    dst: u64,
) -> std::io::Result<()> {
    let bs = fs.block_size as usize;

    // Pull the full leaf buffer.
    let mut leaf = if loc.parent_block == 0 {
        // Inline: read the inode and copy out i_block.
        let inode = fs.read_inode(loc.inode_num)?;
        let mut buf = vec![0u8; 60];
        unsafe {
            core::ptr::copy_nonoverlapping(
                core::ptr::addr_of!(inode.i_block) as *const u8,
                buf.as_mut_ptr(), 60,
            );
        }
        buf
    } else {
        let mut buf = vec![0u8; bs];
        fs.dev.read_at(loc.parent_block * fs.block_size, &mut buf)?;
        buf
    };

    let hdr: ExtentHeader = unsafe {
        core::ptr::read_unaligned(leaf.as_ptr() as *const ExtentHeader)
    };
    let entries = hdr.eh_entries as usize;
    let max_entries = hdr.eh_max as usize;
    let idx = loc.extent_idx as usize;
    if idx >= entries {
        return Err(std::io::Error::new(std::io::ErrorKind::Other,
            "extent leaf shrunk under us"));
    }

    let off = 12 + idx * 12;
    let e: Extent = unsafe {
        core::ptr::read_unaligned(leaf[off..].as_ptr() as *const Extent)
    };
    let len = e.ee_len;
    let raw_len = if len > 32768 { len - 32768 } else { len };
    let uninit = len > 32768;
    let phys = e.start();
    let logical = e.ee_block;

    // Sanity: src must lie inside this extent.
    if src < phys || src >= phys + raw_len as u64 {
        return Err(std::io::Error::new(std::io::ErrorKind::Other,
            "leaf extent does not cover requested block"));
    }
    let inner = (src - phys) as u32;

    // Common case: the extent is a single block — just rewrite
    // ee_start in place, no split needed.
    if raw_len == 1 {
        let mut e_new = e;
        e_new.set_start(dst);
        unsafe {
            core::ptr::copy_nonoverlapping(
                &e_new as *const Extent as *const u8,
                leaf[off..].as_mut_ptr(), 12,
            );
        }
    } else {
        // Need to split. New record count = entries - 1
        //   + (left non-empty? 1 : 0) + 1 (relocated) + (right non-empty? 1 : 0)
        let left_len  = inner;
        let right_len = raw_len as u32 - inner - 1;
        let extras = (if left_len > 0 { 1 } else { 0 })
                   + 1
                   + (if right_len > 0 { 1 } else { 0 });
        let new_entries = entries - 1 + extras;
        if new_entries > max_entries {
            return Err(std::io::Error::new(std::io::ErrorKind::Other, format!(
                "extent split for block {src} would exceed leaf eh_max \
                 ({max_entries}); on-disk extent leaf splitting is not \
                 implemented in this pass")));
        }

        // Build the replacement record list. Records are 12 bytes
        // each, header still 12 bytes at the start.
        let head_off = 12;
        let mut new_records: Vec<[u8; 12]> = Vec::with_capacity(new_entries);

        // Records before idx — unchanged.
        for i in 0..idx {
            let mut r = [0u8; 12];
            r.copy_from_slice(&leaf[head_off + i * 12 .. head_off + (i + 1) * 12]);
            new_records.push(r);
        }

        // Helper to build an extent record from fields.
        let mk_extent = |logical: u32, length: u32, phys: u64, uninit: bool| -> [u8; 12] {
            let mut e = Extent::default();
            e.ee_block = logical;
            let stored_len = if uninit && length <= 32768 {
                32768 + length as u16
            } else {
                length as u16
            };
            e.ee_len = stored_len;
            e.set_start(phys);
            let mut r = [0u8; 12];
            unsafe {
                core::ptr::copy_nonoverlapping(
                    &e as *const Extent as *const u8,
                    r.as_mut_ptr(), 12,
                );
            }
            r
        };

        if left_len > 0 {
            new_records.push(mk_extent(logical, left_len, phys, uninit));
        }
        // Relocated (single block).
        new_records.push(mk_extent(logical + inner, 1, dst, uninit));
        if right_len > 0 {
            new_records.push(mk_extent(
                logical + inner + 1, right_len, src + 1, uninit,
            ));
        }
        // Records after idx — unchanged.
        for i in idx + 1 .. entries {
            let mut r = [0u8; 12];
            r.copy_from_slice(&leaf[head_off + i * 12 .. head_off + (i + 1) * 12]);
            new_records.push(r);
        }

        // Splat back. Update header eh_entries.
        let mut new_hdr = hdr;
        new_hdr.eh_entries = new_entries as u16;
        unsafe {
            core::ptr::copy_nonoverlapping(
                &new_hdr as *const ExtentHeader as *const u8,
                leaf.as_mut_ptr(), 12,
            );
        }
        // Zero the records area first (in case we shrank — we
        // didn't here, but be defensive about stale bytes).
        let records_max_bytes = if loc.parent_block == 0 {
            48
        } else {
            // External leaf reserves a 4-byte tail csum slot when
            // metadata_csum is on; otherwise the tail is unused
            // anyway, so just don't write past the end.
            bs - head_off
        };
        let zero_end = head_off + records_max_bytes;
        for b in &mut leaf[head_off..zero_end] { *b = 0; }
        for (i, r) in new_records.iter().enumerate() {
            let dst = head_off + i * 12;
            leaf[dst..dst + 12].copy_from_slice(r);
        }
    }

    // Stamp external leaf tail csum if applicable.
    let metadata_csum =
        (fs.sb.s_feature_ro_compat & EXT4_FEATURE_RO_COMPAT_METADATA_CSUM) != 0;
    if loc.parent_block != 0 {
        if metadata_csum {
            let inode = fs.read_inode(loc.inode_num)?;
            let entries_now = u16::from_le_bytes([leaf[2], leaf[3]]);
            let csum = anvil_core::fs::compute_extent_block_csum(
                &fs.sb, loc.inode_num, inode.i_generation, &leaf, entries_now,
            );
            let csum_off = 12 * (entries_now as usize + 1);
            if csum_off + 4 <= leaf.len() {
                leaf[csum_off..csum_off + 4].copy_from_slice(&csum.to_le_bytes());
            }
        }
        fs.dev.write_at(loc.parent_block * fs.block_size, &leaf)?;
    } else {
        // Write the modified i_block back into the inode.
        let group = (loc.inode_num as u64 - 1) / fs.inodes_per_group;
        let i_idx = (loc.inode_num as u64 - 1) % fs.inodes_per_group;
        let table = fs.group_inode_table(group);
        let inode_byte = table * fs.block_size + i_idx * fs.inode_size;
        // i_block lives at offset 0x28 (40) within the inode.
        const IBLOCK_OFFSET: u64 = 0x28;
        fs.dev.write_at(inode_byte + IBLOCK_OFFSET, &leaf[..60])?;
    }

    let _ = loc.leaf_entries;
    Ok(())
}

/// Read inode N, recompute its metadata_csum, and write the two
/// csum fields back. Caller must have already updated the inode's
/// other fields (we re-read fresh bytes from disk so any extent
/// rewrites land in the hash).
fn recompute_inode_csum(fs: &mut Fs, ino_num: u32) -> std::io::Result<()> {
    let group = (ino_num as u64 - 1) / fs.inodes_per_group;
    let idx   = (ino_num as u64 - 1) % fs.inodes_per_group;
    let table = fs.group_inode_table(group);
    let byte  = table * fs.block_size + idx * fs.inode_size;
    let mut buf = vec![0u8; fs.inode_size as usize];
    fs.dev.read_at(byte, &mut buf)?;

    let extra_isize = if fs.inode_size >= 256 {
        u16::from_le_bytes([buf[0x80], buf[0x81]])
    } else { 0 };
    let use_hi = fs.inode_size >= 256 && extra_isize > 2;

    let gen = u32::from_le_bytes([buf[0x64], buf[0x65], buf[0x66], buf[0x67]]);

    // Zero the csum fields before hashing.
    buf[0x7C] = 0; buf[0x7D] = 0;
    if use_hi { buf[0x82] = 0; buf[0x83] = 0; }

    let csum = compute_inode_csum(&fs.sb, ino_num, gen, &buf);
    let lo = csum as u16;
    buf[0x7C] = lo as u8; buf[0x7D] = (lo >> 8) as u8;
    if use_hi {
        let hi = (csum >> 16) as u16;
        buf[0x82] = hi as u8; buf[0x83] = (hi >> 8) as u8;
    }
    fs.dev.write_at(byte, &buf)
}

/// Toggle one bit in a block group's block bitmap. `set=true`
/// marks allocated, false marks free. Updates bg_free_blocks
/// accordingly. Bitmap csum / GDT csum get re-stamped in bulk
/// by the caller.
fn flip_bitmap_bit(fs: &mut Fs, blk: u64, set: bool) -> std::io::Result<()> {
    let first_data_block = fs.sb.s_first_data_block as u64;
    let bpg = fs.blocks_per_group;
    let gi = (blk - first_data_block) / bpg;
    let bit = ((blk - first_data_block) % bpg) as usize;

    let bs = fs.block_size as usize;
    let bb_blk = fs.group_block_bitmap(gi);
    let mut bb = vec![0u8; bs];
    fs.dev.read_at(bb_blk * fs.block_size, &mut bb)?;

    let was_set = anvil_core::bitmap::test_bit(&bb, bit);
    if set && !was_set {
        anvil_core::bitmap::set_bit(&mut bb, bit);
        let d = &mut fs.gdt[gi as usize];
        let cur = bg_free_blocks(d, fs.has_64bit);
        d.set_free_blocks(cur.saturating_sub(1));
    } else if !set && was_set {
        anvil_core::bitmap::clear_bit(&mut bb, bit);
        let d = &mut fs.gdt[gi as usize];
        let cur = bg_free_blocks(d, fs.has_64bit);
        d.set_free_blocks(cur + 1);
    }
    fs.dev.write_at(bb_blk * fs.block_size, &bb)?;
    Ok(())
}

/// Re-stamp a group's block-bitmap csum into its descriptor.
fn stamp_block_bitmap_csum(fs: &mut Fs, gi: u64) -> std::io::Result<()> {
    let bs = fs.block_size as usize;
    let bb_blk = fs.group_block_bitmap(gi);
    let mut bb = vec![0u8; bs];
    fs.dev.read_at(bb_blk * fs.block_size, &mut bb)?;
    let bbc = compute_bitmap_csum(&fs.sb, &bb);
    let d = &mut fs.gdt[gi as usize];
    d.bg_block_bitmap_csum_lo = bbc as u16;
    if fs.has_64bit && fs.desc_size >= 0x3A {
        d.bg_block_bitmap_csum_hi = (bbc >> 16) as u16;
    }
    Ok(())
}

fn bg_free_blocks(d: &anvil_core::group_desc::GroupDesc64, has_64bit: bool) -> u32 {
    let lo = d.bg_free_blocks_count_lo as u32;
    let hi = if has_64bit { d.bg_free_blocks_count_hi as u32 } else { 0 };
    (hi << 16) | lo
}

fn bg_free_inodes(d: &anvil_core::group_desc::GroupDesc64, has_64bit: bool) -> u32 {
    let lo = d.bg_free_inodes_count_lo as u32;
    let hi = if has_64bit { d.bg_free_inodes_count_hi as u32 } else { 0 };
    (hi << 16) | lo
}

fn group_overhead(fs: &Fs, gi: u64, groups_count: u64, has_sparse: bool) -> u64 {
    let block_size = fs.block_size;
    let inode_table_blocks =
        div_ceil_u64(fs.inodes_per_group.saturating_mul(fs.inode_size), block_size);
    let mut overhead = 2u64 + inode_table_blocks;

    let is_backup = !has_sparse || is_backup_group(gi);
    if is_backup {
        let gdt_blocks = div_ceil_u64(groups_count.saturating_mul(fs.desc_size), block_size);
        let reserved_gdt = fs.sb.s_reserved_gdt_blocks as u64;
        overhead = overhead.saturating_add(1 + gdt_blocks + reserved_gdt);
    }
    overhead
}

fn estimate_minimum_blocks(fs: &Fs) -> u64 {
    let total = fs.total_blocks();
    let free = fs.free_blocks();
    let used = total.saturating_sub(free);

    let bpg = fs.blocks_per_group.max(1);
    let hypo_groups = div_ceil_u64(used.max(1), bpg).max(1);

    let has_sparse = (fs.sb.s_feature_ro_compat & EXT4_FEATURE_RO_COMPAT_SPARSE_SUPER) != 0;

    let mut overhead_sum: u64 = 0;
    for g in 0..hypo_groups {
        overhead_sum = overhead_sum.saturating_add(group_overhead(fs, g, hypo_groups, has_sparse));
    }

    let slack = 512u64;
    let candidate_a = used.saturating_add(slack);
    let candidate_b = used.saturating_add(overhead_sum);
    let mut min_blocks = candidate_a.max(candidate_b);
    if min_blocks < 1024 {
        min_blocks = 1024;
    }
    if min_blocks > total {
        min_blocks = total;
    }
    min_blocks
}

fn div_ceil_u64(a: u64, b: u64) -> u64 {
    if b == 0 {
        return 0;
    }
    a.saturating_add(b - 1) / b
}

fn is_backup_group(gi: u64) -> bool {
    if gi == 0 || gi == 1 {
        return true;
    }
    for &base in &[3u64, 5, 7] {
        let mut p = base;
        while p <= gi {
            if p == gi {
                return true;
            }
            p = match p.checked_mul(base) {
                Some(v) => v,
                None => break,
            };
        }
    }
    false
}

fn human_size(bytes: u64) -> String {
    const KIB: u64 = 1024;
    const MIB: u64 = 1024 * KIB;
    const GIB: u64 = 1024 * MIB;
    if bytes >= GIB {
        format!("{:.2} GiB", bytes as f64 / GIB as f64)
    } else if bytes >= MIB {
        format!("{:.2} MiB", bytes as f64 / MIB as f64)
    } else if bytes >= KIB {
        format!("{:.2} KiB", bytes as f64 / KIB as f64)
    } else {
        format!("{bytes} B")
    }
}
