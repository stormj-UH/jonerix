//! e4defrag — read-only fragmentation reporter.
//!
//! Phase 6f scope: diagnostic only. Walks every allocated inode
//! in the filesystem, counts how many extent runs each file
//! occupies via `anvil_core::extent::walk_extents`, and reports
//! the inodes whose fragment count exceeds the minimum the file
//! could theoretically occupy.
//!
//! Actual block relocation (online defragmentation) requires a
//! writable, mounted filesystem and a move-extent ioctl path,
//! both of which are explicitly out of scope here. This binary
//! never writes to the device.
//!
//! Flags:
//!   -c          summary report (default when no flag given)
//!   -v          per-file verbose report (fragmented inodes only)
//!   -V          version
//!
//! Exit codes follow the anvil family:
//!   0   clean scan
//!   8   operational error (open / read)
//!   16  usage error

use std::path::PathBuf;
use std::process::ExitCode;

use anvil_core::consts::{S_IFBLK, S_IFCHR, S_IFIFO, S_IFMT, S_IFSOCK};
use anvil_core::extent::walk_extents;
use anvil_core::fs::Fs;
use anvil_core::inode::Inode;

/// Per-initialized-extent upper bound on `ee_len`. ext4 reserves
/// the top bit of the 16-bit length to mark an uninitialized
/// extent, so a fully-initialized run tops out at 32768 blocks.
/// That's the "ideal" run size we compare actual fragmentation
/// against — a file bigger than one of these must cost at least
/// ceil(size / (32768 * block_size)) extents, and anything above
/// that is fragmentation.
const EXTENT_MAX_LEN: u64 = 32768;

const VERSION_LINE: &str = "anvil-e4defrag 1.47.3-anvil (MIT)";

#[derive(Clone, Copy)]
enum Mode {
    Summary,
    Verbose,
}

fn main() -> ExitCode {
    let args: Vec<String> = std::env::args().skip(1).collect();
    let mut mode = Mode::Summary;
    let mut path: Option<PathBuf> = None;
    for a in args {
        match a.as_str() {
            "-c" => mode = Mode::Summary,
            "-v" => mode = Mode::Verbose,
            "-V" => {
                println!("{VERSION_LINE}");
                return ExitCode::from(0);
            }
            s if s.starts_with('-') => {
                eprintln!("e4defrag: unknown option {s} (ignored)");
            }
            _ => path = Some(PathBuf::from(a)),
        }
    }
    let Some(path) = path else {
        eprintln!("usage: e4defrag [-c|-v] <device>");
        eprintln!("       e4defrag -V");
        return ExitCode::from(16);
    };

    let mut fs = match Fs::open(&path) {
        Ok(fs) => fs,
        Err(e) => {
            eprintln!("e4defrag: open {}: {}", path.display(), e);
            return ExitCode::from(8);
        }
    };

    println!("{VERSION_LINE}");
    println!("Scanning {}", path.display());

    let block_size = fs.block_size;
    let total_inodes = fs.total_inodes();

    // One record per inode we could successfully walk.
    struct Record {
        ino: u32,
        size: u64,
        extents: u64,
        ideal: u64,
    }
    let mut records: Vec<Record> = Vec::new();
    let mut total_allocated: u64 = 0;
    let mut total_with_data: u64 = 0;
    let mut total_extents: u64 = 0;
    let mut walk_errors: u64 = 0;

    for ino_num in 1..=total_inodes {
        let ino_num = ino_num as u32;
        let ino = match fs.read_inode(ino_num) {
            Ok(i) => i,
            Err(_) => continue,
        };
        if !is_allocated(&ino) {
            continue;
        }
        total_allocated += 1;
        if !eligible_for_fragmentation(&ino) {
            continue;
        }
        let size = ino.size();
        if size == 0 {
            continue;
        }
        let mut extent_count: u64 = 0;
        let res = walk_extents(&mut fs, &ino, |_run| {
            extent_count += 1;
        });
        if res.is_err() {
            walk_errors += 1;
            eprintln!("e4defrag: inode {ino_num}: (walk error) — skipping");
            continue;
        }
        if extent_count == 0 {
            // Inline data or empty map — nothing to count.
            continue;
        }
        total_with_data += 1;
        total_extents += extent_count;

        let span = EXTENT_MAX_LEN.saturating_mul(block_size).max(1);
        let ideal = std::cmp::max(1, size.div_ceil(span));

        records.push(Record {
            ino: ino_num,
            size,
            extents: extent_count,
            ideal,
        });
    }

    // A record is "fragmented" iff its extent count exceeds the
    // minimum the file could occupy. Single-extent small files
    // always fall out here.
    let mut fragmented: Vec<&Record> = records
        .iter()
        .filter(|r| r.extents > r.ideal)
        .collect();
    // Worst-first — highest extent count, then highest size as
    // the tie-breaker so the output is stable across runs.
    fragmented.sort_by(|a, b| {
        b.extents
            .cmp(&a.extents)
            .then(b.size.cmp(&a.size))
            .then(a.ino.cmp(&b.ino))
    });

    let avg_str = if total_with_data > 0 {
        let avg = total_extents as f64 / total_with_data as f64;
        format!("{avg:.2}")
    } else {
        "n/a".to_string()
    };

    println!("  Total allocated inodes: {total_allocated}");
    println!("  Inodes with data      : {total_with_data}");
    println!("  Total extents         : {total_extents}");
    println!("  Avg extents per inode : {avg_str}");
    println!(
        "  Fragmented inodes     : {} (of {} with data)",
        fragmented.len(),
        total_with_data
    );
    if let Some(worst) = fragmented.first() {
        println!(
            "  Worst offender        : inode {} (ext: {}, ideal: {})",
            worst.ino, worst.extents, worst.ideal
        );
    } else {
        println!("  Worst offender        : none");
    }
    if walk_errors > 0 {
        println!("  Walk errors (skipped) : {walk_errors}");
    }

    match mode {
        Mode::Summary => {
            println!();
            println!("  Top 5 most-fragmented inodes:");
            if fragmented.is_empty() {
                println!("    (none)");
            } else {
                for r in fragmented.iter().take(5) {
                    println!(
                        "    inode {}: {} extents (size {} bytes)",
                        r.ino, r.extents, r.size
                    );
                }
            }
        }
        Mode::Verbose => {
            println!();
            if fragmented.is_empty() {
                println!("  (no fragmented inodes)");
            } else {
                for r in &fragmented {
                    let ratio = r.extents as f64 / r.ideal as f64;
                    println!(
                        "  inode {}: size={} extents={} ideal={} ratio={:.2}",
                        r.ino, r.size, r.extents, r.ideal, ratio
                    );
                }
            }
        }
    }

    ExitCode::from(0)
}

/// `read_inode` on a never-allocated slot typically returns a
/// zeroed struct. Anvil's convention (matches upstream) is that
/// `i_mode == 0 && i_links_count == 0` means the slot is free;
/// either of those being nonzero means the inode was allocated.
fn is_allocated(ino: &Inode) -> bool {
    ino.i_mode != 0 && ino.i_links_count != 0
}

/// Skip inode types that never own data extents — character
/// devices, block devices, fifos, and sockets all store their
/// identity in i_block directly. Symlinks and regular files and
/// directories are all walkable.
fn eligible_for_fragmentation(ino: &Inode) -> bool {
    let kind = ino.i_mode & S_IFMT;
    !matches!(kind, S_IFBLK | S_IFCHR | S_IFIFO | S_IFSOCK)
}
