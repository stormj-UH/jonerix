//! `-E fragcheck` post-pass reporter.
//!
//! Pass 1 records per-inode extent counts and discontiguous-run
//! counts into `cx.frag_stats` while it is already walking every
//! extent tree. After the normal pass chain finishes, main.rs
//! calls into here to print a compact per-inode report listing
//! the notably fragmented files (>4 extents or >1 discontiguous
//! run). Read-only: this path never queues a fix and never
//! influences the exit code.

use crate::ctx::Ctx;

pub fn run(cx: &mut Ctx) {
    if cx.frag_stats.is_empty() {
        return;
    }

    // Sort by extent count descending, then by discontig desc,
    // then by inode ascending so the output is deterministic.
    cx.frag_stats
        .sort_by(|a, b| b.1.cmp(&a.1).then(b.2.cmp(&a.2)).then(a.0.cmp(&b.0)));

    println!("Fragmentation report:");
    for (ino, extents, discontig, size) in &cx.frag_stats {
        println!(
            "  inode {ino}: {extents} extents, {discontig} discontiguous, size {size}"
        );
    }
}
