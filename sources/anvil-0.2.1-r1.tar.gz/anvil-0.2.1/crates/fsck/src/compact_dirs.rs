//! Pass 3A — `-D` directory compaction.
//!
//! Linear-dir shrink: for each non-htree directory we walk its
//! data blocks and rewrite each one so live entries are packed
//! at the start and the final entry's rec_len extends to end of
//! block (minus 12 when metadata_csum is in play, leaving room
//! for the ext4_dir_entry_tail). Tombstones (inode == 0) are
//! dropped.
//!
//! Htree dirs are *flattened* into linear form: we walk every
//! leaf, collect every live (inode, name, file_type), clear
//! EXT4_INDEX_FL, then re-stamp the dir's existing data blocks
//! as a plain linear dir (block 0 starts with "." / ".."). Any
//! trailing blocks that end up with no entries are left in place
//! as empty slots (single dirent with inode=0 covering the whole
//! usable block) — we don't bother freeing them. Only
//! single-level htrees (indirect_levels == 0) are handled;
//! deeper trees emit a skip message. Directories with more
//! than 1000 entries also bail — the in-place rewrite scope
//! doesn't cover allocating fresh data blocks for a case that
//! doesn't fit in N existing blocks.
//!
//! Gate: only runs when the user asked for `-D` *and* we're in
//! a write mode (`-y` or `-p`). The pass is idempotent: a
//! second run over an already-coalesced block is a no-op.

use crate::ctx::Ctx;
use anvil_core::crc::crc32c_cont;
use anvil_core::extent;
use anvil_core::fs::csum_seed_for;
use std::io;
use std::io::Write;

const EXT4_INDEX_FL: u32 = 0x0000_1000;

pub fn run(cx: &mut Ctx) -> io::Result<()> {
    if !cx.opts.preen {
        println!("Pass 3A: Optimizing directories");
    }

    let block_size = cx.fs.block_size as usize;
    let total_inodes = cx.fs.total_inodes() as usize;

    for ino in 1..=total_inodes as u32 {
        if !cx.inode_is_dir.get(ino as usize) { continue; }
        if !cx.inode_in_use.get(ino as usize) { continue; }

        let inode = match cx.fs.read_inode(ino) {
            Ok(i) => i,
            Err(_) => continue,
        };

        if inode.i_flags & EXT4_INDEX_FL != 0 {
            match flatten_htree(cx, ino) {
                Ok(FlattenResult::Flattened { entries }) => {
                    if cx.opts.verbose {
                        println!(
                            "Flattening htree dir inode {ino} ({entries} entries)"
                        );
                    }
                }
                Ok(FlattenResult::SkippedDeep { levels }) => {
                    if cx.opts.verbose {
                        println!(
                            "Skipping deep htree dir inode {ino} (levels > 0: {levels})"
                        );
                    }
                }
                Ok(FlattenResult::SkippedTooLarge { entries }) => {
                    if cx.opts.verbose {
                        println!(
                            "Directory inode {ino} too large for in-place flatten ({entries} entries), skipping"
                        );
                    }
                }
                Ok(FlattenResult::SkippedEmpty) => {
                    if cx.opts.verbose {
                        println!(
                            "Skipping htree dir inode {ino} (no leaf blocks)"
                        );
                    }
                }
                Err(_) => {
                    // I/O error mid-rewrite: leave the dir in
                    // whatever state the last successful write
                    // left it, and keep processing the rest.
                    if cx.opts.verbose {
                        println!(
                            "Skipping htree dir inode {ino} (rewrite error)"
                        );
                    }
                }
            }
            continue;
        }

        // Gather data blocks (dir data has no holes).
        let mut blocks: Vec<u64> = Vec::new();
        let _ = extent::walk_extents(&mut cx.fs, &inode, |run| {
            for off in 0..run.length as u64 {
                blocks.push(run.physical + off);
            }
        });

        if blocks.is_empty() { continue; }

        let generation = inode.i_generation;
        let has_csum = cx.fs.has_metadata_csum();
        let seed = csum_seed_for(&cx.fs.sb);

        let mut total_compacted: u32 = 0;
        let mut buf = vec![0u8; block_size];

        for &blk in &blocks {
            if cx.fs.read_block(blk, &mut buf).is_err() { continue; }
            let (new_buf, dropped) = match coalesce_block(&buf, block_size, has_csum) {
                Some(v) => v,
                None => continue,
            };
            total_compacted += dropped;

            // Stamp tail csum when metadata_csum is enabled.
            let mut out = new_buf;
            if has_csum {
                stamp_tail_csum(&mut out, block_size, ino, generation, seed);
            }
            let byte_off = blk * cx.fs.block_size;
            cx.fs.dev.write_at(byte_off, &out)?;
        }

        if cx.opts.verbose && total_compacted > 0 {
            println!("Optimizing dir inode {ino} ({total_compacted} entries compacted)");
        }

        // Bump parent's mtime/ctime (best-effort: if write fails
        // the directory is still correct on-disk, just stale).
        let _ = bump_inode_times(cx, ino);
    }

    // Flush stdout so banner + per-dir lines appear before any
    // later summary writes.
    let _ = std::io::stdout().flush();
    Ok(())
}

/// Outcome of a flatten_htree attempt. Callers use this to drive
/// the right verbose message; none of the skip variants are
/// treated as errors.
enum FlattenResult {
    Flattened      { entries: u32 },
    SkippedDeep    { levels:  u8  },
    SkippedTooLarge{ entries: u32 },
    SkippedEmpty,
}

/// Cap on how many entries we'll flatten in a single pass.
/// Rewriting N blocks in place without touching the bitmap /
/// GDT means we can only fit as many entries as already-allocated
/// blocks hold. For a 4k filesystem 1000 entries easily fits in
/// 3-4 blocks even with long names, so this bound is well under
/// any real risk of running out of room. Beyond that we bail —
/// a full rebuild would need to allocate fresh blocks, which is
/// out of scope here.
const FLATTEN_ENTRY_CAP: usize = 1000;

/// Flatten an htree-indexed directory to linear form, in place,
/// reusing the directory's existing data blocks.
///
/// The dx_root in block 0 is being discarded, so its hash-cache
/// csum is irrelevant. We do, however, preserve the "." and
/// ".." entries that live at the start of block 0 — those are
/// structurally required in every ext4 directory.
///
/// On success clears EXT4_INDEX_FL on the inode and re-stamps
/// the inode csum (plus per-block tail csums when
/// metadata_csum is enabled).
fn flatten_htree(cx: &mut Ctx, ino_num: u32) -> io::Result<FlattenResult> {
    let inode = cx.fs.read_inode(ino_num)?;
    let block_size = cx.fs.block_size as usize;
    let has_csum = cx.fs.has_metadata_csum();

    // 1. Resolve logical→physical blocks.
    let mut blocks: Vec<u64> = Vec::new();
    extent::walk_extents(&mut cx.fs, &inode, |run| {
        for off in 0..run.length as u64 {
            blocks.push(run.physical + off);
        }
    })?;
    if blocks.is_empty() {
        return Ok(FlattenResult::SkippedEmpty);
    }

    // 2. Parse dx_root in logical block 0. Layout (matches
    //    ext4_dx_root): bytes 0..24 are the synthetic "." /
    //    ".." dirents, 24..32 is dx_root_info, 32..40 is the
    //    dx_countlimit, then dx_entries follow at 8-byte
    //    stride.
    let mut root = vec![0u8; block_size];
    cx.fs.read_block(blocks[0], &mut root)?;
    if root.len() < 40 {
        return Ok(FlattenResult::SkippedEmpty);
    }
    let ilev = root[30];
    if ilev != 0 {
        return Ok(FlattenResult::SkippedDeep { levels: ilev });
    }

    let limit = u16::from_le_bytes([root[32], root[33]]) as usize;
    let count = u16::from_le_bytes([root[34], root[35]]) as usize;
    if count == 0 || count > limit {
        return Ok(FlattenResult::SkippedEmpty);
    }

    // Leaf block pointers: entry[0] lives in the countlimit
    // slot (block ptr at offset 36), entry[i] at 32 + i*8 + 4.
    let mut leaf_lblks: Vec<u32> = Vec::with_capacity(count);
    for i in 0..count {
        let off = 32 + i * 8 + 4;
        if off + 4 > root.len() { break; }
        let b = u32::from_le_bytes([
            root[off], root[off+1], root[off+2], root[off+3],
        ]);
        leaf_lblks.push(b);
    }

    // 3. Recover "." and ".." from the dx_root's first two
    //    dir-slots. These are regular dir entries sized at
    //    12 bytes each and must land in the flattened block 0.
    let dot_inode = u32::from_le_bytes([root[0], root[1], root[2], root[3]]);
    let dot_rec   = u16::from_le_bytes([root[4], root[5]]);
    let dot_nl    = root[6] as usize;
    let dot_ft    = root[7];
    let dotdot_off = 12usize;
    let dotdot_inode = u32::from_le_bytes([
        root[dotdot_off],   root[dotdot_off+1],
        root[dotdot_off+2], root[dotdot_off+3],
    ]);
    let dotdot_nl = root[dotdot_off+6] as usize;
    let dotdot_ft = root[dotdot_off+7];
    if dot_inode == 0 || dot_rec < 12 || dot_nl != 1 || root[8] != b'.'
        || dotdot_inode == 0 || dotdot_nl != 2
        || root[dotdot_off+8] != b'.' || root[dotdot_off+9] != b'.'
    {
        // Malformed dx_root; let pass 2 handle it.
        return Ok(FlattenResult::SkippedEmpty);
    }

    // 4. Walk every leaf block and collect live entries.
    #[derive(Clone)]
    struct Entry {
        inode:     u32,
        file_type: u8,
        name:      Vec<u8>,
    }
    let mut live: Vec<Entry> = Vec::new();
    let leaf_scan_end = if has_csum { block_size - 12 } else { block_size };

    for &lblk in &leaf_lblks {
        if (lblk as usize) >= blocks.len() { continue; }
        let phys = blocks[lblk as usize];
        let mut lbuf = vec![0u8; block_size];
        if cx.fs.read_block(phys, &mut lbuf).is_err() { continue; }
        let mut off = 0usize;
        while off + 8 <= leaf_scan_end {
            let ino_e = u32::from_le_bytes([
                lbuf[off], lbuf[off+1], lbuf[off+2], lbuf[off+3]]);
            let rec_len = u16::from_le_bytes([lbuf[off+4], lbuf[off+5]]) as usize;
            let name_len = lbuf[off+6] as usize;
            let ft = lbuf[off+7];
            if rec_len < 8 || off + rec_len > block_size || (rec_len & 3) != 0 {
                break;
            }
            // tail marker: inode=0, rec_len=12, ft=0xDE.
            if ino_e == 0 && rec_len == 12 && name_len == 0 && ft == 0xDE {
                break;
            }
            if ino_e != 0
                && name_len > 0
                && off + 8 + name_len <= block_size
            {
                let name = lbuf[off+8 .. off+8+name_len].to_vec();
                // Leaf blocks never contain "." / ".." — but
                // filter just in case of oddly-shaped trees so
                // we don't duplicate them.
                if name != b"." && name != b".." {
                    live.push(Entry { inode: ino_e, file_type: ft, name });
                    if live.len() > FLATTEN_ENTRY_CAP {
                        return Ok(FlattenResult::SkippedTooLarge {
                            entries: live.len() as u32,
                        });
                    }
                }
            }
            off += rec_len;
        }
    }

    // 5. Build the flattened block layout. Block 0 starts with
    //    "." (rec_len=12) + ".." (rec_len=12), then entries
    //    pack after. Subsequent blocks start fresh with entries.
    //    An "end-of-block" sentinel entry absorbs remaining
    //    space per block so walkers stop at the block boundary.
    let aligned = |nl: usize| -> usize { (8 + nl + 3) & !3 };
    let end = leaf_scan_end;

    // Plan each block: Vec<Vec<Entry>> — entries assigned to
    // each physical block. Tracks how many entries still need
    // to fit; if we run out of blocks, bail.
    let mut plan: Vec<Vec<Entry>> = vec![Vec::new(); blocks.len()];
    // Block 0 budget starts at end - 24 (for "." + ".." at 12
    // bytes each). Subsequent blocks get the full `end`.
    let mut budget: Vec<usize> = Vec::with_capacity(blocks.len());
    for bi in 0..blocks.len() {
        budget.push(if bi == 0 { end.saturating_sub(24) } else { end });
    }
    let mut cur_blk = 0usize;
    for e in live.iter().cloned() {
        let need = aligned(e.name.len());
        loop {
            if cur_blk >= plan.len() {
                return Ok(FlattenResult::SkippedTooLarge {
                    entries: live.len() as u32,
                });
            }
            if budget[cur_blk] >= need {
                budget[cur_blk] -= need;
                plan[cur_blk].push(e);
                break;
            }
            cur_blk += 1;
        }
    }

    // 6. Serialize each block and write it.
    let generation = inode.i_generation;
    let seed = csum_seed_for(&cx.fs.sb);

    for (bi, &phys) in blocks.iter().enumerate() {
        let mut out = vec![0u8; block_size];
        let mut cursor = 0usize;

        // Block 0: emit "." and ".." fixed 12-byte slots.
        if bi == 0 {
            // "."
            out[0..4].copy_from_slice(&dot_inode.to_le_bytes());
            out[4..6].copy_from_slice(&12u16.to_le_bytes());
            out[6] = 1;
            out[7] = dot_ft;
            out[8] = b'.';
            // ".."
            out[12..16].copy_from_slice(&dotdot_inode.to_le_bytes());
            out[16..18].copy_from_slice(&12u16.to_le_bytes());
            out[18] = 2;
            out[19] = dotdot_ft;
            out[20] = b'.';
            out[21] = b'.';
            cursor = 24;
        }

        let entries = &plan[bi];
        if entries.is_empty() {
            // No real entries in this block. Emit a single empty
            // slot (inode=0) covering the usable area. On
            // block 0 that slot starts right after "..".
            if bi == 0 {
                // "." / ".." already placed. Extend "..".rec_len
                // to end so a walker sees one slot after ".".
                let ddlen = (end - 12) as u16;
                out[16..18].copy_from_slice(&ddlen.to_le_bytes());
            } else {
                // Empty tail block: single inode=0 slot.
                out[0..4].copy_from_slice(&0u32.to_le_bytes());
                out[4..6].copy_from_slice(&(end as u16).to_le_bytes());
                out[6] = 0;
                out[7] = 0;
            }
        } else {
            let n = entries.len();
            for (i, e) in entries.iter().enumerate() {
                let min_len = aligned(e.name.len());
                let is_last = i + 1 == n;
                let rec_len = if is_last {
                    // Last entry in block: stretch to `end`.
                    end - cursor
                } else {
                    min_len
                };
                out[cursor..cursor+4].copy_from_slice(&e.inode.to_le_bytes());
                out[cursor+4..cursor+6]
                    .copy_from_slice(&(rec_len as u16).to_le_bytes());
                out[cursor+6] = e.name.len() as u8;
                out[cursor+7] = e.file_type;
                out[cursor+8..cursor+8+e.name.len()].copy_from_slice(&e.name);
                cursor += rec_len;
            }
        }

        if has_csum {
            stamp_tail_csum(&mut out, block_size, ino_num, generation, seed);
        }
        let byte_off = phys * cx.fs.block_size;
        cx.fs.dev.write_at(byte_off, &out)?;
    }

    // 7. Clear EXT4_INDEX_FL and re-stamp the inode csum.
    clear_index_flag_and_restamp(cx, ino_num)?;

    Ok(FlattenResult::Flattened { entries: live.len() as u32 })
}

/// Clear EXT4_INDEX_FL on an inode and refresh its checksum +
/// mtime/ctime. Reads / writes the raw inode slot so we don't
/// lose any trailing inline-xattr bytes past the base struct.
fn clear_index_flag_and_restamp(cx: &mut Ctx, ino_num: u32) -> io::Result<()> {
    use anvil_core::fs::compute_inode_csum;

    if ino_num == 0 || ino_num as u64 > cx.fs.sb.s_inodes_count as u64 {
        return Ok(());
    }
    let group = (ino_num as u64 - 1) / cx.fs.inodes_per_group;
    let idx   = (ino_num as u64 - 1) % cx.fs.inodes_per_group;
    let table = cx.fs.group_inode_table(group);
    let byte  = table * cx.fs.block_size + idx * cx.fs.inode_size;
    let mut ibuf = vec![0u8; cx.fs.inode_size as usize];
    cx.fs.dev.read_at(byte, &mut ibuf)?;

    // i_flags @ 0x20
    let mut flags = u32::from_le_bytes(ibuf[0x20..0x24].try_into().unwrap());
    flags &= !EXT4_INDEX_FL;
    ibuf[0x20..0x24].copy_from_slice(&flags.to_le_bytes());

    let now = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_secs() as u32)
        .unwrap_or(0);
    ibuf[0x0C..0x10].copy_from_slice(&now.to_le_bytes());
    ibuf[0x10..0x14].copy_from_slice(&now.to_le_bytes());

    if cx.fs.has_metadata_csum() {
        let generation = u32::from_le_bytes(ibuf[0x64..0x68].try_into().unwrap());
        let extra_isize = if ibuf.len() >= 0x82 {
            u16::from_le_bytes(ibuf[0x80..0x82].try_into().unwrap())
        } else { 0 };
        if ibuf.len() >= 0x7E {
            ibuf[0x7C..0x7E].copy_from_slice(&0u16.to_le_bytes());
        }
        let has_hi = extra_isize >= 4 && ibuf.len() >= 0x84;
        if has_hi {
            ibuf[0x82..0x84].copy_from_slice(&0u16.to_le_bytes());
        }
        let csum = compute_inode_csum(&cx.fs.sb, ino_num, generation, &ibuf);
        if ibuf.len() >= 0x7E {
            ibuf[0x7C..0x7E].copy_from_slice(&(csum as u16).to_le_bytes());
        }
        if has_hi {
            ibuf[0x82..0x84].copy_from_slice(&((csum >> 16) as u16).to_le_bytes());
        }
    }
    cx.fs.dev.write_at(byte, &ibuf)?;
    Ok(())
}

/// Walk dir entries in `buf` (a single dir block). Return the
/// rewritten block plus the number of dropped (tombstoned)
/// entries. Return None if the block is empty / unparseable —
/// caller leaves it alone.
///
/// Drops:
///   * inode==0 slots (tombstones)
///   * trailing ext4_dir_entry_tail marker (inode=0, rec_len=12,
///     file_type=0xDE) — we'll re-stamp it
///
/// Result layout:
///   live entries packed, each entry's rec_len = 8+align4(name_len)
///   except the last, whose rec_len stretches to end-of-block
///   (minus 12 if metadata_csum is on — tail marker will be
///   stamped by the caller).
fn coalesce_block(
    buf: &[u8],
    block_size: usize,
    has_csum: bool,
) -> Option<(Vec<u8>, u32)> {
    let end = if has_csum { block_size - 12 } else { block_size };

    // Parse entries in order.
    #[derive(Clone)]
    struct Entry {
        inode:     u32,
        file_type: u8,
        name:      Vec<u8>,
    }
    let mut live: Vec<Entry> = Vec::new();
    let mut off = 0usize;
    let mut dropped: u32 = 0;
    while off + 8 <= block_size {
        let inode = u32::from_le_bytes([buf[off], buf[off+1], buf[off+2], buf[off+3]]);
        let rec_len = u16::from_le_bytes([buf[off+4], buf[off+5]]) as usize;
        let name_len = buf[off+6] as usize;
        let file_type = buf[off+7];
        if rec_len < 8 || off + rec_len > block_size || (rec_len & 3) != 0 {
            return None;
        }
        // Tail marker detection — skip & stop (it lives at end).
        if inode == 0 && rec_len == 12 && name_len == 0 && file_type == 0xDE
            && off + rec_len == block_size
        {
            break;
        }
        if inode == 0 {
            // Tombstone — drop.
            dropped += 1;
        } else if off + 8 + name_len <= block_size && name_len > 0 {
            let name = buf[off+8..off+8+name_len].to_vec();
            live.push(Entry { inode, file_type, name });
        }
        off += rec_len;
    }

    if live.is_empty() {
        return None;
    }

    // Build packed entries. Compute rec_lens:
    //   each entry except last: 8 + align4(name_len)
    //   last entry: extends to `end`
    let aligned = |nl: usize| -> usize { (8 + nl + 3) & !3 };

    let total_min: usize = live.iter().map(|e| aligned(e.name.len())).sum();
    if total_min > end {
        // Shouldn't happen — more live data than fits. Bail and
        // leave block untouched.
        return None;
    }

    // If the resulting layout is byte-identical to the input
    // (including the trailing padding on the last entry), we
    // can skip the write.
    let mut out = vec![0u8; block_size];
    let mut cursor = 0usize;
    for (i, e) in live.iter().enumerate() {
        let min_len = aligned(e.name.len());
        let rec_len = if i + 1 == live.len() {
            end - cursor
        } else {
            min_len
        };
        out[cursor..cursor+4].copy_from_slice(&e.inode.to_le_bytes());
        out[cursor+4..cursor+6].copy_from_slice(&(rec_len as u16).to_le_bytes());
        out[cursor+6] = e.name.len() as u8;
        out[cursor+7] = e.file_type;
        out[cursor+8..cursor+8+e.name.len()].copy_from_slice(&e.name);
        // Remaining bytes of rec_len left at zero.
        cursor += rec_len;
    }

    // If nothing changed and no tombstones dropped, signal a
    // skip (caller returns None path handled via dropped==0 +
    // equal buffers). Simpler: always write, checksum restamp
    // is cheap and idempotent.
    if dropped == 0 && out[..end] == buf[..end] {
        return None;
    }
    Some((out, dropped))
}

/// Rewrite the 12-byte ext4_dir_entry_tail at end of `out`.
fn stamp_tail_csum(
    out: &mut [u8],
    block_size: usize,
    ino_num: u32,
    generation: u32,
    seed: u32,
) {
    let tail_off = block_size - 12;
    // marker
    out[tail_off..tail_off+4].copy_from_slice(&0u32.to_le_bytes());
    out[tail_off+4..tail_off+6].copy_from_slice(&12u16.to_le_bytes());
    out[tail_off+6] = 0;
    out[tail_off+7] = 0xDE;
    // zero csum word for CRC input
    out[tail_off+8..tail_off+12].copy_from_slice(&0u32.to_le_bytes());
    let s1 = crc32c_cont(seed, &ino_num.to_le_bytes());
    let s2 = crc32c_cont(s1, &generation.to_le_bytes());
    let csum = crc32c_cont(s2, &out[..block_size - 12]);
    out[tail_off+8..tail_off+12].copy_from_slice(&csum.to_le_bytes());
}

/// Bump i_mtime and i_ctime on the parent directory inode to
/// now. Re-stamps the inode csum via patch_inode_slot's hidden
/// path: we have to do it manually since that helper is private
/// to ctx.rs. Inline the pieces we need.
fn bump_inode_times(cx: &mut Ctx, ino_num: u32) -> io::Result<()> {
    use anvil_core::fs::compute_inode_csum;

    if ino_num == 0 || ino_num as u64 > cx.fs.sb.s_inodes_count as u64 {
        return Ok(());
    }
    let group = (ino_num as u64 - 1) / cx.fs.inodes_per_group;
    let idx   = (ino_num as u64 - 1) % cx.fs.inodes_per_group;
    let table = cx.fs.group_inode_table(group);
    let byte  = table * cx.fs.block_size + idx * cx.fs.inode_size;
    let mut ibuf = vec![0u8; cx.fs.inode_size as usize];
    cx.fs.dev.read_at(byte, &mut ibuf)?;

    let now = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_secs() as u32)
        .unwrap_or(0);
    // i_ctime @ 0x10, i_mtime @ 0x10 + 8? Actually ext4 inode:
    //   i_atime @ 0x08, i_ctime @ 0x0C, i_mtime @ 0x10, i_dtime @ 0x14
    ibuf[0x0C..0x10].copy_from_slice(&now.to_le_bytes());
    ibuf[0x10..0x14].copy_from_slice(&now.to_le_bytes());

    if cx.fs.has_metadata_csum() {
        let generation = u32::from_le_bytes(ibuf[0x64..0x68].try_into().unwrap());
        let extra_isize = if ibuf.len() >= 0x82 {
            u16::from_le_bytes(ibuf[0x80..0x82].try_into().unwrap())
        } else { 0 };
        if ibuf.len() >= 0x7E {
            ibuf[0x7C..0x7E].copy_from_slice(&0u16.to_le_bytes());
        }
        let has_hi = extra_isize >= 4 && ibuf.len() >= 0x84;
        if has_hi {
            ibuf[0x82..0x84].copy_from_slice(&0u16.to_le_bytes());
        }
        let csum = compute_inode_csum(&cx.fs.sb, ino_num, generation, &ibuf);
        if ibuf.len() >= 0x7E {
            ibuf[0x7C..0x7E].copy_from_slice(&(csum as u16).to_le_bytes());
        }
        if has_hi {
            ibuf[0x82..0x84].copy_from_slice(&((csum >> 16) as u16).to_le_bytes());
        }
    }
    cx.fs.dev.write_at(byte, &ibuf)?;
    Ok(())
}
