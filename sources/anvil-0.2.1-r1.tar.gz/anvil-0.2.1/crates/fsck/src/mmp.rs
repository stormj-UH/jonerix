//! MMP (Multiple-Mount Protection) detection.
//!
//! When `EXT4_FEATURE_INCOMPAT_MMP` is set, the superblock names
//! a block holding an `ext4_mmp` record. The `mmp_seq` field
//! lets a second mounter (or fsck) see that the filesystem is
//! already in use and refuse rather than corrupt it.
//!
//! Layout/values per the public ext4 on-disk format docs; no
//! e2fsprogs code consulted.

use anvil_core::consts::{
    EXT4_MMP_MAGIC, EXT4_MMP_SEQ_CLEAN, EXT4_MMP_SEQ_FSCK, EXT4_MMP_SEQ_MAX,
};
use anvil_core::fs::Fs;

/// Result of the MMP pre-check.
pub enum MmpDecision {
    /// MMP not enabled, or seq says cleanly unmounted.
    Proceed,
    /// MMP block was unreadable or had a bad magic. Treated as
    /// non-blocking — printed as a warning, fsck continues.
    Corrupt,
    /// Stale fsck sequence — warn but proceed.
    StaleFsck,
    /// Filesystem appears to be in active use; refuse.
    Refuse(String),
}

/// Inspect the MMP block (if the feature is set) and decide
/// whether fsck may continue. Reads the block at
/// `sb.s_mmp_block` of size `fs.block_size` and parses the
/// fixed-prefix fields documented in ext4_mmp (1024-byte
/// record). Larger block sizes simply leave the trailing bytes
/// unused.
pub fn check(fs: &mut Fs) -> MmpDecision {
    use anvil_core::consts::EXT4_FEATURE_INCOMPAT_MMP;
    let feat_incompat = fs.sb.s_feature_incompat;
    if feat_incompat & EXT4_FEATURE_INCOMPAT_MMP == 0 {
        return MmpDecision::Proceed;
    }

    let mmp_block = fs.sb.s_mmp_block;
    if mmp_block == 0 {
        // MMP feature claimed but no block pointer — corrupt
        // header. Treat like bad magic: warn, do not block.
        return MmpDecision::Corrupt;
    }

    let block_size = fs.block_size;
    let offset = mmp_block.saturating_mul(block_size);
    let mut buf = vec![0u8; block_size as usize];
    if fs.dev.read_at(offset, &mut buf).is_err() {
        return MmpDecision::Corrupt;
    }

    // Parse fixed-offset fields. Everything is little-endian.
    let magic = u32::from_le_bytes(buf[0..4].try_into().unwrap());
    let seq   = u32::from_le_bytes(buf[4..8].try_into().unwrap());

    if magic != EXT4_MMP_MAGIC {
        return MmpDecision::Corrupt;
    }

    // Nodename is a NUL-padded ASCII byte string at offset 16,
    // 64 bytes wide. Trim at the first NUL for display.
    let node_end = buf[16..16 + 64]
        .iter()
        .position(|&b| b == 0)
        .unwrap_or(64);
    let nodename = String::from_utf8_lossy(&buf[16..16 + node_end]).into_owned();

    match seq {
        EXT4_MMP_SEQ_CLEAN => MmpDecision::Proceed,
        EXT4_MMP_SEQ_FSCK  => MmpDecision::StaleFsck,
        s if s == EXT4_MMP_SEQ_MAX => {
            let host = if nodename.is_empty() { "<unknown>".into() } else { nodename };
            MmpDecision::Refuse(format!(
                "MMP: filesystem appears to be in use (mounted on {host}); refusing to check"
            ))
        }
        _ => MmpDecision::Refuse(
            "MMP: filesystem is mounted; refusing to check".to_string(),
        ),
    }
}
