//! Pass 3 — Checking directory connectivity.
//!
//! Every directory must be reachable from the root. Orphan
//! directories would end up in lost+found during a real repair
//! pass; here we just report them.

use crate::ctx::Ctx;
use std::io;

pub fn run(cx: &mut Ctx) -> io::Result<()> {
    if !cx.opts.preen { println!("Pass 3: Checking directory connectivity"); }

    let total = cx.fs.total_inodes() as usize;
    for ino in 1..=total {
        if !cx.inode_is_dir.get(ino)    { continue; }
        if !cx.inode_in_use.get(ino)    { continue; }
        if cx.inode_reached.get(ino)    { continue; }
        cx.err(format!("Directory inode {ino} unconnected from root"));
    }
    Ok(())
}
