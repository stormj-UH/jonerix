//! Pass 2 — Checking directory structure.
//!
//! Walk each directory inode, read each dir entry, verify:
//!   * rec_len is ≥ 8 and doesn't run past the block
//!   * name_len matches the visible slot length
//!   * inode number is in range
//!   * "." and ".." point at the right inodes
//!
//! Every destination inode has its `inode_reached` bit set so pass 4
//! can tell orphans from the rest.

use crate::ctx::Ctx;
use anvil_core::consts::*;
use anvil_core::dir::DirEntryHead;
use anvil_core::extent;
use std::io;

pub fn run(cx: &mut Ctx) -> io::Result<()> {
    if !cx.opts.preen { println!("Pass 2: Checking directory structure"); }

    let block_size = cx.fs.block_size as usize;
    let total_inodes = cx.fs.total_inodes() as usize;

    // Pre-mark the root as "reached by itself" so pass 4 doesn't
    // treat it as an orphan.
    cx.inode_reached.set(EXT4_ROOT_INO as usize);

    for ino in 1..=total_inodes as u32 {
        if !cx.inode_is_dir.get(ino as usize) { continue; }
        if !cx.inode_in_use.get(ino as usize) { continue; }
        walk_dir_inode(cx, ino, block_size)?;
    }
    Ok(())
}

fn walk_dir_inode(cx: &mut Ctx, ino_num: u32, block_size: usize) -> io::Result<()> {
    let inode = cx.fs.read_inode(ino_num)?;
    // For directory inodes the logical block sequence must be
    // contiguous starting at 0 — ext4 disallows holes in dir
    // data. Track the highest logical block we've seen and, if
    // a later extent jumps past that + its length, report the
    // gap (f_holedir / f_holedir2).
    let mut blocks: Vec<u64> = Vec::new();
    let mut expected_logical: u32 = 0;
    let mut hole_reported = false;
    extent::walk_extents(&mut cx.fs, &inode, |run| {
        if !hole_reported && run.logical > expected_logical {
            hole_reported = true;
        }
        expected_logical = run.logical + run.length as u32;
        for off in 0..run.length as u64 {
            blocks.push(run.physical + off);
        }
    })?;
    if hole_reported {
        cx.err(format!("Inode {ino_num}: directory has a hole in its block map"));
    }

    // Collect every name once so we can flag duplicates. We could
    // build a hash per-block, but dirs are generally tiny —
    // O(n²) across all blocks is fine and lets us catch
    // cross-block duplicates as well.
    let mut seen_names: std::collections::HashSet<Vec<u8>> = Default::default();
    let mut dot_count = 0u32;
    let mut dotdot_count = 0u32;

    let generation = inode.i_generation;
    // Casefolded directory: duplicate detection compares names
    // under the ASCII fold. See anvil_core::casefold for scope.
    let casefolded = inode.i_flags & EXT4_CASEFOLD_FL != 0;
    // HTree indexed directory: when EXT4_INDEX_FL is set, the
    // first block is a dx_root with a specific layout. A few
    // cheap invariants catch f_h_badroot / f_h_reindex without
    // having to re-hash the whole tree.
    const EXT4_INDEX_FL: u32 = 0x00001000;
    if inode.i_flags & EXT4_INDEX_FL != 0 && !blocks.is_empty() {
        let mut buf = vec![0u8; block_size];
        cx.fs.read_block(blocks[0], &mut buf)?;
        // After the synthetic "." and ".." entries (24 bytes) the
        // dx_root_info struct lives: reserved_zero (u32) +
        // hash_version (u8) + info_length (u8) +
        // indirect_levels (u8) + unused_flags (u8).
        if buf.len() >= 32 {
            let rz = u32::from_le_bytes([buf[24], buf[25], buf[26], buf[27]]);
            let hv = buf[28];
            let info_len = buf[29];
            let ilev = buf[30];
            if rz != 0 {
                cx.err(format!(
                    "HTREE directory inode {ino_num}: dx_root reserved_zero nonzero ({rz:#x})"));
            }
            if hv > 6 {
                cx.err(format!(
                    "HTREE directory inode {ino_num}: unknown hash_version {hv}"));
            }
            if info_len != 8 {
                cx.err(format!(
                    "HTREE directory inode {ino_num}: info_length {info_len} != 8 (invalid root node)"));
            }
            if ilev > 2 {
                cx.err(format!(
                    "HTREE directory inode {ino_num}: indirect_levels {ilev} > 2"));
            }
            // dx_entries[0] overlaps the dx_countlimit: its first
            // 4 bytes are { limit: u16, count: u16 } and the
            // next 4 bytes are the first-block pointer. Real
            // entries (with hash values) start at entries[1] =
            // offset 40. Entries must be strictly hash-sorted.
            let limit = u16::from_le_bytes([buf[32], buf[33]]) as usize;
            let count = u16::from_le_bytes([buf[34], buf[35]]) as usize;
            if count == 0 || count > limit {
                cx.err(format!(
                    "HTREE directory inode {ino_num}: dx_root count={count} / limit={limit}"));
            } else {
                let mut prev_hash: Option<u32> = None;
                for i in 1..count {
                    let off = 32 + i * 8;
                    if off + 8 > buf.len() { break; }
                    let h = u32::from_le_bytes([buf[off], buf[off+1], buf[off+2], buf[off+3]]);
                    if let Some(prev) = prev_hash {
                        if h < prev {
                            cx.err(format!(
                                "HTREE directory inode {ino_num}: dx entries out of hash order (entry {i} hash {h:#x} < prev {prev:#x})"));
                            break;
                        }
                    }
                    prev_hash = Some(h);
                }

                // --- Duplicate-block detection across the whole
                // --- htree (dx_root + every dx_node in between).
                // f_h_badnode's 'block #N referenced twice' fires
                // when two dx_entries (possibly in different
                // nodes) point at the same logical block. Also
                // collects an 'invalid depth' signal for dx_nodes
                // that shouldn't exist given ilevel.
                let mut seen_blocks: std::collections::HashSet<u32>
                    = Default::default();
                let mut reported_dup = false;
                // Helper: extract the `count` block refs from a
                // dx-node buffer. Entry[0]'s block is at offset
                // +36 (32 countlimit header + 4), entry[i]'s
                // block is at offset 32 + i*8 + 4.
                fn collect_blocks(nbuf: &[u8]) -> Vec<u32> {
                    if nbuf.len() < 40 { return Vec::new(); }
                    let nlimit = u16::from_le_bytes([nbuf[0], nbuf[1]]) as usize;
                    let ncount = u16::from_le_bytes([nbuf[2], nbuf[3]]) as usize;
                    if ncount == 0 || ncount > nlimit { return Vec::new(); }
                    let mut out = Vec::with_capacity(ncount);
                    // Entry[i] occupies bytes i*8..(i+1)*8 relative
                    // to the countlimit base. Its block field is
                    // the second u32 of that 8-byte pair, at
                    // relative offset i*8 + 4.
                    for i in 0..ncount {
                        let off = i * 8 + 4;
                        if off + 4 > nbuf.len() { break; }
                        let blk = u32::from_le_bytes([
                            nbuf[off], nbuf[off+1], nbuf[off+2], nbuf[off+3],
                        ]);
                        out.push(blk);
                    }
                    out
                }
                // Start by collecting dx_root's block refs. In
                // dx_root the countlimit starts at offset 32, so
                // "view from offset 32".
                let root_refs = collect_blocks(&buf[32..]);
                let mut queue: Vec<(u32, u8)> = Vec::new();
                for &b in &root_refs {
                    if !seen_blocks.insert(b) && !reported_dup {
                        cx.err(format!(
                            "HTREE directory inode {ino_num}: block #{b} referenced twice"));
                        reported_dup = true;
                    }
                    if ilev >= 1 {
                        queue.push((b, ilev - 1));
                    }
                }
                // Walk dx_nodes. Each logical block b is mapped
                // through `blocks` (logical → physical). Read
                // the dx_node and parse its countlimit at
                // offset +8 (after 8-byte fake dir entry header:
                // inode=0, rec_len=bs, name_len=0, ft=0).
                // Actually upstream's ext4_dx_node has an
                // 8-byte synthetic dirent followed by the
                // dx_countlimit, so parse from offset 8.
                while let Some((lblk, depth_left)) = queue.pop() {
                    if (lblk as usize) >= blocks.len() { continue; }
                    let phys = blocks[lblk as usize];
                    let mut nbuf = vec![0u8; block_size];
                    if cx.fs.read_block(phys, &mut nbuf).is_err() { continue; }
                    if nbuf.len() < 16 { continue; }
                    // dx_node's countlimit starts at offset 8
                    // (past the synthetic 8-byte dirent header).
                    let node_refs = collect_blocks(&nbuf[8..]);
                    for b in node_refs {
                        if !seen_blocks.insert(b) && !reported_dup {
                            cx.err(format!(
                                "HTREE directory inode {ino_num}: block #{b} referenced twice"));
                            reported_dup = true;
                        }
                        if depth_left > 0 {
                            queue.push((b, depth_left - 1));
                        }
                    }
                }

                // --- Hash recomputation (ilev=0 only for now).
                // For each dx_entry that directly references a
                // leaf block, pull the first real dirent name
                // from that block and recompute its hash using
                // the SB's current seed + dx_root's hash_version.
                // The result must fall inside the range
                // [entry[i].hash, entry[i+1].hash) claimed by the
                // dx_root. When the SB seed has been retroactively
                // changed (the `f_h_reindex` corruption), the
                // cached hashes stop matching and we flag the
                // first mismatch.
                //
                // Only runs on hash versions we've validated
                // against the libext2fs oracle (legacy=0, TEA=2).
                if ilev == 0 && (hv == 0 || hv == 2) {
                    let seed = cx.fs.sb.s_hash_seed;
                    let dx_entries: Vec<(u32, u32)> = (0..count).map(|i| {
                        let off = 32 + i * 8;
                        let h = u32::from_le_bytes([
                            buf[off], buf[off+1], buf[off+2], buf[off+3]]);
                        let b = u32::from_le_bytes([
                            buf[off+4], buf[off+5], buf[off+6], buf[off+7]]);
                        (h, b)
                    }).collect();
                    let mut flagged = false;
                    for (i, &(eh, eb)) in dx_entries.iter().enumerate() {
                        if flagged { break; }
                        if (eb as usize) >= blocks.len() { continue; }
                        let phys = blocks[eb as usize];
                        let mut leaf = vec![0u8; block_size];
                        if cx.fs.read_block(phys, &mut leaf).is_err() { continue; }
                        if let Some(first_name) = first_dirent_name(&leaf) {
                            let (h, _) = anvil_core::dirhash::dirhash(
                                hv, &first_name, &seed);
                            // First leaf (i=0) claims hash starting
                            // at 0 so any computed hash is "in
                            // range" on the low side. Check the
                            // upper bound against entry[i+1].hash
                            // when present.
                            let lo = eh;
                            let hi = if i + 1 < dx_entries.len() {
                                dx_entries[i+1].0
                            } else { u32::MAX };
                            if h < lo || h >= hi {
                                let disp = String::from_utf8_lossy(&first_name);
                                cx.err(format!(
                                    "HTREE directory inode {ino_num}: block #{eb} has bad hash ({h:#010x} not in [{lo:#010x}, {hi:#010x})) for entry '{disp}'"));
                                flagged = true;
                            }
                        }
                    }
                }
            }
        }
    }
    for (bi, blk) in blocks.iter().enumerate() {
        let mut buf = vec![0u8; block_size];
        cx.fs.read_block(*blk, &mut buf)?;
        // Dir tail csum (metadata_csum): fires only when the
        // block ends in the ext4_dir_entry_tail marker
        // (inode=0 / rec_len=12 / name_len=0 / file_type=0xDE).
        // Linear dir blocks without the marker skip silently —
        // that's what let clean filesystems pass previously.
        if !cx.fs.verify_dir_block_checksum(&buf, ino_num, generation) {
            cx.err(format!("Inode {ino_num}: dir block {blk} tail csum mismatch"));
        }
        walk_dir_block(cx, ino_num, bi == 0, &buf, block_size);
        // Second sweep purely to build the dup-name map.
        scan_dir_block_names(cx, ino_num, bi == 0, &buf, block_size,
                             &mut seen_names, &mut dot_count, &mut dotdot_count,
                             casefolded);
    }
    if dot_count > 1 {
        cx.err(format!("Inode {ino_num}: directory has {dot_count} '.' entries"));
    }
    if dotdot_count > 1 {
        cx.err(format!("Inode {ino_num}: directory has {dotdot_count} '..' entries"));
    }
    Ok(())
}

/// Return the name of the first real directory entry in a block,
/// skipping synthetic `.` / `..` placeholders, zero-inode deletion
/// markers, and the metadata_csum tail entry (name_len=0,
/// file_type=0xDE). Returns None if the block has no usable name.
fn first_dirent_name(buf: &[u8]) -> Option<Vec<u8>> {
    let mut off = 0usize;
    while off + 8 <= buf.len() {
        let inode = u32::from_le_bytes([buf[off], buf[off+1], buf[off+2], buf[off+3]]);
        let rec_len = u16::from_le_bytes([buf[off+4], buf[off+5]]) as usize;
        let name_len = buf[off+6] as usize;
        let file_type = buf[off+7];
        if rec_len < 8 || off + rec_len > buf.len() { return None; }
        if inode != 0 && name_len > 0 && file_type != 0xDE
           && off + 8 + name_len <= buf.len()
        {
            let name = &buf[off + 8 .. off + 8 + name_len];
            if name != b"." && name != b".." {
                return Some(name.to_vec());
            }
        }
        off += rec_len;
    }
    None
}

fn scan_dir_block_names(
    cx: &mut Ctx,
    parent: u32,
    is_first_block: bool,
    buf: &[u8],
    block_size: usize,
    seen: &mut std::collections::HashSet<Vec<u8>>,
    dot_count: &mut u32,
    dotdot_count: &mut u32,
    casefolded: bool,
) {
    let mut off = 0usize;
    while off + 8 <= buf.len() {
        let hdr: DirEntryHead = unsafe {
            core::ptr::read_unaligned(buf[off..].as_ptr() as *const DirEntryHead)
        };
        let rec_len = hdr.rec_len as usize;
        let name_len = hdr.name_len as usize;
        let entry_ino = hdr.inode;
        if rec_len < 8 || off + rec_len > block_size { break; }
        if entry_ino != 0 && 8 + name_len <= rec_len {
            let name = &buf[off + 8 .. off + 8 + name_len];
            if name == b"." { *dot_count += 1; }
            else if name == b".." { *dotdot_count += 1; }
            else {
                // Casefolded parents: duplicate detection runs
                // on the normalized (ASCII-fold) name so that
                // `Foo` and `foo` collide. The stored name stays
                // as-is on disk.
                let key = if casefolded {
                    anvil_core::casefold::normalize(name)
                } else {
                    name.to_vec()
                };
                if !seen.insert(key) {
                    let disp = String::from_utf8_lossy(name).into_owned();
                    cx.err(format!("Inode {parent}: duplicate dir entry '{disp}'"));
                }
            }
        }
        let _ = is_first_block;
        off += rec_len;
    }
}

fn walk_dir_block(cx: &mut Ctx, parent: u32, is_first_block: bool, buf: &[u8], block_size: usize) {
    // Encrypted directory: when the parent inode carries
    // EXT4_ENCRYPT_FL (0x800) and the fs has the ENCRYPT incompat
    // feature, every dirent's name_len must be >= 16 (the
    // AES-XTS block size) — upstream reports shorter entries as
    // 'Encrypted entry '...' in /X (N) is too short.'
    const EXT4_ENCRYPT_FL: u32 = 0x00000800;
    let parent_inode = cx.fs.read_inode(parent).ok();
    let parent_encrypted = parent_inode.map_or(false, |i| {
        (i.i_flags & EXT4_ENCRYPT_FL != 0)
            && (cx.fs.sb.s_feature_incompat & anvil_core::consts::EXT4_FEATURE_INCOMPAT_ENCRYPT != 0)
    });
    let mut off = 0usize;
    while off + 8 <= buf.len() {
        let hdr: DirEntryHead = unsafe {
            core::ptr::read_unaligned(buf[off..].as_ptr() as *const DirEntryHead)
        };
        // Copy packed fields into locals to avoid &packed.
        let rec_len = hdr.rec_len as usize;
        let entry_ino = hdr.inode;
        let name_len  = hdr.name_len as usize;
        if rec_len < 8 || off + rec_len > block_size {
            cx.err(format!("Inode {parent}: dir entry at offset {off} has rec_len={rec_len}"));
            break;
        }
        if entry_ino != 0 {
            if 8 + name_len > rec_len {
                cx.err(format!("Inode {parent}: dir entry at {off} name_len ({name_len}) > rec_len ({rec_len})"));
            } else {
                let name = &buf[off + 8 .. off + 8 + name_len];
                // Encrypted dirs: every name must be a multiple
                // of 16 bytes and at least 16 (AES block size).
                // Skip "." / ".." which are plaintext.
                if parent_encrypted && name != b"." && name != b".."
                    && (name_len < 16 || name_len % 16 != 0)
                {
                    let disp = String::from_utf8_lossy(name).into_owned();
                    cx.err(format!("Encrypted entry '{disp}' in inode {parent} is too short"));
                }

                // Validate "." / ".." in directory's first block,
                // first two slots. htree-indexed directories have
                // index or leaf blocks past block 0 that start
                // with arbitrary names — don't check those.
                if is_first_block && off == 0 {
                    if name != b"." {
                        cx.err(format!("Inode {parent}: first dir entry is not \".\""));
                    }
                    if entry_ino != parent {
                        cx.err(format!("Inode {parent}: \".\" points to inode {} instead of {}", entry_ino, parent));
                    }
                } else if is_first_block && off == 12 && name == b".." {
                    // parent pointer — pass 3 cross-checks it later
                }

                // Track reachability.
                if (entry_ino as usize) < cx.inode_reached.len() {
                    cx.inode_reached.set(entry_ino as usize);
                    if cx.inode_observed_links[entry_ino as usize] < u16::MAX {
                        cx.inode_observed_links[entry_ino as usize] += 1;
                    }
                    // EA inodes must stay out of the directory
                    // namespace — a dir entry pointing at one is
                    // f_ea_inode_dir_ref corruption.
                    if cx.inode_is_ea.get(entry_ino as usize) {
                        let disp = String::from_utf8_lossy(name).into_owned();
                        cx.err(format!(
                            "Entry '{disp}' in inode {parent} references EA inode {entry_ino}"));
                    }
                    // Dir entry pointing into a group's unused
                    // inodes area (past ipg - bg_itable_unused)
                    // is f_unused_itable corruption.
                    let ipg = cx.fs.inodes_per_group;
                    if ipg > 0 {
                        let group = (entry_ino as u64 - 1) / ipg;
                        let idx   = (entry_ino as u64 - 1) % ipg;
                        if (group as usize) < cx.fs.gdt.len() {
                            let d = &cx.fs.gdt[group as usize];
                            let unused_lo = d.bg_itable_unused_lo as u64;
                            let unused_hi = if cx.fs.has_64bit {
                                d.bg_itable_unused_hi as u64
                            } else { 0 };
                            let unused = (unused_hi << 16) | unused_lo;
                            if unused > 0 && idx >= ipg - unused {
                                let disp = String::from_utf8_lossy(name).into_owned();
                                cx.err(format!(
                                    "Entry '{disp}' in inode {parent} references inode {entry_ino} in group {group}'s unused inodes area"));
                            }
                        }
                    }
                } else {
                    cx.err(format!("Inode {parent}: dir entry refers to out-of-range inode {}", entry_ino));
                }
            }
        }
        off += rec_len;
    }
}
