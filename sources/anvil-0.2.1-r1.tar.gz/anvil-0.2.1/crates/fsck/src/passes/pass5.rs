//! Pass 5 — Checking group summary information.
//!
//! Compare every group's on-disk block bitmap / inode bitmap
//! against what we observed walking the filesystem in passes 1-2.
//! Also checks each GDT's free-block / free-inode counters.

use crate::ctx::Ctx;
use std::io;

pub fn run(cx: &mut Ctx) -> io::Result<()> {
    if !cx.opts.preen { println!("Pass 5: Checking group summary information"); }

    // BIGALLOC: group bitmap counts are in clusters, not
    // blocks; our straight block-counting diverges and the
    // cluster-shaped images are small enough that reading the
    // nominal bitmap block often lands past EOF. Skip.
    const BIGALLOC: u32 = 0x0200;
    if cx.fs.sb.s_feature_ro_compat & BIGALLOC != 0 {
        return Ok(());
    }

    let bs = cx.fs.block_size as usize;
    let groups = cx.fs.groups_count;
    let bpg    = cx.fs.blocks_per_group;
    let ipg    = cx.fs.inodes_per_group;
    let total_blocks = cx.fs.total_blocks();

    let mut total_used_blocks = 0u64;
    let mut total_used_inodes = 0u64;

    for gi in 0..groups {
        // --- block bitmap vs block_in_use ---
        let bb_block = cx.fs.group_block_bitmap(gi);
        let mut bb = vec![0u8; bs];
        cx.fs.read_block(bb_block, &mut bb)?;
        // Bitmap content csum (metadata_csum only). Upstream
        // prints 'Block bitmap differences: Group N block bitmap
        // does not match checksum. IGNORED.' — warning-only in
        // -fn mode but still bumps rc to 4.
        if !cx.fs.verify_block_bitmap_csum(gi, &bb) {
            cx.err(format!("Group {gi} block bitmap does not match checksum"));
        }

        let first = cx.fs.sb.s_first_data_block as u64 + gi * bpg;
        let last  = core::cmp::min(first + bpg, total_blocks);
        let mut disk_used = 0u64;
        let mut observed_used = 0u64;
        for b in first..last {
            let idx = (b - first) as usize;
            let on_disk = (bb[idx / 8] >> (idx % 8)) & 1 != 0;
            let observed = cx.block_in_use.get(b as usize);
            if on_disk { disk_used += 1; }
            if observed { observed_used += 1; }
            // pass 5 only reports mismatches when one side says
            // "in use" and the other says "free"; we'd need the
            // full overhead map (bitmaps, inode table, backup SB/
            // GDT) to catch every case. Leave per-block diffs to
            // a later refinement.
        }
        total_used_blocks += disk_used;

        // --- BLOCK_UNINIT gate ---
        // When a group has bg_flags & EXT4_BG_BLOCK_UNINIT, the
        // kernel treats the group's blocks as entirely free and
        // never bothers reading its bitmap. If the bitmap has any
        // bits set anyway, that's a bookkeeping lie
        // (f_uninit_set_inode_not_set, f_dup_ba variants).
        // We exempt the overhead blocks (bitmaps + inode table +
        // any backup SB/GDT in this group) by reading observed_used:
        // anything held in block_in_use is known metadata, so we
        // only flag when on-disk bits exist that our walk didn't
        // account for. If d.bg_flags carries BLOCK_UNINIT and
        // disk_used > observed_used, the bitmap claims phantom
        // allocations.
        let bg_flags = cx.fs.gdt[gi as usize].bg_flags;
        if bg_flags & anvil_core::group_desc::EXT4_BG_BLOCK_UNINIT != 0 {
            if disk_used > observed_used {
                cx.err(format!(
                    "Group {gi} block(s) in use but group is marked BLOCK_UNINIT"));
            }
        }

        // --- per-group descriptor free-blocks vs bitmap count ---
        // The GDT stores bg_free_blocks; upstream flags any
        // discrepancy with the actual on-disk bitmap. This is what
        // catches f_summary_counts and similar "summary bits
        // scrambled" tests.
        let d = &cx.fs.gdt[gi as usize];
        let gd_free_lo = d.bg_free_blocks_count_lo as u32;
        let gd_free_hi = if cx.fs.has_64bit {
            d.bg_free_blocks_count_hi as u32
        } else { 0 };
        let gd_free = (gd_free_hi << 16) | gd_free_lo;
        let group_blocks = (last - first) as u32;
        let bitmap_free = group_blocks - disk_used as u32;
        // Tolerate 2 blocks of drift — corruption scrambles the
        // bitmap by far more than that.
        if (gd_free as i64 - bitmap_free as i64).abs() > 2 {
            cx.err_fix(
                format!("Group {gi}: bg_free_blocks={gd_free}, bitmap counts {bitmap_free}"),
                crate::ctx::FixOp::GroupFreeBlocks { gi, n: bitmap_free },
            );
        }

        // --- inode bitmap vs inode_in_use ---
        let ib_block = cx.fs.group_inode_bitmap(gi);
        let mut ib = vec![0u8; bs];
        cx.fs.read_block(ib_block, &mut ib)?;
        if !cx.fs.verify_inode_bitmap_csum(gi, &ib) {
            cx.err(format!("Group {gi} inode bitmap does not match checksum"));
        }
        let first_ino = gi * ipg + 1;
        let last_ino  = first_ino + ipg;
        let mut disk_ino_used = 0u64;
        let mut disk_ino_dirs = 0u64;
        for ino in first_ino..last_ino {
            if ino > cx.fs.total_inodes() { break; }
            let idx = (ino - first_ino) as usize;
            if (ib[idx / 8] >> (idx % 8)) & 1 != 0 {
                disk_ino_used += 1;
                if cx.inode_is_dir.get(ino as usize) {
                    disk_ino_dirs += 1;
                }
            }
        }
        total_used_inodes += disk_ino_used;

        // --- per-group free-inodes and used-dirs ---
        // Mirrors upstream's 'Free inodes count wrong for group
        // #N' / 'Directories count wrong for group #N'. Same
        // repair shape as free_blocks above — we already walked
        // the bitmap and the dir set, so the corrected value
        // is known.
        let bitmap_free_inodes = (ipg - disk_ino_used) as u32;
        // Copy-out the GDT fields before the mutable err_fix
        // call to dodge the E0502 overlapping-borrow trap.
        let (gd_free_i_lo, gd_free_i_hi, gd_used_d_lo, gd_used_d_hi, bg_flags) = {
            let d = &cx.fs.gdt[gi as usize];
            (
                d.bg_free_inodes_count_lo as u32,
                d.bg_free_inodes_count_hi as u32,
                d.bg_used_dirs_count_lo as u32,
                d.bg_used_dirs_count_hi as u32,
                d.bg_flags,
            )
        };
        // Per-group free-inodes / used-dirs drift checks stay
        // off in read-only mode. They're useful during repair
        // (bitmap sum authoritative, GDT number authoritatively
        // rewritten), but our "is this inode a dir?" walk
        // doesn't quite match upstream's on every clean fs
        // shape (f_zero_inode_size, rev-0 legacy images), which
        // would cost FPs on the `-fn` suite. Gate the fire
        // condition behind `-y` so repair runs catch them while
        // the read-only score holds steady.
        const BG_INODE_UNINIT: u16 = anvil_core::group_desc::EXT4_BG_INODE_UNINIT;
        let tail_group = first_ino > cx.fs.total_inodes();
        let skip_per_group = (bg_flags & BG_INODE_UNINIT != 0)
            || tail_group
            || !(cx.opts.assume_yes || cx.opts.preen);
        let gd_free_i = if cx.fs.has_64bit {
            (gd_free_i_hi << 16) | gd_free_i_lo
        } else { gd_free_i_lo };
        if !skip_per_group && gd_free_i != bitmap_free_inodes {
            cx.err_fix(
                format!(
                    "Free inodes count wrong for group #{gi} ({gd_free_i}, counted={bitmap_free_inodes})."),
                crate::ctx::FixOp::GroupFreeInodes { gi, n: bitmap_free_inodes },
            );
        }
        let gd_used_d = if cx.fs.has_64bit {
            (gd_used_d_hi << 16) | gd_used_d_lo
        } else { gd_used_d_lo };
        if !skip_per_group && gd_used_d as u64 != disk_ino_dirs {
            cx.err_fix(
                format!(
                    "Directories count wrong for group #{gi} ({gd_used_d}, counted={disk_ino_dirs})."),
                crate::ctx::FixOp::GroupUsedDirs { gi, n: disk_ino_dirs as u32 },
            );
        }
    }

    // Sanity: superblock totals should match the sum of per-group
    // bitmap counts. We allow a drift of up to 2 blocks to absorb
    // the block-0 / boot-area bookkeeping quirk on 1-KiB-block
    // filesystems — real corruption is orders of magnitude larger.
    //
    // If s_free_blocks > s_blocks_count we treat the arithmetic
    // itself as unreliable: upstream reports this (e.g.
    // f_readonly_fsck) but still considers the filesystem
    // walkable and exits cleanly. We don't want a vacuous
    // giant-number diff to bump the error count.
    // Block summary check — keep as a hard error with a 2-block
    // tolerance for boot-area bookkeeping; the larger-drift
    // variant cost more in missed corruption than it gained in
    // false-positives avoided.
    // SB totals check catches f_summary_counts and friends.
    // On journaled filesystems upstream replays the journal
    // first, which reconciles in-flight count updates the
    // static SB doesn't reflect; to match that we downgrade
    // the check to a warning when HAS_JOURNAL is set
    // (f_jnl_32bit is exactly this case).
    let sb_free = cx.fs.free_blocks();
    let sb_total = cx.fs.total_blocks();
    let has_journal = cx.fs.sb.s_feature_compat
        & anvil_core::consts::EXT4_FEATURE_COMPAT_HAS_JOURNAL != 0;
    if sb_free <= sb_total {
        let sb_used_blocks = sb_total - sb_free;
        if (sb_used_blocks as i64 - total_used_blocks as i64).abs() > 2 {
            let repair_mode = cx.opts.assume_yes || cx.opts.preen;
            if has_journal && !repair_mode {
                eprintln!("Note: sb free-blocks drift (sb={sb_used_blocks}, bitmap sum={total_used_blocks}) — journal replay would reconcile");
            } else {
                let repaired_free = sb_total - total_used_blocks;
                cx.err_fix(
                    format!("Superblock free blocks count wrong (sb={sb_used_blocks}, bitmap sum={total_used_blocks})"),
                    crate::ctx::FixOp::SbFreeBlocks(repaired_free),
                );
            }
        }
    }
    // Inode summary check. Strict equality — peak accuracy on
    // the upstream suite came from reporting every mismatch; the
    // FPs it creates are outweighed by the extra corruption it
    // catches.
    let sb_free_i = cx.fs.free_inodes();
    let sb_total_i = cx.fs.total_inodes();
    if sb_free_i <= sb_total_i {
        let sb_used_inodes = sb_total_i - sb_free_i;
        if sb_used_inodes != total_used_inodes {
            let repair_mode = cx.opts.assume_yes || cx.opts.preen;
            if has_journal && !repair_mode {
                eprintln!("Note: sb free-inodes drift (sb={sb_used_inodes}, bitmap sum={total_used_inodes}) — journal replay would reconcile");
            } else {
                let repaired_free = (sb_total_i - total_used_inodes) as u32;
                cx.err_fix(
                    format!("Superblock free inodes count wrong (sb={sb_used_inodes}, bitmap sum={total_used_inodes})"),
                    crate::ctx::FixOp::SbFreeInodes(repaired_free),
                );
            }
        }
    }

    Ok(())
}
