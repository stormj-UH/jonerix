//! Pass 4 — Checking reference counts.
//!
//! Each in-use inode's i_links_count must match the number of dir
//! entries that point at it, ignoring the special cases:
//!   * directories have +1 link from their own "." entry — already
//!     counted during pass 2
//!   * directories have +1 from each sub-directory's ".." — also
//!     counted
//! We allow a small drift for the reserved inodes (bad/resize/
//! journal) whose link count isn't maintained by normal FS ops.

use crate::ctx::Ctx;
use anvil_core::consts::*;
use std::io;

pub fn run(cx: &mut Ctx) -> io::Result<()> {
    if !cx.opts.preen { println!("Pass 4: Checking reference counts"); }

    let total = cx.fs.total_inodes() as u32;
    for ino in 1..=total {
        if !cx.inode_in_use.get(ino as usize) { continue; }
        if is_reserved(ino) { continue; }

        let inode = cx.fs.read_inode(ino)?;
        let want = inode.i_links_count;
        let have = cx.inode_observed_links[ino as usize];

        // Mode=0 on an inode that a directory entry points at is
        // real corruption. Pass 1 skips this check because
        // reserved-range slots legally have mode=0; here we have
        // the benefit of knowing whether the inode was actually
        // reached from the root and can be specific.
        if inode.i_mode == 0 && have > 0 {
            cx.err(format!("Inode {ino}: dir-referenced but i_mode=0"));
        }

        if have == 0 {
            // Allocated inode not referenced by any directory
            // entry. Upstream reports it as "Unattached inode N"
            // and offers to reconnect to /lost+found. Skip:
            //  * EA inodes (i_flags & EA_INODE): store xattr data,
            //    not in the namespace by design
            //  * The orphan-file inode (s_orphan_file_inum): a
            //    reserved helper inode for orphan tracking
            const EA_INODE_FL: u32 = 0x00200000;
            let iflags = inode.i_flags;
            let is_ea_inode = iflags & EA_INODE_FL != 0;
            let is_orphan_file = cx.fs.sb.s_orphan_file_inum != 0
                && ino == cx.fs.sb.s_orphan_file_inum;
            if inode.i_mode != 0
                && inode.i_links_count > 0
                && !is_ea_inode
                && !is_orphan_file
            {
                cx.err(format!("Inode {ino}: unattached (no dir refs)"));
            }
            continue;
        }
        if want != have {
            cx.err(format!("Inode {ino}: i_links_count={want}, observed={have}"));
        }
    }
    Ok(())
}

fn is_reserved(ino: u32) -> bool {
    matches!(ino,
        EXT4_BAD_INO
        | EXT4_RESIZE_INO
        | EXT4_JOURNAL_INO
        | EXT4_USR_QUOTA_INO
        | EXT4_GRP_QUOTA_INO
        | EXT4_BOOT_LOADER_INO
        | EXT4_UNDEL_DIR_INO
    )
}
