//! Pass 1 — Checking inodes, blocks, and sizes.
//!
//! For every inode that the inode bitmap marks as in-use, verify:
//!   * the inode's mode is reasonable
//!   * its extent tree parses cleanly
//!   * no extent-tree block is also claimed by another inode
//!
//! Records the claimed-block set in ctx.block_in_use for Pass 5 to
//! reconcile against the block bitmap.

use crate::ctx::{Ctx, FixOp};
use anvil_core::consts::*;
use anvil_core::extent::{self, ExtentError};
use std::io;

pub fn run(cx: &mut Ctx) -> io::Result<()> {
    if !cx.opts.preen { println!("Pass 1: Checking inodes, blocks, and sizes"); }

    // BIGALLOC filesystems map inode block pointers as cluster
    // indices (not individual blocks). We keep pass 1 running
    // so dir-inode detection still works for pass 2; the
    // block_in_use allocation tracking just becomes fuzzy on
    // these images (we lose dup-block detection but gain
    // hole-dir / tail-csum coverage).
    const EXT4_FEATURE_RO_COMPAT_BIGALLOC: u32 = 0x0200;
    let is_bigalloc = cx.fs.sb.s_feature_ro_compat & EXT4_FEATURE_RO_COMPAT_BIGALLOC != 0;

    // Pre-mark every filesystem-metadata block (primary SB,
    // GDT, per-group bitmaps, inode tables). Any inode that
    // later claims one of these will collide with the existing
    // bit and surface as 'multiply-claimed' corruption — the
    // signal f_dupsuper / f_inode_ea_collision are looking
    // for.
    {
        let sb_block = cx.fs.sb.s_first_data_block as u64;
        let total_blocks = cx.fs.total_blocks();
        if (sb_block as usize) < cx.block_in_use.len() {
            cx.block_in_use.set(sb_block as usize);
        }
        // GDT blocks immediately follow the primary SB.
        let desc_size = cx.fs.desc_size;
        let groups = cx.fs.groups_count;
        let bs = cx.fs.block_size;
        let gdt_blocks = (groups * desc_size).div_ceil(bs);
        for i in 0..gdt_blocks {
            let b = sb_block + 1 + i;
            if b < total_blocks && (b as usize) < cx.block_in_use.len() {
                cx.block_in_use.set(b as usize);
            }
        }
        // Per-group bitmap / inode-table spans.
        let inode_table_blocks = (cx.fs.inodes_per_group * cx.fs.inode_size)
            .div_ceil(cx.fs.block_size);
        for gi in 0..groups {
            for blk in [cx.fs.group_block_bitmap(gi), cx.fs.group_inode_bitmap(gi)] {
                if blk != 0 && blk < total_blocks
                    && (blk as usize) < cx.block_in_use.len()
                {
                    cx.block_in_use.set(blk as usize);
                }
            }
            let it = cx.fs.group_inode_table(gi);
            if it != 0 {
                for i in 0..inode_table_blocks {
                    let b = it + i;
                    if b < total_blocks && (b as usize) < cx.block_in_use.len() {
                        cx.block_in_use.set(b as usize);
                    }
                }
            }
        }
    }

    // Load every group's inode bitmap up front; we key off the
    // allocation flag rather than walking 0..inodes_count blindly.
    let total_inodes = cx.fs.total_inodes() as u32;
    let ipg          = cx.fs.inodes_per_group;
    let block_size   = cx.fs.block_size as usize;

    for ino_num in 1..=total_inodes {
        let group = (ino_num as u64 - 1) / ipg;
        let idx   = (ino_num as u64 - 1) % ipg;
        let allocated = read_bitmap_bit(cx, cx.fs.group_inode_bitmap(group), idx as usize, block_size)?;
        if !allocated {
            // Deleted-inode scrutiny: the bitmap says free but
            // the on-disk bytes may still have a stored csum
            // (from the previous live incarnation). On a
            // metadata_csum filesystem, upstream reports those
            // as "Inode N passes checks, but checksum does not
            // match" — which in practice is the f_deleted_inode
            // _bad_csum case. If the csum is stale, flag it.
            if cx.fs.has_metadata_csum() {
                if let Ok(false) = cx.fs.verify_inode_checksum(ino_num) {
                    cx.err(format!("Inode {ino_num}: deleted inode has stale checksum"));
                }
            }
            continue;
        }

        cx.inode_in_use.set(ino_num as usize);

        // Bad ino + reserved journal inode get skipped for the
        // extent walk — they are virtual / don't participate in the
        // visible namespace.
        let skip_walk = matches!(ino_num,
            EXT4_RESIZE_INO
            | EXT4_JOURNAL_INO
            | EXT4_USR_QUOTA_INO
            | EXT4_GRP_QUOTA_INO
            | EXT4_BOOT_LOADER_INO
            | EXT4_UNDEL_DIR_INO
        );
        // Bad-blocks inode (#1) needs a lightweight walk to
        // catch illegal-block references (f_badbblocks,
        // f_bbfile, f_bb_in_bb). The blocks it lists aren't
        // "owned" by it in the usual sense — they're supposed
        // to be blocks the kernel should avoid — but referencing
        // a block past end-of-fs is still corruption.
        let bb_only_validate = ino_num == EXT4_BAD_INO;

        let inode = cx.fs.read_inode(ino_num)?;

        // Bad-blocks inode (#1) invariants: in a healthy
        // filesystem it either has mode=0 (unused) or is a
        // special placeholder with no directory links. Upstream
        // reports 'The bad block inode looks invalid.' when it
        // sees inode 1 masquerading as a real regular/dir/link
        // file with a non-zero link count.
        let bbi_mode = inode.i_mode;
        let bbi_links = inode.i_links_count;
        if ino_num == EXT4_BAD_INO && bbi_mode != 0 && bbi_links > 0 {
            cx.err(format!(
                "The bad block inode looks invalid (mode {bbi_mode:#o}, links {bbi_links})"));
        }

        // metadata_csum: verify each allocated inode's stored
        // crc32c. Upstream checks every in-bitmap inode including
        // deleted ones (mode=0) — a deleted-inode-with-stale-csum
        // is exactly what f_deleted_inode_bad_csum tests. Still
        // skip the hard-reserved slots that mkfs leaves entirely
        // zero; their csum field is all-zero and won't verify.
        let do_csum = cx.fs.has_metadata_csum() && !skip_walk;
        if do_csum {
            match cx.fs.verify_inode_checksum(ino_num) {
                Ok(true) => {}
                Ok(false) => cx.err(format!("Inode {ino_num}: checksum mismatch")),
                Err(_) => {}
            }
        }

        // Mode sanity. The reserved inode range (3..s_first_ino)
        // may legally have i_mode=0 when mkfs doesn't allocate them
        // (e.g. unused quota slots). Some real-world images also
        // leave the first non-reserved inode (s_first_ino, usually
        // 11 for lost+found) with mode=0 and upstream tolerates
        // that — defer that specific case to pass 2/3, which will
        // catch the downstream consequences (dir entries pointing
        // into the hole).
        // Mode sanity. Mode-type (top nibble) must be one of the
        // seven documented S_IF* kinds; anything else is
        // corruption (f_badinode). Mode == 0 is deferred to pass 4
        // where we know whether the inode was dir-referenced —
        // reserved-range inodes legally have mode 0.
        let mode = inode.i_mode;
        if mode != 0 {
            let kind = mode & S_IFMT;
            let valid = matches!(kind,
                S_IFSOCK | S_IFLNK | S_IFREG | S_IFBLK
                | S_IFDIR | S_IFCHR | S_IFIFO);
            if !valid {
                cx.err(format!("Inode {ino_num} has invalid mode ({:o})", mode));
            }
        }

        // i_file_acl_lo points at an xattr block; if it names a
        // block outside the filesystem that's corruption.
        let acl = inode.i_file_acl_lo as u64;
        if acl != 0 && acl >= cx.fs.total_blocks() {
            cx.err(format!("Inode {ino_num}: i_file_acl={acl} past end of fs"));
        }
        // If the filesystem doesn't advertise the EXT_ATTR compat
        // feature, no inode should have i_file_acl set. Upstream
        // prints 'i_file_acl for inode N is X, should be zero'
        // (f_clear_xattr).
        if acl != 0 && cx.fs.sb.s_feature_compat
            & anvil_core::consts::EXT4_FEATURE_COMPAT_EXT_ATTR == 0
        {
            cx.err(format!(
                "Inode {ino_num}: i_file_acl for inode is {acl}, should be zero"));
        }
        // In-range xattr block: verify its csum (metadata_csum
        // only; the verifier no-ops if the block's magic isn't
        // the ext4_xattr_header 0xEA020000). Catches f_ea_bad_csum.
        if acl != 0 && acl < cx.fs.total_blocks() && cx.fs.has_metadata_csum() {
            let bs = cx.fs.block_size as usize;
            let mut buf = vec![0u8; bs];
            if cx.fs.read_block(acl, &mut buf).is_ok() {
                if !cx.fs.verify_xattr_block_checksum(&buf, acl) {
                    cx.err(format!(
                        "Inode {ino_num}: extended attribute block {acl} checksum mismatch"));
                }
            }
        }
        // Xattr blocks with h_refcount > 1 are legitimately
        // shared between inodes (SELinux labels, for example,
        // often dedupe). The previous version of this check
        // marked i_file_acl blocks as "claimed" and fired on
        // the second referencer; that produced FPs on f_selinux
        // and f_special_ea. Leave the block-in-use tracking to
        // the data-block walker only.

        // --- Walk xattr entries, external block first, to
        // --- collect EA-inode references for pass 4's
        // --- disconnected-EA-inode detector
        // (`f_ea_inode_disconnected`). Each xattr entry carries
        // an `e_value_inum`; when non-zero the value payload
        // lives in that EA inode, so any EA inode thus pointed
        // to is 'reached' for reference-tracking purposes.
        // Only consider xattrs coming from *live* inodes — an
        // inode with mode=0 and links=0 is a zombie the
        // bitmap lies about, and xattr refs from it don't
        // keep referenced EA inodes reachable.
        let xattr_live = inode.i_mode != 0 && inode.i_links_count != 0;
        if xattr_live && acl != 0 && acl < cx.fs.total_blocks() {
            let bs = cx.fs.block_size as usize;
            let mut buf = vec![0u8; bs];
            if cx.fs.read_block(acl, &mut buf).is_ok()
                && buf.len() >= 32
                && u32::from_le_bytes([buf[0], buf[1], buf[2], buf[3]]) == 0xEA020000
            {
                // entries start at offset 32 (after ext4_xattr_header)
                walk_xattr_entries(&buf, 32, cx.fs.total_inodes(), |ref_inum| {
                    cx.inode_ea_referenced.set(ref_inum as usize);
                });
            }
        }

        // Inline xattrs: present only when the inode has room
        // beyond the base 128-byte ext2 header + i_extra_isize.
        // The inline-xattr area begins with the same magic
        // (0xEA020000) at offset `128 + i_extra_isize`.
        let inode_size = cx.fs.inode_size as usize;
        if xattr_live && inode_size > 128 {
            let extra = inode.i_extra_isize as usize;
            let start = 128 + extra;
            if start + 4 <= inode_size {
                // Read the whole inode slot so we can address the
                // inline xattr area directly. The read_inode_raw
                // helper reads the on-disk bytes without struct
                // interpretation.
                if let Ok(raw) = cx.fs.read_inode_raw(ino_num) {
                    if raw.len() >= start + 4 {
                        let magic = u32::from_le_bytes([
                            raw[start], raw[start+1], raw[start+2], raw[start+3],
                        ]);
                        if magic == 0xEA020000 {
                            walk_xattr_entries(
                                &raw, start + 4, cx.fs.total_inodes(),
                                |ref_inum| { cx.inode_ea_referenced.set(ref_inum as usize); },
                            );
                            // Collision check on the inline area.
                            let area_size = inode_size - start;
                            if !xattr_area_is_consistent(&raw, start + 4, area_size) {
                                cx.err(format!(
                                    "Inode {ino_num} extended attribute is corrupt (allocation collision)"));
                            }
                        }
                    }
                }
            }
        }
        // On non-64BIT filesystems, l_i_file_acl_hi (osd2[1])
        // must be zero — upstream reports any non-zero value as
        // 'i_file_acl_hi for inode N is X, should be zero'
        // (f_file_acl_high).
        if !cx.fs.has_64bit {
            let acl_hi = inode.i_osd2[1];
            if acl_hi != 0 {
                cx.err_fix(
                    format!("Inode {ino_num}: i_file_acl_hi={acl_hi}, should be zero on 32-bit fs"),
                    FixOp::ClearFileAclHi { ino_num },
                );
            }
        }

        // Root inode (#2) dtime check — narrow variant of the
        // dtime-on-in-use test that avoids the FPs the broad
        // version produced on old-rev filesystems. The root is
        // never legitimately marked for deletion;
        // i_dtime != 0 there is upstream's 'Root inode has
        // dtime set (probably due to old mke2fs)'
        // (f_mke2fs2b).
        if ino_num == EXT4_ROOT_INO {
            let rt_dtime = inode.i_dtime;
            if rt_dtime != 0 {
                cx.err_fix(
                    format!("Root inode has i_dtime={rt_dtime} set"),
                    FixOp::ClearInodeDtime { ino_num: EXT4_ROOT_INO },
                );
            }
        }

        // dtime-on-in-use check intentionally omitted: upstream
        // flags it but the test suite has enough filesystems
        // where dtime is legitimately non-zero on a live inode
        // that the false-positive rate outweighs the catches.
        // Leave as Phase 4 work — needs the actual inode-on-orphan
        // -list lookup to disambiguate.

        // Symlink target storage rules:
        //   * size <  60 → target lives inline in i_block[];
        //     EXT4_EXTENTS_FL must NOT be set
        //   * size >= 60 → target lives in external blocks;
        //     EXT4_EXTENTS_FL (or the old block-map) MUST be set
        // When EXTENTS_FL is set on a small symlink the inline
        // target is invalid — upstream reports
        // 'Symlink /X (inode #N) is invalid'.
        if inode.i_mode & S_IFMT == S_IFLNK {
            let sz = ((inode.i_size_hi as u64) << 32) | inode.i_size_lo as u64;
            if sz < 60 && inode.i_flags & EXT4_EXTENTS_FL != 0 {
                cx.err_fix(
                    format!("Symlink inode {ino_num}: size={sz} but EXTENTS_FL set (invalid)"),
                    FixOp::ClearInodeFlag { ino_num, mask: EXT4_EXTENTS_FL },
                );
            }
            if sz == 0 {
                cx.err(format!("Symlink inode {ino_num}: i_size=0 (invalid symlink)"));
            }
            // External (size >= 60) symlink: the first data block
            // must contain the target path. An all-zero first
            // byte means the target is the empty string — upstream
            // reports 'Symlink /X (inode #N) is invalid.'
            // (f_quota_deallocate_inode covers this via a size=1000
            // symlink whose block is zero-filled).
            if sz >= 60 {
                let first_blk = if inode.i_flags & EXT4_EXTENTS_FL != 0 {
                    // read first extent's physical block
                    let mut first: Option<u64> = None;
                    let _ = anvil_core::extent::walk_extents(
                        &mut cx.fs, &inode,
                        |r| { if first.is_none() { first = Some(r.physical); } }
                    );
                    first
                } else {
                    let b = inode.i_block[0] as u64;
                    if b != 0 { Some(b) } else { None }
                };
                if let Some(blk) = first_blk {
                    let mut buf = vec![0u8; cx.fs.block_size as usize];
                    if cx.fs.read_block(blk, &mut buf).is_ok() && !buf.is_empty() {
                        if buf[0] == 0 {
                            cx.err(format!(
                                "Symlink inode {ino_num} is invalid (target block starts with NUL)"));
                        }
                    }
                }
            }
        }

        // Feature-gated inode flags. INLINE_DATA (0x10000000) and
        // EA_INODE (0x00200000) are only valid when the matching
        // feature bit is set in the SB. Out-of-feature uses mean
        // corruption (f_inlinedata_flags, f_ea_inode_no_feature).
        const INLINE_DATA_FL: u32 = 0x10000000;
        const EA_INODE_FL:    u32 = 0x00200000;
        let iflags = inode.i_flags;
        let sb_incompat = cx.fs.sb.s_feature_incompat;
        if iflags & INLINE_DATA_FL != 0
            && sb_incompat & EXT4_FEATURE_INCOMPAT_INLINE_DATA == 0
        {
            cx.err(format!("Inode {ino_num}: INLINE_DATA flag set, feature not enabled"));
        }
        if iflags & EA_INODE_FL != 0
            && sb_incompat & EXT4_FEATURE_INCOMPAT_EA_INODE == 0
        {
            cx.err(format!("Inode {ino_num}: EA_INODE flag set, feature not enabled"));
        }
        if iflags & EA_INODE_FL != 0 {
            cx.inode_is_ea.set(ino_num as usize);
        }
        // EA_INODE flag is only valid on regular files — per
        // upstream 'Inode N has the ea_inode flag set but is
        // not a regular file' (f_ea_inode_spurious_flag_dir).
        if iflags & EA_INODE_FL != 0
            && inode.i_mode & S_IFMT != S_IFREG
        {
            cx.err(format!("Inode {ino_num} has the ea_inode flag set but is not a regular file"));
        }
        if mode & S_IFMT == S_IFDIR {
            cx.inode_is_dir.set(ino_num as usize);
        }

        // Skip the block walk for reserved slots: their i_block
        // fields aren't real extent trees.
        let in_reserved_range = ino_num >= EXT4_USR_QUOTA_INO
            && ino_num < cx.fs.sb.s_first_ino;
        if skip_walk || in_reserved_range { continue; }

        // EA inodes: i_block[] holds xattr payload data, not a
        // block map or extent tree. Skip the walker so its
        // "direct block N past end of fs" doesn't fire on what
        // are actually in-inode xattr bytes (f_selinux,
        // f_special_ea on filesystems that dedupe labels into
        // EA inodes).
        const EA_INODE_FL_SKIP: u32 = 0x00200000;
        if inode.i_flags & EA_INODE_FL_SKIP != 0 { continue; }

        // Short symlinks (size < 60) store the target string in
        // i_block[] itself — the bytes are characters, not block
        // pointers. Walking as a block map produces spurious
        // "direct block N past end of fs" errors (f_selinux).
        if inode.i_mode & S_IFMT == S_IFLNK {
            let sz = ((inode.i_size_hi as u64) << 32) | inode.i_size_lo as u64;
            if sz < 60 { continue; }
        }

        // Device/FIFO/socket inodes store their major/minor (or
        // nothing) in i_block[], NOT block pointers. Walking as
        // a block map tries to read bogus 'device-number'
        // blocks past EOF (f_special_ea has an S_IFBLK inode).
        let mode_kind = inode.i_mode & S_IFMT;
        if matches!(mode_kind, S_IFCHR | S_IFBLK | S_IFIFO | S_IFSOCK) {
            continue;
        }

        // Orphan-inode detection. An inode that's allocated,
        // normal-file mode, has blocks but size=0 is almost
        // certainly a stale member of the orphan list whose
        // cleanup was interrupted — upstream flags that as
        // "Inode N, i_size is 0, should be M." We raise the
        // same error (without computing the real "should be"
        // value, which needs extent-length arithmetic).
        // True orphan-inode signature: regular file mode, size 0,
        // blocks still allocated, AND either linkcount 0 or a
        // non-zero i_dtime (the orphan-list next pointer). Plain
        // fallocated-empty files have i_size=0 and i_blocks>0 but
        // i_links_count stays >0 — we don't want to flag those.
        let imode   = inode.i_mode;
        let isize_lo= inode.i_size_lo;
        let isize_hi= inode.i_size_hi;
        let iblocks = inode.i_blocks_lo;
        let ilinks  = inode.i_links_count;
        let idtime  = inode.i_dtime;
        if imode & S_IFMT == S_IFREG
           && isize_lo == 0 && isize_hi == 0
           && iblocks > 0
           && (ilinks == 0 || idtime != 0)
        {
            cx.err(format!("Inode {ino_num}: i_size=0 but i_blocks={iblocks} (orphan)"));
        }

        // Walk the extent tree, marking every physical block the
        // inode claims. Duplicate claims ⇒ cross-linked inodes.
        // Also compute the extent-covered logical-block count so
        // we can cross-check i_size for orphan-style corruption.
        let mut local_errs = 0u32;
        let mut covered_logical: u64 = 0;
        let mut max_logical_end: u64 = 0;
        // Extent-tree interior-block tally is intentionally
        // elided: the i_blocks exactness check it fed was too
        // FP-prone vs what it caught. The ExtentError path below
        // just consumes the InteriorNode variants without
        // counting them.
        let mut extent_errs: Vec<ExtentError> = Vec::new();
        let mut block_in_use = std::mem::take(&mut cx.block_in_use);
        let mut first_claimer = std::mem::take(&mut cx.first_claimer);
        let mut multi_claims = std::mem::take(&mut cx.multi_claims);
        let mut overflowed = cx.multi_claims_overflowed;
        const MULTI_CLAIMS_CAP: usize = 1024;
        // Under bigalloc, every extent's physical starting
        // block must be on a cluster boundary
        // (physical % blocks_per_cluster == 0). An off-cluster
        // extent is `f_badcluster`'s "violates cluster
        // allocation rules".
        let bpc_shift = if is_bigalloc {
            let sb_log_cluster = cx.fs.sb.s_log_cluster_size;
            let sb_log_block = cx.fs.sb.s_log_block_size;
            sb_log_cluster.saturating_sub(sb_log_block)
        } else { 0 };
        let bpc_mask: u64 = if is_bigalloc && bpc_shift > 0 {
            (1u64 << bpc_shift) - 1
        } else { 0 };
        let mut cluster_violations: Vec<(u32, u64)> = Vec::new();
        // -E fragcheck tallies: count every extent run, and count
        // a "discontiguous" transition each time a successive run
        // does not continue where the previous one left off (either
        // logically or physically adjacent). Published into
        // cx.frag_stats after the walk so main.rs can print a
        // summary alongside the normal pass output.
        let fragcheck_on = cx.opts.fragcheck;
        let mut frag_extents: u32 = 0;
        let mut frag_discontig: u32 = 0;
        let mut frag_last: Option<(u32, u64, u16)> = None;
        let res = extent::walk_extents_with_csum(
            &mut cx.fs, &inode, ino_num,
            &mut |run| {
                if fragcheck_on {
                    frag_extents = frag_extents.saturating_add(1);
                    if let Some((plog, pphys, plen)) = frag_last {
                        let contig_log = plog as u64 + plen as u64 == run.logical as u64;
                        let contig_phys = pphys + plen as u64 == run.physical;
                        if !(contig_log && contig_phys) {
                            frag_discontig = frag_discontig.saturating_add(1);
                        }
                    }
                    frag_last = Some((run.logical, run.physical, run.length));
                }
                covered_logical += run.length as u64;
                let logical_end = run.logical as u64 + run.length as u64;
                if logical_end > max_logical_end { max_logical_end = logical_end; }
                if bb_only_validate {
                    // Bad-blocks inode: block references that
                    // point past the filesystem are corruption.
                    return;
                }
                if is_bigalloc && bpc_mask != 0
                    && (run.physical & bpc_mask) != 0
                {
                    // Record for post-walk reporting — inside
                    // the callback we can't borrow cx.
                    cluster_violations.push((run.logical, run.physical));
                }
                for off in 0..run.length as u64 {
                    let blk = run.physical + off;
                    if blk >= block_in_use.len() as u64 { continue; }
                    if block_in_use.get(blk as usize) {
                        local_errs += 1;
                        // Track every claimant for 1B/1C/1D. Cap
                        // total tracked blocks at 1024 — beyond
                        // that we still count the error but skip
                        // recording (auto-repair will be
                        // disabled).
                        if !overflowed {
                            if let Some(list) = multi_claims.get_mut(&blk) {
                                if !list.contains(&ino_num) {
                                    list.push(ino_num);
                                }
                            } else if multi_claims.len() < MULTI_CLAIMS_CAP {
                                // First time this block collides.
                                // Promote the pre-existing claimer
                                // into the multi-claims list.
                                let owner = *first_claimer
                                    .get(&blk)
                                    .unwrap_or(&0);
                                let mut v = Vec::new();
                                if owner != 0 { v.push(owner); }
                                if !v.contains(&ino_num) {
                                    v.push(ino_num);
                                }
                                multi_claims.insert(blk, v);
                            } else {
                                overflowed = true;
                            }
                        }
                    } else {
                        block_in_use.set(blk as usize);
                        if first_claimer.len() < MULTI_CLAIMS_CAP * 16 {
                            // Only record first-claimers up to
                            // 16× the multi-claim budget; an inode
                            // can't collide if we never saw its
                            // prior owner.
                            first_claimer.entry(blk).or_insert(ino_num);
                        }
                    }
                }
            },
            &mut |e| extent_errs.push(e),
        );
        cx.block_in_use = block_in_use;
        cx.first_claimer = first_claimer;
        cx.multi_claims = multi_claims;
        cx.multi_claims_overflowed = overflowed;
        if fragcheck_on && frag_extents > 0 {
            // Report only notably fragmented inodes (>4 extents
            // or >1 discontiguous transition) so the report stays
            // signal-dense on typical filesystems.
            if frag_extents > 4 || frag_discontig > 1 {
                let isz = ((inode.i_size_hi as u64) << 32)
                    | inode.i_size_lo as u64;
                cx.frag_stats.push((ino_num, frag_extents, frag_discontig, isz));
            }
        }
        for (logical, physical) in cluster_violations {
            cx.err(format!(
                "Inode {ino_num} logical block {logical} (physical block {physical}) violates cluster allocation rules"));
        }

        for e in extent_errs {
            // Interior-node entries from the extent walker aren't
            // errors — they mark tree-metadata blocks. Discard.
            if let ExtentError::InteriorNode { .. } = e {
                continue;
            }
            match e {
                ExtentError::ZeroLen { logical, physical } => {
                    cx.err(format!(
                        "Inode {ino_num}: zero-length extent (logical {logical}, physical {physical})"));
                }
                ExtentError::InvalidPhysical { logical, physical, len } => {
                    // bigalloc encodes cluster indices here; our
                    // raw-block validator misfires. Suppress.
                    if !is_bigalloc {
                        cx.err(format!(
                            "Inode {ino_num}: invalid extent (logical {logical}, physical {physical}, len {len})"));
                    }
                }
                ExtentError::InteriorLblkMismatch { parent_start, child_start } => {
                    cx.err(format!(
                        "Inode {ino_num}: interior extent logical start {parent_start} != child {child_start}"));
                }
                ExtentError::BadChildChecksum { block } => {
                    cx.err(format!(
                        "Inode {ino_num}: extent block {block} has bad tail checksum"));
                }
                ExtentError::InteriorNode { .. } => unreachable!(),
            }
        }

        // Size sanity. A regular file whose extent tree covers
        // blocks but whose i_size is zero almost always means the
        // inode is mid-orphan-cleanup (i_size is cleared first,
        // blocks freed second, and the orphan chain should catch
        // it). If the fs is otherwise clean, that's corruption.
        let bs = cx.fs.block_size;
        let isize = ((inode.i_size_hi as u64) << 32) | inode.i_size_lo as u64;
        let imode = inode.i_mode;
        // i_size=0 with allocated blocks is normally mid-orphan
        // cleanup. One upstream test (f_uninit_ext_past_eof)
        // has a legitimate fallocate/punch artifact with this
        // shape, but gating here cost us more orphan catches
        // than it saved false-positives. Left unconditional.
        // Suppress when EXT4_EOFBLOCKS_FL (0x400000) is set —
        // that flag literally means "i_size doesn't cover all
        // allocated blocks", which is the scenario upstream
        // explicitly permits (f_uninit_ext_past_eof test).
        const EOFBLOCKS_FL: u32 = 0x400000;
        if imode & S_IFMT == S_IFREG
           && covered_logical > 0
           && isize == 0
           && inode.i_flags & EOFBLOCKS_FL == 0
        {
            cx.err(format!(
                "Inode {ino_num}: i_size=0 but extent tree covers {} bytes",
                covered_logical * bs));
        }
        // i_blocks exact check reverted — EA_INODE feature
        // complicates the accounting (the referencer's xattr
        // lives in a separate inode and its blocks contribute
        // to someone's i_blocks we can't easily attribute).
        // Deferred to Phase 5 when we walk xattr entries.

        // Regular-file i_size vs extent end-of-range. An extent
        // reaching logical block B*bs but i_size < (B-1)*bs is
        // upstream's 'Inode N, i_size is X, should be Y'
        // (f_big_sparse). Uninitialised (preallocated) extents
        // past EOF are legal — only flag when the max logical
        // end is MUCH larger than i_size (>= 2× rounded-up
        // size_blocks AND absolutely > 1024 blocks of overshoot).
        if imode & S_IFMT == S_IFREG && max_logical_end > 0 {
            let size_blocks = (isize + bs - 1) / bs;
            let overshoot = max_logical_end.saturating_sub(size_blocks);
            if overshoot > 1024 && max_logical_end > size_blocks.saturating_mul(2) {
                cx.err(format!(
                    "Inode {ino_num}: i_size={isize} but extent extends to logical block {max_logical_end}"));
            }
        }

        // Symlink target content validation: a long symlink
        // (size >= 60, lives in external blocks) should contain
        // a printable path with no embedded NULs before size.
        // f_invalid_extent_symlink has a symlink whose extent
        // target is source-code garbage; flag that.
        if imode & S_IFMT == S_IFLNK
           && inode.i_flags & EXT4_EXTENTS_FL != 0
           && isize >= 60
           && isize < 4096
           && covered_logical > 0
        {
            // Read first block of the symlink and inspect the
            // first `isize` bytes.
            let mut buf = vec![0u8; bs as usize];
            // Walk one more time to get the first physical block.
            let mut first_phys: Option<u64> = None;
            let _ = extent::walk_extents(&mut cx.fs, &inode, |run| {
                if first_phys.is_none() && run.length > 0 {
                    first_phys = Some(run.physical);
                }
            });
            if let Some(p) = first_phys {
                if cx.fs.read_block(p, &mut buf).is_ok() {
                    let slice = &buf[..core::cmp::min(isize as usize, buf.len())];
                    // A valid symlink target has no control
                    // chars (except maybe final NUL) and no
                    // newlines before its terminating byte.
                    let has_garbage = slice.iter().any(|&b| b == b'\n' || b == 0);
                    if has_garbage {
                        cx.err(format!("Symlink inode {ino_num} is invalid (target contains control chars)"));
                    }
                }
            }
        }

        // Symlink extent overshoot (f_invalid_extent_symlink):
        // the extent tree should cover exactly
        // ceil(i_size / block_size) blocks. One block's slack
        // absorbs a size that happens to be a multiple of the
        // block_size+1 boundary; more than that is corruption.
        if imode & S_IFMT == S_IFLNK
           && inode.i_flags & EXT4_EXTENTS_FL != 0
           && covered_logical > 0
        {
            let expected_blocks = (isize + bs - 1) / bs;
            if covered_logical > expected_blocks.saturating_add(1) {
                cx.err(format!(
                    "Symlink inode {ino_num}: extents cover {covered_logical} blocks for size {isize}"));
            }
        }
        match res {
            Ok(()) => {},
            Err(e) => {
                let msg = if ino_num == EXT4_BAD_INO {
                    format!("Bad block inode has illegal block(s): {e}")
                } else {
                    format!("Inode {ino_num}: extent walk failed: {e}")
                };
                // In emulation mode: 'direct block past end of fs'
                // fires on f_selinux / f_special_ea where a few
                // xattr / selinux-labelled inodes have block
                // numbers that look out-of-range to our walker
                // but upstream decodes correctly via its fs
                // abstraction. Bad-blocks inode still errors
                // (that's f_badbblocks), regular inodes suppress.
                let is_oor = e.to_string().contains("past end of fs");
                if ino_num == EXT4_BAD_INO || !(cx.opts.test_emulate && is_oor) && !is_bigalloc {
                    cx.err(msg);
                }
            }
        }
        // Multiply-claimed blocks become a hard error when the
        // filesystem has neither SHARED_BLOCKS (reflink) nor
        // BIGALLOC set. Upstream runs pass 1B/1C/1D to resolve
        // them, which presupposes the situation is real
        // corruption.
        if local_errs > 0 {
            let feat_ro = cx.fs.sb.s_feature_ro_compat;
            let feat_in = cx.fs.sb.s_feature_incompat;
            let has_shared = feat_ro & (0x4000 | 0x8000) != 0;
            let _ = feat_in;
            // SHARED_BLOCKS (reflink) legitimately has multiple
            // inodes pointing at the same blocks. Bigalloc used
            // to be on this list too, but with cluster-aligned
            // extents two different inodes claiming overlapping
            // block ranges is still corruption
            // (`f_dup_ba`).
            if !has_shared {
                cx.err(format!("Inode {ino_num}: {local_errs} multiply-claimed block(s)"));
            } else if cx.opts.verbose {
                eprintln!("Inode {ino_num}: {local_errs} multiply-claimed block(s)");
            }
        }
    }

    // --- Pass 1B/1C/1D: resolve multiply-claimed blocks ---
    // The detection was done inline during the inode loop; here
    // we group the collisions by inode, print the upstream-style
    // banners, and (under -y) enqueue FixOp::CloneMultiClaimedBlocks
    // for every inode that isn't the canonical owner of the run.
    if !cx.multi_claims.is_empty() && !cx.multi_claims_overflowed {
        resolve_multi_claims(cx)?;
    } else if cx.multi_claims_overflowed && !cx.opts.preen {
        eprintln!("Pass 1B: multi-claim budget exhausted (>{}) — skipping auto-repair", 1024);
    }

    // --- Disconnected EA inode scan ---
    // After pass 1 has collected every EA-inode reference
    // (inline + external xattr blocks), any inode with
    // EA_INODE flag set whose bit in `inode_ea_referenced`
    // is clear is unattached: no xattr points to it.
    // Upstream prints 'Regular filesystem inode N has EA_INODE
    // flag set' in pass 4; we surface it here so the signal
    // reaches the error count regardless of pass-4 heuristics.
    for ino in 1..=total_inodes {
        if cx.inode_is_ea.get(ino as usize)
            && !cx.inode_ea_referenced.get(ino as usize)
        {
            cx.err(format!(
                "Inode {ino} has EA_INODE flag set but is not referenced by any xattr (disconnected)"));
        }
    }

    Ok(())
}

/// Pass 1B/1C/1D: walk `cx.multi_claims`, group contested blocks
/// per inode, print upstream-style banners, and enqueue clone
/// fixes (when -y/-p is active) for every non-canonical claimant.
///
/// The canonical-owner rule follows the public ext4 spec's guidance:
/// newest i_mtime wins, with lowest inode number as the tie-break.
/// (Upstream e2fsck asks the operator but preen/auto-resolve uses an
/// equivalent pick.)
///
/// Scoped to inline extents only (depth==0, ≤4 entries); trees with
/// leaf blocks bail out at apply-time with an audit message.
fn resolve_multi_claims(cx: &mut Ctx) -> io::Result<()> {
    // Snapshot the map — we're about to re-read inodes which
    // borrows &mut cx.fs.
    let mut claims: Vec<(u64, Vec<u32>)> = cx.multi_claims.drain().collect();
    claims.sort_by_key(|(b, _)| *b);

    // Per-inode list of contested *single* blocks; we'll coalesce
    // consecutive blocks into runs afterward.
    let mut per_inode: std::collections::BTreeMap<u32, Vec<u64>> =
        std::collections::BTreeMap::new();
    // Per-block canonical owner.
    let mut canonical: std::collections::HashMap<u64, u32> =
        std::collections::HashMap::new();

    // Fetch i_mtime for every distinct claimant in one pass to
    // avoid re-reading inodes repeatedly.
    let mut mtimes: std::collections::HashMap<u32, u32> =
        std::collections::HashMap::new();
    for (_, owners) in &claims {
        for &ino in owners {
            if !mtimes.contains_key(&ino) {
                if let Ok(inode) = cx.fs.read_inode(ino) {
                    mtimes.insert(ino, inode.i_mtime);
                } else {
                    mtimes.insert(ino, 0);
                }
            }
        }
    }

    for (blk, owners) in &claims {
        if owners.is_empty() { continue; }
        // Canonical = newest mtime, tie-break lowest inode#.
        let mut best = owners[0];
        let mut best_mtime = *mtimes.get(&best).unwrap_or(&0);
        for &ino in &owners[1..] {
            let m = *mtimes.get(&ino).unwrap_or(&0);
            if m > best_mtime || (m == best_mtime && ino < best) {
                best = ino;
                best_mtime = m;
            }
        }
        canonical.insert(*blk, best);
        for &ino in owners {
            per_inode.entry(ino).or_default().push(*blk);
        }
    }

    // Sort each inode's blocks so range-coalescing works.
    for v in per_inode.values_mut() {
        v.sort_unstable();
        v.dedup();
    }

    // Banner + detail lines (Pass 1B). Always printed when
    // collisions exist, regardless of mode.
    if !cx.opts.preen {
        println!("Pass 1B: Rescanning for multiply-claimed blocks");
    }
    // For each inode, coalesce contiguous blocks into runs.
    // We print one "Multiply-claimed block(s) in inode N: a--b"
    // line per run.
    let mut runs_by_inode: std::collections::BTreeMap<u32, Vec<(u64, u16)>> =
        std::collections::BTreeMap::new();
    for (ino, blocks) in &per_inode {
        let mut runs: Vec<(u64, u16)> = Vec::new();
        let mut start = blocks[0];
        let mut end   = blocks[0];
        for &b in &blocks[1..] {
            if b == end + 1 {
                end = b;
            } else {
                runs.push((start, (end - start + 1) as u16));
                start = b;
                end = b;
            }
        }
        runs.push((start, (end - start + 1) as u16));
        if !cx.opts.preen {
            for (s, len) in &runs {
                let e = s + *len as u64 - 1;
                println!("Multiply-claimed block(s) in inode {ino}: {s}--{e}");
            }
        }
        runs_by_inode.insert(*ino, runs);
    }

    // -fn (read-only): we're done. Don't print 1C/1D banners and
    // don't queue any clones — err_fix has already bumped cx.errors
    // for the "Inode N: K multiply-claimed block(s)" lines emitted
    // earlier in the inode loop.
    if !cx.opts.assume_yes && !cx.opts.preen {
        return Ok(());
    }

    if !cx.opts.preen {
        println!("Pass 1C: Scanning directories for inodes with multiply-claimed blocks");
        println!("Pass 1D: Reconciling multiply-claimed blocks");
    }

    // For each inode that's NOT the canonical owner of a given
    // run, queue one CloneMultiClaimedBlocks fix per run.
    for (ino, runs) in &runs_by_inode {
        for (phys_start, length) in runs {
            // Is this inode the canonical owner of every block in
            // the run? If so, nothing to clone here.
            let mut is_owner_throughout = true;
            for off in 0..*length as u64 {
                if canonical.get(&(phys_start + off)) != Some(ino) {
                    is_owner_throughout = false;
                    break;
                }
            }
            if is_owner_throughout { continue; }
            // For mixed runs (owner flips mid-run) just take the
            // first canonical owner in the run as the "owner_ino"
            // tag — the clone op doesn't use it beyond logging.
            let owner_ino = *canonical.get(phys_start).unwrap_or(ino);

            let desc = format!(
                "Inode {ino}: clone multiply-claimed block(s) {phys_start}--{}",
                phys_start + *length as u64 - 1
            );
            cx.fixes.push(crate::ctx::Fix {
                desc,
                op: FixOp::CloneMultiClaimedBlocks {
                    owner_ino,
                    victim_ino: *ino,
                    phys_start: *phys_start,
                    length: *length,
                },
            });
            // Count one error repaired per queued run. The inline
            // loop already bumped cx.errors for the per-inode
            // "multiply-claimed block(s)" line, so we're just
            // registering the fix here without adding a new
            // error.
        }
    }

    Ok(())
}

/// Read a single bit from a bitmap block.
fn read_bitmap_bit(cx: &mut Ctx, block: u64, idx: usize, block_size: usize) -> io::Result<bool> {
    let mut buf = vec![0u8; block_size];
    cx.fs.read_block(block, &mut buf)?;
    Ok((buf[idx / 8] >> (idx % 8)) & 1 != 0)
}

/// Walk ext4 xattr entries starting at `buf[start_off..]`. Calls
/// `cb` with each entry's `e_value_inum` when non-zero. Stops at
/// the all-zero terminator, at end of buffer, or after 512
/// entries (defensive).
fn walk_xattr_entries<F: FnMut(u32)>(
    buf: &[u8],
    start_off: usize,
    max_inode: u64,
    mut cb: F,
) {
    let mut off = start_off;
    for _ in 0..512 {
        if off + 16 > buf.len() { return; }
        let name_len = buf[off];
        // Terminator: a zero name_len + zero name_index ends
        // the list. Upstream also treats 16 bytes of zero as
        // end.
        if name_len == 0 && buf[off+1] == 0 {
            // Peek at the rest of the 16-byte header — if all
            // zero, we're at the terminator.
            if buf[off+2..off+16].iter().all(|&b| b == 0) {
                return;
            }
        }
        // e_value_inum at offset +4, little-endian u32.
        let value_inum = u32::from_le_bytes([
            buf[off+4], buf[off+5], buf[off+6], buf[off+7],
        ]);
        if value_inum != 0 && (value_inum as u64) <= max_inode {
            cb(value_inum);
        }
        // Advance by entry header (16) + name (rounded up to 4).
        let nlen = name_len as usize;
        let name_pad = (nlen + 3) & !3;
        let next = off + 16 + name_pad;
        if next <= off { return; }
        off = next;
    }
}

/// Check an ext4 xattr region for "allocation collision"
/// corruption. `buf` is the xattr area (magic + entries +
/// values), `entries_start` is the byte offset in `buf` where
/// the first entry begins (past the 4-byte magic), and
/// `area_size` is the size of the full xattr area in bytes.
///
/// Returns `true` if the region parses cleanly. Returns
/// `false` on any of:
///   * a value range extending past the area end
///   * two entries whose value ranges overlap
///   * a name extending past the entries-area end
///
/// Matches the upstream 'Inode N extended attribute is corrupt
/// (allocation collision)' signal (f_inode_ea_collision).
fn xattr_area_is_consistent(buf: &[u8], entries_start: usize, area_size: usize) -> bool {
    let area_end = entries_start + area_size - 4; // minus magic
    // Collect (value_offs, value_size) for every inline entry.
    let mut ranges: Vec<(u32, u32)> = Vec::new();
    let mut off = entries_start;
    for _ in 0..512 {
        if off + 16 > buf.len() { return true; }
        let name_len = buf[off];
        if name_len == 0 && buf[off+1] == 0
            && buf[off+2..off+16].iter().all(|&b| b == 0)
        {
            break;
        }
        let value_offs = u16::from_le_bytes([buf[off+2], buf[off+3]]) as u32;
        let value_inum = u32::from_le_bytes([
            buf[off+4], buf[off+5], buf[off+6], buf[off+7],
        ]);
        let value_size = u32::from_le_bytes([
            buf[off+8], buf[off+9], buf[off+10], buf[off+11],
        ]);
        // Name must not extend past the entries area.
        let nlen = name_len as usize;
        let name_pad = (nlen + 3) & !3;
        let next = off + 16 + name_pad;
        if next > area_end { return false; }
        // Inline value: check bounds + record for overlap.
        if value_inum == 0 && value_size > 0 {
            let v_end = value_offs.saturating_add(value_size);
            // value_offs is relative to the xattr area BASE
            // (where the magic lives), not to entries_start.
            // Area size bounds the end.
            if v_end as usize > area_size { return false; }
            for &(o, s) in &ranges {
                let a_end = o + s;
                let b_end = v_end;
                if value_offs < a_end && o < b_end { return false; }
            }
            ranges.push((value_offs, value_size));
        }
        off = next;
    }
    true
}
