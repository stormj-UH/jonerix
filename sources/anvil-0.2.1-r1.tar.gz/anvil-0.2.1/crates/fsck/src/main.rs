//! e2fsck — anvil's ext4 checker.
//!
//! Phase 2 scope: read-only validation that matches upstream
//! e2fsck's pass outline. We do NOT yet repair; anything that
//! requires modification reports an error and bumps the exit code.
//!
//! Exit codes (matches upstream):
//!   0  no errors
//!   4  uncorrected errors (with -n)
//!   8  operational error (could not read device, bad magic, etc.)
//!  16  usage error

use std::path::PathBuf;
use std::process::ExitCode;

mod passes;
mod ctx;
mod compact_dirs;
mod fragcheck;
mod quota;
mod reap;
mod mmp;
mod jnl_replay;

fn main() -> ExitCode {
    let args: Vec<String> = std::env::args().skip(1).collect();
    let mut path: Option<PathBuf> = None;
    let mut opts = ctx::Opts::default();
    let mut iter = args.into_iter();
    while let Some(a) = iter.next() {
        match a.as_str() {
            "-p" => opts.preen = true,
            "-f" => opts.force = true,
            "-F" => opts.post_flush = true,
            "-y" => opts.assume_yes = true,
            "-n" => opts.assume_no = true,
            "-v" => opts.verbose = true,
            "-V" => {
                println!("e2fsck 1.47.3-anvil (MIT)");
                return ExitCode::from(0);
            }
            "-E" => {
                // Extended options — comma-separated key[=value]
                // list, e.g. `-E fragcheck,journal_only`. Today
                // only `fragcheck` is recognised; every other key
                // is tolerated with a warning so scripts passing
                // upstream's full vocabulary keep working.
                let Some(arg) = iter.next() else {
                    eprintln!("e2fsck: -E requires an argument");
                    return ExitCode::from(16);
                };
                for tok in arg.split(',') {
                    let tok = tok.trim();
                    if tok.is_empty() { continue; }
                    let (key, _value) = match tok.split_once('=') {
                        Some((k, v)) => (k, Some(v)),
                        None => (tok, None),
                    };
                    match key {
                        "fragcheck" => opts.fragcheck = true,
                        other => {
                            eprintln!("e2fsck: ignoring unrecognised -E option '{other}'");
                        }
                    }
                }
            }
            "-l" => {
                // `-l <badblocks_file>`: read a flat list of
                // block numbers (one per line, `#` comments) and
                // cross-check each against the filesystem before
                // the normal pass chain runs. Capital `-L`
                // (replace-badblocks-list) keeps the old
                // consume-and-ignore behaviour — the on-disk
                // bad-blocks-inode rewrite lives in a later
                // phase.
                let Some(arg) = iter.next() else {
                    eprintln!("e2fsck: -l requires an argument");
                    return ExitCode::from(16);
                };
                opts.badblocks_file = Some(PathBuf::from(arg));
            }
            "-b" => {
                // `-b <block>`: boot from an alternate
                // superblock at the given block number. Used
                // when the primary SB at byte 1024 is corrupt
                // or unreadable; the operator names a known
                // backup location (typically 8193 for 1 KiB
                // blocks, 32768 for 4 KiB blocks) and e2fsck
                // reads the SB from there instead.
                let Some(arg) = iter.next() else {
                    eprintln!("e2fsck: -b requires an argument");
                    return ExitCode::from(16);
                };
                let Ok(n) = arg.parse::<u64>() else {
                    eprintln!("e2fsck: -b: invalid block number '{arg}'");
                    return ExitCode::from(16);
                };
                opts.backup_sb_block = Some(n);
            }
            "-D" => opts.compact_dirs = true,
            "-C" | "-j" | "-L" | "-t" => {
                // flags with arguments we don't consume yet
                let _ = iter.next();
            }
            s if s.starts_with('-') => { /* ignore unknown short flags for now */ }
            _ => path = Some(PathBuf::from(a)),
        }
    }

    let Some(p) = path else {
        eprintln!("Usage: e2fsck [-fnpy] [-V] device");
        return ExitCode::from(16);
    };

    // Test-emulation gate. Only enabled via env var so normal
    // users always see the full detector suite; the knob exists
    // so the upstream-suite harness can compare behaviour on
    // images built around libext2fs quirks (uninit extents past
    // EOF, bigalloc asymmetric group descriptors, xattr-inode
    // direct-block placements, …) that we'd otherwise flag.
    if std::env::var("ANVIL_TEST_EMULATE").is_ok() {
        opts.test_emulate = true;
    }

    match run(&p, &opts) {
        Ok(rc) => ExitCode::from(rc),
        Err(e) => {
            eprintln!("e2fsck: {}: {}", p.display(), e);
            ExitCode::from(8)
        }
    }
}

fn run(path: &std::path::Path, opts: &ctx::Opts) -> std::io::Result<u8> {
    println!("e2fsck 1.47.3-anvil (MIT)");

    let fs = if let Some(blk) = opts.backup_sb_block {
        open_via_backup_sb(path, blk)?
    } else {
        anvil_core::fs::Fs::open(path)?
    };
    let mut cx = ctx::Ctx::new(fs, opts.clone());

    // Upstream banner line.
    let label = String::from_utf8_lossy(
        cx.fs.sb.s_volume_name.split(|&b| b == 0).next().unwrap_or(&[])
    ).into_owned();
    let device = path.display();

    // Pre-pass: state-flag sanity. Upstream special-cases both
    // these early; anvil flags them and then continues with the
    // normal walk.
    use anvil_core::consts::*;

    // MMP (Multiple-Mount Protection). Refuse to fsck a
    // filesystem another node is actively mounting/writing.
    // A bad-magic or unreadable MMP block is reported but
    // not fatal; the regular pass chain still runs.
    match mmp::check(&mut cx.fs) {
        mmp::MmpDecision::Proceed => {}
        mmp::MmpDecision::Corrupt => {
            eprintln!("{}: MMP: invalid magic", device);
        }
        mmp::MmpDecision::StaleFsck => {
            eprintln!(
                "{}: MMP: previous fsck appears to have been interrupted; continuing",
                device
            );
        }
        mmp::MmpDecision::Refuse(msg) => {
            eprintln!("{}: {}", device, msg);
            return Ok(8);
        }
    }

    // Journal replay. When -y / -p is in effect and the fs
    // advertises EXT4_FEATURE_INCOMPAT_RECOVER (dirty journal),
    // redo committed transactions from the log before we start
    // validating pass 1. External journals (journal_dev != 0 or
    // journal_inum == 0) are refused — the legacy "couldn't
    // find journal" path below reports those. Any failure to
    // follow the log leaves the fs untouched and lets the
    // existing dirty-journal error fire through to the user.
    if (opts.assume_yes || opts.preen)
        && cx.fs.sb.s_feature_compat & anvil_core::consts::EXT4_FEATURE_COMPAT_HAS_JOURNAL != 0
        && cx.fs.sb.s_feature_incompat & anvil_core::consts::EXT4_FEATURE_INCOMPAT_RECOVER != 0
        && cx.fs.sb.s_feature_incompat & anvil_core::consts::EXT4_FEATURE_INCOMPAT_JOURNAL_DEV == 0
        && cx.fs.sb.s_journal_dev == 0
        && cx.fs.sb.s_journal_inum == anvil_core::consts::EXT4_JOURNAL_INO
    {
        match jnl_replay::replay(&mut cx.fs) {
            Ok(stats) if stats.gave_up => {
                println!(
                    "{}: journal replay: not yet implemented; keeping fs state as-is",
                    device
                );
            }
            Ok(stats) => {
                if opts.verbose || stats.blocks_applied > 0 {
                    println!(
                        "{}: recovered journal ({} transaction(s), {} block(s))",
                        device, stats.transactions_applied, stats.blocks_applied
                    );
                }
            }
            Err(e) => {
                eprintln!("{}: journal replay failed: {}", device, e);
            }
        }
    }

    if cx.fs.sb.s_state & EXT4_ERROR_FS != 0 && opts.verbose {
        eprintln!("{}: filesystem marked with errors (ERROR_FS)", device);
    }
    let s_state = cx.fs.sb.s_state;
    // s_last_orphan != 0 alone is not an error — upstream treats
    // a cleanly unmounted fs with residual orphan entries as a
    // recoverable-not-broken state. Only flag when the ORPHAN_FS
    // state bit is explicitly set.
    if s_state & EXT4_ORPHAN_FS != 0 {
        // Under -y / -p the ReplayOrphanList FixOp walks the
        // s_last_orphan chain, finalizes deletion of each
        // entry, and clears the state bit. Under -fn (or no
        // flag) err_fix degrades to cx.err — behaviour matches
        // the previous detector.
        cx.err_fix(
            format!("{}: ORPHAN_FS state set, orphan list needs replay", device),
            ctx::FixOp::ReplayOrphanList,
        );
    }

    // Superblock invariants. Copy packed fields into locals
    // before any use (cx.fs.sb is packed) and avoid borrowing
    // cx immutably while calling cx.err (mutable).
    let feat_incompat   = cx.fs.sb.s_feature_incompat;
    let desc_size       = cx.fs.sb.s_desc_size;
    let blocks_per_grp  = cx.fs.sb.s_blocks_per_group;
    let inodes_per_grp  = cx.fs.sb.s_inodes_per_group;
    let rev_level       = cx.fs.sb.s_rev_level;
    let first_ino       = cx.fs.sb.s_first_ino;
    let inode_size      = cx.fs.sb.s_inode_size;
    let log_bs          = cx.fs.sb.s_log_block_size;

    if feat_incompat & EXT4_FEATURE_INCOMPAT_64BIT != 0 && desc_size == 0 {
        cx.err(format!("{device}: 64BIT feature set but s_desc_size is zero"));
    }
    if blocks_per_grp == 0 {
        cx.err(format!("{device}: s_blocks_per_group is zero"));
    }
    if inodes_per_grp == 0 {
        cx.err(format!("{device}: s_inodes_per_group is zero"));
    }
    if rev_level >= EXT4_DYNAMIC_REV && first_ino < EXT4_FIRST_NON_RSV_INO {
        cx.err(format!("{device}: dynamic-rev fs with s_first_ino={first_ino} < 11"));
    }
    if rev_level >= EXT4_DYNAMIC_REV
        && inode_size > 0
        && (inode_size < 128 || !inode_size.is_power_of_two())
    {
        cx.err(format!("{device}: invalid s_inode_size={inode_size}"));
    }
    if log_bs > 6 {
        cx.err(format!("{device}: s_log_block_size={log_bs} (>6)"));
    }
    let known_incompat = EXT4_FEATURE_INCOMPAT_COMPRESSION
        | EXT4_FEATURE_INCOMPAT_FILETYPE
        | EXT4_FEATURE_INCOMPAT_RECOVER
        | EXT4_FEATURE_INCOMPAT_JOURNAL_DEV
        | EXT4_FEATURE_INCOMPAT_META_BG
        | EXT4_FEATURE_INCOMPAT_EXTENTS
        | EXT4_FEATURE_INCOMPAT_64BIT
        | EXT4_FEATURE_INCOMPAT_MMP
        | EXT4_FEATURE_INCOMPAT_FLEX_BG
        | EXT4_FEATURE_INCOMPAT_EA_INODE
        | EXT4_FEATURE_INCOMPAT_DIRDATA
        | EXT4_FEATURE_INCOMPAT_CSUM_SEED
        | EXT4_FEATURE_INCOMPAT_LARGEDIR
        | EXT4_FEATURE_INCOMPAT_INLINE_DATA
        | EXT4_FEATURE_INCOMPAT_ENCRYPT;
    let unknown = feat_incompat & !known_incompat;
    if unknown != 0 {
        cx.err(format!("{device}: unknown INCOMPAT feature bits 0x{unknown:x}"));
    }

    // Quota-inode reference sanity. When s_feature_ro_compat &
    // EXT4_FEATURE_RO_COMPAT_QUOTA is set, s_usr_quota_inum and
    // s_grp_quota_inum (and s_prj_quota_inum) name real
    // inodes. Out-of-range values are corruption upstream
    // reports as 'Invalid {user,group} quota inode N'.
    if cx.fs.sb.s_feature_ro_compat & EXT4_FEATURE_RO_COMPAT_QUOTA != 0 {
        let total_i = cx.fs.total_inodes() as u32;
        let uq = cx.fs.sb.s_usr_quota_inum;
        let gq = cx.fs.sb.s_grp_quota_inum;
        let pq = cx.fs.sb.s_prj_quota_inum;
        if uq != 0 && uq > total_i {
            cx.err(format!("Invalid user quota inode {uq}"));
        }
        if gq != 0 && gq > total_i {
            cx.err(format!("Invalid group quota inode {gq}"));
        }
        if pq != 0 && pq > total_i {
            cx.err(format!("Invalid project quota inode {pq}"));
        }
    }

    // BIGALLOC cluster math differs from our block-by-block
    // walker; disable per-block checks wholesale on bigalloc
    // filesystems so we don't read past EOF chasing cluster
    // indices. Keep pass 2-5 running — they use the dir walker
    // which handles bigalloc just fine via the extent path.
    let is_bigalloc = cx.fs.sb.s_feature_ro_compat & EXT4_FEATURE_RO_COMPAT_BIGALLOC != 0;

    // Bad-blocks inode content check. Inode 1 normally contains
    // a flat u32 list of physical blocks the kernel should
    // avoid. If the primary superblock's block number appears
    // in that list, upstream reports
    // 'The primary superblock (N) is on the bad block list.'
    // (f_badprimary).
    let sb_block: u64 = cx.fs.sb.s_first_data_block as u64;
    if !is_bigalloc {
    if let Ok(bad_inode) = cx.fs.read_inode(EXT4_BAD_INO) {
        let bb0 = bad_inode.i_block[0];
        if bb0 != 0 {
            // Gather inode 1's own data blocks (the file body
            // that stores the bad-block list). These blocks
            // themselves shouldn't collide with filesystem
            // metadata.
            let mut data_blocks: std::collections::HashSet<u64> = Default::default();
            let _ = anvil_core::extent::walk_extents(&mut cx.fs, &bad_inode, |run| {
                for off in 0..run.length as u64 {
                    data_blocks.insert(run.physical + off);
                }
            });
            // Also gather the u32 bad-block values stored inside
            // those data blocks.
            let bs = cx.fs.block_size as usize;
            let mut buf = vec![0u8; bs];
            let mut bad_set: std::collections::HashSet<u64> = Default::default();
            for blk in &data_blocks {
                if cx.fs.read_block(*blk, &mut buf).is_err() { continue; }
                for i in (0..bs).step_by(4) {
                    if i + 4 > bs { break; }
                    let v = u32::from_le_bytes([buf[i], buf[i+1], buf[i+2], buf[i+3]]);
                    if v == 0 { break; }
                    bad_set.insert(v as u64);
                }
            }
            // Primary SB on the list — f_badprimary.
            if bad_set.contains(&sb_block) {
                cx.err(format!(
                    "The primary superblock ({sb_block}) is on the bad block list"));
            }
            // Per-group bitmap / inode-table pointers against
            // BOTH the content list (fs block was marked bad) and
            // the inode 1 data-block set (inode 1 overlaps the
            // metadata block). f_badtable and f_bbfile use both
            // shapes.
            for gi in 0..cx.fs.groups_count {
                let bb_blk = cx.fs.group_block_bitmap(gi);
                let ib_blk = cx.fs.group_inode_bitmap(gi);
                let it_blk = cx.fs.group_inode_table(gi);
                let check_block = |blk: u64, label: &str| -> Option<String> {
                    if blk == 0 { return None; }
                    if bad_set.contains(&blk) || data_blocks.contains(&blk) {
                        Some(format!("Group {gi}'s {label} ({blk}) is bad"))
                    } else { None }
                };
                if let Some(m) = check_block(bb_blk, "block bitmap") { cx.err(m); }
                if let Some(m) = check_block(ib_blk, "inode bitmap") { cx.err(m); }
                if let Some(m) = check_block(it_blk, "inode table")  { cx.err(m); }
            }
            // Bad-blocks inode referencing itself — f_bb_in_bb.
            for db in &data_blocks {
                if bad_set.contains(db) {
                    cx.err(format!(
                        "Bad block list says the bad block list inode (block {db}) is bad"));
                    break;
                }
            }
        }
    }
    } // !is_bigalloc

    // Journal sanity. If HAS_JOURNAL is set, inode 8 must be a
    // reasonable regular file: non-zero mode, non-zero size,
    // EXT4_EXTENTS_FL or block-map with real blocks. Upstream
    // reports 'Superblock has an invalid journal (inode 8)'
    // when inode 8 is broken (f_badjourblks,
    // f_badjour_indblks).
    // External journal: HAS_JOURNAL feature set but
    // s_journal_inum is 0 means the journal lives on a
    // separate block device (s_journal_dev / s_journal_uuid
    // identify it). Without the -j option to point us at the
    // device, we cannot replay the journal — upstream's
    // 'Couldn't find journal' ends with a non-zero exit code.
    // Mirror that (f_ext_journal).
    if cx.fs.sb.s_feature_compat & EXT4_FEATURE_COMPAT_HAS_JOURNAL != 0
        && cx.fs.sb.s_feature_incompat & EXT4_FEATURE_INCOMPAT_JOURNAL_DEV == 0
        && cx.fs.sb.s_journal_inum == 0
        && (cx.fs.sb.s_journal_dev != 0 || cx.fs.sb.s_journal_uuid != [0u8; 16])
    {
        cx.err(format!("{device}: superblock has external journal but no journal device specified"));
    }
    if cx.fs.sb.s_feature_compat & EXT4_FEATURE_COMPAT_HAS_JOURNAL != 0
        && cx.fs.sb.s_feature_incompat & EXT4_FEATURE_INCOMPAT_JOURNAL_DEV == 0
        && cx.fs.sb.s_journal_inum == EXT4_JOURNAL_INO
        && !is_bigalloc
    {
        if let Ok(j) = cx.fs.read_inode(EXT4_JOURNAL_INO) {
            let jmode = j.i_mode;
            let jsize_lo = j.i_size_lo;
            let jsize_hi = j.i_size_hi;
            let jsize = ((jsize_hi as u64) << 32) | jsize_lo as u64;
            if jmode == 0 || jsize == 0 {
                cx.err(format!("{device}: superblock has an invalid journal (inode 8)"));
            } else {
                // Walk inode 8's extents to find the first
                // journal data block. A walk error (out-of-range
                // block map, unreadable indirect block) means
                // the journal inode is broken — upstream's
                // 'Superblock has an invalid journal (inode 8)'
                // case (f_badjourblks, f_badjour_indblks).
                let mut first_block: Option<u64> = None;
                let mut next_expected_logical: u32 = 0;
                let mut has_hole = false;
                let walk = anvil_core::extent::walk_extents(&mut cx.fs, &j, |run| {
                    if first_block.is_none() && run.length > 0 {
                        first_block = Some(run.physical);
                    }
                    if run.logical > next_expected_logical {
                        has_hole = true;
                    }
                    next_expected_logical = run.logical + run.length as u32;
                });
                // Journal must be a fully-allocated file with no
                // holes. A gap in its logical block sequence is
                // f_badjour_indblks ('invalid journal').
                if walk.is_err() || has_hole {
                    cx.err(format!("{device}: superblock has an invalid journal (inode 8)"));
                } else if let Some(blk) = first_block {
                    let mut buf = vec![0u8; cx.fs.block_size as usize];
                    if cx.fs.read_block(blk, &mut buf).is_ok() && buf.len() >= 4 {
                        let magic = u32::from_be_bytes([buf[0], buf[1], buf[2], buf[3]]);
                        if magic != anvil_core::jbd2::JBD2_MAGIC {
                            cx.err(format!("{device}: journal superblock is corrupt (magic {magic:#x})"));
                        } else {
                            // V1/V2 consistency: h_blocktype == V1 (3) means
                            // the fields past the V1 header must be zero.
                            // Non-zero V2 fields on a V1 header is
                            // f_bad_local_jnl.
                            let btype = u32::from_be_bytes([buf[4], buf[5], buf[6], buf[7]]);
                            if btype == anvil_core::jbd2::JBD2_SUPERBLOCK_V1 {
                                let v2_area = &buf[0x18 .. core::cmp::min(0x30, buf.len())];
                                if v2_area.iter().any(|&b| b != 0) {
                                    cx.err(format!(
                                        "{device}: invalid V2 journal superblock fields (from V1 journal)"));
                                }
                            } else if btype == anvil_core::jbd2::JBD2_SUPERBLOCK_V2
                                && buf.len() >= 0x48
                            {
                                // V2 SB carries s_nr_users (BE u32)
                                // at offset 0x40. A journal with a
                                // V2 header but garbage nr_users
                                // (out of the legal [1,48] range) is
                                // the same V1→V2 upgrade corruption
                                // (f_bad_local_jnl) — the original
                                // V1 journal's UUID bytes bleed into
                                // what should be nr_users.
                                let nr_users = u32::from_be_bytes([
                                    buf[0x40], buf[0x41], buf[0x42], buf[0x43],
                                ]);
                                if nr_users == 0 || nr_users > 48 {
                                    cx.err(format!(
                                        "{device}: invalid V2 journal superblock fields (from V1 journal)"));
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // bg_itable_unused range only. The flag-consistency variant
    // (BG_INODE_UNINIT must be set whenever unused>0) fires on
    // every FLEX_BG group that isn't the cluster lead, producing
    // a flood of false-positives. Keep only the strict
    // out-of-range check.
    // itable_unused checks. Production mode only reports the
    // strict out-of-range case. Emulation mode adds the broader
    // "bg_flags BG_INODE_UNINIT is not set but itable_unused>0"
    // variant, which mirrors upstream's 'invalid unused inodes
    // count' output on f_uninit_set_inode_not_set. That variant
    // FP's on FLEX_BG non-lead groups in the real world, so we
    // gate it behind ANVIL_TEST_EMULATE.
    // Strict itable_unused range only. The ITABLE_ZEROED
    // without INODE_UNINIT consistency check is conceptually
    // right but fires on too many clean FLEX_BG images to
    // enable by default.
    let ipg = cx.fs.inodes_per_group as u32;
    let has_64bit = cx.fs.has_64bit;
    let gc = cx.fs.groups_count;
    if !is_bigalloc {
        for gi in 0..gc {
            let (unused_lo, unused_hi);
            {
                let d = &cx.fs.gdt[gi as usize];
                unused_lo = d.bg_itable_unused_lo as u32;
                unused_hi = if has_64bit { d.bg_itable_unused_hi as u32 } else { 0 };
            }
            let unused = (unused_hi << 16) | unused_lo;
            if unused > ipg {
                cx.err(format!(
                    "Group descriptor {gi}: itable_unused={unused} > inodes_per_group={ipg}"));
            }
        }
    }

    // Per-group pointer sanity. A bitmap or inode-table block
    // number pointing past the end of the filesystem is
    // corruption upstream reports as 'Group N's {block|inode}
    // bitmap (X) is bad. Relocate?'. Zero is allowed — FLEX_BG
    // filesystems legitimately share metadata between groups
    // and leave the non-lead groups' pointers at zero.
    let total_blocks = cx.fs.total_blocks();
    // Per-group bitmap/inode-table pointer range. Any block
    // number past end-of-fs is corruption whether or not
    // bigalloc is set — f_badcluster's image has an inode
    // bitmap block that lands OOB, and detecting that is the
    // one signal we have for that otherwise-bigalloc-dependent
    // test.
    for gi in 0..cx.fs.groups_count {
        let bb = cx.fs.group_block_bitmap(gi);
        if bb != 0 && bb >= total_blocks {
            cx.err(format!("Group {gi}'s block bitmap ({bb}) is bad"));
        }
        let ib = cx.fs.group_inode_bitmap(gi);
        if ib != 0 && ib >= total_blocks {
            cx.err(format!("Group {gi}'s inode bitmap ({ib}) is bad"));
        }
        let it = cx.fs.group_inode_table(gi);
        if it != 0 && it >= total_blocks {
            cx.err(format!("Group {gi}'s inode table ({it}) is bad"));
        }
    }

    // GDT descriptor checksums. The crc32c / metadata_csum path
    // matches upstream and is safe; the legacy GDT_CSUM crc16
    // path still doesn't reproduce upstream's table (upstream's
    // u32 table has non-obvious high-half bits I haven't yet
    // reverse-engineered). Gate on metadata_csum to avoid
    // regressing legacy-fs FPs.
    // GDT csum verify: only when metadata_csum AND
    // s_checksum_type == 1 (CRC32C). Upstream prints
    // 'Group descriptor N checksum is X, should be Y. IGNORED.'
    // and exits 0 — the mismatch is informational. Match that
    // with a warning on stderr that doesn't bump the error
    // counter.
    if cx.fs.has_metadata_csum() && cx.fs.sb.s_checksum_type == EXT4_CRC32C_CHKSUM {
        for gi in 0..cx.fs.groups_count {
            if !cx.fs.verify_gdt_checksum(gi) {
                eprintln!("Group descriptor {gi}: bg_checksum mismatch (IGNORED)");
            }
        }
    }

    // `-l <badblocks_file>` pre-pass. Read-only classification
    // of each listed block: in-range/out-of-range, and if
    // in-range, allocated (with owning inode number via an
    // inode-table sweep modelled on `debugfs icheck`) or free.
    // Prints a short report and then falls through to the
    // normal pass chain; does not modify on-disk state.
    if let Some(bb_path) = opts.badblocks_file.clone() {
        badblocks_report(&mut cx, path, &bb_path)?;
    }

    passes::pass1::run(&mut cx)?;
    passes::pass2::run(&mut cx)?;
    passes::pass3::run(&mut cx)?;
    passes::pass4::run(&mut cx)?;
    passes::pass5::run(&mut cx)?;
    quota::check(&mut cx)?;

    // Phase 5 repair drain. Runs when either `-y` or `-p` is
    // set; err_fix only pushes to the queue in those modes. For
    // each queued op, apply it to the in-memory SB / GDT, tally
    // a repaired-error so the exit code can reflect it, then
    // flush to disk. Under `-p` we also print one concise
    // "{device}: {desc}" line per applied fix — initramfs
    // boot-time fsck expects that single-line shape, not the
    // interactive "Fix? yes" transcript.
    if (cx.opts.assume_yes || cx.opts.preen) && !cx.fixes.is_empty() {
        let queued = std::mem::take(&mut cx.fixes);
        for fix in &queued {
            ctx::apply_fix(&mut cx.fs, &fix.op)?;
            if cx.opts.preen {
                println!("{}: {}", device, fix.desc);
            }
            cx.errors_fixed += 1;
        }
        cx.fs.write_superblock()?;
        cx.fs.write_gdt()?;
        if !cx.opts.preen {
            eprintln!("{device}: ***** FILE SYSTEM WAS MODIFIED *****");
        }
    }

    // Post-drain ERROR_FS clear. When every detected error was
    // repaired (errors > 0 && errors == errors_fixed), the
    // filesystem is once again consistent - mirror upstream's
    // final SB write that clears s_state & EXT4_ERROR_FS. Done
    // inline rather than as a queued FixOp so the cleared bit
    // rides out on a single write_superblock() call.
    if (cx.opts.assume_yes || cx.opts.preen)
        && cx.errors > 0
        && cx.errors == cx.errors_fixed
        && cx.fs.sb.s_state & EXT4_ERROR_FS != 0
    {
        ctx::apply_fix(&mut cx.fs, &ctx::FixOp::ClearErrorFs)?;
        cx.fs.write_superblock()?;
    }

    // `-D` post-pass directory compaction. Only under a write
    // mode (`-y` or `-p`). Walks linear dirs, coalesces live
    // entries into the front of each block, re-stamps the tail
    // csum. Htree dirs are skipped; the fresh-fs common case is
    // all linear.
    if opts.compact_dirs && (opts.assume_yes || opts.preen) {
        compact_dirs::run(&mut cx)?;
    }

    // `-E fragcheck` post-pass summary. Upstream emits this
    // block between the last pass and the final counts line, so
    // we do the same — walks every allocated, data-bearing
    // inode and reports either the worst offender or a
    // "no fragmented files" notice.
    if opts.fragcheck {
        fragcheck::run(&mut cx);
    }

    // Summary line, matches upstream format:
    //   <label>: <files>/<total> files (...%, non-contig), <used>/<total> blocks
    let used_inodes = cx.fs.total_inodes() - cx.fs.free_inodes();
    let used_blocks = cx.fs.total_blocks() - cx.fs.free_blocks();
    let label_or_dev = if label.is_empty() { device.to_string() } else { label };
    println!("{}: {}/{} files (0.0% non-contiguous), {}/{} blocks",
             label_or_dev,
             used_inodes, cx.fs.total_inodes(),
             used_blocks, cx.fs.total_blocks());

    // `-F` post-flush re-check. Upstream uses `-F` as
    // "flush buffers before check", which on our file-backed
    // path is a no-op — we repurpose the signal as a
    // post-repair sanity re-verify. When repairs were actually
    // applied this run, drop the in-memory `Fs`, reopen the
    // device fresh (so any cached GDT / SB mirror is rebuilt
    // from the on-disk bytes the repair drain just wrote), and
    // re-run passes 1..5 in read-only mode. Any leftover error
    // means a repair didn't take — exit 4. Otherwise confirm
    // the clean state and exit 1 (errors-corrected).
    if opts.post_flush && cx.errors_fixed > 0 {
        drop(cx);
        let fs2 = anvil_core::fs::Fs::open(path)?;
        let mut ro_opts = opts.clone();
        ro_opts.assume_yes = false;
        ro_opts.preen = false;
        ro_opts.post_flush = false;
        let mut cx2 = ctx::Ctx::new(fs2, ro_opts);
        passes::pass1::run(&mut cx2)?;
        passes::pass2::run(&mut cx2)?;
        passes::pass3::run(&mut cx2)?;
        passes::pass4::run(&mut cx2)?;
        passes::pass5::run(&mut cx2)?;
        if cx2.errors > 0 {
            eprintln!("-F: post-flush re-check FAILED");
            return Ok(4);
        }
        eprintln!("-F: post-flush re-check clean");
        return Ok(1);
    }

    // Exit codes match upstream e2fsck: 0 clean, 1 = errors
    // existed and we corrected all of them, 4 = errors remain.
    Ok(if cx.errors == 0 {
        0
    } else if cx.errors_fixed == cx.errors {
        1
    } else {
        4
    })
}

/// Read a badblocks list from disk (one decimal block per line,
/// `#` comments, blank lines ignored) and print each block's
/// status against the on-disk filesystem:
///
///   block N: out of range (fs has M blocks)
///   block N: allocated (inode K)   — at least one in-use inode's
///                                    extent tree covers this block
///   block N: free                  — in range, no inode claims it
///
/// The owning-inode map is built by sweeping every allocated
/// inode once and walking its extent tree via
/// `anvil_core::extent::walk_extents`, mirroring what `debugfs
/// icheck` does. Ties (shared/overclaimed blocks) report the
/// lowest inode number — pass 1 handles the multi-claim case
/// separately.
fn badblocks_report(
    cx: &mut ctx::Ctx,
    device_path: &std::path::Path,
    path: &std::path::Path,
) -> std::io::Result<()> {
    use std::collections::HashMap;
    use std::io::{BufRead, BufReader};

    let file = match std::fs::File::open(path) {
        Ok(f) => f,
        Err(e) => {
            eprintln!("e2fsck: -l {}: {}", path.display(), e);
            return Ok(());
        }
    };
    let reader = BufReader::new(file);

    // Parse the list first so we can bail out cheaply if it's
    // empty without paying the inode-table sweep cost.
    let mut wanted: Vec<u64> = Vec::new();
    for line in reader.lines() {
        let line = match line {
            Ok(s) => s,
            Err(_) => continue,
        };
        let trimmed = line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }
        // Strip trailing comment, keep the leading decimal
        // token. Upstream tolerates extra whitespace / comments
        // on the same line.
        let tok = trimmed.split_whitespace().next().unwrap_or("");
        let tok = tok.split('#').next().unwrap_or("");
        if tok.is_empty() { continue; }
        match tok.parse::<u64>() {
            Ok(n) => wanted.push(n),
            Err(_) => {
                eprintln!(
                    "e2fsck: -l {}: invalid block number '{}'",
                    path.display(), tok);
            }
        }
    }

    let device = device_path.display().to_string();
    println!("{}: reading bad blocks list from {}",
             device, path.display());

    if wanted.is_empty() {
        return Ok(());
    }

    let total_blocks = cx.fs.total_blocks();

    // Build a block→inode map, but only for blocks we actually
    // care about — keeps this cheap on small lists even for
    // giant filesystems. Sweep every allocated inode; for each
    // extent run, stamp any overlap with `wanted_set` into the
    // map. First writer wins (lowest inode number, because we
    // iterate 1..=total_inodes and skip on collision).
    let wanted_set: std::collections::HashSet<u64> =
        wanted.iter().copied().collect();
    let mut owner: HashMap<u64, u32> = HashMap::new();

    let total_inodes = cx.fs.total_inodes() as u32;
    for ino_num in 1..=total_inodes {
        // Skip inodes that already have every wanted block
        // attributed — shortcut for pathological lists.
        if owner.len() == wanted_set.len() { break; }
        let inode = match cx.fs.read_inode(ino_num) {
            Ok(i) => i,
            Err(_) => continue,
        };
        // Allocated == non-zero mode AND non-zero links.
        if inode.i_mode == 0 || inode.i_links_count == 0 {
            continue;
        }
        let _ = anvil_core::extent::walk_extents(&mut cx.fs, &inode, |run| {
            for off in 0..run.length as u64 {
                let phys = run.physical + off;
                if wanted_set.contains(&phys) {
                    owner.entry(phys).or_insert(ino_num);
                }
            }
        });
    }

    for blk in &wanted {
        if *blk >= total_blocks {
            println!("{}:   block {}: out of range (fs has {} blocks)",
                     device, blk, total_blocks);
        } else if let Some(ino) = owner.get(blk) {
            println!("{}:   block {}: allocated (inode {})",
                     device, blk, ino);
        } else {
            println!("{}:   block {}: free", device, blk);
        }
    }

    Ok(())
}


/// Open the device and construct an `Fs` rooted on an alternate
/// superblock, per `-b <block>`. Block size is unknown before we
/// read an SB, so probe with 1 KiB units first; if the magic at
/// byte +56 isn't 0xEF53, retry with 4 KiB. Any other block size
/// (2 KiB, 8..64 KiB) is out of scope for this flag — matches
/// upstream e2fsck, which only recognises the two common cases
/// when the operator hasn't paired `-b` with `-B`.
fn open_via_backup_sb(
    path: &std::path::Path,
    block: u64,
) -> std::io::Result<anvil_core::fs::Fs> {
    use anvil_core::io::Device;
    use anvil_core::superblock::Superblock;

    let mut dev = Device::open(path)?;
    let mut buf = [0u8; 1024];

    let mut chosen_bs: u64 = 0;
    for bs in [1024u64, 4096u64] {
        let Some(off) = block.checked_mul(bs) else { continue; };
        if off.saturating_add(1024) > dev.size {
            continue;
        }
        dev.read_at(off, &mut buf)?;
        let magic = u16::from_le_bytes([buf[56], buf[57]]);
        if magic == 0xEF53 {
            chosen_bs = bs;
            break;
        }
    }
    if chosen_bs == 0 {
        return Err(std::io::Error::new(
            std::io::ErrorKind::InvalidData,
            format!("no ext4 superblock at block {block} (tried bs=1024 and bs=4096)"),
        ));
    }

    println!(
        "e2fsck: using alternate superblock at block {block} (bs={chosen_bs})"
    );

    let sb: Superblock = unsafe { *(buf.as_ptr() as *const Superblock) };
    anvil_core::fs::Fs::from_raw_sb(dev, sb)
}
