//! Helpers for the -y orphan-list replay path in ctx.rs. Each
//! function edits exactly one on-disk structure (bitmap block,
//! group descriptor, superblock counter) and leaves the
//! in-memory mirror in sync so main.rs's trailing
//! `write_superblock` / `write_gdt` pick up the updated values.
//!
//! Why a separate module: the replay needs to read a bitmap
//! block, flip individual bits, recompute the metadata_csum the
//! GDT pins against that bitmap, and write the block back. That
//! is three round-trips and a csum recompute per bitmap — too
//! much to inline inside the FixOp match.

use anvil_core::bitmap;
use anvil_core::fs::Fs;
use anvil_core::inode::Inode;
use std::io;

/// Walk the orphan inode's data blocks via the extent tree and
/// clear each one in its owning group's block bitmap. Bumps
/// `*freed` by the number of newly-freed blocks so the caller
/// can adjust the SB-wide free counter once at the end.
pub fn walk_and_free_blocks(
    fs: &mut Fs,
    ino: &Inode,
    freed: &mut u64,
) -> io::Result<()> {
    // Collect first — the extent walker borrows &mut Fs for the
    // duration of its callback, and we need the borrow back to
    // edit bitmap blocks per freed extent.
    let mut runs: Vec<(u64, u16)> = Vec::new();
    let _ = anvil_core::extent::walk_extents(fs, ino, |run| {
        if run.length > 0 {
            runs.push((run.physical, run.length));
        }
    });

    for (phys_start, length) in runs {
        for off in 0..length as u64 {
            let blk = phys_start + off;
            if blk == 0 { continue; }
            if free_one_block(fs, blk)? {
                *freed += 1;
            }
        }
    }

    Ok(())
}

/// Clear one physical block in its owning group's bitmap,
/// recompute the bitmap csum, update bg_free_blocks, and write
/// everything back. Returns true when the bit transitioned
/// from set→clear (so the caller knows to bump free_blocks).
fn free_one_block(fs: &mut Fs, blk: u64) -> io::Result<bool> {
    // Group ownership: blocks_per_group is the stride from
    // first_data_block. A block before first_data_block (the
    // boot sector on 1k-blocksize fs) can't be owned — skip.
    let fdb = fs.sb.s_first_data_block as u64;
    if blk < fdb { return Ok(false); }
    let group = (blk - fdb) / fs.blocks_per_group;
    let idx_in_group = ((blk - fdb) % fs.blocks_per_group) as usize;
    if group >= fs.groups_count { return Ok(false); }

    let bmap_blk = fs.group_block_bitmap(group);
    if bmap_blk == 0 { return Ok(false); }

    let bs = fs.block_size as usize;
    let mut buf = vec![0u8; bs];
    fs.read_block(bmap_blk, &mut buf)?;

    // Only bump the free counter when the bit was actually
    // set. A chain with two orphans pointing at overlapping
    // blocks would otherwise over-credit the SB.
    let was_set = bitmap::test_bit(&buf, idx_in_group);
    if !was_set { return Ok(false); }

    bitmap::clear_bit(&mut buf, idx_in_group);

    // Recompute and stash the bitmap csum. The block-bitmap
    // csum covers the whole bitmap block. Only update when
    // metadata_csum is on; legacy fs has no field to store it.
    if fs.has_metadata_csum() {
        let seed = fs.csum_seed();
        let full = anvil_core::crc::crc32c_cont(seed, &buf);
        let has_64bit = fs.has_64bit;
        let desc_size = fs.desc_size;
        let d = &mut fs.gdt[group as usize];
        d.bg_block_bitmap_csum_lo = full as u16;
        if has_64bit && desc_size >= 0x3A {
            d.bg_block_bitmap_csum_hi = (full >> 16) as u16;
        }
    }

    // Write the bitmap block back.
    let bs_u64 = fs.block_size;
    fs.dev.write_at(bmap_blk * bs_u64, &buf)?;

    // bg_free_blocks++. In-memory GDT is what main.rs's
    // write_gdt will flush.
    {
        let d = &mut fs.gdt[group as usize];
        let lo = d.bg_free_blocks_count_lo as u32;
        let hi = if fs.has_64bit { d.bg_free_blocks_count_hi as u32 } else { 0 };
        let n = ((hi << 16) | lo).saturating_add(1);
        d.set_free_blocks(n);
    }

    Ok(true)
}

/// Clear `ino_num`'s bit in its owning group's inode bitmap,
/// recompute the inode-bitmap csum, bump bg_free_inodes and
/// s_free_inodes_count.
pub fn clear_inode_bitmap_bit(fs: &mut Fs, ino_num: u32) -> io::Result<()> {
    if ino_num == 0 || ino_num as u64 > fs.sb.s_inodes_count as u64 {
        return Ok(());
    }
    let group = (ino_num as u64 - 1) / fs.inodes_per_group;
    let idx_in_group = ((ino_num as u64 - 1) % fs.inodes_per_group) as usize;
    let bmap_blk = fs.group_inode_bitmap(group);
    if bmap_blk == 0 { return Ok(()); }

    let bs = fs.block_size as usize;
    let mut buf = vec![0u8; bs];
    fs.read_block(bmap_blk, &mut buf)?;

    let was_set = bitmap::test_bit(&buf, idx_in_group);
    bitmap::clear_bit(&mut buf, idx_in_group);

    // Inode-bitmap csum covers only the bytes that cover the
    // real inodes in the group (ceil(ipg / 8)), mirroring
    // upstream's ext2fs_inode_bitmap_csum_set size argument.
    if fs.has_metadata_csum() {
        let seed = fs.csum_seed();
        let bytes_used = ((fs.inodes_per_group + 7) / 8) as usize;
        let sz = core::cmp::min(bytes_used, buf.len());
        let full = anvil_core::crc::crc32c_cont(seed, &buf[..sz]);
        let has_64bit = fs.has_64bit;
        let desc_size = fs.desc_size;
        let d = &mut fs.gdt[group as usize];
        d.bg_inode_bitmap_csum_lo = full as u16;
        if has_64bit && desc_size >= 0x3C {
            d.bg_inode_bitmap_csum_hi = (full >> 16) as u16;
        }
    }

    let bs_u64 = fs.block_size;
    fs.dev.write_at(bmap_blk * bs_u64, &buf)?;

    if was_set {
        {
            let d = &mut fs.gdt[group as usize];
            let lo = d.bg_free_inodes_count_lo as u32;
            let hi = if fs.has_64bit { d.bg_free_inodes_count_hi as u32 } else { 0 };
            let n = ((hi << 16) | lo).saturating_add(1);
            d.set_free_inodes(n);
        }
        fs.sb.s_free_inodes_count = fs.sb.s_free_inodes_count.saturating_add(1);
    }

    Ok(())
}
