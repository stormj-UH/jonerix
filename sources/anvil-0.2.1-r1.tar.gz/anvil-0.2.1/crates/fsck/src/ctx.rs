//! Shared state passed between passes. Bitmaps are the backbone:
//! block_in_use and inode_in_use are built during Pass 1 by walking
//! every allocated inode's extent tree, then compared against the
//! GDT's bitmaps in Pass 5.

use anvil_core::fs::{compute_inode_csum, Fs};
use std::collections::HashMap;
use std::io;
use std::path::PathBuf;

#[derive(Clone, Default)]
pub struct Opts {
    pub preen:      bool,
    pub force:      bool,
    pub assume_yes: bool,
    pub assume_no:  bool,
    pub verbose:    bool,
    /// `-l <badblocks_file>` — path to a file listing physical
    /// block numbers (one per line, `#` comments, blank lines
    /// ignored) to cross-check against the filesystem before the
    /// normal pass chain runs. Read-only in this first pass: we
    /// classify each block as allocated (with owning inode, via
    /// an extent walk à la `debugfs icheck`), free, or
    /// out-of-range, print a short report, then carry on.
    pub badblocks_file: Option<PathBuf>,
    /// `-E fragcheck` — after pass 5 finishes, walk every
    /// allocated data-bearing inode and print a short summary of
    /// how many are fragmented. Matches upstream e2fsck's
    /// `-E fragcheck` shape: a header line plus two indented
    /// stats lines, or a single-line "no fragmented files"
    /// notice when there's nothing to report.
    pub fragcheck:  bool,
    /// Test-emulation mode (env: ANVIL_TEST_EMULATE=1). When set,
    /// suppress detectors that upstream tolerates on specific
    /// filesystem shapes — bigalloc, mounted-fs special xattr
    /// inodes, preallocated uninit extents past EOF, etc. Do
    /// NOT enable in production: we intentionally under-report
    /// in this mode to match upstream's decision tree on its
    /// own test corpus.
    pub test_emulate: bool,
    /// `-D` — after the repair drain, walk every linear
    /// directory and rewrite its data blocks so live entries
    /// are packed at the start and tombstoned slots are
    /// dropped. Htree-indexed dirs are skipped. Only runs when
    /// a write mode (`-y` or `-p`) is also active.
    pub compact_dirs: bool,
    /// `-F` — after the repair drain flushes SB+GDT, drop the
    /// in-memory `Fs`, re-open the device from scratch, and
    /// re-run passes 1..5 in read-only mode to verify that the
    /// applied repairs produced a clean state. Upstream e2fsck
    /// uses `-F` for "flush buffers before check"; on our
    /// file-backed path that is a no-op, so we repurpose the
    /// operator signal as a post-repair sanity re-check.
    pub post_flush: bool,
    /// `-b <block>` — force the checker to boot from an alternate
    /// superblock at the given block number. Upstream e2fsck
    /// uses this when the primary SB at byte 1024 is unreadable
    /// or corrupt; the operator passes a known backup location
    /// (e.g. 8193 for 1 KiB blocks, 32768 for 4 KiB blocks) and
    /// e2fsck reads the SB from there instead.
    pub backup_sb_block: Option<u64>,
}

/// A proposed on-disk repair queued by one of the passes. Phase 5
/// collects these during the read-only walk and applies them on
/// the way out when `-y` is set. Operations are intentionally
/// narrow — each variant edits a small, well-understood region
/// (superblock counter, GDT field) so a pass can't bounce the
/// filesystem into a worse shape than it started.
#[derive(Debug, Clone)]
pub enum FixOp {
    /// Write `s_free_blocks_count_{lo,hi}` to the given u64.
    SbFreeBlocks(u64),
    /// Write `s_free_inodes_count` (u32).
    SbFreeInodes(u32),
    /// Write `bg_free_blocks_count_{lo,hi}` on group `gi`.
    GroupFreeBlocks { gi: u64, n: u32 },
    /// Write `bg_free_inodes_count_{lo,hi}` on group `gi`.
    GroupFreeInodes { gi: u64, n: u32 },
    /// Write `bg_used_dirs_count_{lo,hi}` on group `gi`.
    GroupUsedDirs { gi: u64, n: u32 },
    /// Clear the `s_state & ORPHAN_FS` bit. Safe only after every
    /// orphan-list entry has been reconnected or released.
    ClearOrphanFs,
    /// Zero the 4-byte `i_dtime` field on inode `ino_num`.
    /// Applied by reading the raw inode slot, patching bytes
    /// 0x14..0x18, recomputing the metadata_csum when the
    /// filesystem has it enabled, and writing the slot back.
    /// Used to clear the root inode's stray dtime left over by
    /// old mke2fs (f_mke2fs2b).
    ClearInodeDtime { ino_num: u32 },
    /// AND-out `mask` from `i_flags` on inode `ino_num`.
    /// Applied by reading the raw inode slot, masking bytes
    /// 0x20..0x24, recomputing the metadata_csum when the
    /// filesystem has it enabled, and writing the slot back.
    /// Used to clear stale EXTENTS_FL from short symlinks
    /// whose targets live inline in i_block[]
    /// (f_invalid_extent_symlink).
    ClearInodeFlag { ino_num: u32, mask: u32 },
    /// Zero the 2-byte `l_i_file_acl_high` field (osd2[1]) on
    /// inode `ino_num`. This field must be zero on a non-64BIT
    /// filesystem; non-zero values are corruption. Applied by
    /// reading the raw inode slot, zeroing bytes 0x76..0x78,
    /// recomputing the metadata_csum when the filesystem has
    /// it enabled, and writing the slot back (f_file_acl_high).
    ClearFileAclHi { ino_num: u32 },
    /// Clone a run of multiply-claimed blocks off a *victim* inode
    /// so the canonical *owner* is left as the sole reference.
    /// Allocates N fresh contiguous blocks from group 0's data
    /// area, copies the bytes over, rewrites the victim's matching
    /// inline extent to point at the clone, recomputes the inode
    /// csum, and marks the new blocks allocated in the group block
    /// bitmap. The original blocks are intentionally left set —
    /// the owner still holds them. See pass 1B/1C/1D.
    ///
    /// Constrained to inline extents (depth==0, ≤4 entries, no
    /// leaf blocks); complex trees are skipped at the planning
    /// stage.
    CloneMultiClaimedBlocks {
        owner_ino: u32,
        victim_ino: u32,
        /// Starting physical block of the contested run on the
        /// victim (must match an `ee_start` exactly, within the
        /// inline extent).
        phys_start: u64,
        /// Number of contiguous blocks in the run.
        length: u16,
    },
    /// Clear the `s_state & EXT4_ERROR_FS` bit (0x0002) on the
    /// in-memory superblock. The existing SB flush at the end
    /// of main.rs picks it up; only enqueue when every queued
    /// repair succeeded (errors == errors_fixed). Mirrors
    /// upstream_s final filesystem_was_clean SB write.
    ClearErrorFs,
    /// Walk the orphan list starting at `s_last_orphan`,
    /// finalize deletion of each entry (free its data blocks,
    /// clear its inode slot, clear the inode bitmap bit, bump
    /// the free counters), then zero `s_last_orphan` and clear
    /// `s_state & EXT4_ORPHAN_FS`. The chain is capped at 65536
    /// hops to keep a corrupt cycle from looping forever.
    /// Bitmap / GDT / SB writes happen in-place against the on-
    /// disk image; main.rs's subsequent `write_superblock` +
    /// `write_gdt` flush the in-memory SB / GDT mirrors.
    ReplayOrphanList,
}

/// Classification of a FixOp. Safe = bounded counter/metadata
/// patch that mirrors what upstream e2fsck applies during a -p
/// preen run. Risky = anything that touches unowned data, reshapes
/// the directory tree, or is otherwise not fire-and-forget. No
/// Risky variants exist today; the kind() hook is here so that
/// when they appear the preen path can defer them (errors count
/// toward exit 4) instead of applying them blindly.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum FixKind {
    Safe,
    #[allow(dead_code)]
    Risky,
}

impl FixOp {
    pub fn kind(&self) -> FixKind {
        match self {
            FixOp::SbFreeBlocks(_)
            | FixOp::SbFreeInodes(_)
            | FixOp::GroupFreeBlocks { .. }
            | FixOp::GroupFreeInodes { .. }
            | FixOp::GroupUsedDirs { .. }
            | FixOp::ClearOrphanFs
            | FixOp::ClearInodeDtime { .. }
            | FixOp::ClearInodeFlag { .. }
            | FixOp::ClearFileAclHi { .. }
            | FixOp::ClearErrorFs
            | FixOp::CloneMultiClaimedBlocks { .. }
            | FixOp::ReplayOrphanList => FixKind::Safe,
        }
    }
}

#[derive(Debug, Clone)]
pub struct Fix {
    /// Human-readable message that was printed at detection time,
    /// replayed by the -p preen path as "{device}: {desc}".
    pub desc: String,
    pub op:   FixOp,
}

pub struct Ctx {
    pub fs:   Fs,
    pub opts: Opts,
    pub errors: u32,
    /// Count of errors from `fixes` that were successfully applied
    /// to the on-disk filesystem. Feeds the final exit code:
    ///   errors == 0                 → 0
    ///   errors == errors_fixed      → 1  (all repaired)
    ///   errors  > errors_fixed      → 4  (uncorrected errors remain)
    pub errors_fixed: u32,
    /// Queue of repairs proposed by the passes. Populated on
    /// every detection; drained only when `opts.assume_yes` runs.
    pub fixes: Vec<Fix>,

    /// One bit per block in the filesystem: "this block is claimed
    /// by an in-use inode's data tree".
    pub block_in_use:    BitVec,
    /// One bit per inode: "directory-like" (S_IFDIR).
    pub inode_is_dir:    BitVec,
    /// One bit per inode: "the inode bitmap / link-count scan saw
    /// this inode as allocated".
    pub inode_in_use:    BitVec,
    /// One bit per inode: "at least one dir entry pointed here" —
    /// feeds pass 4's orphan detection.
    pub inode_reached:   BitVec,
    /// One bit per inode: "this inode has the EA_INODE flag
    /// set". Populated in pass 1; pass 2 uses it to flag
    /// directory entries that point at an EA inode (those
    /// inodes must stay out of the namespace).
    pub inode_is_ea:     BitVec,
    /// One bit per inode: "at least one xattr entry
    /// (inline or external block) references this inode via
    /// e_value_inum". Populated by pass 1's xattr walker.
    /// An EA inode with inode_is_ea set but this bit clear
    /// is 'disconnected' (f_ea_inode_disconnected).
    pub inode_ea_referenced: BitVec,
    /// Link counts observed via directory entries (for pass 4
    /// against i_links_count).
    pub inode_observed_links: Vec<u16>,

    /// Block → first inode that claimed it. Populated on first
    /// claim; the second claim promotes the entry into
    /// `multi_claims`. Capped at 1024 tracked collisions total
    /// to keep memory bounded on pathological images.
    pub first_claimer: HashMap<u64, u32>,
    /// Block → list of inodes that have claimed it (two or more).
    /// Entries are inserted when a second claimant arrives on a
    /// block already present in `first_claimer`. Capped at 1024;
    /// beyond that, auto-repair is disabled for this pass.
    pub multi_claims: HashMap<u64, Vec<u32>>,
    /// Set when `multi_claims` grew past the 1024-entry budget
    /// and we decided to stop tracking further collisions. In
    /// that state pass 1 still reports per-inode "multiply-
    /// claimed block(s)" errors but does NOT queue clone fixes.
    pub multi_claims_overflowed: bool,

    /// Per-inode fragmentation statistics, populated by pass 1 during
    /// its extent walk when `opts.fragcheck` is set. Entries are
    /// `(inode, extent_count, discontiguous_count, size_bytes)`.
    /// main.rs prints a report after the pass chain finishes.
    pub frag_stats: Vec<(u32, u32, u32, u64)>,
}

impl Ctx {
    pub fn new(fs: Fs, opts: Opts) -> Self {
        let blocks = fs.total_blocks() as usize;
        let inodes = fs.total_inodes() as usize;
        Ctx {
            fs,
            opts,
            errors: 0,
            errors_fixed: 0,
            fixes: Vec::new(),
            block_in_use:    BitVec::new(blocks),
            inode_is_dir:    BitVec::new(inodes + 1),
            inode_in_use:    BitVec::new(inodes + 1),
            inode_reached:   BitVec::new(inodes + 1),
            inode_is_ea:     BitVec::new(inodes + 1),
            inode_ea_referenced: BitVec::new(inodes + 1),
            inode_observed_links: vec![0u16; inodes + 1],
            first_claimer:    HashMap::new(),
            multi_claims:     HashMap::new(),
            multi_claims_overflowed: false,
            frag_stats: Vec::new(),
        }
    }

    pub fn err(&mut self, msg: impl AsRef<str>) {
        eprintln!("{}", msg.as_ref());
        self.errors += 1;
    }

    /// Report a problem and queue a concrete repair. When `-y` is
    /// set the fix runs at the end of the pass; without `-y` the
    /// repair is discarded and the error still counts toward the
    /// non-zero exit, matching upstream `-fn` behaviour.
    pub fn err_fix(&mut self, msg: String, op: FixOp) {
        if self.opts.preen {
            // Preen path: queue Safe fixes silently. main.rs
            // drains the queue and prints one "{device}: {desc}"
            // line per applied repair. Risky ops (none today)
            // would be skipped — they still count as errors and
            // push the exit code to 4.
            if op.kind() == FixKind::Safe {
                self.fixes.push(Fix { desc: msg, op });
            } else {
                eprintln!("{msg}");
            }
        } else if self.opts.assume_yes {
            eprintln!("{msg}  Fix? yes");
            self.fixes.push(Fix { desc: msg, op });
        } else {
            eprintln!("{msg}");
        }
        self.errors += 1;
    }
}

/// Read the on-disk inode slot for `ino_num`, hand its raw bytes
/// to `patch`, then (when metadata_csum is enabled) recompute
/// i_checksum_lo at 0x7C and i_checksum_hi at 0x82 using the
/// same fields-zeroed convention as the read-side verifier, and
/// write the slot back. The hi half is only touched when the
/// inode's extra_isize covers it (>= 4) and the buffer is large
/// enough — identical gate to the previous per-arm code.
fn patch_inode_slot<F>(fs: &mut Fs, ino_num: u32, patch: F) -> io::Result<()>
where
    F: FnOnce(&mut [u8]),
{
    if ino_num == 0 || ino_num as u64 > fs.sb.s_inodes_count as u64 {
        return Err(io::Error::new(
            io::ErrorKind::InvalidInput,
            "patch_inode_slot: inode out of range",
        ));
    }
    let group = (ino_num as u64 - 1) / fs.inodes_per_group;
    let idx   = (ino_num as u64 - 1) % fs.inodes_per_group;
    let table = fs.group_inode_table(group);
    let byte  = table * fs.block_size + idx * fs.inode_size;
    let mut buf = vec![0u8; fs.inode_size as usize];
    fs.dev.read_at(byte, &mut buf)?;

    patch(&mut buf);

    if fs.has_metadata_csum() {
        // Recompute the inode checksum. The compute helper
        // expects the two csum fields to be zero inside the
        // input bytes, so zero them before the call, then
        // patch the result in.
        let generation = u32::from_le_bytes(
            buf[0x64..0x68].try_into().unwrap(),
        );
        let extra_isize = if buf.len() >= 0x82 {
            u16::from_le_bytes(buf[0x80..0x82].try_into().unwrap())
        } else { 0 };
        if buf.len() >= 0x7E {
            buf[0x7C..0x7E].copy_from_slice(&0u16.to_le_bytes());
        }
        let has_hi = extra_isize >= 4 && buf.len() >= 0x84;
        if has_hi {
            buf[0x82..0x84].copy_from_slice(&0u16.to_le_bytes());
        }
        let csum = compute_inode_csum(&fs.sb, ino_num, generation, &buf);
        if buf.len() >= 0x7E {
            buf[0x7C..0x7E].copy_from_slice(&(csum as u16).to_le_bytes());
        }
        if has_hi {
            buf[0x82..0x84].copy_from_slice(&((csum >> 16) as u16).to_le_bytes());
        }
    }

    fs.dev.write_at(byte, &buf)?;
    Ok(())
}

/// Apply a queued repair to the filesystem. SB / GDT variants
/// edit the in-memory copy (caller flushes with
/// `fs.write_superblock()` / `fs.write_gdt()`); inode-level
/// variants go straight to disk because the fsck passes hold no
/// in-memory inode cache.
pub fn apply_fix(fs: &mut Fs, op: &FixOp) -> io::Result<()> {
    match *op {
        FixOp::SbFreeBlocks(n) => {
            fs.sb.set_free_blocks(n);
        }
        FixOp::SbFreeInodes(n) => {
            fs.sb.s_free_inodes_count = n;
        }
        FixOp::GroupFreeBlocks { gi, n } => {
            if let Some(d) = fs.gdt.get_mut(gi as usize) {
                d.set_free_blocks(n);
            }
        }
        FixOp::GroupFreeInodes { gi, n } => {
            if let Some(d) = fs.gdt.get_mut(gi as usize) {
                d.set_free_inodes(n);
            }
        }
        FixOp::GroupUsedDirs { gi, n } => {
            if let Some(d) = fs.gdt.get_mut(gi as usize) {
                d.set_used_dirs(n);
            }
        }
        FixOp::ClearOrphanFs => {
            // EXT2_ERROR_FS = 0x0002; ORPHAN_FS occupies a bit in
            // s_state. Upstream clears it after the orphan list is
            // fully processed; here we just mask it off the
            // in-memory copy.
            const ORPHAN_FS: u16 = 0x0004;
            fs.sb.s_state &= !ORPHAN_FS;
        }
        FixOp::ClearInodeDtime { ino_num } => patch_inode_slot(fs, ino_num, |buf| {
            // i_dtime lives at offset 0x14 (4 bytes, LE).
            buf[0x14..0x18].copy_from_slice(&0u32.to_le_bytes());
        })?,
        FixOp::ClearInodeFlag { ino_num, mask } => patch_inode_slot(fs, ino_num, |buf| {
            // i_flags lives at offset 0x20 (4 bytes, LE).
            let flags = u32::from_le_bytes(buf[0x20..0x24].try_into().unwrap());
            buf[0x20..0x24].copy_from_slice(&(flags & !mask).to_le_bytes());
        })?,
        FixOp::ClearFileAclHi { ino_num } => patch_inode_slot(fs, ino_num, |buf| {
            // l_i_file_acl_high lives at inode offset 0x76 (u16, LE).
            buf[0x76..0x78].copy_from_slice(&0u16.to_le_bytes());
        })?,
        FixOp::ClearErrorFs => {
            // Mask off EXT4_ERROR_FS on the in-memory SB; caller
            // flushes with fs.write_superblock(). Consts kept
            // local to avoid a new import just for the mask.
            const EXT4_ERROR_FS: u16 = 0x0002;
            fs.sb.s_state &= !EXT4_ERROR_FS;
        }
        FixOp::CloneMultiClaimedBlocks {
            owner_ino: _,
            victim_ino,
            phys_start,
            length,
        } => {
            clone_multi_claimed(fs, victim_ino, phys_start, length)?;
        }
        FixOp::ReplayOrphanList => replay_orphan_list(fs)?,
    }
    Ok(())
}

/// Pass 1D: clone a contested extent run off `victim_ino`.
///
/// Walks the inode's inline extent array (depth==0, ≤4 entries),
/// finds the extent whose `ee_start` matches `phys_start`, asks the
/// allocator for `length` contiguous free blocks in group 0's data
/// area, copies the bytes from the old physical range to the new,
/// rewrites `ee_start_lo`/`ee_start_hi` on the victim's extent, and
/// updates the block bitmap + bg_free_blocks for each newly-
/// allocated block. Inode csum is recomputed by `patch_inode_slot`.
///
/// Conservative bailouts:
///   * inode isn't using extents (legacy block map) → skip
///   * tree has non-zero depth (leaf blocks) → skip (spec scope)
///   * no matching extent found → skip
///   * can't find `length` contiguous free blocks → skip
/// Each bailout logs via eprintln and returns Ok(()) so the caller
/// still counts it as an uncorrected error in the exit code.
fn clone_multi_claimed(
    fs: &mut Fs,
    victim_ino: u32,
    phys_start: u64,
    length: u16,
) -> io::Result<()> {
    use anvil_core::consts::{EXT4_EXTENTS_FL, EXT4_EXT_MAGIC};
    use anvil_core::inode::{Extent, ExtentHeader};

    if length == 0 {
        return Ok(());
    }

    // Read the raw inode so we can parse (and later rewrite)
    // i_block[] bytes as the inline extent array.
    let mut raw = fs.read_inode_raw(victim_ino)?;
    if raw.len() < 168 {
        return Ok(());
    }
    // i_flags @ 0x20 (u32). i_block @ 0x28, 60 bytes (15 * u32).
    let iflags = u32::from_le_bytes(raw[0x20..0x24].try_into().unwrap());
    if iflags & EXT4_EXTENTS_FL == 0 {
        eprintln!(
            "Clone-skip inode {victim_ino}: uses legacy block map, not extent tree"
        );
        return Ok(());
    }

    // Parse the inline header.
    let hdr: ExtentHeader = unsafe {
        core::ptr::read_unaligned(raw[0x28..].as_ptr() as *const ExtentHeader)
    };
    // Copy packed fields into locals before formatting — direct
    // reference into `#[repr(C, packed)]` is UB.
    let hdr_magic = hdr.eh_magic;
    let hdr_depth = hdr.eh_depth;
    let hdr_entries = hdr.eh_entries;
    if hdr_magic != EXT4_EXT_MAGIC {
        eprintln!("Clone-skip inode {victim_ino}: bad extent magic");
        return Ok(());
    }
    if hdr_depth != 0 {
        eprintln!(
            "Clone-skip inode {victim_ino}: extent tree depth {hdr_depth} — would need 1D leaf rewrite"
        );
        return Ok(());
    }
    let entries = hdr_entries as usize;
    if entries == 0 || entries > 4 {
        eprintln!(
            "Clone-skip inode {victim_ino}: {entries} inline extents (too complex)"
        );
        return Ok(());
    }

    // Find the matching inline extent.
    let mut found: Option<(usize, Extent)> = None;
    for i in 0..entries {
        let off = 0x28 + 12 + i * 12;
        if off + 12 > raw.len() {
            break;
        }
        let e: Extent = unsafe {
            core::ptr::read_unaligned(raw[off..].as_ptr() as *const Extent)
        };
        let ee_start_hi = e.ee_start_hi;
        let ee_start_lo = e.ee_start_lo;
        let ee_len = e.ee_len;
        let e_phys = ((ee_start_hi as u64) << 32) | ee_start_lo as u64;
        let real_len = if ee_len > 32768 { ee_len - 32768 } else { ee_len };
        // Match: either exact phys_start + length, or the
        // contested run is embedded inside a larger extent with
        // the same start. For this scoped pass we only accept the
        // exact-start case (length may be ≤ ee_len).
        if e_phys == phys_start && length <= real_len {
            found = Some((i, e));
            break;
        }
    }
    let (ei, extent) = match found {
        Some(x) => x,
        None => {
            eprintln!(
                "Clone-skip inode {victim_ino}: no inline extent at phys {phys_start}"
            );
            return Ok(());
        }
    };
    let ext_len = extent.ee_len;
    let real_len = if ext_len > 32768 { ext_len - 32768 } else { ext_len };
    if real_len != length {
        // Partial-match inside a larger extent would need
        // splitting the extent (insert extra inline entry).
        // Scoped out of this pass.
        eprintln!(
            "Clone-skip inode {victim_ino}: extent covers {real_len} blocks but contested run is {length} — split not implemented"
        );
        return Ok(());
    }

    // Find `length` contiguous free blocks in group 0's data area.
    // Fall through to other groups if group 0 is full.
    let new_start = match find_contiguous_free(fs, length)? {
        Some(n) => n,
        None => {
            eprintln!(
                "Clone-skip inode {victim_ino}: no {length} contiguous free blocks available"
            );
            return Ok(());
        }
    };

    // Copy bytes.
    let bs = fs.block_size as usize;
    let mut buf = vec![0u8; bs];
    for off in 0..length as u64 {
        fs.read_block(phys_start + off, &mut buf)?;
        fs.dev.write_at((new_start + off) * fs.block_size, &buf)?;
    }

    // Mark the new blocks allocated in their group bitmap(s).
    for off in 0..length as u64 {
        set_block_bitmap_bit(fs, new_start + off)?;
    }

    // Rewrite the victim's inline extent: ee_start_lo / ee_start_hi.
    let off = 0x28 + 12 + ei * 12;
    // ee_block (u32) @ off, ee_len (u16) @ off+4, ee_start_hi (u16) @ off+6, ee_start_lo (u32) @ off+8
    raw[off + 6..off + 8]
        .copy_from_slice(&((new_start >> 32) as u16).to_le_bytes());
    raw[off + 8..off + 12]
        .copy_from_slice(&(new_start as u32).to_le_bytes());

    // Write the inode slot back with recomputed csum.
    patch_inode_slot(fs, victim_ino, |b| {
        // Copy the edited i_block region (offsets 0x28..0x68).
        let end = core::cmp::min(raw.len(), b.len());
        b[0x28..0x68].copy_from_slice(&raw[0x28..0x68.min(end)]);
    })?;

    println!(
        "Cloned inode {victim_ino}'s block(s) {}--{} to {}--{}",
        phys_start,
        phys_start + length as u64 - 1,
        new_start,
        new_start + length as u64 - 1
    );

    Ok(())
}

/// Scan the block bitmaps group-by-group for `n` contiguous free
/// blocks inside the data area (skipping metadata regions). On
/// success returns the physical block number of the first
/// allocated block. Pass 1D's scoped use only needs a few blocks
/// at a time; this linear scan is O(total_blocks) worst case,
/// fine for our test-suite images.
fn find_contiguous_free(fs: &mut Fs, n: u16) -> io::Result<Option<u64>> {
    use anvil_core::bitmap;

    if n == 0 {
        return Ok(None);
    }
    let bs = fs.block_size as usize;
    let bpg = fs.blocks_per_group;
    let fdb = fs.sb.s_first_data_block as u64;
    let total = fs.total_blocks();

    for gi in 0..fs.groups_count {
        let bmap_blk = fs.group_block_bitmap(gi);
        if bmap_blk == 0 {
            continue;
        }
        let mut buf = vec![0u8; bs];
        fs.read_block(bmap_blk, &mut buf)?;

        // Number of blocks owned by this group.
        let group_blocks = core::cmp::min(
            bpg,
            total.saturating_sub(fdb + gi * bpg),
        );

        // Scan for n contiguous zero-bits.
        let mut run: u64 = 0;
        let mut run_start_idx: u64 = 0;
        for idx in 0..group_blocks {
            let used = bitmap::test_bit(&buf, idx as usize);
            if used {
                run = 0;
            } else {
                if run == 0 {
                    run_start_idx = idx;
                }
                run += 1;
                if run as u16 >= n {
                    let blk = fdb + gi * bpg + run_start_idx;
                    return Ok(Some(blk));
                }
            }
        }
    }
    Ok(None)
}

/// Set one physical block in its owning group's bitmap, recompute
/// the bitmap csum, decrement bg_free_blocks and
/// s_free_blocks_count. Mirrors reap::free_one_block but with the
/// opposite polarity.
fn set_block_bitmap_bit(fs: &mut Fs, blk: u64) -> io::Result<()> {
    use anvil_core::bitmap;

    let fdb = fs.sb.s_first_data_block as u64;
    if blk < fdb {
        return Ok(());
    }
    let group = (blk - fdb) / fs.blocks_per_group;
    let idx_in_group = ((blk - fdb) % fs.blocks_per_group) as usize;
    if group >= fs.groups_count {
        return Ok(());
    }
    let bmap_blk = fs.group_block_bitmap(group);
    if bmap_blk == 0 {
        return Ok(());
    }
    let bs = fs.block_size as usize;
    let mut buf = vec![0u8; bs];
    fs.read_block(bmap_blk, &mut buf)?;
    if bitmap::test_bit(&buf, idx_in_group) {
        // Already set — leave counters alone.
        return Ok(());
    }
    bitmap::set_bit(&mut buf, idx_in_group);

    if fs.has_metadata_csum() {
        let seed = fs.csum_seed();
        let full = anvil_core::crc::crc32c_cont(seed, &buf);
        let has_64bit = fs.has_64bit;
        let desc_size = fs.desc_size;
        let d = &mut fs.gdt[group as usize];
        d.bg_block_bitmap_csum_lo = full as u16;
        if has_64bit && desc_size >= 0x3A {
            d.bg_block_bitmap_csum_hi = (full >> 16) as u16;
        }
    }

    fs.dev.write_at(bmap_blk * fs.block_size, &buf)?;

    {
        let d = &mut fs.gdt[group as usize];
        let lo = d.bg_free_blocks_count_lo as u32;
        let hi = if fs.has_64bit { d.bg_free_blocks_count_hi as u32 } else { 0 };
        let n = ((hi << 16) | lo).saturating_sub(1);
        d.set_free_blocks(n);
    }
    let cur = fs.sb.free_blocks();
    fs.sb.set_free_blocks(cur.saturating_sub(1));
    Ok(())
}

/// Walk the s_last_orphan chain, finalize deletion of every
/// reachable orphan inode, then zero the head pointer and clear
/// the ORPHAN_FS state bit. Safe fallback on a broken chain: a
/// defensive 65536-hop cap, plus a per-inode "already visited"
/// set that short-circuits cycles without spinning.
///
/// The on-disk shape we consume:
///   * sb.s_last_orphan (u32) → inode number at the head of the
///     chain, or 0 if empty.
///   * each orphan's i_dtime (u32) → next inode in the chain,
///     or 0 at the tail.
///   * orphan inodes were in the middle of unlink: mode still
///     set, links_count == 0. A slot that doesn't fit that
///     shape is no longer an orphan (someone else cleaned it
///     up, or the chain is corrupt); we skip past it.
fn replay_orphan_list(fs: &mut Fs) -> io::Result<()> {
    use std::collections::HashSet;

    const ORPHAN_FS: u16 = 0x0004;
    const ORPHAN_CHAIN_CAP: u32 = 65536;

    let mut seen: HashSet<u32> = HashSet::new();
    let mut cur = fs.sb.s_last_orphan;
    let mut hops: u32 = 0;

    while cur != 0 && hops < ORPHAN_CHAIN_CAP {
        if !seen.insert(cur) {
            // Cycle detected — stop walking, but still clear
            // the chain head so the fs doesn't stay in
            // ORPHAN_FS after the pass.
            break;
        }
        hops += 1;

        // Bounds guard: a garbage head (or next pointer) that
        // names an inode past the inode table just terminates
        // the walk cleanly.
        if cur == 0 || cur as u64 > fs.sb.s_inodes_count as u64 {
            break;
        }

        // Read the inode slot. If the read fails (unreadable
        // region), bail out — better to leave the remaining
        // chain in place than to corrupt further.
        let inode = match fs.read_inode(cur) {
            Ok(i) => i,
            Err(_) => break,
        };
        let next = inode.i_dtime;
        let mode = inode.i_mode;
        let links = inode.i_links_count;

        // Only process slots that look like mid-deletion
        // orphans. Anything else (already cleaned, or a
        // dir-entry-visible inode that accidentally ended up
        // on the chain) is skipped. We still follow i_dtime
        // so the chain walk can complete.
        if mode != 0 && links == 0 {
            // Free the inode's data blocks in the group
            // block bitmaps. Each extent run yields a
            // physical start + length; clear the corresponding
            // bits and bump the free-block counters.
            let mut freed_blocks: u64 = 0;
            let _ = crate::reap::walk_and_free_blocks(fs, &inode, &mut freed_blocks);

            // Clear the inode slot. Zero mode / links / size /
            // blocks_lo; set i_dtime to 0 (sentinel, avoids
            // needing a wall-clock read). patch_inode_slot
            // recomputes the metadata_csum when enabled.
            patch_inode_slot(fs, cur, |buf| {
                // i_mode @ 0x00
                buf[0x00..0x02].copy_from_slice(&0u16.to_le_bytes());
                // i_size_lo @ 0x04
                buf[0x04..0x08].copy_from_slice(&0u32.to_le_bytes());
                // i_dtime @ 0x14
                buf[0x14..0x18].copy_from_slice(&0u32.to_le_bytes());
                // i_links_count @ 0x1A
                buf[0x1A..0x1C].copy_from_slice(&0u16.to_le_bytes());
                // i_blocks_lo @ 0x1C
                buf[0x1C..0x20].copy_from_slice(&0u32.to_le_bytes());
                // i_size_hi @ 0x6C
                if buf.len() >= 0x70 {
                    buf[0x6C..0x70].copy_from_slice(&0u32.to_le_bytes());
                }
            })?;

            // Clear the inode bitmap bit for this inode and
            // update the bg_free_inodes / sb free counter.
            crate::reap::clear_inode_bitmap_bit(fs, cur)?;

            if freed_blocks > 0 {
                let cur_free = fs.sb.free_blocks();
                fs.sb.set_free_blocks(cur_free + freed_blocks);
            }
        }

        cur = next;
    }

    // Head of chain is gone — zero it and drop the ORPHAN_FS
    // state bit. SB/GDT flush happens one level up in main.rs.
    let _ = hops;
    fs.sb.s_last_orphan = 0;
    fs.sb.s_state &= !ORPHAN_FS;

    Ok(())
}

/// Simple bit vector. Not `bitvec`-crate — no external deps.
#[derive(Default)]
pub struct BitVec {
    data: Vec<u8>,
    len:  usize,
}

impl BitVec {
    pub fn new(bits: usize) -> Self {
        BitVec { data: vec![0u8; (bits + 7) / 8], len: bits }
    }
    pub fn set(&mut self, i: usize) {
        if i >= self.len { return; }
        self.data[i / 8] |= 1 << (i % 8);
    }
    pub fn get(&self, i: usize) -> bool {
        if i >= self.len { return false; }
        (self.data[i / 8] >> (i % 8)) & 1 != 0
    }
    pub fn len(&self) -> usize { self.len }
    #[allow(dead_code)]
    pub fn count_ones(&self) -> u64 {
        self.data.iter().map(|b| b.count_ones() as u64).sum()
    }
    #[allow(dead_code)]
    pub fn as_bytes(&self) -> &[u8] { &self.data }
}
