//! QFMT_V2 disk quota cross-check.
//!
//! Walks the per-UID radix tree stored in the user/group quota
//! inode and compares the declared (curspace, curinodes) fields
//! against totals we compute by scanning every used inode's owner
//! and its `i_blocks_lo`. A mismatch is the same signal upstream
//! reports as '[QUOTA WARNING] Usage inconsistent for ID ...'
//! (`f_quota`, `f_quota_deallocate_inode`).
//!
//! Layout is the public QFMT_V2 on-disk format:
//!   block 0: 8-byte header {magic, version} + 24-byte info struct
//!   block 1: radix tree root (256 × u32 block pointers per node
//!            for 1-KiB blocks; each level consumes one byte of
//!            the 32-bit UID, so the tree has 4 levels)
//!   leaves: 16-byte `qt_disk_dqdbheader` + N × 72-byte dqblk
//!           entries, where dqblk fields are
//!             +0  dqb_id          u32
//!             +4  dqb_pad         u32
//!             +8  dqb_ihardlimit  u64
//!             +16 dqb_isoftlimit  u64
//!             +24 dqb_curinodes   u64
//!             +32 dqb_bhardlimit  u64
//!             +40 dqb_bsoftlimit  u64
//!             +48 dqb_curspace    u64
//!             +56 dqb_btime       u64
//!             +64 dqb_itime       u64

use crate::ctx::Ctx;
use anvil_core::consts::*;
use anvil_core::extent;
use std::collections::HashMap;
use std::io;

/// Walk the quota inode `qino` and return a map
/// `uid -> (curspace_bytes, curinodes)`.
fn read_quota_table(
    cx: &mut Ctx, qino: u32,
) -> io::Result<HashMap<u32, (u64, u64)>> {
    let mut out: HashMap<u32, (u64, u64)> = HashMap::new();
    let bs = cx.fs.block_size as usize;
    if qino == 0 || qino as u64 > cx.fs.total_inodes() {
        return Ok(out);
    }
    let ino = cx.fs.read_inode(qino)?;
    // Build logical -> physical map from the extent tree.
    let mut log2phys: Vec<u64> = Vec::new();
    let walk_res = extent::walk_extents(&mut cx.fs, &ino, |r| {
        let need = (r.logical as usize) + r.length as usize;
        if log2phys.len() < need {
            log2phys.resize(need, 0);
        }
        for off in 0..r.length as usize {
            log2phys[r.logical as usize + off] = r.physical + off as u64;
        }
    });
    if walk_res.is_err() || log2phys.len() < 2 { return Ok(out); }

    // Quick sanity: block 0 must carry the QFMT_V2 magic so we
    // don't chase garbage on a corrupted / non-quota inode.
    let mut hdr = vec![0u8; bs];
    if cx.fs.read_block(log2phys[0], &mut hdr).is_err() { return Ok(out); }
    let magic = u32::from_le_bytes([hdr[0], hdr[1], hdr[2], hdr[3]]);
    // 0xd9c01f11 = user, 0xd9c01927 = group, 0xd9c03f14 = project
    if !matches!(magic, 0xd9c01f11 | 0xd9c01927 | 0xd9c03f14) {
        return Ok(out);
    }

    // Recurse the radix tree from logical block 1 at depth 0.
    // DQTREEDEPTH = 4 for 1-KiB blocks (256 pointers per level;
    // 4 levels cover all 32 bits of a UID). Leaves live one level
    // below the last tree node, i.e. when we descend from a
    // depth-3 node we land on a leaf.
    let tree_depth: u32 = {
        let mut entries: u64 = 1;
        let epb = (bs / 4) as u64;
        let mut d = 0u32;
        while entries < (1u64 << 32) {
            entries = entries.saturating_mul(epb);
            d += 1;
        }
        d
    };
    fn recurse(
        cx: &mut Ctx, log2phys: &[u64], lblk: u32, depth: u32,
        tree_depth: u32, bs: usize,
        out: &mut HashMap<u32, (u64, u64)>,
        visited: &mut std::collections::HashSet<u32>,
    ) {
        if !visited.insert(lblk) { return; } // avoid cycles
        if (lblk as usize) >= log2phys.len() { return; }
        let phys = log2phys[lblk as usize];
        if phys == 0 { return; }
        let mut buf = vec![0u8; bs];
        if cx.fs.read_block(phys, &mut buf).is_err() { return; }
        if depth < tree_depth {
            // Tree node: bs/4 u32 block pointers.
            let slots = bs / 4;
            for i in 0..slots {
                let off = i * 4;
                if off + 4 > buf.len() { break; }
                let ptr = u32::from_le_bytes([
                    buf[off], buf[off+1], buf[off+2], buf[off+3],
                ]);
                if ptr != 0 {
                    recurse(cx, log2phys, ptr, depth + 1, tree_depth, bs, out, visited);
                }
            }
        } else {
            // Leaf: 16-byte qt_disk_dqdbheader, then dqblk entries.
            if buf.len() < 16 { return; }
            let entries = u16::from_le_bytes([buf[8], buf[9]]) as usize;
            let dqblk_sz = 72usize;
            let cap = (buf.len() - 16) / dqblk_sz;
            let n = entries.min(cap).min(256);
            for e in 0..n {
                let off = 16 + e * dqblk_sz;
                if off + dqblk_sz > buf.len() { break; }
                let uid = u32::from_le_bytes([
                    buf[off], buf[off+1], buf[off+2], buf[off+3],
                ]);
                // Skip genuinely-empty slots (all-zero dqblk).
                let all_zero = buf[off..off+dqblk_sz].iter().all(|&b| b == 0);
                if all_zero { continue; }
                let curinodes = u64::from_le_bytes(
                    buf[off+24..off+32].try_into().unwrap());
                let curspace = u64::from_le_bytes(
                    buf[off+48..off+56].try_into().unwrap());
                out.entry(uid).and_modify(|e| {
                    e.0 += curspace; e.1 += curinodes;
                }).or_insert((curspace, curinodes));
            }
        }
    }
    let mut visited: std::collections::HashSet<u32> = Default::default();
    recurse(cx, &log2phys, 1, 0, tree_depth, bs, &mut out, &mut visited);

    Ok(out)
}

/// Compute per-UID totals by scanning every allocated inode.
/// Returns `uid -> (curspace_bytes, curinodes)` where curspace is
/// `i_blocks_lo * 512`. EA inodes are excluded from inode-count
/// because they live off-namespace and upstream's tally does too.
fn walk_real_usage(cx: &mut Ctx) -> io::Result<HashMap<u32, (u64, u64)>> {
    let mut out: HashMap<u32, (u64, u64)> = HashMap::new();
    let total = cx.fs.total_inodes() as u32;
    const EA_INODE_FL: u32 = 0x00200000;
    for ino in 1..=total {
        if !cx.inode_in_use.get(ino as usize) { continue; }
        // Upstream's walked quota tally excludes the whole
        // reserved-inode range — bad-blocks (#1), usr/grp/
        // boot/undel/resize (#3-7), journal (#8), replica
        // (#9), exclude (#10) — along with the user / group /
        // project quota inodes themselves. Everything from
        // s_first_ino (typically #11 = lost+found) onward plus
        // the root dir (#2) counts. Verified against f_quota's
        // expect: root + lost+found = 2 inodes / 26 sectors =
        // 13312 bytes, matching upstream.
        let is_service = ino == 1
            || (ino >= 3 && ino < cx.fs.sb.s_first_ino.max(11))
            || ino == cx.fs.sb.s_journal_inum
            || (cx.fs.sb.s_feature_ro_compat & EXT4_FEATURE_RO_COMPAT_QUOTA != 0
                && (ino == cx.fs.sb.s_usr_quota_inum
                    || ino == cx.fs.sb.s_grp_quota_inum
                    || ino == cx.fs.sb.s_prj_quota_inum));
        if is_service { continue; }
        let inode = match cx.fs.read_inode(ino) {
            Ok(i) => i, Err(_) => continue,
        };
        if inode.i_flags & EA_INODE_FL != 0 { continue; }
        if inode.i_mode == 0 { continue; }
        let uid_lo = inode.i_uid as u32;
        let uid_hi = inode.i_osd2[2] as u32; // l_i_uid_high (osd2[2])
        let uid = uid_lo | (uid_hi << 16);
        // i_blocks_lo is in 512-byte sectors; HUGE_FILE feature
        // promotes it to filesystem-blocks when EXT4_HUGE_FILE_FL
        // is set, but quota always counts in bytes either way.
        let blocks_hi = inode.i_osd2[0] as u64; // l_i_blocks_high
        let blocks = (blocks_hi << 32) | inode.i_blocks_lo as u64;
        let bytes = blocks.saturating_mul(512);
        out.entry(uid).and_modify(|e| {
            e.0 = e.0.saturating_add(bytes);
            e.1 = e.1.saturating_add(1);
        }).or_insert((bytes, 1));
    }
    Ok(out)
}

/// Cross-check the user quota inode. If a declared (space,
/// inodes) pair doesn't match the walked tally, emit the same
/// '[QUOTA WARNING]' signal upstream uses. Silently returns on
/// filesystems without QUOTA feature or with a zero quota inum.
pub fn check(cx: &mut Ctx) -> io::Result<()> {
    if cx.fs.sb.s_feature_ro_compat & EXT4_FEATURE_RO_COMPAT_QUOTA == 0 {
        return Ok(());
    }
    let uq = cx.fs.sb.s_usr_quota_inum;
    if uq == 0 { return Ok(()); }

    let declared = read_quota_table(cx, uq)?;
    if declared.is_empty() { return Ok(()); }
    let actual = walk_real_usage(cx)?;

    for (&uid, &(dspace, dinodes)) in &declared {
        let (aspace, ainodes) = actual.get(&uid).copied().unwrap_or((0, 0));
        if aspace != dspace || ainodes != dinodes {
            cx.err(format!(
                "[QUOTA WARNING] Usage inconsistent for ID {uid}:actual ({aspace}, {ainodes}) != expected ({dspace}, {dinodes})"));
        }
    }
    Ok(())
}
