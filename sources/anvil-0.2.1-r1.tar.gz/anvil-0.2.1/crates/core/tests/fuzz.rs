//! Fuzz-style robustness suite for on-disk parsers.
//!
//! Feeds seeded pseudo-random bytes at the parser/walker surfaces
//! that anvil-core exposes and asserts the robustness contract:
//! no panics on arbitrary input, no infinite loops in walkers.
//! We are not looking for new bugs here; we are codifying that
//! the parsers are allowed to return garbage or errors on
//! garbage, but must never abort the process.
//!
//! Stable Rust only — no nightly cargo-fuzz, no external deps.
//! The pseudo-random source is a 128-bit LCG (Knuth's constants)
//! seeded with a fixed value so runs are deterministic.

use anvil_core::dirhash::{dirhash, DX_HASH_LEGACY, DX_HASH_TEA};
use anvil_core::crc::crc32c_cont;
use anvil_core::dir::DirEntryHead;
use anvil_core::inode::ExtentHeader;
use anvil_core::jbd2::JournalSuperblock;
use anvil_core::superblock::Superblock;

/// Tiny seeded LCG. Not cryptographic — just a stable stream
/// so test runs are reproducible.
struct Rng(u64);
impl Rng {
    fn new(seed: u64) -> Self { Self(seed) }
    fn next_u64(&mut self) -> u64 {
        self.0 = self.0
            .wrapping_mul(6364136223846793005)
            .wrapping_add(1442695040888963407);
        self.0
    }
    fn bytes(&mut self, n: usize) -> Vec<u8> {
        (0..n).map(|_| (self.next_u64() >> 56) as u8).collect()
    }
    fn range(&mut self, max: u64) -> u64 {
        if max == 0 { 0 } else { self.next_u64() % max }
    }
}

const ITERS: usize = 10_000;
const HOP_CAP: usize = 512;

#[test]
fn fuzz_superblock_parse() {
    let mut rng = Rng::new(0x5eed_0001);
    for _ in 0..ITERS {
        let bytes = rng.bytes(1024);
        // SAFETY: Superblock is repr(C, packed) of POD integers
        // and byte arrays; every 1024-byte pattern is a valid
        // Superblock value. Copy out to avoid keeping a pointer
        // into the Vec alive.
        let sb: Superblock = unsafe { core::ptr::read_unaligned(bytes.as_ptr() as *const Superblock) };
        let _ = sb.blocks_count();
        let _ = sb.free_blocks();
        let _ = sb.block_size();
        let _ = sb.reserved_blocks();
    }
}

#[test]
fn fuzz_dir_entry_walk() {
    let mut rng = Rng::new(0x5eed_0002);
    for _ in 0..ITERS {
        let buf = rng.bytes(4096);
        tolerant_dir_walk(&buf);
    }
}

/// Mirrors the pass2 dir-block walker in shape but is tolerant
/// of every possible input: if any invariant is violated the
/// walk stops. Also hop-capped to HOP_CAP iterations so an
/// rec_len=0 doesn't spin.
fn tolerant_dir_walk(buf: &[u8]) {
    let mut off = 0usize;
    for _ in 0..HOP_CAP {
        if off + core::mem::size_of::<DirEntryHead>() > buf.len() { return; }
        let hdr: DirEntryHead = unsafe {
            core::ptr::read_unaligned(buf[off..].as_ptr() as *const DirEntryHead)
        };
        // Copy packed fields to locals.
        let rec_len = hdr.rec_len as usize;
        let name_len = hdr.name_len as usize;
        let _ino = hdr.inode;
        let _ft = hdr.file_type;
        // rec_len must be at least the header size, 4-aligned,
        // and fit in the remaining buffer. Anything else is
        // corrupt — bail the walk.
        if rec_len < 8 || rec_len % 4 != 0 || off + rec_len > buf.len() {
            return;
        }
        // name must fit within rec_len — we don't read the name
        // bytes but we do compute the slice bounds to mimic the
        // shape of the real walker.
        if 8 + name_len <= rec_len && off + 8 + name_len <= buf.len() {
            let _name = &buf[off + 8 .. off + 8 + name_len];
        }
        let next = off.checked_add(rec_len);
        match next {
            Some(n) if n > off => off = n,
            _ => return,
        }
    }
}

#[test]
fn fuzz_extent_header_parse() {
    let mut rng = Rng::new(0x5eed_0003);
    for _ in 0..ITERS {
        // 12 bytes of header + four 12-byte entries.
        let bytes = rng.bytes(12 + 48);
        let hdr: ExtentHeader = unsafe {
            core::ptr::read_unaligned(bytes.as_ptr() as *const ExtentHeader)
        };
        // Read every field. Copy to locals so we never touch a
        // reference into a packed struct.
        let _m = hdr.eh_magic;
        let _e = hdr.eh_entries;
        let _x = hdr.eh_max;
        let _d = hdr.eh_depth;
        let _g = hdr.eh_generation;
    }
}

#[test]
fn fuzz_xattr_entry_walk() {
    let mut rng = Rng::new(0x5eed_0004);
    for _ in 0..ITERS {
        let buf = rng.bytes(4096);
        let mut count = 0u32;
        tolerant_xattr_walk(&buf, 32, u64::MAX, |_| { count += 1; });
        // count is just drained so LLVM can't DCE the walk.
        std::hint::black_box(count);
    }
}

/// Mirrors `pass1::walk_xattr_entries`. Returns after HOP_CAP
/// iterations / terminator / buffer end. Never panics on any
/// 4 KiB input — we guard every slice bound with an explicit
/// length check.
fn tolerant_xattr_walk<F: FnMut(u32)>(
    buf: &[u8],
    start_off: usize,
    max_inode: u64,
    mut cb: F,
) {
    let mut off = start_off;
    for _ in 0..HOP_CAP {
        if off + 16 > buf.len() { return; }
        let name_len = buf[off];
        if name_len == 0 && buf[off + 1] == 0 {
            if buf[off + 2 .. off + 16].iter().all(|&b| b == 0) {
                return;
            }
        }
        let value_inum = u32::from_le_bytes([
            buf[off + 4], buf[off + 5], buf[off + 6], buf[off + 7],
        ]);
        if value_inum != 0 && (value_inum as u64) <= max_inode {
            cb(value_inum);
        }
        let nlen = name_len as usize;
        let name_pad = (nlen + 3) & !3;
        let next = match (16usize).checked_add(name_pad).and_then(|a| off.checked_add(a)) {
            Some(n) if n > off => n,
            _ => return,
        };
        off = next;
    }
}

#[test]
fn fuzz_jbd2_sb_parse() {
    let mut rng = Rng::new(0x5eed_0005);
    for _ in 0..ITERS {
        let bytes = rng.bytes(1024);
        // SAFETY: JournalSuperblock is repr(C, packed) of POD
        // ints + byte arrays; every 1024-byte pattern is a
        // valid bit-level value.
        let sb: JournalSuperblock = unsafe {
            core::ptr::read_unaligned(bytes.as_ptr() as *const JournalSuperblock)
        };
        // Read every multi-byte field with the correct
        // big-endian decode. Assigning to locals avoids
        // creating references into the packed struct.
        let h_magic     = sb.s_header.h_magic;
        let h_blocktype = sb.s_header.h_blocktype;
        let h_sequence  = sb.s_header.h_sequence;
        let _ = u32::from_be(h_magic);
        let _ = u32::from_be(h_blocktype);
        let _ = u32::from_be(h_sequence);

        let blocksize = sb.s_blocksize;
        let maxlen = sb.s_maxlen;
        let first = sb.s_first;
        let sequence = sb.s_sequence;
        let start = sb.s_start;
        let errno = sb.s_errno;
        let feat_c = sb.s_feature_compat;
        let feat_i = sb.s_feature_incompat;
        let feat_r = sb.s_feature_ro_compat;
        let nr_users = sb.s_nr_users;
        let dynsuper = sb.s_dynsuper;
        let max_tx = sb.s_max_transaction;
        let max_tx_data = sb.s_max_trans_data;
        let ct = sb.s_checksum_type;
        let nfc = sb.s_num_fc_blks;
        let head = sb.s_head;
        let csum = sb.s_checksum;
        let _ = u32::from_be(blocksize);
        let _ = u32::from_be(maxlen);
        let _ = u32::from_be(first);
        let _ = u32::from_be(sequence);
        let _ = u32::from_be(start);
        let _ = i32::from_be(errno);
        let _ = u32::from_be(feat_c);
        let _ = u32::from_be(feat_i);
        let _ = u32::from_be(feat_r);
        let _ = u32::from_be(nr_users);
        let _ = u32::from_be(dynsuper);
        let _ = u32::from_be(max_tx);
        let _ = u32::from_be(max_tx_data);
        let _ = u32::from_be(nfc);
        let _ = u32::from_be(head);
        let _ = u32::from_be(csum);
        let _ = ct;
        let _ = sb.s_uuid;
    }
}

#[test]
fn fuzz_crc32c_cont() {
    let mut rng = Rng::new(0x5eed_0006);
    for _ in 0..ITERS {
        let len = rng.range(65537) as usize; // 0..=65536
        let data = rng.bytes(len);
        let seed = (rng.next_u64() & 0xFFFF_FFFF) as u32;
        let a = crc32c_cont(seed, &data);
        // Repeatability: identical input → identical output.
        let b = crc32c_cont(seed, &data);
        assert_eq!(a, b, "crc32c_cont not deterministic for len={len}");
    }
}

#[test]
fn fuzz_dirhash() {
    let mut rng = Rng::new(0x5eed_0007);
    for _ in 0..ITERS {
        let nlen = rng.range(513) as usize; // 0..=512
        let name = rng.bytes(nlen);
        let seed = [
            (rng.next_u64() & 0xFFFF_FFFF) as u32,
            (rng.next_u64() & 0xFFFF_FFFF) as u32,
            (rng.next_u64() & 0xFFFF_FFFF) as u32,
            (rng.next_u64() & 0xFFFF_FFFF) as u32,
        ];
        // Version 0 (LEGACY) — seed-independent.
        let (h0, _m0) = dirhash(DX_HASH_LEGACY, &name, &seed);
        // Low bit must be cleared by the spec contract.
        assert_eq!(h0 & 1, 0, "legacy dirhash left low bit set");
        // Version 2 (TEA).
        let (h2, _m2) = dirhash(DX_HASH_TEA, &name, &seed);
        assert_eq!(h2 & 1, 0, "tea dirhash left low bit set");
    }
}
