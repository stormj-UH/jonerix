//! Unit tests for anvil_core::casefold.
//!
//! First-pass scope: ASCII-only fold. The non-ASCII test below is
//! pinned to the **current** (byte-compare) behaviour, explicitly
//! calling out that Unicode fold is a deliberate TODO waiting on
//! the `CaseFolding.txt`-derived table.

use anvil_core::casefold;

#[test]
fn ascii_fold_equal() {
    assert!(casefold::eq(b"HELLO", b"hello"));
    assert!(casefold::eq(b"MiXeD", b"mixed"));
    assert!(casefold::eq(b"abc", b"abc"));
    assert!(casefold::eq(b"File.TXT", b"file.txt"));
}

#[test]
fn different_names_stay_different() {
    assert!(!casefold::eq(b"foo", b"bar"));
    assert!(!casefold::eq(b"hello", b"hellp"));
    assert!(!casefold::eq(b"short", b"shorter"));
}

/// Unicode fold not yet implemented. `Ü` (U+00DC, 0xC3 0x9C in
/// UTF-8) and `ü` (U+00FC, 0xC3 0xBC) are *not* equal under the
/// ASCII-only fold. When the Unicode 12.1 fold table lands
/// (derived from the Unicode Consortium`s public
/// `CaseFolding.txt`, permissive license), flip this assertion.
#[test]
fn non_ascii_left_alone_until_unicode_table_lands() {
    let u_upper = b"\xc3\x9c";
    let u_lower = b"\xc3\xbc";
    assert!(!casefold::eq(u_upper, u_lower),
        "ASCII-only fold: non-ASCII case pair should still compare \
         unequal; when Unicode fold lands, flip this test");
}

#[test]
fn normalize_preserves_length_and_non_ascii() {
    let input = b"\xc3\x9cABC\xc3\xbc";
    let out = casefold::normalize(input);
    assert_eq!(out.len(), input.len());
    // ASCII letters lowered; non-ASCII bytes untouched.
    assert_eq!(&out[..], b"\xc3\x9cabc\xc3\xbc");
}

#[test]
fn cf_hash_matches_folded_dirhash() {
    let seed = [0x01234567u32, 0x89abcdef, 0xdeadbeef, 0xfeedface];
    let a = casefold::cf_hash(b"Hello.TXT", &seed, 2);
    let b = casefold::cf_hash(b"hello.txt", &seed, 2);
    assert_eq!(a, b, "cf_hash must fold before hashing");
}
