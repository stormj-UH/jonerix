//! Directory entries. ext4 uses the "ext2-style" linked-list dir
//! format with the FILETYPE feature (so d_name_len fits in one byte
//! and the second byte is file_type). hashed htree indexing is only
//! enabled when EXT4_INDEX_FL flips in the inode; we stick to
//! linear dirs for the initial root / lost+found.

#[repr(C, packed)]
#[derive(Clone, Copy)]
pub struct DirEntryHead {
    pub inode:    u32,   // 0 ⇒ unused slot
    pub rec_len:  u16,   // total entry length, incl this header
    pub name_len: u8,
    pub file_type: u8,
    // name follows
}

const _: () = assert!(core::mem::size_of::<DirEntryHead>() == 8);

pub const DIR_ENTRY_ALIGN: usize = 4;

/// Round `n` up to the nearest multiple of DIR_ENTRY_ALIGN.
pub fn align4(n: usize) -> usize {
    (n + DIR_ENTRY_ALIGN - 1) & !(DIR_ENTRY_ALIGN - 1)
}

/// Append a directory entry to `buf`. Sets rec_len such that this
/// entry fills the remaining space up to `block_end_offset` — that
/// way the last entry always consumes the block tail, which is what
/// the kernel expects for a linear dir block.
pub fn append_dir_entry(
    buf: &mut Vec<u8>,
    inode: u32,
    file_type: u8,
    name: &[u8],
    last_in_block: bool,
    block_size: usize,
) {
    let min_len = 8 + align4(name.len());
    let rec_len = if last_in_block {
        block_size - buf.len()
    } else {
        min_len
    };

    buf.extend_from_slice(&inode.to_le_bytes());
    buf.extend_from_slice(&(rec_len as u16).to_le_bytes());
    buf.push(name.len() as u8);
    buf.push(file_type);
    buf.extend_from_slice(name);
    // pad to rec_len
    let pad = rec_len - (8 + name.len());
    for _ in 0..pad { buf.push(0); }
}

/// Tail checksum structure that lives in the last slot of a
/// metadata_csum-enabled dir block.
#[repr(C, packed)]
#[derive(Clone, Copy, Default)]
pub struct DirEntryTail {
    pub det_reserved_zero1: u32,
    pub det_rec_len:        u16,    // always 12
    pub det_reserved_zero2: u8,     // 0
    pub det_reserved_ft:    u8,     // 0xDE
    pub det_checksum:       u32,
}

const _: () = assert!(core::mem::size_of::<DirEntryTail>() == 12);
