//! Read-side helpers shared by e2fsck. Opens a device, loads the
//! superblock + GDT, and hands back typed views into each structure.

use crate::consts::*;
use crate::group_desc::GroupDesc64;
use crate::inode::Inode;
use crate::io::Device;
use crate::superblock::Superblock;
use std::io;

pub struct Fs {
    pub dev: Device,
    pub sb:  Superblock,
    pub gdt: Vec<GroupDesc64>,
    pub groups_count: u64,
    pub block_size: u64,
    pub inode_size: u64,
    pub inodes_per_group: u64,
    pub blocks_per_group: u64,
    pub desc_size: u64,
    pub has_64bit: bool,
    /// Byte offset on disk where the primary GDT begins. Cached
    /// so the Phase 5 repair path can flush the in-memory GDT
    /// back without re-deriving the location.
    pub gdt_start_byte: u64,
}

impl Fs {
    pub fn open(path: &std::path::Path) -> io::Result<Self> {
        let mut dev = Device::open(path)?;

        // Load primary superblock at byte 1024, and fall back to
        // the sparse_super backup groups if the primary fails
        // sanity. Upstream prints "Superblock invalid, trying
        // backup blocks..." in this situation and proceeds with
        // the first good backup.
        let mut sb_bytes = [0u8; 1024];
        dev.read_at(1024, &mut sb_bytes)?;
        let mut sb: Superblock = unsafe { *(sb_bytes.as_ptr() as *const Superblock) };
        if !sb_looks_sane(&sb, dev.size) {
            eprintln!("Superblock invalid, trying backup blocks...");
            let recovered = try_backup_sb(&mut dev, &sb)?;
            sb = recovered;
        }

        Self::from_raw_sb(dev, sb)
    }

    /// Construct an `Fs` from an already-loaded superblock,
    /// skipping the byte-1024 primary read. Used by dumpe2fs
    /// `-o superblock=N` to let operators inspect a backup SB
    /// when the primary is corrupt: the caller reads the
    /// backup bytes from the requested block, decodes them
    /// into a `Superblock`, and hands both to this helper.
    /// Derived fields (block_size, groups_count, GDT, ...)
    /// are rebuilt from the provided SB, and the GDT is
    /// read from the primary location implied by it.
    pub fn from_raw_sb(mut dev: Device, sb: Superblock) -> io::Result<Self> {
        let block_size = sb.block_size();
        let blocks_per_group = sb.s_blocks_per_group as u64;
        let inodes_per_group = sb.s_inodes_per_group as u64;
        let inode_size = if sb.s_rev_level == 0 { 128 } else { sb.s_inode_size as u64 };
        let total_blocks = sb.blocks_count();
        if blocks_per_group == 0 {
            return Err(io::Error::new(io::ErrorKind::InvalidData,
                "superblock has zero blocks_per_group"));
        }
        let groups_count = (total_blocks + blocks_per_group - 1) / blocks_per_group;
        let has_64bit = sb.s_feature_incompat & EXT4_FEATURE_INCOMPAT_64BIT != 0;
        let desc_size = if has_64bit {
            sb.s_desc_size.max(64) as u64
        } else {
            32
        };

        // Load GDT. The superblock lives at byte 1024 of the
        // device; for block_size==1024 it occupies block 1, and
        // for larger block sizes it sits inside block 0. The
        // GDT follows in the next block. s_first_data_block is
        // a separate concept (first data block) and can be 0 or
        // 1 regardless, so don't derive GDT placement from it.
        let sb_block = if block_size == 1024 { 1u64 } else { 0u64 };
        let gdt_start = (sb_block + 1) * block_size;
        let gdt_bytes_total = groups_count * desc_size;
        let mut gdt_bytes = vec![0u8; gdt_bytes_total as usize];
        dev.read_at(gdt_start, &mut gdt_bytes)?;
        let mut gdt = Vec::with_capacity(groups_count as usize);
        for gi in 0..groups_count {
            let off = (gi * desc_size) as usize;
            let mut d = GroupDesc64::default();
            let src = &gdt_bytes[off..off + desc_size as usize];
            unsafe {
                core::ptr::copy_nonoverlapping(
                    src.as_ptr(),
                    &mut d as *mut _ as *mut u8,
                    src.len().min(core::mem::size_of::<GroupDesc64>()),
                );
            }
            gdt.push(d);
        }

        Ok(Fs {
            dev, sb, gdt,
            groups_count,
            block_size,
            inode_size,
            inodes_per_group,
            blocks_per_group,
            desc_size,
            has_64bit,
            gdt_start_byte: gdt_start,
        })
    }

    /// Absolute block numbers of the block bitmap / inode bitmap /
    /// inode table for a given group.
    pub fn group_block_bitmap(&self, g: u64) -> u64 {
        let d = &self.gdt[g as usize];
        let lo = d.bg_block_bitmap_lo as u64;
        let hi = if self.has_64bit { d.bg_block_bitmap_hi as u64 } else { 0 };
        (hi << 32) | lo
    }
    pub fn group_inode_bitmap(&self, g: u64) -> u64 {
        let d = &self.gdt[g as usize];
        let lo = d.bg_inode_bitmap_lo as u64;
        let hi = if self.has_64bit { d.bg_inode_bitmap_hi as u64 } else { 0 };
        (hi << 32) | lo
    }
    pub fn group_inode_table(&self, g: u64) -> u64 {
        let d = &self.gdt[g as usize];
        let lo = d.bg_inode_table_lo as u64;
        let hi = if self.has_64bit { d.bg_inode_table_hi as u64 } else { 0 };
        (hi << 32) | lo
    }

    /// Read a single block into `out` (which must be block_size).
    /// Reads past the device return all-zero — avoids
    /// 'failed to fill whole buffer' cascading failures on
    /// bigalloc / pathological inodes whose block pointers
    /// escape the image. Upstream's buffered IO has the same
    /// property.
    pub fn read_block(&mut self, blk: u64, out: &mut [u8]) -> io::Result<()> {
        debug_assert!(out.len() == self.block_size as usize);
        let off = blk * self.block_size;
        if off >= self.dev.size {
            for b in out.iter_mut() { *b = 0; }
            return Ok(());
        }
        // Zero-fill on partial read (e.g. last block straddling EOF).
        match self.dev.read_at(off, out) {
            Ok(()) => Ok(()),
            Err(_) => {
                for b in out.iter_mut() { *b = 0; }
                Ok(())
            }
        }
    }

    /// Read inode N (1-based). Returns a fully parsed Inode plus
    /// the raw trailing bytes (for checksum verification later).
    pub fn read_inode(&mut self, ino: u32) -> io::Result<Inode> {
        if ino == 0 || ino as u64 > self.sb.s_inodes_count as u64 {
            return Err(io::Error::new(io::ErrorKind::InvalidInput, "inode out of range"));
        }
        let group = (ino as u64 - 1) / self.inodes_per_group;
        let idx   = (ino as u64 - 1) % self.inodes_per_group;
        let table = self.group_inode_table(group);
        let byte  = table * self.block_size + idx * self.inode_size;
        let mut buf = vec![0u8; self.inode_size as usize];
        self.dev.read_at(byte, &mut buf)?;
        let mut inode = Inode::default();
        let n = buf.len().min(core::mem::size_of::<Inode>());
        unsafe {
            core::ptr::copy_nonoverlapping(
                buf.as_ptr(),
                &mut inode as *mut _ as *mut u8,
                n,
            );
        }
        Ok(inode)
    }

    /// Serialize the in-memory superblock and write it back to the
    /// primary slot at byte 1024. Used by the Phase 5 repair path.
    /// Backup superblocks are not touched here — callers that want
    /// to propagate to sparse_super backups iterate groups
    /// separately.
    pub fn write_superblock(&mut self) -> io::Result<()> {
        let bytes: [u8; 1024] = unsafe {
            *(&self.sb as *const Superblock as *const [u8; 1024])
        };
        self.dev.write_at(1024, &bytes)
    }

    /// Serialize the in-memory GDT and write it back to the primary
    /// GDT slot. Each descriptor is written at `desc_size` stride
    /// (64 bytes when 64BIT is set, 32 otherwise).
    pub fn write_gdt(&mut self) -> io::Result<()> {
        let ds = self.desc_size as usize;
        let mut buf = vec![0u8; self.gdt.len() * ds];
        for (gi, d) in self.gdt.iter().enumerate() {
            let src: [u8; 64] = unsafe {
                *(d as *const GroupDesc64 as *const [u8; 64])
            };
            let take = core::cmp::min(ds, 64);
            buf[gi * ds .. gi * ds + take].copy_from_slice(&src[..take]);
        }
        self.dev.write_at(self.gdt_start_byte, &buf)
    }

    /// Return the full on-disk inode slot (`inode_size` bytes).
    /// Used by callers that need to parse the inline-xattr area
    /// past the base 128-byte struct.
    pub fn read_inode_raw(&mut self, ino: u32) -> io::Result<Vec<u8>> {
        if ino == 0 || ino as u64 > self.sb.s_inodes_count as u64 {
            return Err(io::Error::new(io::ErrorKind::InvalidInput, "inode out of range"));
        }
        let group = (ino as u64 - 1) / self.inodes_per_group;
        let idx   = (ino as u64 - 1) % self.inodes_per_group;
        let table = self.group_inode_table(group);
        let byte  = table * self.block_size + idx * self.inode_size;
        let mut buf = vec![0u8; self.inode_size as usize];
        self.dev.read_at(byte, &mut buf)?;
        Ok(buf)
    }

    pub fn free_blocks(&self) -> u64 { self.sb.free_blocks() }
    pub fn free_inodes(&self) -> u64 { self.sb.s_free_inodes_count as u64 }
    pub fn total_blocks(&self) -> u64 { self.sb.blocks_count() }
    pub fn total_inodes(&self) -> u64 { self.sb.s_inodes_count as u64 }

    /// True if the filesystem advertises metadata_csum and we
    /// should verify per-structure CRC32C fields.
    pub fn has_metadata_csum(&self) -> bool {
        self.sb.s_feature_ro_compat & EXT4_FEATURE_RO_COMPAT_METADATA_CSUM != 0
    }

    /// CRC-32C seed for every metadata_csum structure. With
    /// CSUM_SEED feature the SB stores it explicitly; otherwise
    /// seed = crc32c(~0, uuid).
    pub fn csum_seed(&self) -> u32 {
        if self.sb.s_feature_incompat & EXT4_FEATURE_INCOMPAT_CSUM_SEED != 0 {
            self.sb.s_checksum_seed
        } else {
            // Upstream: crc32c_le(0xFFFFFFFF, uuid, 16) — raw
            // state, no final XOR. See ext2fs_init_csum_seed.
            crate::crc::crc32c_cont(0xFFFFFFFF, &self.sb.s_uuid)
        }
    }

    /// Verify a group's block-bitmap checksum. Stored in
    /// bg_block_bitmap_csum_lo (offset 0x18 of GDT) + _hi
    /// (offset 0x38 when 64BIT + desc_size>=0x3A).
    /// CRC = crc32c_cont(fs_seed, bitmap_bytes).
    /// Algorithm from ext2fs_block_bitmap_csum_set decomp.
    pub fn verify_block_bitmap_csum(&self, gi: u64, bitmap: &[u8]) -> bool {
        if !self.has_metadata_csum() { return true; }
        let d = &self.gdt[gi as usize];
        let lo = d.bg_block_bitmap_csum_lo as u32;
        let hi = if self.has_64bit && self.desc_size >= 0x3A {
            d.bg_block_bitmap_csum_hi as u32
        } else { 0 };
        let stored = (hi << 16) | lo;

        let computed = crate::crc::crc32c_cont(self.csum_seed(), bitmap);
        let want = if hi != 0 { computed } else { computed & 0xFFFF };
        want == stored
    }

    /// Verify a group's inode-bitmap checksum. Same scheme as
    /// block-bitmap but at bg_inode_bitmap_csum_lo (offset 0x1A)
    /// and _hi (offset 0x3A when 64BIT).
    pub fn verify_inode_bitmap_csum(&self, gi: u64, bitmap: &[u8]) -> bool {
        if !self.has_metadata_csum() { return true; }
        let d = &self.gdt[gi as usize];
        let lo = d.bg_inode_bitmap_csum_lo as u32;
        let hi = if self.has_64bit && self.desc_size >= 0x3C {
            d.bg_inode_bitmap_csum_hi as u32
        } else { 0 };
        let stored = (hi << 16) | lo;

        // Inode bitmap csum inputs only the bytes covering the
        // actual inodes (ceil(inodes_per_group / 8)), not the
        // whole bitmap block — upstream's
        // ext2fs_inode_bitmap_csum_set passes size=bytes-in-use
        // rather than block_size.
        let bytes_used = (self.inodes_per_group + 7) / 8;
        let sz = core::cmp::min(bytes_used as usize, bitmap.len());
        let computed = crate::crc::crc32c_cont(self.csum_seed(), &bitmap[..sz]);
        let want = if hi != 0 { computed } else { computed & 0xFFFF };
        want == stored
    }

    /// Verify an xattr block's checksum. ext4_xattr_header has
    /// h_checksum at offset 0x10 (u32). The CRC covers:
    ///   crc32c_cont(seed, block_num_le_u64)
    ///   crc32c_cont(_,   block_bytes_with_csum_zeroed)
    /// Algorithm from ext2fs_ext_attr_block_csum_set decomp.
    pub fn verify_xattr_block_checksum(
        &self,
        block: &[u8],
        block_num: u64,
    ) -> bool {
        if !self.has_metadata_csum() { return true; }
        let bs = self.block_size as usize;
        if block.len() < bs || bs < 0x14 { return true; }
        // Magic check — ext4_xattr_header h_magic is 0xEA020000
        // at offset 0; a block that doesn't have that magic
        // isn't an xattr block.
        let magic = u32::from_le_bytes([block[0], block[1], block[2], block[3]]);
        if magic != 0xEA020000 {
            return true;
        }
        let stored = u32::from_le_bytes([
            block[0x10], block[0x11], block[0x12], block[0x13]
        ]);
        let mut buf = block.to_vec();
        buf[0x10] = 0; buf[0x11] = 0; buf[0x12] = 0; buf[0x13] = 0;

        let seed = self.csum_seed();
        let s1 = crate::crc::crc32c_cont(seed, &block_num.to_le_bytes());
        let computed = crate::crc::crc32c_cont(s1, &buf);
        computed == stored
    }

    /// Verify a directory block's tail checksum. The dir block
    /// format with metadata_csum stores an ext4_dir_entry_tail
    /// in the final 12 bytes; its `det_checksum` (last 4 bytes)
    /// is crc32c over the block's first (block_size - 4) bytes,
    /// seeded with inode_num + generation.
    pub fn verify_dir_block_checksum(
        &self,
        block: &[u8],
        inode_num: u32,
        generation: u32,
    ) -> bool {
        if !self.has_metadata_csum() { return true; }
        let bs = self.block_size as usize;
        if block.len() < bs { return true; }
        // The dir tail csum only exists when the block ends in
        // an ext4_dir_entry_tail marker — 12 bytes laid out as
        // (inode=0, rec_len=12, name_len=0, file_type=0xDE, csum).
        // Without that marker the block is a plain linear dir
        // and has no trailing csum to verify.
        let tail = &block[bs - 12..bs];
        let inode0 = u32::from_le_bytes([tail[0], tail[1], tail[2], tail[3]]);
        let rec_len = u16::from_le_bytes([tail[4], tail[5]]);
        let name_len = tail[6];
        let file_type = tail[7];
        if inode0 != 0 || rec_len != 12 || name_len != 0 || file_type != 0xDE {
            return true;
        }
        let stored = u32::from_le_bytes([tail[8], tail[9], tail[10], tail[11]]);
        let seed = self.csum_seed();
        let s1 = crate::crc::crc32c_cont(seed, &inode_num.to_le_bytes());
        let s2 = crate::crc::crc32c_cont(s1, &generation.to_le_bytes());
        // The CRC input is block[..bs-12] — the entire trailing
        // ext4_dir_entry_tail (marker + csum) is excluded, not
        // just the csum word. Verified against
        // ext2fs_dir_block_csum_set decomp at libext2fs+0x1ecb0.
        let computed = crate::crc::crc32c_cont(s2, &block[..bs - 12]);
        computed == stored
    }

    /// Verify an external extent-tree block's tail checksum.
    /// Only used when metadata_csum is set; otherwise returns
    /// true. The `inode_num` and `generation` are the owning
    /// inode's fields (same as the inode-csum seed stack).
    ///
    /// The tail checksum lives at byte offset 12 * (eh_entries+1)
    /// from the start of the extent block — immediately after
    /// the last extent record — and its 4 bytes are zeroed for
    /// the CRC input. Formula:
    ///   csum = crc32c_cont(fs_seed, inode_num_le)
    ///   csum = crc32c_cont(csum, generation_le)
    ///   csum = crc32c_cont(csum, block_bytes_with_tail_zeroed)
    pub fn verify_extent_block_checksum(
        &self,
        block: &[u8],
        inode_num: u32,
        generation: u32,
    ) -> bool {
        if !self.has_metadata_csum() { return true; }
        if block.len() < 12 { return true; }
        let eh_entries = u16::from_le_bytes([block[4], block[5]]) as usize;
        let csum_off = 12 * (eh_entries + 1);
        if csum_off + 4 > block.len() { return true; }
        let stored = u32::from_le_bytes([
            block[csum_off], block[csum_off+1],
            block[csum_off+2], block[csum_off+3]
        ]);
        // Verified against ext2fs_extent_block_csum_set decomp:
        // the CRC is over exactly the header + entries (bytes
        // [0..12*(eh_entries+1))) — the tail csum word is NOT
        // part of the input. No zeroing needed.
        let seed = self.csum_seed();
        let s1 = crate::crc::crc32c_cont(seed, &inode_num.to_le_bytes());
        let s2 = crate::crc::crc32c_cont(s1, &generation.to_le_bytes());
        let computed = crate::crc::crc32c_cont(s2, &block[..csum_off]);
        computed == stored
    }

    /// Verify a group descriptor's checksum against bg_checksum.
    /// Returns Ok(true) if it matches, Ok(false) if not. Handles
    /// both the modern metadata_csum path (CRC-32C truncated to
    /// 16 bits) and the legacy GDT_CSUM path (CRC-16 over
    /// uuid + group_nr + desc).
    ///
    /// Algorithm layout verified against libext2fs v1.47.3's
    /// ext2fs_group_desc_csum(): with metadata_csum on,
    ///   csum = crc32c(seed, group_nr_le + desc_bytes_csum_zeroed)
    /// then truncate to 16 bits. With metadata_csum off but
    /// GDT_CSUM set,
    ///   csum = crc16(0xffff, uuid + group_nr_le + desc_bytes_csum_zeroed)
    pub fn verify_gdt_checksum(&self, group: u64) -> bool {
        let desc_size = self.desc_size as usize;
        let buf = self.gdt[group as usize].to_bytes(desc_size);
        // bg_checksum lives at offset 0x1E of the descriptor.
        let stored = u16::from_le_bytes([buf[0x1E], buf[0x1F]]);
        let group_nr_le = (group as u32).to_le_bytes();

        let computed: u32 = if self.has_metadata_csum() {
            // metadata_csum path: crc32c(seed, group_nr_le +
            // desc_with_csum_zeroed) over the whole descriptor.
            let mut z = buf.clone();
            z[0x1E] = 0; z[0x1F] = 0;
            let seed = self.csum_seed();
            let s1 = crate::crc::crc32c_cont(seed, &group_nr_le);
            crate::crc::crc32c_cont(s1, &z)
        } else if self.sb.s_feature_ro_compat & EXT4_FEATURE_RO_COMPAT_GDT_CSUM != 0 {
            // Legacy GDT_CSUM path — matches libext2fs v1.47.3
            // ext2fs_group_desc_csum:
            //   c = crc16(0xFFFFFFFF, uuid, 16)
            //   c = crc16(c_zx, group_nr_le, 4)
            //   c = crc16(c_zx, desc[0..30], 30)      // NOT desc_size
            //   if desc_size > 32:
            //       c = crc16(c_zx, desc[32..desc_size], desc_size-32)
            // Each crc16 returns u16; chaining zero-extends to u32.
            let c0 = crc16(0xFFFFFFFF, &self.sb.s_uuid) & 0xFFFF;
            let c1 = crc16(c0, &group_nr_le) & 0xFFFF;
            let c2 = crc16(c1, &buf[..0x1E]) & 0xFFFF;
            if desc_size > 0x20 {
                crc16(c2, &buf[0x20..desc_size]) & 0xFFFF
            } else {
                c2
            }
        } else {
            return true;
        };

        (computed as u16) == stored
    }

    /// Verify an on-disk inode's crc32c checksum. Returns Ok(true)
    /// if the inode's checksum field matches, Ok(false) if not.
    pub fn verify_inode_checksum(&mut self, ino_num: u32) -> std::io::Result<bool> {
        if !self.has_metadata_csum() { return Ok(true); }
        let group = (ino_num as u64 - 1) / self.inodes_per_group;
        let idx   = (ino_num as u64 - 1) % self.inodes_per_group;
        let table = self.group_inode_table(group);
        let byte  = table * self.block_size + idx * self.inode_size;
        let mut buf = vec![0u8; self.inode_size as usize];
        self.dev.read_at(byte, &mut buf)?;

        // An all-zero inode (unused slot in the bitmap or a
        // freshly-cleared deleted inode) verifies trivially.
        if buf.iter().all(|&b| b == 0) { return Ok(true); }

        // Pull the stored checksum fields. i_checksum_lo sits in
        // osd2 at inode offset 0x7C; i_checksum_hi at 0x82 —
        // but the hi half only *participates* in the csum if
        // i_extra_isize (at 0x80) is strictly greater than
        // sizeof(__u16) == 2. That's upstream's check in
        // ext2fs_inode_csum. An inode with extra_isize == 0
        // (reserved unused slots, pre-4.5 images) only uses the
        // low 16 bits.
        let csum_lo = u16::from_le_bytes([buf[0x7C], buf[0x7D]]);
        let extra_isize = if self.inode_size >= 256 {
            u16::from_le_bytes([buf[0x80], buf[0x81]])
        } else { 0 };
        let use_hi = self.inode_size >= 256 && extra_isize > 2;
        let stored: u32 = if use_hi {
            let hi = u16::from_le_bytes([buf[0x82], buf[0x83]]);
            ((hi as u32) << 16) | csum_lo as u32
        } else {
            csum_lo as u32
        };
        buf[0x7C] = 0; buf[0x7D] = 0;
        if use_hi {
            buf[0x82] = 0; buf[0x83] = 0;
        }

        let gen = u32::from_le_bytes([buf[0x64], buf[0x65], buf[0x66], buf[0x67]]);
        let seed = self.csum_seed();
        let num_le = ino_num.to_le_bytes();
        let gen_le = gen.to_le_bytes();
        let s1 = crate::crc::crc32c_cont(seed, &num_le);
        let s2 = crate::crc::crc32c_cont(s1, &gen_le);
        let computed = crate::crc::crc32c_cont(s2, &buf);

        let want = if use_hi { computed } else { computed & 0xFFFF };
        Ok(want == stored)
    }
}

/// CRC-32C seed for a filesystem given its SB. Computed here as
/// a free function so mkfs (which hasn't built a full Fs yet)
/// can call it while constructing the superblock.
pub fn csum_seed_for(sb: &Superblock) -> u32 {
    if sb.s_feature_incompat & EXT4_FEATURE_INCOMPAT_CSUM_SEED != 0 {
        sb.s_checksum_seed
    } else {
        crate::crc::crc32c_cont(0xFFFFFFFF, &sb.s_uuid)
    }
}

/// Compute the crc32c metadata_csum value for a GDT descriptor.
/// Caller is responsible for writing it back into the descriptor
/// at `bg_checksum` (offset 0x1E of the 64-byte struct).
///
///   csum = crc32c(seed, group_nr_le_u32)
///   csum = crc32c(csum, desc_bytes_with_csum_zeroed)
///
/// The crc32c field is truncated to the 16-bit `bg_checksum`
/// slot when the legacy `GDT_CSUM` feature is the only thing set;
/// under `metadata_csum` the low 16 bits of the 32-bit crc32c are
/// stored. This helper returns the full u32 and lets the caller
/// mask.
pub fn compute_gdt_csum(sb: &Superblock, group: u32, desc_bytes: &[u8]) -> u32 {
    let seed = csum_seed_for(sb);
    let mut z = desc_bytes.to_vec();
    if z.len() >= 0x20 { z[0x1E] = 0; z[0x1F] = 0; }
    let group_nr_le = group.to_le_bytes();
    let s1 = crate::crc::crc32c_cont(seed, &group_nr_le);
    crate::crc::crc32c_cont(s1, &z)
}

/// Compute an inode's crc32c metadata_csum. `inode_bytes` is the
/// full on-disk inode slot (`inode_size` bytes) with the two
/// checksum fields already zeroed. Caller zeros `i_checksum_lo`
/// at offset 0x7C and, when `i_extra_isize > 2`, also
/// `i_checksum_hi` at 0x82.
pub fn compute_inode_csum(
    sb: &Superblock, ino_num: u32, generation: u32, inode_bytes: &[u8],
) -> u32 {
    let seed = csum_seed_for(sb);
    let num_le = ino_num.to_le_bytes();
    let gen_le = generation.to_le_bytes();
    let s1 = crate::crc::crc32c_cont(seed, &num_le);
    let s2 = crate::crc::crc32c_cont(s1, &gen_le);
    crate::crc::crc32c_cont(s2, inode_bytes)
}

/// Compute the crc32c value for a bitmap block (block-bitmap or
/// inode-bitmap). Result is the full u32; caller stores the low
/// 16 into the `lo` half and the high 16 into `_hi` when the
/// descriptor has room for it.
pub fn compute_bitmap_csum(sb: &Superblock, bitmap: &[u8]) -> u32 {
    let seed = csum_seed_for(sb);
    crate::crc::crc32c_cont(seed, bitmap)
}

/// Compute the crc32c tail checksum for an extent-tree interior
/// or leaf block. `block_bytes` is the full block (including the
/// 4-byte tail csum slot at `12 * (entries + 1)`); those 4 bytes
/// at the tail are NOT part of the CRC input, so the caller does
/// not need to zero them — we hash over exactly the first
/// `12 * (entries + 1)` bytes (the eh_header + the `entries`
/// 12-byte records). Result is the full u32; caller stores it
/// little-endian at offset `12 * (entries + 1)` inside the block.
///
/// This mirrors `Fs::verify_extent_block_checksum`; kept as a
/// free function so writers that haven't yet mounted an `Fs`
/// (mkfs, resize2fs, a future multi-level extent emitter) can
/// stamp the csum without rebuilding the hash from scratch.
pub fn compute_extent_block_csum(
    sb: &Superblock,
    inode_num: u32,
    generation: u32,
    block_bytes: &[u8],
    entries: u16,
) -> u32 {
    let seed = csum_seed_for(sb);
    let s1 = crate::crc::crc32c_cont(seed, &inode_num.to_le_bytes());
    let s2 = crate::crc::crc32c_cont(s1, &generation.to_le_bytes());
    let csum_off = 12usize.saturating_mul(entries as usize + 1);
    let end = csum_off.min(block_bytes.len());
    crate::crc::crc32c_cont(s2, &block_bytes[..end])
}

/// CRC-16 with polynomial 0xA001 (reflected / ANSI variant) —
/// the legacy GDT_CSUM algorithm. Upstream's `ext2fs_crc16`
/// keeps the accumulator in a u32 register and only truncates
/// at the end; the high bits of the initial seed (e.g. the
/// 0xFFFFFFFF upstream passes for a fresh run) therefore feed
/// back through the >>8 shift on the first iteration. Track
/// in u32 to match byte-for-byte.
fn crc16(seed: u32, data: &[u8]) -> u32 {
    let mut c = seed;
    for &b in data {
        let idx = ((c ^ b as u32) & 0xFF) as usize;
        let mut t: u32 = idx as u32;
        for _ in 0..8 {
            t = if t & 1 != 0 { (t >> 1) ^ 0xA001 } else { t >> 1 };
        }
        c = (c >> 8) ^ t;
    }
    c
}

/// A superblock's own self-consistency check. Catches the common
/// corruption patterns — bad magic, total size exceeding the
/// device, block_size out of the documented 1 K..64 K range,
/// impossible inode counts.
fn sb_looks_sane(sb: &Superblock, device_bytes: u64) -> bool {
    if sb.s_magic != EXT4_SUPER_MAGIC { return false; }
    let log = sb.s_log_block_size;
    if log > 6 { return false; }                  // 1024 << 6 = 64 KiB
    let block_size = 1024u64 << log;
    let total_bytes = sb.blocks_count().saturating_mul(block_size);
    // Allow a modest overshoot; offsets on loopback + partition
    // tables routinely leave a few KiB of slack.
    if total_bytes > device_bytes + 65536 { return false; }
    if sb.s_blocks_per_group == 0 || sb.s_inodes_per_group == 0 { return false; }
    if sb.s_free_blocks_count_lo as u64 > sb.s_blocks_count_lo as u64
       && sb.s_blocks_count_hi == 0 && sb.s_free_blocks_count_hi == 0 {
        return false;
    }
    if sb.s_free_inodes_count > sb.s_inodes_count { return false; }
    if sb.s_inode_size != 0
       && (sb.s_inode_size < 128 || !sb.s_inode_size.is_power_of_two()) {
        return false;
    }
    true
}

/// Walk the SPARSE_SUPER backup-SB groups (0, 1, 3ⁿ, 5ⁿ, 7ⁿ) and
/// return the first one that self-checks. We use the
/// possibly-corrupt primary to estimate the block size — failing
/// that, scan the three common sizes.
fn try_backup_sb(dev: &mut Device, hint: &Superblock) -> io::Result<Superblock> {
    let hint_log = hint.s_log_block_size;      // copy out of packed
    let hint_bpg = hint.s_blocks_per_group;
    let try_block_sizes: Vec<u64> = if (0..=6).contains(&hint_log) {
        vec![1024u64 << hint_log]
    } else {
        vec![4096, 1024, 2048]
    };

    let backup_groups: Vec<u64> = (0..64).filter(|&g| is_backup_group(g)).collect();
    for bs in try_block_sizes {
        // Need blocks_per_group to know where each backup lives —
        // use hint if plausible, else the canonical 8*block_size.
        let bpg = if hint_bpg != 0 && hint_bpg as u64 <= 8 * bs {
            hint_bpg as u64
        } else {
            8 * bs
        };
        let first_data = if bs == 1024 { 1 } else { 0 };

        for g in &backup_groups {
            if *g == 0 { continue; } // primary already failed
            let group_start = first_data + g * bpg;
            let sb_byte = group_start * bs;
            let mut buf = [0u8; 1024];
            if dev.read_at(sb_byte, &mut buf).is_err() { continue; }
            let sb: Superblock = unsafe { *(buf.as_ptr() as *const Superblock) };
            if sb_looks_sane(&sb, dev.size) {
                return Ok(sb);
            }
        }
    }
    Err(io::Error::new(io::ErrorKind::InvalidData,
        "primary and all backup superblocks are corrupt"))
}

/// SPARSE_SUPER placement: groups 0, 1, and powers of 3/5/7.
fn is_backup_group(gi: u64) -> bool {
    if gi == 0 || gi == 1 { return true; }
    let mut p: u64 = 3;
    while p <= gi { if p == gi { return true; } p = match p.checked_mul(3) { Some(v) => v, None => break }; }
    let mut p: u64 = 5;
    while p <= gi { if p == gi { return true; } p = match p.checked_mul(5) { Some(v) => v, None => break }; }
    let mut p: u64 = 7;
    while p <= gi { if p == gi { return true; } p = match p.checked_mul(7) { Some(v) => v, None => break }; }
    false
}


#[cfg(test)]
mod tests {
    use super::*;
    use crate::superblock::Superblock;
    use crate::EXT4_FEATURE_RO_COMPAT_METADATA_CSUM;

    fn make_sb() -> Superblock {
        let mut sb = Superblock::zeroed();
        sb.s_uuid = *b"anvil-phase7c-x!";
        sb.s_feature_ro_compat |= EXT4_FEATURE_RO_COMPAT_METADATA_CSUM;
        sb
    }

    // Build a plausible extent leaf block: eh header + entries
    // records + tail csum slot. Stamp the csum via the compute
    // helper, then confirm: the value is deterministic, it is
    // stored little-endian at the right offset, and any tamper
    // of the hashed prefix (or of inode/generation) changes it.
    #[test]
    fn compute_extent_block_csum_roundtrip() {
        let sb = make_sb();
        let ino: u32 = 42;
        let gen: u32 = 0xDEAD_BEEF;
        let block_size = 4096usize;
        let entries: u16 = 5;

        let mut blk = vec![0u8; block_size];
        blk[0] = 0x0A; blk[1] = 0xF3;
        blk[2] = (entries & 0xff) as u8;
        blk[3] = ((entries >> 8) & 0xff) as u8;
        blk[4] = 0x06; blk[5] = 0x00;
        blk[6] = 0x01; blk[7] = 0x00;
        for i in 0..entries as usize {
            let off = 12 + 12 * i;
            for j in 0..12 {
                blk[off + j] = ((i * 12 + j) as u8).wrapping_add(0x5A);
            }
        }

        let csum = compute_extent_block_csum(&sb, ino, gen, &blk, entries);
        let csum_off = 12 * (entries as usize + 1);
        blk[csum_off..csum_off + 4].copy_from_slice(&csum.to_le_bytes());

        let recomputed = compute_extent_block_csum(&sb, ino, gen, &blk, entries);
        assert_eq!(recomputed, csum, "helper must be deterministic");

        let stored = u32::from_le_bytes([
            blk[csum_off], blk[csum_off + 1],
            blk[csum_off + 2], blk[csum_off + 3],
        ]);
        assert_eq!(stored, csum, "stamped csum must round-trip through the block");

        blk[20] ^= 0xFF;
        let after = compute_extent_block_csum(&sb, ino, gen, &blk, entries);
        assert_ne!(after, csum, "mutating the hashed prefix must change the csum");
        blk[20] ^= 0xFF;

        let other_ino = compute_extent_block_csum(&sb, ino + 1, gen, &blk, entries);
        assert_ne!(other_ino, csum);
        let other_gen = compute_extent_block_csum(&sb, ino, gen.wrapping_add(1), &blk, entries);
        assert_ne!(other_gen, csum);
    }

    // Sanity: with zero entries (empty leaf), we still hash the
    // 12-byte header, and the csum changes if the header changes.
    #[test]
    fn compute_extent_block_csum_empty_leaf() {
        let sb = make_sb();
        let mut blk = vec![0u8; 64];
        blk[0] = 0x0A; blk[1] = 0xF3;
        let a = compute_extent_block_csum(&sb, 1, 1, &blk, 0);
        blk[6] = 1;
        let b = compute_extent_block_csum(&sb, 1, 1, &blk, 0);
        assert_ne!(a, b);
    }
}
