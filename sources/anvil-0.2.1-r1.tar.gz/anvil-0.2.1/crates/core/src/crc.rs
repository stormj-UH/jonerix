//! CRC-32C (Castagnoli polynomial 0x1EDC6F41, reflected). Used by
//! ext4 metadata_csum. Implementation is a standard table-driven
//! reflected-CRC32 — the algorithm itself is mathematical prior
//! art (Castagnoli 1993) and the table is derivable from the
//! polynomial alone.

const POLY: u32 = 0x82F63B78; // reflected form of 0x1EDC6F41

static TABLE: [u32; 256] = {
    let mut t = [0u32; 256];
    let mut i = 0;
    while i < 256 {
        let mut c = i as u32;
        let mut j = 0;
        while j < 8 {
            c = if c & 1 != 0 { (c >> 1) ^ POLY } else { c >> 1 };
            j += 1;
        }
        t[i] = c;
        i += 1;
    }
    t
};

pub fn crc32c(seed: u32, data: &[u8]) -> u32 {
    let mut c = !seed;
    for &b in data {
        c = TABLE[((c as u8) ^ b) as usize] ^ (c >> 8);
    }
    !c
}

/// Continuation variant of CRC-32C used by e2fsprogs' libext2fs
/// (ext2fs_crc32c_le). Unlike the standard [`crc32c`] above, this
/// variant passes the state through without the
/// 0xFFFFFFFF pre/post XOR, so `crc32c_cont(crc32c_cont(x, a), b)`
/// ≡ `crc32c_cont(x, ab)`. Starting value for a fresh run is
/// 0xFFFFFFFF.
pub fn crc32c_cont(state: u32, data: &[u8]) -> u32 {
    let mut c = state;
    for &b in data {
        c = TABLE[((c as u8) ^ b) as usize] ^ (c >> 8);
    }
    c
}

// ext4 uses the seed differently per structure. The usual pattern:
//   csum = crc32c(uuid_seed, superblock_bytes_with_csum_zero)
// for the superblock itself, and
//   csum = crc32c(sb_csum_seed, structure_bytes_with_csum_zero)
// for per-group-descriptor and per-inode checksums.
