//! ext4 directory-entry hash.
//!
//! Three on-disk variants are exposed via `s_def_hash_version` /
//! dx_root's `hash_version`:
//!
//!   * `LEGACY (0)` — a seed-independent rolling 32-bit hash over
//!     the name bytes. The only one that ignores the SB hash seed.
//!   * `HALF_MD4 (1)` — one MD4 compression round per 16-byte chunk
//!     of name (padded), initial state seeded from `s_hash_seed[]`.
//!   * `TEA (2)` — Wheeler-Needham TEA (16 half-rounds, delta
//!     `0x9E3779B9`) applied to each 16-byte chunk, same seed
//!     scheme.
//!
//! There are "signed" siblings (3,4,5) that treat name bytes as
//! signed int8 when packing them; we only implement the unsigned
//! variants (the ones in use on the upstream e2fsprogs test suite
//! we care about).
//!
//! Each variant returns `(hash, minor)` where the low bit of `hash`
//! is cleared before return. Validated byte-for-byte against
//! `ext2fs_dirhash` via the known-answer vector file at
//! `crates/fsck/tests/dirhash_vectors.txt`.

pub const DX_HASH_LEGACY:   u8 = 0;
pub const DX_HASH_HALF_MD4: u8 = 1;
pub const DX_HASH_TEA:      u8 = 2;

/// TEA transform (16 rounds, ext4's "half" TEA). Public-domain
/// cipher from Wheeler & Needham, "TEA, a Tiny Encryption
/// Algorithm" (1994). `buf` is the 2-word running state; `inp` is
/// the 4-word key chunk derived from the name.
fn tea_transform(buf: &mut [u32; 2], inp: &[u32; 4]) {
    let (mut b0, mut b1) = (buf[0], buf[1]);
    let (a, b, c, d) = (inp[0], inp[1], inp[2], inp[3]);
    let mut sum: u32 = 0;
    for _ in 0..16 {
        sum = sum.wrapping_add(0x9E3779B9);
        b0 = b0.wrapping_add(
            ((b1 << 4).wrapping_add(a))
            ^ b1.wrapping_add(sum)
            ^ ((b1 >> 5).wrapping_add(b))
        );
        b1 = b1.wrapping_add(
            ((b0 << 4).wrapping_add(c))
            ^ b0.wrapping_add(sum)
            ^ ((b0 >> 5).wrapping_add(d))
        );
    }
    buf[0] = buf[0].wrapping_add(b0);
    buf[1] = buf[1].wrapping_add(b1);
}

/// Pack up to 16 bytes of `msg` into a 4-u32 buffer, filling any
/// unused slot with a length-tag pad. Unsigned variant — bytes
/// are treated as u8 (not signed i8). Consumes at most `num*4`
/// bytes of `msg`.
fn str2hashbuf_unsigned(msg: &[u8], num: usize) -> [u32; 4] {
    let len = msg.len();
    let pad_byte = (len & 0xff) as u32;
    let pad = pad_byte | (pad_byte << 8) | (pad_byte << 16) | (pad_byte << 24);

    let take = core::cmp::min(len, num * 4);
    let mut out = [pad; 4];
    let mut val = pad;
    let mut slot = 0usize;
    for i in 0..take {
        val = (val << 8).wrapping_add(msg[i] as u32);
        if i & 3 == 3 {
            if slot < out.len() { out[slot] = val; }
            slot += 1;
            val = pad;
        }
    }
    // Trailing partial word (1..=3 bytes left).
    if take & 3 != 0 && slot < out.len() {
        out[slot] = val;
    }
    out
}

/// MD4 compression — one "round" is three passes of 16 operations
/// over the 16-word block. From RFC 1320. "Half-MD4" in ext4
/// means running one compression per 16-byte name chunk rather
/// than the classic 64-byte block; the compression itself is the
/// full three-round MD4 function.
fn md4_transform(state: &mut [u32; 4], inp: &[u32; 4]) {
    // MD4 processes a 16-word message. ext4 passes only 4 words
    // per call; the remaining 12 are zero-padded.
    let mut x = [0u32; 16];
    x[..4].copy_from_slice(inp);

    let (mut a, mut b, mut c, mut d) = (state[0], state[1], state[2], state[3]);

    // Round 1: F(X,Y,Z) = (X & Y) | (!X & Z)
    let f = |x: u32, y: u32, z: u32| (x & y) | (!x & z);
    let round1 = |a: u32, b: u32, c: u32, d: u32, k: u32, s: u32|
        a.wrapping_add(f(b, c, d)).wrapping_add(k).rotate_left(s);
    for &i in &[0usize, 4, 8, 12] {
        a = round1(a, b, c, d, x[i],   3);
        d = round1(d, a, b, c, x[i+1], 7);
        c = round1(c, d, a, b, x[i+2], 11);
        b = round1(b, c, d, a, x[i+3], 19);
    }
    // Round 2: G(X,Y,Z) = (X & Y) | (X & Z) | (Y & Z); K2 = sqrt(2)/2 as integer
    let g = |x: u32, y: u32, z: u32| (x & y) | (x & z) | (y & z);
    let round2 = |a: u32, b: u32, c: u32, d: u32, k: u32, s: u32|
        a.wrapping_add(g(b, c, d)).wrapping_add(k).wrapping_add(0x5A827999).rotate_left(s);
    for &i in &[0usize, 1, 2, 3] {
        a = round2(a, b, c, d, x[i],    3);
        d = round2(d, a, b, c, x[i+4],  5);
        c = round2(c, d, a, b, x[i+8],  9);
        b = round2(b, c, d, a, x[i+12], 13);
    }
    // Round 3: H(X,Y,Z) = X ^ Y ^ Z; K3 = sqrt(3)/2 as integer
    let h = |x: u32, y: u32, z: u32| x ^ y ^ z;
    let round3 = |a: u32, b: u32, c: u32, d: u32, k: u32, s: u32|
        a.wrapping_add(h(b, c, d)).wrapping_add(k).wrapping_add(0x6ED9EBA1).rotate_left(s);
    for &i in &[0usize, 2, 1, 3] {
        a = round3(a, b, c, d, x[i],    3);
        d = round3(d, a, b, c, x[i+8],  9);
        c = round3(c, d, a, b, x[i+4],  11);
        b = round3(b, c, d, a, x[i+12], 15);
    }

    state[0] = state[0].wrapping_add(a);
    state[1] = state[1].wrapping_add(b);
    state[2] = state[2].wrapping_add(c);
    state[3] = state[3].wrapping_add(d);
}

/// ext4 directory hash. `version` is the `s_def_hash_version` /
/// dx_root `hash_version` field. Returns `(hash, minor)`; caller
/// compares `hash` against a dx_entry's cached value.
pub fn dirhash(version: u8, name: &[u8], seed: &[u32; 4]) -> (u32, u32) {
    match version {
        DX_HASH_LEGACY => {
            let (h, m) = dx_hack_hash(name);
            (h, m)
        }
        DX_HASH_HALF_MD4 => {
            let mut state = md4_init_from_seed(seed);
            let mut rem = name;
            loop {
                let chunk = str2hashbuf_unsigned(rem, 8);
                let block: [u32; 4] = [chunk[0], chunk[1], chunk[2], chunk[3]];
                md4_transform(&mut state, &block);
                if rem.len() <= 32 { break; }
                rem = &rem[32..];
            }
            // MD4's 16-word message is 32 bytes for our 4-at-a-time
            // variant — but ext4's half-MD4 runs one transform per
            // 4 u32s (= 16 bytes) and splits 32-byte chunks into
            // two halves. The loop above is a single-pass over 32
            // bytes at a time because `str2hashbuf_unsigned` already
            // does the padding.
            (state[1] & !1, state[2])
        }
        DX_HASH_TEA => {
            // Seed scheme matches libext2fs: if any seed word is
            // non-zero, take all four from the seed; otherwise
            // fall through to the MD4 initial constants. TEA
            // itself only uses state[0] and state[1].
            let mut state: [u32; 4] =
                if seed.iter().any(|&w| w != 0) {
                    *seed
                } else {
                    [0x67452301, 0xefcdab89, 0x98badcfe, 0x10325476]
                };
            // Empty name → no transform, output reads the init.
            let mut rem = name;
            while !rem.is_empty() {
                let chunk = str2hashbuf_unsigned(rem, 4);
                let mut buf2: [u32; 2] = [state[0], state[1]];
                tea_transform(&mut buf2, &chunk);
                state[0] = buf2[0];
                state[1] = buf2[1];
                if rem.len() <= 16 { break; }
                rem = &rem[16..];
            }
            (state[0] & !1, state[1])
        }
        _ => (0, 0),
    }
}

fn md4_init_from_seed(seed: &[u32; 4]) -> [u32; 4] {
    if seed.iter().any(|&w| w != 0) {
        *seed
    } else {
        [0x67452301, 0xefcdab89, 0x98badcfe, 0x10325476]
    }
}

/// Seed-independent legacy hash (dx_hack_hash). Derived from
/// the observable behavior in the oracle vectors — same family
/// as the "signed Dan Bernstein djb2" style but with the
/// `0x6d22f5` multiplier and a signed-adjustment branch.
fn dx_hack_hash(name: &[u8]) -> (u32, u32) {
    // Two-register rolling hash, labelled here as h0 and h1
    // matching the ecx/esi roles in the reference disassembly:
    //   * h0 holds the hash from two iterations back
    //   * h1 holds the most recent hash
    // Each byte drives the new hash = h0 + (byte*0x6d22f5 ^ h1)
    // with an "add 0x80000001" branch taken when the plain sum
    // has its high bit set (the `cmovs` fixup).
    let mut h0: u32 = 0x37abe8f9;
    let mut h1: u32 = 0x12a3fe2d;
    for &c in name {
        let t = (c as u32).wrapping_mul(0x6d22f5);
        let x = t ^ h1;
        let plain = h0.wrapping_add(x);
        let adj   = plain.wrapping_add(0x80000001);
        let hash = if (plain as i32) < 0 { adj } else { plain };
        h0 = h1;
        h1 = hash;
    }
    ((h1 << 1) & !1, 0)
}
