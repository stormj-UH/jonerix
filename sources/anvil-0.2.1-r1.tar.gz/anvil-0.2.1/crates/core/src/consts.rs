//! ext4 on-disk constants. All values are from the public
//! on-disk format spec, not e2fsprogs headers.

// Superblock magic at offset 0x38 of the 1024-byte block starting at
// byte 1024 on the device.
pub const EXT4_SUPER_MAGIC: u16 = 0xEF53;

// Superblock location on the device
pub const SB_OFFSET: u64 = 1024;
pub const SB_SIZE: usize = 1024;

// Reserved inodes
pub const EXT4_BAD_INO: u32 = 1;
pub const EXT4_ROOT_INO: u32 = 2;
pub const EXT4_USR_QUOTA_INO: u32 = 3;
pub const EXT4_GRP_QUOTA_INO: u32 = 4;
pub const EXT4_BOOT_LOADER_INO: u32 = 5;
pub const EXT4_UNDEL_DIR_INO: u32 = 6;
pub const EXT4_RESIZE_INO: u32 = 7;
pub const EXT4_JOURNAL_INO: u32 = 8;
pub const EXT4_FIRST_NON_RSV_INO: u32 = 11; // lost+found

// State flags (s_state)
pub const EXT4_VALID_FS: u16 = 0x0001;
pub const EXT4_ERROR_FS: u16 = 0x0002;
pub const EXT4_ORPHAN_FS: u16 = 0x0004;

// Error behaviour (s_errors)
pub const EXT4_ERRORS_CONTINUE: u16 = 1;
pub const EXT4_ERRORS_RO: u16 = 2;
pub const EXT4_ERRORS_PANIC: u16 = 3;

// Revision levels
pub const EXT4_GOOD_OLD_REV: u32 = 0;
pub const EXT4_DYNAMIC_REV: u32 = 1;
pub const EXT4_GOOD_OLD_INODE_SIZE: u16 = 128;

// Creator OS values (s_creator_os)
pub const EXT4_OS_LINUX: u32 = 0;

// Feature compat bits (s_feature_compat)
pub const EXT4_FEATURE_COMPAT_DIR_PREALLOC:    u32 = 0x0001;
pub const EXT4_FEATURE_COMPAT_IMAGIC_INODES:   u32 = 0x0002;
pub const EXT4_FEATURE_COMPAT_HAS_JOURNAL:     u32 = 0x0004;
pub const EXT4_FEATURE_COMPAT_EXT_ATTR:        u32 = 0x0008;
pub const EXT4_FEATURE_COMPAT_RESIZE_INODE:    u32 = 0x0010;
pub const EXT4_FEATURE_COMPAT_DIR_INDEX:       u32 = 0x0020;
pub const EXT4_FEATURE_COMPAT_LAZY_BG:         u32 = 0x0040;
pub const EXT4_FEATURE_COMPAT_SPARSE_SUPER2:   u32 = 0x0200;

// Feature incompat bits (s_feature_incompat)
pub const EXT4_FEATURE_INCOMPAT_COMPRESSION:   u32 = 0x0001;
pub const EXT4_FEATURE_INCOMPAT_FILETYPE:      u32 = 0x0002;
pub const EXT4_FEATURE_INCOMPAT_RECOVER:       u32 = 0x0004;
pub const EXT4_FEATURE_INCOMPAT_JOURNAL_DEV:   u32 = 0x0008;
pub const EXT4_FEATURE_INCOMPAT_META_BG:       u32 = 0x0010;
pub const EXT4_FEATURE_INCOMPAT_EXTENTS:       u32 = 0x0040;
pub const EXT4_FEATURE_INCOMPAT_64BIT:         u32 = 0x0080;
pub const EXT4_FEATURE_INCOMPAT_MMP:           u32 = 0x0100;
pub const EXT4_FEATURE_INCOMPAT_FLEX_BG:       u32 = 0x0200;
pub const EXT4_FEATURE_INCOMPAT_EA_INODE:      u32 = 0x0400;
pub const EXT4_FEATURE_INCOMPAT_DIRDATA:       u32 = 0x1000;
pub const EXT4_FEATURE_INCOMPAT_CSUM_SEED:     u32 = 0x2000;
pub const EXT4_FEATURE_INCOMPAT_LARGEDIR:      u32 = 0x4000;
pub const EXT4_FEATURE_INCOMPAT_INLINE_DATA:   u32 = 0x8000;
pub const EXT4_FEATURE_INCOMPAT_ENCRYPT:       u32 = 0x10000;
pub const EXT4_FEATURE_INCOMPAT_CASEFOLD:      u32 = 0x20000;

// Feature ro-compat bits (s_feature_ro_compat)
pub const EXT4_FEATURE_RO_COMPAT_SPARSE_SUPER:   u32 = 0x0001;
pub const EXT4_FEATURE_RO_COMPAT_LARGE_FILE:     u32 = 0x0002;
pub const EXT4_FEATURE_RO_COMPAT_BTREE_DIR:      u32 = 0x0004;
pub const EXT4_FEATURE_RO_COMPAT_HUGE_FILE:      u32 = 0x0008;
pub const EXT4_FEATURE_RO_COMPAT_GDT_CSUM:       u32 = 0x0010;
pub const EXT4_FEATURE_RO_COMPAT_DIR_NLINK:      u32 = 0x0020;
pub const EXT4_FEATURE_RO_COMPAT_EXTRA_ISIZE:    u32 = 0x0040;
pub const EXT4_FEATURE_RO_COMPAT_QUOTA:          u32 = 0x0100;
pub const EXT4_FEATURE_RO_COMPAT_BIGALLOC:       u32 = 0x0200;
pub const EXT4_FEATURE_RO_COMPAT_METADATA_CSUM:  u32 = 0x0400;
pub const EXT4_FEATURE_RO_COMPAT_PROJECT:        u32 = 0x2000;

// Default block sizes
pub const EXT4_MIN_BLOCK_LOG_SIZE: u32 = 10; //  1 KiB
pub const EXT4_MAX_BLOCK_LOG_SIZE: u32 = 16; // 64 KiB

// File mode helpers
pub const S_IFMT:  u16 = 0o170000;
pub const S_IFSOCK:u16 = 0o140000;
pub const S_IFLNK: u16 = 0o120000;
pub const S_IFREG: u16 = 0o100000;
pub const S_IFBLK: u16 = 0o060000;
pub const S_IFDIR: u16 = 0o040000;
pub const S_IFCHR: u16 = 0o020000;
pub const S_IFIFO: u16 = 0o010000;
pub const S_ISUID: u16 = 0o004000;
pub const S_ISGID: u16 = 0o002000;
pub const S_ISVTX: u16 = 0o001000;

// Dir entry file_type
pub const EXT4_FT_UNKNOWN:  u8 = 0;
pub const EXT4_FT_REG_FILE: u8 = 1;
pub const EXT4_FT_DIR:      u8 = 2;
pub const EXT4_FT_CHRDEV:   u8 = 3;
pub const EXT4_FT_BLKDEV:   u8 = 4;
pub const EXT4_FT_FIFO:     u8 = 5;
pub const EXT4_FT_SOCK:     u8 = 6;
pub const EXT4_FT_SYMLINK:  u8 = 7;

// Inode i_flags
pub const EXT4_INDEX_FL:    u32 = 0x00001000;
pub const EXT4_EXTENTS_FL:  u32 = 0x00080000;
pub const EXT4_INLINE_DATA_FL: u32 = 0x10000000;
pub const EXT4_CASEFOLD_FL:    u32 = 0x40000000;

// Extent magic
pub const EXT4_EXT_MAGIC: u16 = 0xF30A;

// Checksum types
pub const EXT4_CRC32C_CHKSUM: u8 = 1;

// MMP (Multiple-Mount Protection) magic + sequence values.
// See sb.s_mmp_block; the named block holds an ext4_mmp record
// whose first u32 is EXT4_MMP_MAGIC and whose second u32 is the
// sequence/state field.
pub const EXT4_MMP_MAGIC:     u32 = 0x004D_4D50;
pub const EXT4_MMP_SEQ_CLEAN: u32 = 0x0000_0000; // cleanly unmounted
pub const EXT4_MMP_SEQ_FSCK:  u32 = 0xFF4D_4D50; // fsck is in progress
pub const EXT4_MMP_SEQ_MAX:   u32 = 0xE24D_4D50; // currently mounted
