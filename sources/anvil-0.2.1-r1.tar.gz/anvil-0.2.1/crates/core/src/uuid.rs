//! RFC 4122 version-4 UUID, drawn from /dev/urandom. Keeps anvil
//! dependency-free — no `uuid` crate.

use std::io::Read;
use std::time::{SystemTime, UNIX_EPOCH};

fn fill_random(buf: &mut [u8]) {
    if let Ok(mut f) = std::fs::File::open("/dev/urandom") {
        let _ = f.read_exact(buf);
    }
}

pub fn v4() -> [u8; 16] {
    let mut b = [0u8; 16];
    fill_random(&mut b);
    // Per RFC 4122 §4.4: set version (4) and variant (10xxxxxx) bits.
    b[6] = (b[6] & 0x0F) | 0x40;
    b[8] = (b[8] & 0x3F) | 0x80;
    b
}

/// Time-flavored UUID: first 8 bytes = current unix nanos big-endian,
/// last 8 bytes random. Version nibble set to 1, variant to RFC 4122.
pub fn v1_like() -> [u8; 16] {
    let mut b = [0u8; 16];
    let nanos: u64 = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_nanos() as u64)
        .unwrap_or(0);
    b[..8].copy_from_slice(&nanos.to_be_bytes());
    let mut tail = [0u8; 8];
    fill_random(&mut tail);
    b[8..].copy_from_slice(&tail);
    b[6] = (b[6] & 0x0F) | 0x10;
    b[8] = (b[8] & 0x3F) | 0x80;
    b
}

/// All-zero UUID (clears s_uuid).
pub fn zero() -> [u8; 16] {
    [0u8; 16]
}

pub fn format(u: &[u8; 16]) -> String {
    format!(
        "{:02x}{:02x}{:02x}{:02x}-{:02x}{:02x}-{:02x}{:02x}-{:02x}{:02x}-{:02x}{:02x}{:02x}{:02x}{:02x}{:02x}",
        u[0],u[1],u[2],u[3], u[4],u[5], u[6],u[7], u[8],u[9],
        u[10],u[11],u[12],u[13],u[14],u[15]
    )
}
