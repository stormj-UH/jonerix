//! Walk an inode's extent tree and yield each data block the inode
//! owns. Used by fsck Pass 1 (mark blocks as claimed) and whenever
//! we need to read file bodies.

use crate::consts::*;
use crate::inode::{Extent, ExtentHeader, ExtentIdx, Inode};
use crate::fs::Fs;
use std::io;

pub struct ExtentRun {
    pub logical:  u32,   // logical block number within the file
    pub physical: u64,   // absolute device block
    pub length:   u16,   // blocks
}

/// Problems an extent-tree walk can surface. Each variant carries
/// the inode-relative context needed to produce an upstream-style
/// error line in the caller.
#[derive(Debug)]
pub enum ExtentError {
    ZeroLen        { logical: u32, physical: u64 },
    InvalidPhysical{ logical: u32, physical: u64, len: u16 },
    InteriorLblkMismatch { parent_start: u32, child_start: u32 },
    BadChildChecksum     { block: u64 },
    /// Emitted for each extent-tree interior node visited. Not
    /// really an error — pass 1 uses it to tally how many
    /// metadata blocks the extent tree occupies (which count
    /// toward i_blocks but don't cover any file data).
    InteriorNode        { block: u64 },
}

pub fn walk_extents<F: FnMut(ExtentRun)>(
    fs: &mut Fs,
    ino: &Inode,
    cb: F,
) -> io::Result<()> {
    walk_extents_validated(fs, ino, cb, |_| {})
}

/// Same as [`walk_extents`] but also invokes `err_cb` on each
/// problematic node. Lets fsck pass 1 surface ZeroLen /
/// InvalidPhysical / InteriorLblkMismatch without aborting.
pub fn walk_extents_validated<F, E>(
    fs: &mut Fs,
    ino: &Inode,
    mut cb: F,
    mut err_cb: E,
) -> io::Result<()>
where
    F: FnMut(ExtentRun),
    E: FnMut(ExtentError),
{
    walk_extents_with_csum(fs, ino, 0, &mut cb, &mut err_cb)
}

/// Like [`walk_extents_validated`] but takes the owning inode
/// number so child extent blocks' tail checksums can be verified
/// (metadata_csum feature).
pub fn walk_extents_with_csum<F, E>(
    fs: &mut Fs,
    ino: &Inode,
    inode_num: u32,
    cb: &mut F,
    err_cb: &mut E,
) -> io::Result<()>
where
    F: FnMut(ExtentRun),
    E: FnMut(ExtentError),
{
    if ino.i_flags & EXT4_EXTENTS_FL == 0 {
        walk_block_map(fs, ino, |r| cb(r))?;
        return Ok(());
    }
    let mut buf = vec![0u8; 60];
    unsafe {
        core::ptr::copy_nonoverlapping(
            core::ptr::addr_of!(ino.i_block) as *const u8,
            buf.as_mut_ptr(),
            60,
        );
    }
    let generation = ino.i_generation;
    walk_node_validated(fs, &buf, None, inode_num, generation, cb, err_cb)
}

fn walk_node_validated<F, E>(
    fs: &mut Fs,
    buf: &[u8],
    expected_start: Option<u32>,
    inode_num: u32,
    generation: u32,
    cb: &mut F,
    err_cb: &mut E,
) -> io::Result<()>
where F: FnMut(ExtentRun), E: FnMut(ExtentError)
{
    if buf.len() < 12 {
        return Err(io::Error::new(io::ErrorKind::InvalidData, "extent hdr truncated"));
    }
    let hdr: ExtentHeader = unsafe { core::ptr::read_unaligned(buf.as_ptr() as *const ExtentHeader) };
    let magic   = hdr.eh_magic;
    let entries = hdr.eh_entries as usize;
    let depth   = hdr.eh_depth;
    if magic != EXT4_EXT_MAGIC {
        return Err(io::Error::new(io::ErrorKind::InvalidData,
            format!("bad extent magic 0x{:04x}", magic)));
    }

    // Maximum plausible physical block. Anything ≥ filesystem
    // block count is bogus (the common poison value is u32::MAX /
    // 4294967295 — see f_extent_leaf_bad_extent).
    let max_phys = fs.total_blocks();

    if depth == 0 {
        for i in 0..entries {
            let off = 12 + i * 12;
            if off + 12 > buf.len() { break; }
            let e: Extent = unsafe { core::ptr::read_unaligned(buf[off..].as_ptr() as *const Extent) };
            let len = e.ee_len;
            let logical = e.ee_block;
            let physical = e.start();
            let real_len = if len > 32768 { len - 32768 } else { len };

            // Interior-node cross-check: the first extent's logical
            // must match what the parent index said.
            if i == 0 {
                if let Some(expected) = expected_start {
                    if expected != logical {
                        err_cb(ExtentError::InteriorLblkMismatch {
                            parent_start: expected, child_start: logical,
                        });
                    }
                }
            }

            if real_len == 0 {
                err_cb(ExtentError::ZeroLen { logical, physical });
                continue;
            }
            if physical >= max_phys || physical.saturating_add(real_len as u64) > max_phys {
                err_cb(ExtentError::InvalidPhysical { logical, physical, len: real_len });
                continue;
            }

            cb(ExtentRun { logical, physical, length: real_len });
        }
    } else {
        for i in 0..entries {
            let off = 12 + i * 12;
            if off + 12 > buf.len() { break; }
            let idx: ExtentIdx = unsafe { core::ptr::read_unaligned(buf[off..].as_ptr() as *const ExtentIdx) };
            let child_blk = ((idx.ei_leaf_hi as u64) << 32) | idx.ei_leaf_lo as u64;
            let child_expected = idx.ei_block;
            if child_blk >= max_phys {
                err_cb(ExtentError::InvalidPhysical {
                    logical: child_expected, physical: child_blk, len: 0,
                });
                continue;
            }
            err_cb(ExtentError::InteriorNode { block: child_blk });
            let mut child = vec![0u8; fs.block_size as usize];
            fs.read_block(child_blk, &mut child)?;
            // Verify the child's tail checksum before walking it
            // (metadata_csum only; no-op otherwise). Corruption
            // here still lets us descend and report per-extent
            // issues too — don't short-circuit.
            if !fs.verify_extent_block_checksum(&child, inode_num, generation) {
                err_cb(ExtentError::BadChildChecksum { block: child_blk });
            }
            walk_node_validated(fs, &child, Some(child_expected), inode_num, generation, cb, err_cb)?;
        }
    }
    Ok(())
}

fn walk_block_map<F: FnMut(ExtentRun)>(
    fs: &mut Fs,
    ino: &Inode,
    mut cb: F,
) -> io::Result<()> {
    let bs = fs.block_size;
    let max_phys = fs.total_blocks();
    let mut logical: u32 = 0;

    // Direct blocks 0..12
    for i in 0..12 {
        let b = ino.i_block[i];
        if b != 0 {
            if (b as u64) >= max_phys {
                // Out-of-range direct block — short-circuit so
                // the caller's walker marks this as corruption
                // via the InvalidPhysical extent error path.
                return Err(io::Error::new(io::ErrorKind::InvalidData,
                    format!("direct block {b} past end of fs")));
            }
            cb(ExtentRun { logical, physical: b as u64, length: 1 });
        }
        logical += 1;
    }

    // Single-indirect
    if ino.i_block[12] != 0 {
        let indir = ino.i_block[12] as u64;
        if indir >= max_phys {
            return Err(io::Error::new(io::ErrorKind::InvalidData,
                format!("illegal indirect block {indir}")));
        }
        let mut ib = vec![0u8; bs as usize];
        fs.read_block(indir, &mut ib)?;
        for i in 0..(bs as usize / 4) {
            let off = i * 4;
            let b = u32::from_le_bytes([ib[off], ib[off+1], ib[off+2], ib[off+3]]);
            if b != 0 {
                if (b as u64) >= max_phys {
                    return Err(io::Error::new(io::ErrorKind::InvalidData,
                        format!("indirect block content references block {b} past end of fs")));
                }
                cb(ExtentRun { logical, physical: b as u64, length: 1 });
            }
            logical = logical.wrapping_add(1);
        }
    }
    // Double-indirect (block 13 in i_block): walks a block full of
    // pointers each of which points to a block of direct-block
    // pointers. We walk both levels.
    if ino.i_block[13] != 0 {
        let mut dib = vec![0u8; bs as usize];
        fs.read_block(ino.i_block[13] as u64, &mut dib)?;
        for i in 0..(bs as usize / 4) {
            let off = i * 4;
            let ib_blk = u32::from_le_bytes([dib[off], dib[off+1], dib[off+2], dib[off+3]]);
            if ib_blk == 0 { logical = logical.wrapping_add(bs as u32 / 4); continue; }
            let mut ib = vec![0u8; bs as usize];
            fs.read_block(ib_blk as u64, &mut ib)?;
            for j in 0..(bs as usize / 4) {
                let off2 = j * 4;
                let b = u32::from_le_bytes([ib[off2], ib[off2+1], ib[off2+2], ib[off2+3]]);
                if b != 0 { cb(ExtentRun { logical, physical: b as u64, length: 1 }); }
                logical = logical.wrapping_add(1);
            }
        }
    }
    // Triple-indirect is extremely rare — a 4-KiB block holds
    // 1024 pointers, so triple-indirect is only needed past the
    // first 4 GiB per inode. Walk it the same way, one level deeper.
    if ino.i_block[14] != 0 {
        let mut tib = vec![0u8; bs as usize];
        fs.read_block(ino.i_block[14] as u64, &mut tib)?;
        for i in 0..(bs as usize / 4) {
            let off = i * 4;
            let dib_blk = u32::from_le_bytes([tib[off], tib[off+1], tib[off+2], tib[off+3]]);
            if dib_blk == 0 { logical = logical.wrapping_add((bs as u32 / 4) * (bs as u32 / 4)); continue; }
            let mut dib = vec![0u8; bs as usize];
            fs.read_block(dib_blk as u64, &mut dib)?;
            for j in 0..(bs as usize / 4) {
                let off2 = j * 4;
                let ib_blk = u32::from_le_bytes([dib[off2], dib[off2+1], dib[off2+2], dib[off2+3]]);
                if ib_blk == 0 { logical = logical.wrapping_add(bs as u32 / 4); continue; }
                let mut ib = vec![0u8; bs as usize];
                fs.read_block(ib_blk as u64, &mut ib)?;
                for k in 0..(bs as usize / 4) {
                    let off3 = k * 4;
                    let b = u32::from_le_bytes([ib[off3], ib[off3+1], ib[off3+2], ib[off3+3]]);
                    if b != 0 { cb(ExtentRun { logical, physical: b as u64, length: 1 }); }
                    logical = logical.wrapping_add(1);
                }
            }
        }
    }
    Ok(())
}
