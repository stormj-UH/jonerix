//! Block group descriptor. 32 bytes for legacy (no 64BIT feature),
//! 64 bytes with 64BIT. On-disk layout from the public ext4 spec.

#[repr(C, packed)]
#[derive(Clone, Copy, Default)]
pub struct GroupDesc64 {
    pub bg_block_bitmap_lo:      u32,
    pub bg_inode_bitmap_lo:      u32,
    pub bg_inode_table_lo:       u32,
    pub bg_free_blocks_count_lo: u16,
    pub bg_free_inodes_count_lo: u16,
    pub bg_used_dirs_count_lo:   u16,
    pub bg_flags:                u16,
    pub bg_exclude_bitmap_lo:    u32,
    pub bg_block_bitmap_csum_lo: u16,
    pub bg_inode_bitmap_csum_lo: u16,
    pub bg_itable_unused_lo:     u16,
    pub bg_checksum:             u16,

    // 64-bit extension — present when INCOMPAT_64BIT is set and
    // s_desc_size >= 64.
    pub bg_block_bitmap_hi:      u32,
    pub bg_inode_bitmap_hi:      u32,
    pub bg_inode_table_hi:       u32,
    pub bg_free_blocks_count_hi: u16,
    pub bg_free_inodes_count_hi: u16,
    pub bg_used_dirs_count_hi:   u16,
    pub bg_itable_unused_hi:     u16,
    pub bg_exclude_bitmap_hi:    u32,
    pub bg_block_bitmap_csum_hi: u16,
    pub bg_inode_bitmap_csum_hi: u16,
    pub bg_reserved:             u32,
}

const _: () = assert!(core::mem::size_of::<GroupDesc64>() == 64);

// Group descriptor flags
pub const EXT4_BG_INODE_UNINIT: u16 = 0x0001;
pub const EXT4_BG_BLOCK_UNINIT: u16 = 0x0002;
pub const EXT4_BG_INODE_ZEROED: u16 = 0x0004;

impl GroupDesc64 {
    pub fn set_block_bitmap(&mut self, blk: u64) {
        self.bg_block_bitmap_lo = blk as u32;
        self.bg_block_bitmap_hi = (blk >> 32) as u32;
    }
    pub fn set_inode_bitmap(&mut self, blk: u64) {
        self.bg_inode_bitmap_lo = blk as u32;
        self.bg_inode_bitmap_hi = (blk >> 32) as u32;
    }
    pub fn set_inode_table(&mut self, blk: u64) {
        self.bg_inode_table_lo = blk as u32;
        self.bg_inode_table_hi = (blk >> 32) as u32;
    }
    pub fn set_free_blocks(&mut self, n: u32) {
        self.bg_free_blocks_count_lo = n as u16;
        self.bg_free_blocks_count_hi = (n >> 16) as u16;
    }
    pub fn set_free_inodes(&mut self, n: u32) {
        self.bg_free_inodes_count_lo = n as u16;
        self.bg_free_inodes_count_hi = (n >> 16) as u16;
    }
    pub fn set_used_dirs(&mut self, n: u32) {
        self.bg_used_dirs_count_lo = n as u16;
        self.bg_used_dirs_count_hi = (n >> 16) as u16;
    }
    pub fn set_itable_unused(&mut self, n: u32) {
        self.bg_itable_unused_lo = n as u16;
        self.bg_itable_unused_hi = (n >> 16) as u16;
    }
    pub fn to_bytes(&self, size: usize) -> Vec<u8> {
        // Serialize. Struct is 64 bytes; real-world s_desc_size
        // can be 32, 64, or a power-of-two up to block_size.
        // Sizes larger than 64 get zero-filled tails — those
        // bytes are reserved and must be zero both on disk and
        // in the checksum calculation.
        let mut out = vec![0u8; size];
        let raw: [u8; 64] = unsafe { *(self as *const _ as *const [u8; 64]) };
        let n = core::cmp::min(size, 64);
        out[..n].copy_from_slice(&raw[..n]);
        out
    }
}
