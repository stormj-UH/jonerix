//! JBD2 (ext4 journal) on-disk format. Constants and the
//! superblock layout come from the public jbd2 UAPI documentation
//! (include/linux/jbd2.h header is GPL but the on-disk binary
//! format itself is a published interface — we reimplement, not
//! copy).

pub const JBD2_MAGIC: u32 = 0xC03B3998;

pub const JBD2_DESCRIPTOR_BLOCK:    u32 = 1;
pub const JBD2_COMMIT_BLOCK:        u32 = 2;
pub const JBD2_SUPERBLOCK_V1:       u32 = 3;
pub const JBD2_SUPERBLOCK_V2:       u32 = 4;
pub const JBD2_REVOKE_BLOCK:        u32 = 5;

pub const JBD2_FEATURE_INCOMPAT_REVOKE:           u32 = 0x00000001;
pub const JBD2_FEATURE_INCOMPAT_64BIT:            u32 = 0x00000002;
pub const JBD2_FEATURE_INCOMPAT_ASYNC_COMMIT:     u32 = 0x00000004;
pub const JBD2_FEATURE_INCOMPAT_CSUM_V2:          u32 = 0x00000008;
pub const JBD2_FEATURE_INCOMPAT_CSUM_V3:          u32 = 0x00000010;

#[repr(C, packed)]
#[derive(Clone, Copy)]
pub struct JournalHeader {
    pub h_magic:     u32,      // big-endian on disk
    pub h_blocktype: u32,      // big-endian
    pub h_sequence:  u32,      // big-endian
}

/// JBD2 superblock. 1024 bytes, lives at block 0 of the journal.
/// All multi-byte fields are **big-endian** on disk — note the
/// contrast with ext4 itself which is little-endian.
#[repr(C, packed)]
#[derive(Clone, Copy)]
pub struct JournalSuperblock {
    pub s_header:           JournalHeader,

    // static info describing the journal
    pub s_blocksize:        u32,
    pub s_maxlen:           u32,
    pub s_first:            u32,  // first block of log

    // dynamic info describing the current log
    pub s_sequence:         u32,
    pub s_start:            u32,

    // error value, as set by jbd2_journal_abort()
    pub s_errno:            i32,

    // v2 fields begin here (present when h_blocktype = SUPERBLOCK_V2)
    pub s_feature_compat:   u32,
    pub s_feature_incompat: u32,
    pub s_feature_ro_compat:u32,
    pub s_uuid:             [u8; 16],
    pub s_nr_users:         u32,
    pub s_dynsuper:         u32,

    pub s_max_transaction:  u32,
    pub s_max_trans_data:   u32,

    pub s_checksum_type:    u8,
    pub s_padding2:         [u8; 3],
    pub s_num_fc_blks:      u32,
    pub s_head:             u32,
    pub s_padding:          [u32; 40],
    pub s_checksum:         u32,
    pub s_users:            [u8; 16 * 48],
}

const _: () = assert!(core::mem::size_of::<JournalSuperblock>() == 1024);

impl JournalSuperblock {
    pub fn new_ext4(block_size: u32, max_blocks: u32, uuid: [u8; 16]) -> Self {
        // SAFETY: every field is a POD integer / byte array.
        let mut s: Self = unsafe { core::mem::zeroed() };
        // Big-endian because JBD2 has always been big-endian on
        // disk (inherited from the ext3 journal format).
        s.s_header.h_magic     = JBD2_MAGIC.to_be();
        s.s_header.h_blocktype = JBD2_SUPERBLOCK_V2.to_be();
        s.s_header.h_sequence  = 0u32.to_be();
        s.s_blocksize = block_size.to_be();
        s.s_maxlen    = max_blocks.to_be();
        s.s_first     = 1u32.to_be();           // log starts after the SB
        s.s_sequence  = 1u32.to_be();
        s.s_start     = 0u32.to_be();           // empty journal
        s.s_errno     = 0i32.to_be();
        s.s_nr_users  = 1u32.to_be();
        s.s_uuid      = uuid;
        s
    }

    pub fn to_bytes(&self) -> [u8; 1024] {
        unsafe { *(self as *const _ as *const [u8; 1024]) }
    }
}

/// CRC32C (JBD2's checksum_type = 4).
pub const JBD2_CRC32C_CHKSUM: u8 = 4;

/// Opt this journal SB into JBD2 CSUM_V3: sets the incompat
/// feature bit, the checksum type, copies the uuid, and stamps
/// `s_checksum` with the crc32c of the SB bytes (with `s_checksum`
/// zeroed). The JBD2 SB is big-endian on disk, so the bytes we
/// hand to crc32c are the on-disk big-endian layout — matching
/// the kernel jbd2_superblock_csum contract.
pub fn set_csum_v3(sb: &mut JournalSuperblock, uuid: &[u8; 16]) {
    // Make sure the uuid slot matches what the ext4 side advertises.
    sb.s_uuid = *uuid;

    // OR the CSUM_V3 incompat bit into whatever is already there.
    let feat = u32::from_be(sb.s_feature_incompat) | JBD2_FEATURE_INCOMPAT_CSUM_V3;
    sb.s_feature_incompat = feat.to_be();

    sb.s_checksum_type = JBD2_CRC32C_CHKSUM;

    // Zero the checksum slot, serialize, hash, store big-endian.
    sb.s_checksum = 0;
    let bytes = sb.to_bytes();
    let csum = crate::crc::crc32c_cont(0xFFFFFFFF, &bytes);
    sb.s_checksum = csum.to_be();
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn set_csum_v3_stamps_fields() {
        let uuid = [0x11u8; 16];
        let mut sb = JournalSuperblock::new_ext4(4096, 8192, uuid);
        set_csum_v3(&mut sb, &uuid);
        assert_eq!(
            u32::from_be(sb.s_feature_incompat) & JBD2_FEATURE_INCOMPAT_CSUM_V3,
            JBD2_FEATURE_INCOMPAT_CSUM_V3
        );
        assert_eq!(sb.s_checksum_type, JBD2_CRC32C_CHKSUM);
        let stored = u32::from_be(sb.s_checksum);
        sb.s_checksum = 0;
        let bytes = sb.to_bytes();
        let recomputed = crate::crc::crc32c_cont(0xFFFFFFFF, &bytes);
        assert_eq!(stored, recomputed);
    }
}
