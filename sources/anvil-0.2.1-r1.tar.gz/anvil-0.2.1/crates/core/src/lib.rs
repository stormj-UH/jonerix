//! anvil-core — ext4 on-disk format types and helpers.
//!
//! Structure layouts come from the public ext4 on-disk format
//! documentation at Documentation/filesystems/ext4/ in the Linux
//! kernel tree (dual-licensed GPL-2.0 / CC-BY-SA for the prose
//! portion). No code is derived from e2fsprogs.

#![allow(dead_code)]

pub mod superblock;
pub mod group_desc;
pub mod inode;
pub mod dir;
pub mod consts;
pub mod bitmap;
pub mod io;
pub mod uuid;
pub mod crc;
pub mod jbd2;
pub mod fs;
pub mod extent;
pub mod dirhash;
pub mod casefold;

pub use consts::*;
