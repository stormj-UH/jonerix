//! Name normalization for ext4 casefolded directories.
//!
//! # Scope (first pass)
//!
//! This module implements **ASCII-only** case folding: `A..Z` -> `a..z`.
//! Non-ASCII bytes pass through unchanged. That is enough to make
//! mixed-case lookups for plain-ASCII names work (`Hello.txt` ==
//! `HELLO.TXT` == `hello.txt`) and it mirrors what the Linux kernel
//! does for the ASCII subset under `utf8_strncasecmp`.
//!
//! # Unicode gap
//!
//! The Linux kernel full casefold for `s_encoding = UTF-8-12.1`
//! uses a Unicode 12.1.0 fold table derived from
//! `CaseFolding.txt` + `DerivedNormalizationProps.txt` published
//! by the Unicode Consortium (`https://www.unicode.org/Public/`).
//! That data file is distributed under the Unicode License
//! (permissive, MIT-compatible), so a future patch can generate a
//! `static FOLD_TABLE: &[(u32, &[u32])]` at build time from that
//! public source without touching any GPL code. Until then, any
//! two names that differ only by **non-ASCII** case - e.g. `U+00DC`
//! vs `U+00FC` - compare **unequal** here, same as byte compare.
//! The callers (`debugfs` lookup, `fsck` pass 2 duplicate detector)
//! accept that and will be upgraded in lock step with the table
//! landing.
//!
//! Nothing in this module is derived from e2fsprogs or the Linux
//! kernel source. The ASCII fold is the obvious one-liner.

use crate::dirhash;

#[inline]
fn fold_byte(b: u8) -> u8 {
    if b >= b'A' && b <= b'Z' { b + 32 } else { b }
}

/// Return a normalized copy of `name`, lowercasing ASCII letters.
/// Non-ASCII bytes are left as-is. The result has the same length
/// as the input.
pub fn normalize(name: &[u8]) -> Vec<u8> {
    name.iter().map(|&b| fold_byte(b)).collect()
}

/// Case-insensitive equality under the ASCII fold. Byte-compares
/// the normalized forms of both inputs.
pub fn eq(a: &[u8], b: &[u8]) -> bool {
    if a.len() != b.len() { return false; }
    for i in 0..a.len() {
        if fold_byte(a[i]) != fold_byte(b[i]) { return false; }
    }
    true
}

/// Hash a name as the kernel does in a casefolded HTree directory:
/// normalize first, then run `dirhash` over the folded bytes.
/// Returns `(hash, minor)` like `dirhash::dirhash`.
pub fn cf_hash(name: &[u8], seed: &[u32; 4], hash_version: u8) -> (u32, u32) {
    let folded = normalize(name);
    dirhash::dirhash(hash_version, &folded, seed)
}
