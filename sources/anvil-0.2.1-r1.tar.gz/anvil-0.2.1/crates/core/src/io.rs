//! Block-level device I/O. Wraps a seekable `File` so both regular
//! files (image targets) and block devices work the same way.

use std::fs::{File, OpenOptions};
use std::io::{self, Read, Seek, SeekFrom, Write};
use std::path::Path;

pub struct Device {
    file: File,
    pub size: u64,
}

impl Device {
    pub fn open<P: AsRef<Path>>(path: P) -> io::Result<Self> {
        let mut file = OpenOptions::new().read(true).write(true).open(&path)?;
        let size = device_size(&mut file)?;
        Ok(Device { file, size })
    }

    pub fn create_image<P: AsRef<Path>>(path: P, size: u64) -> io::Result<Self> {
        let file = OpenOptions::new().read(true).write(true).create(true).truncate(true).open(&path)?;
        file.set_len(size)?;
        Ok(Device { file, size })
    }

    pub fn write_at(&mut self, offset: u64, data: &[u8]) -> io::Result<()> {
        self.file.seek(SeekFrom::Start(offset))?;
        self.file.write_all(data)
    }

    pub fn read_at(&mut self, offset: u64, buf: &mut [u8]) -> io::Result<()> {
        self.file.seek(SeekFrom::Start(offset))?;
        self.file.read_exact(buf)
    }

    /// Write a zeroed block range [start, end) — used for bitmap
    /// areas and inode tables that haven't been otherwise filled.
    pub fn zero_range(&mut self, start: u64, end: u64) -> io::Result<()> {
        const CHUNK: usize = 1024 * 1024;
        let zero = vec![0u8; CHUNK];
        let mut off = start;
        while off < end {
            let n = core::cmp::min(CHUNK as u64, end - off) as usize;
            self.write_at(off, &zero[..n])?;
            off += n as u64;
        }
        Ok(())
    }

    pub fn sync(&mut self) -> io::Result<()> {
        self.file.sync_all()
    }
}

fn device_size(file: &mut File) -> io::Result<u64> {
    let md = file.metadata()?;
    if md.file_type().is_file() {
        Ok(md.len())
    } else {
        // Block device: BLKGETSIZE64 ioctl — 0x80081272.
        const BLKGETSIZE64: IoctlReq = 0x80081272;
        let mut sz: u64 = 0;
        let fd = std::os::unix::io::AsRawFd::as_raw_fd(file);
        // SAFETY: ioctl writes exactly 8 bytes into `sz`.
        let rc = unsafe { libc_ioctl_fn(fd, BLKGETSIZE64, &mut sz as *mut u64 as *mut _) };
        if rc < 0 {
            // Fall back to seek-to-end for exotic device types.
            let sz = file.seek(SeekFrom::End(0))?;
            file.seek(SeekFrom::Start(0))?;
            return Ok(sz);
        }
        Ok(sz)
    }
}

// Minimal libc surface so we don't need to pull in the libc crate.
type IoctlReq = core::ffi::c_ulong;
extern "C" {
    #[link_name = "ioctl"]
    fn libc_ioctl_fn(fd: i32, req: IoctlReq, ...) -> i32;
}
