//! Bitmap helpers. ext4 bitmaps are little-endian bit-within-byte,
//! LSB-first. Bit N clear ⇒ slot N free; bit N set ⇒ allocated.

pub fn set_bit(buf: &mut [u8], idx: usize) {
    buf[idx / 8] |= 1 << (idx % 8);
}

pub fn clear_bit(buf: &mut [u8], idx: usize) {
    buf[idx / 8] &= !(1 << (idx % 8));
}

pub fn test_bit(buf: &[u8], idx: usize) -> bool {
    (buf[idx / 8] >> (idx % 8)) & 1 != 0
}

/// Mark bits [start..end) as used.
pub fn mark_range(buf: &mut [u8], start: usize, end: usize) {
    for i in start..end { set_bit(buf, i); }
}
