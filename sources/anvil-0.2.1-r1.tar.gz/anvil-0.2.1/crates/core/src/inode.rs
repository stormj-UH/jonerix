//! ext4 inode. 128 bytes (legacy) or 256 bytes (ext4 default with
//! EXT4_FEATURE_RO_COMPAT_EXTRA_ISIZE). On-disk layout from the
//! public spec.

#[repr(C, packed)]
#[derive(Clone, Copy, Default)]
pub struct Inode {
    pub i_mode:         u16,
    pub i_uid:          u16,
    pub i_size_lo:      u32,
    pub i_atime:        u32,
    pub i_ctime:        u32,
    pub i_mtime:        u32,
    pub i_dtime:        u32,
    pub i_gid:          u16,
    pub i_links_count:  u16,
    pub i_blocks_lo:    u32,   // count in 512-byte sectors
    pub i_flags:        u32,
    pub i_osd1:         u32,
    pub i_block:        [u32; 15],
    pub i_generation:   u32,
    pub i_file_acl_lo:  u32,
    pub i_size_hi:      u32,
    pub i_faddr:        u32,
    pub i_osd2:         [u16; 6],

    // extra fields (when i_extra_isize > 0)
    pub i_extra_isize:  u16,
    pub i_checksum_hi:  u16,
    pub i_ctime_extra:  u32,
    pub i_mtime_extra:  u32,
    pub i_atime_extra:  u32,
    pub i_crtime:       u32,
    pub i_crtime_extra: u32,
    pub i_version_hi:   u32,
    pub i_projid:       u32,
}

const _: () = assert!(core::mem::size_of::<Inode>() == 160);
// On-disk inode size is a mkfs-time decision (128 or 256). When 256 we
// pad the trailing bytes to zero; when 128 we only serialize the first
// 128 bytes of this struct.

impl Inode {
    pub fn size(&self) -> u64 {
        ((self.i_size_hi as u64) << 32) | self.i_size_lo as u64
    }
    pub fn set_size(&mut self, n: u64) {
        self.i_size_lo = n as u32;
        self.i_size_hi = (n >> 32) as u32;
    }
    pub fn to_bytes(&self, inode_size: usize) -> Vec<u8> {
        let raw: [u8; 160] = unsafe { *(self as *const _ as *const [u8; 160]) };
        let mut out = vec![0u8; inode_size];
        let n = core::cmp::min(inode_size, 160);
        out[..n].copy_from_slice(&raw[..n]);
        out
    }
}

// ---- Extent tree nodes (EXT4_EXTENTS_FL set in i_flags) ----

#[repr(C, packed)]
#[derive(Clone, Copy, Default)]
pub struct ExtentHeader {
    pub eh_magic:      u16,  // 0xF30A
    pub eh_entries:    u16,
    pub eh_max:        u16,
    pub eh_depth:      u16,
    pub eh_generation: u32,
}

#[repr(C, packed)]
#[derive(Clone, Copy, Default)]
pub struct Extent {
    pub ee_block:      u32,
    pub ee_len:        u16,
    pub ee_start_hi:   u16,
    pub ee_start_lo:   u32,
}

#[repr(C, packed)]
#[derive(Clone, Copy, Default)]
pub struct ExtentIdx {
    pub ei_block:    u32,
    pub ei_leaf_lo:  u32,
    pub ei_leaf_hi:  u16,
    pub ei_unused:   u16,
}

const _: () = assert!(core::mem::size_of::<ExtentHeader>() == 12);
const _: () = assert!(core::mem::size_of::<Extent>() == 12);
const _: () = assert!(core::mem::size_of::<ExtentIdx>() == 12);

impl Extent {
    pub fn start(&self) -> u64 {
        ((self.ee_start_hi as u64) << 32) | self.ee_start_lo as u64
    }
    pub fn set_start(&mut self, blk: u64) {
        self.ee_start_lo = blk as u32;
        self.ee_start_hi = (blk >> 32) as u16;
    }
}
