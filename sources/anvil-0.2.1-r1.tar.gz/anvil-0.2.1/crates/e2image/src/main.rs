//! e2image — save (and, later, restore) a metadata-only copy of
//! an ext4 filesystem. The point of the tool is to ship a broken
//! image for diagnosis without shipping user data: the output
//! retains only the structural metadata (superblocks, GDT,
//! bitmaps, inode tables, extent-tree interior blocks, the first
//! block of every directory inode, the journal, xattr blocks) and
//! leaves every regular-file data block as a sparse hole.
//!
//! Flags:
//!   -r <image> <out>   raw/sparse mode: <out> has the same
//!                      nominal size as <image>, but only
//!                      metadata blocks are copied; everything
//!                      else is a sparse hole.
//!   -Q <image> <out>   QCOW2-ish metadata-only mode. First pass
//!                      emits a flat sparse file; we do NOT
//!                      produce an upstream-compatible QCOW2
//!                      container, and the output is documented
//!                      as the same sparse format the `-r` mode
//!                      produces. Callers that need a real
//!                      QCOW2 should convert with qemu-img.
//!   -V                 version
//!
//! Exit codes:
//!   0   success
//!   8   operational error (open / read / write)
//!   16  usage error
//!
//! Clean-room reimplementation: the metadata-classification rule
//! below is derived from the public ext4 on-disk format, not from
//! e2fsprogs source. No upstream code is consulted or copied.

use std::collections::HashSet;
use std::fs::OpenOptions;
use std::io::{Seek, SeekFrom, Write};
use std::path::{Path, PathBuf};
use std::process::ExitCode;

use anvil_core::consts::{
    EXT4_EXT_MAGIC, EXT4_JOURNAL_INO, EXT4_ROOT_INO, S_IFDIR, S_IFMT,
};
use anvil_core::extent::{walk_extents_validated, ExtentError, ExtentRun};
use anvil_core::fs::Fs;
use anvil_core::group_desc::EXT4_BG_INODE_UNINIT;

const VERSION_LINE: &str = "anvil-e2image 1.47.3-anvil (MIT)";

fn main() -> ExitCode {
    let args: Vec<String> = std::env::args().skip(1).collect();
    let mut mode: Option<char> = None;
    let mut positional: Vec<String> = Vec::new();
    for a in args {
        match a.as_str() {
            "-V" => {
                println!("{VERSION_LINE}");
                return ExitCode::from(0);
            }
            "-r" => mode = Some('r'),
            "-Q" => mode = Some('Q'),
            s if s.starts_with('-') => {
                eprintln!("e2image: unknown option {s} (ignored)");
            }
            _ => positional.push(a),
        }
    }

    let Some(m) = mode else {
        eprintln!("usage: e2image -r <image> <out>");
        eprintln!("       e2image -Q <image> <out>   (flat sparse, not real QCOW2)");
        eprintln!("       e2image -V");
        return ExitCode::from(16);
    };
    if positional.len() != 2 {
        eprintln!("e2image: -{m} takes <image> <out>");
        return ExitCode::from(16);
    }

    let src = PathBuf::from(&positional[0]);
    let out = PathBuf::from(&positional[1]);

    if m == 'Q' {
        eprintln!(
            "e2image: -Q produces a sparse metadata-only file, \
             not an upstream QCOW2 container"
        );
    }

    match dump_metadata(&src, &out) {
        Ok(()) => ExitCode::from(0),
        Err(e) => {
            eprintln!("e2image: {e}");
            ExitCode::from(8)
        }
    }
}

fn dump_metadata(src: &Path, out: &Path) -> std::io::Result<()> {
    let mut fs = Fs::open(src)?;

    let block_size = fs.block_size;
    let total_blocks = fs.total_blocks();
    let src_len = total_blocks.saturating_mul(block_size);

    // Create the destination as a same-size sparse file.
    let mut out_f = OpenOptions::new()
        .read(true)
        .write(true)
        .create(true)
        .truncate(true)
        .open(out)?;
    out_f.set_len(src_len)?;

    // Collect the set of "metadata" blocks to copy.
    let mut metadata: HashSet<u64> = HashSet::new();

    // 1. Primary superblock's containing block (s_first_data_block
    //    for bs>1024, or block 1 for bs==1024) and the block that
    //    covers bytes 1024..2048 for bs>=2048. In all practical
    //    cases the SB-containing block is `sb_block` below, and
    //    we add it unconditionally.
    let sb_block: u64 = if block_size == 1024 { 1 } else { 0 };
    metadata.insert(sb_block);

    // 2. Backup superblocks + their GDT copies live in groups 0,
    //    1, powers of 3, 5, 7 (SPARSE_SUPER). Group 0's SB/GDT
    //    are already the primary; add the per-group copies for
    //    the backup groups.
    let groups = fs.groups_count;
    let desc_size = fs.desc_size;
    let gdt_blocks: u64 = (groups * desc_size).div_ceil(block_size);
    let reserved_gdt = fs.sb.s_reserved_gdt_blocks as u64;
    let blocks_per_group = fs.blocks_per_group;
    let first_data = fs.sb.s_first_data_block as u64;

    // Primary GDT + reserved-GDT blocks (these hold the growth
    // slots and are part of structural metadata even though most
    // of the reserved slots are zero).
    for i in 0..(gdt_blocks + reserved_gdt) {
        let b = first_data + 1 + i;
        if b < total_blocks {
            metadata.insert(b);
        }
    }

    // Backup SB + GDT copies.
    for gi in 0..groups {
        if gi == 0 {
            continue; // primary handled above
        }
        if !is_backup_group(gi) {
            continue;
        }
        let group_start = first_data + gi * blocks_per_group;
        // Backup SB lives at group_start (block 0 of the group).
        if group_start < total_blocks {
            metadata.insert(group_start);
        }
        for i in 0..(gdt_blocks + reserved_gdt) {
            let b = group_start + 1 + i;
            if b < total_blocks {
                metadata.insert(b);
            }
        }
    }

    // 3. Per-group block bitmap, inode bitmap, and inode table.
    let inode_table_blocks: u64 =
        (fs.inodes_per_group * fs.inode_size).div_ceil(block_size);
    for gi in 0..groups {
        let bb = fs.group_block_bitmap(gi);
        if bb != 0 && bb < total_blocks {
            metadata.insert(bb);
        }
        let ib = fs.group_inode_bitmap(gi);
        if ib != 0 && ib < total_blocks {
            metadata.insert(ib);
        }
        let it = fs.group_inode_table(gi);
        if it != 0 {
            for i in 0..inode_table_blocks {
                let b = it + i;
                if b < total_blocks {
                    metadata.insert(b);
                }
            }
        }
    }

    // 4. Walk every allocated inode and add its metadata-ish
    //    blocks to the set:
    //      - extent-tree interior nodes (from walk_extents InteriorNode)
    //      - first block of every directory inode (dir contents)
    //      - every data block of the journal inode (JBD2 SB +
    //        descriptor / commit records live here)
    //      - xattr blocks referenced by i_file_acl.
    let total_inodes = fs.total_inodes() as u32;
    let ipg = fs.inodes_per_group;
    let journal_inum = fs.sb.s_journal_inum;

    // Preload each group's inode bitmap once.
    let bs_usize = block_size as usize;
    let mut group_ibs: Vec<Option<Vec<u8>>> = Vec::with_capacity(groups as usize);
    for gi in 0..groups {
        let flags = fs.gdt[gi as usize].bg_flags;
        if flags & EXT4_BG_INODE_UNINIT != 0 {
            group_ibs.push(None);
            continue;
        }
        let blk = fs.group_inode_bitmap(gi);
        if blk == 0 || blk >= total_blocks {
            group_ibs.push(None);
            continue;
        }
        let mut buf = vec![0u8; bs_usize];
        fs.read_block(blk, &mut buf)?;
        group_ibs.push(Some(buf));
    }

    for ino_num in 1..=total_inodes {
        let group = (ino_num as u64 - 1) / ipg;
        let idx = ((ino_num as u64 - 1) % ipg) as usize;
        let allocated = match &group_ibs[group as usize] {
            Some(bm) => anvil_core::bitmap::test_bit(bm, idx),
            None => false,
        };
        if !allocated {
            continue;
        }

        let ino = match fs.read_inode(ino_num) {
            Ok(i) => i,
            Err(_) => continue,
        };
        let mode_field = ino.i_mode;
        let is_dir = (mode_field & S_IFMT) == S_IFDIR;
        let is_journal = ino_num == journal_inum && journal_inum == EXT4_JOURNAL_INO;
        // Fall back to the reserved journal inum (8) too, in case
        // s_journal_inum is zero but inode 8 is populated.
        let is_journal = is_journal || ino_num == EXT4_JOURNAL_INO;

        let file_acl_lo = ino.i_file_acl_lo as u64;
        if file_acl_lo != 0 && file_acl_lo < total_blocks {
            metadata.insert(file_acl_lo);
        }

        // Collect extent runs + interior nodes. For directories
        // and the journal we also want their data runs; for
        // regular files only the interior nodes are metadata.
        let mut runs: Vec<ExtentRun> = Vec::new();
        let mut interior: Vec<u64> = Vec::new();
        let _ = walk_extents_validated(
            &mut fs,
            &ino,
            |r| runs.push(r),
            |e| {
                if let ExtentError::InteriorNode { block } = e {
                    interior.push(block);
                }
            },
        );

        for b in &interior {
            if *b < total_blocks {
                metadata.insert(*b);
            }
        }

        if is_journal {
            // The journal inode's body is pure JBD2 metadata —
            // copy every block it covers.
            for r in &runs {
                for k in 0..r.length as u64 {
                    let pb = r.physical + k;
                    if pb < total_blocks {
                        metadata.insert(pb);
                    }
                }
            }
        } else if is_dir {
            // Dir contents are metadata for debugging purposes.
            // The task spec asks for "the first block of every
            // directory inode"; for most directories that IS
            // the whole directory. For htree-indexed dirs
            // covering >1 block, copy block 0 only per spec.
            if let Some(r) = runs.iter().find(|r| r.logical == 0) {
                if r.physical < total_blocks {
                    metadata.insert(r.physical);
                }
            }
        }
        // Regular files: no data blocks are metadata, just their
        // extent-tree interior nodes (already added above).
        let _ = ino_num;
        let _ = mode_field;
    }

    // Phase 2: actually copy each metadata block from src to out,
    // skipping already-written ones (HashSet gives us that for
    // free, but we sort for deterministic IO order).
    let mut ordered: Vec<u64> = metadata.into_iter().collect();
    ordered.sort_unstable();

    let mut buf = vec![0u8; bs_usize];
    let mut copied: u64 = 0;
    for blk in &ordered {
        if *blk >= total_blocks {
            continue;
        }
        let off = blk.saturating_mul(block_size);
        if off >= fs.dev.size {
            continue;
        }
        if let Err(e) = fs.dev.read_at(off, &mut buf) {
            // Truncated source — skip this block rather than
            // aborting. The whole point of e2image is to dump
            // whatever metadata is still legible.
            eprintln!("e2image: read block {blk}: {e} (skipped)");
            continue;
        }
        // Skip writing if block is all zeros — preserves the
        // sparse hole in the output. (An all-zero metadata
        // block is indistinguishable from a hole and the output
        // round-trips identically.)
        if buf.iter().all(|&x| x == 0) {
            copied += 1;
            continue;
        }
        out_f.seek(SeekFrom::Start(off))?;
        out_f.write_all(&buf)?;
        copied += 1;
    }

    out_f.sync_all()?;

    let pct = if total_blocks > 0 {
        (copied as f64 / total_blocks as f64) * 100.0
    } else {
        0.0
    };
    println!(
        "e2image: copied {copied} metadata blocks out of {total_blocks} total ({pct:.1}% retained)"
    );
    Ok(())
}

/// SPARSE_SUPER placement: groups 0, 1, and powers of 3/5/7.
/// Duplicated from `anvil_core::fs` (private there) because the
/// `-r` dump needs to know which groups carry backup SBs/GDTs.
fn is_backup_group(gi: u64) -> bool {
    if gi == 0 || gi == 1 {
        return true;
    }
    let mut p: u64 = 3;
    while p <= gi {
        if p == gi {
            return true;
        }
        p = match p.checked_mul(3) {
            Some(v) => v,
            None => break,
        };
    }
    let mut p: u64 = 5;
    while p <= gi {
        if p == gi {
            return true;
        }
        p = match p.checked_mul(5) {
            Some(v) => v,
            None => break,
        };
    }
    let mut p: u64 = 7;
    while p <= gi {
        if p == gi {
            return true;
        }
        p = match p.checked_mul(7) {
            Some(v) => v,
            None => break,
        };
    }
    false
}

// Silence unused imports for items referenced only in comments.
#[allow(dead_code)]
fn _unused_imports() {
    let _ = EXT4_EXT_MAGIC;
    let _ = EXT4_ROOT_INO;
}
