//! e2label — read or set the volume label (`s_volume_name`) on an
//! ext2/3/4 filesystem. One-liner equivalent to `tune2fs -L`.
//!
//! Usage:
//!   e2label <device>              print the current label
//!   e2label <device> <new-label>  set the label (max 16 bytes)
//!   e2label -V                    print version

use std::path::PathBuf;
use std::process::ExitCode;

use anvil_core::fs::Fs;

fn main() -> ExitCode {
    let mut args = std::env::args().skip(1);
    let first = match args.next() {
        Some(s) => s,
        None => return usage_err("missing device"),
    };

    if first == "-V" {
        println!("e2label 1.47.3-anvil (MIT)");
        return ExitCode::SUCCESS;
    }

    let device = PathBuf::from(first);
    let new_label = args.next();
    if args.next().is_some() {
        return usage_err("too many arguments");
    }

    let mut fs = match Fs::open(&device) {
        Ok(f) => f,
        Err(e) => {
            eprintln!("e2label: cannot open {}: {e}", device.display());
            return ExitCode::from(1);
        }
    };

    match new_label {
        None => {
            // Read path: print label (truncated at first NUL).
            let raw = &fs.sb.s_volume_name;
            let end = raw.iter().position(|&b| b == 0).unwrap_or(raw.len());
            println!("{}", String::from_utf8_lossy(&raw[..end]));
            ExitCode::SUCCESS
        }
        Some(label) => {
            // Write path.
            if label.as_bytes().contains(&0u8) {
                eprintln!("e2label: error: label contains NUL byte");
                return ExitCode::from(1);
            }
            let bytes = label.as_bytes();
            let n = if bytes.len() > 16 {
                eprintln!("e2label: warning: label truncated to 16 bytes");
                16
            } else {
                bytes.len()
            };
            let mut buf = [0u8; 16];
            buf[..n].copy_from_slice(&bytes[..n]);
            fs.sb.s_volume_name = buf;
            if let Err(e) = fs.write_superblock() {
                eprintln!("e2label: cannot write superblock: {e}");
                return ExitCode::from(1);
            }
            ExitCode::SUCCESS
        }
    }
}

fn usage_err(msg: &str) -> ExitCode {
    eprintln!("e2label: {msg}\nusage: e2label <device> [new-label]");
    ExitCode::from(1)
}
