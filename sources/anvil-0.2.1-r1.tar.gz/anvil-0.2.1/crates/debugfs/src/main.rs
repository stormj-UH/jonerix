//! debugfs — read-only inspection CLI for ext4 images.
//!
//! Phase 6c scope: the non-interactive subset that covers most
//! ops / incident-response use. Invocation shapes:
//!
//!   debugfs -R "cmd [args...]" image.img
//!   debugfs image.img                 # line-oriented REPL
//!
//! Commands implemented:
//!   stats                 — superblock + group summary
//!   stat <inode>          — inode fields, extent layout
//!   ls <path>             — directory listing from the root tree
//!   clri <inode>          — zero an inode table slot (destructive)
//!   icheck <block>        — reverse lookup: which inode owns a block
//!   mi <ino> <fld> <val>  — modify one inode field (destructive)
//!   block_dump <block>    — hex+ASCII dump of a single block
//!   dump_inode <ino> [f]  — write an inode's data to file or stdout
//!   write <src> <dst>     — copy a host file into the filesystem
//!   mkdir <path>          — create a directory at the given path
//!   rmdir <path>          — remove an empty directory
//!   rm <path>             — unlink a regular file + free its blocks
//!   symlink <target> <path> — create a symbolic link at <path>
//!   logdump               — decode the JBD2 journal superblock
//!   list_xattr <inode>    — print extended attributes of an inode
//!   quit                  — end REPL
//!
//! `clri` is destructive by design — it zeroes the target inode
//! slot without touching the bitmap, matching upstream debugfs
//! semantics. `icheck` walks every allocated inode's extent tree
//! linearly; it's slow on big filesystems but fine for debugging.

use std::path::PathBuf;
use std::process::ExitCode;

use anvil_core::consts::*;
use anvil_core::extent;
use anvil_core::fs::{compute_bitmap_csum, compute_gdt_csum, compute_inode_csum, csum_seed_for, Fs};

fn main() -> ExitCode {
    let mut single_cmd: Option<String> = None;
    let mut path: Option<PathBuf> = None;
    let mut it = std::env::args().skip(1);
    while let Some(a) = it.next() {
        match a.as_str() {
            "-R" => {
                single_cmd = it.next();
                if single_cmd.is_none() {
                    eprintln!("debugfs: -R requires a command string");
                    return ExitCode::from(16);
                }
            }
            "-V" => {
                println!("debugfs 1.47.3-anvil (MIT)");
                return ExitCode::from(0);
            }
            s if s.starts_with('-') => {
                eprintln!("debugfs: unknown option {s} (ignored)");
            }
            _ => { path = Some(PathBuf::from(a)); }
        }
    }
    let Some(path) = path else {
        eprintln!("usage: debugfs [-R \"cmd\"] <device>");
        return ExitCode::from(16);
    };

    let mut fs = match Fs::open(&path) {
        Ok(fs) => fs,
        Err(e) => {
            eprintln!("debugfs: open {}: {}", path.display(), e);
            return ExitCode::from(8);
        }
    };
    // Banner goes to stderr so the caller can pipe the payload of
    // stdout-writing commands (dump_inode without an outfile) into
    // `od` / a file without having to strip the header.
    eprintln!("debugfs 1.47.3-anvil (MIT)");

    if let Some(cmd) = single_cmd {
        return run_cmd(&mut fs, &cmd);
    }

    // Interactive REPL (non-termios; a raw line loop is enough
    // for scripted debugfs use. Readline / history editing stay
    // out of scope so we don't pull in a dep just for that.)
    let stdin = std::io::stdin();
    let mut line = String::new();
    loop {
        use std::io::Write;
        print!("debugfs:  ");
        let _ = std::io::stdout().flush();
        line.clear();
        if stdin.read_line(&mut line).is_err() { break; }
        let trimmed = line.trim();
        if trimmed.is_empty() { continue; }
        if matches!(trimmed, "quit" | "q" | "exit") { break; }
        let _ = run_cmd(&mut fs, trimmed);
    }
    ExitCode::from(0)
}

fn run_cmd(fs: &mut Fs, line: &str) -> ExitCode {
    let mut parts = line.split_whitespace();
    let Some(cmd) = parts.next() else { return ExitCode::from(0); };
    let args: Vec<&str> = parts.collect();
    match cmd {
        "stats" => { cmd_stats(fs); ExitCode::from(0) }
        "stat"  => {
            // Accept optional -e flag for extended (post-128-byte) fields.
            let mut extended = false;
            let mut ino_arg: Option<&str> = None;
            for a in &args {
                if *a == "-e" { extended = true; }
                else if ino_arg.is_none() { ino_arg = Some(*a); }
            }
            match ino_arg {
                Some(a) => match parse_ino(a) {
                    Some(n) => { if let Err(e) = cmd_stat(fs, n, extended) {
                        eprintln!("debugfs: {e}"); return ExitCode::from(8);
                    } ExitCode::from(0) }
                    None => { eprintln!("debugfs: bad inode '{a}'"); ExitCode::from(16) }
                },
                None => { eprintln!("debugfs: stat [-e] <inode>"); ExitCode::from(16) }
            }
        },
        "ls"    => {
            let path = args.first().copied().unwrap_or("/");
            match cmd_ls(fs, path) {
                Ok(_) => ExitCode::from(0),
                Err(e) => { eprintln!("debugfs: {e}"); ExitCode::from(8) }
            }
        }
        "clri"  => match args.first() {
            Some(a) => match parse_ino(a) {
                Some(n) => match cmd_clri(fs, n) {
                    Ok(_) => ExitCode::from(0),
                    Err(e) => { eprintln!("debugfs: {e}"); ExitCode::from(8) }
                },
                None => { eprintln!("debugfs: bad inode '{a}'"); ExitCode::from(16) }
            },
            None => { eprintln!("debugfs: clri <inode>"); ExitCode::from(16) }
        },
        "icheck" => match args.first() {
            Some(a) => match parse_u64(a) {
                Some(b) => match cmd_icheck(fs, b) {
                    Ok(_) => ExitCode::from(0),
                    Err(e) => { eprintln!("debugfs: {e}"); ExitCode::from(8) }
                },
                None => { eprintln!("debugfs: bad block '{a}'"); ExitCode::from(16) }
            },
            None => { eprintln!("debugfs: icheck <block>"); ExitCode::from(16) }
        },
        "mi" => {
            // mi <inode> <field> <value>
            let (ino_s, fld, val_s) = match (args.first(), args.get(1), args.get(2)) {
                (Some(a), Some(b), Some(c)) => (*a, *b, *c),
                _ => {
                    eprintln!("debugfs: mi <inode> <field> <value>");
                    return ExitCode::from(16);
                }
            };
            let Some(ino_num) = parse_ino(ino_s) else {
                eprintln!("debugfs: bad inode '{ino_s}'");
                return ExitCode::from(16);
            };
            match cmd_mi(fs, ino_num, fld, val_s) {
                Ok(_) => ExitCode::from(0),
                Err(e) => { eprintln!("debugfs: {e}"); ExitCode::from(8) }
            }
        }
        "block_dump" => match args.first() {
            Some(a) => match parse_u64(a) {
                Some(b) => match cmd_block_dump(fs, b) {
                    Ok(_) => ExitCode::from(0),
                    Err(e) => { eprintln!("debugfs: {e}"); ExitCode::from(8) }
                },
                None => { eprintln!("debugfs: bad block '{a}'"); ExitCode::from(16) }
            },
            None => { eprintln!("debugfs: block_dump <block>"); ExitCode::from(16) }
        },
        "dump_inode" => match args.first() {
            Some(a) => match parse_ino(a) {
                Some(n) => {
                    let outpath = args.get(1).map(|s| PathBuf::from(*s));
                    match cmd_dump_inode(fs, n, outpath.as_deref()) {
                        Ok(_) => ExitCode::from(0),
                        Err(e) => { eprintln!("debugfs: {e}"); ExitCode::from(8) }
                    }
                }
                None => { eprintln!("debugfs: bad inode '{a}'"); ExitCode::from(16) }
            },
            None => { eprintln!("debugfs: dump_inode <inode> [outfile]"); ExitCode::from(16) }
        },
        "write" => {
            let (src, dst) = match (args.first(), args.get(1)) {
                (Some(a), Some(b)) => (*a, *b),
                _ => {
                    eprintln!("debugfs: write <src> <dst>");
                    return ExitCode::from(16);
                }
            };
            match cmd_write(fs, std::path::Path::new(src), dst) {
                Ok(()) => ExitCode::from(0),
                Err(e) => { eprintln!("debugfs: {e}"); ExitCode::from(8) }
            }
        }
        "rm" => match args.first() {
            Some(p) => match cmd_rm(fs, p) {
                Ok(_) => ExitCode::from(0),
                Err(e) => { eprintln!("debugfs: {e}"); ExitCode::from(8) }
            },
            None => { eprintln!("debugfs: rm <path>"); ExitCode::from(16) }
        },
        "logdump" => match cmd_logdump(fs) {
            Ok(()) => ExitCode::from(0),
            Err(e) => { eprintln!("debugfs: {e}"); ExitCode::from(8) }
        },
        "list_xattr" => match args.first() {
            Some(a) => match parse_ino(a) {
                Some(n) => match cmd_list_xattr(fs, n) {
                    Ok(_) => ExitCode::from(0),
                    Err(e) => { eprintln!("debugfs: {e}"); ExitCode::from(8) }
                },
                None => { eprintln!("debugfs: bad inode '{a}'"); ExitCode::from(16) }
            },
            None => { eprintln!("debugfs: list_xattr <inode>"); ExitCode::from(16) }
        },
        "chmod" => {
            let (ino_s, mode_s) = match (args.first(), args.get(1)) {
                (Some(a), Some(b)) => (*a, *b),
                _ => {
                    eprintln!("debugfs: chmod <inode> <mode>");
                    return ExitCode::from(16);
                }
            };
            let Some(ino_num) = parse_ino(ino_s) else {
                eprintln!("debugfs: bad inode '{ino_s}'");
                return ExitCode::from(16);
            };
            let Some(mode) = parse_mode(mode_s) else {
                eprintln!("debugfs: bad mode '{mode_s}'");
                return ExitCode::from(16);
            };
            match cmd_chmod(fs, ino_num, mode) {
                Ok(_) => ExitCode::from(0),
                Err(e) => { eprintln!("debugfs: {e}"); ExitCode::from(8) }
            }
        }
        "chown" => {
            let (ino_s, spec) = match (args.first(), args.get(1)) {
                (Some(a), Some(b)) => (*a, *b),
                _ => {
                    eprintln!("debugfs: chown <inode> <uid>[:<gid>]");
                    return ExitCode::from(16);
                }
            };
            let Some(ino_num) = parse_ino(ino_s) else {
                eprintln!("debugfs: bad inode '{ino_s}'");
                return ExitCode::from(16);
            };
            let (uid_s, gid_s) = match spec.split_once(':') {
                Some((u, g)) => (u, Some(g)),
                None => (spec, None),
            };
            let Some(uid) = parse_num(uid_s) else {
                eprintln!("debugfs: bad uid '{uid_s}'");
                return ExitCode::from(16);
            };
            let gid = match gid_s {
                Some(g) => match parse_num(g) {
                    Some(v) => Some(v),
                    None => {
                        eprintln!("debugfs: bad gid '{g}'");
                        return ExitCode::from(16);
                    }
                },
                None => None,
            };
            if uid > u32::MAX as u64 {
                eprintln!("debugfs: uid {uid} out of range");
                return ExitCode::from(16);
            }
            if let Some(g) = gid {
                if g > u32::MAX as u64 {
                    eprintln!("debugfs: gid {g} out of range");
                    return ExitCode::from(16);
                }
            }
            match cmd_chown(fs, ino_num, uid as u32, gid.map(|g| g as u32)) {
                Ok(_) => ExitCode::from(0),
                Err(e) => { eprintln!("debugfs: {e}"); ExitCode::from(8) }
            }
        }
        "mkdir" => match args.first() {
            Some(p) => match cmd_mkdir(fs, p) {
                Ok(_) => ExitCode::from(0),
                Err(e) => { eprintln!("debugfs: {e}"); ExitCode::from(8) }
            },
            None => { eprintln!("debugfs: mkdir <path>"); ExitCode::from(16) }
        },
        "rmdir" => match args.first() {
            Some(p) => match cmd_rmdir(fs, p) {
                Ok(_) => ExitCode::from(0),
                Err(e) => { eprintln!("debugfs: {e}"); ExitCode::from(8) }
            },
            None => { eprintln!("debugfs: rmdir <path>"); ExitCode::from(16) }
        },
        "ln" => {
            let (src, dst) = match (args.first(), args.get(1)) {
                (Some(a), Some(b)) => (*a, *b),
                _ => {
                    eprintln!("debugfs: ln <src> <dst>");
                    return ExitCode::from(16);
                }
            };
            match cmd_ln(fs, src, dst) {
                Ok(()) => ExitCode::from(0),
                Err(e) => { eprintln!("debugfs: {e}"); ExitCode::from(8) }
            }
        }
        "symlink" => {
            let (target, dst) = match (args.first(), args.get(1)) {
                (Some(a), Some(b)) => (*a, *b),
                _ => {
                    eprintln!("debugfs: symlink <target> <path>");
                    return ExitCode::from(16);
                }
            };
            match cmd_symlink(fs, target, dst) {
                Ok(()) => ExitCode::from(0),
                Err(e) => { eprintln!("debugfs: {e}"); ExitCode::from(8) }
            }
        }
        other => { eprintln!("debugfs: unknown command '{other}'"); ExitCode::from(16) }
    }
}

/// Parse a numeric value accepting decimal, `0xNN` hex, or `0oNNN`
/// octal. Angle brackets (`<N>`) are stripped — matches the shapes
/// tooling already uses for block/inode literals.
fn parse_num(s: &str) -> Option<u64> {
    let s = s.trim_start_matches('<').trim_end_matches('>');
    if let Some(rest) = s.strip_prefix("0x").or_else(|| s.strip_prefix("0X")) {
        u64::from_str_radix(rest, 16).ok()
    } else if let Some(rest) = s.strip_prefix("0o").or_else(|| s.strip_prefix("0O")) {
        u64::from_str_radix(rest, 8).ok()
    } else {
        s.parse().ok()
    }
}

/// Parse a mode argument. Accepts `0oNNNN`, `0xNN`, and — unique to
/// mode args — plain numbers are treated as **octal** (so `755` means
/// `0o755`, matching `chmod` convention).
fn parse_mode(s: &str) -> Option<u32> {
    let s = s.trim_start_matches('<').trim_end_matches('>');
    let v: u64 = if let Some(rest) = s.strip_prefix("0x").or_else(|| s.strip_prefix("0X")) {
        u64::from_str_radix(rest, 16).ok()?
    } else if let Some(rest) = s.strip_prefix("0o").or_else(|| s.strip_prefix("0O")) {
        u64::from_str_radix(rest, 8).ok()?
    } else {
        // Bare digits -> octal by chmod(1) convention.
        u64::from_str_radix(s, 8).ok()?
    };
    if v > u16::MAX as u64 { return None; }
    Some(v as u32)
}

/// Locate inode `ino_num`'s on-disk slot, apply `mutate` to the
/// raw bytes, recompute `metadata_csum` if the feature is enabled,
/// and write the slot back. Mirrors the `patch_inode_slot` pattern
/// in fsck — same slot-math, same csum-zeroing discipline.
fn patch_inode_slot<F>(fs: &mut Fs, ino_num: u32, mutate: F) -> std::io::Result<()>
where
    F: FnOnce(&mut [u8]) -> std::io::Result<()>,
{
    if ino_num == 0 || ino_num as u64 > fs.sb.s_inodes_count as u64 {
        return Err(std::io::Error::new(
            std::io::ErrorKind::InvalidInput,
            format!("inode {ino_num} out of range"),
        ));
    }
    let group = (ino_num as u64 - 1) / fs.inodes_per_group;
    let idx   = (ino_num as u64 - 1) % fs.inodes_per_group;
    let table = fs.group_inode_table(group);
    let byte  = table * fs.block_size + idx * fs.inode_size;
    let mut buf = vec![0u8; fs.inode_size as usize];
    fs.dev.read_at(byte, &mut buf)?;

    mutate(&mut buf)?;

    if fs.has_metadata_csum() {
        let generation = u32::from_le_bytes(
            buf[0x64..0x68].try_into().unwrap(),
        );
        let extra_isize = if buf.len() >= 0x82 {
            u16::from_le_bytes(buf[0x80..0x82].try_into().unwrap())
        } else { 0 };
        if buf.len() >= 0x7E {
            buf[0x7C..0x7E].copy_from_slice(&0u16.to_le_bytes());
        }
        let has_hi = extra_isize >= 4 && buf.len() >= 0x84;
        if has_hi {
            buf[0x82..0x84].copy_from_slice(&0u16.to_le_bytes());
        }
        let csum = compute_inode_csum(&fs.sb, ino_num, generation, &buf);
        if buf.len() >= 0x7E {
            buf[0x7C..0x7E].copy_from_slice(&(csum as u16).to_le_bytes());
        }
        if has_hi {
            buf[0x82..0x84].copy_from_slice(&((csum >> 16) as u16).to_le_bytes());
        }
    }

    fs.dev.write_at(byte, &buf)?;
    Ok(())
}

fn cmd_chmod(fs: &mut Fs, ino_num: u32, mode: u32) -> std::io::Result<()> {
    // Only the low 12 bits are user-controllable; preserve S_IFMT.
    let perm = (mode & 0o7777) as u16;
    let mut final_mode: u16 = 0;
    patch_inode_slot(fs, ino_num, |buf| {
        let cur = u16::from_le_bytes(buf[0x00..0x02].try_into().unwrap());
        let kept = cur & 0o170000; // S_IFMT = top 4 bits
        let new_m = kept | perm;
        buf[0x00..0x02].copy_from_slice(&new_m.to_le_bytes());
        final_mode = new_m;
        Ok(())
    })?;
    println!("chmod: inode {ino_num} mode 0o{:o}", final_mode);
    Ok(())
}

fn cmd_chown(fs: &mut Fs, ino_num: u32, uid: u32, gid: Option<u32>) -> std::io::Result<()> {
    let mut final_uid: u32 = 0;
    let mut final_gid: u32 = 0;
    patch_inode_slot(fs, ino_num, |buf| {
        // uid: low16 at 0x02, high16 at 0x78 (osd2.linux2.l_i_uid_high).
        let uid_lo = (uid & 0xFFFF) as u16;
        let uid_hi = ((uid >> 16) & 0xFFFF) as u16;
        buf[0x02..0x04].copy_from_slice(&uid_lo.to_le_bytes());
        if buf.len() >= 0x7A {
            buf[0x78..0x7A].copy_from_slice(&uid_hi.to_le_bytes());
        }
        final_uid = uid;
        if let Some(g) = gid {
            let gid_lo = (g & 0xFFFF) as u16;
            let gid_hi = ((g >> 16) & 0xFFFF) as u16;
            buf[0x18..0x1A].copy_from_slice(&gid_lo.to_le_bytes());
            if buf.len() >= 0x7C {
                buf[0x7A..0x7C].copy_from_slice(&gid_hi.to_le_bytes());
            }
            final_gid = g;
        } else {
            let glo = u16::from_le_bytes(buf[0x18..0x1A].try_into().unwrap()) as u32;
            let ghi = if buf.len() >= 0x7C {
                u16::from_le_bytes(buf[0x7A..0x7C].try_into().unwrap()) as u32
            } else { 0 };
            final_gid = (ghi << 16) | glo;
        }
        Ok(())
    })?;
    println!("chown: inode {ino_num} uid={} gid={}", final_uid, final_gid);
    Ok(())
}

fn cmd_mi(fs: &mut Fs, ino_num: u32, field: &str, value: &str) -> std::io::Result<()> {
    if ino_num == 0 || ino_num as u64 > fs.sb.s_inodes_count as u64 {
        return Err(std::io::Error::new(
            std::io::ErrorKind::InvalidInput,
            format!("inode {ino_num} out of range"),
        ));
    }
    let v = parse_num(value).ok_or_else(|| std::io::Error::new(
        std::io::ErrorKind::InvalidInput,
        format!("bad value '{value}'"),
    ))?;

    // Slot-locating: same formula as cmd_stat / cmd_clri / read_inode.
    let group = (ino_num as u64 - 1) / fs.inodes_per_group;
    let idx   = (ino_num as u64 - 1) % fs.inodes_per_group;
    let table = fs.group_inode_table(group);
    let byte  = table * fs.block_size + idx * fs.inode_size;
    let mut buf = vec![0u8; fs.inode_size as usize];
    fs.dev.read_at(byte, &mut buf)?;

    // Patch one field. Offsets from the ext4 inode layout.
    let (display_v, bad_width) = match field {
        "mode" => {
            if v > u16::MAX as u64 { (v, true) }
            else {
                buf[0x00..0x02].copy_from_slice(&(v as u16).to_le_bytes());
                (v, false)
            }
        }
        "uid" => {
            if v > u16::MAX as u64 { (v, true) }
            else {
                buf[0x02..0x04].copy_from_slice(&(v as u16).to_le_bytes());
                (v, false)
            }
        }
        "gid" => {
            if v > u16::MAX as u64 { (v, true) }
            else {
                buf[0x18..0x1A].copy_from_slice(&(v as u16).to_le_bytes());
                (v, false)
            }
        }
        "size" => {
            let lo = (v & 0xFFFF_FFFF) as u32;
            let hi = ((v >> 32) & 0xFFFF_FFFF) as u32;
            buf[0x04..0x08].copy_from_slice(&lo.to_le_bytes());
            if buf.len() >= 0x70 {
                buf[0x6C..0x70].copy_from_slice(&hi.to_le_bytes());
            }
            (v, false)
        }
        "links" => {
            if v > u16::MAX as u64 { (v, true) }
            else {
                buf[0x1A..0x1C].copy_from_slice(&(v as u16).to_le_bytes());
                (v, false)
            }
        }
        "flags" => {
            if v > u32::MAX as u64 { (v, true) }
            else {
                buf[0x20..0x24].copy_from_slice(&(v as u32).to_le_bytes());
                (v, false)
            }
        }
        "dtime" => {
            if v > u32::MAX as u64 { (v, true) }
            else {
                buf[0x14..0x18].copy_from_slice(&(v as u32).to_le_bytes());
                (v, false)
            }
        }
        other => {
            return Err(std::io::Error::new(
                std::io::ErrorKind::InvalidInput,
                format!("unknown field '{other}' (supported: mode uid gid size links flags dtime)"),
            ));
        }
    };
    if bad_width {
        return Err(std::io::Error::new(
            std::io::ErrorKind::InvalidInput,
            format!("value {display_v} out of range for field '{field}'"),
        ));
    }

    // Same csum-recompute gate as fsck's patch_inode_slot: the
    // compute helper expects the two csum half-fields zeroed in
    // the input bytes, so zero them, compute, then patch back.
    if fs.has_metadata_csum() {
        let generation = u32::from_le_bytes(
            buf[0x64..0x68].try_into().unwrap(),
        );
        let extra_isize = if buf.len() >= 0x82 {
            u16::from_le_bytes(buf[0x80..0x82].try_into().unwrap())
        } else { 0 };
        if buf.len() >= 0x7E {
            buf[0x7C..0x7E].copy_from_slice(&0u16.to_le_bytes());
        }
        let has_hi = extra_isize >= 4 && buf.len() >= 0x84;
        if has_hi {
            buf[0x82..0x84].copy_from_slice(&0u16.to_le_bytes());
        }
        let csum = compute_inode_csum(&fs.sb, ino_num, generation, &buf);
        if buf.len() >= 0x7E {
            buf[0x7C..0x7E].copy_from_slice(&(csum as u16).to_le_bytes());
        }
        if has_hi {
            buf[0x82..0x84].copy_from_slice(&((csum >> 16) as u16).to_le_bytes());
        }
    }

    fs.dev.write_at(byte, &buf)?;

    // Mode prints in octal to match stat; the rest print decimal.
    if field == "mode" {
        println!("inode {ino_num}: set {field} = 0o{:o}", display_v);
    } else {
        println!("inode {ino_num}: set {field} = {}", display_v);
    }
    Ok(())
}

fn cmd_block_dump(fs: &mut Fs, blk: u64) -> std::io::Result<()> {
    let bs = fs.block_size as usize;
    let mut buf = vec![0u8; bs];
    fs.read_block(blk, &mut buf)?;
    println!("block {blk} (physical):");
    // 16 bytes per row, 4-digit hex offset, hex + ASCII sidebar.
    let mut off = 0usize;
    while off < bs {
        let end = (off + 16).min(bs);
        let row = &buf[off..end];
        let mut hex = String::new();
        for (i, b) in row.iter().enumerate() {
            if i == 8 { hex.push(' '); }
            hex.push_str(&format!("{:02x} ", b));
        }
        // Pad the short final row so the ASCII column aligns.
        let target_cells = if row.len() <= 8 { 8 * 3 } else { 16 * 3 + 1 };
        while hex.len() < target_cells { hex.push(' '); }
        let mut ascii = String::new();
        for &b in row.iter() {
            ascii.push(if (0x20..0x7f).contains(&b) { b as char } else { '.' });
        }
        println!("{:04x}  {} |{}|", off, hex.trim_end(), ascii);
        off = end;
    }
    Ok(())
}

fn cmd_dump_inode(fs: &mut Fs, ino_num: u32, outpath: Option<&std::path::Path>)
    -> std::io::Result<()>
{
    use std::io::Write;

    if ino_num == 0 || ino_num as u64 > fs.sb.s_inodes_count as u64 {
        return Err(std::io::Error::new(
            std::io::ErrorKind::InvalidInput,
            format!("inode {ino_num} out of range"),
        ));
    }
    let inode = fs.read_inode(ino_num)?;
    let mode = inode.i_mode;
    let size = inode.size();

    // Reject device / fifo / socket modes up front — nothing
    // reasonable to dump, and the extent walk would be a no-op.
    let kind = mode & S_IFMT;
    match kind {
        S_IFREG | S_IFDIR | S_IFLNK => {}
        S_IFCHR | S_IFBLK => {
            return Err(std::io::Error::new(
                std::io::ErrorKind::InvalidInput,
                format!("inode {ino_num}: device nodes have no data"),
            ));
        }
        S_IFIFO | S_IFSOCK => {
            return Err(std::io::Error::new(
                std::io::ErrorKind::InvalidInput,
                format!("inode {ino_num}: FIFOs and sockets have no data"),
            ));
        }
        _ => {
            return Err(std::io::Error::new(
                std::io::ErrorKind::InvalidInput,
                format!("inode {ino_num}: unsupported mode {:#o}", mode),
            ));
        }
    }

    let mut data: Vec<u8> = Vec::new();

    // Inline-data symlinks (target < 60 bytes) store the path
    // directly in i_block as raw bytes — no extent tree.
    if kind == S_IFLNK && size > 0 && size < 60 {
        // Inode is a packed struct; copy i_block out as a value
        // first so we aren't taking a misaligned reference into it.
        let i_block: [u32; 15] = inode.i_block;
        let mut raw = [0u8; 60];
        for (i, w) in i_block.iter().enumerate() {
            raw[i*4 .. i*4 + 4].copy_from_slice(&w.to_le_bytes());
        }
        data.extend_from_slice(&raw[..size as usize]);
    } else {
        // Walk the extent tree, reading each run block-by-block into
        // the output buffer at its logical offset. For directories
        // i_size usually == one block anyway, but we still honour it.
        let bs = fs.block_size as usize;
        let mut runs: Vec<(u32, u64, u16)> = Vec::new();
        extent::walk_extents(fs, &inode, |r| {
            runs.push((r.logical, r.physical, r.length));
        })?;
        // Figure out buffer size: for files and symlinks this is
        // i_size; for directories we fall back to all covered
        // logical blocks (i_size on dirs == allocated bytes).
        let total_logical_blocks: u32 = runs.iter()
            .map(|(lg, _, len)| lg.saturating_add(*len as u32))
            .max()
            .unwrap_or(0);
        let covered_bytes = total_logical_blocks as u64 * bs as u64;
        let effective_size = if kind == S_IFDIR {
            // Dirs: dump everything covered by extents, capped by
            // i_size if it's larger-than-covered (shouldn't happen
            // on a well-formed fs but defensive anyway).
            covered_bytes.max(size)
        } else {
            size
        };
        data.resize(effective_size as usize, 0);

        let mut blk_buf = vec![0u8; bs];
        for (logical, physical, length) in runs {
            for off in 0..length as u64 {
                let lb = logical as u64 + off;
                let pb = physical + off;
                let start = (lb as usize) * bs;
                if start >= data.len() { break; }
                fs.read_block(pb, &mut blk_buf)?;
                let end = (start + bs).min(data.len());
                let slice_len = end - start;
                data[start..end].copy_from_slice(&blk_buf[..slice_len]);
            }
        }
    }

    // Clamp to i_size for regular files / symlinks (non-zero size).
    // Directories intentionally keep the full block.
    if kind != S_IFDIR && size > 0 && data.len() > size as usize {
        data.truncate(size as usize);
    }

    let written = data.len();
    let dest: String = match outpath {
        Some(p) => {
            let mut f = std::fs::OpenOptions::new()
                .write(true).create(true).truncate(true).open(p)?;
            f.write_all(&data)?;
            f.flush()?;
            p.display().to_string()
        }
        None => {
            let stdout = std::io::stdout();
            let mut lk = stdout.lock();
            lk.write_all(&data)?;
            lk.flush()?;
            "<stdout>".into()
        }
    };

    // Print the status line to stderr so it doesn't mix into stdout
    // when the caller is piping the payload somewhere.
    eprintln!("dump_inode {ino_num}: wrote {written} bytes to {dest}");
    Ok(())
}

fn parse_ino(s: &str) -> Option<u32> {
    // Accept `<N>` (angle-bracket form that tooling uses) or a
    // plain integer. Hex (0x…) also supported for operators
    // reading out of hexdumps.
    let s = s.trim_start_matches('<').trim_end_matches('>');
    if let Some(rest) = s.strip_prefix("0x") {
        u32::from_str_radix(rest, 16).ok()
    } else {
        s.parse().ok()
    }
}

fn parse_u64(s: &str) -> Option<u64> {
    let s = s.trim_start_matches('<').trim_end_matches('>');
    if let Some(rest) = s.strip_prefix("0x") {
        u64::from_str_radix(rest, 16).ok()
    } else {
        s.parse().ok()
    }
}

fn cmd_clri(fs: &mut Fs, ino_num: u32) -> std::io::Result<()> {
    // Sanity: same bounds check that read_inode enforces, so a
    // bogus argument gets a clear error rather than a corrupt
    // write somewhere outside the inode table.
    if ino_num == 0 || ino_num as u64 > fs.sb.s_inodes_count as u64 {
        return Err(std::io::Error::new(
            std::io::ErrorKind::InvalidInput,
            format!("inode {ino_num} out of range"),
        ));
    }
    // Same slot-locating formula as cmd_stat / Fs::read_inode.
    let group = (ino_num as u64 - 1) / fs.inodes_per_group;
    let idx   = (ino_num as u64 - 1) % fs.inodes_per_group;
    let table = fs.group_inode_table(group);
    let byte  = table * fs.block_size + idx * fs.inode_size;
    let zeros = vec![0u8; fs.inode_size as usize];
    fs.dev.write_at(byte, &zeros)?;
    println!("cleared inode {ino_num}");
    Ok(())
}

fn cmd_icheck(fs: &mut Fs, target_blk: u64) -> std::io::Result<()> {
    // Linear reverse-lookup: walk each plausibly-allocated inode's
    // extent tree and report every run that covers target_blk.
    // No bigalloc accounting — the task calls this out explicitly.
    let total = fs.sb.s_inodes_count;
    let mut hits: Vec<(u32, u32)> = Vec::new();
    for ino_num in 1u32..=total {
        // Cheap filter: skip slots that look unallocated. Saves a
        // lot of work on a fresh fs where most inodes are empty.
        let inode = match fs.read_inode(ino_num) {
            Ok(i) => i,
            Err(_) => continue,
        };
        if inode.i_mode == 0 && inode.i_links_count == 0 {
            continue;
        }
        let mut found: Option<u32> = None;
        let _ = extent::walk_extents(fs, &inode, |r| {
            if found.is_some() { return; }
            let end = r.physical.saturating_add(r.length as u64);
            if target_blk >= r.physical && target_blk < end {
                let logical = r.logical + (target_blk - r.physical) as u32;
                found = Some(logical);
            }
        });
        if let Some(logical) = found {
            hits.push((ino_num, logical));
        }
    }
    if hits.is_empty() {
        println!("nothing found");
    } else {
        for (ino, logical) in hits {
            println!("{ino} {logical}");
        }
    }
    Ok(())
}

fn cmd_stats(fs: &Fs) {
    let sb = &fs.sb;
    let uuid = sb.s_uuid;
    let magic = sb.s_magic;
    let total_blocks = sb.blocks_count();
    let total_inodes = sb.s_inodes_count;
    let free_blocks = sb.free_blocks();
    let free_inodes = sb.s_free_inodes_count;
    let bs = sb.block_size();
    let ipg = sb.s_inodes_per_group;
    let bpg = sb.s_blocks_per_group;
    println!("Filesystem UUID:    {}", format_uuid(&uuid));
    println!("Filesystem magic:   0x{magic:04X}");
    println!("Block size:         {bs}");
    println!("Total blocks:       {total_blocks}");
    println!("Free blocks:        {free_blocks}");
    println!("Total inodes:       {total_inodes}");
    println!("Free inodes:        {free_inodes}");
    println!("Blocks per group:   {bpg}");
    println!("Inodes per group:   {ipg}");
    println!("Group count:        {}", fs.groups_count);
}

fn cmd_stat(fs: &mut Fs, ino_num: u32, extended: bool) -> std::io::Result<()> {
    let ino = fs.read_inode(ino_num)?;
    let mode = ino.i_mode;
    let uid = ino.i_uid;
    let gid = ino.i_gid;
    let size = ino.size();
    let links = ino.i_links_count;
    let blocks = ino.i_blocks_lo;
    let flags = ino.i_flags;
    let gen = ino.i_generation;
    let atime = ino.i_atime;
    let ctime = ino.i_ctime;
    let mtime = ino.i_mtime;
    let dtime = ino.i_dtime;
    println!("Inode:   {ino_num}");
    println!("  Mode:        {mode:#o} ({})", describe_mode(mode));
    println!("  UID/GID:     {uid}/{gid}");
    println!("  Size:        {size}");
    println!("  Links:       {links}");
    println!("  Blocks:      {blocks} (512-byte sectors)");
    println!("  Flags:       0x{flags:x}");
    println!("  Generation:  {gen}");
    println!("  atime:       {atime}");
    println!("  ctime:       {ctime}");
    println!("  mtime:       {mtime}");
    println!("  dtime:       {dtime}");
    // Extent layout
    if flags & EXT4_EXTENTS_FL != 0 {
        println!("  Extents:");
        let _ = extent::walk_extents(fs, &ino, |r| {
            println!("    logical {}..+{} -> physical {}",
                     r.logical, r.length, r.physical);
        });
    }
    if extended {
        print_extended_inode(fs, ino_num)?;
    }
    Ok(())
}

/// Print the extra-inode fields that live past the legacy 128-byte
/// struct. Each field is read straight from the raw on-disk slot
/// so this works regardless of how much of the slot the in-memory
/// Inode struct covers.
fn print_extended_inode(fs: &mut Fs, ino_num: u32) -> std::io::Result<()> {
    let raw = fs.read_inode_raw(ino_num)?;
    // Base legacy inode is 128 bytes; anything smaller can't have
    // extra fields at all.
    if raw.len() < 0x82 {
        return Ok(());
    }
    let u16_at = |o: usize| u16::from_le_bytes([raw[o], raw[o+1]]);
    let u32_at = |o: usize| u32::from_le_bytes([raw[o], raw[o+1], raw[o+2], raw[o+3]]);

    let extra_isize = u16_at(0x80);
    let csum_lo     = u16_at(0x7C);
    println!("  Extra isize:    {extra_isize}");
    println!("  Checksum lo:    0x{csum_lo:04x}");

    if extra_isize >= 4 && raw.len() >= 0x84 {
        let csum_hi = u16_at(0x82);
        println!("  Checksum hi:    0x{csum_hi:04x}");
    }
    if extra_isize >= 8 && raw.len() >= 0x88 {
        let ctime_extra = u32_at(0x84);
        println!("  ctime extra:    {ctime_extra} ns");
    }
    if extra_isize >= 12 && raw.len() >= 0x8C {
        let mtime_extra = u32_at(0x88);
        println!("  mtime extra:    {mtime_extra} ns");
    }
    if extra_isize >= 16 && raw.len() >= 0x90 {
        let atime_extra = u32_at(0x8C);
        println!("  atime extra:    {atime_extra} ns");
    }
    if extra_isize >= 20 && raw.len() >= 0x94 {
        let crtime = u32_at(0x90);
        println!("  crtime:         {crtime}");
    }
    if extra_isize >= 24 && raw.len() >= 0x98 {
        let crtime_extra = u32_at(0x94);
        println!("  crtime extra:   {crtime_extra} ns");
    }
    if extra_isize >= 28 && raw.len() >= 0x9C {
        let version_hi = u32_at(0x98);
        println!("  Version hi:     {version_hi}");
    }
    Ok(())
}

fn cmd_ls(fs: &mut Fs, path: &str) -> std::io::Result<()> {
    let target = resolve_path(fs, path)?;
    let inode = fs.read_inode(target)?;
    if inode.i_mode & S_IFMT != S_IFDIR {
        println!("{path}: not a directory");
        return Ok(());
    }
    let mut blocks: Vec<u64> = Vec::new();
    extent::walk_extents(fs, &inode, |r| {
        for off in 0..r.length as u64 { blocks.push(r.physical + off); }
    })?;
    let bs = fs.block_size as usize;
    for blk in blocks {
        let mut buf = vec![0u8; bs];
        fs.read_block(blk, &mut buf)?;
        walk_dir_block_print(fs, &buf, bs);
    }
    Ok(())
}

fn walk_dir_block_print(fs: &mut Fs, buf: &[u8], bs: usize) {
    let mut off = 0usize;
    while off + 8 <= buf.len() {
        let inode = u32::from_le_bytes([buf[off], buf[off+1], buf[off+2], buf[off+3]]);
        let rec_len = u16::from_le_bytes([buf[off+4], buf[off+5]]) as usize;
        let name_len = buf[off+6] as usize;
        let file_type = buf[off+7];
        if rec_len < 8 || off + rec_len > bs { return; }
        if inode != 0 && name_len > 0 && file_type != 0xDE
           && off + 8 + name_len <= buf.len()
        {
            let name = &buf[off + 8 .. off + 8 + name_len];
            let name_str = String::from_utf8_lossy(name);
            let type_str = match file_type {
                1 => "-", 2 => "d", 3 => "c", 4 => "b", 5 => "p", 6 => "s", 7 => "l",
                _ => "?",
            };
            let mode_size = fs.read_inode(inode)
                .map(|i| (i.i_mode, i.size()))
                .unwrap_or((0, 0));
            println!("  {} {:>8} {:>10}  {}",
                     type_str, inode, mode_size.1, name_str);
        }
        off += rec_len;
    }
}

fn resolve_path(fs: &mut Fs, path: &str) -> std::io::Result<u32> {
    let clean = path.trim();
    if clean.is_empty() || clean == "/" { return Ok(EXT4_ROOT_INO); }
    // Walk from root one component at a time. Only supports
    // literal name lookups — no hash-tree acceleration. Fine for
    // the depths a debugfs session typically pokes at.
    let mut cur = EXT4_ROOT_INO;
    for comp in clean.split('/').filter(|s| !s.is_empty()) {
        cur = lookup_in_dir(fs, cur, comp.as_bytes())?;
    }
    Ok(cur)
}

fn lookup_in_dir(fs: &mut Fs, dir_ino: u32, name: &[u8]) -> std::io::Result<u32> {
    let inode = fs.read_inode(dir_ino)?;
    if inode.i_mode & S_IFMT != S_IFDIR {
        return Err(std::io::Error::new(std::io::ErrorKind::NotFound, "not a directory"));
    }
    // When the parent directory is marked casefolded, name
    // matches use the ASCII fold from anvil_core::casefold
    // instead of byte-exact compare. See module docs there
    // for the Unicode gap.
    let casefolded = inode.i_flags & EXT4_CASEFOLD_FL != 0;
    let mut blocks: Vec<u64> = Vec::new();
    extent::walk_extents(fs, &inode, |r| {
        for off in 0..r.length as u64 { blocks.push(r.physical + off); }
    })?;
    let bs = fs.block_size as usize;
    for blk in blocks {
        let mut buf = vec![0u8; bs];
        fs.read_block(blk, &mut buf)?;
        let mut off = 0usize;
        while off + 8 <= buf.len() {
            let inode = u32::from_le_bytes([buf[off], buf[off+1], buf[off+2], buf[off+3]]);
            let rec_len = u16::from_le_bytes([buf[off+4], buf[off+5]]) as usize;
            let name_len = buf[off+6] as usize;
            if rec_len < 8 || off + rec_len > bs { break; }
            if inode != 0 && off + 8 + name_len <= buf.len() {
                let entry_name = &buf[off + 8 .. off + 8 + name_len];
                let hit = if casefolded {
                    anvil_core::casefold::eq(entry_name, name)
                } else {
                    entry_name == name
                };
                if hit { return Ok(inode); }
            }
            off += rec_len;
        }
    }
    Err(std::io::Error::new(std::io::ErrorKind::NotFound,
        format!("no such entry: {}", String::from_utf8_lossy(name))))
}


/// Copy `src` (host path) into the filesystem at absolute path `dst`.
///
/// Symmetric with `dump_inode`. The parent directory must exist,
/// and an entry with the target basename must not already exist.
/// A fresh inode is allocated past `s_first_ino`; data blocks are
/// allocated as a single contiguous run in group 0 past the
/// existing metadata + journal + data region.
fn cmd_write(fs: &mut Fs, src: &std::path::Path, dst: &str) -> std::io::Result<()> {
    // --- Split dst into (parent_path, basename). Parent defaults
    //     to "/" when dst is "/name".
    if !dst.starts_with('/') {
        return Err(std::io::Error::new(
            std::io::ErrorKind::InvalidInput,
            format!("dst '{dst}' must be absolute (start with '/')"),
        ));
    }
    let trimmed = dst.trim_end_matches('/');
    let (parent_path, basename) = match trimmed.rsplit_once('/') {
        Some((p, b)) => (if p.is_empty() { "/" } else { p }, b),
        None => return Err(std::io::Error::new(
            std::io::ErrorKind::InvalidInput,
            format!("dst '{dst}' has no basename"),
        )),
    };
    if basename.is_empty() {
        return Err(std::io::Error::new(
            std::io::ErrorKind::InvalidInput,
            format!("dst '{dst}' has empty basename"),
        ));
    }
    let name_bytes = basename.as_bytes();
    if name_bytes.len() > 255 || name_bytes.contains(&0) {
        return Err(std::io::Error::new(
            std::io::ErrorKind::InvalidInput,
            format!("dst basename '{basename}' is not a valid filename"),
        ));
    }

    // --- Read host source bytes up-front, so any read error aborts
    //     before we mutate disk state.
    let data = std::fs::read(src)?;
    let data_len = data.len() as u64;

    // --- Resolve parent dir inode.
    let parent_ino_num = resolve_path(fs, parent_path).map_err(|e| {
        std::io::Error::new(e.kind(), format!("parent '{parent_path}': {e}"))
    })?;
    let parent_inode = fs.read_inode(parent_ino_num)?;
    if parent_inode.i_mode & S_IFMT != S_IFDIR {
        return Err(std::io::Error::new(
            std::io::ErrorKind::InvalidInput,
            format!("parent '{parent_path}' is not a directory"),
        ));
    }

    // --- Refuse if name already exists in parent.
    if dir_has_name(fs, &parent_inode, name_bytes)? {
        return Err(std::io::Error::new(
            std::io::ErrorKind::AlreadyExists,
            format!("{dst}: file already exists"),
        ));
    }

    let bs = fs.block_size;
    let nblocks: u64 = if data_len == 0 { 0 } else { data_len.div_ceil(bs) };

    // --- Allocate a free inode in group 0 past `s_first_ino`.
    //     Inode N is at bitmap bit (N-1). We start scanning at
    //     s_first_ino so the first candidate is max(s_first_ino, 11).
    //     s_first_ino is typically 11 (lost+found); the prose says
    //     "bump past s_first_ino", so first candidate is
    //     max(s_first_ino+1, EXT4_FIRST_NON_RSV_INO+1) == 12.
    let first_ino = fs.sb.s_first_ino.max(EXT4_FIRST_NON_RSV_INO);
    let ipg = fs.inodes_per_group as usize;
    let ib_block = fs.group_inode_bitmap(0);
    let mut ib_buf = vec![0u8; bs as usize];
    fs.read_block(ib_block, &mut ib_buf)?;
    let mut new_ino_num: Option<u32> = None;
    // inodes 1..=first_ino are reserved; scan from (first_ino + 1).
    let start_bit = first_ino as usize; // bit index == ino - 1; bit first_ino corresponds to ino=first_ino+1
    for bit in start_bit..ipg {
        if !anvil_core::bitmap::test_bit(&ib_buf, bit) {
            new_ino_num = Some((bit + 1) as u32);
            break;
        }
    }
    let new_ino_num = new_ino_num.ok_or_else(|| std::io::Error::new(
        std::io::ErrorKind::Other,
        "no free inode slot in group 0",
    ))?;

    // --- Allocate a contiguous free block run in group 0.
    let bb_block = fs.group_block_bitmap(0);
    let mut bb_buf = vec![0u8; bs as usize];
    fs.read_block(bb_block, &mut bb_buf)?;
    let bpg = fs.blocks_per_group as usize;
    let first_data_block = fs.sb.s_first_data_block as u64;
    let alloc_phys_start: u64 = if nblocks == 0 {
        0
    } else {
        // Find a contiguous run of `nblocks` free bits. Relative
        // bit index i corresponds to physical block
        // (first_data_block + i) when scanning group 0. (The task
        // only allocates in group 0, same as mkfs -d.)
        let mut run_start: Option<usize> = None;
        let mut run_len: usize = 0;
        let mut found: Option<usize> = None;
        for bit in 0..bpg {
            if anvil_core::bitmap::test_bit(&bb_buf, bit) {
                run_start = None;
                run_len = 0;
                continue;
            }
            if run_start.is_none() {
                run_start = Some(bit);
                run_len = 0;
            }
            run_len += 1;
            if run_len as u64 == nblocks {
                found = run_start;
                break;
            }
        }
        let bit = found.ok_or_else(|| std::io::Error::new(
            std::io::ErrorKind::Other,
            format!("no contiguous free run of {nblocks} blocks in group 0"),
        ))?;
        first_data_block + bit as u64
    };

    // --- All allocations are committed in memory. From here on out
    //     we start writing to the device. On failure we bail — the
    //     task doesn't require transactional rollback, but every
    //     error above this point left the disk untouched.

    // 1. Write file data into the allocated run, zero-padding the
    //    tail of the last block when data doesn't align.
    if nblocks > 0 {
        let start_byte = alloc_phys_start * bs;
        fs.dev.write_at(start_byte, &data)?;
        let tail_start = start_byte + data_len;
        let tail_end = start_byte + nblocks * bs;
        if tail_end > tail_start {
            fs.dev.zero_range(tail_start, tail_end)?;
        }
    }

    // 2. Build the new regular-file inode.
    let now = now_u32();
    let inode_size = fs.inode_size as usize;
    let mut ibuf = vec![0u8; inode_size];
    // i_mode (u16 @ 0x00) = S_IFREG | 0o644
    let mode: u16 = S_IFREG | 0o644;
    ibuf[0x00..0x02].copy_from_slice(&mode.to_le_bytes());
    // i_uid, i_gid zero (already).
    // i_size_lo @ 0x04 / i_size_hi @ 0x6C.
    ibuf[0x04..0x08].copy_from_slice(&((data_len & 0xFFFF_FFFF) as u32).to_le_bytes());
    ibuf[0x6C..0x70].copy_from_slice(&((data_len >> 32) as u32).to_le_bytes());
    // i_atime / i_ctime / i_mtime @ 0x08 / 0x10 / 0x0C
    ibuf[0x08..0x0C].copy_from_slice(&now.to_le_bytes());
    ibuf[0x0C..0x10].copy_from_slice(&now.to_le_bytes());
    ibuf[0x10..0x14].copy_from_slice(&now.to_le_bytes());
    // i_dtime @ 0x14 zero.
    // i_links_count @ 0x1A = 1
    ibuf[0x1A..0x1C].copy_from_slice(&1u16.to_le_bytes());
    // i_blocks_lo @ 0x1C — count in 512-byte sectors. This counts
    // the sectors actually allocated on disk (nblocks * bs/512),
    // not ceil(len/512): a 15-byte file in a 1024-byte block
    // still consumes two 512-byte sectors.
    let i_blocks_lo: u32 = (nblocks * (bs / 512)) as u32;
    ibuf[0x1C..0x20].copy_from_slice(&i_blocks_lo.to_le_bytes());
    // i_flags @ 0x20 = EXT4_EXTENTS_FL
    ibuf[0x20..0x24].copy_from_slice(&EXT4_EXTENTS_FL.to_le_bytes());
    // Extent tree in i_block (@ 0x28, 60 bytes = 5 * 12). Layout:
    //   ExtentHeader { magic=0xF30A, entries, max=4, depth=0, gen=0 }
    //   Extent       { ee_block, ee_len, ee_start_hi, ee_start_lo }
    let iblock_off = 0x28usize;
    // ExtentHeader
    ibuf[iblock_off..iblock_off+2].copy_from_slice(&EXT4_EXT_MAGIC.to_le_bytes());
    let eh_entries: u16 = if nblocks > 0 { 1 } else { 0 };
    ibuf[iblock_off+2..iblock_off+4].copy_from_slice(&eh_entries.to_le_bytes());
    ibuf[iblock_off+4..iblock_off+6].copy_from_slice(&4u16.to_le_bytes()); // eh_max
    // eh_depth, eh_generation already zero.
    if nblocks > 0 {
        // Single extent starting at logical 0, length nblocks,
        // physical alloc_phys_start. Enforced nblocks <= 32768
        // (ee_len is u16). For a 16M image scaled, len fits.
        if nblocks > u16::MAX as u64 {
            return Err(std::io::Error::new(
                std::io::ErrorKind::Other,
                format!("file {nblocks} blocks exceeds single-extent cap (32768)"),
            ));
        }
        let e_off = iblock_off + 12;
        ibuf[e_off..e_off+4].copy_from_slice(&0u32.to_le_bytes()); // ee_block
        ibuf[e_off+4..e_off+6].copy_from_slice(&(nblocks as u16).to_le_bytes()); // ee_len
        ibuf[e_off+6..e_off+8].copy_from_slice(&((alloc_phys_start >> 32) as u16).to_le_bytes()); // ee_start_hi
        ibuf[e_off+8..e_off+12].copy_from_slice(&(alloc_phys_start as u32).to_le_bytes()); // ee_start_lo
    }
    // i_generation @ 0x64 = 0 (already).
    // extra_isize when inode_size >= 256.
    if inode_size >= 256 {
        let extra_isize: u16 = 32;
        ibuf[0x80..0x82].copy_from_slice(&extra_isize.to_le_bytes());
        // i_crtime @ 0x90
        ibuf[0x90..0x94].copy_from_slice(&now.to_le_bytes());
    }

    // Stamp i_checksum_lo/hi if metadata_csum is on. Input bytes
    // must have the two csum slots zeroed (they already are).
    if fs.has_metadata_csum() {
        let generation: u32 = 0;
        let extra_isize = if inode_size >= 256 {
            u16::from_le_bytes(ibuf[0x80..0x82].try_into().unwrap())
        } else { 0 };
        let use_hi = inode_size >= 256 && extra_isize > 2;
        let csum = compute_inode_csum(&fs.sb, new_ino_num, generation, &ibuf);
        ibuf[0x7C..0x7E].copy_from_slice(&(csum as u16).to_le_bytes());
        if use_hi {
            ibuf[0x82..0x84].copy_from_slice(&((csum >> 16) as u16).to_le_bytes());
        }
    }

    // Write the inode into group 0's inode table.
    let group0 = 0u64;
    let idx = (new_ino_num as u64 - 1) % fs.inodes_per_group;
    let table = fs.group_inode_table(group0);
    let ino_byte = table * bs + idx * fs.inode_size;
    fs.dev.write_at(ino_byte, &ibuf)?;

    // 3. Insert the dir entry into the parent directory. The parent
    //    directory occupies a single extent block in the current
    //    layout; we look up that block, split an existing entry's
    //    rec_len to make room, and re-stamp the tail csum.
    add_parent_dir_entry(
        fs, parent_ino_num, &parent_inode,
        new_ino_num, name_bytes, EXT4_FT_REG_FILE,
    )?;

    // 4. Update the inode bitmap.
    anvil_core::bitmap::set_bit(&mut ib_buf, (new_ino_num - 1) as usize);
    fs.dev.write_at(ib_block * bs, &ib_buf)?;

    // 5. Update the block bitmap for the allocated run.
    if nblocks > 0 {
        for i in 0..nblocks as usize {
            let rel = (alloc_phys_start + i as u64 - first_data_block) as usize;
            anvil_core::bitmap::set_bit(&mut bb_buf, rel);
        }
        fs.dev.write_at(bb_block * bs, &bb_buf)?;
    }

    // 6. Update group 0 descriptor: free_blocks -= nblocks,
    //    free_inodes -= 1. Recompute bitmap csums if enabled.
    {
        let gd = &mut fs.gdt[0];
        let cur_fb = (gd.bg_free_blocks_count_lo as u32)
            | ((gd.bg_free_blocks_count_hi as u32) << 16);
        let cur_fi = (gd.bg_free_inodes_count_lo as u32)
            | ((gd.bg_free_inodes_count_hi as u32) << 16);
        gd.set_free_blocks(cur_fb.saturating_sub(nblocks as u32));
        gd.set_free_inodes(cur_fi.saturating_sub(1));
    }
    if fs.has_metadata_csum() {
        let bbc = compute_bitmap_csum(&fs.sb, &bb_buf);
        fs.gdt[0].bg_block_bitmap_csum_lo = bbc as u16;
        if fs.desc_size as usize >= 0x3A {
            fs.gdt[0].bg_block_bitmap_csum_hi = (bbc >> 16) as u16;
        }
        let ipg_bytes = ((fs.inodes_per_group as usize + 7) / 8).min(ib_buf.len());
        let ibc = compute_bitmap_csum(&fs.sb, &ib_buf[..ipg_bytes]);
        fs.gdt[0].bg_inode_bitmap_csum_lo = ibc as u16;
        if fs.desc_size as usize >= 0x3A {
            fs.gdt[0].bg_inode_bitmap_csum_hi = (ibc >> 16) as u16;
        }
    }

    // 7. Re-stamp every GDT descriptor's bg_checksum (since group
    //    0 changed, and the csum of each descriptor is independent
    //    of the others, only group 0 strictly needs it — but
    //    touching all keeps the invariant simple).
    if fs.has_metadata_csum() {
        // Drain the uuid / sb features once; csum helpers want
        // fs.sb by ref.
        for gi in 0..fs.groups_count {
            let desc_bytes = fs.gdt[gi as usize].to_bytes(fs.desc_size as usize);
            let csum = compute_gdt_csum(&fs.sb, gi as u32, &desc_bytes);
            fs.gdt[gi as usize].bg_checksum = csum as u16;
        }
    } else if fs.sb.s_feature_ro_compat & EXT4_FEATURE_RO_COMPAT_GDT_CSUM != 0 {
        // Legacy GDT_CSUM path (no metadata_csum) — we don't
        // currently compute it here; mkfs doesn't produce that
        // combination, so leaving the stored value stale is not
        // expected. Fall through — fsck will renumber if needed.
    }

    // 8. Update SB free counts.
    {
        let fb = fs.sb.free_blocks();
        fs.sb.set_free_blocks(fb.saturating_sub(nblocks));
        fs.sb.s_free_inodes_count = fs.sb.s_free_inodes_count.saturating_sub(1);
    }
    // Re-stamp SB checksum.
    if fs.has_metadata_csum() {
        fs.sb.s_checksum = 0;
        let sb_bytes = fs.sb.to_bytes();
        let new_sb_csum = anvil_core::crc::crc32c_cont(0xFFFFFFFF, &sb_bytes[..0x3FC]);
        fs.sb.s_checksum = new_sb_csum;
    }

    // 9. Flush SB + GDT.
    fs.write_superblock()?;
    fs.write_gdt()?;

    // Parent inode was touched (mtime/ctime) inside add_parent_dir_entry;
    // nothing else to flush.

    eprintln!("write: created {dst} (inode {new_ino_num}, {data_len} bytes)");
    Ok(())
}

/// Returns true if any entry in `dir_inode`'s blocks has a name
/// matching `name`.
fn dir_has_name(fs: &mut Fs, dir_inode: &anvil_core::inode::Inode, name: &[u8])
    -> std::io::Result<bool>
{
    let mut blocks: Vec<u64> = Vec::new();
    extent::walk_extents(fs, dir_inode, |r| {
        for off in 0..r.length as u64 { blocks.push(r.physical + off); }
    })?;
    let bs = fs.block_size as usize;
    for blk in blocks {
        let mut buf = vec![0u8; bs];
        fs.read_block(blk, &mut buf)?;
        let mut off = 0usize;
        while off + 8 <= bs {
            let inode = u32::from_le_bytes([buf[off], buf[off+1], buf[off+2], buf[off+3]]);
            let rec_len = u16::from_le_bytes([buf[off+4], buf[off+5]]) as usize;
            let name_len = buf[off+6] as usize;
            if rec_len < 8 || off + rec_len > bs { break; }
            if inode != 0 && name_len > 0 && off + 8 + name_len <= bs {
                if &buf[off+8..off+8+name_len] == name { return Ok(true); }
            }
            off += rec_len;
        }
    }
    Ok(false)
}

/// Find an existing entry in the parent's dir block whose padding
/// can be split to make room for a new entry with `name_bytes`.
/// Rewrites the block and (if metadata_csum is on) re-stamps the
/// tail csum. Also bumps the parent's mtime/ctime + re-stamps its
/// inode csum.
///
/// Assumes the directory fits in a single data block — which is
/// the only shape `ls /` reliably walks today.
fn add_parent_dir_entry(
    fs: &mut Fs,
    parent_ino_num: u32,
    parent_inode: &anvil_core::inode::Inode,
    new_ino: u32,
    name_bytes: &[u8],
    file_type: u8,
) -> std::io::Result<()> {
    use anvil_core::dir::align4;
    let want = 8 + align4(name_bytes.len());
    let bs = fs.block_size as usize;

    // Collect dir blocks. We only support a linear single-block
    // dir for now — matches what mkfs emits and what the upstream
    // debugfs write command relies on.
    let mut blocks: Vec<u64> = Vec::new();
    extent::walk_extents(fs, parent_inode, |r| {
        for off in 0..r.length as u64 { blocks.push(r.physical + off); }
    })?;
    if blocks.is_empty() {
        return Err(std::io::Error::new(
            std::io::ErrorKind::InvalidData,
            format!("parent inode {parent_ino_num} has no data blocks"),
        ));
    }

    let want_csum = fs.has_metadata_csum();
    // With metadata_csum the 12-byte tail marker occupies the end
    // of the block and must stay there.
    let block_end = if want_csum { bs - 12 } else { bs };

    // Scan each block for a splittable entry; first fit wins.
    let mut chosen_block: Option<u64> = None;
    let mut chosen_split_off: usize = 0;
    let mut chosen_shrunk_rec_len: usize = 0;
    let mut chosen_new_rec_len: usize = 0;
    let mut buf = vec![0u8; bs];
    for &blk in &blocks {
        fs.read_block(blk, &mut buf)?;
        let mut off = 0usize;
        while off + 8 <= block_end {
            let inode = u32::from_le_bytes([buf[off], buf[off+1], buf[off+2], buf[off+3]]);
            let rec_len = u16::from_le_bytes([buf[off+4], buf[off+5]]) as usize;
            let name_len = buf[off+6] as usize;
            if rec_len < 8 || off + rec_len > block_end { break; }
            let min_here = if inode == 0 { 8 } else { 8 + align4(name_len) };
            let slack = rec_len.saturating_sub(min_here);
            if slack >= want {
                // Found. Shrink this entry to min_here, new entry
                // consumes the rest of rec_len.
                chosen_block = Some(blk);
                chosen_split_off = off;
                chosen_shrunk_rec_len = min_here;
                chosen_new_rec_len = rec_len - min_here;
                break;
            }
            off += rec_len;
        }
        if chosen_block.is_some() { break; }
    }
    let blk = chosen_block.ok_or_else(|| std::io::Error::new(
        std::io::ErrorKind::Other,
        "parent directory has no free slot for new entry",
    ))?;

    // Rewrite the chosen block. We reload it so we know we hold a
    // matching buffer; `buf` already holds it from the last scan
    // iteration but re-reading avoids assumptions about loop state.
    fs.read_block(blk, &mut buf)?;
    // Shrink the existing entry.
    buf[chosen_split_off+4..chosen_split_off+6]
        .copy_from_slice(&(chosen_shrunk_rec_len as u16).to_le_bytes());
    // Write the new entry.
    let new_off = chosen_split_off + chosen_shrunk_rec_len;
    buf[new_off..new_off+4].copy_from_slice(&new_ino.to_le_bytes());
    buf[new_off+4..new_off+6].copy_from_slice(&(chosen_new_rec_len as u16).to_le_bytes());
    buf[new_off+6] = name_bytes.len() as u8;
    buf[new_off+7] = file_type;
    buf[new_off+8..new_off+8+name_bytes.len()].copy_from_slice(name_bytes);
    // Zero the padding between name end and chosen_new_rec_len.
    for b in &mut buf[new_off+8+name_bytes.len() .. new_off+chosen_new_rec_len] {
        *b = 0;
    }

    // Stamp the tail csum if enabled.
    if want_csum {
        // Write the tail-entry header (inode=0, rec_len=12,
        // name_len=0, file_type=0xDE). The last valid entry's
        // rec_len already leaves exactly 12 bytes for the tail
        // (we preserved block_end = bs - 12 in the scan). Just
        // re-write the marker bytes and compute the csum.
        let tail_off = bs - 12;
        buf[tail_off..tail_off+8].copy_from_slice(&[0, 0, 0, 0, 0x0C, 0, 0, 0xDE]);
        for b in &mut buf[tail_off+8..tail_off+12] { *b = 0; }
        let generation = parent_inode.i_generation;
        let seed = csum_seed_for(&fs.sb);
        let s1 = anvil_core::crc::crc32c_cont(seed, &parent_ino_num.to_le_bytes());
        let s2 = anvil_core::crc::crc32c_cont(s1, &generation.to_le_bytes());
        let csum = anvil_core::crc::crc32c_cont(s2, &buf[..bs - 12]);
        buf[bs-4..bs].copy_from_slice(&csum.to_le_bytes());
    }
    fs.dev.write_at(blk * fs.block_size, &buf)?;

    // Bump parent mtime/ctime + re-stamp its inode csum. Read the
    // raw inode slot so we preserve any trailing xattr area.
    let now = now_u32();
    let pgroup = (parent_ino_num as u64 - 1) / fs.inodes_per_group;
    let pidx   = (parent_ino_num as u64 - 1) % fs.inodes_per_group;
    let ptable = fs.group_inode_table(pgroup);
    let pbyte  = ptable * fs.block_size + pidx * fs.inode_size;
    let mut pbuf = vec![0u8; fs.inode_size as usize];
    fs.dev.read_at(pbyte, &mut pbuf)?;
    pbuf[0x0C..0x10].copy_from_slice(&now.to_le_bytes()); // ctime
    pbuf[0x10..0x14].copy_from_slice(&now.to_le_bytes()); // mtime
    if fs.has_metadata_csum() {
        let pgen = u32::from_le_bytes(pbuf[0x64..0x68].try_into().unwrap());
        let extra_isize = if fs.inode_size >= 256 {
            u16::from_le_bytes(pbuf[0x80..0x82].try_into().unwrap())
        } else { 0 };
        let use_hi = fs.inode_size >= 256 && extra_isize > 2;
        pbuf[0x7C..0x7E].copy_from_slice(&0u16.to_le_bytes());
        if use_hi { pbuf[0x82..0x84].copy_from_slice(&0u16.to_le_bytes()); }
        let csum = compute_inode_csum(&fs.sb, parent_ino_num, pgen, &pbuf);
        pbuf[0x7C..0x7E].copy_from_slice(&(csum as u16).to_le_bytes());
        if use_hi {
            pbuf[0x82..0x84].copy_from_slice(&((csum >> 16) as u16).to_le_bytes());
        }
    }
    fs.dev.write_at(pbyte, &pbuf)?;
    Ok(())
}

fn now_u32() -> u32 {
    use std::time::{SystemTime, UNIX_EPOCH};
    SystemTime::now().duration_since(UNIX_EPOCH).map(|d| d.as_secs() as u32).unwrap_or(0)
}

/// Create a new directory at absolute `path`. Parent must exist
/// and be a directory; the final component must not already exist.
///
/// Allocates one fresh inode (first free slot past reserved range)
/// and one data block (first free block in group 0). The new dir
/// inode gets S_IFDIR | 0o755, links=2 (self via "." + "..-from-
/// self"), a single EXTENTS_FL extent pointing at the block, and
/// size = block_size. The data block is populated with "." (self)
/// and ".." (parent). The parent's link count is incremented by
/// one (new dir's ".." ref-counts against parent), an entry is
/// appended in the parent pointing at the new inode with
/// EXT4_FT_DIR, and the inode/block bitmaps + GDT + SB counters
/// are updated in lockstep. When metadata_csum is on, every
/// freshly-written region (new inode, parent inode, new dir block
/// tail, parent dir block tail, bitmap csums, GDT csum, SB csum)
/// is re-stamped.
fn cmd_mkdir(fs: &mut Fs, path: &str) -> std::io::Result<()> {
    if !path.starts_with('/') {
        return Err(std::io::Error::new(
            std::io::ErrorKind::InvalidInput,
            format!("path '{path}' must be absolute (start with '/')"),
        ));
    }
    let trimmed = path.trim_end_matches('/');
    let (parent_path, basename) = match trimmed.rsplit_once('/') {
        Some((p, b)) => (if p.is_empty() { "/" } else { p }, b),
        None => return Err(std::io::Error::new(
            std::io::ErrorKind::InvalidInput,
            format!("path '{path}' has no basename"),
        )),
    };
    if basename.is_empty() {
        return Err(std::io::Error::new(
            std::io::ErrorKind::InvalidInput,
            format!("path '{path}' has empty basename"),
        ));
    }
    let name_bytes = basename.as_bytes();
    if name_bytes.len() > 255 || name_bytes.contains(&0)
        || name_bytes == b"." || name_bytes == b".."
    {
        return Err(std::io::Error::new(
            std::io::ErrorKind::InvalidInput,
            format!("basename '{basename}' is not a valid directory name"),
        ));
    }

    // --- Resolve parent dir inode.
    let parent_ino_num = resolve_path(fs, parent_path).map_err(|e| {
        std::io::Error::new(e.kind(), format!("parent '{parent_path}': {e}"))
    })?;
    let parent_inode = fs.read_inode(parent_ino_num)?;
    if parent_inode.i_mode & S_IFMT != S_IFDIR {
        return Err(std::io::Error::new(
            std::io::ErrorKind::InvalidInput,
            format!("parent '{parent_path}' is not a directory"),
        ));
    }

    // --- Refuse if name already exists.
    if dir_has_name(fs, &parent_inode, name_bytes)? {
        return Err(std::io::Error::new(
            std::io::ErrorKind::AlreadyExists,
            format!("{path}: already exists"),
        ));
    }

    let bs = fs.block_size;

    // --- Allocate a free inode slot past the reserved range in group 0.
    let first_ino = fs.sb.s_first_ino.max(EXT4_FIRST_NON_RSV_INO);
    let ipg = fs.inodes_per_group as usize;
    let ib_block = fs.group_inode_bitmap(0);
    let mut ib_buf = vec![0u8; bs as usize];
    fs.read_block(ib_block, &mut ib_buf)?;
    let start_bit = first_ino as usize;
    let mut new_ino_num: Option<u32> = None;
    for bit in start_bit..ipg {
        if !anvil_core::bitmap::test_bit(&ib_buf, bit) {
            new_ino_num = Some((bit + 1) as u32);
            break;
        }
    }
    let new_ino_num = new_ino_num.ok_or_else(|| std::io::Error::new(
        std::io::ErrorKind::Other,
        "no free inode slot in group 0",
    ))?;

    // --- Allocate a single free data block in group 0.
    let bb_block = fs.group_block_bitmap(0);
    let mut bb_buf = vec![0u8; bs as usize];
    fs.read_block(bb_block, &mut bb_buf)?;
    let bpg = fs.blocks_per_group as usize;
    let first_data_block = fs.sb.s_first_data_block as u64;
    let mut alloc_rel: Option<usize> = None;
    for bit in 0..bpg {
        if !anvil_core::bitmap::test_bit(&bb_buf, bit) {
            alloc_rel = Some(bit);
            break;
        }
    }
    let alloc_rel = alloc_rel.ok_or_else(|| std::io::Error::new(
        std::io::ErrorKind::Other,
        "no free block in group 0",
    ))?;
    let dir_block = first_data_block + alloc_rel as u64;

    // --- Build the data block: "." (self) + ".." (parent).
    //     When metadata_csum is on, the tail slot is reserved —
    //     the last entry's rec_len stops at (bs - 12).
    let want_csum = fs.has_metadata_csum();
    let block_end = if want_csum { bs as usize - 12 } else { bs as usize };
    let mut dbuf: Vec<u8> = Vec::with_capacity(bs as usize);
    anvil_core::dir::append_dir_entry(
        &mut dbuf, new_ino_num, EXT4_FT_DIR, b".", false, block_end,
    );
    anvil_core::dir::append_dir_entry(
        &mut dbuf, parent_ino_num, EXT4_FT_DIR, b"..", true, block_end,
    );
    // Pad to block_end, then (if csum on) write the 12-byte tail
    // marker at [bs-12 .. bs].
    dbuf.resize(bs as usize, 0);
    if want_csum {
        let tail_off = bs as usize - 12;
        dbuf[tail_off..tail_off+8].copy_from_slice(&[0, 0, 0, 0, 0x0C, 0, 0, 0xDE]);
        // det_checksum placeholder; set after we compute the csum.
        for b in &mut dbuf[tail_off+8..tail_off+12] { *b = 0; }
    }

    // --- Build the new dir inode.
    let now = now_u32();
    let inode_size = fs.inode_size as usize;
    let mut ibuf = vec![0u8; inode_size];
    let mode: u16 = S_IFDIR | 0o755;
    ibuf[0x00..0x02].copy_from_slice(&mode.to_le_bytes());
    // i_size = block_size (one data block).
    let size: u64 = bs;
    ibuf[0x04..0x08].copy_from_slice(&((size & 0xFFFF_FFFF) as u32).to_le_bytes());
    ibuf[0x6C..0x70].copy_from_slice(&((size >> 32) as u32).to_le_bytes());
    ibuf[0x08..0x0C].copy_from_slice(&now.to_le_bytes()); // atime
    ibuf[0x0C..0x10].copy_from_slice(&now.to_le_bytes()); // ctime
    ibuf[0x10..0x14].copy_from_slice(&now.to_le_bytes()); // mtime
    // links_count = 2 (self via "." and ".." from self).
    ibuf[0x1A..0x1C].copy_from_slice(&2u16.to_le_bytes());
    // i_blocks_lo in 512-byte sectors.
    let i_blocks_lo: u32 = (bs / 512) as u32;
    ibuf[0x1C..0x20].copy_from_slice(&i_blocks_lo.to_le_bytes());
    // i_flags = EXT4_EXTENTS_FL.
    ibuf[0x20..0x24].copy_from_slice(&EXT4_EXTENTS_FL.to_le_bytes());
    // Extent tree in i_block: header + one extent pointing at dir_block.
    let iblock_off = 0x28usize;
    ibuf[iblock_off..iblock_off+2].copy_from_slice(&EXT4_EXT_MAGIC.to_le_bytes());
    ibuf[iblock_off+2..iblock_off+4].copy_from_slice(&1u16.to_le_bytes()); // eh_entries
    ibuf[iblock_off+4..iblock_off+6].copy_from_slice(&4u16.to_le_bytes()); // eh_max
    // eh_depth, eh_generation already zero.
    let e_off = iblock_off + 12;
    ibuf[e_off..e_off+4].copy_from_slice(&0u32.to_le_bytes()); // ee_block
    ibuf[e_off+4..e_off+6].copy_from_slice(&1u16.to_le_bytes()); // ee_len = 1
    ibuf[e_off+6..e_off+8].copy_from_slice(&((dir_block >> 32) as u16).to_le_bytes());
    ibuf[e_off+8..e_off+12].copy_from_slice(&(dir_block as u32).to_le_bytes());
    if inode_size >= 256 {
        let extra_isize: u16 = 32;
        ibuf[0x80..0x82].copy_from_slice(&extra_isize.to_le_bytes());
        ibuf[0x90..0x94].copy_from_slice(&now.to_le_bytes()); // i_crtime
    }

    // Stamp the inode's metadata_csum.
    if want_csum {
        let generation: u32 = 0;
        let extra_isize = if inode_size >= 256 {
            u16::from_le_bytes(ibuf[0x80..0x82].try_into().unwrap())
        } else { 0 };
        let use_hi = inode_size >= 256 && extra_isize > 2;
        let csum = compute_inode_csum(&fs.sb, new_ino_num, generation, &ibuf);
        ibuf[0x7C..0x7E].copy_from_slice(&(csum as u16).to_le_bytes());
        if use_hi {
            ibuf[0x82..0x84].copy_from_slice(&((csum >> 16) as u16).to_le_bytes());
        }
    }

    // --- Stamp the new dir block's tail csum (now that the new
    //     inode number + generation are fixed).
    if want_csum {
        let seed = csum_seed_for(&fs.sb);
        let s1 = anvil_core::crc::crc32c_cont(seed, &new_ino_num.to_le_bytes());
        let s2 = anvil_core::crc::crc32c_cont(s1, &0u32.to_le_bytes()); // generation
        let csum = anvil_core::crc::crc32c_cont(s2, &dbuf[..bs as usize - 12]);
        let n = bs as usize;
        dbuf[n-4..n].copy_from_slice(&csum.to_le_bytes());
    }

    // --- Commit to disk. From here on, failures leave a partially
    //     written image; ordering matches cmd_write.
    // 1. Write the dir data block.
    fs.dev.write_at(dir_block * bs, &dbuf)?;

    // 2. Write the new inode slot.
    let idx = (new_ino_num as u64 - 1) % fs.inodes_per_group;
    let table = fs.group_inode_table(0);
    let ino_byte = table * bs + idx * fs.inode_size;
    fs.dev.write_at(ino_byte, &ibuf)?;

    // 3. Insert the dir entry into the parent directory.
    add_parent_dir_entry(
        fs, parent_ino_num, &parent_inode,
        new_ino_num, name_bytes, EXT4_FT_DIR,
    )?;

    // 4. Bump the parent's i_links_count by 1 (new dir's ".."
    //    points back at parent). Re-stamps parent inode csum.
    patch_inode_slot(fs, parent_ino_num, |buf| {
        let cur = u16::from_le_bytes(buf[0x1A..0x1C].try_into().unwrap());
        buf[0x1A..0x1C].copy_from_slice(&cur.saturating_add(1).to_le_bytes());
        Ok(())
    })?;

    // 5. Update the inode bitmap.
    anvil_core::bitmap::set_bit(&mut ib_buf, (new_ino_num - 1) as usize);
    fs.dev.write_at(ib_block * bs, &ib_buf)?;

    // 6. Update the block bitmap.
    anvil_core::bitmap::set_bit(&mut bb_buf, alloc_rel);
    fs.dev.write_at(bb_block * bs, &bb_buf)?;

    // 7. Update group 0 descriptor counters.
    {
        let gd = &mut fs.gdt[0];
        let cur_fb = (gd.bg_free_blocks_count_lo as u32)
            | ((gd.bg_free_blocks_count_hi as u32) << 16);
        let cur_fi = (gd.bg_free_inodes_count_lo as u32)
            | ((gd.bg_free_inodes_count_hi as u32) << 16);
        let cur_ud = (gd.bg_used_dirs_count_lo as u32)
            | ((gd.bg_used_dirs_count_hi as u32) << 16);
        gd.set_free_blocks(cur_fb.saturating_sub(1));
        gd.set_free_inodes(cur_fi.saturating_sub(1));
        gd.set_used_dirs(cur_ud.saturating_add(1));
    }
    if want_csum {
        let bbc = compute_bitmap_csum(&fs.sb, &bb_buf);
        fs.gdt[0].bg_block_bitmap_csum_lo = bbc as u16;
        if fs.desc_size as usize >= 0x3A {
            fs.gdt[0].bg_block_bitmap_csum_hi = (bbc >> 16) as u16;
        }
        let ipg_bytes = ((fs.inodes_per_group as usize + 7) / 8).min(ib_buf.len());
        let ibc = compute_bitmap_csum(&fs.sb, &ib_buf[..ipg_bytes]);
        fs.gdt[0].bg_inode_bitmap_csum_lo = ibc as u16;
        if fs.desc_size as usize >= 0x3A {
            fs.gdt[0].bg_inode_bitmap_csum_hi = (ibc >> 16) as u16;
        }
    }

    // 8. Re-stamp every GDT descriptor's bg_checksum (same blanket
    //    approach cmd_write uses).
    if want_csum {
        for gi in 0..fs.groups_count {
            let desc_bytes = fs.gdt[gi as usize].to_bytes(fs.desc_size as usize);
            let csum = compute_gdt_csum(&fs.sb, gi as u32, &desc_bytes);
            fs.gdt[gi as usize].bg_checksum = csum as u16;
        }
    }

    // 9. Update SB free counters.
    {
        let fb = fs.sb.free_blocks();
        fs.sb.set_free_blocks(fb.saturating_sub(1));
        fs.sb.s_free_inodes_count = fs.sb.s_free_inodes_count.saturating_sub(1);
    }
    if want_csum {
        fs.sb.s_checksum = 0;
        let sb_bytes = fs.sb.to_bytes();
        let new_sb_csum = anvil_core::crc::crc32c_cont(0xFFFFFFFF, &sb_bytes[..0x3FC]);
        fs.sb.s_checksum = new_sb_csum;
    }

    // 10. Flush SB + GDT.
    fs.write_superblock()?;
    fs.write_gdt()?;

    eprintln!("mkdir: created {path} (inode {new_ino_num})");
    Ok(())
}

/// Remove a regular file at `path`. Symmetric with `cmd_write`:
/// unlinks the dir entry from the parent directory, decrements
/// i_links_count, and when that drops to zero frees the file's
/// data blocks + inode, zeroes the inode slot, and updates the
/// block/inode bitmaps + GDT + SB free counters.
///
/// Directories are rejected — a separate `rmdir` would need to
/// walk `.` / `..` and update the parent's subdir count.
fn cmd_rm(fs: &mut Fs, path: &str) -> std::io::Result<()> {
    if !path.starts_with('/') {
        return Err(std::io::Error::new(
            std::io::ErrorKind::InvalidInput,
            format!("path '{path}' must be absolute (start with '/')"),
        ));
    }
    let trimmed = path.trim_end_matches('/');
    let (parent_path, basename) = match trimmed.rsplit_once('/') {
        Some((p, b)) => (if p.is_empty() { "/" } else { p }, b),
        None => return Err(std::io::Error::new(
            std::io::ErrorKind::InvalidInput,
            format!("path '{path}' has no basename"),
        )),
    };
    if basename.is_empty() {
        return Err(std::io::Error::new(
            std::io::ErrorKind::InvalidInput,
            format!("path '{path}' has empty basename"),
        ));
    }
    let name_bytes = basename.as_bytes();

    // Resolve the target. `resolve_path` errors cleanly on missing
    // intermediate components or missing target; reuse it for the
    // existence check.
    let target_ino_num = resolve_path(fs, path).map_err(|e| {
        std::io::Error::new(e.kind(), format!("{path}: {e}"))
    })?;
    let target_inode = fs.read_inode(target_ino_num)?;
    if target_inode.i_mode & S_IFMT != S_IFREG {
        return Err(std::io::Error::new(
            std::io::ErrorKind::InvalidInput,
            format!("{path}: not a regular file (rm only unlinks regular files)"),
        ));
    }

    // Resolve the parent so we can rewrite its dir block.
    let parent_ino_num = resolve_path(fs, parent_path).map_err(|e| {
        std::io::Error::new(e.kind(), format!("parent '{parent_path}': {e}"))
    })?;
    let parent_inode = fs.read_inode(parent_ino_num)?;
    if parent_inode.i_mode & S_IFMT != S_IFDIR {
        return Err(std::io::Error::new(
            std::io::ErrorKind::InvalidInput,
            format!("parent '{parent_path}' is not a directory"),
        ));
    }

    // 1. Remove the dir entry from the parent and bump parent times.
    remove_parent_dir_entry(fs, parent_ino_num, &parent_inode, name_bytes)?;

    // 2. Decrement link count. If still > 0, just write inode back.
    //    debugfs-style `rm` is expected to fully unlink when links
    //    drop to zero; for >1 we just rewrite the link count.
    let new_links = target_inode.i_links_count.saturating_sub(1);
    let bs = fs.block_size;
    let tgroup = (target_ino_num as u64 - 1) / fs.inodes_per_group;
    let tidx   = (target_ino_num as u64 - 1) % fs.inodes_per_group;
    let ttable = fs.group_inode_table(tgroup);
    let tbyte  = ttable * bs + tidx * fs.inode_size;

    if new_links > 0 {
        // Partial unlink: rewrite i_links_count + ctime + csum.
        let mut tbuf = vec![0u8; fs.inode_size as usize];
        fs.dev.read_at(tbyte, &mut tbuf)?;
        tbuf[0x1A..0x1C].copy_from_slice(&new_links.to_le_bytes());
        let now = now_u32();
        tbuf[0x0C..0x10].copy_from_slice(&now.to_le_bytes());
        if fs.has_metadata_csum() {
            let gen = u32::from_le_bytes(tbuf[0x64..0x68].try_into().unwrap());
            let extra_isize = if fs.inode_size >= 256 {
                u16::from_le_bytes(tbuf[0x80..0x82].try_into().unwrap())
            } else { 0 };
            let use_hi = fs.inode_size >= 256 && extra_isize > 2;
            tbuf[0x7C..0x7E].copy_from_slice(&0u16.to_le_bytes());
            if use_hi { tbuf[0x82..0x84].copy_from_slice(&0u16.to_le_bytes()); }
            let csum = compute_inode_csum(&fs.sb, target_ino_num, gen, &tbuf);
            tbuf[0x7C..0x7E].copy_from_slice(&(csum as u16).to_le_bytes());
            if use_hi {
                tbuf[0x82..0x84].copy_from_slice(&((csum >> 16) as u16).to_le_bytes());
            }
        }
        fs.dev.write_at(tbyte, &tbuf)?;
        println!("rm: removed {path} (freed 0 blocks, 0 inodes)");
        return Ok(());
    }

    // 3. Full unlink path. Collect the file's extents so we know
    //    which physical blocks to free.
    let mut runs: Vec<(u64, u64)> = Vec::new(); // (physical, length)
    extent::walk_extents(fs, &target_inode, |r| {
        runs.push((r.physical, r.length as u64));
    })?;
    let total_blocks_freed: u64 = runs.iter().map(|(_, l)| *l).sum();

    // 4. Free each block run in its group's block bitmap. Runs can
    //    straddle groups on bigger filesystems; split per-group so
    //    the GDT + bitmap updates stay consistent. We batch updates
    //    per group so we only read/write each bitmap once.
    let bpg = fs.blocks_per_group;
    let first_data_block = fs.sb.s_first_data_block as u64;
    // Map group -> list of (rel_bit, count).
    use std::collections::BTreeMap;
    let mut per_group: BTreeMap<u64, Vec<(usize, usize)>> = BTreeMap::new();
    for (phys, len) in &runs {
        let mut remaining = *len;
        let mut cur = *phys;
        while remaining > 0 {
            // group that owns `cur`. For ext4 with s_first_data_block==0
            // the group of block b is b / bpg.
            let group = (cur.saturating_sub(first_data_block)) / bpg;
            let group_first = first_data_block + group * bpg;
            let group_last = group_first + bpg - 1;
            let run_end_in_group = (cur + remaining - 1).min(group_last);
            let count = (run_end_in_group - cur + 1) as usize;
            let rel = (cur - group_first) as usize;
            per_group.entry(group).or_default().push((rel, count));
            cur += count as u64;
            remaining -= count as u64;
        }
    }
    for (group, spans) in &per_group {
        let bb_block = fs.group_block_bitmap(*group);
        let mut bb_buf = vec![0u8; bs as usize];
        fs.read_block(bb_block, &mut bb_buf)?;
        for (rel, count) in spans {
            for i in 0..*count {
                anvil_core::bitmap::clear_bit(&mut bb_buf, rel + i);
            }
        }
        fs.dev.write_at(bb_block * bs, &bb_buf)?;
        // GDT: bump free_blocks for this group.
        let freed_in_group: u64 = spans.iter().map(|(_, c)| *c as u64).sum();
        {
            let gd = &mut fs.gdt[*group as usize];
            let cur_fb = (gd.bg_free_blocks_count_lo as u32)
                | ((gd.bg_free_blocks_count_hi as u32) << 16);
            gd.set_free_blocks(cur_fb.saturating_add(freed_in_group as u32));
        }
        if fs.has_metadata_csum() {
            let bbc = compute_bitmap_csum(&fs.sb, &bb_buf);
            fs.gdt[*group as usize].bg_block_bitmap_csum_lo = bbc as u16;
            if fs.desc_size as usize >= 0x3A {
                fs.gdt[*group as usize].bg_block_bitmap_csum_hi = (bbc >> 16) as u16;
            }
        }
    }

    // 5. Clear the inode's bit in its group's inode bitmap + update
    //    the group's free_inodes count + bitmap csum.
    let ib_block = fs.group_inode_bitmap(tgroup);
    let mut ib_buf = vec![0u8; bs as usize];
    fs.read_block(ib_block, &mut ib_buf)?;
    anvil_core::bitmap::clear_bit(&mut ib_buf, (target_ino_num - 1) as usize % fs.inodes_per_group as usize);
    fs.dev.write_at(ib_block * bs, &ib_buf)?;
    {
        let gd = &mut fs.gdt[tgroup as usize];
        let cur_fi = (gd.bg_free_inodes_count_lo as u32)
            | ((gd.bg_free_inodes_count_hi as u32) << 16);
        gd.set_free_inodes(cur_fi.saturating_add(1));
    }
    if fs.has_metadata_csum() {
        let ipg_bytes = ((fs.inodes_per_group as usize + 7) / 8).min(ib_buf.len());
        let ibc = compute_bitmap_csum(&fs.sb, &ib_buf[..ipg_bytes]);
        fs.gdt[tgroup as usize].bg_inode_bitmap_csum_lo = ibc as u16;
        if fs.desc_size as usize >= 0x3A {
            fs.gdt[tgroup as usize].bg_inode_bitmap_csum_hi = (ibc >> 16) as u16;
        }
    }

    // 6. Zero the inode slot. Leave dtime = now so e2fsck recognises
    //    it as a formally-deleted inode.
    let now = now_u32();
    let mut zero_ibuf = vec![0u8; fs.inode_size as usize];
    zero_ibuf[0x14..0x18].copy_from_slice(&now.to_le_bytes()); // i_dtime
    if fs.has_metadata_csum() {
        // Compute checksum over zeroed buffer (with dtime stamped,
        // csum slots zero).
        let csum = compute_inode_csum(&fs.sb, target_ino_num, 0, &zero_ibuf);
        zero_ibuf[0x7C..0x7E].copy_from_slice(&(csum as u16).to_le_bytes());
        if fs.inode_size >= 256 {
            // extra_isize is zero in the zeroed slot so the hi half
            // isn't part of the stored csum — leave as zero.
        }
    }
    fs.dev.write_at(tbyte, &zero_ibuf)?;

    // 7. Re-stamp every GDT descriptor checksum. Same rationale as
    //    cmd_write: only touched groups strictly need it, but
    //    touching all keeps the invariant simple.
    if fs.has_metadata_csum() {
        for gi in 0..fs.groups_count {
            let desc_bytes = fs.gdt[gi as usize].to_bytes(fs.desc_size as usize);
            let csum = compute_gdt_csum(&fs.sb, gi as u32, &desc_bytes);
            fs.gdt[gi as usize].bg_checksum = csum as u16;
        }
    }

    // 8. Update SB free counters.
    {
        let fb = fs.sb.free_blocks();
        fs.sb.set_free_blocks(fb.saturating_add(total_blocks_freed));
        fs.sb.s_free_inodes_count = fs.sb.s_free_inodes_count.saturating_add(1);
    }
    if fs.has_metadata_csum() {
        fs.sb.s_checksum = 0;
        let sb_bytes = fs.sb.to_bytes();
        let new_sb_csum = anvil_core::crc::crc32c_cont(0xFFFFFFFF, &sb_bytes[..0x3FC]);
        fs.sb.s_checksum = new_sb_csum;
    }

    fs.write_superblock()?;
    fs.write_gdt()?;

    println!("rm: removed {path} (freed {total_blocks_freed} blocks, 1 inode)");
    Ok(())
}


/// Create a hardlink at absolute `dst` pointing at `src`'s inode.
///
/// `src` must exist and be a regular file (no hardlinks to
/// directories). `dst`'s parent must exist and be a directory; the
/// final component must not already exist. Appends a dir entry in
/// the parent of `dst` (same rec_len split as `cmd_write`), bumps
/// the source inode's `i_links_count`, and re-stamps csums.
fn cmd_ln(fs: &mut Fs, src: &str, dst: &str) -> std::io::Result<()> {
    if !src.starts_with('/') {
        return Err(std::io::Error::new(
            std::io::ErrorKind::InvalidInput,
            format!("src '{src}' must be absolute (start with '/')"),
        ));
    }
    if !dst.starts_with('/') {
        return Err(std::io::Error::new(
            std::io::ErrorKind::InvalidInput,
            format!("dst '{dst}' must be absolute (start with '/')"),
        ));
    }

    // --- Resolve src; must exist and be a regular file.
    let src_ino_num = resolve_path(fs, src).map_err(|e| {
        std::io::Error::new(e.kind(), format!("src '{src}': {e}"))
    })?;
    let src_inode = fs.read_inode(src_ino_num)?;
    let src_kind = src_inode.i_mode & S_IFMT;
    if src_kind == S_IFDIR {
        return Err(std::io::Error::new(
            std::io::ErrorKind::InvalidInput,
            format!("src '{src}' is a directory (cannot hardlink directories)"),
        ));
    }
    if src_kind != S_IFREG {
        return Err(std::io::Error::new(
            std::io::ErrorKind::InvalidInput,
            format!("src '{src}' is not a regular file"),
        ));
    }

    // --- Split dst into (parent_path, basename).
    let trimmed = dst.trim_end_matches('/');
    let (parent_path, basename) = match trimmed.rsplit_once('/') {
        Some((p, b)) => (if p.is_empty() { "/" } else { p }, b),
        None => return Err(std::io::Error::new(
            std::io::ErrorKind::InvalidInput,
            format!("dst '{dst}' has no basename"),
        )),
    };
    if basename.is_empty() {
        return Err(std::io::Error::new(
            std::io::ErrorKind::InvalidInput,
            format!("dst '{dst}' has empty basename"),
        ));
    }
    let name_bytes = basename.as_bytes();
    if name_bytes.len() > 255 || name_bytes.contains(&0) {
        return Err(std::io::Error::new(
            std::io::ErrorKind::InvalidInput,
            format!("dst basename '{basename}' is not a valid filename"),
        ));
    }

    // --- Resolve dst parent dir inode.
    let parent_ino_num = resolve_path(fs, parent_path).map_err(|e| {
        std::io::Error::new(e.kind(), format!("parent '{parent_path}': {e}"))
    })?;
    let parent_inode = fs.read_inode(parent_ino_num)?;
    if parent_inode.i_mode & S_IFMT != S_IFDIR {
        return Err(std::io::Error::new(
            std::io::ErrorKind::InvalidInput,
            format!("parent '{parent_path}' is not a directory"),
        ));
    }

    // --- Refuse if dst already exists.
    if dir_has_name(fs, &parent_inode, name_bytes)? {
        return Err(std::io::Error::new(
            std::io::ErrorKind::AlreadyExists,
            format!("{dst}: file already exists"),
        ));
    }

    // 1. Append the new dir entry pointing at src's inode.
    add_parent_dir_entry(
        fs, parent_ino_num, &parent_inode,
        src_ino_num, name_bytes, EXT4_FT_REG_FILE,
    )?;

    // 2. Bump src's i_links_count + ctime; re-stamp its inode csum.
    //    Read the raw inode slot so we preserve trailing xattr area.
    let bs = fs.block_size;
    let sgroup = (src_ino_num as u64 - 1) / fs.inodes_per_group;
    let sidx   = (src_ino_num as u64 - 1) % fs.inodes_per_group;
    let stable = fs.group_inode_table(sgroup);
    let sbyte  = stable * bs + sidx * fs.inode_size;
    let mut sbuf = vec![0u8; fs.inode_size as usize];
    fs.dev.read_at(sbyte, &mut sbuf)?;
    let cur_links = u16::from_le_bytes(sbuf[0x1A..0x1C].try_into().unwrap());
    let new_links = cur_links.saturating_add(1);
    sbuf[0x1A..0x1C].copy_from_slice(&new_links.to_le_bytes());
    let now = now_u32();
    sbuf[0x0C..0x10].copy_from_slice(&now.to_le_bytes()); // ctime
    if fs.has_metadata_csum() {
        let gen = u32::from_le_bytes(sbuf[0x64..0x68].try_into().unwrap());
        let extra_isize = if fs.inode_size >= 256 {
            u16::from_le_bytes(sbuf[0x80..0x82].try_into().unwrap())
        } else { 0 };
        let use_hi = fs.inode_size >= 256 && extra_isize > 2;
        sbuf[0x7C..0x7E].copy_from_slice(&0u16.to_le_bytes());
        if use_hi { sbuf[0x82..0x84].copy_from_slice(&0u16.to_le_bytes()); }
        let csum = compute_inode_csum(&fs.sb, src_ino_num, gen, &sbuf);
        sbuf[0x7C..0x7E].copy_from_slice(&(csum as u16).to_le_bytes());
        if use_hi {
            sbuf[0x82..0x84].copy_from_slice(&((csum >> 16) as u16).to_le_bytes());
        }
    }
    fs.dev.write_at(sbyte, &sbuf)?;

    println!("ln: {src} -> {dst} (inode {src_ino_num}, links={new_links})");
    Ok(())
}

/// Remove an empty directory at `path`. Symmetric with `cmd_mkdir`:
/// refuses non-empty dirs, the root, and `/lost+found`; unlinks the
/// parent's entry, frees the dir's data blocks, clears the inode,
/// decrements `bg_used_dirs`, and re-stamps all metadata csums.
fn cmd_rmdir(fs: &mut Fs, path: &str) -> std::io::Result<()> {
    if !path.starts_with('/') {
        return Err(std::io::Error::new(
            std::io::ErrorKind::InvalidInput,
            format!("path '{path}' must be absolute (start with '/')"),
        ));
    }
    let trimmed = path.trim_end_matches('/');
    if trimmed.is_empty() {
        return Err(std::io::Error::new(
            std::io::ErrorKind::InvalidInput,
            "rmdir: refusing to remove root directory".to_string(),
        ));
    }
    if trimmed == "/lost+found" {
        return Err(std::io::Error::new(
            std::io::ErrorKind::InvalidInput,
            "rmdir: refusing to remove /lost+found".to_string(),
        ));
    }
    let (parent_path, basename) = match trimmed.rsplit_once('/') {
        Some((p, b)) => (if p.is_empty() { "/" } else { p }, b),
        None => return Err(std::io::Error::new(
            std::io::ErrorKind::InvalidInput,
            format!("path '{path}' has no basename"),
        )),
    };
    if basename.is_empty() || basename == "." || basename == ".." {
        return Err(std::io::Error::new(
            std::io::ErrorKind::InvalidInput,
            format!("basename '{basename}' is not a valid directory name"),
        ));
    }
    let name_bytes = basename.as_bytes();

    let target_ino_num = resolve_path(fs, path).map_err(|e| {
        std::io::Error::new(e.kind(), format!("{path}: {e}"))
    })?;
    if target_ino_num == EXT4_ROOT_INO {
        return Err(std::io::Error::new(
            std::io::ErrorKind::InvalidInput,
            "rmdir: refusing to remove root directory".to_string(),
        ));
    }
    let target_inode = fs.read_inode(target_ino_num)?;
    if target_inode.i_mode & S_IFMT != S_IFDIR {
        return Err(std::io::Error::new(
            std::io::ErrorKind::InvalidInput,
            format!("{path}: rmdir only removes directories"),
        ));
    }

    let parent_ino_num = resolve_path(fs, parent_path).map_err(|e| {
        std::io::Error::new(e.kind(), format!("parent '{parent_path}': {e}"))
    })?;
    let parent_inode = fs.read_inode(parent_ino_num)?;
    if parent_inode.i_mode & S_IFMT != S_IFDIR {
        return Err(std::io::Error::new(
            std::io::ErrorKind::InvalidInput,
            format!("parent '{parent_path}' is not a directory"),
        ));
    }

    let bs = fs.block_size;
    let bs_u = bs as usize;
    let want_csum = fs.has_metadata_csum();
    let block_end = if want_csum { bs_u - 12 } else { bs_u };

    let mut dir_runs: Vec<(u64, u64)> = Vec::new();
    extent::walk_extents(fs, &target_inode, |r| {
        dir_runs.push((r.physical, r.length as u64));
    })?;
    let mut dir_blocks: Vec<u64> = Vec::new();
    for (phys, len) in &dir_runs {
        for off in 0..*len { dir_blocks.push(*phys + off); }
    }

    let mut buf = vec![0u8; bs_u];
    for &blk in &dir_blocks {
        fs.read_block(blk, &mut buf)?;
        let mut off = 0usize;
        while off + 8 <= block_end {
            let ino = u32::from_le_bytes([buf[off], buf[off+1], buf[off+2], buf[off+3]]);
            let rec_len = u16::from_le_bytes([buf[off+4], buf[off+5]]) as usize;
            let name_len = buf[off+6] as usize;
            if rec_len < 8 || off + rec_len > block_end { break; }
            if ino != 0 && name_len > 0 && off + 8 + name_len <= block_end {
                let name = &buf[off+8..off+8+name_len];
                if name != b"." && name != b".." {
                    return Err(std::io::Error::new(
                        std::io::ErrorKind::InvalidInput,
                        format!("{path}: directory not empty"),
                    ));
                }
            }
            off += rec_len;
        }
    }

    remove_parent_dir_entry(fs, parent_ino_num, &parent_inode, name_bytes)?;

    patch_inode_slot(fs, parent_ino_num, |buf| {
        let cur = u16::from_le_bytes(buf[0x1A..0x1C].try_into().unwrap());
        buf[0x1A..0x1C].copy_from_slice(&cur.saturating_sub(1).to_le_bytes());
        Ok(())
    })?;

    let bpg = fs.blocks_per_group;
    let first_data_block = fs.sb.s_first_data_block as u64;
    use std::collections::BTreeMap;
    let mut per_group: BTreeMap<u64, Vec<(usize, usize)>> = BTreeMap::new();
    for (phys, len) in &dir_runs {
        let mut remaining = *len;
        let mut cur = *phys;
        while remaining > 0 {
            let group = (cur.saturating_sub(first_data_block)) / bpg;
            let group_first = first_data_block + group * bpg;
            let group_last = group_first + bpg - 1;
            let run_end_in_group = (cur + remaining - 1).min(group_last);
            let count = (run_end_in_group - cur + 1) as usize;
            let rel = (cur - group_first) as usize;
            per_group.entry(group).or_default().push((rel, count));
            cur += count as u64;
            remaining -= count as u64;
        }
    }
    let total_blocks_freed: u64 = dir_runs.iter().map(|(_, l)| *l).sum();
    for (group, spans) in &per_group {
        let bb_block = fs.group_block_bitmap(*group);
        let mut bb_buf = vec![0u8; bs_u];
        fs.read_block(bb_block, &mut bb_buf)?;
        for (rel, count) in spans {
            for i in 0..*count {
                anvil_core::bitmap::clear_bit(&mut bb_buf, rel + i);
            }
        }
        fs.dev.write_at(bb_block * bs, &bb_buf)?;
        let freed_in_group: u64 = spans.iter().map(|(_, c)| *c as u64).sum();
        {
            let gd = &mut fs.gdt[*group as usize];
            let cur_fb = (gd.bg_free_blocks_count_lo as u32)
                | ((gd.bg_free_blocks_count_hi as u32) << 16);
            gd.set_free_blocks(cur_fb.saturating_add(freed_in_group as u32));
        }
        if want_csum {
            let bbc = compute_bitmap_csum(&fs.sb, &bb_buf);
            fs.gdt[*group as usize].bg_block_bitmap_csum_lo = bbc as u16;
            if fs.desc_size as usize >= 0x3A {
                fs.gdt[*group as usize].bg_block_bitmap_csum_hi = (bbc >> 16) as u16;
            }
        }
    }

    let tgroup = (target_ino_num as u64 - 1) / fs.inodes_per_group;
    let ib_block = fs.group_inode_bitmap(tgroup);
    let mut ib_buf = vec![0u8; bs_u];
    fs.read_block(ib_block, &mut ib_buf)?;
    anvil_core::bitmap::clear_bit(
        &mut ib_buf,
        (target_ino_num - 1) as usize % fs.inodes_per_group as usize,
    );
    fs.dev.write_at(ib_block * bs, &ib_buf)?;
    {
        let gd = &mut fs.gdt[tgroup as usize];
        let cur_fi = (gd.bg_free_inodes_count_lo as u32)
            | ((gd.bg_free_inodes_count_hi as u32) << 16);
        gd.set_free_inodes(cur_fi.saturating_add(1));
        let cur_ud = (gd.bg_used_dirs_count_lo as u32)
            | ((gd.bg_used_dirs_count_hi as u32) << 16);
        gd.set_used_dirs(cur_ud.saturating_sub(1));
    }
    if want_csum {
        let ipg_bytes = ((fs.inodes_per_group as usize + 7) / 8).min(ib_buf.len());
        let ibc = compute_bitmap_csum(&fs.sb, &ib_buf[..ipg_bytes]);
        fs.gdt[tgroup as usize].bg_inode_bitmap_csum_lo = ibc as u16;
        if fs.desc_size as usize >= 0x3A {
            fs.gdt[tgroup as usize].bg_inode_bitmap_csum_hi = (ibc >> 16) as u16;
        }
    }

    let now = now_u32();
    let tidx   = (target_ino_num as u64 - 1) % fs.inodes_per_group;
    let ttable = fs.group_inode_table(tgroup);
    let tbyte  = ttable * bs + tidx * fs.inode_size;
    let mut zero_ibuf = vec![0u8; fs.inode_size as usize];
    zero_ibuf[0x14..0x18].copy_from_slice(&now.to_le_bytes());
    if want_csum {
        let csum = compute_inode_csum(&fs.sb, target_ino_num, 0, &zero_ibuf);
        zero_ibuf[0x7C..0x7E].copy_from_slice(&(csum as u16).to_le_bytes());
    }
    fs.dev.write_at(tbyte, &zero_ibuf)?;

    if want_csum {
        for gi in 0..fs.groups_count {
            let desc_bytes = fs.gdt[gi as usize].to_bytes(fs.desc_size as usize);
            let csum = compute_gdt_csum(&fs.sb, gi as u32, &desc_bytes);
            fs.gdt[gi as usize].bg_checksum = csum as u16;
        }
    }

    {
        let fb = fs.sb.free_blocks();
        fs.sb.set_free_blocks(fb.saturating_add(total_blocks_freed));
        fs.sb.s_free_inodes_count = fs.sb.s_free_inodes_count.saturating_add(1);
    }
    if want_csum {
        fs.sb.s_checksum = 0;
        let sb_bytes = fs.sb.to_bytes();
        let new_sb_csum = anvil_core::crc::crc32c_cont(0xFFFFFFFF, &sb_bytes[..0x3FC]);
        fs.sb.s_checksum = new_sb_csum;
    }

    fs.write_superblock()?;
    fs.write_gdt()?;

    println!("rmdir: removed {path} (freed {total_blocks_freed} blocks, 1 inode)");
    Ok(())
}

/// Walk the parent's dir blocks, find the entry with `name_bytes`,
/// and unlink it. Upstream-style "tombstone" treatment:
///   * if the entry is the first one in its block, zero its
///     inode field (rec_len stays so the slot still spans the
///     block properly).
///   * otherwise, grow the previous entry's rec_len to absorb
///     the removed entry.
/// Re-stamps the dir-block tail csum when metadata_csum is on.
/// Bumps the parent inode's mtime/ctime + its inode csum.
fn remove_parent_dir_entry(
    fs: &mut Fs,
    parent_ino_num: u32,
    parent_inode: &anvil_core::inode::Inode,
    name_bytes: &[u8],
) -> std::io::Result<()> {
    let bs = fs.block_size as usize;
    let mut blocks: Vec<u64> = Vec::new();
    extent::walk_extents(fs, parent_inode, |r| {
        for off in 0..r.length as u64 { blocks.push(r.physical + off); }
    })?;

    let want_csum = fs.has_metadata_csum();
    let block_end = if want_csum { bs - 12 } else { bs };

    let mut chosen_block: Option<u64> = None;
    let mut chosen_off: usize = 0;
    let mut chosen_prev_off: Option<usize> = None;
    let mut buf = vec![0u8; bs];
    'outer: for &blk in &blocks {
        fs.read_block(blk, &mut buf)?;
        let mut off = 0usize;
        let mut prev_off: Option<usize> = None;
        while off + 8 <= block_end {
            let inode = u32::from_le_bytes([buf[off], buf[off+1], buf[off+2], buf[off+3]]);
            let rec_len = u16::from_le_bytes([buf[off+4], buf[off+5]]) as usize;
            let name_len = buf[off+6] as usize;
            if rec_len < 8 || off + rec_len > block_end { break; }
            if inode != 0 && name_len > 0 && off + 8 + name_len <= block_end
               && &buf[off+8..off+8+name_len] == name_bytes
            {
                chosen_block = Some(blk);
                chosen_off = off;
                chosen_prev_off = prev_off;
                break 'outer;
            }
            prev_off = Some(off);
            off += rec_len;
        }
    }
    let blk = chosen_block.ok_or_else(|| std::io::Error::new(
        std::io::ErrorKind::NotFound,
        format!("entry '{}' not found in parent directory",
                String::from_utf8_lossy(name_bytes)),
    ))?;

    // Re-read the chosen block (buf already has it from the match
    // iteration, but being explicit avoids coupling to loop state).
    fs.read_block(blk, &mut buf)?;
    let rec_len = u16::from_le_bytes([buf[chosen_off+4], buf[chosen_off+5]]) as usize;

    if let Some(prev_off) = chosen_prev_off {
        // Extend the previous entry's rec_len to absorb ours.
        let prev_rec = u16::from_le_bytes([buf[prev_off+4], buf[prev_off+5]]) as usize;
        let new_prev = prev_rec + rec_len;
        buf[prev_off+4..prev_off+6].copy_from_slice(&(new_prev as u16).to_le_bytes());
        // Zero the absorbed slot for cleanliness.
        for b in &mut buf[chosen_off..chosen_off + rec_len] { *b = 0; }
    } else {
        // First entry in block: tombstone it by zeroing the inode,
        // name_len, and file_type, keep rec_len so the slot spans.
        buf[chosen_off..chosen_off+4].copy_from_slice(&0u32.to_le_bytes());
        buf[chosen_off+6] = 0;
        buf[chosen_off+7] = 0;
        // Zero the old name bytes too.
        let pay_end = chosen_off + rec_len;
        for b in &mut buf[chosen_off+8..pay_end] { *b = 0; }
    }

    if want_csum {
        let tail_off = bs - 12;
        buf[tail_off..tail_off+8].copy_from_slice(&[0, 0, 0, 0, 0x0C, 0, 0, 0xDE]);
        for b in &mut buf[tail_off+8..tail_off+12] { *b = 0; }
        let generation = parent_inode.i_generation;
        let seed = csum_seed_for(&fs.sb);
        let s1 = anvil_core::crc::crc32c_cont(seed, &parent_ino_num.to_le_bytes());
        let s2 = anvil_core::crc::crc32c_cont(s1, &generation.to_le_bytes());
        let csum = anvil_core::crc::crc32c_cont(s2, &buf[..bs - 12]);
        buf[bs-4..bs].copy_from_slice(&csum.to_le_bytes());
    }
    fs.dev.write_at(blk * fs.block_size, &buf)?;

    // Bump parent mtime/ctime + re-stamp its inode csum.
    let now = now_u32();
    let pgroup = (parent_ino_num as u64 - 1) / fs.inodes_per_group;
    let pidx   = (parent_ino_num as u64 - 1) % fs.inodes_per_group;
    let ptable = fs.group_inode_table(pgroup);
    let pbyte  = ptable * fs.block_size + pidx * fs.inode_size;
    let mut pbuf = vec![0u8; fs.inode_size as usize];
    fs.dev.read_at(pbyte, &mut pbuf)?;
    pbuf[0x0C..0x10].copy_from_slice(&now.to_le_bytes()); // ctime
    pbuf[0x10..0x14].copy_from_slice(&now.to_le_bytes()); // mtime
    if fs.has_metadata_csum() {
        let pgen = u32::from_le_bytes(pbuf[0x64..0x68].try_into().unwrap());
        let extra_isize = if fs.inode_size >= 256 {
            u16::from_le_bytes(pbuf[0x80..0x82].try_into().unwrap())
        } else { 0 };
        let use_hi = fs.inode_size >= 256 && extra_isize > 2;
        pbuf[0x7C..0x7E].copy_from_slice(&0u16.to_le_bytes());
        if use_hi { pbuf[0x82..0x84].copy_from_slice(&0u16.to_le_bytes()); }
        let csum = compute_inode_csum(&fs.sb, parent_ino_num, pgen, &pbuf);
        pbuf[0x7C..0x7E].copy_from_slice(&(csum as u16).to_le_bytes());
        if use_hi {
            pbuf[0x82..0x84].copy_from_slice(&((csum >> 16) as u16).to_le_bytes());
        }
    }
    fs.dev.write_at(pbyte, &pbuf)?;
    Ok(())
}

/// Create a symbolic link at absolute `path` pointing to `target`.
///
/// Follows the ext4 on-disk layout used by upstream mke2fs/e2fsck:
///
/// * `target.len() < 60` — fast-symlink form. The target bytes live
///   directly in the inode's `i_block` area (60 bytes = 15 * u32),
///   `i_size = target.len()`, `i_flags` has `EXTENTS_FL` cleared,
///   `i_blocks_lo = 0`. No data block is allocated.
/// * `target.len() >= 60` — block-backed form. One free block in
///   group 0 holds the target bytes (null-padded to block size),
///   the inode gets an `EXTENTS_FL` extent tree with a single
///   extent pointing at that block, `i_size = target.len()`,
///   `i_blocks_lo = 2` (one 512-byte sector, matching how upstream
///   e2fsprogs accounts a single-block symlink regardless of the
///   filesystem's actual block size).
///
/// Parent dir entry carries `EXT4_FT_SYMLINK (7)`. All checksums
/// (new inode, parent inode, parent dir tail, block/inode bitmap,
/// GDT, SB) are re-stamped when metadata_csum is on.
fn cmd_symlink(fs: &mut Fs, target: &str, path: &str) -> std::io::Result<()> {
    // --- Split path into (parent_path, basename).
    if !path.starts_with('/') {
        return Err(std::io::Error::new(
            std::io::ErrorKind::InvalidInput,
            format!("path '{path}' must be absolute (start with '/')"),
        ));
    }
    let trimmed = path.trim_end_matches('/');
    let (parent_path, basename) = match trimmed.rsplit_once('/') {
        Some((p, b)) => (if p.is_empty() { "/" } else { p }, b),
        None => return Err(std::io::Error::new(
            std::io::ErrorKind::InvalidInput,
            format!("path '{path}' has no basename"),
        )),
    };
    if basename.is_empty() {
        return Err(std::io::Error::new(
            std::io::ErrorKind::InvalidInput,
            format!("path '{path}' has empty basename"),
        ));
    }
    let name_bytes = basename.as_bytes();
    if name_bytes.len() > 255 || name_bytes.contains(&0)
        || name_bytes == b"." || name_bytes == b".."
    {
        return Err(std::io::Error::new(
            std::io::ErrorKind::InvalidInput,
            format!("basename '{basename}' is not a valid filename"),
        ));
    }

    let target_bytes = target.as_bytes();
    if target_bytes.is_empty() {
        return Err(std::io::Error::new(
            std::io::ErrorKind::InvalidInput,
            "symlink target may not be empty".to_string(),
        ));
    }
    let target_len = target_bytes.len();
    let inline = target_len < 60;

    // --- Resolve parent dir inode.
    let parent_ino_num = resolve_path(fs, parent_path).map_err(|e| {
        std::io::Error::new(e.kind(), format!("parent '{parent_path}': {e}"))
    })?;
    let parent_inode = fs.read_inode(parent_ino_num)?;
    if parent_inode.i_mode & S_IFMT != S_IFDIR {
        return Err(std::io::Error::new(
            std::io::ErrorKind::InvalidInput,
            format!("parent '{parent_path}' is not a directory"),
        ));
    }

    // --- Refuse if name already exists.
    if dir_has_name(fs, &parent_inode, name_bytes)? {
        return Err(std::io::Error::new(
            std::io::ErrorKind::AlreadyExists,
            format!("{path}: file already exists"),
        ));
    }

    let bs = fs.block_size;

    // --- Allocate a free inode slot past the reserved range in group 0.
    let first_ino = fs.sb.s_first_ino.max(EXT4_FIRST_NON_RSV_INO);
    let ipg = fs.inodes_per_group as usize;
    let ib_block = fs.group_inode_bitmap(0);
    let mut ib_buf = vec![0u8; bs as usize];
    fs.read_block(ib_block, &mut ib_buf)?;
    let start_bit = first_ino as usize;
    let mut new_ino_num: Option<u32> = None;
    for bit in start_bit..ipg {
        if !anvil_core::bitmap::test_bit(&ib_buf, bit) {
            new_ino_num = Some((bit + 1) as u32);
            break;
        }
    }
    let new_ino_num = new_ino_num.ok_or_else(|| std::io::Error::new(
        std::io::ErrorKind::Other,
        "no free inode slot in group 0",
    ))?;

    // --- For block-form, reserve one free block in group 0.
    let bb_block = fs.group_block_bitmap(0);
    let mut bb_buf = vec![0u8; bs as usize];
    fs.read_block(bb_block, &mut bb_buf)?;
    let bpg = fs.blocks_per_group as usize;
    let first_data_block = fs.sb.s_first_data_block as u64;
    let (data_block, alloc_rel): (Option<u64>, Option<usize>) = if inline {
        (None, None)
    } else {
        let mut found: Option<usize> = None;
        for bit in 0..bpg {
            if !anvil_core::bitmap::test_bit(&bb_buf, bit) {
                found = Some(bit);
                break;
            }
        }
        let rel = found.ok_or_else(|| std::io::Error::new(
            std::io::ErrorKind::Other,
            "no free block in group 0",
        ))?;
        (Some(first_data_block + rel as u64), Some(rel))
    };

    // --- Build the inode.
    let now = now_u32();
    let inode_size = fs.inode_size as usize;
    let mut ibuf = vec![0u8; inode_size];
    let mode: u16 = S_IFLNK | 0o777;
    ibuf[0x00..0x02].copy_from_slice(&mode.to_le_bytes());
    // i_size_lo / i_size_hi = target_len.
    let size = target_len as u64;
    ibuf[0x04..0x08].copy_from_slice(&((size & 0xFFFF_FFFF) as u32).to_le_bytes());
    ibuf[0x6C..0x70].copy_from_slice(&((size >> 32) as u32).to_le_bytes());
    // timestamps
    ibuf[0x08..0x0C].copy_from_slice(&now.to_le_bytes()); // atime
    ibuf[0x0C..0x10].copy_from_slice(&now.to_le_bytes()); // ctime
    ibuf[0x10..0x14].copy_from_slice(&now.to_le_bytes()); // mtime
    // links_count = 1
    ibuf[0x1A..0x1C].copy_from_slice(&1u16.to_le_bytes());
    if inline {
        // i_blocks_lo = 0, i_flags &= !EXTENTS_FL (already 0).
        // Copy target bytes straight into i_block[0..len].
        let iblock_off = 0x28usize;
        ibuf[iblock_off..iblock_off + target_len].copy_from_slice(target_bytes);
    } else {
        // i_blocks_lo = 2 (one 512-byte sector).
        ibuf[0x1C..0x20].copy_from_slice(&2u32.to_le_bytes());
        // i_flags |= EXTENTS_FL
        ibuf[0x20..0x24].copy_from_slice(&EXT4_EXTENTS_FL.to_le_bytes());
        // Extent header + one extent covering the data block.
        let iblock_off = 0x28usize;
        ibuf[iblock_off..iblock_off+2].copy_from_slice(&EXT4_EXT_MAGIC.to_le_bytes());
        ibuf[iblock_off+2..iblock_off+4].copy_from_slice(&1u16.to_le_bytes()); // eh_entries
        ibuf[iblock_off+4..iblock_off+6].copy_from_slice(&4u16.to_le_bytes()); // eh_max
        // depth/gen already zero.
        let e_off = iblock_off + 12;
        let phys = data_block.unwrap();
        ibuf[e_off..e_off+4].copy_from_slice(&0u32.to_le_bytes()); // ee_block = 0
        ibuf[e_off+4..e_off+6].copy_from_slice(&1u16.to_le_bytes()); // ee_len = 1
        ibuf[e_off+6..e_off+8].copy_from_slice(&((phys >> 32) as u16).to_le_bytes());
        ibuf[e_off+8..e_off+12].copy_from_slice(&(phys as u32).to_le_bytes());
    }
    if inode_size >= 256 {
        let extra_isize: u16 = 32;
        ibuf[0x80..0x82].copy_from_slice(&extra_isize.to_le_bytes());
        ibuf[0x90..0x94].copy_from_slice(&now.to_le_bytes()); // i_crtime
    }
    // Stamp inode csum.
    if fs.has_metadata_csum() {
        let generation: u32 = 0;
        let extra_isize = if inode_size >= 256 {
            u16::from_le_bytes(ibuf[0x80..0x82].try_into().unwrap())
        } else { 0 };
        let use_hi = inode_size >= 256 && extra_isize > 2;
        let csum = compute_inode_csum(&fs.sb, new_ino_num, generation, &ibuf);
        ibuf[0x7C..0x7E].copy_from_slice(&(csum as u16).to_le_bytes());
        if use_hi {
            ibuf[0x82..0x84].copy_from_slice(&((csum >> 16) as u16).to_le_bytes());
        }
    }

    // --- Commit to disk. Ordering matches cmd_write / cmd_mkdir.
    // 1. If block-form, write the target bytes into the data block
    //    (null-padded to block size).
    if let Some(blk) = data_block {
        let mut dbuf = vec![0u8; bs as usize];
        dbuf[..target_len].copy_from_slice(target_bytes);
        fs.dev.write_at(blk * bs, &dbuf)?;
    }

    // 2. Write the new inode slot.
    let idx = (new_ino_num as u64 - 1) % fs.inodes_per_group;
    let table = fs.group_inode_table(0);
    let ino_byte = table * bs + idx * fs.inode_size;
    fs.dev.write_at(ino_byte, &ibuf)?;

    // 3. Insert dir entry (file_type = EXT4_FT_SYMLINK).
    add_parent_dir_entry(
        fs, parent_ino_num, &parent_inode,
        new_ino_num, name_bytes, EXT4_FT_SYMLINK,
    )?;

    // 4. Update the inode bitmap.
    anvil_core::bitmap::set_bit(&mut ib_buf, (new_ino_num - 1) as usize);
    fs.dev.write_at(ib_block * bs, &ib_buf)?;

    // 5. Update the block bitmap (block-form only).
    if let Some(rel) = alloc_rel {
        anvil_core::bitmap::set_bit(&mut bb_buf, rel);
        fs.dev.write_at(bb_block * bs, &bb_buf)?;
    }

    // 6. Update group 0 descriptor: one fewer free inode, one
    //    fewer free block if block-form.
    {
        let gd = &mut fs.gdt[0];
        let cur_fb = (gd.bg_free_blocks_count_lo as u32)
            | ((gd.bg_free_blocks_count_hi as u32) << 16);
        let cur_fi = (gd.bg_free_inodes_count_lo as u32)
            | ((gd.bg_free_inodes_count_hi as u32) << 16);
        if !inline { gd.set_free_blocks(cur_fb.saturating_sub(1)); }
        gd.set_free_inodes(cur_fi.saturating_sub(1));
    }
    if fs.has_metadata_csum() {
        let bbc = compute_bitmap_csum(&fs.sb, &bb_buf);
        fs.gdt[0].bg_block_bitmap_csum_lo = bbc as u16;
        if fs.desc_size as usize >= 0x3A {
            fs.gdt[0].bg_block_bitmap_csum_hi = (bbc >> 16) as u16;
        }
        let ipg_bytes = ((fs.inodes_per_group as usize + 7) / 8).min(ib_buf.len());
        let ibc = compute_bitmap_csum(&fs.sb, &ib_buf[..ipg_bytes]);
        fs.gdt[0].bg_inode_bitmap_csum_lo = ibc as u16;
        if fs.desc_size as usize >= 0x3A {
            fs.gdt[0].bg_inode_bitmap_csum_hi = (ibc >> 16) as u16;
        }
    }

    // 7. Re-stamp every GDT descriptor's bg_checksum.
    if fs.has_metadata_csum() {
        for gi in 0..fs.groups_count {
            let desc_bytes = fs.gdt[gi as usize].to_bytes(fs.desc_size as usize);
            let csum = compute_gdt_csum(&fs.sb, gi as u32, &desc_bytes);
            fs.gdt[gi as usize].bg_checksum = csum as u16;
        }
    }

    // 8. Update SB free counters.
    {
        let fb = fs.sb.free_blocks();
        if !inline { fs.sb.set_free_blocks(fb.saturating_sub(1)); }
        fs.sb.s_free_inodes_count = fs.sb.s_free_inodes_count.saturating_sub(1);
    }
    if fs.has_metadata_csum() {
        fs.sb.s_checksum = 0;
        let sb_bytes = fs.sb.to_bytes();
        let new_sb_csum = anvil_core::crc::crc32c_cont(0xFFFFFFFF, &sb_bytes[..0x3FC]);
        fs.sb.s_checksum = new_sb_csum;
    }

    // 9. Flush SB + GDT.
    fs.write_superblock()?;
    fs.write_gdt()?;

    let form = if inline { "inline" } else { "block" };
    eprintln!("symlink: {path} -> {target} (inode {new_ino_num}, {form})");
    Ok(())
}

fn cmd_logdump(fs: &mut Fs) -> std::io::Result<()> {
    // JBD2 SB decode only. No transaction walk — that is a much
    // bigger feature and is called out as out-of-scope for this
    // pass. The on-disk format we decode is big-endian by JBD2
    // convention (inherited from ext3's journal).
    if fs.sb.s_feature_compat & EXT4_FEATURE_COMPAT_HAS_JOURNAL == 0 {
        println!("logdump: filesystem has no journal");
        return Ok(());
    }

    let jino = fs.read_inode(EXT4_JOURNAL_INO)?;
    let jsize_bytes = jino.size();
    let bs = fs.block_size;
    let jblocks = jsize_bytes / bs;

    // Walk the journal inode's extent tree to find the first
    // physical block — that is where the JBD2 SB lives.
    let mut first_phys: Option<u64> = None;
    let _ = extent::walk_extents(fs, &jino, |r| {
        if first_phys.is_none() {
            // Prefer the run that covers logical block 0.
            if r.logical == 0 {
                first_phys = Some(r.physical);
            }
        }
    });
    let first_phys = match first_phys {
        Some(b) => b,
        None => {
            return Err(std::io::Error::new(
                std::io::ErrorKind::InvalidData,
                "logdump: journal inode has no extents",
            ));
        }
    };

    let mut buf = vec![0u8; bs as usize];
    fs.read_block(first_phys, &mut buf)?;

    // Cast the read buffer to the JBD2 SB layout. 1024 bytes of
    // POD integers / byte arrays — safe as long as the buffer is
    // at least 1024 bytes (block size is >= 1024 for ext4).
    if buf.len() < core::mem::size_of::<anvil_core::jbd2::JournalSuperblock>() {
        return Err(std::io::Error::new(
            std::io::ErrorKind::InvalidData,
            "logdump: block too small to hold JBD2 superblock",
        ));
    }
    let jsb: anvil_core::jbd2::JournalSuperblock =
        unsafe { *(buf.as_ptr() as *const anvil_core::jbd2::JournalSuperblock) };

    // Every multi-byte field is big-endian on disk. Decode up front
    // so we can print without the packed-struct unaligned-read dance.
    let magic     = u32::from_be(jsb.s_header.h_magic);
    let blocktype = u32::from_be(jsb.s_header.h_blocktype);
    let sequence  = u32::from_be(jsb.s_header.h_sequence);
    let blocksize = u32::from_be(jsb.s_blocksize);
    let maxlen    = u32::from_be(jsb.s_maxlen);
    let first     = u32::from_be(jsb.s_first);
    let start     = u32::from_be(jsb.s_start);
    let errno     = i32::from_be(jsb.s_errno);
    let fcompat   = u32::from_be(jsb.s_feature_compat);
    let fincompat = u32::from_be(jsb.s_feature_incompat);
    let frocompat = u32::from_be(jsb.s_feature_ro_compat);
    let nr_users  = u32::from_be(jsb.s_nr_users);
    let csum_type = jsb.s_checksum_type;
    let csum      = u32::from_be(jsb.s_checksum);
    let uuid      = jsb.s_uuid;

    let blocktype_str = match blocktype {
        anvil_core::jbd2::JBD2_SUPERBLOCK_V1 => "V1 (3)",
        anvil_core::jbd2::JBD2_SUPERBLOCK_V2 => "V2 (4)",
        _ => "unknown",
    };

    println!("Journal inode:        {}", EXT4_JOURNAL_INO);
    println!("Journal size:         {} blocks ({} bytes)", jblocks, jsize_bytes);
    println!("Journal SB fields:");
    println!("  magic              0x{:08x}", magic);
    println!("  block type          {}", blocktype_str);
    println!("  sequence            {}", sequence);
    println!("  blocksize           {}", blocksize);
    println!("  maxlen              {}", maxlen);
    println!("  first               {}", first);
    println!("  start               {}", start);
    println!("  errno               {}", errno);
    println!("  feature compat      0x{:08x}", fcompat);
    // Mirror the CSUM_V3 convention dumpe2fs uses: print the raw
    // hex and, when the bit is set, annotate it.
    if fincompat & anvil_core::jbd2::JBD2_FEATURE_INCOMPAT_CSUM_V3 != 0 {
        println!("  feature incompat    0x{:08x}     # CSUM_V3", fincompat);
    } else {
        println!("  feature incompat    0x{:08x}", fincompat);
    }
    println!("  feature ro_compat   0x{:08x}", frocompat);
    println!("  nr_users            {}", nr_users);
    if csum_type != 0 {
        let tname = match csum_type {
            anvil_core::jbd2::JBD2_CRC32C_CHKSUM => "crc32c",
            _ => "?",
        };
        println!("  checksum_type       {} ({})", csum_type, tname);
    }
    if csum != 0 {
        println!("  checksum            0x{:08x}", csum);
    }
    println!("  uuid                {}", format_uuid(&uuid));

    Ok(())
}

fn describe_mode(m: u16) -> &'static str {
    match m & S_IFMT {
        S_IFREG => "regular file",
        S_IFDIR => "directory",
        S_IFLNK => "symlink",
        S_IFCHR => "char device",
        S_IFBLK => "block device",
        S_IFIFO => "FIFO",
        S_IFSOCK => "socket",
        _ => "unknown",
    }
}

fn format_uuid(bytes: &[u8; 16]) -> String {
    if bytes.iter().all(|&b| b == 0) { return "<none>".into(); }
    let b = bytes;
    format!(
        "{:02x}{:02x}{:02x}{:02x}-{:02x}{:02x}-{:02x}{:02x}-{:02x}{:02x}-{:02x}{:02x}{:02x}{:02x}{:02x}{:02x}",
        b[0],b[1],b[2],b[3], b[4],b[5], b[6],b[7], b[8],b[9],
        b[10],b[11],b[12],b[13],b[14],b[15])
}


/// Print extended attributes attached to an inode — both the inline
/// area past the extra-isize fields and any external xattr block
/// referenced by i_file_acl. Read-only; clean-room implementation
/// built from the public on-disk format spec.
fn cmd_list_xattr(fs: &mut Fs, ino_num: u32) -> std::io::Result<()> {
    let raw = fs.read_inode_raw(ino_num)?;
    let inode_size = fs.inode_size as usize;

    // Inline extra_isize sits at raw[0x80..0x82] when inode_size > 128.
    let extra_isize: u16 = if inode_size > 128 && raw.len() >= 0x82 {
        u16::from_le_bytes([raw[0x80], raw[0x81]])
    } else { 0 };

    // i_file_acl_lo at 0x68 (u32 LE), l_i_file_acl_high in osd2[1] at 0x76 (u16 LE).
    let acl_lo = if raw.len() >= 0x6C {
        u32::from_le_bytes([raw[0x68], raw[0x69], raw[0x6A], raw[0x6B]]) as u64
    } else { 0 };
    let acl_hi = if fs.has_64bit && raw.len() >= 0x78 {
        u16::from_le_bytes([raw[0x76], raw[0x77]]) as u64
    } else { 0 };
    let acl_block = (acl_hi << 32) | acl_lo;

    let mut entries: Vec<XattrEntry> = Vec::new();
    let mut had_any_area = false;
    let mut malformed = false;

    // Inline xattr area.
    if inode_size > 128 && extra_isize > 0 {
        let base = 128 + extra_isize as usize;
        if base + 4 <= raw.len() {
            let magic = u32::from_le_bytes([raw[base], raw[base+1], raw[base+2], raw[base+3]]);
            if magic == 0xEA020000 {
                had_any_area = true;
                let body = &raw[base+4..];
                match parse_xattr_entries(body, body, "inline") {
                    Ok(mut v) => entries.append(&mut v),
                    Err(()) => malformed = true,
                }
            }
        }
    }

    // External xattr block.
    if acl_block != 0 {
        had_any_area = true;
        let bs = fs.block_size as usize;
        let mut blk = vec![0u8; bs];
        fs.read_block(acl_block, &mut blk)?;
        if blk.len() >= 4 {
            let magic = u32::from_le_bytes([blk[0], blk[1], blk[2], blk[3]]);
            if magic == 0xEA020000 && blk.len() > 32 {
                // Entries start after the 32-byte header; values are
                // offsets relative to the start of the block.
                let body = blk[32..].to_vec();
                match parse_xattr_entries(&body, &blk, "block") {
                    Ok(mut v) => entries.append(&mut v),
                    Err(()) => malformed = true,
                }
            } else {
                malformed = true;
            }
        } else {
            malformed = true;
        }
    }

    if malformed {
        println!("malformed xattr entry");
        return Ok(());
    }
    if !had_any_area || entries.is_empty() {
        println!("no extended attributes");
        return Ok(());
    }

    println!("Extended attributes for inode {ino_num}:");
    for e in &entries {
        let full_name = format_xattr_name(e.name_index, &e.name);
        match &e.value {
            XattrValue::Inline(bytes) => {
                if is_printable(bytes) {
                    let s = String::from_utf8_lossy(bytes);
                    println!("  {full_name} = \"{s}\" ({} bytes, inline)", bytes.len());
                } else {
                    println!("  {full_name} = <{} bytes binary> (inline)", bytes.len());
                }
            }
            XattrValue::EaInode(inum, size) => {
                println!("  {full_name} = <EA inode {inum}> ({size} bytes)");
            }
        }
    }
    Ok(())
}

struct XattrEntry {
    name_index: u8,
    name: Vec<u8>,
    value: XattrValue,
}

enum XattrValue {
    Inline(Vec<u8>),
    EaInode(u32, u32),
}

/// Walk an xattr entry stream. `entries` is the byte slice starting at
/// the first ext4_xattr_entry; `values_base` is the region value_offs
/// is relative to (same slice for inline, the whole block for the
/// external case — caller passes the right one).
fn parse_xattr_entries(entries: &[u8], values_base: &[u8], _tag: &str)
    -> Result<Vec<XattrEntry>, ()>
{
    let mut out = Vec::new();
    let mut cur = 0usize;
    loop {
        // 4-byte alignment.
        if cur % 4 != 0 { cur += 4 - (cur % 4); }
        if cur + 16 > entries.len() { return Err(()); }
        let name_len = entries[cur];
        // Terminator: first 4 bytes all zero.
        if name_len == 0
            && entries[cur+1] == 0
            && entries[cur+2] == 0
            && entries[cur+3] == 0
        {
            break;
        }
        let name_index = entries[cur+1];
        let value_offs = u16::from_le_bytes([entries[cur+2], entries[cur+3]]) as usize;
        let value_inum = u32::from_le_bytes([entries[cur+4], entries[cur+5], entries[cur+6], entries[cur+7]]);
        let value_size = u32::from_le_bytes([entries[cur+8], entries[cur+9], entries[cur+10], entries[cur+11]]);
        // entries[cur+12..cur+16] = e_hash; ignored for listing.
        let name_start = cur + 16;
        let name_end = name_start + name_len as usize;
        if name_end > entries.len() { return Err(()); }
        let name = entries[name_start..name_end].to_vec();

        let value = if value_inum != 0 {
            XattrValue::EaInode(value_inum, value_size)
        } else {
            let vs = value_size as usize;
            if value_offs.saturating_add(vs) > values_base.len() { return Err(()); }
            XattrValue::Inline(values_base[value_offs..value_offs+vs].to_vec())
        };

        if name_len > 0 {
            out.push(XattrEntry { name_index, name, value });
        }

        // Advance past the fixed header + name, padded to 4 bytes.
        let raw_adv = 16 + name_len as usize;
        let padded = (raw_adv + 3) & !3;
        cur += padded;
    }
    Ok(out)
}

fn format_xattr_name(ns: u8, name: &[u8]) -> String {
    let n = String::from_utf8_lossy(name);
    match ns {
        1 => format!("user.{n}"),
        2 => "system.posix_acl_access".to_string(),
        3 => "system.posix_acl_default".to_string(),
        4 => format!("trusted.{n}"),
        6 => format!("security.{n}"),
        7 => format!("trusted.{n}"),
        8 => format!("security.{n}"),
        other => format!("ns{other}.{n}"),
    }
}

fn is_printable(bytes: &[u8]) -> bool {
    !bytes.is_empty() && bytes.iter().all(|&b| (0x20..=0x7E).contains(&b))
}

