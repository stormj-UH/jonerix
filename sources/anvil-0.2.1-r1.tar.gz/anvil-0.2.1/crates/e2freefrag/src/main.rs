//! e2freefrag — report free-space fragmentation of an ext4
//! filesystem image. Reads each block-group's block bitmap,
//! walks the bits, and accumulates contiguous runs of free
//! (zero) bits as "free extents". Output is a human-readable
//! summary plus a power-of-two histogram of free-extent sizes.
//!
//! Flags:
//!   <device>             summary + default histogram (bucket=1)
//!   -c <bucket_size>     bucket size for the histogram
//!   -V                   version
//!
//! Exit codes:
//!   0   ran to completion
//!   8   operational error (open / read)
//!   16  usage error
//!
//! Bigalloc note: when the filesystem has the BIGALLOC feature
//! the block bitmap is cluster-granularity, not block-granularity.
//! Reporting free runs in cluster units would be misleading next
//! to the "Blocksize: N" header, so we print a notice and exit 0.

use std::path::PathBuf;
use std::process::ExitCode;

use anvil_core::consts::EXT4_FEATURE_RO_COMPAT_BIGALLOC;
use anvil_core::fs::Fs;

const VERSION_LINE: &str = "anvil-e2freefrag 1.47.3-anvil (MIT)";

fn main() -> ExitCode {
    let args: Vec<String> = std::env::args().skip(1).collect();
    let mut bucket: u64 = 1;
    let mut device: Option<PathBuf> = None;
    let mut i = 0;
    while i < args.len() {
        let a = &args[i];
        match a.as_str() {
            "-V" => {
                println!("{VERSION_LINE}");
                return ExitCode::from(0);
            }
            "-c" => {
                i += 1;
                let Some(v) = args.get(i) else {
                    eprintln!("e2freefrag: -c requires a bucket size");
                    return ExitCode::from(16);
                };
                match v.parse::<u64>() {
                    Ok(n) if n >= 1 => bucket = n,
                    _ => {
                        eprintln!("e2freefrag: invalid bucket size '{v}'");
                        return ExitCode::from(16);
                    }
                }
            }
            s if s.starts_with('-') => {
                eprintln!("e2freefrag: unknown option {s} (ignored)");
            }
            _ => {
                if device.is_some() {
                    eprintln!("e2freefrag: extra positional argument '{a}'");
                    return ExitCode::from(16);
                }
                device = Some(PathBuf::from(a));
            }
        }
        i += 1;
    }

    let Some(dev_path) = device else {
        eprintln!("usage: e2freefrag [-c bucket_size] <device>");
        eprintln!("       e2freefrag -V");
        return ExitCode::from(16);
    };

    let mut fs = match Fs::open(&dev_path) {
        Ok(fs) => fs,
        Err(e) => {
            eprintln!("e2freefrag: open {}: {}", dev_path.display(), e);
            return ExitCode::from(8);
        }
    };

    if fs.sb.s_feature_ro_compat & EXT4_FEATURE_RO_COMPAT_BIGALLOC != 0 {
        println!("Device: {}", dev_path.display());
        println!("Blocksize: {} bytes", fs.block_size);
        println!();
        println!("e2freefrag: bigalloc filesystems are not supported by this");
        println!("            first-pass reporter (block bitmap is cluster-");
        println!("            granularity; per-block free runs would be");
        println!("            misleading). Skipping.");
        return ExitCode::from(0);
    }

    match scan(&mut fs, bucket) {
        Ok(report) => {
            print_report(&dev_path, &fs, &report, bucket);
            ExitCode::from(0)
        }
        Err(e) => {
            eprintln!("e2freefrag: scan: {e}");
            ExitCode::from(8)
        }
    }
}

#[derive(Default)]
struct Report {
    free_blocks: u64,
    free_extents: u64,
    max_extent: u64,
    /// Histogram keyed by bucket index. With the default
    /// power-of-two bucketing each entry represents extents whose
    /// size falls in [2^i .. 2^(i+1)) blocks. With `-c bucket`
    /// each entry covers a fixed-width slice [k*bucket .. (k+1)*bucket).
    hist: Vec<(u64, u64)>, // (bucket-low-bound-in-blocks, count)
}

fn scan(fs: &mut Fs, bucket: u64) -> std::io::Result<Report> {
    let block_size = fs.block_size as usize;
    let total_blocks = fs.total_blocks();
    let blocks_per_group = fs.blocks_per_group;

    // Bucket accumulator. Power-of-two buckets when bucket==1
    // (the upstream default), fixed-width otherwise.
    let pow2 = bucket == 1;
    // 64 buckets covers up to 2^63 blocks — more than enough.
    let mut buckets: Vec<u64> = vec![0; 64];

    let mut free_blocks: u64 = 0;
    let mut free_extents: u64 = 0;
    let mut max_extent: u64 = 0;

    let mut bitmap = vec![0u8; block_size];

    // Track a run that crosses the group boundary. ext4 numbers
    // blocks contiguously across groups, so a free extent at the
    // very tail of group N can join with one at the head of group
    // N+1. We close the run only when we hit an allocated bit or
    // the end of the device.
    let mut run_len: u64 = 0;

    let groups = fs.groups_count;
    for g in 0..groups {
        let bm_block = fs.group_block_bitmap(g);
        fs.read_block(bm_block, &mut bitmap)?;

        // How many blocks does this group actually cover? The last
        // group may be short.
        let first_block_in_group = g * blocks_per_group + fs.sb.s_first_data_block as u64;
        let blocks_here = if first_block_in_group >= total_blocks {
            0
        } else {
            std::cmp::min(blocks_per_group, total_blocks - first_block_in_group)
        };

        for b in 0..blocks_here {
            let byte = bitmap[(b / 8) as usize];
            let used = (byte >> (b % 8)) & 1 != 0;
            if used {
                if run_len > 0 {
                    record(&mut buckets, run_len, pow2, bucket);
                    if run_len > max_extent { max_extent = run_len; }
                    free_extents += 1;
                    free_blocks += run_len;
                    run_len = 0;
                }
            } else {
                run_len += 1;
            }
        }
    }
    if run_len > 0 {
        record(&mut buckets, run_len, pow2, bucket);
        if run_len > max_extent { max_extent = run_len; }
        free_extents += 1;
        free_blocks += run_len;
    }

    // Materialize histogram entries for non-empty buckets only.
    let mut hist: Vec<(u64, u64)> = Vec::new();
    for (i, &c) in buckets.iter().enumerate() {
        if c == 0 { continue; }
        let lo = if pow2 { 1u64 << i } else { (i as u64) * bucket + 1 };
        hist.push((lo, c));
    }

    Ok(Report { free_blocks, free_extents, max_extent, hist })
}

fn record(buckets: &mut [u64], len: u64, pow2: bool, bucket: u64) {
    let idx = if pow2 {
        // floor(log2(len)) — index 0 = "1 block" bucket.
        63usize.saturating_sub(len.leading_zeros() as usize)
    } else {
        ((len - 1) / bucket) as usize
    };
    if idx < buckets.len() {
        buckets[idx] += 1;
    } else {
        let last = buckets.len() - 1;
        buckets[last] += 1;
    }
}

fn print_report(dev: &std::path::Path, fs: &Fs, r: &Report, bucket: u64) {
    let total = fs.total_blocks();
    let pct = if total > 0 {
        (r.free_blocks as f64) * 100.0 / (total as f64)
    } else { 0.0 };
    let avg = if r.free_extents > 0 {
        r.free_blocks / r.free_extents
    } else { 0 };

    println!("Device: {}", dev.display());
    println!("Blocksize: {} bytes", fs.block_size);
    println!("Total blocks: {}", total);
    println!("Free blocks: {} ({:.1}%)", r.free_blocks, pct);
    println!("Free extents:    {}", r.free_extents);
    println!("Avg free extent: {} blocks", avg);
    println!("Max free extent: {} blocks", r.max_extent);
    println!();
    println!("Free-extent size histogram:");
    let pow2 = bucket == 1;
    for (lo, count) in &r.hist {
        let label = if pow2 {
            if *lo == 1 {
                format!("{:>5} block", lo)
            } else {
                format!("{:>5} blocks", lo)
            }
        } else {
            let hi = lo + bucket - 1;
            if bucket == 1 {
                format!("{:>5} blocks", lo)
            } else {
                format!("{:>5}-{} blocks", lo, hi)
            }
        };
        println!("{}:   {}", label, count);
    }
}
