#!/bin/sh
# scripts/build-bash-oracle.sh — build a vanilla GNU bash 5.3 into
# .cache/bash-oracle for the test runners to use as the reference shell.
#
# The upstream .right files were generated from the bash-5.3 release, and a
# distribution's bash can differ from it (homebrew's 5.3.9 on macOS keeps a
# stale tilde home, so `HOME=/x; echo ~` prints the old home).  A vanilla
# build compared byte-for-byte against those files is the only oracle that
# cannot mask a brash bug the distribution shell shares.
#
# The build tree it leaves in .cache/bash-oracle-src is also what
# run-tests-local.sh runs the upstream suite from: tests like heredoc.tests
# read $BUILD_DIR/config.h and ../y.tab.c, which only a configured tree has.
#
# Usage:  sh scripts/build-bash-oracle.sh        (idempotent, ~2 minutes)
# Needs a C compiler and network access to ftp.gnu.org.
set -eu
ROOT_DIR=$(cd "$(dirname "$0")/.." && pwd)
CACHE="$ROOT_DIR/.cache"
PREFIX="$CACHE/bash-oracle"
SRC="$CACHE/bash-oracle-src"
TARBALL_URL=https://ftp.gnu.org/gnu/bash/bash-5.3.tar.gz

if [ -x "$PREFIX/bin/bash" ]; then
    printf 'bash oracle already built: %s (%s)\n' "$PREFIX/bin/bash" "$("$PREFIX/bin/bash" --version | head -1)"
    exit 0
fi
mkdir -p "$SRC"
cd "$SRC"
if [ ! -f bash-5.3.tar.gz ]; then
    printf 'fetching %s\n' "$TARBALL_URL"
    curl -fsSL -o bash-5.3.tar.gz "$TARBALL_URL"
fi
rm -rf bash-5.3
tar xzf bash-5.3.tar.gz
cd bash-5.3
./configure --prefix="$PREFIX" --without-bash-malloc > configure.log 2>&1
make -j"$(getconf _NPROCESSORS_ONLN 2>/dev/null || echo 4)" > make.log 2>&1
make install > install.log 2>&1
printf 'built %s\n' "$("$PREFIX/bin/bash" --version | head -1)"
