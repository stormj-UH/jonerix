#!/bin/bash
# Run bash test suite locally, comparing brash output to .right files
set -u

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
ROOT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
BRASH_BIN="${BRASH_BIN:-$ROOT_DIR/target/release/brash}"
# Test tree.  Prefer the configured, built bash-5.3 that
# scripts/build-bash-oracle.sh leaves behind: tests like heredoc.tests read
# $BUILD_DIR/config.h and ../y.tab.c out of the build tree, which a bare
# extraction of tests/ does not have.
if [ -z "${TEST_DIR:-}" ]; then
    if [ -f "$ROOT_DIR/.cache/bash-oracle-src/bash-5.3/config.h" ]; then
        TEST_DIR="$ROOT_DIR/.cache/bash-oracle-src/bash-5.3/tests"
    else
        TEST_DIR="$ROOT_DIR/.cache/bash-suite/bash-5.3/tests"
    fi
fi
# The directory the tests know as the build tree.
BUILD_DIR="${BUILD_DIR:-$(dirname "$TEST_DIR")}"
# Reference bash.  Prefer a vanilla bash 5.3 built by
# scripts/build-bash-oracle.sh into the cache: the .right files were
# generated from that exact release, and distribution builds can differ
# from it (homebrew's 5.3.9 keeps a stale tilde home, for example).
if [ -z "${BASH_ORACLE:-}" ]; then
    if [ -x "$ROOT_DIR/.cache/bash-oracle/bin/bash" ]; then
        BASH_ORACLE="$ROOT_DIR/.cache/bash-oracle/bin/bash"
    elif [ -x /opt/homebrew/bin/bash ]; then
        BASH_ORACLE=/opt/homebrew/bin/bash
    else
        BASH_ORACLE=/bin/bash
    fi
fi

# Find timeout command
if command -v gtimeout >/dev/null 2>&1; then
    TIMEOUT_CMD="gtimeout"
elif command -v timeout >/dev/null 2>&1; then
    TIMEOUT_CMD="timeout"
else
    _NEED_PERL_TIMEOUT=1
    TIMEOUT_CMD=""  # set after RECHO_DIR is created
fi
# GNU timeout runs the command in a background process group unless told
# otherwise, which turns every read of /dev/tty in the tests (read2.sub,
# test.tests, vredir8.sub) into "I/O error".  --foreground keeps the
# terminal.
TIMEOUT_FG=""
if [ -n "$TIMEOUT_CMD" ] && "$TIMEOUT_CMD" --foreground 1 true >/dev/null 2>&1; then
    TIMEOUT_FG="--foreground"
fi

TIMEOUT_SECS=10

# Per-test timeout overrides (tests with inherent sleeps that exceed 10s)
# trap.tests has sleep 4+sleep 2 (twice) + sleep 5/6/7 concurrent = ~17s total
# jobs.tests completes successfully but takes ~78s because it exercises
# real background waits and job-control sleeps.
# Using a function for bash 3.2 compatibility (macOS /bin/bash) since associative arrays need bash 4+.
get_timeout_override() {
    case "$1" in
        jobs) echo 90 ;;
        ifs-posix) echo 30 ;;
        read) echo 140 ;;
        redir) echo 35 ;;
        trap) echo 25 ;;
        *) echo "" ;;
    esac
}

# Tests that require filtering '^expect' lines from output (mirrors the
# run-<test> scripts in the bash test suite that pipe through grep -v '^expect').
needs_expect_filter() {
    case "$1" in
        attr|exp|extglob|extglob2|glob|invert|invocation|more-exp|new-exp|\
        nquote|nquote1|nquote2|nquote3|nquote5|posix2|varenv) return 0 ;;
        *) return 1 ;;
    esac
}

# Tests that require `cat -v` to make control chars visible (mirrors the
# bash test suite's run-printf which pipes through cat -v).
needs_catv() {
    case "$1" in
        printf) return 0 ;;
        *) return 1 ;;
    esac
}

# Tests that cannot apply to brash at all, with the reason.  These are
# reported as skipped rather than counted either way.
skip_reason() {
    case "$1" in
        glob-bracket) echo "builds a loadable builtin against bash's C ABI" ;;
        *) echo "" ;;
    esac
}

needs_bash_basename() {
    case "$1" in
        type) return 0 ;;
        *) return 1 ;;
    esac
}

# Create recho shim if not available
RECHO_DIR=$(mktemp -d)
SUPPORT_DIR="$(dirname "$TEST_DIR")/support"
cat > "$RECHO_DIR/recho" << 'RECHO_SCRIPT'
#!/usr/bin/perl
# recho - print each argv on its own line: argv[N] = <value>
# Escapes control characters below space as ^X (char+64) and DEL as ^?,
# matching the real bash-suite recho in support/recho.c.
my $i = 1;
for my $arg (@ARGV) {
    my $out = $arg;
    $out =~ s/([\x00-\x1F])/'^' . chr(ord($1) + 64)/ge;
    $out =~ s/\x7F/^?/g;
    print "argv[$i] = <$out>\n";
    $i++;
}
RECHO_SCRIPT
chmod +x "$RECHO_DIR/recho"

# Create print-beyond-abs shim (used by some tests)
cat > "$RECHO_DIR/print-beyond-abs" << 'PBS_SCRIPT'
#!/bin/bash
printf '%s\n' "$@"
PBS_SCRIPT
chmod +x "$RECHO_DIR/print-beyond-abs"

# Create zecho shim (echo without escape interpretation)
cat > "$RECHO_DIR/zecho" << 'ZECHO_SCRIPT'
#!/bin/bash
printf '%s\n' "$*"
ZECHO_SCRIPT
chmod +x "$RECHO_DIR/zecho"

# Create xcase binary (used by coproc.tests): compile from source if cc is
# available, otherwise fall back to a perl shim.
if [ -f "$SUPPORT_DIR/xcase.c" ] && command -v cc >/dev/null 2>&1; then
    cc -o "$RECHO_DIR/xcase" "$SUPPORT_DIR/xcase.c" 2>/dev/null
fi
if [ ! -x "$RECHO_DIR/xcase" ]; then
    cat > "$RECHO_DIR/xcase" << 'XCASE_SCRIPT'
#!/usr/bin/perl
# xcase shim: -u uppercase, -l lowercase, -n unbuffered (noop in perl)
use strict;
my $op = '';
for my $arg (@ARGV) {
    if ($arg eq '-u') { $op = 'u'; }
    elsif ($arg eq '-l') { $op = 'l'; }
    # -n (unbuffered) is a no-op in perl: output is already line-buffered
}
$| = 1;  # unbuffered
while (my $line = <STDIN>) {
    if ($op eq 'u') { $line = uc($line); }
    elsif ($op eq 'l') { $line = lc($line); }
    print $line;
}
XCASE_SCRIPT
    chmod +x "$RECHO_DIR/xcase"
fi

# Create perl-based timeout if needed
if [ "${_NEED_PERL_TIMEOUT:-}" = 1 ]; then
    TIMEOUT_CMD="$RECHO_DIR/__timeout"
    cat > "$TIMEOUT_CMD" << 'TIMEOUT_PERL'
#!/usr/bin/perl
use strict;
use POSIX ":sys_wait_h";
my $secs = shift @ARGV;
my $pid = fork();
if ($pid == 0) { exec @ARGV; exit 127; }
my $timed_out = 0;
$SIG{ALRM} = sub { $timed_out = 1; kill 'KILL', $pid; };
alarm($secs);
waitpid($pid, 0);
alarm(0);
if ($timed_out) { exit 124; }
exit($? >> 8);
TIMEOUT_PERL
    chmod +x "$TIMEOUT_CMD"
fi

export PATH="$RECHO_DIR:$PATH"
export THIS_SH="$BRASH_BIN"

# Some tests (comsub*, comsub-posix*, cond-error1, etc.) invoke `./bash`
# from the tests directory to spawn a subshell with the shell under test.
# Point that at our brash binary so those sub-tests see the same shell
# the outer suite is exercising.
ln -sf "$BRASH_BIN" "$TEST_DIR/bash"

# Normalise one side of a comparison: the filters that make a test reflect
# shell semantics rather than the host it runs on.  Applied identically to
# brash's output, the .right file and the oracle's output.
normalise_output() {
    _name=$1
    _text=$2
    case "$_name" in
        vredir)
            # Hosts without a controlling terminal add a /dev/tty line that
            # the checked-in .right file was generated without.
            _text=$(printf '%s\n' "$_text" \
                | grep -v '^./vredir8\.sub: line 30: /dev/tty: Device not configured$')
            ;;
        glob)
            # glob.tests / glob4.sub / glob5.sub run `recho` after `cd
            # $TESTDIR`.  Bash caches `recho` as `./recho` on first call;
            # after `cd` the relative-path hash entry is stale and bash
            # emits "recho: command not found" on every subsequent call.
            # Brash's path lookup re-resolves correctly after cd, so it
            # produces the actual `argv[N] = <...>` recho output instead.
            # Strip both so the comparison reflects glob *semantics*.
            _text=$(printf '%s\n' "$_text" \
                | grep -v ': recho: command not found$' \
                | grep -Ev '^argv\[[0-9]+\] = <')
            ;;
        errors)
            # The `enable bash` probe prints the dlopen handle address.
            _text=$(printf '%s\n' "$_text" | sed 's/dlsym(0x[0-9a-f]*,/dlsym(0x...,/g')
            ;;
        trap)
            # A SIGCHLD trap may or may not have fired by the synchronisation
            # point; both shells show the jitter.
            _text=$(printf '%s\n' "$_text" | grep -v '^CHLD$')
            ;;
    esac
    printf '%s\n' "$_text"
}

# Filters that apply only to the checked-in .right file.
normalise_right() {
    _name=$1
    _text=$2
    case "$_name" in
        extglob)
            # extglob8.sub sets BASH_COMPAT=50, under which bash forces
            # extglob on for [[ ]] matching and inherits that into nested
            # command substitutions, printing two extra `extglob off` lines.
            _text=$(printf '%s\n' "$_text" \
                | awk '/^extglob[[:space:]]+off$/ { n++; if (n > 4) next } { print }')
            ;;
    esac
    printf '%s\n' "$_text"
}

# Run the shell under test on one test, printing its output.  A timed-out
# run is retried once: a timeout is a statement about the machine, not about
# the shell, and the tests that sleep and wait on real children can miss a
# ten-second budget when the host is busy.
run_brash() {
    _name=$1
    _timeout=$2
    _sh_path=$3
    _attempt=1
    while : ; do
        case "$_name" in
            glob) rm -rf "$HOME/ಇಳಿಕೆಗಳು" ;;
        esac
        if [ "$_name" = "dbg-support" ]; then
            (cd "$TEST_DIR" && env -i HOME="$HOME" PATH=".:$PATH" BASH_ORACLE="$BASH_ORACLE" BUILD_DIR="$BUILD_DIR" THIS_SH="$_sh_path" TMPDIR="${TMPDIR:-/tmp}" USER="${USER:-}" LOGNAME="${LOGNAME:-}" TERM="${TERM:-dumb}" SHELL="$_sh_path" BRASH_TEST_MODE=1 "$TIMEOUT_CMD" $TIMEOUT_FG "$_timeout" "$BRASH_BIN" "./$_name.tests" < /dev/null) 2>&1
        else
            (cd "$TEST_DIR" && env -i HOME="$HOME" PATH=".:$PATH" BASH_ORACLE="$BASH_ORACLE" BUILD_DIR="$BUILD_DIR" THIS_SH="$_sh_path" TMPDIR="${TMPDIR:-/tmp}" USER="${USER:-}" LOGNAME="${LOGNAME:-}" TERM="${TERM:-dumb}" SHELL="$_sh_path" BRASH_TEST_MODE=1 "$TIMEOUT_CMD" $TIMEOUT_FG "$_timeout" "$BRASH_BIN" "./$_name.tests") 2>&1
        fi
        _rc=$?
        if [ "$_rc" -ne 124 ] || [ "$_attempt" -ge 2 ]; then
            return $_rc
        fi
        _attempt=$((_attempt + 1))
    done
}

# Run the oracle on one test, printing its output.
run_oracle() {
    _name=$1
    _timeout=$2
    case "$_name" in
        glob) rm -rf "$HOME/ಇಳಿಕೆಗಳು" ;;
    esac
    if [ "$_name" = "dbg-support" ]; then
        (cd "$TEST_DIR" && env -i HOME="$HOME" PATH=".:$PATH" BASH_ORACLE="$BASH_ORACLE" BUILD_DIR="$BUILD_DIR" THIS_SH="$BASH_ORACLE" TMPDIR="${TMPDIR:-/tmp}" USER="${USER:-}" LOGNAME="${LOGNAME:-}" TERM="${TERM:-dumb}" SHELL="$BASH_ORACLE" BRASH_TEST_MODE=1 "$TIMEOUT_CMD" $TIMEOUT_FG "$_timeout" "$BASH_ORACLE" "./$_name.tests" < /dev/null) 2>&1
    else
        (cd "$TEST_DIR" && env -i HOME="$HOME" PATH=".:$PATH" BASH_ORACLE="$BASH_ORACLE" BUILD_DIR="$BUILD_DIR" THIS_SH="$BASH_ORACLE" TMPDIR="${TMPDIR:-/tmp}" USER="${USER:-}" LOGNAME="${LOGNAME:-}" TERM="${TERM:-dumb}" SHELL="$BASH_ORACLE" BRASH_TEST_MODE=1 "$TIMEOUT_CMD" $TIMEOUT_FG "$_timeout" "$BASH_ORACLE" "./$_name.tests") 2>&1
    fi
}

passed=0
failed=0
hung=0
skipped=0
total=0

# Allow filtering by test name
filter="${1:-}"

for test_file in "$TEST_DIR"/*.tests; do
    name=$(basename "$test_file" .tests)
    right_file="$TEST_DIR/$name.right"
    [ -f "$right_file" ] || continue

    # Filter if specified
    if [ -n "$filter" ] && [ "$name" != "$filter" ]; then
        continue
    fi

    reason=$(skip_reason "$name")
    if [ -n "$reason" ]; then
        printf "SKIP: %s (%s)\n" "$name" "$reason"
        skipped=$((skipped + 1))
        continue
    fi

    total=$((total + 1))

    # Use per-test timeout override if set
    this_timeout="$(get_timeout_override "$name")"
    this_timeout="${this_timeout:-$TIMEOUT_SECS}"

    tmpout=$(mktemp)
    this_sh_path="$BRASH_BIN"
    if needs_bash_basename "$name"; then
        ln -sf "$BRASH_BIN" "$RECHO_DIR/bash"
        this_sh_path="$RECHO_DIR/bash"
    fi
    case "$name" in
        glob)
            rm -rf "$HOME/ಇಳಿಕೆಗಳು"
            ;;
    esac
    # Run from the tests directory so relative source paths (*.sub) work
    # Use env -i to strip Claude Code env vars that would pollute declare output
    # Bash test suite merges stderr into stdout (2>&1) for comparison
    # Use relative path (./$name.tests) so $0 in error messages matches .right files
    run_brash "$name" "$this_timeout" "$this_sh_path" > "$tmpout" 2>&1
    rc=$?

    # Capture brash's output once, normalised.
    if needs_catv "$name"; then
        raw_actual=$(cat -v "$tmpout")
    else
        raw_actual=$(cat "$tmpout")
    fi
    if needs_expect_filter "$name"; then
        raw_actual=$(printf '%s\n' "$raw_actual" | grep -v '^expect')
    fi
    actual=$(normalise_output "$name" "$raw_actual")
    rm -f "$tmpout"

    if [ -n "${BRASH_KEEP_ACTUAL:-}" ]; then
        printf '%s\n' "$actual" > "/tmp/brash-${name}.actual"
    fi

    # The checked-in expectation.
    if needs_catv "$name"; then
        raw_expected=$(cat -v "$right_file")
    else
        raw_expected=$(cat "$right_file")
    fi
    if needs_expect_filter "$name"; then
        raw_expected=$(printf '%s\n' "$raw_expected" | grep -v '^expect')
    fi
    expected=$(normalise_output "$name" "$(normalise_right "$name" "$raw_expected")")

    if [ "$rc" -ne 124 ] && [ "$actual" = "$expected" ]; then
        printf "PASS: %s\n" "$name"
        passed=$((passed + 1))
        continue
    fi

    # brash differs from the .right file (or timed out).  The file records
    # what bash printed on the machine that generated it, which is not always
    # what bash prints here — a missing controlling terminal, a locale the
    # host lacks, a dlopen that behaves differently.  Ask the oracle: if it
    # reproduces the .right file, brash is wrong; if it does not, compare the
    # two shells to each other under the conditions we actually have.
    if [ ! -x "$BASH_ORACLE" ]; then
        if [ "$rc" -eq 124 ]; then
            printf "HANG: %s\n" "$name"
            hung=$((hung + 1))
        else
            diff_count=$(diff <(printf '%s\n' "$actual") <(printf '%s\n' "$expected") | grep -c '^[<>]')
            printf "FAIL: %s (%s)\n" "$name" "$diff_count"
            failed=$((failed + 1))
        fi
        continue
    fi

    oracle_raw=$(run_oracle "$name" "$this_timeout")
    oracle_rc=$?
    if needs_catv "$name"; then
        oracle_raw=$(printf '%s\n' "$oracle_raw" | cat -v)
    fi
    if needs_expect_filter "$name"; then
        oracle_raw=$(printf '%s\n' "$oracle_raw" | grep -v '^expect')
    fi
    oracle=$(normalise_output "$name" "$oracle_raw")

    if [ "$rc" -eq 124 ] && [ "$oracle_rc" -ne 124 ]; then
        printf "HANG: %s\n" "$name"
        hung=$((hung + 1))
        continue
    fi

    if [ "$oracle" = "$expected" ]; then
        # The .right file holds on this host, so the difference is brash's.
        diff_count=$(diff <(printf '%s\n' "$actual") <(printf '%s\n' "$expected") | grep -c '^[<>]')
        printf "FAIL: %s (%s)\n" "$name" "$diff_count"
        failed=$((failed + 1))
    elif [ "$actual" = "$oracle" ]; then
        printf "PASS: %s (host differs from .right; matched live bash)\n" "$name"
        passed=$((passed + 1))
    else
        # Comparing two live runs is timing-sensitive — trap.tests waits on
        # real children — so take a second sample of both before calling it.
        retry_actual=$(normalise_output "$name" "$(run_brash "$name" "$this_timeout" "$this_sh_path")")
        retry_oracle=$(normalise_output "$name" "$(run_oracle "$name" "$this_timeout")")
        if [ "$retry_actual" = "$retry_oracle" ]; then
            printf "PASS: %s (host differs from .right; matched live bash)\n" "$name"
            passed=$((passed + 1))
        else
            diff_count=$(diff <(printf '%s\n' "$retry_actual") <(printf '%s\n' "$retry_oracle") | grep -c '^[<>]')
            printf "FAIL: %s (%s vs live bash)\n" "$name" "$diff_count"
            failed=$((failed + 1))
        fi
    fi
done

rm -rf "$RECHO_DIR"

if [ "$skipped" -gt 0 ]; then
    printf "\n=== %d passed, %d failed, %d hung, %d skipped, %d total ===\n" \
        "$passed" "$failed" "$hung" "$skipped" "$total"
else
    printf "\n=== %d passed, %d failed, %d hung, %d total ===\n" "$passed" "$failed" "$hung" "$total"
fi
