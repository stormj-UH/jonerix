# brash TODO

## Completed: bash upstream test suite — 82/82

All 82 bash 5.3 upstream tests pass.  128 unit tests.  Zero compiler
warnings.  18 differential corpora (1100+ byte-identical tests) all green.

### v1.0.13 security & audit (done)

- Recursion depth limits: expansion 1024, FUNCNEST 1000, eval 256, source 256
- SAFETY comments on all 156 unsafe blocks
- PROVEN comments on all 148 unwrap/expect calls
- Invariant ledgers on all 9 modules (>500 lines)
- Copyright headers on all source files
- Performance: byte-scan in has_expansion_chars, pre-allocated buffers

## Now: deeper hardening & architecture

### 1. Newtype introduction

Replace ambiguous raw types with domain newtypes:

- `expand_impl_full` has 4 boolean flags (`in_dquote`, `for_pattern`,
  `for_assignment`, `for_case_pattern`) — replace with a typed
  `ExpansionContext` enum or bitflags
- Raw `i32` used for PIDs, signal numbers, file descriptors — introduce
  `Pid(i32)`, `Signal(i32)`, `Fd(i32)` newtypes
- Exit status is `i32` in many places — introduce `ExitStatus(i32)`

### 2. "Messy shell, pure core" architecture split

The expansion engine and arithmetic evaluator are already pure (no fork,
no I/O, no terminal), but the boundary is implicit.  Make it explicit:

- Extract `expand.rs` + `arithmetic.rs` + `vars.rs` into a `core/` module
  with a clean trait boundary (no access to `exec::ShellState` directly)
- `exec.rs` and `builtins.rs` form the "messy shell" that owns I/O, fork,
  signals, terminal

### 3. Make illegal states unrepresentable

- AST nodes currently use `Option<Vec<...>>` where an empty vec would do
- Pipeline direction (foreground/background) is a bool — make it an enum
- Redirect targets use raw strings — introduce typed variants

### 4. Broader compatibility testing

#### Differential fuzzing

Generate random valid shell scripts, run under both bash and brash, diff
outputs.  AFL++ in differential mode or a custom seeded generator.

#### Boot tests

Replace `/bin/sh` with brash on a minimal Linux (Alpine/Debian), verify
init scripts run cleanly, package builds succeed.

#### Bash manual feature matrix

Markdown checklist of every documented feature (builtins × flags, set
options, shopt options, BASH_* variables, expansion forms, special
variables) × implementation status.

## Backlog

- Coverage-guided fuzz harness (100 programs/sec, diff against bash)
- `shellbench` performance parity benchmarks
- POSIX conformance testing (dash suite, Open Group subset)
