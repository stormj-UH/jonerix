# Brash Feature Matrix

Comprehensive checklist of Bash 5.3 features and their implementation status in brash.

- ✅ Implemented
- ⚠️ Partial
- ❌ Missing

---

## 1. Builtins × Flags

### echo

| Flag | Status | Notes |
|------|--------|-------|
| -n   | ✅     | suppress trailing newline |
| -e   | ✅     | enable escape sequences |
| -E   | ✅     | disable escape sequences |

### printf

| Flag | Status | Notes |
|------|--------|-------|
| -v var | ✅   | assign to variable |

### read

| Flag | Status | Notes |
|------|--------|-------|
| -r   | ✅     | raw mode (no backslash escapes) |
| -s   | ✅     | silent mode (no echo) |
| -p prompt | ✅ | prompt string |
| -a array  | ✅ | read into array |
| -d delim  | ✅ | custom delimiter |
| -n nchars | ✅ | read N characters |
| -N nchars | ✅ | read exactly N characters |
| -t timeout | ✅ | timeout in seconds |
| -u fd     | ✅ | read from file descriptor |
| -e        | ⚠️ | accepted, readline not wired |
| -E        | ⚠️ | accepted, readline not wired |
| -i text   | ⚠️ | accepted, ignored |

### declare / typeset / local

| Flag | Status | Notes |
|------|--------|-------|
| -a   | ✅     | indexed array |
| -A   | ✅     | associative array |
| -i   | ✅     | integer attribute |
| -r   | ✅     | readonly |
| -x   | ✅     | export |
| -l   | ✅     | lowercase |
| -u   | ✅     | uppercase |
| -c   | ✅     | capitalize |
| -p   | ✅     | print declarations |
| -f   | ✅     | functions only |
| -F   | ✅     | function names only |
| -g   | ✅     | global scope |
| -n   | ✅     | nameref |
| -t   | ✅     | trace |
| -I   | ✅     | local inherit |
| +flag | ✅    | removal of attribute with + prefix |

### export

| Flag | Status | Notes |
|------|--------|-------|
| -p   | ✅     | print all exports |
| -n   | ✅     | unexport |
| -f   | ✅     | export function |
| -a   | ✅     | accepted |
| -A   | ✅     | accepted |

### readonly

| Flag | Status | Notes |
|------|--------|-------|
| -p   | ✅     | print readonly vars |
| -f   | ✅     | functions |
| -a   | ✅     | arrays |
| -A   | ✅     | associative arrays |
| -n   | ✅     | silently accepted for compat |

### unset

| Flag | Status | Notes |
|------|--------|-------|
| -f   | ✅     | unset function |
| -v   | ✅     | unset variable |
| -n   | ✅     | unset nameref itself |

### set

| Flag | Status | Notes |
|------|--------|-------|
| -a   | ✅     | allexport |
| -b   | ✅     | notify |
| -e   | ✅     | errexit |
| -f   | ✅     | noglob |
| -h   | ✅     | hashall |
| -k   | ✅     | keyword |
| -m   | ✅     | monitor |
| -n   | ✅     | noexec |
| -p   | ✅     | privileged |
| -t   | ✅     | onecmd |
| -u   | ✅     | nounset |
| -v   | ✅     | verbose |
| -x   | ✅     | xtrace |
| -B   | ✅     | braceexpand |
| -C   | ✅     | noclobber |
| -E   | ✅     | errtrace |
| -H   | ✅     | histexpand |
| -P   | ✅     | physical |
| -T   | ✅     | functrace |
| -I   | ✅     | accepted |
| -r   | ✅     | restricted (accepted) |
| -o name | ✅  | set by long option name |
| +o name | ✅  | unset by long option name |
| --   | ✅     | end of options / set positional params |
| -    | ✅     | unset -x and -v, end option parsing |

### cd

| Flag | Status | Notes |
|------|--------|-------|
| -P   | ✅     | physical (resolve symlinks) |
| -L   | ✅     | logical (follow symlinks) |
| -e   | ⚠️     | accepted, ignored |

### pwd

| Flag | Status | Notes |
|------|--------|-------|
| -P   | ✅     | physical path |
| -L   | ✅     | logical path |

### test / [

| Flag | Status | Notes |
|------|--------|-------|
| (all operators) | ✅ | see Conditional Expressions section |

### exec

| Flag | Status | Notes |
|------|--------|-------|
| -c   | ✅     | clear environment |
| -l   | ✅     | login shell (prefix argv0 with -) |
| -a name | ✅  | override argv[0] |

### type

| Flag | Status | Notes |
|------|--------|-------|
| -t   | ✅     | print type word only |
| -a   | ✅     | show all occurrences |
| -p   | ✅     | path only |
| -P   | ✅     | force PATH search |
| -f   | ⚠️     | suppress function lookup (accepted, ignored) |

### command

| Flag | Status | Notes |
|------|--------|-------|
| -v   | ✅     | which mode |
| -V   | ✅     | verbose which |
| -p   | ✅     | default PATH |

### trap

| Flag | Status | Notes |
|------|--------|-------|
| -l   | ✅     | list signals |
| -p   | ✅     | print traps |
| -P   | ✅     | print raw action |

### kill

| Flag | Status | Notes |
|------|--------|-------|
| -l   | ✅     | list signals |
| -L   | ✅     | list signals |
| -s sigspec | ✅ | signal by name |
| -n signum  | ✅ | signal by number |
| -sigspec   | ✅ | signal shorthand |

### jobs

| Flag | Status | Notes |
|------|--------|-------|
| -p   | ✅     | PIDs only |
| -r   | ✅     | running only |
| -s   | ✅     | stopped only |
| -l   | ⚠️     | accepted, no extra info |
| -n   | ⚠️     | accepted, no filtering |
| -x   | ❌     | run command replacing job |

### wait

| Flag | Status | Notes |
|------|--------|-------|
| -n   | ✅     | wait for any |
| -f   | ⚠️     | accepted, no foreground wait enforcement |
| -p var | ✅   | assign PID to variable |

### disown

| Flag | Status | Notes |
|------|--------|-------|
| -a   | ✅     | all jobs |
| -r   | ✅     | running only |
| -h   | ✅     | mark for SIGHUP suppression |

### hash

| Flag | Status | Notes |
|------|--------|-------|
| -r   | ✅     | clear table |
| -p path | ✅  | add explicit path |
| -d   | ✅     | delete entry |
| -l   | ✅     | list long form |
| -t   | ✅     | show path for names |

### enable

| Flag | Status | Notes |
|------|--------|-------|
| -p   | ✅     | print enabled |
| -s   | ✅     | POSIX special builtins only |
| -n   | ✅     | list/set disabled |
| -a   | ✅     | list all with state |
| -d   | ✅     | dynamically loaded (errors correctly) |
| -f   | ⚠️     | accepted, no loadable module support |

### shopt

| Flag | Status | Notes |
|------|--------|-------|
| -s   | ✅     | set option |
| -u   | ✅     | unset option |
| -p   | ✅     | print in set form |
| -q   | ✅     | quiet mode |
| -o   | ✅     | operate on set -o options |

### getopts

| Flag | Status | Notes |
|------|--------|-------|
| (no flags) | ✅ | full POSIX getopts implementation |

### mapfile / readarray

| Flag | Status | Notes |
|------|--------|-------|
| -d delim | ✅ | custom delimiter |
| -n count | ✅ | max lines |
| -O origin | ✅ | starting index |
| -s count | ✅ | skip lines |
| -t   | ✅     | strip delimiter |
| -u fd | ✅    | read from fd |
| -C callback | ✅ | callback function |
| -c quantum  | ✅ | callback quantum |

### history

| Flag | Status | Notes |
|------|--------|-------|
| -c   | ✅     | clear history |
| -d   | ✅     | delete entry |
| -a   | ✅     | append to file |
| -r   | ✅     | read from file |
| -w   | ✅     | write to file |
| -n   | ✅     | read new entries |
| -p   | ✅     | history expansion |
| -s   | ✅     | add to history |

### fc

| Flag | Status | Notes |
|------|--------|-------|
| -l   | ✅     | list |
| -n   | ✅     | strip numbers |
| -r   | ✅     | reverse |
| -s   | ✅     | substitute and re-execute |
| -e editor | ✅ | specify editor |

### bind

| Flag | Status | Notes |
|------|--------|-------|
| -v   | ✅     | print readline variables |
| -V   | ✅     | verbose readline variables |
| -f file | ✅  | read key bindings from file |
| -m keymap | ⚠️ | accepted, ignored |
| -p   | ⚠️     | accepted |
| -P   | ⚠️     | accepted |
| -s   | ⚠️     | accepted |
| -S   | ⚠️     | accepted |
| -l   | ⚠️     | accepted |
| -q   | ⚠️     | accepted |
| -r   | ⚠️     | accepted |
| -u   | ⚠️     | accepted |
| -x   | ⚠️     | accepted |
| -X   | ⚠️     | accepted |

### umask

| Flag | Status | Notes |
|------|--------|-------|
| -S   | ✅     | symbolic output |
| -p   | ✅     | print re-executable form |

### ulimit

| Flag | Status | Notes |
|------|--------|-------|
| -S   | ✅     | soft limit |
| -H   | ✅     | hard limit |
| -a   | ✅     | show all |
| -c   | ✅     | core file size |
| -d   | ✅     | data seg size |
| -f   | ✅     | file size |
| -l   | ✅     | locked memory |
| -m   | ✅     | max memory |
| -n   | ✅     | open files |
| -s   | ✅     | stack size |
| -t   | ✅     | cpu time |
| -u   | ✅     | max user processes |
| -v   | ✅     | virtual memory |
| -i   | ❌     | pending signals |
| -P   | ❌     | pseudoterminals |
| -R   | ❌     | RTPRIO |
| -T   | ❌     | threads |
| -b   | ❌     | socket buffer size |
| -e   | ❌     | scheduling priority |
| -k   | ❌     | kqueues |
| -p   | ❌     | pipe size |
| -q   | ❌     | message queue size |
| -r   | ❌     | real-time priority |
| -x   | ❌     | file locks |

### dirs

| Flag | Status | Notes |
|------|--------|-------|
| -l   | ✅     | long listing (no tilde) |
| -p   | ✅     | one entry per line |
| -c   | ✅     | clear directory stack |
| -v   | ✅     | verbose (numbered) |
| +N   | ✅     | Nth entry from left |
| -N   | ✅     | Nth entry from right |

### pushd

| Flag | Status | Notes |
|------|--------|-------|
| -n   | ✅     | no cd, just manipulate stack |
| +N   | ✅     | rotate from left |
| -N   | ✅     | rotate from right |

### popd

| Flag | Status | Notes |
|------|--------|-------|
| -n   | ✅     | no cd, just remove from stack |
| +N   | ✅     | remove Nth from left |
| -N   | ✅     | remove Nth from right |

### complete

| Flag | Status | Notes |
|------|--------|-------|
| -a   | ✅     | alias |
| -b   | ✅     | builtin |
| -c   | ✅     | command |
| -d   | ✅     | directory |
| -e   | ✅     | export |
| -f   | ✅     | file |
| -g   | ✅     | group |
| -j   | ✅     | job |
| -k   | ✅     | keyword |
| -s   | ✅     | service |
| -u   | ✅     | user |
| -v   | ✅     | variable |
| -p   | ✅     | print |
| -r   | ✅     | remove |
| -D   | ✅     | default |
| -E   | ✅     | empty |
| -I   | ✅     | initial word |
| -o option | ✅ | compopt options |
| -A action | ✅ | action |
| -G globpat | ✅ | glob pattern |
| -W wordlist | ✅ | word list |
| -F function | ✅ | function |
| -C command | ✅ | command |
| -X filterpat | ✅ | filter pattern |
| -P prefix | ✅ | prefix |
| -S suffix | ✅ | suffix |

### compgen

| Flag | Status | Notes |
|------|--------|-------|
| -V varname | ✅ | assign to variable |
| (same as complete) | ✅ | shares flags with complete |

### compopt

| Flag | Status | Notes |
|------|--------|-------|
| -o option | ✅ | set option |
| +o option | ✅ | unset option |
| -D   | ✅     | default |
| -E   | ✅     | empty |
| -I   | ✅     | initial word |

### caller

| Flag | Status | Notes |
|------|--------|-------|
| [expr] | ✅   | stack frame number |

### suspend

| Flag | Status | Notes |
|------|--------|-------|
| -f   | ✅     | force (even if login shell) |

### Other builtins (no flags)

| Builtin | Status | Notes |
|---------|--------|-------|
| true    | ✅     | |
| false   | ✅     | |
| :       | ✅     | |
| eval    | ✅     | |
| source / . | ✅ | |
| exit    | ✅     | |
| return  | ✅     | |
| break   | ✅     | |
| continue | ✅    | |
| shift   | ✅     | |
| let     | ✅     | |
| alias   | ✅     | |
| unalias | ✅     | with -a flag |
| builtin | ✅     | |
| times   | ✅     | |
| fg      | ✅     | |
| bg      | ✅     | |
| logout  | ✅     | |
| help    | ✅     | |

---

## 2. Set Options (`set -o`)

| Long Name | Short | Status | Notes |
|-----------|-------|--------|-------|
| allexport | -a | ✅ | |
| braceexpand | -B | ✅ | |
| emacs | (none) | ✅ | |
| errexit | -e | ✅ | |
| errtrace | -E | ✅ | |
| functrace | -T | ✅ | |
| hashall | -h | ✅ | |
| histexpand | -H | ✅ | |
| history | (none) | ✅ | |
| ignoreeof | (none) | ✅ | |
| interactive-comments | (none) | ✅ | |
| keyword | -k | ✅ | |
| monitor | -m | ✅ | |
| noclobber | -C | ✅ | |
| noexec | -n | ✅ | |
| noglob | -f | ✅ | |
| nolog | (none) | ✅ | accepted (no effect per spec) |
| notify | -b | ✅ | |
| nounset | -u | ✅ | |
| onecmd | -t | ✅ | |
| physical | -P | ✅ | |
| pipefail | (none) | ✅ | |
| posix | (none) | ✅ | |
| privileged | -p | ✅ | |
| verbose | -v | ✅ | |
| vi | (none) | ✅ | |
| xtrace | -x | ✅ | |

---

## 3. Shopt Options

| Option | Status | Notes |
|--------|--------|-------|
| array_expand_once | ✅ | |
| assoc_expand_once | ✅ | |
| autocd | ✅ | |
| bash_source_fullpath | ✅ | |
| cdable_vars | ✅ | |
| cdspell | ✅ | |
| checkhash | ✅ | |
| checkjobs | ✅ | |
| checkwinsize | ✅ | default on |
| cmdhist | ✅ | default on |
| compat31 | ✅ | |
| compat32 | ✅ | |
| compat40 | ✅ | |
| compat41 | ✅ | |
| compat42 | ✅ | |
| compat43 | ✅ | |
| compat44 | ✅ | |
| complete_fullquote | ✅ | default on |
| direxpand | ✅ | |
| dirspell | ✅ | |
| dotglob | ✅ | |
| execfail | ✅ | |
| expand_aliases | ✅ | on in interactive mode |
| extdebug | ✅ | |
| extglob | ✅ | |
| extquote | ✅ | default on |
| failglob | ✅ | |
| force_fignore | ✅ | default on |
| globasciiranges | ✅ | default on |
| globskipdots | ✅ | default on |
| globstar | ✅ | |
| gnu_errfmt | ✅ | |
| histappend | ✅ | |
| histreedit | ✅ | |
| histverify | ✅ | |
| hostcomplete | ✅ | default on |
| huponexit | ✅ | |
| inherit_errexit | ✅ | |
| interactive_comments | ✅ | default on |
| lastpipe | ✅ | |
| lithist | ✅ | |
| localvar_inherit | ✅ | |
| localvar_unset | ✅ | |
| login_shell | ✅ | |
| mailwarn | ✅ | |
| no_empty_cmd_completion | ✅ | |
| nocaseglob | ✅ | |
| nocasematch | ✅ | |
| noexpand_translation | ✅ | |
| nullglob | ✅ | |
| patsub_replacement | ✅ | default on |
| progcomp | ✅ | default on |
| progcomp_alias | ✅ | |
| promptvars | ✅ | default on |
| restricted_shell | ✅ | |
| shift_verbose | ✅ | |
| sourcepath | ✅ | default on |
| varredir_close | ✅ | |
| xpg_echo | ✅ | |

---

## 4. BASH_* Variables

| Variable | Status | Notes |
|----------|--------|-------|
| BASH | ✅ | path to shell executable |
| BASH_ALIASES | ✅ | associative array mirror of alias table |
| BASH_ARGC | ✅ | array of argument counts per stack frame |
| BASH_ARGV | ✅ | flattened array of arguments per stack frame |
| BASH_ARGV0 | ✅ | dynamic: reflects and can set $0 |
| BASH_CMDS | ✅ | associative array mirror of hash table |
| BASH_COMMAND | ✅ | command currently executing |
| BASH_COMPAT | ❌ | |
| BASH_ENV | ✅ | checked on startup for non-interactive shells |
| BASH_EXECUTION_STRING | ❌ | |
| BASH_LINENO | ✅ | array of line numbers per stack frame |
| BASH_LOADABLES_PATH | ❌ | no loadable builtin support |
| BASH_MONOSECONDS | ❌ | bash 5.3 new feature |
| BASH_REMATCH | ✅ | populated by [[ =~ ]] |
| BASH_SOURCE | ✅ | array of source files per stack frame |
| BASH_SUBSHELL | ✅ | incremented in subshells |
| BASH_TRAPSIG | ✅ | signal number that triggered current trap |
| BASH_VERSINFO | ✅ | version info array |
| BASH_VERSION | ✅ | version string |
| BASH_XTRACEFD | ✅ | fd for xtrace output |
| BASHPID | ✅ | dynamic: current PID (subshell aware) |
| BASHOPTS | ✅ | colon-separated shopt options |

---

## 5. Special Variables

### Automatic / dynamic

| Variable | Status | Notes |
|----------|--------|-------|
| $? | ✅ | last exit status |
| $$ | ✅ | original shell PID |
| $! | ✅ | last background PID |
| $0 | ✅ | shell or script name |
| $# | ✅ | positional parameter count |
| $@ | ✅ | all positional parameters (separate words) |
| $* | ✅ | all positional parameters (joined) |
| $- | ✅ | current option flags |
| $_ | ✅ | last argument of previous command |
| PIPESTATUS | ✅ | array of pipeline exit statuses |
| FUNCNAME | ✅ | array of function call stack names |
| LINENO | ✅ | current line number |
| GROUPS | ✅ | array of supplementary group IDs |
| DIRSTACK | ✅ | array of directory stack |
| COMP_LINE | ✅ | current completion line |
| COMP_POINT | ✅ | cursor position for completion |
| COMP_CWORD | ✅ | current word index for completion |
| COMP_WORDBREAKS | ✅ | word break characters for completion |
| COMP_WORDS | ✅ | array of words in completion line |

### Time-related

| Variable | Status | Notes |
|----------|--------|-------|
| SECONDS | ✅ | seconds since shell start |
| EPOCHSECONDS | ✅ | Unix epoch seconds |
| EPOCHREALTIME | ✅ | Unix epoch with microseconds |
| SRANDOM | ❌ | cryptographic random number |
| RANDOM | ✅ | pseudo-random number (0-32767) |

### Identity / system

| Variable | Status | Notes |
|----------|--------|-------|
| BASH | ✅ | path to shell |
| HOSTNAME | ✅ | |
| HOSTTYPE | ✅ | architecture |
| MACHTYPE | ✅ | full machine type |
| OSTYPE | ✅ | operating system type |
| UID | ✅ | real user ID |
| EUID | ✅ | effective user ID |
| PPID | ✅ | parent process ID |
| SHLVL | ✅ | shell nesting level |
| SHELL | ✅ | |

### Configuration / behavior

| Variable | Status | Notes |
|----------|--------|-------|
| IFS | ✅ | input field separator |
| HOME | ✅ | |
| PATH | ✅ | |
| PWD | ✅ | |
| OLDPWD | ✅ | |
| CDPATH | ✅ | |
| PS1 | ✅ | primary prompt |
| PS2 | ✅ | continuation prompt |
| PS3 | ❌ | select prompt |
| PS4 | ✅ | xtrace prompt |
| PROMPT_COMMAND | ✅ | |
| PROMPT_DIRTRIM | ✅ | |
| OPTIND | ✅ | getopts index |
| OPTARG | ✅ | getopts argument |
| OPTERR | ✅ | getopts error flag |
| REPLY | ✅ | default read variable |
| MAPFILE | ✅ | default mapfile variable |
| TMOUT | ✅ | timeout for read/interactive |
| COLUMNS | ✅ | terminal width |
| LINES | ✅ | terminal height |
| IGNOREEOF | ✅ | |
| TIMEFORMAT | ✅ | |
| FUNCNEST | ✅ | max function nesting depth |
| POSIXLY_CORRECT | ✅ | enables POSIX mode when set |

### History

| Variable | Status | Notes |
|----------|--------|-------|
| HISTFILE | ✅ | |
| HISTSIZE | ✅ | |
| HISTFILESIZE | ✅ | |
| HISTCONTROL | ✅ | |
| HISTIGNORE | ✅ | |
| HISTTIMEFORMAT | ✅ | |
| HISTCMD | ❌ | |
| histchars | ✅ | |

### Mail

| Variable | Status | Notes |
|----------|--------|-------|
| MAIL | ✅ | |
| MAILCHECK | ✅ | |
| MAILPATH | ✅ | |

### Completion / readline

| Variable | Status | Notes |
|----------|--------|-------|
| INPUTRC | ✅ | |
| FIGNORE | ✅ | |
| FCEDIT | ⚠️ | used by fc |
| GLOBIGNORE | ✅ | |
| EXECIGNORE | ❌ | |
| CHILD_MAX | ❌ | |
| BASH_LOADABLES_PATH | ❌ | |
| COPROC | ✅ | array for coproc fds |
| SHELLOPTS | ✅ | colon-separated set options |
| ENV | ✅ | checked in restricted mode |
| TMPDIR | ❌ | |

---

## 6. Expansion Forms

### Parameter expansion (basic)

| Form | Status | Notes |
|------|--------|-------|
| $name | ✅ | |
| ${name} | ✅ | |
| ${name:-default} | ✅ | use default if unset or null |
| ${name-default} | ✅ | use default if unset |
| ${name:=default} | ✅ | assign default if unset or null |
| ${name=default} | ✅ | assign default if unset |
| ${name:+alt} | ✅ | use alt if set and non-null |
| ${name+alt} | ✅ | use alt if set |
| ${name:?error} | ✅ | error if unset or null |
| ${name?error} | ✅ | error if unset |

### String operations

| Form | Status | Notes |
|------|--------|-------|
| ${#name} | ✅ | string length |
| ${name#pattern} | ✅ | remove shortest prefix |
| ${name##pattern} | ✅ | remove longest prefix |
| ${name%pattern} | ✅ | remove shortest suffix |
| ${name%%pattern} | ✅ | remove longest suffix |
| ${name/pat/repl} | ✅ | first substitution |
| ${name//pat/repl} | ✅ | global substitution |
| ${name/#pat/repl} | ✅ | anchored at start |
| ${name/%pat/repl} | ✅ | anchored at end |

### Case modification

| Form | Status | Notes |
|------|--------|-------|
| ${name^pattern} | ✅ | uppercase first match |
| ${name^^pattern} | ✅ | uppercase all matches |
| ${name,pattern} | ✅ | lowercase first match |
| ${name,,pattern} | ✅ | lowercase all matches |
| ${name~pattern} | ✅ | toggle case first match |
| ${name~~pattern} | ✅ | toggle case all matches |

### Substring / slicing

| Form | Status | Notes |
|------|--------|-------|
| ${name:offset} | ✅ | substring from offset |
| ${name:offset:length} | ✅ | substring with length |
| ${@:offset:length} | ✅ | positional parameter slice |
| ${arr[@]:offset:length} | ✅ | array element slice |

### Indirection and prefix

| Form | Status | Notes |
|------|--------|-------|
| ${!name} | ✅ | indirect expansion |
| ${!prefix*} | ✅ | variable names matching prefix |
| ${!prefix@} | ✅ | variable names matching prefix (separate words) |
| ${!arr[@]} | ✅ | array keys |
| ${!arr[*]} | ✅ | array keys (joined) |

### Parameter transformation (`${name@op}`)

| Operator | Status | Notes |
|----------|--------|-------|
| @Q | ✅ | shell-quoted |
| @E | ✅ | expand escape sequences |
| @A | ✅ | assignment form |
| @a | ✅ | attribute flags |
| @U | ✅ | uppercase |
| @u | ✅ | capitalize first |
| @L | ✅ | lowercase |
| @K | ✅ | key-value form |
| @k | ✅ | key-value form (lowercase variant) |
| @P | ✅ | prompt expansion |

### Other expansions

| Form | Status | Notes |
|------|--------|-------|
| $((expr)) | ✅ | arithmetic expansion |
| $(command) | ✅ | command substitution |
| `command` | ✅ | command substitution (legacy) |
| <(command) | ✅ | process substitution (input) |
| >(command) | ✅ | process substitution (output) |
| {a,b,c} | ✅ | brace expansion (comma) |
| {a..z} | ✅ | brace expansion (sequence) |
| {1..10} | ✅ | brace expansion (numeric seq) |
| {01..10} | ✅ | brace expansion (zero-padded) |
| {a..z..2} | ✅ | brace expansion (with step) |
| ~  | ✅ | tilde expansion (HOME) |
| ~user | ✅ | tilde expansion (user home) |
| ~+ | ✅ | tilde expansion (PWD) |
| ~- | ✅ | tilde expansion (OLDPWD) |
| $'...' | ✅ | ANSI-C quoting |
| $"..." | ✅ | locale translation (accepted) |
| *.txt | ✅ | pathname expansion / globbing |
| **/ | ✅ | recursive globbing (globstar) |
| ?(pat) | ✅ | extended glob: zero or one |
| *(pat) | ✅ | extended glob: zero or more |
| +(pat) | ✅ | extended glob: one or more |
| @(pat) | ✅ | extended glob: exactly one |
| !(pat) | ✅ | extended glob: not matching |

---

## 7. Conditional Expressions

### `test` / `[` / `[[` unary operators

| Operator | Status | Notes |
|----------|--------|-------|
| -z string | ✅ | true if string is empty |
| -n string | ✅ | true if string is non-empty |
| -e file | ✅ | file exists |
| -f file | ✅ | regular file |
| -d file | ✅ | directory |
| -r file | ✅ | readable |
| -w file | ✅ | writable |
| -x file | ✅ | executable |
| -s file | ✅ | size > 0 |
| -L file | ✅ | symbolic link |
| -h file | ✅ | symbolic link (same as -L) |
| -p file | ✅ | named pipe (FIFO) |
| -S file | ✅ | socket |
| -b file | ✅ | block device |
| -c file | ✅ | character device |
| -g file | ✅ | setgid bit set |
| -u file | ✅ | setuid bit set |
| -k file | ✅ | sticky bit set |
| -O file | ✅ | owned by effective UID |
| -G file | ✅ | owned by effective GID |
| -N file | ✅ | modified since last access |
| -t fd   | ✅ | fd is a terminal |
| -v var  | ✅ | variable is set |
| -R var  | ✅ | variable is a nameref |
| -o opt  | ✅ | shell option is set |
| -a file | ✅ | file exists (deprecated, same as -e) |

### `test` / `[` / `[[` binary operators

| Operator | Status | Notes |
|----------|--------|-------|
| = | ✅ | string equality |
| == | ✅ | string equality (pattern in `[[`) |
| != | ✅ | string inequality |
| < | ✅ | string less than (lexicographic) |
| > | ✅ | string greater than (lexicographic) |
| -eq | ✅ | integer equal |
| -ne | ✅ | integer not equal |
| -lt | ✅ | integer less than |
| -le | ✅ | integer less or equal |
| -gt | ✅ | integer greater than |
| -ge | ✅ | integer greater or equal |
| -nt | ✅ | newer than (modification time) |
| -ot | ✅ | older than (modification time) |
| -ef | ✅ | same file (inode) |
| =~ | ✅ | regex match (`[[` only) |

### `test` / `[` / `[[` logical

| Operator | Status | Notes |
|----------|--------|-------|
| ! | ✅ | negation |
| -a | ✅ | AND (test/[ only, deprecated) |
| -o | ✅ | OR (test/[ only, deprecated) |
| && | ✅ | AND (`[[` only) |
| \|\| | ✅ | OR (`[[` only) |
| ( ) | ✅ | grouping |

---

## 8. Arithmetic

### Operators

| Operator | Status | Notes |
|----------|--------|-------|
| + - * / % | ✅ | basic arithmetic |
| ** | ✅ | exponentiation (right-associative) |
| ++ -- (prefix) | ✅ | pre-increment/decrement |
| ++ -- (postfix) | ✅ | post-increment/decrement |
| ! | ✅ | logical NOT |
| ~ | ✅ | bitwise NOT |
| << >> | ✅ | bit shift |
| & \| ^ | ✅ | bitwise AND, OR, XOR |
| && \|\| | ✅ | logical AND, OR |
| == != | ✅ | equality |
| < > <= >= | ✅ | relational |
| ? : | ✅ | ternary conditional |
| , | ✅ | comma (sequence) |
| = | ✅ | assignment |
| += -= *= /= %= | ✅ | compound assignment |
| &= \|= ^= | ✅ | bitwise compound assignment |
| <<= >>= | ✅ | shift compound assignment |
| **= | ✅ | exponentiation compound assignment |
| (expr) | ✅ | parenthesized grouping |

### Arithmetic features

| Feature | Status | Notes |
|---------|--------|-------|
| Integer literals (decimal) | ✅ | |
| Octal literals (0NNN) | ✅ | |
| Hex literals (0xNNN) | ✅ | |
| base#number literals | ✅ | |
| Variable references | ✅ | |
| Array subscripts | ✅ | |
| Nested expressions | ✅ | with recursion limit (1024) |
| (( expr )) command | ✅ | |
| $((expr)) expansion | ✅ | |
| let builtin | ✅ | |
| declare -i | ✅ | integer attribute |
| Division by zero error | ✅ | |
| 64-bit signed integers | ✅ | |

---

## 9. Shell Grammar / Syntax

| Feature | Status | Notes |
|---------|--------|-------|
| Simple commands | ✅ | |
| Pipelines | ✅ | |
| Lists (;  & && \|\|) | ✅ | |
| Compound commands | ✅ | |
| if/elif/else/fi | ✅ | |
| for/do/done | ✅ | |
| for ((;;)) | ✅ | C-style for loop |
| while/until/do/done | ✅ | |
| case/esac | ✅ | |
| select/do/done | ✅ | |
| (list) subshell | ✅ | |
| { list; } group | ✅ | |
| [[ expr ]] | ✅ | |
| (( expr )) | ✅ | |
| function name { } | ✅ | |
| name() { } | ✅ | |
| Coproc | ✅ | |
| time keyword | ✅ | |
| ! pipeline | ✅ | negation |
| Heredocs (<< and <<-) | ✅ | |
| Herestrings (<<<) | ✅ | |
| Redirections (> >> < etc.) | ✅ | |
| File descriptor duplication | ✅ | |
| &> and &>> | ✅ | |
| Process substitution in redir | ✅ | |
| {varname} fd assignment | ✅ | |

---

## 10. Miscellaneous Features

| Feature | Status | Notes |
|---------|--------|-------|
| Signal trapping | ✅ | |
| DEBUG trap | ✅ | |
| ERR trap | ✅ | |
| RETURN trap | ✅ | |
| EXIT trap | ✅ | |
| Job control (fg/bg/jobs) | ✅ | |
| Command hashing | ✅ | |
| Alias expansion | ✅ | |
| History expansion (!) | ✅ | |
| Programmable completion | ✅ | |
| Restricted shell (-r) | ✅ | |
| POSIX mode | ✅ | |
| Login shell processing | ✅ | |
| Interactive shell processing | ✅ | |
| Prompt expansion (\u, \h, \w, etc.) | ✅ | |
| Exported functions | ✅ | |
| Nameref variables | ✅ | |
| Associative arrays | ✅ | |
| Indexed arrays | ✅ | |
| Array assignment syntax | ✅ | |
| += append operator | ✅ | |
| Locale-dependent collation | ⚠️ | globasciiranges preferred |
| Network redirection (/dev/tcp) | ❌ | |
| Loadable builtins | ❌ | |
