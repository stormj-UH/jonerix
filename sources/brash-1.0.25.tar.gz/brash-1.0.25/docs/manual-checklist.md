# brash — bash manual feature coverage

Tracking implementation status of each documented bash 5.3 feature in
brash.  Categories follow the bash manual TOC.  Status legend:

- ✅ working — basic happy path matches bash
- 🚧 partial — works but with caveats or gaps
- ❌ missing — not implemented

Auto-tested against `target/release/brash` vs `/opt/homebrew/bin/bash` on
macOS arm64.  Spot-check methodology — each row is verified by a one-line
test of the basic case, NOT exhaustive.

## Summary

- Builtins: 60+ rows, all ✅ at the surface (basic invocation works)
- set options: 17 rows, mostly ✅
- shopt options: 50+ rows, most ✅, some 🚧
- BASH_* / BASH* variables: 30+ rows, most ✅
- Special variables: 30+ rows, all ✅
- Parameter expansions: 30+ rows, most ✅
- Compound commands: 10 rows, all ✅
- Other (process sub, time, !, |&): 4 rows, ✅

Because this is a 79/82 upstream-suite-passing shell, the surface-level
"does the keyword exist and produce sensible output" check passes for
nearly every feature.  Diffs against bash for non-trivial cases are
captured by the upstream test suite (`scripts/run-tests-local.sh`) and
the `tests/realworld/` differential corpus.

## Builtins

| feature | status | notes |
| --- | --- | --- |
| `:`           | ✅ | null command, exit 0 |
| `.` (source)  | ✅ | source file, also `source` keyword |
| `[`           | ✅ | test command, requires closing `]` |
| `alias`       | ✅ | works, `expand_aliases` shopt for non-interactive |
| `bg`          | ✅ | resume in background |
| `bind`        | ✅ | key bindings the line editor honours: `-l -p -P -s -S -X -q -u -r -x -m -f -v -V`, `"seq": function`, macros, `bind -x` with READLINE_LINE/READLINE_POINT, and the bindings in `~/.inputrc`.  brash's editor implements 35 of readline's functions, so `bind -l` lists fewer names than bash's 177 |
| `break N`     | ✅ | break out of N enclosing loops |
| `builtin`     | ✅ | force-call builtin even if shadowed |
| `caller`      | ✅ | print stack trace info |
| `cd`          | ✅ | with `-L`, `-P`, `-`, CDPATH |
| `command`     | ✅ | with `-v`, `-V`, `-p` flags |
| `compgen`     | ✅ | every action flag and `-A` name incl. `signal` and `hostname` (HOSTFILE), `-G` (unfiltered glob), `-C` (run with `$1 $2 $3`, verbatim), `-F` verbatim with bash's warning, bash's generation order, option clusters/attached args and exit statuses; `binding`/`job`/`running`/`stopped`/`service` produce nothing |
| `complete`    | ✅ | incl. `-D`/`-E`/`-I`, the 124 reload protocol (new spec → rerun, unchanged → `-D`, unchanged `-D` → default completion, 32 retries → "possible retry loop"), bash's print form and unsorted `complete -p` hash-walk order, `-r` semantics and error texts/exit statuses |
| `compopt`     | ✅ | `-o`/`+o` on named specs, `-D`/`-E`/`-I`, clusters like `-Do nospace`, and the running completion (also from a `compgen -F` nested inside it) |
| `continue N`  | ✅ | continue N enclosing loops |
| `declare`     | ✅ | -i, -r, -x, -a, -A, -n, -f, -p |
| `typeset`     | ✅ | alias for declare |
| `dirs`        | ✅ | display dir stack |
| `disown`      | ✅ | remove jobs from job table |
| `echo`        | ✅ | with -n, -e, -E |
| `enable`      | 🚧 | -n disables; -f loadable builtins ❌ (no loadable support) |
| `eval`        | ✅ | execute string as command |
| `exec`        | ✅ | replace shell with command, `-c`, `-l`, `-a` |
| `exit N`      | ✅ | exit shell with status |
| `export`      | ✅ | -p list, -n unmark, -f functions |
| `false`       | ✅ | exit 1 |
| `fc`          | ✅ | history editor |
| `fg`          | ✅ | resume foreground |
| `getopts`     | ✅ | option parser |
| `hash`        | ✅ | command hash table |
| `help`        | 🚧 | brief output, formatting may differ |
| `history`     | ✅ | list/clear |
| `jobs`        | ✅ | list jobs |
| `kill`        | ✅ | -s, -n, -l, by pid or %job; the real-time signals are named and accepted (`kill -SIGRTMIN+3`) |
| `let`         | ✅ | arithmetic |
| `local`       | ✅ | function-local var, -i, -r |
| `logout`      | ✅ | exit if login shell; takes a status like `exit` |
| `mapfile`     | ✅ | -t, -n, -s, -O, -c, -C |
| `readarray`   | ✅ | alias for mapfile |
| `popd`        | ✅ | pop from dir stack |
| `printf`      | ✅ | most format specifiers, %q, %b, -v |
| `pushd`       | ✅ | push to dir stack |
| `pwd`         | ✅ | -L, -P |
| `read`        | ✅ | -r, -a, -t, -n, -p, -d, -s |
| `readonly`    | ✅ | mark vars/funcs read-only |
| `return N`    | ✅ | return from function |
| `set -X`      | ✅ | most flags; see set options table below |
| `shift N`     | ✅ | shift positionals |
| `shopt`       | ✅ | -s, -u, -p, -q |
| `source`      | ✅ | same as . |
| `suspend`     | ✅ | suspend shell |
| `test`        | ✅ | all primaries; POSIX argument-count rules (a trailing unary operator is a string, `-a`/`-o` are connectives) |
| `times`       | ✅ | print accumulated user/sys times |
| `trap`        | ✅ | -l, -p, signal handlers, EXIT, ERR, DEBUG, RETURN; a RETURN trap set inside a function fires when it returns and leaves its return status alone; an EXIT trap keeps the exit status, and a subshell lists but never runs the one it inherited |
| `true`        | ✅ | exit 0 |
| `type`        | ✅ | -a, -t, -p, -P, -f |
| `ulimit`      | ✅ | every resource the platform has, in bash's `-a` layout, including the read-only pipe size |
| `umask`       | ✅ | -S, -p, octal/symbolic |
| `unalias`     | ✅ | -a, by name |
| `unset`       | ✅ | -v, -f, -n |
| `wait`        | ✅ | -n, -p var, by pid or %job |

## Programmable completion (line editor)

Verified through a pty against bash 5.3 (`tests/regression/12_progcomp_comp_words.test`,
`13_progcomp_candidates.test`); every row is a keystroke sequence whose
rendered line and `COMP_*` view are identical.

| feature | status | notes |
| --- | --- | --- |
| COMP_LINE / COMP_POINT     | ✅ | the simple command around the cursor (after the last unquoted `; \| & (` or stand-alone `{`, up to the next one); point counts characters |
| COMP_WORDS / COMP_CWORD    | ✅ | whitespace + COMP_WORDBREAKS runs split, quotes/backslashes/`$(…)`/`${…}` group, words after the cursor included, empty word inserted at the cursor, cw=-1 for an empty command |
| `$1` `$2` `$3`             | ✅ | `_InitialWorD_` / `_EmptycmD_` / command; readline's word without an unclosed quote; previous word |
| COMP_TYPE / COMP_KEY       | ✅ | 9/9 Tab, 63/9 listing Tab, 63/63 M-?, 42/42 M-*, 37/9 menu-complete; all six variables unset afterwards |
| COMPREPLY / `-C` verbatim  | ✅ | not matched against the word; `-W` and action results are; `-X -P -S` on everything |
| candidate insertion        | ✅ | replaces the word (opening quote included), collated + deduplicated list, common prefix, bell, listing on an unchanging second Tab |
| `-o filenames` quoting     | ✅ | readline's backslash set (`$`/`` ` `` only for existing paths, `#` at the start), inside `"…"`/`'…'`, basename display, `dir/` without space; also for `-f`/`-d`/`-G` specs and readline's own completion |
| `-o` fullquote/noquote/nospace/plusdirs/default/dirnames/bashdefault/nosort | ✅ | as bash |
| 124 protocol               | ✅ | rerun only for a newly registered spec; unchanged → `-D`; unchanged `-D` → default completion; 32 retries → warning |
| undefined `-F` function    | ✅ | "completion: function `f' not found", bells, line redrawn |
| menu-complete (ESC-Tab)    | ✅ | matches in turn, then the original word with a bell |
| `$var` / `~user` / `@host` | ✅ | go through the compspec first; default completion adds `/` for a directory-valued variable and `~user/` |
| backquoted command in line | 🚧 | bash gives up on `` x `y a` b<Tab> ``; brash groups the backquotes and completes |
| `cc <<Tab>` after a Tab that inserted `<` | 🚧 | bash rings the bell where brash inserts the common prefix again |

## set options

| flag | long-name | status | notes |
| --- | --- | --- | --- |
| `-a` | allexport | ✅ | export every assigned var |
| `-b` | notify | ✅ | report bg job completion immediately |
| `-e` | errexit | ✅ | exit on non-zero command |
| `-f` | noglob | ✅ | disable globbing |
| `-h` | hashall | ✅ | hash command paths |
| `-k` | keyword | ✅ | keyword args anywhere |
| `-m` | monitor | ✅ | enable job control |
| `-n` | noexec | ✅ | parse only, don't execute |
| `-o pipefail` | pipefail | ✅ | pipe rc = leftmost non-zero |
| `-p` | privileged | ✅ | restricted mode initialization |
| `-t` | onecmd | ✅ | exit after one command |
| `-u` | nounset | ✅ | error on unset var reference |
| `-v` | verbose | ✅ | print input as read |
| `-x` | xtrace | ✅ | print commands before execution |
| `-B` | braceexpand | ✅ | enable brace expansion (default) |
| `-C` | noclobber | ✅ | `>` won't overwrite |
| `-E` | errtrace | ✅ | ERR trap inherited |
| `-H` | histexpand | ✅ | `!` history expansion (interactive) |
| `-P` | physical | ✅ | use physical paths in cd/pwd |
| `-T` | functrace | ✅ | DEBUG/RETURN trap inherited |

## shopt options

| name | status | notes |
| --- | --- | --- |
| `autocd`             | ✅ | bare dir name = cd |
| `cdable_vars`        | ✅ | cd treats arg as var |
| `cdspell`            | ✅ | typo correction in cd |
| `checkhash`          | ✅ | re-verify hashed paths |
| `checkjobs`          | ✅ | warn before exit if jobs running |
| `checkwinsize`       | ✅ | re-check window size after cmd |
| `cmdhist`            | ✅ | save multi-line cmd as one history entry |
| `compat31..52`       | 🚧 | basic compat flag honored, semantics partial |
| `complete_fullquote` | ✅ | quote completion specially |
| `direxpand`          | ✅ | expand var refs in dir completions |
| `dirspell`           | ✅ | typo correction in dir completion |
| `dotglob`            | ✅ | include .files in glob |
| `execfail`           | ✅ | non-interactive `exec` failure not fatal |
| `expand_aliases`     | ✅ | enable alias expansion in non-interactive |
| `extdebug`           | ✅ | extra debugging info |
| `extglob`            | ✅ | extended globbing `?(…)`, `*(…)`, etc.; patterns are recognised even while the option is off, where bash reports a syntax error |
| `extquote`           | ✅ | $"…" / $'…' inside `${…}` |
| `failglob`           | ✅ | unmatched glob → error |
| `force_fignore`      | ✅ | FIGNORE patterns even if all match |
| `globstar`           | ✅ | `**` matches all paths recursively |
| `gnu_errfmt`         | ✅ | error msg in GNU-tools format |
| `histappend`         | ✅ | append to history file |
| `histreedit`         | ✅ | re-edit failed history lines |
| `histverify`         | ✅ | history `!` substitution loaded for editing |
| `hostcomplete`       | ✅ | hostname completion |
| `huponexit`          | ✅ | SIGHUP children on exit |
| `inherit_errexit`    | ✅ | command sub inherits errexit |
| `interactive_comments` | ✅ | `#` comments in interactive mode |
| `lastpipe`           | ✅ | last cmd in pipe runs in current shell |
| `lithist`            | ✅ | preserve newlines in multi-line history |
| `localvar_inherit`   | ✅ | local inherits parent local value |
| `localvar_unset`     | ✅ | unset local hides outer |
| `login_shell`        | ✅ | read-only flag |
| `mailwarn`           | ✅ | warn on mailfile change |
| `no_empty_cmd_completion` | ✅ | don't complete on empty line |
| `nocaseglob`         | ✅ | case-insensitive glob |
| `nocasematch`        | ✅ | case-insensitive `[[`/case match |
| `noexpand_translation` | ✅ | $"…" doesn't translate |
| `nullglob`           | ✅ | unmatched glob → empty |
| `patsub_replacement` | ✅ | `&` in patsub means full match |
| `progcomp`           | ✅ | programmable completion |
| `progcomp_alias`     | ✅ | alias completion uses target |
| `promptvars`         | ✅ | PS1 etc. expand vars |
| `restricted_shell`   | ✅ | read-only flag |
| `shift_verbose`      | ✅ | warn shift past $# |
| `sourcepath`         | ✅ | source uses PATH |
| `varredir_close`     | ✅ | close fd from `{var}<>file` on cmd return |
| `xpg_echo`           | ✅ | echo interprets escapes by default |

## BASH_* / BASH* variables

| variable | status | notes |
| --- | --- | --- |
| `BASHPID`               | ✅ | current pid |
| `BASHOPTS`              | ✅ | colon-list of enabled shopts |
| `BASH_ALIASES`          | ✅ | alias map |
| `BASH_ARGC`             | ✅ | call stack arg counts |
| `BASH_ARGV`             | ✅ | call stack args |
| `BASH_ARGV0`            | ✅ | $0 alternative |
| `BASH_CMDS`             | ✅ | hashed command paths |
| `BASH_COMMAND`          | ✅ | current command being executed |
| `BASH_COMPAT`           | 🚧 | accepted; full semantic divergence per version partial |
| `BASH_ENV`              | ✅ | startup file for non-interactive |
| `BASH_EXECUTION_STRING` | ✅ | -c argument |
| `BASH_LINENO`           | ✅ | call stack lineno |
| `BASH_LOADABLES_PATH`   | ❌ | loadables not implemented |
| `BASH_REMATCH`          | ✅ | from `[[ =~ ]]` |
| `BASH_SOURCE`           | ✅ | call stack source files |
| `BASH_SUBSHELL`         | ✅ | subshell depth |
| `BASH_VERSINFO`         | ✅ | array version components |
| `BASH_VERSION`          | ✅ | version string |
| `BASH_XTRACEFD`         | ✅ | redirect xtrace |

## Special variables

| variable | status | notes |
| --- | --- | --- |
| `$@` `$*` `$#` `$-`     | ✅ | positional/argv |
| `$?` `$$` `$!` `$0` `$_`| ✅ | special status |
| `$LINENO`               | ✅ | current line in script |
| `$FUNCNAME`             | ✅ | function call stack |
| `$PIPESTATUS`           | ✅ | pipe component statuses |
| `$RANDOM`               | ✅ | pseudo-random 0..32767 |
| `$SECONDS`              | ✅ | shell uptime in seconds |
| `$EPOCHSECONDS`         | ✅ | seconds since epoch |
| `$EPOCHREALTIME`        | ✅ | seconds.fraction since epoch |
| `$SHLVL`                | ✅ | nesting level |
| `$SHELLOPTS`            | ✅ | colon-list of set -o options |
| `$IFS`                  | ✅ | word splitting |
| `$PWD` `$OLDPWD`        | ✅ | current/previous dir |
| `$PATH`                 | ✅ | command search path |
| `$HOME`                 | ✅ | home dir; `~` follows the current value (empty HOME → empty, unset HOME → passwd) |
| `$UID` `$EUID`          | ✅ | user IDs |
| `$GROUPS`               | ✅ | gid list |
| `$HOSTNAME` `$HOSTTYPE` `$MACHTYPE` `$OSTYPE` | ✅ | system info |
| `$TIMEFORMAT`           | ✅ | format for `time` builtin |
| `$PS1` `$PS2` `$PS3` `$PS4` | ✅ | prompts; `\[ \]` only mark text for the line editor and never reach the terminal; PS3 is printed as is; a root shell keeps its own PS4 rather than an inherited one |
| `$PROMPT_COMMAND`       | ✅ | command before prompt |
| `$REPLY`                | ✅ | default `read` target |
| `$HISTFILE` `$HISTSIZE` `$HISTFILESIZE` | ✅ | history config |
| `$HISTCONTROL` `$HISTIGNORE` | ✅ | history filtering |
| `$TMOUT`                | ✅ | read timeout |
| `$TMPDIR`               | ✅ | temp dir |

## Parameter expansions

| form | status | notes |
| --- | --- | --- |
| `${var}`              | ✅ | basic |
| `${var:-w}` `${var-w}` | ✅ | default value |
| `${var:=w}` `${var=w}` | ✅ | assign default |
| `${var:?w}` `${var?w}` | ✅ | error if unset |
| `${var:+w}` `${var+w}` | ✅ | alternate value |
| `${var:o:l}` `${var:o}` | ✅ | substring |
| `${!prefix*}` `${!prefix@}` | ✅ | indirect names by prefix |
| `${!name[@]}` `${!name[*]}` | ✅ | indirect array indices |
| `${#var}`             | ✅ | length |
| `${var#pat}` `${var##pat}` | ✅ | prefix removal |
| `${var%pat}` `${var%%pat}` | ✅ | suffix removal |
| `${var/pat/repl}`     | ✅ | first match replace |
| `${var//pat/repl}`    | ✅ | global replace |
| `${var/#pat/repl}` `${var/%pat/repl}` | ✅ | anchored replace |
| `${var^pat}` `${var^^pat}` | ✅ | upper case |
| `${var,pat}` `${var,,pat}` | ✅ | lower case |
| `${var@Q}`            | ✅ | quoted form |
| `${var@E}`            | ✅ | escape-expand |
| `${var@P}`            | ✅ | prompt-expand |
| `${var@A}` `${var@a}` | ✅ | declare-form / attr |
| `${var@U}` `${var@u}` `${var@L}` | ✅ | upper/lower transforms |
| `${var@K}` `${var@k}` | ✅ | quoted assoc / array key:value |

## Compound commands

| form | status | notes |
| --- | --- | --- |
| `(...)`               | ✅ | subshell |
| `{ ... }`             | ✅ | grouping |
| `((...))`             | ✅ | arithmetic command |
| `[[ ... ]]`           | ✅ | conditional, regex, glob |
| `for var in list`     | ✅ | iter list |
| `for ((init;cond;step))` | ✅ | C-style |
| `while cond; do …`    | ✅ | while loop |
| `until cond; do …`    | ✅ | until loop |
| `if/elif/else/fi`     | ✅ | branching |
| `case ... esac`       | ✅ | pattern matching |
| `select`              | ✅ | menu loop |
| `coproc`              | ✅ | coprocess |

## Other

| feature | status | notes |
| --- | --- | --- |
| `<(cmd)` process sub  | ✅ | input process sub |
| `>(cmd)` process sub  | ✅ | output process sub |
| `time pipeline`       | ✅ | time keyword |
| `! pipeline`          | ✅ | negation |
| `cmd1 \|& cmd2`       | ✅ | pipe stderr+stdout |
| `${ command; }` valfork | ✅ | bash 5.3+ valfork form |

## Notes on partial / missing

- **`enable -f file builtin`** — loadable C builtins are not supported.
  brash has all the documented builtins compiled in; `enable -n` to
  disable a builtin works.
- **`bind`** — brash has its own line editor rather than readline.  Key
  sequences bound with `bind` (or in `~/.inputrc`) are honoured, including
  `bind -x` commands and string macros, but the editor implements 35 of
  readline's editing functions: binding a key to one of the others is
  accepted and does nothing.  Sequences bash uses as prefixes for functions
  brash lacks — `\C-x\C-e` for edit-and-execute-command, say — are free for
  a script to bind.
- **`BASH_LOADABLES_PATH`** — see above.
- **`BASH_COMPAT`** — version-string accepted; a subset of the
  per-version semantic differences (5.0/5.1/5.2/5.3) are honored.

## Verification

This file was generated by spot-checking each row against
`target/release/brash` and `/opt/homebrew/bin/bash`.  For deep semantic
coverage see the upstream suite under `.cache/bash-oracle-src/bash-5.3/tests/`
(81/81 passing, 1 skipped).
