// Copyright (c) 2026 Jon-Erik G. Storm, Inc., a California Corporation,
// doing business as LAVA GOAT SOFTWARE. All rights reserved.
// Licensed under MIT.

use std::collections::HashMap;
use libc;

// ---------------------------------------------------------------------------
// TrapHandler
// ---------------------------------------------------------------------------

/// Stores per-signal trap actions.
///
/// The action string for a signal can be:
///   - A non-empty shell command to execute when the signal fires.
///   - `""` (empty string) — the signal is ignored (SIG_IGN semantics).
///   - `"-"` — the signal is reset to its default disposition (SIG_DFL).
///
/// Pseudo-signals supported: EXIT (0), DEBUG, RETURN, ERR.
pub struct TrapHandler {
    /// Maps signal name (upper-case) → action string.
    traps: HashMap<String, String>,
    /// Bumped whenever the RETURN trap is set or removed.  A function fires
    /// the RETURN trap on the way out when this moved during its own
    /// invocation — that is bash's rule for a trap the function set itself,
    /// as opposed to one merely inherited from the caller.
    return_epoch: u64,
}

impl TrapHandler {
    // ------------------------------------------------------------------
    // Construction
    // ------------------------------------------------------------------

    pub fn new() -> Self {
        TrapHandler {
            traps: HashMap::new(),
            return_epoch: 0,
        }
    }

    // ------------------------------------------------------------------
    // Core operations
    // ------------------------------------------------------------------

    /// Register `action` for `signal`.
    /// `signal` may be a name ("INT", "SIGINT") or a number ("2").
    /// The name is normalised before storage (upper-case, SIGXXX → XXX).
    pub fn set(&mut self, signal: &str, action: &str) {
        let normalised = Self::normalise(signal);
        if normalised == "RETURN" {
            self.return_epoch = self.return_epoch.wrapping_add(1);
        }
        self.traps.insert(normalised, action.to_owned());
    }

    /// See `return_epoch`.
    pub fn return_epoch(&self) -> u64 {
        self.return_epoch
    }

    /// Look up the action for `signal`.  Returns `None` if no trap is set.
    pub fn get(&self, signal: &str) -> Option<&str> {
        // Fast path for the common pseudo-signal names that are already
        // upper-case and have no "SIG" prefix — avoids the to_uppercase()
        // allocation in the hot no-trap-set path.
        if matches!(signal, "DEBUG" | "EXIT" | "ERR" | "RETURN") {
            return self.traps.get(signal).map(|s| s.as_str());
        }
        let normalised = Self::normalise(signal);
        self.traps.get(&normalised).map(|s| s.as_str())
    }

    /// Remove the trap for `signal` (reset to default disposition).
    pub fn remove(&mut self, signal: &str) {
        let normalised = Self::normalise(signal);
        if normalised == "RETURN" {
            self.return_epoch = self.return_epoch.wrapping_add(1);
        }
        self.traps.remove(&normalised);
    }

    /// Return the EXIT trap action if one is set.
    pub fn get_exit_trap(&self) -> Option<String> {
        self.traps.get("EXIT").cloned()
    }

    /// Return a sorted list of `(display_signal_name, action)` pairs.
    /// Sorted by signal number (EXIT=0 first, then real signals by number,
    /// then pseudo-signals DEBUG/RETURN/ERR).
    /// Real signals are returned with the "SIG" prefix (e.g. "SIGHUP").
    /// Pseudo-signals (EXIT, DEBUG, RETURN, ERR) are returned without prefix.
    pub fn list(&self) -> Vec<(String, String)> {
        let mut pairs: Vec<(String, String)> = self
            .traps
            .iter()
            .map(|(k, v)| {
                let display = Self::to_display_name(k);
                (display, v.clone())
            })
            .collect();
        // Sort by signal number for consistent bash-compatible output order.
        pairs.sort_by_key(|(display, _)| {
            let internal = Self::strip_sig_prefix_static(display);
            Self::signal_name_to_num(internal).unwrap_or(999)
        });
        pairs
    }

    /// Convert an internal (stored) signal name to its display form.
    /// Real OS signals get a "SIG" prefix; pseudo-signals do not.
    pub fn to_display_name(internal: &str) -> String {
        match internal {
            "EXIT" | "DEBUG" | "RETURN" | "ERR" => internal.to_string(),
            _ => format!("SIG{}", internal),
        }
    }

    fn strip_sig_prefix_static(s: &str) -> &str {
        s.strip_prefix("SIG").unwrap_or(s)
    }

    // ------------------------------------------------------------------
    // Signal name ↔ number mapping
    // ------------------------------------------------------------------

    /// Convert a signal name (e.g. `"INT"`, `"SIGINT"`) to its number.
    /// Returns `None` for unknown names.
    pub fn signal_name_to_num(name: &str) -> Option<i32> {
        let n = Self::strip_sig_prefix(name);
        // Pseudo-signals
        match n {
            "EXIT" => return Some(0),
            // DEBUG, RETURN, ERR have no POSIX number; use sentinel values that
            // are outside the normal signal range so callers can distinguish them.
            "DEBUG" => return Some(256),
            "RETURN" => return Some(257),
            "ERR" => return Some(258),
            _ => {}
        }
        Self::name_to_num_table()
            .iter()
            .find(|(sig_name, _)| *sig_name == n)
            .map(|(_, num)| *num)
            .or_else(|| Self::rt_signal_number(n))
    }

    /// Convert a signal number to its canonical name (without "SIG" prefix).
    /// Returns `None` for unknown numbers.
    pub fn signal_num_to_name(num: i32) -> Option<&'static str> {
        match num {
            0 => return Some("EXIT"),
            256 => return Some("DEBUG"),
            257 => return Some("RETURN"),
            258 => return Some("ERR"),
            _ => {}
        }
        Self::name_to_num_table()
            .iter()
            .find(|(_, n)| *n == num)
            .map(|(name, _)| *name)
    }

    /// The name of signal `num`, including the real-time signals that only
    /// exist at run time.
    ///
    /// Linux numbers a block of signals above the named ones: the C library
    /// keeps the first few for its own threading use — bash calls those
    /// `JUNK(n)` — and the rest are the real-time signals, named from either
    /// end (`SIGRTMIN+3`, `SIGRTMAX-2`) depending on which half they fall in.
    pub fn signal_name_owned(num: i32) -> Option<String> {
        if let Some(name) = Self::signal_num_to_name(num) {
            return Some(name.to_string());
        }
        let (rtmin, rtmax) = Self::rt_signal_range()?;
        if num >= 1 && num < rtmin {
            return Some(format!("JUNK({})", num));
        }
        if num < rtmin || num > rtmax {
            return None;
        }
        let from_min = num - rtmin;
        let from_max = rtmax - num;
        Some(if from_min <= from_max {
            if from_min == 0 {
                "RTMIN".to_string()
            } else {
                format!("RTMIN+{}", from_min)
            }
        } else if from_max == 0 {
            "RTMAX".to_string()
        } else {
            format!("RTMAX-{}", from_max)
        })
    }

    /// The number a real-time signal name stands for (`RTMIN+3`, `RTMAX-1`).
    pub fn rt_signal_number(name: &str) -> Option<i32> {
        let (rtmin, rtmax) = Self::rt_signal_range()?;
        let name = Self::strip_sig_prefix(name);
        let (base, rest) = if let Some(rest) = name.strip_prefix("RTMIN") {
            (rtmin, rest)
        } else if let Some(rest) = name.strip_prefix("RTMAX") {
            (rtmax, rest)
        } else {
            return None;
        };
        let num = if rest.is_empty() {
            base
        } else if let Some(offset) = rest.strip_prefix('+') {
            base + offset.parse::<i32>().ok()?
        } else if let Some(offset) = rest.strip_prefix('-') {
            base - offset.parse::<i32>().ok()?
        } else {
            return None;
        };
        if num >= rtmin && num <= rtmax {
            Some(num)
        } else {
            None
        }
    }

    /// The highest signal number this platform has, for `kill -l`.
    pub fn max_signal_number() -> i32 {
        Self::rt_signal_range().map(|(_, max)| max).unwrap_or(31)
    }

    /// The real-time signal range, on the platforms that have one.
    // SIGRTMIN/SIGRTMAX are `unsafe extern` accessors against glibc and plain
    // functions against musl, so the blocks below are needed for one and
    // redundant for the other.
    #[allow(unused_unsafe)]
    fn rt_signal_range() -> Option<(i32, i32)> {
        #[cfg(target_os = "linux")]
        {
            // SAFETY: both are plain accessor functions in libc with no
            // arguments and no side effects.
            let min = unsafe { libc::SIGRTMIN() };
            let max = unsafe { libc::SIGRTMAX() };
            if min > 0 && max >= min {
                return Some((min, max));
            }
            None
        }
        #[cfg(not(target_os = "linux"))]
        {
            None
        }
    }

    // ------------------------------------------------------------------
    // Internal helpers
    // ------------------------------------------------------------------

    /// Public wrapper around `normalise` for use in builtins.
    pub fn normalise_pub(signal: &str) -> String {
        Self::normalise(signal)
    }

    /// Normalise a signal specifier:
    ///   - strip optional "SIG" prefix
    ///   - convert to upper-case
    ///   - if it is a pure number, resolve it to a name
    fn normalise(signal: &str) -> String {
        let upper = signal.trim().to_uppercase();
        let stripped = Self::strip_sig_prefix(&upper);

        // If it looks like a number, resolve to a name so storage is consistent.
        if let Ok(n) = stripped.parse::<i32>() {
            return Self::signal_name_owned(n)
                .unwrap_or_else(|| stripped.to_owned());
        }

        stripped.to_owned()
    }

    /// Remove a leading "SIG" prefix (case-insensitive, already upper-cased by
    /// the time this is called).
    fn strip_sig_prefix(s: &str) -> &str {
        s.strip_prefix("SIG").unwrap_or(s)
    }

    /// Static table of POSIX + common signal name → number.
    /// Uses platform-specific libc constants so signal numbers are correct on
    /// both Linux (SIGUSR1=10, SIGCHLD=17, ...) and macOS (SIGUSR1=30,
    /// SIGCHLD=20, ...).
    fn name_to_num_table() -> &'static [(&'static str, i32)] {
        &[
            ("HUP",  libc::SIGHUP  as i32),
            ("INT",  libc::SIGINT  as i32),
            ("QUIT", libc::SIGQUIT as i32),
            ("ILL",  libc::SIGILL  as i32),
            ("TRAP", libc::SIGTRAP as i32),
            ("ABRT", libc::SIGABRT as i32),
            ("FPE",  libc::SIGFPE  as i32),
            ("KILL", libc::SIGKILL as i32),
            ("SEGV", libc::SIGSEGV as i32),
            ("PIPE", libc::SIGPIPE as i32),
            ("ALRM", libc::SIGALRM as i32),
            ("TERM", libc::SIGTERM as i32),
            ("USR1", libc::SIGUSR1 as i32),
            ("USR2", libc::SIGUSR2 as i32),
            ("CHLD", libc::SIGCHLD as i32),
            ("CONT", libc::SIGCONT as i32),
            ("STOP", libc::SIGSTOP as i32),
            ("TSTP", libc::SIGTSTP as i32),
            ("TTIN", libc::SIGTTIN as i32),
            ("TTOU", libc::SIGTTOU as i32),
            ("BUS",  libc::SIGBUS  as i32),
            ("SYS",  libc::SIGSYS  as i32),
            ("URG",  libc::SIGURG  as i32),
            ("XCPU", libc::SIGXCPU as i32),
            ("XFSZ", libc::SIGXFSZ as i32),
            ("VTALRM", libc::SIGVTALRM as i32),
            ("PROF", libc::SIGPROF as i32),
            ("WINCH", libc::SIGWINCH as i32),
            ("IO",   libc::SIGIO   as i32),
            #[cfg(target_os = "linux")]
            ("STKFLT", libc::SIGSTKFLT as i32),
            #[cfg(target_os = "linux")]
            ("PWR",  libc::SIGPWR  as i32),
            #[cfg(any(target_os = "macos", target_os = "freebsd", target_os = "netbsd",
                      target_os = "openbsd", target_os = "dragonfly"))]
            ("EMT",  libc::SIGEMT  as i32),
            #[cfg(any(target_os = "macos", target_os = "freebsd", target_os = "netbsd",
                      target_os = "openbsd", target_os = "dragonfly"))]
            ("INFO", libc::SIGINFO as i32),
        ]
    }

    /// Every signal this platform has, lowest number first, as `kill -l` and
    /// `compgen -A signal` list them.
    pub fn all_signal_names() -> Vec<(i32, String)> {
        let mut numbered: Vec<(i32, String)> = Self::name_to_num_table()
            .iter()
            .map(|(name, num)| (*num, (*name).to_string()))
            .collect();
        numbered.sort_by_key(|(num, _)| *num);
        let highest = numbered.last().map(|(num, _)| *num).unwrap_or(0);
        for num in (highest + 1)..=Self::max_signal_number() {
            if let Some(name) = Self::signal_name_owned(num) {
                numbered.push((num, name));
            }
        }
        numbered
    }
}

impl Default for TrapHandler {
    fn default() -> Self {
        Self::new()
    }
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_set_and_get() {
        let mut th = TrapHandler::new();
        th.set("INT", "echo interrupted");
        assert_eq!(th.get("INT"), Some("echo interrupted"));
        // Lookup by number should work too.
        assert_eq!(th.get("2"), Some("echo interrupted"));
        // Lookup with SIGXXX prefix.
        assert_eq!(th.get("SIGINT"), Some("echo interrupted"));
    }

    #[test]
    fn test_remove() {
        let mut th = TrapHandler::new();
        th.set("TERM", "cleanup");
        th.remove("TERM");
        assert_eq!(th.get("TERM"), None);
    }

    #[test]
    fn test_pseudo_signals() {
        assert_eq!(TrapHandler::signal_name_to_num("EXIT"), Some(0));
        assert_eq!(TrapHandler::signal_name_to_num("DEBUG"), Some(256));
        assert_eq!(TrapHandler::signal_name_to_num("RETURN"), Some(257));
        assert_eq!(TrapHandler::signal_name_to_num("ERR"), Some(258));
    }

    #[test]
    fn test_num_to_name() {
        assert_eq!(TrapHandler::signal_num_to_name(2), Some("INT"));
        assert_eq!(TrapHandler::signal_num_to_name(15), Some("TERM"));
        assert_eq!(TrapHandler::signal_num_to_name(0), Some("EXIT"));
        assert_eq!(TrapHandler::signal_num_to_name(999), None);
    }

    #[test]
    fn test_list_sorted() {
        let mut th = TrapHandler::new();
        th.set("TERM", "a");
        th.set("INT",  "b");
        th.set("HUP",  "c");
        let list = th.list();
        // list() now returns display names with SIG prefix, sorted by signal number
        let names: Vec<&str> = list.iter().map(|(n, _)| n.as_str()).collect();
        assert_eq!(names, vec!["SIGHUP", "SIGINT", "SIGTERM"]);
    }

    #[test]
    fn test_display_name() {
        assert_eq!(TrapHandler::to_display_name("HUP"), "SIGHUP");
        assert_eq!(TrapHandler::to_display_name("INT"), "SIGINT");
        assert_eq!(TrapHandler::to_display_name("EXIT"), "EXIT");
        assert_eq!(TrapHandler::to_display_name("DEBUG"), "DEBUG");
        assert_eq!(TrapHandler::to_display_name("ERR"), "ERR");
        assert_eq!(TrapHandler::to_display_name("RETURN"), "RETURN");
    }
}
