// Copyright (c) 2026 Jon-Erik G. Storm, Inc., a California Corporation,
// doing business as LAVA GOAT SOFTWARE. All rights reserved.
// Licensed under MIT.

//! # Module Invariant Ledger
//!
//! ## Structural Invariants
//! - INV-001: A key sequence is stored as the exact bytes the terminal
//!   delivers.  `parse_seq` is the only way sequences enter the table, and
//!   `format_seq` is its inverse for every byte string it can produce.
//! - INV-002: `DEFAULTS` describes bindings the line editor implements
//!   itself.  The table in `Keymaps` holds only what a script changed —
//!   a new binding, a macro, a `bind -x` command, or an `Action::Unbound`
//!   marker where a default was removed.  Listing merges the two; the
//!   editor consults only the table, so an untouched default costs nothing.
//! - INV-003: Every sequence in `DEFAULTS` parses.  `defaults_for` unwraps
//!   the parse, which the unit tests cover for the whole table.
//!
//! ## Performance Invariants
//! - PINV-001: `lookup` is called once per input byte in the line editor.
//!   It is a `BTreeMap` range scan over sequences that share the prefix,
//!   and returns `Miss` after one comparison when the table is empty —
//!   the case for a shell whose bindings have not been changed.

use std::collections::BTreeMap;

/// Which keymap a binding belongs to.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum KeymapId {
    Emacs,
    ViInsert,
    ViCommand,
}

impl KeymapId {
    fn index(self) -> usize {
        match self {
            KeymapId::Emacs => 0,
            KeymapId::ViInsert => 1,
            KeymapId::ViCommand => 2,
        }
    }

    /// The keymap `name` selects, as `bind -m` spells it.
    pub fn from_name(name: &str) -> Option<KeymapId> {
        match name {
            "emacs" | "emacs-standard" | "emacs-meta" | "emacs-ctlx" => Some(KeymapId::Emacs),
            "vi" | "vi-move" | "vi-command" => Some(KeymapId::ViCommand),
            "vi-insert" => Some(KeymapId::ViInsert),
            _ => None,
        }
    }
}

/// What a key sequence does.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum Action {
    /// A named editing function.
    Function(String),
    /// Text inserted into the line as if typed.
    Macro(String),
    /// A shell command run with READLINE_LINE and READLINE_POINT set
    /// (`bind -x`).
    Command(String),
    /// The sequence was explicitly unbound, overriding a default.
    Unbound,
}

/// The result of matching input bytes against the bindings.
#[derive(Debug, PartialEq, Eq)]
pub enum Lookup<'a> {
    /// The bytes are a complete binding.
    Exact(&'a Action),
    /// The bytes begin at least one longer binding; read more.
    Prefix,
    /// Nothing in the table starts with these bytes.
    Miss,
}

/// The editing functions brash's line editor implements, in the order
/// `bind -l` lists them.
pub const FUNCTIONS: &[&str] = &[
    "accept-line",
    "backward-char",
    "backward-delete-char",
    "backward-kill-word",
    "backward-word",
    "beginning-of-history",
    "beginning-of-line",
    "capitalize-word",
    "clear-screen",
    "complete",
    "delete-char",
    "downcase-word",
    "end-of-history",
    "end-of-line",
    "forward-char",
    "forward-word",
    "insert-last-argument",
    "kill-line",
    "kill-whole-line",
    "kill-word",
    "menu-complete",
    "next-history",
    "operate-and-get-next",
    "possible-completions",
    "previous-history",
    "quoted-insert",
    "reverse-search-history",
    "self-insert",
    "transpose-chars",
    "transpose-words",
    "unix-line-discard",
    "unix-word-rubout",
    "upcase-word",
    "yank",
    "yank-last-arg",
];

/// The bindings the line editor implements without being told.
const DEFAULTS: &[(KeymapId, &str, &str)] = &[
    (KeymapId::Emacs, "\\C-a", "beginning-of-line"),
    (KeymapId::Emacs, "\\C-b", "backward-char"),
    (KeymapId::Emacs, "\\C-d", "delete-char"),
    (KeymapId::Emacs, "\\C-e", "end-of-line"),
    (KeymapId::Emacs, "\\C-f", "forward-char"),
    (KeymapId::Emacs, "\\C-i", "complete"),
    (KeymapId::Emacs, "\\C-j", "accept-line"),
    (KeymapId::Emacs, "\\C-k", "kill-line"),
    (KeymapId::Emacs, "\\C-l", "clear-screen"),
    (KeymapId::Emacs, "\\C-m", "accept-line"),
    (KeymapId::Emacs, "\\C-n", "next-history"),
    (KeymapId::Emacs, "\\C-o", "operate-and-get-next"),
    (KeymapId::Emacs, "\\C-p", "previous-history"),
    (KeymapId::Emacs, "\\C-r", "reverse-search-history"),
    (KeymapId::Emacs, "\\C-t", "transpose-chars"),
    (KeymapId::Emacs, "\\C-u", "unix-line-discard"),
    (KeymapId::Emacs, "\\C-v", "quoted-insert"),
    (KeymapId::Emacs, "\\C-w", "unix-word-rubout"),
    (KeymapId::Emacs, "\\C-y", "yank"),
    (KeymapId::Emacs, "\\C-?", "backward-delete-char"),
    (KeymapId::Emacs, "\\e<", "beginning-of-history"),
    (KeymapId::Emacs, "\\e>", "end-of-history"),
    (KeymapId::Emacs, "\\eb", "backward-word"),
    (KeymapId::Emacs, "\\ec", "capitalize-word"),
    (KeymapId::Emacs, "\\ed", "kill-word"),
    (KeymapId::Emacs, "\\ef", "forward-word"),
    (KeymapId::Emacs, "\\el", "downcase-word"),
    (KeymapId::Emacs, "\\et", "transpose-words"),
    (KeymapId::Emacs, "\\eu", "upcase-word"),
    (KeymapId::Emacs, "\\e.", "yank-last-arg"),
    (KeymapId::Emacs, "\\e_", "yank-last-arg"),
    (KeymapId::Emacs, "\\e\\C-?", "backward-kill-word"),
    (KeymapId::Emacs, "\\e[A", "previous-history"),
    (KeymapId::Emacs, "\\e[B", "next-history"),
    (KeymapId::Emacs, "\\e[C", "forward-char"),
    (KeymapId::Emacs, "\\e[D", "backward-char"),
    (KeymapId::Emacs, "\\e[F", "end-of-line"),
    (KeymapId::Emacs, "\\e[H", "beginning-of-line"),
    (KeymapId::Emacs, "\\e[3~", "delete-char"),
    (KeymapId::Emacs, "\\eOF", "end-of-line"),
    (KeymapId::Emacs, "\\eOH", "beginning-of-line"),
    (KeymapId::ViInsert, "\\C-d", "delete-char"),
    (KeymapId::ViInsert, "\\C-i", "complete"),
    (KeymapId::ViInsert, "\\C-j", "accept-line"),
    (KeymapId::ViInsert, "\\C-m", "accept-line"),
    (KeymapId::ViInsert, "\\C-?", "backward-delete-char"),
    (KeymapId::ViCommand, "0", "beginning-of-line"),
    (KeymapId::ViCommand, "$", "end-of-line"),
    (KeymapId::ViCommand, "b", "backward-word"),
    (KeymapId::ViCommand, "h", "backward-char"),
    (KeymapId::ViCommand, "j", "next-history"),
    (KeymapId::ViCommand, "k", "previous-history"),
    (KeymapId::ViCommand, "l", "forward-char"),
    (KeymapId::ViCommand, "w", "forward-word"),
    (KeymapId::ViCommand, "x", "delete-char"),
    (KeymapId::ViCommand, "\\C-m", "accept-line"),
];

/// The bindings a shell has: what the editor does by default, plus whatever
/// `bind` and the inputrc changed.
#[derive(Clone, Default)]
pub struct Keymaps {
    maps: [BTreeMap<Vec<u8>, Action>; 3],
}

impl Keymaps {
    pub fn new() -> Self {
        Keymaps::default()
    }

    /// True when nothing has been rebound, which lets the line editor skip
    /// the lookup entirely.
    pub fn is_empty(&self) -> bool {
        self.maps.iter().all(|m| m.is_empty())
    }

    pub fn bind(&mut self, map: KeymapId, seq: Vec<u8>, action: Action) {
        self.maps[map.index()].insert(seq, action);
    }

    /// Remove the binding for `seq`.  A default is masked with `Unbound`
    /// rather than deleted, since the editor would otherwise still run it.
    pub fn unbind(&mut self, map: KeymapId, seq: &[u8]) {
        if default_function(map, seq).is_some() {
            self.maps[map.index()].insert(seq.to_vec(), Action::Unbound);
        } else {
            self.maps[map.index()].remove(seq);
        }
    }

    /// Remove every binding for `function`, defaults included.
    pub fn unbind_function(&mut self, map: KeymapId, function: &str) {
        let seqs: Vec<Vec<u8>> = self
            .bindings(map)
            .into_iter()
            .filter(|(_, action)| matches!(action, Action::Function(f) if f == function))
            .map(|(seq, _)| seq)
            .collect();
        for seq in seqs {
            self.unbind(map, &seq);
        }
    }

    /// Match input bytes against the changed bindings.
    pub fn lookup(&self, map: KeymapId, bytes: &[u8]) -> Lookup<'_> {
        let table = &self.maps[map.index()];
        if let Some(action) = table.get(bytes) {
            return Lookup::Exact(action);
        }
        // A longer binding starting with these bytes means more input is
        // coming; BTreeMap keeps those immediately after `bytes`.
        if table
            .range(bytes.to_vec()..)
            .next()
            .map(|(k, _)| k.len() > bytes.len() && k.starts_with(bytes))
            .unwrap_or(false)
        {
            return Lookup::Prefix;
        }
        Lookup::Miss
    }

    /// Every binding in effect for `map`, sorted by key sequence.
    pub fn bindings(&self, map: KeymapId) -> Vec<(Vec<u8>, Action)> {
        let mut out: BTreeMap<Vec<u8>, Action> = BTreeMap::new();
        for (id, seq, function) in DEFAULTS {
            if *id == map {
                if let Some(bytes) = parse_seq(seq) {
                    out.insert(bytes, Action::Function((*function).to_string()));
                }
            }
        }
        for (seq, action) in &self.maps[map.index()] {
            match action {
                Action::Unbound => {
                    out.remove(seq);
                }
                other => {
                    out.insert(seq.clone(), other.clone());
                }
            }
        }
        out.into_iter().collect()
    }
}

/// The keystrokes that invoke `function` by default, which is how a
/// rebound sequence reaches the editor's own implementation of it.
pub fn default_seq_for(map: KeymapId, function: &str) -> Option<Vec<u8>> {
    DEFAULTS
        .iter()
        .find(|(id, _, name)| *id == map && *name == function)
        .and_then(|(_, spec, _)| parse_seq(spec))
        .or_else(|| {
            if map == KeymapId::Emacs {
                None
            } else {
                // Every keymap falls back to the emacs table, which is where
                // the editor's implementations actually live.
                DEFAULTS
                    .iter()
                    .find(|(id, _, name)| *id == KeymapId::Emacs && *name == function)
                    .and_then(|(_, spec, _)| parse_seq(spec))
            }
        })
}

/// The default function bound to `seq`, if the editor has one.
fn default_function(map: KeymapId, seq: &[u8]) -> Option<&'static str> {
    DEFAULTS.iter().find_map(|(id, spec, function)| {
        if *id == map && parse_seq(spec).as_deref() == Some(seq) {
            Some(*function)
        } else {
            None
        }
    })
}

/// Parse a readline key-sequence spec — `\C-x`, `\M-x`, `\e[A`, `a` — into
/// the bytes the terminal sends.  Returns `None` for a spec that does not
/// terminate (a trailing backslash, say).
pub fn parse_seq(spec: &str) -> Option<Vec<u8>> {
    let chars: Vec<char> = spec.chars().collect();
    let mut out: Vec<u8> = Vec::new();
    let mut i = 0;
    while i < chars.len() {
        if chars[i] != '\\' {
            let mut buf = [0u8; 4];
            out.extend_from_slice(chars[i].encode_utf8(&mut buf).as_bytes());
            i += 1;
            continue;
        }
        i += 1;
        let c = *chars.get(i)?;
        i += 1;
        match c {
            'C' | 'c' => {
                // \C-x, and \C-\M-x for a meta-control character.
                if chars.get(i) == Some(&'-') {
                    i += 1;
                }
                let mut meta = false;
                if chars.get(i) == Some(&'\\') && matches!(chars.get(i + 1), Some('M') | Some('m')) {
                    meta = true;
                    i += 2;
                    if chars.get(i) == Some(&'-') {
                        i += 1;
                    }
                }
                let key = *chars.get(i)?;
                i += 1;
                if meta {
                    out.push(0x1b);
                }
                out.push(control_byte(key));
            }
            'M' | 'm' => {
                // Meta is sent as an ESC prefix, readline's default.
                if chars.get(i) == Some(&'-') {
                    i += 1;
                }
                out.push(0x1b);
                if chars.get(i) == Some(&'\\') {
                    let rest: String = chars[i..].iter().collect();
                    let mut inner = parse_seq(&rest)?;
                    out.append(&mut inner);
                    i = chars.len();
                } else {
                    let key = *chars.get(i)?;
                    i += 1;
                    let mut buf = [0u8; 4];
                    out.extend_from_slice(key.encode_utf8(&mut buf).as_bytes());
                }
            }
            'e' => out.push(0x1b),
            'a' => out.push(0x07),
            'b' => out.push(0x08),
            'd' => out.push(0x7f),
            'f' => out.push(0x0c),
            'n' => out.push(b'\n'),
            'r' => out.push(b'\r'),
            't' => out.push(b'\t'),
            'v' => out.push(0x0b),
            '0'..='7' => {
                let mut value = c.to_digit(8)? as u32;
                let mut digits = 1;
                while digits < 3 {
                    match chars.get(i).and_then(|d| d.to_digit(8)) {
                        Some(d) => {
                            value = value * 8 + d;
                            i += 1;
                            digits += 1;
                        }
                        None => break,
                    }
                }
                out.push(value as u8);
            }
            'x' | 'X' => {
                let mut value: u32 = 0;
                let mut digits = 0;
                while digits < 2 {
                    match chars.get(i).and_then(|d| d.to_digit(16)) {
                        Some(d) => {
                            value = value * 16 + d;
                            i += 1;
                            digits += 1;
                        }
                        None => break,
                    }
                }
                if digits == 0 {
                    return None;
                }
                out.push(value as u8);
            }
            other => {
                let mut buf = [0u8; 4];
                out.extend_from_slice(other.encode_utf8(&mut buf).as_bytes());
            }
        }
    }
    Some(out)
}

/// The byte `\C-key` stands for.
fn control_byte(key: char) -> u8 {
    match key {
        '?' => 0x7f,
        '@' => 0,
        c if c.is_ascii() => (c as u8) & 0x1f,
        _ => key as u8,
    }
}

/// Render a key sequence the way `bind -p` writes it, without the quotes.
pub fn format_seq(bytes: &[u8]) -> String {
    let mut out = String::new();
    for &b in bytes {
        match b {
            0x1b => out.push_str("\\e"),
            0x7f => out.push_str("\\C-?"),
            0 => out.push_str("\\C-@"),
            0x01..=0x1a => {
                out.push_str("\\C-");
                out.push((b + b'a' - 1) as char);
            }
            b'"' => out.push_str("\\\""),
            b'\\' => out.push_str("\\\\"),
            0x20..=0x7e => out.push(b as char),
            other => out.push_str(&format!("\\{:03o}", other)),
        }
    }
    out
}

/// Render a macro or command body for `bind -s` / `bind -X`.
pub fn format_text(text: &str) -> String {
    let mut out = String::new();
    for c in text.chars() {
        match c {
            '"' => out.push_str("\\\""),
            '\\' => out.push_str("\\\\"),
            '\n' => out.push_str("\\n"),
            '\r' => out.push_str("\\r"),
            '\t' => out.push_str("\\t"),
            '\x1b' => out.push_str("\\e"),
            other => out.push(other),
        }
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn every_default_sequence_parses() {
        for (_, spec, _) in DEFAULTS {
            assert!(parse_seq(spec).is_some(), "unparsable default: {}", spec);
        }
    }

    #[test]
    fn control_and_meta_sequences() {
        assert_eq!(parse_seq("\\C-a").unwrap(), vec![0x01]);
        assert_eq!(parse_seq("\\C-?").unwrap(), vec![0x7f]);
        assert_eq!(parse_seq("\\e[A").unwrap(), vec![0x1b, b'[', b'A']);
        assert_eq!(parse_seq("\\M-f").unwrap(), vec![0x1b, b'f']);
        assert_eq!(parse_seq("\\M-\\C-h").unwrap(), vec![0x1b, 0x08]);
        assert_eq!(parse_seq("\\C-\\M-h").unwrap(), vec![0x1b, 0x08]);
        assert_eq!(parse_seq("\\x41").unwrap(), vec![b'A']);
        assert_eq!(parse_seq("\\101").unwrap(), vec![b'A']);
        assert_eq!(parse_seq("ab").unwrap(), vec![b'a', b'b']);
    }

    #[test]
    fn formatting_round_trips() {
        for spec in ["\\C-a", "\\e[A", "\\C-x\\C-e", "\\e.", "\\C-?"] {
            let bytes = parse_seq(spec).unwrap();
            assert_eq!(format_seq(&bytes), spec.replace("\\\\", "\\"));
        }
    }

    #[test]
    fn lookup_finds_prefixes_and_exact_matches() {
        let mut maps = Keymaps::new();
        maps.bind(
            KeymapId::Emacs,
            parse_seq("\\C-x\\C-e").unwrap(),
            Action::Function("clear-screen".into()),
        );
        assert_eq!(maps.lookup(KeymapId::Emacs, &[0x18]), Lookup::Prefix);
        assert!(matches!(
            maps.lookup(KeymapId::Emacs, &[0x18, 0x05]),
            Lookup::Exact(_)
        ));
        assert_eq!(maps.lookup(KeymapId::Emacs, &[0x19]), Lookup::Miss);
    }

    #[test]
    fn unbinding_a_default_masks_it() {
        let mut maps = Keymaps::new();
        let seq = parse_seq("\\C-a").unwrap();
        maps.unbind(KeymapId::Emacs, &seq);
        assert!(matches!(
            maps.lookup(KeymapId::Emacs, &seq),
            Lookup::Exact(Action::Unbound)
        ));
        assert!(!maps
            .bindings(KeymapId::Emacs)
            .iter()
            .any(|(s, _)| *s == seq));
    }
}
