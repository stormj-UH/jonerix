// Copyright (c) 2026 Jon-Erik G. Storm, Inc., a California Corporation,
// doing business as LAVA GOAT SOFTWARE. All rights reserved.
// Licensed under MIT.

//! Domain newtypes for the brash shell.
//!
//! These replace raw primitive types with named wrappers that make the code
//! self-documenting and prevent accidental mixing of unrelated values that
//! happen to share the same representation.

use std::fmt;
use std::os::unix::io::RawFd;

// ---------------------------------------------------------------------------
// ExitStatus — shell command exit status
// ---------------------------------------------------------------------------

/// A shell command exit status (0..=255 by convention, but the shell stores
/// the full `i32` from `waitpid` internally).
///
/// Convention:
///   - 0 = success
///   - 1 = general error
///   - 2 = misuse of shell builtins / syntax error
///   - 126 = command found but not executable
///   - 127 = command not found
///   - 128+N = killed by signal N
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct ExitStatus(i32);

impl ExitStatus {
    /// Successful exit (status 0).
    pub const SUCCESS: ExitStatus = ExitStatus(0);

    /// General failure (status 1).
    pub const FAILURE: ExitStatus = ExitStatus(1);

    /// Create an ExitStatus from a raw integer.
    pub const fn new(code: i32) -> Self {
        ExitStatus(code)
    }

    /// Returns `true` when the status indicates success (zero).
    pub fn is_success(self) -> bool {
        self.0 == 0
    }

    /// Build an exit status for a process killed by signal `signum`.
    /// Returns `128 + signum` per bash convention.
    pub fn from_signal(signum: i32) -> Self {
        ExitStatus(128 + signum)
    }

    /// Return the raw `i32` value.
    pub fn code(self) -> i32 {
        self.0
    }
}

impl From<i32> for ExitStatus {
    fn from(code: i32) -> Self {
        ExitStatus(code)
    }
}

impl From<ExitStatus> for i32 {
    fn from(status: ExitStatus) -> Self {
        status.0
    }
}

impl fmt::Display for ExitStatus {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{}", self.0)
    }
}

// Allow `status == 0` style comparisons without explicit conversion.
impl PartialEq<i32> for ExitStatus {
    fn eq(&self, other: &i32) -> bool {
        self.0 == *other
    }
}

impl PartialEq<ExitStatus> for i32 {
    fn eq(&self, other: &ExitStatus) -> bool {
        *self == other.0
    }
}

// ---------------------------------------------------------------------------
// Fd — file descriptor wrapper
// ---------------------------------------------------------------------------

/// A file descriptor.  Wraps `RawFd` (`i32` on Unix) so that file-descriptor
/// values cannot be accidentally confused with exit statuses, signal numbers,
/// or other integers.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct Fd(RawFd);

impl Fd {
    pub const STDIN: Fd = Fd(0);
    pub const STDOUT: Fd = Fd(1);
    pub const STDERR: Fd = Fd(2);

    /// Sentinel: the original fd was not open before the redirect.
    pub const NOT_OPEN: Fd = Fd(-1);

    /// Sentinel: the fd was newly created by a redirect and should be closed
    /// on restore (not dup2'd back).
    pub const NEWLY_CREATED: Fd = Fd(-2);

    /// Create from a raw file descriptor value.
    pub const fn new(raw: RawFd) -> Self {
        Fd(raw)
    }

    /// Return the underlying `RawFd`.
    pub fn raw(self) -> RawFd {
        self.0
    }

    /// True when this represents a valid (non-negative) file descriptor.
    pub fn is_valid(self) -> bool {
        self.0 >= 0
    }
}

impl From<RawFd> for Fd {
    fn from(raw: RawFd) -> Self {
        Fd(raw)
    }
}

impl From<Fd> for RawFd {
    fn from(fd: Fd) -> Self {
        fd.0
    }
}

impl fmt::Display for Fd {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{}", self.0)
    }
}

// Allow `fd >= 0` style comparisons.
impl PartialEq<RawFd> for Fd {
    fn eq(&self, other: &RawFd) -> bool {
        self.0 == *other
    }
}

impl PartialOrd<RawFd> for Fd {
    fn partial_cmp(&self, other: &RawFd) -> Option<std::cmp::Ordering> {
        self.0.partial_cmp(other)
    }
}

// ---------------------------------------------------------------------------
// ExpansionContext — flags that control word expansion behaviour
// ---------------------------------------------------------------------------

/// Controls the behaviour of the word-expansion engine (`expand_impl_full`).
///
/// Replaces the five separate `bool` parameters that were previously threaded
/// through `expand_impl_inner` / `expand_impl_full`.
#[derive(Debug, Clone, Copy, Default)]
pub struct ExpansionContext {
    /// Start the expansion as if already inside double quotes.
    pub initial_dquote: bool,
    /// Prefix IFS-whitespace characters inside quotes with CTLESC so that
    /// downstream word splitting preserves them.
    pub mark_quoted: bool,
    /// Also CTLESC-mark literal (non-expansion) characters so that
    /// IFS-matching literals like `+` in `$x+$y` (with IFS=+) are
    /// preserved through word splitting.
    pub mark_unquoted_literal: bool,
    /// Suppress `$'…'` ANSI-C quoting (used inside heredocs).
    pub no_ansi_c: bool,
    /// Mark pattern-substitution replacement literals with CTLESC.
    pub mark_patsub_literals: bool,
}

// ---------------------------------------------------------------------------
// Tracked — a value that records when it was last mutated
// ---------------------------------------------------------------------------

/// A wrapper that bumps a monotonic epoch on every mutable access.
///
/// Hot paths that mirror shell state into shell variables (see
/// `Shell::sync_dynamic_vars`) compare the epoch against the one they last
/// observed and skip the rebuild entirely when nothing has changed.  Because
/// the bump happens in `DerefMut`, no call site has to remember to invalidate:
/// any `&mut` borrow — `insert`, `remove`, `clear`, whole-value assignment —
/// counts as a change.
#[derive(Debug, Default)]
pub struct Tracked<T> {
    inner: T,
    epoch: u64,
}

impl<T> Tracked<T> {
    /// Wrap a value.  The initial epoch is 1 so that a zero-initialised
    /// observer always sees the first state as "changed".
    pub fn new(inner: T) -> Self {
        Tracked { inner, epoch: 1 }
    }

    /// The current epoch.  Changes whenever the value is borrowed mutably.
    pub fn epoch(&self) -> u64 {
        self.epoch
    }
}

impl<T: Clone> Clone for Tracked<T> {
    fn clone(&self) -> Self {
        Tracked { inner: self.inner.clone(), epoch: self.epoch }
    }
}

impl<T> std::ops::Deref for Tracked<T> {
    type Target = T;
    fn deref(&self) -> &T {
        &self.inner
    }
}

impl<T> std::ops::DerefMut for Tracked<T> {
    fn deref_mut(&mut self) -> &mut T {
        self.epoch = self.epoch.wrapping_add(1);
        &mut self.inner
    }
}
