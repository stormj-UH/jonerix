#!/usr/bin/env bash
# 14_compgen_generators_and_order.sh — compgen -G / -C / -F semantics,
# -A signal and -A hostname, the fixed generation order of multiple
# actions, the COMP_* environment compgen gives -F/-C, and the unsorted
# `complete -p` walk order (bash's hash table: FNV-1 over the name, 512
# buckets, newest first inside a bucket, in-place update on re-registration).
#
# Every case was first observed against bash 5.3.

tmp=$(mktemp -d) || exit 1
trap 'cd /; rm -rf "$tmp"' EXIT
cd "$tmp" || exit 1

run() { printf '### %s\n' "$*"; ( eval "$*" ); printf '[rc=%s]\n' "$?"; }
f1() { COMPREPLY=(one two); }

touch a.sh b.sh dpr.sh .hid.sh zzfile
mkdir -p sub zzdir
touch sub/c.sh

echo "--- -G: pathname expansion, not filtered by the word ---"
run 'compgen -G "*.sh"'
run 'compgen -G "*.sh" dpr'
run 'compgen -G "*.sh" -- x'
run 'compgen -G "nomatch*"'
run 'compgen -G "*.sh" -X "dp*"'
run 'compgen -G "*.sh" -P "<" -S ">"'
run 'compgen -G "sub/*"'
run 'compgen -G "*"'
run 'compgen -G ".*"'
run 'shopt -s dotglob; compgen -G "*"'
run 'compgen -G "s*/*.sh"'
run 'compgen -G "[ab].sh"'
run 'compgen -G "a.sh"'
run 'compgen -G "none.sh"'

echo "--- generation order: actions, -G, -W, then -F / -C; -F and -C verbatim ---"
run 'compgen -f -G "*.sh" -- d'
run 'compgen -W "zz" -G "*.sh" -- z'
run 'compgen -W "zz" -C "echo yy" -- x'
run 'compgen -W "zz" -C "echo yy" -- z'
run 'compgen -W "a b" -F f1 -- x'
run 'compgen -F f1 o'
run 'compgen -F f1 -- o'
run 'compgen -F f1 -X "!t*" -- o'
run 'compgen -o nosort -W "c a b"'
run 'compgen -C "printf %s\\\\n aa ab" a'
run 'compgen -C "printf %s\\\\n" xx'
run 'compgen -C "printf %s\\\\n"'
run 'compgen -C "printf <%s>\\\\n" a'
run 'compgen -F nosuchfn a'
run 'complete -F nosuchfn zz; compgen -F nosuchfn a'
run 'alias zza=ls; zzf() { :; }; zzv=1; export zze=1; declare -a zzarr=(1); compgen -A variable -A alias -A file -A function -A keyword -A builtin -A export -A directory -A arrayvar -A helptopic -- zz'
run 'compgen -bk -- ti; echo --; compgen -kb -- ti'

echo "--- the COMP_* environment under compgen, unset afterwards ---"
run 'f3() { echo "W=${COMP_WORDS+set} C=${COMP_CWORD+set} L=${COMP_LINE+set} P=${COMP_POINT+set} T=${COMP_TYPE+set} K=${COMP_KEY+set} n=${#COMP_WORDS[@]} cw=$COMP_CWORD"; declare -p COMP_WORDS; }; compgen -F f3 -- abc'
run 'f4() { echo "[1=$1|2=$2|3=$3|L=$COMP_LINE|P=$COMP_POINT|T=$COMP_TYPE|K=$COMP_KEY]"; }; compgen -F f4 -- abc'
run 'compgen -F f1 -- x; echo "L=${COMP_LINE+set} W=${COMP_WORDS+set} C=${COMP_CWORD+set} P=${COMP_POINT+set} T=${COMP_TYPE+set} K=${COMP_KEY+set}"'
run 'compgen -C "sh -c \"env | grep COMP_ | sort\"" a'

echo "--- -A signal ---"
run 'compgen -A signal'
run 'compgen -A signal SIGT'
run 'compgen -A signal -P x SIGK'

echo "--- -A hostname reads HOSTFILE ---"
run 'printf "1.2.3.4 alpha beta\n# comment\n\n5.6.7.8\tgamma delta.example\n" > hostfile; HOSTFILE=hostfile compgen -A hostname; HOSTFILE=hostfile compgen -A hostname g'
run 'printf "1.2.3.4 alpha alpha\n::1 six\nfe80::1%%lo0 seven\n" > hostfile; HOSTFILE=hostfile compgen -A hostname'
run 'printf "  1.2.3.4   ind\n1.2.3.5 # cmt\n1.2.3.6 x#y z\nabc\n" > hostfile; HOSTFILE=hostfile compgen -A hostname'
run 'printf "1a.2 h1\n1 h2\n12345 h3\na:b h4\n1.2.3.4\n1.2.3.4 host#tail\n1.2.3.4 host #tail\n\t1.2.3.4\thost5  \n" > hostfile; HOSTFILE=hostfile compgen -A hostname'
run 'printf "1.2.3.4 h1\n" > hostfile; HOSTFILE=hostfile compgen -A hostname -- 1'
run 'HOSTFILE=/nonexistent compgen -A hostname'
run 'HOSTFILE= compgen -A hostname'

echo "--- complete -p walk order (unsorted) ---"
names="nvfpa br-e ms glfak n.hmmvmty. ak ah oa ob pf qf qw alpha beta gamma delta epsilon zeta eta theta iota kappa lambda mu nu xi omicron pi rho sigma tau upsilon phi chi psi omega
git ls cd cat make cargo python3 ssh scp rsync docker kubectl vim nano less more head tail grep sed awk sort uniq wc find xargs tar gzip curl wget"
run 'complete -W a -D; complete -W a -E; complete -W a -I; for n in $names; do complete -W a "$n"; done; complete -p'
run 'complete -W 1 ak; complete -W 2 ah; complete -W 3 oa; complete -W 4 ob; complete -p; echo --; complete -W 5 ak; complete -p; echo --; complete -r ak; complete -W 6 ak; complete -p'
