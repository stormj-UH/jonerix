#!/usr/bin/env bash
# 12_compgen_actions.sh — compgen action generators: -f, -d, -c, -v, -e, -u,
# -g and the matching -A names.
#
# bash-completion's file helpers are built on `compgen -f` / `compgen -d`, so
# these were the difference between "Tab completes a path" and "Tab does
# nothing" once `complete -D` started loading bash-completion's functions.
#
# Everything runs inside a fixed tree under a controlled PATH so the output is
# identical on any machine.

tmp=$(mktemp -d) || exit 1
trap 'cd /; rm -rf "$tmp"' EXIT
mkdir -p "$tmp/tree/subdir" "$tmp/tree/subdir2/inner" "$tmp/tree/.hiddendir"
mkdir -p "$tmp/bin1" "$tmp/bin2"
touch "$tmp/tree/onlyfile.txt" "$tmp/tree/.hidden" "$tmp/tree/subdir2/inner/deep.txt"
touch "$tmp/tree/sp ace.txt"
printf '#!/bin/sh\n' > "$tmp/bin1/zzcmd"
printf '#!/bin/sh\n' > "$tmp/bin2/zzcmd"
printf '#!/bin/sh\n' > "$tmp/bin2/zzother"
printf 'not executable\n' > "$tmp/bin1/zznotexec"
mkdir "$tmp/bin1/zzdir"
chmod +x "$tmp/bin1/zzcmd" "$tmp/bin2/zzcmd" "$tmp/bin2/zzother"

cd "$tmp/tree" || exit 1

echo "--- -f: files and directories, dotfiles need an explicit dot ---"
compgen -f | sort
echo "--- -f with a prefix ---"
compgen -f -- sub | sort
echo "--- -f with a directory part (no trailing slash added) ---"
compgen -f -- subdir2/
compgen -f -- subdir2/inner/
echo "--- -f -- . includes . and .. ---"
compgen -f -- . | sort
echo "--- -f -- .h ---"
compgen -f -- .h | sort
echo "--- -d: directories only ---"
compgen -d | sort
compgen -d -- subdir2/in
echo "--- -f on a name containing a space ---"
compgen -f -- sp
echo "--- -f on a nonexistent directory (exit status) ---"
compgen -f -- nonexist/
echo "rc=$?"
echo "--- -A file / -A directory are the same generators ---"
compgen -A file -- sub | sort
compgen -A directory -- sub | sort
echo "--- -P/-S wrap and -X filters the generated paths ---"
compgen -f -P x -S y -- sub | sort
compgen -f -X '!*.txt' | sort
echo "--- -v / -e ---"
zzvar=1
export zzexported=1
compgen -v -- zz | sort
compgen -e -- zz | sort
echo "--- -c: aliases, keywords, functions, builtins, then \$PATH in order ---"
PATH="$tmp/bin1:$tmp/bin2"
alias zzalias=ls
zzfunc() { :; }
compgen -c -- zz
echo "--- -c finds keywords and builtins ---"
compgen -c -- tim | sort
echo "--- -A command is -c ---"
compgen -A command -- zzo
