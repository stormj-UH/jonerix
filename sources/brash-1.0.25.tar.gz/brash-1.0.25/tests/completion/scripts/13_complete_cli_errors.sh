#!/usr/bin/env bash
# 13_complete_cli_errors.sh — complete / compgen / compopt command-line
# fidelity: error texts and exit statuses, option clusters and attached
# arguments, -p/-r interplay, and the `complete -p` print form.
#
# Every case here was first observed against bash 5.3; stderr and the exit
# status are part of the comparison.

run() { printf '### %s\n' "$*"; ( eval "$*" ); printf '[rc=%s]\n' "$?"; }
f1() { COMPREPLY=(one two); }

# Invalid option / action names exit 2, a missing argument prints the usage
run 'complete -o bogus x'
run 'complete -A bogus x'
run 'compgen -o bogus'
run 'compgen -A bogus'
run 'complete -X'
run 'complete -o'
run 'complete -F'
run 'compgen -W'
run 'compgen -F'
run 'compgen -V'
run 'compgen -V 1x -W a'
run 'complete -V x'
run 'complete -w'
run 'compgen -p'
run 'compgen -r'
run 'compopt +o'
run 'compopt -o'
run 'compopt -x'
run 'compopt -oD nospace'
run 'compopt -Do nospace'
run 'compopt +o nospace'
run 'compopt'
run 'compopt -D'
run 'compopt -o nospace -D nosuch'

# Attached arguments and clusters
run 'complete -Wfoo x; complete -p x'
run 'complete -W "a b" -Pfoo x; complete -p x'
run 'complete -ofilenames x; complete -p x'
run 'compgen -Varr -W "a b"; declare -p arr'
run 'compgen -V arr -W "a b"; declare -p arr'
run 'complete -pW a x'
run 'complete -DW a; complete -p -D'
run 'complete -Dp'
run 'complete -DEI -W a; complete -p -D -E -I'
run 'complete -W a -- x; complete -p x'
run 'complete -- -W a x'
run 'complete -o filenames'
run 'complete -o filenames -r'
run 'complete -r -o filenames x'

# -p wins over -r; removing an unknown name is only an error once something
# is registered
run 'complete -pr'
run 'complete -rp'
run 'complete -r nothing'
run 'complete -W a x; complete -r nothing'
run 'complete -r'
run 'complete -p nothing'
run 'complete -p'
run 'complete -W a x; complete -W b y; complete -pr; echo after; complete -p'
run 'complete -W a x; complete -r -p x; complete -p'
run 'complete -pr x'
run 'complete -p x y'
run 'complete -W a x y; complete -p y x'
run 'complete -p -W a x'

# Print form: options and flags sorted, -A names, then G W P S X C F;
# repeated -X/-F keep the last, repeated -o prints once
run 'complete -W "a b" -F f1 -X "*" -P p -S s -G g -C c -o nospace -abcdefgjksuv -A alias x; complete -p x'
run 'complete -A arrayvar -a -A helptopic x; complete -p x'
run 'complete -vfd x; complete -p x'
run 'complete -A file -A directory -A variable x; complete -p x'
run 'complete -A arrayvar -G g -W w -F f -C c -X x -P p -S s -o nospace -o default x; complete -p x'
run 'complete -A binding -A disabled -A enabled -A export -A function -A group -A hostname -A job -A keyword -A running -A service -A setopt -A shopt -A signal -A stopped -A user x; complete -p x'
run 'complete -X "a" -X "b" x; complete -p x'
run 'complete -F f1 -F f2 x; complete -p x'
run 'complete -o nospace -o default -o bashdefault -o plusdirs -o nosort -o dirnames -o filenames -o noquote -o fullquote x; complete -p x'
run 'complete -o filenames -o filenames x; complete -p x'
run 'complete -X "" x; complete -W "" y; complete -P "" z; complete -p x y z'
run 'complete -C "echo" x; complete -p x'

# compopt inside `compgen -F` outside any live completion
run 'f2() { compopt; compopt -o nospace; compopt; echo inner-rc=$?; }; complete -F f2 zz; compgen -F f2 a; echo rc=$?'
run 'complete -W a -D; compopt -D; compopt'
