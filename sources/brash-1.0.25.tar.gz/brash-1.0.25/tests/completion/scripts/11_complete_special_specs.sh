#!/usr/bin/env bash
# 11_complete_special_specs.sh — complete -D / -E / -I and compopt.
# Tests: registering the default (-D), empty-line (-E) and initial-word (-I)
#        specs; -D > -E > -I precedence; NAMEs ignored alongside -D;
#        complete -p -D/-E/-I; complete -r -D; an empty NAME; compopt with
#        NAMEs (-o / +o, print form, -D); error paths and exit codes.

_def() { :; }
_empty() { :; }
_init() { :; }

# Register all three special specs and print each one back
complete -F _def -D
complete -F _empty -E
complete -F _init -I
complete -p -D
complete -p -E
complete -p -I
echo "---"

# They show up in the full listing (sorted: bash's hash-walk order is not
# part of the contract) alongside regular names
complete -W "one two" regular
complete -p | sort
echo "---"

# -D takes precedence over -E, and both take precedence over -I
complete -o nospace -F _def -DE
complete -F _init -IE
complete -W "x" -ID
complete -p -D
complete -p -E
complete -p -I
echo "---"

# NAMEs supplied with -D are ignored entirely
complete -W "a b" -D ignored_name
complete -p -D
complete -p ignored_name
echo "rc=$?"
echo "---"

# Options print in bash's order, and the flag comes last
complete -o bashdefault -o default -F _def -D
complete -p -D
echo "---"

# compopt with a NAME edits that spec; +o removes; no options prints
complete -F _def cat
compopt -o nospace cat
complete -p cat
compopt +o nospace cat
complete -p cat
compopt -o default -o filenames cat
complete -p cat
compopt cat
compopt -o dirnames -D
complete -p -D
compopt -D
compopt +o dirnames +o default +o bashdefault -D
complete -p -D
echo "---"

# `complete -E` with no actions registers an empty spec
complete -r -E
complete -E
complete -p -E
echo "---"

# Removing the special slots; removing an unregistered one is an error
# that names bash's internal slot
complete -r -D
complete -r -E
complete -r -I
complete -p | sort
complete -r -D
echo "rc=$?"
echo "---"

# Printing an unregistered special slot is an error naming bash's internal slot
complete -p -D
echo "rc=$?"
compopt -o default -E
echo "rc=$?"
echo "---"

# An empty NAME prints as ''
complete -F _def ''
complete -p ''
echo "---"

# compopt outside a completion function, invalid names and options
compopt -o default
echo "rc=$?"
compopt -o nospace nosuchcmd
echo "rc=$?"
compopt -o bogus cat
echo "rc=$?"
compopt -x cat
echo "rc=$?"
compgen -D
echo "rc=$?"
echo "---"

# After getopt stops at a NAME, a later -D is just another NAME
complete -p cat -D
echo "rc=$?"
