#!/bin/bash
# Bashism: `-n` reads a script without running anything (even loops), and
# a `-c` string keeps its valid UTF-8 intact for builtins like `cd`.

tmp=$(mktemp -d)
trap 'rm -rf "$tmp"' EXIT
printf 'while false; do :; done\necho AFTER\n' > "$tmp/w.sh"
"$BASH" -n "$tmp/w.sh"; echo "-n while: $?"
printf 'echo a\nset -n\necho b\nwhile false; do :; done\necho c\n' > "$tmp/sn.sh"
"$BASH" "$tmp/sn.sh"
mkdir "$tmp/ಇಳಿ"
( cd "$tmp" && "$BASH" -c 'cd ಇಳಿ && echo utf8-cd-ok' )
"$BASH" -c 'printf "%s\n" "$1"' _ 'ಇಳಿ'
