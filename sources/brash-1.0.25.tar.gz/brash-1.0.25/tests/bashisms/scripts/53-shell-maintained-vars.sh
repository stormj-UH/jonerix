#!/bin/bash
# Bashism: the variables the shell maintains itself stay correct when the
# state behind them changes — and assigning to SECONDS moves its origin
# rather than storing a number.

SECONDS=100; echo "SECONDS=$SECONDS"
SECONDS=0; echo "SECONDS=$SECONDS"
declare -p SECONDS

alias one='echo 1'
echo "alias one: ${BASH_ALIASES[one]}"
alias one='echo 2'
echo "alias one: ${BASH_ALIASES[one]}"
unalias one
echo "after unalias: ${BASH_ALIASES[one]-unset}"

true | false | true
echo "pipestatus: ${PIPESTATUS[*]}"
false | true
echo "pipestatus: ${PIPESTATUS[*]}"

f() { echo "funcname: ${FUNCNAME[0]} depth=${#FUNCNAME[@]}"; g; }
g() { echo "funcname: ${FUNCNAME[0]} caller=${FUNCNAME[1]}"; }
f
echo "funcname outside: ${FUNCNAME[0]-unset}"

echo "flags: $-"
set -u
echo "flags: $-"
set +u
case ":$SHELLOPTS:" in *:braceexpand:*) echo "shellopts has braceexpand" ;; esac
set -f
case ":$SHELLOPTS:" in *:noglob:*) echo "shellopts has noglob" ;; esac
set +f
case ":$SHELLOPTS:" in *:noglob:*) echo "still noglob" ;; *) echo "noglob gone" ;; esac

shopt -s extglob
case ":$BASHOPTS:" in *:extglob:*) echo "bashopts has extglob" ;; esac
shopt -u extglob
case ":$BASHOPTS:" in *:extglob:*) echo "still extglob" ;; *) echo "extglob gone" ;; esac

hash -r
/bin/echo hashed >/dev/null
echo "cmds: ${BASH_CMDS[/bin/echo]-none}"

echo "status: $?"
false
echo "status: $?"
(exit 42)
echo "status: $?"
