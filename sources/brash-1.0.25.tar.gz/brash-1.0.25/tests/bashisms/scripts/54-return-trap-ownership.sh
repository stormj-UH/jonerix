#!/bin/bash
# Bashism: a RETURN trap set inside a function fires when that function
# returns, in every context; one merely inherited from the caller does not
# fire without `set -o functrace`.

foo() { trap 'echo ret' RETURN; echo bar; }
foo
foo | cat
foo & wait
x=$(foo); echo "[$x]"
( foo )

baz() { echo B; }
baz

h() { trap 'echo R' RETURN; echo h; }
g() { h; echo g-after; }
g

trap 'echo outer' RETURN
q() { echo q; }
q
trap - RETURN
q

set -o functrace
r() { echo r; }
trap 'echo traced' RETURN
r
trap - RETURN
set +o functrace
