#!/bin/bash
# Bashism-adjacent: a child process sees the command word as typed in argv[0],
# not the path the shell resolved it to.  GNU tools print argv[0] in their
# diagnostics, so `grep: …` must never come out as `/usr/bin/grep: …`.

sh -c 'echo "$0"'
env sh -c 'echo "$0"'
( cd /bin && ./sh -c 'echo "$0"' )
/bin/sh -c 'echo "$0"'

# A script found through PATH runs with $0 set to the path that was found.
tmp=$(mktemp -d)
trap 'rm -rf "$tmp"' EXIT
printf '#!/bin/sh\necho "$0"\n' > "$tmp/zzargv"
chmod +x "$tmp/zzargv"
PATH="$tmp:$PATH" zzargv | sed "s|$tmp|TMP|"
# ...and the same script without a shebang, which the shell runs itself.
printf 'echo "[$0]"\n' > "$tmp/zznoshebang"
chmod +x "$tmp/zznoshebang"
PATH="$tmp:$PATH" zznoshebang | sed "s|$tmp|TMP|"
