#!/bin/bash
# Bashism: `ulimit` reports every limit the platform has, in bash's order and
# layout, and the pipe size that no one can change.

ulimit -a
echo "---"
ulimit -p
ulimit -p 4 2>&1 | sed 's/^[^ ]*: //'
echo "rc=$?"
echo "---"
for f in c d f l m n s t u v; do
    printf '%s: soft=%s hard=%s\n' "$f" "$(ulimit -S -$f)" "$(ulimit -H -$f)"
done
