#!/bin/bash
# Bashism: an EXIT trap runs on the way out but does not change the exit
# status -- `exit N`, errexit and `set -u` keep theirs unless the trap body
# itself runs `exit`.  A bare `exit` inside an EXIT, ERR or signal trap uses
# the status from before the trap; a DEBUG trap's uses the current one.  A
# subshell never runs the EXIT trap it inherited ($( ), <( ), &, a coproc,
# a pipeline element), though `trap -p` still lists it until the subshell
# changes a trap.  `exit` wins over the `if`/`while`/`!` around it.

tmp=$(mktemp -d)
trap 'rm -rf "$tmp"' EXIT

t() {
    printf -- '--- %s\n' "$1"
    "$BASH" -c "$1" 2>/dev/null
    echo "rc=$?"
}

# exit N, bare exit, errexit, set -u
t 'trap "echo t" EXIT; exit 3'
t 'trap true EXIT; exit 5'
t 'trap false EXIT; exit 3'
t 'f(){ :; }; trap f EXIT; exit 12'
t 'trap : EXIT; false; exit'
t 'trap "echo in=\$?" EXIT; exit 3'
t 'set -e; trap "echo x" EXIT; false; echo not-reached'
t 'set -e; trap "echo x" EXIT; exit 4'
t 'set -o pipefail; set -e; trap "echo t" EXIT; false | true; echo nr'
t 'set -u; trap "echo t" EXIT; echo $undefined_var; echo nr'
t 'trap : EXIT; false'
t 'trap "echo t" EXIT; while :; do exit 5; done'
t 'trap "echo t" EXIT; eval "exit 5"'
t 'f(){ exit 4; }; trap "echo t" EXIT; f; echo nr'
t 'f(){ return 7; }; trap "echo t" EXIT; f || exit $?'
t 'trap "echo t" EXIT; exit 300'
t 'trap "echo t" EXIT; exit -1'

# the trap body decides only when it runs exit itself (or trips errexit)
t 'trap "exit 7" EXIT; exit 3'
t 'trap exit EXIT; exit 3'
t 'trap "(exit 9)" EXIT; exit 3'
t 'trap "echo t; exit" EXIT; exit 3'
t 'trap "false; exit" EXIT; true'
t 'trap "(exit 7); eval exit" EXIT; exit 3'
t 'trap "(exit 7); x=\$(exit); echo \$?" EXIT; exit 3'
t 'trap "sub() { (exit 9); exit; }; sub" EXIT; exit 3'
t 'trap "trap - EXIT; exit 2" EXIT; exit 3'
t 'set -e; trap "false; :" EXIT; exit 3'
t 'trap '\''rc=$?; echo cleanup; exit $rc'\'' EXIT; exit 3'

# exit inside a condition or under ! still ends the shell with its status
t 'if exit 3; then :; fi'
t 'trap "echo t" EXIT; if exit 3; then :; fi'
t 'while exit 4; do :; done'
t '! exit 3; echo nr'

# exit in ERR, DEBUG and signal traps
t 'trap "echo e; exit 3" ERR; false; echo nr'
t 'set -e; trap "echo e; exit 3" ERR; false; echo nr'
t 'trap "echo t" EXIT; trap "exit 4" ERR; false; echo nr'
t 'trap "(exit 7); exit" ERR; false; echo nr'
t 'trap "(exit 7); exit" DEBUG; (exit 5); echo nr'
t 'trap "echo u; exit 9" USR1; kill -USR1 $$; echo nr'
t 'trap "echo t" EXIT; trap "echo term; exit 9" TERM; kill -TERM $$; echo nr'

# subshells: ( ), $( ), <( ), &, pipelines, coproc
t '( trap "echo t" EXIT; exit 8 ); echo rc=$?'
t '( set -e; trap "echo t" EXIT; false; echo nr ); echo rc=$?'
t '( trap "echo t; false" EXIT; true ); echo rc=$?'
t 'x=$( trap "echo t" EXIT; exit 6 ); echo "x=$x rc=$?"'
t 'x=$( trap "echo t" EXIT; false ); echo "x=$x rc=$?"'
t 'x=$( set -e; trap "echo t" EXIT; false; echo nr ); echo "x=$x rc=$?"'
t '{ trap "echo t" EXIT; exit 4; } | cat; echo ${PIPESTATUS[@]}'
t '{ set -e; trap "echo t" EXIT; false; echo nr; } | cat; echo ${PIPESTATUS[@]}'
t 'trap "echo t" EXIT; x=$(exit 1); echo "x=[$x] $?"'
t 'trap "echo t" EXIT; { exit 3; } & wait $!; echo $?'
t 'trap "echo t" EXIT; f(){ exit 3; }; f & wait $!; echo $?'
t 'trap "echo t" EXIT; ( trap "echo in" EXIT; true ) & wait $!; echo $?'
t 'trap "echo t" EXIT; ( trap "echo in" EXIT; exit 4 ) & wait $!; echo $?'
t 'trap "echo t" EXIT; cat <(echo a; exit 3)'
t 'trap "echo t" EXIT; cat <(trap "echo in" EXIT; echo a)'
t 'trap "echo t" EXIT; coproc { exit 3; }; wait $!; echo $?'
t 'trap "echo t" EXIT; ( ( trap "echo in2" EXIT; exit 3 ); echo $? )'

# trap -p in a subshell lists the parent's EXIT trap until a trap changes
t 'trap "echo t" EXIT; x=$(trap -p EXIT); echo "[$x]"'
t 'trap "echo t" EXIT; ( trap -p EXIT; exit 2 ); echo $?'
t 'trap "echo t" EXIT; echo | { trap -p EXIT; }'
t 'trap "echo t" EXIT; x=$(trap "" USR1; trap -p EXIT); echo "[$x]"'
t 'trap "echo t" EXIT; ( trap - EXIT; trap -p EXIT ); echo x'
t 'trap "echo t" EXIT; ( trap "echo u" EXIT; trap -p EXIT )'

# logout takes a status like exit
mkdir "$tmp/home"
HOME="$tmp/home" "$BASH" --login --noprofile -c 'trap "echo t" EXIT; logout 3'
echo "logout rc=$?"

# a script file and stdin behave as -c does
printf 'trap "echo cleanup" EXIT\nexit 9\n' > "$tmp/s.sh"
"$BASH" "$tmp/s.sh"; echo "script rc=$?"
"$BASH" < "$tmp/s.sh"; echo "stdin rc=$?"

# return in a sourced file stops the file even when a later line is shopt
printf 'if true; then\n  return 3\nfi\nshopt -s nullglob\necho not-reached\n' > "$tmp/rc"
. "$tmp/rc"; echo "source rc=$?"
