#!/bin/bash
# Bashism: `test` follows the argument-count rules — a unary operator with
# no operand is just a non-empty string, and `-a` / `-o` between operands
# are connectives.

test -t; echo "test -t: $?"
test -n xx -a -t; echo "-n xx -a -t: $?"
test -n xx -a -z "" -a -t; echo "-n xx -a -z '' -a -t: $?"
[ -t -a xx ]; echo "[ -t -a xx ]: $?"
test -z -a; echo "-z -a: $?"
test -n -a; echo "-n -a: $?"
test -e -a -t; echo "-e -a -t: $?"
test ! -t; echo "! -t: $?"
test -t 0 -a -t </dev/null; echo "-t 0 -a -t (stdin closed): $?"
test -n xx -a -z "" -a -t 0 -a -t </dev/null; echo "long chain: $?"
