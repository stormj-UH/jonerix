#!/bin/bash
# Bashism: `\[` and `\]` in a prompt mark non-printing text for the line
# editor.  Without line editing (a script, `--noediting`) bash drops them,
# so `${PS1@P}` and a PS4 trace carry no \001/\002 bytes.  `set -o emacs`
# or `set -o vi` turns line editing on, and an interactive shell starts in
# emacs mode.  PS3 is printed as it is: no prompt escapes, no expansion.

PS1='\[\e[34m\]P\[\e[0m\]> '
printf '%s' "${PS1@P}" | od -An -c
x='\[x\]y'
printf '%s\n' "${x@P}"
x='a\[b'
printf '%s\n' "${x@P}"
x='a\]b'
printf '%s\n' "${x@P}"
x='\[\]'
printf '[%s]\n' "${x@P}"

PS4='\[z\]+ ' "$BASH" -xc 'true' 2>&1

v=5
PS3='\[W\]$v \u? '
select c in one; do echo "$c"; break; done <<< 1 2>&1


# `set -o emacs` or `set -o vi` turns line editing on even in a script, and
# then the markers stay in ${var@P}; the two modes exclude each other
x='\[x\]y'
set -o emacs
printf '%s' "${x@P}" | od -An -c
set -o vi
set -o | grep -E '^(emacs|vi) '
set +o vi
printf '%s' "${x@P}" | od -An -c

# an interactive shell starts in emacs mode unless --noediting
c='set -o | grep -E "^(emacs|vi) "; x="\[a\]"; printf %s "${x@P}" | od -An -c'
"$BASH" --norc --noprofile -ic "$c" 2>/dev/null
"$BASH" --norc --noprofile --noediting -ic "$c" 2>/dev/null
