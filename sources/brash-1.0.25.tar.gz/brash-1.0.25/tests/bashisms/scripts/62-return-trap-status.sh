#!/bin/bash
# Bashism: a RETURN trap runs in full when its function (or sourced file)
# ends with an explicit `return`, sees `$?` as it was before that
# `return`, and does not change the status the function returns -- unless
# the trap body runs `exit` or trips errexit.  `trap 'rm -f "$tmp"' RETURN`
# must not turn `return 1` into success.

tmp=$(mktemp -d)
trap 'cd / && rm -rf "$tmp"' EXIT
cd "$tmp" || exit 1

t() {
    printf -- '--- %s\n' "$1"
    "$BASH" -c "$1" 2>/dev/null
    echo "rc=$?"
}

# the whole trap body runs, and the return status survives it
t 'f(){ trap "echo a; echo b" RETURN; return 2; }; f; echo "after $?"'
t 'f(){ trap "echo r" RETURN; return 2; }; f; echo "after $?"'
t 'f(){ trap "(exit 9)" RETURN; return 2; }; f; echo "after $?"'
t 'f(){ trap "true" RETURN; return 1; }; if f; then echo yes; else echo no; fi'
t 'f(){ trap "true" RETURN; return 1; }; f || echo "failed $?"'
t 'f(){ local t=$1; trap "rm -f \"$t\"" RETURN; : > "$t"; return 3; }; f x; echo "after $? [$(ls)]"'
t 'g(){ return 3; }; f(){ trap "echo a; echo b" RETURN; g; }; f; echo "after $?"'
t 'f(){ trap "echo a; false" RETURN; (exit 5); }; f; echo "after $?"'

# $? inside the trap is the status from before `return`
t 'f(){ trap "echo in=\$?" RETURN; false; return 2; }; f; echo "after $?"'
t 'f(){ trap "echo in=\$?" RETURN; (exit 4); return; }; f; echo "after $?"'
t 'f(){ trap "echo in=\$?" RETURN; return 3; }; false; f; echo "after $?"'
t 'g(){ return 6; }; f(){ trap "echo in=\$?" RETURN; g; }; false; f; echo "after $?"'

# exit or errexit in the trap body ends the shell with its status
t 'f(){ trap "echo ret; exit 6" RETURN; return 2; }; f; echo "after $?"'
t 'trap "echo t" EXIT; f(){ trap "echo ret; exit 6" RETURN; return 2; }; f; echo nr'
t 'f(){ trap "echo ret; exit 6" RETURN; :; }; f; echo "after $?"'
t 'f(){ trap "exit" RETURN; return 2; }; f; echo "after $?"'
t 'set -e; f(){ trap "false; echo x" RETURN; return 0; }; f; echo "after $?"'

# functrace (set -T) and a trap set outside the function
t 'set -T; trap "echo ret" RETURN; f(){ return 4; }; f; echo "after $?"'

# a sourced file that ends with return
printf 'trap "echo a; echo b" RETURN\nreturn 4\n' > r1
printf 'trap "echo in=\\$?" RETURN\nfalse\nreturn 4\n' > r2
printf 'trap "echo a; (exit 7)" RETURN\ntrue\n' > r3
t '. ./r1; echo "after $?"'
t '. ./r2; echo "after $?"'
t '. ./r3; echo "after $?"'
