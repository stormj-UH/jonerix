#!/bin/bash
# Bashism: `shopt -s nocasematch` applies to `[[ =~ ]]` as well as to
# pattern matching, and BASH_REMATCH follows the same rules.

[[ ABC =~ ^abc$ ]] && echo "case-sensitive: match" || echo "case-sensitive: no match"
shopt -s nocasematch
[[ ABC =~ ^abc$ ]] && echo "nocasematch: match" || echo "nocasematch: no match"
[[ FooBar123 =~ ^([a-z]+)([0-9]+)$ ]] && echo "captures: ${BASH_REMATCH[1]}/${BASH_REMATCH[2]}"
shopt -u nocasematch
[[ ABC =~ ^abc$ ]] && echo "restored: match" || echo "restored: no match"

# The same pattern evaluated repeatedly keeps its captures per evaluation.
for s in a1 b22 c333; do
    if [[ $s =~ ^([a-z])([0-9]+)$ ]]; then
        echo "$s -> ${BASH_REMATCH[1]} ${BASH_REMATCH[2]} (${#BASH_REMATCH[@]})"
    fi
done
[[ zz =~ ^([a-z])([0-9]+)$ ]] || echo "no match clears: [${BASH_REMATCH[*]}]"
