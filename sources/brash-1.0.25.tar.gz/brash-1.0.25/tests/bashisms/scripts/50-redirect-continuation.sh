#!/bin/bash
# Bashism: a backslash-newline between a compound command and its
# redirections is a line continuation (gzip's zdiff writes `( … ) \` then
# `5<&0` on the next line).

echo X | (cat >/dev/null 2>&1) \
  5<&0 && echo subshell-ok
{ cat; } \
  <<< brace-ok
if
  echo X |
   (echo X | cat /dev/fd/5 - >/dev/null 2>&1) \
          5<&0
then echo if-ok; fi </dev/null
f() { cat; }
f \
  <<< func-ok
