#!/bin/bash
# Bashism: printf %q reproduces bash's quoting choices — `=` is never
# escaped, `,` always is, `#` and `~` only at the start of a word, and in a
# UTF-8 locale printable multibyte characters are left alone (the C locale
# octal-escapes them).

for s in '=' ',' 'a=b' 'x#' '##' 'a#' '#a' '~' '~a' 'a~' 'é' 'aé' 'é=b' 'é,b' '' ' ' '!' 'a b' "'" '"' '$x' '`' '*' '[x]' '{a}' '|' '&;<>' '?' '^' '(' ')' '%' '@' '+' ':/._-'; do
    printf '%q\n' "$s"
done
printf '%q\n' "$(printf 'a\tb')"
printf '%q\n' "$(printf 'a\177b')"
echo "--- C locale ---"
env LANG=C LC_ALL=C "$BASH" -c 'printf "%q\n" "é" "aé" "a=b" ","'
echo "--- ${var@Q} ---"
for s in '=' 'a,b' "it's" 'é'; do v=$s; echo "${v@Q}"; done
