#!/bin/bash
# Bashism: here-documents and here-strings deliver their body whole, whatever
# the size and whoever reads them — builtin, external command, or a redirect
# on a compound command.

read -r line <<EOF
first $((1 + 1))
