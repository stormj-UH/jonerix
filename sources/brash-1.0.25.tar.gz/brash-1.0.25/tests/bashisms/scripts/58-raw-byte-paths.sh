#!/bin/bash
# Bashism: a filename whose bytes are not valid UTF-8 survives every path the
# shell takes it through — globbing, redirection, the file tests, `source`
# and `cd`.  Filesystems that reject such names (APFS) skip the body.

tmp=$(mktemp -d) || exit 1
trap 'rm -rf "$tmp"' EXIT
cd "$tmp" || exit 1

name=$'raw\xe9name'
if ! : > "$name" 2>/dev/null; then
    echo "skipped: filesystem rejects non-UTF-8 names"
    exit 0
fi

echo "glob: $(echo raw*)"
printf 'hello\n' > "$name"
echo "read back: $(cat "$name")"
[ -e "$name" ] && echo "test -e: yes" || echo "test -e: no"
[ -f "$name" ] && echo "test -f: yes" || echo "test -f: no"
[ -s "$name" ] && echo "test -s: yes" || echo "test -s: no"
[ -r "$name" ] && echo "test -r: yes" || echo "test -r: no"
[[ -f $name ]] && echo "[[ -f ]]: yes" || echo "[[ -f ]]: no"

printf 'echo sourced-ok\n' > "$name"
source "$name"

mkdir $'dir\xe9' && cd $'dir\xe9' && echo "cd: ${PWD##*/}" && cd ..
: > $'dir\xe9/inner'
echo "nested glob: $(echo dir*/inner)"

for f in raw*; do echo "loop sees ${#f} bytes"; done
