#!/bin/bash
# Bashism: extended globs are syntax only while `shopt -s extglob` is on, and
# the option is read as each command is parsed — a `shopt` earlier in the
# script turns the syntax on for the lines that follow.  Patterns inside
# `[[ … ]]` take the extended operators either way.

x=abcabc
echo "off #@(a|b): ${x#@(a|b)}"
echo "off ##+(a): ${x##+(a)}"
echo "off /@(a|b): ${x/@(a|b)/Z}"
[[ abc == @(a|x)bc ]] && echo "off [[ @( ]]: match" || echo "off [[ @( ]]: no match"
[[ aaa == +(a) ]] && echo "off [[ +( ]]: match" || echo "off [[ +( ]]: no match"

shopt -s extglob
echo "on  #@(a|b): ${x#@(a|b)}"
echo "on  ##+(a): ${x##+(a)}"
echo "on  /@(a|b): ${x/@(a|b)/Z}"
echo "on  //@(a|b): ${x//@(a|b)/Z}"
y=file.tar.gz
echo "on  %%?(.tar).gz: ${y%%?(.tar).gz}"
case abc in +(a|b)c) echo "on  case: match" ;; *) echo "on  case: no match" ;; esac
case abc in @(x|y)) echo "on  case: wrong" ;; *) echo "on  case: fell through" ;; esac
z=xyz
echo "on  /!(x): ${z/!(x)/Q}"
shopt -u extglob
echo "off again: ${x#@(a|b)}"
