#!/bin/bash
# Bashism: a shell running as root does not take PS4 from the environment
# -- `set -x` would otherwise run the command substitutions in an inherited
# PS4 with root's privileges.  PS4 stays exported, with the default value.
# Any other user inherits PS4 like every other variable, so this script
# prints the same thing under bash and brash whoever runs it.

PS4='E+ ' "$BASH" -xc 'true' 2>&1
PS4='$(echo S)+ ' "$BASH" -xc 'true' 2>&1
PS4='E+ ' "$BASH" -c 'printf "[%s]\n" "$PS4"; env | grep "^PS4="'

# set inside the shell, PS4 is used as given
"$BASH" -c 'PS4="I+ "; set -x; true' 2>&1
