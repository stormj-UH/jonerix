#!/bin/bash
# Bashism: `~` expands to the current value of $HOME, an empty HOME expands
# to nothing, and only an unset HOME falls back to the password database.
# (homebrew's macOS bash keeps a stale tilde home; vanilla bash does not.)

HOME=/usr/xyz
echo ~/foo
SHELL=~/bash
echo "$SHELL"
p=/usr/ucb:/bin:~/bin:~/tmp/bin
echo "$p"
export HOME=/usr/abc
echo ~ ~/x
HOME=/x echo ~
HOME=
echo "[~]"
unset HOME
[ "$(echo ~)" = "$(cd; pwd -P 2>/dev/null || echo ~)" ] && echo "unset HOME uses passwd"
