#!/bin/bash
# Bashism: process substitution bodies are handed to the child shell
# verbatim — quotes, parentheses and expansions inside them belong to the
# child, and substitutions nest.

cat <(echo ")")
cat <(echo 'x)')
cat <(echo "(")
cat <(printf 'a)b\n')
cat <(echo "))")
diff <(echo ")") <(echo ")") && echo same
cat <(echo "a (1)" | sed "s/ ([0-9]*)//")
cat <(cat <(echo nested))
cat <(cat <(cat <(echo deep)))
x="1 2"
cat <(echo $x) <(echo "$x")
y=Q
cat <(echo "$y" "${y}z" $(echo cs) `echo bt`)
f() { cat "$1"; }
f <(echo viafn)
cat < <(echo redir)
while read -r l; do echo "got $l"; done < <(printf 'a\nb\n')
echo "$(cat <(echo inside))"
cat <(echo a b) <(echo "c  d")

# A process substitution as a redirection target is resolved to /dev/fd/N,
# so its command text is never word-split or opened as a file name.
tmp=$(mktemp -d)
trap 'rm -rf "$tmp"' EXIT
echo redirected > >(cat > "$tmp/out"); sleep 0.3; cat "$tmp/out"
exec 3> >(cat > "$tmp/out3"); echo via-fd3 >&3; exec 3>&-; sleep 0.3; cat "$tmp/out3"
{ echo group; } > >(cat > "$tmp/outg"); sleep 0.3; cat "$tmp/outg"
echo to-stderr 2> >(cat > "$tmp/oute") >&2; sleep 0.3; cat "$tmp/oute"
