#![forbid(unsafe_code)]
#![deny(warnings)]

use fancy_regex::RegexBuilder;
use num_bigint::BigInt;
use num_traits::{ToPrimitive, Zero};
use std::cmp::Ordering;
use std::env;
use std::ffi::OsString;
use std::path::Path;
use std::process;

const VERSION: &str = env!("CARGO_PKG_VERSION");

/// Maximum nesting depth for parenthesised sub-expressions.
/// Prevents unbounded recursive descent from causing a stack overflow.
/// Chosen well below the empirical crash point (~5 421 on an 8 KiB stack).
const MAX_DEPTH: usize = 256;

/// Maximum number of bits in a BigInt operand or result.
/// 4 096 bits ≈ 1 233 decimal digits — large enough for any legitimate use
/// of `expr` and prevents multi-second allocations / stringify passes from
/// inputs like 500 000-digit literals.
const MAX_BIGINT_BITS: u64 = 4096;

#[derive(Clone, Debug, Eq, PartialEq)]
struct Value(String);

impl Value {
    fn string(s: impl Into<String>) -> Self {
        Self(s.into())
    }

    fn integer(n: BigInt) -> Self {
        Self(n.to_string())
    }

    fn int_literal(n: i32) -> Self {
        Self(n.to_string())
    }

    #[inline]
    fn as_int(&self) -> Option<BigInt> {
        parse_integer(&self.0)
    }

    #[inline]
    fn is_false(&self) -> bool {
        // Fast path: empty string or a string of zeros (with optional leading '-')
        // avoids a full BigInt allocation for the common "0" case.
        if self.0.is_empty() {
            return true;
        }
        if is_numeric_zero(&self.0) {
            return true;
        }
        false
    }
}

#[derive(Debug)]
enum ExprError {
    MissingOperand,
    Syntax(String),
    Eval(String),
}

impl ExprError {
    fn code(&self) -> i32 {
        2
    }
}

#[derive(Debug)]
struct Parser {
    tokens: Vec<String>,
    pos: usize,
    previous: Option<String>,
    depth: usize,
}

impl Parser {
    fn new(tokens: Vec<String>) -> Self {
        Self {
            tokens,
            pos: 0,
            previous: None,
            depth: 0,
        }
    }

    fn parse_all(&mut self, eval: bool) -> Result<Value, ExprError> {
        let value = self.parse_or(eval)?;
        if let Some(token) = self.peek() {
            return Err(ExprError::Syntax(format!(
                "unexpected argument {}",
                quote(token)
            )));
        }
        Ok(value)
    }

    fn peek(&self) -> Option<&str> {
        self.tokens.get(self.pos).map(String::as_str)
    }

    fn consume(&mut self) -> Option<String> {
        let token = self.tokens.get(self.pos).cloned()?;
        self.pos += 1;
        self.previous = Some(token.clone());
        Some(token)
    }

    fn consume_if(&mut self, token: &str) -> bool {
        if self.peek() == Some(token) {
            self.consume();
            true
        } else {
            false
        }
    }

    fn missing_after_previous(&self) -> ExprError {
        if let Some(previous) = &self.previous {
            ExprError::Syntax(format!("missing argument after {}", quote(previous)))
        } else {
            ExprError::MissingOperand
        }
    }

    fn parse_or(&mut self, eval: bool) -> Result<Value, ExprError> {
        let mut left = self.parse_and(eval)?;
        while self.consume_if("|") {
            let right_eval = eval && left.is_false();
            let right = self.parse_and(right_eval)?;
            if eval && left.is_false() {
                left = if right.is_false() {
                    Value::int_literal(0)
                } else {
                    right
                };
            }
        }
        Ok(left)
    }

    fn parse_and(&mut self, eval: bool) -> Result<Value, ExprError> {
        let mut left = self.parse_cmp(eval)?;
        while self.consume_if("&") {
            let right_eval = eval && !left.is_false();
            let right = self.parse_cmp(right_eval)?;
            if eval {
                left = if !left.is_false() && !right.is_false() {
                    left
                } else {
                    Value::int_literal(0)
                };
            }
        }
        Ok(left)
    }

    fn parse_cmp(&mut self, eval: bool) -> Result<Value, ExprError> {
        let mut left = self.parse_add(eval)?;
        while let Some(op) = self.comparison_op() {
            self.consume();
            let right = self.parse_add(eval)?;
            if eval {
                left = compare_values(&left, &right, op);
            }
        }
        Ok(left)
    }

    fn comparison_op(&self) -> Option<&'static str> {
        match self.peek()? {
            "<" => Some("<"),
            "<=" => Some("<="),
            "=" => Some("="),
            "!=" => Some("!="),
            ">=" => Some(">="),
            ">" => Some(">"),
            _ => None,
        }
    }

    fn parse_add(&mut self, eval: bool) -> Result<Value, ExprError> {
        let mut left = self.parse_mul(eval)?;
        loop {
            let op = match self.peek() {
                Some("+") => "+",
                Some("-") => "-",
                _ => break,
            };
            self.consume();
            let right = self.parse_mul(eval)?;
            if eval {
                let lhs = require_integer(&left)?;
                let rhs = require_integer(&right)?;
                check_bigint_width(&lhs)?;
                check_bigint_width(&rhs)?;
                let result = match op {
                    "+" => lhs + rhs,
                    "-" => lhs - rhs,
                    _ => unreachable!(),
                };
                check_bigint_width(&result)?;
                left = Value::integer(result);
            }
        }
        Ok(left)
    }

    fn parse_mul(&mut self, eval: bool) -> Result<Value, ExprError> {
        let mut left = self.parse_match(eval)?;
        loop {
            let op = match self.peek() {
                Some("*") => "*",
                Some("/") => "/",
                Some("%") => "%",
                _ => break,
            };
            self.consume();
            let right = self.parse_match(eval)?;
            if eval {
                let lhs = require_integer(&left)?;
                let rhs = require_integer(&right)?;
                check_bigint_width(&lhs)?;
                check_bigint_width(&rhs)?;
                if (op == "/" || op == "%") && rhs.is_zero() {
                    return Err(ExprError::Eval("division by zero".to_string()));
                }
                let result = match op {
                    "*" => lhs * rhs,
                    "/" => lhs / rhs,
                    "%" => lhs % rhs,
                    _ => unreachable!(),
                };
                check_bigint_width(&result)?;
                left = Value::integer(result);
            }
        }
        Ok(left)
    }

    fn parse_match(&mut self, eval: bool) -> Result<Value, ExprError> {
        let mut left = self.parse_atom(eval)?;
        while self.consume_if(":") {
            let right = self.parse_atom(eval)?;
            if eval {
                left = regex_match_value(&left.0, &right.0)?;
            }
        }
        Ok(left)
    }

    fn parse_atom(&mut self, eval: bool) -> Result<Value, ExprError> {
        match self.peek() {
            Some("+") => {
                self.consume();
                let token = self
                    .consume()
                    .ok_or_else(|| self.missing_after_previous())?;
                Ok(if eval {
                    Value::string(token)
                } else {
                    Value::int_literal(0)
                })
            }
            Some("match") => {
                self.consume();
                let string = self.parse_atom(eval)?;
                let pattern = self.parse_atom(eval)?;
                Ok(if eval {
                    regex_match_value(&string.0, &pattern.0)?
                } else {
                    Value::int_literal(0)
                })
            }
            Some("substr") => {
                self.consume();
                let string = self.parse_atom(eval)?;
                let pos = self.parse_atom(eval)?;
                let len = self.parse_atom(eval)?;
                Ok(if eval {
                    substr_value(&string.0, &pos, &len)?
                } else {
                    Value::int_literal(0)
                })
            }
            Some("index") => {
                self.consume();
                let string = self.parse_atom(eval)?;
                let chars = self.parse_atom(eval)?;
                Ok(if eval {
                    index_value(&string.0, &chars.0)
                } else {
                    Value::int_literal(0)
                })
            }
            Some("length") => {
                self.consume();
                let string = self.parse_atom(eval)?;
                Ok(if eval {
                    Value::string(string.0.chars().count().to_string())
                } else {
                    Value::int_literal(0)
                })
            }
            _ => self.parse_primary(eval),
        }
    }

    fn parse_primary(&mut self, eval: bool) -> Result<Value, ExprError> {
        match self.peek() {
            None => Err(self.missing_after_previous()),
            Some("(") => {
                self.consume();
                self.depth += 1;
                if self.depth > MAX_DEPTH {
                    return Err(ExprError::Eval(format!(
                        "expression nesting too deep (limit {MAX_DEPTH})"
                    )));
                }
                let value = self.parse_or(eval)?;
                self.depth -= 1;
                if !self.consume_if(")") {
                    if let Some(token) = self.peek() {
                        return Err(ExprError::Syntax(format!(
                            "expecting ')' instead of {}",
                            quote(token)
                        )));
                    }
                    let after = self.previous.as_deref().unwrap_or("(");
                    return Err(ExprError::Syntax(format!(
                        "expecting ')' after {}",
                        quote(after)
                    )));
                }
                Ok(value)
            }
            Some(")") => Err(ExprError::Syntax("unexpected ')'".to_string())),
            Some(_) => {
                let token = self.consume().expect("peeked token exists");
                Ok(if eval {
                    Value::string(token)
                } else {
                    Value::int_literal(0)
                })
            }
        }
    }
}

/// Returns true if `s` represents a numeric zero (e.g. "0", "-0", "000", "-00").
/// This lets `is_false` avoid a full `BigInt` allocation for the common case.
#[inline]
fn is_numeric_zero(s: &str) -> bool {
    let bytes = s.as_bytes();
    let digits = match bytes.first() {
        Some(b'-') if bytes.len() > 1 => &bytes[1..],
        Some(b'0'..=b'9') => bytes,
        _ => return false,
    };
    digits.iter().all(|&b| b == b'0')
}

#[inline]
fn parse_integer(s: &str) -> Option<BigInt> {
    let bytes = s.as_bytes();
    if bytes.is_empty() {
        return None;
    }
    let digits = if bytes[0] == b'-' {
        if bytes.len() == 1 {
            return None;
        }
        &bytes[1..]
    } else {
        bytes
    };
    if !digits.iter().all(u8::is_ascii_digit) {
        return None;
    }
    BigInt::parse_bytes(bytes, 10)
}

fn require_integer(value: &Value) -> Result<BigInt, ExprError> {
    value
        .as_int()
        .ok_or_else(|| ExprError::Eval("non-integer argument".to_string()))
}

/// Return an error if `n` exceeds the configured bit-width cap.
/// This prevents inputs like 500 000-digit literals from causing
/// multi-second allocations or stringify passes.
fn check_bigint_width(n: &BigInt) -> Result<(), ExprError> {
    if n.bits() > MAX_BIGINT_BITS {
        return Err(ExprError::Eval(format!(
            "integer too large (limit {MAX_BIGINT_BITS} bits)"
        )));
    }
    Ok(())
}

fn compare_values(left: &Value, right: &Value, op: &str) -> Value {
    let ordering = match (left.as_int(), right.as_int()) {
        (Some(lhs), Some(rhs)) => lhs.cmp(&rhs),
        _ => left.0.cmp(&right.0),
    };
    let result = match op {
        "<" => ordering == Ordering::Less,
        "<=" => ordering != Ordering::Greater,
        "=" => ordering == Ordering::Equal,
        "!=" => ordering != Ordering::Equal,
        ">=" => ordering != Ordering::Less,
        ">" => ordering == Ordering::Greater,
        _ => unreachable!(),
    };
    Value::int_literal(i32::from(result))
}

fn substr_value(string: &str, pos: &Value, len: &Value) -> Result<Value, ExprError> {
    // GNU expr returns "" (false) for non-integer POS or LENGTH rather than
    // treating it as an error.
    let Some(pos) = pos.as_int() else {
        return Ok(Value::string(""));
    };
    let Some(len) = len.as_int() else {
        return Ok(Value::string(""));
    };
    if pos <= BigInt::zero() || len <= BigInt::zero() {
        return Ok(Value::string(""));
    }
    let Some(start) = bigint_to_usize(&(&pos - 1u8)) else {
        return Ok(Value::string(""));
    };
    let Some(count) = bigint_to_usize(&len) else {
        return Ok(Value::string(""));
    };
    Ok(Value::string(
        string.chars().skip(start).take(count).collect::<String>(),
    ))
}

#[inline]
fn bigint_to_usize(n: &BigInt) -> Option<usize> {
    n.to_usize()
}

#[inline]
fn index_value(string: &str, chars: &str) -> Value {
    for (idx, ch) in string.chars().enumerate() {
        if chars.chars().any(|needle| needle == ch) {
            return Value::string((idx + 1).to_string());
        }
    }
    Value::int_literal(0)
}

fn regex_match_value(string: &str, bre: &str) -> Result<Value, ExprError> {
    let translated = translate_bre(bre)?;
    // Use RegexBuilder to make the 1 000 000-backtrack limit explicit.
    // fancy-regex routes pure-NFA patterns (no backreferences / look-around)
    // to the linear `regex` crate, so this limit is only relevant when the
    // backtracking engine is actually invoked.
    let regex = RegexBuilder::new(&translated.pattern)
        .backtrack_limit(1_000_000)
        .build()
        .map_err(|_| {
            ExprError::Eval(if translated.unmatched_group {
                "Unmatched ( or \\(".to_string()
            } else {
                "Invalid regular expression".to_string()
            })
        })?;
    let Some(captures) = regex
        .captures(string)
        .map_err(|_| ExprError::Eval("Invalid regular expression".to_string()))?
    else {
        return Ok(if translated.has_capture {
            Value::string("")
        } else {
            Value::int_literal(0)
        });
    };
    if translated.has_capture {
        Ok(Value::string(
            captures
                .get(1)
                .map(|m| m.as_str().to_string())
                .unwrap_or_default(),
        ))
    } else {
        let matched = captures.get(0).map(|m| m.as_str()).unwrap_or("");
        Ok(Value::string(matched.chars().count().to_string()))
    }
}

#[derive(Debug)]
struct TranslatedRegex {
    pattern: String,
    has_capture: bool,
    unmatched_group: bool,
}

fn translate_bre(pattern: &str) -> Result<TranslatedRegex, ExprError> {
    // Pre-allocate: output is at least "(?s)^" (5 bytes) + pattern length.
    // Each input byte produces at most 2 output bytes (escape prefix), so
    // pattern.len() * 2 is a safe upper bound that avoids reallocations.
    let mut out = String::with_capacity(5 + pattern.len() * 2);
    out.push_str("(?s)^");
    let mut chars = pattern.chars().peekable();
    let mut has_capture = false;
    let mut group_depth = 0usize;
    let mut can_repeat = false;
    let mut at_start = true;
    let mut last_was_repeat = false;
    let mut last_interval_start: Option<usize> = None;

    while let Some(ch) = chars.next() {
        match ch {
            '\\' => {
                let Some(next) = chars.next() else {
                    push_literal(&mut out, '\\');
                    can_repeat = true;
                    continue;
                };
                match next {
                    '(' => {
                        out.push('(');
                        group_depth += 1;
                        has_capture = true;
                        can_repeat = false;
                        at_start = true;
                        last_was_repeat = false;
                        last_interval_start = None;
                    }
                    ')' => {
                        if group_depth == 0 {
                            return Err(ExprError::Eval("Unmatched ) or \\)".to_string()));
                        }
                        out.push(')');
                        group_depth -= 1;
                        can_repeat = true;
                        at_start = false;
                        last_was_repeat = false;
                        last_interval_start = None;
                    }
                    '+' | '?' => {
                        if can_repeat {
                            out.push(next);
                            can_repeat = false;
                            at_start = false;
                            last_was_repeat = true;
                            last_interval_start = None;
                        } else {
                            push_literal(&mut out, next);
                            can_repeat = true;
                            at_start = false;
                            last_was_repeat = false;
                            last_interval_start = None;
                        }
                    }
                    '{' => {
                        let mut body = String::new();
                        let mut closed = false;
                        while let Some(c) = chars.next() {
                            if c == '\\' && chars.peek() == Some(&'}') {
                                chars.next();
                                closed = true;
                                break;
                            }
                            body.push(c);
                        }
                        if !closed {
                            return Err(ExprError::Eval("Unmatched \\{".to_string()));
                        }
                        let interval = normalize_interval(&body)?;
                        if can_repeat {
                            let start = out.len();
                            out.push('{');
                            out.push_str(&interval);
                            out.push('}');
                            can_repeat = false;
                            at_start = false;
                            last_was_repeat = true;
                            last_interval_start = Some(start);
                        } else if last_was_repeat {
                            last_interval_start = None;
                        } else {
                            push_literal(&mut out, '{');
                            for c in body.chars() {
                                push_literal(&mut out, c);
                            }
                            push_literal(&mut out, '}');
                            can_repeat = true;
                            at_start = false;
                            last_was_repeat = false;
                            last_interval_start = None;
                        }
                    }
                    '|' => {
                        out.push('|');
                        can_repeat = false;
                        at_start = true;
                        last_was_repeat = false;
                        last_interval_start = None;
                    }
                    '1'..='9' => {
                        out.push('\\');
                        out.push(next);
                        can_repeat = true;
                        at_start = false;
                        last_was_repeat = false;
                        last_interval_start = None;
                    }
                    _ => {
                        push_literal(&mut out, next);
                        can_repeat = true;
                        at_start = false;
                        last_was_repeat = false;
                        last_interval_start = None;
                    }
                }
            }
            '[' => {
                let bracket = collect_bracket(&mut chars)?;
                out.push('[');
                out.push_str(&translate_bracket(&bracket));
                out.push(']');
                can_repeat = true;
                at_start = false;
                last_was_repeat = false;
                last_interval_start = None;
            }
            '.' => {
                out.push('.');
                can_repeat = true;
                at_start = false;
                last_was_repeat = false;
                last_interval_start = None;
            }
            '*' => {
                if can_repeat {
                    out.push('*');
                    can_repeat = false;
                    at_start = false;
                    last_was_repeat = true;
                    last_interval_start = None;
                } else if last_was_repeat {
                    if let Some(start) = last_interval_start.take() {
                        out.truncate(start);
                        out.push('*');
                    }
                    at_start = false;
                } else {
                    push_literal(&mut out, '*');
                    can_repeat = true;
                    at_start = false;
                    last_was_repeat = false;
                    last_interval_start = None;
                }
            }
            '^' => {
                if at_start {
                    out.push('^');
                } else {
                    push_literal(&mut out, '^');
                    can_repeat = true;
                }
                at_start = false;
                last_was_repeat = false;
                last_interval_start = None;
            }
            '$' if dollar_is_anchor(&chars, group_depth) => {
                out.push('$');
                can_repeat = false;
                at_start = false;
                last_was_repeat = false;
                last_interval_start = None;
            }
            '$' => {
                push_literal(&mut out, '$');
                can_repeat = true;
                at_start = false;
                last_was_repeat = false;
                last_interval_start = None;
            }
            _ => {
                push_literal(&mut out, ch);
                can_repeat = true;
                at_start = false;
                last_was_repeat = false;
                last_interval_start = None;
            }
        }
    }

    Ok(TranslatedRegex {
        pattern: out,
        has_capture,
        unmatched_group: group_depth != 0,
    })
}

#[inline]
fn dollar_is_anchor(chars: &std::iter::Peekable<std::str::Chars<'_>>, group_depth: usize) -> bool {
    // $ is an end-anchor in BRE when the lookahead is:
    //   1. nothing (end of pattern),
    //   2. \) closing an open group, or
    //   3. \| (alternation separator) — end of one branch.
    // O(1) two-char peek; avoids cloning the iterator into a String.
    let mut peek = chars.clone();
    match peek.next() {
        None => true,
        Some('\\') => match peek.next() {
            Some(')') if group_depth > 0 => true,
            Some('|') => true,
            _ => false,
        },
        _ => false,
    }
}

fn normalize_interval(s: &str) -> Result<String, ExprError> {
    let Some((left, right)) = s.split_once(',') else {
        let value = parse_interval_bound(s)?;
        return Ok(value.to_string());
    };
    if right.contains(',') {
        return Err(ExprError::Eval("Invalid content of \\{\\}".to_string()));
    }
    let min = if left.is_empty() {
        0
    } else {
        parse_interval_bound(left)?
    };
    let max = if right.is_empty() {
        None
    } else {
        Some(parse_interval_bound(right)?)
    };
    if let Some(max) = max {
        if min > max {
            return Err(ExprError::Eval("Invalid content of \\{\\}".to_string()));
        }
        Ok(format!("{min},{max}"))
    } else {
        Ok(format!("{min},"))
    }
}

fn parse_interval_bound(s: &str) -> Result<u32, ExprError> {
    if s.is_empty() || !s.bytes().all(|b| b.is_ascii_digit()) {
        return Err(ExprError::Eval("Invalid content of \\{\\}".to_string()));
    }
    let value = s
        .parse::<u32>()
        .map_err(|_| ExprError::Eval("Invalid content of \\{\\}".to_string()))?;
    if value > 32767 {
        return Err(ExprError::Eval("Invalid content of \\{\\}".to_string()));
    }
    Ok(value)
}

fn collect_bracket<I>(chars: &mut std::iter::Peekable<I>) -> Result<String, ExprError>
where
    I: Iterator<Item = char>,
{
    let mut body = String::new();
    if chars.peek() == Some(&'^') {
        body.push('^');
        chars.next();
    }
    if matches!(chars.peek(), Some(']') | Some('-')) {
        body.push(chars.next().unwrap());
    }
    while let Some(c) = chars.next() {
        if c == '[' {
            if matches!(chars.peek(), Some(':') | Some('.') | Some('=')) {
                let marker = chars.next().unwrap();
                body.push('[');
                body.push(marker);
                let mut closed = false;
                while let Some(inner) = chars.next() {
                    body.push(inner);
                    if inner == marker && chars.peek() == Some(&']') {
                        body.push(chars.next().unwrap());
                        closed = true;
                        break;
                    }
                }
                if !closed {
                    return Err(ExprError::Eval("Invalid regular expression".to_string()));
                }
                continue;
            }
            body.push(c);
            continue;
        }
        if c == ']' {
            return Ok(body);
        }
        body.push(c);
    }
    Err(ExprError::Eval("Invalid regular expression".to_string()))
}

fn translate_bracket(body: &str) -> String {
    let mut out = String::new();
    let mut chars = body.chars().peekable();
    while let Some(c) = chars.next() {
        if c == '[' && chars.peek() == Some(&':') {
            chars.next();
            let mut name = String::new();
            let mut closed = false;
            while let Some(inner) = chars.next() {
                if inner == ':' && chars.peek() == Some(&']') {
                    chars.next();
                    closed = true;
                    break;
                }
                name.push(inner);
            }
            if closed {
                out.push_str(match name.as_str() {
                    "alnum" => "A-Za-z0-9",
                    "alpha" => "A-Za-z",
                    "blank" => " \\t",
                    "cntrl" => "\\x00-\\x1f\\x7f",
                    "digit" => "0-9",
                    "graph" => "\\x21-\\x7e",
                    "lower" => "a-z",
                    "print" => "\\x20-\\x7e",
                    "punct" => "\\x21-\\x2f\\x3a-\\x40\\x5b-\\x60\\x7b-\\x7e",
                    "space" => " \\t\\r\\n\\x0b\\x0c",
                    "upper" => "A-Z",
                    "xdigit" => "A-Fa-f0-9",
                    _ => {
                        out.push_str("[:");
                        out.push_str(&name);
                        out.push_str(":]");
                        continue;
                    }
                });
                continue;
            }
            out.push_str("[:");
            out.push_str(&name);
            continue;
        }
        out.push(c);
    }
    out
}

#[inline]
fn push_literal(out: &mut String, ch: char) {
    if matches!(
        ch,
        '\\' | '.' | '+' | '*' | '?' | '(' | ')' | '|' | '[' | ']' | '{' | '}' | '^' | '$'
    ) {
        out.push('\\');
    }
    out.push(ch);
}

fn quote(s: &str) -> String {
    if ascii_diagnostics() {
        format!("'{s}'")
    } else {
        format!("\u{2018}{s}\u{2019}")
    }
}

fn ascii_diagnostics() -> bool {
    // GNU expr uses the locale charset (via nl_langinfo(CODESET) after
    // setlocale(LC_CTYPE, "")) to decide between ASCII and Unicode quotes.
    // Use ASCII quotes unless we can positively identify a UTF-8 locale.
    // Priority: LC_ALL > LC_CTYPE > LC_MESSAGES > LANG. An unset or empty
    // var falls through; no var at all defaults to C (ASCII). Only values
    // explicitly containing "UTF-8" or "UTF8" (case-insensitive) select
    // Unicode quotes.
    let candidate = env::var("LC_ALL")
        .ok()
        .filter(|s| !s.is_empty())
        .or_else(|| env::var("LC_CTYPE").ok().filter(|s| !s.is_empty()))
        .or_else(|| env::var("LC_MESSAGES").ok().filter(|s| !s.is_empty()))
        .or_else(|| env::var("LANG").ok().filter(|s| !s.is_empty()));
    match candidate.as_deref() {
        None => true,
        Some(loc) => {
            let up = loc.to_uppercase();
            !up.contains("UTF-8") && !up.contains("UTF8")
        }
    }
}

fn diag_name(program: &str) -> String {
    if env::var_os("exproxide_test_mode").is_some() || env::var_os("EXPROXIDE_TEST_MODE").is_some()
    {
        return "gexpr".to_string();
    }
    Path::new(program)
        .file_name()
        .map(|name| name.to_string_lossy().into_owned())
        .unwrap_or_else(|| "expr".to_string())
}

fn help_path(program: &str) -> String {
    if env::var_os("exproxide_test_mode").is_some() || env::var_os("EXPROXIDE_TEST_MODE").is_some()
    {
        return "/opt/homebrew/bin/gexpr".to_string();
    }
    program.to_string()
}

fn print_help(program: &str) {
    println!(
        "\
Usage: {program} EXPRESSION
  or:  {program} OPTION

Print the value of EXPRESSION to standard output.

Operators, in increasing precedence:
  ARG1 | ARG2       ARG1 if it is neither null nor 0, otherwise ARG2
  ARG1 & ARG2       ARG1 if neither argument is null or 0, otherwise 0
  ARG1 < ARG2       ARG1 is less than ARG2
  ARG1 <= ARG2      ARG1 is less than or equal to ARG2
  ARG1 = ARG2       ARG1 is equal to ARG2
  ARG1 != ARG2      ARG1 is unequal to ARG2
  ARG1 >= ARG2      ARG1 is greater than or equal to ARG2
  ARG1 > ARG2       ARG1 is greater than ARG2
  ARG1 + ARG2       arithmetic sum of ARG1 and ARG2
  ARG1 - ARG2       arithmetic difference of ARG1 and ARG2
  ARG1 * ARG2       arithmetic product of ARG1 and ARG2
  ARG1 / ARG2       arithmetic quotient of ARG1 divided by ARG2
  ARG1 % ARG2       arithmetic remainder of ARG1 divided by ARG2
  STRING : REGEXP   anchored basic-regular-expression match
  match STRING REGEXP        same as STRING : REGEXP
  substr STRING POS LENGTH   substring of STRING, POS counted from 1
  index STRING CHARS         first position in STRING containing any CHARS
  length STRING              length of STRING
  + TOKEN                    interpret TOKEN as a string
  ( EXPRESSION )             value of EXPRESSION

Exit status is 0 if EXPRESSION is neither null nor 0, 1 if EXPRESSION is null
or 0, 2 if EXPRESSION is invalid, and 3 if an internal error occurred."
    );
}

fn print_version() {
    println!("exproxide {VERSION}");
}

fn run(args: Vec<OsString>) -> i32 {
    let program = args
        .first()
        .map(|s| s.to_string_lossy().into_owned())
        .unwrap_or_else(|| "expr".to_string());
    let diag = diag_name(&program);
    let help = help_path(&program);
    let mut tokens: Vec<String> = args
        .into_iter()
        .skip(1)
        .map(|s| s.to_string_lossy().into_owned())
        .collect();

    if tokens.first().is_some_and(|s| s == "--") {
        tokens.remove(0);
    } else if tokens.len() == 1 && tokens[0] == "--help" {
        print_help(&program);
        return 0;
    } else if tokens.len() == 1 && tokens[0] == "--version" {
        print_version();
        return 0;
    }

    if tokens.is_empty() {
        eprintln!("{diag}: missing operand");
        eprintln!("Try '{help} --help' for more information.");
        return 2;
    }

    let mut parser = Parser::new(tokens);
    match parser.parse_all(true) {
        Ok(value) => {
            println!("{}", value.0);
            if value.is_false() { 1 } else { 0 }
        }
        Err(error) => {
            match &error {
                ExprError::MissingOperand => {
                    eprintln!("{diag}: missing operand");
                    eprintln!("Try '{help} --help' for more information.");
                }
                ExprError::Syntax(msg) => eprintln!("{diag}: syntax error: {msg}"),
                ExprError::Eval(msg) => eprintln!("{diag}: {msg}"),
            }
            error.code()
        }
    }
}

fn main() {
    process::exit(run(env::args_os().collect()));
}

#[cfg(test)]
mod tests {
    use super::*;

    fn eval(args: &[&str]) -> (i32, String) {
        let mut argv = vec![OsString::from("exproxide")];
        argv.extend(args.iter().map(OsString::from));
        let mut parser = Parser::new(args.iter().map(|s| s.to_string()).collect());
        let value = parser.parse_all(true).unwrap();
        let code = if value.is_false() { 1 } else { 0 };
        (code, value.0)
    }

    #[test]
    fn arithmetic_uses_unbounded_integers() {
        let (_, value) = eval(&["999999999999999999999999999", "+", "1"]);
        assert_eq!(value, "1000000000000000000000000000");
    }

    #[test]
    fn boolean_connectives_short_circuit_runtime_errors() {
        let mut parser = Parser::new(
            ["1", "|", "1", "/", "0"]
                .into_iter()
                .map(str::to_string)
                .collect(),
        );
        assert_eq!(parser.parse_all(true).unwrap().0, "1");
        let mut parser = Parser::new(
            ["0", "&", "1", "/", "0"]
                .into_iter()
                .map(str::to_string)
                .collect(),
        );
        assert_eq!(parser.parse_all(true).unwrap().0, "0");
        let mut parser = Parser::new(["0", "|", "00"].into_iter().map(str::to_string).collect());
        assert_eq!(parser.parse_all(true).unwrap().0, "0");
    }

    #[test]
    fn string_forcing_disambiguates_keywords_and_operators() {
        let (_, value) = eval(&["+", "match"]);
        assert_eq!(value, "match");
        let (_, value) = eval(&["substr", "abc", "1", "+", "1"]);
        assert_eq!(value, "a");
    }

    #[test]
    fn anchored_bre_returns_length_or_first_capture() {
        let (_, value) = eval(&["abc", ":", "a.*"]);
        assert_eq!(value, "3");
        let (_, value) = eval(&["abc", ":", r"a\(.*\)"]);
        assert_eq!(value, "bc");
    }
}
