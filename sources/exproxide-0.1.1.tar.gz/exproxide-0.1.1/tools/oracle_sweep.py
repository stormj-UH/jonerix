#!/usr/bin/env python3
"""Black-box comparison helper for exproxide.

This script compares stdout, stderr, and exit status against a GNU expr binary.
It intentionally treats GNU expr as an executable oracle only; it does not read
or require GNU coreutils source code.
"""

from __future__ import annotations

import argparse
import os
import subprocess
import sys
from dataclasses import dataclass


@dataclass(frozen=True)
class Case:
    name: str
    args: tuple[str, ...]


CASES: list[Case] = [
    Case("literal-true", ("hello",)),
    Case("literal-zero", ("00",)),
    Case("literal-negative-zero", ("-0",)),
    Case("arithmetic-add", ("1", "+", "2")),
    Case("arithmetic-negative", ("-1", "+", "2")),
    Case("arithmetic-bigint", ("999999999999999999999999999", "+", "1")),
    Case("arithmetic-noninteger", ("+1", "+", "2")),
    Case("division-zero", ("5", "/", "0")),
    Case("compare-numeric", ("01", "=", "1")),
    Case("compare-lexical", ("2a", "<", "10")),
    Case("or-true-short-circuit", ("1", "|", "1", "/", "0")),
    Case("or-false-evaluates", ("0", "|", "x")),
    Case("or-both-false-normalizes", ("0", "|", "00")),
    Case("and-false-short-circuit", ("0", "&", "1", "/", "0")),
    Case("and-true", ("x", "&", "y")),
    Case("short-circuit-still-parses", ("1", "|", "1", "+")),
    Case("parenthesized", ("(", "1", "+", "2", ")", "*", "3")),
    Case("missing-close-paren", ("(", "1", "+", "2")),
    Case("unexpected-argument", ("1", "2")),
    Case("substr", ("substr", "abcdef", "2", "3")),
    Case("substr-zero", ("substr", "abc", "0", "2")),
    Case("substr-forced-plus", ("substr", "abc", "1", "+", "1")),
    Case("index", ("index", "abc", "ca")),
    Case("index-none", ("index", "abc", "z")),
    Case("length", ("length", "abc")),
    Case("length-nested", ("length", "substr", "abcdef", "2", "3")),
    Case("force-keyword", ("+", "match")),
    Case("regex-length", ("abc", ":", "a.*")),
    Case("regex-capture", ("abc", ":", r"a\(.*\)")),
    Case("regex-no-capture-unmatched", ("abc", ":", "z")),
    Case("regex-capture-unmatched", ("abc", ":", r"z\(x\)")),
    Case("regex-posix-class", ("abc", ":", "[[:alpha:]]*")),
    Case("regex-plus-extension", ("aaa", ":", r"a\+")),
    Case("regex-star-literal", ("aaa", ":", r"a\*")),
    Case("regex-interval", ("aaa", ":", r"a\{2\}")),
    Case("regex-leading-star-literal", ("a", ":", "*")),
]


def run(binary: str, case: Case) -> tuple[int, bytes, bytes]:
    env = dict(os.environ)
    env["exproxide_test_mode"] = "TRUE"
    proc = subprocess.run(
        [binary, *case.args],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env=env,
        check=False,
    )
    return proc.returncode, proc.stdout, proc.stderr


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--oracle", default=os.environ.get("EXPR_ORACLE", "/opt/homebrew/bin/gexpr"))
    parser.add_argument("--candidate", default="target/debug/exproxide")
    parser.add_argument("--list", action="store_true")
    ns = parser.parse_args()

    if ns.list:
        for case in CASES:
            print(case.name)
        return 0

    failed = 0
    for case in CASES:
        expected = run(ns.oracle, case)
        actual = run(ns.candidate, case)
        if expected != actual:
            failed += 1
            print(f"FAIL {case.name}", file=sys.stderr)
            print(f"  args={case.args!r}", file=sys.stderr)
            print(f"  expected rc={expected[0]} stdout={expected[1]!r} stderr={expected[2]!r}", file=sys.stderr)
            print(f"  actual   rc={actual[0]} stdout={actual[1]!r} stderr={actual[2]!r}", file=sys.stderr)
        else:
            print(f"ok {case.name}")
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
