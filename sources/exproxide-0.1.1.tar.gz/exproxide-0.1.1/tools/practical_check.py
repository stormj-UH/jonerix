#!/usr/bin/env python3
"""Practical-workload compatibility checker for exproxide.

Runs every entry in practical-corpus/corpus.json against both the candidate
(exproxide) and the oracle (GNU expr), diffs stdout/stderr/exit, and reports
pass/fail.  Requires EXPR_ORACLE to be set.

Exit codes:
  0  all pass
  1  one or more divergences
"""

from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent
CORPUS = REPO_ROOT / "practical-corpus" / "corpus.json"
CANDIDATE = REPO_ROOT / "target" / "debug" / "exproxide"


def run_cmd(binary: str, args: list[str]) -> tuple[str, str, int]:
    env = os.environ.copy()
    env["exproxide_test_mode"] = "TRUE"
    # ensure diagnostics use ASCII quotes so stderr matches oracle
    env.setdefault("LC_ALL", "C")
    result = subprocess.run(
        [binary] + args,
        capture_output=True,
        text=True,
        env=env,
    )
    return result.stdout.rstrip("\n"), result.stderr.rstrip("\n"), result.returncode


def main() -> int:
    oracle = os.environ.get("EXPR_ORACLE", "")
    if not oracle:
        print("error: EXPR_ORACLE env var not set", file=sys.stderr)
        return 2

    if not Path(oracle).exists():
        print(f"error: oracle not found: {oracle}", file=sys.stderr)
        return 2

    candidate = str(CANDIDATE.resolve())
    if not Path(candidate).exists():
        print(f"error: candidate not found: {candidate}", file=sys.stderr)
        print("  Run: cargo build (from the compat dir)", file=sys.stderr)
        return 2

    with CORPUS.open() as f:
        cases = json.load(f)

    passes = 0
    fails = 0
    corpus_fails: list[str] = []

    for case in cases:
        name = case["name"]
        args = case["args"]
        expected_stdout = case["stdout"]
        expected_stderr = case["stderr"]
        expected_exit = case["exit"]

        # Run oracle to verify corpus expectations
        oracle_out, oracle_err, oracle_exit = run_cmd(oracle, args)
        corpus_ok = (
            oracle_out == expected_stdout
            and oracle_err == expected_stderr
            and oracle_exit == expected_exit
        )
        if not corpus_ok:
            corpus_fails.append(
                f"  CORPUS-MISMATCH {name}:\n"
                f"    expected: out={expected_stdout!r} err={expected_stderr!r} exit={expected_exit}\n"
                f"    oracle:   out={oracle_out!r} err={oracle_err!r} exit={oracle_exit}"
            )

        # Run candidate
        cand_out, cand_err, cand_exit = run_cmd(candidate, args)

        if cand_out == oracle_out and cand_err == oracle_err and cand_exit == oracle_exit:
            print(f"ok {name}")
            passes += 1
        else:
            print(f"FAIL {name}")
            print(f"  args:       {args}")
            print(f"  oracle:     out={oracle_out!r}  err={oracle_err!r}  exit={oracle_exit}")
            print(f"  candidate:  out={cand_out!r}  err={cand_err!r}  exit={cand_exit}")
            fails += 1

    print()
    print(f"Results: {passes} passed, {fails} failed out of {passes + fails} cases")

    if corpus_fails:
        print()
        print("Corpus annotation mismatches (corpus.json needs updating):")
        for msg in corpus_fails:
            print(msg)

    return 0 if fails == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
