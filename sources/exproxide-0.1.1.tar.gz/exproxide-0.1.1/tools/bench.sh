#!/usr/bin/env bash
# bench.sh — self-contained perf comparison: exproxide vs gexpr
# Usage: bash bench.sh [exproxide-binary] [gexpr-binary]
set -euo pipefail

EXP="${1:-./target/release/exproxide}"
GNU="${2:-/opt/homebrew/bin/gexpr}"
N=1000

ts() { python3 -c "import time; print(time.time())"; }

run_op() {
    local label="$1"; shift
    local bin="$1"; shift
    local start end elapsed
    start=$(ts)
    for i in $(seq 1 $N); do "$bin" "$@" > /dev/null 2>&1; done
    end=$(ts)
    elapsed=$(python3 -c "print(f'{$end-$start:.3f}')")
    printf "%-30s %ss\n" "$label" "$elapsed"
}

echo "=== exproxide vs gexpr (${N} invocations per op) ==="
printf "%-30s %s\n" "operation" "wall-clock"
printf '%s\n' "----------------------------------------------"

run_op "exproxide/length"   "$EXP" length "autoconf_string_42"
run_op "gexpr/length"       "$GNU" length "autoconf_string_42"

run_op "exproxide/add"      "$EXP" 42 + 58
run_op "gexpr/add"          "$GNU" 42 + 58

run_op "exproxide/multiply" "$EXP" 42 "*" 58
run_op "gexpr/multiply"     "$GNU" 42 "*" 58

run_op "exproxide/match"    "$EXP" "autoconf_string_42" : "autoconf_.*"
run_op "gexpr/match"        "$GNU" "autoconf_string_42" : "autoconf_.*"

run_op "exproxide/substr"   "$EXP" substr "autoconf_string_42" 2 8
run_op "gexpr/substr"       "$GNU" substr "autoconf_string_42" 2 8

echo ""
echo "=== full stress (5000 invocations) ==="
printf "%-30s " "exproxide/stress"
{ time bash stress.sh "$EXP"; } 2>&1 | grep real | awk '{print $2}'

printf "%-30s " "gexpr/stress"
{ time bash stress.sh "$GNU"; } 2>&1 | grep real | awk '{print $2}'
