#!/usr/bin/env python3
"""Run extracted GNU coreutils expr tests against exproxide.

The upstream test files are test inputs, not implementation source. Keep
extracted upstream assets under cleanroom/private so they are not committed.
This helper supplies the small Perl harness surface needed by tests/expr/expr.pl
and puts the candidate binary first on PATH as `expr`.
"""

from __future__ import annotations

import argparse
import os
import subprocess
import sys
import tempfile
from pathlib import Path


COREUTILS_PM = r'''
package Coreutils;
use strict;
use warnings;
use Exporter 'import';
use IPC::Open3;
use Symbol qw(gensym);
our @EXPORT = qw(run_tests);

sub run_tests {
  my ($program_name, $prog, $tests, $save_temps, $verbose) = @_;
  my $fail = 0;
  for my $test (@$tests) {
    my $name = $test->[0];
    my $expr = $test->[1];
    my $cmd;
    my @specs;
    if (defined $expr && !ref($expr)) {
      $cmd = "$prog $expr";
      @specs = @$test[2 .. $#$test];
    } else {
      $cmd = "$prog";
      @specs = @$test[1 .. $#$test];
    }

    my ($want_out, $want_err, $want_exit) = ("", "", 0);
    my (@out_subst, @err_subst, @env, @env_del);
    for my $spec (@specs) {
      next unless ref($spec) eq 'HASH';
      $want_out = $spec->{OUT} if exists $spec->{OUT};
      $want_err = $spec->{ERR} if exists $spec->{ERR};
      $want_exit = $spec->{EXIT} if exists $spec->{EXIT};
      push @out_subst, $spec->{OUT_SUBST} if exists $spec->{OUT_SUBST};
      push @err_subst, $spec->{ERR_SUBST} if exists $spec->{ERR_SUBST};
      push @env, $spec->{ENV} if exists $spec->{ENV};
      push @env_del, $spec->{ENV_DEL} if exists $spec->{ENV_DEL};
    }

    my %saved_env;
    for my $del (@env_del) {
      $saved_env{$del} = exists $ENV{$del} ? $ENV{$del} : undef;
      delete $ENV{$del};
    }
    my %saved_set;
    for my $assignment (@env) {
      for my $pair (split /\s+/, $assignment) {
        next unless length $pair;
        my ($k, $v) = split /=/, $pair, 2;
        $saved_set{$k} = exists $ENV{$k} ? $ENV{$k} : undef;
        $ENV{$k} = $v;
      }
    }

    my $errh = gensym;
    my $pid = open3(undef, my $outh, $errh, 'sh', '-c', $cmd);
    my $out = do { local $/; <$outh> // "" };
    my $err = do { local $/; <$errh> // "" };
    waitpid($pid, 0);
    my $status = $? == -1 ? 127 : ($? >> 8);

    for my $subst (@out_subst) { eval "\$out =~ $subst"; }
    for my $subst (@err_subst) { eval "\$err =~ $subst"; }

    for my $k (keys %saved_set) {
      defined $saved_set{$k} ? ($ENV{$k} = $saved_set{$k}) : delete $ENV{$k};
    }
    for my $k (keys %saved_env) {
      defined $saved_env{$k} ? ($ENV{$k} = $saved_env{$k}) : delete $ENV{$k};
    }

    if ($out ne $want_out || $err ne $want_err || $status != $want_exit) {
      print STDERR "FAIL $name\n";
      print STDERR "  cmd=[$cmd]\n";
      print STDERR "  want status=$want_exit out=<$want_out> err=<$want_err>\n";
      print STDERR "  got  status=$status out=<$out> err=<$err>\n";
      ++$fail;
    } elsif ($verbose) {
      print "ok $name\n";
    }
  }
  return $fail;
}

1;
'''


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("coreutils_root", type=Path)
    parser.add_argument("--candidate", default="target/debug/exproxide")
    ns = parser.parse_args()

    root = ns.coreutils_root.resolve()
    test = root / "tests" / "expr" / "expr.pl"
    if not test.exists():
        print(f"missing upstream test file: {test}", file=sys.stderr)
        return 2

    candidate = Path(ns.candidate).resolve()
    if not candidate.exists():
        print(f"missing candidate binary: {candidate}", file=sys.stderr)
        return 2

    with tempfile.TemporaryDirectory(prefix="exproxide-upstream-") as tmp:
        tmp_path = Path(tmp)
        harness = tmp_path / "Coreutils.pm"
        harness.write_text(COREUTILS_PM)
        bin_dir = tmp_path / "bin"
        bin_dir.mkdir()
        (bin_dir / "expr").symlink_to(candidate)

        env = dict(os.environ)
        env["PATH"] = f"{bin_dir}{os.pathsep}{env.get('PATH', '')}"
        env["srcdir"] = str(root)
        env["PERL5LIB"] = f"{tmp_path}{os.pathsep}{root / 'tests'}"
        env.pop("LOCALE_FR_UTF8", None)

        proc = subprocess.run(
            ["perl", "-I", str(tmp_path), "-I", str(root / "tests"), "-MCoreutils", str(test)],
            cwd=root,
            env=env,
            check=False,
        )
        return proc.returncode


if __name__ == "__main__":
    raise SystemExit(main())
