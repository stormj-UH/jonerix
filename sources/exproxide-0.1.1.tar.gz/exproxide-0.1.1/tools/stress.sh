#!/usr/bin/env bash
# stress.sh — synthetic bulk workload for exproxide / gexpr comparison
# Runs ~5000 separate invocations mixing length, +, *, match, substr
set -euo pipefail

CANDIDATE="${1:-./target/release/exproxide}"
ORACLE="${2:-/opt/homebrew/bin/gexpr}"

N=1000  # 5 op-types × 1000 = 5000 invocations

for i in $(seq 1 $N); do
    "$CANDIDATE" length "autoconf_string_$i" > /dev/null
done

for i in $(seq 1 $N); do
    "$CANDIDATE" "$i" + "$(( i * 3 ))" > /dev/null
done

for i in $(seq 1 $N); do
    "$CANDIDATE" "$i" \* "$(( i + 7 ))" > /dev/null
done

for i in $(seq 1 $N); do
    "$CANDIDATE" "autoconf_string_$i" : "autoconf_.*" > /dev/null
done

for i in $(seq 1 $N); do
    "$CANDIDATE" substr "autoconf_string_$i" 2 8 > /dev/null
done
