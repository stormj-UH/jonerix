#!/usr/bin/env python3
"""Differential fuzzer for exproxide vs the GNU expr oracle.

Generates random valid expr argument lists using a small grammar,
runs both binaries, and reports any divergence.

Usage:
    EXPR_ORACLE=/opt/homebrew/bin/gexpr python3 fuzz.py [--count N] [--seed S]

Exit codes:
  0  no divergences found
  1  one or more divergences found
  2  configuration error
"""

from __future__ import annotations

import argparse
import os
import random
import subprocess
import sys
from pathlib import Path

CANDIDATE = Path(__file__).resolve().parent.parent / "target" / "debug" / "exproxide"

# ---------------------------------------------------------------------------
# Grammar terminals
# ---------------------------------------------------------------------------

INTEGERS = ["-10", "-1", "0", "1", "2", "3", "5", "7", "10", "100", "007", "00"]
STRINGS = ["abc", "hello", "foo", "bar", "xyz", "abcabc", "a1b2", "", "X", "Xhello", "X-flag"]
PATTERNS = [
    r".*", r"a.*", r"[[:alpha:]]*", r"[[:alnum:]]*",
    r"\(.*\)", r"a\(.*\)", r"X\(.*\)",
    r"a\{2,3\}", r"a\{1\}", r"[[:upper:]]\{5\}",
    r"\(abc\)\1",
    r"^hello$", r"foo", r"bar",
    r"[[:alpha:]]\{2,3\}",
]
CHARS_ARGS = ["abc", "aeiou", "xyz", "0-9"]
OPS_ARITH = ["+", "-", "*", "/", "%"]
OPS_CMP = ["<", "<=", "=", "!=", ">=", ">"]


# ---------------------------------------------------------------------------
# Random argument-list generators
# ---------------------------------------------------------------------------

def rnd_int(rng: random.Random) -> str:
    return rng.choice(INTEGERS)


def rnd_str(rng: random.Random) -> str:
    return rng.choice(STRINGS)


def rnd_pattern(rng: random.Random) -> str:
    return rng.choice(PATTERNS)


def gen_arith(rng: random.Random) -> list[str]:
    op = rng.choice(OPS_ARITH)
    return [rnd_int(rng), op, rnd_int(rng)]


def gen_cmp(rng: random.Random) -> list[str]:
    op = rng.choice(OPS_CMP)
    left = rng.choice(INTEGERS + STRINGS)
    right = rng.choice(INTEGERS + STRINGS)
    return [left, op, right]


def gen_regex(rng: random.Random) -> list[str]:
    return [rnd_str(rng), ":", rnd_pattern(rng)]


def gen_substr(rng: random.Random) -> list[str]:
    s = rnd_str(rng)
    pos = str(rng.randint(0, 5))
    length = str(rng.randint(0, 5))
    return ["substr", s, pos, length]


def gen_index(rng: random.Random) -> list[str]:
    return ["index", rnd_str(rng), rng.choice(CHARS_ARGS)]


def gen_length(rng: random.Random) -> list[str]:
    return ["length", rnd_str(rng)]


def gen_match(rng: random.Random) -> list[str]:
    return ["match", rnd_str(rng), rnd_pattern(rng)]


def gen_logic(rng: random.Random) -> list[str]:
    op = rng.choice(["|", "&"])
    left = rng.choice(INTEGERS + STRINGS[:4])
    right = rng.choice(INTEGERS + STRINGS[:4])
    return [left, op, right]


def gen_chain(rng: random.Random) -> list[str]:
    """Generate a chained arithmetic/comparison expression."""
    base = gen_arith(rng)
    op = rng.choice(OPS_CMP)
    right = rnd_int(rng)
    return base + [op, right]


def gen_autoconf_x_idiom(rng: random.Random) -> list[str]:
    """Autoconf X-prefix stripping idiom."""
    payload = rng.choice(["hello", "-flag", "=value", "0", "", "world"])
    return [f"X{payload}", ":", r"X\(.*\)"]


GENERATORS = [
    gen_arith,
    gen_cmp,
    gen_regex,
    gen_substr,
    gen_index,
    gen_length,
    gen_match,
    gen_logic,
    gen_chain,
    gen_autoconf_x_idiom,
]


# ---------------------------------------------------------------------------
# Runner
# ---------------------------------------------------------------------------

def run_cmd(binary: str, args: list[str]) -> tuple[str, str, int]:
    env = os.environ.copy()
    env["exproxide_test_mode"] = "TRUE"
    env["LC_ALL"] = "C"
    result = subprocess.run(
        [binary] + args,
        capture_output=True,
        text=True,
        env=env,
    )
    return result.stdout.rstrip("\n"), result.stderr.rstrip("\n"), result.returncode


def main() -> int:
    parser = argparse.ArgumentParser(description="Differential fuzzer for exproxide")
    parser.add_argument("--count", type=int, default=200, help="number of cases (default 200)")
    parser.add_argument("--seed", type=int, default=42, help="RNG seed (default 42)")
    ns = parser.parse_args()

    oracle = os.environ.get("EXPR_ORACLE", "")
    if not oracle:
        print("error: EXPR_ORACLE env var not set", file=sys.stderr)
        return 2
    if not Path(oracle).exists():
        print(f"error: oracle not found: {oracle}", file=sys.stderr)
        return 2

    candidate = str(CANDIDATE.resolve())
    if not Path(candidate).exists():
        print(f"error: candidate not found: {candidate}", file=sys.stderr)
        return 2

    rng = random.Random(ns.seed)
    passes = 0
    fails = 0
    divergences: list[tuple[list[str], tuple, tuple]] = []

    for i in range(ns.count):
        gen = rng.choice(GENERATORS)
        args = gen(rng)

        oracle_out, oracle_err, oracle_exit = run_cmd(oracle, args)
        cand_out, cand_err, cand_exit = run_cmd(candidate, args)

        if oracle_out == cand_out and oracle_err == cand_err and oracle_exit == cand_exit:
            passes += 1
        else:
            fails += 1
            divergences.append((args, (oracle_out, oracle_err, oracle_exit), (cand_out, cand_err, cand_exit)))
            print(f"DIVERGE [{i}] args={args}")
            print(f"  oracle:    out={oracle_out!r}  err={oracle_err!r}  exit={oracle_exit}")
            print(f"  candidate: out={cand_out!r}  err={cand_err!r}  exit={cand_exit}")

    print()
    print(f"Fuzz results ({ns.count} cases, seed={ns.seed}): {passes} pass, {fails} diverge")

    if divergences:
        print("\nDivergent invocations summary:")
        for args, exp, got in divergences:
            print(f"  {args}")

    return 0 if fails == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
