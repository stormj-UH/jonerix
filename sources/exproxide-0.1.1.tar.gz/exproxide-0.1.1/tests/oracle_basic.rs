use std::process::Command;

fn oracle() -> String {
    std::env::var("EXPR_ORACLE").unwrap_or_else(|_| "/opt/homebrew/bin/gexpr".to_string())
}

fn run(binary: &str, args: &[&str]) -> (i32, Vec<u8>, Vec<u8>) {
    let out = Command::new(binary)
        .env("exproxide_test_mode", "TRUE")
        .args(args)
        .output()
        .unwrap_or_else(|e| panic!("spawn {binary}: {e}"));
    (out.status.code().unwrap_or(127), out.stdout, out.stderr)
}

fn assert_gnu(args: &[&str]) {
    let oracle = oracle();
    if !std::path::Path::new(&oracle).exists() {
        eprintln!("skipping oracle test; {oracle} not found");
        return;
    }
    let ours = env!("CARGO_BIN_EXE_exproxide");
    let expected = run(&oracle, args);
    let actual = run(ours, args);
    assert_eq!(actual, expected, "args: {args:?}");
}

#[test]
fn arithmetic_and_comparisons_match_gnu() {
    assert_gnu(&["1", "+", "2"]);
    assert_gnu(&["-1", "+", "2"]);
    assert_gnu(&["999999999999999999999999999", "+", "1"]);
    assert_gnu(&["01", "=", "1"]);
    assert_gnu(&["2a", "<", "10"]);
    assert_gnu(&["+1", "+", "2"]);
    assert_gnu(&["5", "/", "0"]);
}

#[test]
fn logical_operators_short_circuit_like_gnu() {
    assert_gnu(&["1", "|", "1", "/", "0"]);
    assert_gnu(&["0", "|", "x"]);
    assert_gnu(&["0", "|", "00"]);
    assert_gnu(&["0", "&", "1", "/", "0"]);
    assert_gnu(&["x", "&", "y"]);
    assert_gnu(&["1", "|", "1", "+"]);
}

#[test]
fn string_functions_match_gnu() {
    assert_gnu(&["substr", "abc", "1", "2"]);
    assert_gnu(&["substr", "abc", "0", "2"]);
    assert_gnu(&["index", "abc", "ca"]);
    assert_gnu(&["index", "abc", "z"]);
    assert_gnu(&["length", "abc"]);
    assert_gnu(&["+", "match"]);
    assert_gnu(&["substr", "abc", "1", "+", "1"]);
}

#[test]
fn regex_matching_matches_gnu() {
    assert_gnu(&["abc", ":", "a.*"]);
    assert_gnu(&["abc", ":", r"a\(b\)"]);
    assert_gnu(&["abc", ":", r"a\(.*\)"]);
    assert_gnu(&["abc", ":", "[[:alpha:]]*"]);
    assert_gnu(&["aaa", ":", r"a\+"]);
    assert_gnu(&["aaa", ":", r"a\*"]);
    assert_gnu(&["aaa", ":", r"a\{2\}"]);
    assert_gnu(&["bbb", ":", "a*"]);
    assert_gnu(&["a", ":", "*"]);
}
