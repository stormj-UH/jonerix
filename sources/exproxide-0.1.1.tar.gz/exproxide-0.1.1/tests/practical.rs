// Practical-workload compatibility tests drawn from practical-corpus/corpus.json.
// Each test calls assert_gnu() which skips gracefully if the oracle is absent.
use std::process::Command;

fn oracle() -> String {
    std::env::var("EXPR_ORACLE").unwrap_or_else(|_| "/opt/homebrew/bin/gexpr".to_string())
}

fn run(binary: &str, args: &[&str]) -> (i32, Vec<u8>, Vec<u8>) {
    let out = Command::new(binary)
        .env("exproxide_test_mode", "TRUE")
        .env("LC_ALL", "C")
        .args(args)
        .output()
        .unwrap_or_else(|e| panic!("spawn {binary}: {e}"));
    (out.status.code().unwrap_or(127), out.stdout, out.stderr)
}

fn assert_gnu(args: &[&str]) {
    let oracle = oracle();
    if !std::path::Path::new(&oracle).exists() {
        eprintln!("skipping practical oracle test; {oracle} not found");
        return;
    }
    let ours = env!("CARGO_BIN_EXE_exproxide");
    let expected = run(&oracle, args);
    let actual = run(ours, args);
    assert_eq!(actual, expected, "args: {args:?}");
}

// --- autoconf patterns ---

#[test]
fn autoconf_capture_group() {
    assert_gnu(&["hello", ":", r"\(.*\)"]);
}

#[test]
fn autoconf_length_via_regex() {
    assert_gnu(&["hello", ":", ".*"]);
}

#[test]
fn autoconf_strip_prefix_x_idiom() {
    assert_gnu(&["Xhello", ":", r"X\(.*\)"]);
    // empty result when string is exactly "X"
    assert_gnu(&["X", ":", r"X\(.*\)"]);
}

#[test]
fn autoconf_dash_arg_via_x_idiom() {
    // adversarial: arg that starts with '-' — must not be parsed as a flag
    assert_gnu(&["X-flag", ":", r"X\(.*\)"]);
    assert_gnu(&["X=", ":", r"X\(.*\)"]);
    assert_gnu(&["Xhello world", ":", r"X\(.*\)"]);
}

#[test]
fn autoconf_coerce_int() {
    assert_gnu(&["42", "+", "0"]);
    assert_gnu(&["007", "+", "0"]); // leading zeros — not octal
}

// --- shell loop counter patterns ---

#[test]
fn loop_counter_add_and_sub() {
    assert_gnu(&["3", "+", "1"]);
    assert_gnu(&["0", "+", "1"]);
    assert_gnu(&["7", "-", "1"]);
}

#[test]
fn loop_counter_multiply() {
    assert_gnu(&["5", "*", "2"]);
    assert_gnu(&["10", "*", "3"]);
}

// --- string manipulation ---

#[test]
fn string_substr_variants() {
    assert_gnu(&["substr", "abcdef", "1", "3"]);
    assert_gnu(&["substr", "abcdef", "4", "10"]); // past end
    assert_gnu(&["substr", "hello", "2", "1"]); // single char
}

#[test]
fn string_index_and_length() {
    assert_gnu(&["index", "abcde", "ce"]);
    assert_gnu(&["index", "hello", "xyz"]); // not found → 0 / exit 1
    assert_gnu(&["length", "abcdef"]);
    assert_gnu(&["length", ""]); // empty → 0 / exit 1
}

// --- regex patterns ---

#[test]
fn regex_interval_quantifiers() {
    assert_gnu(&["aaa", ":", r"a\{2,3\}"]);
    assert_gnu(&["ab", ":", r"a\{2,3\}"]); // no match
    assert_gnu(&["abc", ":", r"[[:alpha:]]\{2,3\}"]); // POSIX class + interval
    assert_gnu(&["HELLO", ":", r"[[:upper:]]\{5\}"]);
}

#[test]
fn regex_backreference() {
    assert_gnu(&["abcabc", ":", r"\(abc\)\1"]);
}

#[test]
fn regex_anchored_and_unanchored() {
    assert_gnu(&["hello", ":", "^hello$"]); // anchored full match
    assert_gnu(&["foobar", ":", "foo"]); // prefix match (anchored at start only)
    assert_gnu(&["foobar", ":", "bar"]); // no match — anchored at start
}

// --- negative / error cases ---

#[test]
fn error_non_integer_argument() {
    assert_gnu(&["abc", "/", "2"]);
    assert_gnu(&["abc", "+", "0"]);
}

#[test]
fn error_division_by_zero() {
    assert_gnu(&["5", "/", "0"]);
}

#[test]
fn error_invalid_regex() {
    assert_gnu(&["abc", ":", r"a\{"]); // unmatched \{
    assert_gnu(&["abc", ":", r"a\{bad\}"]); // invalid interval content
    assert_gnu(&["abc", ":", r"a\("]); // unmatched \(
    assert_gnu(&["abc", ":", r"a\)"]); // unmatched \)
}

// --- corner cases ---

#[test]
fn corner_empty_string_arg() {
    assert_gnu(&[""]); // empty string → exit 1
}

#[test]
fn corner_negative_numbers() {
    assert_gnu(&["-5", "+", "3"]);
    assert_gnu(&["-5", "+", "-3"]);
}

#[test]
fn corner_leading_zero_not_octal() {
    assert_gnu(&["010", "+", "0"]); // 10, not 8
}

#[test]
fn match_keyword_forms() {
    assert_gnu(&["match", "abc", "a.*"]);
    assert_gnu(&["match", "abc", r"a\(.*\)"]);
}
