# Clean-Room Notes

This repository must not contain GNU coreutils implementation source code.

Generated binary-analysis output, traces, downloaded upstream archives, and
temporary oracle fixtures belong under `cleanroom/private/`, which is ignored by
git. Checked-in notes should summarize externally observable behavior and cite
the command or binary observation that produced it.
