# exproxide

Clean-room Rust implementation of `expr`, an expression evaluator, for jonerix.

The implementation is developed from public documentation, black-box behavior
of compiled `expr` binaries, and test suites. GNU coreutils implementation
source code is not used.

## Build & install

```sh
cargo build --release
cargo install --path .
```

Or install via jonerix once published:

```sh
jpkg install exproxide
```

The jonerix package installs `/bin/exproxide` and a `/bin/expr` symlink so
existing `./configure` scripts and shell pipelines that resolve `expr` from
`$PATH` find exproxide. The recipe declares `replaces = ["toybox", "uutils"]`
to claim `/bin/expr` from whichever package was previously providing it.

## Performance

`exproxide` ships a fat-LTO release profile (`Cargo.toml`'s `[profile.release]`
sets `lto = "fat"`, `codegen-units = 1`, `panic = "abort"`, `strip = "symbols"`).
With three deps in the tree (`fancy-regex`, `num-bigint`, `num-traits`) LTO
collapses everything into a single optimized binary.

Measured on macOS arm64, GNU coreutils 9.10 `gexpr` as the oracle, 100 calls
per workload, best of 3:

| Workload                                              | exproxide | GNU expr 9.10 | Ratio        |
| ----------------------------------------------------- | --------- | ------------- | ------------ |
| arithmetic loop (`i+1`, `length`, `*13`)              | 755 ms    | 869 ms        | **1.15× faster** |
| anchored BRE match (`X[0-9]*\.txt` with capture)      | 268 ms    | 266 ms        | parity       |
| binary size (release, fat-LTO, stripped, statically   | 1.6 MiB   | 150 KiB       | bigger (no   |
|   linked against fancy-regex + num-bigint)            |           | (system libc) | system deps) |

`tools/bench.sh` reproduces these numbers; `tools/stress.sh` is the synthetic
workload.

## Security

### Audit summary

The codebase has been audited end-to-end for ReDoS, integer / bignum DoS,
stack overflow, command injection, and `unsafe` soundness. There is no file
I/O, no subprocess execution, and no environment-variable use beyond
diagnostic-locale detection (`LC_ALL`, `LC_CTYPE`, `LC_MESSAGES`, `LANG`).
The attack surface is purely "evaluate this command line".

P1 hardening landed in v0.1.1:

- **Parser recursion cap** — `MAX_DEPTH = 256`. Pre-fix, deeply-nested
  parenthesised expressions crashed at empirical depth ~5 421 on an 8 KiB
  stack. Now the parser returns a clean syntax error well before the OS
  stack guard fires.
- **Bignum width cap** — `MAX_BIGINT_BITS = 4 096` (~1 233 decimal digits).
  Operands and intermediate results are bounded; pre-fix a 500 000-digit
  multiplication took ~3 s and a 100 000-digit addition ~120 ms. Now those
  inputs return exit 2 with a clear error.
- **Explicit regex backtrack limit** — `RegexBuilder::backtrack_limit(1_000_000)`.
  `fancy-regex` already enforced this implicitly; making it explicit
  documents the policy and means a 10-input ReDoS corpus completes in
  single-digit milliseconds without hangs.

Pathological-but-valid input still consumes time on GNU `expr` and exproxide
identically (e.g. a 10 000-digit modulo). For untrusted input use a
process-level timeout.

### `unsafe` inventory

**Zero `unsafe` in our code, compiler-enforced:**

```rust
// src/main.rs:1
#![forbid(unsafe_code)]
#![deny(warnings)]
```

`forbid(unsafe_code)` makes any future `unsafe` block a hard compile error.
`deny(warnings)` plus CI's `RUSTFLAGS=-D warnings` makes any rustc warning
a hard error.

The dependency tree carries some `unsafe` for SIMD / regex DFA / bignum
primitive operations. Counts (occurrences of the `unsafe ` keyword across
all `.rs` files) at the version pins shipped in v0.1.1:

| Crate                      | `unsafe` occurrences           |
| -------------------------- | ------------------------------ |
| `aho-corasick` 1.1.4       | 227 (SIMD memchr fast paths)   |
| `memchr` 2.8.0             | 326 (SIMD byte search)         |
| `regex-automata` 0.4.14    | 57 (DFA state machine)         |
| `num-bigint` 0.4.6         | 12 (digit-buffer primitives)   |
| `bit-vec` 0.8.0            | 8                              |
| `bit-set` 0.8.0            | 2                              |
| `num-traits` 0.2.19        | 1                              |
| `fancy-regex` 0.17.0       | 0                              |
| `regex-syntax` 0.8.10      | 0                              |
| `num-integer` 0.1.46       | 0                              |
| `autocfg` 1.5.0            | 0                              |

The transitive `unsafe` is concentrated in `aho-corasick` and `memchr` —
both authored by Andrew Gallant (`BurntSushi`) and used by virtually every
serious Rust regex implementation. They are the most-audited string-search
crates in the ecosystem.

### Threat model

- **Trusted input.** `expr` is invoked from shell scripts with operator-controlled
  arguments. The listed limits exist as belt-and-braces.
- **Untrusted input.** If you wrap `exproxide` for an external caller, add
  a process-level timeout (e.g. `timeout 1s exproxide …`) and consider
  capping arg count and length at the wrapper layer.
- **No filesystem, no network.** `exproxide` does not open files, spawn
  processes, or read any environment variable beyond locale detection. There
  is no command-injection or path-traversal surface.

## Compatibility Mode

Set `EXPROXIDE_TEST_MODE=1` to make diagnostic / identity strings emit the
exact same bytes as GNU `expr` (the `gexpr` program name, the
`/opt/homebrew/bin/gexpr` help-page path, etc.). The legacy variable name
`exproxide_test_mode=TRUE` is still accepted for backward compatibility.

```sh
EXPROXIDE_TEST_MODE=1 cargo test
```

Without `EXPROXIDE_TEST_MODE`, `exproxide --version` reports
`exproxide <version>` and the help-page path identifies as `exproxide`.

## Testing

The oracle defaults to GNU `gexpr`; set `EXPR_ORACLE` to point at a specific
binary.

```sh
EXPR_ORACLE=/opt/homebrew/bin/gexpr cargo test
cargo build --release
./tools/oracle_sweep.py    --candidate target/release/exproxide
./tools/practical_check.py
./tools/fuzz.py            --seed 42 --count 200
./tools/bench.sh
```

Test surface at v0.1.1:

- 4 Rust unit tests + 4 oracle-parity tests (`tests/oracle_basic.rs`) +
  19 oracle-parity tests (`tests/practical.rs`) — 27 cargo tests total.
- 36-case `tools/oracle_sweep.py` covering literals, arithmetic, comparisons,
  string functions, anchored BRE matching, back references, intervals.
- 43-case `practical-corpus/corpus.json` covering autoconf-style quoting,
  shell-loop counters, string idioms, regex with intervals/classes/anchors,
  negative-error inputs, corner cases (empty / leading-zero / negative).
- 200-input fuzzer (`tools/fuzz.py`) generating valid expr arg-lists across
  arithmetic, comparison, regex, substr, index, length, match, logic,
  chained, and autoconf-X-idiom grammar branches.
- Upstream coreutils 9.10 `tests/expr/expr.pl` Perl harness via
  `tools/run_upstream_expr_tests.py`.

Upstream coreutils test inputs and generated binary-analysis output belong
under `cleanroom/private/`, which is intentionally ignored by git:

```sh
mkdir -p cleanroom/private/upstream
cd cleanroom/private/upstream
curl -fsSLO https://ftp.gnu.org/gnu/coreutils/coreutils-9.10.tar.xz
mkdir -p coreutils-9.10-tests
tar -xf coreutils-9.10.tar.xz -C coreutils-9.10-tests --strip-components=1 \
  coreutils-9.10/tests/expr coreutils-9.10/tests/Coreutils.pm
cd ../../..
./tools/run_upstream_expr_tests.py cleanroom/private/upstream/coreutils-9.10-tests
```

Do not extract or inspect GNU coreutils implementation source files.

## Repository layout

- `src/main.rs` — single-file binary crate (parser, evaluator, BRE →
  fancy-regex translation, builtin dispatch).
- `tests/` — Rust integration tests (`oracle_basic.rs`, `practical.rs`).
- `tools/` — runtime developer tools.
  - `oracle_sweep.py` — 36-case core-builtin sweep.
  - `practical_check.py` — runs the 43-case practical corpus.
  - `run_upstream_expr_tests.py` — runs coreutils 9.10 `expr.pl` Perl harness.
  - `fuzz.py` — random-valid-expr generator + oracle differ.
  - `bench.sh` — reproducible perf measurement.
  - `stress.sh` — synthetic many-call stress workload.
- `practical-corpus/corpus.json` — 43 real-world-style invocations.
- `vendor/` — vendored Cargo deps (`fancy-regex`, `num-bigint`, `num-traits`,
  plus their transitive deps) for offline jonerix builds.
- `cleanroom/` — clean-room provenance: notes; `cleanroom/private/`
  (gitignored) for downloaded upstream archives and generated traces.
- `.forgejo/workflows/ci.yml` — fmt, clippy, unit tests, oracle sweep.

## Lint policy

`#![forbid(unsafe_code)]` and `#![deny(warnings)]` are in effect at the
crate root, and CI also passes `RUSTFLAGS=-D warnings`. Any rustc warning
or any `unsafe` block is a hard error. CI additionally runs `cargo clippy
--all-targets -- -D warnings` and `cargo fmt --check`.

## License

MIT.
