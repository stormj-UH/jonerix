// (c) 2026 Jon-Erik G. Storm, Inc., a California Corporation,
// doing business as LAVA GOAT SOFTWARE.  MIT license.
//
// Integration tests for the iptables shim.
//
// These exercise the parser → lowerer → nft-text path end-to-end,
// asserting on the textual nft commands the lowerer emits. No kernel
// or netlink socket is touched, so they run on any host with a Rust
// toolchain — no #[ignore], no #[cfg(target_os = "linux")] gate.
//
// A separate set of "kernel-real" integration tests lives in the
// `tests/iptables-shim.sh` shell harness; those are gated on Linux +
// CAP_NET_ADMIN and only run from the package CI runner.

use super::cmd::*;
use super::lower::lower;
use super::parser::parse;
use super::save::{parse_restore_stream, render_rule_save};

fn lower_argv(family: Family, args: &[&str]) -> Vec<String> {
    let argv: Vec<String> = args.iter().map(|s| s.to_string()).collect();
    let cmd = parse(family, &argv).unwrap().cmd;
    lower(&cmd).unwrap().lines.into_iter().map(|l| l.0).collect()
}

fn last_rule(family: Family, args: &[&str]) -> String {
    lower_argv(family, args).into_iter().last().unwrap()
}

/// True when the command never reaches the kernel: either the lowerer
/// refuses it outright, or the nft text it produces carries a token the
/// nft parser cannot encode (which `check_fully_parsed` refuses).
fn is_refused(family: Family, args: &[&str]) -> bool {
    let argv: Vec<String> = args.iter().map(|s| s.to_string()).collect();
    let cmd = match parse(family, &argv) {
        Ok(c) => c.cmd,
        Err(_) => return true,
    };
    let batch = match lower(&cmd) {
        Ok(b) => b,
        Err(_) => return true,
    };
    batch.lines.iter().any(|l| {
        crate::parser::parse(&l.0)
            .map(|c| super::check_fully_parsed(&c).is_err())
            .unwrap_or(true)
    })
}

// ── 1. iptables_basic_append ─────────────────────────────────────────

#[test]
fn iptables_basic_append() {
    // iptables -A FORWARD -j ACCEPT
    //   → add rule ip filter forward accept
    let lines = lower_argv(Family::Ip, &["-A", "FORWARD", "-j", "ACCEPT"]);
    assert!(lines.iter().any(|l| l == "add rule ip filter forward accept"),
        "lines: {:?}", lines);
    // Plus the implicit table+chain preamble.
    assert!(lines.iter().any(|l| l.starts_with("add table ip filter")));
    assert!(lines.iter().any(|l| l.contains("hook forward") && l.contains("policy accept")));
}

// ── 2. iptables_with_match ───────────────────────────────────────────

#[test]
fn iptables_with_match() {
    // iptables -A FORWARD -p tcp --dport 22 -j ACCEPT
    //   → add rule ip filter forward tcp dport 22 accept
    let rule = last_rule(Family::Ip, &[
        "-A", "FORWARD", "-p", "tcp", "--dport", "22", "-j", "ACCEPT",
    ]);
    assert!(rule.contains("tcp dport 22"), "rule: {}", rule);
    assert!(rule.ends_with("accept"), "rule: {}", rule);
}

// ── 3. iptables_nat_masquerade — Docker first-start sequence ─────────

#[test]
fn iptables_nat_masquerade() {
    // iptables -t nat -N DOCKER
    let r = lower_argv(Family::Ip, &["-t", "nat", "-N", "DOCKER"]);
    assert!(r.iter().any(|l| l == "add chain ip nat DOCKER"), "{:?}", r);

    // iptables -t nat -A POSTROUTING -s 172.17.0.0/16 ! -o docker0 -j MASQUERADE
    let rule = last_rule(Family::Ip, &[
        "-t", "nat", "-A", "POSTROUTING",
        "-s", "172.17.0.0/16", "!", "-o", "docker0",
        "-j", "MASQUERADE",
    ]);
    assert!(rule.contains("ip saddr 172.17.0.0/16"), "rule: {}", rule);
    assert!(rule.contains("oifname != \"docker0\""), "rule: {}", rule);
    assert!(rule.contains("masquerade"), "rule: {}", rule);

    // iptables -t nat -A PREROUTING -m addrtype --dst-type LOCAL -j DOCKER
    let rule = last_rule(Family::Ip, &[
        "-t", "nat", "-A", "PREROUTING",
        "-m", "addrtype", "--dst-type", "LOCAL",
        "-j", "DOCKER",
    ]);
    assert!(rule.contains("fib daddr type local"), "rule: {}", rule);
    assert!(rule.contains("jump DOCKER"), "rule: {}", rule);
}

// ── 4. iptables_dnat_port_publish — Docker -p 8080:80 case ───────────

#[test]
fn iptables_dnat_port_publish() {
    // iptables -t nat -A DOCKER ! -i docker0 -p tcp --dport 8080
    //          -j DNAT --to-destination 172.17.0.2:80
    //
    // Note: this uses a USER chain (DOCKER). Since 1.1.2 the lowerer
    // emits a bare `add chain` preamble for user chains as well, so
    // `-A` is safe whether the caller did `-N` first or not — `add
    // chain` is idempotent in nft. We verify both pieces below.
    let create_lines = lower_argv(Family::Ip, &["-t", "nat", "-N", "DOCKER"]);
    assert!(create_lines.iter().any(|l| l == "add chain ip nat DOCKER"));

    // Now the rule itself.
    let rule = last_rule(Family::Ip, &[
        "-t", "nat", "-A", "DOCKER",
        "!", "-i", "docker0",
        "-p", "tcp", "--dport", "8080",
        "-j", "DNAT", "--to-destination", "172.17.0.2:80",
    ]);
    assert!(rule.contains("iifname != \"docker0\""), "rule: {}", rule);
    assert!(rule.contains("tcp dport 8080"), "rule: {}", rule);
    assert!(rule.contains("dnat to 172.17.0.2:80"), "rule: {}", rule);
}

// ── 5. iptables_save_round_trip ──────────────────────────────────────

#[test]
fn iptables_save_round_trip() {
    // Build a small ruleset, dump via iptables-save format, parse
    // back, verify every rule survives the round-trip semantically.
    let inputs: &[&[&str]] = &[
        &["-A", "INPUT", "-p", "tcp", "--dport", "22", "-j", "ACCEPT"],
        &["-A", "FORWARD", "-m", "conntrack", "--ctstate", "RELATED,ESTABLISHED", "-j", "ACCEPT"],
        &["-t", "nat", "-A", "POSTROUTING", "-s", "172.17.0.0/16", "-j", "MASQUERADE"],
    ];
    let mut save_text = String::from("# Generated by stormwall iptables-save\n");
    let mut tables: std::collections::BTreeMap<&str, Vec<&'static [&'static str]>> =
        std::collections::BTreeMap::new();
    for spec in inputs {
        let table = if spec.iter().any(|t| *t == "-t") {
            spec[spec.iter().position(|t| *t == "-t").unwrap() + 1]
        } else { "filter" };
        tables.entry(table).or_default().push(*spec);
    }
    for (table, specs) in &tables {
        save_text.push_str(&format!("*{}\n", table));
        save_text.push_str(":INPUT ACCEPT [0:0]\n");
        save_text.push_str(":FORWARD ACCEPT [0:0]\n");
        save_text.push_str(":OUTPUT ACCEPT [0:0]\n");
        if *table == "nat" {
            save_text.push_str(":PREROUTING ACCEPT [0:0]\n");
            save_text.push_str(":POSTROUTING ACCEPT [0:0]\n");
        }
        for spec in specs {
            // Build a one-shot IptCmd to render in save format.
            let mut argv: Vec<String> = spec.iter().map(|s| s.to_string()).collect();
            // Drop the "-t TABLE" prefix because render_rule_save
            // doesn't include it (the *table line above scopes it).
            if argv.first().map(|s| s.as_str()) == Some("-t") {
                argv.drain(0..2);
            }
            let cmd = parse(Family::Ip, &argv).unwrap().cmd;
            save_text.push_str(&render_rule_save(&cmd));
            save_text.push('\n');
        }
        save_text.push_str("COMMIT\n");
    }

    // Round-trip: parse the save text and compare rule count / chain set.
    let stream = parse_restore_stream(Family::Ip, &save_text).unwrap();
    let total_rules: usize = stream.tables.iter().map(|t| t.rules.len()).sum();
    assert_eq!(total_rules, inputs.len(),
        "round-trip lost rules: {}", save_text);

    // Each parsed rule should re-lower cleanly.
    for t in &stream.tables {
        for r in &t.rules {
            let _ = lower(&r.cmd).expect("re-lower failed");
        }
    }
}

// ── 6. iptables_user_chain_lifecycle ─────────────────────────────────

#[test]
fn iptables_user_chain_lifecycle() {
    // -N DOCKER creates the user chain.
    let r = lower_argv(Family::Ip, &["-N", "DOCKER"]);
    assert!(r.iter().any(|l| l == "add chain ip filter DOCKER"));

    // -A DOCKER -j RETURN appends a rule to it.
    let rule = last_rule(Family::Ip, &["-A", "DOCKER", "-j", "RETURN"]);
    assert!(rule.contains("return"), "rule: {}", rule);

    // -X DOCKER deletes the user chain.
    let r = lower_argv(Family::Ip, &["-X", "DOCKER"]);
    assert!(r.iter().any(|l| l == "delete chain ip filter DOCKER"), "{:?}", r);
}

// ── 6b. iptables_user_chain_auto_create_on_append ────────────────────
//
// Regression: dockerd's libnetwork bridge driver issues `-A` against
// user chains it expects to already exist (DOCKER-USER, isolation
// chains, per-network DOCKER-FOOBAR sub-chains) without always doing
// `-N` first in the same invocation. The lowerer used to emit only
// `add table` for those calls, leaving the rule add to fail with
// ENOENT, which dockerd surfaces as "iptables: No such file or
// directory" and then aborts bridge bring-up. Since 1.1.2 we emit a
// bare `add chain` preamble for user chains too — it's idempotent in
// nft (no-op if the chain exists) so callers that did `-N` first are
// unaffected.
#[test]
fn iptables_user_chain_auto_create_on_append() {
    let lines = lower_argv(
        Family::Ip,
        &["-A", "DOCKER-USER", "-j", "ACCEPT"],
    );
    // Preamble must contain both the table and the chain creation.
    assert!(
        lines.iter().any(|l| l == "add table ip filter"),
        "missing add table: {:?}", lines,
    );
    assert!(
        lines.iter().any(|l| l == "add chain ip filter DOCKER-USER"),
        "missing user-chain auto-create: {:?}", lines,
    );
    // Built-in chain creation has braces and a hook; user-chain
    // creation must NOT — otherwise nft refuses with "Could not
    // process rule: Operation not supported" because user chains
    // don't take a hook spec.
    let chain_line = lines
        .iter()
        .find(|l| l.starts_with("add chain ip filter DOCKER-USER"))
        .unwrap();
    assert!(!chain_line.contains('{'), "user chain emitted with hook: {}", chain_line);
    // And the rule itself still lands.
    assert!(
        lines.iter().any(|l| l == "add rule ip filter DOCKER-USER accept"),
        "missing rule: {:?}", lines,
    );
}

// ── 6b2. iptables_jump_target_user_chain_auto_create ─────────────────
//
// Regression for the dockerd bridge bring-up sequence. After dockerd
// flushes + deletes its DOCKER user chain in cleanup, it issues
//
//     iptables -I FORWARD -o docker0 -j DOCKER
//
// against an existing built-in (FORWARD) but jumps to a user chain
// (DOCKER) it never recreated. nft refuses with ENOENT because the
// jump target doesn't exist; stormwall used to surface that as
// "iptables: No such file or directory" and dockerd treats that as
// fatal, aborting bridge bring-up.
//
// 1.1.3 emits a bare `add chain` for the JUMP target as well, so the
// rule add lands cleanly. Real iptables would error here ("No
// chain/target/match by that name"), but auto-creation is consistent
// with how we already handle `-A USERCHAIN` and is what dockerd needs.
#[test]
fn iptables_jump_target_user_chain_auto_create() {
    let lines = lower_argv(
        Family::Ip,
        &["-I", "FORWARD", "-o", "docker0", "-j", "DOCKER"],
    );
    // Both the operating chain (built-in FORWARD with hook) and the
    // jump target (user chain DOCKER, bare) must be in the preamble.
    let forward_line = lines
        .iter()
        .find(|l| l.starts_with("add chain ip filter forward"))
        .unwrap_or_else(|| panic!("no FORWARD preamble: {:?}", lines));
    assert!(forward_line.contains("type filter hook forward"),
        "expected FORWARD hook spec: {}", forward_line);
    assert!(
        lines.iter().any(|l| l == "add chain ip filter DOCKER"),
        "missing jump-target auto-create for DOCKER: {:?}", lines,
    );
    // And the rule itself.
    assert!(
        lines.iter().any(|l| l.contains("insert rule ip filter forward")
                          && l.contains("oifname \"docker0\"")
                          && l.contains("jump DOCKER")),
        "missing insert rule: {:?}", lines,
    );
}

// ── 6b3. iptables_jump_target_builtin_skips_extra_preamble ───────────
//
// Sanity: a `-j` to a built-in chain name (rare but legal) must NOT
// emit a bare `add chain` for that built-in. The hook-bearing preamble
// for the operating chain is the only one we want.
#[test]
fn iptables_jump_target_builtin_skips_extra_preamble() {
    let lines = lower_argv(
        Family::Ip,
        &["-A", "FORWARD", "-j", "INPUT"],
    );
    let bare_input = lines.iter()
        .filter(|l| l.starts_with("add chain ip filter input") && !l.contains('{'))
        .count();
    assert_eq!(bare_input, 0,
        "must not emit bare add chain for built-in jump target: {:?}", lines);
}

// ── 7c. New target/match coverage (1.1.5 surface expansion) ──────────
//
// Each of these covers an iptables flag/target/match-module that was
// either silently dropped or treated as an unknown user chain in
// previous revisions. The lower-side text assertions below match the
// canonical nft form documented at wiki.nftables.org / man nft.

#[test]
fn iptables_rename_chain() {
    // -E OLD NEW lowers to the nft `rename chain` primitive.
    let lines = lower_argv(Family::Ip, &["-E", "OLD-CHAIN", "NEW-CHAIN"]);
    assert!(
        lines.iter().any(|l| l == "rename chain ip filter OLD-CHAIN NEW-CHAIN"),
        "missing rename: {:?}", lines,
    );
}

#[test]
fn iptables_random_fully_masquerade() {
    let rule = last_rule(Family::Ip, &[
        "-t", "nat", "-A", "POSTROUTING", "-o", "eth0",
        "-j", "MASQUERADE", "--random-fully",
    ]);
    assert!(rule.contains("masquerade"), "{}", rule);
    assert!(rule.contains("fully-random"),
        "expected fully-random flag: {}", rule);
}

#[test]
fn iptables_random_fully_snat() {
    let rule = last_rule(Family::Ip, &[
        "-t", "nat", "-A", "POSTROUTING",
        "-j", "SNAT", "--to-source", "1.2.3.4", "--random-fully",
    ]);
    assert!(rule.contains("snat to 1.2.3.4"), "{}", rule);
    assert!(rule.contains("fully-random"),
        "expected fully-random flag: {}", rule);
}

#[test]
fn iptables_iprange_match() {
    let rule = last_rule(Family::Ip, &[
        "-A", "FORWARD", "-m", "iprange",
        "--src-range", "10.0.0.1-10.0.0.100",
        "-j", "ACCEPT",
    ]);
    assert!(rule.contains("ip saddr 10.0.0.1-10.0.0.100"),
        "expected iprange src clause: {}", rule);
}

#[test]
fn iptables_iprange_combined() {
    // Single -m iprange with both --src-range and --dst-range folds
    // into one MatchModule::Iprange.
    let rule = last_rule(Family::Ip, &[
        "-A", "FORWARD", "-m", "iprange",
        "--src-range", "10.0.0.1-10.0.0.100",
        "--dst-range", "192.168.0.1-192.168.0.50",
        "-j", "ACCEPT",
    ]);
    assert!(rule.contains("ip saddr 10.0.0.1-10.0.0.100"), "{}", rule);
    assert!(rule.contains("ip daddr 192.168.0.1-192.168.0.50"), "{}", rule);
}

#[test]
fn iptables_length_match() {
    let single = last_rule(Family::Ip, &[
        "-A", "INPUT", "-m", "length", "--length", "100", "-j", "ACCEPT",
    ]);
    assert!(single.contains("meta length 100"), "{}", single);

    let range = last_rule(Family::Ip, &[
        "-A", "INPUT", "-m", "length", "--length", "200:500", "-j", "ACCEPT",
    ]);
    assert!(range.contains("meta length 200-500"), "{}", range);
}

#[test]
fn iptables_pkttype_match() {
    let rule = last_rule(Family::Ip, &[
        "-A", "INPUT", "-m", "pkttype", "--pkt-type", "broadcast",
        "-j", "DROP",
    ]);
    assert!(rule.contains("meta pkttype broadcast"), "{}", rule);
}

#[test]
fn iptables_connmark_match_distinct_from_mark() {
    // -m connmark --mark X must lower to ct mark (not meta mark).
    let rule = last_rule(Family::Ip, &[
        "-A", "INPUT", "-m", "connmark", "--mark", "0x10",
        "-j", "ACCEPT",
    ]);
    assert!(rule.contains("ct mark 0x10"),
        "expected ct mark: {}", rule);
    assert!(!rule.contains("meta mark 0x10"),
        "must not emit meta mark for connmark match: {}", rule);

    // -m mark --mark X stays as meta mark.
    let rule = last_rule(Family::Ip, &[
        "-A", "INPUT", "-m", "mark", "--mark", "0x10",
        "-j", "ACCEPT",
    ]);
    // Existing -m mark lowering uses the `==` operator form
    // (`meta mark == 0x10`); -m connmark uses bare `ct mark 0x10`.
    // Both are valid nft.
    assert!(rule.contains("meta mark"),
        "expected meta mark: {}", rule);
    assert!(rule.contains("0x10"),
        "expected mark value: {}", rule);
}

#[test]
fn iptables_connmark_restore_mark_with_masks() {
    // Tailscale's healthcheck rule: `-j CONNMARK --restore-mark
    // --nfmask 0xff0000 --ctmask 0xff0000`.  1.1.6 rejected the
    // `--nfmask` flag as unknown ("iptables: unknown flag: --nfmask"),
    // breaking `tailscale up`.  1.1.7 parses both masks and emits the
    // masked nft form `meta mark set ct mark and 0xff0000`.
    let rule = last_rule(Family::Ip, &[
        "-t", "mangle", "-I", "PREROUTING", "1",
        "-m", "conntrack", "--ctstate", "RELATED,ESTABLISHED",
        "-j", "CONNMARK", "--restore-mark",
        "--nfmask", "0xff0000", "--ctmask", "0xff0000",
    ]);
    assert!(rule.contains("meta mark set ct mark and 0xff0000"),
        "rule should mask connmark restore: {}", rule);
}

#[test]
fn iptables_connmark_save_mark_with_masks() {
    // Symmetric of restore-mark — sets ct mark from packet mark
    // through the mask. ctmask wins when both are set (same value
    // in this test, so trivially).
    let rule = last_rule(Family::Ip, &[
        "-t", "mangle", "-A", "POSTROUTING",
        "-j", "CONNMARK", "--save-mark",
        "--nfmask", "0xff0000", "--ctmask", "0xff0000",
    ]);
    assert!(rule.contains("ct mark set meta mark and 0xff0000"),
        "rule should mask connmark save: {}", rule);
}

#[test]
fn iptables_connmark_restore_mark_no_masks_unchanged() {
    // Without --nfmask/--ctmask, the existing simple form stays.
    let rule = last_rule(Family::Ip, &[
        "-t", "mangle", "-A", "PREROUTING",
        "-j", "CONNMARK", "--restore-mark",
    ]);
    assert!(rule.contains("meta mark set ct mark"),
        "rule should preserve simple restore: {}", rule);
    assert!(!rule.contains(" and "),
        "must not have stray mask: {}", rule);
}

#[test]
fn iptables_notrack_target() {
    let rule = last_rule(Family::Ip, &[
        "-t", "raw", "-A", "PREROUTING", "-p", "udp",
        "-j", "NOTRACK",
    ]);
    assert!(rule.ends_with("notrack"),
        "expected notrack verdict: {}", rule);
}

#[test]
fn iptables_nfqueue_target() {
    let single = last_rule(Family::Ip, &[
        "-A", "INPUT", "-j", "NFQUEUE", "--queue-num", "5",
    ]);
    assert!(single.contains("queue num 5"), "{}", single);

    let bypass = last_rule(Family::Ip, &[
        "-A", "INPUT", "-j", "NFQUEUE", "--queue-num", "10", "--queue-bypass",
    ]);
    assert!(bypass.contains("queue num 10"), "{}", bypass);
    assert!(bypass.contains("bypass"), "{}", bypass);

    let balance = last_rule(Family::Ip, &[
        "-A", "INPUT", "-j", "NFQUEUE", "--queue-balance", "0:3",
    ]);
    assert!(balance.contains("queue num 0-3"), "{}", balance);
}

#[test]
fn iptables_tcpmss_target_clamp() {
    let rule = last_rule(Family::Ip, &[
        "-t", "mangle", "-A", "FORWARD", "-p", "tcp", "--tcp-flags",
        "SYN,RST", "SYN", "-j", "TCPMSS", "--clamp-mss-to-pmtu",
    ]);
    assert!(rule.contains("tcp option maxseg size set rt mtu"),
        "expected clamp-to-pmtu lowering: {}", rule);
}

#[test]
fn iptables_tcpmss_target_set_explicit() {
    let rule = last_rule(Family::Ip, &[
        "-t", "mangle", "-A", "FORWARD",
        "-j", "TCPMSS", "--set-mss", "1400",
    ]);
    assert!(rule.contains("tcp option maxseg size set 1400"), "{}", rule);
}

#[test]
fn iptables_tcpmss_match() {
    let rule = last_rule(Family::Ip, &[
        "-A", "FORWARD", "-p", "tcp", "-m", "tcpmss", "--mss", "1400",
        "-j", "DROP",
    ]);
    assert!(rule.contains("tcp option maxseg size 1400"), "{}", rule);
}

#[test]
fn iptables_ct_target_notrack() {
    let rule = last_rule(Family::Ip, &[
        "-t", "raw", "-A", "PREROUTING", "-p", "udp", "--dport", "53",
        "-j", "CT", "--notrack",
    ]);
    assert!(rule.contains("notrack"), "{}", rule);
}

#[test]
fn iptables_ct_target_helper() {
    let rule = last_rule(Family::Ip, &[
        "-t", "raw", "-A", "PREROUTING", "-p", "tcp", "--dport", "21",
        "-j", "CT", "--helper", "ftp",
    ]);
    assert!(rule.contains("ct helper set \"ftp\""),
        "expected ct helper set: {}", rule);
}

#[test]
fn iptables_ct_target_zone() {
    let rule = last_rule(Family::Ip, &[
        "-t", "raw", "-A", "PREROUTING", "-i", "eth0",
        "-j", "CT", "--zone", "5",
    ]);
    assert!(rule.contains("ct zone set 5"), "{}", rule);
}

// ── Tier 2 (1.1.9): TOS/DSCP/TTL/HL/statistic/connlimit/helper/time/
//                    rpfilter matches + CLASSIFY/CHECKSUM/NETMAP/SET targets.

#[test]
fn iptables_tos_match() {
    let rule = last_rule(Family::Ip, &[
        "-A", "INPUT", "-m", "tos", "--tos", "0x10", "-j", "ACCEPT",
    ]);
    // -m tos lowers to ip dscp (top 6 bits).
    assert!(rule.contains("ip dscp"), "{}", rule);
    assert!(rule.contains("0x10"), "{}", rule);
}

#[test]
fn iptables_dscp_match() {
    let rule = last_rule(Family::Ip, &[
        "-A", "INPUT", "-m", "dscp", "--dscp-class", "EF", "-j", "ACCEPT",
    ]);
    // EF = 46 = 0x2e
    assert!(rule.contains("ip dscp 0x2e"), "{}", rule);
}

#[test]
fn iptables_ttl_match() {
    let eq = last_rule(Family::Ip, &["-A", "INPUT", "-m", "ttl", "--ttl-eq", "64", "-j", "ACCEPT"]);
    assert!(eq.contains("ip ttl 64"), "{}", eq);
    let lt = last_rule(Family::Ip, &["-A", "INPUT", "-m", "ttl", "--ttl-lt", "64", "-j", "ACCEPT"]);
    assert!(lt.contains("ip ttl < 64"), "{}", lt);
    let gt = last_rule(Family::Ip, &["-A", "INPUT", "-m", "ttl", "--ttl-gt", "64", "-j", "ACCEPT"]);
    assert!(gt.contains("ip ttl > 64"), "{}", gt);
}

#[test]
fn iptables_hl_match() {
    let rule = last_rule(Family::Ip6, &[
        "-A", "INPUT", "-m", "hl", "--hl-eq", "64", "-j", "ACCEPT",
    ]);
    assert!(rule.contains("ip6 hoplimit 64"), "{}", rule);
}

#[test]
fn iptables_statistic_random() {
    let rule = last_rule(Family::Ip, &[
        "-A", "INPUT", "-m", "statistic", "--mode", "random",
        "--probability", "0.5", "-j", "DROP",
    ]);
    // 0.5 probability → 5e8 ppb threshold.
    assert!(rule.contains("numgen random mod 1000000000"), "{}", rule);
    assert!(rule.contains("500000000"), "{}", rule);
}

#[test]
fn iptables_statistic_nth() {
    let rule = last_rule(Family::Ip, &[
        "-A", "INPUT", "-m", "statistic", "--mode", "nth",
        "--every", "3", "--packet", "0", "-j", "DROP",
    ]);
    assert!(rule.contains("numgen inc mod 3 == 0"), "{}", rule);
}

#[test]
fn iptables_connlimit_above() {
    let rule = last_rule(Family::Ip, &[
        "-A", "INPUT", "-p", "tcp", "--dport", "22",
        "-m", "connlimit", "--connlimit-above", "10",
        "-j", "REJECT", "--reject-with", "tcp-reset",
    ]);
    assert!(rule.contains("ct count over 10"), "{}", rule);
}

#[test]
fn iptables_helper_match_distinct_from_ct_target() {
    // -m helper --helper "ftp" is a match (ct helper "ftp")
    let rule = last_rule(Family::Ip, &[
        "-A", "INPUT", "-m", "helper", "--helper", "ftp", "-j", "ACCEPT",
    ]);
    assert!(rule.contains("ct helper \"ftp\""), "{}", rule);
    // -j CT --helper is a target (ct helper set "ftp")
    let rule = last_rule(Family::Ip, &[
        "-t", "raw", "-A", "PREROUTING", "-p", "tcp", "--dport", "21",
        "-j", "CT", "--helper", "ftp",
    ]);
    assert!(rule.contains("ct helper set \"ftp\""), "{}", rule);
}

#[test]
fn iptables_time_match() {
    let rule = last_rule(Family::Ip, &[
        "-A", "INPUT", "-m", "time",
        "--timestart", "09:00", "--timestop", "17:00",
        "--weekdays", "Mon,Tue,Wed,Thu,Fri",
        "-j", "ACCEPT",
    ]);
    assert!(rule.contains("meta hour"), "{}", rule);
    assert!(rule.contains("meta day"), "{}", rule);
    assert!(rule.contains("monday"), "{}", rule);
    assert!(rule.contains("friday"), "{}", rule);
}

#[test]
fn iptables_rpfilter_match() {
    let pass = last_rule(Family::Ip, &[
        "-A", "PREROUTING", "-m", "rpfilter", "-j", "ACCEPT",
    ]);
    assert!(pass.contains("fib saddr . iif oif != 0"), "{}", pass);
    let fail = last_rule(Family::Ip, &[
        "-A", "PREROUTING", "-m", "rpfilter", "--invert", "-j", "DROP",
    ]);
    assert!(fail.contains("fib saddr . iif oif eq 0"), "{}", fail);
}

#[test]
fn iptables_tos_target() {
    let rule = last_rule(Family::Ip, &[
        "-t", "mangle", "-A", "POSTROUTING",
        "-j", "TOS", "--set-tos", "0x10",
    ]);
    assert!(rule.contains("ip dscp set 0x10"), "{}", rule);
}

#[test]
fn iptables_dscp_target() {
    let rule = last_rule(Family::Ip, &[
        "-t", "mangle", "-A", "POSTROUTING",
        "-j", "DSCP", "--set-dscp-class", "EF",
    ]);
    // EF = 46 = 0x2e
    assert!(rule.contains("ip dscp set 0x2e"), "{}", rule);
}

#[test]
fn iptables_ttl_target() {
    let rule = last_rule(Family::Ip, &[
        "-t", "mangle", "-A", "PREROUTING",
        "-j", "TTL", "--ttl-set", "64",
    ]);
    assert!(rule.contains("ip ttl set 64"), "{}", rule);
}

#[test]
fn iptables_hl_target() {
    let rule = last_rule(Family::Ip6, &[
        "-t", "mangle", "-A", "PREROUTING",
        "-j", "HL", "--hl-set", "64",
    ]);
    assert!(rule.contains("ip6 hoplimit set 64"), "{}", rule);
}

#[test]
fn iptables_classify_target() {
    let rule = last_rule(Family::Ip, &[
        "-t", "mangle", "-A", "POSTROUTING",
        "-j", "CLASSIFY", "--set-class", "1:10",
    ]);
    assert!(rule.contains("meta priority set"), "{}", rule);
    assert!(rule.contains("0x1:0x10"), "{}", rule);
}

#[test]
fn iptables_netmap_target() {
    let pre = last_rule(Family::Ip, &[
        "-t", "nat", "-A", "PREROUTING",
        "-j", "NETMAP", "--to", "10.0.0.0/24",
    ]);
    assert!(pre.contains("dnat to 10.0.0.0/24"), "{}", pre);
    let post = last_rule(Family::Ip, &[
        "-t", "nat", "-A", "POSTROUTING",
        "-j", "NETMAP", "--to", "10.0.0.0/24",
    ]);
    assert!(post.contains("snat to 10.0.0.0/24"), "{}", post);
}

#[test]
fn iptables_set_target_add() {
    let rule = last_rule(Family::Ip, &[
        "-A", "INPUT",
        "-j", "SET", "--add-set", "BLACKLIST", "src",
    ]);
    assert!(rule.contains("add @BLACKLIST { ip saddr }"), "{}", rule);
}

// ── 1.1.10: -m recent (port-knocking / rate-limit-by-IP) ─────────────

#[test]
fn iptables_recent_rcheck() {
    let rule = last_rule(Family::Ip, &[
        "-A", "INPUT", "-m", "recent", "--rcheck",
        "--seconds", "60", "--name", "BLACKLIST", "-j", "DROP",
    ]);
    assert!(rule.contains("ip saddr @BLACKLIST"), "{}", rule);
    assert!(rule.contains("drop"), "{}", rule);
}

#[test]
fn iptables_recent_set() {
    let rule = last_rule(Family::Ip, &[
        "-A", "INPUT", "-p", "tcp", "--dport", "22",
        "-m", "recent", "--set", "--name", "ssh-flood",
        "-j", "ACCEPT",
    ]);
    assert!(rule.contains("update @ssh-flood"), "{}", rule);
    assert!(rule.contains("ip saddr"), "{}", rule);
}

#[test]
fn iptables_recent_with_timeout() {
    let rule = last_rule(Family::Ip, &[
        "-A", "INPUT", "-m", "recent", "--update",
        "--seconds", "300", "--name", "sshtrack",
        "-j", "DROP",
    ]);
    assert!(rule.contains("update @sshtrack"), "{}", rule);
    assert!(rule.contains("timeout 300s"), "{}", rule);
}

// ── 1.1.10: -m connbytes (per-flow byte/packet count) ─────────────────

#[test]
fn iptables_connbytes_packets() {
    let rule = last_rule(Family::Ip, &[
        "-A", "FORWARD", "-m", "connbytes", "--connbytes", "100:",
        "--connbytes-dir", "both", "--connbytes-mode", "packets",
        "-j", "LOG",
    ]);
    assert!(rule.contains("ct packets"), "{}", rule);
}

#[test]
fn iptables_connbytes_bytes_range() {
    let rule = last_rule(Family::Ip, &[
        "-A", "FORWARD", "-m", "connbytes", "--connbytes", "1000:5000",
        "--connbytes-mode", "bytes",
        "-j", "ACCEPT",
    ]);
    assert!(rule.contains("ct bytes"), "{}", rule);
    assert!(rule.contains("1000-5000"), "{}", rule);
}

#[test]
fn iptables_log_extra_flags() {
    let rule = last_rule(Family::Ip, &[
        "-A", "INPUT", "-j", "LOG",
        "--log-prefix", "DROP: ",
        "--log-tcp-sequence", "--log-tcp-options", "--log-ip-options",
    ]);
    assert!(rule.contains("prefix \"DROP: \""), "{}", rule);
    assert!(rule.contains("flags tcp"), "{}", rule);
    assert!(rule.contains("sequence"), "{}", rule);
    assert!(rule.contains("options"), "{}", rule);
    assert!(rule.contains("flags ip options"), "{}", rule);
}

#[test]
fn iptables_set_counters_compat() {
    // -c PKTS BYTES is parsed and the rule still installs (the counter
    // values are not honoured, just consumed).
    let rule = last_rule(Family::Ip, &[
        "-A", "INPUT", "-c", "0", "0", "-p", "tcp", "--dport", "22",
        "-j", "ACCEPT",
    ]);
    assert!(rule.contains("tcp dport 22"), "{}", rule);
    assert!(rule.contains("accept"), "{}", rule);
}

// ── 6c. iptables_builtin_chain_keeps_hook_preamble ───────────────────
//
// Sanity: built-in chains (FORWARD, INPUT, etc.) must continue to be
// emitted with full hook + priority + policy spec — the user-chain
// fix above must not regress that path.
#[test]
fn iptables_builtin_chain_keeps_hook_preamble() {
    let lines = lower_argv(
        Family::Ip,
        &["-A", "FORWARD", "-j", "ACCEPT"],
    );
    let forward = lines
        .iter()
        .find(|l| l.starts_with("add chain ip filter forward"))
        .unwrap_or_else(|| panic!("no FORWARD preamble: {:?}", lines));
    assert!(forward.contains("type filter hook forward"),
        "expected hook spec: {}", forward);
    assert!(forward.contains("policy accept"),
        "expected policy: {}", forward);
}

// ── 7. iptables_check ────────────────────────────────────────────────

#[test]
fn iptables_check_lowering_emits_check_token() {
    // -C is special: the lowerer emits a __CHECK_BY_MATCH__ marker
    // that the dispatcher turns into a GETRULE walk + match. We
    // assert here only that the lowering reaches the right marker.
    let argv: Vec<String> = ["-C", "FORWARD", "-p", "tcp", "--dport", "22", "-j", "ACCEPT"]
        .iter().map(|s| s.to_string()).collect();
    let cmd = parse(Family::Ip, &argv).unwrap().cmd;
    assert!(matches!(cmd.op, IptOp::Check));
    let lines = lower(&cmd).unwrap().lines;
    assert!(lines.iter().any(|l| l.0.starts_with("__CHECK_BY_MATCH__ ")), "{:?}", lines);
}

// ── 7b. iptables_legacy_negation_after_flag ──────────────────────────
//
// Regression: the parser captured `pending_neg` BEFORE calling
// `take_value`, but `take_value` is the function that recognises the
// legacy `-s ! 1.2.3.4` form by flipping `pending_neg`. So the legacy
// form never made it into the rule (capture happened too early).
// 1.1.4's `take_value_neg` helper captures after the read so both the
// modern (`! -s X`) and legacy (`-s ! X`) forms work.
#[test]
fn iptables_legacy_negation_after_flag() {
    let rule = last_rule(Family::Ip, &[
        "-A", "FORWARD", "-s", "!", "10.0.0.0/8", "-j", "DROP",
    ]);
    assert!(rule.contains("ip saddr != 10.0.0.0/8"),
        "expected legacy -s ! to negate: {}", rule);

    let rule = last_rule(Family::Ip, &[
        "-A", "FORWARD", "-o", "!", "docker0", "-j", "DROP",
    ]);
    assert!(rule.contains("oifname != \"docker0\""),
        "expected legacy -o ! to negate: {}", rule);

    let rule = last_rule(Family::Ip, &[
        "-A", "INPUT", "-p", "tcp", "--dport", "!", "22", "-j", "DROP",
    ]);
    assert!(rule.contains("tcp dport != 22"),
        "expected legacy --dport ! to negate: {}", rule);
}

// ── 8. ip6tables_smoke ───────────────────────────────────────────────

#[test]
fn ip6tables_smoke() {
    // ip6tables -A FORWARD -j ACCEPT
    //   → add rule ip6 filter forward accept
    let lines = lower_argv(Family::Ip6, &["-A", "FORWARD", "-j", "ACCEPT"]);
    assert!(lines.iter().any(|l| l == "add rule ip6 filter forward accept"),
        "lines: {:?}", lines);
    // Family-aware: source address keyword must be ip6.
    let rule = last_rule(Family::Ip6, &[
        "-A", "FORWARD", "-s", "fe80::1", "-j", "DROP",
    ]);
    assert!(rule.contains("ip6 saddr fe80::1"), "rule: {}", rule);
}

// ── 9. iptables_restore_atomic ───────────────────────────────────────

#[test]
fn iptables_restore_atomic_rejects_bad_syntax() {
    // A mid-stream syntax error should fail the entire parse so
    // nothing downstream gets applied. The dispatcher's apply path
    // calls parse_restore_stream first; if it errors, no nft batch
    // is sent. We verify the parser refuses the broken stream.
    let txt = "*filter
:INPUT ACCEPT [0:0]
-A INPUT -p tcp --dport 22 -j ACCEPT
-A INPUT --frobnicate-the-flux 12 -j ACCEPT
COMMIT
";
    let r = parse_restore_stream(Family::Ip, txt);
    assert!(r.is_err(), "expected parse failure, got {:?}", r);
}

#[test]
fn iptables_restore_accepts_clean_stream() {
    let txt = "*filter
:INPUT ACCEPT [0:0]
:FORWARD DROP [0:0]
:OUTPUT ACCEPT [0:0]
-A INPUT -p tcp --dport 22 -j ACCEPT
-A FORWARD -m conntrack --ctstate RELATED,ESTABLISHED -j ACCEPT
COMMIT
*nat
:POSTROUTING ACCEPT [0:0]
-A POSTROUTING -s 172.17.0.0/16 -j MASQUERADE
COMMIT
";
    let s = parse_restore_stream(Family::Ip, txt).expect("parse ok");
    assert_eq!(s.tables.len(), 2);
    let f = &s.tables[0];
    assert_eq!(f.table, IptTable::Filter);
    assert_eq!(f.chains.len(), 3);
    assert_eq!(f.rules.len(), 2);
    let n = &s.tables[1];
    assert_eq!(n.table, IptTable::Nat);
    assert_eq!(n.rules.len(), 1);
}

// ── 10. iptables_drop_and_reject ─────────────────────────────────────

#[test]
fn iptables_drop_target() {
    let rule = last_rule(Family::Ip, &["-A", "INPUT", "-j", "DROP"]);
    assert!(rule.ends_with("drop"), "rule: {}", rule);
}

#[test]
fn iptables_reject_with_icmp_host_unreachable() {
    let rule = last_rule(Family::Ip, &[
        "-A", "INPUT", "-j", "REJECT", "--reject-with", "icmp-host-unreachable",
    ]);
    assert!(rule.contains("reject with icmp type host-unreachable"),
        "rule: {}", rule);
}

// ── Docker first-start corpus ────────────────────────────────────────
//
// These mirror the calls libnetwork makes when dockerd boots (taken
// from `iptables -S` after a clean dockerd start, on a 6.x kernel).
// Every line below is something Docker actually issues; if all pass,
// Docker's bridge networking should "just work" through the shim.

#[test]
fn docker_first_start_filter_chains() {
    // -N DOCKER
    // -N DOCKER-USER
    // -N DOCKER-ISOLATION-STAGE-1
    // -A FORWARD -j DOCKER-USER
    // -A FORWARD -j DOCKER-ISOLATION-STAGE-1
    // -A FORWARD -m conntrack --ctstate RELATED,ESTABLISHED -j ACCEPT
    let cases: &[(&[&str], &str)] = &[
        (&["-N", "DOCKER"], "add chain ip filter DOCKER"),
        (&["-N", "DOCKER-USER"], "add chain ip filter DOCKER-USER"),
        (&["-N", "DOCKER-ISOLATION-STAGE-1"], "add chain ip filter DOCKER-ISOLATION-STAGE-1"),
    ];
    for (argv, expected) in cases {
        let lines = lower_argv(Family::Ip, argv);
        assert!(lines.iter().any(|l| l == expected), "{:?} → {:?}", argv, lines);
    }

    let rule = last_rule(Family::Ip, &["-A", "FORWARD", "-j", "DOCKER-USER"]);
    assert!(rule.contains("jump DOCKER-USER"), "rule: {}", rule);

    let rule = last_rule(Family::Ip, &[
        "-A", "FORWARD", "-m", "conntrack",
        "--ctstate", "RELATED,ESTABLISHED", "-j", "ACCEPT",
    ]);
    assert!(rule.contains("ct state { related, established }"), "rule: {}", rule);
    assert!(rule.contains("accept"));
}

#[test]
fn docker_first_start_nat_chains() {
    // -t nat -N DOCKER
    // -t nat -A PREROUTING -m addrtype --dst-type LOCAL -j DOCKER
    // -t nat -A OUTPUT ! -d 127.0.0.0/8 -m addrtype --dst-type LOCAL -j DOCKER
    // -t nat -A POSTROUTING -s 172.17.0.0/16 ! -o docker0 -j MASQUERADE
    let r = lower_argv(Family::Ip, &["-t", "nat", "-N", "DOCKER"]);
    assert!(r.iter().any(|l| l == "add chain ip nat DOCKER"));

    let rule = last_rule(Family::Ip, &[
        "-t", "nat", "-A", "PREROUTING",
        "-m", "addrtype", "--dst-type", "LOCAL", "-j", "DOCKER",
    ]);
    assert!(rule.contains("fib daddr type local"), "rule: {}", rule);
    assert!(rule.contains("jump DOCKER"));

    let rule = last_rule(Family::Ip, &[
        "-t", "nat", "-A", "OUTPUT",
        "!", "-d", "127.0.0.0/8",
        "-m", "addrtype", "--dst-type", "LOCAL", "-j", "DOCKER",
    ]);
    assert!(rule.contains("ip daddr != 127.0.0.0/8"), "rule: {}", rule);
    assert!(rule.contains("fib daddr type local"));
    assert!(rule.contains("jump DOCKER"));

    let rule = last_rule(Family::Ip, &[
        "-t", "nat", "-A", "POSTROUTING",
        "-s", "172.17.0.0/16", "!", "-o", "docker0", "-j", "MASQUERADE",
    ]);
    assert!(rule.contains("ip saddr 172.17.0.0/16"));
    assert!(rule.contains("oifname != \"docker0\""));
    assert!(rule.contains("masquerade"));
}

#[test]
fn docker_port_publish_pair() {
    // The two rules dockerd writes when you `docker run -p 8080:80`:
    //   1. -t nat -A DOCKER ! -i docker0 -p tcp --dport 8080 -j DNAT --to-destination 172.17.0.2:80
    //   2. -A DOCKER -d 172.17.0.2/32 ! -i docker0 -o docker0 -p tcp --dport 80 -j ACCEPT

    // Need to predeclare DOCKER chains in both tables for the rules
    // to make sense, but the lowerer just emits text — it doesn't
    // verify chain existence. So we only assert the rule shape.
    let rule = last_rule(Family::Ip, &[
        "-t", "nat", "-A", "DOCKER",
        "!", "-i", "docker0",
        "-p", "tcp", "--dport", "8080",
        "-j", "DNAT", "--to-destination", "172.17.0.2:80",
    ]);
    assert!(rule.contains("iifname != \"docker0\""), "{}", rule);
    assert!(rule.contains("tcp dport 8080"), "{}", rule);
    assert!(rule.contains("dnat to 172.17.0.2:80"), "{}", rule);

    let rule = last_rule(Family::Ip, &[
        "-A", "DOCKER",
        "-d", "172.17.0.2/32",
        "!", "-i", "docker0",
        "-o", "docker0",
        "-p", "tcp", "--dport", "80",
        "-j", "ACCEPT",
    ]);
    assert!(rule.contains("ip daddr 172.17.0.2/32"), "{}", rule);
    assert!(rule.contains("iifname != \"docker0\""), "{}", rule);
    assert!(rule.contains("oifname \"docker0\""), "{}", rule);
    assert!(rule.contains("tcp dport 80"), "{}", rule);
    assert!(rule.contains("accept"), "{}", rule);
}

// ── IPv6 extension header match modules ─────────────────────────────

// ── T-ext-1. -m ah (IPv4/IPv6) ─────────────────────────────────────
#[test]
fn ext_ah_spi_lowers() {
    // ip6tables -A INPUT -m ah --ahspi 42 -j ACCEPT
    //   → … ah spi 42 accept
    let rule = last_rule(Family::Ip6, &[
        "-A", "INPUT", "-m", "ah", "--ahspi", "42", "-j", "ACCEPT",
    ]);
    assert!(rule.contains("ah spi 42"), "rule: {}", rule);
    assert!(rule.ends_with("accept"), "rule: {}", rule);
}

// ── T-ext-2. -m esp ─────────────────────────────────────────────────
#[test]
fn ext_esp_spi_lowers() {
    // ip6tables -A FORWARD -m esp --espspi 100 -j ACCEPT
    //   → … esp spi 100 accept
    let rule = last_rule(Family::Ip6, &[
        "-A", "FORWARD", "-m", "esp", "--espspi", "100", "-j", "ACCEPT",
    ]);
    assert!(rule.contains("esp spi 100"), "rule: {}", rule);
}

// ── T-ext-3. -m frag ────────────────────────────────────────────────
#[test]
fn ext_frag_id_lowers() {
    // ip6tables -A INPUT -m frag --fragid 12345 --fragmore -j DROP
    //   → … frag id 12345 frag more-fragments 1 drop
    let rule = last_rule(Family::Ip6, &[
        "-A", "INPUT", "-m", "frag", "--fragid", "12345", "--fragmore", "-j", "DROP",
    ]);
    assert!(rule.contains("frag id 12345"), "rule: {}", rule);
    assert!(rule.contains("frag more-fragments 1"), "rule: {}", rule);
    assert!(rule.ends_with("drop"), "rule: {}", rule);
}

// ── T-ext-4. -m hbh ─────────────────────────────────────────────────
#[test]
fn ext_hbh_len_lowers() {
    // ip6tables -A INPUT -m hbh --hbh-len 8 -j ACCEPT
    //   → … hbh hdrlength 8 accept
    let rule = last_rule(Family::Ip6, &[
        "-A", "INPUT", "-m", "hbh", "--hbh-len", "8", "-j", "ACCEPT",
    ]);
    assert!(rule.contains("hbh hdrlength 8"), "rule: {}", rule);
}

// ── T-ext-5. -m mh ──────────────────────────────────────────────────
#[test]
fn ext_mh_type_lowers() {
    // ip6tables -A INPUT -m mh --mh-type binding-update -j ACCEPT
    //   → … mh type 5 accept
    let rule = last_rule(Family::Ip6, &[
        "-A", "INPUT", "-m", "mh", "--mh-type", "binding-update", "-j", "ACCEPT",
    ]);
    assert!(rule.contains("mh type 5"), "rule: {}", rule);
}

// ── T-ext-6. -m rt ──────────────────────────────────────────────────
#[test]
fn ext_rt_type_segs_lowers() {
    // ip6tables -A INPUT -m rt --rt-type 0 --rt-segsleft 3 -j ACCEPT
    //   → … rt type 0 rt segs-left 3 accept
    let rule = last_rule(Family::Ip6, &[
        "-A", "INPUT", "-m", "rt", "--rt-type", "0", "--rt-segsleft", "3", "-j", "ACCEPT",
    ]);
    assert!(rule.contains("rt type 0"), "rule: {}", rule);
    assert!(rule.contains("rt segs-left 3"), "rule: {}", rule);
}

// ── T-ext-7. -m dst ─────────────────────────────────────────────────
#[test]
fn ext_dst_len_lowers() {
    // ip6tables -A INPUT -m dst --dst-len 16 -j ACCEPT
    //   → … dst hdrlength 16 accept
    let rule = last_rule(Family::Ip6, &[
        "-A", "INPUT", "-m", "dst", "--dst-len", "16", "-j", "ACCEPT",
    ]);
    assert!(rule.contains("dst hdrlength 16"), "rule: {}", rule);
}

// ── T-ext-8. -m ipv6header ──────────────────────────────────────────
#[test]
fn ext_ipv6header_lowers() {
    // ip6tables -A INPUT -m ipv6header --header frag,ah -j DROP
    //   → … ip6 nexthdr { frag, ah } drop
    let rule = last_rule(Family::Ip6, &[
        "-A", "INPUT", "-m", "ipv6header", "--header", "frag,ah", "-j", "DROP",
    ]);
    // Header names resolve to their IANA next-header numbers: the
    // kernel compares one byte, so `frag`/`ah` as text never matched.
    assert!(rule.contains("ip6 nexthdr { 44, 51 }"), "rule: {}", rule);
}

// ── Save renderer fidelity ───────────────────────────────────────────

#[test]
fn save_render_negation_preserved() {
    let argv: Vec<String> = ["-A", "FORWARD", "!", "-i", "eth0", "-j", "DROP"]
        .iter().map(|s| s.to_string()).collect();
    let cmd = parse(Family::Ip, &argv).unwrap().cmd;
    let s = render_rule_save(&cmd);
    assert!(s.contains("! -i eth0"), "{}", s);
    assert!(s.contains("-j DROP"));
}

#[test]
fn save_render_dnat_to_destination() {
    let argv: Vec<String> = [
        "-t", "nat", "-A", "PREROUTING",
        "-p", "tcp", "--dport", "80",
        "-j", "DNAT", "--to-destination", "1.2.3.4:8080",
    ].iter().map(|s| s.to_string()).collect();
    // strip the -t and table prefix for save (table scope is from *nat).
    let cmd = parse(Family::Ip, &argv).unwrap().cmd;
    let s = render_rule_save(&cmd);
    assert!(s.contains("-A PREROUTING"), "{}", s);
    assert!(s.contains("-p tcp"));
    assert!(s.contains("--dport 80"));
    assert!(s.contains("--to-destination 1.2.3.4:8080"));
}

// ── hashlimit tests ──────────────────────────────────────────────────

// ── hashlimit_upto_basic: cap form lowers to plain `limit rate` ──────
#[test]
fn iptables_hashlimit_upto_basic() {
    // iptables -A INPUT -m hashlimit --hashlimit-upto 100/second
    //          --hashlimit-burst 20 --hashlimit-name rl0 -j ACCEPT
    //   → add rule … limit rate 100/second burst 20 packets … accept
    let rule = last_rule(Family::Ip, &[
        "-A", "INPUT",
        "-m", "hashlimit",
        "--hashlimit-upto", "100/second",
        "--hashlimit-burst", "20",
        "--hashlimit-name", "rl0",
        "-j", "ACCEPT",
    ]);
    assert!(rule.contains("limit rate 100/second burst 20 packets"), "rule: {}", rule);
    // "over" must NOT appear — that's the above/floor form.
    assert!(!rule.contains("over"), "rule: {}", rule);
    assert!(rule.ends_with("accept"), "rule: {}", rule);
}

// ── hashlimit_above_over: floor form lowers to `limit rate over` ─────
#[test]
fn iptables_hashlimit_above_over() {
    // iptables -A FORWARD -m hashlimit --hashlimit-above 50/minute
    //          --hashlimit-burst 10 -j DROP
    //   → add rule … limit rate over 50/minute burst 10 packets … drop
    let rule = last_rule(Family::Ip, &[
        "-A", "FORWARD",
        "-m", "hashlimit",
        "--hashlimit-above", "50/minute",
        "--hashlimit-burst", "10",
        "-j", "DROP",
    ]);
    assert!(rule.contains("limit rate over 50/minute burst 10 packets"), "rule: {}", rule);
    assert!(rule.ends_with("drop"), "rule: {}", rule);
}

// ── hashlimit_mode_comment: mode/srcmask land in comment marker ──────
#[test]
fn iptables_hashlimit_mode_comment() {
    // iptables -A INPUT -m hashlimit --hashlimit-upto 10/second
    //          --hashlimit-mode srcip,dstport --hashlimit-srcmask 24 -j ACCEPT
    //   → rule comment should include mode=srcip,dstport and srcmask=24
    let rule = last_rule(Family::Ip, &[
        "-A", "INPUT",
        "-m", "hashlimit",
        "--hashlimit-upto", "10/second",
        "--hashlimit-mode", "srcip,dstport",
        "--hashlimit-srcmask", "24",
        "-j", "ACCEPT",
    ]);
    assert!(rule.contains("limit rate 10/second"), "rule: {}", rule);
    assert!(rule.contains("comment"), "rule: {}", rule);
    assert!(rule.contains("mode=srcip,dstport"), "rule: {}", rule);
    assert!(rule.contains("srcmask=24"), "rule: {}", rule);
}

// ── hashlimit_save_roundtrip: iptables-save reproduces the flags ──────
#[test]
fn iptables_hashlimit_save_roundtrip() {
    let argv: Vec<String> = [
        "-A", "INPUT",
        "-m", "hashlimit",
        "--hashlimit-upto", "5/hour",
        "--hashlimit-burst", "3",
        "--hashlimit-name", "ssh-limit",
        "--hashlimit-mode", "srcip",
        "--hashlimit-htable-expire", "60000",
        "-j", "ACCEPT",
    ].iter().map(|s| s.to_string()).collect();
    let cmd = parse(Family::Ip, &argv).unwrap().cmd;
    let s = render_rule_save(&cmd);
    assert!(s.contains("-m hashlimit"), "{}", s);
    assert!(s.contains("--hashlimit-upto 5/hour"), "{}", s);
    assert!(s.contains("--hashlimit-burst 3"), "{}", s);
    assert!(s.contains("--hashlimit-name ssh-limit"), "{}", s);
    assert!(s.contains("--hashlimit-mode srcip"), "{}", s);
    assert!(s.contains("--hashlimit-htable-expire 60000"), "{}", s);
}

// ── policy tests ─────────────────────────────────────────────────────

// ── policy is refused: `meta secpath` is not a key we can encode ─────
// Up to 1.1.13 the clause was dropped on the way to the kernel and the
// rule installed its verdict alone, i.e. accepted or dropped every
// packet. The argv still parses (iptables-save round-trips the flags).
#[test]
fn iptables_policy_is_refused() {
    let refused: &[&[&str]] = &[
        &["-A", "INPUT", "-m", "policy", "--dir", "in", "--pol", "ipsec", "-j", "ACCEPT"],
        &["-A", "FORWARD", "-m", "policy", "--dir", "out", "--pol", "none", "-j", "DROP"],
        &["-A", "INPUT", "-m", "policy", "--dir", "in", "--pol", "ipsec",
          "--proto", "esp", "--mode", "tunnel", "--reqid", "42", "-j", "ACCEPT"],
        &["-A", "INPUT", "-m", "policy", "-j", "ACCEPT"],
    ];
    for args in refused {
        assert!(is_refused(Family::Ip, args), "installed {:?}", args);
    }
}

// ── policy_save_roundtrip: iptables-save reproduces the flags ────────
#[test]
fn iptables_policy_save_roundtrip() {
    let argv: Vec<String> = [
        "-A", "INPUT",
        "-m", "policy",
        "--dir", "in",
        "--pol", "ipsec",
        "--proto", "esp",
        "--mode", "tunnel",
        "--tunnel-src", "192.0.2.0/24",
        "--tunnel-dst", "198.51.100.1",
        "--strict",
        "-j", "ACCEPT",
    ].iter().map(|s| s.to_string()).collect();
    let cmd = parse(Family::Ip, &argv).unwrap().cmd;
    let s = render_rule_save(&cmd);
    assert!(s.contains("-m policy"), "{}", s);
    assert!(s.contains("--dir in"), "{}", s);
    assert!(s.contains("--pol ipsec"), "{}", s);
    assert!(s.contains("--proto esp"), "{}", s);
    assert!(s.contains("--mode tunnel"), "{}", s);
    assert!(s.contains("--tunnel-src 192.0.2.0/24"), "{}", s);
    assert!(s.contains("--tunnel-dst 198.51.100.1"), "{}", s);
    assert!(s.contains("--strict"), "{}", s);
}

// ── Mark round-trips: iptables argv → nft text → parser IR → netlink
//    attributes → `nft list` text ────────────────────────────────────
//
// 1.1.11 lowered `-m mark --mark V/M` to `meta mark & M == V`, which
// the nft parser read as `meta mark == 0x26` (the `&` byte), and
// `-j MARK --set-mark` to a meta set with no value source, so the
// kernel copied the iifname bytes from register 1 into the mark. The
// old tests only grepped the lowered text. These parse it, encode it
// and render the listing, and check the expressions the kernel gets.

use crate::parser::{CmdObj, Expr};
use crate::netlink::{NFT_META_MARK, NFT_META_L4PROTO, NFT_CT_MARK, NFT_REG_1, NFT_CMP_EQ, NFT_CMP_NEQ};

/// The expressions of the rule an iptables command installs, parsed
/// the way apply_cmd parses the lowered batch.
fn rule_exprs(family: Family, args: &[&str]) -> Vec<Expr> {
    let rule = last_rule(family, args);
    let cmds = crate::parser::parse(&rule).unwrap_or_else(|e| panic!("`{}`: {}", rule, e));
    if let Err(e) = super::check_fully_parsed(&cmds) {
        panic!("`{}`: {}: {:?}", rule, e, cmds.last().map(|c| &c.exprs));
    }
    let r = cmds.into_iter().filter(|c| matches!(c.obj, CmdObj::Rule)).last()
        .unwrap_or_else(|| panic!("no rule in `{}`", rule));
    r.exprs
}

/// `nft list` text for the rule an iptables command installs.
fn listed(family: Family, args: &[&str]) -> String {
    let attrs = crate::ops::encode_rule_exprs(&rule_exprs(family, args));
    crate::output::render_rule_text(&attrs)
}

fn ne(v: u32) -> Vec<u8> { v.to_ne_bytes().to_vec() }

#[test]
fn mark_set_with_mask_encodes_bitwise_on_the_mark() {
    // tailscale ts-forward: -i tailscale0 -j MARK --set-mark 0x40000/0xff0000
    let e = rule_exprs(Family::Ip, &[
        "-A", "ts-forward", "-i", "tailscale0",
        "-j", "MARK", "--set-mark", "0x40000/0xff0000",
    ]);
    let n = e.len();
    assert!(n >= 5, "{:?}", e);
    assert!(matches!(&e[n - 3], Expr::MetaReg { reg, key, .. } if *reg == NFT_REG_1 && *key == NFT_META_MARK), "{:?}", e);
    assert!(matches!(&e[n - 2], Expr::BitwiseReg { reg, mask, xor }
        if *reg == NFT_REG_1 && *mask == ne(0xff00ffff) && *xor == ne(0x00040000)), "{:?}", e);
    assert!(matches!(&e[n - 1], Expr::MetaSet { key } if *key == NFT_META_MARK), "{:?}", e);
}

#[test]
fn mark_match_with_mask_encodes_bitwise_and_cmp() {
    // tailscale ts-forward: -m mark --mark 0x40000/0xff0000 -j ACCEPT
    let e = rule_exprs(Family::Ip, &[
        "-A", "ts-forward", "-m", "mark", "--mark", "0x40000/0xff0000", "-j", "ACCEPT",
    ]);
    assert!(matches!(&e[0], Expr::Meta { key, width: 4 } if *key == NFT_META_MARK), "{:?}", e);
    assert!(matches!(&e[1], Expr::Bitwise { mask, xor } if *mask == ne(0x00ff0000) && *xor == ne(0)), "{:?}", e);
    assert!(matches!(&e[2], Expr::Cmp { op, data } if *op == NFT_CMP_EQ && *data == ne(0x00040000)), "{:?}", e);
    assert!(matches!(&e[3], Expr::Verdict { .. }), "{:?}", e);
    assert_eq!(e.len(), 4, "{:?}", e);
}

#[test]
fn connmark_match_and_set_encode_ct_mark() {
    let e = rule_exprs(Family::Ip, &[
        "-A", "INPUT", "-m", "connmark", "--mark", "0x40000/0xff0000", "-j", "ACCEPT",
    ]);
    assert!(matches!(&e[0], Expr::Ct { key, .. } if *key == NFT_CT_MARK), "{:?}", e);
    assert!(matches!(&e[1], Expr::Bitwise { mask, .. } if *mask == ne(0x00ff0000)), "{:?}", e);
    assert!(matches!(&e[2], Expr::Cmp { op, data } if *op == NFT_CMP_EQ && *data == ne(0x00040000)), "{:?}", e);

    let e = rule_exprs(Family::Ip, &[
        "-t", "mangle", "-A", "PREROUTING", "-j", "CONNMARK", "--set-mark", "0x10",
    ]);
    let n = e.len();
    assert!(matches!(&e[n - 2], Expr::Immediate { dreg, data } if *dreg == NFT_REG_1 && *data == ne(0x10)), "{:?}", e);
    assert!(matches!(&e[n - 1], Expr::CtSet { key } if *key == NFT_CT_MARK), "{:?}", e);
}

#[test]
fn tailscale_ruleset_lists_back_as_installed() {
    // Every rule tailscaled (firewallmode=ipt-default) installs, and
    // the listing real nft prints for it.
    let cases: &[(Family, &[&str], &str)] = &[
        (Family::Ip, &["-A", "ts-input", "-i", "lo", "-s", "100.108.18.1", "-j", "ACCEPT"],
            "ip saddr 100.108.18.1 iifname \"lo\" accept"),
        (Family::Ip, &["-A", "ts-input", "!", "-i", "tailscale0", "-s", "100.115.92.0/23", "-j", "RETURN"],
            "ip saddr 100.115.92.0/23 iifname != \"tailscale0\" return"),
        (Family::Ip, &["-A", "ts-input", "-i", "tailscale0", "-j", "ACCEPT"],
            "iifname \"tailscale0\" accept"),
        (Family::Ip, &["-A", "ts-forward", "-i", "tailscale0", "-j", "MARK", "--set-mark", "0x40000/0xff0000"],
            "iifname \"tailscale0\" meta mark set meta mark & 0xff04ffff | 0x00040000"),
        (Family::Ip, &["-A", "ts-forward", "-m", "mark", "--mark", "0x40000/0xff0000", "-j", "ACCEPT"],
            "meta mark & 0x00ff0000 == 0x00040000 accept"),
        (Family::Ip, &["-A", "ts-forward", "-o", "tailscale0", "-s", "100.64.0.0/10", "-j", "DROP"],
            "ip saddr 100.64.0.0/10 oifname \"tailscale0\" drop"),
        (Family::Ip, &["-A", "ts-forward", "-o", "tailscale0", "-j", "ACCEPT"],
            "oifname \"tailscale0\" accept"),
        (Family::Ip, &["-t", "nat", "-A", "ts-postrouting", "-m", "mark", "--mark", "0x40000/0xff0000", "-j", "MASQUERADE"],
            "meta mark & 0x00ff0000 == 0x00040000 masquerade"),
        (Family::Ip, &["-t", "mangle", "-I", "PREROUTING", "1", "-m", "conntrack", "--ctstate", "ESTABLISHED,RELATED",
                       "-j", "CONNMARK", "--restore-mark", "--nfmask", "0xff0000", "--ctmask", "0xff0000"],
            "ct state established,related meta mark set ct mark & 0x00ff0000"),
        (Family::Ip, &["-t", "mangle", "-I", "OUTPUT", "1", "-m", "conntrack", "--ctstate", "NEW",
                       "-m", "mark", "!", "--mark", "0x0/0xff0000",
                       "-j", "CONNMARK", "--save-mark", "--nfmask", "0xff0000", "--ctmask", "0xff0000"],
            "ct state new meta mark & 0x00ff0000 != 0x00000000 ct mark set meta mark & 0x00ff0000"),
        (Family::Ip6, &["-A", "ts-input", "-i", "lo", "-s", "fd7a:115c:a1e0::338:f6d", "-j", "ACCEPT"],
            "ip6 saddr fd7a:115c:a1e0::338:f6d iifname \"lo\" accept"),
        (Family::Ip6, &["-A", "ts-forward", "-i", "tailscale0", "-j", "MARK", "--set-mark", "0x40000/0xff0000"],
            "iifname \"tailscale0\" meta mark set meta mark & 0xff04ffff | 0x00040000"),
        (Family::Ip6, &["-t", "nat", "-A", "ts-postrouting", "-m", "mark", "--mark", "0x40000/0xff0000", "-j", "MASQUERADE"],
            "meta mark & 0x00ff0000 == 0x00040000 masquerade"),
    ];
    check_listings(cases.iter().map(|(f, a, w)| (*f, *a, *w)));
}

/// Compare every case and report all mismatches at once.
fn check_listings<'a>(cases: impl Iterator<Item = (Family, &'a [&'a str], &'a str)>) {
    let mut bad = Vec::new();
    for (family, args, want) in cases {
        let got = listed(family, args);
        if got != want {
            bad.push(format!("argv {:?}\n   got: {}\n  want: {}", args, got, want));
        }
    }
    assert!(bad.is_empty(), "{}", bad.join("\n"));
}

#[test]
fn cni_portmap_hairpin_marks_list_back() {
    // CNI portmap: mark hairpin traffic, masquerade what carries the bit.
    assert_eq!(listed(Family::Ip, &["-t", "nat", "-A", "CNI-HOSTPORT-SETMARK",
                                    "-j", "MARK", "--set-xmark", "0x2000/0x2000"]),
        "meta mark set meta mark | 0x00002000");
    assert_eq!(listed(Family::Ip, &["-t", "nat", "-A", "CNI-HOSTPORT-MASQ",
                                    "-m", "mark", "--mark", "0x2000/0x2000", "-j", "MASQUERADE"]),
        "meta mark & 0x00002000 == 0x00002000 masquerade");
}

#[test]
fn mark_target_variants_list_back() {
    let cases: &[(&[&str], &str)] = &[
        (&["-j", "MARK", "--set-mark", "0x1"], "meta mark set 0x00000001"),
        (&["-j", "MARK", "--set-mark", "0x1/0xffffffff"], "meta mark set 0x00000001"),
        (&["-j", "MARK", "--set-xmark", "0x1/0x3"], "meta mark set meta mark & 0xfffffffd | 0x00000001"),
        (&["-j", "MARK", "--set-xmark", "0x3/0x1"], "meta mark set meta mark ^ 0x00000002 | 0x00000001"),
        (&["-j", "MARK", "--and-mark", "0xff"], "meta mark set meta mark & 0x000000ff"),
        (&["-j", "MARK", "--or-mark", "0x10"], "meta mark set meta mark | 0x00000010"),
        (&["-j", "MARK", "--xor-mark", "0x10"], "meta mark set meta mark ^ 0x00000010"),
        (&["-j", "CONNMARK", "--set-mark", "0x10"], "ct mark set 0x00000010"),
        (&["-j", "CONNMARK", "--set-mark", "0x10/0xff"], "ct mark set ct mark & 0xffffff10 | 0x00000010"),
        (&["-j", "CONNMARK", "--set-xmark", "0x10/0xff"], "ct mark set ct mark & 0xffffff10 | 0x00000010"),
        (&["-j", "CONNMARK", "--or-mark", "0x10"], "ct mark set ct mark | 0x00000010"),
        (&["-j", "CONNMARK", "--restore-mark"], "meta mark set ct mark"),
        (&["-j", "CONNMARK", "--save-mark"], "ct mark set meta mark"),
        (&["-m", "mark", "--mark", "0x10"], "meta mark 0x00000010"),
        (&["-m", "mark", "!", "--mark", "0x10/0x10"], "meta mark & 0x00000010 != 0x00000010"),
        (&["-m", "connmark", "--mark", "0x10"], "ct mark 0x00000010"),
        (&["-m", "connmark", "!", "--mark", "0x1/0xf"], "ct mark & 0x0000000f != 0x00000001"),
    ];
    let argvs: Vec<(Vec<&str>, &str)> = cases.iter().map(|(tail, want)| {
        let mut argv = vec!["-t", "mangle", "-A", "PREROUTING"];
        argv.extend_from_slice(tail);
        (argv, *want)
    }).collect();
    check_listings(argvs.iter().map(|(a, w)| (Family::Ip, a.as_slice(), *w)));
}

#[test]
fn other_setters_carry_an_immediate() {
    // Same missing-immediate bug: TRACE, CLASSIFY and CT --zone.
    assert_eq!(listed(Family::Ip, &["-t", "raw", "-A", "PREROUTING", "-j", "TRACE"]),
        "meta nftrace set 1");
    assert_eq!(listed(Family::Ip, &["-t", "mangle", "-A", "POSTROUTING",
                                    "-j", "CLASSIFY", "--set-class", "1:2"]),
        "meta priority set 1:2");
    assert_eq!(listed(Family::Ip, &["-t", "raw", "-A", "PREROUTING",
                                    "-j", "CT", "--zone", "5"]),
        "ct zone set 5");
}

#[test]
fn ip6_prefix_match_keeps_the_prefix() {
    // `-s fd00::/8` used to install an exact match on fd00::.
    let e = rule_exprs(Family::Ip6, &["-A", "INPUT", "-s", "fd00::/8", "-j", "DROP"]);
    assert!(e.iter().any(|x| matches!(x, Expr::Bitwise { mask, .. } if mask.len() == 16 && mask[0] == 0xff && mask[1] == 0)),
        "{:?}", e);
    assert_eq!(listed(Family::Ip6, &["-A", "INPUT", "-s", "fd00::/8", "-j", "DROP"]),
        "ip6 saddr fd00::/8 drop");
    assert_eq!(listed(Family::Ip6, &["-A", "INPUT", "-d", "2001:db8::1/128", "-j", "ACCEPT"]),
        "ip6 daddr 2001:db8::1 accept");
}

#[test]
fn negated_mark_match_uses_neq() {
    let e = rule_exprs(Family::Ip, &[
        "-t", "mangle", "-A", "OUTPUT", "-m", "mark", "!", "--mark", "0x0/0xff0000", "-j", "ACCEPT",
    ]);
    assert!(matches!(&e[2], Expr::Cmp { op, data } if *op == NFT_CMP_NEQ && *data == ne(0)), "{:?}", e);
}

#[test]
fn batch_with_unencodable_tokens_is_refused() {
    // What 1.1.11 did with a masked mark match it could not parse:
    // skip the tokens and install `meta mark == <garbage>`.
    let cmds = crate::parser::parse("add rule ip filter c meta mark frobnicate 0x1 accept").unwrap();
    assert!(super::check_fully_parsed(&cmds).is_err());
    let cmds = crate::parser::parse("add rule ip filter c meta mark & 0xff0000 == 0x40000 accept").unwrap();
    assert!(super::check_fully_parsed(&cmds).is_ok());
}

// ── Protocol-only matches and tcp flags ─────────────────────────────
//
// `-p tcp` with no port lowers to `meta l4proto tcp`; up to this
// release the nft parser read that `tcp` as the start of a `tcp FIELD`
// match, which also swallowed the verdict, so `-p tcp -j DROP`
// installed a rule that did nothing. `--syn` and `--tcp-flags` lowered
// to `tcp flags & (fin|syn|rst|ack) == syn`, and the parser took
// `fin|syn|rst|ack` as one unknown word, so the mask was 0 and the
// rule could never match.

#[test]
fn protocol_only_rules_keep_protocol_and_verdict() {
    let e = rule_exprs(Family::Ip, &["-A", "INPUT", "-p", "tcp", "-j", "DROP"]);
    assert!(matches!(&e[1], Expr::Cmp { op, data } if *op == NFT_CMP_EQ && *data == vec![6u8]), "{:?}", e);
    assert!(matches!(e.last(), Some(Expr::Verdict { .. })), "{:?}", e);

    let cases: &[(&[&str], &str)] = &[
        (&["-A", "INPUT", "-p", "tcp", "-j", "ACCEPT"], "meta l4proto tcp accept"),
        (&["-A", "INPUT", "-p", "udp", "-j", "DROP"], "meta l4proto udp drop"),
        (&["-A", "INPUT", "-p", "icmp", "-j", "ACCEPT"], "meta l4proto icmp accept"),
        (&["-A", "INPUT", "-i", "eth0", "-p", "tcp", "-j", "ACCEPT"], "iifname \"eth0\" meta l4proto tcp accept"),
        (&["-A", "INPUT", "-p", "tcp", "-j", "REJECT", "--reject-with", "tcp-reset"],
            "meta l4proto tcp reject with tcp reset"),
        (&["-A", "INPUT", "-p", "tcp", "-m", "conntrack", "--ctstate", "NEW", "-j", "ACCEPT"],
            "meta l4proto tcp ct state new accept"),
        (&["-A", "INPUT", "-p", "tcp", "--syn", "-j", "DROP"],
            "tcp flags & (fin | syn | rst | ack) == syn drop"),
        (&["-A", "INPUT", "-p", "tcp", "--tcp-flags", "SYN,RST", "SYN", "-j", "DROP"],
            "tcp flags & (syn | rst) == syn drop"),
        (&["-A", "INPUT", "-p", "tcp", "--tcp-flags", "ALL", "NONE", "-j", "DROP"],
            "tcp flags & (fin | syn | rst | psh | ack | urg) == 0x0 drop"),
        (&["-A", "INPUT", "-p", "tcp", "!", "--tcp-flags", "SYN,ACK", "SYN,ACK", "-j", "DROP"],
            "tcp flags & (syn | ack) != syn | ack drop"),
        (&["-A", "INPUT", "-m", "mac", "--mac-source", "00:11:22:33:44:55", "-j", "ACCEPT"],
            "ether saddr 00:11:22:33:44:55 accept"),
    ];
    check_listings(cases.iter().map(|(a, w)| (Family::Ip, *a, *w)));

    let e = rule_exprs(Family::Ip, &["-t", "raw", "-A", "PREROUTING", "-p", "udp", "-j", "NOTRACK"]);
    assert!(matches!(&e[1], Expr::Cmp { data, .. } if *data == vec![17u8]), "{:?}", e);
    assert!(matches!(e.last(), Some(Expr::Notrack)), "{:?}", e);
    let e = rule_exprs(Family::Ip, &["-A", "INPUT", "-p", "gre", "-j", "ACCEPT"]);
    assert!(matches!(&e[1], Expr::Cmp { data, .. } if *data == vec![47u8]), "{:?}", e);
}

#[test]
fn syn_match_masks_the_flags_byte() {
    let e = rule_exprs(Family::Ip, &["-A", "INPUT", "-p", "tcp", "--syn", "-j", "DROP"]);
    let i = e.iter().position(|x| matches!(x, Expr::Bitwise { .. })).unwrap_or_else(|| panic!("{:?}", e));
    assert!(matches!(&e[i], Expr::Bitwise { mask, .. } if *mask == vec![0x17u8]), "{:?}", e);
    assert!(matches!(&e[i + 1], Expr::Cmp { op, data } if *op == NFT_CMP_EQ && *data == vec![0x02u8]), "{:?}", e);
    let e = rule_exprs(Family::Ip, &["-A", "INPUT", "-p", "tcp", "!", "--tcp-flags", "SYN,ACK", "SYN", "-j", "DROP"]);
    let i = e.iter().position(|x| matches!(x, Expr::Bitwise { .. })).unwrap_or_else(|| panic!("{:?}", e));
    assert!(matches!(&e[i], Expr::Bitwise { mask, .. } if *mask == vec![0x12u8]), "{:?}", e);
    assert!(matches!(&e[i + 1], Expr::Cmp { op, data } if *op == NFT_CMP_NEQ && *data == vec![0x02u8]), "{:?}", e);
}

#[test]
fn fragment_match_is_refused_not_dropped() {
    // `-f` lowers to `ip frag-off & 0x1fff != 0`, which the nft parser
    // cannot encode yet. 1.1.12 installed `-f -j DROP` as a bare `drop`
    // (every packet); refuse instead.
    let rule = last_rule(Family::Ip, &["-A", "INPUT", "-f", "-j", "DROP"]);
    let cmds = crate::parser::parse(&rule).unwrap();
    assert!(super::check_fully_parsed(&cmds).is_err(), "{}", rule);
}

// ── Negation ─────────────────────────────────────────────────────────
//
// `! --syn` used to drop its `!`: the `--syn` arm never took the
// pending negation, so `-p tcp ! --syn -j ACCEPT` accepted SYNs, and in
// `-p tcp ! --syn -m state --state NEW -j DROP` the `!` moved on to
// `--state`. With the flags mask fixed in this release both became
// live rules; `-m conntrack --ctstate NEW ! --syn -j DROP` dropped
// every new connection.

fn argv(args: &[&str]) -> Vec<String> { args.iter().map(|s| s.to_string()).collect() }

#[test]
fn negated_syn_keeps_its_negation_in_either_order() {
    let orders: &[&[&str]] = &[
        &["-A", "INPUT", "-p", "tcp", "-m", "conntrack", "--ctstate", "NEW", "!", "--syn", "-j", "DROP"],
        &["-A", "INPUT", "-p", "tcp", "!", "--syn", "-m", "state", "--state", "NEW", "-j", "DROP"],
        &["-A", "INPUT", "-p", "tcp", "!", "--syn", "-m", "conntrack", "--ctstate", "NEW", "-j", "DROP"],
    ];
    for args in orders {
        let c = parse(Family::Ip, &argv(args)).unwrap().cmd;
        assert!(c.spec.tcp_syn && c.spec.tcp_syn_neg, "{:?}: {:?}", args, c.spec);
        let st = c.spec.state.as_ref().unwrap();
        assert!(!st.neg, "{:?}: the ! moved onto the state match", args);
        assert_eq!(listed(Family::Ip, args),
            "tcp flags & (fin | syn | rst | ack) != syn ct state new drop", "{:?}", args);
    }
    let c = parse(Family::Ip, &argv(&["-A", "INPUT", "-p", "tcp", "--syn", "-j", "DROP"])).unwrap().cmd;
    assert!(c.spec.tcp_syn && !c.spec.tcp_syn_neg);
}

#[test]
fn negated_syn_encodes_neq_behind_the_tcp_dependency() {
    let e = rule_exprs(Family::Ip, &["-A", "INPUT", "-p", "tcp", "!", "--syn", "-j", "ACCEPT"]);
    // A `!=` on the flags byte without the l4proto test would also
    // match every udp and icmp packet.
    assert!(matches!(&e[0], Expr::Meta { key, .. } if *key == NFT_META_L4PROTO), "{:?}", e);
    assert!(matches!(&e[1], Expr::Cmp { op, data } if *op == NFT_CMP_EQ && *data == vec![6u8]), "{:?}", e);
    let i = e.iter().position(|x| matches!(x, Expr::Bitwise { .. })).unwrap_or_else(|| panic!("{:?}", e));
    assert!(matches!(&e[i], Expr::Bitwise { mask, .. } if *mask == vec![0x17u8]), "{:?}", e);
    assert!(matches!(&e[i + 1], Expr::Cmp { op, data } if *op == NFT_CMP_NEQ && *data == vec![0x02u8]), "{:?}", e);
    assert!(matches!(e.last(), Some(Expr::Verdict { .. })), "{:?}", e);
    assert_eq!(listed(Family::Ip, &["-A", "INPUT", "-p", "tcp", "!", "--syn", "-j", "ACCEPT"]),
        "tcp flags & (fin | syn | rst | ack) != syn accept");
}

#[test]
fn negated_syn_and_flags_survive_iptables_save() {
    for args in [
        &["-A", "INPUT", "-p", "tcp", "!", "--syn", "-j", "DROP"][..],
        &["-A", "INPUT", "-p", "tcp", "!", "--tcp-flags", "SYN,ACK", "SYN", "-j", "DROP"][..],
        &["-A", "INPUT", "-p", "tcp", "!", "--dport", "22", "-j", "DROP"][..],
        &["-A", "INPUT", "-m", "conntrack", "!", "--ctstate", "NEW", "-j", "DROP"][..],
        &["-A", "INPUT", "-m", "addrtype", "!", "--src-type", "LOCAL", "-j", "DROP"][..],
    ] {
        let c = parse(Family::Ip, &argv(args)).unwrap().cmd;
        let line = render_rule_save(&c);
        assert!(line.contains(" ! "), "{:?} rendered without its !: {}", args, line);
        let back: Vec<String> = line.split_whitespace().map(|s| s.to_string()).collect();
        let c2 = parse(Family::Ip, &back).unwrap_or_else(|e| panic!("{}: {}", line, e)).cmd;
        assert_eq!(c.spec, c2.spec, "{}", line);
    }
}

#[test]
fn addrtype_negation_encodes_neq() {
    let e = rule_exprs(Family::Ip, &["-A", "INPUT", "-m", "addrtype", "!", "--src-type", "LOCAL", "-j", "RETURN"]);
    assert!(matches!(&e[0], Expr::Fib { .. }), "{:?}", e);
    assert!(matches!(&e[1], Expr::Cmp { op, data } if *op == NFT_CMP_NEQ && *data == 2u32.to_le_bytes().to_vec()), "{:?}", e);
    assert_eq!(listed(Family::Ip, &["-A", "INPUT", "-m", "addrtype", "!", "--src-type", "LOCAL", "-j", "RETURN"]),
        "fib saddr type != local return");
    assert_eq!(listed(Family::Ip, &["-t", "nat", "-A", "PREROUTING", "-m", "addrtype", "--dst-type", "LOCAL", "-j", "ACCEPT"]),
        "fib daddr type local accept");
}

#[test]
fn a_bang_no_flag_takes_is_refused() {
    let refused: &[&[&str]] = &[
        // Flags that cannot be inverted, in the modern and legacy forms.
        &["-A", "INPUT", "!", "--limit", "5/s", "-j", "ACCEPT"],
        &["-A", "INPUT", "-m", "limit", "--limit", "!", "5/s", "-j", "ACCEPT"],
        &["-A", "INPUT", "-m", "owner", "!", "--uid-owner", "0", "-j", "ACCEPT"],
        &["-A", "INPUT", "-m", "physdev", "!", "--physdev-is-bridged", "-j", "ACCEPT"],
        &["-A", "INPUT", "-m", "statistic", "--mode", "random", "!", "--probability", "0.5", "-j", "DROP"],
        &["-A", "INPUT", "!", "-j", "DROP"],
        &["-A", "INPUT", "-j", "DROP", "!"],
        &["!", "-A", "INPUT", "-j", "DROP"],
        &["-A", "INPUT", "!", "!", "-s", "10.0.0.1", "-j", "DROP"],
        &["-A", "INPUT", "!", "-s", "!", "10.0.0.1", "-j", "DROP"],
    ];
    for args in refused {
        assert!(parse(Family::Ip, &argv(args)).is_err(), "accepted {:?}", args);
    }
    // Owner names and ranges used to parse as id 0 (root).
    assert!(parse(Family::Ip, &argv(&["-A", "OUTPUT", "-m", "owner", "--uid-owner", "tor", "-j", "ACCEPT"])).is_err());
    assert!(parse(Family::Ip, &argv(&["-A", "OUTPUT", "-m", "owner", "--gid-owner", "100-200", "-j", "ACCEPT"])).is_err());
    let e = rule_exprs(Family::Ip, &["-A", "OUTPUT", "-m", "owner", "--uid-owner", "1000", "-j", "ACCEPT"]);
    assert!(e.iter().any(|x| matches!(x, Expr::Cmp { op, data } if *op == NFT_CMP_EQ && *data == ne(1000))), "{:?}", e);
    let e = parse(Family::Ip, &argv(&["-A", "INPUT", "!", "--limit", "5/s", "-j", "ACCEPT"])).err().unwrap();
    assert!(e.0.contains("--limit"), "{}", e.0);

    // The forms iptables accepts still parse, and keep their negation.
    let ok: &[&[&str]] = &[
        &["-A", "INPUT", "!", "-s", "10.0.0.0/8", "-j", "DROP"],
        &["-A", "INPUT", "-s", "!", "10.0.0.0/8", "-j", "DROP"],
        &["-A", "INPUT", "-p", "tcp", "--dport", "!", "22", "-j", "DROP"],
        &["-A", "INPUT", "-m", "mark", "!", "--mark", "0x1", "-j", "DROP"],
        &["-A", "INPUT", "!", "-i", "lo", "-m", "conntrack", "!", "--ctstate", "NEW", "-j", "DROP"],
    ];
    for args in ok {
        parse(Family::Ip, &argv(args)).unwrap_or_else(|e| panic!("{:?}: {}", args, e.0));
    }
    let c = parse(Family::Ip, &argv(&["-A", "INPUT", "-s", "!", "10.0.0.0/8", "-p", "tcp", "--dport", "22", "-j", "DROP"])).unwrap().cmd;
    assert!(c.spec.src.as_ref().unwrap().neg && !c.spec.dport_neg, "{:?}", c.spec);
}

// ── LOG and NFLOG ────────────────────────────────────────────────────
//
// The nft parser read `log` with a prefix only, so the `level` of
// `-j LOG --log-level N` and the `group` of `-j NFLOG` were unencodable
// tokens and the whole command was refused. 1.1.12 installed them with
// the level dropped, named levels read as 0, `--log-uid` turned into a
// rule comment, and NFLOG as a syslog `log` rule unless a group was
// given. These go through parse, encode and listing like the mark cases.

#[test]
fn log_and_nflog_list_back_as_installed() {
    let cases: &[(Family, &[&str], &str)] = &[
        (Family::Ip, &["-A", "INPUT", "-j", "LOG"], "log"),
        (Family::Ip, &["-A", "INPUT", "-j", "LOG", "--log-level", "4"], "log"),
        (Family::Ip, &["-A", "INPUT", "-j", "LOG", "--log-level", "warning"], "log"),
        (Family::Ip, &["-A", "INPUT", "-j", "LOG", "--log-prefix", "IN ", "--log-level", "info"],
            "log prefix \"IN \" level info"),
        (Family::Ip, &["-A", "INPUT", "-m", "limit", "--limit", "5/min", "-j", "LOG",
                       "--log-prefix", "iptables denied: ", "--log-level", "7"],
            "limit rate 5/minute burst 5 packets log prefix \"iptables denied: \" level debug"),
        (Family::Ip6, &["-A", "INPUT", "-j", "LOG", "--log-prefix", "v6 ", "--log-level", "6"],
            "log prefix \"v6 \" level info"),
        (Family::Ip, &["-A", "INPUT", "-j", "LOG", "--log-level", "0"], "log level emerg"),
        (Family::Ip, &["-A", "INPUT", "-j", "LOG", "--log-level", "err"], "log level err"),
        (Family::Ip, &["-A", "INPUT", "-j", "LOG", "--log-level", "NOTICE"], "log level notice"),
        (Family::Ip, &["-A", "INPUT", "-j", "LOG", "--log-level", "crit", "--log-prefix", "X"],
            "log prefix \"X\" level crit"),
        (Family::Ip, &["-A", "INPUT", "-j", "LOG", "--log-uid"], "log flags skuid"),
        (Family::Ip, &["-A", "INPUT", "-j", "LOG", "--log-tcp-sequence", "--log-tcp-options"],
            "log flags tcp sequence,options"),
        (Family::Ip, &["-A", "INPUT", "-j", "LOG", "--log-tcp-options", "--log-ip-options"],
            "log flags tcp options flags ip options"),
        (Family::Ip, &["-A", "INPUT", "-j", "LOG", "--log-macdecode", "--log-level", "1"],
            "log level alert flags ether"),
        (Family::Ip, &["-A", "INPUT", "-j", "LOG", "--log-tcp-sequence", "--log-tcp-options",
                       "--log-ip-options", "--log-uid", "--log-macdecode"], "log flags all"),
        (Family::Ip, &["-A", "INPUT", "-j", "NFLOG"], "log group 0"),
        (Family::Ip, &["-A", "INPUT", "-j", "NFLOG", "--nflog-group", "5"], "log group 5"),
        (Family::Ip, &["-A", "INPUT", "-j", "NFLOG", "--nflog-prefix", "x"], "log prefix \"x\" group 0"),
        (Family::Ip, &["-A", "INPUT", "-j", "NFLOG", "--nflog-threshold", "1"], "log group 0"),
        (Family::Ip, &["-A", "INPUT", "-j", "NFLOG", "--nflog-group", "65535", "--nflog-prefix", "ulog: ",
                       "--nflog-size", "128", "--nflog-threshold", "10"],
            "log prefix \"ulog: \" group 65535 snaplen 128 queue-threshold 10"),
        (Family::Ip6, &["-A", "INPUT", "-p", "tcp", "--dport", "22", "-j", "NFLOG", "--nflog-group", "3"],
            "tcp dport 22 log group 3"),
    ];
    check_listings(cases.iter().map(|(f, a, w)| (*f, *a, *w)));
}

#[test]
fn log_level_and_group_reach_the_expression() {
    let e = rule_exprs(Family::Ip, &["-A", "INPUT", "-j", "LOG", "--log-prefix", "IN ", "--log-level", "info"]);
    assert!(matches!(e.last(), Some(Expr::Log { prefix, group: None, level: Some(6), flags: 0, .. })
        if prefix == "IN "), "{:?}", e);
    let e = rule_exprs(Family::Ip, &["-A", "INPUT", "-j", "LOG", "--log-uid", "--log-ip-options"]);
    assert!(matches!(e.last(), Some(Expr::Log { level: None, flags: 0x0c, .. })), "{:?}", e);
    let e = rule_exprs(Family::Ip, &["-A", "INPUT", "-j", "NFLOG", "--nflog-group", "5", "--nflog-size", "64"]);
    assert!(matches!(e.last(), Some(Expr::Log { group: Some(5), snaplen: Some(64), level: None, flags: 0, .. })),
        "{:?}", e);
    // A LOG rule is a verdict-less statement: nothing else is emitted.
    assert_eq!(e.len(), 1, "{:?}", e);
}

#[test]
fn log_options_iptables_refuses_are_refused() {
    let refused: &[&[&str]] = &[
        &["-A", "INPUT", "-j", "LOG", "--log-level", "8"],
        &["-A", "INPUT", "-j", "LOG", "--log-level", "loud"],
        &["-A", "INPUT", "-j", "LOG", "--log-level", "e"],        // emerg or error
        &["-A", "INPUT", "-j", "NFLOG", "--nflog-group", "65536"],
        &["-A", "INPUT", "-j", "NFLOG", "--nflog-group", "x"],
        &["-A", "INPUT", "-j", "NFLOG", "--nflog-threshold", "-1"],
        &["-A", "INPUT", "-j", "LOG", "!", "--log-level", "4"],
    ];
    for args in refused {
        assert!(parse(Family::Ip, &argv(args)).is_err(), "accepted {:?}", args);
    }
    let e = parse(Family::Ip, &argv(&["-A", "INPUT", "-j", "LOG", "--log-level", "e"])).err().unwrap();
    assert!(e.0.contains("ambiguous"), "{}", e.0);
    // Prefixes of one name, any case, are what iptables takes.
    for (lv, want) in [("warn", 4u8), ("INFO", 6), ("panic", 0), ("deb", 7), ("n", 5)] {
        let c = parse(Family::Ip, &argv(&["-A", "INPUT", "-j", "LOG", "--log-level", lv])).unwrap().cmd;
        assert!(matches!(c.spec.target, Some(Target::Log { level: Some(l), .. }) if l == want), "{}: {:?}", lv, c.spec.target);
    }
    // --nflog-range is taken and ignored, with a warning.
    assert_eq!(listed(Family::Ip, &["-A", "INPUT", "-j", "NFLOG", "--nflog-range", "256"]), "log group 0");
}

#[test]
fn log_and_nflog_survive_iptables_save() {
    for args in [
        &["-A", "INPUT", "-j", "LOG", "--log-prefix", "IN ", "--log-level", "6", "--log-uid", "--log-macdecode"][..],
        &["-A", "INPUT", "-j", "NFLOG", "--nflog-group", "5", "--nflog-prefix", "x", "--nflog-size", "64",
          "--nflog-threshold", "10"][..],
    ] {
        let c = parse(Family::Ip, &argv(args)).unwrap().cmd;
        let line = render_rule_save(&c);
        let again = parse(Family::Ip, &super::save::split_quoted(&line).unwrap())
            .unwrap_or_else(|e| panic!("{}: {}", line, e)).cmd;
        assert_eq!(c.spec, again.spec, "{}", line);
    }
}

#[test]
fn nft_log_statement_takes_nft_arguments() {
    use crate::netlink::{NF_LOG_TCPSEQ, NF_LOG_TCPOPT, NF_LOG_IPOPT, NF_LOG_UID, NF_LOG_MACDECODE};
    let one = |text: &str| -> Result<Expr, String> {
        let cmds = crate::parser::parse(&format!("add rule ip filter input {}", text))?;
        super::check_fully_parsed(&cmds)?;
        Ok(cmds.last().unwrap().exprs.iter().find(|e| matches!(e, Expr::Log { .. })).unwrap().clone())
    };
    let e = one("log prefix \"a\" level debug flags tcp sequence,options flags ip options flags skuid flags ether accept").unwrap();
    assert!(matches!(&e, Expr::Log { level: Some(7), flags, group: None, .. }
        if *flags == NF_LOG_TCPSEQ | NF_LOG_TCPOPT | NF_LOG_IPOPT | NF_LOG_UID | NF_LOG_MACDECODE), "{:?}", e);
    let e = one("log group 2 snaplen 100 queue-threshold 7 prefix \"p\" drop").unwrap();
    assert!(matches!(&e, Expr::Log { group: Some(2), snaplen: Some(100), qthreshold: Some(7), level: None, .. }), "{:?}", e);
    let e = one("log level audit").unwrap();
    assert!(matches!(&e, Expr::Log { level: Some(8), .. }), "{:?}", e);
    // nft 1.0.9 takes a snaplen without a group (and sends none).
    let e = one("log snaplen 64").unwrap();
    assert!(matches!(&e, Expr::Log { group: None, snaplen: Some(64), .. }), "{:?}", e);
    // nft's own checks.
    for (text, msg) in [
        ("log level info group 1", "level and group are mutually exclusive"),
        ("log group 1 flags skuid", "flags and group are mutually exclusive"),
        ("log level loud", "invalid log level"),
        ("log group 70000", "invalid log group"),
        ("log level audit prefix \"x\"", "log level audit doesn't support any further options"),
    ] {
        let r = one(text);
        assert!(matches!(&r, Err(m) if m.contains(msg)), "{}: {:?}", text, r);
    }
}

// ── NAT addresses the nft parser cannot encode ──────────────────────
//
// `dnat to`/`snat to` took the text up to the first `:` as an IPv4
// address and the rest as the port, so `ip6tables -j DNAT
// --to-destination fd00::2` and `-j SNAT --to-source 2001:db8::1`
// installed `dnat to :0` / `snat to :0`. They are refused now.

#[test]
fn nat_to_ipv6_or_port_range_is_refused() {
    let refused: &[(Family, &[&str])] = &[
        (Family::Ip6, &["-t", "nat", "-A", "PREROUTING", "-p", "tcp", "--dport", "80",
                        "-j", "DNAT", "--to-destination", "fd00::2"]),
        (Family::Ip6, &["-t", "nat", "-A", "POSTROUTING", "-o", "eth0", "-j", "SNAT", "--to-source", "2001:db8::1"]),
        (Family::Ip6, &["-t", "nat", "-A", "PREROUTING", "-p", "tcp", "--dport", "80",
                        "-j", "DNAT", "--to-destination", "[fd00::2]:8080"]),
        (Family::Ip, &["-t", "nat", "-A", "PREROUTING", "-p", "tcp", "--dport", "80",
                       "-j", "DNAT", "--to-destination", "10.0.0.2:8080-8090"]),
        (Family::Ip, &["-t", "nat", "-A", "POSTROUTING", "-j", "SNAT", "--to-source", "1.2.3.4:1024-2048"]),
        (Family::Ip, &["-t", "nat", "-A", "PREROUTING", "-p", "tcp", "--dport", "80",
                       "-j", "DNAT", "--to-destination", "example.org"]),
    ];
    for (family, args) in refused {
        assert!(is_refused(*family, args), "installed {:?}", args);
    }
    let cases: &[(Family, &[&str], &str)] = &[
        (Family::Ip, &["-t", "nat", "-A", "PREROUTING", "-p", "tcp", "--dport", "80",
                       "-j", "DNAT", "--to-destination", "10.0.0.2:8080"], "tcp dport 80 dnat to 10.0.0.2:8080"),
        (Family::Ip, &["-t", "nat", "-A", "POSTROUTING", "-o", "eth0", "-j", "SNAT", "--to-source", "1.2.3.4-1.2.3.10"],
            "oifname \"eth0\" snat to 1.2.3.4-1.2.3.10"),
        (Family::Ip, &["-t", "nat", "-A", "PREROUTING", "-p", "tcp", "--dport", "80",
                       "-j", "DNAT", "--to-destination", ":8080"], "tcp dport 80 dnat to :8080"),
    ];
    check_listings(cases.iter().map(|(f, a, w)| (*f, *a, *w)));
    // `snat ip to` (inet tables) names the family instead of swallowing it.
    let cmds = crate::parser::parse("add rule inet nat postrouting snat ip to 1.2.3.4").unwrap();
    super::check_fully_parsed(&cmds).unwrap();
    assert!(cmds.last().unwrap().exprs.iter().any(|e| matches!(e,
        Expr::Nat { family, has_addr: true, .. } if *family == crate::netlink::NFPROTO_IPV4)), "{:?}", cmds.last().unwrap().exprs);
}

// ── 1.1.14: a match that lowers to nothing is refused ────────────────
//
// Up to 1.1.13 the refusal only fired when the lowered nft *text*
// carried a token the nft parser could not read. A match module that
// contributed no clause at all — or only a comment — slipped through
// and installed the verdict on its own, so `ip6tables -A C -m hbh
// -j DROP` exited 0 and dropped every packet.

#[test]
fn bare_match_module_is_refused() {
    // The optionless form of every `-m <name>` stormwall recognises,
    // plus the ones it only knows as a marker.
    let names = [
        "esp", "ah", "frag", "hbh", "dst", "mh", "rt", "ipv6header",
        "physdev", "socket", "time", "pkttype", "string", "policy",
        "mark", "connmark", "conntrack", "state", "limit", "multiport",
        "tcp", "udp", "addrtype", "owner", "set", "mac", "iprange",
        "length", "tcpmss", "tos", "dscp", "ttl", "hl", "statistic",
        "connlimit", "helper", "rpfilter", "recent", "connbytes",
        "hashlimit", "comment",
        "u32", "cluster", "quota", "nfacct", "bpf", "cgroup", "devgroup",
        "osf", "realm", "ipvs", "ecn", "connlabel", "rateest", "srh",
        "eui64", "cpu", "sctp", "dccp",
    ];
    for n in names {
        let args = ["-A", "INPUT", "-m", n, "-j", "DROP"];
        assert!(is_refused(Family::Ip, &args), "bare -m {} installed a rule", n);
    }
}

#[test]
fn comment_only_match_module_is_refused() {
    // Options that lowered to a comment marker and nothing else.
    let refused: &[(Family, &[&str])] = &[
        (Family::Ip6, &["-A", "INPUT", "-m", "hbh", "--hbh-opts", "5", "-j", "DROP"]),
        (Family::Ip6, &["-A", "INPUT", "-m", "dst", "--dst-opts", "5", "-j", "DROP"]),
        (Family::Ip6, &["-A", "INPUT", "-m", "frag", "--fraglast", "-j", "DROP"]),
        (Family::Ip6, &["-A", "INPUT", "-m", "frag", "--fragres", "-j", "DROP"]),
        (Family::Ip6, &["-A", "INPUT", "-m", "rt", "--rt-0-res", "-j", "DROP"]),
        (Family::Ip6, &["-A", "INPUT", "-m", "ipv6header", "--soft", "-j", "DROP"]),
        (Family::Ip, &["-A", "INPUT", "-m", "string", "--string", "abc", "--algo", "bm", "-j", "DROP"]),
    ];
    for (family, args) in refused {
        assert!(is_refused(*family, args), "installed {:?}", args);
    }
}

#[test]
fn unencodable_match_module_is_refused() {
    // Modules that did lower to a clause, but to one the nft parser
    // read as something else (or dropped), so the rule matched
    // everything: `-m physdev --physdev-in eth0 -j DROP` installed a
    // bare drop and `--physdev-is-bridged` a `meta length != 0`.
    let refused: &[(Family, &[&str])] = &[
        (Family::Ip, &["-A", "INPUT", "-m", "physdev", "--physdev-in", "eth0", "-j", "DROP"]),
        (Family::Ip, &["-A", "FORWARD", "-m", "physdev", "--physdev-out", "eth0", "-j", "DROP"]),
        (Family::Ip, &["-A", "FORWARD", "-m", "physdev", "--physdev-is-bridged", "-j", "DROP"]),
        (Family::Ip, &["-A", "INPUT", "-m", "policy", "--dir", "in", "--pol", "ipsec", "-j", "ACCEPT"]),
        (Family::Ip, &["-A", "INPUT", "-m", "time", "--timestart", "10:00", "-j", "ACCEPT"]),
        (Family::Ip6, &["-A", "INPUT", "-m", "rt", "--rt-type", "0", "-j", "DROP"]),
        (Family::Ip, &["-A", "FORWARD", "-m", "connbytes", "--connbytes", "100",
                       "--connbytes-mode", "packets", "-j", "DROP"]),
    ];
    for (family, args) in refused {
        assert!(is_refused(*family, args), "installed {:?}", args);
    }
}

#[test]
fn unknown_meta_and_ct_keys_are_refused() {
    // The native nft front-end had the mirror hole: an unknown key fell
    // through to NFT_META_LEN / NFT_CT_STATE, so the rule installed a
    // test on the wrong field or none at all.
    for text in [
        "add rule ip t c meta ibrname \"eth0\" drop",
        "add rule ip t c meta obrname \"br0\" drop",
        "add rule ip t c meta secpath exists accept",
        "add rule ip t c ct count over 10 drop",
        "add rule ip6 t c rt type 0 drop",
        "add rule ip t c socket bogus 1 accept",
    ] {
        let cmds = crate::parser::parse(text).unwrap();
        assert!(super::check_fully_parsed(&cmds).is_err(), "accepted `{}`", text);
    }
    // The keys that do have an id still parse.
    for text in [
        "add rule ip t c meta mark 0x40 drop",
        "add rule ip t c meta pkttype broadcast drop",
        "add rule ip t c ct packets 100 drop",
        "add rule ip t c ct avgpkt 100 drop",
        "add rule ip t c socket transparent 1 accept",
    ] {
        let cmds = crate::parser::parse(text).unwrap();
        super::check_fully_parsed(&cmds).unwrap_or_else(|e| panic!("refused `{}`: {}", text, e));
    }
}

#[test]
fn pkttype_compares_the_kernel_byte() {
    // `meta pkttype broadcast` is a one-byte PACKET_* code; comparing
    // the name's ASCII against it never matched.
    for (name, code) in [("unicast", 0u8), ("broadcast", 1), ("multicast", 2)] {
        let rule = last_rule(Family::Ip, &[
            "-A", "INPUT", "-m", "pkttype", "--pkt-type", name, "-j", "DROP",
        ]);
        assert!(rule.contains(&format!("meta pkttype {}", name)), "rule: {}", rule);
        let cmds = crate::parser::parse(&rule).unwrap();
        super::check_fully_parsed(&cmds).unwrap();
        assert!(cmds.last().unwrap().exprs.iter().any(|e|
            matches!(e, Expr::Cmp { data, .. } if data.as_slice() == [code])),
            "{}: {:?}", name, cmds.last().unwrap().exprs);
    }
}

#[test]
fn nat_port_needs_a_transport_match() {
    // Real iptables: "Need TCP, UDP, SCTP or DCCP with port
    // specification". Without one the rule port-maps ICMP too.
    let refused: &[&[&str]] = &[
        &["-t", "nat", "-A", "PREROUTING", "-j", "DNAT", "--to-destination", "10.0.0.5:8080"],
        &["-t", "nat", "-A", "POSTROUTING", "-j", "SNAT", "--to-source", "10.0.0.5:8080"],
        &["-t", "nat", "-A", "PREROUTING", "-p", "icmp", "-j", "DNAT", "--to-destination", "10.0.0.5:8080"],
    ];
    for args in refused {
        assert!(is_refused(Family::Ip, args), "installed {:?}", args);
    }
    // With a transport match it installs, and a plain address needs none.
    let rule = last_rule(Family::Ip, &["-t", "nat", "-A", "PREROUTING", "-p", "tcp",
                                       "-j", "DNAT", "--to-destination", "10.0.0.5:8080"]);
    assert!(rule.ends_with("dnat to 10.0.0.5:8080"), "rule: {}", rule);
    let rule = last_rule(Family::Ip, &["-t", "nat", "-A", "PREROUTING",
                                       "-j", "DNAT", "--to-destination", "10.0.0.5"]);
    assert!(rule.ends_with("dnat to 10.0.0.5"), "rule: {}", rule);
}

#[test]
fn notrack_is_raw_table_only() {
    assert!(is_refused(Family::Ip, &["-t", "filter", "-A", "INPUT", "-p", "udp", "-j", "NOTRACK"]));
    assert!(is_refused(Family::Ip, &["-t", "mangle", "-A", "PREROUTING", "-j", "NOTRACK"]));
    let rule = last_rule(Family::Ip, &["-t", "raw", "-A", "PREROUTING", "-p", "udp", "-j", "NOTRACK"]);
    assert!(rule.ends_with("notrack"), "rule: {}", rule);
}

#[test]
fn matches_that_still_install() {
    // The guard must not touch a module that does lower to a clause.
    let cases: &[(Family, &[&str], &str)] = &[
        (Family::Ip, &["-A", "INPUT", "-m", "comment", "--comment", "hi", "-j", "ACCEPT"],
            "comment \"hi\""),
        (Family::Ip, &["-A", "INPUT", "-m", "conntrack", "--ctstate", "NEW", "-j", "ACCEPT"],
            "ct state new"),
        (Family::Ip, &["-A", "INPUT", "-m", "state", "--state", "ESTABLISHED", "-j", "ACCEPT"],
            "ct state established"),
        (Family::Ip, &["-A", "INPUT", "-m", "limit", "--limit", "5/min", "-j", "ACCEPT"],
            "limit rate 5/minute"),
        (Family::Ip, &["-A", "INPUT", "-p", "tcp", "-m", "tcp", "--dport", "22", "-j", "ACCEPT"],
            "tcp dport 22"),
        (Family::Ip, &["-A", "INPUT", "-p", "tcp", "-m", "multiport", "--dports", "80,443", "-j", "ACCEPT"],
            "tcp dport { 80, 443 }"),
        (Family::Ip, &["-A", "INPUT", "-m", "mark", "--mark", "0x40000/0xff0000", "-j", "ACCEPT"],
            "meta mark & 0xff0000 == 0x40000"),
        (Family::Ip, &["-A", "INPUT", "-m", "addrtype", "--dst-type", "LOCAL", "-j", "ACCEPT"],
            "fib daddr type local"),
        (Family::Ip, &["-A", "INPUT", "-m", "mac", "--mac-source", "00:11:22:33:44:55", "-j", "DROP"],
            "ether saddr 00:11:22:33:44:55"),
        (Family::Ip, &["-A", "INPUT", "-m", "length", "--length", "100", "-j", "DROP"],
            "meta length 100"),
        (Family::Ip, &["-A", "INPUT", "-m", "time", "--timestart", "10:00", "--timestop", "12:00", "-j", "ACCEPT"],
            "meta hour"),
        (Family::Ip, &["-A", "INPUT", "-m", "iprange", "--src-range", "10.0.0.1-10.0.0.9", "-j", "DROP"],
            "ip saddr 10.0.0.1-10.0.0.9"),
        (Family::Ip, &["-A", "OUTPUT", "-m", "owner", "--uid-owner", "1000", "-j", "ACCEPT"],
            "meta skuid 1000"),
        (Family::Ip6, &["-A", "INPUT", "-m", "ipv6header", "--header", "hop-by-hop", "-j", "DROP"],
            "ip6 nexthdr 0"),
    ];
    for (family, args, want) in cases {
        let rule = last_rule(*family, args);
        assert!(rule.contains(want), "argv {:?}\n   got: {}\n  want: {}", args, rule, want);
        let cmds = crate::parser::parse(&rule).unwrap();
        super::check_fully_parsed(&cmds)
            .unwrap_or_else(|e| panic!("argv {:?} lowered to unencodable `{}`: {}", args, rule, e));
    }
}

// ── 1.1.15: names stormwall cannot encode are refused ────────────────

#[test]
fn unknown_ctstate_names_are_refused() {
    // 1.1.14 installed the ASCII bytes of the name as the state
    // bitmask: `--ctstate BOGUS` became `ct state established,untracked`
    // — an ACCEPT of traffic the admin never named.
    for args in [
        vec!["-A", "INPUT", "-m", "conntrack", "--ctstate", "BOGUS", "-j", "ACCEPT"],
        vec!["-A", "INPUT", "-m", "state", "--state", "BOGUS", "-j", "ACCEPT"],
        vec!["-A", "INPUT", "-m", "conntrack", "--ctstate", "NEW,BOGUS", "-j", "ACCEPT"],
        vec!["-A", "INPUT", "-m", "conntrack", "--ctstate", "", "-j", "ACCEPT"],
    ] {
        assert!(is_refused(Family::Ip, &args), "accepted {:?}", args);
    }
    // iptables' own wording, so a script that greps for it still works.
    let argv: Vec<String> = ["-A", "INPUT", "-m", "conntrack", "--ctstate", "BOGUS",
        "-j", "ACCEPT"].iter().map(|s| s.to_string()).collect();
    let e = match parse(Family::Ip, &argv) { Err(e) => e.to_string(), Ok(_) => panic!("accepted") };
    assert!(e.contains("Bad ctstate \"BOGUS\""), "message: {}", e);
    let argv: Vec<String> = ["-A", "INPUT", "-m", "state", "--state", "BOGUS",
        "-j", "ACCEPT"].iter().map(|s| s.to_string()).collect();
    let e = match parse(Family::Ip, &argv) { Err(e) => e.to_string(), Ok(_) => panic!("accepted") };
    assert!(e.contains("Bad state \"BOGUS\""), "message: {}", e);
}

#[test]
fn ctstate_dnat_snat_are_refused_not_dropped() {
    // Real iptables lowers these to `ct status dnat|snat`. stormwall
    // has no `ct status` matcher: 1.1.14 turned `DNAT,SNAT` into
    // `ct state 0x0` (a rule that matched nothing) and quietly dropped
    // the DNAT element out of `RELATED,ESTABLISHED,DNAT`.
    for names in ["DNAT", "SNAT", "DNAT,SNAT", "RELATED,ESTABLISHED,DNAT"] {
        assert!(is_refused(Family::Ip, &[
            "-A", "INPUT", "-m", "conntrack", "--ctstate", names, "-j", "ACCEPT",
        ]), "accepted --ctstate {}", names);
    }
    // The states stormwall does encode still install, and a lowercase
    // spelling round-trips uppercase the way iptables-save prints it.
    let rule = last_rule(Family::Ip, &[
        "-A", "FORWARD", "-m", "conntrack", "--ctstate", "related,established",
        "-j", "ACCEPT",
    ]);
    assert!(rule.contains("ct state { related, established }"), "rule: {}", rule);
    let argv: Vec<String> = ["-A", "FORWARD", "-m", "conntrack", "--ctstate",
        "related,established", "-j", "ACCEPT"].iter().map(|s| s.to_string()).collect();
    let cmd = parse(Family::Ip, &argv).unwrap().cmd;
    assert_eq!(cmd.spec.state.unwrap().names, vec!["RELATED", "ESTABLISHED"]);
}

#[test]
fn nft_ct_state_refuses_an_unknown_name() {
    for text in [
        "add rule ip t c ct state bogus accept",
        "add rule ip t c ct state dnat accept",
        "add rule ip t c ct state { established, dnat } accept",
    ] {
        // `ct state dnat` fails in the parser itself (`dnat` starts a
        // statement); the rest reach `check_fully_parsed`. Either way
        // the rule never reaches the kernel.
        let refused = match crate::parser::parse(text) {
            Err(_) => true,
            Ok(cmds) => super::check_fully_parsed(&cmds).is_err(),
        };
        assert!(refused, "accepted `{}`", text);
    }
    for text in [
        "add rule ip t c ct state established accept",
        "add rule ip t c ct state { established, related } accept",
        "add rule ip t c ct state != new accept",
    ] {
        let cmds = crate::parser::parse(text).unwrap();
        super::check_fully_parsed(&cmds).unwrap_or_else(|e| panic!("refused `{}`: {}", text, e));
    }
}

#[test]
fn icmp_type_names_resolve_to_numbers() {
    // iptables' ICMP names are not nft's. 1.1.14 passed the name
    // through, so `--icmp-type port-unreachable` reached the kernel as
    // the ASCII bytes of the name (or a register overflow), and
    // `--icmp-type 3/4` became the ASCII of "3/4".
    let rule = last_rule(Family::Ip, &[
        "-A", "INPUT", "-p", "icmp", "--icmp-type", "port-unreachable", "-j", "ACCEPT",
    ]);
    assert!(rule.contains("icmp type 3") && rule.contains("icmp code 3"), "rule: {}", rule);
    let rule = last_rule(Family::Ip, &[
        "-A", "INPUT", "-p", "icmp", "--icmp-type", "3/4", "-j", "ACCEPT",
    ]);
    assert!(rule.contains("icmp type 3") && rule.contains("icmp code 4"), "rule: {}", rule);
    let rule = last_rule(Family::Ip, &[
        "-A", "INPUT", "-p", "icmp", "--icmp-type", "echo-request", "-j", "ACCEPT",
    ]);
    assert!(rule.contains("icmp type 8"), "rule: {}", rule);
    // A prefix picks out one name, as iptables allows.
    let rule = last_rule(Family::Ip, &[
        "-A", "INPUT", "-p", "icmp", "--icmp-type", "echo-req", "-j", "ACCEPT",
    ]);
    assert!(rule.contains("icmp type 8"), "rule: {}", rule);
    // `any` is every ICMP packet, so the protocol test has to survive.
    let rule = last_rule(Family::Ip, &[
        "-A", "INPUT", "-p", "icmp", "--icmp-type", "any", "-j", "ACCEPT",
    ]);
    assert!(rule.contains("meta l4proto icmp"), "rule: {}", rule);
    assert!(!rule.contains("icmp type"), "rule: {}", rule);
    // ip6tables names map to the ICMPv6 numbers.
    let rule = last_rule(Family::Ip6, &[
        "-A", "INPUT", "-p", "icmpv6", "--icmpv6-type", "neighbour-solicitation",
        "-j", "ACCEPT",
    ]);
    assert!(rule.contains("icmpv6 type 135"), "rule: {}", rule);
    // Both spellings resolve, so the shared prefix is not ambiguous.
    let rule = last_rule(Family::Ip6, &[
        "-A", "INPUT", "-p", "icmpv6", "--icmpv6-type", "neighbor-solicitation",
        "-j", "ACCEPT",
    ]);
    assert!(rule.contains("icmpv6 type 135"), "rule: {}", rule);
}

#[test]
fn unknown_icmp_type_is_refused() {
    for (fam, flag, name) in [
        (Family::Ip, "--icmp-type", "bogus"),
        (Family::Ip, "--icmp-type", "3/999"),
        (Family::Ip, "--icmp-type", "no-route"),
        (Family::Ip6, "--icmpv6-type", "bogus"),
        (Family::Ip6, "--icmpv6-type", "address-mask-request"),
    ] {
        let p = if matches!(fam, Family::Ip6) { "icmpv6" } else { "icmp" };
        assert!(is_refused(fam, &["-A", "INPUT", "-p", p, flag, name, "-j", "ACCEPT"]),
            "accepted {} {}", flag, name);
    }
    // A negated name that pins a code is not one nft clause.
    assert!(is_refused(Family::Ip, &[
        "-A", "INPUT", "-p", "icmp", "!", "--icmp-type", "port-unreachable", "-j", "ACCEPT",
    ]));
    // A negated plain type still works.
    let rule = last_rule(Family::Ip, &[
        "-A", "INPUT", "-p", "icmp", "!", "--icmp-type", "echo-request", "-j", "ACCEPT",
    ]);
    assert!(rule.contains("icmp type != 8"), "rule: {}", rule);
}

#[test]
fn unknown_reject_kind_is_refused() {
    // 1.1.14 exited 0 and installed a bare `reject`, which the kernel
    // answers with ICMP port-unreachable.
    assert!(is_refused(Family::Ip, &[
        "-A", "INPUT", "-j", "REJECT", "--reject-with", "bogus-thing",
    ]));
    // An ICMPv6 kind is not an IPv4 kind, and the other way round.
    assert!(is_refused(Family::Ip, &[
        "-A", "INPUT", "-j", "REJECT", "--reject-with", "icmp6-no-route",
    ]));
    assert!(is_refused(Family::Ip6, &[
        "-A", "INPUT", "-j", "REJECT", "--reject-with", "icmp-host-unreachable",
    ]));
    // The kinds iptables knows still install.
    let rule = last_rule(Family::Ip, &[
        "-A", "INPUT", "-j", "REJECT", "--reject-with", "icmp-host-unreachable",
    ]);
    assert!(rule.contains("reject with icmp type host-unreachable"), "rule: {}", rule);
    let rule = last_rule(Family::Ip6, &[
        "-A", "INPUT", "-j", "REJECT", "--reject-with", "icmp6-adm-prohibited",
    ]);
    assert!(rule.contains("reject with icmpv6 type admin-prohibited"), "rule: {}", rule);
    let rule = last_rule(Family::Ip, &["-A", "INPUT", "-j", "REJECT", "--reject-with", "tcp-reset"]);
    assert!(rule.contains("reject with tcp reset"), "rule: {}", rule);
}

#[test]
fn nft_reject_refuses_an_unknown_kind() {
    for text in [
        "add rule ip t c reject with bogus-thing",
        "add rule ip t c reject with icmp type bogus",
    ] {
        let cmds = crate::parser::parse(text).unwrap();
        assert!(super::check_fully_parsed(&cmds).is_err(), "accepted `{}`", text);
    }
    for text in [
        "add rule ip t c reject",
        "add rule ip t c reject with icmp type host-unreachable",
        "add rule ip t c meta l4proto tcp reject with tcp reset",
    ] {
        let cmds = crate::parser::parse(text).unwrap();
        super::check_fully_parsed(&cmds).unwrap_or_else(|e| panic!("refused `{}`: {}", text, e));
    }
}

#[test]
fn unknown_dscp_class_is_refused() {
    // An unrecognised class became 0, so `--dscp-class bogus` installed
    // `ip dscp 0` — a match on unmarked traffic, silently.
    assert!(is_refused(Family::Ip, &[
        "-A", "INPUT", "-m", "dscp", "--dscp-class", "bogus", "-j", "ACCEPT",
    ]));
    assert!(is_refused(Family::Ip, &[
        "-t", "mangle", "-A", "OUTPUT", "-j", "DSCP", "--set-dscp-class", "bogus",
    ]));
    let rule = last_rule(Family::Ip, &[
        "-A", "INPUT", "-m", "dscp", "--dscp-class", "EF", "-j", "ACCEPT",
    ]);
    assert!(rule.contains("ip dscp"), "rule: {}", rule);
}

#[test]
fn icmp_type_any_without_p_still_tests_the_protocol() {
    // `--icmp-type any` lowers to no type clause, so without a `-p` to
    // carry the protocol the rule would be a bare verdict.
    let rule = last_rule(Family::Ip, &[
        "-A", "INPUT", "-m", "icmp", "--icmp-type", "any", "-j", "ACCEPT",
    ]);
    assert!(rule.contains("meta l4proto icmp"), "rule: {}", rule);
    // ip6tables has no `any`, and neither does stormwall: real
    // ip6tables answers ``Unknown ICMPv6 type `any'``.
    assert!(is_refused(Family::Ip6, &[
        "-A", "INPUT", "-p", "icmpv6", "--icmpv6-type", "any", "-j", "ACCEPT",
    ]));
}
