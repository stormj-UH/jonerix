#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <readline/history.h>

static void
fail(const char *message)
{
    fprintf(stderr, "history_expand_semantics: %s\n", message);
    exit(1);
}

static int hook_calls;
static int hook_inhibit_call;
static char hook_lines[4][128];

static int
expansion_hook(char *line, int offset)
{
    if (hook_calls < 4)
        snprintf(hook_lines[hook_calls], sizeof(hook_lines[hook_calls]),
            "%d:%s", offset, line);
    hook_calls++;
    return hook_calls == hook_inhibit_call;
}

static void
expect_expand(const char *message, char *input, int expected_result,
    const char *expected_output)
{
    char *output = NULL;
    int result = history_expand(input, &output);

    if (result != expected_result) {
        fprintf(stderr, "history_expand_semantics: %s: result %d != %d\n",
            message, result, expected_result);
        exit(1);
    }
    if (output == NULL || strcmp(output, expected_output) != 0) {
        fprintf(stderr, "history_expand_semantics: %s: output <%s> != <%s>\n",
            message, output == NULL ? "(null)" : output, expected_output);
        exit(1);
    }
    free(output);
}

static void
expect_hook_line(const char *message, int which, const char *expected)
{
    if (strcmp(hook_lines[which], expected) != 0) {
        fprintf(stderr,
            "history_expand_semantics: %s: hook line <%s> != <%s>\n",
            message, hook_lines[which], expected);
        exit(1);
    }
}

static void
reset_expansion_hook(int inhibit_call)
{
    int i;

    hook_calls = 0;
    hook_inhibit_call = inhibit_call;
    for (i = 0; i < 4; i++)
        hook_lines[i][0] = '\0';
    history_inhibit_expansion_function = expansion_hook;
}

int
main(void)
{
    char *saved_delimiters;
    char *arg;

    clear_history();
    history_base = 1;
    add_history("echo /tmp/archive.tar.gz alpha alpha");
    add_history("grep needle haystack");
    history_set_pos(history_length);

    expect_expand("head modifier", "!-2:1:h", 1, "/tmp");
    expect_expand("tail modifier", "!-2:1:t", 1, "archive.tar.gz");
    expect_expand("root modifier", "!-2:1:r", 1, "/tmp/archive.tar");
    expect_expand("extension modifier", "!-2:1:e", 1, ".gz");
    expect_expand("quote modifier", "!!:q", 1, "'grep needle haystack'");
    expect_expand("xquote modifier", "!!:x", 1,
        "'grep' 'needle' 'haystack'");
    expect_expand("first substitution", "!-2:s/alpha/beta/", 1,
        "echo /tmp/archive.tar.gz beta alpha");
    expect_expand("global substitution", "!-2:gs/alpha/beta/", 1,
        "echo /tmp/archive.tar.gz beta beta");
    expect_expand("repeat substitution", "!-2:&", 1,
        "echo /tmp/archive.tar.gz beta alpha");
    expect_expand("search word designator", "!?needle?:%", 1, "needle");
    expect_expand("range to penultimate", "!-2:1-", 1,
        "/tmp/archive.tar.gz alpha");
    expect_expand("range from word", "!-2:1*", 1,
        "/tmp/archive.tar.gz alpha alpha");
    expect_expand("range from command", "!-2:-1", 1,
        "echo /tmp/archive.tar.gz");
    expect_expand("print only", "!-2:p", 2,
        "echo /tmp/archive.tar.gz alpha alpha");
    expect_expand("quick substitution", "^needle^pin^", 1,
        "grep pin haystack");
    expect_expand("missing numeric event", "!999", -1,
        "!999: event not found");
    expect_expand("missing prefix event", "!zzz", -1,
        "!zzz: event not found");
    expect_expand("bang followed by no-expand space", "cmd ! ls", 0,
        "cmd ! ls");
    expect_expand("bang followed by no-expand equals", "cmd != 1", 0,
        "cmd != 1");
    expect_expand("leading space does not inhibit later expansion", " !!", 1,
        " grep needle haystack");
    expect_expand("leading equals does not inhibit later expansion", "=!!", 1,
        "=grep needle haystack");
    expect_expand("escaped repeated bang", "echo \\!!", 0, "echo \\!!");
    expect_expand("escaped bang word", "echo \\!x", 0, "echo \\!x");
    expect_expand("even backslashes before bang", "echo \\\\!!", 1,
        "echo \\\\grep needle haystack");
    history_quotes_inhibit_expansion = 1;
    history_quoting_state = '\'';
    expect_expand("initial single quote inhibits", "!!", 0, "!!");
    history_quoting_state = 0;
    expect_expand("single quote inhibits", "'!!'", 0, "'!!'");
    expect_expand("double quote expands", "\"!!\"", 1,
        "\"grep needle haystack\"");
    history_quotes_inhibit_expansion = 0;

    reset_expansion_hook(0);
    expect_expand("hook observes partial event", "pre !-1", 1,
        "pre grep needle haystack");
    if (hook_calls != 2)
        fail("hook observes two calls");
    expect_hook_line("hook original event", 0, "4:pre !-1");
    expect_hook_line("hook partial event", 1, "4:pre !-");

    reset_expansion_hook(2);
    expect_expand("hook second call inhibits", "!echo", 0, "!echo");
    if (hook_calls != 2)
        fail("hook second inhibit call count");
    expect_hook_line("hook prefix partial event", 1, "0:!e");

    reset_expansion_hook(3);
    expect_expand("hook later event inhibits", "pre !! post !echo", 1,
        "pre grep needle haystack post !echo");
    if (hook_calls != 3)
        fail("hook later inhibit call count");
    expect_hook_line("hook later event partial", 2,
        "30:pre grep needle haystack post !e");
    history_inhibit_expansion_function = NULL;

    history_set_pos(0);
    expect_expand("prefix search before offset", "!grep", -1,
        "!grep: event not found");
    expect_expand("substring search before offset", "!?needle?", -1,
        "!?needle?: event not found");
    history_set_pos(1);
    expect_expand("prefix search includes offset", "!grep", 1,
        "grep needle haystack");
    expect_expand("substring search includes offset", "!?needle?", 1,
        "grep needle haystack");
    history_set_pos(history_length);
    expect_expand("prefix search at end", "!grep", 1, "grep needle haystack");
    expect_expand("substring search at end", "!?needle?", 1,
        "grep needle haystack");

    history_comment_char = '#';
    expect_expand("comment at start", "# !1", 0, "# !1");
    expect_expand("comment after word", "cmd # !1", 0, "cmd # !1");
    history_comment_char = 0;

    saved_delimiters = history_word_delimiters;
    history_word_delimiters = ":";
    arg = history_arg_extract(1, 2, "left:middle:right");
    if (arg == NULL || strcmp(arg, ": middle") != 0)
        fail("custom word delimiter token");
    free(arg);
    history_word_delimiters = saved_delimiters;

    arg = history_arg_extract(2, 1, "cmd one two");
    if (arg == NULL || strcmp(arg, "") != 0)
        fail("empty inverted arg range");
    free(arg);

    arg = history_arg_extract(3, 1, "cmd one two three");
    if (arg != NULL)
        fail("bad inverted arg range");

    arg = history_arg_extract(-1, -1, "cmd one two");
    if (arg == NULL || strcmp(arg, "one") != 0)
        fail("negative arg index");
    free(arg);

    return 0;
}
