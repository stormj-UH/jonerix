#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <readline/readline.h>

static const char *active_input;
static int input_pos;

static void
fail(const char *message)
{
    fprintf(stderr, "keymap_funmap_semantics: %s\n", message);
    exit(1);
}

static int
insert_x(int count, int key)
{
    (void)count;
    (void)key;
    return rl_insert_text("X");
}

static int
insert_y(int count, int key)
{
    (void)count;
    (void)key;
    return rl_insert_text("Y");
}

static int
accept_now(int count, int key)
{
    (void)count;
    (void)key;
    rl_done = 1;
    return 0;
}

static int
test_getc(FILE *stream)
{
    (void)stream;
    if (active_input[input_pos] == '\0')
        return EOF;
    return active_input[input_pos++];
}

static void
expect_line(const char *message, const char *input, const char *expected)
{
    char *line;

    active_input = input;
    input_pos = 0;
    rl_getc_function = test_getc;
    line = readline("");
    if (line == NULL || strcmp(line, expected) != 0) {
        fprintf(stderr, "keymap_funmap_semantics: %s: <%s> != <%s>\n",
            message, line == NULL ? "(null)" : line, expected);
        exit(1);
    }
    free(line);
}

static void
expect_next_line(const char *message, const char *expected)
{
    char *line = readline("");

    if (line == NULL || strcmp(line, expected) != 0) {
        fprintf(stderr, "keymap_funmap_semantics: %s: <%s> != <%s>\n",
            message, line == NULL ? "(null)" : line, expected);
        exit(1);
    }
    free(line);
}

static int
contains_string(char **items, const char *needle)
{
    int i;

    if (items == NULL)
        return 0;
    for (i = 0; items[i] != NULL; i++) {
        if (strcmp(items[i], needle) == 0)
            return 1;
    }
    return 0;
}

int
main(void)
{
    Keymap original;
    Keymap map_a;
    Keymap map_b;
    Keymap default_map;
    Keymap copy_map;
    Keymap foreign_map;
    rl_keyseq_type_t type = 0;
    rl_command_func_t *func;
    char *name;

    original = rl_get_keymap();
    map_a = rl_make_bare_keymap();
    map_b = rl_make_bare_keymap();
    if (map_a == NULL || map_b == NULL || map_a == map_b)
        fail("distinct bare keymaps");
    if (rl_get_keymap_name(map_a) != NULL)
        fail("bare keymap name");

    default_map = rl_make_keymap();
    if (default_map == NULL || default_map == map_a || default_map == map_b)
        fail("make keymap");
    if (rl_get_keymap_name(default_map) != NULL)
        fail("default keymap name");
    func = rl_function_of_keyseq("x", default_map, &type);
    if (func != rl_insert)
        fail("make keymap self insert");
    rl_set_keymap(default_map);
    expect_line("dispatch make keymap", "q\n", "q");
    rl_set_keymap(original);

    func = rl_function_of_keyseq("q", original, &type);
    if (func != rl_insert)
        fail("builtin self insert lookup");
    if (rl_bind_key_if_unbound('q', insert_y) != 0)
        fail("bind if unbound printable");
    func = rl_function_of_keyseq("q", original, &type);
    if (func != rl_insert)
        fail("printable binding preserved");

    if (rl_bind_key_in_map('!', accept_now, default_map) != 0)
        fail("bind rl_done accept");
    rl_set_keymap(default_map);
    active_input = "ab!tail\n";
    input_pos = 0;
    rl_getc_function = test_getc;
    expect_next_line("rl_done accepts blocking line", "ab");
    expect_next_line("rl_done leaves trailing input", "tail");
    rl_set_keymap(original);

    if (rl_bind_key_in_map('x', insert_x, map_a) != 0)
        fail("bind map a");
    if (rl_bind_key_in_map('x', insert_y, map_b) != 0)
        fail("bind map b");

    func = rl_function_of_keyseq("x", map_a, &type);
    if (func != insert_x)
        fail("map a lookup");
    func = rl_function_of_keyseq("x", map_b, &type);
    if (func != insert_y)
        fail("map b lookup");
    func = rl_function_of_keyseq("x", original, &type);
    if (func == insert_x || func == insert_y)
        fail("custom binding leaked to original map");

    if (rl_set_keymap_name("probe-map-a", map_a) != 8)
        fail("set keymap name");
    name = rl_get_keymap_name(map_a);
    if (name == NULL || strcmp(name, "probe-map-a") != 0)
        fail("get keymap name");
    rl_free(name);
    if (rl_get_keymap_by_name("probe-map-a") != map_a)
        fail("get keymap by name");
    if (rl_get_keymap_by_name("missing-probe-map") != NULL)
        fail("missing keymap by name");
    if (rl_get_keymap_by_name("emacs-control-x") != NULL)
        fail("unsupported emacs control-x alias");

    copy_map = rl_copy_keymap(map_a);
    if (copy_map == NULL || copy_map == map_a)
        fail("copy keymap");
    if (rl_bind_key_in_map('z', insert_y, copy_map) != 0)
        fail("bind copy map");
    func = rl_function_of_keyseq("z", copy_map, &type);
    if (func != insert_y)
        fail("copy map lookup");
    rl_free_keymap(copy_map);
    rl_free_keymap(copy_map);
    if (rl_bind_key_in_map('q', insert_y, copy_map) != -1)
        fail("freed keymap rejected");

    foreign_map = (Keymap)&type;
    if (rl_bind_key_in_map('q', insert_y, foreign_map) != -1)
        fail("foreign keymap bind rejected");
    if (rl_get_keymap_name(foreign_map) != NULL)
        fail("foreign keymap name rejected");
    rl_set_keymap(foreign_map);
    if (rl_get_keymap() == foreign_map)
        fail("foreign keymap not current");
    rl_free_keymap(foreign_map);

    rl_set_keymap(map_a);
    if (rl_get_keymap() != map_a)
        fail("set current keymap");
    expect_line("dispatch map a", "x\n", "X");
    rl_set_keymap(map_b);
    expect_line("dispatch map b", "x\n", "Y");
    rl_set_keymap(original);

    if (rl_add_funmap_entry("probe-insert-x", insert_x) != 1)
        fail("add funmap entry");
    if (rl_named_function("probe-insert-x") != insert_x)
        fail("named function");
    if (!contains_string(rl_funmap_names(), "probe-insert-x"))
        fail("funmap names");

    if (rl_named_function("operate-and-get-next") != rl_operate_and_get_next)
        fail("operate-and-get-next named function");
    if (rl_named_function("quoted-insert") != rl_quoted_insert)
        fail("quoted-insert named function");
    if (rl_named_function("history-search-forward") != rl_history_search_forward)
        fail("history-search-forward named function");
    if (rl_named_function("vi-movement-mode") != rl_vi_movement_mode)
        fail("vi-movement-mode named function");
    if (!contains_string(rl_funmap_names(), "operate-and-get-next"))
        fail("operate-and-get-next funmap name");
    if (!contains_string(rl_funmap_names(), "vi-movement-mode"))
        fail("vi-movement-mode funmap name");

    if (rl_parse_and_bind("\"\\C-o\": operate-and-get-next") != 0)
        fail("parse bind operate-and-get-next");
    func = rl_function_of_keyseq("\\C-o", rl_get_keymap(), &type);
    if (func != rl_operate_and_get_next)
        fail("inputrc named command binding");

    if (rl_add_defun("probe-defun-y", insert_y, -1) != 0)
        fail("add defun by name");
    if (rl_named_function("probe-defun-y") != insert_y)
        fail("add defun named function");
    if (rl_parse_and_bind("\"\\C-y\": probe-defun-y") != 0)
        fail("parse bind add defun");
    func = rl_function_of_keyseq("\\C-y", rl_get_keymap(), &type);
    if (func != insert_y)
        fail("inputrc add defun binding");

    clear_history();
    add_history("older");
    add_history("newer");
    if (!history_set_pos(history_length))
        fail("history end");
    rl_replace_line("scratch", 0);
    if (rl_get_previous_history(1, 0) != 0)
        fail("previous history command");
    if (rl_line_buffer == NULL || strcmp(rl_line_buffer, "newer") != 0 ||
        rl_point != 5 || rl_end != 5)
        fail("previous history buffer");
    if (rl_get_next_history(1, 0) != 0)
        fail("next history command");
    if (rl_line_buffer == NULL || strcmp(rl_line_buffer, "") != 0 ||
        rl_point != 0 || rl_end != 0)
        fail("next history buffer");

    active_input = "D";
    input_pos = 0;
    rl_getc_function = test_getc;
    rl_replace_line("abc", 0);
    rl_point = 2;
    if (rl_arrow_keys(1, '[') != 0 || rl_point != 1)
        fail("arrow left command");

    active_input = "C";
    input_pos = 0;
    rl_getc_function = test_getc;
    if (rl_arrow_keys(1, '[') != 0 || rl_point != 2)
        fail("arrow right command");

    active_input = "A";
    input_pos = 0;
    rl_getc_function = test_getc;
    if (!history_set_pos(history_length))
        fail("arrow history end");
    rl_replace_line("", 0);
    if (rl_arrow_keys(1, '[') != 0 ||
        rl_line_buffer == NULL || strcmp(rl_line_buffer, "newer") != 0)
        fail("arrow up history command");

    active_input = "B";
    input_pos = 0;
    rl_getc_function = test_getc;
    if (rl_arrow_keys(1, '[') != 0 ||
        rl_line_buffer == NULL || strcmp(rl_line_buffer, "") != 0)
        fail("arrow down history command");

    active_input = "XY\033[201~";
    input_pos = 0;
    rl_getc_function = test_getc;
    rl_replace_line("ab", 0);
    rl_point = 1;
    if (rl_bracketed_paste_begin(1, 0) != 0 ||
        rl_line_buffer == NULL || strcmp(rl_line_buffer, "aXYb") != 0 ||
        rl_point != 3)
        fail("bracketed paste command");

    active_input = "ZZ";
    input_pos = 0;
    rl_getc_function = test_getc;
    rl_replace_line("ab", 0);
    rl_point = 1;
    if (rl_bracketed_paste_begin(1, 0) != 0 ||
        rl_line_buffer == NULL || strcmp(rl_line_buffer, "aZZb") != 0 ||
        rl_point != 3)
        fail("bracketed paste eof command");

    active_input = "12~Z";
    input_pos = 0;
    rl_getc_function = test_getc;
    if (rl_skip_csi_sequence(1, '[') != 0 || input_pos != 3 ||
        rl_read_key() != 'Z' || input_pos != 4)
        fail("skip csi sequence tilde");

    active_input = "ABC";
    input_pos = 0;
    rl_getc_function = test_getc;
    if (rl_skip_csi_sequence(1, '[') != 0 || input_pos != 1 ||
        rl_read_key() != 'B' || input_pos != 2)
        fail("skip csi sequence final byte");

    active_input = "12";
    input_pos = 0;
    rl_getc_function = test_getc;
    if (rl_skip_csi_sequence(1, '[') != 1 || input_pos != 2)
        fail("skip csi sequence eof");

    if (rl_bind_keyseq("\\C-xp", insert_x) != 0)
        fail("bind invoking keyseq");
    if (!contains_string(rl_invoking_keyseqs(insert_x), "\\C-xp"))
        fail("invoking keyseqs");
    if (!contains_string(rl_invoking_keyseqs_in_map(insert_x, rl_get_keymap()),
            "\\C-xp"))
        fail("invoking keyseqs in map");

    rl_getc_function = NULL;
    return 0;
}
