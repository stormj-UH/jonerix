/*
 * callback_unbuffered_fd: drive rl_callback_read_char without a
 * caller-supplied rl_getc_function and verify the line handler fires
 * after the \n is processed.
 *
 * Regression coverage for the 0.1.10 fix: previously rl_callback_read_char
 * fed bytes through stdio buffering, so a single read(2) syscall would
 * pull every available byte into libc's buffer. A select()-driven outer
 * loop would then see no further kernel-level data and stall before the
 * \n could be processed, leaving the handler uninvoked.
 *
 * The harness wires the readline instream to a pipe, writes "hi\n" once,
 * then pumps rl_callback_read_char() one byte at a time. With the fix in
 * place each call reads exactly one byte directly from the fd, so the
 * trailing \n is observed and the handler fires with line == "hi".
 */

#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/select.h>
#include <unistd.h>

#include <readline/readline.h>

static int handler_calls;
static char *captured_line;
static int handler_saw_eof;

static void
fail(const char *message)
{
    fprintf(stderr, "callback_unbuffered_fd: %s\n", message);
    exit(1);
}

static void
handler(char *line)
{
    handler_calls++;
    if (line == NULL) {
        handler_saw_eof = 1;
        captured_line = NULL;
    } else {
        captured_line = strdup(line);
        free(line);
    }
}

/* Pump rl_callback_read_char while data is readable on `read_fd`,
 * stopping when the handler fires or after at most `max_steps` calls. */
static void
pump(int read_fd, int max_steps)
{
    for (int i = 0; i < max_steps && handler_calls == 0; i++) {
        fd_set r;
        FD_ZERO(&r);
        FD_SET(read_fd, &r);
        struct timeval tv = {1, 0};
        int n = select(read_fd + 1, &r, NULL, NULL, &tv);
        if (n < 0) {
            if (errno == EINTR) continue;
            fail("select error");
        }
        if (n == 0)
            fail("select timed out before handler fired");
        rl_callback_read_char();
    }
}

static FILE *
open_read_pipe(int *read_fd_out, int *write_fd_out)
{
    int fds[2];
    if (pipe(fds) != 0)
        fail("pipe");
    FILE *stream = fdopen(fds[0], "r");
    if (stream == NULL)
        fail("fdopen");
    /* Deliberately leave stdio's default fully-buffered mode in place.
     * The pre-0.1.10 dispatch path reads via fgetc, so a buffered stream
     * would absorb every byte in one underlying read(2) syscall and
     * subsequent select() polls on read_fd would never wake up — exactly
     * the failure mode this test exists to catch. */
    *read_fd_out = fds[0];
    *write_fd_out = fds[1];
    return stream;
}

static void
test_basic_line(void)
{
    int read_fd, write_fd;
    FILE *stream = open_read_pipe(&read_fd, &write_fd);
    rl_instream = stream;
    rl_outstream = stderr;
    handler_calls = 0;
    captured_line = NULL;
    handler_saw_eof = 0;

    rl_callback_handler_install("p> ", handler);
    if (write(write_fd, "hi\n", 3) != 3)
        fail("pipe write hi");
    pump(read_fd, 32);

    if (handler_calls != 1)
        fail("handler not invoked exactly once");
    if (handler_saw_eof)
        fail("handler saw EOF unexpectedly");
    if (captured_line == NULL || strcmp(captured_line, "hi") != 0)
        fail("handler line mismatch");
    free(captured_line);
    captured_line = NULL;
    rl_callback_handler_remove();
    fclose(stream);
    close(write_fd);
    rl_instream = NULL;
    rl_outstream = NULL;
}

static void
test_empty_line(void)
{
    int read_fd, write_fd;
    FILE *stream = open_read_pipe(&read_fd, &write_fd);
    rl_instream = stream;
    rl_outstream = stderr;
    handler_calls = 0;
    captured_line = NULL;
    handler_saw_eof = 0;

    rl_callback_handler_install("p> ", handler);
    if (write(write_fd, "\n", 1) != 1)
        fail("pipe write newline");
    pump(read_fd, 8);

    if (handler_calls != 1)
        fail("empty line handler not invoked exactly once");
    if (handler_saw_eof)
        fail("empty line handler saw EOF");
    if (captured_line == NULL || captured_line[0] != '\0')
        fail("empty line handler did not receive empty string");
    free(captured_line);
    captured_line = NULL;
    rl_callback_handler_remove();
    fclose(stream);
    close(write_fd);
    rl_instream = NULL;
    rl_outstream = NULL;
}

static void
test_eof(void)
{
    int read_fd, write_fd;
    FILE *stream = open_read_pipe(&read_fd, &write_fd);
    rl_instream = stream;
    rl_outstream = stderr;
    handler_calls = 0;
    captured_line = NULL;
    handler_saw_eof = 0;

    rl_callback_handler_install("p> ", handler);
    /* Close the write end so a read() from the pipe returns 0 (EOF). */
    close(write_fd);
    pump(read_fd, 8);

    if (handler_calls != 1)
        fail("EOF handler not invoked exactly once");
    if (!handler_saw_eof)
        fail("EOF handler did not receive NULL line");
    rl_callback_handler_remove();
    fclose(stream);
    rl_instream = NULL;
    rl_outstream = NULL;
}

int
main(void)
{
    test_basic_line();
    test_empty_line();
    test_eof();
    return 0;
}
