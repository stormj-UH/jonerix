/*
 * callback_pty_select: end-to-end regression test that mirrors the
 * man-page reproducer used to triage the 0.1.9 dispatch hang.
 *
 * forkpty()s a child that drives rl_callback_read_char in a
 * select()-based loop without any caller-installed rl_getc_function.
 * The parent writes "hello\n" once to the master side. With the 0.1.10
 * fix, the child reads each byte directly from its stdin fd and the
 * registered line handler fires exactly once with "hello"; without the
 * fix, the child stalls in select() waiting for kernel-level data that
 * is already stranded in libc's stdio buffer.
 *
 * We bound the harness with alarm(8) so a regression surfaces as a
 * fast failure instead of a 20-second pty timeout buried in a higher
 * layer (CPython's test_readline pattern).
 */

#define _XOPEN_SOURCE 700

#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/select.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <termios.h>
#include <unistd.h>
#ifdef __APPLE__
#include <util.h>
#elif defined(__linux__)
#include <pty.h>
#else
#include <libutil.h>
#endif

#include <readline/readline.h>

static volatile sig_atomic_t timed_out;
static void on_alarm(int sig) { (void)sig; timed_out = 1; }

static void
fail_p(const char *message)
{
    fprintf(stderr, "callback_pty_select: %s\n", message);
    exit(1);
}

static int child_done;
static char *child_captured;

static void
child_handler(char *line)
{
    child_done = 1;
    if (line == NULL) {
        child_captured = NULL;
    } else {
        child_captured = strdup(line);
        free(line);
    }
    rl_callback_handler_remove();
}

static int
child_main(void)
{
    /* Child: drive rl_callback_read_char in a strict select() loop with
     * NO rl_getc_function — exactly the API path Python's input() takes. */
    rl_callback_handler_install("pty> ", child_handler);
    for (int i = 0; i < 200 && !child_done; i++) {
        fd_set r;
        FD_ZERO(&r);
        FD_SET(0, &r);
        struct timeval tv = {2, 0};
        int n = select(1, &r, NULL, NULL, &tv);
        if (n < 0) {
            if (errno == EINTR) continue;
            fprintf(stderr, "child: select error\n");
            return 11;
        }
        if (n == 0) {
            fprintf(stderr, "child: select timed out at iter=%d done=%d\n",
                    i, child_done);
            return 12;
        }
        rl_callback_read_char();
    }
    if (!child_done) {
        fprintf(stderr, "child: loop bound reached without dispatch\n");
        return 13;
    }
    if (child_captured == NULL) {
        fprintf(stderr, "child: handler saw EOF\n");
        return 14;
    }
    if (strcmp(child_captured, "hello") != 0) {
        fprintf(stderr, "child: handler line='%s' (want 'hello')\n",
                child_captured);
        return 15;
    }
    free(child_captured);
    return 0;
}

int
main(void)
{
    int master;
    pid_t pid = forkpty(&master, NULL, NULL, NULL);
    if (pid < 0)
        fail_p("forkpty");
    if (pid == 0)
        _exit(child_main());

    signal(SIGALRM, on_alarm);
    alarm(8);

    if (write(master, "hello\n", 6) != 6) {
        kill(pid, SIGKILL);
        fail_p("pty write");
    }

    /* Drain output until child exits or we time out. */
    char buf[256];
    int status = 0;
    int reaped = 0;
    while (!timed_out && !reaped) {
        fd_set r;
        FD_ZERO(&r);
        FD_SET(master, &r);
        struct timeval tv = {0, 100000};
        int n = select(master + 1, &r, NULL, NULL, &tv);
        if (n < 0 && errno != EINTR)
            break;
        if (n > 0 && FD_ISSET(master, &r)) {
            ssize_t got = read(master, buf, sizeof buf);
            if (got <= 0) {
                /* pty closed */
            }
        }
        pid_t w = waitpid(pid, &status, WNOHANG);
        if (w == pid)
            reaped = 1;
    }
    if (!reaped) {
        kill(pid, SIGKILL);
        waitpid(pid, &status, 0);
        fail_p("child hung (regression in rl_callback_read_char dispatch)");
    }
    close(master);
    if (!WIFEXITED(status))
        fail_p("child died abnormally");
    if (WEXITSTATUS(status) != 0) {
        fprintf(stderr, "callback_pty_select: child exited %d\n",
                WEXITSTATUS(status));
        return 1;
    }
    return 0;
}
