#include <stdio.h>

#include <readline/readline.h>
#include <readline/history.h>

static void
display_hook(char **matches, int num_matches, int max_length)
{
    (void)matches;
    (void)num_matches;
    (void)max_length;
}

static const char *active_input;
static int input_pos;

static int
test_getc(FILE *stream)
{
    (void)stream;
    if (active_input[input_pos] == '\0')
        return EOF;
    return active_input[input_pos++];
}

int
main(void)
{
    if (RL_VERSION_MAJOR < 7)
        return 1;
    if (RL_READLINE_VERSION != rl_readline_version)
        return 2;

    rl_completion_type = '\t';
    rl_completion_suppress_append = 1;
    rl_completion_display_matches_hook = display_hook;
    rl_catch_signals = 0;
    rl_catch_sigwinch = 0;
    if (rl_change_environment != 1)
        return 15;
    if (rl_completion_mark_symlink_dirs != 0
        || rl_persistent_signal_handlers != 0
        || rl_prefer_env_winsize != 0
        || rl_key_sequence_length != 0)
        return 16;

    if (rl_insert(1, 'x') != 0)
        return 3;
    if (rl_complete(1, '\t') != 0)
        return 4;
    if (rl_tilde_expand(1, '~') != 0)
        return 5;
    rl_replace_line("abcd", 0);
    rl_point = 2;
    if (rl_delete_text(1, 3) != 2)
        return 6;
    if (rl_line_buffer_len < rl_end + 1)
        return 7;
    if (rl_beginning_of_line(1, 0) != 0 || rl_point != 0)
        return 8;
    if (rl_end_of_line(1, 0) != 0 || rl_point != rl_end)
        return 9;
    if (rl_set_keyboard_input_timeout(1000) != 100000)
        return 10;
    if (RL_ISSTATE(RL_STATE_TIMEOUT))
        return 11;
    if (rl_clear_pending_input() != 0)
        return 12;
    if (rl_reset_line_state() != 0)
        return 13;
    rl_save_prompt();
    rl_restore_prompt();
    rl_set_screen_size(33, 99);
    rl_get_screen_size(&rl_point, &rl_end);
    if (rl_point != 33 || rl_end != 98)
        return 14;
    rl_set_screen_size(-1, 44);
    rl_get_screen_size(&rl_point, &rl_end);
    if (rl_point != 33 || rl_end != 43)
        return 18;
    rl_set_screen_size(55, 0);
    rl_get_screen_size(&rl_point, &rl_end);
    if (rl_point != 55 || rl_end != 43)
        return 19;
    rl_reset_screen_size();
    rl_get_screen_size(&rl_point, &rl_end);
    if (rl_point != 24 || rl_end != 79)
        return 30;
    if (history_total_bytes() < 0)
        return 17;
    /* Echoing reports the previous state while setting the next one. */
    if (rl_tty_set_echoing(0) != 1)
        return 20;
    if (rl_tty_set_echoing(0) != 0)
        return 21;
    if (rl_tty_set_echoing(1) != 0)
        return 22;
    if (rl_tty_set_echoing(1) != 1)
        return 23;
    if (rl_tty_set_echoing(1) != 1)
        return 24;

    rl_echo_signal_char(2);
    rl_reparse_colors();
    rl_check_signals();
    active_input = "A";
    input_pos = 0;
    rl_getc_function = test_getc;
    if (rl_skip_csi_sequence(1, '[') != 0)
        return 25;
    rl_getc_function = NULL;

    if (rl_set_paren_blink_timeout(111) != 500000)
        return 26;
    if (rl_set_paren_blink_timeout(-1) != 111)
        return 27;
    if (rl_set_paren_blink_timeout(333) != 111)
        return 28;
    if (rl_set_paren_blink_timeout(500000) != 333)
        return 29;

    return 0;
}
