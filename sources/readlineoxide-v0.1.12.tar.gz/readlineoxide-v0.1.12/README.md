# readlineoxide

`readlineoxide` is a clean-room Rust compatibility layer for the
`libreadline` and `libhistory` C ABIs used by Unix command-line programs.

The goal is to give jonerix a permissive replacement for the GPL-3 GNU
Readline dependency. The implementation is intentionally derived from the
public C ABI, documented behavior, and black-box test results, not from GNU
Readline source or decompiled output.

## Scope

The current implementation provides:

- `readline(3)` with prompt display, line allocation semantics, common edit
  commands, kill/yank behavior, undo snapshots, pending input, macro input, and
  keyboard macro support.
- Basic `libhistory` storage, traversal, replacement, removal, and history
  file read/write functions, plus history search, expansion, tokenization, and
  stifling behavior.
- Common readline globals, callback-mode entry points, terminal prep/deprep
  hooks, screen-size helpers, timeout state, and signal cleanup stubs so
  configure probes and simple consumers can link.
- Public compatibility macros and hooks used by common consumers such as
  Python's `_readline` extension and GDB's system-readline configure probe.
- Completion hooks, completion display, quoting/dequoting hooks, menu
  completion, keymap management, funmap lookups, macro bindings, inputrc
  conditionals/includes, variable binding/dumping, and tilde expansion hooks.
- A focused vi command subset covering insertion/movement modes, word motions,
  delete/change/yank operators, put, replace, character search/repeat, `%`
  matching, marks, and non-incremental history search/repeat.
- Compatibility headers under `include/readline/`.

This is not yet a full interactive editor or a complete GNU Readline clone.
Terminal redisplay remains intentionally conservative, full vi redo/repeat and
the long tail of advanced inputrc variables/customization remain incomplete,
and compatibility should continue to be driven by public documentation,
black-box behavior probes, and downstream consumers rather than GPL source.

## Unsafe Rust

The ABI is intentionally implemented as a C-facing compatibility shim, so the
unsafe surface is substantial and concentrated in `src/abi.rs`. Both
`crates/readline/src/lib.rs` and `crates/history/src/lib.rs` include that same
file rather than maintaining separate implementations.

As of the 0.1.12 release snapshot, the Rust source tree contains 11,248
lines:

- `src/abi.rs`: 11,195 lines.
- `crates/readline/src/lib.rs`: 2 lines.
- `crates/history/src/lib.rs`: 2 lines.
- `crates/readline/build.rs`: 49 lines.

Unsafe counts at that commit:

- 453 Rust source lines contain the `unsafe` keyword.
- 238 exported `pub unsafe extern "C" fn` ABI entry points.
- 123 private `unsafe fn` helpers.
- 79 inline `unsafe { ... }` blocks.
- 3 `unsafe impl Send` declarations for mutex-protected state wrappers.

The counts above were measured with:

```sh
wc -l $(rg --files -g '*.rs')
rg -n '\bunsafe\b' -g '*.rs' | wc -l
rg -n '^pub unsafe extern "C" fn ' src/abi.rs | wc -l
rg -n '^unsafe fn ' src/abi.rs | wc -l
rg -n 'unsafe \{' -g '*.rs' | wc -l
rg -n '^unsafe impl ' src/abi.rs | wc -l
```

Most of that unsafe surface is the unavoidable boundary with C callers:
process-global variables, raw C strings, caller-owned allocation/free
contracts, callback function pointers, keymap pointers, and history structs.
Internal work should keep moving behavior into safe helpers where possible, but
this crate should be reviewed as an unsafe FFI library, not as mostly-safe Rust
with a few isolated raw-pointer calls.

The serious-module invariants are tracked in `INVARIANTS.md`. New compatibility
or hardening work should update that ledger when it changes ownership,
reentrancy, path, keymap, history, callback, or line-buffer rules.

## Validation

Local validation starts with `RUSTFLAGS='-D warnings' cargo test --locked`,
`cargo clippy --locked --all-targets -- -D warnings`, and
`CFLAGS='-Wall -Wextra -Werror' sh tests/run-simulations.sh`. The jonerix
package path is validated in `ghcr.io/stormj-uh/jonerix:builder` with the same
simulation suite linked statically against `libreadline.a`; that builder image
does not currently include the `cargo clippy` subcommand, so Clippy is a local
static-analysis gate until the image grows that component.

GNU Readline release tarballs do not ship a substantive top-level test suite;
the external black-box probe is
`GNU_READLINE_SRC=/path/to/readline-8.3 sh tests/run-gnu-readline-examples.sh`,
which compiles selected upstream examples against the readlineoxide headers and
libraries without vendoring GPL test artifacts into this MIT source tree.
