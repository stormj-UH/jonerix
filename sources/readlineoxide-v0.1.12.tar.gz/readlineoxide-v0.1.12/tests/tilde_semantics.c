#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <readline/readline.h>
#include <readline/tilde.h>

static char pre_arg[128];
static char fail_arg[128];
static char home_env[512];

static void
fail(const char *message)
{
    fprintf(stderr, "tilde_semantics: %s\n", message);
    exit(1);
}

static char *
xdup(const char *text)
{
    char *copy;
    size_t len;

    len = strlen(text);
    copy = malloc(len + 1);
    if (copy == NULL)
        fail("malloc");
    memcpy(copy, text, len + 1);
    return copy;
}

static char *
pre_hook(char *user)
{
    snprintf(pre_arg, sizeof(pre_arg), "%s", user);
    if (strcmp(user, "hook") == 0)
        return xdup("/PRE_USER");
    return NULL;
}

static char *
fail_hook(char *user)
{
    snprintf(fail_arg, sizeof(fail_arg), "%s", user);
    if (strcmp(user, "missing_user_xyz") == 0)
        return xdup("/FAIL_USER");
    return NULL;
}

static void
expect_expand(const char *message, const char *input, const char *expected)
{
    char *expanded;

    expanded = tilde_expand(input);
    if (expanded == NULL || strcmp(expanded, expected) != 0) {
        fprintf(stderr, "tilde_semantics: %s: <%s> != <%s>\n", message,
            expanded == NULL ? "(null)" : expanded, expected);
        exit(1);
    }
    free(expanded);
}

static void
expect_command_expand(const char *message, const char *input, int point,
    const char *expected, int expected_point)
{
    rl_replace_line(input, 0);
    rl_point = point;
    if (rl_tilde_expand(1, '~') != 0)
        fail(message);
    if (rl_line_buffer == NULL || strcmp(rl_line_buffer, expected) != 0) {
        fprintf(stderr, "tilde_semantics: %s: line <%s> != <%s>\n", message,
            rl_line_buffer == NULL ? "(null)" : rl_line_buffer, expected);
        exit(1);
    }
    if (rl_point != expected_point || rl_end != (int)strlen(expected)) {
        fprintf(stderr,
            "tilde_semantics: %s: point/end %d/%d != %d/%zu\n",
            message, rl_point, rl_end, expected_point, strlen(expected));
        exit(1);
    }
}

int
main(int argc, char **argv)
{
    char expected[512];
    char command[512];
    char *prefixes[3];
    char *suffixes[2];

    if (argc != 2)
        fail("usage");
    if (snprintf(home_env, sizeof(home_env), "HOME=%s", argv[1]) >=
        (int)sizeof(home_env))
        fail("home env too long");
    if (putenv(home_env) != 0)
        fail("putenv");

    if (snprintf(expected, sizeof(expected), "%s/p", argv[1]) >=
        (int)sizeof(expected))
        fail("expected too long");
    expect_expand("home slash", "~/p", expected);

    if (rl_initialize() != 0)
        fail("rl_initialize");
    expect_command_expand("command home alone", "~", 0, argv[1],
        (int)strlen(argv[1]));
    expect_command_expand("command home slash", "~/p", 3, expected,
        (int)strlen(expected));
    if (snprintf(command, sizeof(command), "cmd %s", expected) >=
        (int)sizeof(command))
        fail("command expected too long");
    expect_command_expand("command word at end", "cmd ~/p", 7, command,
        (int)strlen(command));
    expect_command_expand("command ignores later cursor", "~/p tail", 8,
        "~/p tail", 8);

    tilde_expansion_preexpansion_hook = pre_hook;
    expect_expand("pre hook", "~hook/rest", "/PRE_USER/rest");
    if (strcmp(pre_arg, "hook") != 0)
        fail("pre hook argument");

    tilde_expansion_failure_hook = fail_hook;
    expect_expand("failure hook", "~missing_user_xyz/rest", "/FAIL_USER/rest");
    if (strcmp(fail_arg, "missing_user_xyz") != 0)
        fail("failure hook argument");

    prefixes[0] = "=~";
    prefixes[1] = ":~";
    prefixes[2] = NULL;
    tilde_additional_prefixes = prefixes;
    if (snprintf(expected, sizeof(expected), "x=%s/p", argv[1]) >=
        (int)sizeof(expected))
        fail("prefix expected too long");
    expect_expand("additional prefix", "x=~/p", expected);

    suffixes[0] = ":";
    suffixes[1] = NULL;
    tilde_additional_suffixes = suffixes;
    if (snprintf(expected, sizeof(expected), "%s:tail", argv[1]) >=
        (int)sizeof(expected))
        fail("suffix expected too long");
    expect_expand("additional suffix", "~:tail", expected);

    tilde_expansion_preexpansion_hook = NULL;
    tilde_expansion_failure_hook = NULL;
    tilde_additional_prefixes = NULL;
    tilde_additional_suffixes = NULL;
    return 0;
}
