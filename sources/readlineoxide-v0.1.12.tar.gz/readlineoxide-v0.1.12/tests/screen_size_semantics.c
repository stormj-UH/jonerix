/*
 * screen_size_semantics: pty-backed regression coverage for the public
 * readline screen-size ABI.
 *
 * Clean-room evidence from the installed readline binary shows that screen
 * columns are reported as terminal columns minus one, rl_resize_terminal()
 * re-reads the active terminal, and rl_reset_screen_size() prefers the live
 * terminal size before falling back to the default 24x79.
 */

#define _XOPEN_SOURCE 700

#include <stdio.h>
#include <stdlib.h>
#include <sys/ioctl.h>
#include <termios.h>
#include <unistd.h>
#ifdef __APPLE__
#include <util.h>
#elif defined(__linux__)
#include <pty.h>
#else
#include <libutil.h>
#endif

#include <readline/readline.h>

static void
fail(const char *message)
{
    fprintf(stderr, "screen_size_semantics: %s\n", message);
    exit(1);
}

static void
set_winsize(int fd, unsigned short rows, unsigned short cols)
{
    struct winsize ws;

    ws.ws_row = rows;
    ws.ws_col = cols;
    ws.ws_xpixel = 0;
    ws.ws_ypixel = 0;
    if (ioctl(fd, TIOCSWINSZ, &ws) != 0)
        fail("TIOCSWINSZ");
}

static void
expect_size(const char *message, int expected_rows, int expected_cols)
{
    int rows;
    int cols;

    rows = -1;
    cols = -1;
    rl_get_screen_size(&rows, &cols);
    if (rows != expected_rows || cols != expected_cols) {
        fprintf(stderr,
            "screen_size_semantics: %s: got %d/%d expected %d/%d\n",
            message, rows, cols, expected_rows, expected_cols);
        exit(1);
    }
}

int
main(void)
{
    int master;
    int slave;
    FILE *stream;

    if (openpty(&master, &slave, NULL, NULL, NULL) != 0)
        fail("openpty");
    set_winsize(slave, 41, 101);

    stream = fdopen(slave, "r+");
    if (stream == NULL)
        fail("fdopen");
    rl_instream = stream;
    rl_outstream = stream;

    if (rl_initialize() != 0)
        fail("rl_initialize");
    expect_size("initialize reads pty size", 41, 100);

    rl_set_screen_size(12, 34);
    expect_size("explicit set", 12, 33);

    rl_resize_terminal();
    expect_size("resize restores pty size", 41, 100);

    set_winsize(slave, 22, 80);
    rl_resize_terminal();
    expect_size("resize observes changed pty size", 22, 79);

    rl_set_screen_size(12, 34);
    rl_reset_screen_size();
    expect_size("reset prefers pty size", 22, 79);

    fclose(stream);
    close(master);
    return 0;
}
