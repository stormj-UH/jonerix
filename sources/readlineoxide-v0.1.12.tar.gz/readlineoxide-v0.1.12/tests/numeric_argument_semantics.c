#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <readline/readline.h>

static const char *active_input;
static int input_pos;

static void
fail(const char *message)
{
    fprintf(stderr, "numeric_argument_semantics: %s\n", message);
    exit(1);
}

static int
test_getc(FILE *stream)
{
    (void)stream;
    if (active_input[input_pos] == '\0')
        return EOF;
    return (unsigned char)active_input[input_pos++];
}

static char *
read_test_line(const char *input)
{
    active_input = input;
    input_pos = 0;
    rl_getc_function = test_getc;
    return readline("");
}

static void
expect_line(const char *message, const char *input, const char *expected)
{
    char *line = read_test_line(input);

    if (line == NULL || strcmp(line, expected) != 0) {
        fprintf(stderr, "numeric_argument_semantics: %s: <%s> != <%s>\n",
            message, line == NULL ? "(null)" : line, expected);
        exit(1);
    }
    if (rl_explicit_arg != 0 || rl_numeric_arg != 1)
        fail("numeric argument leaked");
    free(line);
}

int
main(void)
{
    expect_line("plain insert", "a\n", "a");
    expect_line("meta digit", "\0333a\n", "aaa");
    expect_line("meta digit accumulation", "\0331\0332b\n", "bbbbbbbbbbbb");
    expect_line("leading zero digit", "\0330\0333c\n", "ccc");
    expect_line("negative self insert", "\033-\0333d\n", "");
    expect_line("abort clears digit argument", "\0333\007e\n", "e");

    rl_getc_function = NULL;
    return 0;
}
