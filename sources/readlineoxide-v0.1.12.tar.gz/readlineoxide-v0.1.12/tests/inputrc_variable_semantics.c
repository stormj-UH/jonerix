#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <readline/readline.h>

static void
fail(const char *message)
{
    fprintf(stderr, "inputrc_variable_semantics: %s\n", message);
    exit(1);
}

static void
expect_value(const char *variable, const char *expected)
{
    char *value = rl_variable_value(variable);

    if (value == NULL || strcmp(value, expected) != 0) {
        fprintf(stderr, "inputrc_variable_semantics: %s: <%s> != <%s>\n",
            variable, value == NULL ? "(null)" : value, expected);
        exit(1);
    }
}

static void
expect_bind(const char *variable, const char *value, const char *expected)
{
    if (rl_variable_bind(variable, value) != 0)
        fail(variable);
    expect_value(variable, expected);
}

int
main(void)
{
    expect_value("bind-tty-special-chars", "on");
    expect_value("byte-oriented", "off");
    expect_value("echo-control-characters", "on");
    expect_value("enable-active-region", "on");
    expect_value("enable-keypad", "off");
    expect_value("enable-meta-key", "on");
    expect_value("expand-tilde", "off");
    expect_value("force-meta-prefix", "off");
    expect_value("history-preserve-point", "off");
    expect_value("horizontal-scroll-mode", "off");
    expect_value("mark-modified-lines", "off");
    expect_value("menu-complete-display-prefix", "off");
    expect_value("meta-flag", "off");
    expect_value("page-completions", "on");
    expect_value("prefer-visible-bell", "on");
    expect_value("revert-all-at-newline", "off");
    expect_value("search-ignore-case", "off");
    expect_value("skip-completed-text", "off");
    expect_value("comment-begin", "#");
    expect_value("emacs-mode-string", "@");
    expect_value("keyseq-timeout", "500");
    expect_value("vi-cmd-mode-string", "(cmd)");
    expect_value("vi-ins-mode-string", "(ins)");

    expect_bind("bind-tty-special-chars", "off", "off");
    expect_bind("byte-oriented", "on", "on");
    expect_bind("echo-control-characters", "off", "off");
    expect_bind("enable-active-region", "off", "off");
    expect_bind("enable-keypad", "on", "on");
    expect_bind("enable-meta-key", "off", "off");
    expect_bind("expand-tilde", "on", "on");
    expect_bind("force-meta-prefix", "on", "on");
    expect_bind("history-preserve-point", "on", "on");
    expect_bind("horizontal-scroll-mode", "on", "on");
    expect_bind("mark-modified-lines", "on", "on");
    expect_bind("menu-complete-display-prefix", "on", "on");
    expect_bind("meta-flag", "on", "on");
    expect_bind("page-completions", "off", "off");
    expect_bind("prefer-visible-bell", "off", "off");
    expect_bind("revert-all-at-newline", "on", "on");
    expect_bind("search-ignore-case", "on", "on");
    expect_bind("skip-completed-text", "on", "on");
    expect_bind("comment-begin", "//", "//");
    if (rl_variable_bind("comment-begin", "") != 1)
        fail("empty comment-begin rejected");
    expect_value("comment-begin", "//");
    expect_bind("emacs-mode-string", "E", "E");
    expect_bind("keyseq-timeout", "42", "42");
    expect_bind("keyseq-timeout", "bad", "0");
    expect_bind("vi-cmd-mode-string", "CMD", "CMD");
    expect_bind("vi-ins-mode-string", "INS", "INS");

    rl_replace_line("abc", 0);
    rl_point = 2;
    rl_done = 0;
    if (rl_insert_comment(1, '#') != 0)
        fail("insert comment");
    if (strcmp(rl_line_buffer, "//abc") != 0 || rl_point != 2 || rl_end != 5 ||
        rl_done != 1)
        fail("custom comment insertion");

    expect_bind("comment-begin", "# ", "# ");
    rl_replace_line("", 0);
    rl_point = 0;
    rl_done = 0;
    if (rl_insert_comment(1, '#') != 0)
        fail("insert spaced comment");
    if (strcmp(rl_line_buffer, "# ") != 0 || rl_point != 2 || rl_end != 2 ||
        rl_done != 1)
        fail("spaced comment insertion");

    if (rl_variable_bind("definitely-unknown-variable", "on") != 1)
        fail("unknown variable still rejected");
    if (rl_variable_value("definitely-unknown-variable") != NULL)
        fail("unknown variable value");

    return 0;
}
