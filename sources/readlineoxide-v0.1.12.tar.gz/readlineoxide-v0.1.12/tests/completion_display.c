#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <readline/readline.h>

static int display_calls;
static int display_count;
static int display_max;
static FILE *capture;

static void
fail(const char *message)
{
    fprintf(stderr, "completion_display: %s\n", message);
    exit(1);
}

static char *
copy_string(const char *value)
{
    size_t len = strlen(value);
    char *copy = malloc(len + 1);
    if (copy == NULL)
        fail("malloc string");
    memcpy(copy, value, len + 1);
    return copy;
}

static char **
attempted_completion(const char *text, int start, int end)
{
    char **matches;

    if (strcmp(text, "ab") != 0 || start != 0 || end != 2)
        fail("completion arguments");

    matches = malloc(4 * sizeof(matches[0]));
    if (matches == NULL)
        fail("malloc matches");
    matches[0] = copy_string("ab");
    matches[1] = copy_string("aba");
    matches[2] = copy_string("abb");
    matches[3] = NULL;
    return matches;
}

static void
display_hook(char **matches, int num_matches, int max_length)
{
    if (matches == NULL)
        fail("display matches null");
    if (strcmp(matches[0], "ab") != 0)
        fail("display common");
    if (strcmp(matches[1], "aba") != 0 || strcmp(matches[2], "abb") != 0)
        fail("display entries");
    display_calls++;
    display_count = num_matches;
    display_max = max_length;
}

static void
reset_capture(void)
{
    if (capture != NULL)
        fclose(capture);
    capture = tmpfile();
    if (capture == NULL)
        fail("tmpfile");
    rl_outstream = capture;
}

static void
expect_capture(const char *message, const char *expected)
{
    char buffer[256];
    size_t used;
    size_t expected_len;

    if (fflush(capture) != 0)
        fail("fflush");
    if (fseek(capture, 0, SEEK_SET) != 0)
        fail("fseek");
    used = fread(buffer, 1, sizeof(buffer), capture);
    if (ferror(capture))
        fail("fread");
    expected_len = strlen(expected);
    if (used != expected_len || memcmp(buffer, expected, expected_len) != 0) {
        fprintf(stderr, "completion_display: %s: output mismatch\n",
            message);
        exit(1);
    }
}

int
main(void)
{
    char *matches[] = { "common", "alpha", "alpine", "arc", NULL };
    char *five[] = { "c", "a1", "a2", "a3", "a4", "a5", NULL };
    char *prefix_matches[] = {
        "longcommonprefix",
        "longcommonprefixA",
        "longcommonprefixB",
        NULL
    };

    rl_attempted_completion_function = attempted_completion;
    rl_completion_display_matches_hook = display_hook;
    rl_completion_suppress_append = 0;
    rl_replace_line("ab", 0);
    rl_point = 2;

    if (rl_complete(1, '\t') != 0)
        fail("complete");
    if (display_calls != 1)
        fail("display calls");
    if (display_count != 2 || display_max != 3)
        fail("display dimensions");
    if (rl_line_buffer == NULL || strcmp(rl_line_buffer, "ab") != 0)
        fail("line unchanged");
    if (rl_point != 2 || rl_end != 2)
        fail("point");

    rl_set_screen_size(24, 80);
    _rl_completion_prefix_display_length = 0;
    _rl_print_completions_horizontally = 0;
    reset_capture();
    rl_display_match_list(matches, 3, 6);
    expect_capture("vertical built-in display", "alpha   alpine  arc\n");

    _rl_print_completions_horizontally = 1;
    reset_capture();
    rl_display_match_list(matches, 3, 6);
    expect_capture("horizontal built-in display", "alpha   alpine  arc\n");

    rl_set_screen_size(24, 17);
    _rl_print_completions_horizontally = 0;
    reset_capture();
    rl_display_match_list(five, 5, 2);
    expect_capture("vertical column order", "a1  a3  a5\na2  a4\n");

    if (rl_variable_bind("completion-display-width", "17") != 0)
        fail("completion display width bind");
    rl_set_screen_size(24, 80);
    reset_capture();
    rl_display_match_list(five, 5, 2);
    expect_capture("variable display width", "a1  a3  a5\na2  a4\n");
    if (rl_variable_bind("completion-display-width", "-1") != 0)
        fail("completion display width reset");
    rl_set_screen_size(24, 17);

    _rl_print_completions_horizontally = 1;
    reset_capture();
    rl_display_match_list(five, 5, 2);
    expect_capture("horizontal column order", "a1  a2  a3  a4\na5\n");

    rl_set_screen_size(24, 80);
    _rl_print_completions_horizontally = 0;
    _rl_completion_prefix_display_length = 5;
    reset_capture();
    rl_display_match_list(prefix_matches, 2, 17);
    expect_capture("prefix elision", "...A  ...B\n");

    if (capture != NULL) {
        fclose(capture);
        capture = NULL;
    }
    rl_outstream = NULL;
    _rl_completion_prefix_display_length = 0;
    _rl_print_completions_horizontally = 0;
    rl_attempted_completion_function = NULL;
    rl_completion_display_matches_hook = NULL;
    return 0;
}
