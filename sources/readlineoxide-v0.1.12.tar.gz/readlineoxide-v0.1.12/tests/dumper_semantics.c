#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <readline/readline.h>

static void
fail(const char *message)
{
    fprintf(stderr, "dumper_semantics: %s\n", message);
    exit(1);
}

static void
read_stream(FILE *file, char *buffer, size_t size)
{
    size_t nread;

    if (fflush(file) != 0)
        fail("fflush");
    if (fseek(file, 0, SEEK_SET) != 0)
        fail("fseek");
    nread = fread(buffer, 1, size - 1, file);
    if (ferror(file))
        fail("fread");
    buffer[nread] = '\0';
}

static void
expect_contains(const char *buffer, const char *needle)
{
    if (strstr(buffer, needle) == NULL) {
        fprintf(stderr, "dumper_semantics: missing <%s> in <%s>\n", needle,
            buffer);
        exit(1);
    }
}

int
main(void)
{
    FILE *old_stream = rl_outstream;
    FILE *file = tmpfile();
    char buffer[4096];
    char macro_a[] = "Control-a: \"MAC\"";
    char macro_b[] = "\"\\M-x\": \"META\"";

    if (file == NULL)
        fail("tmpfile");
    rl_outstream = file;

    if (rl_variable_bind("Completion-Ignore-Case", "On") != 0)
        fail("mixed variable bind");
    if (strcmp(rl_variable_value("COMPLETION-IGNORE-CASE"), "on") != 0)
        fail("mixed variable value");
    if (rl_variable_bind("disable-completion", "") != 0)
        fail("empty bool bind");
    if (strcmp(rl_variable_value("disable-completion"), "on") != 0)
        fail("empty bool value");
    if (rl_variable_bind("editing-mode", "VI") != 0)
        fail("mixed editing mode");
    if (rl_variable_bind("keymap", "EMACS") != 0)
        fail("mixed keymap");
    if (rl_variable_bind("completion-query-items", "17") != 0)
        fail("query items bind");
    if (rl_variable_bind("history-size", "3") != 0)
        fail("history size bind");
    if (rl_variable_bind("editing-mode", "EMACS") != 0)
        fail("mixed editing mode reset");

    rl_variable_dumper(1);
    read_stream(file, buffer, sizeof(buffer));
    expect_contains(buffer, "set bind-tty-special-chars on");
    expect_contains(buffer, "set blink-matching-paren off");
    expect_contains(buffer, "set completion-ignore-case on");
    expect_contains(buffer, "set disable-completion on");
    expect_contains(buffer, "set match-hidden-files on");
    expect_contains(buffer, "set show-all-if-ambiguous off");
    expect_contains(buffer, "set comment-begin #");
    expect_contains(buffer, "set completion-query-items 17");
    expect_contains(buffer, "set keyseq-timeout 500");
    expect_contains(buffer, "set history-size 3");
    expect_contains(buffer, "set keymap emacs");
    expect_contains(buffer, "set editing-mode emacs");
    expect_contains(buffer, "set vi-cmd-mode-string (cmd)");

    if (fseek(file, 0, SEEK_SET) != 0 || fflush(file) != 0)
        fail("rewind macros");
    if (rl_parse_and_bind(macro_a) != 0)
        fail("parse macro a");
    if (rl_parse_and_bind(macro_b) != 0)
        fail("parse macro b");
    rl_macro_dumper(1);
    read_stream(file, buffer, sizeof(buffer));
    expect_contains(buffer, "\\C-a: \"MAC\"");
    expect_contains(buffer, "\\M-x: \"META\"");

    rl_outstream = old_stream;
    fclose(file);
    rl_variable_bind("disable-completion", "off");
    rl_variable_bind("completion-ignore-case", "off");
    return 0;
}
