#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <readline/readline.h>

static FILE *capture;
static int redisplay_hook_calls;

static void
fail(const char *message)
{
    fprintf(stderr, "display_message_semantics: %s\n", message);
    exit(1);
}

static void
reset_capture(void)
{
    if (capture != NULL)
        fclose(capture);
    capture = tmpfile();
    if (capture == NULL)
        fail("tmpfile");
    rl_outstream = capture;
}

static size_t
read_capture(unsigned char *buffer, size_t size)
{
    size_t used;

    if (fflush(capture) != 0)
        fail("fflush");
    if (fseek(capture, 0, SEEK_SET) != 0)
        fail("fseek");
    used = fread(buffer, 1, size, capture);
    if (ferror(capture))
        fail("fread");
    return used;
}

static void
expect_output(const char *message, const unsigned char *expected, size_t len)
{
    unsigned char buffer[128];
    size_t used = read_capture(buffer, sizeof(buffer));

    if (used != len || memcmp(buffer, expected, len) != 0) {
        fprintf(stderr, "display_message_semantics: %s: output mismatch\n",
            message);
        exit(1);
    }
}

static void
expect_repeated_output(const char *message, unsigned char expected, size_t len)
{
    unsigned char buffer[128];
    size_t i;
    size_t used = read_capture(buffer, sizeof(buffer));

    if (used != len) {
        fprintf(stderr,
            "display_message_semantics: %s: length %zu != %zu\n",
            message, used, len);
        exit(1);
    }
    for (i = 0; i < used; i++) {
        if (buffer[i] != expected) {
            fprintf(stderr,
                "display_message_semantics: %s: byte %zu mismatch\n",
                message, i);
            exit(1);
        }
    }
}

static void
expect_display(const char *message, const char *expected)
{
    if (rl_display_prompt == NULL || strcmp(rl_display_prompt, expected) != 0) {
        fprintf(stderr, "display_message_semantics: %s: <%s> != <%s>\n",
            message, rl_display_prompt == NULL ? "(null)" : rl_display_prompt,
            expected);
        exit(1);
    }
}

static void
redisplay_hook(void)
{
    redisplay_hook_calls++;
}

int
main(void)
{
    static const unsigned char redisplay[] = "P> abc";
    static const unsigned char bell[] = "\007";
    static const unsigned char visible_bell[] = "\033[?5h\033[?5l";
    static const unsigned char show_ascii[] = "A";
    static const unsigned char show_control[] = "C-J";
    static const unsigned char show_meta_control[] = "M-C-@";

    reset_capture();
    if (rl_initialize() != 0)
        fail("initialize");
    if (rl_set_prompt("P> ") != 0)
        fail("set prompt");
    rl_replace_line("abc", 0);
    rl_point = 1;

    if (rl_ding() != -1)
        fail("ding before prep");
    expect_output("ding before prep", (const unsigned char *)"", 0);
    if (strcmp(rl_variable_value("bell-style"), "audible") != 0)
        fail("default bell style");

    if (rl_message("MSG:%s:%d", "ok", 7) != 0)
        fail("message");
    expect_display("message display", "MSG:ok:7");
    if (rl_clear_message() != 0)
        fail("clear message");
    expect_display("clear message display", "P> ");

    reset_capture();
    rl_redisplay();
    expect_output("redisplay", redisplay, sizeof(redisplay) - 1);

    reset_capture();
    if (rl_forced_update_display() != 0)
        fail("forced update");
    expect_output("forced update", redisplay, sizeof(redisplay) - 1);

    reset_capture();
    rl_redisplay_function = redisplay_hook;
    if (rl_forced_update_display() != 0)
        fail("forced update hook");
    if (redisplay_hook_calls != 1)
        fail("forced update hook calls");
    expect_output("forced update hook output", (const unsigned char *)"", 0);
    rl_redisplay_function = rl_redisplay;

    reset_capture();
    if (rl_clear_display() != 0)
        fail("clear display");
    expect_output("clear display", (const unsigned char *)"", 0);

    reset_capture();
    if (rl_clear_screen(1, 0) != 0)
        fail("clear screen");
    expect_output("clear screen", (const unsigned char *)"", 0);

    reset_capture();
    if (rl_clear_visible_line() != 0)
        fail("clear visible line");
    expect_repeated_output("clear visible line", ' ', 79);

    reset_capture();
    if (rl_show_char('A') != (int)sizeof(show_ascii) - 1)
        fail("show ascii char");
    expect_output("show ascii char", show_ascii, sizeof(show_ascii) - 1);

    reset_capture();
    if (rl_show_char('\n') != (int)sizeof(show_control) - 1)
        fail("show control char");
    expect_output("show control char", show_control,
        sizeof(show_control) - 1);

    reset_capture();
    if (rl_show_char(0x80) != (int)sizeof(show_meta_control) - 1)
        fail("show meta control char");
    expect_output("show meta control char", show_meta_control,
        sizeof(show_meta_control) - 1);

    reset_capture();
    if (rl_prep_terminal(1) != 0)
        fail("prep terminal");
    if (rl_ding() != 0)
        fail("ding after prep");
    expect_output("ding after prep", bell, sizeof(bell) - 1);
    rl_deprep_terminal();

    if (rl_variable_bind("bell-style", "none") != 0 ||
        strcmp(rl_variable_value("bell-style"), "none") != 0)
        fail("bell style none bind");
    reset_capture();
    if (rl_prep_terminal(1) != 0)
        fail("prep terminal none");
    if (rl_ding() != 0)
        fail("ding none");
    expect_output("ding none", (const unsigned char *)"", 0);
    rl_deprep_terminal();

    if (rl_variable_bind("bell-style", "visible") != 0 ||
        strcmp(rl_variable_value("bell-style"), "visible") != 0)
        fail("bell style visible bind");
    reset_capture();
    if (rl_prep_terminal(1) != 0)
        fail("prep terminal visible");
    if (rl_ding() != 0)
        fail("ding visible");
    expect_output("ding visible", visible_bell, sizeof(visible_bell) - 1);
    rl_deprep_terminal();

    if (rl_variable_bind("bell-style", "audible") != 0 ||
        strcmp(rl_variable_value("bell-style"), "audible") != 0)
        fail("bell style audible bind");
    if (rl_variable_bind("bell-style", "not-a-style") != 1 ||
        strcmp(rl_variable_value("bell-style"), "audible") != 0)
        fail("bell style rejects invalid value");

    fclose(capture);
    capture = NULL;
    rl_outstream = NULL;
    return 0;
}
