/*
 * tty_default_bindings: regression coverage for the public
 * rl_tty_set_default_bindings() keymap hook.
 *
 * The Linux Readline 8.3 binary binds the terminal erase, kill, word-erase,
 * and literal-next characters into the supplied keymap. The public manual
 * documents rl_tty_unset_default_bindings() as resetting bindings manipulated
 * by the set call back to rl_insert, so this test covers that cleanup contract
 * without touching unrelated user bindings.
 */

#define _XOPEN_SOURCE 700

#include <stdio.h>
#include <stdlib.h>
#include <sys/ioctl.h>
#include <termios.h>
#include <unistd.h>
#ifdef __APPLE__
#include <util.h>
#elif defined(__linux__)
#include <pty.h>
#else
#include <libutil.h>
#endif

#include <readline/readline.h>

static int
custom_binding(int count, int key)
{
    (void)count;
    (void)key;
    return 0;
}

static void
fail(const char *message)
{
    fprintf(stderr, "tty_default_bindings: %s\n", message);
    exit(1);
}

static void
expect_binding(const char *message, int key, rl_command_func_t *expected,
    Keymap map)
{
    char seq[2];
    rl_keyseq_type_t type;
    rl_command_func_t *actual;

    seq[0] = (char)key;
    seq[1] = '\0';
    type = -1;
    actual = rl_function_of_keyseq(seq, map, &type);
    if (actual != expected) {
        fprintf(stderr, "tty_default_bindings: %s: key=%d\n", message, key);
        exit(1);
    }
}

int
main(void)
{
    int master;
    int slave;
    FILE *stream;
    struct termios tio;
    Keymap map;

    if (openpty(&master, &slave, NULL, NULL, NULL) != 0)
        fail("openpty");
    if (tcgetattr(slave, &tio) != 0)
        fail("tcgetattr");
    tio.c_cc[VERASE] = 3;
    tio.c_cc[VKILL] = 4;
    tio.c_cc[VWERASE] = 8;
    tio.c_cc[VLNEXT] = 9;
    if (tcsetattr(slave, TCSANOW, &tio) != 0)
        fail("tcsetattr");

    stream = fdopen(slave, "r+");
    if (stream == NULL)
        fail("fdopen");
    rl_instream = stream;
    rl_outstream = stream;

    map = rl_make_bare_keymap();
    if (map == NULL)
        fail("make keymap");
    if (rl_bind_key_in_map(5, custom_binding, map) != 0)
        fail("custom bind");

    rl_tty_set_default_bindings(map);
    expect_binding("erase", 3, rl_rubout, map);
    expect_binding("kill", 4, rl_unix_line_discard, map);
    expect_binding("word erase", 8, rl_unix_word_rubout, map);
    expect_binding("literal next", 9, rl_quoted_insert, map);
    expect_binding("unrelated custom binding", 5, custom_binding, map);

    rl_tty_unset_default_bindings(map);
    expect_binding("erase reset", 3, rl_insert, map);
    expect_binding("kill reset", 4, rl_insert, map);
    expect_binding("word erase reset", 8, rl_insert, map);
    expect_binding("literal next reset", 9, rl_insert, map);
    expect_binding("custom binding survives reset", 5, custom_binding, map);

    rl_free_keymap(map);
    fclose(stream);
    close(master);
    return 0;
}
