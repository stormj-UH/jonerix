#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

#include <readline/readline.h>

static void
fail(const char *message)
{
    fprintf(stderr, "completion_extended: %s\n", message);
    exit(1);
}

static char *
copy_string(const char *value)
{
    size_t len = strlen(value);
    char *copy = malloc(len + 1);
    if (copy == NULL)
        return NULL;
    memcpy(copy, value, len + 1);
    return copy;
}

static char *
many_generator(const char *text, int state)
{
    char buf[32];

    (void)text;
    if (state >= 1100)
        return NULL;
    snprintf(buf, sizeof(buf), "m%04d", state);
    return copy_string(buf);
}

static void
free_matches(char **matches)
{
    int i;

    if (matches == NULL)
        return;
    for (i = 0; matches[i] != NULL; i++)
        free(matches[i]);
    free(matches);
}

static void
write_empty_file(const char *path)
{
    FILE *file = fopen(path, "w");
    if (file == NULL)
        fail("fopen");
    fclose(file);
}

int
main(void)
{
    char **matches;
    char tmp[] = "/tmp/readlineoxide-completion-XXXXXX";
    char path[256];
    char query[256];
    char *item;
    int count;

    matches = rl_completion_matches("", many_generator);
    if (matches == NULL)
        fail("many matches null");
    for (count = 0; matches[count] != NULL; count++)
        ;
    if (count != 1101)
        fail("many matches count");
    if (strcmp(matches[1100], "m1099") != 0)
        fail("many matches tail");
    free_matches(matches);

    if (mkdtemp(tmp) == NULL)
        fail("mkdtemp");
    snprintf(path, sizeof(path), "%s/alpha", tmp);
    write_empty_file(path);
    snprintf(path, sizeof(path), "%s/beta", tmp);
    write_empty_file(path);
    snprintf(path, sizeof(path), "%s/Makefile", tmp);
    write_empty_file(path);
    snprintf(path, sizeof(path), "%s/map_case", tmp);
    write_empty_file(path);
    snprintf(path, sizeof(path), "%s/real-dir", tmp);
    if (mkdir(path, 0700) != 0)
        fail("mkdir real dir");
    snprintf(query, sizeof(query), "%s/link-dir", tmp);
    if (symlink(path, query) != 0)
        fail("symlink dir");
    snprintf(path, sizeof(path), "%s/.hidden", tmp);
    write_empty_file(path);

    snprintf(query, sizeof(query), "%s/al", tmp);
    item = rl_filename_completion_function(query, 0);
    if (item == NULL)
        fail("filename item null");
    snprintf(path, sizeof(path), "%s/alpha", tmp);
    if (strcmp(item, path) != 0)
        fail("filename item");
    free(item);
    if (rl_filename_completion_function(query, 1) != NULL)
        fail("filename terminator");

    if (rl_variable_bind("completion-ignore-case", "on") != 0)
        fail("completion ignore case bind");
    item = rl_variable_value("completion-ignore-case");
    if (item == NULL || strcmp(item, "on") != 0)
        fail("completion ignore case value");
    snprintf(query, sizeof(query), "%s/make", tmp);
    item = rl_filename_completion_function(query, 0);
    if (item == NULL)
        fail("case insensitive filename null");
    snprintf(path, sizeof(path), "%s/Makefile", tmp);
    if (strcmp(item, path) != 0)
        fail("case insensitive filename");
    free(item);
    if (rl_variable_bind("completion-ignore-case", "off") != 0)
        fail("completion ignore case reset");
    if (strcmp(rl_variable_value("completion-ignore-case"), "off") != 0)
        fail("completion ignore case reset value");

    if (rl_variable_bind("disable-completion", "on") != 0)
        fail("disable completion bind on");
    if (rl_inhibit_completion != 1 ||
        strcmp(rl_variable_value("disable-completion"), "on") != 0)
        fail("disable completion value on");
    if (rl_variable_bind("disable-completion", "off") != 0)
        fail("disable completion bind off");
    if (rl_inhibit_completion != 0 ||
        strcmp(rl_variable_value("disable-completion"), "off") != 0)
        fail("disable completion value off");

    if (rl_variable_bind("completion-map-case", "on") != 0 ||
        strcmp(rl_variable_value("completion-map-case"), "on") != 0)
        fail("completion map case on");
    snprintf(query, sizeof(query), "%s/map-", tmp);
    item = rl_filename_completion_function(query, 0);
    if (item == NULL)
        fail("map case filename null");
    snprintf(path, sizeof(path), "%s/map_case", tmp);
    if (strcmp(item, path) != 0)
        fail("map case filename");
    free(item);
    if (strcmp(rl_variable_value("show-all-if-ambiguous"), "off") != 0)
        fail("default show all ambiguous off");
    if (rl_variable_bind("show-all-if-ambiguous", "off") != 0 ||
        strcmp(rl_variable_value("show-all-if-ambiguous"), "off") != 0)
        fail("show all ambiguous off");
    if (rl_variable_bind("show-all-if-unmodified", "on") != 0 ||
        strcmp(rl_variable_value("show-all-if-unmodified"), "on") != 0)
        fail("show all unmodified on");
    if (rl_variable_bind("mark-directories", "off") != 0 ||
        _rl_complete_mark_directories != 0 ||
        strcmp(rl_variable_value("mark-directories"), "off") != 0)
        fail("mark directories off");
    if (rl_variable_bind("mark-symlinked-directories", "on") != 0 ||
        rl_completion_mark_symlink_dirs != 1 ||
        strcmp(rl_variable_value("mark-symlinked-directories"), "on") != 0)
        fail("mark symlinked directories on");
    if (rl_variable_bind("mark-directories", "on") != 0)
        fail("mark directories reset on");
    snprintf(query, sizeof(query), "%s/link", tmp);
    item = rl_filename_completion_function(query, 0);
    if (item == NULL)
        fail("symlink directory completion null");
    snprintf(path, sizeof(path), "%s/link-dir/", tmp);
    if (strcmp(item, path) != 0)
        fail("symlink directory completion");
    free(item);
    if (rl_variable_bind("visible-stats", "on") != 0 || rl_visible_stats != 1 ||
        strcmp(rl_variable_value("visible-stats"), "on") != 0)
        fail("visible stats on");
    if (rl_variable_bind("print-completions-horizontally", "on") != 0 ||
        _rl_print_completions_horizontally != 1 ||
        strcmp(rl_variable_value("print-completions-horizontally"), "on") != 0)
        fail("print completions horizontally on");
    if (rl_variable_bind("completion-prefix-display-length", "5") != 0 ||
        _rl_completion_prefix_display_length != 5 ||
        strcmp(rl_variable_value("completion-prefix-display-length"), "5") != 0)
        fail("completion prefix display length");
    if (rl_variable_bind("completion-prefix-display-length", "bad") != 0 ||
        _rl_completion_prefix_display_length != 0 ||
        strcmp(rl_variable_value("completion-prefix-display-length"), "0") != 0)
        fail("completion prefix display length invalid");
    if (strcmp(rl_variable_value("completion-display-width"), "-1") != 0)
        fail("default completion display width");
    if (rl_variable_bind("completion-display-width", "40") != 0 ||
        strcmp(rl_variable_value("completion-display-width"), "40") != 0)
        fail("completion display width");
    if (rl_variable_bind("completion-display-width", "bad") != 0 ||
        strcmp(rl_variable_value("completion-display-width"), "0") != 0)
        fail("completion display width invalid");
    if (rl_variable_bind("completion-display-width", "-1") != 0 ||
        strcmp(rl_variable_value("completion-display-width"), "-1") != 0)
        fail("completion display width reset");
    if (strcmp(rl_variable_value("enable-bracketed-paste"), "on") != 0)
        fail("default bracketed paste");
    if (rl_variable_bind("enable-bracketed-paste", "off") != 0 ||
        strcmp(rl_variable_value("enable-bracketed-paste"), "off") != 0)
        fail("bracketed paste off");
    if (strcmp(rl_variable_value("match-hidden-files"), "on") != 0)
        fail("default match hidden files");
    if (rl_variable_bind("match-hidden-files", "off") != 0 ||
        strcmp(rl_variable_value("match-hidden-files"), "off") != 0)
        fail("match hidden files off");
    if (rl_variable_bind("match-hidden-files", "on") != 0 ||
        strcmp(rl_variable_value("match-hidden-files"), "on") != 0)
        fail("match hidden files on");
    if (rl_variable_bind("blink-matching-paren", "on") != 0 ||
        rl_blink_matching_paren != 1 ||
        strcmp(rl_variable_value("blink-matching-paren"), "on") != 0)
        fail("blink matching paren on");
    if (rl_variable_bind("convert-meta", "off") != 0 ||
        strcmp(rl_variable_value("convert-meta"), "off") != 0)
        fail("convert meta off");
    if (rl_variable_bind("input-meta", "on") != 0 ||
        strcmp(rl_variable_value("input-meta"), "on") != 0)
        fail("input meta on");
    if (rl_variable_bind("output-meta", "on") != 0 ||
        strcmp(rl_variable_value("output-meta"), "on") != 0)
        fail("output meta on");
    if (rl_variable_bind("show-mode-in-prompt", "on") != 0 ||
        strcmp(rl_variable_value("show-mode-in-prompt"), "on") != 0)
        fail("show mode in prompt on");
    if (rl_variable_bind("colored-stats", "on") != 0 ||
        strcmp(rl_variable_value("colored-stats"), "on") != 0)
        fail("colored stats on");
    if (rl_variable_bind("colored-completion-prefix", "on") != 0 ||
        strcmp(rl_variable_value("colored-completion-prefix"), "on") != 0)
        fail("colored completion prefix on");
    if (strcmp(rl_variable_value("history-size"), "-1") != 0)
        fail("default history size value");
    if (rl_variable_bind("history-size", "3") != 0 ||
        strcmp(rl_variable_value("history-size"), "3") != 0)
        fail("history size value");
    if (rl_variable_bind("completion-query-items", "17") != 0 ||
        strcmp(rl_variable_value("completion-query-items"), "17") != 0)
        fail("completion query items value");
    if (rl_variable_bind("editing-mode", "vi") != 0 ||
        strcmp(rl_variable_value("editing-mode"), "vi") != 0 ||
        strcmp(rl_variable_value("keymap"), "vi-insert") != 0)
        fail("editing mode variable value");
    if (rl_variable_bind("keymap", "vi-command") != 0 ||
        strcmp(rl_variable_value("keymap"), "vi") != 0)
        fail("vi command keymap value");
    if (rl_variable_bind("keymap", "emacs-meta") != 0 ||
        strcmp(rl_variable_value("keymap"), "emacs-meta") != 0)
        fail("emacs meta keymap value");
    if (rl_variable_bind("editing-mode", "emacs") != 0)
        fail("editing mode reset");

    snprintf(query, sizeof(query), "%s/", tmp);
    item = NULL;
    for (count = 0; (item = rl_filename_completion_function(query, count)) != NULL;
         count++) {
        if (strstr(item, "/.hidden") != NULL)
            break;
        free(item);
    }
    if (item == NULL)
        fail("hidden file matched by default");
    free(item);
    if (rl_variable_bind("match-hidden-files", "off") != 0)
        fail("match hidden files off for completion");
    snprintf(query, sizeof(query), "%s/", tmp);
    for (count = 0; (item = rl_filename_completion_function(query, count)) != NULL;
         count++) {
        if (strstr(item, "/.hidden") != NULL)
            fail("hidden file without dot prefix when disabled");
        free(item);
    }
    snprintf(query, sizeof(query), "%s/.", tmp);
    item = rl_filename_completion_function(query, 0);
    if (item == NULL || strstr(item, "/.hidden") == NULL)
        fail("hidden file with dot prefix");
    free(item);

    snprintf(path, sizeof(path), "%s/alpha", tmp);
    unlink(path);
    snprintf(path, sizeof(path), "%s/beta", tmp);
    unlink(path);
    snprintf(path, sizeof(path), "%s/Makefile", tmp);
    unlink(path);
    snprintf(path, sizeof(path), "%s/map_case", tmp);
    unlink(path);
    snprintf(path, sizeof(path), "%s/link-dir", tmp);
    unlink(path);
    snprintf(path, sizeof(path), "%s/real-dir", tmp);
    rmdir(path);
    snprintf(path, sizeof(path), "%s/.hidden", tmp);
    unlink(path);
    rmdir(tmp);

    item = rl_username_completion_function("~", 0);
    if (item == NULL || item[0] != '~')
        fail("username item");
    free(item);

    return 0;
}
