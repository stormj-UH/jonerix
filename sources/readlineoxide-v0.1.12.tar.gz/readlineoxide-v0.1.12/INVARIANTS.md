# readlineoxide invariant ledger

Copyright (c) 2026 Jon-Erik G. Storm, Inc., a California Corporation, doing
business as LAVA GOAT SOFTWARE.

This ledger records the invariants that serious modules must maintain. Public C
entry points are the messy shell: they accept raw pointers, raw Unix bytes,
process globals, callbacks, environment variables, and filesystem paths. The
internal core should immediately convert that input into owned bytes, checked
indexes, registered handles, and bounded Rust collections.

## FFI boundary and allocation

- C string inputs are either null-checked at the public boundary or documented as
  required non-null before dereference.
- Public headers and exported symbols use the documented Readline ABI shape;
  compatibility cannot depend on callers ignoring mismatched return types or
  command-function arguments.
- C strings that represent filenames or inputrc paths stay raw Unix bytes. They
  must not pass through lossy UTF-8 conversion.
- Memory returned to callers is allocated with the same allocator family that
  `rl_free()` and public free functions expect.
- Public globals that may point at caller-owned storage are never freed unless
  their address is present in the owned-global-string registry.
- Early returns after allocation must free any temporary C allocation owned by
  the callee before returning.
- `struct readline_state` values passed to `rl_save_state()` own a stable opaque
  slot handle. Restores must look up the caller's slot rather than consuming a
  process-global snapshot.

## Line buffer and editor state

- `rl_line_buffer` is null or points to an owned, NUL-terminated allocation with
  at least `rl_line_buffer_len` bytes of capacity.
- `0 <= rl_point <= rl_end`, and `rl_end` is the byte length of the current line.
- Public editing functions must restore the point/end invariant before return,
  even when indexes are negative, inverted, or beyond the current line.
- Internal line editing operates on owned `Vec<u8>` values. Raw globals are only
  synchronized at the boundary before or after command dispatch.
- Panic while holding editor state must not expose a partially updated raw line
  buffer; mutations should be staged in owned values where possible.

## History store and history files

- The history vector owns every `HIST_ENTRY` it stores. `history_get()` and list
  APIs expose borrowed raw pointers that remain valid until the next mutating
  history operation.
- `history_length`, `history_offset`, and `history_max_entries` are mirrors of
  the mutex-protected `History` struct and are synchronized after mutation.
- `history_offset <= entries.len()` after every traversal, removal, restore, or
  stifle/unstifle operation.
- History line and timestamp bytes are preserved exactly except for documented
  newline stripping while reading files.
- With `history_multiline_entries` enabled, timestamp lines delimit logical
  entries. Reads and truncation operate on logical entries and must not split a
  multiline command between two history entries.
- When `history_quotes_inhibit_expansion` is enabled, both literal single quotes
  in the input and an initial single-quote `history_quoting_state` inhibit
  history expansion until quote state changes.
- `history_inhibit_expansion_function` is called before expansion commits an
  event. If it inhibits either the original event or the secondary partial-line
  view, the original event bytes remain unchanged in the output.
- History filenames are raw byte paths. Missing-file and filesystem errors
  return the platform errno value when available.

## Keymaps and funmap

- Public keymap pointers are valid only if they are built-in handles or appear in
  the keymap registry.
- Keymap sequence indexes are derived state. The public keyseq and macro vectors
  remain the source of truth, and every bind/unbind/clear operation that mutates
  either vector must rebuild the exact-match and prefix indexes before returning.
- `rl_set_keymap()` rejects foreign handles by leaving the active keymap
  unchanged.
- `rl_free_keymap()` must not free built-in, foreign, or already-freed handles.
- Key binding lookup returns the correct binding type: function, keymap, macro,
  or no binding.
- Registry locks are not held while calling public callbacks or doing any work
  that may reenter keymap APIs.
- Tty-default bindings are tracked per keymap. `rl_tty_unset_default_bindings()`
  may reset only keys previously marked by `rl_tty_set_default_bindings()` and
  must preserve unrelated application bindings.
- During bound key dispatch, `rl_dispatching`, `rl_executing_key`,
  `rl_executing_keyseq`, and `rl_key_sequence_length` describe the command being
  invoked before user callbacks run.
- `rl_arrow_keys()` consumes exactly one byte after the escape prefix and maps
  documented arrow suffixes to history and character movement commands.
- `rl_bracketed_paste_begin()` inserts all input bytes until the terminal
  bracketed-paste end marker, or all bytes read before EOF if the marker is
  missing.
- `rl_skip_csi_sequence()` consumes input through the first CSI final byte and
  reports EOF if the sequence ends before a final byte is read.

## Completion

- Completion generator mutexes protect only cached generator state: key bytes and
  match vectors.
- User hooks, dequoting hooks, directory hooks, rewrite hooks, ignore hooks,
  quoting hooks, and filesystem scans run without holding generator mutexes.
- Completion candidates are owned byte strings until converted to C allocations
  for the public ABI.
- `completion-ignore-case` and `completion-map-case` affect comparison only; they
  do not rewrite candidate bytes.
- Numeric completion display variables accept messy input at the ABI boundary:
  invalid or negative `completion-prefix-display-length` values normalize to
  `0`, invalid `completion-display-width` values normalize to `0`, and negative
  display widths mean "use the current screen width" before the display core
  observes them.
- Documented boolean inputrc variables accepted for compatibility are stored as
  normalized `0`/`1` state before any core logic observes them, even when their
  current effect is limited to bind/value/dump compatibility.
- Filename completion honors `match-hidden-files`: dotfile candidates are
  visible by default, and disabling the variable only suppresses implicit
  dotfile matches when the typed filename component does not start with `.`.
- `comment-begin` is a validated inputrc string inside the editor state; comment
  insertion prepends that byte sequence to the line, restores `rl_end` to the new
  buffer length, leaves `rl_point` immediately after the inserted marker, and
  marks the line done.
- Numeric argument state is explicit: the public argument globals hold the
  current magnitude and sign, private digit-tracking records whether decimal
  accumulation has begun, and every command except the argument-building
  functions restores the default argument state before returning to input
  processing.
- Counted motion and deletion commands normalize signed counts before mutating
  line state: negative character/word motion and forward/backward delete pairs
  delegate to the opposite direction with a saturated positive count; explicit
  zero counts for character and word motion are no-ops; scans stop once the
  target boundary can no longer advance.
- Word kill commands treat explicit zero counts as no-ops without disturbing
  the adjacent-kill coalescing state.
- Transpose commands are count-normalized before mutation: character transpose
  treats zero and negative counts as no-ops and repeats positive counts from the
  updated cursor, while word transpose rejects negative counts and swaps the
  previous word with the requested following word.
- Word case commands treat zero counts as no-ops, transform previous words for
  negative counts without moving point, and capitalize at the start of each word
  in the selected range.
- Horizontal-space deletion removes the contiguous space/tab run around point
  and restores point to the start of the removed run, or leaves point unchanged
  when no horizontal whitespace is present.
- Copy-word commands replace the kill buffer without mutating the line, treat
  negative counts as a request to copy the opposite direction, and preserve the
  copied bytes in line order without leading or trailing word separators.
- Vi append mode always moves at most one character to enter insertion mode
  after the current character; numeric counts do not widen that motion.
- Vi case-change commands treat non-positive counts as no-ops and only record
  undo state when at least one character may be changed.
- Vi delete/rubout commands keep the cursor on an existing character after a
  deletion when the line is non-empty, treat zero counts as no-ops, and route
  negative counts to the opposite deletion direction.
- Vi put commands treat non-positive counts as no-ops; positive counts insert
  whole kill-buffer copies and leave point on the final inserted byte.
- Directory marking follows the configured public variables and must not append
  directory markers to non-directories.
- Filename quoting is applied during completion insertion only when filename or
  full quoting is desired and the candidate contains a byte from
  `rl_filename_quote_characters`. Raw generator APIs return unquoted candidates.
- Completion entry points reset per-attempt public completion state before
  calling application completers; application hooks may then opt back into
  filename or full quoting for that attempt.
- `rl_display_match_list()` treats `matches[0]` as metadata/common-prefix state
  and displays only `matches[1]..matches[len]`, preserving the documented
  vertical/horizontal display order and prefix-elision variables.
- `rl_tilde_expand()` edits only the current tilde word at or immediately behind
  point. A successful expansion restores `rl_line_buffer`, `rl_point`, and
  `rl_end` as a single checked byte-range replacement.

## Inputrc

- `rl_read_init_file()` accepts null, explicit C filenames, `$INPUTRC`, `$HOME`,
  `$include`, and leading-tilde paths as raw byte paths.
- Include recursion is bounded by `inputrc_depth`; every successful increment is
  restored before return on success, parse error, missing file, or early failure.
- Conditional frames restore stack balance: stray `$else` and `$endif` mark the
  file status as failed, and unclosed `$if` fails at EOF.
- `rl_variable_bind()` returns success only for known variables it handles.
  Unknown variables are an explicit failure.

## Callback and blocking readline

- Blocking `readline()` and callback mode initialize inputrc state before first
  use.
- `rl_done` is honored as an accept-line signal during blocking line reads, and
  stale restored `rl_done` state must not terminate the next read.
- Callback state owns its prompt copy and line buffer while installed, and
  handler removal frees that ownership exactly once.
- User handlers are called after the accepted line is detached from callback
  mutable state.

## Display and terminal hooks

- `rl_redisplay()` is the built-in redisplay routine and writes only through the
  configured output adapter.
- `rl_forced_update_display()` dispatches through the public
  `rl_redisplay_function` hook so callers that replace the redisplay routine see
  the forced-refresh ABI event.
- `rl_show_char()` writes its visible character representation to `rl_outstream`
  and returns the number of bytes emitted, including control/meta prefixes.
- `bell-style` accepts only `audible`, `visible`, or `none` aliases at the ABI
  boundary. `rl_ding()` must not write any output when the terminal is unprepped
  or the style is `none`.
- Screen-size globals store the public Readline column value: live terminal
  columns are represented as `ws_col - 1`, explicit positive
  `rl_set_screen_size()` columns are represented as `cols - 1`, and reset falls
  back to `24/79` only when no terminal size can be read. Captured clear-screen
  operations must not emit hard-coded terminal escape sequences to non-tty output
  streams.
- `rl_set_paren_blink_timeout()` returns the previous timeout and ignores
  negative replacement values.
- Terminal prep/deprep hooks may be unset; prep state is mirrored by
  `RL_STATE_TERMPREPPED` before returning to C.

## Panic and drop audit

- Mutex poisoning is recovered with `into_inner()` because ABI callers cannot
  handle Rust panics. New code should still avoid panicking inside locks.
- `Drop` implementations that free C allocations must tolerate null pointers and
  partially initialized values.
- New code should prefer checked conversions, saturating arithmetic, and explicit
  error returns over `unwrap()`, `expect()`, or panic-based control flow.
- Any new unsafe block should include nearby `SAFETY:` bullets, and each bullet
  should be backed by a type invariant, constructor check, assertion, or focused
  test where practical.
