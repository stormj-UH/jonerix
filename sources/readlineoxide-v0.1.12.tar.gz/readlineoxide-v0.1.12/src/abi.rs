#![allow(non_camel_case_types)]

use std::collections::{HashMap, HashSet, VecDeque};
use std::ffi::OsString;
use std::ffi::{CStr, CString};
use std::fs::{self, OpenOptions};
use std::io::{self, BufRead, Write};
use std::os::raw::{c_char, c_int, c_long, c_ulong, c_void};
use std::os::unix::ffi::{OsStrExt, OsStringExt};
use std::path::PathBuf;
use std::ptr;
use std::sync::{Mutex, MutexGuard};
use std::time::{SystemTime, UNIX_EPOCH};

type rl_command_func_t = Option<extern "C" fn(c_int, c_int) -> c_int>;
type rl_compentry_func_t = Option<extern "C" fn(*const c_char, c_int) -> *mut c_char>;
type rl_completion_func_t = Option<extern "C" fn(*const c_char, c_int, c_int) -> *mut *mut c_char>;
type rl_callback_handler_t = Option<extern "C" fn(*mut c_char)>;
type rl_hook_func_t = Option<extern "C" fn() -> c_int>;
type rl_completion_word_break_hook_t = Option<extern "C" fn() -> *mut c_char>;
type rl_getc_func_t = Option<extern "C" fn(*mut c_void) -> c_int>;
type rl_compdisp_func_t = Option<extern "C" fn(*mut *mut c_char, c_int, c_int)>;
type rl_voidfunc_t = Option<extern "C" fn()>;
type rl_vintfunc_t = Option<extern "C" fn(c_int)>;
type rl_directory_completion_hook_t = Option<extern "C" fn(*mut *mut c_char) -> c_int>;
type rl_filename_quoting_func_t =
    Option<extern "C" fn(*mut c_char, c_int, *mut c_char) -> *mut c_char>;
type rl_filename_dequoting_func_t = Option<extern "C" fn(*mut c_char, c_int) -> *mut c_char>;
type rl_char_is_quoted_func_t = Option<extern "C" fn(*mut c_char, c_int) -> c_int>;
type rl_macro_print_func_t =
    Option<extern "C" fn(*const c_char, *const c_char, c_int, *const c_char)>;
type history_inhibit_expansion_func_t = Option<extern "C" fn(*mut c_char, c_int) -> c_int>;
type rl_keyseq_type_ptr_t = *mut c_int;
type HistoryEventExpansion = (Vec<u8>, usize, bool, Option<Vec<u8>>);

#[repr(C)]
pub struct HIST_ENTRY {
    pub line: *mut c_char,
    pub timestamp: *mut c_char,
    pub data: *mut c_void,
}

#[repr(C)]
pub struct HISTORY_STATE {
    pub entries: *mut *mut HIST_ENTRY,
    pub offset: c_int,
    pub length: c_int,
    pub size: c_int,
    pub flags: c_int,
}

extern "C" {
    fn malloc(size: usize) -> *mut c_void;
    fn realloc(ptr: *mut c_void, size: usize) -> *mut c_void;
    fn free(ptr: *mut c_void);
    fn fdopen(fd: c_int, mode: *const c_char) -> *mut c_void;
    fn fgetc(stream: *mut c_void) -> c_int;
    fn fputc(ch: c_int, stream: *mut c_void) -> c_int;
    fn fputs(string: *const c_char, stream: *mut c_void) -> c_int;
    fn fflush(stream: *mut c_void) -> c_int;
    fn fileno(stream: *mut c_void) -> c_int;
    fn isatty(fd: c_int) -> c_int;
    fn ioctl(fd: c_int, request: c_ulong, ...) -> c_int;
    fn read(fd: c_int, buf: *mut c_void, count: usize) -> isize;
    fn tcgetattr(fd: c_int, termios: *mut Termios) -> c_int;
    fn tcsetattr(fd: c_int, optional_actions: c_int, termios: *const Termios) -> c_int;
}

// POSIX termios fields the prep_terminal path needs to flip.  Layout-wise
// the struct varies by platform, so we hold it as an opaque byte buffer
// and only manipulate it through tcgetattr/tcsetattr.  The buffer must be
// large enough for any libc's struct termios; 256 bytes is far beyond
// what Linux musl (60 bytes) or BSD libcs need.
#[repr(C)]
#[derive(Copy, Clone)]
struct Termios {
    storage: [u8; 256],
}

impl Termios {
    fn zero() -> Self {
        Self { storage: [0; 256] }
    }
}

#[repr(C)]
#[derive(Copy, Clone)]
struct Winsize {
    ws_row: u16,
    ws_col: u16,
    ws_xpixel: u16,
    ws_ypixel: u16,
}

impl Winsize {
    fn zero() -> Self {
        Self {
            ws_row: 0,
            ws_col: 0,
            ws_xpixel: 0,
            ws_ypixel: 0,
        }
    }
}

#[cfg(any(target_os = "linux", target_os = "android"))]
const TIOCGWINSZ_IOCTL: c_ulong = 0x5413;
#[cfg(any(
    target_os = "macos",
    target_os = "ios",
    target_os = "freebsd",
    target_os = "netbsd",
    target_os = "openbsd",
    target_os = "dragonfly"
))]
const TIOCGWINSZ_IOCTL: c_ulong = 0x40087468;

// Constants for termios c_lflag bits — POSIX values are identical across
// Linux glibc/musl and the BSD family.
const ICANON: c_ulong = 0x00000002;
const ECHO: c_ulong = 0x00000008;
const ECHOE: c_ulong = 0x00000010;
const ECHOK: c_ulong = 0x00000020;
const ECHONL: c_ulong = 0x00000040;
const ISIG: c_ulong = 0x00000001;
const IEXTEN: c_ulong = 0x00008000;
// c_iflag bits.
const IXON: c_ulong = 0x00000400;
const ICRNL: c_ulong = 0x00000100;
const INLCR: c_ulong = 0x00000040;
const ISTRIP: c_ulong = 0x00000020;
const INPCK: c_ulong = 0x00000010;
const BRKINT: c_ulong = 0x00000002;
// c_oflag bits.
const OPOST: c_ulong = 0x00000001;

// TCSADRAIN: apply after pending output drains.  POSIX value 1 on Linux/BSD.
const TCSADRAIN: c_int = 1;
// TCSANOW: 0 on Linux (apply immediately).  We use DRAIN to match real readline.

// Indices of the c_iflag / c_oflag / c_cflag / c_lflag fields and the
// special-character array (c_cc) inside `struct termios` for Linux/musl on
// aarch64 / x86_64 / arm.  POSIX guarantees the field types and their
// relative order; we only need raw byte offsets to flip the relevant
// bits without depending on libc-rs.  The values are identical on all
// jonerix targets we support.
const TERMIOS_IFLAG_OFFSET: usize = 0;
const TERMIOS_OFLAG_OFFSET: usize = 4;
const TERMIOS_LFLAG_OFFSET: usize = 12;
const TERMIOS_CC_OFFSET: usize = 17;
const TERMIOS_CC_VERASE: usize = TERMIOS_CC_OFFSET + 2;
const TERMIOS_CC_VKILL: usize = TERMIOS_CC_OFFSET + 3;
const TERMIOS_CC_VMIN: usize = TERMIOS_CC_OFFSET + 6;
const TERMIOS_CC_VTIME: usize = TERMIOS_CC_OFFSET + 5;
const TERMIOS_CC_VWERASE: usize = TERMIOS_CC_OFFSET + 14;
const TERMIOS_CC_VLNEXT: usize = TERMIOS_CC_OFFSET + 15;

unsafe fn termios_flag_load(t: &Termios, offset: usize) -> c_ulong {
    let mut value: u32 = 0;
    ptr::copy_nonoverlapping(
        t.storage.as_ptr().add(offset),
        &mut value as *mut u32 as *mut u8,
        4,
    );
    value as c_ulong
}

unsafe fn termios_flag_store(t: &mut Termios, offset: usize, value: c_ulong) {
    let value: u32 = value as u32;
    ptr::copy_nonoverlapping(
        &value as *const u32 as *const u8,
        t.storage.as_mut_ptr().add(offset),
        4,
    );
}

const RL_VERSION_BYTES: &[u8] = b"8.3\0";
const WORD_BREAK_BYTES: &[u8] = b" \t\n\"\\'`@$><=;|&{(\0";
const QUOTE_BYTES: &[u8] = b"\"'\0";
const EMPTY_BYTES: &[u8] = b"\0";
const OFF_BYTES: &[u8] = b"off\0";
const ON_BYTES: &[u8] = b"on\0";
const EMACS_BYTES: &[u8] = b"emacs\0";
const VI_BYTES: &[u8] = b"vi\0";
const READERR: c_int = -2;
const RL_STATE_TERMPREPPED: c_ulong = 0x00000004;
const RL_STATE_INITIALIZED: c_ulong = 0x00000002;
const RL_STATE_CALLBACK: c_ulong = 0x00080000;
const RL_STATE_DONE: c_ulong = 0x02000000;
const RL_STATE_TIMEOUT: c_ulong = 0x04000000;
const HISTORY_WORD_DELIMITERS: &[u8] = b" \t\n()<>;&|\0";
const HISTORY_NO_EXPAND_CHARS: &[u8] = b" \t\n\r=\0";
const HISTORY_SEARCH_DELIMITERS: &[u8] = b"\0";
const READLINE_STATE_MAGIC: c_ulong = 0x524c5354;
const KEYSEQ_TYPE_FUNCTION: c_int = 0;
const KEYSEQ_TYPE_MACRO: c_int = 2;
const SINGLE_MATCH: c_int = 1;
const MULT_MATCH: c_int = 2;
const BELL_STYLE_NONE: c_int = 0;
const BELL_STYLE_AUDIBLE: c_int = 1;
const BELL_STYLE_VISIBLE: c_int = 2;

#[no_mangle]
pub static mut rl_readline_name: *mut c_char = ptr::null_mut();
#[no_mangle]
pub static mut rl_terminal_name: *mut c_char = ptr::null_mut();
#[no_mangle]
pub static mut rl_library_version: *mut c_char = RL_VERSION_BYTES.as_ptr() as *mut c_char;
#[no_mangle]
pub static mut rl_readline_version: c_int = 0x0803;
#[no_mangle]
pub static mut rl_gnu_readline_p: c_int = 1;
#[no_mangle]
pub static mut rl_prompt: *mut c_char = ptr::null_mut();
#[no_mangle]
pub static mut rl_display_prompt: *mut c_char = ptr::null_mut();
#[no_mangle]
pub static mut rl_line_buffer: *mut c_char = ptr::null_mut();
#[no_mangle]
pub static mut rl_line_buffer_len: c_int = 0;
#[no_mangle]
pub static mut rl_point: c_int = 0;
#[no_mangle]
pub static mut rl_end: c_int = 0;
#[no_mangle]
pub static mut rl_done: c_int = 0;
#[no_mangle]
pub static mut rl_eof_found: c_int = 0;
#[no_mangle]
pub static mut rl_already_prompted: c_int = 0;
#[no_mangle]
pub static mut rl_num_chars_to_read: c_int = 0;
#[no_mangle]
pub static mut rl_readline_state: c_ulong = 0;
#[no_mangle]
pub static mut rl_completion_append_character: c_int = b' ' as c_int;
#[no_mangle]
pub static mut rl_completion_suppress_append: c_int = 0;
#[no_mangle]
pub static mut rl_completion_type: c_int = 0;
#[no_mangle]
pub static mut rl_attempted_completion_over: c_int = 0;
#[no_mangle]
pub static mut rl_completion_query_items: c_int = 100;
#[no_mangle]
pub static mut rl_catch_signals: c_int = 1;
#[no_mangle]
pub static mut rl_catch_sigwinch: c_int = 1;
#[no_mangle]
pub static mut rl_byte_oriented: c_int = 0;
#[no_mangle]
pub static mut rl_editing_mode: c_int = 1;
#[no_mangle]
pub static mut rl_insert_mode: c_int = 1;
#[no_mangle]
pub static mut rl_explicit_arg: c_int = 0;
#[no_mangle]
pub static mut rl_numeric_arg: c_int = 1;
#[no_mangle]
pub static mut rl_arg_sign: c_int = 1;
#[no_mangle]
pub static mut rl_dispatching: c_int = 0;
#[no_mangle]
pub static mut rl_executing_key: c_int = 0;
#[no_mangle]
pub static mut rl_completion_invoking_key: c_int = 0;
#[no_mangle]
pub static mut rl_completion_quote_character: c_int = 0;
#[no_mangle]
pub static mut rl_completion_found_quote: c_int = 0;
#[no_mangle]
pub static mut rl_completion_suppress_quote: c_int = 0;
#[no_mangle]
pub static mut rl_filename_quoting_desired: c_int = 1;
#[no_mangle]
pub static mut rl_full_quoting_desired: c_int = 0;
#[no_mangle]
pub static mut rl_inhibit_completion: c_int = 0;
#[no_mangle]
pub static mut rl_pending_input: c_int = 0;
#[no_mangle]
pub static mut rl_visible_prompt_length: c_int = 0;
#[no_mangle]
pub static mut rl_blink_matching_paren: c_int = 0;
#[no_mangle]
pub static mut rl_change_environment: c_int = 1;
#[no_mangle]
pub static mut rl_complete_with_tilde_expansion: c_int = 0;
#[no_mangle]
pub static mut rl_completion_mark_symlink_dirs: c_int = 0;
#[no_mangle]
pub static mut rl_key_sequence_length: c_int = 0;
#[no_mangle]
pub static mut rl_persistent_signal_handlers: c_int = 0;
#[no_mangle]
pub static mut rl_prefer_env_winsize: c_int = 0;
#[no_mangle]
pub static mut rl_mark: c_int = 0;
#[no_mangle]
pub static mut rl_last_func: rl_command_func_t = None;
#[no_mangle]
pub static mut rl_linefunc: rl_command_func_t = None;
#[no_mangle]
pub static mut rl_undo_list: *mut c_void = ptr::null_mut();
#[no_mangle]
pub static mut rl_executing_keyseq: *mut c_char = ptr::null_mut();
#[no_mangle]
pub static mut rl_executing_macro: *mut c_char = ptr::null_mut();
#[no_mangle]
pub static mut rl_display_fixed: c_int = 0;
#[no_mangle]
pub static mut rl_erase_empty_line: c_int = 0;
#[no_mangle]
pub static mut rl_special_prefixes: *mut c_char = ptr::null_mut();
#[no_mangle]
pub static mut rl_basic_word_break_characters: *mut c_char =
    WORD_BREAK_BYTES.as_ptr() as *mut c_char;
#[no_mangle]
pub static mut rl_completer_word_break_characters: *mut c_char =
    WORD_BREAK_BYTES.as_ptr() as *mut c_char;
#[no_mangle]
pub static mut rl_basic_quote_characters: *mut c_char = QUOTE_BYTES.as_ptr() as *mut c_char;
#[no_mangle]
pub static mut rl_completer_quote_characters: *mut c_char = ptr::null_mut();
#[no_mangle]
pub static mut rl_filename_quote_characters: *mut c_char = ptr::null_mut();
#[no_mangle]
pub static mut rl_filename_completion_desired: c_int = 0;
#[no_mangle]
pub static mut rl_ignore_completion_duplicates: c_int = 1;
#[no_mangle]
pub static mut rl_sort_completion_matches: c_int = 1;
#[no_mangle]
pub static mut rl_visible_stats: c_int = 0;
#[no_mangle]
pub static mut _rl_complete_mark_directories: c_int = 1;
#[no_mangle]
pub static mut _rl_completion_prefix_display_length: c_int = 0;
#[no_mangle]
pub static mut _rl_print_completions_horizontally: c_int = 0;
#[no_mangle]
pub static mut _rl_term_autowrap: c_int = 1;
#[no_mangle]
pub static mut rl_attempted_completion_function: rl_completion_func_t = None;
#[no_mangle]
pub static mut rl_completion_entry_function: rl_compentry_func_t =
    Some(rl_filename_completion_function);
#[no_mangle]
pub static mut rl_menu_completion_entry_function: rl_compentry_func_t = None;
#[no_mangle]
pub static mut rl_completion_word_break_hook: rl_completion_word_break_hook_t = None;
#[no_mangle]
pub static mut rl_completion_display_matches_hook: rl_compdisp_func_t = None;
#[no_mangle]
pub static mut rl_directory_completion_hook: rl_directory_completion_hook_t = None;
#[no_mangle]
pub static mut rl_completion_rewrite_hook: rl_filename_dequoting_func_t = None;
#[no_mangle]
pub static mut rl_directory_rewrite_hook: rl_directory_completion_hook_t = None;
#[no_mangle]
pub static mut rl_filename_rewrite_hook: rl_filename_dequoting_func_t = None;
#[no_mangle]
pub static mut rl_ignore_some_completions_function: rl_directory_completion_hook_t = None;
#[no_mangle]
pub static mut rl_filename_quoting_function: rl_filename_quoting_func_t = None;
#[no_mangle]
pub static mut rl_filename_dequoting_function: rl_filename_dequoting_func_t = None;
#[no_mangle]
pub static mut rl_filename_stat_hook: rl_filename_dequoting_func_t = None;
#[no_mangle]
pub static mut rl_char_is_quoted_p: rl_char_is_quoted_func_t = None;
#[no_mangle]
pub static mut rl_instream: *mut c_void = ptr::null_mut();
#[no_mangle]
pub static mut rl_outstream: *mut c_void = ptr::null_mut();
#[no_mangle]
pub static mut rl_startup_hook: rl_hook_func_t = None;
#[no_mangle]
pub static mut rl_pre_input_hook: rl_hook_func_t = None;
#[no_mangle]
pub static mut rl_event_hook: rl_hook_func_t = None;
#[no_mangle]
pub static mut rl_signal_event_hook: rl_hook_func_t = None;
#[no_mangle]
pub static mut rl_timeout_event_hook: rl_hook_func_t = None;
#[no_mangle]
pub static mut rl_input_available_hook: rl_hook_func_t = None;
#[no_mangle]
pub static mut rl_getc_function: rl_getc_func_t = None;
#[no_mangle]
pub static mut rl_deprep_term_function: rl_voidfunc_t = None;
#[no_mangle]
pub static mut rl_prep_term_function: rl_vintfunc_t = None;
#[no_mangle]
pub static mut rl_macro_display_hook: rl_macro_print_func_t = None;
#[no_mangle]
pub static mut rl_executing_keymap: *mut c_void = ptr::null_mut();
#[no_mangle]
pub static mut rl_binding_keymap: *mut c_void = ptr::null_mut();
#[no_mangle]
pub static mut emacs_standard_keymap: *mut c_void = ptr::null_mut();
#[no_mangle]
pub static mut emacs_meta_keymap: *mut c_void = ptr::null_mut();
#[no_mangle]
pub static mut emacs_ctlx_keymap: *mut c_void = ptr::null_mut();
#[no_mangle]
pub static mut vi_movement_keymap: *mut c_void = ptr::null_mut();
#[no_mangle]
pub static mut vi_insertion_keymap: *mut c_void = ptr::null_mut();

#[no_mangle]
pub static mut history_base: c_int = 1;
#[no_mangle]
pub static mut history_length: c_int = 0;
#[no_mangle]
pub static mut history_max_entries: c_int = 0;
#[no_mangle]
pub static mut history_offset: c_int = 0;
#[no_mangle]
pub static mut history_write_timestamps: c_int = 0;
#[no_mangle]
pub static mut history_expansion_char: c_char = b'!' as c_char;
#[no_mangle]
pub static mut history_subst_char: c_char = b'^' as c_char;
#[no_mangle]
pub static mut history_comment_char: c_char = 0;
#[no_mangle]
pub static mut history_word_delimiters: *mut c_char =
    HISTORY_WORD_DELIMITERS.as_ptr() as *mut c_char;
#[no_mangle]
pub static mut history_search_delimiter_chars: *mut c_char =
    HISTORY_SEARCH_DELIMITERS.as_ptr() as *mut c_char;
#[no_mangle]
pub static mut history_no_expand_chars: *mut c_char =
    HISTORY_NO_EXPAND_CHARS.as_ptr() as *mut c_char;
#[no_mangle]
pub static mut history_quotes_inhibit_expansion: c_int = 0;
#[no_mangle]
pub static mut history_quoting_state: c_int = 0;
#[no_mangle]
pub static mut history_inhibit_expansion_function: history_inhibit_expansion_func_t = None;
#[no_mangle]
pub static mut history_lines_read_from_file: c_int = 0;
#[no_mangle]
pub static mut history_lines_written_to_file: c_int = 0;
#[no_mangle]
pub static mut history_multiline_entries: c_int = 0;
#[no_mangle]
pub static mut history_file_version: *mut c_char = RL_VERSION_BYTES.as_ptr() as *mut c_char;
#[no_mangle]
pub static mut tilde_additional_prefixes: *mut *mut c_char = ptr::null_mut();
#[no_mangle]
pub static mut tilde_additional_suffixes: *mut *mut c_char = ptr::null_mut();
#[no_mangle]
pub static mut tilde_expansion_preexpansion_hook: Option<
    extern "C" fn(*mut c_char) -> *mut c_char,
> = None;
#[no_mangle]
pub static mut tilde_expansion_failure_hook: Option<extern "C" fn(*mut c_char) -> *mut c_char> =
    None;

static mut CURRENT_KEYMAP: *mut c_void = ptr::null_mut();
static mut BUILTIN_KEYMAP: *mut c_void = ptr::null_mut();
static mut TIMEOUT_SECONDS: c_int = 0;
static mut TIMEOUT_USECONDS: c_int = 0;
static mut TIMEOUT_ACTIVE: bool = false;
static mut KEYBOARD_INPUT_TIMEOUT_USECONDS: c_int = 100000;
static mut PAREN_BLINK_TIMEOUT_USECONDS: c_int = 500000;
static mut VARIABLE_VALUE_STORAGE: *mut c_char = ptr::null_mut();
static mut TTY_ECHOING: c_int = 1;
static mut SCREEN_ROWS: c_int = 24;
static mut SCREEN_COLS: c_int = 79;
static mut BELL_STYLE: c_int = BELL_STYLE_AUDIBLE;
static mut COMPLETION_DISPLAY_WIDTH: c_int = -1;
static mut ENABLE_BRACKETED_PASTE: c_int = 1;
static mut MATCH_HIDDEN_FILES: c_int = 1;
static mut NUMERIC_ARG_HAS_DIGITS: c_int = 0;
static mut CONVERT_META: c_int = 1;
static mut INPUT_META: c_int = 0;
static mut OUTPUT_META: c_int = 0;
static mut SHOW_MODE_IN_PROMPT: c_int = 0;
static mut COLORED_STATS: c_int = 0;
static mut COLORED_COMPLETION_PREFIX: c_int = 0;
static mut SAVED_PROMPT: *mut c_char = ptr::null_mut();

static EDITOR: Mutex<EditorConfig> = Mutex::new(EditorConfig {
    ctrl_a_macro: Vec::new(),
    ctrl_b_backward: true,
    tab_completes: true,
    pending_keyseq: Vec::new(),
    pending_input: VecDeque::new(),
    macro_input: VecDeque::new(),
    kbd_macro_recording: false,
    kbd_macro_current: Vec::new(),
    kbd_macro_last: Vec::new(),
    kill_buffer: Vec::new(),
    kill_ring: Vec::new(),
    kill_ring_index: 0,
    retained_kills: 10,
    last_yank: None,
    last_was_kill: false,
    mark: 0,
    mark_active: false,
    saved_line: None,
    undo_stack: Vec::new(),
    undo_group_depth: 0,
    undo_group_snapshot: None,
    completion_ignore_case: false,
    completion_map_case: false,
    show_all_if_ambiguous: false,
    show_all_if_unmodified: false,
    inputrc_compat: InputrcCompatConfig {
        bind_tty_special_chars: true,
        byte_oriented: false,
        echo_control_characters: true,
        enable_active_region: true,
        enable_keypad: false,
        enable_meta_key: true,
        expand_tilde: false,
        force_meta_prefix: false,
        history_preserve_point: false,
        horizontal_scroll_mode: false,
        mark_modified_lines: false,
        menu_complete_display_prefix: false,
        meta_flag: false,
        page_completions: true,
        prefer_visible_bell: true,
        revert_all_at_newline: false,
        search_ignore_case: false,
        skip_completed_text: false,
        comment_begin: Vec::new(),
        emacs_mode_string: Vec::new(),
        keyseq_timeout: 500,
        vi_cmd_mode_string: Vec::new(),
        vi_ins_mode_string: Vec::new(),
    },
    vi_char_search: None,
    vi_marks: [None; 256],
    vi_search_direction: -1,
    history_search_match: Vec::new(),
    noninc_search_query: Vec::new(),
    inputrc_depth: 0,
});

struct UndoSnapshot {
    line: Vec<u8>,
    point: usize,
}

#[derive(Clone, Copy)]
struct ViCharSearch {
    target: u8,
    forward: bool,
    till: bool,
}

struct EditorConfig {
    ctrl_a_macro: Vec<u8>,
    ctrl_b_backward: bool,
    tab_completes: bool,
    pending_keyseq: Vec<u8>,
    pending_input: VecDeque<c_int>,
    macro_input: VecDeque<u8>,
    kbd_macro_recording: bool,
    kbd_macro_current: Vec<u8>,
    kbd_macro_last: Vec<u8>,
    kill_buffer: Vec<u8>,
    kill_ring: Vec<Vec<u8>>,
    kill_ring_index: usize,
    retained_kills: usize,
    last_yank: Option<(usize, usize)>,
    last_was_kill: bool,
    mark: usize,
    mark_active: bool,
    saved_line: Option<Vec<u8>>,
    undo_stack: Vec<UndoSnapshot>,
    undo_group_depth: usize,
    undo_group_snapshot: Option<UndoSnapshot>,
    completion_ignore_case: bool,
    completion_map_case: bool,
    show_all_if_ambiguous: bool,
    show_all_if_unmodified: bool,
    inputrc_compat: InputrcCompatConfig,
    vi_char_search: Option<ViCharSearch>,
    vi_marks: [Option<usize>; 256],
    vi_search_direction: c_int,
    history_search_match: Vec<u8>,
    noninc_search_query: Vec<u8>,
    inputrc_depth: usize,
}

struct InputrcCompatConfig {
    bind_tty_special_chars: bool,
    byte_oriented: bool,
    echo_control_characters: bool,
    enable_active_region: bool,
    enable_keypad: bool,
    enable_meta_key: bool,
    expand_tilde: bool,
    force_meta_prefix: bool,
    history_preserve_point: bool,
    horizontal_scroll_mode: bool,
    mark_modified_lines: bool,
    menu_complete_display_prefix: bool,
    meta_flag: bool,
    page_completions: bool,
    prefer_visible_bell: bool,
    revert_all_at_newline: bool,
    search_ignore_case: bool,
    skip_completed_text: bool,
    comment_begin: Vec<u8>,
    emacs_mode_string: Vec<u8>,
    keyseq_timeout: c_int,
    vi_cmd_mode_string: Vec<u8>,
    vi_ins_mode_string: Vec<u8>,
}

static CALLBACK: Mutex<CallbackState> = Mutex::new(CallbackState {
    prompt: ptr::null_mut(),
    handler: None,
    prompt_shown: false,
    line: Vec::new(),
    point: 0,
    previous_tab_left_line_unchanged: false,
});

struct CallbackState {
    prompt: *mut c_char,
    handler: rl_callback_handler_t,
    prompt_shown: bool,
    line: Vec<u8>,
    point: usize,
    previous_tab_left_line_unchanged: bool,
}

// SAFETY:
// - CallbackState is stored behind CALLBACK, a process-global Mutex.
// - Raw pointers inside the state are only accessed while the mutex is held or
//   after ownership is detached from the state.
// - The prompt pointer, when non-null, points to an owned C allocation tracked by
//   callback install/remove paths.
unsafe impl Send for CallbackState {}

static HISTORY: Mutex<History> = Mutex::new(History {
    entries: Vec::new(),
    list: Vec::new(),
    offset: 0,
    max_entries: 0,
    stifled: false,
});

static FILENAME_COMPLETION: Mutex<GeneratorState> = Mutex::new(GeneratorState {
    key: Vec::new(),
    matches: Vec::new(),
});

static USERNAME_COMPLETION: Mutex<GeneratorState> = Mutex::new(GeneratorState {
    key: Vec::new(),
    matches: Vec::new(),
});

static HISTORY_SUBSTITUTION: Mutex<HistorySubstitution> = Mutex::new(HistorySubstitution {
    old: Vec::new(),
    new: Vec::new(),
});

static KEYMAP_REGISTRY: Mutex<Vec<usize>> = Mutex::new(Vec::new());
static FUNMAP: Mutex<Vec<(Vec<u8>, rl_command_func_t)>> = Mutex::new(Vec::new());
static SAVED_READLINE_STATES: Mutex<SavedReadlineStateStore> =
    Mutex::new(SavedReadlineStateStore {
        next_slot: 1,
        snapshots: Vec::new(),
    });
static OWNED_GLOBAL_STRINGS: Mutex<Vec<usize>> = Mutex::new(Vec::new());

struct GeneratorState {
    key: Vec<u8>,
    matches: Vec<Vec<u8>>,
}

struct HistorySubstitution {
    old: Vec<u8>,
    new: Vec<u8>,
}

#[derive(Clone)]
struct KeymapData {
    name: Option<Vec<u8>>,
    key_bindings: [rl_command_func_t; 256],
    keyseq_bindings: Vec<(Vec<u8>, rl_command_func_t)>,
    macro_bindings: Vec<(Vec<u8>, Vec<u8>)>,
    keyseq_function_index: HashMap<Vec<u8>, rl_command_func_t>,
    keyseq_macro_index: HashMap<Vec<u8>, Vec<u8>>,
    keyseq_prefix_index: HashSet<Vec<u8>>,
    tty_default_keys: [bool; 256],
}

#[derive(Clone)]
struct SavedReadlineState {
    line: Vec<u8>,
    prompt: Option<Vec<u8>>,
    point: c_int,
    end: c_int,
    mark: c_int,
    done: c_int,
    eof_found: c_int,
    pending_input: c_int,
    readline_state: c_ulong,
    current_keymap: usize,
    pending_queue: VecDeque<c_int>,
    macro_queue: VecDeque<u8>,
}

#[repr(C)]
struct ReadlineStateHandle {
    magic: c_ulong,
    slot: c_ulong,
}

struct SavedReadlineStateStore {
    next_slot: c_ulong,
    snapshots: Vec<(c_ulong, SavedReadlineState)>,
}

struct History {
    #[allow(clippy::vec_box)]
    entries: Vec<Box<HIST_ENTRY>>,
    list: Vec<*mut HIST_ENTRY>,
    offset: usize,
    max_entries: usize,
    stifled: bool,
}

// SAFETY:
// - History is stored behind HISTORY, a process-global Mutex.
// - HIST_ENTRY boxes are owned by the History value; public raw pointers are
//   borrowed views invalidated by the next mutating history operation.
// - The list mirror contains pointers into entries and is rebuilt while the
//   mutex is held.
unsafe impl Send for History {}

// SAFETY:
// - GeneratorState is stored behind a process-global Mutex.
// - It contains only owned Vec allocations and no borrowed raw pointers.
// - User hooks run outside the generator mutex, so reentrant callbacks cannot
//   observe a partially mutated generator state.
unsafe impl Send for GeneratorState {}

fn lock_editor() -> MutexGuard<'static, EditorConfig> {
    EDITOR.lock().unwrap_or_else(|poison| poison.into_inner())
}

fn lock_callback() -> MutexGuard<'static, CallbackState> {
    CALLBACK.lock().unwrap_or_else(|poison| poison.into_inner())
}

fn lock_history() -> MutexGuard<'static, History> {
    HISTORY.lock().unwrap_or_else(|poison| poison.into_inner())
}

fn lock_filename_completion() -> MutexGuard<'static, GeneratorState> {
    FILENAME_COMPLETION
        .lock()
        .unwrap_or_else(|poison| poison.into_inner())
}

fn lock_username_completion() -> MutexGuard<'static, GeneratorState> {
    USERNAME_COMPLETION
        .lock()
        .unwrap_or_else(|poison| poison.into_inner())
}

fn lock_history_substitution() -> MutexGuard<'static, HistorySubstitution> {
    HISTORY_SUBSTITUTION
        .lock()
        .unwrap_or_else(|poison| poison.into_inner())
}

fn lock_keymap_registry() -> MutexGuard<'static, Vec<usize>> {
    KEYMAP_REGISTRY
        .lock()
        .unwrap_or_else(|poison| poison.into_inner())
}

fn lock_funmap() -> MutexGuard<'static, Vec<(Vec<u8>, rl_command_func_t)>> {
    FUNMAP.lock().unwrap_or_else(|poison| poison.into_inner())
}

fn lock_saved_readline_states() -> MutexGuard<'static, SavedReadlineStateStore> {
    SAVED_READLINE_STATES
        .lock()
        .unwrap_or_else(|poison| poison.into_inner())
}

fn lock_owned_global_strings() -> MutexGuard<'static, Vec<usize>> {
    OWNED_GLOBAL_STRINGS
        .lock()
        .unwrap_or_else(|poison| poison.into_inner())
}

fn lock_saved_termios() -> MutexGuard<'static, Option<(c_int, Termios)>> {
    SAVED_TERMIOS
        .lock()
        .unwrap_or_else(|poison| poison.into_inner())
}

impl History {
    fn sync_globals(&self) {
        unsafe {
            history_length = clamp_c_int(self.entries.len());
            history_offset = clamp_c_int(self.offset);
            history_max_entries = clamp_c_int(self.max_entries);
        }
    }

    fn trim(&mut self) {
        if !self.stifled || self.max_entries == 0 {
            return;
        }
        let excess = self.entries.len().saturating_sub(self.max_entries);
        for entry in self.entries.drain(..excess) {
            unsafe { free_entry_box(entry) };
        }
        if self.offset > self.entries.len() {
            self.offset = self.entries.len();
        }
    }

    unsafe fn line_bytes(entry: &HIST_ENTRY) -> usize {
        if entry.line.is_null() {
            0
        } else {
            CStr::from_ptr(entry.line).to_bytes().len()
        }
    }

    fn total_bytes(&self) -> usize {
        self.entries
            .iter()
            .map(|entry| unsafe { Self::line_bytes(entry) })
            .sum()
    }

    fn ptr_at(&mut self, index: usize) -> *mut HIST_ENTRY {
        if index >= self.entries.len() {
            return ptr::null_mut();
        }
        &mut *self.entries[index] as *mut HIST_ENTRY
    }
}

fn clamp_c_int(value: usize) -> c_int {
    if value > c_int::MAX as usize {
        c_int::MAX
    } else {
        value as c_int
    }
}

unsafe fn dup_bytes(bytes: &[u8]) -> *mut c_char {
    let ptr = malloc(bytes.len() + 1) as *mut u8;
    if ptr.is_null() {
        return ptr::null_mut();
    }
    ptr::copy_nonoverlapping(bytes.as_ptr(), ptr, bytes.len());
    *ptr.add(bytes.len()) = 0;
    ptr as *mut c_char
}

unsafe fn dup_c_string(ptr_in: *const c_char) -> *mut c_char {
    if ptr_in.is_null() {
        return ptr::null_mut();
    }
    dup_bytes(CStr::from_ptr(ptr_in).to_bytes())
}

unsafe fn cached_variable_value(bytes: &[u8]) -> *mut c_char {
    if !VARIABLE_VALUE_STORAGE.is_null() {
        free(VARIABLE_VALUE_STORAGE as *mut c_void);
    }
    VARIABLE_VALUE_STORAGE = dup_bytes(bytes);
    VARIABLE_VALUE_STORAGE
}

unsafe fn c_string_bytes(ptr_in: *const c_char) -> Vec<u8> {
    if ptr_in.is_null() {
        Vec::new()
    } else {
        CStr::from_ptr(ptr_in).to_bytes().to_vec()
    }
}

unsafe fn take_hook_string(value: *mut c_char, borrowed: *mut c_char) -> Option<Vec<u8>> {
    if value.is_null() {
        return None;
    }
    let bytes = CStr::from_ptr(value).to_bytes().to_vec();
    if value != borrowed {
        free(value as *mut c_void);
    }
    Some(bytes)
}

fn expand_leading_tilde_path_bytes(path: &[u8]) -> Vec<u8> {
    if path == b"~" {
        return home_dir_bytes().unwrap_or_else(|| path.to_vec());
    }
    if let Some(rest) = path.strip_prefix(b"~/") {
        if let Some(mut home) = home_dir_bytes() {
            if !home.ends_with(b"/") {
                home.push(b'/');
            }
            home.extend_from_slice(rest);
            return home;
        }
    }
    path.to_vec()
}

fn io_error_status(error: io::Error) -> c_int {
    error.raw_os_error().unwrap_or(-1)
}

unsafe fn c_string_array_entry(list: *mut *mut c_char, index: usize) -> Option<Vec<u8>> {
    if list.is_null() {
        return None;
    }
    let item = *list.add(index);
    if item.is_null() {
        None
    } else {
        Some(CStr::from_ptr(item).to_bytes().to_vec())
    }
}

unsafe fn tilde_prefix_matches(input: &[u8], tilde: usize) -> bool {
    if tilde == 0 {
        return true;
    }
    let mut idx = 0usize;
    while let Some(prefix) = c_string_array_entry(tilde_additional_prefixes, idx) {
        let matched = if prefix.ends_with(b"~") {
            let len = prefix.len();
            tilde + 1 >= len && &input[tilde + 1 - len..tilde + 1] == prefix.as_slice()
        } else {
            let len = prefix.len();
            tilde >= len && &input[tilde - len..tilde] == prefix.as_slice()
        };
        if matched {
            return true;
        }
        idx += 1;
    }
    false
}

unsafe fn tilde_suffix_matches(input: &[u8], index: usize) -> bool {
    if input.get(index) == Some(&b'/') {
        return true;
    }
    let mut suffix_idx = 0usize;
    while let Some(suffix) = c_string_array_entry(tilde_additional_suffixes, suffix_idx) {
        if !suffix.is_empty() && input[index..].starts_with(&suffix) {
            return true;
        }
        suffix_idx += 1;
    }
    false
}

unsafe fn expand_tilde_user(user: &[u8], rest: &[u8]) -> Option<Vec<u8>> {
    if user.is_empty() {
        if let Some(mut home) = home_dir_bytes() {
            home.extend_from_slice(rest);
            return Some(home);
        }
        return None;
    }

    let user_ptr = dup_bytes(user);
    if user_ptr.is_null() {
        return None;
    }
    let mut expanded = None;
    if let Some(hook) = tilde_expansion_preexpansion_hook {
        let value = hook(user_ptr);
        if let Some(mut bytes) = take_hook_string(value, user_ptr) {
            bytes.extend_from_slice(rest);
            expanded = Some(bytes);
        }
    }
    if expanded.is_none() {
        let matches_current_user = std::env::var_os("USER")
            .or_else(|| std::env::var_os("LOGNAME"))
            .map(|value| PathBuf::from(value).into_os_string().into_vec())
            .is_some_and(|value| value == user);
        if matches_current_user {
            if let Some(mut home) = home_dir_bytes() {
                home.extend_from_slice(rest);
                expanded = Some(home);
            }
        }
    }
    if expanded.is_none() {
        if let Some(hook) = tilde_expansion_failure_hook {
            let value = hook(user_ptr);
            if let Some(mut bytes) = take_hook_string(value, user_ptr) {
                bytes.extend_from_slice(rest);
                expanded = Some(bytes);
            }
        }
    }
    free(user_ptr as *mut c_void);
    expanded
}

unsafe fn expand_tildes(input: &[u8]) -> Vec<u8> {
    let mut out = Vec::with_capacity(input.len());
    let mut idx = 0usize;
    while idx < input.len() {
        if input[idx] != b'~' || !tilde_prefix_matches(input, idx) {
            out.push(input[idx]);
            idx += 1;
            continue;
        }

        let user_start = idx + 1;
        let mut rest_start = user_start;
        while rest_start < input.len() && !tilde_suffix_matches(input, rest_start) {
            rest_start += 1;
        }
        let rest_end = if rest_start < input.len() {
            input.len()
        } else {
            rest_start
        };
        if let Some(expanded) =
            expand_tilde_user(&input[user_start..rest_start], &input[rest_start..rest_end])
        {
            out.extend_from_slice(&expanded);
            idx = rest_end;
        } else {
            out.push(input[idx]);
            idx += 1;
        }
    }
    out
}

fn tilde_command_range(line: &[u8], point: usize) -> Option<(usize, usize)> {
    let point = point.min(line.len());
    let start = if line.get(point) == Some(&b'~') {
        point
    } else if point > 0 && line.get(point - 1) == Some(&b'~') {
        point - 1
    } else {
        let mut word_start = point;
        while word_start > 0 && !line[word_start - 1].is_ascii_whitespace() {
            word_start -= 1;
        }
        if line.get(word_start) == Some(&b'~') {
            word_start
        } else {
            return None;
        }
    };
    let mut end = start + 1;
    while end < line.len() && !line[end].is_ascii_whitespace() {
        end += 1;
    }
    Some((start, end))
}

unsafe fn current_line_bytes() -> Vec<u8> {
    if rl_line_buffer.is_null() {
        Vec::new()
    } else {
        CStr::from_ptr(rl_line_buffer).to_bytes().to_vec()
    }
}

fn line_buffer_capacity(required: usize, current: c_int) -> usize {
    let mut capacity = if current > 0 { current as usize } else { 256 };
    if capacity < 256 {
        capacity = 256;
    }
    while capacity <= required {
        capacity = capacity.saturating_mul(2);
        if capacity <= required {
            capacity = required.saturating_add(1);
            break;
        }
    }
    capacity
}

unsafe fn replace_global_string(slot: *mut *mut c_char, value: *const c_char) {
    let new_value = dup_c_string(value);
    let old = *slot;
    if !old.is_null() && old != EMPTY_BYTES.as_ptr() as *mut c_char {
        free_owned_global_string(old);
    }
    *slot = new_value;
    mark_owned_global_string(new_value);
}

fn mark_owned_global_string(value: *mut c_char) {
    if value.is_null() {
        return;
    }
    lock_owned_global_strings().push(value as usize);
}

unsafe fn free_owned_global_string(value: *mut c_char) {
    let mut owned = lock_owned_global_strings();
    if let Some(index) = owned.iter().position(|stored| *stored == value as usize) {
        owned.swap_remove(index);
        drop(owned);
        free(value as *mut c_void);
    }
}

unsafe fn set_prompt_value(prompt: *const c_char) {
    replace_global_string(std::ptr::addr_of_mut!(rl_prompt), prompt);
    let display = if rl_prompt.is_null() {
        EMPTY_BYTES.as_ptr() as *const c_char
    } else {
        rl_prompt as *const c_char
    };
    set_display_prompt_value(display);
}

unsafe fn set_display_prompt_value(display: *const c_char) {
    replace_global_string(std::ptr::addr_of_mut!(rl_display_prompt), display);
    rl_visible_prompt_length = expanded_prompt_length(display);
}

unsafe fn set_executing_keyseq(bytes: &[u8]) {
    if !rl_executing_keyseq.is_null() {
        free_owned_global_string(rl_executing_keyseq);
    }
    rl_executing_keyseq = dup_bytes(bytes);
    if rl_executing_keyseq.is_null() {
        rl_key_sequence_length = 0;
    } else {
        mark_owned_global_string(rl_executing_keyseq);
        rl_key_sequence_length = clamp_c_int(bytes.len());
    }
}

unsafe fn expanded_prompt_length(prompt: *const c_char) -> c_int {
    if prompt.is_null() {
        return 0;
    }
    let mut visible = 0usize;
    let mut last_newline_visible = None;
    let mut hidden = false;
    for byte in CStr::from_ptr(prompt).to_bytes() {
        match *byte {
            0x01 => hidden = true,
            0x02 => hidden = false,
            _ if !hidden => {
                visible += 1;
                if *byte == b'\n' {
                    last_newline_visible = Some(visible);
                }
            }
            _ => {}
        }
    }
    clamp_c_int(last_newline_visible.unwrap_or(visible))
}

unsafe fn set_line_buffer_bytes(bytes: &[u8]) {
    let capacity = line_buffer_capacity(bytes.len(), rl_line_buffer_len);
    let current_capacity = if rl_line_buffer_len > 0 {
        rl_line_buffer_len as usize
    } else {
        0
    };
    let buffer = if rl_line_buffer.is_null() || current_capacity < capacity {
        let new_buffer = if rl_line_buffer.is_null() {
            malloc(capacity)
        } else {
            realloc(rl_line_buffer as *mut c_void, capacity)
        } as *mut u8;
        if new_buffer.is_null() {
            return;
        }
        rl_line_buffer = new_buffer as *mut c_char;
        rl_line_buffer_len = clamp_c_int(capacity);
        new_buffer
    } else {
        rl_line_buffer as *mut u8
    };
    ptr::copy_nonoverlapping(bytes.as_ptr(), buffer, bytes.len());
    *buffer.add(bytes.len()) = 0;
    rl_end = clamp_c_int(bytes.len());
    rl_point = rl_end;
}

#[allow(clippy::boxed_local)]
unsafe fn free_entry_box(entry: Box<HIST_ENTRY>) {
    if !entry.line.is_null() {
        free(entry.line as *mut c_void);
    }
    if !entry.timestamp.is_null() {
        free(entry.timestamp as *mut c_void);
    }
}

fn default_history_path_bytes() -> Vec<u8> {
    if let Some(mut home) = home_dir_bytes() {
        if !home.is_empty() {
            if !home.ends_with(b"/") {
                home.push(b'/');
            }
            home.extend_from_slice(b".history");
            return home;
        }
    }
    b".history".to_vec()
}

unsafe fn path_from_c(filename: *const c_char) -> PathBuf {
    if filename.is_null() {
        path_from_bytes(&default_history_path_bytes())
    } else {
        path_from_bytes(CStr::from_ptr(filename).to_bytes())
    }
}

#[allow(clippy::manual_c_str_literals)]
unsafe fn ensure_stdio_streams() {
    if rl_instream.is_null() {
        rl_instream = fdopen(0, b"r\0".as_ptr() as *const c_char);
    }
    if rl_outstream.is_null() {
        rl_outstream = fdopen(1, b"w\0".as_ptr() as *const c_char);
    }
}

unsafe fn output_stream() -> *mut c_void {
    ensure_stdio_streams();
    rl_outstream
}

unsafe fn output_bytes(bytes: &[u8]) {
    let stream = output_stream();
    if stream.is_null() {
        return;
    }
    let Ok(text) = CString::new(bytes) else {
        return;
    };
    let _ = fputs(text.as_ptr(), stream);
    let _ = fflush(stream);
}

unsafe fn output_raw_bytes(bytes: &[u8]) -> c_int {
    let stream = output_stream();
    if stream.is_null() {
        return 0;
    }
    let mut written = 0usize;
    for byte in bytes {
        if fputc(*byte as c_int, stream) < 0 {
            break;
        }
        written += 1;
    }
    let _ = fflush(stream);
    clamp_c_int(written)
}

unsafe fn output_repeated_byte(byte: u8, count: usize) -> c_int {
    let stream = output_stream();
    if stream.is_null() {
        return 0;
    }
    let mut written = 0usize;
    for _ in 0..count {
        if fputc(byte as c_int, stream) < 0 {
            break;
        }
        written += 1;
    }
    let _ = fflush(stream);
    clamp_c_int(written)
}

unsafe fn output_stream_is_tty() -> bool {
    let stream = output_stream();
    if stream.is_null() {
        return false;
    }
    let fd = fileno(stream);
    fd >= 0 && isatty(fd) != 0
}

fn screen_size_from_stream(stream: *mut c_void) -> Option<(c_int, c_int)> {
    if stream.is_null() {
        return None;
    }
    // SAFETY:
    // - stream is non-null and owned by the caller/global readline stream slot.
    // - fileno does not dereference any Rust pointer and only inspects FILE state.
    let fd = unsafe { fileno(stream) };
    if fd < 0 {
        return None;
    }
    let mut winsize = Winsize::zero();
    // SAFETY:
    // - &mut winsize is non-null and aligned for Winsize.
    // - winsize points to initialized memory that ioctl may overwrite.
    // - The pointer is used only for this call; no mutable alias exists.
    // - TIOCGWINSZ has a fixed struct winsize out-parameter ABI.
    let rc = unsafe { ioctl(fd, TIOCGWINSZ_IOCTL, &mut winsize as *mut Winsize) };
    if rc != 0 || winsize.ws_row == 0 || winsize.ws_col == 0 {
        return None;
    }
    Some((winsize.ws_row as c_int, winsize.ws_col as c_int - 1))
}

fn terminal_screen_size() -> Option<(c_int, c_int)> {
    // SAFETY:
    // - ensure_stdio_streams initializes null global FILE slots before use.
    // - screen_size_from_stream validates null/invalid descriptors and does not
    //   retain the raw FILE pointers after returning.
    unsafe {
        ensure_stdio_streams();
        screen_size_from_stream(rl_outstream).or_else(|| screen_size_from_stream(rl_instream))
    }
}

unsafe fn refresh_screen_size_from_terminal() -> bool {
    if let Some((rows, cols)) = terminal_screen_size() {
        SCREEN_ROWS = rows;
        SCREEN_COLS = cols;
        true
    } else {
        false
    }
}

unsafe fn input_terminal_modes() -> Option<Termios> {
    ensure_stdio_streams();
    let fd = rl_input_fd();
    let mut modes = Termios::zero();
    if tcgetattr(fd, &mut modes) == 0 {
        Some(modes)
    } else {
        None
    }
}

fn enabled_termios_char(modes: &Termios, index: usize) -> Option<u8> {
    let key = modes.storage[index];
    match key {
        0 | 0xff => None,
        _ => Some(key),
    }
}

fn bind_tty_default_key(
    keymap: &mut KeymapData,
    modes: &Termios,
    cc_index: usize,
    function: rl_command_func_t,
) {
    let Some(key) = enabled_termios_char(modes, cc_index) else {
        return;
    };
    let index = key as usize;
    keymap.key_bindings[index] = function;
    keymap.tty_default_keys[index] = true;
    keymap
        .macro_bindings
        .retain(|(existing, _)| existing.as_slice() != [key]);
}

unsafe fn output_c_string(text: *const c_char) {
    let stream = output_stream();
    if stream.is_null() || text.is_null() {
        return;
    }
    let _ = fputs(text, stream);
    let _ = fflush(stream);
}

unsafe fn output_newline() {
    let stream = output_stream();
    if stream.is_null() {
        return;
    }
    let _ = fputc(b'\n' as c_int, stream);
    let _ = fflush(stream);
}

unsafe fn ensure_builtin_keymap() -> *mut c_void {
    if BUILTIN_KEYMAP.is_null() {
        emacs_standard_keymap = allocate_keymap(Some(b"emacs"));
        emacs_meta_keymap = allocate_keymap(Some(b"emacs-meta"));
        emacs_ctlx_keymap = allocate_keymap(Some(b"emacs-ctlx"));
        vi_movement_keymap = allocate_keymap(Some(b"vi"));
        vi_insertion_keymap = allocate_keymap(Some(b"vi-insert"));
        initialize_builtin_keymaps();
        BUILTIN_KEYMAP = emacs_standard_keymap;
        CURRENT_KEYMAP = emacs_standard_keymap;
        rl_executing_keymap = emacs_standard_keymap;
        rl_binding_keymap = emacs_standard_keymap;
    }
    BUILTIN_KEYMAP
}

unsafe fn bind_builtin_key(
    map: *mut c_void,
    key: u8,
    function: unsafe extern "C" fn(c_int, c_int) -> c_int,
) {
    bind_builtin_key_command(map, key, command_from_unsafe(function));
}

unsafe fn bind_builtin_key_safe(
    map: *mut c_void,
    key: u8,
    function: extern "C" fn(c_int, c_int) -> c_int,
) {
    bind_builtin_key_command(map, key, command_from_safe(function));
}

unsafe fn bind_builtin_key_command(map: *mut c_void, key: u8, function: rl_command_func_t) {
    if let Some(keymap) = keymap_data_mut(map) {
        keymap.key_bindings[key as usize] = function;
    }
}

// Bind a multi-byte key sequence (e.g. an ESC[A arrow) in a builtin keymap.
// Mirrors how rl_bind_keyseq normalises the sequence: replace any existing
// binding for the same sequence and any macro binding.
unsafe fn bind_builtin_keyseq(
    map: *mut c_void,
    seq: &[u8],
    function: unsafe extern "C" fn(c_int, c_int) -> c_int,
) {
    bind_builtin_keyseq_command(map, seq, command_from_unsafe(function));
}

unsafe fn bind_builtin_keyseq_safe(
    map: *mut c_void,
    seq: &[u8],
    function: extern "C" fn(c_int, c_int) -> c_int,
) {
    bind_builtin_keyseq_command(map, seq, command_from_safe(function));
}

unsafe fn bind_builtin_keyseq_command(
    map: *mut c_void,
    seq: &[u8],
    function: rl_command_func_t,
) {
    if let Some(keymap) = keymap_data_mut(map) {
        let seq = seq.to_vec();
        keymap
            .keyseq_bindings
            .retain(|(existing, _)| existing != &seq);
        keymap
            .macro_bindings
            .retain(|(existing, _)| existing != &seq);
        keymap.keyseq_bindings.push((seq, function));
        rebuild_keyseq_index(keymap);
    }
}

unsafe fn initialize_builtin_keymaps() {
    for key in 0x20..=0x7e {
        bind_builtin_key(emacs_standard_keymap, key, rl_insert);
        bind_builtin_key(vi_insertion_keymap, key, rl_insert);
    }
    bind_builtin_key(emacs_standard_keymap, b'\n', rl_newline);
    bind_builtin_key(emacs_standard_keymap, b'\r', rl_newline);
    bind_builtin_key(vi_insertion_keymap, b'\n', rl_newline);
    bind_builtin_key(vi_insertion_keymap, b'\r', rl_newline);
    bind_builtin_key(vi_insertion_keymap, 0x1b, rl_vi_movement_mode);

    for key in b'1'..=b'9' {
        bind_builtin_key(vi_movement_keymap, key, rl_vi_arg_digit);
    }
    bind_builtin_key(vi_movement_keymap, b'0', rl_vi_arg_digit);
    bind_builtin_key(vi_movement_keymap, b'\n', rl_newline);
    bind_builtin_key(vi_movement_keymap, b'\r', rl_newline);
    bind_builtin_key(vi_movement_keymap, b'h', rl_backward_char);
    bind_builtin_key(vi_movement_keymap, b'l', rl_forward_char);
    bind_builtin_key(vi_movement_keymap, b' ', rl_forward_char);
    bind_builtin_key(vi_movement_keymap, b'$', rl_end_of_line);
    bind_builtin_key(vi_movement_keymap, b'^', rl_vi_first_print);
    bind_builtin_key(vi_movement_keymap, b'w', rl_vi_fword);
    bind_builtin_key(vi_movement_keymap, b'W', rl_vi_fWord);
    bind_builtin_key(vi_movement_keymap, b'b', rl_vi_bword);
    bind_builtin_key(vi_movement_keymap, b'B', rl_vi_bWord);
    bind_builtin_key(vi_movement_keymap, b'e', rl_vi_eword);
    bind_builtin_key(vi_movement_keymap, b'E', rl_vi_eWord);
    bind_builtin_key(vi_movement_keymap, b'i', rl_vi_insert_mode);
    bind_builtin_key(vi_movement_keymap, b'I', rl_vi_insert_beg);
    bind_builtin_key(vi_movement_keymap, b'a', rl_vi_append_mode);
    bind_builtin_key(vi_movement_keymap, b'A', rl_vi_append_eol);
    bind_builtin_key(vi_movement_keymap, b'x', rl_vi_delete);
    bind_builtin_key(vi_movement_keymap, b'X', rl_vi_rubout);
    bind_builtin_key(vi_movement_keymap, b'd', rl_vi_delete_to);
    bind_builtin_key(vi_movement_keymap, b'c', rl_vi_change_to);
    bind_builtin_key(vi_movement_keymap, b'y', rl_vi_yank_to);
    bind_builtin_key(vi_movement_keymap, b'Y', rl_vi_yank_to);
    bind_builtin_key(vi_movement_keymap, b'D', rl_kill_line);
    bind_builtin_key(vi_movement_keymap, b'C', rl_vi_change_to);
    bind_builtin_key(vi_movement_keymap, b'p', rl_vi_put);
    bind_builtin_key(vi_movement_keymap, b'P', rl_vi_put);
    bind_builtin_key(vi_movement_keymap, b'r', rl_vi_change_char);
    bind_builtin_key(vi_movement_keymap, b'R', rl_vi_replace);
    bind_builtin_key(vi_movement_keymap, b's', rl_vi_subst);
    bind_builtin_key(vi_movement_keymap, b'f', rl_vi_char_search);
    bind_builtin_key(vi_movement_keymap, b'F', rl_vi_char_search);
    bind_builtin_key(vi_movement_keymap, b't', rl_vi_char_search);
    bind_builtin_key(vi_movement_keymap, b'T', rl_vi_char_search);
    bind_builtin_key(vi_movement_keymap, b';', rl_vi_char_search);
    bind_builtin_key(vi_movement_keymap, b',', rl_vi_char_search);
    bind_builtin_key(vi_movement_keymap, b'%', rl_vi_match);
    bind_builtin_key(vi_movement_keymap, b'm', rl_vi_set_mark);
    bind_builtin_key(vi_movement_keymap, b'`', rl_vi_goto_mark);
    bind_builtin_key(vi_movement_keymap, b'\'', rl_vi_goto_mark);
    bind_builtin_key(vi_movement_keymap, b'/', rl_vi_search);
    bind_builtin_key(vi_movement_keymap, b'?', rl_vi_search);
    bind_builtin_key(vi_movement_keymap, b'n', rl_vi_search_again);
    bind_builtin_key(vi_movement_keymap, b'N', rl_vi_search_again);

    install_default_emacs_bindings();
}

// Default key bindings for the emacs standard keymap, matching the set
// any modern terminal user expects from a readline-driven REPL:
//   * Ctrl-A/E/B/F/D/H/K/L/N/P/T/U/W/Y/^/_, DEL, Tab
//   * Arrow keys (and their alternative \eO encodings)
//   * Home / End / Insert / Delete / PgUp / PgDn (DEC and xterm flavours)
//   * Meta-{b,f,d,DEL,.,_,t,u,l,c}
//   * Ctrl-X Ctrl-{E,R,U,V}, Ctrl-X (
//
// GNU readline installs these by default once the emacs keymap is built.
// Without them, an interactive REPL (CPython's PYTHON_BASIC_REPL, m4,
// brash, etc.) would not respond to arrow keys or familiar emacs chords
// because the keymap would be empty above U+007E with no escape-sequence
// bindings to consume ESC-prefixed sequences.
unsafe fn install_default_emacs_bindings() {
    let map = emacs_standard_keymap;

    // Single-byte control keys (Ctrl-A .. Ctrl-_).
    bind_builtin_key(map, 0x01, rl_beg_of_line);            // Ctrl-A
    bind_builtin_key(map, 0x02, rl_backward_char);          // Ctrl-B
    bind_builtin_key(map, 0x04, rl_delete);                 // Ctrl-D
    bind_builtin_key(map, 0x05, rl_end_of_line);            // Ctrl-E
    bind_builtin_key(map, 0x06, rl_forward_char);           // Ctrl-F
    bind_builtin_key_safe(map, 0x07, rl_abort);             // Ctrl-G
    bind_builtin_key(map, 0x08, rl_rubout);                 // Ctrl-H (Backspace)
    bind_builtin_key(map, 0x09, rl_complete);               // Tab
    // Ctrl-J/M (\n, \r) remain rl_newline from earlier loop.
    bind_builtin_key(map, 0x0b, rl_kill_line);              // Ctrl-K
    bind_builtin_key_safe(map, 0x0c, rl_clear_screen);      // Ctrl-L
    bind_builtin_key_safe(map, 0x0e, rl_get_next_history);  // Ctrl-N
    bind_builtin_key_safe(map, 0x10, rl_get_previous_history); // Ctrl-P
    bind_builtin_key(map, 0x12, rl_reverse_search_history); // Ctrl-R
    bind_builtin_key(map, 0x13, rl_forward_search_history); // Ctrl-S
    bind_builtin_key(map, 0x14, rl_transpose_chars);        // Ctrl-T
    bind_builtin_key(map, 0x15, rl_unix_line_discard);      // Ctrl-U
    bind_builtin_key(map, 0x16, rl_quoted_insert);          // Ctrl-V
    bind_builtin_key(map, 0x17, rl_unix_word_rubout);       // Ctrl-W
    bind_builtin_key(map, 0x19, rl_yank);                   // Ctrl-Y
    bind_builtin_key(map, 0x1a, rl_undo_command);           // Ctrl-Z (undo)
    bind_builtin_key(map, 0x1f, rl_undo_command);           // Ctrl-_
    bind_builtin_key(map, 0x7f, rl_rubout);                 // DEL

    // Escape sequences for arrow keys and friends. xterm/VT100 ship two
    // encodings: CSI (\e[) and SS3 (\eO); we bind both.
    bind_builtin_keyseq_safe(map, b"\x1b[A", rl_get_previous_history);
    bind_builtin_keyseq_safe(map, b"\x1b[B", rl_get_next_history);
    bind_builtin_keyseq(map, b"\x1b[C", rl_forward_char);
    bind_builtin_keyseq(map, b"\x1b[D", rl_backward_char);
    bind_builtin_keyseq_safe(map, b"\x1bOA", rl_get_previous_history);
    bind_builtin_keyseq_safe(map, b"\x1bOB", rl_get_next_history);
    bind_builtin_keyseq(map, b"\x1bOC", rl_forward_char);
    bind_builtin_keyseq(map, b"\x1bOD", rl_backward_char);

    // Home / End in their two common encodings.
    bind_builtin_keyseq(map, b"\x1b[H", rl_beg_of_line);
    bind_builtin_keyseq(map, b"\x1b[F", rl_end_of_line);
    bind_builtin_keyseq(map, b"\x1bOH", rl_beg_of_line);
    bind_builtin_keyseq(map, b"\x1bOF", rl_end_of_line);
    bind_builtin_keyseq(map, b"\x1b[1~", rl_beg_of_line);
    bind_builtin_keyseq(map, b"\x1b[7~", rl_beg_of_line);
    bind_builtin_keyseq(map, b"\x1b[4~", rl_end_of_line);
    bind_builtin_keyseq(map, b"\x1b[8~", rl_end_of_line);

    // Delete / Insert / PgUp / PgDn.
    bind_builtin_keyseq(map, b"\x1b[3~", rl_delete);
    bind_builtin_keyseq_safe(map, b"\x1b[2~", rl_overwrite_mode);
    bind_builtin_keyseq(map, b"\x1b[5~", rl_history_search_backward);
    bind_builtin_keyseq(map, b"\x1b[6~", rl_history_search_forward);

    // Meta-prefixed word-motion / line-editing commands.
    bind_builtin_keyseq(map, b"\x1bf", rl_forward_word);
    bind_builtin_keyseq(map, b"\x1bF", rl_forward_word);
    bind_builtin_keyseq(map, b"\x1bb", rl_backward_word);
    bind_builtin_keyseq(map, b"\x1bB", rl_backward_word);
    bind_builtin_keyseq(map, b"\x1bd", rl_kill_word);
    bind_builtin_keyseq(map, b"\x1bD", rl_kill_word);
    bind_builtin_keyseq(map, b"\x1b\x7f", rl_backward_kill_word);
    bind_builtin_keyseq(map, b"\x1b\x08", rl_backward_kill_word);
    bind_builtin_keyseq(map, b"\x1bt", rl_transpose_words);
    bind_builtin_keyseq(map, b"\x1bu", rl_upcase_word);
    bind_builtin_keyseq(map, b"\x1bl", rl_downcase_word);
    bind_builtin_keyseq(map, b"\x1bc", rl_capitalize_word);
    bind_builtin_keyseq_safe(map, b"\x1b-", rl_digit_argument);
    for digit in b'0'..=b'9' {
        bind_builtin_keyseq_safe(map, &[0x1b, digit], rl_digit_argument);
    }
    bind_builtin_keyseq(map, b"\x1b.", rl_yank_last_arg);
    bind_builtin_keyseq(map, b"\x1b_", rl_yank_last_arg);

    // Ctrl-X two-key sequences.
    bind_builtin_keyseq(map, b"\x18\x05", rl_call_last_kbd_macro);
    bind_builtin_keyseq_safe(map, b"\x18(", rl_start_kbd_macro);
    bind_builtin_keyseq_safe(map, b"\x18)", rl_end_kbd_macro);
    bind_builtin_keyseq(map, b"\x18\x12", rl_re_read_init_file);
    bind_builtin_keyseq(map, b"\x18\x15", rl_undo_command);
    bind_builtin_keyseq(map, b"\x18\x16", rl_quoted_insert);
}

fn add_keyseq_prefixes(prefixes: &mut HashSet<Vec<u8>>, seq: &[u8]) {
    for end in 1..seq.len() {
        prefixes.insert(seq[..end].to_vec());
    }
}

fn rebuild_keyseq_index(keymap: &mut KeymapData) {
    keymap.keyseq_function_index.clear();
    keymap.keyseq_macro_index.clear();
    keymap.keyseq_prefix_index.clear();
    for (seq, function) in &keymap.keyseq_bindings {
        if !seq.is_empty() {
            keymap.keyseq_function_index.insert(seq.clone(), *function);
            add_keyseq_prefixes(&mut keymap.keyseq_prefix_index, seq);
        }
    }
    for (seq, bytes) in &keymap.macro_bindings {
        if !seq.is_empty() {
            keymap.keyseq_macro_index.insert(seq.clone(), bytes.clone());
            add_keyseq_prefixes(&mut keymap.keyseq_prefix_index, seq);
        }
    }
}

unsafe fn allocate_keymap(name: Option<&[u8]>) -> *mut c_void {
    let map = Box::into_raw(Box::new(KeymapData {
        name: name.map(|name| name.to_vec()),
        key_bindings: [None; 256],
        keyseq_bindings: Vec::new(),
        macro_bindings: Vec::new(),
        keyseq_function_index: HashMap::new(),
        keyseq_macro_index: HashMap::new(),
        keyseq_prefix_index: HashSet::new(),
        tty_default_keys: [false; 256],
    })) as *mut c_void;
    lock_keymap_registry().push(map as usize);
    map
}

fn keymap_registered(map: *mut c_void) -> bool {
    !map.is_null() && lock_keymap_registry().contains(&(map as usize))
}

unsafe fn is_builtin_keymap(map: *mut c_void) -> bool {
    ensure_builtin_keymap();
    map == emacs_standard_keymap
        || map == emacs_meta_keymap
        || map == emacs_ctlx_keymap
        || map == vi_movement_keymap
        || map == vi_insertion_keymap
}

unsafe fn normalize_keymap(map: *mut c_void) -> *mut c_void {
    if map.is_null() {
        if CURRENT_KEYMAP.is_null() {
            ensure_builtin_keymap()
        } else {
            CURRENT_KEYMAP
        }
    } else {
        map
    }
}

unsafe fn keymap_data_mut(map: *mut c_void) -> Option<&'static mut KeymapData> {
    let map = normalize_keymap(map);
    if !keymap_registered(map) {
        None
    } else {
        Some(&mut *(map as *mut KeymapData))
    }
}

unsafe fn keymap_data(map: *mut c_void) -> Option<&'static KeymapData> {
    let map = normalize_keymap(map);
    if !keymap_registered(map) {
        None
    } else {
        Some(&*(map as *const KeymapData))
    }
}

unsafe fn keymap_name_bytes(map: *mut c_void) -> Option<Vec<u8>> {
    keymap_data(map).and_then(|keymap| keymap.name.clone())
}

fn same_command(left: rl_command_func_t, right: rl_command_func_t) -> bool {
    match (left, right) {
        (Some(left), Some(right)) => left as *const () == right as *const (),
        (None, None) => true,
        _ => false,
    }
}

fn keyseq_display_bytes(seq: &[u8]) -> Vec<u8> {
    let mut out = Vec::new();
    let mut idx = 0usize;
    while idx < seq.len() {
        if seq[idx] == 0x1b && idx + 1 < seq.len() {
            out.extend_from_slice(b"\\M-");
            out.push(seq[idx + 1]);
            idx += 2;
            continue;
        }
        let byte = seq[idx];
        if byte < 0x20 {
            out.extend_from_slice(b"\\C-");
            out.push((byte | 0x40).to_ascii_lowercase());
        } else if byte == 0x7f {
            out.extend_from_slice(b"\\C-?");
        } else if matches!(byte, b'\\' | b'"') {
            out.push(b'\\');
            out.push(byte);
        } else {
            out.push(byte);
        }
        idx += 1;
    }
    out
}

unsafe fn enqueue_macro_input(bytes: &[u8]) {
    if !rl_executing_macro.is_null() {
        free(rl_executing_macro as *mut c_void);
    }
    rl_executing_macro = dup_bytes(bytes);
    let mut editor = lock_editor();
    editor.macro_input.clear();
    editor.macro_input.extend(bytes.iter().copied());
}

fn record_kbd_macro_key(key: c_int) {
    if !(0..=u8::MAX as c_int).contains(&key) {
        return;
    }
    record_kbd_macro_bytes(&[key as u8]);
}

fn record_kbd_macro_bytes(bytes: &[u8]) {
    let mut editor = lock_editor();
    if editor.kbd_macro_recording {
        editor.kbd_macro_current.extend_from_slice(bytes);
    }
}

unsafe fn bind_macro_in_map(seq: Vec<u8>, bytes: Vec<u8>, map: *mut c_void) -> c_int {
    let Some(keymap) = keymap_data_mut(map) else {
        return -1;
    };
    if seq.len() == 1 {
        keymap.key_bindings[seq[0] as usize] = None;
    }
    keymap
        .keyseq_bindings
        .retain(|(existing, _)| existing != &seq);
    keymap
        .macro_bindings
        .retain(|(existing, _)| existing != &seq);
    keymap.macro_bindings.push((seq, bytes));
    rebuild_keyseq_index(keymap);
    0
}

fn contains_bytes(haystack: &[u8], needle: &[u8]) -> bool {
    if needle.is_empty() {
        return true;
    }
    haystack
        .windows(needle.len())
        .any(|window| window == needle)
}

fn ascii_byte_eq(left: u8, right: u8, ignore_case: bool) -> bool {
    if ignore_case {
        left.eq_ignore_ascii_case(&right)
    } else {
        left == right
    }
}

fn completion_byte_eq(left: u8, right: u8, ignore_case: bool, map_case: bool) -> bool {
    if map_case && matches!((left, right), (b'-', b'_') | (b'_', b'-')) {
        true
    } else {
        ascii_byte_eq(left, right, ignore_case)
    }
}

fn byte_starts_with(value: &[u8], prefix: &[u8], ignore_case: bool, map_case: bool) -> bool {
    value.len() >= prefix.len()
        && value
            .iter()
            .zip(prefix.iter())
            .all(|(left, right)| completion_byte_eq(*left, *right, ignore_case, map_case))
}

fn parse_decimal_after(bytes: &[u8], marker: &[u8]) -> Option<c_int> {
    let start = bytes
        .windows(marker.len())
        .position(|window| window == marker)?;
    let mut idx = start + marker.len();
    while idx < bytes.len() && bytes[idx].is_ascii_whitespace() {
        idx += 1;
    }
    let value_start = idx;
    while idx < bytes.len() && bytes[idx].is_ascii_digit() {
        idx += 1;
    }
    if idx == value_start {
        return None;
    }
    std::str::from_utf8(&bytes[value_start..idx])
        .ok()
        .and_then(|value| value.parse::<c_int>().ok())
}

fn unescape_binding_bytes(bytes: &[u8]) -> Vec<u8> {
    let mut out = Vec::with_capacity(bytes.len());
    let mut idx = 0;
    while idx < bytes.len() {
        if bytes[idx] != b'\\' || idx + 1 >= bytes.len() {
            out.push(bytes[idx]);
            idx += 1;
            continue;
        }

        idx += 1;
        match bytes[idx] {
            b'a' => out.push(0x07),
            b'b' => out.push(0x08),
            b'e' | b'E' => out.push(0x1b),
            b'f' => out.push(0x0c),
            b'n' => out.push(b'\n'),
            b'r' => out.push(b'\r'),
            b't' => out.push(b'\t'),
            b'v' => out.push(0x0b),
            b'\\' => out.push(b'\\'),
            b'"' => out.push(b'"'),
            b'0'..=b'7' => {
                let mut value = bytes[idx] - b'0';
                let mut consumed = 1;
                while consumed < 3
                    && idx + consumed < bytes.len()
                    && (b'0'..=b'7').contains(&bytes[idx + consumed])
                {
                    value = value
                        .saturating_mul(8)
                        .saturating_add(bytes[idx + consumed] - b'0');
                    consumed += 1;
                }
                out.push(value);
                idx += consumed - 1;
            }
            other => out.push(other),
        }
        idx += 1;
    }
    out
}

fn control_byte(byte: u8) -> u8 {
    byte.to_ascii_uppercase() & 0x1f
}

fn parse_keyseq_bytes(bytes: &[u8]) -> Vec<u8> {
    let mut out = Vec::new();
    let mut idx = 0;
    while idx < bytes.len() {
        if bytes[idx] == b'^' && idx + 1 < bytes.len() {
            out.push(control_byte(bytes[idx + 1]));
            idx += 2;
            continue;
        }
        if bytes[idx] != b'\\' || idx + 1 >= bytes.len() {
            out.push(bytes[idx]);
            idx += 1;
            continue;
        }

        idx += 1;
        match bytes[idx] {
            b'C' | b'c' if idx + 2 < bytes.len() && bytes[idx + 1] == b'-' => {
                out.push(control_byte(bytes[idx + 2]));
                idx += 3;
            }
            b'M' | b'm' if idx + 2 < bytes.len() && bytes[idx + 1] == b'-' => {
                out.push(0x1b);
                out.push(bytes[idx + 2]);
                idx += 3;
            }
            b'x' if idx + 2 < bytes.len() => {
                let hi = bytes[idx + 1];
                let lo = bytes[idx + 2];
                let value = (hi as char)
                    .to_digit(16)
                    .zip((lo as char).to_digit(16))
                    .map(|(hi, lo)| ((hi << 4) | lo) as u8);
                if let Some(value) = value {
                    out.push(value);
                    idx += 3;
                } else {
                    out.push(bytes[idx]);
                    idx += 1;
                }
            }
            other => {
                out.extend_from_slice(&unescape_binding_bytes(&bytes[idx - 1..=idx]));
                if other == b'0' || (b'1'..=b'7').contains(&other) {
                    idx += 1;
                    while idx < bytes.len() && (b'0'..=b'7').contains(&bytes[idx]) {
                        idx += 1;
                    }
                } else {
                    idx += 1;
                }
            }
        }
    }
    out
}

fn quoted_binding_value(bytes: &[u8]) -> Option<Vec<u8>> {
    let mut start = None;
    let mut idx = 0;
    while idx < bytes.len() {
        if bytes[idx] == b'"' {
            start = Some(idx + 1);
            break;
        }
        idx += 1;
    }
    let start = start?;
    let mut escaped = false;
    idx = start;
    while idx < bytes.len() {
        if escaped {
            escaped = false;
        } else if bytes[idx] == b'\\' {
            escaped = true;
        } else if bytes[idx] == b'"' {
            return Some(unescape_binding_bytes(&bytes[start..idx]));
        }
        idx += 1;
    }
    None
}

fn inputrc_unquote_token(bytes: &[u8]) -> Vec<u8> {
    let bytes = bytes.trim_ascii();
    let Some((&quote, rest)) = bytes.split_first() else {
        return Vec::new();
    };
    if quote != b'"' && quote != b'\'' {
        return bytes.to_vec();
    }

    let mut escaped = false;
    let mut idx = 0usize;
    while idx < rest.len() {
        let byte = rest[idx];
        if escaped {
            escaped = false;
        } else if byte == b'\\' {
            escaped = true;
        } else if byte == quote {
            return unescape_binding_bytes(&rest[..idx]);
        }
        idx += 1;
    }
    bytes.to_vec()
}

fn previous_char_boundary(bytes: &[u8], point: usize) -> usize {
    let mut idx = point.min(bytes.len());
    if idx == 0 {
        return 0;
    }
    idx -= 1;
    while idx > 0 && (bytes[idx] & 0xc0) == 0x80 {
        idx -= 1;
    }
    idx
}

fn next_char_boundary(bytes: &[u8], point: usize) -> usize {
    let mut idx = point.min(bytes.len());
    if idx >= bytes.len() {
        return bytes.len();
    }
    idx += 1;
    while idx < bytes.len() && (bytes[idx] & 0xc0) == 0x80 {
        idx += 1;
    }
    idx
}

fn insert_bytes(line: &mut Vec<u8>, point: &mut usize, bytes: &[u8]) {
    let idx = (*point).min(line.len());
    line.splice(idx..idx, bytes.iter().copied());
    *point = idx + bytes.len();
}

fn word_byte(byte: u8) -> bool {
    byte.is_ascii_alphanumeric() || byte == b'_'
}

fn filename_word_byte(byte: u8) -> bool {
    !byte.is_ascii_whitespace() && byte != b'/'
}

fn vi_big_word_byte(byte: u8) -> bool {
    !byte.is_ascii_whitespace()
}

fn previous_word_start(bytes: &[u8], point: usize) -> usize {
    let mut idx = point.min(bytes.len());
    while idx > 0 && !word_byte(bytes[idx - 1]) {
        idx -= 1;
    }
    while idx > 0 && word_byte(bytes[idx - 1]) {
        idx -= 1;
    }
    idx
}

fn previous_big_word_start(bytes: &[u8], point: usize) -> usize {
    let mut idx = point.min(bytes.len());
    while idx > 0 && !vi_big_word_byte(bytes[idx - 1]) {
        idx -= 1;
    }
    while idx > 0 && vi_big_word_byte(bytes[idx - 1]) {
        idx -= 1;
    }
    idx
}

fn next_word_end(bytes: &[u8], point: usize) -> usize {
    let mut idx = point.min(bytes.len());
    while idx < bytes.len() && !word_byte(bytes[idx]) {
        idx += 1;
    }
    while idx < bytes.len() && word_byte(bytes[idx]) {
        idx += 1;
    }
    idx
}

fn next_big_word_end(bytes: &[u8], point: usize) -> usize {
    let mut idx = point.min(bytes.len());
    while idx < bytes.len() && !vi_big_word_byte(bytes[idx]) {
        idx += 1;
    }
    while idx < bytes.len() && vi_big_word_byte(bytes[idx]) {
        idx += 1;
    }
    idx
}

fn next_word_start(bytes: &[u8], point: usize) -> usize {
    let mut idx = next_word_end(bytes, point);
    while idx < bytes.len() && !word_byte(bytes[idx]) {
        idx += 1;
    }
    idx
}

fn copy_forward_word_bounds(bytes: &[u8], point: usize, count: c_int) -> (usize, usize) {
    let mut remaining = count.max(1);
    let mut start = point.min(bytes.len());
    while start < bytes.len() && !word_byte(bytes[start]) {
        start += 1;
    }
    let mut end = start;
    while remaining > 0 {
        while end < bytes.len() && word_byte(bytes[end]) {
            end += 1;
        }
        remaining -= 1;
        if remaining == 0 {
            break;
        }

        let word_end = end;
        while end < bytes.len() && !word_byte(bytes[end]) {
            end += 1;
        }
        if end == bytes.len() {
            end = word_end;
            break;
        }
    }
    (start, end)
}

fn copy_backward_word_bounds(bytes: &[u8], point: usize, count: c_int) -> (usize, usize) {
    let count = count.max(1);
    let mut start = point.min(bytes.len());
    for _ in 0..count {
        let next = previous_word_start(bytes, start);
        if next == start {
            break;
        }
        start = next;
    }
    copy_forward_word_bounds(bytes, start, count)
}

fn next_big_word_start(bytes: &[u8], point: usize) -> usize {
    let mut idx = next_big_word_end(bytes, point);
    while idx < bytes.len() && !vi_big_word_byte(bytes[idx]) {
        idx += 1;
    }
    idx
}

fn previous_filename_word_start(bytes: &[u8], point: usize) -> usize {
    let mut idx = point.min(bytes.len());
    while idx > 0 && !filename_word_byte(bytes[idx - 1]) {
        idx -= 1;
    }
    while idx > 0 && filename_word_byte(bytes[idx - 1]) {
        idx -= 1;
    }
    idx
}

unsafe fn current_point() -> usize {
    if rl_point < 0 {
        0
    } else {
        (rl_point as usize).min(current_line_bytes().len())
    }
}

unsafe fn set_point(point: usize) {
    rl_point = clamp_c_int(point.min(current_line_bytes().len()));
}

unsafe fn save_undo_snapshot() {
    let snapshot = current_undo_snapshot();
    let mut editor = lock_editor();
    if editor.undo_group_depth > 0 {
        if editor.undo_group_snapshot.is_none() {
            editor.undo_group_snapshot = Some(snapshot);
        }
        return;
    }
    push_undo_snapshot(&mut editor, snapshot);
}

unsafe fn current_undo_snapshot() -> UndoSnapshot {
    UndoSnapshot {
        line: current_line_bytes(),
        point: current_point(),
    }
}

fn push_undo_snapshot(editor: &mut EditorConfig, snapshot: UndoSnapshot) {
    editor.undo_stack.push(snapshot);
    if editor.undo_stack.len() > 64 {
        let _ = editor.undo_stack.remove(0);
    }
}

unsafe fn set_kill_buffer(bytes: &[u8], prepend: bool, append: bool) {
    let mut editor = lock_editor();
    let mut kill = if prepend {
        let mut merged = bytes.to_vec();
        merged.extend_from_slice(&editor.kill_buffer);
        merged
    } else if append {
        let mut merged = editor.kill_buffer.clone();
        merged.extend_from_slice(bytes);
        merged
    } else {
        bytes.to_vec()
    };
    editor.kill_buffer = kill.clone();
    editor.last_yank = None;

    if kill.is_empty() {
        return;
    }
    if (prepend || append) && !editor.kill_ring.is_empty() {
        let index = editor.kill_ring_index.min(editor.kill_ring.len() - 1);
        editor.kill_ring[index] = kill;
        editor.kill_ring_index = index;
        return;
    }

    editor.kill_ring.insert(0, std::mem::take(&mut kill));
    editor.kill_ring_index = 0;
    let limit = editor.retained_kills.max(1);
    if editor.kill_ring.len() > limit {
        editor.kill_ring.truncate(limit);
    }
}

fn mark_last_kill(value: bool) {
    let mut editor = lock_editor();
    editor.last_was_kill = value;
    if !value {
        editor.last_yank = None;
    }
}

fn last_was_kill() -> bool {
    lock_editor().last_was_kill
}

fn inputrc_bool(value: &[u8]) -> bool {
    value.is_empty() || value.eq_ignore_ascii_case(b"on") || value == b"1"
}

fn inputrc_on_off_bytes(enabled: bool) -> &'static [u8] {
    if enabled {
        b"on"
    } else {
        b"off"
    }
}

fn inputrc_parse_int(value: &[u8]) -> c_int {
    std::str::from_utf8(value)
        .ok()
        .and_then(|value| value.trim().parse::<c_int>().ok())
        .unwrap_or(0)
}

fn inputrc_or_default_bytes(value: &[u8], default: &'static [u8]) -> Vec<u8> {
    if value.is_empty() {
        default.to_vec()
    } else {
        value.to_vec()
    }
}

enum InputrcCompatValue {
    Bool(bool),
    Bytes(Vec<u8>),
    Int(c_int),
}

fn bind_inputrc_compat_variable(variable: &[u8], value: &[u8]) -> bool {
    let mut editor = lock_editor();
    let compat = &mut editor.inputrc_compat;
    match variable {
        b"bind-tty-special-chars" => compat.bind_tty_special_chars = inputrc_bool(value),
        b"byte-oriented" => compat.byte_oriented = inputrc_bool(value),
        b"echo-control-characters" => compat.echo_control_characters = inputrc_bool(value),
        b"enable-active-region" => compat.enable_active_region = inputrc_bool(value),
        b"enable-keypad" => compat.enable_keypad = inputrc_bool(value),
        b"enable-meta-key" => compat.enable_meta_key = inputrc_bool(value),
        b"expand-tilde" => compat.expand_tilde = inputrc_bool(value),
        b"force-meta-prefix" => compat.force_meta_prefix = inputrc_bool(value),
        b"history-preserve-point" => compat.history_preserve_point = inputrc_bool(value),
        b"horizontal-scroll-mode" => compat.horizontal_scroll_mode = inputrc_bool(value),
        b"mark-modified-lines" => compat.mark_modified_lines = inputrc_bool(value),
        b"menu-complete-display-prefix" => {
            compat.menu_complete_display_prefix = inputrc_bool(value)
        }
        b"meta-flag" => compat.meta_flag = inputrc_bool(value),
        b"page-completions" => compat.page_completions = inputrc_bool(value),
        b"prefer-visible-bell" => compat.prefer_visible_bell = inputrc_bool(value),
        b"revert-all-at-newline" => compat.revert_all_at_newline = inputrc_bool(value),
        b"search-ignore-case" => compat.search_ignore_case = inputrc_bool(value),
        b"skip-completed-text" => compat.skip_completed_text = inputrc_bool(value),
        b"comment-begin" if !value.is_empty() => compat.comment_begin = value.to_vec(),
        b"comment-begin" => return false,
        b"emacs-mode-string" => compat.emacs_mode_string = value.to_vec(),
        b"keyseq-timeout" => compat.keyseq_timeout = inputrc_parse_int(value),
        b"vi-cmd-mode-string" => compat.vi_cmd_mode_string = value.to_vec(),
        b"vi-ins-mode-string" => compat.vi_ins_mode_string = value.to_vec(),
        _ => return false,
    }
    true
}

fn inputrc_compat_variable_value(variable: &[u8]) -> Option<InputrcCompatValue> {
    let editor = lock_editor();
    let compat = &editor.inputrc_compat;
    let value = match variable {
        b"bind-tty-special-chars" => InputrcCompatValue::Bool(compat.bind_tty_special_chars),
        b"byte-oriented" => InputrcCompatValue::Bool(compat.byte_oriented),
        b"echo-control-characters" => InputrcCompatValue::Bool(compat.echo_control_characters),
        b"enable-active-region" => InputrcCompatValue::Bool(compat.enable_active_region),
        b"enable-keypad" => InputrcCompatValue::Bool(compat.enable_keypad),
        b"enable-meta-key" => InputrcCompatValue::Bool(compat.enable_meta_key),
        b"expand-tilde" => InputrcCompatValue::Bool(compat.expand_tilde),
        b"force-meta-prefix" => InputrcCompatValue::Bool(compat.force_meta_prefix),
        b"history-preserve-point" => InputrcCompatValue::Bool(compat.history_preserve_point),
        b"horizontal-scroll-mode" => InputrcCompatValue::Bool(compat.horizontal_scroll_mode),
        b"mark-modified-lines" => InputrcCompatValue::Bool(compat.mark_modified_lines),
        b"menu-complete-display-prefix" => {
            InputrcCompatValue::Bool(compat.menu_complete_display_prefix)
        }
        b"meta-flag" => InputrcCompatValue::Bool(compat.meta_flag),
        b"page-completions" => InputrcCompatValue::Bool(compat.page_completions),
        b"prefer-visible-bell" => InputrcCompatValue::Bool(compat.prefer_visible_bell),
        b"revert-all-at-newline" => InputrcCompatValue::Bool(compat.revert_all_at_newline),
        b"search-ignore-case" => InputrcCompatValue::Bool(compat.search_ignore_case),
        b"skip-completed-text" => InputrcCompatValue::Bool(compat.skip_completed_text),
        b"comment-begin" => {
            InputrcCompatValue::Bytes(inputrc_or_default_bytes(&compat.comment_begin, b"#"))
        }
        b"emacs-mode-string" => {
            InputrcCompatValue::Bytes(inputrc_or_default_bytes(&compat.emacs_mode_string, b"@"))
        }
        b"keyseq-timeout" => InputrcCompatValue::Int(compat.keyseq_timeout),
        b"vi-cmd-mode-string" => InputrcCompatValue::Bytes(inputrc_or_default_bytes(
            &compat.vi_cmd_mode_string,
            b"(cmd)",
        )),
        b"vi-ins-mode-string" => InputrcCompatValue::Bytes(inputrc_or_default_bytes(
            &compat.vi_ins_mode_string,
            b"(ins)",
        )),
        _ => return None,
    };
    Some(value)
}

fn inputrc_comment_begin_bytes() -> Vec<u8> {
    match inputrc_compat_variable_value(b"comment-begin") {
        Some(InputrcCompatValue::Bytes(bytes)) => bytes,
        _ => b"#".to_vec(),
    }
}

unsafe fn dump_inputrc_compat_line(name: &[u8], value: InputrcCompatValue, readable: bool) {
    match value {
        InputrcCompatValue::Bool(enabled) => {
            dump_variable_line(name, inputrc_on_off_bytes(enabled), readable)
        }
        InputrcCompatValue::Bytes(bytes) => dump_variable_line(name, &bytes, readable),
        InputrcCompatValue::Int(value) => {
            dump_variable_line(name, format!("{value}").as_bytes(), readable)
        }
    }
}

unsafe fn dump_inputrc_compat_variables(readable: bool) {
    for name in [
        b"bind-tty-special-chars".as_slice(),
        b"byte-oriented".as_slice(),
        b"echo-control-characters".as_slice(),
        b"enable-active-region".as_slice(),
        b"enable-keypad".as_slice(),
        b"enable-meta-key".as_slice(),
        b"expand-tilde".as_slice(),
        b"force-meta-prefix".as_slice(),
        b"history-preserve-point".as_slice(),
        b"horizontal-scroll-mode".as_slice(),
        b"mark-modified-lines".as_slice(),
        b"menu-complete-display-prefix".as_slice(),
        b"meta-flag".as_slice(),
        b"page-completions".as_slice(),
        b"prefer-visible-bell".as_slice(),
        b"revert-all-at-newline".as_slice(),
        b"search-ignore-case".as_slice(),
        b"skip-completed-text".as_slice(),
        b"comment-begin".as_slice(),
        b"emacs-mode-string".as_slice(),
        b"keyseq-timeout".as_slice(),
        b"vi-cmd-mode-string".as_slice(),
        b"vi-ins-mode-string".as_slice(),
    ] {
        if let Some(value) = inputrc_compat_variable_value(name) {
            dump_inputrc_compat_line(name, value, readable);
        }
    }
}

unsafe fn command_count() -> c_int {
    if rl_explicit_arg != 0 {
        rl_numeric_arg.saturating_mul(rl_arg_sign)
    } else {
        1
    }
}

unsafe fn reset_numeric_arg() {
    rl_numeric_arg = 1;
    rl_explicit_arg = 0;
    rl_arg_sign = 1;
    NUMERIC_ARG_HAS_DIGITS = 0;
}

fn preserves_numeric_arg(function: extern "C" fn(c_int, c_int) -> c_int) -> bool {
    let ptr = function as *const ();
    ptr == rl_digit_argument as *const ()
        || ptr == rl_universal_argument as *const ()
        || ptr == rl_vi_arg_digit as *const ()
}

unsafe fn current_keymap_is_vi_movement() -> bool {
    ensure_builtin_keymap();
    rl_get_keymap() == vi_movement_keymap
}

unsafe fn kill_range(start: usize, end: usize, prepend: bool, append: bool) -> c_int {
    let line = current_line_bytes();
    let s = start.min(line.len());
    let e = end.min(line.len());
    if s >= e {
        return 0;
    }
    let append = append || (!prepend && last_was_kill());
    let prepend = prepend && last_was_kill();
    set_kill_buffer(&line[s..e], prepend, append);
    let result = rl_delete_text(clamp_c_int(s), clamp_c_int(e));
    rl_point = clamp_c_int(s.min(current_line_bytes().len()));
    mark_last_kill(true);
    if result < 0 {
        result
    } else {
        0
    }
}

unsafe fn region_bounds() -> Option<(usize, usize)> {
    let line = current_line_bytes();
    let point = current_point();
    let editor = lock_editor();
    if !editor.mark_active {
        return None;
    }
    let mark = editor.mark.min(line.len());
    Some(if mark <= point {
        (mark, point)
    } else {
        (point, mark)
    })
}

unsafe fn entry_line_bytes(entry: &HIST_ENTRY) -> Vec<u8> {
    if entry.line.is_null() {
        Vec::new()
    } else {
        CStr::from_ptr(entry.line).to_bytes().to_vec()
    }
}

fn history_previous_line() -> Option<Vec<u8>> {
    let mut hist = lock_history();
    if hist.offset == 0 {
        return None;
    }
    hist.offset -= 1;
    let idx = hist.offset;
    hist.sync_globals();
    Some(unsafe { entry_line_bytes(&hist.entries[idx]) })
}

fn history_next_line() -> Option<Vec<u8>> {
    let mut hist = lock_history();
    if hist.offset >= hist.entries.len() {
        return None;
    }
    hist.offset += 1;
    hist.sync_globals();
    if hist.offset >= hist.entries.len() {
        Some(Vec::new())
    } else {
        Some(unsafe { entry_line_bytes(&hist.entries[hist.offset]) })
    }
}

enum KeyOutcome {
    Continue,
    Accept,
}

enum BoundAction {
    Function(Vec<u8>, rl_command_func_t),
    Macro(Vec<u8>, Vec<u8>),
}

unsafe fn dispatch_bound_key(line: &mut Vec<u8>, point: &mut usize, key: c_int) -> bool {
    if !(0..=u8::MAX as c_int).contains(&key) {
        return false;
    }
    let key = key as u8;
    let action = {
        let mut editor = lock_editor();
        let keymap = keymap_data(rl_get_keymap());
        if let Some(keymap) = keymap {
            editor.pending_keyseq.push(key);
            let current_seq = editor.pending_keyseq.clone();
            let exact_function = keymap
                .keyseq_function_index
                .get(&editor.pending_keyseq)
                .map(|func| BoundAction::Function(current_seq.clone(), *func));
            let exact_macro = keymap
                .keyseq_macro_index
                .get(&editor.pending_keyseq)
                .map(|bytes| BoundAction::Macro(current_seq.clone(), bytes.clone()));
            let exact = exact_macro.or(exact_function);
            if exact.is_some() {
                editor.pending_keyseq.clear();
                exact
            } else if keymap.keyseq_prefix_index.contains(&editor.pending_keyseq)
            {
                return true;
            } else {
                if editor.pending_keyseq.len() > 1 {
                    editor.pending_keyseq.clear();
                    return true;
                }
                editor.pending_keyseq.clear();
                keymap.key_bindings[key as usize]
                    .map(|function| BoundAction::Function(vec![key], Some(function)))
            }
        } else {
            None
        }
    };

    let Some(action) = action else {
        return false;
    };
    let (seq, function) = match action {
        BoundAction::Macro(seq, bytes) => {
            set_executing_keyseq(&seq);
            record_kbd_macro_bytes(&seq);
            enqueue_macro_input(&bytes);
            return true;
        }
        BoundAction::Function(seq, function) => {
            let Some(function) = function else {
                return false;
            };
            if function as *const () != rl_end_kbd_macro as *const ()
                && function as *const () != rl_start_kbd_macro as *const ()
            {
                record_kbd_macro_bytes(&seq);
            }
            (seq, function)
        }
    };
    set_line_buffer_bytes(line);
    rl_point = clamp_c_int(*point);
    rl_end = clamp_c_int(line.len());
    set_executing_keyseq(&seq);
    rl_executing_key = key as c_int;
    rl_dispatching = 1;
    // rl_last_func reflects the *previous* command that ran, so any logic the
    // current function consults during its body (e.g. rl_completion_mode's
    // "did the user press the same key twice?" check inside rl_complete) sees
    // the prior command. GNU readline updates rl_last_func only after the
    // command returns — match that ordering here.
    let count = command_count();
    let _ = function(count, key as c_int);
    rl_last_func = Some(function);
    rl_dispatching = 0;
    if !preserves_numeric_arg(function) {
        reset_numeric_arg();
    }
    *line = current_line_bytes();
    *point = current_point();
    true
}

unsafe fn run_command_on_local(
    line: &mut Vec<u8>,
    point: &mut usize,
    key: c_int,
    function: unsafe extern "C" fn(c_int, c_int) -> c_int,
) -> c_int {
    set_line_buffer_bytes(line);
    rl_point = clamp_c_int(*point);
    rl_end = clamp_c_int(line.len());
    let result = function(1, key);
    *line = current_line_bytes();
    *point = current_point();
    result
}

unsafe fn process_edit_key(
    line: &mut Vec<u8>,
    point: &mut usize,
    previous_tab_left_line_unchanged: &mut bool,
    key: c_int,
) -> KeyOutcome {
    if dispatch_bound_key(line, point, key) {
        *previous_tab_left_line_unchanged = false;
        return KeyOutcome::Continue;
    }
    record_kbd_macro_key(key);
    match key {
        0x0a | 0x0d => KeyOutcome::Accept,
        0x01 => {
            let macro_bytes = {
                let editor = lock_editor();
                editor.ctrl_a_macro.clone()
            };
            if macro_bytes.is_empty() {
                *point = 0;
            } else {
                insert_bytes(line, point, &macro_bytes);
            }
            *previous_tab_left_line_unchanged = false;
            KeyOutcome::Continue
        }
        0x02 => {
            let backward = {
                let editor = lock_editor();
                editor.ctrl_b_backward
            };
            if backward {
                *point = previous_char_boundary(line, *point);
            }
            *previous_tab_left_line_unchanged = false;
            KeyOutcome::Continue
        }
        0x04 => {
            if *point < line.len() {
                let next = next_char_boundary(line, *point);
                line.drain(*point..next);
            }
            *previous_tab_left_line_unchanged = false;
            KeyOutcome::Continue
        }
        0x05 => {
            *point = line.len();
            *previous_tab_left_line_unchanged = false;
            KeyOutcome::Continue
        }
        0x06 => {
            *point = next_char_boundary(line, *point);
            *previous_tab_left_line_unchanged = false;
            KeyOutcome::Continue
        }
        0x08 | 0x7f => {
            let prev = previous_char_boundary(line, *point);
            if prev < *point {
                line.drain(prev..*point);
                *point = prev;
            }
            *previous_tab_left_line_unchanged = false;
            KeyOutcome::Continue
        }
        0x09 => {
            let completes = {
                let editor = lock_editor();
                editor.tab_completes
            };
            if completes {
                if rl_inhibit_completion != 0 {
                    insert_bytes(line, point, b"\t");
                    *previous_tab_left_line_unchanged = false;
                } else {
                    let changed = complete_line(line, point, *previous_tab_left_line_unchanged);
                    *previous_tab_left_line_unchanged = !changed;
                }
            } else {
                insert_bytes(line, point, b"\t");
                *previous_tab_left_line_unchanged = false;
            }
            KeyOutcome::Continue
        }
        0x0b => {
            let _ = run_command_on_local(line, point, key, rl_kill_line);
            *previous_tab_left_line_unchanged = false;
            KeyOutcome::Continue
        }
        0x0e => {
            if let Some(next) = history_next_line() {
                *line = next;
                *point = line.len();
            }
            *previous_tab_left_line_unchanged = false;
            KeyOutcome::Continue
        }
        0x10 => {
            if let Some(previous) = history_previous_line() {
                *line = previous;
                *point = line.len();
            }
            *previous_tab_left_line_unchanged = false;
            KeyOutcome::Continue
        }
        0x15 => {
            let _ = run_command_on_local(line, point, key, rl_unix_line_discard);
            *previous_tab_left_line_unchanged = false;
            KeyOutcome::Continue
        }
        0x19 => {
            let _ = run_command_on_local(line, point, key, rl_yank);
            *previous_tab_left_line_unchanged = false;
            KeyOutcome::Continue
        }
        0x14 => {
            let _ = run_command_on_local(line, point, key, rl_transpose_chars);
            *previous_tab_left_line_unchanged = false;
            KeyOutcome::Continue
        }
        0x00..=0x1f => {
            *previous_tab_left_line_unchanged = false;
            KeyOutcome::Continue
        }
        _ => {
            if current_keymap_is_vi_movement() {
                *point = current_point();
            } else if key <= u8::MAX as c_int {
                insert_bytes(line, point, &[key as u8]);
            }
            *previous_tab_left_line_unchanged = false;
            KeyOutcome::Continue
        }
    }
}

unsafe fn word_break_bytes() -> Vec<u8> {
    if let Some(hook) = rl_completion_word_break_hook {
        let bytes = hook();
        if !bytes.is_null() {
            return CStr::from_ptr(bytes).to_bytes().to_vec();
        }
    }
    if rl_completer_word_break_characters.is_null() {
        WORD_BREAK_BYTES[..WORD_BREAK_BYTES.len() - 1].to_vec()
    } else {
        CStr::from_ptr(rl_completer_word_break_characters)
            .to_bytes()
            .to_vec()
    }
}

unsafe fn completion_word_start(line: &[u8], point: usize) -> usize {
    let breaks = word_break_bytes();
    let quotes = if rl_completer_quote_characters.is_null() {
        if rl_basic_quote_characters.is_null() {
            QUOTE_BYTES[..QUOTE_BYTES.len() - 1].to_vec()
        } else {
            CStr::from_ptr(rl_basic_quote_characters)
                .to_bytes()
                .to_vec()
        }
    } else {
        CStr::from_ptr(rl_completer_quote_characters)
            .to_bytes()
            .to_vec()
    };
    let end = point.min(line.len());
    let mut start = 0usize;
    let mut quote = 0u8;
    let mut quote_start = 0usize;
    let mut escaped = false;
    let quote_hook = rl_char_is_quoted_p;
    let quoted_line = if quote_hook.is_some() {
        let ptr = dup_bytes(&line[..end]);
        if ptr.is_null() {
            None
        } else {
            Some(ptr)
        }
    } else {
        None
    };
    for (idx, &byte) in line[..end].iter().enumerate() {
        let hook_quoted = if let (Some(hook), Some(quoted_line)) = (quote_hook, quoted_line) {
            hook(quoted_line, clamp_c_int(idx)) != 0
        } else {
            false
        };
        if escaped {
            escaped = false;
            continue;
        }
        if hook_quoted {
            continue;
        }
        if byte == b'\\' {
            escaped = true;
            continue;
        }
        if quote != 0 {
            if byte == quote {
                quote = 0;
                start = idx + 1;
            }
            continue;
        }
        if quotes.contains(&byte) {
            quote = byte;
            quote_start = idx;
            start = idx + 1;
            continue;
        }
        if breaks.contains(&byte) {
            start = idx + 1;
        }
    }
    if let Some(quoted_line) = quoted_line {
        free(quoted_line as *mut c_void);
    }
    if quote != 0 {
        rl_completion_found_quote = 1;
        rl_completion_quote_character = quote as c_int;
        quote_start + 1
    } else {
        rl_completion_found_quote = 0;
        rl_completion_quote_character = 0;
        start
    }
}

fn normalize_completion_matches(matches: &mut Vec<Vec<u8>>) {
    unsafe {
        if rl_sort_completion_matches != 0 {
            matches.sort();
        }
        if rl_ignore_completion_duplicates != 0 {
            if rl_sort_completion_matches != 0 {
                matches.dedup();
            } else {
                let mut seen = HashSet::new();
                matches.retain(|item| seen.insert(item.clone()));
            }
        }
    }
}

unsafe fn completion_generator_result<F>(
    state: &mut GeneratorState,
    text: *const c_char,
    index: c_int,
    build: F,
) -> *mut c_char
where
    F: FnOnce(&[u8]) -> Vec<Vec<u8>>,
{
    if text.is_null() || index < 0 {
        return ptr::null_mut();
    }

    let key = CStr::from_ptr(text).to_bytes();
    if index == 0 || state.key != key {
        state.key = key.to_vec();
        state.matches = build(key);
        normalize_completion_matches(&mut state.matches);
    }

    state
        .matches
        .get(index as usize)
        .map_or(ptr::null_mut(), |item| dup_bytes(item))
}

fn path_from_bytes(bytes: &[u8]) -> PathBuf {
    PathBuf::from(OsString::from_vec(bytes.to_vec()))
}

fn home_dir_bytes() -> Option<Vec<u8>> {
    std::env::var_os("HOME").map(|home| PathBuf::from(home).as_os_str().as_bytes().to_vec())
}

fn expand_completion_dir(dir: &[u8]) -> Vec<u8> {
    if dir == b"~" {
        return home_dir_bytes().unwrap_or_else(|| dir.to_vec());
    }
    if let Some(rest) = dir.strip_prefix(b"~/") {
        if let Some(mut home) = home_dir_bytes() {
            if !home.ends_with(b"/") {
                home.push(b'/');
            }
            home.extend_from_slice(rest);
            return home;
        }
    }
    dir.to_vec()
}

struct CompletionDirectory {
    read_dir: Vec<u8>,
    display_prefix: Vec<u8>,
}

unsafe fn apply_directory_pointer_hook(
    dir: Vec<u8>,
    hook: rl_directory_completion_hook_t,
) -> (Vec<u8>, bool) {
    let Some(hook) = hook else {
        return (dir, false);
    };
    let mut dir_ptr = dup_bytes(&dir);
    if dir_ptr.is_null() {
        return (dir, false);
    }
    let modified = hook(&mut dir_ptr) != 0;
    let read_dir = if modified && !dir_ptr.is_null() {
        CStr::from_ptr(dir_ptr).to_bytes().to_vec()
    } else {
        dir
    };
    if !dir_ptr.is_null() {
        free(dir_ptr as *mut c_void);
    }
    (read_dir, modified)
}

unsafe fn apply_directory_hooks(dir: Vec<u8>, display_prefix: &[u8]) -> CompletionDirectory {
    let (read_dir, _) = apply_directory_pointer_hook(dir, rl_directory_rewrite_hook);
    let (read_dir, display_modified) =
        apply_directory_pointer_hook(read_dir, rl_directory_completion_hook);
    let display_prefix = if display_modified {
        read_dir.clone()
    } else {
        display_prefix.to_vec()
    };
    CompletionDirectory {
        read_dir,
        display_prefix,
    }
}

unsafe fn apply_filename_rewrite_hook(bytes: &[u8], hook: rl_filename_dequoting_func_t) -> Vec<u8> {
    let Some(hook) = hook else {
        return bytes.to_vec();
    };
    let tmp = dup_bytes(bytes);
    if tmp.is_null() {
        return bytes.to_vec();
    }
    let rewritten = hook(tmp, clamp_c_int(bytes.len()));
    let out = if rewritten.is_null() {
        bytes.to_vec()
    } else {
        CStr::from_ptr(rewritten).to_bytes().to_vec()
    };
    if !rewritten.is_null() && rewritten != tmp {
        free(rewritten as *mut c_void);
    }
    free(tmp as *mut c_void);
    out
}

fn path_join_bytes(dir: &[u8], name: &[u8]) -> Vec<u8> {
    let mut path = dir.to_vec();
    if !path.ends_with(b"/") {
        path.push(b'/');
    }
    path.extend_from_slice(name);
    path
}

unsafe fn completion_stat_path(
    dir: &[u8],
    name: &[u8],
    hook: rl_filename_dequoting_func_t,
) -> Vec<u8> {
    apply_filename_rewrite_hook(&path_join_bytes(dir, name), hook)
}

fn build_filename_completions(text: &[u8]) -> Vec<Vec<u8>> {
    let (dir, prefix, display_prefix) = match text.iter().rposition(|byte| *byte == b'/') {
        Some(0) => (&b"/"[..], &text[1..], &text[..1]),
        Some(pos) => (&text[..pos], &text[pos + 1..], &text[..pos + 1]),
        None => (&b"."[..], text, &b""[..]),
    };
    let (ignore_case, map_case) = {
        let editor = lock_editor();
        (editor.completion_ignore_case, editor.completion_map_case)
    };
    let compare_prefix = unsafe { apply_filename_rewrite_hook(prefix, rl_completion_rewrite_hook) };
    let directory = unsafe { apply_directory_hooks(expand_completion_dir(dir), display_prefix) };
    let Ok(entries) = fs::read_dir(path_from_bytes(&directory.read_dir)) else {
        return Vec::new();
    };

    let mut matches = Vec::new();
    for entry in entries.flatten() {
        let name = entry.file_name();
        let name = name.as_os_str().as_bytes();
        if name.first() == Some(&b'.')
            && unsafe { MATCH_HIDDEN_FILES == 0 }
            && prefix.first() != Some(&b'.')
        {
            continue;
        }
        let display_name = unsafe { apply_filename_rewrite_hook(name, rl_filename_rewrite_hook) };
        if !byte_starts_with(&display_name, &compare_prefix, ignore_case, map_case) {
            continue;
        }
        let mut candidate = directory.display_prefix.clone();
        candidate.extend_from_slice(&display_name);
        let stat_hook = unsafe { rl_filename_stat_hook };
        let mark_directory = unsafe { _rl_complete_mark_directories != 0 }
            && if stat_hook.is_some() {
                let stat_path =
                    unsafe { completion_stat_path(&directory.read_dir, name, stat_hook) };
                fs::metadata(path_from_bytes(&stat_path)).is_ok_and(|metadata| metadata.is_dir())
            } else {
                entry.file_type().is_ok_and(|file_type| {
                    file_type.is_dir()
                        || (unsafe { rl_completion_mark_symlink_dirs != 0 }
                            && file_type.is_symlink()
                            && fs::metadata(entry.path()).is_ok_and(|metadata| metadata.is_dir()))
                })
            };
        if mark_directory {
            candidate.push(b'/');
        }
        matches.push(candidate);
    }
    matches
}

fn build_username_completions(text: &[u8]) -> Vec<Vec<u8>> {
    let tilde = text.first() == Some(&b'~');
    let prefix = if tilde { &text[1..] } else { text };
    let (ignore_case, map_case) = {
        let editor = lock_editor();
        (editor.completion_ignore_case, editor.completion_map_case)
    };

    let mut matches = Vec::new();
    if let Ok(passwd) = fs::read("/etc/passwd") {
        for line in passwd.split(|byte| *byte == b'\n') {
            let Some(colon) = line.iter().position(|byte| *byte == b':') else {
                continue;
            };
            let name = &line[..colon];
            if !byte_starts_with(name, prefix, ignore_case, map_case) {
                continue;
            }
            let mut candidate = Vec::with_capacity(name.len() + usize::from(tilde));
            if tilde {
                candidate.push(b'~');
            }
            candidate.extend_from_slice(name);
            matches.push(candidate);
        }
    }

    for fallback in ["USER", "LOGNAME"].into_iter().filter_map(std::env::var_os) {
        let name = PathBuf::from(fallback).into_os_string().into_vec();
        if !name.is_empty() && byte_starts_with(&name, prefix, ignore_case, map_case) {
            let mut candidate = Vec::with_capacity(name.len() + usize::from(tilde));
            if tilde {
                candidate.push(b'~');
            }
            candidate.extend_from_slice(&name);
            matches.push(candidate);
        }
    }

    if byte_starts_with(b"root", prefix, ignore_case, map_case) {
        let mut candidate = Vec::with_capacity(4 + usize::from(tilde));
        if tilde {
            candidate.push(b'~');
        }
        candidate.extend_from_slice(b"root");
        matches.push(candidate);
    }
    matches
}

unsafe fn quote_completion_candidate(candidate: &[u8], match_type: c_int) -> Option<Vec<u8>> {
    if rl_filename_quoting_desired == 0 || rl_filename_quote_characters.is_null() {
        return None;
    }
    let quote_chars = CStr::from_ptr(rl_filename_quote_characters).to_bytes();
    if quote_chars.is_empty() || !candidate.iter().any(|byte| quote_chars.contains(byte)) {
        return None;
    }
    let quote = rl_filename_quoting_function?;
    let tmp = dup_bytes(candidate);
    if tmp.is_null() {
        return None;
    }
    let quoted = quote(tmp, match_type, ptr::null_mut());
    let out = take_hook_string(quoted, tmp);
    free(tmp as *mut c_void);
    out
}

unsafe fn free_completion_matches(matches: *mut *mut c_char) {
    if matches.is_null() {
        return;
    }
    let mut idx = 0;
    loop {
        let item = *matches.add(idx);
        if item.is_null() {
            break;
        }
        free(item as *mut c_void);
        idx += 1;
    }
    free(matches as *mut c_void);
}

struct CompletionResult {
    matches: *mut *mut c_char,
    start: usize,
    end: usize,
    item_count: usize,
    max_length: usize,
}

impl Drop for CompletionResult {
    fn drop(&mut self) {
        unsafe {
            free_completion_matches(self.matches);
            rl_attempted_completion_over = 0;
        }
    }
}

unsafe fn gather_completion_matches(line: &[u8], point: usize) -> Option<CompletionResult> {
    if rl_inhibit_completion != 0 {
        return None;
    }
    rl_completion_append_character = b' ' as c_int;
    rl_completion_suppress_append = 0;
    rl_completion_suppress_quote = 0;
    rl_filename_completion_desired = 0;
    rl_filename_quoting_desired = 1;
    rl_full_quoting_desired = 0;
    let end = point.min(line.len());
    let start = completion_word_start(line, end);
    set_line_buffer_bytes(line);
    rl_point = clamp_c_int(end);
    rl_end = clamp_c_int(line.len());

    let text = dup_bytes(&line[start..end]);
    if text.is_null() {
        return None;
    }
    let mut attempted_called = false;
    let mut matches = if let Some(completer) = rl_attempted_completion_function {
        attempted_called = true;
        completer(text, clamp_c_int(start), clamp_c_int(end))
    } else {
        ptr::null_mut()
    };
    if matches.is_null() && (!attempted_called || rl_attempted_completion_over == 0) {
        let entry = rl_completion_entry_function.or(Some(rl_filename_completion_function));
        rl_filename_completion_desired = if entry
            .map(|func| func as *const () == rl_filename_completion_function as *const ())
            .unwrap_or(false)
        {
            1
        } else {
            0
        };
        matches = rl_completion_matches(text, entry);
    }
    free(text as *mut c_void);
    if matches.is_null() {
        rl_attempted_completion_over = 0;
        return None;
    }
    if let Some(ignore) = rl_ignore_some_completions_function {
        let _ = ignore(matches);
    }

    let mut item_count = 0usize;
    let mut max_length = 0usize;
    while !(*matches.add(item_count + 1)).is_null() {
        let len = CStr::from_ptr(*matches.add(item_count + 1))
            .to_bytes()
            .len();
        if len > max_length {
            max_length = len;
        }
        item_count += 1;
    }
    if item_count == 0 {
        free_completion_matches(matches);
        rl_attempted_completion_over = 0;
        return None;
    }

    Some(CompletionResult {
        matches,
        start,
        end,
        item_count,
        max_length,
    })
}

unsafe fn display_completion_matches(completion: &CompletionResult) {
    if let Some(display) = rl_completion_display_matches_hook {
        display(
            completion.matches,
            clamp_c_int(completion.item_count),
            clamp_c_int(completion.max_length),
        );
    }
}

unsafe fn completion_candidate_bytes(completion: &CompletionResult, idx: usize) -> Vec<u8> {
    let mut candidate = CStr::from_ptr(*completion.matches.add(idx))
        .to_bytes()
        .to_vec();
    if rl_filename_completion_desired != 0 || rl_full_quoting_desired != 0 {
        let match_type = if completion.item_count == 1 {
            SINGLE_MATCH
        } else {
            MULT_MATCH
        };
        if let Some(quoted) = quote_completion_candidate(&candidate, match_type) {
            candidate = quoted;
        }
    }
    candidate
}

unsafe fn apply_common_completion(
    line: &mut Vec<u8>,
    point: &mut usize,
    completion: &CompletionResult,
) -> bool {
    let replacement = completion_candidate_bytes(completion, 0);
    let current = line[completion.start..completion.end].to_vec();
    let mut changed = false;
    if replacement != current {
        line.splice(
            completion.start..completion.end,
            replacement.iter().copied(),
        );
        *point = completion.start + replacement.len();
        changed = true;
    }

    if completion.item_count == 1 && rl_completion_suppress_append == 0 {
        let append = rl_completion_append_character;
        if append > 0 && append <= u8::MAX as c_int {
            insert_bytes(line, point, &[append as u8]);
            changed = true;
        }
    }
    changed
}

unsafe fn apply_insert_all_completions(
    line: &mut Vec<u8>,
    point: &mut usize,
    completion: &CompletionResult,
) -> bool {
    let mut replacement = Vec::new();
    for idx in 1..=completion.item_count {
        if idx > 1 {
            replacement.push(b' ');
        }
        replacement.extend_from_slice(&completion_candidate_bytes(completion, idx));
    }
    replacement.push(b' ');
    let current = line[completion.start..completion.end].to_vec();
    line.splice(
        completion.start..completion.end,
        replacement.iter().copied(),
    );
    *point = completion.start + replacement.len();
    replacement != current
}

unsafe fn apply_menu_completion(
    line: &mut Vec<u8>,
    point: &mut usize,
    completion: &CompletionResult,
    backward: bool,
) -> bool {
    let idx = if backward { completion.item_count } else { 1 };
    let mut replacement = completion_candidate_bytes(completion, idx);
    if rl_completion_suppress_append == 0 {
        let append = rl_completion_append_character;
        if append > 0 && append <= u8::MAX as c_int {
            replacement.push(append as u8);
        }
    }
    let current = line[completion.start..completion.end].to_vec();
    line.splice(
        completion.start..completion.end,
        replacement.iter().copied(),
    );
    *point = completion.start + replacement.len();
    replacement != current
}

unsafe fn complete_line_with_mode(
    line: &mut Vec<u8>,
    point: &mut usize,
    mode: c_int,
    force_display: bool,
) -> bool {
    let Some(completion) = gather_completion_matches(line, *point) else {
        return false;
    };
    let changed = match mode {
        mode if mode == b'?' as c_int => {
            display_completion_matches(&completion);
            false
        }
        mode if mode == b'*' as c_int => apply_insert_all_completions(line, point, &completion),
        mode if mode == b'!' as c_int => {
            let changed = apply_common_completion(line, point, &completion);
            if completion.item_count > 1 {
                display_completion_matches(&completion);
            }
            changed
        }
        mode if mode == b'@' as c_int => {
            let changed = apply_common_completion(line, point, &completion);
            if !changed {
                display_completion_matches(&completion);
            }
            changed
        }
        mode if mode == b'%' as c_int => apply_menu_completion(line, point, &completion, false),
        _ => {
            let changed = apply_common_completion(line, point, &completion);
            if !changed && force_display {
                display_completion_matches(&completion);
            }
            changed
        }
    };

    set_line_buffer_bytes(line);
    rl_point = clamp_c_int(*point);
    rl_end = clamp_c_int(line.len());
    changed
}

unsafe fn complete_line(line: &mut Vec<u8>, point: &mut usize, force_display: bool) -> bool {
    rl_completion_type = b'\t' as c_int;
    complete_line_with_mode(line, point, b'\t' as c_int, force_display)
}

unsafe fn read_edited_line() -> Option<Vec<u8>> {
    let mut line = current_line_bytes();
    let mut point = if rl_point < 0 {
        0
    } else {
        (rl_point as usize).min(line.len())
    };
    let mut got_byte = false;
    let mut previous_tab_left_line_unchanged = false;

    loop {
        if let Some(hook) = rl_event_hook {
            let _ = hook();
        }
        let key = rl_read_key();
        if key < 0 {
            if got_byte {
                break;
            }
            return None;
        }
        got_byte = true;

        let outcome = process_edit_key(
            &mut line,
            &mut point,
            &mut previous_tab_left_line_unchanged,
            key,
        );
        if matches!(outcome, KeyOutcome::Accept) || rl_done != 0 {
            break;
        }
        if rl_num_chars_to_read > 0 && line.len() >= rl_num_chars_to_read as usize {
            line.truncate(rl_num_chars_to_read as usize);
            point = point.min(line.len());
            break;
        }
        set_line_buffer_bytes(&line);
        rl_point = clamp_c_int(point);
        rl_end = clamp_c_int(line.len());
    }

    set_line_buffer_bytes(&line);
    rl_point = clamp_c_int(point);
    rl_end = clamp_c_int(line.len());
    Some(line)
}

unsafe fn begin_configured_timeout() {
    if TIMEOUT_SECONDS != 0 || TIMEOUT_USECONDS != 0 {
        TIMEOUT_ACTIVE = true;
        rl_readline_state &= !RL_STATE_TIMEOUT;
    }
}

unsafe fn end_configured_timeout() {
    TIMEOUT_ACTIVE = false;
    rl_readline_state &= !RL_STATE_TIMEOUT;
}

#[no_mangle]
pub unsafe extern "C" fn readline(prompt: *const c_char) -> *mut c_char {
    if rl_readline_state & RL_STATE_INITIALIZED == 0 {
        let _ = rl_initialize();
    }
    ensure_stdio_streams();
    if let Some(hook) = rl_startup_hook {
        let _ = hook();
    }
    if !prompt.is_null() {
        set_prompt_value(prompt);
    }
    if !prompt.is_null() && rl_already_prompted == 0 {
        output_c_string(prompt);
    }
    let saved_line = {
        let mut editor = lock_editor();
        editor.saved_line.take()
    };
    set_line_buffer_bytes(saved_line.as_deref().unwrap_or(&[]));
    if let Some(hook) = rl_pre_input_hook {
        let _ = hook();
    }

    rl_done = 0;
    rl_readline_state &= !RL_STATE_DONE;
    begin_configured_timeout();
    let result = match read_edited_line() {
        None => {
            rl_eof_found = 1;
            ptr::null_mut()
        }
        Some(line) => {
            rl_eof_found = 0;
            let mut line = line;
            let mut point = current_point();
            if rl_num_chars_to_read > 0 && line.len() > rl_num_chars_to_read as usize {
                line.truncate(rl_num_chars_to_read as usize);
                point = point.min(line.len());
            }
            set_line_buffer_bytes(&line);
            rl_point = clamp_c_int(point);
            dup_bytes(&line)
        }
    };
    end_configured_timeout();
    rl_done = 0;
    rl_readline_state &= !RL_STATE_DONE;
    result
}

#[no_mangle]
pub unsafe extern "C" fn rl_initialize() -> c_int {
    ensure_stdio_streams();
    ensure_builtin_keymap();
    let _ = refresh_screen_size_from_terminal();
    if rl_line_buffer.is_null() {
        set_line_buffer_bytes(&[]);
    }
    if rl_display_prompt.is_null() {
        replace_global_string(
            std::ptr::addr_of_mut!(rl_display_prompt),
            EMPTY_BYTES.as_ptr() as *const c_char,
        );
    }
    rl_done = 0;
    rl_mark = 0;
    let _ = rl_read_init_file(ptr::null());
    rl_readline_state = RL_STATE_INITIALIZED;
    0
}

#[no_mangle]
pub extern "C" fn rl_cleanup_after_signal() {
    unsafe {
        rl_deprep_terminal();
    }
    let _ = rl_clear_signals();
}

#[no_mangle]
pub extern "C" fn rl_reset_after_signal() {
    let _ = rl_set_signals();
    unsafe {
        let _ = rl_prep_terminal(1);
    }
}

#[no_mangle]
pub extern "C" fn rl_free_line_state() {
    unsafe {
        rl_explicit_arg = 0;
        rl_numeric_arg = 1;
        rl_arg_sign = 1;
        NUMERIC_ARG_HAS_DIGITS = 0;
        if !rl_executing_macro.is_null() {
            free(rl_executing_macro as *mut c_void);
            rl_executing_macro = ptr::null_mut();
        }
    }
    let mut editor = lock_editor();
    editor.pending_keyseq.clear();
    editor.macro_input.clear();
    editor.kbd_macro_recording = false;
    editor.kbd_macro_current.clear();
    editor.undo_stack.clear();
    editor.undo_group_depth = 0;
    editor.undo_group_snapshot = None;
}

#[no_mangle]
pub unsafe extern "C" fn rl_deprep_terminal() {
    if rl_readline_state & RL_STATE_TERMPREPPED == 0 {
        return;
    }
    if let Some(deprep) = rl_deprep_term_function {
        deprep();
    }
    // Restore the terminal modes that rl_prep_terminal stashed away.
    // Without this every readline session would leave the user's terminal
    // in raw mode after the handler returns — devastating for an
    // interactive REPL that exits and expects normal shell echo.
    restore_terminal_modes();
    rl_readline_state &= !RL_STATE_TERMPREPPED;
}

#[no_mangle]
pub unsafe extern "C" fn rl_prep_terminal(_meta_flag: c_int) -> c_int {
    if rl_readline_state & RL_STATE_TERMPREPPED != 0 {
        return 0;
    }
    rl_readline_state |= RL_STATE_TERMPREPPED;
    if let Some(prep) = rl_prep_term_function {
        prep(_meta_flag);
    }
    // The user's `prep_term_function`, if any, ran first.  We still need
    // to put the input fd into a state where readline can actually do
    // character-at-a-time editing: disable canonical mode and local echo
    // so the kernel doesn't intercept the line or duplicate keystrokes,
    // and disable IXON so Ctrl-S / Ctrl-Q don't pause the stream.
    apply_readline_terminal_modes();
    0
}

// Saved termios state — populated by apply_readline_terminal_modes() on
// the way in, restored by restore_terminal_modes() on the way out.  The
// option lets the deprep path no-op cleanly if prep never ran (e.g. when
// rl_instream is a pipe and tcgetattr fails).
static SAVED_TERMIOS: Mutex<Option<(c_int, Termios)>> = Mutex::new(None);

unsafe fn rl_input_fd() -> c_int {
    if rl_instream.is_null() {
        0
    } else {
        let fd = fileno(rl_instream);
        if fd < 0 {
            0
        } else {
            fd
        }
    }
}

unsafe fn apply_readline_terminal_modes() {
    let fd = rl_input_fd();
    if isatty(fd) == 0 {
        return;
    }
    let mut current = Termios::zero();
    if tcgetattr(fd, &mut current) != 0 {
        return;
    }
    // Stash the original so we can restore it later.
    {
        let mut saved = lock_saved_termios();
        *saved = Some((fd, current));
    }

    let mut new_modes = current;
    let lflag = termios_flag_load(&new_modes, TERMIOS_LFLAG_OFFSET)
        & !(ICANON | ECHO | ECHOE | ECHOK | ECHONL | IEXTEN);
    // ISIG stays on so Ctrl-C / Ctrl-Z keep working in the surrounding
    // shell context — matching real readline (which leaves ISIG set when
    // rl_catch_signals is on, as it is by default).
    termios_flag_store(&mut new_modes, TERMIOS_LFLAG_OFFSET, lflag | ISIG);
    let iflag = termios_flag_load(&new_modes, TERMIOS_IFLAG_OFFSET)
        & !(IXON | ICRNL | INLCR | ISTRIP | INPCK | BRKINT);
    termios_flag_store(&mut new_modes, TERMIOS_IFLAG_OFFSET, iflag);
    // Keep OPOST set: we WANT the kernel to translate \n → \r\n on
    // output so existing display code that emits bare \n still looks
    // right on a real terminal.
    let oflag = termios_flag_load(&new_modes, TERMIOS_OFLAG_OFFSET) | OPOST;
    termios_flag_store(&mut new_modes, TERMIOS_OFLAG_OFFSET, oflag);
    // VMIN=1, VTIME=0: read returns as soon as one byte is available, no
    // inter-byte timeout.  This is what readline relies on.
    new_modes.storage[TERMIOS_CC_VMIN] = 1;
    new_modes.storage[TERMIOS_CC_VTIME] = 0;
    let _ = tcsetattr(fd, TCSADRAIN, &new_modes);
}

unsafe fn restore_terminal_modes() {
    let saved = {
        let mut guard = lock_saved_termios();
        guard.take()
    };
    if let Some((fd, modes)) = saved {
        let _ = tcsetattr(fd, TCSADRAIN, &modes);
    }
}

#[no_mangle]
pub unsafe extern "C" fn rl_set_prompt(prompt: *const c_char) -> c_int {
    set_prompt_value(prompt);
    0
}

#[no_mangle]
pub extern "C" fn rl_on_new_line() -> c_int {
    0
}

#[no_mangle]
pub unsafe extern "C" fn rl_newline(_count: c_int, _key: c_int) -> c_int {
    rl_done = 1;
    0
}

#[no_mangle]
pub unsafe extern "C" fn rl_redisplay() {
    if !rl_display_prompt.is_null() {
        output_c_string(rl_display_prompt);
    }
    if !rl_line_buffer.is_null() {
        output_c_string(rl_line_buffer);
    }
}

#[no_mangle]
pub unsafe extern "C" fn rl_forced_update_display() -> c_int {
    if let Some(redisplay) = rl_redisplay_function {
        redisplay();
    }
    0
}

#[no_mangle]
pub static mut rl_redisplay_function: Option<extern "C" fn()> = Some(rl_default_redisplay);

extern "C" fn rl_default_redisplay() {
    unsafe { rl_redisplay() };
}

#[no_mangle]
pub extern "C" fn rl_refresh_line(_ignore1: c_int, _ignore2: c_int) -> c_int {
    unsafe { rl_forced_update_display() }
}

#[no_mangle]
pub unsafe extern "C" fn readlineoxide_rl_message_formatted(text: *const c_char) -> c_int {
    if text.is_null() {
        return 0;
    }
    set_display_prompt_value(text);
    0
}

#[no_mangle]
pub unsafe extern "C" fn rl_clear_message() -> c_int {
    let display = if rl_prompt.is_null() {
        EMPTY_BYTES.as_ptr() as *const c_char
    } else {
        rl_prompt as *const c_char
    };
    set_display_prompt_value(display);
    0
}

#[no_mangle]
pub extern "C" fn rl_on_new_line_with_prompt() -> c_int {
    rl_on_new_line()
}

#[no_mangle]
pub extern "C" fn rl_clear_display() -> c_int {
    // SAFETY:
    // - output_stream_is_tty normalizes rl_outstream and checks the FILE fd.
    // - output_bytes writes a fixed NUL-free byte string to that stream.
    // - No raw pointer from the caller is dereferenced here.
    unsafe {
        if output_stream_is_tty() {
            output_bytes(b"\x1b[H\x1b[2J");
        }
    };
    0
}

#[no_mangle]
pub extern "C" fn rl_clear_screen(_count: c_int, _key: c_int) -> c_int {
    rl_clear_display()
}

#[no_mangle]
pub extern "C" fn rl_clear_visible_line() -> c_int {
    // SAFETY:
    // - SCREEN_COLS is maintained by rl_set_screen_size/rl_reset_screen_size.
    // - output helpers normalize rl_outstream before writing.
    // - No caller-provided pointer is dereferenced here.
    unsafe {
        let is_tty = output_stream_is_tty();
        if is_tty {
            output_raw_bytes(b"\r");
        }
        output_repeated_byte(b' ', SCREEN_COLS.max(0) as usize);
        if is_tty {
            output_raw_bytes(b"\r");
        }
    };
    0
}

#[no_mangle]
pub unsafe extern "C" fn rl_display_match_list(matches: *mut *mut c_char, len: c_int, max: c_int) {
    if matches.is_null() || len <= 0 {
        return;
    }
    let common_prefix_len = {
        let common = *matches;
        if common.is_null() {
            0
        } else {
            CStr::from_ptr(common).to_bytes().len()
        }
    };
    let count = len as usize;
    let mut items = Vec::with_capacity(count);
    for idx in 1..=count {
        let item = *matches.add(idx);
        if item.is_null() {
            continue;
        }
        items.push(CStr::from_ptr(item).to_bytes().to_vec());
    }
    if items.is_empty() {
        return;
    }
    let prefix_limit = _rl_completion_prefix_display_length.max(0) as usize;
    let mut prefix_elided = false;
    if prefix_limit > 0 && common_prefix_len > prefix_limit {
        for item in &mut items {
            if item.len() > common_prefix_len {
                let keep = item.len() - common_prefix_len;
                let mut shortened = Vec::with_capacity(keep + 3);
                shortened.extend_from_slice(b"...");
                shortened.extend_from_slice(&item[common_prefix_len..]);
                *item = shortened;
                prefix_elided = true;
            }
        }
    }

    let display_width = items.iter().map(|item| item.len()).max().unwrap_or(0);
    let item_width = if prefix_elided {
        display_width
    } else {
        max.max(display_width as c_int).max(0) as usize
    };
    let column_width = item_width.saturating_add(2).max(1);
    let screen_cols = if COMPLETION_DISPLAY_WIDTH >= 0 {
        COMPLETION_DISPLAY_WIDTH.max(1)
    } else {
        SCREEN_COLS.max(1)
    } as usize;
    let columns = (screen_cols / column_width).max(1).min(items.len());
    let rows = items.len().div_ceil(columns);

    for row in 0..rows {
        for column in 0..columns {
            let idx = if _rl_print_completions_horizontally != 0 {
                row * columns + column
            } else {
                column * rows + row
            };
            if idx >= items.len() {
                continue;
            }
            let item = &items[idx];
            output_raw_bytes(item);
            let more_on_row = (column + 1..columns).any(|next_column| {
                let next_idx = if _rl_print_completions_horizontally != 0 {
                    row * columns + next_column
                } else {
                    next_column * rows + row
                };
                next_idx < items.len()
            });
            if more_on_row {
                let padding = column_width.saturating_sub(item.len());
                output_repeated_byte(b' ', padding);
            }
        }
        output_bytes(b"\n");
    }
}

#[no_mangle]
pub unsafe extern "C" fn rl_expand_prompt(prompt: *mut c_char) -> c_int {
    expanded_prompt_length(prompt)
}

#[no_mangle]
pub unsafe extern "C" fn rl_save_prompt() {
    if !SAVED_PROMPT.is_null() {
        free(SAVED_PROMPT as *mut c_void);
    }
    SAVED_PROMPT = dup_c_string(rl_prompt);
}

#[no_mangle]
pub unsafe extern "C" fn rl_restore_prompt() {
    if SAVED_PROMPT.is_null() {
        return;
    }
    set_prompt_value(SAVED_PROMPT);
    free(SAVED_PROMPT as *mut c_void);
    SAVED_PROMPT = ptr::null_mut();
}

#[no_mangle]
pub unsafe extern "C" fn rl_reset_line_state() -> c_int {
    rl_done = 0;
    rl_eof_found = 0;
    TIMEOUT_ACTIVE = false;
    rl_readline_state &= !(RL_STATE_DONE | RL_STATE_TIMEOUT);
    0
}

#[no_mangle]
pub unsafe extern "C" fn rl_clear_pending_input() -> c_int {
    rl_pending_input = 0;
    let editor = lock_editor();
    if editor.pending_input.is_empty() && editor.macro_input.is_empty() {
        rl_readline_state &= !0x00020000;
    }
    0
}

#[no_mangle]
pub extern "C" fn _rl_erase_entire_line() {}

#[no_mangle]
pub unsafe extern "C" fn _rl_qsort_string_compare(a: *const c_void, b: *const c_void) -> c_int {
    if a.is_null() || b.is_null() {
        return 0;
    }
    let left = *(a as *const *const c_char);
    let right = *(b as *const *const c_char);
    if left.is_null() || right.is_null() {
        return if left == right {
            0
        } else if left.is_null() {
            -1
        } else {
            1
        };
    }
    let left = CStr::from_ptr(left).to_bytes();
    let right = CStr::from_ptr(right).to_bytes();
    match left.cmp(right) {
        std::cmp::Ordering::Less => -1,
        std::cmp::Ordering::Equal => 0,
        std::cmp::Ordering::Greater => 1,
    }
}

#[no_mangle]
pub unsafe extern "C" fn rl_replace_line(text: *const c_char, clear_undo: c_int) {
    let point = rl_point;
    mark_last_kill(false);
    if clear_undo != 0 {
        lock_editor().undo_stack.clear();
    }
    if text.is_null() {
        set_line_buffer_bytes(&[]);
    } else {
        set_line_buffer_bytes(CStr::from_ptr(text).to_bytes());
    }
    rl_point = point.max(0).min(rl_end);
}

#[no_mangle]
pub unsafe extern "C" fn rl_insert_text(text: *const c_char) -> c_int {
    if text.is_null() {
        return 0;
    }
    mark_last_kill(false);

    let mut line = current_line_bytes();
    let insert = CStr::from_ptr(text).to_bytes();
    let point = if rl_point < 0 {
        0
    } else {
        (rl_point as usize).min(line.len())
    };
    save_undo_snapshot();
    line.splice(point..point, insert.iter().copied());
    set_line_buffer_bytes(&line);
    rl_point = clamp_c_int(point + insert.len());
    rl_end = clamp_c_int(line.len());
    clamp_c_int(insert.len())
}

#[no_mangle]
pub unsafe extern "C" fn rl_delete_text(start: c_int, end: c_int) -> c_int {
    mark_last_kill(false);
    let mut line = current_line_bytes();
    let s = start.min(end).max(0) as usize;
    let e = start.max(end).max(0) as usize;
    if s >= e || s >= line.len() {
        return 0;
    }
    let e = e.min(line.len());
    let point = rl_point;
    save_undo_snapshot();
    line.drain(s..e);
    set_line_buffer_bytes(&line);
    rl_point = point.max(0).min(rl_end);
    rl_end = clamp_c_int(line.len());
    clamp_c_int(e - s)
}

#[no_mangle]
pub unsafe extern "C" fn rl_beginning_of_line(_count: c_int, _key: c_int) -> c_int {
    mark_last_kill(false);
    rl_point = 0;
    0
}

#[no_mangle]
pub unsafe extern "C" fn rl_beg_of_line(count: c_int, key: c_int) -> c_int {
    rl_beginning_of_line(count, key)
}

#[no_mangle]
pub unsafe extern "C" fn rl_end_of_line(_count: c_int, _key: c_int) -> c_int {
    mark_last_kill(false);
    rl_point = rl_end;
    0
}

#[no_mangle]
pub unsafe extern "C" fn rl_forward_char(count: c_int, _key: c_int) -> c_int {
    if count < 0 {
        return rl_backward_char(count.saturating_neg(), 0);
    }
    mark_last_kill(false);
    if count == 0 {
        return 0;
    }
    let line = current_line_bytes();
    let mut point = rl_point.max(0) as usize;
    for _ in 0..count.max(1) {
        let next = next_char_boundary(&line, point);
        if next == point {
            break;
        }
        point = next;
    }
    rl_point = clamp_c_int(point);
    0
}

#[no_mangle]
pub unsafe extern "C" fn rl_forward(count: c_int, key: c_int) -> c_int {
    rl_forward_char(count, key)
}

#[no_mangle]
pub unsafe extern "C" fn rl_forward_byte(count: c_int, key: c_int) -> c_int {
    rl_forward_char(count, key)
}

#[no_mangle]
pub unsafe extern "C" fn rl_backward_char(count: c_int, _key: c_int) -> c_int {
    if count < 0 {
        return rl_forward_char(count.saturating_neg(), 0);
    }
    mark_last_kill(false);
    if count == 0 {
        return 0;
    }
    let line = current_line_bytes();
    let mut point = rl_point.max(0) as usize;
    for _ in 0..count.max(1) {
        let next = previous_char_boundary(&line, point);
        if next == point {
            break;
        }
        point = next;
    }
    rl_point = clamp_c_int(point);
    0
}

#[no_mangle]
pub unsafe extern "C" fn rl_backward(count: c_int, key: c_int) -> c_int {
    rl_backward_char(count, key)
}

#[no_mangle]
pub unsafe extern "C" fn rl_backward_byte(count: c_int, key: c_int) -> c_int {
    rl_backward_char(count, key)
}

#[no_mangle]
pub unsafe extern "C" fn rl_forward_word(count: c_int, _key: c_int) -> c_int {
    if count < 0 {
        return rl_backward_word(count.saturating_neg(), 0);
    }
    mark_last_kill(false);
    if count == 0 {
        return 0;
    }
    let line = current_line_bytes();
    let mut point = current_point();
    for _ in 0..count.max(1) {
        point = next_word_start(&line, point);
        if point >= line.len() {
            point = line.len();
            break;
        }
    }
    rl_point = clamp_c_int(point);
    0
}

#[no_mangle]
pub unsafe extern "C" fn rl_backward_word(count: c_int, _key: c_int) -> c_int {
    if count < 0 {
        return rl_forward_word(count.saturating_neg(), 0);
    }
    mark_last_kill(false);
    if count == 0 {
        return 0;
    }
    let line = current_line_bytes();
    let mut point = current_point();
    for _ in 0..count.max(1) {
        let next = previous_word_start(&line, point);
        if next == point {
            break;
        }
        point = next;
    }
    rl_point = clamp_c_int(point);
    0
}

#[no_mangle]
pub unsafe extern "C" fn rl_delete(count: c_int, _key: c_int) -> c_int {
    if count < 0 {
        return rl_rubout(count.saturating_neg(), 0);
    }
    let line = current_line_bytes();
    let point = rl_point;
    let mut end = rl_point.max(0) as usize;
    for _ in 0..count.max(1) {
        let next = next_char_boundary(&line, end);
        if next == end {
            break;
        }
        end = next;
    }
    let result = rl_delete_text(point, clamp_c_int(end));
    rl_point = point.min(rl_end);
    if result < 0 {
        result
    } else {
        0
    }
}

#[no_mangle]
pub unsafe extern "C" fn rl_rubout(count: c_int, _key: c_int) -> c_int {
    if count < 0 {
        return rl_delete(count.saturating_neg(), 0);
    }
    let line = current_line_bytes();
    let mut start = rl_point.max(0) as usize;
    for _ in 0..count.max(1) {
        let next = previous_char_boundary(&line, start);
        if next == start {
            break;
        }
        start = next;
    }
    let result = rl_delete_text(clamp_c_int(start), rl_point);
    rl_point = clamp_c_int(start.min(current_line_bytes().len()));
    if result < 0 {
        result
    } else {
        0
    }
}

#[no_mangle]
pub unsafe extern "C" fn rl_unix_line_discard(_count: c_int, _key: c_int) -> c_int {
    kill_range(0, current_point(), false, false)
}

#[no_mangle]
pub unsafe extern "C" fn rl_kill_line(_count: c_int, _key: c_int) -> c_int {
    kill_range(current_point(), current_line_bytes().len(), false, false)
}

#[no_mangle]
pub unsafe extern "C" fn rl_backward_kill_line(_count: c_int, _key: c_int) -> c_int {
    kill_range(0, current_point(), true, false)
}

#[no_mangle]
pub unsafe extern "C" fn rl_kill_full_line(_count: c_int, _key: c_int) -> c_int {
    kill_range(0, current_line_bytes().len(), false, false)
}

#[no_mangle]
pub unsafe extern "C" fn rl_kill_word(count: c_int, _key: c_int) -> c_int {
    if count < 0 {
        return rl_backward_kill_word(count.saturating_neg(), 0);
    }
    if count == 0 {
        return 0;
    }
    let line = current_line_bytes();
    let mut end = current_point();
    for _ in 0..count.max(1) {
        let next = next_word_end(&line, end);
        if next == end {
            break;
        }
        end = next;
    }
    kill_range(current_point(), end, false, false)
}

#[no_mangle]
pub unsafe extern "C" fn rl_backward_kill_word(count: c_int, _key: c_int) -> c_int {
    if count < 0 {
        return rl_kill_word(count.saturating_neg(), 0);
    }
    if count == 0 {
        return 0;
    }
    let line = current_line_bytes();
    let mut start = current_point();
    for _ in 0..count.max(1) {
        let next = previous_word_start(&line, start);
        if next == start {
            break;
        }
        start = next;
    }
    kill_range(start, current_point(), true, false)
}

#[no_mangle]
pub unsafe extern "C" fn rl_unix_word_rubout(count: c_int, key: c_int) -> c_int {
    rl_backward_kill_word(count, key)
}

#[no_mangle]
pub unsafe extern "C" fn rl_unix_filename_rubout(count: c_int, _key: c_int) -> c_int {
    let line = current_line_bytes();
    let mut start = current_point();
    for _ in 0..count.max(1) {
        start = previous_filename_word_start(&line, start);
    }
    kill_range(start, current_point(), true, false)
}

#[no_mangle]
pub unsafe extern "C" fn rl_delete_horizontal_space(_count: c_int, _key: c_int) -> c_int {
    let line = current_line_bytes();
    let mut start = current_point();
    let mut end = current_point();
    while start > 0 && matches!(line[start - 1], b' ' | b'\t') {
        start -= 1;
    }
    while end < line.len() && matches!(line[end], b' ' | b'\t') {
        end += 1;
    }
    let result = rl_delete_text(clamp_c_int(start), clamp_c_int(end));
    rl_point = clamp_c_int(start.min(current_line_bytes().len()));
    if result < 0 {
        result
    } else {
        0
    }
}

unsafe fn copy_text_region_bytes(start: usize, end: usize) -> Vec<u8> {
    let line = current_line_bytes();
    let s = start.min(line.len());
    let e = end.min(line.len());
    if s >= e {
        Vec::new()
    } else {
        line[s..e].to_vec()
    }
}

#[no_mangle]
pub unsafe extern "C" fn rl_copy_region_to_kill(_count: c_int, _key: c_int) -> c_int {
    if let Some((start, end)) = region_bounds() {
        let text = copy_text_region_bytes(start, end);
        set_kill_buffer(&text, false, false);
    }
    0
}

#[no_mangle]
pub unsafe extern "C" fn rl_kill_region(_count: c_int, _key: c_int) -> c_int {
    if let Some((start, end)) = region_bounds() {
        return kill_range(start, end, false, false);
    }
    0
}

#[no_mangle]
pub unsafe extern "C" fn rl_copy_forward_word(count: c_int, _key: c_int) -> c_int {
    let line = current_line_bytes();
    let point = current_point();
    let (start, end) = if count < 0 {
        copy_backward_word_bounds(&line, point, count.saturating_neg())
    } else {
        copy_forward_word_bounds(&line, point, count)
    };
    set_kill_buffer(&line[start..end], false, false);
    0
}

#[no_mangle]
pub unsafe extern "C" fn rl_copy_backward_word(count: c_int, _key: c_int) -> c_int {
    let line = current_line_bytes();
    let point = current_point();
    let (start, end) = if count < 0 {
        copy_forward_word_bounds(&line, point, count.saturating_neg())
    } else {
        copy_backward_word_bounds(&line, point, count)
    };
    set_kill_buffer(&line[start..end], false, false);
    0
}

#[no_mangle]
pub unsafe extern "C" fn rl_yank(_count: c_int, _key: c_int) -> c_int {
    let kill = {
        let editor = lock_editor();
        editor.kill_buffer.clone()
    };
    let start = current_point();
    let tmp = dup_bytes(&kill);
    if tmp.is_null() {
        return -1;
    }
    let result = rl_insert_text(tmp);
    free(tmp as *mut c_void);
    if result < 0 {
        result
    } else {
        let mut editor = lock_editor();
        if !kill.is_empty() && editor.kill_ring.is_empty() {
            editor.kill_ring.push(kill.clone());
            editor.kill_ring_index = 0;
        }
        editor.kill_buffer = kill;
        editor.last_yank = Some((start, current_point()));
        0
    }
}

#[no_mangle]
pub extern "C" fn rl_yank_pop(_count: c_int, _key: c_int) -> c_int {
    unsafe {
        let (start, end, replacement) = {
            let mut editor = lock_editor();
            let Some((start, end)) = editor.last_yank else {
                return 0;
            };
            if editor.kill_ring.is_empty() {
                return 0;
            }
            editor.kill_ring_index = (editor.kill_ring_index + 1) % editor.kill_ring.len();
            let replacement = editor.kill_ring[editor.kill_ring_index].clone();
            editor.kill_buffer = replacement.clone();
            (start, end, replacement)
        };

        let _ = rl_begin_undo_group();
        let line_len = current_line_bytes().len();
        let start = start.min(line_len);
        let end = end.min(line_len).max(start);
        let delete_result = rl_delete_text(clamp_c_int(start), clamp_c_int(end));
        if delete_result < 0 {
            let _ = rl_end_undo_group();
            return delete_result;
        }
        rl_point = clamp_c_int(start);
        let tmp = dup_bytes(&replacement);
        if tmp.is_null() {
            let _ = rl_end_undo_group();
            return -1;
        }
        let insert_result = rl_insert_text(tmp);
        free(tmp as *mut c_void);
        if insert_result < 0 {
            let _ = rl_end_undo_group();
            insert_result
        } else {
            let _ = rl_end_undo_group();
            let mut editor = lock_editor();
            editor.kill_buffer = replacement;
            editor.last_yank = Some((start, current_point()));
            0
        }
    }
}

#[no_mangle]
pub unsafe extern "C" fn rl_yank_nth_arg(count: c_int, _key: c_int) -> c_int {
    let hist = lock_history();
    let Some(entry) = hist.entries.last() else {
        return 0;
    };
    let line = entry_line_bytes(entry);
    drop(hist);
    let index = count.max(0);
    if let Some(arg) = extract_history_args(&line, index, index) {
        let tmp = dup_bytes(&arg);
        if tmp.is_null() {
            return -1;
        }
        let result = rl_insert_text(tmp);
        free(tmp as *mut c_void);
        return if result < 0 { result } else { 0 };
    }
    0
}

#[no_mangle]
pub unsafe extern "C" fn rl_yank_last_arg(count: c_int, key: c_int) -> c_int {
    let _ = key;
    rl_yank_nth_arg(if count <= 0 { c_int::MAX } else { count }, 0)
}

#[no_mangle]
pub unsafe extern "C" fn rl_set_mark(_count: c_int, _key: c_int) -> c_int {
    let point = current_point();
    let mut editor = lock_editor();
    editor.mark = point;
    editor.mark_active = true;
    rl_mark = clamp_c_int(point);
    0
}

#[no_mangle]
pub extern "C" fn rl_activate_mark() {
    let mut editor = lock_editor();
    editor.mark_active = true;
}

#[no_mangle]
pub extern "C" fn rl_deactivate_mark() {
    let mut editor = lock_editor();
    editor.mark_active = false;
}

#[no_mangle]
pub extern "C" fn rl_mark_active_p() -> c_int {
    if lock_editor().mark_active {
        1
    } else {
        0
    }
}

#[no_mangle]
pub unsafe extern "C" fn rl_exchange_point_and_mark(_count: c_int, _key: c_int) -> c_int {
    let point = current_point();
    let mut editor = lock_editor();
    let mark = editor.mark;
    editor.mark = point;
    drop(editor);
    set_point(mark);
    0
}

#[no_mangle]
pub unsafe extern "C" fn rl_transpose_chars(_count: c_int, _key: c_int) -> c_int {
    if _count <= 0 {
        return 0;
    }
    let mut line = current_line_bytes();
    if line.len() < 2 {
        return 0;
    }
    save_undo_snapshot();
    let mut point = current_point().min(line.len());
    for _ in 0.._count {
        let right = if point == line.len() {
            point - 1
        } else {
            point
        };
        let left = previous_char_boundary(&line, right);
        if left == right {
            break;
        }
        let next = next_char_boundary(&line, right);
        let left_bytes = line[left..right].to_vec();
        let right_bytes = line[right..next].to_vec();
        line.splice(
            left..next,
            right_bytes.iter().chain(left_bytes.iter()).copied(),
        );
        point = next;
    }
    set_line_buffer_bytes(&line);
    rl_point = clamp_c_int(point);
    0
}

#[no_mangle]
pub unsafe extern "C" fn rl_upcase_word(count: c_int, _key: c_int) -> c_int {
    rl_change_word_case(count, |byte| byte.to_ascii_uppercase())
}

#[no_mangle]
pub unsafe extern "C" fn rl_downcase_word(count: c_int, _key: c_int) -> c_int {
    rl_change_word_case(count, |byte| byte.to_ascii_lowercase())
}

#[no_mangle]
pub unsafe extern "C" fn rl_capitalize_word(count: c_int, _key: c_int) -> c_int {
    let mut first = true;
    rl_change_word_case(count, |byte| {
        if word_byte(byte) {
            if byte.is_ascii_alphabetic() && first {
                first = false;
                byte.to_ascii_uppercase()
            } else {
                first = false;
                byte.to_ascii_lowercase()
            }
        } else {
            first = true;
            byte
        }
    })
}

unsafe fn rl_change_word_case<F>(count: c_int, mut change: F) -> c_int
where
    F: FnMut(u8) -> u8,
{
    if count == 0 {
        return 0;
    }
    let mut line = current_line_bytes();
    let len = line.len();
    let point = current_point().min(len);
    let (start, end, new_point) = if count > 0 {
        let start = point;
        let mut end = point;
        for _ in 0..count {
            end = next_word_end(&line, end);
        }
        (start.min(len), end.min(len), end.min(len))
    } else {
        let end = point;
        let mut start = point;
        for _ in 0..count.saturating_neg() {
            start = previous_word_start(&line, start);
        }
        (start.min(len), end, point)
    };
    if start >= end {
        return 0;
    }
    save_undo_snapshot();
    for byte in &mut line[start..end] {
        *byte = change(*byte);
    }
    set_line_buffer_bytes(&line);
    rl_point = clamp_c_int(new_point);
    0
}

#[no_mangle]
pub unsafe extern "C" fn rl_do_undo() -> c_int {
    let mut editor = lock_editor();
    let Some(snapshot) = editor.undo_stack.pop() else {
        return 0;
    };
    drop(editor);
    set_line_buffer_bytes(&snapshot.line);
    set_point(snapshot.point);
    1
}

#[no_mangle]
pub unsafe extern "C" fn rl_undo_command(_count: c_int, _key: c_int) -> c_int {
    let result = rl_do_undo();
    if result < 0 {
        result
    } else {
        0
    }
}

#[no_mangle]
pub unsafe extern "C" fn rl_begin_undo_group() -> c_int {
    let snapshot = current_undo_snapshot();
    let mut editor = lock_editor();
    if editor.undo_group_depth == 0 {
        editor.undo_group_snapshot = Some(snapshot);
    }
    editor.undo_group_depth = editor.undo_group_depth.saturating_add(1);
    0
}

#[no_mangle]
pub unsafe extern "C" fn rl_end_undo_group() -> c_int {
    let current = current_undo_snapshot();
    let mut editor = lock_editor();
    if editor.undo_group_depth == 0 {
        return 0;
    }
    editor.undo_group_depth -= 1;
    if editor.undo_group_depth == 0 {
        if let Some(snapshot) = editor.undo_group_snapshot.take() {
            if snapshot.line != current.line || snapshot.point != current.point {
                push_undo_snapshot(&mut editor, snapshot);
            }
        }
    }
    0
}

#[no_mangle]
pub unsafe extern "C" fn rl_add_undo(
    _what: c_int,
    _start: c_int,
    _end: c_int,
    _text: *mut c_char,
) -> c_int {
    save_undo_snapshot();
    0
}

#[no_mangle]
pub extern "C" fn rl_free_undo_list() {
    let mut editor = lock_editor();
    editor.undo_stack.clear();
    editor.undo_group_depth = 0;
    editor.undo_group_snapshot = None;
}

#[no_mangle]
pub unsafe extern "C" fn rl_maybe_save_line() -> c_int {
    let mut editor = lock_editor();
    if editor.saved_line.is_none() {
        editor.saved_line = Some(current_line_bytes());
    }
    0
}

#[no_mangle]
pub unsafe extern "C" fn rl_maybe_unsave_line() -> c_int {
    let mut editor = lock_editor();
    let Some(line) = editor.saved_line.take() else {
        return 0;
    };
    drop(editor);
    set_line_buffer_bytes(&line);
    0
}

#[no_mangle]
pub unsafe extern "C" fn rl_maybe_replace_line() -> c_int {
    rl_maybe_unsave_line()
}

#[no_mangle]
pub unsafe extern "C" fn rl_revert_line(_count: c_int, _key: c_int) -> c_int {
    rl_maybe_unsave_line()
}

#[no_mangle]
pub extern "C" fn rl_bind_key(key: c_int, function: rl_command_func_t) -> c_int {
    unsafe { rl_bind_key_in_map(key, function, rl_get_keymap()) }
}

#[no_mangle]
pub extern "C" fn rl_bind_key_in_map(
    key: c_int,
    function: rl_command_func_t,
    map: *mut c_void,
) -> c_int {
    if !(0..=u8::MAX as c_int).contains(&key) {
        return -1;
    }
    unsafe {
        let Some(keymap) = keymap_data_mut(map) else {
            return -1;
        };
        keymap.key_bindings[key as usize] = function;
        keymap
            .macro_bindings
            .retain(|(existing, _)| existing.as_slice() != [key as u8]);
        rebuild_keyseq_index(keymap);
        if key == b'\t' as c_int {
            let mut editor = lock_editor();
            let complete = function
                .map(|func| func as *const () == rl_complete as *const ())
                .unwrap_or(false);
            let insert = function
                .map(|func| func as *const () == rl_insert as *const ())
                .unwrap_or(false);
            if complete {
                editor.tab_completes = true;
            } else if insert {
                editor.tab_completes = false;
            }
        } else if key == 0x02 {
            let mut editor = lock_editor();
            editor.ctrl_b_backward = true;
        }
    }
    0
}

#[no_mangle]
pub unsafe extern "C" fn rl_bind_keyseq(
    keyseq: *const c_char,
    function: rl_command_func_t,
) -> c_int {
    rl_bind_keyseq_in_map(keyseq, function, rl_get_keymap())
}

#[no_mangle]
pub unsafe extern "C" fn rl_bind_keyseq_in_map(
    keyseq: *const c_char,
    function: rl_command_func_t,
    map: *mut c_void,
) -> c_int {
    if keyseq.is_null() {
        return -1;
    }
    let seq = parse_keyseq_bytes(CStr::from_ptr(keyseq).to_bytes());
    if seq.is_empty() {
        return -1;
    }
    let Some(keymap) = keymap_data_mut(map) else {
        return -1;
    };
    keymap
        .keyseq_bindings
        .retain(|(existing, _)| existing != &seq);
    keymap
        .macro_bindings
        .retain(|(existing, _)| existing != &seq);
    keymap.keyseq_bindings.push((seq, function));
    rebuild_keyseq_index(keymap);
    0
}

#[no_mangle]
pub unsafe extern "C" fn rl_bind_key_if_unbound(key: c_int, function: rl_command_func_t) -> c_int {
    if !(0..=u8::MAX as c_int).contains(&key) {
        return -1;
    }
    let Some(keymap) = keymap_data(rl_get_keymap()) else {
        return -1;
    };
    if keymap.key_bindings[key as usize].is_some() {
        0
    } else {
        rl_bind_key(key, function)
    }
}

#[no_mangle]
pub unsafe extern "C" fn rl_bind_key_if_unbound_in_map(
    key: c_int,
    function: rl_command_func_t,
    map: *mut c_void,
) -> c_int {
    if !(0..=u8::MAX as c_int).contains(&key) {
        return -1;
    }
    let Some(keymap) = keymap_data(map) else {
        return -1;
    };
    if keymap.key_bindings[key as usize].is_some() {
        0
    } else {
        rl_bind_key_in_map(key, function, map)
    }
}

#[no_mangle]
pub unsafe extern "C" fn rl_bind_keyseq_if_unbound(
    keyseq: *const c_char,
    function: rl_command_func_t,
) -> c_int {
    if keyseq.is_null() {
        return -1;
    }
    let seq = parse_keyseq_bytes(CStr::from_ptr(keyseq).to_bytes());
    let Some(keymap) = keymap_data(rl_get_keymap()) else {
        return -1;
    };
    if keymap
        .keyseq_bindings
        .iter()
        .any(|(existing, _)| existing == &seq)
    {
        0
    } else {
        rl_bind_keyseq(keyseq, function)
    }
}

#[no_mangle]
pub unsafe extern "C" fn rl_bind_keyseq_if_unbound_in_map(
    keyseq: *const c_char,
    function: rl_command_func_t,
    map: *mut c_void,
) -> c_int {
    if keyseq.is_null() {
        return -1;
    }
    let seq = parse_keyseq_bytes(CStr::from_ptr(keyseq).to_bytes());
    let Some(keymap) = keymap_data(map) else {
        return -1;
    };
    if keymap
        .keyseq_bindings
        .iter()
        .any(|(existing, _)| existing == &seq)
    {
        0
    } else {
        rl_bind_keyseq_in_map(keyseq, function, map)
    }
}

#[no_mangle]
pub unsafe extern "C" fn rl_unbind_key(key: c_int) -> c_int {
    if !(0..=u8::MAX as c_int).contains(&key) {
        return -1;
    }
    rl_unbind_key_in_map(key, rl_get_keymap())
}

#[no_mangle]
pub unsafe extern "C" fn rl_unbind_key_in_map(key: c_int, map: *mut c_void) -> c_int {
    if !(0..=u8::MAX as c_int).contains(&key) {
        return -1;
    }
    let Some(keymap) = keymap_data_mut(map) else {
        return -1;
    };
    keymap.key_bindings[key as usize] = None;
    keymap
        .macro_bindings
        .retain(|(existing, _)| existing.as_slice() != [key as u8]);
    rebuild_keyseq_index(keymap);
    0
}

#[no_mangle]
pub extern "C" fn rl_unbind_function_in_map(
    function: rl_command_func_t,
    map: *mut c_void,
) -> c_int {
    let Some(function) = function else {
        return -1;
    };
    unsafe {
        let Some(keymap) = keymap_data_mut(map) else {
            return -1;
        };
        for binding in &mut keymap.key_bindings {
            if same_command(*binding, Some(function)) {
                *binding = None;
            }
        }
        keymap
            .keyseq_bindings
            .retain(|(_, bound)| !same_command(*bound, Some(function)));
        rebuild_keyseq_index(keymap);
    }
    0
}

#[no_mangle]
pub extern "C" fn rl_unbind_command_in_map(command: *const c_char, map: *mut c_void) -> c_int {
    unsafe {
        let function = rl_named_function(command);
        if function.is_none() {
            -1
        } else {
            rl_unbind_function_in_map(function, map)
        }
    }
}

unsafe fn command_from_unsafe(
    function: unsafe extern "C" fn(c_int, c_int) -> c_int,
) -> rl_command_func_t {
    Some(std::mem::transmute::<
        unsafe extern "C" fn(c_int, c_int) -> c_int,
        extern "C" fn(c_int, c_int) -> c_int,
    >(function))
}

fn command_from_safe(function: extern "C" fn(c_int, c_int) -> c_int) -> rl_command_func_t {
    Some(function)
}

unsafe fn command_name(function: rl_command_func_t) -> &'static [u8] {
    let Some(function) = function else {
        return b"";
    };
    let ptr = function as *const ();
    if ptr == rl_insert as *const () {
        b"self-insert"
    } else if ptr == rl_complete as *const () {
        b"complete"
    } else if ptr == rl_beginning_of_line as *const () || ptr == rl_beg_of_line as *const () {
        b"beginning-of-line"
    } else if ptr == rl_end_of_line as *const () {
        b"end-of-line"
    } else if ptr == rl_forward_char as *const () || ptr == rl_forward as *const () {
        b"forward-char"
    } else if ptr == rl_backward_char as *const () || ptr == rl_backward as *const () {
        b"backward-char"
    } else if ptr == rl_delete as *const () {
        b"delete-char"
    } else if ptr == rl_rubout as *const () {
        b"backward-delete-char"
    } else if ptr == rl_kill_line as *const () {
        b"kill-line"
    } else if ptr == rl_unix_line_discard as *const () {
        b"unix-line-discard"
    } else if ptr == rl_yank as *const () {
        b"yank"
    } else {
        b"readlineoxide-function"
    }
}

#[no_mangle]
pub unsafe extern "C" fn rl_named_function(name: *const c_char) -> rl_command_func_t {
    if name.is_null() {
        return None;
    }
    let name = CStr::from_ptr(name).to_bytes();
    if let Some((_, function)) = lock_funmap()
        .iter()
        .find(|(registered, _)| registered.as_slice() == name)
    {
        return *function;
    }
    match name {
        b"self-insert" | b"insert" => command_from_unsafe(rl_insert),
        b"complete" => command_from_unsafe(rl_complete),
        b"possible-completions" => command_from_unsafe(rl_possible_completions),
        b"insert-completions" => command_from_unsafe(rl_insert_completions),
        b"menu-complete" => command_from_unsafe(rl_menu_complete),
        b"old-menu-complete" => command_from_unsafe(rl_old_menu_complete),
        b"menu-complete-backward" | b"backward-menu-complete" => {
            command_from_unsafe(rl_backward_menu_complete)
        }
        b"delete-char-or-list" => command_from_unsafe(rl_delete_or_show_completions),
        b"beginning-of-line" | b"beg-of-line" => command_from_unsafe(rl_beginning_of_line),
        b"end-of-line" => command_from_unsafe(rl_end_of_line),
        b"forward-char" | b"forward" => command_from_unsafe(rl_forward_char),
        b"backward-char" | b"backward" => command_from_unsafe(rl_backward_char),
        b"forward-byte" => command_from_unsafe(rl_forward_byte),
        b"backward-byte" => command_from_unsafe(rl_backward_byte),
        b"forward-word" => command_from_unsafe(rl_forward_word),
        b"backward-word" => command_from_unsafe(rl_backward_word),
        b"delete-char" | b"delete" => command_from_unsafe(rl_delete),
        b"backward-delete-char" | b"rubout" => command_from_unsafe(rl_rubout),
        b"rubout-or-delete" => command_from_unsafe(rl_rubout_or_delete),
        b"kill-line" => command_from_unsafe(rl_kill_line),
        b"backward-kill-line" => command_from_unsafe(rl_backward_kill_line),
        b"kill-whole-line" => command_from_unsafe(rl_kill_full_line),
        b"unix-line-discard" => command_from_unsafe(rl_unix_line_discard),
        b"kill-word" => command_from_unsafe(rl_kill_word),
        b"backward-kill-word" | b"unix-word-rubout" => command_from_unsafe(rl_backward_kill_word),
        b"unix-filename-rubout" => command_from_unsafe(rl_unix_filename_rubout),
        b"delete-horizontal-space" => command_from_unsafe(rl_delete_horizontal_space),
        b"copy-region-as-kill" => command_from_unsafe(rl_copy_region_to_kill),
        b"kill-region" => command_from_unsafe(rl_kill_region),
        b"copy-forward-word" => command_from_unsafe(rl_copy_forward_word),
        b"copy-backward-word" => command_from_unsafe(rl_copy_backward_word),
        b"yank" => command_from_unsafe(rl_yank),
        b"yank-pop" => command_from_safe(rl_yank_pop),
        b"yank-nth-arg" => command_from_unsafe(rl_yank_nth_arg),
        b"yank-last-arg" | b"insert-last-argument" => command_from_unsafe(rl_yank_last_arg),
        b"set-mark" => command_from_unsafe(rl_set_mark),
        b"exchange-point-and-mark" => command_from_unsafe(rl_exchange_point_and_mark),
        b"transpose-chars" => command_from_unsafe(rl_transpose_chars),
        b"transpose-words" => command_from_unsafe(rl_transpose_words),
        b"upcase-word" => command_from_unsafe(rl_upcase_word),
        b"downcase-word" => command_from_unsafe(rl_downcase_word),
        b"capitalize-word" => command_from_unsafe(rl_capitalize_word),
        b"undo" => command_from_unsafe(rl_undo_command),
        b"revert-line" => command_from_unsafe(rl_revert_line),
        b"abort" => command_from_safe(rl_abort),
        b"newline" | b"accept-line" => command_from_unsafe(rl_newline),
        b"clear-screen" => command_from_safe(rl_clear_screen),
        b"redraw-current-line" => command_from_safe(rl_refresh_line),
        b"character-search" => command_from_unsafe(rl_char_search),
        b"character-search-backward" => command_from_unsafe(rl_backward_char_search),
        b"bracketed-paste-begin" => command_from_unsafe(rl_bracketed_paste_begin),
        b"digit-argument" => command_from_safe(rl_digit_argument),
        b"universal-argument" => command_from_safe(rl_universal_argument),
        b"do-lowercase-version" => command_from_safe(rl_do_lowercase_version),
        b"emacs-editing-mode" => command_from_safe(rl_emacs_editing_mode),
        b"start-kbd-macro" => command_from_safe(rl_start_kbd_macro),
        b"end-kbd-macro" => command_from_safe(rl_end_kbd_macro),
        b"call-last-kbd-macro" => command_from_unsafe(rl_call_last_kbd_macro),
        b"export-completions" => command_from_unsafe(rl_export_completions),
        b"insert-comment" => command_from_unsafe(rl_insert_comment),
        b"history-substr-search-forward" | b"history-substring-search-forward" => {
            command_from_unsafe(rl_history_substr_search_forward)
        }
        b"history-substr-search-backward" | b"history-substring-search-backward" => {
            command_from_unsafe(rl_history_substr_search_backward)
        }
        b"next-screen-line" => command_from_safe(rl_next_screen_line),
        b"previous-screen-line" => command_from_safe(rl_previous_screen_line),
        b"non-incremental-forward-search-history" => command_from_unsafe(rl_noninc_forward_search),
        b"non-incremental-reverse-search-history" => command_from_unsafe(rl_noninc_reverse_search),
        b"non-incremental-forward-search-history-again" => {
            command_from_unsafe(rl_noninc_forward_search_again)
        }
        b"non-incremental-reverse-search-history-again" => {
            command_from_unsafe(rl_noninc_reverse_search_again)
        }
        b"forward-search-history" => command_from_unsafe(rl_forward_search_history),
        b"reverse-search-history" => command_from_unsafe(rl_reverse_search_history),
        b"history-search-forward" => command_from_unsafe(rl_history_search_forward),
        b"history-search-backward" => command_from_unsafe(rl_history_search_backward),
        b"overwrite-mode" => command_from_safe(rl_overwrite_mode),
        b"quoted-insert" => command_from_unsafe(rl_quoted_insert),
        b"re-read-init-file" => command_from_unsafe(rl_re_read_init_file),
        b"restart-output" => command_from_safe(rl_restart_output),
        b"stop-output" => command_from_safe(rl_stop_output),
        b"tab-insert" => command_from_unsafe(rl_tab_insert),
        b"tilde-expand" => command_from_unsafe(rl_tilde_expand),
        b"previous-history" => command_from_safe(rl_get_previous_history),
        b"next-history" => command_from_safe(rl_get_next_history),
        b"beginning-of-history" => command_from_safe(rl_beginning_of_history),
        b"end-of-history" => command_from_safe(rl_end_of_history),
        b"operate-and-get-next" => command_from_unsafe(rl_operate_and_get_next),
        b"vi-append-eol" => command_from_unsafe(rl_vi_append_eol),
        b"vi-append-mode" => command_from_unsafe(rl_vi_append_mode),
        b"vi-arg-digit" => command_from_unsafe(rl_vi_arg_digit),
        b"vi-bword" => command_from_unsafe(rl_vi_bword),
        b"vi-bWord" => command_from_unsafe(rl_vi_bWord),
        b"vi-back-to-indent" => command_from_unsafe(rl_vi_back_to_indent),
        b"vi-bracktype" => command_from_safe(rl_vi_bracktype),
        b"vi-change-case" => command_from_unsafe(rl_vi_change_case),
        b"vi-change-char" => command_from_unsafe(rl_vi_change_char),
        b"vi-change-to" => command_from_unsafe(rl_vi_change_to),
        b"vi-char-search" => command_from_unsafe(rl_vi_char_search),
        b"vi-check" => command_from_safe(rl_vi_check),
        b"vi-column" => command_from_unsafe(rl_vi_column),
        b"vi-complete" => command_from_unsafe(rl_vi_complete),
        b"vi-delete" => command_from_unsafe(rl_vi_delete),
        b"vi-delete-to" => command_from_unsafe(rl_vi_delete_to),
        b"vi-domove" => command_from_unsafe(rl_vi_domove),
        b"vi-editing-mode" | b"vi-mode" => command_from_safe(rl_vi_editing_mode),
        b"vi-end-word" => command_from_unsafe(rl_vi_end_word),
        b"vi-eof-maybe" => command_from_unsafe(rl_vi_eof_maybe),
        b"vi-eword" => command_from_unsafe(rl_vi_eword),
        b"vi-eWord" => command_from_unsafe(rl_vi_eWord),
        b"vi-fetch-history" => command_from_unsafe(rl_vi_fetch_history),
        b"vi-first-print" => command_from_unsafe(rl_vi_first_print),
        b"vi-fword" => command_from_unsafe(rl_vi_fword),
        b"vi-fWord" => command_from_unsafe(rl_vi_fWord),
        b"vi-goto-mark" => command_from_unsafe(rl_vi_goto_mark),
        b"vi-insert-beg" => command_from_unsafe(rl_vi_insert_beg),
        b"vi-insert-mode" => command_from_unsafe(rl_vi_insert_mode),
        b"vi-insertion-mode" => command_from_unsafe(rl_vi_insertion_mode),
        b"vi-match" => command_from_unsafe(rl_vi_match),
        b"vi-movement-mode" => command_from_unsafe(rl_vi_movement_mode),
        b"vi-next-word" => command_from_unsafe(rl_vi_next_word),
        b"vi-overstrike" => command_from_unsafe(rl_vi_overstrike),
        b"vi-overstrike-delete" => command_from_safe(rl_vi_overstrike_delete),
        b"vi-prev-word" => command_from_unsafe(rl_vi_prev_word),
        b"vi-put" => command_from_unsafe(rl_vi_put),
        b"vi-redo" => command_from_unsafe(rl_vi_redo),
        b"vi-replace" => command_from_unsafe(rl_vi_replace),
        b"vi-rubout" => command_from_unsafe(rl_vi_rubout),
        b"vi-search" => command_from_unsafe(rl_vi_search),
        b"vi-search-again" => command_from_unsafe(rl_vi_search_again),
        b"vi-set-mark" => command_from_unsafe(rl_vi_set_mark),
        b"vi-start-inserting" => command_from_unsafe(rl_vi_start_inserting),
        b"vi-subst" => command_from_unsafe(rl_vi_subst),
        b"vi-tilde-expand" => command_from_unsafe(rl_vi_tilde_expand),
        b"vi-undo" => command_from_unsafe(rl_vi_undo),
        b"vi-unix-word-rubout" => command_from_unsafe(rl_vi_unix_word_rubout),
        b"vi-yank-arg" => command_from_unsafe(rl_vi_yank_arg),
        b"vi-yank-pop" => command_from_safe(rl_vi_yank_pop),
        b"vi-yank-to" => command_from_unsafe(rl_vi_yank_to),
        _ => None,
    }
}

#[no_mangle]
pub unsafe extern "C" fn rl_function_of_keyseq(
    keyseq: *const c_char,
    map: *mut c_void,
    type_out: rl_keyseq_type_ptr_t,
) -> rl_command_func_t {
    if keyseq.is_null() {
        return None;
    }
    let seq = parse_keyseq_bytes(CStr::from_ptr(keyseq).to_bytes());
    let (function, binding_type) = if let Some(keymap) = keymap_data(map) {
        if keymap.keyseq_macro_index.contains_key(&seq)
        {
            (None, KEYSEQ_TYPE_MACRO)
        } else {
            let exact = keymap
                .keyseq_function_index
                .get(&seq)
                .and_then(|func| *func);
            if exact.is_some() {
                (exact, KEYSEQ_TYPE_FUNCTION)
            } else if seq.len() == 1 {
                (keymap.key_bindings[seq[0] as usize], KEYSEQ_TYPE_FUNCTION)
            } else {
                (None, KEYSEQ_TYPE_FUNCTION)
            }
        }
    } else {
        (None, KEYSEQ_TYPE_FUNCTION)
    };
    if !type_out.is_null() {
        *type_out = if function.is_some() || binding_type == KEYSEQ_TYPE_MACRO {
            binding_type
        } else {
            KEYSEQ_TYPE_FUNCTION
        };
    }
    function
}

#[no_mangle]
pub unsafe extern "C" fn rl_function_of_keyseq_len(
    keyseq: *const c_char,
    len: c_int,
    map: *mut c_void,
    type_out: rl_keyseq_type_ptr_t,
) -> rl_command_func_t {
    if keyseq.is_null() || len < 0 {
        return None;
    }
    let bytes = CStr::from_ptr(keyseq).to_bytes();
    let end = (len as usize).min(bytes.len());
    let tmp = dup_bytes(&bytes[..end]);
    if tmp.is_null() {
        return None;
    }
    let result = rl_function_of_keyseq(tmp, map, type_out);
    free(tmp as *mut c_void);
    result
}

#[no_mangle]
pub unsafe extern "C" fn rl_add_funmap_entry(
    name: *const c_char,
    function: rl_command_func_t,
) -> c_int {
    if name.is_null() || function.is_none() {
        return 0;
    }
    let name = CStr::from_ptr(name).to_bytes().to_vec();
    let mut funmap = lock_funmap();
    funmap.retain(|(existing, _)| existing != &name);
    funmap.push((name, function));
    1
}

#[no_mangle]
pub unsafe extern "C" fn rl_generic_bind(
    type_id: c_int,
    keyseq: *const c_char,
    data: *const c_char,
    map: *mut c_void,
) -> c_int {
    if keyseq.is_null() {
        return -1;
    }
    match type_id {
        0 => rl_bind_keyseq_in_map(keyseq, rl_named_function(data), map),
        1 => {
            let bytes = if data.is_null() {
                Vec::new()
            } else {
                CStr::from_ptr(data).to_bytes().to_vec()
            };
            let keyseq = parse_keyseq_bytes(CStr::from_ptr(keyseq).to_bytes());
            if keyseq.is_empty() {
                -1
            } else {
                if keyseq == [0x01] {
                    lock_editor().ctrl_a_macro = bytes.clone();
                }
                bind_macro_in_map(keyseq, bytes, map)
            }
        }
        _ => -1,
    }
}

#[no_mangle]
pub unsafe extern "C" fn rl_macro_bind(
    keyseq: *const c_char,
    macro_text: *const c_char,
    map: *mut c_void,
) -> c_int {
    rl_generic_bind(1, keyseq, macro_text, map)
}

#[no_mangle]
pub unsafe extern "C" fn rl_translate_keyseq(
    keyseq: *const c_char,
    array: *mut c_char,
    len: *mut c_int,
) -> c_int {
    if keyseq.is_null() {
        return -1;
    }
    let bytes = parse_keyseq_bytes(CStr::from_ptr(keyseq).to_bytes());
    if !array.is_null() {
        ptr::copy_nonoverlapping(bytes.as_ptr() as *const c_char, array, bytes.len());
    }
    if !len.is_null() {
        *len = clamp_c_int(bytes.len());
    }
    0
}

unsafe fn keyseqs_to_c_array(seqs: &[Vec<u8>]) -> *mut *mut c_char {
    let raw = malloc((seqs.len() + 1) * std::mem::size_of::<*mut c_char>()) as *mut *mut c_char;
    if raw.is_null() {
        return ptr::null_mut();
    }
    for (idx, seq) in seqs.iter().enumerate() {
        let item = dup_bytes(seq);
        if item.is_null() {
            for prev in 0..idx {
                free(*raw.add(prev) as *mut c_void);
            }
            free(raw as *mut c_void);
            return ptr::null_mut();
        }
        *raw.add(idx) = item;
    }
    *raw.add(seqs.len()) = ptr::null_mut();
    raw
}

#[no_mangle]
pub unsafe extern "C" fn rl_invoking_keyseqs(function: rl_command_func_t) -> *mut *mut c_char {
    rl_invoking_keyseqs_in_map(function, rl_get_keymap())
}

#[no_mangle]
pub unsafe extern "C" fn rl_invoking_keyseqs_in_map(
    function: rl_command_func_t,
    map: *mut c_void,
) -> *mut *mut c_char {
    let Some(keymap) = keymap_data(map) else {
        return keyseqs_to_c_array(&[]);
    };
    let mut seqs = Vec::new();
    for (key, binding) in keymap.key_bindings.iter().enumerate() {
        if same_command(*binding, function) {
            seqs.push(keyseq_display_bytes(&[key as u8]));
        }
    }
    for (seq, binding) in &keymap.keyseq_bindings {
        if same_command(*binding, function) {
            seqs.push(keyseq_display_bytes(seq));
        }
    }
    keyseqs_to_c_array(&seqs)
}

#[no_mangle]
pub unsafe extern "C" fn rl_funmap_names() -> *mut *mut c_char {
    const NAMES: &[&[u8]] = &[
        b"self-insert",
        b"complete",
        b"possible-completions",
        b"insert-completions",
        b"menu-complete",
        b"old-menu-complete",
        b"menu-complete-backward",
        b"delete-char-or-list",
        b"beginning-of-line",
        b"end-of-line",
        b"forward-char",
        b"backward-char",
        b"forward-byte",
        b"backward-byte",
        b"forward-word",
        b"backward-word",
        b"delete-char",
        b"backward-delete-char",
        b"rubout-or-delete",
        b"kill-line",
        b"backward-kill-line",
        b"kill-whole-line",
        b"unix-line-discard",
        b"kill-word",
        b"backward-kill-word",
        b"unix-word-rubout",
        b"unix-filename-rubout",
        b"delete-horizontal-space",
        b"copy-region-as-kill",
        b"kill-region",
        b"copy-forward-word",
        b"copy-backward-word",
        b"yank",
        b"yank-pop",
        b"yank-nth-arg",
        b"yank-last-arg",
        b"insert-last-argument",
        b"set-mark",
        b"exchange-point-and-mark",
        b"transpose-chars",
        b"transpose-words",
        b"upcase-word",
        b"downcase-word",
        b"capitalize-word",
        b"undo",
        b"revert-line",
        b"abort",
        b"accept-line",
        b"clear-screen",
        b"redraw-current-line",
        b"character-search",
        b"character-search-backward",
        b"bracketed-paste-begin",
        b"digit-argument",
        b"universal-argument",
        b"do-lowercase-version",
        b"emacs-editing-mode",
        b"start-kbd-macro",
        b"end-kbd-macro",
        b"call-last-kbd-macro",
        b"export-completions",
        b"insert-comment",
        b"history-substring-search-forward",
        b"history-substring-search-backward",
        b"next-screen-line",
        b"previous-screen-line",
        b"non-incremental-forward-search-history",
        b"non-incremental-reverse-search-history",
        b"non-incremental-forward-search-history-again",
        b"non-incremental-reverse-search-history-again",
        b"forward-search-history",
        b"reverse-search-history",
        b"history-search-forward",
        b"history-search-backward",
        b"overwrite-mode",
        b"quoted-insert",
        b"re-read-init-file",
        b"restart-output",
        b"stop-output",
        b"tab-insert",
        b"tilde-expand",
        b"previous-history",
        b"next-history",
        b"beginning-of-history",
        b"end-of-history",
        b"operate-and-get-next",
        b"vi-append-eol",
        b"vi-append-mode",
        b"vi-arg-digit",
        b"vi-bword",
        b"vi-bWord",
        b"vi-back-to-indent",
        b"vi-bracktype",
        b"vi-change-case",
        b"vi-change-char",
        b"vi-change-to",
        b"vi-char-search",
        b"vi-check",
        b"vi-column",
        b"vi-complete",
        b"vi-delete",
        b"vi-delete-to",
        b"vi-domove",
        b"vi-editing-mode",
        b"vi-mode",
        b"vi-end-word",
        b"vi-eof-maybe",
        b"vi-eword",
        b"vi-eWord",
        b"vi-fetch-history",
        b"vi-first-print",
        b"vi-fword",
        b"vi-fWord",
        b"vi-goto-mark",
        b"vi-insert-beg",
        b"vi-insert-mode",
        b"vi-insertion-mode",
        b"vi-match",
        b"vi-movement-mode",
        b"vi-next-word",
        b"vi-overstrike",
        b"vi-overstrike-delete",
        b"vi-prev-word",
        b"vi-put",
        b"vi-redo",
        b"vi-replace",
        b"vi-rubout",
        b"vi-search",
        b"vi-search-again",
        b"vi-set-mark",
        b"vi-start-inserting",
        b"vi-subst",
        b"vi-tilde-expand",
        b"vi-undo",
        b"vi-unix-word-rubout",
        b"vi-yank-arg",
        b"vi-yank-pop",
        b"vi-yank-to",
    ];
    let funmap = lock_funmap();
    let raw = malloc((NAMES.len() + funmap.len() + 1) * std::mem::size_of::<*mut c_char>())
        as *mut *mut c_char;
    if raw.is_null() {
        return ptr::null_mut();
    }
    for (idx, name) in NAMES.iter().enumerate() {
        *raw.add(idx) = dup_bytes(name);
    }
    for (idx, (name, _)) in funmap.iter().enumerate() {
        *raw.add(NAMES.len() + idx) = dup_bytes(name);
    }
    *raw.add(NAMES.len() + funmap.len()) = ptr::null_mut();
    raw
}

#[no_mangle]
pub unsafe extern "C" fn rl_list_funmap_names() {
    let names = rl_funmap_names();
    if names.is_null() {
        return;
    }
    let mut idx = 0usize;
    loop {
        let name = *names.add(idx);
        if name.is_null() {
            break;
        }
        output_c_string(name);
        output_bytes(b"\n");
        free(name as *mut c_void);
        idx += 1;
    }
    free(names as *mut c_void);
}

#[no_mangle]
pub unsafe extern "C" fn rl_print_keybinding(keyseq: *const c_char, function: rl_command_func_t) {
    output_c_string(keyseq);
    output_bytes(b": ");
    output_bytes(command_name(function));
    output_bytes(b"\n");
}

#[no_mangle]
pub unsafe extern "C" fn rl_function_dumper(_readable: c_int) {
    rl_list_funmap_names();
}

fn quoted_inputrc_bytes(bytes: &[u8]) -> Vec<u8> {
    let mut out = Vec::with_capacity(bytes.len() + 2);
    out.push(b'"');
    for byte in bytes {
        match *byte {
            b'\\' | b'"' => {
                out.push(b'\\');
                out.push(*byte);
            }
            b'\n' => out.extend_from_slice(b"\\n"),
            b'\r' => out.extend_from_slice(b"\\r"),
            b'\t' => out.extend_from_slice(b"\\t"),
            byte if byte < 0x20 || byte == 0x7f => {
                out.extend_from_slice(b"\\C-");
                out.push((byte | 0x40).to_ascii_lowercase());
            }
            byte => out.push(byte),
        }
    }
    out.push(b'"');
    out
}

unsafe fn dump_variable_line(name: &[u8], value: &[u8], readable: bool) {
    if readable {
        output_bytes(b"set ");
        output_bytes(name);
        output_bytes(b" ");
        output_bytes(value);
        output_bytes(b"\n");
    } else {
        output_bytes(name);
        output_bytes(b" is set to ");
        output_bytes(value);
        output_bytes(b"\n");
    }
}

#[no_mangle]
pub unsafe extern "C" fn rl_macro_dumper(readable: c_int) {
    let macros = keymap_data(rl_get_keymap())
        .map(|keymap| keymap.macro_bindings.clone())
        .unwrap_or_default();
    for (seq, bytes) in macros {
        output_bytes(&keyseq_display_bytes(&seq));
        if readable != 0 {
            output_bytes(b": ");
        } else {
            output_bytes(b" outputs ");
        }
        output_bytes(&quoted_inputrc_bytes(&bytes));
        output_bytes(b"\n");
    }
}

#[no_mangle]
pub unsafe extern "C" fn rl_variable_dumper(readable: c_int) {
    let readable = readable != 0;
    let (
        completion_ignore_case,
        completion_map_case,
        show_all_if_ambiguous,
        show_all_if_unmodified,
        completion_query_items,
        completion_prefix_display_length,
        completion_display_width,
        enable_bracketed_paste,
        match_hidden_files,
        convert_meta,
        input_meta,
        output_meta,
        show_mode_in_prompt,
        colored_stats,
        colored_completion_prefix,
        editing_mode,
        history_size,
        keymap_name,
    ) = {
        let editor = lock_editor();
        let hist = lock_history();
        let history_size = if hist.stifled {
            clamp_c_int(hist.max_entries)
        } else {
            -1
        };
        drop(hist);
        (
            editor.completion_ignore_case,
            editor.completion_map_case,
            editor.show_all_if_ambiguous,
            editor.show_all_if_unmodified,
            rl_completion_query_items,
            _rl_completion_prefix_display_length,
            COMPLETION_DISPLAY_WIDTH,
            ENABLE_BRACKETED_PASTE,
            MATCH_HIDDEN_FILES,
            CONVERT_META,
            INPUT_META,
            OUTPUT_META,
            SHOW_MODE_IN_PROMPT,
            COLORED_STATS,
            COLORED_COMPLETION_PREFIX,
            rl_editing_mode,
            history_size,
            keymap_name_bytes(rl_get_keymap()).unwrap_or_else(|| b"emacs".to_vec()),
        )
    };
    let bool_bytes = |enabled: bool| {
        if enabled {
            b"on".as_slice()
        } else {
            b"off".as_slice()
        }
    };
    dump_inputrc_compat_variables(readable);
    dump_variable_line(
        b"completion-ignore-case",
        bool_bytes(completion_ignore_case),
        readable,
    );
    dump_variable_line(
        b"completion-map-case",
        bool_bytes(completion_map_case),
        readable,
    );
    dump_variable_line(
        b"disable-completion",
        bool_bytes(rl_inhibit_completion != 0),
        readable,
    );
    dump_variable_line(
        b"show-all-if-ambiguous",
        bool_bytes(show_all_if_ambiguous),
        readable,
    );
    dump_variable_line(
        b"show-all-if-unmodified",
        bool_bytes(show_all_if_unmodified),
        readable,
    );
    dump_variable_line(
        b"mark-directories",
        bool_bytes(_rl_complete_mark_directories != 0),
        readable,
    );
    dump_variable_line(
        b"mark-symlinked-directories",
        bool_bytes(rl_completion_mark_symlink_dirs != 0),
        readable,
    );
    dump_variable_line(
        b"visible-stats",
        bool_bytes(rl_visible_stats != 0),
        readable,
    );
    dump_variable_line(
        b"bell-style",
        match BELL_STYLE {
            BELL_STYLE_NONE => b"none".as_slice(),
            BELL_STYLE_VISIBLE => b"visible".as_slice(),
            _ => b"audible".as_slice(),
        },
        readable,
    );
    dump_variable_line(
        b"print-completions-horizontally",
        bool_bytes(_rl_print_completions_horizontally != 0),
        readable,
    );
    dump_variable_line(
        b"completion-prefix-display-length",
        format!("{completion_prefix_display_length}").as_bytes(),
        readable,
    );
    dump_variable_line(
        b"completion-display-width",
        format!("{completion_display_width}").as_bytes(),
        readable,
    );
    dump_variable_line(
        b"enable-bracketed-paste",
        bool_bytes(enable_bracketed_paste != 0),
        readable,
    );
    dump_variable_line(
        b"blink-matching-paren",
        bool_bytes(rl_blink_matching_paren != 0),
        readable,
    );
    dump_variable_line(
        b"match-hidden-files",
        bool_bytes(match_hidden_files != 0),
        readable,
    );
    dump_variable_line(b"convert-meta", bool_bytes(convert_meta != 0), readable);
    dump_variable_line(b"input-meta", bool_bytes(input_meta != 0), readable);
    dump_variable_line(b"output-meta", bool_bytes(output_meta != 0), readable);
    dump_variable_line(
        b"show-mode-in-prompt",
        bool_bytes(show_mode_in_prompt != 0),
        readable,
    );
    dump_variable_line(b"colored-stats", bool_bytes(colored_stats != 0), readable);
    dump_variable_line(
        b"colored-completion-prefix",
        bool_bytes(colored_completion_prefix != 0),
        readable,
    );
    dump_variable_line(
        b"completion-query-items",
        format!("{completion_query_items}").as_bytes(),
        readable,
    );
    dump_variable_line(
        b"editing-mode",
        if editing_mode == 0 {
            b"vi".as_slice()
        } else {
            b"emacs".as_slice()
        },
        readable,
    );
    dump_variable_line(
        b"history-size",
        format!("{history_size}").as_bytes(),
        readable,
    );
    dump_variable_line(b"keymap", &keymap_name, readable);
}

#[no_mangle]
pub extern "C" fn rl_dump_functions(readable: c_int) {
    unsafe { rl_function_dumper(readable) };
}

#[no_mangle]
pub extern "C" fn rl_dump_macros(readable: c_int) {
    unsafe { rl_macro_dumper(readable) };
}

#[no_mangle]
pub extern "C" fn rl_dump_variables(readable: c_int) {
    unsafe { rl_variable_dumper(readable) };
}

#[no_mangle]
pub extern "C" fn rl_echo_signal_char(_sig: c_int) {}

#[no_mangle]
pub extern "C" fn rl_print_last_kbd_macro() -> c_int {
    let macro_bytes = lock_editor().kbd_macro_last.clone();
    if !macro_bytes.is_empty() {
        let display = keyseq_display_bytes(&macro_bytes);
        unsafe {
            output_bytes(&display);
            output_bytes(b"\n");
        }
    }
    0
}

#[no_mangle]
pub extern "C" fn rl_push_macro_input(macro_text: *const c_char) -> c_int {
    unsafe {
        if !macro_text.is_null() {
            if !rl_executing_macro.is_null() {
                free(rl_executing_macro as *mut c_void);
            }
            rl_executing_macro = dup_c_string(macro_text);
            let bytes = CStr::from_ptr(macro_text).to_bytes();
            let mut editor = lock_editor();
            editor.macro_input.clear();
            editor.macro_input.extend(bytes.iter().copied());
        }
    }
    0
}

#[no_mangle]
pub extern "C" fn readline_internal_setup() -> c_int {
    0
}

#[no_mangle]
pub extern "C" fn readline_internal_teardown(_eof: c_int) -> c_int {
    0
}

#[no_mangle]
pub extern "C" fn readline_common_teardown(_eof: c_int) -> c_int {
    0
}

#[no_mangle]
pub unsafe extern "C" fn readline_internal_char() -> c_int {
    rl_read_key()
}

#[no_mangle]
pub extern "C" fn rl_alphabetic(key: c_int) -> c_int {
    if (key as u8).is_ascii_alphabetic() {
        1
    } else {
        0
    }
}

#[no_mangle]
pub extern "C" fn rl_character_len(_c: c_int, _pos: c_int) -> c_int {
    1
}

#[no_mangle]
pub unsafe extern "C" fn rl_arrow_keys(count: c_int, _key: c_int) -> c_int {
    match rl_read_key() {
        key if key == b'A' as c_int => rl_get_previous_history(count, key),
        key if key == b'B' as c_int => rl_get_next_history(count, key),
        key if key == b'C' as c_int => rl_forward_char(count, key),
        key if key == b'D' as c_int => rl_backward_char(count, key),
        _ => 0,
    }
}

unsafe fn rl_char_search_impl(count: c_int, forward: bool) -> c_int {
    let target = rl_read_key();
    if target < 0 || target > u8::MAX as c_int {
        return 1;
    }
    if count == 0 {
        return 0;
    }

    let line = current_line_bytes();
    let original = current_point();
    let mut remaining = count.unsigned_abs() as usize;
    let search_forward = if count < 0 { !forward } else { forward };
    let target = target as u8;

    if search_forward {
        let mut start = original.saturating_add(1).min(line.len());
        while remaining > 0 {
            let Some(found) = line[start..]
                .iter()
                .position(|byte| *byte == target)
                .map(|idx| start + idx)
            else {
                return 1;
            };
            remaining -= 1;
            if remaining == 0 {
                rl_point = clamp_c_int(found);
                return 0;
            }
            start = found.saturating_add(1).min(line.len());
        }
    } else {
        let mut end = original.min(line.len());
        while remaining > 0 {
            let Some(found) = line[..end].iter().rposition(|byte| *byte == target) else {
                return 1;
            };
            remaining -= 1;
            if remaining == 0 {
                rl_point = clamp_c_int(found);
                return 0;
            }
            end = found;
        }
    }
    0
}

#[no_mangle]
pub unsafe extern "C" fn rl_backward_char_search(count: c_int, _key: c_int) -> c_int {
    rl_char_search_impl(count, false)
}

#[no_mangle]
pub unsafe extern "C" fn rl_char_search(count: c_int, _key: c_int) -> c_int {
    rl_char_search_impl(count, true)
}

#[no_mangle]
pub unsafe extern "C" fn rl_bracketed_paste_begin(_count: c_int, _key: c_int) -> c_int {
    const END_MARKER: &[u8] = b"\x1b[201~";
    let mut pasted = Vec::new();
    loop {
        let key = rl_read_key();
        if key < 0 || key > u8::MAX as c_int {
            break;
        }
        pasted.push(key as u8);
        if pasted.ends_with(END_MARKER) {
            let len = pasted.len() - END_MARKER.len();
            pasted.truncate(len);
            break;
        }
    }
    if !pasted.is_empty() {
        let mut line = current_line_bytes();
        let mut point = current_point();
        save_undo_snapshot();
        insert_bytes(&mut line, &mut point, &pasted);
        set_line_buffer_bytes(&line);
        rl_point = clamp_c_int(point);
        rl_end = clamp_c_int(line.len());
    }
    0
}

#[no_mangle]
pub unsafe extern "C" fn rl_call_last_kbd_macro(_count: c_int, _key: c_int) -> c_int {
    let macro_bytes = lock_editor().kbd_macro_last.clone();
    if !macro_bytes.is_empty() {
        enqueue_macro_input(&macro_bytes);
    }
    0
}

#[no_mangle]
pub unsafe extern "C" fn rl_complete_internal(_what: c_int) -> c_int {
    rl_completion_type = _what;
    let mut line = current_line_bytes();
    let mut point = if rl_point < 0 {
        0
    } else {
        (rl_point as usize).min(line.len())
    };
    let _ = complete_line_with_mode(&mut line, &mut point, _what, true);
    0
}

#[no_mangle]
pub extern "C" fn rl_completion_mode(_func: rl_command_func_t) -> c_int {
    if _func.is_none() {
        return 0;
    }
    unsafe {
        if same_command(rl_last_func, _func) {
            return b'?' as c_int;
        }
    }
    let editor = lock_editor();
    if editor.show_all_if_ambiguous {
        b'!' as c_int
    } else if editor.show_all_if_unmodified {
        b'@' as c_int
    } else {
        b'\t' as c_int
    }
}

unsafe fn complete_menu_from_current_line(backward: bool) -> c_int {
    if rl_inhibit_completion != 0 {
        return 0;
    }
    rl_completion_type = b'%' as c_int;
    let mut line = current_line_bytes();
    let mut point = if rl_point < 0 {
        0
    } else {
        (rl_point as usize).min(line.len())
    };
    let Some(completion) = gather_completion_matches(&line, point) else {
        return 0;
    };
    let _ = apply_menu_completion(&mut line, &mut point, &completion, backward);
    set_line_buffer_bytes(&line);
    rl_point = clamp_c_int(point);
    rl_end = clamp_c_int(line.len());
    0
}

#[no_mangle]
pub unsafe extern "C" fn rl_delete_or_show_completions(count: c_int, key: c_int) -> c_int {
    if rl_point < rl_end {
        rl_delete(count, key)
    } else {
        rl_complete(count, key)
    }
}

#[no_mangle]
pub extern "C" fn rl_digit_argument(_count: c_int, key: c_int) -> c_int {
    unsafe {
        if key == b'-' as c_int {
            rl_arg_sign = -rl_arg_sign;
            rl_explicit_arg = 1;
            return 0;
        }
        if (b'0' as c_int..=b'9' as c_int).contains(&key) {
            let digit = key - b'0' as c_int;
            rl_numeric_arg = if NUMERIC_ARG_HAS_DIGITS != 0 {
                rl_numeric_arg.saturating_mul(10).saturating_add(digit)
            } else {
                digit
            };
            NUMERIC_ARG_HAS_DIGITS = 1;
            rl_explicit_arg = 1;
        }
    }
    0
}

#[no_mangle]
pub extern "C" fn rl_universal_argument(_count: c_int, _key: c_int) -> c_int {
    unsafe {
        rl_numeric_arg = rl_numeric_arg.saturating_mul(4);
        NUMERIC_ARG_HAS_DIGITS = 1;
        rl_explicit_arg = 1;
    }
    0
}

#[no_mangle]
pub extern "C" fn rl_discard_argument() -> c_int {
    unsafe {
        rl_numeric_arg = 1;
        rl_explicit_arg = 0;
        rl_arg_sign = 1;
        NUMERIC_ARG_HAS_DIGITS = 0;
    }
    0
}

#[no_mangle]
pub extern "C" fn rl_do_lowercase_version(count: c_int, key: c_int) -> c_int {
    let lower = (key as u8).to_ascii_lowercase() as c_int;
    unsafe { rl_insert(count, lower) }
}

#[no_mangle]
pub extern "C" fn rl_emacs_editing_mode(_count: c_int, _key: c_int) -> c_int {
    unsafe {
        ensure_builtin_keymap();
        rl_editing_mode = 1;
        rl_set_keymap(emacs_standard_keymap);
    }
    0
}

#[no_mangle]
pub unsafe extern "C" fn rl_empty_keymap(map: *mut c_void) {
    if let Some(keymap) = keymap_data_mut(map) {
        keymap.key_bindings = [None; 256];
        keymap.keyseq_bindings.clear();
        keymap.macro_bindings.clear();
        rebuild_keyseq_index(keymap);
    }
}

#[no_mangle]
pub extern "C" fn rl_end_kbd_macro(_count: c_int, _key: c_int) -> c_int {
    let mut editor = lock_editor();
    if editor.kbd_macro_recording {
        editor.kbd_macro_recording = false;
        editor.kbd_macro_last = editor.kbd_macro_current.clone();
    }
    0
}

#[no_mangle]
pub extern "C" fn rl_start_kbd_macro(_count: c_int, _key: c_int) -> c_int {
    let mut editor = lock_editor();
    editor.kbd_macro_recording = true;
    editor.kbd_macro_current.clear();
    0
}

#[no_mangle]
pub unsafe extern "C" fn rl_execute_named_command(
    name: *mut c_char,
    count: c_int,
    key: c_int,
) -> c_int {
    if let Some(function) = rl_named_function(name) {
        function(count, key)
    } else {
        1
    }
}

#[no_mangle]
pub unsafe extern "C" fn rl_execute_next(key: c_int) -> c_int {
    rl_pending_input = key;
    rl_readline_state |= 0x00020000;
    0
}

#[no_mangle]
pub unsafe extern "C" fn rl_export_completions(_count: c_int, key: c_int) -> c_int {
    rl_complete(1, key)
}

#[no_mangle]
pub extern "C" fn rl_get_keymap_name_from_edit_mode() -> *mut c_char {
    unsafe {
        if rl_editing_mode == 0 {
            dup_bytes(b"vi")
        } else {
            dup_bytes(b"emacs")
        }
    }
}

#[no_mangle]
pub extern "C" fn rl_get_termcap(_cap: *const c_char) -> *mut c_char {
    ptr::null_mut()
}

#[no_mangle]
pub unsafe extern "C" fn rl_history_substr_search_forward(count: c_int, key: c_int) -> c_int {
    rl_history_search_forward(count, key)
}

#[no_mangle]
pub unsafe extern "C" fn rl_history_substr_search_backward(count: c_int, key: c_int) -> c_int {
    rl_history_search_backward(count, key)
}

#[no_mangle]
pub extern "C" fn rl_initialize_funmap() -> c_int {
    0
}

#[no_mangle]
pub unsafe extern "C" fn rl_insert_close(count: c_int, key: c_int) -> c_int {
    rl_insert(count, key)
}

#[no_mangle]
pub unsafe extern "C" fn rl_insert_comment(_count: c_int, _key: c_int) -> c_int {
    let comment = inputrc_comment_begin_bytes();
    let line = current_line_bytes();
    let Some(capacity) = comment.len().checked_add(line.len()) else {
        return -1;
    };
    let mut commented = Vec::new();
    if commented.try_reserve_exact(capacity).is_err() {
        return -1;
    }
    commented.extend_from_slice(&comment);
    commented.extend_from_slice(&line);
    save_undo_snapshot();
    set_line_buffer_bytes(&commented);
    rl_point = clamp_c_int(comment.len());
    rl_end = clamp_c_int(commented.len());
    rl_done = 1;
    0
}

#[no_mangle]
pub unsafe extern "C" fn rl_insert_completions(count: c_int, key: c_int) -> c_int {
    let _ = count;
    rl_completion_invoking_key = if key == 0 { b'*' as c_int } else { key };
    rl_complete_internal(b'*' as c_int)
}

#[no_mangle]
pub unsafe extern "C" fn rl_possible_completions(count: c_int, key: c_int) -> c_int {
    let _ = count;
    rl_completion_invoking_key = if key == 0 { b'?' as c_int } else { key };
    rl_complete_internal(b'?' as c_int)
}

#[no_mangle]
pub unsafe extern "C" fn rl_menu_complete(count: c_int, key: c_int) -> c_int {
    let _ = count;
    rl_completion_invoking_key = if key == 0 { b'\t' as c_int } else { key };
    complete_menu_from_current_line(false)
}

#[no_mangle]
pub unsafe extern "C" fn rl_old_menu_complete(count: c_int, key: c_int) -> c_int {
    let _ = count;
    rl_completion_invoking_key = if key == 0 { b'\t' as c_int } else { key };
    complete_menu_from_current_line(false)
}

#[no_mangle]
pub unsafe extern "C" fn rl_backward_menu_complete(count: c_int, key: c_int) -> c_int {
    let _ = count;
    rl_completion_invoking_key = if key == 0 { b'\t' as c_int } else { key };
    complete_menu_from_current_line(true)
}

#[no_mangle]
pub extern "C" fn rl_keep_mark_active() {
    rl_activate_mark();
}

#[no_mangle]
pub unsafe extern "C" fn rl_kill_text(start: c_int, end: c_int) -> c_int {
    let line = current_line_bytes();
    let s = start.min(end).max(0) as usize;
    let e = start.max(end).max(0) as usize;
    if s >= e || s >= line.len() {
        return 0;
    }
    let e = e.min(line.len());
    set_kill_buffer(&line[s..e], false, last_was_kill());
    let result = rl_delete_text(clamp_c_int(s), clamp_c_int(e));
    mark_last_kill(true);
    if result < 0 {
        result
    } else {
        0
    }
}

#[no_mangle]
pub extern "C" fn rl_next_screen_line(_count: c_int, _key: c_int) -> c_int {
    0
}

#[no_mangle]
pub extern "C" fn rl_previous_screen_line(_count: c_int, _key: c_int) -> c_int {
    0
}

unsafe fn read_nonincremental_query() -> Option<Vec<u8>> {
    let mut query = Vec::new();
    loop {
        let key = rl_read_key();
        match key {
            READERR..=-1 => return None,
            0x07 => return None,
            0x0a | 0x0d => return Some(query),
            0..=255 => query.push(key as u8),
            _ => return None,
        }
    }
}

unsafe fn find_history_query(query: &[u8], direction: c_int) -> Option<(usize, Vec<u8>)> {
    let hist = lock_history();
    if hist.entries.is_empty() || query.is_empty() {
        return None;
    }
    let mut idx = if direction >= 0 {
        let start = hist.offset.saturating_add(1);
        if start >= hist.entries.len() {
            return None;
        }
        start
    } else if hist.offset >= hist.entries.len() {
        hist.entries.len() - 1
    } else if hist.offset == 0 {
        return None;
    } else {
        hist.offset - 1
    };

    loop {
        let line = entry_line_bytes(&hist.entries[idx]);
        if contains_bytes(&line, query) {
            return Some((idx, line));
        }
        if direction >= 0 {
            idx += 1;
            if idx >= hist.entries.len() {
                break;
            }
        } else if idx == 0 {
            break;
        } else {
            idx -= 1;
        }
    }
    None
}

unsafe fn nonincremental_history_search(direction: c_int, read_query: bool) -> c_int {
    let original_line = current_line_bytes();
    let original_point = rl_point;
    let original_end = rl_end;
    let query = if read_query {
        let Some(query) = read_nonincremental_query() else {
            return 1;
        };
        lock_editor().noninc_search_query = query.clone();
        query
    } else {
        lock_editor().noninc_search_query.clone()
    };

    let Some((idx, line)) = find_history_query(&query, direction) else {
        set_line_buffer_bytes(&original_line);
        rl_point = original_point;
        rl_end = original_end;
        return 1;
    };

    {
        let mut hist = lock_history();
        hist.offset = idx;
        hist.sync_globals();
    }
    set_line_buffer_bytes(&line);
    rl_point = 0;
    rl_end = clamp_c_int(line.len());
    0
}

#[no_mangle]
pub unsafe extern "C" fn rl_noninc_forward_search(_count: c_int, _key: c_int) -> c_int {
    nonincremental_history_search(1, true)
}

#[no_mangle]
pub unsafe extern "C" fn rl_noninc_reverse_search(_count: c_int, _key: c_int) -> c_int {
    nonincremental_history_search(-1, true)
}

#[no_mangle]
pub unsafe extern "C" fn rl_noninc_forward_search_again(_count: c_int, _key: c_int) -> c_int {
    nonincremental_history_search(1, false)
}

#[no_mangle]
pub unsafe extern "C" fn rl_noninc_reverse_search_again(_count: c_int, _key: c_int) -> c_int {
    nonincremental_history_search(-1, false)
}

#[no_mangle]
pub unsafe extern "C" fn rl_forward_search_history(_count: c_int, _key: c_int) -> c_int {
    nonincremental_history_search(1, true)
}

#[no_mangle]
pub unsafe extern "C" fn rl_reverse_search_history(_count: c_int, _key: c_int) -> c_int {
    nonincremental_history_search(-1, true)
}

#[no_mangle]
pub extern "C" fn rl_overwrite_mode(_count: c_int, _key: c_int) -> c_int {
    unsafe {
        rl_insert_mode = if rl_insert_mode == 0 { 1 } else { 0 };
    }
    0
}

#[no_mangle]
pub unsafe extern "C" fn rl_quoted_insert(_count: c_int, _key: c_int) -> c_int {
    let key = rl_read_key();
    if key >= 0 {
        rl_insert(1, key)
    } else {
        1
    }
}

#[no_mangle]
pub unsafe extern "C" fn rl_re_read_init_file(_count: c_int, _key: c_int) -> c_int {
    rl_read_init_file(ptr::null())
}

#[no_mangle]
pub extern "C" fn rl_redraw_prompt_last_line() -> c_int {
    unsafe { rl_redisplay() };
    0
}

#[no_mangle]
pub extern "C" fn rl_reparse_colors() {}

#[no_mangle]
pub extern "C" fn rl_restart_output(_count: c_int, _key: c_int) -> c_int {
    0
}

#[no_mangle]
pub extern "C" fn rl_stop_output(_count: c_int, _key: c_int) -> c_int {
    0
}

unsafe fn readline_state_handle_mut(
    state: *mut c_void,
) -> Option<&'static mut ReadlineStateHandle> {
    if state.is_null() {
        return None;
    }
    // SAFETY:
    // - state is non-null.
    // - Public callers must pass a pointer to struct readline_state.
    // - struct readline_state begins with the two c_ulong fields represented by
    //   ReadlineStateHandle.
    // - The mutable borrow is scoped to rl_save_state/rl_restore_state.
    // - No other mutable alias is created by this function.
    Some(&mut *(state as *mut ReadlineStateHandle))
}

fn remember_readline_state(handle: &mut ReadlineStateHandle, saved: SavedReadlineState) {
    let mut store = lock_saved_readline_states();
    let slot = if handle.magic == READLINE_STATE_MAGIC && handle.slot != 0 {
        handle.slot
    } else {
        let slot = store.next_slot;
        store.next_slot = store.next_slot.wrapping_add(1);
        if store.next_slot == 0 {
            store.next_slot = 1;
        }
        handle.magic = READLINE_STATE_MAGIC;
        handle.slot = slot;
        slot
    };
    if let Some((_, existing)) = store
        .snapshots
        .iter_mut()
        .find(|(existing_slot, _)| *existing_slot == slot)
    {
        *existing = saved;
    } else {
        store.snapshots.push((slot, saved));
    }
}

fn remembered_readline_state(handle: &ReadlineStateHandle) -> Option<SavedReadlineState> {
    if handle.magic != READLINE_STATE_MAGIC || handle.slot == 0 {
        return None;
    }
    let store = lock_saved_readline_states();
    store
        .snapshots
        .iter()
        .find(|(slot, _)| *slot == handle.slot)
        .map(|(_, saved)| saved.clone())
}

#[no_mangle]
pub unsafe extern "C" fn rl_save_state(state: *mut c_void) -> c_int {
    let Some(handle) = readline_state_handle_mut(state) else {
        return -1;
    };
    let editor = lock_editor();
    let saved = SavedReadlineState {
        line: current_line_bytes(),
        prompt: if rl_prompt.is_null() {
            None
        } else {
            Some(CStr::from_ptr(rl_prompt).to_bytes().to_vec())
        },
        point: rl_point,
        end: rl_end,
        mark: rl_mark,
        done: rl_done,
        eof_found: rl_eof_found,
        pending_input: rl_pending_input,
        readline_state: rl_readline_state,
        current_keymap: rl_get_keymap() as usize,
        pending_queue: editor.pending_input.clone(),
        macro_queue: editor.macro_input.clone(),
    };
    remember_readline_state(handle, saved);
    0
}

#[no_mangle]
pub unsafe extern "C" fn rl_restore_state(state: *mut c_void) -> c_int {
    let Some(handle) = readline_state_handle_mut(state) else {
        return -1;
    };
    let Some(saved) = remembered_readline_state(handle) else {
        return -1;
    };
    set_line_buffer_bytes(&saved.line);
    rl_point = saved.point.min(saved.end).max(0);
    rl_end = saved.end;
    rl_mark = saved.mark;
    rl_done = saved.done;
    rl_eof_found = saved.eof_found;
    rl_pending_input = saved.pending_input;
    rl_readline_state = saved.readline_state;
    CURRENT_KEYMAP = saved.current_keymap as *mut c_void;
    rl_binding_keymap = CURRENT_KEYMAP;
    rl_executing_keymap = CURRENT_KEYMAP;
    if let Some(prompt) = saved.prompt {
        let tmp = dup_bytes(&prompt);
        set_prompt_value(tmp);
        if !tmp.is_null() {
            free(tmp as *mut c_void);
        }
    } else {
        set_prompt_value(ptr::null());
    }
    let mut editor = lock_editor();
    editor.pending_input = saved.pending_queue;
    editor.macro_input = saved.macro_queue;
    0
}

#[no_mangle]
pub unsafe extern "C" fn rl_rubout_or_delete(count: c_int, key: c_int) -> c_int {
    if rl_point < rl_end {
        rl_delete(count, key)
    } else {
        rl_rubout(count, key)
    }
}

#[no_mangle]
pub extern "C" fn rl_set_key(
    keyseq: *const c_char,
    function: rl_command_func_t,
    map: *mut c_void,
) -> c_int {
    unsafe { rl_bind_keyseq_in_map(keyseq, function, map) }
}

#[no_mangle]
pub unsafe extern "C" fn rl_set_keymap_from_edit_mode() {
    if rl_editing_mode == 0 {
        rl_set_keymap(vi_insertion_keymap);
    } else {
        rl_set_keymap(emacs_standard_keymap);
    }
}

#[no_mangle]
pub unsafe extern "C" fn rl_set_paren_blink_timeout(usec: c_int) -> c_int {
    let old = PAREN_BLINK_TIMEOUT_USECONDS;
    if usec >= 0 {
        PAREN_BLINK_TIMEOUT_USECONDS = usec;
    }
    old
}

#[no_mangle]
pub extern "C" fn rl_set_retained_kills(num: c_int) -> c_int {
    let mut editor = lock_editor();
    editor.retained_kills = num.max(1) as usize;
    let retained_kills = editor.retained_kills;
    if editor.kill_ring.len() > retained_kills {
        editor.kill_ring.truncate(retained_kills);
    }
    if !editor.kill_ring.is_empty() {
        editor.kill_ring_index = editor.kill_ring_index.min(editor.kill_ring.len() - 1);
    } else {
        editor.kill_ring_index = 0;
    }
    0
}

#[no_mangle]
pub unsafe extern "C" fn rl_show_char(key: c_int) -> c_int {
    let mut bytes = Vec::new();
    if (0..=127).contains(&key) || key < 0 {
        let raw = key as u8;
        let mut ch = raw;
        if raw & 0x80 != 0 {
            bytes.extend_from_slice(b"M-");
            ch &= 0x7f;
        }
        if ch < 0x20 {
            bytes.extend_from_slice(b"C-");
            bytes.push(ch + b'@');
        } else if ch == 0x7f {
            bytes.extend_from_slice(b"C-?");
        } else {
            bytes.push(ch);
        }
    } else if (128..=255).contains(&key) {
        let ch = (key as u8) & 0x7f;
        bytes.extend_from_slice(b"M-");
        if ch < 0x20 {
            bytes.extend_from_slice(b"C-");
            bytes.push(ch + b'@');
        } else if ch == 0x7f {
            bytes.extend_from_slice(b"C-?");
        } else {
            bytes.push(ch);
        }
    } else {
        bytes.push(key as u8);
    }
    output_raw_bytes(&bytes)
}

#[no_mangle]
pub extern "C" fn rl_skip_csi_sequence(_count: c_int, _key: c_int) -> c_int {
    loop {
        // SAFETY:
        // - rl_read_key validates pending input and the configured getc hook.
        // - A null rl_instream is normalized through ensure_stdio_streams().
        // - This command only observes and consumes public input state.
        let key = unsafe { rl_read_key() };
        if key < 0 {
            return 1;
        }
        if (0x40..=0x7e).contains(&key) {
            return 0;
        }
    }
}

#[no_mangle]
pub unsafe extern "C" fn rl_tab_insert(count: c_int, _key: c_int) -> c_int {
    rl_insert(count, b'\t' as c_int)
}

#[no_mangle]
pub unsafe extern "C" fn rl_transpose_words(_count: c_int, _key: c_int) -> c_int {
    if _count < 0 {
        return 1;
    }
    if _count == 0 {
        return 0;
    }
    let mut line = current_line_bytes();
    let point = current_point();
    let left_start = previous_word_start(&line, point);
    let left_end = next_word_end(&line, left_start);
    let mut scan = left_end;
    let mut right_start = left_end;
    let mut right_end = left_end;
    for _ in 0.._count {
        while scan < line.len() && !word_byte(line[scan]) {
            scan += 1;
        }
        right_start = scan;
        right_end = next_word_end(&line, right_start);
        if right_start >= right_end {
            return 0;
        }
        scan = right_end;
    }
    if left_start >= left_end || right_start >= right_end || right_end > line.len() {
        return 0;
    }
    let left = line[left_start..left_end].to_vec();
    let between = line[left_end..right_start].to_vec();
    let right = line[right_start..right_end].to_vec();
    save_undo_snapshot();
    line.splice(
        left_start..right_end,
        right
            .iter()
            .chain(between.iter())
            .chain(left.iter())
            .copied(),
    );
    set_line_buffer_bytes(&line);
    rl_point = clamp_c_int(right_end);
    0
}

#[no_mangle]
pub extern "C" fn rl_trim_arg_from_keyseq(keyseq: *const c_char, _type_id: c_int) -> *mut c_char {
    unsafe { dup_c_string(keyseq) }
}

#[no_mangle]
pub unsafe extern "C" fn rl_tty_set_default_bindings(map: *mut c_void) {
    let Some(modes) = input_terminal_modes() else {
        return;
    };
    let Some(keymap) = keymap_data_mut(map) else {
        return;
    };
    bind_tty_default_key(
        keymap,
        &modes,
        TERMIOS_CC_VERASE,
        command_from_unsafe(rl_rubout),
    );
    bind_tty_default_key(
        keymap,
        &modes,
        TERMIOS_CC_VKILL,
        command_from_unsafe(rl_unix_line_discard),
    );
    bind_tty_default_key(
        keymap,
        &modes,
        TERMIOS_CC_VWERASE,
        command_from_unsafe(rl_unix_word_rubout),
    );
    bind_tty_default_key(
        keymap,
        &modes,
        TERMIOS_CC_VLNEXT,
        command_from_unsafe(rl_quoted_insert),
    );
}

#[no_mangle]
pub unsafe extern "C" fn rl_tty_unset_default_bindings(map: *mut c_void) {
    let Some(keymap) = keymap_data_mut(map) else {
        return;
    };
    let tty_default_keys = keymap.tty_default_keys;
    keymap
        .macro_bindings
        .retain(|(existing, _)| {
            existing.len() != 1 || !tty_default_keys[existing[0] as usize]
        });
    rebuild_keyseq_index(keymap);
    for key in 0..keymap.tty_default_keys.len() {
        if keymap.tty_default_keys[key] {
            keymap.key_bindings[key] = command_from_unsafe(rl_insert);
            keymap.tty_default_keys[key] = false;
        }
    }
}

#[no_mangle]
pub unsafe extern "C" fn rl_tty_set_echoing(value: c_int) -> c_int {
    let previous = TTY_ECHOING;
    TTY_ECHOING = if value == 0 { 0 } else { 1 };
    previous
}

#[no_mangle]
pub extern "C" fn rl_tty_status(_count: c_int, _key: c_int) -> c_int {
    0
}

macro_rules! vi_stub {
    ($($name:ident),* $(,)?) => {
        $(
            #[no_mangle]
            pub extern "C" fn $name(_count: c_int, _key: c_int) -> c_int {
                0
            }
        )*
    };
}

vi_stub!(rl_vi_bracktype, rl_vi_check, rl_vi_overstrike_delete,);

#[derive(Clone, Copy, PartialEq, Eq)]
enum ViOperator {
    Delete,
    Change,
    Yank,
}

fn vi_motion_target(line: &[u8], start: usize, key: c_int, count: c_int, op: ViOperator) -> usize {
    let mut point = start.min(line.len());
    let count = count.max(1);
    match key {
        key if key == b'w' as c_int => {
            for _ in 0..count {
                point = if op == ViOperator::Change {
                    next_word_end(line, point)
                } else {
                    next_word_start(line, point)
                };
            }
        }
        key if key == b'W' as c_int => {
            for _ in 0..count {
                point = if op == ViOperator::Change {
                    next_big_word_end(line, point)
                } else {
                    next_big_word_start(line, point)
                };
            }
        }
        key if key == b'e' as c_int => {
            for _ in 0..count {
                point = next_word_end(line, point);
            }
        }
        key if key == b'E' as c_int => {
            for _ in 0..count {
                point = next_big_word_end(line, point);
            }
        }
        key if key == b'b' as c_int => {
            for _ in 0..count {
                point = previous_word_start(line, point);
            }
        }
        key if key == b'B' as c_int => {
            for _ in 0..count {
                point = previous_big_word_start(line, point);
            }
        }
        key if key == b'l' as c_int || key == b' ' as c_int => {
            for _ in 0..count {
                point = next_char_boundary(line, point);
            }
        }
        key if key == b'h' as c_int => {
            for _ in 0..count {
                point = previous_char_boundary(line, point);
            }
        }
        key if key == b'$' as c_int => point = line.len(),
        key if key == b'0' as c_int || key == b'^' as c_int => point = 0,
        _ => {}
    }
    point.min(line.len())
}

unsafe fn vi_operator_range(op: ViOperator, count: c_int, motion: c_int) -> Option<(usize, usize)> {
    let line = current_line_bytes();
    let start = current_point();
    if (op == ViOperator::Delete && motion == b'd' as c_int)
        || (op == ViOperator::Change && motion == b'c' as c_int)
        || (op == ViOperator::Yank && (motion == b'y' as c_int || motion == b'Y' as c_int))
    {
        return Some((0, line.len()));
    }
    if op == ViOperator::Change && motion == b'C' as c_int {
        return Some((start, line.len()));
    }
    if op == ViOperator::Yank && motion == b'Y' as c_int {
        return Some((0, line.len()));
    }
    let target = vi_motion_target(&line, start, motion, count, op);
    Some((start.min(target), start.max(target)))
}

unsafe fn vi_apply_operator(op: ViOperator, count: c_int, motion: c_int) -> c_int {
    let Some((start, end)) = vi_operator_range(op, count, motion) else {
        return 0;
    };
    match op {
        ViOperator::Delete => kill_range(start, end, false, false),
        ViOperator::Change => {
            let result = kill_range(start, end, false, false);
            let _ = rl_vi_insert_mode(1, 0);
            result
        }
        ViOperator::Yank => {
            let bytes = copy_text_region_bytes(start, end);
            set_kill_buffer(&bytes, false, false);
            rl_point = clamp_c_int(start.min(current_line_bytes().len()));
            0
        }
    }
}

#[no_mangle]
pub unsafe extern "C" fn rl_vi_arg_digit(_count: c_int, key: c_int) -> c_int {
    if !(b'0' as c_int..=b'9' as c_int).contains(&key) {
        return 0;
    }
    if key == b'0' as c_int && rl_explicit_arg == 0 {
        return rl_vi_column(1, key);
    }
    let digit = key - b'0' as c_int;
    rl_numeric_arg = if rl_explicit_arg != 0 {
        rl_numeric_arg.saturating_mul(10).saturating_add(digit)
    } else {
        digit
    };
    NUMERIC_ARG_HAS_DIGITS = 1;
    rl_explicit_arg = 1;
    0
}

#[no_mangle]
pub unsafe extern "C" fn rl_vi_delete_to(count: c_int, _key: c_int) -> c_int {
    let motion = rl_read_key();
    vi_apply_operator(ViOperator::Delete, count, motion)
}

#[no_mangle]
pub unsafe extern "C" fn rl_vi_change_to(count: c_int, key: c_int) -> c_int {
    let motion = if key == b'C' as c_int {
        b'C' as c_int
    } else {
        rl_read_key()
    };
    vi_apply_operator(ViOperator::Change, count, motion)
}

#[no_mangle]
pub unsafe extern "C" fn rl_vi_yank_to(count: c_int, key: c_int) -> c_int {
    let motion = if key == b'Y' as c_int {
        b'Y' as c_int
    } else {
        rl_read_key()
    };
    vi_apply_operator(ViOperator::Yank, count, motion)
}

#[no_mangle]
pub unsafe extern "C" fn rl_vi_domove(count: c_int, _key: c_int) -> c_int {
    let motion = rl_read_key();
    let line = current_line_bytes();
    let target = vi_motion_target(&line, current_point(), motion, count, ViOperator::Delete);
    rl_point = clamp_c_int(target);
    0
}

#[no_mangle]
pub unsafe extern "C" fn rl_vi_change_char(count: c_int, _key: c_int) -> c_int {
    let replacement = rl_read_key();
    if !(0..=u8::MAX as c_int).contains(&replacement) {
        return 0;
    }
    let mut line = current_line_bytes();
    let mut point = current_point();
    save_undo_snapshot();
    for _ in 0..count.max(1) {
        if point >= line.len() {
            break;
        }
        line[point] = replacement as u8;
        point = next_char_boundary(&line, point);
    }
    set_line_buffer_bytes(&line);
    rl_point = clamp_c_int(point.saturating_sub(1));
    0
}

#[no_mangle]
pub unsafe extern "C" fn rl_vi_replace(_count: c_int, _key: c_int) -> c_int {
    let mut replaced = false;
    loop {
        let key = rl_read_key();
        if key < 0 || key == 0x1b {
            break;
        }
        if key == b'\n' as c_int || key == b'\r' as c_int {
            rl_done = 1;
            break;
        }
        let _ = rl_vi_overstrike(1, key);
        replaced = true;
    }
    if replaced {
        let line = current_line_bytes();
        rl_point = clamp_c_int(previous_char_boundary(&line, current_point()));
    }
    rl_vi_movement_mode(1, 0)
}

#[no_mangle]
pub unsafe extern "C" fn rl_vi_redo(_count: c_int, _key: c_int) -> c_int {
    0
}

unsafe fn apply_vi_char_search(count: c_int, forward: bool, till: bool, target: u8) -> c_int {
    let line = current_line_bytes();
    let mut point = current_point();
    for _ in 0..count.max(1) {
        if forward {
            let start = next_char_boundary(&line, point);
            let Some(found) = line[start..]
                .iter()
                .position(|byte| *byte == target)
                .map(|idx| start + idx)
            else {
                return 1;
            };
            point = if till {
                previous_char_boundary(&line, found)
            } else {
                found
            };
        } else {
            let Some(found) = line[..point].iter().rposition(|byte| *byte == target) else {
                return 1;
            };
            point = if till {
                next_char_boundary(&line, found).min(line.len())
            } else {
                found
            };
        }
    }
    rl_point = clamp_c_int(point);
    0
}

#[no_mangle]
pub unsafe extern "C" fn rl_vi_char_search(count: c_int, key: c_int) -> c_int {
    let (target, forward, till) = match key {
        key if key == b';' as c_int => {
            let Some(search) = lock_editor().vi_char_search else {
                return 1;
            };
            (search.target, search.forward, search.till)
        }
        key if key == b',' as c_int => {
            let Some(search) = lock_editor().vi_char_search else {
                return 1;
            };
            (search.target, !search.forward, search.till)
        }
        key if key == b'f' as c_int || key == b't' as c_int => {
            let target = rl_read_key();
            if !(0..=u8::MAX as c_int).contains(&target) {
                return 1;
            }
            (target as u8, true, key == b't' as c_int)
        }
        key if key == b'F' as c_int || key == b'T' as c_int => {
            let target = rl_read_key();
            if !(0..=u8::MAX as c_int).contains(&target) {
                return 1;
            }
            (target as u8, false, key == b'T' as c_int)
        }
        _ => return 1,
    };
    lock_editor().vi_char_search = Some(ViCharSearch {
        target,
        forward,
        till,
    });
    apply_vi_char_search(count, forward, till, target)
}

#[no_mangle]
pub unsafe extern "C" fn rl_vi_append_eol(_count: c_int, _key: c_int) -> c_int {
    rl_end_of_line(1, 0);
    rl_vi_insert_mode(1, 0)
}

#[no_mangle]
pub unsafe extern "C" fn rl_vi_append_mode(_count: c_int, _key: c_int) -> c_int {
    rl_forward_char(1, 0);
    rl_vi_insert_mode(1, 0)
}

#[no_mangle]
pub unsafe extern "C" fn rl_vi_insert_beg(_count: c_int, _key: c_int) -> c_int {
    rl_beginning_of_line(1, 0);
    rl_vi_insert_mode(1, 0)
}

#[no_mangle]
pub unsafe extern "C" fn rl_vi_start_inserting(count: c_int, key: c_int) -> c_int {
    rl_vi_insert_mode(count, key)
}

#[no_mangle]
pub unsafe extern "C" fn rl_vi_insert_mode(_count: c_int, _key: c_int) -> c_int {
    ensure_builtin_keymap();
    rl_set_keymap(vi_insertion_keymap);
    rl_editing_mode = 0;
    rl_insert_mode = 1;
    0
}

#[no_mangle]
pub unsafe extern "C" fn rl_vi_insertion_mode(count: c_int, key: c_int) -> c_int {
    rl_vi_insert_mode(count, key)
}

#[no_mangle]
pub unsafe extern "C" fn rl_vi_movement_mode(_count: c_int, _key: c_int) -> c_int {
    ensure_builtin_keymap();
    rl_set_keymap(vi_movement_keymap);
    rl_editing_mode = 0;
    rl_insert_mode = 0;
    0
}

#[no_mangle]
pub unsafe extern "C" fn rl_vi_first_print(_count: c_int, _key: c_int) -> c_int {
    let line = current_line_bytes();
    let point = line
        .iter()
        .position(|byte| !byte.is_ascii_whitespace())
        .unwrap_or(line.len());
    rl_point = clamp_c_int(point);
    0
}

#[no_mangle]
pub unsafe extern "C" fn rl_vi_back_to_indent(count: c_int, key: c_int) -> c_int {
    rl_vi_first_print(count, key)
}

#[no_mangle]
pub unsafe extern "C" fn rl_vi_column(count: c_int, _key: c_int) -> c_int {
    let line = current_line_bytes();
    let column = count.max(1) as usize;
    rl_point = clamp_c_int(column.saturating_sub(1).min(line.len()));
    0
}

#[no_mangle]
pub unsafe extern "C" fn rl_vi_prev_word(count: c_int, key: c_int) -> c_int {
    rl_backward_word(count, key)
}

#[no_mangle]
pub unsafe extern "C" fn rl_vi_bword(count: c_int, key: c_int) -> c_int {
    rl_vi_prev_word(count, key)
}

#[no_mangle]
pub unsafe extern "C" fn rl_vi_bWord(count: c_int, _key: c_int) -> c_int {
    let line = current_line_bytes();
    let mut point = current_point();
    for _ in 0..count.max(1) {
        point = previous_big_word_start(&line, point);
    }
    rl_point = clamp_c_int(point);
    0
}

#[no_mangle]
pub unsafe extern "C" fn rl_vi_next_word(count: c_int, key: c_int) -> c_int {
    rl_forward_word(count, key)
}

#[no_mangle]
pub unsafe extern "C" fn rl_vi_fword(count: c_int, key: c_int) -> c_int {
    rl_vi_next_word(count, key)
}

#[no_mangle]
pub unsafe extern "C" fn rl_vi_fWord(count: c_int, _key: c_int) -> c_int {
    let line = current_line_bytes();
    let mut point = current_point();
    for _ in 0..count.max(1) {
        point = next_big_word_start(&line, point);
    }
    rl_point = clamp_c_int(point);
    0
}

#[no_mangle]
pub unsafe extern "C" fn rl_vi_end_word(count: c_int, _key: c_int) -> c_int {
    let line = current_line_bytes();
    let mut point = current_point();
    for _ in 0..count.max(1) {
        let end = next_word_end(&line, point);
        point = end.saturating_sub(1);
        if end >= line.len() {
            break;
        }
    }
    rl_point = clamp_c_int(point);
    0
}

#[no_mangle]
pub unsafe extern "C" fn rl_vi_eword(count: c_int, key: c_int) -> c_int {
    rl_vi_end_word(count, key)
}

#[no_mangle]
pub unsafe extern "C" fn rl_vi_eWord(count: c_int, _key: c_int) -> c_int {
    let line = current_line_bytes();
    let mut point = current_point();
    for _ in 0..count.max(1) {
        let end = next_big_word_end(&line, point);
        point = end.saturating_sub(1);
    }
    rl_point = clamp_c_int(point);
    0
}

#[no_mangle]
pub unsafe extern "C" fn rl_vi_change_case(count: c_int, _key: c_int) -> c_int {
    if count <= 0 {
        return 0;
    }
    let mut line = current_line_bytes();
    let mut point = current_point();
    save_undo_snapshot();
    for _ in 0..count {
        if point >= line.len() {
            break;
        }
        if line[point].is_ascii_lowercase() {
            line[point] = line[point].to_ascii_uppercase();
        } else if line[point].is_ascii_uppercase() {
            line[point] = line[point].to_ascii_lowercase();
        }
        point = next_char_boundary(&line, point);
    }
    set_line_buffer_bytes(&line);
    rl_point = clamp_c_int(point);
    0
}

#[no_mangle]
pub unsafe extern "C" fn rl_vi_delete(count: c_int, _key: c_int) -> c_int {
    if count < 0 {
        return rl_vi_rubout(count.saturating_neg(), 0);
    }
    if count == 0 {
        return 0;
    }
    let line = current_line_bytes();
    let start = current_point();
    if start >= line.len() {
        rl_point = clamp_c_int(line.len().saturating_sub(1));
        return 0;
    }
    let mut end = start;
    for _ in 0..count {
        let next = next_char_boundary(&line, end);
        if next == end {
            break;
        }
        end = next;
    }
    let result = kill_range(start, end, false, false);
    rl_point = rl_point.min((rl_end - 1).max(0));
    result
}

#[no_mangle]
pub unsafe extern "C" fn rl_vi_rubout(count: c_int, _key: c_int) -> c_int {
    if count < 0 {
        return rl_vi_delete(count.saturating_neg(), 0);
    }
    if count == 0 {
        return 0;
    }
    let line = current_line_bytes();
    let end = current_point();
    if end == 0 {
        return 1;
    }
    let mut start = end;
    for _ in 0..count {
        let next = previous_char_boundary(&line, start);
        if next == start {
            break;
        }
        start = next;
    }
    kill_range(start, end, true, false)
}

#[no_mangle]
pub unsafe extern "C" fn rl_vi_complete(count: c_int, key: c_int) -> c_int {
    rl_complete(count, key)
}

#[no_mangle]
pub unsafe extern "C" fn rl_vi_fetch_history(_count: c_int, _key: c_int) -> c_int {
    let len = lock_history().entries.len();
    if len == 0 {
        return 0;
    }
    if rl_explicit_arg == 0 && where_history() == 0 {
        return 0;
    }
    let target = if rl_explicit_arg != 0 {
        (_count.max(1) - 1).max(0) as usize
    } else {
        0
    };
    let _ = history_set_pos(clamp_c_int(target.min(len - 1)));
    rl_fetch_history()
}

#[no_mangle]
pub unsafe extern "C" fn rl_vi_set_mark(_count: c_int, _key: c_int) -> c_int {
    let mark = rl_read_key();
    if !(0..=u8::MAX as c_int).contains(&mark) {
        return 1;
    }
    lock_editor().vi_marks[mark as usize] = Some(current_point());
    0
}

#[no_mangle]
pub unsafe extern "C" fn rl_vi_goto_mark(_count: c_int, _key: c_int) -> c_int {
    let mark = rl_read_key();
    if !(0..=u8::MAX as c_int).contains(&mark) {
        return 1;
    }
    let Some(point) = lock_editor().vi_marks[mark as usize] else {
        return 1;
    };
    set_point(point);
    0
}

fn matching_vi_delimiter(byte: u8) -> Option<(u8, bool)> {
    match byte {
        b'(' => Some((b')', true)),
        b'[' => Some((b']', true)),
        b'{' => Some((b'}', true)),
        b')' => Some((b'(', false)),
        b']' => Some((b'[', false)),
        b'}' => Some((b'{', false)),
        _ => None,
    }
}

#[no_mangle]
pub unsafe extern "C" fn rl_vi_match(_count: c_int, _key: c_int) -> c_int {
    let line = current_line_bytes();
    let point = current_point();
    let Some(&byte) = line.get(point) else {
        return 1;
    };
    let Some((target, forward)) = matching_vi_delimiter(byte) else {
        return 1;
    };
    let mut depth = 0usize;
    if forward {
        for (idx, current) in line.iter().enumerate().skip(point) {
            if *current == byte {
                depth = depth.saturating_add(1);
            } else if *current == target {
                depth = depth.saturating_sub(1);
                if depth == 0 {
                    rl_point = clamp_c_int(idx);
                    return 0;
                }
            }
        }
    } else {
        for idx in (0..=point).rev() {
            if line[idx] == byte {
                depth = depth.saturating_add(1);
            } else if line[idx] == target {
                depth = depth.saturating_sub(1);
                if depth == 0 {
                    rl_point = clamp_c_int(idx);
                    return 0;
                }
            }
        }
    }
    1
}

#[no_mangle]
pub unsafe extern "C" fn rl_vi_search(_count: c_int, key: c_int) -> c_int {
    let direction = if key == b'/' as c_int { 1 } else { -1 };
    lock_editor().vi_search_direction = direction;
    nonincremental_history_search(direction, true)
}

#[no_mangle]
pub unsafe extern "C" fn rl_vi_search_again(_count: c_int, key: c_int) -> c_int {
    let direction = {
        let editor = lock_editor();
        if key == b'N' as c_int {
            -editor.vi_search_direction
        } else {
            editor.vi_search_direction
        }
    };
    nonincremental_history_search(direction, false)
}

#[no_mangle]
pub unsafe extern "C" fn rl_vi_tilde_expand(count: c_int, key: c_int) -> c_int {
    rl_tilde_expand(count, key)
}

#[no_mangle]
pub unsafe extern "C" fn rl_vi_undo(count: c_int, key: c_int) -> c_int {
    rl_undo_command(count, key)
}

#[no_mangle]
pub unsafe extern "C" fn rl_vi_unix_word_rubout(count: c_int, key: c_int) -> c_int {
    rl_unix_word_rubout(count, key)
}

#[no_mangle]
pub unsafe extern "C" fn rl_vi_subst(count: c_int, _key: c_int) -> c_int {
    let point = current_point();
    let line = current_line_bytes();
    let mut end = point;
    for _ in 0..count.max(1) {
        end = next_char_boundary(&line, end);
    }
    let _ = rl_delete_text(clamp_c_int(point), clamp_c_int(end));
    rl_vi_insert_mode(1, 0)
}

#[no_mangle]
pub unsafe extern "C" fn rl_vi_overstrike(count: c_int, key: c_int) -> c_int {
    if count <= 0 || !(0..=u8::MAX as c_int).contains(&key) {
        return 0;
    }
    let mut line = current_line_bytes();
    let point = current_point();
    let end = point.saturating_add(count as usize);
    save_undo_snapshot();
    if end > line.len() {
        line.resize(end, key as u8);
    }
    for byte in &mut line[point..end] {
        *byte = key as u8;
    }
    set_line_buffer_bytes(&line);
    rl_point = clamp_c_int(end);
    0
}

#[no_mangle]
pub unsafe extern "C" fn rl_vi_put(count: c_int, key: c_int) -> c_int {
    if count <= 0 {
        return 0;
    }
    let kill = {
        let editor = lock_editor();
        editor.kill_buffer.clone()
    };
    if kill.is_empty() {
        return 0;
    }

    let mut insert = Vec::new();
    for _ in 0..count {
        insert.extend_from_slice(&kill);
    }
    let line = current_line_bytes();
    let point = current_point();
    let insert_at = if key == b'P' as c_int {
        point
    } else if line.is_empty() {
        0
    } else {
        next_char_boundary(&line, point)
    };
    rl_point = clamp_c_int(insert_at);
    let tmp = dup_bytes(&insert);
    if tmp.is_null() {
        return -1;
    }
    let result = rl_insert_text(tmp);
    free(tmp as *mut c_void);
    if result < 0 {
        result
    } else {
        if !insert.is_empty() {
            rl_point = clamp_c_int(insert_at + insert.len() - 1);
        }
        0
    }
}

#[no_mangle]
pub extern "C" fn rl_vi_yank_pop(count: c_int, key: c_int) -> c_int {
    rl_yank_pop(count, key)
}

#[no_mangle]
pub unsafe extern "C" fn rl_vi_eof_maybe(count: c_int, key: c_int) -> c_int {
    rl_newline(count, key)
}

#[no_mangle]
pub unsafe extern "C" fn rl_vi_yank_arg(count: c_int, _key: c_int) -> c_int {
    let hist = lock_history();
    if hist.offset == 0 || hist.entries.is_empty() {
        return 0;
    }
    let entry_index = (hist.offset - 1).min(hist.entries.len() - 1);
    let line = entry_line_bytes(&hist.entries[entry_index]);
    drop(hist);
    let arg = if rl_explicit_arg != 0 {
        let index = count.max(1) - 1;
        extract_history_args(&line, index, index)
    } else {
        let words = tokenize_history_bytes(&line);
        words.last().cloned()
    };
    let Some(arg) = arg else {
        return 0;
    };
    let tmp = dup_bytes(&arg);
    if tmp.is_null() {
        return -1;
    }
    let result = rl_insert_text(tmp);
    free(tmp as *mut c_void);
    if result < 0 {
        result
    } else {
        0
    }
}

#[no_mangle]
pub extern "C" fn rl_vi_editing_mode(_count: c_int, _key: c_int) -> c_int {
    unsafe {
        ensure_builtin_keymap();
        rl_editing_mode = 0;
        rl_set_keymap(vi_insertion_keymap);
    }
    0
}

#[no_mangle]
pub unsafe extern "C" fn rl_variable_bind(variable: *const c_char, value: *const c_char) -> c_int {
    if variable.is_null() || value.is_null() {
        return -1;
    }
    let variable = CStr::from_ptr(variable).to_bytes().to_ascii_lowercase();
    let variable = variable.as_slice();
    if variable == b"history-size" {
        let value = CStr::from_ptr(value).to_bytes();
        if let Ok(value) = std::str::from_utf8(value) {
            if let Ok(max) = value.trim().parse::<c_int>() {
                stifle_history(max);
                return 0;
            }
        }
        return 0;
    }
    if variable == b"completion-query-items" {
        let value = CStr::from_ptr(value).to_bytes();
        if let Ok(value) = std::str::from_utf8(value) {
            if let Ok(max) = value.trim().parse::<c_int>() {
                rl_completion_query_items = max;
                return 0;
            }
        }
        return -1;
    }
    if variable == b"editing-mode" {
        ensure_builtin_keymap();
        let value = CStr::from_ptr(value).to_bytes();
        if value.eq_ignore_ascii_case(b"vi") || value.eq_ignore_ascii_case(b"vi-insert") {
            rl_editing_mode = 0;
            rl_set_keymap(vi_insertion_keymap);
            return 0;
        } else if value.eq_ignore_ascii_case(b"emacs") {
            rl_editing_mode = 1;
            rl_set_keymap(emacs_standard_keymap);
            return 0;
        }
        return 1;
    }
    if variable == b"keymap" {
        ensure_builtin_keymap();
        let value = CStr::from_ptr(value).to_bytes();
        if value.eq_ignore_ascii_case(b"vi")
            || value.eq_ignore_ascii_case(b"vi-command")
            || value.eq_ignore_ascii_case(b"vi-move")
        {
            rl_set_keymap(vi_movement_keymap);
        } else if value.eq_ignore_ascii_case(b"vi-insert") {
            rl_set_keymap(vi_insertion_keymap);
        } else if value.eq_ignore_ascii_case(b"emacs")
            || value.eq_ignore_ascii_case(b"emacs-standard")
        {
            rl_set_keymap(emacs_standard_keymap);
        } else if value.eq_ignore_ascii_case(b"emacs-meta") {
            rl_set_keymap(emacs_meta_keymap);
        } else if value.eq_ignore_ascii_case(b"emacs-ctlx") {
            rl_set_keymap(emacs_ctlx_keymap);
        } else {
            return 1;
        }
        return 0;
    }
    if variable == b"completion-ignore-case" {
        let value = CStr::from_ptr(value).to_bytes();
        lock_editor().completion_ignore_case = inputrc_bool(value);
        return 0;
    }
    if variable == b"completion-map-case" {
        let value = CStr::from_ptr(value).to_bytes();
        lock_editor().completion_map_case = inputrc_bool(value);
        return 0;
    }
    if variable == b"disable-completion" {
        let value = CStr::from_ptr(value).to_bytes();
        rl_inhibit_completion = if inputrc_bool(value) { 1 } else { 0 };
        return 0;
    }
    if variable == b"enable-bracketed-paste" {
        let value = CStr::from_ptr(value).to_bytes();
        ENABLE_BRACKETED_PASTE = if inputrc_bool(value) { 1 } else { 0 };
        return 0;
    }
    if variable == b"match-hidden-files" {
        let value = CStr::from_ptr(value).to_bytes();
        MATCH_HIDDEN_FILES = if inputrc_bool(value) { 1 } else { 0 };
        return 0;
    }
    if variable == b"blink-matching-paren" {
        let value = CStr::from_ptr(value).to_bytes();
        rl_blink_matching_paren = if inputrc_bool(value) { 1 } else { 0 };
        return 0;
    }
    if variable == b"convert-meta" {
        let value = CStr::from_ptr(value).to_bytes();
        CONVERT_META = if inputrc_bool(value) { 1 } else { 0 };
        return 0;
    }
    if variable == b"input-meta" {
        let value = CStr::from_ptr(value).to_bytes();
        INPUT_META = if inputrc_bool(value) { 1 } else { 0 };
        return 0;
    }
    if variable == b"output-meta" {
        let value = CStr::from_ptr(value).to_bytes();
        OUTPUT_META = if inputrc_bool(value) { 1 } else { 0 };
        return 0;
    }
    if variable == b"show-mode-in-prompt" {
        let value = CStr::from_ptr(value).to_bytes();
        SHOW_MODE_IN_PROMPT = if inputrc_bool(value) { 1 } else { 0 };
        return 0;
    }
    if variable == b"colored-stats" {
        let value = CStr::from_ptr(value).to_bytes();
        COLORED_STATS = if inputrc_bool(value) { 1 } else { 0 };
        return 0;
    }
    if variable == b"colored-completion-prefix" {
        let value = CStr::from_ptr(value).to_bytes();
        COLORED_COMPLETION_PREFIX = if inputrc_bool(value) { 1 } else { 0 };
        return 0;
    }
    if variable == b"show-all-if-ambiguous" {
        let value = CStr::from_ptr(value).to_bytes();
        lock_editor().show_all_if_ambiguous = inputrc_bool(value);
        return 0;
    }
    if variable == b"show-all-if-unmodified" {
        let value = CStr::from_ptr(value).to_bytes();
        lock_editor().show_all_if_unmodified = inputrc_bool(value);
        return 0;
    }
    if variable == b"mark-directories" {
        let value = CStr::from_ptr(value).to_bytes();
        _rl_complete_mark_directories = if inputrc_bool(value) { 1 } else { 0 };
        return 0;
    }
    if variable == b"mark-symlinked-directories" {
        let value = CStr::from_ptr(value).to_bytes();
        rl_completion_mark_symlink_dirs = if inputrc_bool(value) { 1 } else { 0 };
        return 0;
    }
    if variable == b"visible-stats" {
        let value = CStr::from_ptr(value).to_bytes();
        rl_visible_stats = if inputrc_bool(value) { 1 } else { 0 };
        return 0;
    }
    if variable == b"bell-style" {
        let value = CStr::from_ptr(value).to_bytes();
        if value.eq_ignore_ascii_case(b"none") || value.eq_ignore_ascii_case(b"off") {
            BELL_STYLE = BELL_STYLE_NONE;
            return 0;
        }
        if value.eq_ignore_ascii_case(b"audible") || value.eq_ignore_ascii_case(b"on") {
            BELL_STYLE = BELL_STYLE_AUDIBLE;
            return 0;
        }
        if value.eq_ignore_ascii_case(b"visible") {
            BELL_STYLE = BELL_STYLE_VISIBLE;
            return 0;
        }
        return 1;
    }
    if variable == b"print-completions-horizontally" {
        let value = CStr::from_ptr(value).to_bytes();
        _rl_print_completions_horizontally = if inputrc_bool(value) { 1 } else { 0 };
        return 0;
    }
    if variable == b"completion-prefix-display-length" {
        let value = CStr::from_ptr(value).to_bytes();
        _rl_completion_prefix_display_length = std::str::from_utf8(value)
            .ok()
            .and_then(|value| value.trim().parse::<c_int>().ok())
            .unwrap_or(0)
            .max(0);
        return 0;
    }
    if variable == b"completion-display-width" {
        let value = CStr::from_ptr(value).to_bytes();
        COMPLETION_DISPLAY_WIDTH = std::str::from_utf8(value)
            .ok()
            .and_then(|value| value.trim().parse::<c_int>().ok())
            .unwrap_or(0);
        return 0;
    }
    let value = CStr::from_ptr(value).to_bytes();
    if bind_inputrc_compat_variable(variable, value) {
        return 0;
    }
    1
}

#[no_mangle]
pub unsafe extern "C" fn rl_variable_value(variable: *const c_char) -> *mut c_char {
    if variable.is_null() {
        return ptr::null_mut();
    }
    let variable = CStr::from_ptr(variable).to_bytes().to_ascii_lowercase();
    let variable = variable.as_slice();
    let bool_value = |enabled: bool| {
        if enabled {
            ON_BYTES.as_ptr() as *mut c_char
        } else {
            OFF_BYTES.as_ptr() as *mut c_char
        }
    };
    if variable == b"history-size" {
        let hist = lock_history();
        let value = if hist.stifled {
            clamp_c_int(hist.max_entries)
        } else {
            -1
        };
        cached_variable_value(format!("{value}").as_bytes())
    } else if variable == b"completion-query-items" {
        let value = rl_completion_query_items;
        cached_variable_value(format!("{value}").as_bytes())
    } else if variable == b"editing-mode" {
        if rl_editing_mode == 0 {
            VI_BYTES.as_ptr() as *mut c_char
        } else {
            EMACS_BYTES.as_ptr() as *mut c_char
        }
    } else if variable == b"keymap" {
        keymap_name_bytes(rl_get_keymap())
            .map_or(ptr::null_mut(), |name| cached_variable_value(&name))
    } else if variable == b"completion-ignore-case" {
        bool_value(lock_editor().completion_ignore_case)
    } else if variable == b"completion-map-case" {
        bool_value(lock_editor().completion_map_case)
    } else if variable == b"disable-completion" {
        bool_value(rl_inhibit_completion != 0)
    } else if variable == b"enable-bracketed-paste" {
        bool_value(ENABLE_BRACKETED_PASTE != 0)
    } else if variable == b"match-hidden-files" {
        bool_value(MATCH_HIDDEN_FILES != 0)
    } else if variable == b"blink-matching-paren" {
        bool_value(rl_blink_matching_paren != 0)
    } else if variable == b"convert-meta" {
        bool_value(CONVERT_META != 0)
    } else if variable == b"input-meta" {
        bool_value(INPUT_META != 0)
    } else if variable == b"output-meta" {
        bool_value(OUTPUT_META != 0)
    } else if variable == b"show-mode-in-prompt" {
        bool_value(SHOW_MODE_IN_PROMPT != 0)
    } else if variable == b"colored-stats" {
        bool_value(COLORED_STATS != 0)
    } else if variable == b"colored-completion-prefix" {
        bool_value(COLORED_COMPLETION_PREFIX != 0)
    } else if variable == b"show-all-if-ambiguous" {
        bool_value(lock_editor().show_all_if_ambiguous)
    } else if variable == b"show-all-if-unmodified" {
        bool_value(lock_editor().show_all_if_unmodified)
    } else if variable == b"mark-directories" {
        bool_value(_rl_complete_mark_directories != 0)
    } else if variable == b"mark-symlinked-directories" {
        bool_value(rl_completion_mark_symlink_dirs != 0)
    } else if variable == b"visible-stats" {
        bool_value(rl_visible_stats != 0)
    } else if variable == b"bell-style" {
        match BELL_STYLE {
            BELL_STYLE_NONE => c"none".as_ptr() as *mut c_char,
            BELL_STYLE_VISIBLE => c"visible".as_ptr() as *mut c_char,
            _ => c"audible".as_ptr() as *mut c_char,
        }
    } else if variable == b"print-completions-horizontally" {
        bool_value(_rl_print_completions_horizontally != 0)
    } else if variable == b"completion-prefix-display-length" {
        let value = _rl_completion_prefix_display_length;
        cached_variable_value(format!("{value}").as_bytes())
    } else if variable == b"completion-display-width" {
        let value = COMPLETION_DISPLAY_WIDTH;
        cached_variable_value(format!("{value}").as_bytes())
    } else if let Some(value) = inputrc_compat_variable_value(variable) {
        match value {
            InputrcCompatValue::Bool(enabled) => bool_value(enabled),
            InputrcCompatValue::Bytes(bytes) => cached_variable_value(&bytes),
            InputrcCompatValue::Int(value) => cached_variable_value(format!("{value}").as_bytes()),
        }
    } else {
        ptr::null_mut()
    }
}

#[no_mangle]
pub unsafe extern "C" fn rl_parse_and_bind(line: *mut c_char) -> c_int {
    if line.is_null() {
        return -1;
    }
    let bytes = CStr::from_ptr(line).to_bytes();
    let trimmed = bytes
        .iter()
        .position(|byte| !byte.is_ascii_whitespace())
        .map(|idx| &bytes[idx..])
        .unwrap_or(&[]);
    if trimmed.is_empty() || trimmed.starts_with(b"#") {
        return 0;
    }

    if let Some(rest) = trimmed.strip_prefix(b"set ") {
        let mut parts = rest.splitn(2, |byte| byte.is_ascii_whitespace());
        if let Some(variable) = parts.next() {
            let raw_value = parts
                .next()
                .map(|value| {
                    let start = value
                        .iter()
                        .position(|byte| !byte.is_ascii_whitespace())
                        .unwrap_or(value.len());
                    &value[start..]
                })
                .unwrap_or(b"");
            let value = if variable.eq_ignore_ascii_case(b"editing-mode")
                || variable.eq_ignore_ascii_case(b"keymap")
            {
                inputrc_unquote_token(raw_value)
            } else {
                raw_value.to_vec()
            };
            let variable = dup_bytes(variable);
            let value = dup_bytes(&value);
            if variable.is_null() || value.is_null() {
                if !variable.is_null() {
                    free(variable as *mut c_void);
                }
                if !value.is_null() {
                    free(value as *mut c_void);
                }
                return -1;
            }
            let result = rl_variable_bind(variable, value);
            free(variable as *mut c_void);
            free(value as *mut c_void);
            return result;
        }
    }

    if let Some(max) = parse_decimal_after(bytes, b"history-size") {
        stifle_history(max);
        return 0;
    }

    if let Some(colon) = bytes.iter().position(|byte| *byte == b':') {
        let key = bytes[..colon].trim_ascii();
        let command = bytes[colon + 1..].trim_ascii();
        let key = if key.starts_with(b"\"") && key.ends_with(b"\"") && key.len() >= 2 {
            &key[1..key.len() - 1]
        } else if key == b"Control-a" {
            b"\\C-a"
        } else if key == b"Control-b" {
            b"\\C-b"
        } else {
            key
        };
        let keyseq = dup_bytes(key);
        if keyseq.is_null() {
            return -1;
        }
        let result = if command.starts_with(b"\"") {
            if let Some(value) = quoted_binding_value(command) {
                let mut editor = lock_editor();
                let seq = parse_keyseq_bytes(key);
                if seq == [0x01] {
                    editor.ctrl_a_macro = value.clone();
                }
                drop(editor);
                let _ = bind_macro_in_map(seq, value, rl_get_keymap());
                0
            } else {
                -1
            }
        } else {
            let command = dup_bytes(command);
            if command.is_null() {
                -1
            } else {
                let result = rl_bind_keyseq(keyseq, rl_named_function(command));
                free(command as *mut c_void);
                result
            }
        };
        free(keyseq as *mut c_void);
        return result;
    }

    if contains_bytes(bytes, b"complete") {
        let mut editor = lock_editor();
        editor.tab_completes = true;
    }
    if contains_bytes(bytes, b"Control-b") || contains_bytes(bytes, b"^B") {
        let mut editor = lock_editor();
        editor.ctrl_b_backward = true;
    }
    if contains_bytes(bytes, b"Control-a") || contains_bytes(bytes, b"^A") {
        if let Some(value) = quoted_binding_value(bytes) {
            let mut editor = lock_editor();
            editor.ctrl_a_macro = value;
        }
    }
    0
}

struct InputrcFrame {
    parent_active: bool,
    active: bool,
    taken: bool,
    else_seen: bool,
}

fn inputrc_stack_active(stack: &[InputrcFrame]) -> bool {
    stack.last().map(|frame| frame.active).unwrap_or(true)
}

unsafe fn inputrc_condition_matches(condition: &[u8]) -> bool {
    let condition = condition.trim_ascii();
    if let Some(mode) = condition.strip_prefix(b"mode=") {
        let mode = mode.trim_ascii();
        return if mode == b"vi" {
            rl_editing_mode == 0
        } else if mode == b"emacs" {
            rl_editing_mode != 0
        } else {
            false
        };
    }
    if let Some(application) = condition.strip_prefix(b"application=") {
        let application = application.trim_ascii();
        if rl_readline_name.is_null() {
            return false;
        }
        return CStr::from_ptr(rl_readline_name).to_bytes() == application;
    }
    if let Some(term) = condition.strip_prefix(b"term=") {
        let term = term.trim_ascii();
        if !rl_terminal_name.is_null()
            && CStr::from_ptr(rl_terminal_name)
                .to_bytes()
                .starts_with(term)
        {
            return true;
        }
        return std::env::var_os("TERM")
            .map(|value| PathBuf::from(value).into_os_string().into_vec())
            .is_some_and(|value| value.starts_with(term));
    }
    if rl_readline_name.is_null() {
        false
    } else {
        CStr::from_ptr(rl_readline_name).to_bytes() == condition
    }
}

unsafe fn read_init_file_path(path: &[u8], explicit: bool) -> c_int {
    {
        let mut editor = lock_editor();
        if editor.inputrc_depth >= 16 {
            return -1;
        }
        editor.inputrc_depth += 1;
    }

    let path = expand_leading_tilde_path_bytes(path);
    let content = match fs::read(path_from_bytes(&path)) {
        Ok(content) => content,
        Err(_) => {
            lock_editor().inputrc_depth -= 1;
            return if explicit { -1 } else { 0 };
        }
    };

    let mut status = 0;
    let mut stack = Vec::new();
    for line in content.split(|byte| *byte == b'\n') {
        let mut line = line;
        if line.ends_with(b"\r") {
            line = &line[..line.len() - 1];
        }
        let trimmed = line.trim_ascii();
        if let Some(condition) = trimmed.strip_prefix(b"$if") {
            let parent_active = inputrc_stack_active(&stack);
            let active = parent_active && inputrc_condition_matches(condition);
            stack.push(InputrcFrame {
                parent_active,
                active,
                taken: active,
                else_seen: false,
            });
            continue;
        }
        if trimmed == b"$else" {
            if let Some(frame) = stack.last_mut() {
                frame.active = frame.parent_active && !frame.taken && !frame.else_seen;
                frame.taken |= frame.active;
                frame.else_seen = true;
            } else {
                status = -1;
            }
            continue;
        }
        if trimmed == b"$endif" {
            if stack.pop().is_none() {
                status = -1;
            }
            continue;
        }
        if let Some(include) = trimmed.strip_prefix(b"$include") {
            if inputrc_stack_active(&stack) {
                let include = include.trim_ascii();
                let include_path = expand_leading_tilde_path_bytes(include);
                let _ = read_init_file_path(&include_path, false);
            }
            continue;
        }
        if inputrc_stack_active(&stack) {
            let tmp = dup_bytes(line);
            if !tmp.is_null() {
                if rl_parse_and_bind(tmp) != 0 {
                    status = -1;
                }
                free(tmp as *mut c_void);
            }
        }
    }
    if !stack.is_empty() {
        status = -1;
    }
    lock_editor().inputrc_depth -= 1;
    status
}

#[no_mangle]
pub unsafe extern "C" fn rl_read_init_file(filename: *const c_char) -> c_int {
    let path = if filename.is_null() {
        match std::env::var_os("INPUTRC")
            .map(|path| PathBuf::from(path).into_os_string().into_vec())
            .filter(|path| !path.is_empty())
        {
            Some(path) => path,
            None => match home_dir_bytes() {
                Some(mut home) if !home.is_empty() => {
                    if !home.ends_with(b"/") {
                        home.push(b'/');
                    }
                    home.extend_from_slice(b".inputrc");
                    home
                }
                _ => return 0,
            },
        }
    } else {
        c_string_bytes(filename)
    };
    read_init_file_path(&path, !filename.is_null())
}

#[no_mangle]
pub unsafe extern "C" fn rl_add_defun(
    name: *const c_char,
    function: rl_command_func_t,
    key: c_int,
) -> c_int {
    if !name.is_null() && function.is_some() {
        let _ = rl_add_funmap_entry(name, function);
    }
    if key >= 0 {
        rl_bind_key(key, function)
    } else {
        0
    }
}

#[no_mangle]
pub unsafe extern "C" fn rl_completion_matches(
    text: *const c_char,
    entry_func: rl_compentry_func_t,
) -> *mut *mut c_char {
    let Some(generator) = entry_func else {
        return ptr::null_mut();
    };

    let mut matches = Vec::new();
    let mut state = 0;
    loop {
        let item = generator(text, state);
        if item.is_null() {
            break;
        }
        matches.push(item);
        if state == c_int::MAX {
            break;
        }
        state += 1;
    }

    if matches.is_empty() {
        return ptr::null_mut();
    }

    let first = CStr::from_ptr(matches[0]).to_bytes();
    let mut prefix_len = first.len();
    for item in &matches[1..] {
        let bytes = CStr::from_ptr(*item).to_bytes();
        let limit = prefix_len.min(bytes.len());
        let mut idx = 0;
        while idx < limit && first[idx] == bytes[idx] {
            idx += 1;
        }
        prefix_len = idx;
    }

    let count = matches.len() + 2;
    let raw = malloc(count * std::mem::size_of::<*mut c_char>()) as *mut *mut c_char;
    if raw.is_null() {
        for item in matches {
            free(item as *mut c_void);
        }
        return ptr::null_mut();
    }
    let prefix = dup_bytes(&first[..prefix_len]);
    if prefix.is_null() {
        for item in matches {
            free(item as *mut c_void);
        }
        free(raw as *mut c_void);
        return ptr::null_mut();
    }
    *raw = prefix;
    for (idx, item) in matches.into_iter().enumerate() {
        *raw.add(idx + 1) = item;
    }
    *raw.add(count - 1) = ptr::null_mut();
    raw
}

#[no_mangle]
pub extern "C" fn rl_filename_completion_function(
    text: *const c_char,
    state: c_int,
) -> *mut c_char {
    if text.is_null() || state < 0 {
        return ptr::null_mut();
    }
    unsafe {
        let mut key = CStr::from_ptr(text).to_bytes().to_vec();
        if let Some(dequote) = rl_filename_dequoting_function {
            let tmp = dup_bytes(&key);
            if tmp.is_null() {
                return ptr::null_mut();
            }
            let dequoted = dequote(tmp, rl_completion_quote_character);
            if let Some(bytes) = take_hook_string(dequoted, tmp) {
                key = bytes;
            }
            free(tmp as *mut c_void);
        }

        let item = if state == 0 {
            let mut matches = build_filename_completions(&key);
            normalize_completion_matches(&mut matches);
            let item = matches.first().cloned();
            let mut generator = lock_filename_completion();
            generator.key = key;
            generator.matches = matches;
            item
        } else {
            let generator = lock_filename_completion();
            if generator.key != key {
                return ptr::null_mut();
            }
            generator.matches.get(state as usize).cloned()
        };
        let Some(item) = item else {
            return ptr::null_mut();
        };

        dup_bytes(&item)
    }
}

#[no_mangle]
pub extern "C" fn rl_username_completion_function(
    text: *const c_char,
    state: c_int,
) -> *mut c_char {
    let mut generator = lock_username_completion();
    unsafe { completion_generator_result(&mut generator, text, state, build_username_completions) }
}

#[no_mangle]
pub extern "C" fn filename_completion_function(text: *const c_char, state: c_int) -> *mut c_char {
    rl_filename_completion_function(text, state)
}

#[no_mangle]
pub extern "C" fn username_completion_function(text: *const c_char, state: c_int) -> *mut c_char {
    rl_username_completion_function(text, state)
}

#[no_mangle]
pub unsafe extern "C" fn rl_copy_text(start: c_int, end: c_int) -> *mut c_char {
    let line = current_line_bytes();
    if start < 0 || end < 0 {
        return dup_bytes(&[]);
    }
    let s = start.min(end) as usize;
    let e = start.max(end) as usize;
    if s >= e || s >= line.len() {
        return dup_bytes(&[]);
    }
    dup_bytes(&line[s..e.min(line.len())])
}

#[no_mangle]
pub unsafe extern "C" fn rl_extend_line_buffer(len: c_int) -> c_int {
    if len < 0 {
        return 0;
    }
    let required = len as usize;
    let current_capacity = if rl_line_buffer_len > 0 {
        rl_line_buffer_len as usize
    } else {
        0
    };
    if current_capacity > required && !rl_line_buffer.is_null() {
        return 0;
    }

    let line = current_line_bytes();
    let capacity = line_buffer_capacity(required.max(line.len()), rl_line_buffer_len);
    let new_buffer = if rl_line_buffer.is_null() {
        malloc(capacity)
    } else {
        realloc(rl_line_buffer as *mut c_void, capacity)
    } as *mut u8;
    if new_buffer.is_null() {
        return -1;
    }
    ptr::copy_nonoverlapping(line.as_ptr(), new_buffer, line.len());
    *new_buffer.add(line.len()) = 0;
    rl_line_buffer = new_buffer as *mut c_char;
    rl_line_buffer_len = clamp_c_int(capacity);
    rl_end = clamp_c_int(line.len());
    rl_point = rl_point.max(0).min(rl_end);
    0
}

#[no_mangle]
pub extern "C" fn rl_ding() -> c_int {
    unsafe {
        if rl_readline_state & RL_STATE_TERMPREPPED == 0 {
            return -1;
        }
        if BELL_STYLE == BELL_STYLE_AUDIBLE {
            output_bytes(b"\x07");
        } else if BELL_STYLE == BELL_STYLE_VISIBLE {
            output_bytes(b"\x1b[?5h\x1b[?5l");
        }
    }
    0
}

#[no_mangle]
pub extern "C" fn rl_abort(_count: c_int, _key: c_int) -> c_int {
    0
}

#[no_mangle]
pub unsafe extern "C" fn rl_insert(count: c_int, key: c_int) -> c_int {
    if count <= 0 || !(0..=255).contains(&key) {
        return 0;
    }
    let bytes = vec![key as u8; count as usize];
    let text = dup_bytes(&bytes);
    if text.is_null() {
        return -1;
    }
    let result = rl_insert_text(text);
    free(text as *mut c_void);
    if result < 0 {
        result
    } else {
        0
    }
}

#[no_mangle]
pub unsafe extern "C" fn rl_complete(_count: c_int, _key: c_int) -> c_int {
    rl_completion_invoking_key = if _key == 0 { b'\t' as c_int } else { _key };
    if rl_inhibit_completion != 0 {
        if (0..=u8::MAX as c_int).contains(&_key) {
            return rl_insert(_count, _key);
        }
        return 0;
    }
    let mut line = current_line_bytes();
    let mut point = if rl_point < 0 {
        0
    } else {
        (rl_point as usize).min(line.len())
    };
    let mode = rl_completion_mode(command_from_unsafe(rl_complete));
    rl_completion_type = mode;
    let _ = complete_line_with_mode(&mut line, &mut point, mode, true);
    0
}

#[no_mangle]
pub unsafe extern "C" fn rl_tilde_expand(_count: c_int, _key: c_int) -> c_int {
    let mut line = current_line_bytes();
    let point = if rl_point < 0 {
        0
    } else {
        (rl_point as usize).min(line.len())
    };
    let Some((start, end)) = tilde_command_range(&line, point) else {
        return 0;
    };
    let expanded = expand_tildes(&line[start..end]);
    if expanded == line[start..end] {
        return 0;
    }
    save_undo_snapshot();
    line.splice(start..end, expanded.iter().copied());
    set_line_buffer_bytes(&line);
    rl_point = clamp_c_int(start + expanded.len());
    rl_end = clamp_c_int(line.len());
    0
}

#[no_mangle]
pub unsafe extern "C" fn rl_modifying(_start: c_int, _end: c_int) -> c_int {
    save_undo_snapshot();
    0
}

#[no_mangle]
pub unsafe extern "C" fn rl_history_search_forward(_count: c_int, _key: c_int) -> c_int {
    set_line_from_history_search(1)
}

#[no_mangle]
pub unsafe extern "C" fn rl_history_search_backward(_count: c_int, _key: c_int) -> c_int {
    set_line_from_history_search(-1)
}

#[no_mangle]
pub extern "C" fn rl_reset_terminal(_terminal_name: *const c_char) -> c_int {
    0
}

#[no_mangle]
pub extern "C" fn rl_resize_terminal() {
    // SAFETY:
    // - refresh_screen_size_from_terminal reads only process-global FILE slots.
    // - Invalid or non-terminal streams are ignored without mutating state.
    unsafe {
        let _ = refresh_screen_size_from_terminal();
    }
}

#[no_mangle]
pub unsafe extern "C" fn rl_set_screen_size(rows: c_int, cols: c_int) {
    if rows > 0 {
        SCREEN_ROWS = rows;
    }
    if cols > 0 {
        SCREEN_COLS = cols - 1;
    }
}

#[no_mangle]
pub unsafe extern "C" fn rl_get_screen_size(rows: *mut c_int, cols: *mut c_int) {
    if !rows.is_null() {
        *rows = SCREEN_ROWS;
    }
    if !cols.is_null() {
        *cols = SCREEN_COLS;
    }
}

#[no_mangle]
pub unsafe extern "C" fn rl_reset_screen_size() {
    if !refresh_screen_size_from_terminal() {
        SCREEN_ROWS = 24;
        SCREEN_COLS = 79;
    }
}

#[no_mangle]
pub extern "C" fn rl_set_signals() -> c_int {
    0
}

#[no_mangle]
pub extern "C" fn rl_clear_signals() -> c_int {
    0
}

#[no_mangle]
pub extern "C" fn rl_pending_signal() -> c_int {
    0
}

#[no_mangle]
pub extern "C" fn rl_check_signals() {}

#[no_mangle]
pub unsafe extern "C" fn rl_set_timeout(seconds: u32, useconds: u32) -> c_int {
    TIMEOUT_SECONDS = seconds.min(c_int::MAX as u32) as c_int;
    TIMEOUT_USECONDS = useconds.min(c_int::MAX as u32) as c_int;
    if seconds == 0 && useconds == 0 {
        TIMEOUT_ACTIVE = false;
        rl_readline_state &= !RL_STATE_TIMEOUT;
    }
    0
}

#[no_mangle]
pub unsafe extern "C" fn rl_timeout_remaining(seconds: *mut u32, useconds: *mut u32) -> c_int {
    if !TIMEOUT_ACTIVE {
        return -1;
    }
    if rl_readline_state & RL_STATE_TIMEOUT != 0 {
        if !seconds.is_null() {
            *seconds = 0;
        }
        if !useconds.is_null() {
            *useconds = 0;
        }
        return 0;
    }
    if !seconds.is_null() {
        *seconds = TIMEOUT_SECONDS.max(0) as u32;
    }
    if !useconds.is_null() {
        *useconds = TIMEOUT_USECONDS.max(0) as u32;
    }
    1
}

#[no_mangle]
pub unsafe extern "C" fn rl_set_keyboard_input_timeout(usec: c_int) -> c_int {
    let old = KEYBOARD_INPUT_TIMEOUT_USECONDS;
    if usec >= 0 {
        KEYBOARD_INPUT_TIMEOUT_USECONDS = usec;
    }
    old
}

#[no_mangle]
pub unsafe extern "C" fn rl_getc(stream: *mut c_void) -> c_int {
    if let Some(getc) = rl_getc_function {
        return getc(stream);
    }
    let input = if stream.is_null() {
        ensure_stdio_streams();
        rl_instream
    } else {
        stream
    };
    if input.is_null() {
        READERR
    } else {
        fgetc(input)
    }
}

#[no_mangle]
pub unsafe extern "C" fn rl_read_key() -> c_int {
    ensure_stdio_streams();
    if rl_pending_input != 0 {
        let key = rl_pending_input;
        rl_pending_input = 0;
        return key;
    }
    {
        let mut editor = lock_editor();
        if let Some(key) = editor.macro_input.pop_front() {
            if editor.macro_input.is_empty() && !rl_executing_macro.is_null() {
                free(rl_executing_macro as *mut c_void);
                rl_executing_macro = ptr::null_mut();
            }
            return key as c_int;
        }
        if let Some(key) = editor.pending_input.pop_front() {
            return key;
        }
    }
    rl_readline_state &= !0x00020000;
    rl_getc(rl_instream)
}

// Single-byte read tailored to rl_callback_read_char.
//
// The callback API is driven by select()/poll() on the underlying file
// descriptor. Consumers (CPython input(), the man-page reproducer) call
// rl_callback_read_char() at most once per readiness event. Using stdio
// buffering (fgetc) traps subsequent bytes inside libc; select() then
// reports the fd idle even though characters are still waiting, and the
// dispatcher hangs without ever firing the registered line handler.
//
// Honor the same short-circuits as rl_read_key (rl_pending_input, the
// editor queue, macro playback, a caller-supplied rl_getc_function) and
// fall back to a one-byte read(2) directly against the instream fd. That
// keeps every byte visible to the kernel-level readiness layer driving
// the outer loop while still feeding one character per call into the
// shared key-binding / line-completion machinery used by readline().
unsafe fn callback_read_byte() -> c_int {
    ensure_stdio_streams();
    if rl_pending_input != 0 {
        let key = rl_pending_input;
        rl_pending_input = 0;
        return key;
    }
    {
        let mut editor = lock_editor();
        if let Some(key) = editor.macro_input.pop_front() {
            if editor.macro_input.is_empty() && !rl_executing_macro.is_null() {
                free(rl_executing_macro as *mut c_void);
                rl_executing_macro = ptr::null_mut();
            }
            return key as c_int;
        }
        if let Some(key) = editor.pending_input.pop_front() {
            return key;
        }
    }
    rl_readline_state &= !0x00020000;
    if let Some(getc) = rl_getc_function {
        return getc(rl_instream);
    }
    let fd = if rl_instream.is_null() {
        0
    } else {
        fileno(rl_instream)
    };
    if fd < 0 {
        return READERR;
    }
    let mut byte: u8 = 0;
    let got = read(fd, &mut byte as *mut u8 as *mut c_void, 1);
    if got == 1 { byte as c_int } else { READERR }
}

unsafe fn queued_input_available() -> bool {
    if rl_pending_input != 0 {
        return true;
    }
    let editor = lock_editor();
    !editor.pending_input.is_empty() || !editor.macro_input.is_empty()
}

#[no_mangle]
pub unsafe extern "C" fn rl_stuff_char(key: c_int) -> c_int {
    lock_editor().pending_input.push_back(key);
    rl_readline_state |= 0x00020000;
    1
}

#[no_mangle]
pub extern "C" fn rl_crlf() -> c_int {
    unsafe { output_newline() };
    0
}

#[no_mangle]
pub unsafe extern "C" fn rl_untranslate_keyseq(key: c_int) -> *mut c_char {
    if (0..=255).contains(&key) {
        dup_bytes(&[key as u8])
    } else {
        dup_bytes(&[])
    }
}

#[no_mangle]
pub unsafe extern "C" fn rl_free(mem: *mut c_void) {
    if !mem.is_null() {
        free(mem);
    }
}

#[no_mangle]
pub unsafe extern "C" fn rl_callback_handler_install(
    prompt: *const c_char,
    handler: rl_callback_handler_t,
) {
    if rl_readline_state & RL_STATE_INITIALIZED == 0 {
        let _ = rl_initialize();
    }
    ensure_stdio_streams();
    set_prompt_value(prompt);
    let _ = rl_prep_terminal(1);
    // rl_startup_hook fires once per readline session, before the prompt is
    // displayed.  Mirror the readline() entry path so callback consumers
    // (CPython's input() via rl_callback_*) see identical setup semantics.
    if let Some(hook) = rl_startup_hook {
        let _ = hook();
    }
    {
        let mut cb = lock_callback();
        if !cb.prompt.is_null() {
            free(cb.prompt as *mut c_void);
        }
        cb.prompt = dup_c_string(prompt);
        cb.handler = handler;
        cb.prompt_shown = false;
        cb.line.clear();
        cb.point = 0;
        cb.previous_tab_left_line_unchanged = false;
        if !prompt.is_null() && rl_already_prompted == 0 {
            output_c_string(prompt);
            cb.prompt_shown = true;
        }
    }
    let _ = load_saved_line_into_callback();
    // rl_pre_input_hook fires after the prompt is on screen but before the
    // first input byte is consumed.  CPython's test_nonascii uses this hook
    // to inject text (via rl_insert_text / rl_redisplay) that must show up in
    // the line buffer the user is editing.
    if let Some(hook) = rl_pre_input_hook {
        let _ = hook();
        // Hook may have called rl_insert_text, which writes to rl_line_buffer.
        // Synchronise the callback-side staging buffer with whatever the hook
        // left behind so subsequent keystrokes edit the post-hook line.
        let line = current_line_bytes();
        let point = current_point();
        let mut cb = lock_callback();
        cb.line = line;
        cb.point = point;
    }
    rl_readline_state |= RL_STATE_CALLBACK;
}

#[no_mangle]
pub unsafe extern "C" fn rl_callback_read_char() {
    let handler = {
        let cb = lock_callback();
        cb.handler
    };
    let Some(handler) = handler else {
        return;
    };

    if let Some(hook) = rl_event_hook {
        let _ = hook();
    }
    if let Some(input_available) = rl_input_available_hook {
        if input_available() == 0 && !queued_input_available() {
            return;
        }
    }

    let key = callback_read_byte();
    if key < 0 {
        let line = {
            let mut cb = lock_callback();
            if cb.line.is_empty() {
                ptr::null_mut()
            } else {
                let line = dup_bytes(&cb.line);
                cb.line.clear();
                cb.point = 0;
                cb.previous_tab_left_line_unchanged = false;
                line
            }
        };
        if line.is_null() {
            rl_eof_found = 1;
            rl_readline_state |= RL_STATE_DONE;
            rl_deprep_terminal();
            handler(ptr::null_mut());
        } else {
            rl_eof_found = 0;
            rl_done = 0;
            rl_readline_state &= !RL_STATE_DONE;
            rl_deprep_terminal();
            handler(line);
        }
        if callback_handler_installed() {
            let _ = rl_prep_terminal(1);
        }
        return;
    }

    let (mut line, mut point, mut previous_tab) = {
        let mut cb = lock_callback();
        (
            std::mem::take(&mut cb.line),
            cb.point,
            cb.previous_tab_left_line_unchanged,
        )
    };
    let outcome = process_edit_key(&mut line, &mut point, &mut previous_tab, key);
    let accepted_by_limit =
        if rl_num_chars_to_read > 0 && line.len() >= rl_num_chars_to_read as usize {
            line.truncate(rl_num_chars_to_read as usize);
            point = point.min(line.len());
            true
        } else {
            false
        };
    set_line_buffer_bytes(&line);
    rl_point = clamp_c_int(point);
    rl_end = clamp_c_int(line.len());
    let accepted = accepted_by_limit || matches!(outcome, KeyOutcome::Accept) || rl_done != 0;
    {
        let mut cb = lock_callback();
        cb.line = line;
        cb.point = point;
        cb.previous_tab_left_line_unchanged = previous_tab;
    }

    if accepted {
        rl_eof_found = 0;
        rl_readline_state |= RL_STATE_DONE;
        let line = {
            let mut cb = lock_callback();
            let line = dup_bytes(&cb.line);
            cb.line.clear();
            cb.point = 0;
            cb.previous_tab_left_line_unchanged = false;
            line
        };
        rl_deprep_terminal();
        handler(line);
        rl_done = 0;
        rl_readline_state &= !RL_STATE_DONE;
        if callback_handler_installed() {
            let _ = rl_prep_terminal(1);
        }
        let _ = load_saved_line_into_callback();

        let prompt = {
            let cb = lock_callback();
            if cb.handler.is_some() && !cb.prompt.is_null() && rl_already_prompted == 0 {
                cb.prompt
            } else {
                ptr::null_mut()
            }
        };
        if !prompt.is_null() {
            output_c_string(prompt);
        }
    } else {
        rl_readline_state &= !RL_STATE_DONE;
    }
}

#[no_mangle]
pub unsafe extern "C" fn rl_callback_handler_remove() {
    rl_deprep_terminal();
    let mut cb = lock_callback();
    if !cb.prompt.is_null() {
        free(cb.prompt as *mut c_void);
    }
    cb.prompt = ptr::null_mut();
    cb.handler = None;
    cb.prompt_shown = false;
    cb.line.clear();
    cb.point = 0;
    cb.previous_tab_left_line_unchanged = false;
    rl_readline_state &= !RL_STATE_CALLBACK;
}

fn callback_handler_installed() -> bool {
    let cb = lock_callback();
    cb.handler.is_some()
}

#[no_mangle]
pub unsafe extern "C" fn rl_callback_sigcleanup() {
    let mut cb = lock_callback();
    cb.line.clear();
    cb.point = 0;
    cb.previous_tab_left_line_unchanged = false;
    rl_done = 0;
    rl_readline_state &= !RL_STATE_DONE;
}

unsafe fn load_saved_line_into_callback() -> bool {
    let callback_active = {
        let cb = lock_callback();
        cb.handler.is_some()
    };
    if !callback_active {
        return false;
    }

    let saved_line = {
        let mut editor = lock_editor();
        editor.saved_line.take()
    };
    let Some(saved_line) = saved_line else {
        return false;
    };

    let mut cb = lock_callback();
    if cb.handler.is_none() {
        drop(cb);
        let mut editor = lock_editor();
        editor.saved_line = Some(saved_line);
        return false;
    }
    cb.line = saved_line;
    cb.point = cb.line.len();
    cb.previous_tab_left_line_unchanged = false;
    set_line_buffer_bytes(&cb.line);
    rl_point = clamp_c_int(cb.point);
    rl_end = clamp_c_int(cb.line.len());
    true
}

#[no_mangle]
pub unsafe extern "C" fn rl_make_bare_keymap() -> *mut c_void {
    allocate_keymap(None)
}

#[no_mangle]
pub unsafe extern "C" fn rl_make_keymap() -> *mut c_void {
    let map = allocate_keymap(None);
    if let Some(keymap) = keymap_data_mut(map) {
        for key in 0x20..=0x7e {
            keymap.key_bindings[key] = command_from_unsafe(rl_insert);
        }
        keymap.key_bindings[b'\t' as usize] = command_from_unsafe(rl_insert);
    }
    map
}

#[no_mangle]
pub unsafe extern "C" fn rl_copy_keymap(map: *mut c_void) -> *mut c_void {
    let Some(keymap) = keymap_data(map) else {
        return ptr::null_mut();
    };
    let copy = Box::into_raw(Box::new(keymap.clone())) as *mut c_void;
    lock_keymap_registry().push(copy as usize);
    copy
}

#[no_mangle]
pub unsafe extern "C" fn rl_discard_keymap(map: *mut c_void) {
    rl_free_keymap(map);
}

#[no_mangle]
pub unsafe extern "C" fn rl_free_keymap(map: *mut c_void) {
    if map.is_null() {
        return;
    }
    if !is_builtin_keymap(map) {
        if !keymap_registered(map) {
            return;
        }
        if CURRENT_KEYMAP == map {
            CURRENT_KEYMAP = ensure_builtin_keymap();
        }
        lock_keymap_registry().retain(|registered| *registered != map as usize);
        drop(Box::from_raw(map as *mut KeymapData));
    }
}

#[no_mangle]
pub unsafe extern "C" fn rl_get_keymap_by_name(name: *const c_char) -> *mut c_void {
    ensure_builtin_keymap();
    if name.is_null() {
        return ptr::null_mut();
    }
    let name = CStr::from_ptr(name).to_bytes();
    match name {
        b"emacs" | b"emacs-standard" => emacs_standard_keymap,
        b"emacs-meta" => emacs_meta_keymap,
        b"emacs-ctlx" => emacs_ctlx_keymap,
        b"vi-insert" => vi_insertion_keymap,
        b"vi" | b"vi-move" | b"vi-command" => vi_movement_keymap,
        _ => {
            let registered_maps = lock_keymap_registry().clone();
            for registered in registered_maps {
                let map = registered as *mut c_void;
                if let Some(keymap) = keymap_data(map) {
                    if keymap.name.as_deref() == Some(name) {
                        return map;
                    }
                }
            }
            ptr::null_mut()
        }
    }
}

#[no_mangle]
pub unsafe extern "C" fn rl_get_keymap_name(map: *mut c_void) -> *mut c_char {
    if map.is_null() {
        ptr::null_mut()
    } else if let Some(keymap) = keymap_data(map) {
        keymap
            .name
            .as_deref()
            .map_or_else(ptr::null_mut, |name| dup_bytes(name))
    } else {
        ptr::null_mut()
    }
}

#[no_mangle]
pub unsafe extern "C" fn rl_set_keymap(map: *mut c_void) {
    CURRENT_KEYMAP = if map.is_null() {
        ensure_builtin_keymap()
    } else if keymap_registered(map) {
        map
    } else {
        ensure_builtin_keymap()
    };
    rl_binding_keymap = CURRENT_KEYMAP;
}

#[no_mangle]
pub unsafe extern "C" fn rl_get_keymap() -> *mut c_void {
    if CURRENT_KEYMAP.is_null() {
        ensure_builtin_keymap()
    } else {
        CURRENT_KEYMAP
    }
}

#[no_mangle]
pub unsafe extern "C" fn rl_set_keymap_name(name: *const c_char, map: *mut c_void) -> c_int {
    if name.is_null() || map.is_null() {
        return -1;
    }
    let name = CStr::from_ptr(name).to_bytes();
    if is_builtin_keymap(map) {
        -1
    } else if let Some(keymap) = keymap_data_mut(map) {
        keymap.name = Some(name.to_vec());
        8
    } else {
        -1
    }
}

#[no_mangle]
pub unsafe extern "C" fn tilde_expand(filename: *const c_char) -> *mut c_char {
    if filename.is_null() {
        return dup_bytes(&[]);
    }
    let input = CStr::from_ptr(filename).to_bytes();
    let expanded = expand_tildes(input);
    dup_bytes(&expanded)
}

#[no_mangle]
pub unsafe extern "C" fn tilde_expand_word(filename: *const c_char) -> *mut c_char {
    tilde_expand(filename)
}

unsafe fn global_string_bytes(value: *mut c_char, fallback: &[u8]) -> Vec<u8> {
    if value.is_null() {
        fallback.to_vec()
    } else {
        CStr::from_ptr(value).to_bytes().to_vec()
    }
}

fn unix_timestamp_bytes() -> Vec<u8> {
    let seconds = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|duration| duration.as_secs())
        .unwrap_or(0);
    format!("#{seconds}").into_bytes()
}

unsafe fn timestamp_for_write(entry: &HIST_ENTRY) -> Option<Vec<u8>> {
    if history_write_timestamps == 0 {
        return None;
    }
    if entry.timestamp.is_null() {
        return Some(unix_timestamp_bytes());
    }
    let timestamp = CStr::from_ptr(entry.timestamp).to_bytes();
    if timestamp.starts_with(b"#") {
        Some(timestamp.to_vec())
    } else {
        let mut with_marker = Vec::with_capacity(timestamp.len() + 1);
        with_marker.push(b'#');
        with_marker.extend_from_slice(timestamp);
        Some(with_marker)
    }
}

unsafe fn write_history_entry(file: &mut fs::File, entry: &HIST_ENTRY) -> io::Result<bool> {
    if entry.line.is_null() {
        return Ok(false);
    }
    if let Some(timestamp) = timestamp_for_write(entry) {
        file.write_all(&timestamp)?;
        file.write_all(b"\n")?;
    }
    file.write_all(CStr::from_ptr(entry.line).to_bytes())?;
    file.write_all(b"\n")?;
    Ok(true)
}

unsafe fn add_history_entry_bytes(line: &[u8], timestamp: Option<&[u8]>) -> bool {
    let line = dup_bytes(line);
    if line.is_null() {
        return false;
    }
    let timestamp = if let Some(timestamp) = timestamp {
        let timestamp = dup_bytes(timestamp);
        if timestamp.is_null() {
            free(line as *mut c_void);
            return false;
        }
        timestamp
    } else {
        ptr::null_mut()
    };
    let entry = Box::new(HIST_ENTRY {
        line,
        timestamp,
        data: ptr::null_mut(),
    });
    let mut hist = lock_history();
    hist.entries.push(entry);
    hist.trim();
    hist.sync_globals();
    true
}

fn is_history_timestamp_line(line: &[u8]) -> bool {
    line.len() > 1 && line[0] == b'#' && line[1..].iter().all(u8::is_ascii_digit)
}

struct HistoryFileEntry {
    timestamp: Option<Vec<u8>>,
    line: Vec<u8>,
}

fn finish_multiline_history_entry(
    entries: &mut Vec<HistoryFileEntry>,
    timestamp: &mut Option<Vec<u8>>,
    line: &mut Option<Vec<u8>>,
) {
    if let Some(line) = line.take() {
        entries.push(HistoryFileEntry {
            timestamp: timestamp.take(),
            line,
        });
    }
}

fn parse_history_content(content: &[u8], multiline: bool) -> Vec<HistoryFileEntry> {
    let mut entries = Vec::new();
    let mut pending_timestamp = None;
    let mut current_timestamp = None;
    let mut current_line = None;
    let mut offset = 0usize;

    while offset < content.len() {
        let line_end = content[offset..]
            .iter()
            .position(|byte| *byte == b'\n')
            .map_or(content.len(), |pos| offset + pos);
        let mut line = &content[offset..line_end];
        if line.ends_with(b"\r") {
            line = &line[..line.len() - 1];
        }
        offset = if line_end < content.len() {
            line_end + 1
        } else {
            content.len()
        };

        if line.is_empty() && pending_timestamp.is_none() && current_line.is_none() {
            continue;
        }
        if is_history_timestamp_line(line) {
            if multiline {
                finish_multiline_history_entry(
                    &mut entries,
                    &mut current_timestamp,
                    &mut current_line,
                );
            }
            pending_timestamp = Some(line.to_vec());
            continue;
        }
        if multiline && (pending_timestamp.is_some() || current_line.is_some()) {
            if let Some(current) = current_line.as_mut() {
                current.push(b'\n');
                current.extend_from_slice(line);
            } else {
                current_timestamp = pending_timestamp.take();
                current_line = Some(line.to_vec());
            }
        } else {
            entries.push(HistoryFileEntry {
                timestamp: pending_timestamp.take(),
                line: line.to_vec(),
            });
        }
    }
    if multiline {
        finish_multiline_history_entry(&mut entries, &mut current_timestamp, &mut current_line);
    }
    entries
}

fn truncate_history_content(content: &[u8], keep: usize, multiline: bool) -> Vec<u8> {
    let entries = parse_history_content(content, multiline);
    let start = entries.len().saturating_sub(keep);
    let mut output = Vec::new();
    for entry in &entries[start..] {
        if let Some(timestamp) = &entry.timestamp {
            output.extend_from_slice(timestamp);
            output.push(b'\n');
        }
        output.extend_from_slice(&entry.line);
        output.push(b'\n');
    }
    output
}

unsafe fn history_line_at(hist: &History, index: usize) -> Option<Vec<u8>> {
    hist.entries.get(index).map(|entry| entry_line_bytes(entry))
}

unsafe fn history_last_line() -> Option<Vec<u8>> {
    let hist = lock_history();
    hist.entries.last().map(|entry| entry_line_bytes(entry))
}

unsafe fn history_absolute_line(offset: c_int) -> Option<Vec<u8>> {
    let hist = lock_history();
    let base = history_base;
    let index = offset - base;
    if index < 0 {
        return None;
    }
    history_line_at(&hist, index as usize)
}

unsafe fn history_relative_line(distance: usize) -> Option<Vec<u8>> {
    if distance == 0 {
        return None;
    }
    let hist = lock_history();
    if distance > hist.entries.len() {
        return None;
    }
    history_line_at(&hist, hist.entries.len() - distance)
}

unsafe fn history_find_prefix(prefix: &[u8]) -> Option<Vec<u8>> {
    let hist = lock_history();
    let end = if hist.offset >= hist.entries.len() {
        hist.entries.len()
    } else {
        hist.offset + 1
    };
    hist.entries[..end].iter().rev().find_map(|entry| {
        let line = entry_line_bytes(entry);
        if line.starts_with(prefix) {
            Some(line)
        } else {
            None
        }
    })
}

unsafe fn history_find_substring(needle: &[u8]) -> Option<Vec<u8>> {
    let hist = lock_history();
    let end = if hist.offset >= hist.entries.len() {
        hist.entries.len()
    } else {
        hist.offset + 1
    };
    hist.entries[..end].iter().rev().find_map(|entry| {
        let line = entry_line_bytes(entry);
        if contains_bytes(&line, needle) {
            Some(line)
        } else {
            None
        }
    })
}

unsafe fn history_search_impl(
    needle: &[u8],
    direction: c_int,
    prefix_only: bool,
    pos: usize,
    return_index: bool,
) -> c_int {
    let mut hist = lock_history();
    if hist.entries.is_empty() || needle.is_empty() {
        return -1;
    }
    let mut idx = pos.min(hist.entries.len().saturating_sub(1));
    loop {
        let line = entry_line_bytes(&hist.entries[idx]);
        let found = if needle.is_empty() {
            Some(0)
        } else if prefix_only {
            line.starts_with(needle).then_some(0)
        } else {
            line.windows(needle.len())
                .position(|window| window == needle)
        };
        if let Some(offset) = found {
            return if return_index {
                clamp_c_int(idx)
            } else {
                hist.offset = idx;
                hist.sync_globals();
                clamp_c_int(offset)
            };
        }
        if direction >= 0 {
            idx += 1;
            if idx >= hist.entries.len() {
                break;
            }
        } else if idx == 0 {
            break;
        } else {
            idx -= 1;
        }
    }
    -1
}

unsafe fn set_line_from_history_search(direction: c_int) -> c_int {
    let line = current_line_bytes();
    let point = if rl_point < 0 {
        0
    } else {
        (rl_point as usize).min(line.len())
    };
    let needle = &line[..point];
    let mut hist = lock_history();
    if hist.entries.is_empty() || needle.is_empty() {
        return 1;
    }

    let Some(start) = (if direction >= 0 {
        let start = hist.offset.saturating_add(1);
        (start < hist.entries.len()).then_some(start)
    } else if hist.offset >= hist.entries.len() {
        Some(hist.entries.len() - 1)
    } else if hist.offset == 0 {
        None
    } else {
        Some(hist.offset - 1)
    }) else {
        return 1;
    };
    let mut idx = start;
    loop {
        let candidate = entry_line_bytes(&hist.entries[idx]);
        if candidate.starts_with(needle) {
            hist.offset = idx;
            hist.sync_globals();
            drop(hist);
            set_line_buffer_bytes(&candidate);
            rl_point = clamp_c_int(point.min(candidate.len()));
            rl_end = clamp_c_int(candidate.len());
            return 0;
        }
        if direction >= 0 {
            idx += 1;
            if idx >= hist.entries.len() {
                break;
            }
        } else if idx == 0 {
            break;
        } else {
            idx -= 1;
        }
    }
    1
}

#[no_mangle]
pub extern "C" fn using_history() {
    // GNU history's using_history() initialises the temporary editing
    // state by parking the cursor one past the most-recent entry.  After
    // this call, previous_history() returns the most-recent line.  This
    // is the only spec-mandated way to reset the cursor; callers that
    // want fresh "Up arrow surfaces last entry" behaviour invoke this
    // before each readline() / rl_callback_handler_install().  CPython's
    // readline module does so on every input() — that's how interactive
    // history-recall is supposed to work.
    let mut hist = lock_history();
    hist.offset = hist.entries.len();
    hist.sync_globals();
}

#[no_mangle]
pub unsafe extern "C" fn add_history(line: *const c_char) {
    if line.is_null() {
        return;
    }
    let entry = Box::new(HIST_ENTRY {
        line: dup_c_string(line),
        timestamp: ptr::null_mut(),
        data: ptr::null_mut(),
    });
    let mut hist = lock_history();
    hist.entries.push(entry);
    hist.trim();
    // Preserve the GNU-history invariant that where_history() does not
    // move on add_history(); the read-loop entry points (readline(),
    // rl_callback_handler_install()) are responsible for parking the
    // cursor at the end on a fresh session via the using_history() rule.
    hist.sync_globals();
}

#[no_mangle]
pub unsafe extern "C" fn add_history_time(string: *const c_char) {
    if string.is_null() {
        return;
    }
    let mut hist = lock_history();
    if let Some(entry) = hist.entries.last_mut() {
        if !entry.timestamp.is_null() {
            free(entry.timestamp as *mut c_void);
        }
        entry.timestamp = dup_c_string(string);
    }
}

#[no_mangle]
pub unsafe extern "C" fn clear_history() {
    let mut hist = lock_history();
    while let Some(entry) = hist.entries.pop() {
        free_entry_box(entry);
    }
    hist.list.clear();
    hist.offset = 0;
    hist.sync_globals();
}

#[no_mangle]
pub unsafe extern "C" fn rl_clear_history() {
    clear_history();
}

#[no_mangle]
pub extern "C" fn stifle_history(max: c_int) {
    let mut hist = lock_history();
    hist.max_entries = max.max(0) as usize;
    hist.stifled = true;
    hist.trim();
    hist.sync_globals();
}

#[no_mangle]
pub extern "C" fn unstifle_history() -> c_int {
    let mut hist = lock_history();
    let old = clamp_c_int(hist.max_entries);
    hist.max_entries = 0;
    hist.stifled = false;
    hist.sync_globals();
    old
}

#[no_mangle]
pub extern "C" fn history_is_stifled() -> c_int {
    let hist = lock_history();
    if hist.stifled {
        1
    } else {
        0
    }
}

#[no_mangle]
pub extern "C" fn history_list() -> *mut *mut HIST_ENTRY {
    let mut hist = lock_history();
    let mut ptrs = Vec::with_capacity(hist.entries.len() + 1);
    for entry in hist.entries.iter_mut() {
        ptrs.push(&mut **entry as *mut HIST_ENTRY);
    }
    ptrs.push(ptr::null_mut());
    hist.list = ptrs;
    hist.list.as_mut_ptr()
}

#[no_mangle]
pub extern "C" fn history_get(offset: c_int) -> *mut HIST_ENTRY {
    let mut hist = lock_history();
    let base = unsafe { history_base };
    let index = offset - base;
    if index < 0 {
        return ptr::null_mut();
    }
    hist.ptr_at(index as usize)
}

#[no_mangle]
pub unsafe extern "C" fn history_get_time(entry: *mut HIST_ENTRY) -> c_long {
    if entry.is_null() || (*entry).timestamp.is_null() {
        return 0;
    }
    let bytes = CStr::from_ptr((*entry).timestamp).to_bytes();
    let digits = bytes.strip_prefix(b"#").unwrap_or(bytes);
    std::str::from_utf8(digits)
        .ok()
        .and_then(|value| value.parse::<c_long>().ok())
        .unwrap_or_default()
}

#[no_mangle]
pub unsafe extern "C" fn history_get_history_state() -> *mut HISTORY_STATE {
    history_get_state()
}

#[no_mangle]
pub unsafe extern "C" fn history_get_state() -> *mut HISTORY_STATE {
    let list = history_list();
    let hist = lock_history();
    let state = HISTORY_STATE {
        entries: list,
        offset: clamp_c_int(hist.offset),
        length: clamp_c_int(hist.entries.len()),
        size: clamp_c_int(if hist.stifled {
            hist.max_entries
        } else {
            hist.entries.capacity()
        }),
        flags: if hist.stifled { 1 } else { 0 },
    };
    let raw = malloc(std::mem::size_of::<HISTORY_STATE>()) as *mut HISTORY_STATE;
    if raw.is_null() {
        return ptr::null_mut();
    }
    ptr::write(raw, state);
    raw
}

#[no_mangle]
pub extern "C" fn history_set_history_state(state: *mut HISTORY_STATE) {
    if state.is_null() {
        return;
    }
    let state = unsafe { &*state };
    let length = state.length.max(0) as usize;
    let mut entries = Vec::new();
    if !state.entries.is_null() {
        for index in 0..length {
            let entry = unsafe { *state.entries.add(index) };
            if entry.is_null() {
                continue;
            }
            entries.push(Box::new(HIST_ENTRY {
                line: unsafe { dup_c_string((*entry).line) },
                timestamp: unsafe { dup_c_string((*entry).timestamp) },
                data: unsafe { (*entry).data },
            }));
        }
    }

    let mut hist = lock_history();
    while let Some(entry) = hist.entries.pop() {
        unsafe { free_entry_box(entry) };
    }
    hist.list.clear();
    hist.entries = entries;
    hist.stifled = state.flags & 1 != 0;
    hist.max_entries = if hist.stifled {
        state.size.max(state.length).max(0) as usize
    } else {
        0
    };
    hist.trim();
    let offset = state.offset;
    hist.offset = offset.max(0) as usize;
    if hist.offset > hist.entries.len() {
        hist.offset = hist.entries.len();
    }
    hist.sync_globals();
}

#[no_mangle]
pub extern "C" fn where_history() -> c_int {
    let hist = lock_history();
    clamp_c_int(hist.offset)
}

#[no_mangle]
pub extern "C" fn history_set_pos(pos: c_int) -> c_int {
    let mut hist = lock_history();
    if pos < 0 || pos as usize > hist.entries.len() {
        return 0;
    }
    hist.offset = pos as usize;
    hist.sync_globals();
    1
}

#[no_mangle]
pub extern "C" fn current_history() -> *mut HIST_ENTRY {
    let mut hist = lock_history();
    let idx = hist.offset;
    hist.ptr_at(idx)
}

#[no_mangle]
pub extern "C" fn previous_history() -> *mut HIST_ENTRY {
    let mut hist = lock_history();
    if hist.offset == 0 {
        return ptr::null_mut();
    }
    hist.offset -= 1;
    let idx = hist.offset;
    hist.sync_globals();
    hist.ptr_at(idx)
}

#[no_mangle]
pub extern "C" fn next_history() -> *mut HIST_ENTRY {
    let mut hist = lock_history();
    if hist.offset >= hist.entries.len() {
        return ptr::null_mut();
    }
    hist.offset += 1;
    hist.sync_globals();
    if hist.offset >= hist.entries.len() {
        ptr::null_mut()
    } else {
        let idx = hist.offset;
        hist.ptr_at(idx)
    }
}

#[no_mangle]
pub extern "C" fn rl_get_previous_history(count: c_int, _key: c_int) -> c_int {
    let steps = count.max(1);
    let mut selected = None;
    for _ in 0..steps {
        match history_previous_line() {
            Some(line) => selected = Some(line),
            None => break,
        }
    }
    if let Some(line) = selected {
        unsafe { set_line_buffer_bytes(&line) };
    }
    0
}

#[no_mangle]
pub extern "C" fn rl_get_next_history(count: c_int, _key: c_int) -> c_int {
    let steps = count.max(1);
    let mut selected = None;
    for _ in 0..steps {
        match history_next_line() {
            Some(line) => selected = Some(line),
            None => break,
        }
    }
    if let Some(line) = selected {
        unsafe { set_line_buffer_bytes(&line) };
    }
    0
}

#[no_mangle]
pub unsafe extern "C" fn rl_replace_from_history(_entry: *mut HIST_ENTRY, _flags: c_int) -> c_int {
    let entry = current_history();
    if entry.is_null() {
        return 1;
    }
    let line = entry_line_bytes(&*entry);
    set_line_buffer_bytes(&line);
    0
}

#[no_mangle]
pub unsafe extern "C" fn rl_fetch_history() -> c_int {
    rl_replace_from_history(ptr::null_mut(), 0)
}

#[no_mangle]
pub extern "C" fn rl_beginning_of_history(_count: c_int, _key: c_int) -> c_int {
    history_set_pos(0);
    0
}

#[no_mangle]
pub extern "C" fn rl_end_of_history(_count: c_int, _key: c_int) -> c_int {
    let len = lock_history().entries.len();
    history_set_pos(clamp_c_int(len));
    0
}

#[no_mangle]
pub unsafe extern "C" fn rl_operate_and_get_next(_count: c_int, _key: c_int) -> c_int {
    rl_done = 1;
    let mut hist = lock_history();
    if hist.offset + 1 < hist.entries.len() {
        hist.offset += 1;
        let line = entry_line_bytes(&hist.entries[hist.offset]);
        hist.sync_globals();
        drop(hist);
        let mut editor = lock_editor();
        editor.saved_line = Some(line);
    } else {
        hist.sync_globals();
    }
    0
}

#[no_mangle]
pub extern "C" fn remove_history(which: c_int) -> *mut HIST_ENTRY {
    if which < 0 {
        return ptr::null_mut();
    }
    let mut hist = lock_history();
    let index = which as usize;
    if index >= hist.entries.len() {
        return ptr::null_mut();
    }
    let entry = hist.entries.remove(index);
    if hist.offset > hist.entries.len() {
        hist.offset = hist.entries.len();
    }
    hist.sync_globals();
    Box::into_raw(entry)
}

#[no_mangle]
pub extern "C" fn remove_history_range(from: c_int, to: c_int) -> c_int {
    if from < 0 || to < from {
        return -1;
    }
    let mut hist = lock_history();
    let start = from as usize;
    let end = (to as usize).min(hist.entries.len().saturating_sub(1));
    if start >= hist.entries.len() {
        return -1;
    }
    for entry in hist.entries.drain(start..=end) {
        unsafe { free_entry_box(entry) };
    }
    if hist.offset > hist.entries.len() {
        hist.offset = hist.entries.len();
    }
    hist.sync_globals();
    0
}

#[no_mangle]
pub unsafe extern "C" fn replace_history_entry(
    which: c_int,
    line: *const c_char,
    data: *mut c_void,
) -> *mut HIST_ENTRY {
    if which < 0 || line.is_null() {
        return ptr::null_mut();
    }
    let mut hist = lock_history();
    let index = which as usize;
    if index >= hist.entries.len() {
        return ptr::null_mut();
    }
    let new_entry = Box::new(HIST_ENTRY {
        line: dup_c_string(line),
        timestamp: ptr::null_mut(),
        data,
    });
    let old = std::mem::replace(&mut hist.entries[index], new_entry);
    hist.sync_globals();
    Box::into_raw(old)
}

#[no_mangle]
pub unsafe extern "C" fn free_history_entry(entry: *mut HIST_ENTRY) -> *mut c_void {
    if entry.is_null() {
        return ptr::null_mut();
    }
    let data = (*entry).data;
    free_entry_box(Box::from_raw(entry));
    data
}

#[no_mangle]
pub unsafe extern "C" fn read_history(filename: *const c_char) -> c_int {
    read_history_range(filename, 0, -1)
}

#[no_mangle]
pub extern "C" fn history_total_bytes() -> c_int {
    clamp_c_int(lock_history().total_bytes())
}

#[no_mangle]
pub unsafe extern "C" fn read_history_range(
    filename: *const c_char,
    from: c_int,
    to: c_int,
) -> c_int {
    let path = path_from_c(filename);
    let file = match fs::File::open(path) {
        Ok(file) => file,
        Err(error) => return io_error_status(error),
    };
    let start = from.max(0) as usize;
    let stop = if to < 0 {
        usize::MAX
    } else {
        (to.max(from.saturating_add(1)) as usize).saturating_sub(1)
    };
    let mut command_index = 0usize;
    let mut pending_timestamp: Option<Vec<u8>> = None;
    let mut current_timestamp: Option<Vec<u8>> = None;
    let mut current_line: Option<Vec<u8>> = None;
    let mut lines_read = 0usize;
    let multiline = history_multiline_entries != 0;
    let mut import_entry = |line: &[u8], timestamp: Option<&[u8]>| -> Result<bool, ()> {
        if command_index > stop {
            return Ok(false);
        }
        if command_index >= start {
            if !add_history_entry_bytes(line, timestamp) {
                return Err(());
            }
            lines_read += 1;
        }
        command_index += 1;
        Ok(true)
    };

    let mut reader = io::BufReader::new(file);
    let mut line = Vec::new();
    loop {
        line.clear();
        let count = match reader.read_until(b'\n', &mut line) {
            Ok(count) => count,
            Err(_) => return -1,
        };
        if count == 0 {
            break;
        }
        if line.ends_with(b"\n") {
            line.pop();
            if line.ends_with(b"\r") {
                line.pop();
            }
        }
        let bytes = line.as_slice();
        if is_history_timestamp_line(bytes) {
            if multiline {
                if let Some(entry) = current_line.take() {
                    match import_entry(&entry, current_timestamp.as_deref()) {
                        Ok(true) => {}
                        Ok(false) => break,
                        Err(()) => return -1,
                    }
                    current_timestamp = None;
                }
            }
            pending_timestamp = Some(bytes.to_vec());
            continue;
        }
        if line.is_empty() && pending_timestamp.is_none() && current_line.is_none() {
            continue;
        }
        if multiline && (pending_timestamp.is_some() || current_line.is_some()) {
            if let Some(entry) = current_line.as_mut() {
                entry.push(b'\n');
                entry.extend_from_slice(bytes);
            } else {
                current_timestamp = pending_timestamp.take();
                current_line = Some(bytes.to_vec());
            }
            continue;
        }
        let timestamp = pending_timestamp.take();
        match import_entry(bytes, timestamp.as_deref()) {
            Ok(true) => {}
            Ok(false) => break,
            Err(()) => return -1,
        }
    }
    if multiline {
        if let Some(entry) = current_line.take() {
            match import_entry(&entry, current_timestamp.as_deref()) {
                Ok(true) | Ok(false) => {}
                Err(()) => return -1,
            }
        }
    }
    history_lines_read_from_file = clamp_c_int(lines_read);
    0
}

#[no_mangle]
pub unsafe extern "C" fn write_history(filename: *const c_char) -> c_int {
    let path = path_from_c(filename);
    let hist = lock_history();
    let mut file = match fs::File::create(path) {
        Ok(file) => file,
        Err(error) => return io_error_status(error),
    };
    let mut written = 0usize;
    for entry in &hist.entries {
        match write_history_entry(&mut file, entry) {
            Ok(true) => written += 1,
            Ok(false) => {}
            Err(_) => return -1,
        }
    }
    history_lines_written_to_file = clamp_c_int(written);
    0
}

#[no_mangle]
pub unsafe extern "C" fn append_history(nelements: c_int, filename: *const c_char) -> c_int {
    let path = path_from_c(filename);
    let hist = lock_history();
    if nelements < 0 {
        history_lines_written_to_file = -1;
        return 0;
    }
    let count = nelements.max(0) as usize;
    let start = hist.entries.len().saturating_sub(count);
    let mut file = match OpenOptions::new().append(true).open(path) {
        Ok(file) => file,
        Err(error) => return io_error_status(error),
    };
    let mut written = 0usize;
    for entry in &hist.entries[start..] {
        match write_history_entry(&mut file, entry) {
            Ok(true) => written += 1,
            Ok(false) => {}
            Err(_) => return -1,
        }
    }
    history_lines_written_to_file = clamp_c_int(written);
    0
}

#[no_mangle]
pub unsafe extern "C" fn history_truncate_file(filename: *const c_char, nlines: c_int) -> c_int {
    let path = path_from_c(filename);
    let content = match fs::read(&path) {
        Ok(content) => content,
        Err(error) => return io_error_status(error),
    };
    let keep = nlines.max(0) as usize;
    let output = truncate_history_content(&content, keep, history_multiline_entries != 0);
    fs::write(path, output)
        .map(|_| 0)
        .unwrap_or_else(io_error_status)
}

fn tokenize_history_bytes(input: &[u8]) -> Vec<Vec<u8>> {
    let delimiters = unsafe {
        global_string_bytes(
            history_word_delimiters,
            &HISTORY_WORD_DELIMITERS[..HISTORY_WORD_DELIMITERS.len() - 1],
        )
    };
    let comment = unsafe { history_comment_char as u8 };
    let mut words = Vec::new();
    let mut idx = 0usize;

    while idx < input.len() {
        while idx < input.len() && input[idx].is_ascii_whitespace() {
            idx += 1;
        }
        if idx >= input.len() {
            break;
        }
        if comment != 0 && input[idx] == comment {
            break;
        }
        if delimiters.contains(&input[idx]) && !input[idx].is_ascii_whitespace() {
            let start = idx;
            while idx < input.len()
                && delimiters.contains(&input[idx])
                && !input[idx].is_ascii_whitespace()
            {
                idx += 1;
            }
            words.push(input[start..idx].to_vec());
            continue;
        }

        let mut word = Vec::new();
        let mut quote = 0u8;
        let mut escaped = false;
        while idx < input.len() {
            let byte = input[idx];
            if escaped {
                word.push(byte);
                escaped = false;
                idx += 1;
                continue;
            }
            if byte == b'\\' {
                word.push(byte);
                escaped = true;
                idx += 1;
                continue;
            }
            if quote != 0 {
                word.push(byte);
                if byte == quote {
                    quote = 0;
                }
                idx += 1;
                continue;
            }
            if byte == b'\'' || byte == b'"' {
                quote = byte;
                word.push(byte);
                idx += 1;
                continue;
            }
            if delimiters.contains(&byte) {
                if byte.is_ascii_whitespace() {
                    while idx < input.len() && input[idx].is_ascii_whitespace() {
                        idx += 1;
                    }
                }
                break;
            }
            word.push(byte);
            idx += 1;
        }
        if !word.is_empty() {
            words.push(word);
        }
    }
    words
}

unsafe fn words_to_c_array(words: &[Vec<u8>]) -> *mut *mut c_char {
    let raw = malloc((words.len() + 1) * std::mem::size_of::<*mut c_char>()) as *mut *mut c_char;
    if raw.is_null() {
        return ptr::null_mut();
    }
    for (idx, word) in words.iter().enumerate() {
        let item = dup_bytes(word);
        if item.is_null() {
            for prev in 0..idx {
                free(*raw.add(prev) as *mut c_void);
            }
            free(raw as *mut c_void);
            return ptr::null_mut();
        }
        *raw.add(idx) = item;
    }
    *raw.add(words.len()) = ptr::null_mut();
    raw
}

fn extract_history_args(line: &[u8], first: c_int, last: c_int) -> Option<Vec<u8>> {
    if first < 0 {
        return None;
    }
    let words = tokenize_history_bytes(line);
    if words.is_empty() {
        return None;
    }
    let start = first as usize;
    let end = if last < 0 {
        words.len().saturating_sub(1)
    } else {
        last as usize
    };
    if start >= words.len() || start > end {
        return None;
    }
    let mut out = Vec::new();
    for (idx, word) in words[start..=end.min(words.len() - 1)].iter().enumerate() {
        if idx > 0 {
            out.push(b' ');
        }
        out.extend_from_slice(word);
    }
    Some(out)
}

fn public_history_index(index: c_int, len: usize) -> Option<usize> {
    if index >= 0 {
        let index = index as usize;
        return (index < len).then_some(index);
    }
    let resolved = len as isize + index as isize - 1;
    (resolved >= 0).then_some(resolved as usize)
}

fn extract_public_history_args(line: &[u8], first: c_int, last: c_int) -> Option<Vec<u8>> {
    let words = tokenize_history_bytes(line);
    if words.is_empty() {
        return None;
    }
    let start = public_history_index(first, words.len())?;
    let Some(end) = public_history_index(last, words.len()) else {
        return (start == 0).then(Vec::new);
    };
    if start > end {
        return (start == end + 1).then(Vec::new);
    }
    let mut out = Vec::new();
    for (idx, word) in words[start..=end].iter().enumerate() {
        if idx > 0 {
            out.push(b' ');
        }
        out.extend_from_slice(word);
    }
    Some(out)
}

fn history_event_error(input: &[u8], bang: usize) -> Vec<u8> {
    let mut end = bang + 1;
    while end < input.len() && !input[end].is_ascii_whitespace() {
        end += 1;
    }
    let mut error = input[bang..end].to_vec();
    error.extend_from_slice(b": event not found");
    error
}

fn replace_first_bytes(input: &[u8], needle: &[u8], replacement: &[u8]) -> Option<Vec<u8>> {
    if needle.is_empty() {
        return None;
    }
    let pos = input
        .windows(needle.len())
        .position(|window| window == needle)?;
    let mut out = Vec::with_capacity(input.len() - needle.len() + replacement.len());
    out.extend_from_slice(&input[..pos]);
    out.extend_from_slice(replacement);
    out.extend_from_slice(&input[pos + needle.len()..]);
    Some(out)
}

fn replace_history_bytes(
    input: &[u8],
    needle: &[u8],
    replacement: &[u8],
    global: bool,
) -> Option<Vec<u8>> {
    if needle.is_empty() {
        return None;
    }
    let mut out = Vec::with_capacity(input.len());
    let mut idx = 0usize;
    let mut changed = false;
    while idx < input.len() {
        if input[idx..].starts_with(needle) {
            out.extend_from_slice(replacement);
            idx += needle.len();
            changed = true;
            if !global {
                out.extend_from_slice(&input[idx..]);
                return Some(out);
            }
        } else {
            out.push(input[idx]);
            idx += 1;
        }
    }
    changed.then_some(out)
}

fn remember_history_substitution(old: &[u8], new: &[u8]) {
    let mut substitution = lock_history_substitution();
    substitution.old = old.to_vec();
    substitution.new = new.to_vec();
}

fn parse_history_substitution(input: &[u8]) -> Option<(Vec<u8>, Vec<u8>, usize)> {
    let delimiter = *input.first()?;
    let mut idx = 1usize;
    let old_start = idx;
    while idx < input.len() && input[idx] != delimiter {
        idx += 1;
    }
    if idx >= input.len() {
        return None;
    }
    let old = input[old_start..idx].to_vec();
    idx += 1;
    let new_start = idx;
    while idx < input.len() && input[idx] != delimiter {
        idx += 1;
    }
    let new = input[new_start..idx.min(input.len())].to_vec();
    if idx < input.len() && input[idx] == delimiter {
        idx += 1;
    }
    Some((old, new, idx))
}

fn shell_quote_word(word: &[u8]) -> Vec<u8> {
    let mut out = Vec::with_capacity(word.len() + 2);
    out.push(b'\'');
    for &byte in word {
        if byte == b'\'' {
            out.extend_from_slice(b"'\\''");
        } else {
            out.push(byte);
        }
    }
    out.push(b'\'');
    out
}

fn shell_quote_bytes(input: &[u8], split_words: bool) -> Vec<u8> {
    if split_words {
        let words = tokenize_history_bytes(input);
        let mut out = Vec::new();
        for (idx, word) in words.iter().enumerate() {
            if idx > 0 {
                out.push(b' ');
            }
            out.extend_from_slice(&shell_quote_word(word));
        }
        out
    } else {
        shell_quote_word(input)
    }
}

fn path_head(input: &[u8]) -> Vec<u8> {
    match input.iter().rposition(|byte| *byte == b'/') {
        Some(0) => b"/".to_vec(),
        Some(pos) => input[..pos].to_vec(),
        None => input.to_vec(),
    }
}

fn path_tail(input: &[u8]) -> Vec<u8> {
    match input.iter().rposition(|byte| *byte == b'/') {
        Some(pos) => input[pos + 1..].to_vec(),
        None => input.to_vec(),
    }
}

fn path_root(input: &[u8]) -> Vec<u8> {
    let base_start = input
        .iter()
        .rposition(|byte| *byte == b'/')
        .map(|pos| pos + 1)
        .unwrap_or(0);
    match input[base_start..].iter().rposition(|byte| *byte == b'.') {
        Some(dot) => input[..base_start + dot].to_vec(),
        None => input.to_vec(),
    }
}

fn path_extension(input: &[u8]) -> Vec<u8> {
    let base_start = input
        .iter()
        .rposition(|byte| *byte == b'/')
        .map(|pos| pos + 1)
        .unwrap_or(0);
    match input[base_start..].iter().rposition(|byte| *byte == b'.') {
        Some(dot) => input[base_start + dot..].to_vec(),
        None => Vec::new(),
    }
}

fn matched_history_word(line: &[u8], needle: &[u8]) -> Option<Vec<u8>> {
    tokenize_history_bytes(line)
        .into_iter()
        .find(|word| contains_bytes(word, needle))
}

fn remember_history_match(word: &[u8]) {
    lock_editor().history_search_match = word.to_vec();
}

fn remembered_history_match() -> Option<Vec<u8>> {
    let word = lock_editor().history_search_match.clone();
    if word.is_empty() {
        None
    } else {
        Some(word)
    }
}

fn bad_word_specifier(input: &[u8], consumed: usize) -> Vec<u8> {
    let mut out = input[..consumed.min(input.len())].to_vec();
    out.extend_from_slice(b": bad word specifier");
    out
}

fn parse_history_word_designator(line: &[u8], input: &[u8]) -> (Vec<u8>, usize, Option<Vec<u8>>) {
    let has_colon = input.first() == Some(&b':');
    let designator = if has_colon { &input[1..] } else { input };
    let Some(first_byte) = designator.first().copied() else {
        return (line.to_vec(), 0, None);
    };
    let colon = usize::from(has_colon);
    match first_byte {
        b'$' => {
            let words = tokenize_history_bytes(line);
            let last = words.len().saturating_sub(1) as c_int;
            (
                extract_history_args(line, last, last).unwrap_or_else(|| line.to_vec()),
                colon + 1,
                None,
            )
        }
        b'^' => {
            if designator.starts_with(b"^-$") {
                let consumed = colon + 3;
                match extract_history_args(line, 1, -1) {
                    Some(args) => (args, consumed, None),
                    None => (
                        Vec::new(),
                        consumed,
                        Some(bad_word_specifier(input, consumed)),
                    ),
                }
            } else {
                (
                    extract_history_args(line, 1, 1).unwrap_or_else(|| line.to_vec()),
                    colon + 1,
                    None,
                )
            }
        }
        b'*' => (
            extract_history_args(line, 1, -1).unwrap_or_default(),
            colon + 1,
            None,
        ),
        b'%' => (
            remembered_history_match().unwrap_or_else(|| line.to_vec()),
            colon + 1,
            None,
        ),
        b'-' if designator.get(1).is_some_and(|byte| byte.is_ascii_digit()) => {
            let mut idx = 1usize;
            while idx < designator.len() && designator[idx].is_ascii_digit() {
                idx += 1;
            }
            let last = std::str::from_utf8(&designator[1..idx])
                .ok()
                .and_then(|value| value.parse::<c_int>().ok())
                .unwrap_or(0);
            let consumed = colon + idx;
            match extract_history_args(line, 0, last) {
                Some(args) => (args, consumed, None),
                None => (
                    Vec::new(),
                    consumed,
                    Some(bad_word_specifier(input, consumed)),
                ),
            }
        }
        byte if byte.is_ascii_digit() => {
            let mut idx = 0usize;
            while idx < designator.len() && designator[idx].is_ascii_digit() {
                idx += 1;
            }
            let first = std::str::from_utf8(&designator[..idx])
                .ok()
                .and_then(|value| value.parse::<c_int>().ok())
                .unwrap_or(0);
            let mut last = first;
            if designator.get(idx) == Some(&b'*') {
                last = -1;
                idx += 1;
            } else if designator.get(idx) == Some(&b'-') {
                idx += 1;
                let last_start = idx;
                while idx < designator.len() && designator[idx].is_ascii_digit() {
                    idx += 1;
                }
                last = if idx == last_start {
                    -2
                } else {
                    std::str::from_utf8(&designator[last_start..idx])
                        .ok()
                        .and_then(|value| value.parse::<c_int>().ok())
                        .unwrap_or(first)
                };
            }
            let words = tokenize_history_bytes(line);
            let resolved_last = if last == -2 {
                words.len().saturating_sub(2) as c_int
            } else {
                last
            };
            let consumed = colon + idx;
            match extract_history_args(line, first, resolved_last) {
                Some(args) => (args, consumed, None),
                None => (
                    Vec::new(),
                    consumed,
                    Some(bad_word_specifier(input, consumed)),
                ),
            }
        }
        _ => (line.to_vec(), 0, None),
    }
}

fn apply_history_modifiers(
    mut line: Vec<u8>,
    input: &[u8],
) -> (Vec<u8>, usize, bool, Option<Vec<u8>>) {
    let mut idx = 0usize;
    let mut print_only = false;
    while idx < input.len() {
        let start = idx;
        if input[idx] != b':' {
            break;
        }
        idx += 1;
        let mut global_substitution = false;
        if input
            .get(idx)
            .is_some_and(|byte| matches!(*byte, b'g' | b'a' | b'G'))
        {
            global_substitution = true;
            idx += 1;
        }
        let Some(modifier) = input.get(idx).copied() else {
            idx = start;
            break;
        };
        match modifier {
            b'h' => {
                line = path_head(&line);
                idx += 1;
            }
            b't' => {
                line = path_tail(&line);
                idx += 1;
            }
            b'r' => {
                line = path_root(&line);
                idx += 1;
            }
            b'e' => {
                line = path_extension(&line);
                idx += 1;
            }
            b'q' => {
                line = shell_quote_bytes(&line, false);
                idx += 1;
            }
            b'x' => {
                line = shell_quote_bytes(&line, true);
                idx += 1;
            }
            b'p' => {
                print_only = true;
                idx += 1;
            }
            b's' => {
                let Some((old, new, consumed)) = parse_history_substitution(&input[idx + 1..])
                else {
                    idx = start;
                    break;
                };
                let end = idx + 1 + consumed;
                if let Some(changed) = replace_history_bytes(&line, &old, &new, global_substitution)
                {
                    line = changed;
                    remember_history_substitution(&old, &new);
                } else {
                    let mut error = input[start..end.min(input.len())].to_vec();
                    error.extend_from_slice(b": substitution failed");
                    return (line, end, print_only, Some(error));
                }
                idx = end;
            }
            b'&' => {
                let substitution = lock_history_substitution();
                if let Some(changed) = replace_history_bytes(
                    &line,
                    &substitution.old,
                    &substitution.new,
                    global_substitution,
                ) {
                    line = changed;
                }
                idx += 1;
            }
            _ => {
                idx = start;
                break;
            }
        }
    }
    (line, idx, print_only, None)
}

fn apply_designator(line: Vec<u8>, input: &[u8]) -> (Vec<u8>, usize, bool, Option<Vec<u8>>) {
    let (line, designator_consumed, error) = parse_history_word_designator(&line, input);
    if error.is_some() {
        return (line, designator_consumed, false, error);
    }
    let (line, modifier_consumed, print_only, error) =
        apply_history_modifiers(line, &input[designator_consumed..]);
    (
        line,
        designator_consumed + modifier_consumed,
        print_only,
        error,
    )
}

fn history_secondary_hook_fragment(input: &[u8], consumed: usize) -> Vec<u8> {
    let Some(&first) = input.first() else {
        return Vec::new();
    };
    match first {
        b'-' => vec![b'-'],
        b'0'..=b'9' => input[..consumed.min(input.len())].to_vec(),
        _ => vec![first],
    }
}

unsafe fn history_expansion_hook_inhibits(prefix: &[u8], fragment: &[u8]) -> bool {
    let Some(hook) = history_inhibit_expansion_function else {
        return false;
    };
    let mut line = Vec::with_capacity(prefix.len() + 1 + fragment.len() + 1);
    line.extend_from_slice(prefix);
    line.push(history_expansion_char as u8);
    line.extend_from_slice(fragment);
    let offset = prefix.len();
    line.push(0);
    hook(line.as_mut_ptr() as *mut c_char, clamp_c_int(offset)) != 0
}

unsafe fn expand_history_event(input: &[u8]) -> Option<HistoryEventExpansion> {
    if input.is_empty() {
        return None;
    }
    let mut consumed;
    let line = match input[0] {
        b'!' => {
            consumed = 1;
            history_last_line()?
        }
        b'#' => {
            return Some((Vec::new(), 1, false, None));
        }
        b'-' => {
            let mut idx = 1;
            while idx < input.len() && input[idx].is_ascii_digit() {
                idx += 1;
            }
            if idx == 1 {
                return None;
            }
            let distance = std::str::from_utf8(&input[1..idx])
                .ok()
                .and_then(|value| value.parse::<usize>().ok())?;
            consumed = idx;
            history_relative_line(distance)?
        }
        b'0'..=b'9' => {
            let mut idx = 0;
            while idx < input.len() && input[idx].is_ascii_digit() {
                idx += 1;
            }
            let offset = std::str::from_utf8(&input[..idx])
                .ok()
                .and_then(|value| value.parse::<c_int>().ok())?;
            consumed = idx;
            history_absolute_line(offset)?
        }
        b'?' => {
            let end = input[1..]
                .iter()
                .position(|byte| *byte == b'?')
                .map(|idx| idx + 1)
                .unwrap_or(input.len());
            if end <= 1 {
                return None;
            }
            consumed = if end < input.len() { end + 1 } else { end };
            let line = history_find_substring(&input[1..end])?;
            if let Some(word) = matched_history_word(&line, &input[1..end]) {
                remember_history_match(&word);
            }
            line
        }
        b'$' | b'^' | b'*' | b':' => {
            consumed = 0;
            history_last_line()?
        }
        _ => {
            let delimiters = global_string_bytes(
                history_search_delimiter_chars,
                &HISTORY_SEARCH_DELIMITERS[..HISTORY_SEARCH_DELIMITERS.len() - 1],
            );
            let word_delimiters = global_string_bytes(
                history_word_delimiters,
                &HISTORY_WORD_DELIMITERS[..HISTORY_WORD_DELIMITERS.len() - 1],
            );
            let mut idx = 0;
            while idx < input.len()
                && !input[idx].is_ascii_whitespace()
                && !delimiters.contains(&input[idx])
                && !word_delimiters.contains(&input[idx])
                && !matches!(input[idx], b':' | b'$' | b'^' | b'*')
            {
                idx += 1;
            }
            if idx == 0 {
                return None;
            }
            consumed = idx;
            history_find_prefix(&input[..idx])?
        }
    };

    let (line, designator_consumed, print_only, error) = apply_designator(line, &input[consumed..]);
    consumed += designator_consumed;
    Some((line, consumed, print_only, error))
}

#[no_mangle]
pub unsafe extern "C" fn history_expand(string: *mut c_char, output: *mut *mut c_char) -> c_int {
    if output.is_null() {
        return -1;
    }
    *output = ptr::null_mut();
    if string.is_null() {
        *output = dup_bytes(&[]);
        return 0;
    }

    let input = CStr::from_ptr(string).to_bytes();
    if input.first() == Some(&(history_subst_char as u8)) {
        let sep = history_subst_char as u8;
        let Some(last) = history_last_line() else {
            *output = dup_bytes(b"event not found");
            return -1;
        };
        let Some(old_end) = input[1..]
            .iter()
            .position(|byte| *byte == sep)
            .map(|idx| idx + 1)
        else {
            *output = dup_bytes(input);
            return 0;
        };
        let new_start = old_end + 1;
        let new_end = input[new_start..]
            .iter()
            .position(|byte| *byte == sep)
            .map(|idx| new_start + idx)
            .unwrap_or(input.len());
        let old = &input[1..old_end];
        let new = &input[new_start..new_end];
        match replace_first_bytes(&last, old, new) {
            Some(line) => {
                remember_history_substitution(old, new);
                *output = dup_bytes(&line);
                return if (*output).is_null() { -1 } else { 1 };
            }
            None => {
                *output = dup_bytes(b"substitution failed");
                return -1;
            }
        }
    }

    let expansion = history_expansion_char as u8;
    let no_expand = global_string_bytes(
        history_no_expand_chars,
        &HISTORY_NO_EXPAND_CHARS[..HISTORY_NO_EXPAND_CHARS.len() - 1],
    );
    let comment = history_comment_char as u8;

    let mut out = Vec::with_capacity(input.len());
    let mut idx = 0usize;
    let mut changed = false;
    let mut print_only = false;
    let mut single_quote =
        history_quotes_inhibit_expansion != 0 && history_quoting_state == b'\'' as c_int;
    while idx < input.len() {
        let byte = input[idx];
        if history_quotes_inhibit_expansion != 0 && byte == b'\'' {
            single_quote = !single_quote;
            out.push(byte);
            idx += 1;
            continue;
        }
        if byte == b'\\' {
            out.push(byte);
            idx += 1;
            continue;
        }
        if comment != 0 && byte == comment && (idx == 0 || input[idx - 1].is_ascii_whitespace()) {
            out.extend_from_slice(&input[idx..]);
            break;
        }
        if byte != expansion || single_quote {
            out.push(byte);
            idx += 1;
            continue;
        }
        let mut backslashes = 0usize;
        let mut scan = idx;
        while scan > 0 && input[scan - 1] == b'\\' {
            backslashes += 1;
            scan -= 1;
        }
        if backslashes % 2 == 1 {
            out.push(byte);
            idx += 1;
            if input.get(idx) == Some(&expansion) {
                out.push(expansion);
                idx += 1;
            }
            continue;
        }
        if input
            .get(idx + 1)
            .is_some_and(|byte| no_expand.contains(byte))
        {
            out.push(byte);
            idx += 1;
            continue;
        }
        if let Some(hook) = history_inhibit_expansion_function {
            if !changed && out.as_slice() == &input[..idx] && hook(string, clamp_c_int(idx)) != 0 {
                out.push(byte);
                idx += 1;
                continue;
            }
        }
        if input.get(idx + 1) == Some(&b'#') {
            let current_line = out.clone();
            if history_expansion_hook_inhibits(&current_line, b"#") {
                out.extend_from_slice(&input[idx..idx + 2]);
                idx += 2;
                continue;
            }
            let (event, consumed, event_print_only, error) =
                apply_designator(current_line.clone(), &input[idx + 2..]);
            if let Some(error) = error {
                *output = dup_bytes(&error);
                return -1;
            }
            if consumed == 0 {
                out.extend_from_slice(&current_line);
                idx += 2;
            } else {
                out.extend_from_slice(&event);
                idx += consumed + 2;
            }
            print_only |= event_print_only;
            changed = true;
            continue;
        }
        match expand_history_event(&input[idx + 1..]) {
            Some((event, consumed, event_print_only, error)) if consumed > 0 => {
                let hook_fragment = history_secondary_hook_fragment(&input[idx + 1..], consumed);
                if history_expansion_hook_inhibits(&out, &hook_fragment) {
                    out.extend_from_slice(&input[idx..idx + 1 + consumed]);
                    idx += consumed + 1;
                    continue;
                }
                if let Some(error) = error {
                    *output = dup_bytes(&error);
                    return -1;
                }
                out.extend_from_slice(&event);
                print_only |= event_print_only;
                idx += consumed + 1;
                changed = true;
            }
            _ => {
                *output = dup_bytes(&history_event_error(input, idx));
                return -1;
            }
        }
    }

    *output = dup_bytes(&out);
    if (*output).is_null() {
        -1
    } else if print_only {
        2
    } else if changed {
        1
    } else {
        0
    }
}

#[no_mangle]
pub unsafe extern "C" fn history_tokenize(string: *const c_char) -> *mut *mut c_char {
    if string.is_null() {
        return ptr::null_mut();
    }
    let words = tokenize_history_bytes(CStr::from_ptr(string).to_bytes());
    if words.is_empty() {
        return ptr::null_mut();
    }
    words_to_c_array(&words)
}

#[no_mangle]
pub unsafe extern "C" fn history_arg_extract(
    first: c_int,
    last: c_int,
    string: *const c_char,
) -> *mut c_char {
    if string.is_null() {
        return ptr::null_mut();
    }
    extract_public_history_args(CStr::from_ptr(string).to_bytes(), first, last)
        .map_or(ptr::null_mut(), |bytes| dup_bytes(&bytes))
}

#[no_mangle]
pub unsafe extern "C" fn history_search(string: *const c_char, direction: c_int) -> c_int {
    if string.is_null() {
        return -1;
    }
    let needle = CStr::from_ptr(string).to_bytes();
    if needle.is_empty() {
        return -1;
    }
    let hist = lock_history();
    let pos = hist.offset.min(hist.entries.len().saturating_sub(1));
    drop(hist);
    history_search_impl(needle, direction, false, pos, false)
}

#[no_mangle]
pub unsafe extern "C" fn history_search_prefix(string: *const c_char, direction: c_int) -> c_int {
    if string.is_null() {
        return -1;
    }
    let needle = CStr::from_ptr(string).to_bytes();
    if needle.is_empty() {
        return -1;
    }
    let hist = lock_history();
    let pos = hist.offset.min(hist.entries.len().saturating_sub(1));
    drop(hist);
    history_search_impl(needle, direction, true, pos, false)
}

#[no_mangle]
pub unsafe extern "C" fn history_search_pos(
    string: *const c_char,
    direction: c_int,
    pos: c_int,
) -> c_int {
    if string.is_null() {
        return -1;
    }
    let needle = CStr::from_ptr(string).to_bytes();
    if needle.is_empty() {
        return -1;
    }
    let start = if pos < 0 {
        lock_history().offset
    } else {
        pos as usize
    };
    history_search_impl(needle, direction, false, start, true)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn duplicate_bytes_are_c_terminated() {
        unsafe {
            let ptr = dup_bytes(b"abc");
            assert!(!ptr.is_null());
            assert_eq!(CStr::from_ptr(ptr).to_bytes(), b"abc");
            free(ptr as *mut c_void);
        }
    }

    #[test]
    fn clamp_keeps_c_int_bounds() {
        assert_eq!(clamp_c_int(7), 7);
        assert_eq!(clamp_c_int(usize::MAX), c_int::MAX);
    }

    #[test]
    fn free_line_state_clears_transient_editor_state() {
        unsafe {
            {
                let mut editor = lock_editor();
                editor.pending_keyseq = vec![b'x'];
                editor.macro_input.push_back(b'y');
                editor.kbd_macro_recording = true;
                editor.kbd_macro_current = vec![b'z'];
                editor.undo_stack.push(UndoSnapshot {
                    line: b"old".to_vec(),
                    point: 1,
                });
                editor.undo_group_depth = 1;
                editor.undo_group_snapshot = Some(UndoSnapshot {
                    line: b"group".to_vec(),
                    point: 2,
                });
            }
            rl_explicit_arg = 1;
            rl_numeric_arg = 99;
            rl_arg_sign = -1;
            rl_free_line_state();
            let explicit_arg = rl_explicit_arg;
            let numeric_arg = rl_numeric_arg;
            let arg_sign = rl_arg_sign;
            assert_eq!(explicit_arg, 0);
            assert_eq!(numeric_arg, 1);
            assert_eq!(arg_sign, 1);

            let editor = lock_editor();
            assert!(editor.pending_keyseq.is_empty());
            assert!(editor.macro_input.is_empty());
            assert!(!editor.kbd_macro_recording);
            assert!(editor.kbd_macro_current.is_empty());
            assert!(editor.undo_stack.is_empty());
            assert_eq!(editor.undo_group_depth, 0);
            assert!(editor.undo_group_snapshot.is_none());
        }
    }

    // Callback dispatch unit tests for the 0.1.10 fix.
    //
    // These exercise rl_callback_read_char against a real pipe so the
    // unbuffered read(2) path inside callback_read_byte runs end to end.
    // They are serialized through CALLBACK_TEST_LOCK because every static
    // in the ABI module is shared mutable state.

    use std::sync::Mutex as TestMutex;

    static CALLBACK_TEST_LOCK: TestMutex<()> = TestMutex::new(());

    struct CallbackTestEnv {
        read_fd: c_int,
        write_fd: c_int,
        prev_instream: *mut c_void,
        prev_outstream: *mut c_void,
        sink: *mut c_void,
    }

    impl CallbackTestEnv {
        unsafe fn new() -> Self {
            extern "C" {
                fn pipe(fds: *mut c_int) -> c_int;
                fn fopen(path: *const c_char, mode: *const c_char) -> *mut c_void;
            }
            let mut fds: [c_int; 2] = [0; 2];
            assert_eq!(pipe(fds.as_mut_ptr()), 0, "pipe(2) failed");
            let stream = fdopen(fds[0], c"r".as_ptr());
            assert!(!stream.is_null(), "fdopen on pipe read end failed");
            // Discard any prompt-echo output to /dev/null so cargo test
            // captures don't carry interactive escape sequences.
            let sink = fopen(
                c"/dev/null".as_ptr(),
                c"w".as_ptr(),
            );
            assert!(!sink.is_null(), "fopen /dev/null failed");
            let prev_instream = rl_instream;
            let prev_outstream = rl_outstream;
            rl_instream = stream;
            rl_outstream = sink;
            Self {
                read_fd: fds[0],
                write_fd: fds[1],
                prev_instream,
                prev_outstream,
                sink,
            }
        }

        unsafe fn write(&self, data: &[u8]) {
            extern "C" {
                fn write(fd: c_int, buf: *const c_void, count: usize) -> isize;
            }
            let n = write(self.write_fd, data.as_ptr() as *const c_void, data.len());
            assert_eq!(n as usize, data.len(), "pipe write short");
        }

        unsafe fn close_write(&mut self) {
            extern "C" {
                fn close(fd: c_int) -> c_int;
            }
            if self.write_fd >= 0 {
                close(self.write_fd);
                self.write_fd = -1;
            }
        }

        unsafe fn step_once(&self) {
            // Drive a single rl_callback_read_char call. The caller is
            // responsible for only invoking this when at least one byte
            // is queued, otherwise the underlying read(2) blocks.
            rl_callback_read_char();
        }
    }

    impl Drop for CallbackTestEnv {
        fn drop(&mut self) {
            unsafe {
                extern "C" {
                    fn fclose(stream: *mut c_void) -> c_int;
                    fn close(fd: c_int) -> c_int;
                }
                rl_callback_handler_remove();
                if !rl_instream.is_null() {
                    fclose(rl_instream);
                }
                rl_instream = self.prev_instream;
                if !self.sink.is_null() {
                    fclose(self.sink);
                }
                rl_outstream = self.prev_outstream;
                if self.write_fd >= 0 {
                    close(self.write_fd);
                }
                let _ = self.read_fd; // ownership transferred to fdopen
                callback_test_reset();
            }
        }
    }

    static CALLBACK_TEST_RESULT: TestMutex<Option<Option<Vec<u8>>>> = TestMutex::new(None);

    fn callback_test_reset() {
        *CALLBACK_TEST_RESULT.lock().unwrap() = None;
        // Clear any stray editor / line-buffer state a previous test might
        // have left behind so we always install from a known baseline.
        // Tests in this module share global readline state and serialize via
        // CALLBACK_TEST_LOCK, but the underlying static buffers (saved line,
        // rl_line_buffer, history-cycle position) are not part of that lock.
        unsafe {
            {
                let mut editor = lock_editor();
                editor.saved_line = None;
            }
            set_line_buffer_bytes(b"");
            rl_point = 0;
            rl_end = 0;
            // Wipe any pending startup/pre-input hooks so an earlier test's
            // probe does not fire during the next install.
            rl_startup_hook = None;
            rl_pre_input_hook = None;
        }
    }

    extern "C" fn callback_test_handler(line: *mut c_char) {
        unsafe {
            let value = if line.is_null() {
                None
            } else {
                Some(CStr::from_ptr(line).to_bytes().to_vec())
            };
            *CALLBACK_TEST_RESULT.lock().unwrap() = Some(value);
            if !line.is_null() {
                free(line as *mut c_void);
            }
        }
    }

    #[test]
    fn callback_dispatches_complete_line_byte_by_byte() {
        let _guard = CALLBACK_TEST_LOCK.lock().unwrap();
        unsafe {
            let env = CallbackTestEnv::new();
            callback_test_reset();
            rl_callback_handler_install(
                c"u> ".as_ptr(),
                Some(callback_test_handler),
            );

            for byte in b"hi\n" {
                env.write(std::slice::from_ref(byte));
                env.step_once();
            }

            let result = CALLBACK_TEST_RESULT
                .lock()
                .unwrap()
                .clone()
                .expect("handler should fire after \\n");
            assert_eq!(result.as_deref(), Some(b"hi".as_slice()));
        }
    }

    #[test]
    fn callback_dispatches_empty_line() {
        let _guard = CALLBACK_TEST_LOCK.lock().unwrap();
        unsafe {
            let env = CallbackTestEnv::new();
            callback_test_reset();
            rl_callback_handler_install(
                c"u> ".as_ptr(),
                Some(callback_test_handler),
            );
            env.write(b"\n");
            env.step_once();
            let result = CALLBACK_TEST_RESULT
                .lock()
                .unwrap()
                .clone()
                .expect("handler should fire on bare newline");
            assert_eq!(result.as_deref(), Some(b"".as_slice()));
        }
    }

    #[test]
    fn callback_dispatches_eof_as_null() {
        let _guard = CALLBACK_TEST_LOCK.lock().unwrap();
        unsafe {
            let mut env = CallbackTestEnv::new();
            callback_test_reset();
            rl_callback_handler_install(
                c"u> ".as_ptr(),
                Some(callback_test_handler),
            );
            env.close_write();
            env.step_once();
            let result = CALLBACK_TEST_RESULT
                .lock()
                .unwrap()
                .clone()
                .expect("handler should fire on EOF");
            assert!(result.is_none(), "EOF should surface as None line");
        }
    }

    // 0.1.11 fix #1: rl_last_func must reflect the *previous* command at the
    // moment a bound function runs.  If we update rl_last_func BEFORE
    // dispatching, the function-under-test sees itself as the prior command
    // and any "same key twice" branch fires spuriously.  rl_complete's
    // tab-mode classification is the canonical example: a single Tab should
    // run the LCD path, not the "list all" path.
    static LAST_FUNC_TEST_OBSERVED: TestMutex<Option<rl_command_func_t>> = TestMutex::new(None);

    extern "C" fn last_func_test_probe(_count: c_int, _key: c_int) -> c_int {
        unsafe {
            *LAST_FUNC_TEST_OBSERVED.lock().unwrap() = Some(rl_last_func);
        }
        0
    }

    #[test]
    fn dispatch_sees_previous_rl_last_func_during_command() {
        let _guard = CALLBACK_TEST_LOCK.lock().unwrap();
        unsafe {
            // Reset to a clean baseline so the probe sees None on entry.
            rl_last_func = None;
            ensure_builtin_keymap();
            let probe: extern "C" fn(c_int, c_int) -> c_int = last_func_test_probe;
            // Bind a chord (single byte 0x06 ^F is plenty) to our probe via
            // the keyseq map so dispatch_bound_key actually runs.
            if let Some(keymap) = keymap_data_mut(emacs_standard_keymap) {
                keymap
                    .keyseq_bindings
                    .retain(|(seq, _)| seq != &vec![0x06]);
                keymap.keyseq_bindings.push((vec![0x06], Some(probe)));
                rebuild_keyseq_index(keymap);
            }
            *LAST_FUNC_TEST_OBSERVED.lock().unwrap() = None;
            let mut line = Vec::new();
            let mut point = 0usize;
            assert!(dispatch_bound_key(&mut line, &mut point, 0x06));
            let observed = *LAST_FUNC_TEST_OBSERVED.lock().unwrap();
            assert!(observed.is_some(), "probe should have observed something");
            let observed = observed.unwrap();
            // The probe should *not* have seen itself: rl_last_func must
            // reflect the previous command (None on this clean baseline).
            assert!(
                observed.is_none(),
                "rl_last_func should remain at the prior command (None) while the new one is running"
            );
            // After the dispatch, rl_last_func should now be the probe.
            // Read the raw pointer rather than borrowing the static directly
            // to avoid Rust 2024 static_mut_refs lints.
            let last_func_after =
                std::ptr::addr_of!(rl_last_func).read();
            assert!(last_func_after.is_some());
            // Clean the binding back out so subsequent tests aren't polluted.
            if let Some(keymap) = keymap_data_mut(emacs_standard_keymap) {
                keymap
                    .keyseq_bindings
                    .retain(|(seq, _)| seq != &vec![0x06]);
                rebuild_keyseq_index(keymap);
            }
            rl_last_func = None;
        }
    }

    // 0.1.11 fix #2: rl_callback_handler_install must invoke
    // rl_startup_hook and rl_pre_input_hook to match readline() entry
    // semantics.  CPython 3.15's test_readline.test_nonascii drives input()
    // via the callback API and sets rl_pre_input_hook to inject text into
    // the line buffer; if the install path skips the hook the injected text
    // never appears.
    static PRE_INPUT_TEST_FIRED: TestMutex<bool> = TestMutex::new(false);
    static STARTUP_TEST_FIRED: TestMutex<bool> = TestMutex::new(false);

    extern "C" fn pre_input_test_probe() -> c_int {
        unsafe {
            *PRE_INPUT_TEST_FIRED.lock().unwrap() = true;
            // Insert "X" so we can also verify the buffer-sync path.
            let _ = rl_insert_text(c"X".as_ptr());
        }
        0
    }

    extern "C" fn startup_test_probe() -> c_int {
        *STARTUP_TEST_FIRED.lock().unwrap() = true;
        0
    }

    #[test]
    fn callback_install_fires_startup_and_pre_input_hooks() {
        let _guard = CALLBACK_TEST_LOCK.lock().unwrap();
        unsafe {
            let env = CallbackTestEnv::new();
            callback_test_reset();
            *PRE_INPUT_TEST_FIRED.lock().unwrap() = false;
            *STARTUP_TEST_FIRED.lock().unwrap() = false;

            let prev_startup = rl_startup_hook;
            let prev_pre_input = rl_pre_input_hook;
            rl_startup_hook = Some(startup_test_probe);
            rl_pre_input_hook = Some(pre_input_test_probe);

            rl_callback_handler_install(
                c"u> ".as_ptr(),
                Some(callback_test_handler),
            );

            assert!(
                *STARTUP_TEST_FIRED.lock().unwrap(),
                "rl_startup_hook must fire on callback install"
            );
            assert!(
                *PRE_INPUT_TEST_FIRED.lock().unwrap(),
                "rl_pre_input_hook must fire on callback install"
            );

            // The pre-input hook injected "X"; the callback line buffer
            // should reflect that so the user types into a non-empty line.
            env.write(b"\n");
            env.step_once();
            let result = CALLBACK_TEST_RESULT
                .lock()
                .unwrap()
                .clone()
                .expect("handler should fire on newline");
            assert_eq!(
                result.as_deref(),
                Some(b"X".as_slice()),
                "pre-input hook insertion must persist into the callback buffer"
            );

            rl_startup_hook = prev_startup;
            rl_pre_input_hook = prev_pre_input;
        }
    }

    // 0.1.11 fix #3: the default emacs keymap must bind the multi-byte
    // arrow / Home / End / Delete / PgUp / PgDn escape sequences (plus
    // every standard emacs control-key), so an interactive REPL can use
    // them without sourcing a custom inputrc.  Probe a representative
    // sample after ensure_builtin_keymap() runs.
    #[test]
    fn default_emacs_keymap_binds_arrows_and_emacs_chords() {
        // Serialise against any other test that mutates the shared emacs
        // keymap (dispatch_sees_previous_rl_last_func_during_command in
        // particular pushes a transient binding).
        let _guard = CALLBACK_TEST_LOCK.lock().unwrap();
        unsafe {
            ensure_builtin_keymap();
            let keymap = keymap_data(emacs_standard_keymap)
                .expect("emacs keymap must be registered");

            // Ctrl-A is the canonical "did anything happen here?"
            // single-byte binding.  rl_beg_of_line is the expected target.
            let ctrl_a = keymap.key_bindings[0x01]
                .expect("Ctrl-A must be bound in the default emacs keymap");
            assert_eq!(
                ctrl_a as *const () as usize,
                rl_beg_of_line as *const () as usize,
                "Ctrl-A should be bound to beginning-of-line"
            );

            // Arrow-Up via CSI must dispatch to previous-history.
            let arrow_up = keymap
                .keyseq_bindings
                .iter()
                .find(|(seq, _)| seq.as_slice() == b"\x1b[A")
                .and_then(|(_, func)| *func)
                .expect("ESC[A (arrow up) must be bound");
            assert_eq!(
                arrow_up as *const () as usize,
                rl_get_previous_history as *const () as usize,
                "ESC[A should be bound to previous-history"
            );

            // Arrow-Down via SS3 — alternate encoding terminals send.
            let arrow_down_ss3 = keymap
                .keyseq_bindings
                .iter()
                .find(|(seq, _)| seq.as_slice() == b"\x1bOB")
                .and_then(|(_, func)| *func)
                .expect("ESC OB (arrow down, SS3) must be bound");
            assert_eq!(
                arrow_down_ss3 as *const () as usize,
                rl_get_next_history as *const () as usize,
                "ESC OB should be bound to next-history"
            );

            // Meta-f → forward-word.
            let meta_f = keymap
                .keyseq_bindings
                .iter()
                .find(|(seq, _)| seq.as_slice() == b"\x1bf")
                .and_then(|(_, func)| *func)
                .expect("Meta-f must be bound");
            assert_eq!(
                meta_f as *const () as usize,
                rl_forward_word as *const () as usize,
                "Meta-f should be bound to forward-word"
            );
        }
    }

    // 0.1.11 fix #4: using_history() must park the history cursor at
    // the past-the-last-entry position so the next previous_history()
    // returns the most-recent line.  CPython calls using_history() on
    // every input() — that's how interactive Up-arrow recall is wired.
    // add_history() itself must NOT move the cursor (history_basic C
    // simulation pins that invariant).
    #[test]
    fn using_history_resets_cursor_for_recall() {
        // Serialise against any other test that mutates global history.
        let _guard = CALLBACK_TEST_LOCK.lock().unwrap();
        unsafe {
            clear_history();
            let line_a = std::ffi::CString::new("alpha").unwrap();
            let line_b = std::ffi::CString::new("beta").unwrap();
            add_history(line_a.as_ptr());
            add_history(line_b.as_ptr());
            assert_eq!(
                lock_history().offset,
                0,
                "add_history must not move the cursor"
            );

            using_history();
            assert_eq!(
                lock_history().offset,
                2,
                "using_history must park the cursor one past the most-recent entry"
            );

            let retrieved = history_previous_line()
                .expect("previous_history must surface a history entry");
            assert_eq!(retrieved.as_slice(), b"beta");

            clear_history();
        }
    }
}
