{%
    include-markdown "../../CONTRIBUTING.md"
%}
