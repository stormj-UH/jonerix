# m4oxide

Clean-room Rust implementation of `m4` for jonerix.

The implementation is developed from public documentation, black-box behavior
of compiled `m4` binaries, Ghidra/disassembly observations, and test suites.
GNU m4 implementation source code is not used.

## Compatibility Mode

Set `m4oxide_test_mode=TRUE` to make diagnostics and identity strings target
GNU m4 compatibility for oracle tests.

```sh
m4oxide_test_mode=TRUE cargo test
```

## Testing

Local tests include Rust unit tests and black-box oracle tests. If `M4_ORACLE`
is set, tests compare stdout, stderr, and exit status against that binary.

```sh
M4_ORACLE=/opt/homebrew/opt/m4/bin/m4 cargo test
cargo build
./tools/oracle_sweep.py
```

Current upstream GNU m4 1.4.21 check-suite status: the implementation passes
the custom oracle sweep and 248/248 extracted upstream check inputs. No known
failures remain in the extracted upstream check inputs; broader m4
compatibility should still be tested against additional real-world workloads.

Upstream GNU m4 check inputs can be downloaded into `cleanroom/private/`, which
is intentionally ignored by git:

```sh
mkdir -p cleanroom/private/upstream
cd cleanroom/private/upstream
curl -fsSLO https://ftp.gnu.org/gnu/m4/m4-1.4.21.tar.xz
mkdir -p m4-1.4.21-checks
tar -xf m4-1.4.21.tar.xz -C m4-1.4.21-checks --strip-components=1 \
  m4-1.4.21/checks m4-1.4.21/examples
cd ../../..
./tools/run_upstream_checks.py cleanroom/private/upstream/m4-1.4.21-checks/checks
```

Do not extract or inspect GNU m4 implementation source files.
