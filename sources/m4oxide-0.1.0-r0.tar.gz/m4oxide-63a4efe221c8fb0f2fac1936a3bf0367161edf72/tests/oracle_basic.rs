use std::io::Write;
use std::process::{Command, Stdio};

fn run_bin(bin: &str, input: &[u8]) -> (i32, Vec<u8>, Vec<u8>) {
    let mut child = Command::new(bin)
        .env("m4oxide_test_mode", "TRUE")
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn()
        .unwrap_or_else(|e| panic!("spawn {bin}: {e}"));
    child.stdin.as_mut().unwrap().write_all(input).unwrap();
    let out = child.wait_with_output().unwrap();
    (out.status.code().unwrap_or(127), out.stdout, out.stderr)
}

fn oracle() -> String {
    std::env::var("M4_ORACLE").unwrap_or_else(|_| "/opt/homebrew/opt/m4/bin/m4".to_string())
}

fn assert_gnu(input: &[u8]) {
    let oracle = oracle();
    if !std::path::Path::new(&oracle).exists() {
        eprintln!("skipping oracle test; {oracle} not found");
        return;
    }
    let ours = env!("CARGO_BIN_EXE_m4oxide");
    let expected = run_bin(&oracle, input);
    let actual = run_bin(ours, input);
    assert_eq!(actual, expected, "input: {}", String::from_utf8_lossy(input));
}

#[test]
fn basic_macro_expansion_matches_gnu() {
    assert_gnu(b"define(`x', `hello')x\n");
    assert_gnu(b"define(`wrap', `<$1,$2>')wrap(`a', `bc')\n");
    assert_gnu(b"ifdef(`define', `yes', `no')\n");
}

#[test]
fn string_builtins_match_gnu() {
    assert_gnu(b"len(`abcdef')\n");
    assert_gnu(b"index(`abcdef', `cd')\n");
    assert_gnu(b"substr(`abcdef', `2', `3')\n");
    assert_gnu(b"translit(`abcdef', `ace', `ACE')\n");
}

#[test]
fn arithmetic_matches_gnu() {
    assert_gnu(b"eval(`1 + 2 * 3')\n");
    assert_gnu(b"incr(`41') decr(`41')\n");
}
