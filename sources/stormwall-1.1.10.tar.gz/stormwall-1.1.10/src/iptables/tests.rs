// (c) 2026 Jon-Erik G. Storm, Inc., a California Corporation,
// doing business as LAVA GOAT SOFTWARE.  MIT license.
//
// Integration tests for the iptables shim.
//
// These exercise the parser → lowerer → nft-text path end-to-end,
// asserting on the textual nft commands the lowerer emits. No kernel
// or netlink socket is touched, so they run on any host with a Rust
// toolchain — no #[ignore], no #[cfg(target_os = "linux")] gate.
//
// A separate set of "kernel-real" integration tests lives in the
// `tests/iptables-shim.sh` shell harness; those are gated on Linux +
// CAP_NET_ADMIN and only run from the package CI runner.

use super::cmd::*;
use super::lower::lower;
use super::parser::parse;
use super::save::{parse_restore_stream, render_rule_save};

fn lower_argv(family: Family, args: &[&str]) -> Vec<String> {
    let argv: Vec<String> = args.iter().map(|s| s.to_string()).collect();
    let cmd = parse(family, &argv).unwrap().cmd;
    lower(&cmd).unwrap().lines.into_iter().map(|l| l.0).collect()
}

fn last_rule(family: Family, args: &[&str]) -> String {
    lower_argv(family, args).into_iter().last().unwrap()
}

// ── 1. iptables_basic_append ─────────────────────────────────────────

#[test]
fn iptables_basic_append() {
    // iptables -A FORWARD -j ACCEPT
    //   → add rule ip filter forward accept
    let lines = lower_argv(Family::Ip, &["-A", "FORWARD", "-j", "ACCEPT"]);
    assert!(lines.iter().any(|l| l == "add rule ip filter forward accept"),
        "lines: {:?}", lines);
    // Plus the implicit table+chain preamble.
    assert!(lines.iter().any(|l| l.starts_with("add table ip filter")));
    assert!(lines.iter().any(|l| l.contains("hook forward") && l.contains("policy accept")));
}

// ── 2. iptables_with_match ───────────────────────────────────────────

#[test]
fn iptables_with_match() {
    // iptables -A FORWARD -p tcp --dport 22 -j ACCEPT
    //   → add rule ip filter forward tcp dport 22 accept
    let rule = last_rule(Family::Ip, &[
        "-A", "FORWARD", "-p", "tcp", "--dport", "22", "-j", "ACCEPT",
    ]);
    assert!(rule.contains("tcp dport 22"), "rule: {}", rule);
    assert!(rule.ends_with("accept"), "rule: {}", rule);
}

// ── 3. iptables_nat_masquerade — Docker first-start sequence ─────────

#[test]
fn iptables_nat_masquerade() {
    // iptables -t nat -N DOCKER
    let r = lower_argv(Family::Ip, &["-t", "nat", "-N", "DOCKER"]);
    assert!(r.iter().any(|l| l == "add chain ip nat DOCKER"), "{:?}", r);

    // iptables -t nat -A POSTROUTING -s 172.17.0.0/16 ! -o docker0 -j MASQUERADE
    let rule = last_rule(Family::Ip, &[
        "-t", "nat", "-A", "POSTROUTING",
        "-s", "172.17.0.0/16", "!", "-o", "docker0",
        "-j", "MASQUERADE",
    ]);
    assert!(rule.contains("ip saddr 172.17.0.0/16"), "rule: {}", rule);
    assert!(rule.contains("oifname != \"docker0\""), "rule: {}", rule);
    assert!(rule.contains("masquerade"), "rule: {}", rule);

    // iptables -t nat -A PREROUTING -m addrtype --dst-type LOCAL -j DOCKER
    let rule = last_rule(Family::Ip, &[
        "-t", "nat", "-A", "PREROUTING",
        "-m", "addrtype", "--dst-type", "LOCAL",
        "-j", "DOCKER",
    ]);
    assert!(rule.contains("fib daddr type local"), "rule: {}", rule);
    assert!(rule.contains("jump DOCKER"), "rule: {}", rule);
}

// ── 4. iptables_dnat_port_publish — Docker -p 8080:80 case ───────────

#[test]
fn iptables_dnat_port_publish() {
    // iptables -t nat -A DOCKER ! -i docker0 -p tcp --dport 8080
    //          -j DNAT --to-destination 172.17.0.2:80
    //
    // Note: this uses a USER chain (DOCKER). Since 1.1.2 the lowerer
    // emits a bare `add chain` preamble for user chains as well, so
    // `-A` is safe whether the caller did `-N` first or not — `add
    // chain` is idempotent in nft. We verify both pieces below.
    let create_lines = lower_argv(Family::Ip, &["-t", "nat", "-N", "DOCKER"]);
    assert!(create_lines.iter().any(|l| l == "add chain ip nat DOCKER"));

    // Now the rule itself.
    let rule = last_rule(Family::Ip, &[
        "-t", "nat", "-A", "DOCKER",
        "!", "-i", "docker0",
        "-p", "tcp", "--dport", "8080",
        "-j", "DNAT", "--to-destination", "172.17.0.2:80",
    ]);
    assert!(rule.contains("iifname != \"docker0\""), "rule: {}", rule);
    assert!(rule.contains("tcp dport 8080"), "rule: {}", rule);
    assert!(rule.contains("dnat to 172.17.0.2:80"), "rule: {}", rule);
}

// ── 5. iptables_save_round_trip ──────────────────────────────────────

#[test]
fn iptables_save_round_trip() {
    // Build a small ruleset, dump via iptables-save format, parse
    // back, verify every rule survives the round-trip semantically.
    let inputs: &[&[&str]] = &[
        &["-A", "INPUT", "-p", "tcp", "--dport", "22", "-j", "ACCEPT"],
        &["-A", "FORWARD", "-m", "conntrack", "--ctstate", "RELATED,ESTABLISHED", "-j", "ACCEPT"],
        &["-t", "nat", "-A", "POSTROUTING", "-s", "172.17.0.0/16", "-j", "MASQUERADE"],
    ];
    let mut save_text = String::from("# Generated by stormwall iptables-save\n");
    let mut tables: std::collections::BTreeMap<&str, Vec<&'static [&'static str]>> =
        std::collections::BTreeMap::new();
    for spec in inputs {
        let table = if spec.iter().any(|t| *t == "-t") {
            spec[spec.iter().position(|t| *t == "-t").unwrap() + 1]
        } else { "filter" };
        tables.entry(table).or_default().push(*spec);
    }
    for (table, specs) in &tables {
        save_text.push_str(&format!("*{}\n", table));
        save_text.push_str(":INPUT ACCEPT [0:0]\n");
        save_text.push_str(":FORWARD ACCEPT [0:0]\n");
        save_text.push_str(":OUTPUT ACCEPT [0:0]\n");
        if *table == "nat" {
            save_text.push_str(":PREROUTING ACCEPT [0:0]\n");
            save_text.push_str(":POSTROUTING ACCEPT [0:0]\n");
        }
        for spec in specs {
            // Build a one-shot IptCmd to render in save format.
            let mut argv: Vec<String> = spec.iter().map(|s| s.to_string()).collect();
            // Drop the "-t TABLE" prefix because render_rule_save
            // doesn't include it (the *table line above scopes it).
            if argv.first().map(|s| s.as_str()) == Some("-t") {
                argv.drain(0..2);
            }
            let cmd = parse(Family::Ip, &argv).unwrap().cmd;
            save_text.push_str(&render_rule_save(&cmd));
            save_text.push('\n');
        }
        save_text.push_str("COMMIT\n");
    }

    // Round-trip: parse the save text and compare rule count / chain set.
    let stream = parse_restore_stream(Family::Ip, &save_text).unwrap();
    let total_rules: usize = stream.tables.iter().map(|t| t.rules.len()).sum();
    assert_eq!(total_rules, inputs.len(),
        "round-trip lost rules: {}", save_text);

    // Each parsed rule should re-lower cleanly.
    for t in &stream.tables {
        for r in &t.rules {
            let _ = lower(&r.cmd).expect("re-lower failed");
        }
    }
}

// ── 6. iptables_user_chain_lifecycle ─────────────────────────────────

#[test]
fn iptables_user_chain_lifecycle() {
    // -N DOCKER creates the user chain.
    let r = lower_argv(Family::Ip, &["-N", "DOCKER"]);
    assert!(r.iter().any(|l| l == "add chain ip filter DOCKER"));

    // -A DOCKER -j RETURN appends a rule to it.
    let rule = last_rule(Family::Ip, &["-A", "DOCKER", "-j", "RETURN"]);
    assert!(rule.contains("return"), "rule: {}", rule);

    // -X DOCKER deletes the user chain.
    let r = lower_argv(Family::Ip, &["-X", "DOCKER"]);
    assert!(r.iter().any(|l| l == "delete chain ip filter DOCKER"), "{:?}", r);
}

// ── 6b. iptables_user_chain_auto_create_on_append ────────────────────
//
// Regression: dockerd's libnetwork bridge driver issues `-A` against
// user chains it expects to already exist (DOCKER-USER, isolation
// chains, per-network DOCKER-FOOBAR sub-chains) without always doing
// `-N` first in the same invocation. The lowerer used to emit only
// `add table` for those calls, leaving the rule add to fail with
// ENOENT, which dockerd surfaces as "iptables: No such file or
// directory" and then aborts bridge bring-up. Since 1.1.2 we emit a
// bare `add chain` preamble for user chains too — it's idempotent in
// nft (no-op if the chain exists) so callers that did `-N` first are
// unaffected.
#[test]
fn iptables_user_chain_auto_create_on_append() {
    let lines = lower_argv(
        Family::Ip,
        &["-A", "DOCKER-USER", "-j", "ACCEPT"],
    );
    // Preamble must contain both the table and the chain creation.
    assert!(
        lines.iter().any(|l| l == "add table ip filter"),
        "missing add table: {:?}", lines,
    );
    assert!(
        lines.iter().any(|l| l == "add chain ip filter DOCKER-USER"),
        "missing user-chain auto-create: {:?}", lines,
    );
    // Built-in chain creation has braces and a hook; user-chain
    // creation must NOT — otherwise nft refuses with "Could not
    // process rule: Operation not supported" because user chains
    // don't take a hook spec.
    let chain_line = lines
        .iter()
        .find(|l| l.starts_with("add chain ip filter DOCKER-USER"))
        .unwrap();
    assert!(!chain_line.contains('{'), "user chain emitted with hook: {}", chain_line);
    // And the rule itself still lands.
    assert!(
        lines.iter().any(|l| l == "add rule ip filter DOCKER-USER accept"),
        "missing rule: {:?}", lines,
    );
}

// ── 6b2. iptables_jump_target_user_chain_auto_create ─────────────────
//
// Regression for the dockerd bridge bring-up sequence. After dockerd
// flushes + deletes its DOCKER user chain in cleanup, it issues
//
//     iptables -I FORWARD -o docker0 -j DOCKER
//
// against an existing built-in (FORWARD) but jumps to a user chain
// (DOCKER) it never recreated. nft refuses with ENOENT because the
// jump target doesn't exist; stormwall used to surface that as
// "iptables: No such file or directory" and dockerd treats that as
// fatal, aborting bridge bring-up.
//
// 1.1.3 emits a bare `add chain` for the JUMP target as well, so the
// rule add lands cleanly. Real iptables would error here ("No
// chain/target/match by that name"), but auto-creation is consistent
// with how we already handle `-A USERCHAIN` and is what dockerd needs.
#[test]
fn iptables_jump_target_user_chain_auto_create() {
    let lines = lower_argv(
        Family::Ip,
        &["-I", "FORWARD", "-o", "docker0", "-j", "DOCKER"],
    );
    // Both the operating chain (built-in FORWARD with hook) and the
    // jump target (user chain DOCKER, bare) must be in the preamble.
    let forward_line = lines
        .iter()
        .find(|l| l.starts_with("add chain ip filter forward"))
        .unwrap_or_else(|| panic!("no FORWARD preamble: {:?}", lines));
    assert!(forward_line.contains("type filter hook forward"),
        "expected FORWARD hook spec: {}", forward_line);
    assert!(
        lines.iter().any(|l| l == "add chain ip filter DOCKER"),
        "missing jump-target auto-create for DOCKER: {:?}", lines,
    );
    // And the rule itself.
    assert!(
        lines.iter().any(|l| l.contains("insert rule ip filter forward")
                          && l.contains("oifname \"docker0\"")
                          && l.contains("jump DOCKER")),
        "missing insert rule: {:?}", lines,
    );
}

// ── 6b3. iptables_jump_target_builtin_skips_extra_preamble ───────────
//
// Sanity: a `-j` to a built-in chain name (rare but legal) must NOT
// emit a bare `add chain` for that built-in. The hook-bearing preamble
// for the operating chain is the only one we want.
#[test]
fn iptables_jump_target_builtin_skips_extra_preamble() {
    let lines = lower_argv(
        Family::Ip,
        &["-A", "FORWARD", "-j", "INPUT"],
    );
    let bare_input = lines.iter()
        .filter(|l| l.starts_with("add chain ip filter input") && !l.contains('{'))
        .count();
    assert_eq!(bare_input, 0,
        "must not emit bare add chain for built-in jump target: {:?}", lines);
}

// ── 7c. New target/match coverage (1.1.5 surface expansion) ──────────
//
// Each of these covers an iptables flag/target/match-module that was
// either silently dropped or treated as an unknown user chain in
// previous revisions. The lower-side text assertions below match the
// canonical nft form documented at wiki.nftables.org / man nft.

#[test]
fn iptables_rename_chain() {
    // -E OLD NEW lowers to the nft `rename chain` primitive.
    let lines = lower_argv(Family::Ip, &["-E", "OLD-CHAIN", "NEW-CHAIN"]);
    assert!(
        lines.iter().any(|l| l == "rename chain ip filter OLD-CHAIN NEW-CHAIN"),
        "missing rename: {:?}", lines,
    );
}

#[test]
fn iptables_random_fully_masquerade() {
    let rule = last_rule(Family::Ip, &[
        "-t", "nat", "-A", "POSTROUTING", "-o", "eth0",
        "-j", "MASQUERADE", "--random-fully",
    ]);
    assert!(rule.contains("masquerade"), "{}", rule);
    assert!(rule.contains("fully-random"),
        "expected fully-random flag: {}", rule);
}

#[test]
fn iptables_random_fully_snat() {
    let rule = last_rule(Family::Ip, &[
        "-t", "nat", "-A", "POSTROUTING",
        "-j", "SNAT", "--to-source", "1.2.3.4", "--random-fully",
    ]);
    assert!(rule.contains("snat to 1.2.3.4"), "{}", rule);
    assert!(rule.contains("fully-random"),
        "expected fully-random flag: {}", rule);
}

#[test]
fn iptables_iprange_match() {
    let rule = last_rule(Family::Ip, &[
        "-A", "FORWARD", "-m", "iprange",
        "--src-range", "10.0.0.1-10.0.0.100",
        "-j", "ACCEPT",
    ]);
    assert!(rule.contains("ip saddr 10.0.0.1-10.0.0.100"),
        "expected iprange src clause: {}", rule);
}

#[test]
fn iptables_iprange_combined() {
    // Single -m iprange with both --src-range and --dst-range folds
    // into one MatchModule::Iprange.
    let rule = last_rule(Family::Ip, &[
        "-A", "FORWARD", "-m", "iprange",
        "--src-range", "10.0.0.1-10.0.0.100",
        "--dst-range", "192.168.0.1-192.168.0.50",
        "-j", "ACCEPT",
    ]);
    assert!(rule.contains("ip saddr 10.0.0.1-10.0.0.100"), "{}", rule);
    assert!(rule.contains("ip daddr 192.168.0.1-192.168.0.50"), "{}", rule);
}

#[test]
fn iptables_length_match() {
    let single = last_rule(Family::Ip, &[
        "-A", "INPUT", "-m", "length", "--length", "100", "-j", "ACCEPT",
    ]);
    assert!(single.contains("meta length 100"), "{}", single);

    let range = last_rule(Family::Ip, &[
        "-A", "INPUT", "-m", "length", "--length", "200:500", "-j", "ACCEPT",
    ]);
    assert!(range.contains("meta length 200-500"), "{}", range);
}

#[test]
fn iptables_pkttype_match() {
    let rule = last_rule(Family::Ip, &[
        "-A", "INPUT", "-m", "pkttype", "--pkt-type", "broadcast",
        "-j", "DROP",
    ]);
    assert!(rule.contains("meta pkttype broadcast"), "{}", rule);
}

#[test]
fn iptables_connmark_match_distinct_from_mark() {
    // -m connmark --mark X must lower to ct mark (not meta mark).
    let rule = last_rule(Family::Ip, &[
        "-A", "INPUT", "-m", "connmark", "--mark", "0x10",
        "-j", "ACCEPT",
    ]);
    assert!(rule.contains("ct mark 0x10"),
        "expected ct mark: {}", rule);
    assert!(!rule.contains("meta mark 0x10"),
        "must not emit meta mark for connmark match: {}", rule);

    // -m mark --mark X stays as meta mark.
    let rule = last_rule(Family::Ip, &[
        "-A", "INPUT", "-m", "mark", "--mark", "0x10",
        "-j", "ACCEPT",
    ]);
    // Existing -m mark lowering uses the `==` operator form
    // (`meta mark == 0x10`); -m connmark uses bare `ct mark 0x10`.
    // Both are valid nft.
    assert!(rule.contains("meta mark"),
        "expected meta mark: {}", rule);
    assert!(rule.contains("0x10"),
        "expected mark value: {}", rule);
}

#[test]
fn iptables_connmark_restore_mark_with_masks() {
    // Tailscale's healthcheck rule: `-j CONNMARK --restore-mark
    // --nfmask 0xff0000 --ctmask 0xff0000`.  1.1.6 rejected the
    // `--nfmask` flag as unknown ("iptables: unknown flag: --nfmask"),
    // breaking `tailscale up`.  1.1.7 parses both masks and emits the
    // masked nft form `meta mark set ct mark and 0xff0000`.
    let rule = last_rule(Family::Ip, &[
        "-t", "mangle", "-I", "PREROUTING", "1",
        "-m", "conntrack", "--ctstate", "RELATED,ESTABLISHED",
        "-j", "CONNMARK", "--restore-mark",
        "--nfmask", "0xff0000", "--ctmask", "0xff0000",
    ]);
    assert!(rule.contains("meta mark set ct mark and 0xff0000"),
        "rule should mask connmark restore: {}", rule);
}

#[test]
fn iptables_connmark_save_mark_with_masks() {
    // Symmetric of restore-mark — sets ct mark from packet mark
    // through the mask. ctmask wins when both are set (same value
    // in this test, so trivially).
    let rule = last_rule(Family::Ip, &[
        "-t", "mangle", "-A", "POSTROUTING",
        "-j", "CONNMARK", "--save-mark",
        "--nfmask", "0xff0000", "--ctmask", "0xff0000",
    ]);
    assert!(rule.contains("ct mark set meta mark and 0xff0000"),
        "rule should mask connmark save: {}", rule);
}

#[test]
fn iptables_connmark_restore_mark_no_masks_unchanged() {
    // Without --nfmask/--ctmask, the existing simple form stays.
    let rule = last_rule(Family::Ip, &[
        "-t", "mangle", "-A", "PREROUTING",
        "-j", "CONNMARK", "--restore-mark",
    ]);
    assert!(rule.contains("meta mark set ct mark"),
        "rule should preserve simple restore: {}", rule);
    assert!(!rule.contains(" and "),
        "must not have stray mask: {}", rule);
}

#[test]
fn iptables_notrack_target() {
    let rule = last_rule(Family::Ip, &[
        "-t", "raw", "-A", "PREROUTING", "-p", "udp",
        "-j", "NOTRACK",
    ]);
    assert!(rule.ends_with("notrack"),
        "expected notrack verdict: {}", rule);
}

#[test]
fn iptables_nfqueue_target() {
    let single = last_rule(Family::Ip, &[
        "-A", "INPUT", "-j", "NFQUEUE", "--queue-num", "5",
    ]);
    assert!(single.contains("queue num 5"), "{}", single);

    let bypass = last_rule(Family::Ip, &[
        "-A", "INPUT", "-j", "NFQUEUE", "--queue-num", "10", "--queue-bypass",
    ]);
    assert!(bypass.contains("queue num 10"), "{}", bypass);
    assert!(bypass.contains("bypass"), "{}", bypass);

    let balance = last_rule(Family::Ip, &[
        "-A", "INPUT", "-j", "NFQUEUE", "--queue-balance", "0:3",
    ]);
    assert!(balance.contains("queue num 0-3"), "{}", balance);
}

#[test]
fn iptables_tcpmss_target_clamp() {
    let rule = last_rule(Family::Ip, &[
        "-t", "mangle", "-A", "FORWARD", "-p", "tcp", "--tcp-flags",
        "SYN,RST", "SYN", "-j", "TCPMSS", "--clamp-mss-to-pmtu",
    ]);
    assert!(rule.contains("tcp option maxseg size set rt mtu"),
        "expected clamp-to-pmtu lowering: {}", rule);
}

#[test]
fn iptables_tcpmss_target_set_explicit() {
    let rule = last_rule(Family::Ip, &[
        "-t", "mangle", "-A", "FORWARD",
        "-j", "TCPMSS", "--set-mss", "1400",
    ]);
    assert!(rule.contains("tcp option maxseg size set 1400"), "{}", rule);
}

#[test]
fn iptables_tcpmss_match() {
    let rule = last_rule(Family::Ip, &[
        "-A", "FORWARD", "-p", "tcp", "-m", "tcpmss", "--mss", "1400",
        "-j", "DROP",
    ]);
    assert!(rule.contains("tcp option maxseg size 1400"), "{}", rule);
}

#[test]
fn iptables_ct_target_notrack() {
    let rule = last_rule(Family::Ip, &[
        "-t", "raw", "-A", "PREROUTING", "-p", "udp", "--dport", "53",
        "-j", "CT", "--notrack",
    ]);
    assert!(rule.contains("notrack"), "{}", rule);
}

#[test]
fn iptables_ct_target_helper() {
    let rule = last_rule(Family::Ip, &[
        "-t", "raw", "-A", "PREROUTING", "-p", "tcp", "--dport", "21",
        "-j", "CT", "--helper", "ftp",
    ]);
    assert!(rule.contains("ct helper set \"ftp\""),
        "expected ct helper set: {}", rule);
}

#[test]
fn iptables_ct_target_zone() {
    let rule = last_rule(Family::Ip, &[
        "-t", "raw", "-A", "PREROUTING", "-i", "eth0",
        "-j", "CT", "--zone", "5",
    ]);
    assert!(rule.contains("ct zone set 5"), "{}", rule);
}

// ── Tier 2 (1.1.9): TOS/DSCP/TTL/HL/statistic/connlimit/helper/time/
//                    rpfilter matches + CLASSIFY/CHECKSUM/NETMAP/SET targets.

#[test]
fn iptables_tos_match() {
    let rule = last_rule(Family::Ip, &[
        "-A", "INPUT", "-m", "tos", "--tos", "0x10", "-j", "ACCEPT",
    ]);
    // -m tos lowers to ip dscp (top 6 bits).
    assert!(rule.contains("ip dscp"), "{}", rule);
    assert!(rule.contains("0x10"), "{}", rule);
}

#[test]
fn iptables_dscp_match() {
    let rule = last_rule(Family::Ip, &[
        "-A", "INPUT", "-m", "dscp", "--dscp-class", "EF", "-j", "ACCEPT",
    ]);
    // EF = 46 = 0x2e
    assert!(rule.contains("ip dscp 0x2e"), "{}", rule);
}

#[test]
fn iptables_ttl_match() {
    let eq = last_rule(Family::Ip, &["-A", "INPUT", "-m", "ttl", "--ttl-eq", "64", "-j", "ACCEPT"]);
    assert!(eq.contains("ip ttl 64"), "{}", eq);
    let lt = last_rule(Family::Ip, &["-A", "INPUT", "-m", "ttl", "--ttl-lt", "64", "-j", "ACCEPT"]);
    assert!(lt.contains("ip ttl < 64"), "{}", lt);
    let gt = last_rule(Family::Ip, &["-A", "INPUT", "-m", "ttl", "--ttl-gt", "64", "-j", "ACCEPT"]);
    assert!(gt.contains("ip ttl > 64"), "{}", gt);
}

#[test]
fn iptables_hl_match() {
    let rule = last_rule(Family::Ip6, &[
        "-A", "INPUT", "-m", "hl", "--hl-eq", "64", "-j", "ACCEPT",
    ]);
    assert!(rule.contains("ip6 hoplimit 64"), "{}", rule);
}

#[test]
fn iptables_statistic_random() {
    let rule = last_rule(Family::Ip, &[
        "-A", "INPUT", "-m", "statistic", "--mode", "random",
        "--probability", "0.5", "-j", "DROP",
    ]);
    // 0.5 probability → 5e8 ppb threshold.
    assert!(rule.contains("numgen random mod 1000000000"), "{}", rule);
    assert!(rule.contains("500000000"), "{}", rule);
}

#[test]
fn iptables_statistic_nth() {
    let rule = last_rule(Family::Ip, &[
        "-A", "INPUT", "-m", "statistic", "--mode", "nth",
        "--every", "3", "--packet", "0", "-j", "DROP",
    ]);
    assert!(rule.contains("numgen inc mod 3 == 0"), "{}", rule);
}

#[test]
fn iptables_connlimit_above() {
    let rule = last_rule(Family::Ip, &[
        "-A", "INPUT", "-p", "tcp", "--dport", "22",
        "-m", "connlimit", "--connlimit-above", "10",
        "-j", "REJECT", "--reject-with", "tcp-reset",
    ]);
    assert!(rule.contains("ct count over 10"), "{}", rule);
}

#[test]
fn iptables_helper_match_distinct_from_ct_target() {
    // -m helper --helper "ftp" is a match (ct helper "ftp")
    let rule = last_rule(Family::Ip, &[
        "-A", "INPUT", "-m", "helper", "--helper", "ftp", "-j", "ACCEPT",
    ]);
    assert!(rule.contains("ct helper \"ftp\""), "{}", rule);
    // -j CT --helper is a target (ct helper set "ftp")
    let rule = last_rule(Family::Ip, &[
        "-t", "raw", "-A", "PREROUTING", "-p", "tcp", "--dport", "21",
        "-j", "CT", "--helper", "ftp",
    ]);
    assert!(rule.contains("ct helper set \"ftp\""), "{}", rule);
}

#[test]
fn iptables_time_match() {
    let rule = last_rule(Family::Ip, &[
        "-A", "INPUT", "-m", "time",
        "--timestart", "09:00", "--timestop", "17:00",
        "--weekdays", "Mon,Tue,Wed,Thu,Fri",
        "-j", "ACCEPT",
    ]);
    assert!(rule.contains("meta hour"), "{}", rule);
    assert!(rule.contains("meta day"), "{}", rule);
    assert!(rule.contains("monday"), "{}", rule);
    assert!(rule.contains("friday"), "{}", rule);
}

#[test]
fn iptables_rpfilter_match() {
    let pass = last_rule(Family::Ip, &[
        "-A", "PREROUTING", "-m", "rpfilter", "-j", "ACCEPT",
    ]);
    assert!(pass.contains("fib saddr . iif oif != 0"), "{}", pass);
    let fail = last_rule(Family::Ip, &[
        "-A", "PREROUTING", "-m", "rpfilter", "--invert", "-j", "DROP",
    ]);
    assert!(fail.contains("fib saddr . iif oif eq 0"), "{}", fail);
}

#[test]
fn iptables_tos_target() {
    let rule = last_rule(Family::Ip, &[
        "-t", "mangle", "-A", "POSTROUTING",
        "-j", "TOS", "--set-tos", "0x10",
    ]);
    assert!(rule.contains("ip dscp set 0x10"), "{}", rule);
}

#[test]
fn iptables_dscp_target() {
    let rule = last_rule(Family::Ip, &[
        "-t", "mangle", "-A", "POSTROUTING",
        "-j", "DSCP", "--set-dscp-class", "EF",
    ]);
    // EF = 46 = 0x2e
    assert!(rule.contains("ip dscp set 0x2e"), "{}", rule);
}

#[test]
fn iptables_ttl_target() {
    let rule = last_rule(Family::Ip, &[
        "-t", "mangle", "-A", "PREROUTING",
        "-j", "TTL", "--ttl-set", "64",
    ]);
    assert!(rule.contains("ip ttl set 64"), "{}", rule);
}

#[test]
fn iptables_hl_target() {
    let rule = last_rule(Family::Ip6, &[
        "-t", "mangle", "-A", "PREROUTING",
        "-j", "HL", "--hl-set", "64",
    ]);
    assert!(rule.contains("ip6 hoplimit set 64"), "{}", rule);
}

#[test]
fn iptables_classify_target() {
    let rule = last_rule(Family::Ip, &[
        "-t", "mangle", "-A", "POSTROUTING",
        "-j", "CLASSIFY", "--set-class", "1:10",
    ]);
    assert!(rule.contains("meta priority set"), "{}", rule);
    assert!(rule.contains("0x1:0x10"), "{}", rule);
}

#[test]
fn iptables_netmap_target() {
    let pre = last_rule(Family::Ip, &[
        "-t", "nat", "-A", "PREROUTING",
        "-j", "NETMAP", "--to", "10.0.0.0/24",
    ]);
    assert!(pre.contains("dnat to 10.0.0.0/24"), "{}", pre);
    let post = last_rule(Family::Ip, &[
        "-t", "nat", "-A", "POSTROUTING",
        "-j", "NETMAP", "--to", "10.0.0.0/24",
    ]);
    assert!(post.contains("snat to 10.0.0.0/24"), "{}", post);
}

#[test]
fn iptables_set_target_add() {
    let rule = last_rule(Family::Ip, &[
        "-A", "INPUT",
        "-j", "SET", "--add-set", "BLACKLIST", "src",
    ]);
    assert!(rule.contains("add @BLACKLIST { ip saddr }"), "{}", rule);
}

// ── 1.1.10: -m recent (port-knocking / rate-limit-by-IP) ─────────────

#[test]
fn iptables_recent_rcheck() {
    let rule = last_rule(Family::Ip, &[
        "-A", "INPUT", "-m", "recent", "--rcheck",
        "--seconds", "60", "--name", "BLACKLIST", "-j", "DROP",
    ]);
    assert!(rule.contains("ip saddr @BLACKLIST"), "{}", rule);
    assert!(rule.contains("drop"), "{}", rule);
}

#[test]
fn iptables_recent_set() {
    let rule = last_rule(Family::Ip, &[
        "-A", "INPUT", "-p", "tcp", "--dport", "22",
        "-m", "recent", "--set", "--name", "ssh-flood",
        "-j", "ACCEPT",
    ]);
    assert!(rule.contains("update @ssh-flood"), "{}", rule);
    assert!(rule.contains("ip saddr"), "{}", rule);
}

#[test]
fn iptables_recent_with_timeout() {
    let rule = last_rule(Family::Ip, &[
        "-A", "INPUT", "-m", "recent", "--update",
        "--seconds", "300", "--name", "sshtrack",
        "-j", "DROP",
    ]);
    assert!(rule.contains("update @sshtrack"), "{}", rule);
    assert!(rule.contains("timeout 300s"), "{}", rule);
}

// ── 1.1.10: -m connbytes (per-flow byte/packet count) ─────────────────

#[test]
fn iptables_connbytes_packets() {
    let rule = last_rule(Family::Ip, &[
        "-A", "FORWARD", "-m", "connbytes", "--connbytes", "100:",
        "--connbytes-dir", "both", "--connbytes-mode", "packets",
        "-j", "LOG",
    ]);
    assert!(rule.contains("ct pkts"), "{}", rule);
}

#[test]
fn iptables_connbytes_bytes_range() {
    let rule = last_rule(Family::Ip, &[
        "-A", "FORWARD", "-m", "connbytes", "--connbytes", "1000:5000",
        "--connbytes-mode", "bytes",
        "-j", "ACCEPT",
    ]);
    assert!(rule.contains("ct bytes"), "{}", rule);
    assert!(rule.contains("1000-5000"), "{}", rule);
}

#[test]
fn iptables_log_extra_flags() {
    let rule = last_rule(Family::Ip, &[
        "-A", "INPUT", "-j", "LOG",
        "--log-prefix", "DROP: ",
        "--log-tcp-sequence", "--log-tcp-options", "--log-ip-options",
    ]);
    assert!(rule.contains("prefix \"DROP: \""), "{}", rule);
    assert!(rule.contains("flags tcp"), "{}", rule);
    assert!(rule.contains("sequence"), "{}", rule);
    assert!(rule.contains("options"), "{}", rule);
    assert!(rule.contains("flags ip options"), "{}", rule);
}

#[test]
fn iptables_set_counters_compat() {
    // -c PKTS BYTES is parsed and the rule still installs (the counter
    // values are not honoured, just consumed).
    let rule = last_rule(Family::Ip, &[
        "-A", "INPUT", "-c", "0", "0", "-p", "tcp", "--dport", "22",
        "-j", "ACCEPT",
    ]);
    assert!(rule.contains("tcp dport 22"), "{}", rule);
    assert!(rule.contains("accept"), "{}", rule);
}

// ── 6c. iptables_builtin_chain_keeps_hook_preamble ───────────────────
//
// Sanity: built-in chains (FORWARD, INPUT, etc.) must continue to be
// emitted with full hook + priority + policy spec — the user-chain
// fix above must not regress that path.
#[test]
fn iptables_builtin_chain_keeps_hook_preamble() {
    let lines = lower_argv(
        Family::Ip,
        &["-A", "FORWARD", "-j", "ACCEPT"],
    );
    let forward = lines
        .iter()
        .find(|l| l.starts_with("add chain ip filter forward"))
        .unwrap_or_else(|| panic!("no FORWARD preamble: {:?}", lines));
    assert!(forward.contains("type filter hook forward"),
        "expected hook spec: {}", forward);
    assert!(forward.contains("policy accept"),
        "expected policy: {}", forward);
}

// ── 7. iptables_check ────────────────────────────────────────────────

#[test]
fn iptables_check_lowering_emits_check_token() {
    // -C is special: the lowerer emits a __CHECK_BY_MATCH__ marker
    // that the dispatcher turns into a GETRULE walk + match. We
    // assert here only that the lowering reaches the right marker.
    let argv: Vec<String> = ["-C", "FORWARD", "-p", "tcp", "--dport", "22", "-j", "ACCEPT"]
        .iter().map(|s| s.to_string()).collect();
    let cmd = parse(Family::Ip, &argv).unwrap().cmd;
    assert!(matches!(cmd.op, IptOp::Check));
    let lines = lower(&cmd).unwrap().lines;
    assert!(lines.iter().any(|l| l.0.starts_with("__CHECK_BY_MATCH__ ")), "{:?}", lines);
}

// ── 7b. iptables_legacy_negation_after_flag ──────────────────────────
//
// Regression: the parser captured `pending_neg` BEFORE calling
// `take_value`, but `take_value` is the function that recognises the
// legacy `-s ! 1.2.3.4` form by flipping `pending_neg`. So the legacy
// form never made it into the rule (capture happened too early).
// 1.1.4's `take_value_neg` helper captures after the read so both the
// modern (`! -s X`) and legacy (`-s ! X`) forms work.
#[test]
fn iptables_legacy_negation_after_flag() {
    let rule = last_rule(Family::Ip, &[
        "-A", "FORWARD", "-s", "!", "10.0.0.0/8", "-j", "DROP",
    ]);
    assert!(rule.contains("ip saddr != 10.0.0.0/8"),
        "expected legacy -s ! to negate: {}", rule);

    let rule = last_rule(Family::Ip, &[
        "-A", "FORWARD", "-o", "!", "docker0", "-j", "DROP",
    ]);
    assert!(rule.contains("oifname != \"docker0\""),
        "expected legacy -o ! to negate: {}", rule);

    let rule = last_rule(Family::Ip, &[
        "-A", "INPUT", "-p", "tcp", "--dport", "!", "22", "-j", "DROP",
    ]);
    assert!(rule.contains("tcp dport != 22"),
        "expected legacy --dport ! to negate: {}", rule);
}

// ── 8. ip6tables_smoke ───────────────────────────────────────────────

#[test]
fn ip6tables_smoke() {
    // ip6tables -A FORWARD -j ACCEPT
    //   → add rule ip6 filter forward accept
    let lines = lower_argv(Family::Ip6, &["-A", "FORWARD", "-j", "ACCEPT"]);
    assert!(lines.iter().any(|l| l == "add rule ip6 filter forward accept"),
        "lines: {:?}", lines);
    // Family-aware: source address keyword must be ip6.
    let rule = last_rule(Family::Ip6, &[
        "-A", "FORWARD", "-s", "fe80::1", "-j", "DROP",
    ]);
    assert!(rule.contains("ip6 saddr fe80::1"), "rule: {}", rule);
}

// ── 9. iptables_restore_atomic ───────────────────────────────────────

#[test]
fn iptables_restore_atomic_rejects_bad_syntax() {
    // A mid-stream syntax error should fail the entire parse so
    // nothing downstream gets applied. The dispatcher's apply path
    // calls parse_restore_stream first; if it errors, no nft batch
    // is sent. We verify the parser refuses the broken stream.
    let txt = "*filter
:INPUT ACCEPT [0:0]
-A INPUT -p tcp --dport 22 -j ACCEPT
-A INPUT --frobnicate-the-flux 12 -j ACCEPT
COMMIT
";
    let r = parse_restore_stream(Family::Ip, txt);
    assert!(r.is_err(), "expected parse failure, got {:?}", r);
}

#[test]
fn iptables_restore_accepts_clean_stream() {
    let txt = "*filter
:INPUT ACCEPT [0:0]
:FORWARD DROP [0:0]
:OUTPUT ACCEPT [0:0]
-A INPUT -p tcp --dport 22 -j ACCEPT
-A FORWARD -m conntrack --ctstate RELATED,ESTABLISHED -j ACCEPT
COMMIT
*nat
:POSTROUTING ACCEPT [0:0]
-A POSTROUTING -s 172.17.0.0/16 -j MASQUERADE
COMMIT
";
    let s = parse_restore_stream(Family::Ip, txt).expect("parse ok");
    assert_eq!(s.tables.len(), 2);
    let f = &s.tables[0];
    assert_eq!(f.table, IptTable::Filter);
    assert_eq!(f.chains.len(), 3);
    assert_eq!(f.rules.len(), 2);
    let n = &s.tables[1];
    assert_eq!(n.table, IptTable::Nat);
    assert_eq!(n.rules.len(), 1);
}

// ── 10. iptables_drop_and_reject ─────────────────────────────────────

#[test]
fn iptables_drop_target() {
    let rule = last_rule(Family::Ip, &["-A", "INPUT", "-j", "DROP"]);
    assert!(rule.ends_with("drop"), "rule: {}", rule);
}

#[test]
fn iptables_reject_with_icmp_host_unreachable() {
    let rule = last_rule(Family::Ip, &[
        "-A", "INPUT", "-j", "REJECT", "--reject-with", "icmp-host-unreachable",
    ]);
    assert!(rule.contains("reject with icmp type host-unreachable"),
        "rule: {}", rule);
}

// ── Docker first-start corpus ────────────────────────────────────────
//
// These mirror the calls libnetwork makes when dockerd boots (taken
// from `iptables -S` after a clean dockerd start, on a 6.x kernel).
// Every line below is something Docker actually issues; if all pass,
// Docker's bridge networking should "just work" through the shim.

#[test]
fn docker_first_start_filter_chains() {
    // -N DOCKER
    // -N DOCKER-USER
    // -N DOCKER-ISOLATION-STAGE-1
    // -A FORWARD -j DOCKER-USER
    // -A FORWARD -j DOCKER-ISOLATION-STAGE-1
    // -A FORWARD -m conntrack --ctstate RELATED,ESTABLISHED -j ACCEPT
    let cases: &[(&[&str], &str)] = &[
        (&["-N", "DOCKER"], "add chain ip filter DOCKER"),
        (&["-N", "DOCKER-USER"], "add chain ip filter DOCKER-USER"),
        (&["-N", "DOCKER-ISOLATION-STAGE-1"], "add chain ip filter DOCKER-ISOLATION-STAGE-1"),
    ];
    for (argv, expected) in cases {
        let lines = lower_argv(Family::Ip, argv);
        assert!(lines.iter().any(|l| l == expected), "{:?} → {:?}", argv, lines);
    }

    let rule = last_rule(Family::Ip, &["-A", "FORWARD", "-j", "DOCKER-USER"]);
    assert!(rule.contains("jump DOCKER-USER"), "rule: {}", rule);

    let rule = last_rule(Family::Ip, &[
        "-A", "FORWARD", "-m", "conntrack",
        "--ctstate", "RELATED,ESTABLISHED", "-j", "ACCEPT",
    ]);
    assert!(rule.contains("ct state { related, established }"), "rule: {}", rule);
    assert!(rule.contains("accept"));
}

#[test]
fn docker_first_start_nat_chains() {
    // -t nat -N DOCKER
    // -t nat -A PREROUTING -m addrtype --dst-type LOCAL -j DOCKER
    // -t nat -A OUTPUT ! -d 127.0.0.0/8 -m addrtype --dst-type LOCAL -j DOCKER
    // -t nat -A POSTROUTING -s 172.17.0.0/16 ! -o docker0 -j MASQUERADE
    let r = lower_argv(Family::Ip, &["-t", "nat", "-N", "DOCKER"]);
    assert!(r.iter().any(|l| l == "add chain ip nat DOCKER"));

    let rule = last_rule(Family::Ip, &[
        "-t", "nat", "-A", "PREROUTING",
        "-m", "addrtype", "--dst-type", "LOCAL", "-j", "DOCKER",
    ]);
    assert!(rule.contains("fib daddr type local"), "rule: {}", rule);
    assert!(rule.contains("jump DOCKER"));

    let rule = last_rule(Family::Ip, &[
        "-t", "nat", "-A", "OUTPUT",
        "!", "-d", "127.0.0.0/8",
        "-m", "addrtype", "--dst-type", "LOCAL", "-j", "DOCKER",
    ]);
    assert!(rule.contains("ip daddr != 127.0.0.0/8"), "rule: {}", rule);
    assert!(rule.contains("fib daddr type local"));
    assert!(rule.contains("jump DOCKER"));

    let rule = last_rule(Family::Ip, &[
        "-t", "nat", "-A", "POSTROUTING",
        "-s", "172.17.0.0/16", "!", "-o", "docker0", "-j", "MASQUERADE",
    ]);
    assert!(rule.contains("ip saddr 172.17.0.0/16"));
    assert!(rule.contains("oifname != \"docker0\""));
    assert!(rule.contains("masquerade"));
}

#[test]
fn docker_port_publish_pair() {
    // The two rules dockerd writes when you `docker run -p 8080:80`:
    //   1. -t nat -A DOCKER ! -i docker0 -p tcp --dport 8080 -j DNAT --to-destination 172.17.0.2:80
    //   2. -A DOCKER -d 172.17.0.2/32 ! -i docker0 -o docker0 -p tcp --dport 80 -j ACCEPT

    // Need to predeclare DOCKER chains in both tables for the rules
    // to make sense, but the lowerer just emits text — it doesn't
    // verify chain existence. So we only assert the rule shape.
    let rule = last_rule(Family::Ip, &[
        "-t", "nat", "-A", "DOCKER",
        "!", "-i", "docker0",
        "-p", "tcp", "--dport", "8080",
        "-j", "DNAT", "--to-destination", "172.17.0.2:80",
    ]);
    assert!(rule.contains("iifname != \"docker0\""), "{}", rule);
    assert!(rule.contains("tcp dport 8080"), "{}", rule);
    assert!(rule.contains("dnat to 172.17.0.2:80"), "{}", rule);

    let rule = last_rule(Family::Ip, &[
        "-A", "DOCKER",
        "-d", "172.17.0.2/32",
        "!", "-i", "docker0",
        "-o", "docker0",
        "-p", "tcp", "--dport", "80",
        "-j", "ACCEPT",
    ]);
    assert!(rule.contains("ip daddr 172.17.0.2/32"), "{}", rule);
    assert!(rule.contains("iifname != \"docker0\""), "{}", rule);
    assert!(rule.contains("oifname \"docker0\""), "{}", rule);
    assert!(rule.contains("tcp dport 80"), "{}", rule);
    assert!(rule.contains("accept"), "{}", rule);
}

// ── Save renderer fidelity ───────────────────────────────────────────

#[test]
fn save_render_negation_preserved() {
    let argv: Vec<String> = ["-A", "FORWARD", "!", "-i", "eth0", "-j", "DROP"]
        .iter().map(|s| s.to_string()).collect();
    let cmd = parse(Family::Ip, &argv).unwrap().cmd;
    let s = render_rule_save(&cmd);
    assert!(s.contains("! -i eth0"), "{}", s);
    assert!(s.contains("-j DROP"));
}

#[test]
fn save_render_dnat_to_destination() {
    let argv: Vec<String> = [
        "-t", "nat", "-A", "PREROUTING",
        "-p", "tcp", "--dport", "80",
        "-j", "DNAT", "--to-destination", "1.2.3.4:8080",
    ].iter().map(|s| s.to_string()).collect();
    // strip the -t and table prefix for save (table scope is from *nat).
    let cmd = parse(Family::Ip, &argv).unwrap().cmd;
    let s = render_rule_save(&cmd);
    assert!(s.contains("-A PREROUTING"), "{}", s);
    assert!(s.contains("-p tcp"));
    assert!(s.contains("--dport 80"));
    assert!(s.contains("--to-destination 1.2.3.4:8080"));
}
