module github.com/u-root/u-root

go 1.24.0

require (
	github.com/google/go-cmp v0.7.0 // indirect
	github.com/safchain/ethtool v0.0.0-20200218184317-f459e2d13664
	github.com/tklauser/go-sysconf v0.3.14
	github.com/vishvananda/netlink v1.3.0
	github.com/vishvananda/netns v0.0.4
	golang.org/x/net v0.47.0 // indirect
	golang.org/x/sys v0.41.0
)

require (
	github.com/josharian/native v1.1.0 // indirect
	github.com/mdlayher/packet v1.1.2
	github.com/mdlayher/socket v0.5.1 // indirect
	github.com/tklauser/numcpus v0.8.0 // indirect
	golang.org/x/sync v0.18.0 // indirect
)

retract (
	// Published v7 too early (before migrating to go modules)
	v7.0.0+incompatible
	// Published v6 too early (before migrating to go modules)
	v6.0.0+incompatible
	// Published v5 too early (before migrating to go modules)
	v5.0.0+incompatible
	// Published v4 too early (before migrating to go modules)
	v4.0.0+incompatible
	// Published v3 too early (before migrating to go modules)
	v3.0.0+incompatible
	// Published v2 too early (before migrating to go modules)
	v2.0.0+incompatible
	// Published v1 too early (before migrating to go modules)
	[v1.0.0, v1.0.1]
)
