// Copyright (C) 2026 Jon-Erik G. Storm, Inc., a California Corporation,
// doing business as LAVA GOAT SOFTWARE.
//
// SPDX-License-Identifier: MIT
//go:build !tinygo || tinygo.enable

// route prints and manipulates the IPv4/IPv6 routing table.
//
// Synopsis:
//
//	route [-n] [-A inet|inet6]                 # show routing table
//	route [-A inet|inet6] add {-net|-host} DEST [/PREFIX]
//	      [netmask MASK] [gw GW] [dev IFACE] [metric N]
//	route [-A inet|inet6] del {-net|-host} DEST [/PREFIX] [gw GW] [dev IFACE]
//	route add default gw GW [dev IFACE]
//
// We dump the kernel table via netlink RTM_GETROUTE and modify via
// RTM_NEWROUTE / RTM_DELROUTE. The grammar is a streamlined subset of
// classic net-tools route(8) plus the IPv6 mode toggle (-A inet6 or
// -6) used by some scripts.
//
// Requires CAP_NET_ADMIN for add/del.
package main

import (
	"fmt"
	"net"
	"os"
	"strconv"
	"strings"

	"github.com/vishvananda/netlink"
	"golang.org/x/sys/unix"
)

const help = `Usage: route [-n] [-A inet|inet6]                     show routing table
       route [-A inet|inet6] add {-net|-host} DEST[/PREFIX]
             [netmask MASK] [gw GW] [dev IFACE] [metric N]
       route [-A inet|inet6] del {-net|-host} DEST[/PREFIX] [gw GW] [dev IFACE]
       route add default gw GW [dev IFACE]
`

type opts struct {
	numeric bool
	family  int // unix.AF_INET / AF_INET6
	tail    []string
}

// parseFlags pulls -n, -A inet|inet6, -4/-6 out of argv and returns the
// remaining tokens for the subcommand. We intentionally avoid the
// stdlib flag package: route's grammar mixes flags and positional
// tokens (e.g. `route del -net 10.0.0.0/8 gw 1.1.1.1`) in a way that
// confuses flag.Parse.
func parseFlags(argv []string) (*opts, error) {
	o := &opts{family: unix.AF_INET}
	for i := 0; i < len(argv); i++ {
		switch argv[i] {
		case "-n":
			o.numeric = true
		case "-4":
			o.family = unix.AF_INET
		case "-6":
			o.family = unix.AF_INET6
		case "-A":
			i++
			if i >= len(argv) {
				return nil, fmt.Errorf("-A needs an argument")
			}
			switch argv[i] {
			case "inet", "inet4":
				o.family = unix.AF_INET
			case "inet6":
				o.family = unix.AF_INET6
			default:
				return nil, fmt.Errorf("unknown -A %q", argv[i])
			}
		default:
			o.tail = append(o.tail, argv[i])
		}
	}
	return o, nil
}

func formatDst(r *netlink.Route, numeric bool) string {
	if r.Dst == nil {
		return "default"
	}
	if numeric {
		return r.Dst.String()
	}
	names, err := net.LookupAddr(r.Dst.IP.String())
	if err == nil && len(names) > 0 {
		return strings.TrimSuffix(names[0], ".")
	}
	return r.Dst.String()
}

func ifaceName(idx int, links map[int]string) string {
	if n, ok := links[idx]; ok {
		return n
	}
	if idx == 0 {
		return "*"
	}
	return fmt.Sprintf("if%d", idx)
}

func show(o *opts) error {
	routes, err := netlink.RouteList(nil, o.family)
	if err != nil {
		return fmt.Errorf("dump routes: %w", err)
	}
	links, err := netlink.LinkList()
	if err != nil {
		return fmt.Errorf("dump links: %w", err)
	}
	idx2name := map[int]string{}
	for _, l := range links {
		idx2name[l.Attrs().Index] = l.Attrs().Name
	}

	fmt.Printf("Kernel IP routing table\n")
	fmt.Printf("%-18s %-15s %-15s %-5s %-6s %-3s %-3s %s\n",
		"Destination", "Gateway", "Genmask", "Flags", "Metric", "Ref", "Use", "Iface")

	for _, r := range routes {
		dest := formatDst(&r, o.numeric)
		gw := "0.0.0.0"
		if r.Gw != nil {
			gw = r.Gw.String()
		}
		mask := "0.0.0.0"
		if r.Dst != nil {
			mask = net.IP(r.Dst.Mask).String()
		}
		flags := "U"
		if r.Gw != nil {
			flags += "G"
		}
		if r.Dst != nil {
			ones, _ := r.Dst.Mask.Size()
			if ones == 32 && o.family == unix.AF_INET {
				flags += "H"
			}
			if ones == 128 && o.family == unix.AF_INET6 {
				flags += "H"
			}
		}
		fmt.Printf("%-18s %-15s %-15s %-5s %-6d %-3d %-3d %s\n",
			dest, gw, mask, flags, r.Priority, 0, 0, ifaceName(r.LinkIndex, idx2name))
	}
	return nil
}

// parseDest accepts:
//
//	"default"           -> Dst nil (signals default route)
//	"10.0.0.0/8"        -> CIDR
//	"10.0.0.0"          -> implicit /32 (with -host) or needs netmask
//	"-net 10.0.0.0"     -> following netmask required
//
// Returns (Dst, isDefault). Caller stitches on netmask if needed.
func parseDest(s string, isHost bool) (*net.IPNet, bool, error) {
	if s == "default" || s == "0.0.0.0/0" || s == "::/0" {
		return nil, true, nil
	}
	if strings.Contains(s, "/") {
		_, n, err := net.ParseCIDR(s)
		return n, false, err
	}
	ip := net.ParseIP(s)
	if ip == nil {
		return nil, false, fmt.Errorf("%q is not an IP", s)
	}
	if isHost {
		var bits int
		if ip.To4() != nil {
			bits = 32
			ip = ip.To4()
		} else {
			bits = 128
		}
		return &net.IPNet{IP: ip, Mask: net.CIDRMask(bits, bits)}, false, nil
	}
	// No prefix length, no -host — leave mask zero; caller MUST stitch
	// on a netmask before sending to the kernel.
	return &net.IPNet{IP: ip, Mask: nil}, false, nil
}

// buildRouteRequest pulls dest + key/values from argv after "add"/"del".
// argv looks like: ["-net", "10.0.0.0/8", "gw", "192.168.1.1", "dev", "eth0", ...]
func buildRouteRequest(o *opts, action string, args []string) (*netlink.Route, error) {
	if len(args) == 0 {
		return nil, fmt.Errorf("missing destination")
	}

	isHost := false
	idx := 0
	switch args[idx] {
	case "-net":
		idx++
	case "-host":
		isHost = true
		idx++
	}
	if idx >= len(args) {
		return nil, fmt.Errorf("missing destination after %s", args[idx-1])
	}

	dst, isDefault, err := parseDest(args[idx], isHost)
	if err != nil {
		return nil, err
	}
	idx++

	r := &netlink.Route{
		Family:   o.family,
		Dst:      dst,
		Protocol: unix.RTPROT_BOOT,
		Scope:    netlink.SCOPE_LINK,
		Type:     unix.RTN_UNICAST,
		Table:    unix.RT_TABLE_MAIN,
	}
	if isDefault {
		r.Dst = nil
	}

	for idx < len(args) {
		k := args[idx]
		idx++
		if idx >= len(args) {
			return nil, fmt.Errorf("%s needs an argument", k)
		}
		v := args[idx]
		idx++
		switch k {
		case "gw", "via":
			ip := net.ParseIP(v)
			if ip == nil {
				return nil, fmt.Errorf("gw %q: not an IP", v)
			}
			r.Gw = ip
			r.Scope = netlink.SCOPE_UNIVERSE
		case "dev":
			l, err := netlink.LinkByName(v)
			if err != nil {
				return nil, fmt.Errorf("dev %q: %w", v, err)
			}
			r.LinkIndex = l.Attrs().Index
		case "netmask":
			mask := net.ParseIP(v)
			if mask == nil {
				return nil, fmt.Errorf("netmask %q: not an IP", v)
			}
			if dst != nil {
				if mask.To4() != nil {
					dst.Mask = net.IPMask(mask.To4())
				} else {
					dst.Mask = net.IPMask(mask)
				}
			}
		case "metric":
			n, err := strconv.Atoi(v)
			if err != nil {
				return nil, fmt.Errorf("metric %q: %w", v, err)
			}
			r.Priority = n
		case "src":
			ip := net.ParseIP(v)
			if ip == nil {
				return nil, fmt.Errorf("src %q: not an IP", v)
			}
			r.Src = ip
		default:
			return nil, fmt.Errorf("unknown option %q", k)
		}
	}

	if r.Dst != nil && r.Dst.Mask == nil {
		// User wrote a bare address without -host and without
		// netmask — match classic route(8) which errors out here.
		return nil, fmt.Errorf("%s: bare destination needs netmask or /prefix", r.Dst.IP)
	}

	return r, nil
}

func add(o *opts, args []string) error {
	r, err := buildRouteRequest(o, "add", args)
	if err != nil {
		return err
	}
	return netlink.RouteAdd(r)
}

func del(o *opts, args []string) error {
	r, err := buildRouteRequest(o, "del", args)
	if err != nil {
		return err
	}
	return netlink.RouteDel(r)
}

func main() {
	if len(os.Args) < 2 {
		o, _ := parseFlags(nil)
		if err := show(o); err != nil {
			fmt.Fprintf(os.Stderr, "route: %v\n", err)
			os.Exit(1)
		}
		return
	}
	o, err := parseFlags(os.Args[1:])
	if err != nil {
		fmt.Fprintf(os.Stderr, "route: %v\n", err)
		os.Exit(2)
	}

	if len(o.tail) == 0 {
		err = show(o)
	} else {
		switch o.tail[0] {
		case "add":
			err = add(o, o.tail[1:])
		case "del", "delete":
			err = del(o, o.tail[1:])
		case "-h", "--help", "help":
			fmt.Fprint(os.Stderr, help)
			return
		default:
			err = fmt.Errorf("unknown subcommand %q", o.tail[0])
		}
	}
	if err != nil {
		fmt.Fprintf(os.Stderr, "route: %v\n", err)
		os.Exit(1)
	}
}
