// Copyright (C) 2026 Jon-Erik G. Storm, Inc., a California Corporation,
// doing business as LAVA GOAT SOFTWARE.
//
// SPDX-License-Identifier: MIT
//go:build !tinygo || tinygo.enable

// ethtool reports and configures NIC settings via SIOCETHTOOL.
//
// Synopsis:
//
//	ethtool IFACE                        # default link-info dump
//	ethtool -i IFACE                     # driver info
//	ethtool -k IFACE                     # offload features (on/off)
//	ethtool -K IFACE FEATURE on|off ...  # change offload features
//	ethtool -S IFACE                     # NIC statistics
//	ethtool -P IFACE                     # permanent MAC address
//	ethtool -l IFACE                     # channel counts
//	ethtool -c IFACE                     # interrupt coalescing
//
// We delegate to the vendored safchain/ethtool package so we don't have
// to re-implement every SIOCETHTOOL ioctl by hand. That package wraps
// the raw struct ethtool_cmd / drvinfo / gstrings dance and returns
// idiomatic Go maps and structs.
//
// Requires CAP_NET_ADMIN for -K. Read-only modes work unprivileged on
// most kernels.
package main

import (
	"flag"
	"fmt"
	"os"
	"sort"
	"strings"

	"github.com/safchain/ethtool"
)

func usage() {
	fmt.Fprint(os.Stderr, `Usage: ethtool IFACE                       link info (default)
       ethtool -i IFACE                    driver info
       ethtool -k IFACE                    offload features
       ethtool -K IFACE FEATURE on|off ... change feature
       ethtool -S IFACE                    statistics
       ethtool -P IFACE                    permanent MAC
       ethtool -l IFACE                    channel counts
       ethtool -c IFACE                    coalesce settings
`)
}

func driverInfo(e *ethtool.Ethtool, iface string) error {
	d, err := e.DriverInfo(iface)
	if err != nil {
		return err
	}
	fmt.Printf("driver: %s\n", strings.TrimRight(string(d.Driver[:]), "\x00"))
	fmt.Printf("version: %s\n", strings.TrimRight(string(d.Version[:]), "\x00"))
	fmt.Printf("firmware-version: %s\n", strings.TrimRight(string(d.FwVersion[:]), "\x00"))
	fmt.Printf("bus-info: %s\n", strings.TrimRight(string(d.BusInfo[:]), "\x00"))
	return nil
}

func features(e *ethtool.Ethtool, iface string) error {
	feats, err := e.Features(iface)
	if err != nil {
		return err
	}
	names := make([]string, 0, len(feats))
	for k := range feats {
		names = append(names, k)
	}
	sort.Strings(names)
	for _, n := range names {
		state := "off"
		if feats[n] {
			state = "on"
		}
		fmt.Printf("%-30s %s\n", n+":", state)
	}
	return nil
}

func changeFeatures(e *ethtool.Ethtool, iface string, args []string) error {
	cfg := map[string]bool{}
	if len(args)%2 != 0 {
		return fmt.Errorf("expected FEATURE on|off pairs")
	}
	for i := 0; i < len(args); i += 2 {
		name := args[i]
		val := args[i+1]
		switch val {
		case "on":
			cfg[name] = true
		case "off":
			cfg[name] = false
		default:
			return fmt.Errorf("%s: expected on|off, got %q", name, val)
		}
	}
	return e.Change(iface, cfg)
}

func stats(e *ethtool.Ethtool, iface string) error {
	st, err := e.Stats(iface)
	if err != nil {
		return err
	}
	names := make([]string, 0, len(st))
	for k := range st {
		names = append(names, k)
	}
	sort.Strings(names)
	fmt.Printf("NIC statistics:\n")
	for _, n := range names {
		fmt.Printf("     %s: %d\n", n, st[n])
	}
	return nil
}

func permAddr(e *ethtool.Ethtool, iface string) error {
	a, err := e.PermAddr(iface)
	if err != nil {
		return err
	}
	fmt.Printf("Permanent address: %s\n", a)
	return nil
}

func channels(e *ethtool.Ethtool, iface string) error {
	c, err := e.GetChannels(iface)
	if err != nil {
		return err
	}
	fmt.Printf("Channel parameters for %s:\n", iface)
	fmt.Printf("Pre-set maximums:\n")
	fmt.Printf("RX:             %d\n", c.MaxRx)
	fmt.Printf("TX:             %d\n", c.MaxTx)
	fmt.Printf("Other:          %d\n", c.MaxOther)
	fmt.Printf("Combined:       %d\n", c.MaxCombined)
	fmt.Printf("Current hardware settings:\n")
	fmt.Printf("RX:             %d\n", c.RxCount)
	fmt.Printf("TX:             %d\n", c.TxCount)
	fmt.Printf("Other:          %d\n", c.OtherCount)
	fmt.Printf("Combined:       %d\n", c.CombinedCount)
	return nil
}

func coalesce(e *ethtool.Ethtool, iface string) error {
	c, err := e.GetCoalesce(iface)
	if err != nil {
		return err
	}
	fmt.Printf("Coalesce parameters for %s:\n", iface)
	fmt.Printf("Adaptive RX: %v  TX: %v\n", c.UseAdaptiveRxCoalesce != 0, c.UseAdaptiveTxCoalesce != 0)
	fmt.Printf("rx-usecs: %d\n", c.RxCoalesceUsecs)
	fmt.Printf("rx-frames: %d\n", c.RxMaxCoalescedFrames)
	fmt.Printf("tx-usecs: %d\n", c.TxCoalesceUsecs)
	fmt.Printf("tx-frames: %d\n", c.TxMaxCoalescedFrames)
	return nil
}

func linkInfo(e *ethtool.Ethtool, iface string) error {
	// LinkState returns 0 (down) or 1 (up) — exactly what mii-tool
	// would tell you. For a richer view we also pull stats names for
	// the speed/duplex pair if the driver advertises them, but it's
	// optional.
	st, err := e.LinkState(iface)
	if err != nil {
		return err
	}
	state := "no"
	if st != 0 {
		state = "yes"
	}
	fmt.Printf("Settings for %s:\n", iface)
	fmt.Printf("        Link detected: %s\n", state)
	if drv, err := e.DriverName(iface); err == nil {
		fmt.Printf("        Driver: %s\n", drv)
	}
	if bus, err := e.BusInfo(iface); err == nil && bus != "" {
		fmt.Printf("        Bus-info: %s\n", bus)
	}
	if perm, err := e.PermAddr(iface); err == nil {
		fmt.Printf("        Permanent HW addr: %s\n", perm)
	}
	return nil
}

func main() {
	var (
		showDrv     = flag.Bool("i", false, "driver info")
		showFeats   = flag.Bool("k", false, "offload features")
		changeFeats = flag.Bool("K", false, "change feature: FEATURE on|off ...")
		showStats   = flag.Bool("S", false, "statistics")
		showPerm    = flag.Bool("P", false, "permanent MAC")
		showChan    = flag.Bool("l", false, "channels")
		showCoal    = flag.Bool("c", false, "coalesce")
	)
	flag.Usage = usage
	flag.Parse()
	if flag.NArg() < 1 {
		usage()
		os.Exit(2)
	}
	iface := flag.Arg(0)

	e, err := ethtool.NewEthtool()
	if err != nil {
		fmt.Fprintf(os.Stderr, "ethtool: %v\n", err)
		os.Exit(1)
	}
	defer e.Close()

	switch {
	case *showDrv:
		err = driverInfo(e, iface)
	case *showFeats:
		err = features(e, iface)
	case *changeFeats:
		err = changeFeatures(e, iface, flag.Args()[1:])
	case *showStats:
		err = stats(e, iface)
	case *showPerm:
		err = permAddr(e, iface)
	case *showChan:
		err = channels(e, iface)
	case *showCoal:
		err = coalesce(e, iface)
	default:
		err = linkInfo(e, iface)
	}
	if err != nil {
		fmt.Fprintf(os.Stderr, "ethtool: %v\n", err)
		os.Exit(1)
	}
}
