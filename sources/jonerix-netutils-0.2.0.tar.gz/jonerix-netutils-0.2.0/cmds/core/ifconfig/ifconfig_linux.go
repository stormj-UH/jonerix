// Copyright (C) 2026 Jon-Erik G. Storm, Inc., a California Corporation,
// doing business as LAVA GOAT SOFTWARE.
//
// SPDX-License-Identifier: MIT
//go:build !tinygo || tinygo.enable

// ifconfig configures network interfaces.
//
// Synopsis:
//
//	ifconfig                                       # show all interfaces
//	ifconfig IFACE                                 # show one interface
//	ifconfig IFACE up | down
//	ifconfig IFACE ADDR[/PREFIX] [netmask MASK]    # assign primary IP
//	ifconfig IFACE mtu N
//	ifconfig IFACE hw ether AA:BB:CC:DD:EE:FF
//
// We pick the safer subset of the historical interface — no aliasing
// (use `ip addr add` for that), no obscure flags like `txqueuelen`
// outside what ip handles. All operations go via the vendored netlink
// package; no ioctls.
//
// Requires CAP_NET_ADMIN for any modify operation.
package main

import (
	"fmt"
	"net"
	"os"
	"strconv"
	"strings"

	"github.com/vishvananda/netlink"
	"golang.org/x/sys/unix"
)

const help = `Usage: ifconfig [IFACE]                                   show
       ifconfig IFACE up|down
       ifconfig IFACE ADDR[/PREFIX] [netmask MASK]        assign IP
       ifconfig IFACE mtu N
       ifconfig IFACE hw ether MAC
`

func flagBits(flags net.Flags, attrs *netlink.LinkAttrs) string {
	var b []string
	if flags&net.FlagUp != 0 {
		b = append(b, "UP")
	}
	if flags&net.FlagBroadcast != 0 {
		b = append(b, "BROADCAST")
	}
	if attrs.Flags&unix.IFF_RUNNING != 0 {
		b = append(b, "RUNNING")
	}
	if flags&net.FlagMulticast != 0 {
		b = append(b, "MULTICAST")
	}
	if flags&net.FlagLoopback != 0 {
		b = append(b, "LOOPBACK")
	}
	if flags&net.FlagPointToPoint != 0 {
		b = append(b, "POINTOPOINT")
	}
	return strings.Join(b, " ")
}

func showOne(l netlink.Link) {
	a := l.Attrs()
	mtu := a.MTU
	mac := ""
	if a.HardwareAddr != nil {
		mac = a.HardwareAddr.String()
	}

	flags := a.Flags
	fmt.Printf("%s: flags=%d<%s>  mtu %d\n",
		a.Name,
		uint32(flags),
		flagBits(net.Flags(flags), a),
		mtu)

	// Address dump — both v4 and v6.
	addrs, err := netlink.AddrList(l, unix.AF_UNSPEC)
	if err == nil {
		for _, ad := range addrs {
			fam := "inet"
			if ad.IP.To4() == nil {
				fam = "inet6"
			}
			ones, bits := ad.Mask.Size()
			fmt.Printf("        %s %s  prefixlen %d  scope %d\n",
				fam, ad.IP, ones, ad.Scope)
			_ = bits
		}
	}
	if mac != "" {
		fmt.Printf("        ether %s  txqueuelen %d\n", mac, a.TxQLen)
	}
	// Stats (RX/TX counters from the netlink IFLA_STATS attribute).
	if a.Statistics != nil {
		s := a.Statistics
		fmt.Printf("        RX packets %d  bytes %d  errors %d  dropped %d\n",
			s.RxPackets, s.RxBytes, s.RxErrors, s.RxDropped)
		fmt.Printf("        TX packets %d  bytes %d  errors %d  dropped %d\n",
			s.TxPackets, s.TxBytes, s.TxErrors, s.TxDropped)
	}
	fmt.Println()
}

func showAll() error {
	links, err := netlink.LinkList()
	if err != nil {
		return err
	}
	for _, l := range links {
		showOne(l)
	}
	return nil
}

// parseAddr handles "10.0.0.1" or "10.0.0.1/24". Returned netmask is
// non-nil; default /32 (IPv4) or /128 (IPv6) when no prefix supplied.
func parseAddr(s string) (*net.IPNet, error) {
	if strings.Contains(s, "/") {
		ip, ipnet, err := net.ParseCIDR(s)
		if err != nil {
			return nil, err
		}
		return &net.IPNet{IP: ip, Mask: ipnet.Mask}, nil
	}
	ip := net.ParseIP(s)
	if ip == nil {
		return nil, fmt.Errorf("not an IP: %q", s)
	}
	if ip.To4() != nil {
		return &net.IPNet{IP: ip, Mask: net.CIDRMask(32, 32)}, nil
	}
	return &net.IPNet{IP: ip, Mask: net.CIDRMask(128, 128)}, nil
}

func setAddr(l netlink.Link, ipnet *net.IPNet) error {
	// Replace any existing primary v4 (matches classic ifconfig
	// semantics, where re-running it changes the address rather than
	// adding a secondary).
	if ipnet.IP.To4() != nil {
		old, _ := netlink.AddrList(l, unix.AF_INET)
		for _, a := range old {
			_ = netlink.AddrDel(l, &a)
		}
	}
	a := &netlink.Addr{IPNet: ipnet}
	return netlink.AddrAdd(l, a)
}

func handle(name string, rest []string) error {
	link, err := netlink.LinkByName(name)
	if err != nil {
		return fmt.Errorf("interface %q: %w", name, err)
	}
	if len(rest) == 0 {
		showOne(link)
		return nil
	}

	// Walk the token stream. First token may be a verb (up/down) or an
	// IP (positional address). Then key/value pairs follow.
	i := 0
	for i < len(rest) {
		tok := rest[i]
		switch tok {
		case "up":
			if err := netlink.LinkSetUp(link); err != nil {
				return err
			}
			i++
		case "down":
			if err := netlink.LinkSetDown(link); err != nil {
				return err
			}
			i++
		case "mtu":
			i++
			if i >= len(rest) {
				return fmt.Errorf("mtu needs an argument")
			}
			n, err := strconv.Atoi(rest[i])
			if err != nil {
				return fmt.Errorf("mtu %q: %w", rest[i], err)
			}
			if err := netlink.LinkSetMTU(link, n); err != nil {
				return err
			}
			i++
		case "hw":
			i++
			if i+1 >= len(rest) {
				return fmt.Errorf("hw ether MAC")
			}
			if rest[i] != "ether" {
				return fmt.Errorf("hw %q not supported (use 'ether')", rest[i])
			}
			i++
			mac, err := net.ParseMAC(rest[i])
			if err != nil {
				return fmt.Errorf("hw ether %q: %w", rest[i], err)
			}
			if err := netlink.LinkSetHardwareAddr(link, mac); err != nil {
				return err
			}
			i++
		case "netmask":
			// netmask without a preceding bare address; ignore here
			// (handled inline below as part of the address path).
			return fmt.Errorf("netmask is only valid right after an address")
		default:
			// Positional: bare address; may be followed by "netmask MASK".
			addr, err := parseAddr(tok)
			if err != nil {
				return fmt.Errorf("unrecognized token %q: %w", tok, err)
			}
			i++
			if i < len(rest) && rest[i] == "netmask" {
				i++
				if i >= len(rest) {
					return fmt.Errorf("netmask needs an argument")
				}
				mask := net.ParseIP(rest[i])
				if mask == nil {
					return fmt.Errorf("netmask %q: not an IP", rest[i])
				}
				if mask.To4() != nil {
					addr.Mask = net.IPMask(mask.To4())
				} else {
					addr.Mask = net.IPMask(mask)
				}
				i++
			}
			if err := setAddr(link, addr); err != nil {
				return fmt.Errorf("set address %s: %w", addr, err)
			}
		}
	}
	return nil
}

func main() {
	args := os.Args[1:]
	switch {
	case len(args) == 0:
		if err := showAll(); err != nil {
			fmt.Fprintf(os.Stderr, "ifconfig: %v\n", err)
			os.Exit(1)
		}
		return
	case args[0] == "-h" || args[0] == "--help":
		fmt.Fprint(os.Stderr, help)
		return
	}
	if err := handle(args[0], args[1:]); err != nil {
		fmt.Fprintf(os.Stderr, "ifconfig: %v\n", err)
		os.Exit(1)
	}
}
