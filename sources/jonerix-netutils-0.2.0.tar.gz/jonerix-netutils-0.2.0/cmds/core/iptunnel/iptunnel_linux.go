// Copyright (C) 2026 Jon-Erik G. Storm, Inc., a California Corporation,
// doing business as LAVA GOAT SOFTWARE.
//
// SPDX-License-Identifier: MIT
//go:build !tinygo || tinygo.enable

// iptunnel manages IPv4-in-IPv4 / GRE / SIT tunnel interfaces.
//
// Synopsis:
//
//	iptunnel show
//	iptunnel add NAME mode {ipip|gre|sit} remote ADDR
//	             local ADDR [dev IF] [ttl N] [tos N] [key K]
//	iptunnel del NAME
//	iptunnel change NAME ...     (same key/value vocabulary as add)
//
// We build a netlink.Iptun / Gretun / Sittun struct and hand it to
// netlink.LinkAdd; deletes go through LinkByName + LinkDel. The "show"
// subcommand walks LinkList and prints the tunnel ones.
//
// Requires CAP_NET_ADMIN for add/del/change.
package main

import (
	"fmt"
	"net"
	"os"
	"strconv"

	"github.com/vishvananda/netlink"
)

const help = `Usage: iptunnel show
       iptunnel add NAME mode {ipip|gre|sit} remote ADDR local ADDR
                [dev IF] [ttl N] [tos N] [key K]
       iptunnel del NAME
       iptunnel change NAME ...     (add-style key/value)
`

// kvParse turns ["mode","gre","remote","1.2.3.4"] into a map. We allow
// repeated keys (last wins) and bail on a key without a value.
func kvParse(args []string) (map[string]string, error) {
	out := map[string]string{}
	for i := 0; i < len(args); i += 2 {
		k := args[i]
		if i+1 >= len(args) {
			return nil, fmt.Errorf("key %q missing value", k)
		}
		out[k] = args[i+1]
	}
	return out, nil
}

// buildTunnel takes the parsed key/value map and returns a netlink.Link
// of the appropriate concrete type. We don't try to be exhaustive — the
// common knobs (remote, local, ttl, tos, dev, key) are enough for 95% of
// "stand up an ipip/gre tunnel" use cases.
func buildTunnel(name string, kv map[string]string) (netlink.Link, error) {
	mode := kv["mode"]
	if mode == "" {
		return nil, fmt.Errorf("mode is required (ipip|gre|sit)")
	}

	attrs := netlink.NewLinkAttrs()
	attrs.Name = name
	if dev := kv["dev"]; dev != "" {
		base, err := netlink.LinkByName(dev)
		if err != nil {
			return nil, fmt.Errorf("dev %q: %w", dev, err)
		}
		attrs.ParentIndex = base.Attrs().Index
	}

	var (
		remote, local net.IP
	)
	if s := kv["remote"]; s != "" {
		remote = net.ParseIP(s)
		if remote == nil {
			return nil, fmt.Errorf("remote %q: not an IP", s)
		}
	}
	if s := kv["local"]; s != "" {
		local = net.ParseIP(s)
		if local == nil {
			return nil, fmt.Errorf("local %q: not an IP", s)
		}
	}

	parseU8 := func(k string) (uint8, error) {
		s, ok := kv[k]
		if !ok {
			return 0, nil
		}
		n, err := strconv.ParseUint(s, 0, 8)
		if err != nil {
			return 0, fmt.Errorf("%s %q: %w", k, s, err)
		}
		return uint8(n), nil
	}
	parseU32 := func(k string) (uint32, error) {
		s, ok := kv[k]
		if !ok {
			return 0, nil
		}
		n, err := strconv.ParseUint(s, 0, 32)
		if err != nil {
			return 0, fmt.Errorf("%s %q: %w", k, s, err)
		}
		return uint32(n), nil
	}

	ttl, err := parseU8("ttl")
	if err != nil {
		return nil, err
	}
	tos, err := parseU8("tos")
	if err != nil {
		return nil, err
	}

	switch mode {
	case "ipip":
		return &netlink.Iptun{
			LinkAttrs: attrs,
			Local:     local,
			Remote:    remote,
			Ttl:       ttl,
			Tos:       tos,
		}, nil
	case "gre":
		key, err := parseU32("key")
		if err != nil {
			return nil, err
		}
		return &netlink.Gretun{
			LinkAttrs: attrs,
			Local:     local,
			Remote:    remote,
			Ttl:       ttl,
			Tos:       tos,
			IKey:      key,
			OKey:      key,
		}, nil
	case "sit":
		return &netlink.Sittun{
			LinkAttrs: attrs,
			Local:     local,
			Remote:    remote,
			Ttl:       ttl,
			Tos:       tos,
		}, nil
	default:
		return nil, fmt.Errorf("unknown mode %q (want ipip|gre|sit)", mode)
	}
}

func ipOrEmpty(ip net.IP) string {
	if ip == nil || ip.IsUnspecified() {
		return "any"
	}
	return ip.String()
}

func show() error {
	links, err := netlink.LinkList()
	if err != nil {
		return fmt.Errorf("list links: %w", err)
	}
	for _, l := range links {
		switch t := l.(type) {
		case *netlink.Iptun:
			fmt.Printf("%s: ipip remote %s local %s ttl %d\n",
				t.Attrs().Name, ipOrEmpty(t.Remote), ipOrEmpty(t.Local), t.Ttl)
		case *netlink.Gretun:
			fmt.Printf("%s: gre remote %s local %s ttl %d key %d\n",
				t.Attrs().Name, ipOrEmpty(t.Remote), ipOrEmpty(t.Local), t.Ttl, t.IKey)
		case *netlink.Sittun:
			fmt.Printf("%s: sit remote %s local %s ttl %d\n",
				t.Attrs().Name, ipOrEmpty(t.Remote), ipOrEmpty(t.Local), t.Ttl)
		}
	}
	return nil
}

func add(name string, args []string) error {
	kv, err := kvParse(args)
	if err != nil {
		return err
	}
	link, err := buildTunnel(name, kv)
	if err != nil {
		return err
	}
	return netlink.LinkAdd(link)
}

func change(name string, args []string) error {
	// We don't have a fine-grained "tunnel change" netlink op; the
	// safest portable thing is to delete and re-add. The kernel does
	// briefly drop the tunnel, but for the ttl/tos/remote knobs ip's
	// own implementation does the same thing under the hood for tunnels
	// that don't support IFLA_INFO_DATA mutation.
	link, err := netlink.LinkByName(name)
	if err != nil {
		return fmt.Errorf("not found: %w", err)
	}
	if err := netlink.LinkDel(link); err != nil {
		return fmt.Errorf("delete-for-change: %w", err)
	}
	return add(name, args)
}

func del(name string) error {
	l, err := netlink.LinkByName(name)
	if err != nil {
		return fmt.Errorf("not found: %w", err)
	}
	return netlink.LinkDel(l)
}

func usage(code int) {
	fmt.Fprint(os.Stderr, help)
	os.Exit(code)
}

func main() {
	if len(os.Args) < 2 {
		usage(2)
	}
	cmd := os.Args[1]
	var err error
	switch cmd {
	case "show", "list":
		err = show()
	case "add":
		if len(os.Args) < 3 {
			usage(2)
		}
		err = add(os.Args[2], os.Args[3:])
	case "change":
		if len(os.Args) < 3 {
			usage(2)
		}
		err = change(os.Args[2], os.Args[3:])
	case "del", "delete":
		if len(os.Args) < 3 {
			usage(2)
		}
		err = del(os.Args[2])
	case "-h", "--help", "help":
		usage(0)
	default:
		usage(2)
	}
	if err != nil {
		fmt.Fprintf(os.Stderr, "iptunnel: %v\n", err)
		os.Exit(1)
	}
}
