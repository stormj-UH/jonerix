// Copyright (C) 2026 Jon-Erik G. Storm, Inc., a California Corporation,
// doing business as LAVA GOAT SOFTWARE.
//
// SPDX-License-Identifier: MIT
//go:build !tinygo || tinygo.enable

// tunctl creates and destroys persistent TUN/TAP devices.
//
// Synopsis:
//
//	tunctl [-n] -t name      # create persistent TAP (or TUN with -n)
//	tunctl -d name           # destroy persistent TUN/TAP
//	tunctl -h | -help        # usage
//
// Notes:
//
//	The kernel decides TUN vs TAP from the IFF_TUN / IFF_TAP flag set on
//	the TUNSETIFF ioctl. We pass IFF_NO_PI so the device delivers raw
//	frames without the 4-byte packet-info header. TUNSETPERSIST(1) keeps
//	the device alive after this process exits; TUNSETPERSIST(0) marks the
//	device non-persistent, which immediately destroys it because no fd is
//	holding it open.
//
//	Requires CAP_NET_ADMIN (usually run as root).
package main

import (
	"errors"
	"flag"
	"fmt"
	"os"
	"unsafe"

	"golang.org/x/sys/unix"
)

// ifReq matches struct ifreq's TUN-relevant prefix:
//
//	char ifrn_name[IFNAMSIZ];   // 16 bytes, NUL-padded
//	short ifru_flags;           // padded to 24-byte ifreq total
//
// The kernel only reads the first 18 bytes for TUNSETIFF, but we pass
// a full ifreq-shaped struct (40 bytes on Linux) for safety.
type ifReq struct {
	Name  [unix.IFNAMSIZ]byte
	Flags uint16
	_     [24 - unix.IFNAMSIZ - 2]byte // pad to sizeof(struct ifreq) - first member
	_     [16]byte                     // union ifru_* tail
}

const tunDevice = "/dev/net/tun"

func openTun() (*os.File, error) {
	f, err := os.OpenFile(tunDevice, os.O_RDWR, 0)
	if err != nil {
		return nil, fmt.Errorf("open %s: %w", tunDevice, err)
	}
	return f, nil
}

func setIff(fd uintptr, name string, flags uint16) error {
	if len(name) >= unix.IFNAMSIZ {
		return fmt.Errorf("name %q exceeds IFNAMSIZ-1 (%d)", name, unix.IFNAMSIZ-1)
	}
	var req ifReq
	copy(req.Name[:], name)
	req.Flags = flags
	if _, _, errno := unix.Syscall(unix.SYS_IOCTL, fd, uintptr(unix.TUNSETIFF), uintptr(unsafe.Pointer(&req))); errno != 0 {
		return fmt.Errorf("TUNSETIFF %s: %w", name, errno)
	}
	return nil
}

func setPersist(fd uintptr, persist bool) error {
	var arg uintptr
	if persist {
		arg = 1
	}
	if _, _, errno := unix.Syscall(unix.SYS_IOCTL, fd, uintptr(unix.TUNSETPERSIST), arg); errno != 0 {
		return fmt.Errorf("TUNSETPERSIST: %w", errno)
	}
	return nil
}

func create(name string, isTAP bool) error {
	f, err := openTun()
	if err != nil {
		return err
	}
	defer f.Close()

	flags := uint16(unix.IFF_NO_PI)
	if isTAP {
		flags |= unix.IFF_TAP
	} else {
		flags |= unix.IFF_TUN
	}
	if err := setIff(f.Fd(), name, flags); err != nil {
		return err
	}
	if err := setPersist(f.Fd(), true); err != nil {
		return err
	}
	kind := "TUN"
	if isTAP {
		kind = "TAP"
	}
	fmt.Printf("Set '%s' persistent and owned by root (%s)\n", name, kind)
	return nil
}

func destroy(name string) error {
	f, err := openTun()
	if err != nil {
		return err
	}
	defer f.Close()
	// We must re-attach to the device before we can clear its persist
	// bit. The kernel accepts either IFF_TUN or IFF_TAP for an existing
	// device — it returns the kind already in use. Probe TAP first; if
	// that fails with EINVAL fall through to TUN.
	if err := setIff(f.Fd(), name, uint16(unix.IFF_TAP|unix.IFF_NO_PI)); err != nil {
		if errors.Is(err, unix.EINVAL) {
			if err = setIff(f.Fd(), name, uint16(unix.IFF_TUN|unix.IFF_NO_PI)); err != nil {
				return err
			}
		} else {
			return err
		}
	}
	if err := setPersist(f.Fd(), false); err != nil {
		return err
	}
	fmt.Printf("Set '%s' nonpersistent\n", name)
	return nil
}

func usage() {
	fmt.Fprint(os.Stderr, `Usage: tunctl [-n] -t name     create persistent TAP (TUN with -n)
       tunctl -d name           destroy persistent TUN/TAP
`)
}

func main() {
	var (
		create_ = flag.String("t", "", "create persistent device with this name")
		delete_ = flag.String("d", "", "destroy persistent device with this name")
		tunMode = flag.Bool("n", false, "with -t, create a TUN (point-to-point) instead of a TAP")
		help    = flag.Bool("h", false, "show usage")
	)
	flag.Usage = usage
	flag.Parse()

	if *help || (*create_ == "" && *delete_ == "") || (*create_ != "" && *delete_ != "") {
		usage()
		if *help {
			os.Exit(0)
		}
		os.Exit(2)
	}

	var err error
	switch {
	case *create_ != "":
		err = create(*create_, !*tunMode)
	case *delete_ != "":
		err = destroy(*delete_)
	}
	if err != nil {
		fmt.Fprintf(os.Stderr, "tunctl: %v\n", err)
		os.Exit(1)
	}
}
