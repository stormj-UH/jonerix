// Copyright (C) 2026 Jon-Erik G. Storm, Inc., a California Corporation,
// doing business as LAVA GOAT SOFTWARE.
//
// SPDX-License-Identifier: MIT
//go:build !tinygo || tinygo.enable

// arp manipulates the kernel's ARP cache.
//
// Synopsis:
//
//	arp [-n] [-i iface]                  # list all entries
//	arp [-n] [-i iface] -a [host]        # list (BSD-style)
//	arp -d host [-i iface]               # delete entry for host
//	arp -s host hwaddr [-i iface]        # set static entry
//
// We dump the cache via rtnetlink RTM_GETNEIGH (rather than scraping
// /proc/net/arp) so we get IPv6 neighbours and the correct state for
// each entry. Modify operations go through RTM_NEWNEIGH / RTM_DELNEIGH.
//
// Requires CAP_NET_ADMIN for modify operations; list works unprivileged.
package main

import (
	"flag"
	"fmt"
	"net"
	"os"
	"strings"

	"github.com/vishvananda/netlink"
	"golang.org/x/sys/unix"
)

var (
	flagNumeric = flag.Bool("n", false, "show numerical addresses (no DNS lookup)")
	flagDevice  = flag.String("i", "", "restrict to network interface")
	flagAll     = flag.Bool("a", false, "BSD-style list (optionally for host)")
	flagDelete  = flag.String("d", "", "delete entry for host")
	flagSet     = flag.Bool("s", false, "set static entry: -s host hwaddr")
	flagHelp    = flag.Bool("h", false, "usage")
)

func usage() {
	fmt.Fprint(os.Stderr, `Usage: arp [-n] [-i iface]                 list entries
       arp [-n] [-i iface] -a [host]       list (BSD style)
       arp -d host [-i iface]              delete entry
       arp -s host hwaddr [-i iface]       set static entry
`)
}

func stateString(s int) string {
	// NUD_* bit flags, in priority order — we report the most specific
	// state the entry has set. This mirrors what `ip neigh` prints.
	switch {
	case s&unix.NUD_PERMANENT != 0:
		return "PERM"
	case s&unix.NUD_REACHABLE != 0:
		return "REACHABLE"
	case s&unix.NUD_STALE != 0:
		return "STALE"
	case s&unix.NUD_DELAY != 0:
		return "DELAY"
	case s&unix.NUD_PROBE != 0:
		return "PROBE"
	case s&unix.NUD_FAILED != 0:
		return "FAILED"
	case s&unix.NUD_INCOMPLETE != 0:
		return "INCOMPLETE"
	case s&unix.NUD_NOARP != 0:
		return "NOARP"
	default:
		return "NONE"
	}
}

func ifaceFilter(name string) (int, error) {
	if name == "" {
		return 0, nil
	}
	link, err := netlink.LinkByName(name)
	if err != nil {
		return 0, fmt.Errorf("interface %q: %w", name, err)
	}
	return link.Attrs().Index, nil
}

func lookupHost(numeric bool, ip net.IP) string {
	if numeric || ip == nil {
		if ip == nil {
			return "?"
		}
		return ip.String()
	}
	names, err := net.LookupAddr(ip.String())
	if err != nil || len(names) == 0 {
		return ip.String()
	}
	return strings.TrimSuffix(names[0], ".")
}

func list(filterIdx int, host string) error {
	// Linux exposes both IPv4 and IPv6 neighbours via the same netlink
	// family; pass 0 to dump both. The vendored netlink package's
	// NeighList accepts (linkIndex, family). family=unix.AF_UNSPEC asks
	// for everything.
	neighs, err := netlink.NeighList(filterIdx, unix.AF_UNSPEC)
	if err != nil {
		return fmt.Errorf("dump arp/neigh cache: %w", err)
	}

	// host-filter: resolve once, compare to neigh.IP
	var want net.IP
	if host != "" {
		ips, err := net.LookupIP(host)
		if err != nil || len(ips) == 0 {
			return fmt.Errorf("resolve %q: %w", host, err)
		}
		want = ips[0]
	}

	// Match the classic `arp -n` column layout:
	// Address  HWtype  HWaddress  Flags Mask  Iface
	fmt.Printf("%-30s %-8s %-19s %-10s %s\n", "Address", "HWtype", "HWaddress", "Flags", "Iface")
	links, _ := netlink.LinkList()
	idxName := map[int]string{}
	for _, l := range links {
		idxName[l.Attrs().Index] = l.Attrs().Name
	}
	for _, n := range neighs {
		if want != nil && !n.IP.Equal(want) {
			continue
		}
		hw := "<incomplete>"
		if n.HardwareAddr != nil {
			hw = n.HardwareAddr.String()
		}
		hwtype := "ether"
		if n.Family == unix.AF_INET6 {
			hwtype = "ether6"
		}
		flags := "C" // cached / dynamic
		if n.State&unix.NUD_PERMANENT != 0 {
			flags = "CM" // permanent (static, "C M" in old arp)
		}
		fmt.Printf("%-30s %-8s %-19s %-10s %s\n",
			lookupHost(*flagNumeric, n.IP),
			hwtype,
			hw,
			flags,
			idxName[n.LinkIndex],
		)
	}
	return nil
}

func del(host string, ifIdx int) error {
	ips, err := net.LookupIP(host)
	if err != nil || len(ips) == 0 {
		return fmt.Errorf("resolve %q: %w", host, err)
	}
	if ifIdx == 0 {
		// Find the right interface for the IP by checking the neighbour
		// table — `arp -d host` without -i lets the kernel pick.
		neighs, err := netlink.NeighList(0, unix.AF_UNSPEC)
		if err != nil {
			return fmt.Errorf("dump neigh: %w", err)
		}
		for _, n := range neighs {
			if n.IP.Equal(ips[0]) {
				ifIdx = n.LinkIndex
				break
			}
		}
		if ifIdx == 0 {
			return fmt.Errorf("no neighbour entry for %s", ips[0])
		}
	}
	n := &netlink.Neigh{
		LinkIndex: ifIdx,
		IP:        ips[0],
		Family:    familyOf(ips[0]),
	}
	if err := netlink.NeighDel(n); err != nil {
		return fmt.Errorf("delete %s: %w", ips[0], err)
	}
	return nil
}

func familyOf(ip net.IP) int {
	if ip.To4() != nil {
		return unix.AF_INET
	}
	return unix.AF_INET6
}

func set(host, hw string, ifIdx int) error {
	ips, err := net.LookupIP(host)
	if err != nil || len(ips) == 0 {
		return fmt.Errorf("resolve %q: %w", host, err)
	}
	hwaddr, err := net.ParseMAC(hw)
	if err != nil {
		return fmt.Errorf("hwaddr %q: %w", hw, err)
	}
	if ifIdx == 0 {
		return fmt.Errorf("-s requires -i iface (cannot infer interface)")
	}
	n := &netlink.Neigh{
		LinkIndex:    ifIdx,
		IP:           ips[0],
		Family:       familyOf(ips[0]),
		State:        unix.NUD_PERMANENT,
		HardwareAddr: hwaddr,
	}
	if err := netlink.NeighSet(n); err != nil {
		return fmt.Errorf("set %s -> %s on iface %d: %w", ips[0], hwaddr, ifIdx, err)
	}
	return nil
}

func main() {
	flag.Usage = usage
	flag.Parse()
	if *flagHelp {
		usage()
		os.Exit(0)
	}

	ifIdx, err := ifaceFilter(*flagDevice)
	if err != nil {
		fmt.Fprintf(os.Stderr, "arp: %v\n", err)
		os.Exit(1)
	}

	switch {
	case *flagDelete != "":
		err = del(*flagDelete, ifIdx)
	case *flagSet:
		args := flag.Args()
		if len(args) < 2 {
			usage()
			os.Exit(2)
		}
		err = set(args[0], args[1], ifIdx)
	case *flagAll:
		host := ""
		if len(flag.Args()) > 0 {
			host = flag.Args()[0]
		}
		err = list(ifIdx, host)
		// suppress NUD_NOARP states from short list? keep simple — always show.
		_ = stateString
	default:
		err = list(ifIdx, "")
	}

	if err != nil {
		fmt.Fprintf(os.Stderr, "arp: %v\n", err)
		os.Exit(1)
	}
}
