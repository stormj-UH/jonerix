// Copyright (C) 2026 Jon-Erik G. Storm, Inc., a California Corporation,
// doing business as LAVA GOAT SOFTWARE.
//
// SPDX-License-Identifier: MIT
//go:build !tinygo || tinygo.enable

// arping sends ARP REQUEST packets and prints replies.
//
// Synopsis:
//
//	arping [-c count] [-i interval] [-w timeout] [-I iface]
//	       [-D | -U] [-q] [-s source] TARGET
//
// Flags follow iputils-arping convention:
//
//	-c COUNT     stop after COUNT requests (default: send forever)
//	-i INTERVAL  seconds between sends (default 1, fractional OK)
//	-w TIMEOUT   total timeout in seconds; exit with 1 if no reply
//	-I IFACE     send on this interface (required)
//	-D           DAD mode — request our own address; success on no reply
//	-U           unsolicited / gratuitous ARP announce
//	-q           quiet (only set exit code)
//	-s SOURCE    sender IP in the ARP header (default: kernel-chosen)
//	TARGET       IPv4 address to probe
//
// We build the Ethernet+ARP frame ourselves (42 bytes; padded to 60 on
// the wire by the NIC if it cares) and send it through an AF_PACKET
// socket via mdlayher/packet. The receive loop matches reply target IP
// against TARGET and prints sender hardware addr + elapsed RTT.
//
// Requires CAP_NET_RAW.
package main

import (
	"bytes"
	"encoding/binary"
	"flag"
	"fmt"
	"net"
	"os"
	"time"

	"github.com/mdlayher/packet"
)

const (
	etherTypeARP = 0x0806
	hwTypeEther  = 1
	pTypeIPv4    = 0x0800
	opRequest    = 1
	opReply      = 2
)

var (
	flagCount    = flag.Int("c", 0, "stop after N requests (0 = forever)")
	flagInterval = flag.Float64("i", 1, "seconds between sends")
	flagTimeout  = flag.Int("w", 0, "exit timeout in seconds (0 = no timeout)")
	flagIface    = flag.String("I", "", "interface to send on (required)")
	flagDAD      = flag.Bool("D", false, "DAD mode (sender IP=0.0.0.0, success on silence)")
	flagAnnounce = flag.Bool("U", false, "gratuitous ARP (sender=target)")
	flagQuiet    = flag.Bool("q", false, "quiet (exit code only)")
	flagSource   = flag.String("s", "", "sender IPv4 in ARP header")
)

func usage() {
	fmt.Fprint(os.Stderr, "Usage: arping [-c N] [-i SEC] [-w SEC] -I IFACE [-D|-U] [-q] [-s SOURCE] TARGET\n")
}

// buildARP constructs the on-wire ARP frame:
//
//	14 bytes Ethernet header + 28 bytes ARP payload = 42 bytes total.
func buildARP(op int, srcHW, dstHW net.HardwareAddr, srcIP, dstIP net.IP) []byte {
	buf := new(bytes.Buffer)
	// Ethernet header
	buf.Write(dstHW) // 6
	buf.Write(srcHW) // 6
	binary.Write(buf, binary.BigEndian, uint16(etherTypeARP))
	// ARP body
	binary.Write(buf, binary.BigEndian, uint16(hwTypeEther))
	binary.Write(buf, binary.BigEndian, uint16(pTypeIPv4))
	buf.WriteByte(6) // HLEN
	buf.WriteByte(4) // PLEN
	binary.Write(buf, binary.BigEndian, uint16(op))
	buf.Write(srcHW)
	buf.Write(srcIP.To4())
	buf.Write(dstHW)
	buf.Write(dstIP.To4())
	return buf.Bytes()
}

// parseARP returns the operation, sender HW, sender IP for an ARP reply
// frame. Returns ok=false for non-ARP / malformed / wrong-length input.
func parseARP(frame []byte) (op uint16, sha net.HardwareAddr, spa net.IP, tpa net.IP, ok bool) {
	if len(frame) < 42 {
		return
	}
	if binary.BigEndian.Uint16(frame[12:14]) != etherTypeARP {
		return
	}
	if binary.BigEndian.Uint16(frame[14:16]) != hwTypeEther {
		return
	}
	if binary.BigEndian.Uint16(frame[16:18]) != pTypeIPv4 {
		return
	}
	op = binary.BigEndian.Uint16(frame[20:22])
	sha = net.HardwareAddr(append([]byte{}, frame[22:28]...))
	spa = net.IPv4(frame[28], frame[29], frame[30], frame[31])
	tpa = net.IPv4(frame[38], frame[39], frame[40], frame[41])
	ok = true
	return
}

func firstIPv4(addrs []net.Addr) net.IP {
	for _, a := range addrs {
		if ipn, ok := a.(*net.IPNet); ok && ipn.IP.To4() != nil {
			return ipn.IP.To4()
		}
	}
	return nil
}

func main() {
	flag.Usage = usage
	flag.Parse()
	if *flagIface == "" || flag.NArg() != 1 {
		usage()
		os.Exit(2)
	}
	target := net.ParseIP(flag.Arg(0))
	if target == nil || target.To4() == nil {
		fmt.Fprintf(os.Stderr, "arping: %q is not an IPv4 address\n", flag.Arg(0))
		os.Exit(2)
	}
	target = target.To4()

	ifi, err := net.InterfaceByName(*flagIface)
	if err != nil {
		fmt.Fprintf(os.Stderr, "arping: interface %q: %v\n", *flagIface, err)
		os.Exit(2)
	}

	var srcIP net.IP
	switch {
	case *flagSource != "":
		srcIP = net.ParseIP(*flagSource)
		if srcIP == nil || srcIP.To4() == nil {
			fmt.Fprintf(os.Stderr, "arping: source %q is not an IPv4 address\n", *flagSource)
			os.Exit(2)
		}
		srcIP = srcIP.To4()
	case *flagDAD:
		srcIP = net.IPv4zero.To4()
	default:
		addrs, _ := ifi.Addrs()
		srcIP = firstIPv4(addrs)
		if srcIP == nil {
			fmt.Fprintf(os.Stderr, "arping: %s has no IPv4 address; pass -s or -D\n", *flagIface)
			os.Exit(2)
		}
	}

	// For -U we pretend to be the target; this is how Linux sends a
	// gratuitous ARP announcement after an IP change.
	if *flagAnnounce {
		srcIP = target
	}

	conn, err := packet.Listen(ifi, packet.Raw, etherTypeARP, nil)
	if err != nil {
		fmt.Fprintf(os.Stderr, "arping: open packet socket: %v\n", err)
		os.Exit(1)
	}
	defer conn.Close()

	bcast := net.HardwareAddr{0xff, 0xff, 0xff, 0xff, 0xff, 0xff}
	// THA in the ARP body for a request is all-zero; the wire-level
	// destination MAC in the Ethernet header is broadcast. buildARP
	// takes the ARP-body THA for its dstHW argument when op == request,
	// so we pass the broadcast there too — the kernel/NIC happily
	// accepts either zero or ff:ff for an ARP request payload.
	frame := buildARP(opRequest, ifi.HardwareAddr, bcast, srcIP, target)

	interval := time.Duration(float64(time.Second) * *flagInterval)
	if interval <= 0 {
		interval = time.Second
	}

	// Hard deadline if -w given.
	var deadline time.Time
	if *flagTimeout > 0 {
		deadline = time.Now().Add(time.Duration(*flagTimeout) * time.Second)
	}

	replies := 0
	sent := 0
	exit := func() {
		// iputils-arping returns 0 if at least one reply was received
		// in normal mode, or if no reply was received in -D mode.
		if *flagDAD {
			if replies == 0 {
				os.Exit(0)
			}
			os.Exit(1)
		}
		if replies == 0 {
			os.Exit(1)
		}
		os.Exit(0)
	}

	// Send loop runs in foreground, reads piggyback after each send.
	buf := make([]byte, 1500)
	for {
		if *flagCount > 0 && sent >= *flagCount {
			break
		}
		t0 := time.Now()
		if _, err := conn.WriteTo(frame, &packet.Addr{HardwareAddr: bcast}); err != nil {
			fmt.Fprintf(os.Stderr, "arping: write: %v\n", err)
			os.Exit(1)
		}
		sent++
		if !*flagQuiet {
			fmt.Printf("ARPING %s from %s %s\n", target, srcIP, ifi.Name)
		}

		// Read until interval expires.
		readUntil := t0.Add(interval)
		for {
			now := time.Now()
			if !deadline.IsZero() && now.After(deadline) {
				exit()
			}
			d := readUntil.Sub(now)
			if d <= 0 {
				break
			}
			_ = conn.SetReadDeadline(time.Now().Add(d))
			n, _, err := conn.ReadFrom(buf)
			if err != nil {
				// Timeout or transient — fall through to next send.
				break
			}
			op, sha, spa, _, ok := parseARP(buf[:n])
			if !ok || op != opReply {
				continue
			}
			if !spa.Equal(target) {
				continue
			}
			rtt := time.Since(t0)
			replies++
			if !*flagQuiet {
				fmt.Printf("60 bytes from %s (%s): index=%d time=%.3f ms\n",
					sha, spa, sent, float64(rtt.Microseconds())/1000.0)
			}
			if *flagCount == 0 {
				continue
			}
		}
	}

	if !*flagQuiet {
		fmt.Printf("Sent %d probes (%d replies)\n", sent, replies)
	}
	exit()
}
