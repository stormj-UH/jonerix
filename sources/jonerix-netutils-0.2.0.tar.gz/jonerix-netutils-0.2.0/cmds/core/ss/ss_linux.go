// Copyright (C) 2026 Jon-Erik G. Storm, Inc., a California Corporation,
// doing business as LAVA GOAT SOFTWARE.
//
// SPDX-License-Identifier: MIT
//go:build !tinygo || tinygo.enable

// ss enumerates kernel sockets via sock_diag netlink.
//
// Synopsis:
//
//	ss [-t] [-u] [-x] [-l] [-a] [-n] [-4 | -6]
//
//	-t  TCP   (default if no -u/-x)
//	-u  UDP
//	-x  UNIX
//	-l  only listening (TCP) / unconnected (UDP)
//	-a  all states (TCP); default shows only ESTABLISHED + LISTEN
//	-n  numeric (no service-name lookup)
//	-4  IPv4 only
//	-6  IPv6 only
//
// We dump via vishvananda/netlink's SocketDiag{TCP,UDP} and
// UnixSocketDiag helpers, which wrap the SOCK_DIAG_BY_FAMILY netlink
// request. This is the same interface iproute2's ss uses.
package main

import (
	"flag"
	"fmt"
	"net"
	"os"
	"sort"
	"strconv"

	"github.com/vishvananda/netlink"
	"golang.org/x/sys/unix"
)

var (
	flagTCP     = flag.Bool("t", false, "TCP sockets")
	flagUDP     = flag.Bool("u", false, "UDP sockets")
	flagUNIX    = flag.Bool("x", false, "UNIX-domain sockets")
	flagListen  = flag.Bool("l", false, "listening sockets only")
	flagAll     = flag.Bool("a", false, "include non-LISTEN/ESTABLISHED TCP states")
	flagNumeric = flag.Bool("n", false, "no service-name resolution")
	flag4       = flag.Bool("4", false, "IPv4 only")
	flag6       = flag.Bool("6", false, "IPv6 only")
)

// tcpState mirrors include/net/tcp_states.h.
var tcpState = []string{
	0:                       "UNKNOWN",
	unix.BPF_TCP_ESTABLISHED: "ESTAB",
	unix.BPF_TCP_SYN_SENT:    "SYN-SENT",
	unix.BPF_TCP_SYN_RECV:    "SYN-RECV",
	unix.BPF_TCP_FIN_WAIT1:   "FIN-WAIT-1",
	unix.BPF_TCP_FIN_WAIT2:   "FIN-WAIT-2",
	unix.BPF_TCP_TIME_WAIT:   "TIME-WAIT",
	unix.BPF_TCP_CLOSE:       "CLOSE",
	unix.BPF_TCP_CLOSE_WAIT:  "CLOSE-WAIT",
	unix.BPF_TCP_LAST_ACK:    "LAST-ACK",
	unix.BPF_TCP_LISTEN:      "LISTEN",
	unix.BPF_TCP_CLOSING:     "CLOSING",
}

func stateName(s uint8) string {
	if int(s) < len(tcpState) && tcpState[s] != "" {
		return tcpState[s]
	}
	return fmt.Sprintf("STATE-%d", s)
}

func formatAddr(ip net.IP, port uint16, numeric bool) string {
	host := "*"
	if ip != nil && !ip.IsUnspecified() {
		host = ip.String()
	}
	p := fmt.Sprintf("%d", port)
	if !numeric && port != 0 {
		// LookupPort sometimes returns the protocol's well-known name
		// (http, ssh, dns, ...). Cheap and useful for the LISTEN case.
		if name, err := net.LookupPort("tcp", p); err == nil && name != int(port) {
			p = fmt.Sprintf("%d", port)
		}
	}
	if ip != nil && ip.To4() == nil && !ip.IsUnspecified() {
		// IPv6: bracket the host
		return fmt.Sprintf("[%s]:%s", host, p)
	}
	return fmt.Sprintf("%s:%s", host, p)
}

type sockRow struct {
	state                  string
	recvQ, sendQ           uint32
	local, peer            string
	proto                  string
}

func collectTCP(family uint8, listen, all, numeric bool) ([]sockRow, error) {
	socks, err := netlink.SocketDiagTCP(family)
	if err != nil {
		return nil, err
	}
	var out []sockRow
	for _, s := range socks {
		if listen && s.State != unix.BPF_TCP_LISTEN {
			continue
		}
		if !listen && !all {
			if s.State != unix.BPF_TCP_ESTABLISHED && s.State != unix.BPF_TCP_LISTEN {
				continue
			}
		}
		out = append(out, sockRow{
			state:  stateName(s.State),
			recvQ:  s.RQueue,
			sendQ:  s.WQueue,
			local:  formatAddr(s.ID.Source, s.ID.SourcePort, numeric),
			peer:   formatAddr(s.ID.Destination, s.ID.DestinationPort, numeric),
			proto:  "tcp",
		})
	}
	return out, nil
}

func collectUDP(family uint8, listen, numeric bool) ([]sockRow, error) {
	socks, err := netlink.SocketDiagUDP(family)
	if err != nil {
		return nil, err
	}
	var out []sockRow
	for _, s := range socks {
		// "Listening" UDP = unconnected (peer == 0.0.0.0:0).
		if listen && s.ID.DestinationPort != 0 {
			continue
		}
		out = append(out, sockRow{
			state:  "UNCONN",
			recvQ:  s.RQueue,
			sendQ:  s.WQueue,
			local:  formatAddr(s.ID.Source, s.ID.SourcePort, numeric),
			peer:   formatAddr(s.ID.Destination, s.ID.DestinationPort, numeric),
			proto:  "udp",
		})
	}
	return out, nil
}

func collectUNIX(listen bool) ([]sockRow, error) {
	socks, err := netlink.UnixSocketDiag()
	if err != nil {
		return nil, err
	}
	var out []sockRow
	for _, s := range socks {
		if listen && s.State != unix.BPF_TCP_LISTEN {
			continue
		}
		st := "u_str"
		switch s.Type {
		case unix.SOCK_STREAM:
			st = "u_str"
		case unix.SOCK_DGRAM:
			st = "u_dgr"
		case unix.SOCK_SEQPACKET:
			st = "u_seq"
		}
		// Path attribute isn't exposed by the vendored helper; report
		// inode only. Good enough to confirm a unix socket exists
		// (paths visible via /proc/net/unix).
		out = append(out, sockRow{
			state:  stateName(s.State),
			local:  fmt.Sprintf("[inode:%d]", s.INode),
			peer:   "*",
			proto:  st,
		})
	}
	return out, nil
}

func printRows(rows []sockRow) {
	sort.SliceStable(rows, func(i, j int) bool {
		if rows[i].proto != rows[j].proto {
			return rows[i].proto < rows[j].proto
		}
		return rows[i].local < rows[j].local
	})
	fmt.Printf("%-6s %-12s %-6s %-6s %-30s %-30s\n",
		"Netid", "State", "Recv-Q", "Send-Q", "Local Address:Port", "Peer Address:Port")
	for _, r := range rows {
		fmt.Printf("%-6s %-12s %-6d %-6d %-30s %-30s\n",
			r.proto, r.state, r.recvQ, r.sendQ, r.local, r.peer)
	}
}

func main() {
	flag.Parse()

	// Default to TCP if nothing else picked.
	if !*flagTCP && !*flagUDP && !*flagUNIX {
		*flagTCP = true
	}

	// Family filter.
	families := []uint8{unix.AF_INET, unix.AF_INET6}
	switch {
	case *flag4 && !*flag6:
		families = []uint8{unix.AF_INET}
	case *flag6 && !*flag4:
		families = []uint8{unix.AF_INET6}
	}

	var all []sockRow
	if *flagTCP {
		for _, fam := range families {
			rows, err := collectTCP(fam, *flagListen, *flagAll, *flagNumeric)
			if err != nil {
				fmt.Fprintf(os.Stderr, "ss: tcp(%d): %v\n", fam, err)
				continue
			}
			all = append(all, rows...)
		}
	}
	if *flagUDP {
		for _, fam := range families {
			rows, err := collectUDP(fam, *flagListen, *flagNumeric)
			if err != nil {
				fmt.Fprintf(os.Stderr, "ss: udp(%d): %v\n", fam, err)
				continue
			}
			all = append(all, rows...)
		}
	}
	if *flagUNIX {
		rows, err := collectUNIX(*flagListen)
		if err != nil {
			fmt.Fprintf(os.Stderr, "ss: unix: %v\n", err)
		} else {
			all = append(all, rows...)
		}
	}

	printRows(all)

	// Keep "go vet" quiet about unused imports if a future refactor
	// drops a code path.
	_ = strconv.Itoa
}
