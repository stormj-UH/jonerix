//! Permissive-license `lsusb` drop-in for jonerix.
//!
//! The whole implementation walks `/sys/bus/usb/devices/` and
//! formats one line per device matching the layout upstream
//! `lsusb` prints in its default mode:
//!
//!   Bus 001 Device 002: ID 046d:c52b Logitech, Inc. Unifying Receiver
//!
//! There is no libusb dependency. sysfs is a public kernel
//! interface documented at Documentation/ABI/stable/sysfs-bus-usb;
//! every field we read is one of the stable ones.
//!
//! Flags:
//!   -v          verbose — dump each device's descriptors file as
//!               annotated hex (a minimal version — full lsusb-v
//!               pretty-printing is a follow-up).
//!   -s BUS:DEV  filter to one device
//!   -d VID:PID  filter to one vendor/product pair
//!   -t          tree view (bus/device hierarchy)
//!   --version   print version info
//!
//! Vendor / product names come from a plain-text database at one
//! of the standard locations:
//!   /usr/share/hwdata/usb.ids
//!   /usr/share/misc/usb.ids
//!   /usr/share/usb.ids
//! The file itself is public-domain data maintained by the
//! linux-usb community; we only read it at runtime.

use std::collections::HashMap;
use std::fs;
use std::path::{Path, PathBuf};
use std::process::ExitCode;

const USB_IDS_PATHS: &[&str] = &[
    "/usr/share/hwdata/usb.ids",
    "/usr/share/misc/usb.ids",
    "/usr/share/usb.ids",
];

#[derive(Debug)]
struct UsbDevice {
    sysfs_path: PathBuf,
    bus:        u16,
    dev:        u16,
    vid:        u16,
    pid:        u16,
    manufacturer: Option<String>,
    product:      Option<String>,
    serial:       Option<String>,
    /// For the `-t` tree view. Parent's `busnum:devnum` pair, or
    /// None for a root hub.
    parent_path: Option<PathBuf>,
    speed:      Option<String>,
    /// How many hops down from the root hub this device sits.
    /// Root hubs are level 0.
    level:      u8,
}

struct IdsDb {
    vendor:  HashMap<u16, String>,
    product: HashMap<(u16, u16), String>,
}

impl IdsDb {
    fn empty() -> Self { IdsDb { vendor: HashMap::new(), product: HashMap::new() } }

    fn load_first_available() -> Self {
        for path in USB_IDS_PATHS {
            if let Ok(text) = fs::read_to_string(path) {
                return Self::parse(&text);
            }
        }
        Self::empty()
    }

    /// Parse the simple line-oriented usb.ids format:
    ///   VVVV  Vendor name
    ///   \tPPPP  Product name
    ///   \t\tIII  Interface / endpoint (ignored for top-level lsusb)
    /// Comments start with '#'; anything past a CLASS section
    /// block ("C xx  Class name") is also not needed here.
    fn parse(text: &str) -> Self {
        let mut db = IdsDb::empty();
        let mut cur_vendor: Option<u16> = None;
        for raw in text.lines() {
            let line = raw.trim_end_matches(['\r', '\n']);
            if line.is_empty() || line.starts_with('#') { continue; }
            // Class / HID / language blocks start with a single
            // letter + space at the left margin. Reset vendor
            // tracking when we hit one so we don't accidentally
            // pick up "xx  Thing" rows as products.
            if line.len() >= 2
                && line.as_bytes()[0].is_ascii_alphabetic()
                && line.as_bytes()[1] == b' '
            {
                cur_vendor = None;
                continue;
            }
            if line.starts_with('\t') {
                let rest = line.trim_start_matches('\t');
                let depth = line.len() - rest.len();
                if depth != 1 { continue; }
                if let Some(v) = cur_vendor {
                    if let Some((id_s, name)) = split_id_and_name(rest) {
                        if let Ok(pid) = u16::from_str_radix(id_s, 16) {
                            db.product.insert((v, pid), name.to_string());
                        }
                    }
                }
            } else {
                // Top-level vendor line.
                if let Some((id_s, name)) = split_id_and_name(line) {
                    if let Ok(vid) = u16::from_str_radix(id_s, 16) {
                        db.vendor.insert(vid, name.to_string());
                        cur_vendor = Some(vid);
                    }
                }
            }
        }
        db
    }

    fn vendor_name(&self, vid: u16) -> Option<&str> { self.vendor.get(&vid).map(|s| s.as_str()) }
    fn product_name(&self, vid: u16, pid: u16) -> Option<&str> {
        self.product.get(&(vid, pid)).map(|s| s.as_str())
    }
}

fn split_id_and_name(line: &str) -> Option<(&str, &str)> {
    // usb.ids separates the hex id from the name with at least two
    // spaces. Find the first run of 2+ spaces.
    let bytes = line.as_bytes();
    let mut i = 0;
    while i + 1 < bytes.len() {
        if bytes[i] == b' ' && bytes[i + 1] == b' ' {
            let id = &line[..i];
            let name = line[i..].trim_start();
            return Some((id, name));
        }
        i += 1;
    }
    None
}

fn main() -> ExitCode {
    let args: Vec<String> = std::env::args().skip(1).collect();
    let mut verbose = false;
    let mut tree = false;
    let mut filter_sd: Option<(u16, u16)> = None;   // bus:dev
    let mut filter_vp: Option<(u16, u16)> = None;   // vid:pid
    let mut i = 0;
    while i < args.len() {
        let a = &args[i];
        match a.as_str() {
            "-v" | "--verbose" => verbose = true,
            "-t" | "--tree" => tree = true,
            "-s" => {
                i += 1;
                match args.get(i).and_then(|s| parse_bus_dev(s)) {
                    Some(bd) => filter_sd = Some(bd),
                    None => { eprintln!("lsusb: bad -s value"); return ExitCode::from(2); }
                }
            }
            "-d" => {
                i += 1;
                match args.get(i).and_then(|s| parse_vid_pid(s)) {
                    Some(vp) => filter_vp = Some(vp),
                    None => { eprintln!("lsusb: bad -d value"); return ExitCode::from(2); }
                }
            }
            "--version" | "-V" => {
                println!("lsusb (jonerix) 0.1.1 — permissive drop-in, sysfs backend");
                return ExitCode::from(0);
            }
            "-h" | "--help" => {
                print_help();
                return ExitCode::from(0);
            }
            other => {
                eprintln!("lsusb: unknown option '{other}'");
                return ExitCode::from(2);
            }
        }
        i += 1;
    }

    let db = IdsDb::load_first_available();

    let mut devices = match scan_sysfs() {
        Ok(ds) => ds,
        Err(e) => {
            eprintln!("lsusb: {e}");
            return ExitCode::from(1);
        }
    };
    // Upstream sorts by (bus, dev) for the default view.
    devices.sort_by_key(|d| (d.bus, d.dev));

    let devices: Vec<UsbDevice> = devices
        .into_iter()
        .filter(|d| filter_sd.map_or(true, |(b, dv)| d.bus == b && d.dev == dv))
        .filter(|d| filter_vp.map_or(true, |(v, p)| d.vid == v && d.pid == p))
        .collect();

    if tree {
        print_tree(&devices, &db);
    } else {
        for d in &devices {
            print_default_line(d, &db);
            if verbose {
                print_verbose(d);
            }
        }
    }

    ExitCode::from(0)
}

fn parse_bus_dev(s: &str) -> Option<(u16, u16)> {
    let (a, b) = s.split_once(':')?;
    Some((a.parse().ok()?, b.parse().ok()?))
}
fn parse_vid_pid(s: &str) -> Option<(u16, u16)> {
    let (a, b) = s.split_once(':')?;
    Some((u16::from_str_radix(a, 16).ok()?, u16::from_str_radix(b, 16).ok()?))
}

fn print_help() {
    println!("usage: lsusb [-v] [-t] [-s BUS:DEV] [-d VID:PID]");
    println!("       lsusb --version");
    println!("       lsusb -h");
}

/// Walk /sys/bus/usb/devices/ and pull one `UsbDevice` per
/// directory entry that looks like a USB device node. Skip the
/// symlinks sysfs creates for each interface ("1-1:1.0" style).
fn scan_sysfs() -> std::io::Result<Vec<UsbDevice>> {
    let root = Path::new("/sys/bus/usb/devices");
    if !root.is_dir() {
        return Err(std::io::Error::new(std::io::ErrorKind::NotFound,
            "USB sysfs tree /sys/bus/usb/devices not present — kernel USB support off?"));
    }
    let mut out = Vec::new();
    for entry in fs::read_dir(root)? {
        let entry = match entry {
            Ok(e) => e,
            Err(_) => continue, // B19: skip unreadable entries gracefully
        };
        let name_os = entry.file_name();
        let name = match name_os.to_str() { Some(s) => s, None => continue };
        // Entries with ':' are interface sub-nodes, not devices.
        if name.contains(':') { continue; }
        // B19 fix: fs::metadata follows symlinks so is_symlink() is always
        // false (dead code). Use is_dir() which returns false for dangling
        // symlinks instead of propagating ENOENT and aborting the scan.
        if !entry.path().is_dir() { continue; }
        // Canonicalise via the symlink so we get the real device
        // dir under /sys/devices/... — needed for the tree view
        // which reads parent directories.
        let real = fs::canonicalize(entry.path()).unwrap_or_else(|_| entry.path());
        if let Some(dev) = read_device(&real) {
            out.push(dev);
        }
    }
    Ok(out)
}

fn read_device(path: &Path) -> Option<UsbDevice> {
    let busnum = read_u16_trim(&path.join("busnum"))?;
    let devnum = read_u16_trim(&path.join("devnum"))?;
    let vid    = read_u16_hex(&path.join("idVendor"))?;
    let pid    = read_u16_hex(&path.join("idProduct"))?;
    let manufacturer = read_string(&path.join("manufacturer"));
    let product      = read_string(&path.join("product"));
    let serial       = read_string(&path.join("serial"));
    let speed        = read_string(&path.join("speed"));

    // The parent directory is the upstream hub. For root hubs
    // there is no usb-parent — the parent dir isn't itself a
    // USB device (it's the controller node). We detect that by
    // checking whether the parent has a `busnum` file.
    let parent_path = path.parent().and_then(|p| {
        if p.join("busnum").is_file() { Some(p.to_path_buf()) } else { None }
    });
    let level = compute_level(path);

    Some(UsbDevice {
        sysfs_path: path.to_path_buf(),
        bus: busnum, dev: devnum, vid, pid,
        manufacturer, product, serial, parent_path, speed, level,
    })
}

fn compute_level(path: &Path) -> u8 {
    let mut cur = path.to_path_buf();
    let mut n = 0u8;
    while let Some(p) = cur.parent() {
        if !p.join("busnum").is_file() { return n; }
        cur = p.to_path_buf();
        n = n.saturating_add(1);
    }
    n
}

fn read_string(p: &Path) -> Option<String> {
    fs::read_to_string(p).ok().map(|s| s.trim().to_string()).filter(|s| !s.is_empty())
}
fn read_u16_trim(p: &Path) -> Option<u16> {
    fs::read_to_string(p).ok()?.trim().parse().ok()
}
fn read_u16_hex(p: &Path) -> Option<u16> {
    u16::from_str_radix(fs::read_to_string(p).ok()?.trim(), 16).ok()
}

fn print_default_line(d: &UsbDevice, db: &IdsDb) {
    // Name formatting matches upstream's default: vendor name
    // from usb.ids, a space, product name. When the IDs database
    // isn't present fall back to the sysfs-reported manufacturer
    // / product strings so we still print something useful.
    let vname = db.vendor_name(d.vid)
        .map(|s| s.to_string())
        .or_else(|| d.manufacturer.clone())
        .unwrap_or_default();
    let pname = db.product_name(d.vid, d.pid)
        .map(|s| s.to_string())
        .or_else(|| d.product.clone())
        .unwrap_or_default();
    let label = match (vname.as_str(), pname.as_str()) {
        ("", "") => String::new(),
        (v, "") => v.to_string(),
        ("", p) => p.to_string(),
        (v, p) => format!("{v} {p}"),
    };
    println!(
        "Bus {:03} Device {:03}: ID {:04x}:{:04x} {}",
        d.bus, d.dev, d.vid, d.pid, label,
    );
}

fn print_verbose(d: &UsbDevice) {
    // Minimal verbose mode: dump the supplementary sysfs fields
    // we already collected plus an annotated hexdump of the
    // descriptors file. Full upstream-lsusb-style decoding
    // (device → config → interface → endpoint descriptors with
    // per-field labels) is a follow-up — it needs a parser for
    // the USB standard descriptor types.
    if let Some(m) = &d.manufacturer { println!("  iManufacturer           {m}"); }
    if let Some(p) = &d.product      { println!("  iProduct                {p}"); }
    if let Some(s) = &d.serial       { println!("  iSerial                 {s}"); }
    if let Some(s) = &d.speed        { println!("  speed                   {s} Mbps"); }
    if let Ok(desc) = fs::read(d.sysfs_path.join("descriptors")) {
        println!("  Raw descriptors ({} bytes):", desc.len());
        hexdump(&desc, "    ");
    }
}

fn hexdump(bytes: &[u8], prefix: &str) {
    for (i, chunk) in bytes.chunks(16).enumerate() {
        let mut line = format!("{prefix}{:04x}:", i * 16);
        for b in chunk { line.push_str(&format!(" {b:02x}")); }
        // Pad so the ASCII column starts in the same place on
        // every line even for short tails.
        for _ in chunk.len()..16 { line.push_str("   "); }
        line.push_str("  ");
        for &b in chunk {
            line.push(if (0x20..0x7F).contains(&b) { b as char } else { '.' });
        }
        println!("{line}");
    }
}

fn print_tree(devs: &[UsbDevice], db: &IdsDb) {
    // Tree view: root hubs at level 0, then children of each
    // parent bus path indented per level. Sort children by
    // devnum within each bus for deterministic output.
    //
    // Usage shape mirrors upstream's `lsusb -t`:
    //   /:  Bus 001.Port 001: Dev 001, Class=root_hub, Driver=xhci_hcd/16p, ...
    //       |__ Port 002: Dev 002, ...
    //
    // We don't emit the Driver=/Class= columns yet (they live in
    // sysfs at `driver` symlinks + `bDeviceClass`), just the
    // topology with vendor/product labels so the output is
    // useful for a first cut.
    let mut by_bus: std::collections::BTreeMap<u16, Vec<&UsbDevice>> = Default::default();
    for d in devs { by_bus.entry(d.bus).or_default().push(d); }
    for (bus, mut list) in by_bus {
        list.sort_by_key(|d| d.dev);
        // B21 fix: don't skip the bus if the root hub was filtered out.
        // When the root hub is present, print it as the bus header.
        // Otherwise, print matched devices at their own level.
        let root_dev: Option<u16> = list
            .iter()
            .find(|d| d.parent_path.is_none())
            .map(|d| d.dev);
        if root_dev.is_none() {
            // Root hub was filtered out — synthesise a bus header line.
            println!("/:  Bus {:03}.Dev ???: (root hub filtered)", bus);
        }
        for d in &list {
            if Some(d.dev) == root_dev {
                println!("/:  Bus {:03}.Dev {:03}: {}", bus, d.dev, label_of(d, db));
            } else {
                let indent = "    ".repeat(d.level as usize);
                println!("{indent}|__ Dev {:03}: {}", d.dev, label_of(d, db));
            }
        }
    }
}

fn label_of(d: &UsbDevice, db: &IdsDb) -> String {
    let v = db.vendor_name(d.vid).map(str::to_string).or_else(|| d.manufacturer.clone());
    let p = db.product_name(d.vid, d.pid).map(str::to_string).or_else(|| d.product.clone());
    let name = match (v.as_deref().unwrap_or(""), p.as_deref().unwrap_or("")) {
        ("", "") => String::new(),
        (v, "") => v.to_string(),
        ("", p) => p.to_string(),
        (v, p) => format!("{v} {p}"),
    };
    format!("ID {:04x}:{:04x} {}", d.vid, d.pid, name)
}

// ------------------------------------------------------------
//  Unit tests — coverage that doesn't require real USB hardware.
// ------------------------------------------------------------

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parses_simple_usb_ids_block() {
        let ids = "\
# comment
046d  Logitech, Inc.
\tc52b  Unifying Receiver
\tc077  M105 Optical Mouse
1d6b  Linux Foundation
\t0003  3.0 root hub
";
        let db = IdsDb::parse(ids);
        assert_eq!(db.vendor_name(0x046d), Some("Logitech, Inc."));
        assert_eq!(db.product_name(0x046d, 0xc52b), Some("Unifying Receiver"));
        assert_eq!(db.product_name(0x046d, 0xc077), Some("M105 Optical Mouse"));
        assert_eq!(db.vendor_name(0x1d6b), Some("Linux Foundation"));
        assert_eq!(db.product_name(0x1d6b, 0x0003), Some("3.0 root hub"));
    }

    #[test]
    fn split_id_and_name_handles_multiple_spaces() {
        assert_eq!(split_id_and_name("046d  Logitech"), Some(("046d", "Logitech")));
        assert_eq!(split_id_and_name("\tc52b  Unifying Receiver"),
                   Some(("\tc52b", "Unifying Receiver")));
    }

    #[test]
    fn ignores_class_header_block() {
        // A 'C xx  Name' row should reset the vendor-tracking
        // cursor so subsequent indented lines don't get attached
        // to the last vendor.
        let ids = "\
0001  First Vendor
\t0100  Its Product
C 00  Class marker
\t00  Unused — shouldn't parse as (0001, 0x00)
";
        let db = IdsDb::parse(ids);
        assert_eq!(db.product_name(0x0001, 0x0100), Some("Its Product"));
        // The second indented row must not have been attached to
        // vendor 0x0001.
        assert_eq!(db.product_name(0x0001, 0x0000), None);
    }

    #[test]
    fn parse_bus_dev_and_vid_pid() {
        assert_eq!(parse_bus_dev("001:002"), Some((1, 2)));
        assert_eq!(parse_bus_dev("nope"), None);
        assert_eq!(parse_vid_pid("046d:c52b"), Some((0x046d, 0xc52b)));
        assert_eq!(parse_vid_pid("zz:pp"), None);
    }
}
