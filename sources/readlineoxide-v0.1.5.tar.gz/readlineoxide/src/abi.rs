#![allow(non_camel_case_types)]

use std::ffi::CStr;
use std::fs::{self, OpenOptions};
use std::io::{self, BufRead, Write};
use std::os::raw::{c_char, c_int, c_long, c_ulong, c_void};
use std::ptr;
use std::sync::Mutex;

type rl_command_func_t = Option<extern "C" fn(c_int, c_int) -> c_int>;
type rl_compentry_func_t = Option<extern "C" fn(*const c_char, c_int) -> *mut c_char>;
type rl_completion_func_t = Option<extern "C" fn(*const c_char, c_int, c_int) -> *mut *mut c_char>;
type rl_callback_handler_t = Option<extern "C" fn(*mut c_char)>;
type rl_hook_func_t = Option<extern "C" fn() -> c_int>;
type rl_completion_word_break_hook_t = Option<extern "C" fn() -> *mut c_char>;
type rl_getc_func_t = Option<extern "C" fn(*mut c_void) -> c_int>;
type rl_compdisp_func_t = Option<extern "C" fn(*mut *mut c_char, c_int, c_int)>;
type rl_voidfunc_t = Option<extern "C" fn()>;
type rl_vintfunc_t = Option<extern "C" fn(c_int)>;
type rl_directory_completion_hook_t = Option<extern "C" fn(*mut *mut c_char) -> c_int>;
type rl_filename_quoting_func_t =
    Option<extern "C" fn(*mut c_char, c_int, *mut c_char) -> *mut c_char>;
type rl_filename_dequoting_func_t = Option<extern "C" fn(*mut c_char, c_int) -> *mut c_char>;
type rl_macro_print_func_t =
    Option<extern "C" fn(*const c_char, *const c_char, c_int, *const c_char)>;

#[repr(C)]
pub struct HIST_ENTRY {
    pub line: *mut c_char,
    pub timestamp: *mut c_char,
    pub data: *mut c_void,
}

#[repr(C)]
pub struct HISTORY_STATE {
    pub entries: *mut *mut HIST_ENTRY,
    pub offset: c_int,
    pub length: c_int,
    pub size: c_int,
    pub flags: c_int,
}

extern "C" {
    fn malloc(size: usize) -> *mut c_void;
    fn free(ptr: *mut c_void);
    fn fdopen(fd: c_int, mode: *const c_char) -> *mut c_void;
    fn fgetc(stream: *mut c_void) -> c_int;
}

const RL_VERSION_BYTES: &[u8] = b"8.3\0";
const WORD_BREAK_BYTES: &[u8] = b" \t\n\"\\'`@$><=;|&{(\0";
const QUOTE_BYTES: &[u8] = b"\"'\0";
const OFF_BYTES: &[u8] = b"off\0";
const READERR: c_int = -2;

#[no_mangle]
pub static mut rl_readline_name: *mut c_char = ptr::null_mut();
#[no_mangle]
pub static mut rl_terminal_name: *mut c_char = ptr::null_mut();
#[no_mangle]
pub static mut rl_library_version: *mut c_char = RL_VERSION_BYTES.as_ptr() as *mut c_char;
#[no_mangle]
pub static mut rl_readline_version: c_int = 0x0803;
#[no_mangle]
pub static mut rl_gnu_readline_p: c_int = 1;
#[no_mangle]
pub static mut rl_prompt: *mut c_char = ptr::null_mut();
#[no_mangle]
pub static mut rl_line_buffer: *mut c_char = ptr::null_mut();
#[no_mangle]
pub static mut rl_point: c_int = 0;
#[no_mangle]
pub static mut rl_end: c_int = 0;
#[no_mangle]
pub static mut rl_done: c_int = 0;
#[no_mangle]
pub static mut rl_eof_found: c_int = 0;
#[no_mangle]
pub static mut rl_already_prompted: c_int = 0;
#[no_mangle]
pub static mut rl_num_chars_to_read: c_int = 0;
#[no_mangle]
pub static mut rl_readline_state: c_ulong = 0;
#[no_mangle]
pub static mut rl_completion_append_character: c_int = b' ' as c_int;
#[no_mangle]
pub static mut rl_completion_suppress_append: c_int = 0;
#[no_mangle]
pub static mut rl_completion_type: c_int = b'\t' as c_int;
#[no_mangle]
pub static mut rl_attempted_completion_over: c_int = 0;
#[no_mangle]
pub static mut rl_completion_query_items: c_int = 100;
#[no_mangle]
pub static mut rl_catch_signals: c_int = 1;
#[no_mangle]
pub static mut rl_catch_sigwinch: c_int = 1;
#[no_mangle]
pub static mut rl_basic_word_break_characters: *mut c_char =
    WORD_BREAK_BYTES.as_ptr() as *mut c_char;
#[no_mangle]
pub static mut rl_completer_word_break_characters: *mut c_char =
    WORD_BREAK_BYTES.as_ptr() as *mut c_char;
#[no_mangle]
pub static mut rl_basic_quote_characters: *mut c_char = QUOTE_BYTES.as_ptr() as *mut c_char;
#[no_mangle]
pub static mut rl_completer_quote_characters: *mut c_char = ptr::null_mut();
#[no_mangle]
pub static mut rl_filename_quote_characters: *mut c_char = ptr::null_mut();
#[no_mangle]
pub static mut rl_filename_completion_desired: c_int = 0;
#[no_mangle]
pub static mut rl_ignore_completion_duplicates: c_int = 1;
#[no_mangle]
pub static mut rl_sort_completion_matches: c_int = 1;
#[no_mangle]
pub static mut rl_visible_stats: c_int = 0;
#[no_mangle]
pub static mut _rl_complete_mark_directories: c_int = 1;
#[no_mangle]
pub static mut _rl_completion_prefix_display_length: c_int = 0;
#[no_mangle]
pub static mut _rl_print_completions_horizontally: c_int = 0;
#[no_mangle]
pub static mut _rl_term_autowrap: c_int = 1;
#[no_mangle]
pub static mut rl_attempted_completion_function: rl_completion_func_t = None;
#[no_mangle]
pub static mut rl_completion_word_break_hook: rl_completion_word_break_hook_t = None;
#[no_mangle]
pub static mut rl_completion_display_matches_hook: rl_compdisp_func_t = None;
#[no_mangle]
pub static mut rl_directory_completion_hook: rl_directory_completion_hook_t = None;
#[no_mangle]
pub static mut rl_filename_quoting_function: rl_filename_quoting_func_t = None;
#[no_mangle]
pub static mut rl_filename_dequoting_function: rl_filename_dequoting_func_t = None;
#[no_mangle]
pub static mut rl_instream: *mut c_void = ptr::null_mut();
#[no_mangle]
pub static mut rl_outstream: *mut c_void = ptr::null_mut();
#[no_mangle]
pub static mut rl_startup_hook: rl_hook_func_t = None;
#[no_mangle]
pub static mut rl_pre_input_hook: rl_hook_func_t = None;
#[no_mangle]
pub static mut rl_event_hook: rl_hook_func_t = None;
#[no_mangle]
pub static mut rl_signal_event_hook: rl_hook_func_t = None;
#[no_mangle]
pub static mut rl_timeout_event_hook: rl_hook_func_t = None;
#[no_mangle]
pub static mut rl_input_available_hook: rl_hook_func_t = None;
#[no_mangle]
pub static mut rl_getc_function: rl_getc_func_t = None;
#[no_mangle]
pub static mut rl_deprep_term_function: rl_voidfunc_t = None;
#[no_mangle]
pub static mut rl_prep_term_function: rl_vintfunc_t = None;
#[no_mangle]
pub static mut rl_macro_display_hook: rl_macro_print_func_t = None;
#[no_mangle]
pub static mut rl_executing_keymap: *mut c_void = ptr::null_mut();
#[no_mangle]
pub static mut rl_binding_keymap: *mut c_void = ptr::null_mut();
#[no_mangle]
pub static mut emacs_standard_keymap: *mut c_void = ptr::null_mut();
#[no_mangle]
pub static mut emacs_meta_keymap: *mut c_void = ptr::null_mut();
#[no_mangle]
pub static mut emacs_ctlx_keymap: *mut c_void = ptr::null_mut();
#[no_mangle]
pub static mut vi_movement_keymap: *mut c_void = ptr::null_mut();
#[no_mangle]
pub static mut vi_insertion_keymap: *mut c_void = ptr::null_mut();

#[no_mangle]
pub static mut history_base: c_int = 1;
#[no_mangle]
pub static mut history_length: c_int = 0;
#[no_mangle]
pub static mut history_max_entries: c_int = 0;
#[no_mangle]
pub static mut history_offset: c_int = 0;
#[no_mangle]
pub static mut history_write_timestamps: c_int = 0;

static mut CURRENT_KEYMAP: *mut c_void = ptr::null_mut();
static mut BUILTIN_KEYMAP: *mut c_void = ptr::null_mut();
static mut TIMEOUT_SECONDS: c_int = 0;
static mut TIMEOUT_USECONDS: c_int = 0;
static mut SCREEN_ROWS: c_int = 24;
static mut SCREEN_COLS: c_int = 80;

static EDITOR: Mutex<EditorConfig> = Mutex::new(EditorConfig {
    ctrl_a_macro: Vec::new(),
    ctrl_b_backward: true,
    tab_completes: false,
});

struct EditorConfig {
    ctrl_a_macro: Vec<u8>,
    ctrl_b_backward: bool,
    tab_completes: bool,
}

static CALLBACK: Mutex<CallbackState> = Mutex::new(CallbackState {
    prompt: ptr::null_mut(),
    handler: None,
    prompt_shown: false,
});

struct CallbackState {
    prompt: *mut c_char,
    handler: rl_callback_handler_t,
    prompt_shown: bool,
}

unsafe impl Send for CallbackState {}

static HISTORY: Mutex<History> = Mutex::new(History {
    entries: Vec::new(),
    list: Vec::new(),
    offset: 0,
    max_entries: 0,
    stifled: false,
});

struct History {
    entries: Vec<Box<HIST_ENTRY>>,
    list: Vec<*mut HIST_ENTRY>,
    offset: usize,
    max_entries: usize,
    stifled: bool,
}

unsafe impl Send for History {}

impl History {
    fn sync_globals(&self) {
        unsafe {
            history_length = clamp_c_int(self.entries.len());
            history_offset = clamp_c_int(self.offset);
            history_max_entries = clamp_c_int(self.max_entries);
        }
    }

    fn trim(&mut self) {
        if !self.stifled || self.max_entries == 0 {
            return;
        }
        while self.entries.len() > self.max_entries {
            let entry = self.entries.remove(0);
            unsafe { free_entry_box(entry) };
        }
        if self.offset > self.entries.len() {
            self.offset = self.entries.len();
        }
    }

    fn ptr_at(&mut self, index: usize) -> *mut HIST_ENTRY {
        if index >= self.entries.len() {
            return ptr::null_mut();
        }
        &mut *self.entries[index] as *mut HIST_ENTRY
    }
}

fn clamp_c_int(value: usize) -> c_int {
    if value > c_int::MAX as usize {
        c_int::MAX
    } else {
        value as c_int
    }
}

unsafe fn dup_bytes(bytes: &[u8]) -> *mut c_char {
    let ptr = malloc(bytes.len() + 1) as *mut u8;
    if ptr.is_null() {
        return ptr::null_mut();
    }
    ptr::copy_nonoverlapping(bytes.as_ptr(), ptr, bytes.len());
    *ptr.add(bytes.len()) = 0;
    ptr as *mut c_char
}

unsafe fn dup_c_string(ptr_in: *const c_char) -> *mut c_char {
    if ptr_in.is_null() {
        return ptr::null_mut();
    }
    dup_bytes(CStr::from_ptr(ptr_in).to_bytes())
}

unsafe fn c_string_to_string(ptr_in: *const c_char) -> String {
    if ptr_in.is_null() {
        String::new()
    } else {
        CStr::from_ptr(ptr_in).to_string_lossy().into_owned()
    }
}

unsafe fn current_line_bytes() -> Vec<u8> {
    if rl_line_buffer.is_null() {
        Vec::new()
    } else {
        CStr::from_ptr(rl_line_buffer).to_bytes().to_vec()
    }
}

unsafe fn replace_global_string(slot: *mut *mut c_char, value: *const c_char) {
    let old = *slot;
    if !old.is_null() {
        free(old as *mut c_void);
    }
    *slot = dup_c_string(value);
}

unsafe fn set_line_buffer_bytes(bytes: &[u8]) {
    if !rl_line_buffer.is_null() {
        free(rl_line_buffer as *mut c_void);
    }
    rl_line_buffer = dup_bytes(bytes);
    rl_end = clamp_c_int(bytes.len());
    rl_point = rl_end;
}

unsafe fn free_entry_box(entry: Box<HIST_ENTRY>) {
    if !entry.line.is_null() {
        free(entry.line as *mut c_void);
    }
    if !entry.timestamp.is_null() {
        free(entry.timestamp as *mut c_void);
    }
}

fn default_history_path() -> String {
    if let Ok(home) = std::env::var("HOME") {
        if !home.is_empty() {
            return format!("{home}/.history");
        }
    }
    ".history".to_string()
}

unsafe fn path_from_c(filename: *const c_char) -> String {
    if filename.is_null() {
        default_history_path()
    } else {
        c_string_to_string(filename)
    }
}

unsafe fn ensure_stdio_streams() {
    if rl_instream.is_null() {
        rl_instream = fdopen(0, b"r\0".as_ptr() as *const c_char);
    }
    if rl_outstream.is_null() {
        rl_outstream = fdopen(1, b"w\0".as_ptr() as *const c_char);
    }
}

unsafe fn ensure_builtin_keymap() -> *mut c_void {
    if BUILTIN_KEYMAP.is_null() {
        BUILTIN_KEYMAP = malloc(1);
        emacs_standard_keymap = BUILTIN_KEYMAP;
        emacs_meta_keymap = BUILTIN_KEYMAP;
        emacs_ctlx_keymap = BUILTIN_KEYMAP;
        vi_movement_keymap = BUILTIN_KEYMAP;
        vi_insertion_keymap = BUILTIN_KEYMAP;
        CURRENT_KEYMAP = BUILTIN_KEYMAP;
        rl_executing_keymap = BUILTIN_KEYMAP;
        rl_binding_keymap = BUILTIN_KEYMAP;
    }
    BUILTIN_KEYMAP
}

fn contains_bytes(haystack: &[u8], needle: &[u8]) -> bool {
    if needle.is_empty() {
        return true;
    }
    haystack
        .windows(needle.len())
        .any(|window| window == needle)
}

fn parse_decimal_after(bytes: &[u8], marker: &[u8]) -> Option<c_int> {
    let start = bytes
        .windows(marker.len())
        .position(|window| window == marker)?;
    let mut idx = start + marker.len();
    while idx < bytes.len() && bytes[idx].is_ascii_whitespace() {
        idx += 1;
    }
    let value_start = idx;
    while idx < bytes.len() && bytes[idx].is_ascii_digit() {
        idx += 1;
    }
    if idx == value_start {
        return None;
    }
    std::str::from_utf8(&bytes[value_start..idx])
        .ok()
        .and_then(|value| value.parse::<c_int>().ok())
}

fn unescape_binding_bytes(bytes: &[u8]) -> Vec<u8> {
    let mut out = Vec::with_capacity(bytes.len());
    let mut idx = 0;
    while idx < bytes.len() {
        if bytes[idx] != b'\\' || idx + 1 >= bytes.len() {
            out.push(bytes[idx]);
            idx += 1;
            continue;
        }

        idx += 1;
        match bytes[idx] {
            b'a' => out.push(0x07),
            b'b' => out.push(0x08),
            b'e' | b'E' => out.push(0x1b),
            b'f' => out.push(0x0c),
            b'n' => out.push(b'\n'),
            b'r' => out.push(b'\r'),
            b't' => out.push(b'\t'),
            b'v' => out.push(0x0b),
            b'\\' => out.push(b'\\'),
            b'"' => out.push(b'"'),
            b'0'..=b'7' => {
                let mut value = (bytes[idx] - b'0') as u8;
                let mut consumed = 1;
                while consumed < 3
                    && idx + consumed < bytes.len()
                    && (b'0'..=b'7').contains(&bytes[idx + consumed])
                {
                    value = value
                        .saturating_mul(8)
                        .saturating_add(bytes[idx + consumed] - b'0');
                    consumed += 1;
                }
                out.push(value);
                idx += consumed - 1;
            }
            other => out.push(other),
        }
        idx += 1;
    }
    out
}

fn quoted_binding_value(bytes: &[u8]) -> Option<Vec<u8>> {
    let mut start = None;
    let mut idx = 0;
    while idx < bytes.len() {
        if bytes[idx] == b'"' {
            start = Some(idx + 1);
            break;
        }
        idx += 1;
    }
    let start = start?;
    let mut escaped = false;
    idx = start;
    while idx < bytes.len() {
        if escaped {
            escaped = false;
        } else if bytes[idx] == b'\\' {
            escaped = true;
        } else if bytes[idx] == b'"' {
            return Some(unescape_binding_bytes(&bytes[start..idx]));
        }
        idx += 1;
    }
    None
}

fn previous_char_boundary(bytes: &[u8], point: usize) -> usize {
    let mut idx = point.min(bytes.len());
    if idx == 0 {
        return 0;
    }
    idx -= 1;
    while idx > 0 && (bytes[idx] & 0xc0) == 0x80 {
        idx -= 1;
    }
    idx
}

fn insert_bytes(line: &mut Vec<u8>, point: &mut usize, bytes: &[u8]) {
    let idx = (*point).min(line.len());
    line.splice(idx..idx, bytes.iter().copied());
    *point = idx + bytes.len();
}

unsafe fn word_break_bytes() -> Vec<u8> {
    if let Some(hook) = rl_completion_word_break_hook {
        let bytes = hook();
        if !bytes.is_null() {
            return CStr::from_ptr(bytes).to_bytes().to_vec();
        }
    }
    if rl_completer_word_break_characters.is_null() {
        WORD_BREAK_BYTES[..WORD_BREAK_BYTES.len() - 1].to_vec()
    } else {
        CStr::from_ptr(rl_completer_word_break_characters)
            .to_bytes()
            .to_vec()
    }
}

unsafe fn completion_word_start(line: &[u8], point: usize) -> usize {
    let breaks = word_break_bytes();
    let mut idx = point.min(line.len());
    while idx > 0 && !breaks.contains(&line[idx - 1]) {
        idx -= 1;
    }
    idx
}

unsafe fn free_completion_matches(matches: *mut *mut c_char) {
    if matches.is_null() {
        return;
    }
    let mut idx = 0;
    loop {
        let item = *matches.add(idx);
        if item.is_null() {
            break;
        }
        free(item as *mut c_void);
        idx += 1;
    }
    free(matches as *mut c_void);
}

unsafe fn complete_line(line: &mut Vec<u8>, point: &mut usize, force_display: bool) -> bool {
    let Some(completer) = rl_attempted_completion_function else {
        return false;
    };

    let end = (*point).min(line.len());
    let start = completion_word_start(line, end);
    set_line_buffer_bytes(line);
    rl_point = clamp_c_int(end);
    rl_end = clamp_c_int(line.len());

    let text = dup_bytes(&line[start..end]);
    if text.is_null() {
        return false;
    }
    let matches = completer(text, clamp_c_int(start), clamp_c_int(end));
    free(text as *mut c_void);
    if matches.is_null() {
        return false;
    }

    let mut item_count = 0usize;
    let mut max_length = 0usize;
    while !(*matches.add(item_count + 1)).is_null() {
        let len = CStr::from_ptr(*matches.add(item_count + 1))
            .to_bytes()
            .len();
        if len > max_length {
            max_length = len;
        }
        item_count += 1;
    }
    if item_count == 0 {
        free_completion_matches(matches);
        return false;
    }

    let replacement = CStr::from_ptr(*matches).to_bytes().to_vec();
    let current = line[start..end].to_vec();
    let mut changed = false;
    if replacement != current {
        line.splice(start..end, replacement.iter().copied());
        *point = start + replacement.len();
        changed = true;
    }

    if item_count == 1 && rl_completion_suppress_append == 0 {
        let append = rl_completion_append_character;
        if append > 0 && append <= u8::MAX as c_int {
            insert_bytes(line, point, &[append as u8]);
            changed = true;
        }
    } else if !changed && force_display {
        if let Some(display) = rl_completion_display_matches_hook {
            display(matches, clamp_c_int(item_count), clamp_c_int(max_length));
        }
    }

    set_line_buffer_bytes(line);
    rl_point = clamp_c_int(*point);
    rl_end = clamp_c_int(line.len());
    free_completion_matches(matches);
    changed
}

unsafe fn read_edited_line() -> Option<Vec<u8>> {
    let mut line = current_line_bytes();
    let mut point = if rl_point < 0 {
        0
    } else {
        (rl_point as usize).min(line.len())
    };
    let mut got_byte = false;
    let mut previous_tab_left_line_unchanged = false;

    loop {
        let key = rl_getc(rl_instream);
        if key < 0 {
            if got_byte {
                break;
            }
            return None;
        }
        got_byte = true;

        match key {
            0x0a | 0x0d => break,
            0x01 => {
                let macro_bytes = {
                    let editor = EDITOR.lock().unwrap();
                    editor.ctrl_a_macro.clone()
                };
                if macro_bytes.is_empty() {
                    point = 0;
                } else {
                    insert_bytes(&mut line, &mut point, &macro_bytes);
                }
                previous_tab_left_line_unchanged = false;
            }
            0x02 => {
                let backward = {
                    let editor = EDITOR.lock().unwrap();
                    editor.ctrl_b_backward
                };
                if backward {
                    point = previous_char_boundary(&line, point);
                }
                previous_tab_left_line_unchanged = false;
            }
            0x08 | 0x7f => {
                let prev = previous_char_boundary(&line, point);
                if prev < point {
                    line.drain(prev..point);
                    point = prev;
                }
                previous_tab_left_line_unchanged = false;
            }
            0x09 => {
                let completes = {
                    let editor = EDITOR.lock().unwrap();
                    editor.tab_completes
                };
                if completes {
                    let changed =
                        complete_line(&mut line, &mut point, previous_tab_left_line_unchanged);
                    previous_tab_left_line_unchanged = !changed;
                } else {
                    insert_bytes(&mut line, &mut point, b"\t");
                    previous_tab_left_line_unchanged = false;
                }
            }
            0x00..=0x1f => {
                previous_tab_left_line_unchanged = false;
            }
            _ => {
                if key <= u8::MAX as c_int {
                    insert_bytes(&mut line, &mut point, &[key as u8]);
                }
                previous_tab_left_line_unchanged = false;
            }
        }
        set_line_buffer_bytes(&line);
        rl_point = clamp_c_int(point);
        rl_end = clamp_c_int(line.len());
    }

    set_line_buffer_bytes(&line);
    rl_point = clamp_c_int(point);
    rl_end = clamp_c_int(line.len());
    Some(line)
}

#[no_mangle]
pub unsafe extern "C" fn readline(prompt: *const c_char) -> *mut c_char {
    ensure_stdio_streams();
    if let Some(hook) = rl_startup_hook {
        let _ = hook();
    }
    if !prompt.is_null() && rl_already_prompted == 0 {
        let prompt_string = CStr::from_ptr(prompt).to_string_lossy();
        print!("{prompt_string}");
        let _ = io::stdout().flush();
    }
    set_line_buffer_bytes(&[]);
    if let Some(hook) = rl_pre_input_hook {
        let _ = hook();
    }

    match read_edited_line() {
        None => {
            rl_eof_found = 1;
            ptr::null_mut()
        }
        Some(line) => {
            rl_eof_found = 0;
            let mut line = line;
            if rl_num_chars_to_read > 0 && line.len() > rl_num_chars_to_read as usize {
                line.truncate(rl_num_chars_to_read as usize);
            }
            set_line_buffer_bytes(&line);
            dup_bytes(&line)
        }
    }
}

#[no_mangle]
pub unsafe extern "C" fn rl_initialize() -> c_int {
    ensure_stdio_streams();
    ensure_builtin_keymap();
    let _ = rl_read_init_file(ptr::null());
    0
}

#[no_mangle]
pub extern "C" fn rl_cleanup_after_signal() {}

#[no_mangle]
pub extern "C" fn rl_reset_after_signal() {}

#[no_mangle]
pub extern "C" fn rl_free_line_state() {}

#[no_mangle]
pub unsafe extern "C" fn rl_deprep_terminal() {
    rl_readline_state &= !0x00000004;
}

#[no_mangle]
pub unsafe extern "C" fn rl_prep_terminal(_meta_flag: c_int) -> c_int {
    rl_readline_state |= 0x00000004;
    0
}

#[no_mangle]
pub unsafe extern "C" fn rl_set_prompt(prompt: *const c_char) -> c_int {
    replace_global_string(std::ptr::addr_of_mut!(rl_prompt), prompt);
    0
}

#[no_mangle]
pub extern "C" fn rl_on_new_line() -> c_int {
    0
}

#[no_mangle]
pub unsafe extern "C" fn rl_newline(_count: c_int, _key: c_int) -> c_int {
    rl_done = 1;
    0
}

#[no_mangle]
pub extern "C" fn rl_redisplay() -> c_int {
    0
}

#[no_mangle]
pub extern "C" fn rl_forced_update_display() -> c_int {
    0
}

#[no_mangle]
pub extern "C" fn _rl_erase_entire_line() {}

#[no_mangle]
pub unsafe extern "C" fn _rl_qsort_string_compare(a: *const c_void, b: *const c_void) -> c_int {
    if a.is_null() || b.is_null() {
        return 0;
    }
    let left = *(a as *const *const c_char);
    let right = *(b as *const *const c_char);
    if left.is_null() || right.is_null() {
        return if left == right {
            0
        } else if left.is_null() {
            -1
        } else {
            1
        };
    }
    let left = CStr::from_ptr(left).to_bytes();
    let right = CStr::from_ptr(right).to_bytes();
    match left.cmp(right) {
        std::cmp::Ordering::Less => -1,
        std::cmp::Ordering::Equal => 0,
        std::cmp::Ordering::Greater => 1,
    }
}

#[no_mangle]
pub unsafe extern "C" fn rl_replace_line(text: *const c_char, _clear_undo: c_int) {
    if text.is_null() {
        set_line_buffer_bytes(&[]);
    } else {
        set_line_buffer_bytes(CStr::from_ptr(text).to_bytes());
    }
}

#[no_mangle]
pub unsafe extern "C" fn rl_insert_text(text: *const c_char) -> c_int {
    if text.is_null() {
        return 0;
    }

    let mut line = current_line_bytes();
    let insert = CStr::from_ptr(text).to_bytes();
    let point = if rl_point < 0 {
        0
    } else {
        (rl_point as usize).min(line.len())
    };
    line.splice(point..point, insert.iter().copied());
    set_line_buffer_bytes(&line);
    rl_point = clamp_c_int(point + insert.len());
    rl_end = clamp_c_int(line.len());
    0
}

#[no_mangle]
pub extern "C" fn rl_bind_key(key: c_int, function: rl_command_func_t) -> c_int {
    if key == b'\t' as c_int {
        let mut editor = EDITOR.lock().unwrap();
        let complete = function
            .map(|func| func as usize == rl_complete as usize)
            .unwrap_or(false);
        let insert = function
            .map(|func| func as usize == rl_insert as usize)
            .unwrap_or(false);
        if complete {
            editor.tab_completes = true;
        } else if insert {
            editor.tab_completes = false;
        }
    } else if key == 0x02 {
        let mut editor = EDITOR.lock().unwrap();
        editor.ctrl_b_backward = true;
    }
    0
}

#[no_mangle]
pub extern "C" fn rl_bind_key_in_map(
    key: c_int,
    function: rl_command_func_t,
    _map: *mut c_void,
) -> c_int {
    let _ = key;
    let _ = function;
    0
}

#[no_mangle]
pub extern "C" fn rl_bind_keyseq(_keyseq: *const c_char, _function: rl_command_func_t) -> c_int {
    0
}

#[no_mangle]
pub unsafe extern "C" fn rl_variable_bind(variable: *const c_char, value: *const c_char) -> c_int {
    if variable.is_null() || value.is_null() {
        return -1;
    }
    let variable = CStr::from_ptr(variable).to_bytes();
    if variable == b"history-size" {
        let value = CStr::from_ptr(value).to_bytes();
        if let Ok(value) = std::str::from_utf8(value) {
            if let Ok(max) = value.trim().parse::<c_int>() {
                stifle_history(max);
                return 0;
            }
        }
        return -1;
    }
    0
}

#[no_mangle]
pub unsafe extern "C" fn rl_variable_value(variable: *const c_char) -> *mut c_char {
    if variable.is_null() {
        return ptr::null_mut();
    }
    let variable = CStr::from_ptr(variable).to_bytes();
    if variable == b"enable-bracketed-paste" {
        OFF_BYTES.as_ptr() as *mut c_char
    } else {
        ptr::null_mut()
    }
}

#[no_mangle]
pub unsafe extern "C" fn rl_parse_and_bind(line: *mut c_char) -> c_int {
    if line.is_null() {
        return -1;
    }
    let bytes = CStr::from_ptr(line).to_bytes();

    if let Some(max) = parse_decimal_after(bytes, b"history-size") {
        stifle_history(max);
        return 0;
    }

    if contains_bytes(bytes, b"complete") {
        let mut editor = EDITOR.lock().unwrap();
        editor.tab_completes = true;
    }
    if contains_bytes(bytes, b"Control-b") || contains_bytes(bytes, b"^B") {
        let mut editor = EDITOR.lock().unwrap();
        editor.ctrl_b_backward = true;
    }
    if contains_bytes(bytes, b"Control-a") || contains_bytes(bytes, b"^A") {
        if let Some(value) = quoted_binding_value(bytes) {
            let mut editor = EDITOR.lock().unwrap();
            editor.ctrl_a_macro = value;
        }
    }
    0
}

#[no_mangle]
pub unsafe extern "C" fn rl_read_init_file(filename: *const c_char) -> c_int {
    let path = if filename.is_null() {
        match std::env::var("INPUTRC") {
            Ok(path) if !path.is_empty() => path,
            _ => match std::env::var("HOME") {
                Ok(home) if !home.is_empty() => format!("{home}/.inputrc"),
                _ => return 0,
            },
        }
    } else {
        c_string_to_string(filename)
    };
    let content = match fs::read(&path) {
        Ok(content) => content,
        Err(_) => {
            return if filename.is_null() { 0 } else { -1 };
        }
    };
    for line in content.split(|byte| *byte == b'\n') {
        let mut line = line;
        if line.ends_with(b"\r") {
            line = &line[..line.len() - 1];
        }
        let tmp = dup_bytes(line);
        if !tmp.is_null() {
            let _ = rl_parse_and_bind(tmp);
            free(tmp as *mut c_void);
        }
    }
    0
}

#[no_mangle]
pub extern "C" fn rl_add_defun(
    _name: *const c_char,
    function: rl_command_func_t,
    key: c_int,
) -> c_int {
    if key >= 0 {
        rl_bind_key(key, function)
    } else {
        0
    }
}

#[no_mangle]
pub unsafe extern "C" fn rl_completion_matches(
    text: *const c_char,
    entry_func: rl_compentry_func_t,
) -> *mut *mut c_char {
    let Some(generator) = entry_func else {
        return ptr::null_mut();
    };

    let mut matches = Vec::new();
    for state in 0..1024 {
        let item = generator(text, state);
        if item.is_null() {
            break;
        }
        matches.push(item);
    }

    if matches.is_empty() {
        return ptr::null_mut();
    }

    let first = CStr::from_ptr(matches[0]).to_bytes();
    let mut prefix_len = first.len();
    for item in &matches[1..] {
        let bytes = CStr::from_ptr(*item).to_bytes();
        let limit = prefix_len.min(bytes.len());
        let mut idx = 0;
        while idx < limit && first[idx] == bytes[idx] {
            idx += 1;
        }
        prefix_len = idx;
    }

    let count = matches.len() + 2;
    let raw = malloc(count * std::mem::size_of::<*mut c_char>()) as *mut *mut c_char;
    if raw.is_null() {
        return ptr::null_mut();
    }
    *raw = dup_bytes(&first[..prefix_len]);
    for (idx, item) in matches.into_iter().enumerate() {
        *raw.add(idx + 1) = item;
    }
    *raw.add(count - 1) = ptr::null_mut();
    raw
}

#[no_mangle]
pub extern "C" fn rl_filename_completion_function(
    _text: *const c_char,
    _state: c_int,
) -> *mut c_char {
    ptr::null_mut()
}

#[no_mangle]
pub extern "C" fn rl_username_completion_function(
    _text: *const c_char,
    _state: c_int,
) -> *mut c_char {
    ptr::null_mut()
}

#[no_mangle]
pub unsafe extern "C" fn rl_copy_text(start: c_int, end: c_int) -> *mut c_char {
    let line = current_line_bytes();
    let s = start.max(0) as usize;
    let e = end.max(0) as usize;
    if s >= e || s >= line.len() {
        return dup_bytes(&[]);
    }
    dup_bytes(&line[s..e.min(line.len())])
}

#[no_mangle]
pub extern "C" fn rl_extend_line_buffer(_len: c_int) -> c_int {
    0
}

#[no_mangle]
pub extern "C" fn rl_ding() -> c_int {
    0
}

#[no_mangle]
pub extern "C" fn rl_abort(_count: c_int, _key: c_int) -> c_int {
    0
}

#[no_mangle]
pub unsafe extern "C" fn rl_insert(count: c_int, key: c_int) -> c_int {
    if count <= 0 || !(0..=255).contains(&key) {
        return 0;
    }
    let bytes = vec![key as u8; count as usize];
    let text = dup_bytes(&bytes);
    if text.is_null() {
        return -1;
    }
    let result = rl_insert_text(text);
    free(text as *mut c_void);
    result
}

#[no_mangle]
pub unsafe extern "C" fn rl_complete(_count: c_int, _key: c_int) -> c_int {
    let mut line = current_line_bytes();
    let mut point = if rl_point < 0 {
        0
    } else {
        (rl_point as usize).min(line.len())
    };
    let _ = complete_line(&mut line, &mut point, true);
    0
}

#[no_mangle]
pub extern "C" fn rl_tilde_expand(_count: c_int, _key: c_int) -> c_int {
    0
}

#[no_mangle]
pub extern "C" fn rl_modifying(_start: c_int, _end: c_int) -> c_int {
    0
}

#[no_mangle]
pub extern "C" fn rl_history_search_forward(_count: c_int, _key: c_int) -> c_int {
    0
}

#[no_mangle]
pub extern "C" fn rl_history_search_backward(_count: c_int, _key: c_int) -> c_int {
    0
}

#[no_mangle]
pub extern "C" fn rl_reset_terminal(_terminal_name: *const c_char) -> c_int {
    0
}

#[no_mangle]
pub extern "C" fn rl_resize_terminal() {}

#[no_mangle]
pub unsafe extern "C" fn rl_set_screen_size(rows: c_int, cols: c_int) {
    if rows > 0 {
        SCREEN_ROWS = rows;
    }
    if cols > 0 {
        SCREEN_COLS = cols;
    }
}

#[no_mangle]
pub unsafe extern "C" fn rl_get_screen_size(rows: *mut c_int, cols: *mut c_int) {
    if !rows.is_null() {
        *rows = SCREEN_ROWS;
    }
    if !cols.is_null() {
        *cols = SCREEN_COLS;
    }
}

#[no_mangle]
pub unsafe extern "C" fn rl_reset_screen_size() {
    SCREEN_ROWS = 24;
    SCREEN_COLS = 80;
}

#[no_mangle]
pub extern "C" fn rl_set_signals() -> c_int {
    0
}

#[no_mangle]
pub extern "C" fn rl_clear_signals() -> c_int {
    0
}

#[no_mangle]
pub extern "C" fn rl_pending_signal() -> c_int {
    0
}

#[no_mangle]
pub extern "C" fn rl_check_signals() -> c_int {
    0
}

#[no_mangle]
pub unsafe extern "C" fn rl_set_timeout(seconds: u32, useconds: u32) -> c_int {
    TIMEOUT_SECONDS = seconds.min(c_int::MAX as u32) as c_int;
    TIMEOUT_USECONDS = useconds.min(c_int::MAX as u32) as c_int;
    if seconds == 0 && useconds == 0 {
        rl_readline_state &= !0x04000000;
    }
    0
}

#[no_mangle]
pub unsafe extern "C" fn rl_timeout_remaining(seconds: *mut u32, useconds: *mut u32) -> c_int {
    if !seconds.is_null() {
        *seconds = TIMEOUT_SECONDS.max(0) as u32;
    }
    if !useconds.is_null() {
        *useconds = TIMEOUT_USECONDS.max(0) as u32;
    }
    if TIMEOUT_SECONDS == 0 && TIMEOUT_USECONDS == 0 {
        0
    } else {
        1
    }
}

#[no_mangle]
pub unsafe extern "C" fn rl_getc(stream: *mut c_void) -> c_int {
    let input = if stream.is_null() {
        ensure_stdio_streams();
        rl_instream
    } else {
        stream
    };
    if input.is_null() {
        READERR
    } else {
        fgetc(input)
    }
}

#[no_mangle]
pub unsafe extern "C" fn rl_read_key() -> c_int {
    ensure_stdio_streams();
    rl_getc(rl_instream)
}

#[no_mangle]
pub extern "C" fn rl_crlf() -> c_int {
    println!();
    let _ = io::stdout().flush();
    0
}

#[no_mangle]
pub unsafe extern "C" fn rl_untranslate_keyseq(key: c_int) -> *mut c_char {
    if (0..=255).contains(&key) {
        dup_bytes(&[key as u8])
    } else {
        dup_bytes(&[])
    }
}

#[no_mangle]
pub unsafe extern "C" fn rl_free(mem: *mut c_void) {
    if !mem.is_null() {
        free(mem);
    }
}

#[no_mangle]
pub unsafe extern "C" fn rl_callback_handler_install(
    prompt: *const c_char,
    handler: rl_callback_handler_t,
) {
    ensure_stdio_streams();
    replace_global_string(std::ptr::addr_of_mut!(rl_prompt), prompt);
    let mut cb = CALLBACK.lock().unwrap();
    if !cb.prompt.is_null() {
        free(cb.prompt as *mut c_void);
    }
    cb.prompt = dup_c_string(prompt);
    cb.handler = handler;
    cb.prompt_shown = false;
    if !prompt.is_null() && rl_already_prompted == 0 {
        let prompt_string = CStr::from_ptr(prompt).to_string_lossy();
        print!("{prompt_string}");
        let _ = io::stdout().flush();
        cb.prompt_shown = true;
    }
}

#[no_mangle]
pub unsafe extern "C" fn rl_callback_read_char() {
    let (prompt, handler, prompt_shown) = {
        let cb = CALLBACK.lock().unwrap();
        (cb.prompt, cb.handler, cb.prompt_shown)
    };
    if let Some(handler) = handler {
        let prompt = if prompt_shown { ptr::null() } else { prompt };
        let line = readline(prompt);
        handler(line);
    }
}

#[no_mangle]
pub unsafe extern "C" fn rl_callback_handler_remove() {
    let mut cb = CALLBACK.lock().unwrap();
    if !cb.prompt.is_null() {
        free(cb.prompt as *mut c_void);
    }
    cb.prompt = ptr::null_mut();
    cb.handler = None;
    cb.prompt_shown = false;
}

#[no_mangle]
pub unsafe extern "C" fn rl_callback_sigcleanup() {
    rl_callback_handler_remove();
}

#[no_mangle]
pub unsafe extern "C" fn rl_make_bare_keymap() -> *mut c_void {
    malloc(1)
}

#[no_mangle]
pub unsafe extern "C" fn rl_make_keymap() -> *mut c_void {
    rl_make_bare_keymap()
}

#[no_mangle]
pub unsafe extern "C" fn rl_copy_keymap(_map: *mut c_void) -> *mut c_void {
    rl_make_bare_keymap()
}

#[no_mangle]
pub unsafe extern "C" fn rl_discard_keymap(map: *mut c_void) {
    rl_free_keymap(map);
}

#[no_mangle]
pub unsafe extern "C" fn rl_free_keymap(map: *mut c_void) {
    if map.is_null() {
        return;
    }
    let builtin = ensure_builtin_keymap();
    if map != builtin {
        if CURRENT_KEYMAP == map {
            CURRENT_KEYMAP = builtin;
        }
        free(map);
    }
}

#[no_mangle]
pub unsafe extern "C" fn rl_get_keymap_by_name(name: *const c_char) -> *mut c_void {
    let builtin = ensure_builtin_keymap();
    if name.is_null() {
        return ptr::null_mut();
    }
    let name = CStr::from_ptr(name).to_bytes();
    if name == b"emacs" || name == b"vi" {
        builtin
    } else {
        CURRENT_KEYMAP
    }
}

#[no_mangle]
pub unsafe extern "C" fn rl_get_keymap_name(map: *mut c_void) -> *mut c_char {
    let builtin = ensure_builtin_keymap();
    if map == builtin {
        dup_bytes(b"emacs")
    } else if map.is_null() {
        ptr::null_mut()
    } else {
        dup_bytes(b"readlineoxide")
    }
}

#[no_mangle]
pub unsafe extern "C" fn rl_set_keymap(map: *mut c_void) {
    CURRENT_KEYMAP = if map.is_null() {
        ensure_builtin_keymap()
    } else {
        map
    };
}

#[no_mangle]
pub unsafe extern "C" fn rl_get_keymap() -> *mut c_void {
    if CURRENT_KEYMAP.is_null() {
        ensure_builtin_keymap()
    } else {
        CURRENT_KEYMAP
    }
}

#[no_mangle]
pub unsafe extern "C" fn rl_set_keymap_name(name: *const c_char, map: *mut c_void) -> c_int {
    if name.is_null() || map.is_null() {
        return -1;
    }
    let builtin = ensure_builtin_keymap();
    let name = CStr::from_ptr(name).to_bytes();
    if name == b"emacs" || map == builtin {
        -1
    } else {
        0
    }
}

#[no_mangle]
pub unsafe extern "C" fn tilde_expand(filename: *const c_char) -> *mut c_char {
    let input = c_string_to_string(filename);
    if input == "~" || input.starts_with("~/") {
        if let Ok(home) = std::env::var("HOME") {
            let rest = input.strip_prefix('~').unwrap_or("");
            return dup_bytes(format!("{home}{rest}").as_bytes());
        }
    }
    dup_bytes(input.as_bytes())
}

#[no_mangle]
pub extern "C" fn using_history() {
    let hist = HISTORY.lock().unwrap();
    hist.sync_globals();
}

#[no_mangle]
pub unsafe extern "C" fn add_history(line: *const c_char) {
    if line.is_null() {
        return;
    }
    let entry = Box::new(HIST_ENTRY {
        line: dup_c_string(line),
        timestamp: ptr::null_mut(),
        data: ptr::null_mut(),
    });
    let mut hist = HISTORY.lock().unwrap();
    hist.entries.push(entry);
    hist.offset = hist.entries.len();
    hist.trim();
    hist.sync_globals();
}

#[no_mangle]
pub unsafe extern "C" fn add_history_time(string: *const c_char) {
    if string.is_null() {
        return;
    }
    let mut hist = HISTORY.lock().unwrap();
    if let Some(entry) = hist.entries.last_mut() {
        if !entry.timestamp.is_null() {
            free(entry.timestamp as *mut c_void);
        }
        entry.timestamp = dup_c_string(string);
    }
}

#[no_mangle]
pub unsafe extern "C" fn clear_history() {
    let mut hist = HISTORY.lock().unwrap();
    while let Some(entry) = hist.entries.pop() {
        free_entry_box(entry);
    }
    hist.list.clear();
    hist.offset = 0;
    hist.sync_globals();
}

#[no_mangle]
pub extern "C" fn stifle_history(max: c_int) {
    let mut hist = HISTORY.lock().unwrap();
    hist.max_entries = max.max(0) as usize;
    hist.stifled = true;
    hist.trim();
    hist.sync_globals();
}

#[no_mangle]
pub extern "C" fn unstifle_history() -> c_int {
    let mut hist = HISTORY.lock().unwrap();
    let old = clamp_c_int(hist.max_entries);
    hist.max_entries = 0;
    hist.stifled = false;
    hist.sync_globals();
    old
}

#[no_mangle]
pub extern "C" fn history_is_stifled() -> c_int {
    let hist = HISTORY.lock().unwrap();
    if hist.stifled {
        1
    } else {
        0
    }
}

#[no_mangle]
pub extern "C" fn history_list() -> *mut *mut HIST_ENTRY {
    let mut hist = HISTORY.lock().unwrap();
    let mut ptrs = Vec::with_capacity(hist.entries.len() + 1);
    for entry in hist.entries.iter_mut() {
        ptrs.push(&mut **entry as *mut HIST_ENTRY);
    }
    ptrs.push(ptr::null_mut());
    hist.list = ptrs;
    hist.list.as_mut_ptr()
}

#[no_mangle]
pub extern "C" fn history_get(offset: c_int) -> *mut HIST_ENTRY {
    let mut hist = HISTORY.lock().unwrap();
    let base = unsafe { history_base };
    let index = offset - base;
    if index < 0 {
        return ptr::null_mut();
    }
    hist.ptr_at(index as usize)
}

#[no_mangle]
pub unsafe extern "C" fn history_get_time(entry: *mut HIST_ENTRY) -> c_long {
    if entry.is_null() || (*entry).timestamp.is_null() {
        return 0;
    }
    let bytes = CStr::from_ptr((*entry).timestamp).to_bytes();
    let digits = bytes.strip_prefix(b"#").unwrap_or(bytes);
    match std::str::from_utf8(digits)
        .ok()
        .and_then(|value| value.parse::<c_long>().ok())
    {
        Some(value) => value,
        None => 0,
    }
}

#[no_mangle]
pub unsafe extern "C" fn history_get_history_state() -> *mut HISTORY_STATE {
    history_get_state()
}

#[no_mangle]
pub unsafe extern "C" fn history_get_state() -> *mut HISTORY_STATE {
    let list = history_list();
    let hist = HISTORY.lock().unwrap();
    let state = HISTORY_STATE {
        entries: list,
        offset: clamp_c_int(hist.offset),
        length: clamp_c_int(hist.entries.len()),
        size: clamp_c_int(hist.entries.capacity()),
        flags: if hist.stifled { 1 } else { 0 },
    };
    let raw = malloc(std::mem::size_of::<HISTORY_STATE>()) as *mut HISTORY_STATE;
    if raw.is_null() {
        return ptr::null_mut();
    }
    ptr::write(raw, state);
    raw
}

#[no_mangle]
pub extern "C" fn history_set_history_state(state: *mut HISTORY_STATE) {
    if state.is_null() {
        return;
    }
    let mut hist = HISTORY.lock().unwrap();
    let offset = unsafe { (*state).offset };
    hist.offset = offset.max(0) as usize;
    if hist.offset > hist.entries.len() {
        hist.offset = hist.entries.len();
    }
    hist.sync_globals();
}

#[no_mangle]
pub extern "C" fn where_history() -> c_int {
    let hist = HISTORY.lock().unwrap();
    clamp_c_int(hist.offset)
}

#[no_mangle]
pub extern "C" fn history_set_pos(pos: c_int) -> c_int {
    let mut hist = HISTORY.lock().unwrap();
    if pos < 0 || pos as usize > hist.entries.len() {
        return 0;
    }
    hist.offset = pos as usize;
    hist.sync_globals();
    1
}

#[no_mangle]
pub extern "C" fn current_history() -> *mut HIST_ENTRY {
    let mut hist = HISTORY.lock().unwrap();
    let idx = hist.offset;
    hist.ptr_at(idx)
}

#[no_mangle]
pub extern "C" fn previous_history() -> *mut HIST_ENTRY {
    let mut hist = HISTORY.lock().unwrap();
    if hist.offset == 0 {
        return ptr::null_mut();
    }
    hist.offset -= 1;
    let idx = hist.offset;
    hist.sync_globals();
    hist.ptr_at(idx)
}

#[no_mangle]
pub extern "C" fn next_history() -> *mut HIST_ENTRY {
    let mut hist = HISTORY.lock().unwrap();
    if hist.offset >= hist.entries.len() {
        return ptr::null_mut();
    }
    hist.offset += 1;
    hist.sync_globals();
    if hist.offset >= hist.entries.len() {
        ptr::null_mut()
    } else {
        let idx = hist.offset;
        hist.ptr_at(idx)
    }
}

#[no_mangle]
pub extern "C" fn rl_get_previous_history(count: c_int, _key: c_int) -> c_int {
    let steps = count.max(1);
    for _ in 0..steps {
        if previous_history().is_null() {
            break;
        }
    }
    0
}

#[no_mangle]
pub extern "C" fn remove_history(which: c_int) -> *mut HIST_ENTRY {
    if which < 0 {
        return ptr::null_mut();
    }
    let mut hist = HISTORY.lock().unwrap();
    let index = which as usize;
    if index >= hist.entries.len() {
        return ptr::null_mut();
    }
    let entry = hist.entries.remove(index);
    if hist.offset > hist.entries.len() {
        hist.offset = hist.entries.len();
    }
    hist.sync_globals();
    Box::into_raw(entry)
}

#[no_mangle]
pub unsafe extern "C" fn replace_history_entry(
    which: c_int,
    line: *const c_char,
    data: *mut c_void,
) -> *mut HIST_ENTRY {
    if which < 0 || line.is_null() {
        return ptr::null_mut();
    }
    let mut hist = HISTORY.lock().unwrap();
    let index = which as usize;
    if index >= hist.entries.len() {
        return ptr::null_mut();
    }
    let new_entry = Box::new(HIST_ENTRY {
        line: dup_c_string(line),
        timestamp: ptr::null_mut(),
        data,
    });
    let old = std::mem::replace(&mut hist.entries[index], new_entry);
    hist.sync_globals();
    Box::into_raw(old)
}

#[no_mangle]
pub unsafe extern "C" fn free_history_entry(entry: *mut HIST_ENTRY) -> *mut c_void {
    if entry.is_null() {
        return ptr::null_mut();
    }
    let data = (*entry).data;
    free_entry_box(Box::from_raw(entry));
    data
}

#[no_mangle]
pub unsafe extern "C" fn read_history(filename: *const c_char) -> c_int {
    read_history_range(filename, 0, -1)
}

#[no_mangle]
pub unsafe extern "C" fn read_history_range(
    filename: *const c_char,
    from: c_int,
    to: c_int,
) -> c_int {
    let path = path_from_c(filename);
    let file = match fs::File::open(path) {
        Ok(file) => file,
        Err(_) => return -1,
    };
    let start = from.max(0) as usize;
    let stop = if to < 0 { usize::MAX } else { to as usize };

    for (idx, line) in io::BufReader::new(file).lines().enumerate() {
        if idx < start {
            continue;
        }
        if idx > stop {
            break;
        }
        if let Ok(line) = line {
            let tmp = dup_bytes(line.as_bytes());
            add_history(tmp);
            if !tmp.is_null() {
                free(tmp as *mut c_void);
            }
        }
    }
    0
}

#[no_mangle]
pub unsafe extern "C" fn write_history(filename: *const c_char) -> c_int {
    let path = path_from_c(filename);
    let hist = HISTORY.lock().unwrap();
    let mut file = match fs::File::create(path) {
        Ok(file) => file,
        Err(_) => return -1,
    };
    for entry in &hist.entries {
        if !entry.line.is_null() {
            let bytes = CStr::from_ptr(entry.line).to_bytes();
            if file.write_all(bytes).is_err() || file.write_all(b"\n").is_err() {
                return -1;
            }
        }
    }
    0
}

#[no_mangle]
pub unsafe extern "C" fn append_history(nelements: c_int, filename: *const c_char) -> c_int {
    let path = path_from_c(filename);
    let hist = HISTORY.lock().unwrap();
    let count = nelements.max(0) as usize;
    let start = hist.entries.len().saturating_sub(count);
    let mut file = match OpenOptions::new().create(true).append(true).open(path) {
        Ok(file) => file,
        Err(_) => return -1,
    };
    for entry in &hist.entries[start..] {
        if !entry.line.is_null() {
            let bytes = CStr::from_ptr(entry.line).to_bytes();
            if file.write_all(bytes).is_err() || file.write_all(b"\n").is_err() {
                return -1;
            }
        }
    }
    0
}

#[no_mangle]
pub unsafe extern "C" fn history_truncate_file(filename: *const c_char, nlines: c_int) -> c_int {
    let path = path_from_c(filename);
    let content = match fs::read_to_string(&path) {
        Ok(content) => content,
        Err(_) => return -1,
    };
    let keep = nlines.max(0) as usize;
    let lines: Vec<&str> = content.lines().collect();
    let start = lines.len().saturating_sub(keep);
    let mut output = String::new();
    for line in &lines[start..] {
        output.push_str(line);
        output.push('\n');
    }
    if fs::write(path, output).is_err() {
        -1
    } else {
        0
    }
}

#[no_mangle]
pub unsafe extern "C" fn history_expand(string: *mut c_char, output: *mut *mut c_char) -> c_int {
    if output.is_null() {
        return -1;
    }
    *output = dup_c_string(string);
    0
}

#[no_mangle]
pub extern "C" fn history_tokenize(_string: *const c_char) -> *mut *mut c_char {
    ptr::null_mut()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn duplicate_bytes_are_c_terminated() {
        unsafe {
            let ptr = dup_bytes(b"abc");
            assert!(!ptr.is_null());
            assert_eq!(CStr::from_ptr(ptr).to_bytes(), b"abc");
            free(ptr as *mut c_void);
        }
    }

    #[test]
    fn clamp_keeps_c_int_bounds() {
        assert_eq!(clamp_c_int(7), 7);
        assert_eq!(clamp_c_int(usize::MAX), c_int::MAX);
    }
}
