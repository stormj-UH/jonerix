#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <readline/history.h>

static void
fail(const char *message)
{
    fprintf(stderr, "history_file: %s\n", message);
    exit(1);
}

static void
expect_line(int offset, const char *line)
{
    HIST_ENTRY *entry = history_get(history_base + offset);
    if (entry == NULL || entry->line == NULL || strcmp(entry->line, line) != 0)
        fail(line);
}

int
main(int argc, char **argv)
{
    const char *path;

    if (argc != 2)
        fail("usage");
    path = argv[1];

    clear_history();
    add_history("one");
    add_history("two");
    add_history("three");
    if (write_history(path) != 0)
        fail("write");

    clear_history();
    if (read_history(path) != 0)
        fail("read");
    if (history_length != 3)
        fail("read length");
    expect_line(0, "one");
    expect_line(2, "three");

    if (append_history(2, path) != 0)
        fail("append");
    clear_history();
    if (read_history(path) != 0)
        fail("reread");
    if (history_length != 5)
        fail("append length");
    expect_line(3, "two");
    expect_line(4, "three");

    if (history_truncate_file(path, 2) != 0)
        fail("truncate");
    clear_history();
    if (read_history(path) != 0)
        fail("read truncated");
    if (history_length != 2)
        fail("truncated length");
    expect_line(0, "two");
    expect_line(1, "three");

    clear_history();
    if (read_history_range(path, 1, 1) != 0)
        fail("range");
    if (history_length != 1)
        fail("range length");
    expect_line(0, "three");

    return 0;
}
