#!/bin/sh
set -eu

script_dir=$(dirname "$0")
repo=$(CDPATH= cd "$script_dir/.." && pwd)
build_dir=$repo/target/release
tmp=${TMPDIR:-/tmp}/readlineoxide-sim-$$
cc=${CC:-cc}

cleanup() {
    rm -rf "$tmp"
}
trap cleanup EXIT HUP INT TERM

mkdir -p "$tmp"

cargo build --release --locked

compile() {
    src=$1
    exe=$tmp/${src%.c}
    "$cc" ${CFLAGS:-} -I "$repo/include" -L "$build_dir" \
        -Wl,-rpath,"$build_dir" "$repo/tests/$src" \
        -lreadline -lhistory -o "$exe"
}

run() {
    name=$1
    shift
    DYLD_LIBRARY_PATH=$build_dir LD_LIBRARY_PATH=$build_dir "$tmp/$name" "$@"
}

compile history_basic.c
compile history_file.c
compile readline_pipe.c
compile callback_repl.c
compile completion.c
compile consumer_abi.c
compile real_world_repl.c

run history_basic
run history_file "$tmp/history.txt"
printf 'select * from users;\n' | run readline_pipe
printf 'status\nexit\n' | run callback_repl
run completion
run consumer_abi
printf 'set alpha 1\nget alpha\nhistory\nquit\n' | run real_world_repl "$tmp/repl.hist"

printf '%s\n' "readlineoxide simulations: ok"
