#include <stdio.h>

#include <readline/readline.h>
#include <readline/history.h>

static void
display_hook(char **matches, int num_matches, int max_length)
{
    (void)matches;
    (void)num_matches;
    (void)max_length;
}

int
main(void)
{
    if (RL_VERSION_MAJOR < 7)
        return 1;
    if (RL_READLINE_VERSION != rl_readline_version)
        return 2;

    rl_completion_type = '\t';
    rl_completion_suppress_append = 1;
    rl_completion_display_matches_hook = display_hook;
    rl_catch_signals = 0;
    rl_catch_sigwinch = 0;

    if (rl_insert(1, 'x') != 0)
        return 3;
    if (rl_complete(1, '\t') != 0)
        return 4;
    if (rl_tilde_expand(1, '~') != 0)
        return 5;
    rl_set_screen_size(33, 99);
    rl_get_screen_size(&rl_point, &rl_end);
    if (rl_point != 33 || rl_end != 99)
        return 6;
    rl_reset_screen_size();

    return 0;
}
