#ifndef READLINEOXIDE_TILDE_H
#define READLINEOXIDE_TILDE_H

#ifdef __cplusplus
extern "C" {
#endif

char *tilde_expand(const char *filename);

#ifdef __cplusplus
}
#endif

#endif
