#ifndef READLINEOXIDE_READLINE_H
#define READLINEOXIDE_READLINE_H

#include <stdio.h>
#include "chardefs.h"
#include "history.h"
#include "keymaps.h"
#include "tilde.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef int rl_command_func_t(int, int);
typedef char *rl_compentry_func_t(const char *, int);
typedef char **rl_completion_func_t(const char *, int, int);
typedef int rl_hook_func_t(void);
typedef char *rl_cpvfunc_t(void);
typedef int rl_getc_func_t(FILE *);
typedef int rl_icpfunc_t(char *);
typedef int rl_icppfunc_t(char **);
typedef void rl_compdisp_func_t(char **, int, int);
typedef void rl_voidfunc_t(void);
typedef void rl_vintfunc_t(int);
typedef void rl_vcpfunc_t(char *);
typedef char *rl_filename_quoting_func_t(char *, int, char *);
typedef char *rl_filename_dequoting_func_t(char *, int);
typedef void rl_macro_print_func_t(const char *, const char *, int, const char *);

#define RL_VERSION_MAJOR 8
#define RL_VERSION_MINOR 3
#define RL_READLINE_VERSION 0x0803

extern char *rl_readline_name;
extern char *rl_terminal_name;
extern char *rl_library_version;
extern int rl_readline_version;
extern int rl_gnu_readline_p;
extern char *rl_prompt;
extern char *rl_line_buffer;
extern int rl_point;
extern int rl_end;
extern int rl_done;
extern int rl_eof_found;
extern int rl_already_prompted;
extern int rl_num_chars_to_read;
extern unsigned long rl_readline_state;
extern int rl_completion_append_character;
extern int rl_completion_suppress_append;
extern int rl_completion_type;
extern int rl_attempted_completion_over;
extern int rl_completion_query_items;
extern int rl_catch_signals;
extern int rl_catch_sigwinch;
extern char *rl_basic_word_break_characters;
extern char *rl_completer_word_break_characters;
extern const char *rl_basic_quote_characters;
extern const char *rl_completer_quote_characters;
extern const char *rl_filename_quote_characters;
extern int rl_filename_completion_desired;
extern int rl_ignore_completion_duplicates;
extern int rl_sort_completion_matches;
extern int rl_visible_stats;
extern int _rl_complete_mark_directories;
extern int _rl_completion_prefix_display_length;
extern int _rl_print_completions_horizontally;
extern int _rl_term_autowrap;
extern rl_completion_func_t *rl_attempted_completion_function;
extern rl_cpvfunc_t *rl_completion_word_break_hook;
extern rl_compdisp_func_t *rl_completion_display_matches_hook;
extern rl_icppfunc_t *rl_directory_completion_hook;
extern rl_filename_quoting_func_t *rl_filename_quoting_function;
extern rl_filename_dequoting_func_t *rl_filename_dequoting_function;
extern FILE *rl_instream;
extern FILE *rl_outstream;
extern rl_hook_func_t *rl_startup_hook;
extern rl_hook_func_t *rl_pre_input_hook;
extern rl_hook_func_t *rl_event_hook;
extern rl_hook_func_t *rl_signal_event_hook;
extern rl_hook_func_t *rl_timeout_event_hook;
extern rl_hook_func_t *rl_input_available_hook;
extern rl_getc_func_t *rl_getc_function;
extern rl_voidfunc_t *rl_deprep_term_function;
extern rl_vintfunc_t *rl_prep_term_function;
extern rl_macro_print_func_t *rl_macro_display_hook;
extern Keymap rl_executing_keymap;
extern Keymap rl_binding_keymap;

#define READERR (-2)
#define RL_STATE_NONE 0x00000000UL
#define RL_STATE_INITIALIZING 0x00000001UL
#define RL_STATE_INITIALIZED 0x00000002UL
#define RL_STATE_TERMPREPPED 0x00000004UL
#define RL_STATE_READCMD 0x00000008UL
#define RL_STATE_METANEXT 0x00000010UL
#define RL_STATE_DISPATCHING 0x00000020UL
#define RL_STATE_MOREINPUT 0x00000040UL
#define RL_STATE_ISEARCH 0x00000080UL
#define RL_STATE_NSEARCH 0x00000100UL
#define RL_STATE_SEARCH 0x00000200UL
#define RL_STATE_NUMERICARG 0x00000400UL
#define RL_STATE_MACROINPUT 0x00000800UL
#define RL_STATE_MACRODEF 0x00001000UL
#define RL_STATE_OVERWRITE 0x00002000UL
#define RL_STATE_COMPLETING 0x00004000UL
#define RL_STATE_SIGHANDLER 0x00008000UL
#define RL_STATE_UNDOING 0x00010000UL
#define RL_STATE_INPUTPENDING 0x00020000UL
#define RL_STATE_TTYCSAVED 0x00040000UL
#define RL_STATE_CALLBACK 0x00080000UL
#define RL_STATE_VIMOTION 0x00100000UL
#define RL_STATE_MULTIKEY 0x00200000UL
#define RL_STATE_VICMDONCE 0x00400000UL
#define RL_STATE_CHARSEARCH 0x00800000UL
#define RL_STATE_REDISPLAYING 0x01000000UL
#define RL_STATE_DONE 0x02000000UL
#define RL_STATE_TIMEOUT 0x04000000UL
#define RL_STATE_EOF 0x08000000UL
#define RL_STATE_READSTR 0x10000000UL
#define RL_SETSTATE(x) (rl_readline_state |= (x))
#define RL_UNSETSTATE(x) (rl_readline_state &= ~(x))
#define RL_ISSTATE(x) (rl_readline_state & (x))

char *readline(const char *prompt);
int rl_initialize(void);
void rl_cleanup_after_signal(void);
void rl_reset_after_signal(void);
void rl_free_line_state(void);
void rl_deprep_terminal(void);
int rl_prep_terminal(int meta_flag);
int rl_set_prompt(const char *prompt);
int rl_on_new_line(void);
int rl_newline(int count, int key);
int rl_redisplay(void);
int rl_forced_update_display(void);
void _rl_erase_entire_line(void);
int _rl_qsort_string_compare(const void *left, const void *right);
void rl_replace_line(const char *text, int clear_undo);
int rl_insert_text(const char *text);
int rl_bind_key(int key, rl_command_func_t *function);
int rl_bind_key_in_map(int key, rl_command_func_t *function, Keymap map);
int rl_bind_keyseq(const char *keyseq, rl_command_func_t *function);
int rl_variable_bind(const char *variable, const char *value);
char *rl_variable_value(const char *variable);
int rl_parse_and_bind(char *line);
int rl_read_init_file(const char *filename);
int rl_add_defun(const char *name, rl_command_func_t *function, int key);
char **rl_completion_matches(const char *text, rl_compentry_func_t *entry_func);
char *rl_filename_completion_function(const char *text, int state);
char *rl_username_completion_function(const char *text, int state);
char *rl_copy_text(int start, int end);
int rl_extend_line_buffer(int len);
int rl_ding(void);
int rl_abort(int count, int key);
int rl_insert(int count, int key);
int rl_complete(int count, int key);
int rl_tilde_expand(int count, int key);
void rl_free(void *mem);
int rl_modifying(int start, int end);
int rl_history_search_forward(int count, int key);
int rl_history_search_backward(int count, int key);
int rl_get_previous_history(int count, int key);
int rl_reset_terminal(const char *terminal_name);
void rl_resize_terminal(void);
void rl_set_screen_size(int rows, int cols);
void rl_get_screen_size(int *rows, int *cols);
void rl_reset_screen_size(void);
int rl_set_signals(void);
int rl_clear_signals(void);
int rl_pending_signal(void);
int rl_check_signals(void);
int rl_set_timeout(unsigned int seconds, unsigned int useconds);
int rl_timeout_remaining(unsigned int *seconds, unsigned int *useconds);
int rl_getc(FILE *stream);
int rl_read_key(void);
int rl_crlf(void);
char *rl_untranslate_keyseq(int key);
void rl_callback_handler_install(const char *prompt, rl_vcpfunc_t *handler);
void rl_callback_read_char(void);
void rl_callback_handler_remove(void);
void rl_callback_sigcleanup(void);

Keymap rl_make_bare_keymap(void);
Keymap rl_make_keymap(void);
Keymap rl_copy_keymap(Keymap map);
void rl_discard_keymap(Keymap map);
void rl_free_keymap(Keymap map);
Keymap rl_get_keymap_by_name(const char *name);
char *rl_get_keymap_name(Keymap map);
void rl_set_keymap(Keymap map);
Keymap rl_get_keymap(void);
int rl_set_keymap_name(const char *name, Keymap map);

#ifdef __cplusplus
}
#endif

#endif
