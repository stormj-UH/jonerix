#ifndef READLINEOXIDE_HISTORY_H
#define READLINEOXIDE_HISTORY_H

#include <time.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef void *histdata_t;

typedef struct _hist_entry {
    char *line;
    char *timestamp;
    histdata_t data;
} HIST_ENTRY;

typedef struct _hist_state {
    HIST_ENTRY **entries;
    int offset;
    int length;
    int size;
    int flags;
} HISTORY_STATE;

extern int history_base;
extern int history_length;
extern int history_max_entries;
extern int history_offset;
extern int history_write_timestamps;

void using_history(void);
void add_history(const char *line);
void add_history_time(const char *string);
void clear_history(void);
void stifle_history(int max);
int unstifle_history(void);
int history_is_stifled(void);
HIST_ENTRY **history_list(void);
HIST_ENTRY *history_get(int offset);
time_t history_get_time(HIST_ENTRY *entry);
HISTORY_STATE *history_get_history_state(void);
HISTORY_STATE *history_get_state(void);
void history_set_history_state(HISTORY_STATE *state);
int where_history(void);
int history_set_pos(int pos);
HIST_ENTRY *current_history(void);
HIST_ENTRY *previous_history(void);
HIST_ENTRY *next_history(void);
HIST_ENTRY *remove_history(int which);
HIST_ENTRY *replace_history_entry(int which, const char *line, histdata_t data);
histdata_t free_history_entry(HIST_ENTRY *entry);
int read_history(const char *filename);
int read_history_range(const char *filename, int from, int to);
int write_history(const char *filename);
int append_history(int nelements, const char *filename);
int history_truncate_file(const char *filename, int nlines);
int history_expand(char *string, char **output);
char **history_tokenize(const char *string);

#ifdef __cplusplus
}
#endif

#endif
