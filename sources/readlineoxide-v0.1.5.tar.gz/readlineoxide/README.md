# readlineoxide

`readlineoxide` is a clean-room Rust compatibility layer for the
`libreadline` and `libhistory` C ABIs used by Unix command-line programs.

The goal is to give jonerix a permissive replacement for the GPL-3 GNU
Readline dependency. The implementation is intentionally derived from the
public C ABI, documented behavior, and black-box test results, not from GNU
Readline source or decompiled output.

## Scope

The current implementation provides:

- `readline(3)` with prompt display and line allocation semantics.
- Basic `libhistory` storage, traversal, replacement, removal, and history
  file read/write functions.
- Common readline globals and no-op terminal/customization hooks so configure
  probes and simple consumers can link.
- Public compatibility macros and hooks used by common consumers such as
  Python's `_readline` extension and GDB's system-readline configure probe.
- Compatibility headers under `include/readline/`.

This is not yet a full interactive editor. Completion, keymaps, inputrc
parsing, undo state, and terminal redisplay semantics are stubbed or minimal.

## Validation

Local validation starts with `cargo test --locked` and
`sh tests/run-simulations.sh`. GNU Readline release tarballs do not ship a
substantive top-level test suite; the external black-box probe is
`GNU_READLINE_SRC=/path/to/readline-8.3 sh tests/run-gnu-readline-examples.sh`,
which compiles selected upstream examples against the readlineoxide headers and
libraries without vendoring GPL test artifacts into this MIT source tree.
