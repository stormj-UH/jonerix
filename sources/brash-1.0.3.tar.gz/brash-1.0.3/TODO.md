# brash TODO

## Now: bash upstream test suite

Continue testing to pass bash test suite.

Current state: 67/82 (will fluctuate around there as round-2 fixes settle).

Largest remaining: `cond` (38), `nameref` (32), `errors` (32), `extglob` (30), `exp` (27), `tilde2` (24), `new-exp` (18), `dbg-support` (15), `assoc` (12), `array` (12), `posixexp` (8), `redir` (6), `printf` (6 — flaky), `comsub` (4), `exportfunc` (4), `varenv` (2).

## Next: completeness measurement beyond the upstream suite

The upstream test suite is necessary but narrow — it only exercises features bash devs explicitly chose to test. After we close it, measure real-world drop-in completeness with these complementary tools:

### 1. Differential testing on real-world scripts (highest signal)

Run a corpus of popular real shell scripts under both `bash` and `brash`, diff stdout/stderr/exit-code line-by-line. A "pass" means byte-identical output.

Useful corpora:
- `./configure` scripts from a few hundred autotools projects (autoconf-generated → exercises every weird shell quirk)
- Homebrew formulas (the install/test phases run shell heavily)
- Linux package post-install scripts (`/usr/share/dpkg`, RPM `%post`)
- Common dotfiles repos (`oh-my-bash`, sensible-defaults, etc.)
- `git`'s own hooks and shell scripts under `git/contrib/`
- `direnv`, `asdf`, `nvm` — these inject shell into your environment
- All scripts under `/etc/init.d` of a minimal Linux

Concrete deliverable: `tests/realworld/` with ~20 vetted real scripts and a `make realworld` that runs them under both shells and reports % byte-identical.

### 2. Differential fuzzing

Generate random valid-ish shell scripts, run them under both shells with identical state, diff outputs. Bugs are anywhere they disagree.

Tools:
- AFL++ in differential mode with bash + brash
- `sh-fuzz` / custom seeded generators
- Coverage-guided generators that produce more parser-stressing input

Concrete deliverable: a one-shot fuzz harness that generates 100 programs/sec, diffs outputs against bash, saves divergences. Run on every commit.

### 3. Boot tests / system-level use

Strongest possible measure: replace `/bin/sh` with brash and boot.

- Boot a minimal Linux (Alpine or Debian) with brash as `/bin/sh`
- Build a package with brash as the build shell
- Count which `/etc/init.d/*` scripts run cleanly

A "drop-in clone" that fails to boot init isn't drop-in.

### 4. Manual feature audit against the bash manual

The GNU bash manual has ~125 documented features. Build a checklist:

- Every builtin × every documented flag → works/doesn't
- Every `set -X` and `shopt` option → works/doesn't
- Every `BASH_*` / `BASH*` variable → present and behaves
- Every parameter expansion form (`${var,...}`)
- Every special variable (`$$`, `$!`, `$_`, etc.)

Concrete deliverable: a markdown matrix tracking each documented feature × implementation status. Tied to commits — every PR ticks new boxes.

### 5. Tooling-level smoke tests

Real-world ecosystems that exercise bash deeply:

- Run the **bash-completion** repo's tests under brash
- Run **bats** (bash automated testing) under brash, verify its self-tests pass
- Run **shellcheck**'s test corpus
- Run **shfmt**'s formatter test corpus

If brash can host the major bash tooling without modification, that's strong evidence of drop-in compatibility.

### 6. POSIX conformance (orthogonal but useful)

POSIX has its own test corpora that are independent of bash:

- The Open Group's POSIX shell test suite (paywalled but partial copies floating around)
- `dash`'s test suite (POSIX-only — passing dash's tests proves the POSIX subset)
- `mksh`'s test suite

### 7. Performance / behavior benchmarks

Not correctness but adjacent:

- `shellbench` — running both under common operations (function calls, arithmetic, glob)
- Startup time
- Memory under load
- Job control timing

Massive performance divergence is itself a "drop-in" failure for users with strict time budgets.

### Suggested concrete next steps (after upstream suite ≥ 80/82)

1. **Add `tests/realworld/` corpus** — 10–20 real autoconf `configure` scripts, run-and-diff against bash, score % byte-identical.
2. **Wire bats**: clone `bats-core`, run its self-tests with `BATS_BIN_SHELL=brash`. Score = % bats self-tests pass.
3. **Bash manual checklist file**: markdown matrix of every documented feature × implementation status.
4. **One-shot fuzz harness**: 100 random programs/sec, diff outputs, save divergences. Run on every commit.

The bash test suite at 67/82 is encouraging but only proves the test suite passes — the four measures above are what tell whether brash actually works as a `bash` replacement in practice.
