use std::cell::Cell;
use std::collections::{BTreeMap, HashMap, HashSet};

/// Faster HashMap for associative-array storage: ahash instead of SipHash.
type AssocMap = ahash::AHashMap<String, String>;

// ---------------------------------------------------------------------------
// Bash-compatible FNV hash for associative-array iteration order
// ---------------------------------------------------------------------------

/// Bash's FNV-1 hash variant (see bash hashlib.c).
/// Used to produce the same associative-array iteration order as bash.
fn bash_fnv_hash(s: &str) -> u32 {
    const FNV_OFFSET: u32 = 2166136261;
    let mut h: u32 = FNV_OFFSET;
    for &b in s.as_bytes() {
        // FNV-1 multiply step (matches bash's bit-shift expansion)
        h = h.wrapping_add(h.wrapping_shl(1))
            .wrapping_add(h.wrapping_shl(4))
            .wrapping_add(h.wrapping_shl(7))
            .wrapping_add(h.wrapping_shl(8))
            .wrapping_add(h.wrapping_shl(24));
        h ^= b as u32;
    }
    h
}

/// Generic bash associative arrays use 1024 buckets (ASSOC_HASH_BUCKETS from
/// assoc.h).  Dynamic mirrors like BASH_ALIASES / BASH_CMDS follow the
/// underlying alias/hash-table walk order instead, which uses 256 buckets in
/// the Homebrew bash build we diff against.
///
/// When bash converts an existing non-assoc variable to an assoc array, it
/// allocates a smaller initial hash table (128 buckets), resulting in a
/// different iteration order than a freshly-created assoc array (1024 buckets).
const BASH_NBUCKETS: u32 = 1024;
const BASH_NBUCKETS_CONVERTED: u32 = 128;
const BASH_ALIAS_NBUCKETS: u32 = 64;
const BASH_DYNAMIC_NBUCKETS: u32 = 256;

/// Return the bash hash bucket for a key.
fn bash_bucket(key: &str, buckets: u32) -> u32 {
    bash_fnv_hash(key) & (buckets - 1)
}

/// Sort associative-array entries into bash's iteration order using the given
/// bucket count.
fn bash_sorted_entries_n(map: &AssocMap, nbuckets: u32) -> Vec<(&String, &String)> {
    let mut entries: Vec<(&String, &String)> = map.iter().collect();
    entries.sort_by_key(|(k, _)| bash_bucket(k, nbuckets));
    entries
}

/// Sort associative-array entries into bash's iteration order.
fn bash_sorted_entries(map: &AssocMap) -> Vec<(&String, &String)> {
    bash_sorted_entries_n(map, BASH_NBUCKETS)
}

/// Sort Bash's dynamic mirror arrays (BASH_ALIASES / BASH_CMDS) into the
/// same bucket-walk order used by the underlying alias/hash tables.
fn bash_sorted_dynamic_entries(map: &AssocMap) -> Vec<(&String, &String)> {
    let mut entries: Vec<(&String, &String)> = map.iter().collect();
    entries.sort_by_key(|(k, _)| bash_bucket(k, BASH_DYNAMIC_NBUCKETS));
    entries
}

fn bash_sorted_alias_entries(map: &AssocMap) -> Vec<(&String, &String)> {
    let mut entries: Vec<(&String, &String)> = map.iter().collect();
    entries.sort_by_key(|(k, _)| bash_bucket(k, BASH_ALIAS_NBUCKETS));
    entries
}

pub fn bash_hash_walk_entries<S: std::hash::BuildHasher>(
    map: &HashMap<String, String, S>
) -> Vec<(String, String)> {
    // shell.hash_table — replicate bash_sorted_dynamic_entries inline.
    let mut entries: Vec<(&String, &String)> = map.iter().collect();
    entries.sort_by_key(|(k, _)| bash_bucket(k, BASH_DYNAMIC_NBUCKETS));
    entries
        .into_iter()
        .map(|(k, v)| (k.clone(), v.clone()))
        .collect()
}

// ---------------------------------------------------------------------------
// Public types
// ---------------------------------------------------------------------------

#[derive(Clone)]
pub struct Variables {
    /// Stack of scopes; the last element is the innermost (current) scope.
    /// The first element (index 0) is the global / session scope.
    scopes: Vec<Scope>,
    /// Number of positional parameters currently set.
    pub positional_count: usize,
    /// Whether POSIX mode is enabled (affects tilde expansion rules, etc.)
    pub posix_mode: bool,
    /// Whether `set -u` (nounset) is in effect.  Mirrored here so
    /// the stateless expansion helpers can error on unset vars.
    pub nounset: bool,
    /// Mirrors `shopt -s localvar_unset`, which changes how unset outer
    /// locals are resolved after a nested function unsets them.
    pub localvar_unset: bool,
    /// Error prefix for readonly variable messages (e.g. "scriptname: line N").
    /// Updated by the shell before operations that may emit readonly errors.
    pub error_prefix: String,
    /// When true, certain nameref error messages (e.g. "not a valid identifier"
    /// from an unresolved-nameref assignment) should include the "((" prefix to
    /// match bash's behaviour for errors originating inside `(( expr ))`.
    pub in_arith_cmd: bool,
    /// Set by set() when an unresolved-nameref assignment is rejected because
    /// the value is not a valid identifier (e.g. `foo=7*6` when foo is a
    /// nameref with no target).  Cleared by exec.rs after each standalone
    /// assignment so the abort-list mechanism can fire exactly once per error.
    pub nameref_invalid_target_abort: bool,
    /// Names temporarily forced to resolve against the global scope.
    /// Used by `declare -g` so builtin internals bypass caller locals.
    prefer_global_names: HashSet<String>,
    random_state: Cell<u32>,
    last_random: Cell<u32>,
    /// Bash's tilde-home cache.  Initialised at shell startup from the
    /// startup `$HOME` env var (or passwd fallback if unset), and
    /// refreshed at every fork to the current `$HOME` value at fork
    /// time.  All `~` expansions read from this cache rather than from
    /// passwd or current vars.HOME directly.  This matches bash's
    /// observed behaviour on the tilde2 test.
    pub home_cache: Option<String>,
}

#[derive(Clone)]
pub struct RawBindingSnapshot(Vec<(usize, VarEntry)>);

#[derive(Clone)]
struct Scope {
    /// ahash-backed map for faster variable lookups (every access hashes a
    /// variable name; ahash is ~2x faster than SipHash for short strings).
    vars: ahash::AHashMap<String, VarEntry>,
    /// True if this scope was pushed for a prefix assignment to a
    /// function call (e.g. `var=hello func`).  Used by `typeset NAME`
    /// with no value: names living in a tempenv scope are inherited
    /// into the function's new local, matching bash's semantics where
    /// `var=hello func; func(){ typeset var; }` sees var=hello.
    /// Set by push_tempenv_scope; read indirectly through the scope's
    /// presence in `tempenv_names` on Shell rather than via this flag,
    /// so the field is currently a structural marker only.
    #[allow(dead_code)]
    tempenv: bool,
}

#[derive(Clone)]
struct VarEntry {
    value: VarValue,
    exported: bool,
    readonly: bool,
    integer: bool,
    lowercase: bool,
    uppercase: bool,
    capitalize: bool,
    nameref: bool,
    /// Whether the variable has ever been assigned a value (as
    /// opposed to just declared).  Bash distinguishes these in
    /// `declare -p`: `declare -x foo` vs `declare -x foo=""`.
    initialized: bool,
    local: bool,
    hidden_unset: bool,
    /// Hash-bucket count for assoc-array iteration order.  0 means use the
    /// default (BASH_NBUCKETS = 1024).  Set to BASH_NBUCKETS_CONVERTED (128)
    /// when bash converts a pre-existing non-assoc variable to an assoc array,
    /// because bash allocates a smaller initial hash table in that path.
    assoc_nbuckets: u32,
}

#[derive(Clone)]
enum VarValue {
    Scalar(String),
    /// Indexed array.  Elements may be sparsely set: `None` means the slot
    /// exists in the internal Vec (to keep other indices aligned) but is
    /// *unset* from bash's point of view — `${arr[i]}` expands to empty,
    /// iteration via `${arr[@]}` skips it, and `${#arr[@]}` does not count
    /// it.  `Some(s)` is a real element (possibly the empty string).
    Array(IndexedArray),
    AssocArray(AssocMap),
    Unset,
}

const ARRAY_DENSE_LIMIT: usize = 1 << 24;

#[derive(Clone)]
struct IndexedArray {
    dense: Vec<Option<String>>,
    sparse: BTreeMap<usize, String>,
}

/// Result of trying to seed a new local variable from an outer scope.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum LocalInheritResult {
    Inherited,
    NotFound,
    Readonly,
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

impl VarEntry {
    fn new_scalar(value: &str) -> Self {
        VarEntry {
            value: VarValue::Scalar(value.to_owned()),
            exported: false,
            readonly: false,
            integer: false,
            lowercase: false,
            uppercase: false,
            capitalize: false,
            nameref: false,
            initialized: true,
            local: false,
            hidden_unset: false,
            assoc_nbuckets: 0,
        }
    }

    fn new_unset() -> Self {
        VarEntry {
            value: VarValue::Unset,
            exported: false,
            readonly: false,
            integer: false,
            lowercase: false,
            uppercase: false,
            capitalize: false,
            nameref: false,
            initialized: false,
            local: false,
            hidden_unset: false,
            assoc_nbuckets: 0,
        }
    }

    /// Apply lowercase / uppercase / capitalize transforms when the flag is set.
    fn coerce_scalar(&self, raw: &str) -> String {
        if self.lowercase {
            raw.to_lowercase()
        } else if self.uppercase {
            raw.to_uppercase()
        } else if self.capitalize {
            let mut chars = raw.chars();
            match chars.next() {
                None => String::new(),
                Some(c) => {
                    let rest: String = chars.collect();
                    let mut result = String::new();
                    result.extend(c.to_uppercase());
                    result.push_str(&rest.to_lowercase());
                    result
                }
            }
        } else {
            raw.to_owned()
        }
    }

    /// Run all applicable coercions in the correct order (without integer eval).
    fn coerce(&self, raw: &str) -> String {
        self.coerce_scalar(raw)
    }
}

impl IndexedArray {
    fn new() -> Self {
        IndexedArray {
            dense: Vec::new(),
            sparse: BTreeMap::new(),
        }
    }

    fn from_values(values: Vec<String>) -> Self {
        IndexedArray {
            dense: values.into_iter().map(Some).collect(),
            sparse: BTreeMap::new(),
        }
    }

    fn first(&self) -> Option<String> {
        self.get(0)
    }

    fn get(&self, idx: usize) -> Option<String> {
        if idx <= ARRAY_DENSE_LIMIT {
            self.dense.get(idx).and_then(|o| o.clone())
        } else {
            self.sparse.get(&idx).cloned()
        }
    }

    fn set(&mut self, idx: usize, value: String) {
        if idx <= ARRAY_DENSE_LIMIT {
            if idx >= self.dense.len() {
                self.dense.resize(idx + 1, None);
            }
            self.dense[idx] = Some(value);
            self.sparse.remove(&idx);
        } else {
            self.sparse.insert(idx, value);
        }
    }

    fn unset(&mut self, idx: usize) -> bool {
        if idx <= ARRAY_DENSE_LIMIT {
            if idx < self.dense.len() && self.dense[idx].is_some() {
                self.dense[idx] = None;
                while self.dense.last().map_or(false, |o| o.is_none()) {
                    self.dense.pop();
                }
                true
            } else {
                false
            }
        } else {
            self.sparse.remove(&idx).is_some()
        }
    }

    fn len_set(&self) -> usize {
        self.dense.iter().filter(|o| o.is_some()).count() + self.sparse.len()
    }

    fn values(&self) -> Vec<String> {
        self.entries().into_iter().map(|(_, v)| v).collect()
    }

    fn entries(&self) -> Vec<(usize, String)> {
        let mut out: Vec<(usize, String)> = self.dense.iter().enumerate()
            .filter_map(|(i, o)| o.as_ref().map(|v| (i, v.clone())))
            .collect();
        out.extend(self.sparse.iter().map(|(i, v)| (*i, v.clone())));
        out
    }

    fn max_index(&self) -> Option<usize> {
        let dense_max = self.dense.iter().enumerate()
            .rev()
            .find_map(|(i, o)| if o.is_some() { Some(i) } else { None });
        let sparse_max = self.sparse.last_key_value().map(|(i, _)| *i);
        match (dense_max, sparse_max) {
            (Some(a), Some(b)) => Some(a.max(b)),
            (Some(a), None) => Some(a),
            (None, Some(b)) => Some(b),
            (None, None) => None,
        }
    }

    fn push(&mut self, value: String) {
        let idx = self.max_index().map(|m| m + 1).unwrap_or(0);
        self.set(idx, value);
    }
}

impl Scope {
    fn new() -> Self {
        Scope {
            vars: ahash::AHashMap::new(),
            tempenv: false,
        }
    }
}

// ---------------------------------------------------------------------------
// Variables implementation
// ---------------------------------------------------------------------------

impl Variables {
    // ------------------------------------------------------------------
    // Construction
    // ------------------------------------------------------------------

    fn sync_process_locale(&self) {
        for name in ["LC_ALL", "LC_CTYPE", "LANG"] {
            if let Some(val) = self.get(name).filter(|s| !s.is_empty()) {
                unsafe { std::env::set_var(name, val); }
            } else {
                unsafe { std::env::remove_var(name); }
            }
        }
        let locale = self.get("LC_ALL")
            .filter(|s| !s.is_empty())
            .or_else(|| self.get("LC_CTYPE").filter(|s| !s.is_empty()))
            .or_else(|| self.get("LANG").filter(|s| !s.is_empty()));
        unsafe {
            match locale {
                Some(loc) => {
                    if let Ok(c_loc) = std::ffi::CString::new(loc) {
                        libc::setlocale(libc::LC_ALL, c_loc.as_ptr());
                    }
                }
                None => {
                    if let Ok(empty) = std::ffi::CString::new("") {
                        libc::setlocale(libc::LC_ALL, empty.as_ptr());
                    }
                }
            }
        }
    }

    pub fn new() -> Self {
        // Start with a single global scope.
        // Initialise home_cache from startup env HOME, falling back to passwd.
        let home_cache = std::env::var("HOME").ok()
            .filter(|h| !h.is_empty())
            .or_else(|| {
                // Look up passwd entry as last resort
                let uid = unsafe { libc::getuid() };
                unsafe {
                    let pwd = libc::getpwuid(uid);
                    if pwd.is_null() { return None; }
                    let dir = (*pwd).pw_dir;
                    if dir.is_null() { return None; }
                    std::ffi::CStr::from_ptr(dir).to_str().ok().map(String::from)
                }
            });
        let mut vars = Variables {
            scopes: vec![Scope::new()],
            positional_count: 0,
            posix_mode: false,
            nounset: false,
            localvar_unset: false,
            error_prefix: crate::exec::shell_name().to_owned(),
            in_arith_cmd: false,
            nameref_invalid_target_abort: false,
            prefer_global_names: HashSet::new(),
            random_state: Cell::new(
                std::time::SystemTime::now()
                    .duration_since(std::time::UNIX_EPOCH)
                    .unwrap_or_default()
                    .subsec_nanos()
            ),
            last_random: Cell::new(0),
            home_cache,
        };
        vars.set_integer("RANDOM");
        vars
    }

    /// Refresh the tilde-home cache to the current value of `$HOME`.
    /// Bash performs this refresh at every fork (external command, command
    /// substitution).  Subsequent `~` expansions in the parent shell will
    /// reflect the value of `$HOME` as it was at fork time.
    pub fn refresh_home_cache(&mut self) {
        if let Some(h) = self.get("HOME") {
            self.home_cache = Some(h);
        }
    }

    // ------------------------------------------------------------------
    // Scope management
    // ------------------------------------------------------------------

    pub fn push_scope(&mut self) {
        self.scopes.push(Scope::new());
    }

    /// Push a scope marked as a "tempenv" — used for prefix assignments
    /// applied to a function call (`var=hello func`).  The flag lets
    /// `typeset NAME` decide whether to inherit a value from above.
    /// Currently the executor uses Shell::tempenv_names directly; this
    /// helper is kept for the planned scope-flag-driven path.
    #[allow(dead_code)]
    pub fn push_tempenv_scope(&mut self) {
        let mut s = Scope::new();
        s.tempenv = true;
        self.scopes.push(s);
    }

    pub fn pop_scope(&mut self) {
        // Never remove the global scope.
        if self.scopes.len() > 1 {
            // Only re-sync the process locale if the outgoing scope actually
            // contained a locale-affecting variable.  For the common case of
            // a tight loop with simple scalar assignments the scope holds
            // nothing locale-related, so we skip the setlocale() syscall.
            let needs_locale_sync = {
                let top = self.scopes.last().unwrap();
                top.vars.contains_key("LC_ALL")
                    || top.vars.contains_key("LC_CTYPE")
                    || top.vars.contains_key("LANG")
            };
            self.scopes.pop();
            if needs_locale_sync {
                self.sync_process_locale();
            }
        }
    }

    /// True if the scope at `idx` was pushed as a tempenv.
    /// Today the executor reads `Shell::tempenv_names` for this; the scope
    /// flag is captured for the planned scope-flag-driven path.
    #[allow(dead_code)]
    pub fn is_tempenv_scope(&self, idx: usize) -> bool {
        self.scopes.get(idx).map(|s| s.tempenv).unwrap_or(false)
    }

    /// Returns true when we are inside a function scope (scope depth > 1).
    pub fn in_function_scope(&self) -> bool {
        self.scopes.len() > 1
    }

    /// Returns the index of the current (innermost) scope.
    pub fn current_scope_idx(&self) -> usize {
        self.scopes.len() - 1
    }

    /// Ensure that `name` has an entry in the scope at `scope_idx`,
    /// creating an empty unset entry if needed. Used when declaring
    /// local array variables before assigning elements.
    pub fn ensure_scope_entry(&mut self, scope_idx: usize, name: &str) {
        if scope_idx < self.scopes.len() && !self.scopes[scope_idx].vars.contains_key(name) {
            self.scopes[scope_idx].vars.insert(name.to_string(), VarEntry {
                value: VarValue::Unset,
                exported: false,
                readonly: false,
                integer: false,
                lowercase: false,
                uppercase: false,
                capitalize: false,
                nameref: false,
                initialized: false,
                local: scope_idx > 0,
                hidden_unset: false,
                assoc_nbuckets: 0,
            });
        }
    }

    // ------------------------------------------------------------------
    // Internal helpers
    // ------------------------------------------------------------------

    /// Index of the innermost scope.
    #[inline]
    fn current_idx(&self) -> usize {
        self.scopes.len() - 1
    }

    /// Find the scope index that owns `name`, searching from innermost outward.
    fn find_scope(&self, name: &str) -> Option<usize> {
        if self.prefer_global_names.contains(name) {
            return self.scopes[0].vars.contains_key(name).then_some(0);
        }
        self.find_scope_raw(name)
    }

    /// Raw scope lookup that ignores any temporary global-preference override.
    pub fn find_scope_raw(&self, name: &str) -> Option<usize> {
        let cur = self.current_idx();
        for i in (0..self.scopes.len()).rev() {
            if let Some(entry) = self.scopes[i].vars.get(name) {
                if entry.hidden_unset && (i < cur || (i == cur && !self.localvar_unset)) {
                    continue;
                }
                return Some(i);
            }
        }
        None
    }

    /// Public equivalent of `find_scope` — returns the scope index that
    /// holds `name`, or None if the name is absent.  Currently no in-tree
    /// caller; kept as the public API for embedders.
    #[allow(dead_code)]
    pub fn find_scope_pub(&self, name: &str) -> Option<usize> {
        self.find_scope(name)
    }

    /// Get a reference to an entry, searching from innermost outward.
    fn get_entry(&self, name: &str) -> Option<&VarEntry> {
        let resolved = self.resolve_nameref(name);
        let lookup = resolved.as_deref().unwrap_or(name);
        let idx = self.find_scope(lookup)?;
        self.scopes[idx].vars.get(lookup)
    }

    /// Raw (nameref-bypass) entry lookup — returns the variable by its
    /// literal name, without following the nameref chain.  Used by
    /// resolve_nameref and by callers that explicitly want to inspect
    /// or set the nameref attribute itself.
    fn get_entry_raw(&self, name: &str) -> Option<&VarEntry> {
        let idx = self.find_scope(name)?;
        self.scopes[idx].vars.get(name)
    }

    fn get_entry_raw_global(&self, name: &str) -> Option<&VarEntry> {
        self.scopes.first()?.vars.get(name)
    }

    /// Follow a chain of namerefs starting at `name` and return the
    /// final target name, or None if `name` is not a nameref.
    /// Replicates bash's `_find_variable_nameref` logic — depth 9 max,
    /// with circular-reference detection.
    pub fn resolve_nameref(&self, name: &str) -> Option<String> {
        // Fast path: the overwhelmingly common case is `name` not being a
        // nameref at all.  Avoid the to_string() and the loop allocation
        // entirely for that case — every var lookup goes through here.
        match self.get_entry_raw(name) {
            None => return None,
            Some(e) if !e.nameref => return None,
            _ => {}
        }
        let mut current = name.to_string();
        let mut depth = 9;
        loop {
            let entry = match self.get_entry_raw(&current) {
                Some(e) => e,
                None => return if current == name { None } else { Some(current) },
            };
            if !entry.nameref {
                return if current == name { None } else { Some(current) };
            }
            depth -= 1;
            if depth == 0 {
                // Give up silently — bash emits a warning in the real
                // implementation; here we treat it as "not found".
                return None;
            }
            let target = match &entry.value {
                VarValue::Scalar(s) => s.clone(),
                _ => return None,
            };
            if target.is_empty() || target == current || target == name {
                return None;
            }
            current = target;
        }
    }

    pub fn resolve_nameref_global(&self, name: &str) -> Option<String> {
        let mut current = name.to_string();
        let mut depth = 9;
        loop {
            let entry = match self.get_entry_raw_global(&current) {
                Some(e) => e,
                None => return if current == name { None } else { Some(current) },
            };
            if !entry.nameref {
                return if current == name { None } else { Some(current) };
            }
            depth -= 1;
            if depth == 0 {
                return None;
            }
            let target = match &entry.value {
                VarValue::Scalar(s) => s.clone(),
                _ => return None,
            };
            if target.is_empty() || target == current || target == name {
                return None;
            }
            current = target;
        }
    }

    pub fn is_valid_nameref_target(target: &str) -> bool {
        if target.is_empty() {
            return true;
        }
        if crate::exec::is_valid_identifier_pub(target) {
            return true;
        }
        crate::exec::parse_subscripted_name_pub(target)
            .map(|(base, _)| crate::exec::is_valid_identifier_pub(&base))
            .unwrap_or(false)
    }

    pub fn is_valid_assigned_nameref_target(target: &str) -> bool {
        !target.is_empty() && Self::is_valid_nameref_target(target)
    }

    fn has_circular_nameref(&self, name: &str) -> bool {
        let mut current = name.to_string();
        let mut seen: HashSet<String> = HashSet::new();
        loop {
            let entry = match self.get_entry_raw(&current) {
                Some(e) => e,
                None => return false,
            };
            if !entry.nameref {
                return false;
            }
            let target = match &entry.value {
                VarValue::Scalar(s) => s.as_str(),
                _ => return false,
            };
            if target.is_empty() || !Self::is_valid_nameref_target(target) {
                return false;
            }
            let next = if let Some((base, _)) = crate::exec::parse_subscripted_name_pub(target) {
                base
            } else {
                target.to_string()
            };
            if next == name || !seen.insert(next.clone()) {
                return true;
            }
            current = next;
        }
    }

    fn find_outer_scope_same_name(&self, name: &str) -> Option<usize> {
        let cur = self.current_idx();
        if cur == 0 {
            return None;
        }
        (0..cur).rev().find(|&i| self.scopes[i].vars.contains_key(name))
    }

    pub fn is_local_self_nameref_exact(&self, name: &str) -> bool {
        self.is_local_pub(name)
            && self.is_nameref(name)
            && self.get_raw_scalar(name).as_deref() == Some(name)
    }

    fn is_local_self_nameref_subscript(&self, name: &str) -> bool {
        if !(self.is_local_pub(name) && self.is_nameref(name)) {
            return false;
        }
        let raw = match self.get_raw_scalar(name) {
            Some(s) => s,
            None => return false,
        };
        crate::exec::parse_subscripted_name_pub(&raw)
            .map(|(base, _)| base == name)
            .unwrap_or(false)
    }

    fn get_local_self_nameref_outer_value(&self, name: &str) -> Option<String> {
        if !self.is_local_self_nameref_exact(name) {
            return None;
        }
        let outer = self.find_outer_scope_same_name(name)?;
        let entry = self.scopes[outer].vars.get(name)?;
        match &entry.value {
            VarValue::Scalar(s) => Some(s.clone()),
            VarValue::Array(arr) => {
                arr.first().or_else(|| Some(String::new()))
            }
            VarValue::AssocArray(map) => Some(map.get("0").cloned().unwrap_or_default()),
            VarValue::Unset => None,
        }
    }

    pub fn with_local_binding_hidden<R, F>(&mut self, name: &str, f: F) -> Option<R>
    where
        F: FnOnce(&mut Self) -> R,
    {
        let cur = self.current_idx();
        if cur == 0 || !self.scopes[cur].vars.contains_key(name) {
            return None;
        }
        let saved = self.scopes[cur].vars.remove(name);
        let result = f(self);
        if let Some(entry) = saved {
            self.scopes[cur].vars.insert(name.to_owned(), entry);
        }
        Some(result)
    }

    pub fn prefer_global_name(&mut self, name: &str) {
        self.prefer_global_names.insert(name.to_owned());
    }

    pub fn clear_prefer_global_name(&mut self, name: &str) {
        self.prefer_global_names.remove(name);
    }

    fn clear_hidden_unset_outers(&mut self, name: &str) {
        let cur = self.current_idx();
        for idx in 0..cur {
            let remove = self.scopes[idx]
                .vars
                .get(name)
                .map(|e| e.local && e.hidden_unset)
                .unwrap_or(false);
            if remove {
                self.scopes[idx].vars.remove(name);
            }
        }
    }

    /// Get a mutable reference to an entry.  If the variable does not exist
    /// in any scope, it is created in the **global** scope (index 0).
    /// In bash, variables assigned without `local` inside a function are global.
    fn get_entry_mut(&mut self, name: &str) -> &mut VarEntry {
        // Follow nameref chain before any mutation.
        let resolved = self.resolve_nameref(name);
        let target: String = resolved.unwrap_or_else(|| name.to_string());
        self.clear_hidden_unset_outers(&target);
        let idx = match self.find_scope(&target) {
            Some(i) => i,
            None => {
                self.scopes[0]
                    .vars
                    .insert(target.clone(), VarEntry::new_unset());
                0
            }
        };
        self.scopes[idx].vars.get_mut(&target).unwrap()
    }

    /// Like `get_entry_mut` but does not follow nameref chains.  Used
    /// when we want to touch the nameref variable itself (e.g. to set
    /// or unset the `nameref` attribute).
    fn get_entry_mut_raw(&mut self, name: &str) -> &mut VarEntry {
        let idx = match self.find_scope(name) {
            Some(i) => i,
            None => {
                self.scopes[0]
                    .vars
                    .insert(name.to_owned(), VarEntry::new_unset());
                0
            }
        };
        self.scopes[idx].vars.get_mut(name).unwrap()
    }

    /// Mark a variable as a nameref (`declare -n`).  Creates the entry
    /// in the innermost scope if it doesn't already exist.  Assumes
    /// the variable's value (if any) is already the target name.
    pub fn mark_nameref(&mut self, name: &str) {
        let entry = self.get_entry_mut_raw(name);
        entry.nameref = true;
    }

    pub fn mark_local_nameref(&mut self, name: &str) {
        let cur = self.current_idx();
        let entry = self.scopes[cur]
            .vars
            .entry(name.to_owned())
            .or_insert_with(VarEntry::new_unset);
        entry.nameref = true;
        entry.local = cur > 0;
    }

    /// Clear the nameref attribute.
    pub fn unmark_nameref(&mut self, name: &str) {
        if let Some(entry) = self.scopes.iter_mut().rev()
            .find_map(|s| s.vars.get_mut(name))
        {
            entry.nameref = false;
        }
    }

    pub fn strip_nameref_value(&mut self, name: &str) {
        let entry = self.get_entry_mut_raw(name);
        entry.nameref = false;
        entry.value = VarValue::Unset;
        entry.initialized = false;
    }

    /// Assign a scalar value to the literal variable `name` without
    /// following any nameref chain, and mark the entry as a nameref.
    /// Used by `declare -n name=target` / `typeset -n name=target`:
    /// bash stores `target` as the nameref's own string value so the
    /// resolver can find it, and subsequent `$name` expansions follow
    /// the nameref chain to `target`.
    ///
    /// Bash also validates the target string (`valid_nameref_value`
    /// in variables.c): it must be a plain NAME or NAME[subscript]
    /// and may not contain `=`, reserved chars, or self-reference.
    /// Returns true on success; prints a diagnostic and returns false
    /// on invalid target.
    pub fn set_nameref_target(&mut self, name: &str, target: &str) -> bool {
        if !Self::is_valid_assigned_nameref_target(target) {
            eprintln!("{}: `{}': not a valid identifier", self.error_prefix, target);
            return false;
        }
        if target == name {
            // Use the error_prefix field (set by the caller to the
            // current script/line) and the preceding command name is
            // emitted by the caller via a direct eprintln if needed
            // — mimic bash's `SCRIPT: line N: typeset: NAME: ...`.
            // Here we emit the generic form; the caller (declare
            // builtin) detects the self-ref before calling set_var
            // and uses its own cmd_name message, so this path is
            // only hit for corner cases where declare's check
            // doesn't fire (e.g. an empty get_nameref_target on a
            // freshly-created nameref whose target hasn't been
            // stored yet).
            eprintln!("{}: {}: nameref variable self references not allowed",
                self.error_prefix, name);
            return false;
        }
        // Empty target: bash stores it but `$name` expansion yields
        // nothing.  Allow the assignment silently.
        let entry = self.get_entry_mut_raw(name);
        if entry.readonly {
            eprintln!("{}: {}: readonly variable", self.error_prefix, name);
            return false;
        }
        entry.value = VarValue::Scalar(target.to_owned());
        entry.nameref = true;
        entry.initialized = true;
        true
    }

    pub fn set_local_nameref_target(&mut self, name: &str, target: &str) -> bool {
        if !Self::is_valid_assigned_nameref_target(target) {
            eprintln!("{}: `{}': not a valid identifier", self.error_prefix, target);
            return false;
        }
        let cur = self.current_idx();
        let entry = self.scopes[cur]
            .vars
            .entry(name.to_owned())
            .or_insert_with(VarEntry::new_unset);
        if entry.readonly {
            eprintln!("{}: {}: readonly variable", self.error_prefix, name);
            return false;
        }
        entry.value = VarValue::Scalar(target.to_owned());
        entry.nameref = true;
        entry.initialized = true;
        entry.local = cur > 0;
        true
    }

    /// Set a scalar value directly on the variable itself, bypassing any
    /// nameref chain.  Used for temp-env assignments to a function call when
    /// the nameref target is unresolved (empty or invalid): bash stores the
    /// value as the nameref's own scalar for the duration of the call without
    /// retargeting it, and also clears the nameref attribute so that inside
    /// the function the variable behaves as a plain scalar.
    ///
    /// The snapshot/restore mechanism in exec.rs will restore the original
    /// nameref entry (including the nameref attribute) after the call returns.
    pub fn set_value_direct_bypass_nameref(&mut self, name: &str, value: &str) {
        let entry = self.get_entry_mut_raw(name);
        entry.value = VarValue::Scalar(value.to_string());
        entry.nameref = false;
        entry.initialized = true;
    }

    // ------------------------------------------------------------------
    // Basic get / set / unset
    // ------------------------------------------------------------------

    /// Get the scalar representation of a variable, searching scopes top-down.
    pub fn get(&self, name: &str) -> Option<String> {
        if let Some(val) = self.get_local_self_nameref_outer_value(name) {
            eprintln!("{}: warning: {}: circular name reference",
                self.error_prefix, name);
            return Some(val);
        }
        // Before resolving through the raw entry, follow any nameref
        // chain.  If the chain ends at a subscripted target
        // (`arr[N]`), read the array element directly.
        if let Some(target) = self.resolve_nameref(name) {
            if target != name {
                if let Some(br) = target.find('[') {
                    if target.ends_with(']') {
                        let arr_name = &target[..br];
                        let idx_part = &target[br + 1..target.len() - 1];
                        if !arr_name.is_empty() {
                            if matches!(self.get_entry_raw(arr_name).map(|e| &e.value),
                                Some(VarValue::AssocArray(_)))
                            {
                                return self.get_assoc(arr_name, idx_part);
                            }
                            if let Ok(idx) = idx_part.parse::<usize>() {
                                return self.get_array_element(arr_name, idx)
                                    .or_else(|| Some(String::new()));
                            }
                            // `a[@]` / `a[*]`: whole-array expansion — not an
                            // unbound-variable error even when `a` is empty or
                            // unset.  Return Some("") so callers' nounset checks
                            // (which compare against None) don't fire with the
                            // nameref name instead of the subscript name.
                            // The actual multi-word expansion is done later by
                            // resolve_raw_value / expand_var_value.
                            if idx_part == "@" || idx_part == "*" {
                                return Some(String::new());
                            }
                            // Non-numeric, non-@/* subscript (e.g., a variable
                            // name like `k`).  Evaluate as arithmetic using the
                            // immutable eval path.
                            //   • Success  → look up the indexed element; if
                            //     the element is absent, return None so the
                            //     caller's nounset guard fires with the nameref
                            //     name (correct for `k=""` → index 0 unset).
                            //   • Err containing "unbound variable" → the
                            //     subscript variable itself is unset; return
                            //     Some("") so the nounset guard does NOT fire
                            //     with the nameref name, letting
                            //     resolve_raw_value / expand_var_value emit the
                            //     correct "k: unbound variable" via ARITH_ERR.
                            match crate::arithmetic::eval_expr(idx_part, self) {
                                Ok(n) => {
                                    let idx = if n < 0 { 0usize } else { n as usize };
                                    return self.get_array_element(arr_name, idx)
                                        .map(|s| s.to_string());
                                }
                                Err(ref msg) if msg.contains("unbound variable") => {
                                    return Some(String::new());
                                }
                                Err(_) => {
                                    return None;
                                }
                            }
                        }
                    }
                }
                // Non-subscripted target: fall through to the normal
                // get() path on the resolved name (which itself won't
                // re-resolve because target isn't a nameref).
                return self.get(&target);
            }
        }
        // Empty or invalid nameref targets expand as empty without a
        // circular-reference warning.  Warn only for an actual cycle.
        if self.is_nameref(name) && self.has_circular_nameref(name) {
            eprintln!("{}: warning: {}: circular name reference",
                self.error_prefix, name);
            return Some(String::new());
        }
        if name == "RANDOM" {
            return Some(self.next_random().to_string());
        }
        let entry = self.get_entry(name)?;
        match &entry.value {
            VarValue::Scalar(s) => Some(s.clone()),
            VarValue::Array(arr) => {
                // Bash: `$arr` expands to element 0.
                arr.first().or_else(|| Some(String::new()))
            }
            VarValue::AssocArray(map) => {
                // Bash: `$assoc` expands to element with key "0".
                Some(map.get("0").cloned().unwrap_or_default())
            }
            VarValue::Unset => None,
        }
    }

    /// Fast borrow-based scalar lookup for arithmetic contexts.
    ///
    /// Returns a borrowed `&str` to the stored String for plain scalar variables
    /// without cloning.  Returns `None` for RANDOM, nameref chains, arrays,
    /// assoc arrays, or unset variables — callers must fall back to `get()`.
    ///
    /// ONLY use this as a fast path when the caller can handle None by falling
    /// back to the full `get()` path.
    pub fn get_scalar_str(&self, name: &str) -> Option<&str> {
        // Skip RANDOM — it must generate a fresh value each call.
        if name == "RANDOM" {
            return None;
        }
        // Skip names with subscripts — those need array-lookup logic.
        if name.contains('[') {
            return None;
        }
        // Fast path: no nameref chain. Check the raw entry first.
        let raw = self.get_entry_raw(name)?;
        if raw.nameref {
            return None; // has a nameref chain — fall back to get()
        }
        match &raw.value {
            VarValue::Scalar(s) => Some(s.as_str()),
            // Arrays and assoc arrays: element-0 semantics need the full get() path.
            VarValue::Array(_) | VarValue::AssocArray(_) => None,
            VarValue::Unset => None,
        }
    }

    /// Set a scalar in the innermost scope that already defines the variable,
    /// or in the current scope if it is new.
    /// Try to perform a fast scalar set for the arithmetic evaluator hot path.
    ///
    /// Checks all preconditions (not readonly, not nameref, not integer-typed,
    /// no case-transform attributes, plain scalar or unset) in a single HashMap
    /// lookup, then writes the new value directly if they all hold.
    ///
    /// Returns `true` if the fast set was performed, `false` if the caller must
    /// fall back to the full `set()` path.
    pub(crate) fn try_set_scalar_fast(&mut self, name: &str, value: &str) -> bool {
        // Look up (or create) the entry in the innermost scope that holds it.
        let idx = match self.find_scope(name) {
            Some(i) => i,
            None => {
                // Variable doesn't exist yet — create it as a new plain scalar
                // in the global scope (scope 0).
                self.scopes[0]
                    .vars
                    .insert(name.to_owned(), VarEntry::new_unset());
                0
            }
        };
        let entry = self.scopes[idx].vars.get_mut(name).unwrap();
        // Check all disqualifying attributes in one place.
        if entry.readonly
            || entry.nameref
            || entry.integer
            || entry.lowercase
            || entry.uppercase
            || entry.capitalize
            || matches!(entry.value, VarValue::Array(_) | VarValue::AssocArray(_))
        {
            return false;
        }
        entry.value = VarValue::Scalar(value.to_owned());
        entry.initialized = true;
        entry.hidden_unset = false;
        true
    }

    pub fn set(&mut self, name: &str, value: &str) {
        if self.is_local_self_nameref_exact(name) {
            eprintln!("{}: warning: {}: maximum nameref depth (8) exceeded",
                self.error_prefix, name);
            if self.with_local_binding_hidden(name, |vars| vars.set(name, value)).is_some() {
                return;
            }
        }
        if self.is_local_self_nameref_subscript(name) {
            let raw_target = self.get_raw_scalar(name).unwrap_or_default();
            eprintln!("{}: `{}': not a valid identifier", self.error_prefix, raw_target);
            return;
        }
        if self.is_nameref(name) {
            let raw_target = self.get_nameref_target(name)
                .or_else(|| self.get_raw_scalar(name))
                .unwrap_or_default();
            // A circular nameref chain (valid raw_target but resolve returns None)
            // should emit the circular warning and silently fail the assignment —
            // matching bash's behaviour where x=4 on a circular chain warns and
            // does not change anything.
            let target_valid = !raw_target.is_empty() && Self::is_valid_nameref_target(&raw_target);
            if target_valid && self.resolve_nameref(name).is_none() {
                // Circular chain: warn and bail out without modifying anything.
                eprintln!("{}: warning: {}: circular name reference",
                    self.error_prefix, name);
                return;
            }
            let unresolved_nameref = raw_target.is_empty()
                || !Self::is_valid_nameref_target(&raw_target)
                || self.resolve_nameref(name).is_none();
            if unresolved_nameref {
                if !Self::is_valid_assigned_nameref_target(value) {
                    // In an arithmetic command context (e.g. `((r=0))`) bash
                    // emits the "((" prefix before the error message.
                    if self.in_arith_cmd {
                        eprintln!("{}: ((: `{}': not a valid identifier", self.error_prefix, value);
                    } else {
                        eprintln!("{}: `{}': not a valid identifier", self.error_prefix, value);
                    }
                    // Signal to exec.rs that a standalone assignment on a
                    // `;`-separated list should abort the rest of the list,
                    // matching bash's behaviour (the list stops after the
                    // "not a valid identifier" error).
                    self.nameref_invalid_target_abort = true;
                    return;
                }
                if !self.set_nameref_target(name, value) {
                    return;
                }
                return;
            }
        }
        // Resolve nameref — the error message and storage should use
        // the target name, not the nameref alias.
        let resolved = self.resolve_nameref(name);
        let target: String = resolved.unwrap_or_else(|| name.to_string());
        if target == "RANDOM" {
            let seed = crate::arithmetic::eval_expr(value.trim(), self).unwrap_or(0) as u32;
            self.seed_random(seed);
            let entry = self.get_entry_mut("RANDOM");
            entry.integer = true;
            entry.initialized = true;
            return;
        }
        // If the nameref target is subscripted (`arr[N]`), this is a
        // write to an array element, not to a literal variable named
        // "arr[N]".  Route through the appropriate array setter.
        if let Some(br) = target.find('[') {
            if target.ends_with(']') {
                let arr_name = &target[..br];
                let idx_part = &target[br + 1..target.len() - 1];
                if !arr_name.is_empty() {
                    if self.is_nameref(name) && arr_name == name {
                        eprintln!("{}: warning: {}: removing nameref attribute",
                            self.error_prefix, name);
                        self.strip_nameref_value(name);
                    }
                    if self.get_entry_raw(arr_name).map(|e|
                        matches!(e.value, VarValue::AssocArray(_))).unwrap_or(false)
                    {
                        // Assoc array: key as string (after $-expand).
                        let key = crate::expand::expand_arith_vars(idx_part, self);
                        self.set_assoc(arr_name, &key, value);
                        return;
                    }
                    // Indexed array: arithmetic subscript.
                    if let Ok(idx) = crate::arithmetic::eval_expr(idx_part, self) {
                        let idx = if idx < 0 { 0 } else { idx as usize };
                        self.set_array_element(arr_name, idx, value);
                        return;
                    }
                    eprintln!("{}: {}[{}]: bad array subscript",
                        self.error_prefix, arr_name, idx_part);
                    return;
                }
            }
        }
        // Check attributes on the resolved target.
        let (readonly, is_int, is_lower, is_upper, is_cap) = if let Some(entry) = self.get_entry_raw(&target) {
            (entry.readonly, entry.integer, entry.lowercase, entry.uppercase, entry.capitalize)
        } else {
            (false, false, false, false, false)
        };
        if readonly {
            eprintln!("{}: {}: readonly variable", self.error_prefix, target);
            return;
        }
        // Coerce: integer evaluation, then case
        let s = if is_int {
            match crate::arithmetic::eval_expr(value.trim(), self) {
                Ok(n) => n.to_string(),
                Err(e) => {
                    // Bash emits `<shell>: line <N>: <expr>: <err>`
                    // and aborts the command (exit 1 from the
                    // assignment).  We can't easily abort from here
                    // — callers typically don't check — but printing
                    // the error lets the test suite see the bash-
                    // canonical diagnostic.
                    eprintln!("{}: {}: {}",
                        self.error_prefix, value.trim(), e);
                    "0".to_owned()
                }
            }
        } else {
            value.to_owned()
        };
        let coerced = if is_lower {
            s.to_lowercase()
        } else if is_upper {
            s.to_uppercase()
        } else if is_cap {
            let mut chars = s.chars();
            match chars.next() {
                None => String::new(),
                Some(c) => {
                    let rest: String = chars.collect();
                    let mut result = String::new();
                    result.extend(c.to_uppercase());
                    result.push_str(&rest.to_lowercase());
                    result
                }
            }
        } else {
            s
        };
        let entry = self.get_entry_mut(name);
        // Bash: if the variable is already an indexed array, `NAME=VAL`
        // behaves like `NAME[0]=VAL` — it replaces element 0 and
        // preserves the rest of the array.  Similarly for assoc
        // arrays: stores at key "0".  Only plain scalar or unset
        // variables get overwritten with a new Scalar value.
        match &mut entry.value {
            VarValue::Array(arr) => {
                arr.set(0, coerced);
                entry.initialized = true;
                entry.hidden_unset = false;
                return;
            }
            VarValue::AssocArray(map) => {
                map.insert("0".to_string(), coerced);
                entry.initialized = true;
                entry.hidden_unset = false;
                return;
            }
            _ => {}
        }
        entry.value = VarValue::Scalar(coerced);
        entry.initialized = true;
        entry.hidden_unset = false;
        if matches!(target.as_str(), "LC_ALL" | "LC_CTYPE" | "LANG") {
            self.sync_process_locale();
        }
    }

    fn seed_random(&self, seed: u32) {
        self.random_state.set(seed);
        self.last_random.set(0);
    }

    fn next_random(&self) -> u32 {
        let mut seed = self.random_state.get();
        let mut last = self.last_random.get();
        loop {
            if seed == 0 {
                seed = 123_459_876;
            }
            let hi = seed / 127_773;
            let lo = seed % 127_773;
            let test = 16_807i64 * lo as i64 - 2_836i64 * hi as i64;
            seed = if test < 0 {
                (test + 2_147_483_647) as u32
            } else {
                test as u32
            };
            let value = (seed ^ (seed >> 16)) & 0x7fff;
            if value != last {
                self.random_state.set(seed);
                self.last_random.set(value);
                return value;
            }
            last = value;
        }
    }

    pub fn unset(&mut self, name: &str) {
        // Bash rule for nameref: `unset NAME` where NAME is a
        // nameref unsets its TARGET (following the chain once),
        // not NAME itself.  The nameref attribute stays on NAME so
        // a later assignment through it still finds the (re-
        // created) target.  To strip the nameref attribute, use
        // `unset -n NAME` (handled in builtin_unset separately).
        if let Some(target) = self.resolve_nameref(name) {
            if target != name {
                if let Some((base, sub)) = crate::exec::parse_subscripted_name_pub(&target) {
                    if self.get_entry_raw(&base).map(|e|
                        matches!(e.value, VarValue::AssocArray(_))).unwrap_or(false)
                    {
                        self.unset_assoc_element(&base, &sub);
                        return;
                    }
                    if let Ok(idx) = crate::arithmetic::eval_expr(&sub, self) {
                        let idx = if idx < 0 { 0 } else { idx as usize };
                        self.unset_array_element(&base, idx);
                        return;
                    }
                }
                self.unset(&target);
                return;
            }
        }
        // Walk scopes from innermost to outermost and unset the first
        // binding we find.  For *local* bindings (declared with `local`
        // inside the current function), we keep the entry but mark its
        // value as Unset — bash preserves the local attribute so that a
        // subsequent assignment in the same function lands in the local
        // scope again rather than the global one.
        let cur = self.current_idx();
        for idx in (0..self.scopes.len()).rev() {
            if let Some(entry) = self.scopes[idx].vars.get_mut(name) {
                if entry.readonly {
                    eprintln!("{}: unset: {}: cannot unset: readonly variable", crate::exec::shell_name(), name);
                    return;
                }
                if entry.local && idx == cur {
                    entry.value = VarValue::Unset;
                    entry.initialized = false;
                    entry.hidden_unset = false;
                } else {
                    if entry.local {
                        entry.value = VarValue::Unset;
                        entry.initialized = false;
                        entry.hidden_unset = true;
                    } else {
                        entry.value = VarValue::Unset;
                        self.scopes[idx].vars.remove(name);
                    }
                }
                if matches!(name, "LC_ALL" | "LC_CTYPE" | "LANG") {
                    self.sync_process_locale();
                }
                return;
            }
        }
    }

    /// Remove the literal entry for `name`, regardless of any
    /// nameref flag — used by `unset -n` which strips the nameref
    /// attribute / removes the nameref variable itself (instead of
    /// following it to the target).
    /// Bash `unset -n NAME` is a no-op when NAME is not a nameref.
    pub fn unset_noref(&mut self, name: &str) {
        let cur = self.current_idx();
        for idx in (0..self.scopes.len()).rev() {
            if let Some(entry) = self.scopes[idx].vars.get_mut(name) {
                // bash `unset -n NAME` only acts on actual namerefs.
                // If NAME is not a nameref, it is left unchanged.
                if !entry.nameref {
                    return;
                }
                if entry.readonly {
                    eprintln!("{}: unset: {}: cannot unset: readonly variable", crate::exec::shell_name(), name);
                    return;
                }
                if entry.local && idx == cur {
                    entry.value = VarValue::Unset;
                    entry.nameref = false;
                    entry.initialized = false;
                    entry.hidden_unset = false;
                } else {
                    if entry.local {
                        entry.value = VarValue::Unset;
                        entry.nameref = false;
                        entry.initialized = false;
                        entry.hidden_unset = true;
                    } else {
                        self.scopes[idx].vars.remove(name);
                    }
                }
                if matches!(name, "LC_ALL" | "LC_CTYPE" | "LANG") {
                    self.sync_process_locale();
                }
                return;
            }
        }
    }

    /// Force-unset a variable, bypassing readonly checks.
    /// Used by getopts internal machinery (matching bash behavior).
    pub fn force_unset(&mut self, name: &str) {
        for scope in self.scopes.iter_mut().rev() {
            if scope.vars.contains_key(name) {
                scope.vars.remove(name);
                return;
            }
        }
    }

    pub fn snapshot_raw_bindings(&self, name: &str) -> RawBindingSnapshot {
        let mut out = Vec::new();
        for (idx, scope) in self.scopes.iter().enumerate() {
            if let Some(entry) = scope.vars.get(name) {
                out.push((idx, entry.clone()));
            }
        }
        RawBindingSnapshot(out)
    }

    pub fn restore_raw_bindings(&mut self, name: &str, snapshot: RawBindingSnapshot) {
        for scope in &mut self.scopes {
            scope.vars.remove(name);
        }
        for (idx, entry) in snapshot.0 {
            if idx < self.scopes.len() {
                self.scopes[idx].vars.insert(name.to_owned(), entry);
            }
        }
        if matches!(name, "LC_ALL" | "LC_CTYPE" | "LANG") {
            self.sync_process_locale();
        }
    }

    pub fn restore_outer_raw_bindings(&mut self, name: &str, snapshot: RawBindingSnapshot) {
        let cur = self.current_idx();
        for (idx, scope) in self.scopes.iter_mut().enumerate() {
            if idx != cur {
                scope.vars.remove(name);
            }
        }
        for (idx, entry) in snapshot.0 {
            if idx < self.scopes.len() && idx != cur {
                self.scopes[idx].vars.insert(name.to_owned(), entry);
            }
        }
        if matches!(name, "LC_ALL" | "LC_CTYPE" | "LANG") {
            self.sync_process_locale();
        }
    }

    pub fn is_set(&self, name: &str) -> bool {
        self.get_entry(name)
            .map(|e| !matches!(e.value, VarValue::Unset))
            .unwrap_or(false)
    }

    pub fn is_nameref(&self, name: &str) -> bool {
        // Check the literal entry — following the nameref chain
        // would inspect the target's flags, not the nameref's own.
        self.get_entry_raw(name)
            .map(|e| e.nameref)
            .unwrap_or(false)
    }

    pub fn is_nameref_global(&self, name: &str) -> bool {
        self.get_entry_raw_global(name)
            .map(|e| e.nameref)
            .unwrap_or(false)
    }

    /// Like `has_entry` but bypasses nameref resolution.  Used by
    /// `declare -p NAME` which needs to check whether the literal
    /// variable NAME exists — not whether its nameref target does.
    pub fn has_entry_raw(&self, name: &str) -> bool {
        self.get_entry_raw(name).is_some()
    }

    /// Like `get_entry_is_integer` but bypasses nameref resolution.
    pub fn get_entry_is_integer_raw(&self, name: &str) -> bool {
        self.get_entry_raw(name).map(|e| e.integer).unwrap_or(false)
    }

    /// Like `is_exported` but bypasses nameref resolution.
    pub fn is_exported_raw(&self, name: &str) -> bool {
        self.get_entry_raw(name).map(|e| e.exported).unwrap_or(false)
    }

    /// Like `is_readonly` but bypasses nameref resolution.
    pub fn is_readonly_raw(&self, name: &str) -> bool {
        self.get_entry_raw(name).map(|e| e.readonly).unwrap_or(false)
    }

    /// Like `get_entry_is_initialized` but bypasses nameref.
    pub fn get_entry_is_initialized_raw(&self, name: &str) -> bool {
        self.get_entry_raw(name).map(|e| e.initialized).unwrap_or(false)
    }

    /// True if the variable has the lowercase (`-l`) attribute.
    pub fn is_lowercase_raw(&self, name: &str) -> bool {
        self.get_entry_raw(name).map(|e| e.lowercase).unwrap_or(false)
    }

    /// True if the variable has the uppercase (`-u`) attribute.
    pub fn is_uppercase_raw(&self, name: &str) -> bool {
        self.get_entry_raw(name).map(|e| e.uppercase).unwrap_or(false)
    }

    /// True if the variable has the capitalize (`-c`) attribute.
    pub fn is_capitalize_raw(&self, name: &str) -> bool {
        self.get_entry_raw(name).map(|e| e.capitalize).unwrap_or(false)
    }

    /// Get the raw string value of a nameref variable — i.e. the name
    /// of its target, not what the target expands to.  Returns None
    /// for non-namerefs or unset entries.
    pub fn get_nameref_target(&self, name: &str) -> Option<String> {
        let entry = self.get_entry_raw(name)?;
        if !entry.nameref {
            return None;
        }
        match &entry.value {
            VarValue::Scalar(s) => Some(s.clone()),
            _ => None,
        }
    }

    pub fn get_raw_scalar(&self, name: &str) -> Option<String> {
        match &self.get_entry_raw(name)?.value {
            VarValue::Scalar(s) => Some(s.clone()),
            VarValue::Unset => Some(String::new()),
            _ => None,
        }
    }

    // ------------------------------------------------------------------
    // export / readonly / integer / case transforms / local
    // ------------------------------------------------------------------

    pub fn export(&mut self, name: &str) {
        let entry = self.get_entry_mut(name);
        entry.exported = true;
    }

    pub fn unexport(&mut self, name: &str) {
        if let Some(scope) = self.scopes.iter_mut().rev()
            .find(|s| s.vars.contains_key(name))
        {
            if let Some(entry) = scope.vars.get_mut(name) {
                entry.exported = false;
            }
        }
    }

    /// Set a variable and mark it exported at the same time.  Callers go
    /// through `Shell::export_var` today, which routes via `set_var` and
    /// then flips the export flag — kept here for direct-store callers.
    #[allow(dead_code)]
    pub fn set_exported(&mut self, name: &str, value: &str) {
        self.set(name, value);
        self.export(name);
    }

    pub fn is_exported(&self, name: &str) -> bool {
        self.get_entry(name)
            .map(|e| e.exported)
            .unwrap_or(false)
    }

    pub fn is_readonly(&self, name: &str) -> bool {
        self.get_entry(name)
            .map(|e| e.readonly)
            .unwrap_or(false)
    }

    pub fn set_readonly(&mut self, name: &str) {
        let entry = self.get_entry_mut(name);
        entry.readonly = true;
    }

    pub fn set_readonly_raw(&mut self, name: &str) {
        let entry = self.get_entry_mut_raw(name);
        entry.readonly = true;
    }

    /// Force-set a scalar value, bypassing the readonly check.  Used by
    /// the shell's dynamic-variable sync for SHELLOPTS/BASHOPTS, which
    /// bash keeps readonly from the user's perspective but rebuilds
    /// every command from the current option state.
    pub fn set_raw(&mut self, name: &str, value: &str) {
        let entry = self.get_entry_mut(name);
        entry.value = VarValue::Scalar(value.to_string());
        entry.initialized = true;
        if matches!(name, "LC_ALL" | "LC_CTYPE" | "LANG") {
            self.sync_process_locale();
        }
    }

    pub fn set_integer(&mut self, name: &str) {
        let entry = self.get_entry_mut(name);
        entry.integer = true;
    }

    pub fn set_integer_raw(&mut self, name: &str) {
        let entry = self.get_entry_mut_raw(name);
        entry.integer = true;
    }

    /// Returns true if the variable has the integer attribute (declare -i).
    pub fn get_entry_is_integer(&self, name: &str) -> bool {
        self.get_entry(name).map(|e| e.integer).unwrap_or(false)
    }

    /// Returns true if the variable has been assigned a value (as
    /// opposed to just declared without one).  Bash's `declare -p`
    /// distinguishes `declare -x foo` (not initialized) from
    /// `declare -x foo=""` (initialized with empty value).
    pub fn get_entry_is_initialized(&self, name: &str) -> bool {
        self.get_entry(name).map(|e| e.initialized).unwrap_or(false)
    }

    /// Returns true if the variable has a VarEntry at all — even when
    /// the value is Unset (declared without a value, e.g. via
    /// `declare -x foo`).  Used by declare -p to distinguish
    /// \"not found\" from \"declared but uninitialized\".
    pub fn has_entry(&self, name: &str) -> bool {
        self.get_entry(name).is_some()
    }

    /// Clear the integer attribute (`declare +i NAME`).  Leaves the
    /// stored value in place — bash doesn't re-decode to its original
    /// textual form; whatever the last arithmetic coercion produced
    /// sticks around.
    pub fn unset_integer(&mut self, name: &str) {
        let entry = self.get_entry_mut(name);
        entry.integer = false;
    }

    pub fn unset_integer_raw(&mut self, name: &str) {
        let entry = self.get_entry_mut_raw(name);
        entry.integer = false;
    }

    pub fn unset_lowercase(&mut self, name: &str) {
        let entry = self.get_entry_mut(name);
        entry.lowercase = false;
    }

    pub fn unset_lowercase_raw(&mut self, name: &str) {
        let entry = self.get_entry_mut_raw(name);
        entry.lowercase = false;
    }

    pub fn unset_uppercase(&mut self, name: &str) {
        let entry = self.get_entry_mut(name);
        entry.uppercase = false;
    }

    pub fn unset_uppercase_raw(&mut self, name: &str) {
        let entry = self.get_entry_mut_raw(name);
        entry.uppercase = false;
    }

    pub fn unset_capitalize(&mut self, name: &str) {
        let entry = self.get_entry_mut(name);
        entry.capitalize = false;
    }

    pub fn unset_capitalize_raw(&mut self, name: &str) {
        let entry = self.get_entry_mut_raw(name);
        entry.capitalize = false;
    }

    pub fn unset_exported(&mut self, name: &str) {
        let entry = self.get_entry_mut(name);
        entry.exported = false;
    }

    pub fn unset_exported_raw(&mut self, name: &str) {
        let entry = self.get_entry_mut_raw(name);
        entry.exported = false;
    }

    pub fn set_lowercase(&mut self, name: &str) {
        let entry = self.get_entry_mut(name);
        entry.lowercase = true;
        entry.uppercase = false; // mutually exclusive
        if let VarValue::Scalar(ref s) = entry.value.clone() {
            let coerced = s.to_lowercase();
            entry.value = VarValue::Scalar(coerced);
        }
    }

    pub fn set_lowercase_raw(&mut self, name: &str) {
        let entry = self.get_entry_mut_raw(name);
        entry.lowercase = true;
        entry.uppercase = false;
        if let VarValue::Scalar(ref s) = entry.value.clone() {
            entry.value = VarValue::Scalar(s.to_lowercase());
        }
    }

    pub fn set_uppercase(&mut self, name: &str) {
        let entry = self.get_entry_mut(name);
        entry.uppercase = true;
        entry.lowercase = false;
        entry.capitalize = false;
        if let VarValue::Scalar(ref s) = entry.value.clone() {
            let coerced = s.to_uppercase();
            entry.value = VarValue::Scalar(coerced);
        }
    }

    pub fn set_uppercase_raw(&mut self, name: &str) {
        let entry = self.get_entry_mut_raw(name);
        entry.uppercase = true;
        entry.lowercase = false;
        entry.capitalize = false;
        if let VarValue::Scalar(ref s) = entry.value.clone() {
            entry.value = VarValue::Scalar(s.to_uppercase());
        }
    }

    pub fn set_capitalize(&mut self, name: &str) {
        let entry = self.get_entry_mut(name);
        entry.capitalize = true;
        entry.lowercase = false;
        entry.uppercase = false;
        if let VarValue::Scalar(ref s) = entry.value.clone() {
            let coerced = entry.coerce_scalar(s);
            entry.value = VarValue::Scalar(coerced);
        }
    }

    pub fn set_capitalize_raw(&mut self, name: &str) {
        let entry = self.get_entry_mut_raw(name);
        entry.capitalize = true;
        entry.lowercase = false;
        entry.uppercase = false;
        if let VarValue::Scalar(ref s) = entry.value.clone() {
            let coerced = entry.coerce_scalar(s);
            entry.value = VarValue::Scalar(coerced);
        }
    }

    pub fn export_raw(&mut self, name: &str) {
        let entry = self.get_entry_mut_raw(name);
        entry.exported = true;
    }

    /// Create (or update) a variable in the current (innermost) scope and mark
    /// it as local, regardless of whether an outer scope already defines it.
    /// Returns true if NAME has an entry in the current (innermost) scope
    /// that's not the global scope — i.e. it's been declared local via
    /// `local`/`typeset`/`declare` (or a `set_local` call).
    pub fn is_local_pub(&self, name: &str) -> bool {
        let cur = self.scopes.len() - 1;
        if cur == 0 { return false; }
        self.scopes[cur].vars.contains_key(name)
    }

    pub fn set_local(&mut self, name: &str, value: &str) {
        let cur = self.current_idx();
        let entry = self
            .scopes[cur]
            .vars
            .entry(name.to_owned())
            .or_insert_with(VarEntry::new_unset);
        if entry.readonly {
            return;
        }
        let coerced = entry.coerce(value);
        match &mut entry.value {
            VarValue::Array(arr) => {
                arr.set(0, coerced);
            }
            VarValue::AssocArray(map) => {
                map.insert("0".to_string(), coerced);
            }
            _ => {
                entry.value = VarValue::Scalar(coerced);
            }
        }
        entry.local = true;
        entry.initialized = true;
        entry.hidden_unset = false;
        if matches!(name, "LC_ALL" | "LC_CTYPE" | "LANG") {
            self.sync_process_locale();
        }
    }

    /// Seed the current scope's binding for NAME from the nearest outer scope.
    ///
    /// This is used to implement `shopt -s localvar_inherit`: a local
    /// declaration starts with the value and attributes of the enclosing
    /// binding when one exists.  If NAME is already local in the current
    /// scope, this is a no-op.
    pub fn inherit_local_from_outer(&mut self, name: &str) -> LocalInheritResult {
        let cur = self.current_idx();
        if self.scopes[cur].vars.contains_key(name) {
            return LocalInheritResult::Inherited;
        }
        let mut outer_entry: Option<VarEntry> = None;
        for scope in self.scopes[..cur].iter().rev() {
            if let Some(entry) = scope.vars.get(name) {
                outer_entry = Some(entry.clone());
                break;
            }
        }
        let mut entry = match outer_entry {
            Some(e) => e,
            None => return LocalInheritResult::NotFound,
        };
        if entry.readonly {
            return LocalInheritResult::Readonly;
        }
        entry.local = true;
        self.scopes[cur].vars.insert(name.to_owned(), entry);
        LocalInheritResult::Inherited
    }

    /// Create or update an array in the current (innermost) scope and mark it
    /// as local, similar to `set_local` but for indexed arrays.
    pub fn set_local_array(&mut self, name: &str, values: Vec<String>) {
        let cur = self.current_idx();
        let entry = self
            .scopes[cur]
            .vars
            .entry(name.to_owned())
            .or_insert_with(VarEntry::new_unset);
        if entry.readonly {
            return;
        }
        entry.value = VarValue::Array(IndexedArray::from_values(values));
        entry.local = true;
        entry.initialized = true;
        entry.hidden_unset = false;
    }

    fn get_array_lookup_entry(&self, name: &str) -> Option<&VarEntry> {
        let resolved = self.resolve_nameref(name);
        let lookup = resolved.as_deref().unwrap_or(name);
        let cur = self.current_idx();
        let mut saw_unset = false;
        for i in (0..self.scopes.len()).rev() {
            let Some(entry) = self.scopes[i].vars.get(lookup) else { continue };
            if entry.hidden_unset && (i < cur || (i == cur && !self.localvar_unset)) {
                continue;
            }
            match &entry.value {
                VarValue::Array(_) | VarValue::AssocArray(_) | VarValue::Scalar(_) => return Some(entry),
                VarValue::Unset if !saw_unset => {
                    saw_unset = true;
                    continue;
                }
                _ => return None,
            }
        }
        None
    }

    // ------------------------------------------------------------------
    // Indexed arrays
    // ------------------------------------------------------------------

    /// Like declare_array, but if NAME isn't present in any scope, it
    /// is created in the CURRENT (innermost) scope — for `local -a NAME`
    /// or `declare -a NAME` inside a function.
    pub fn declare_local_array(&mut self, name: &str) {
        let cur = self.scopes.len() - 1;
        let entry = self.scopes[cur]
            .vars
            .entry(name.to_string())
            .or_insert_with(VarEntry::new_unset);
        if entry.readonly {
            return;
        }
        match &entry.value {
            VarValue::Array(_) => {}
            VarValue::Scalar(ref s) => {
                let prev = s.clone();
                let mut arr = IndexedArray::new();
                arr.set(0, prev);
                entry.value = VarValue::Array(arr);
                entry.initialized = true;
            }
            _ => {
                entry.value = VarValue::Array(IndexedArray::new());
            }
        }
        entry.local = true;
    }

    pub fn declare_array(&mut self, name: &str) {
        let entry = self.get_entry_mut(name);
        match &entry.value {
            VarValue::Array(_) => {}
            VarValue::Scalar(ref s) => {
                // Bash behaviour: `declare -a NAME` on an existing
                // scalar converts it to an indexed array whose [0]
                // element is the prior scalar value.
                let prev = s.clone();
                let mut arr = IndexedArray::new();
                arr.set(0, prev);
                entry.value = VarValue::Array(arr);
            }
            _ => {
                entry.value = VarValue::Array(IndexedArray::new());
            }
        }
    }

    pub fn set_array(&mut self, name: &str, values: Vec<String>) {
        let entry = self.get_entry_mut(name);
        if entry.readonly {
            return;
        }
        entry.value = VarValue::Array(IndexedArray::from_values(values));
        entry.initialized = true;
    }

    /// Return the array's set elements (skipping unset holes) as a dense Vec,
    /// in index order.  Use this when callers don't need to know indices.
    pub fn get_array(&self, name: &str) -> Option<Vec<String>> {
        let entry = self.get_array_lookup_entry(name)?;
        let nbuckets = entry.assoc_nbuckets;
        match &entry.value {
            VarValue::Array(arr) => Some(arr.values()),
            VarValue::AssocArray(map) => {
                // Return values in bash's hash-bucket iteration order
                let sorted = if nbuckets != 0 {
                    bash_sorted_entries_n(map, nbuckets)
                } else {
                    bash_sorted_entries(map)
                };
                Some(sorted.into_iter().map(|(_, v)| v.clone()).collect())
            }
            _ => None,
        }
    }

    /// Return the array's set elements as (index, value) pairs in ascending
    /// index order.  Used by `declare -p` and by slicing/iteration operators
    /// that need to know the actual subscripts.
    pub fn get_array_sparse(&self, name: &str) -> Option<Vec<(usize, String)>> {
        match &self.get_array_lookup_entry(name)?.value {
            VarValue::Array(arr) => Some(arr.entries()),
            _ => None,
        }
    }

    /// Largest index present in the array (or 0 if empty).  Used for
    /// negative-index resolution: `arr[-n]` maps to `max_idx - n + 1`
    /// when `max_idx + 1 >= n`.
    pub fn array_max_index(&self, name: &str) -> Option<usize> {
        match &self.get_array_lookup_entry(name)?.value {
            VarValue::Array(arr) => arr.max_index(),
            _ => None,
        }
    }

    pub fn set_array_element(&mut self, name: &str, idx: usize, value: &str) {
        // Array element assignments inherit integer/case attributes from the
        // array variable itself, matching bash.
        let (is_int, is_lower, is_upper, is_cap) = self.get_entry(name)
            .map(|e| (e.integer, e.lowercase, e.uppercase, e.capitalize))
            .unwrap_or((false, false, false, false));
        let s: String = if is_int {
            match crate::arithmetic::eval_expr(value.trim(), self) {
                Ok(n) => n.to_string(),
                Err(_) => "0".to_owned(),
            }
        } else {
            value.to_owned()
        };
        let stored_value = if is_lower {
            s.to_lowercase()
        } else if is_upper {
            s.to_uppercase()
        } else if is_cap {
            let mut chars = s.chars();
            match chars.next() {
                None => String::new(),
                Some(c) => {
                    let rest: String = chars.collect();
                    let mut result = String::new();
                    result.extend(c.to_uppercase());
                    result.push_str(&rest.to_lowercase());
                    result
                }
            }
        } else {
            s
        };
        let entry = self.get_entry_mut(name);
        if entry.readonly {
            eprintln!("{}: {}: readonly variable", self.error_prefix, name);
            return;
        }
        match &mut entry.value {
            VarValue::Array(arr) => {
                arr.set(idx, stored_value);
            }
            VarValue::Scalar(s) => {
                // Promote to array, preserving the previous scalar
                // value as element [0].  Matches bash: `a=foo; a[2]=bar`
                // yields `a=([0]=foo [2]=bar)`.
                let prev = s.clone();
                let mut arr = IndexedArray::new();
                arr.set(0, prev);
                arr.set(idx, stored_value);
                entry.value = VarValue::Array(arr);
            }
            VarValue::Unset => {
                let mut arr = IndexedArray::new();
                arr.set(idx, stored_value);
                entry.value = VarValue::Array(arr);
            }
            VarValue::AssocArray(_) => {
                // Cannot index an assoc array by integer through this path.
            }
        }
        entry.initialized = true;
    }

    /// Like set_array_element but skips the readonly check (used for internal += operations).
    pub fn set_array_element_raw(&mut self, name: &str, idx: usize, value: &str) {
        let entry = self.get_entry_mut(name);
        match &mut entry.value {
            VarValue::Array(arr) => {
                arr.set(idx, value.to_owned());
            }
            VarValue::Scalar(s) => {
                let prev = s.clone();
                let mut arr = IndexedArray::new();
                arr.set(0, prev);
                arr.set(idx, value.to_owned());
                entry.value = VarValue::Array(arr);
            }
            VarValue::Unset => {
                let mut arr = IndexedArray::new();
                arr.set(idx, value.to_owned());
                entry.value = VarValue::Array(arr);
            }
            VarValue::AssocArray(_) => {}
        }
        let entry = self.get_entry_mut(name);
        entry.initialized = true;
    }

    pub fn get_array_element(&self, name: &str, idx: usize) -> Option<String> {
        match &self.get_array_lookup_entry(name)?.value {
            VarValue::Array(arr) => arr.get(idx),
            // Bash treats `${scalar[0]}` as the scalar value itself —
            // a bare scalar behaves like a single-element array at
            // index 0.  Other indices yield empty.
            VarValue::Scalar(s) if idx == 0 => Some(s.clone()),
            _ => None,
        }
    }

    /// Returns true if the array has a set element at index `idx`.
    /// Distinguishes "present but empty string" from "unset".
    pub fn array_element_is_set(&self, name: &str, idx: usize) -> bool {
        matches!(
            self.get_entry(name).map(|e| &e.value),
            Some(VarValue::Array(arr)) if arr.get(idx).is_some()
        )
    }

    /// Unset a single element of an indexed array.  Returns true if the
    /// element existed and was removed; false otherwise.  If all elements
    /// become unset, the array is left empty (not removed entirely — bash
    /// keeps `declare -a NAME` visible after unsetting every element).
    pub fn unset_array_element(&mut self, name: &str, idx: usize) -> bool {
        let entry = match self.scopes.iter_mut().rev()
            .find_map(|s| s.vars.get_mut(name))
        {
            Some(e) => e,
            None => return false,
        };
        match &mut entry.value {
            VarValue::Array(arr) => arr.unset(idx),
            _ => false,
        }
    }

    /// Unset a single element of an associative array.  Returns true on success.
    pub fn unset_assoc_element(&mut self, name: &str, key: &str) -> bool {
        let entry = match self.scopes.iter_mut().rev()
            .find_map(|s| s.vars.get_mut(name))
        {
            Some(e) => e,
            None => return false,
        };
        match &mut entry.value {
            VarValue::AssocArray(map) => map.remove(key).is_some(),
            _ => false,
        }
    }

    /// Total count of *set* elements (skipping sparse holes).
    pub fn array_length(&self, name: &str) -> usize {
        match self.get_entry(name).map(|e| &e.value) {
            Some(VarValue::Array(arr)) => arr.len_set(),
            Some(VarValue::AssocArray(map)) => map.len(),
            Some(VarValue::Scalar(_)) => 1,
            _ => 0,
        }
    }

    pub fn push_array(&mut self, name: &str, value: &str) {
        let entry = self.get_entry_mut(name);
        if entry.readonly {
            return;
        }
        match &mut entry.value {
            VarValue::Array(arr) => arr.push(value.to_owned()),
            VarValue::Scalar(s) => {
                let prev = s.clone();
                let mut arr = IndexedArray::new();
                arr.set(0, prev);
                arr.push(value.to_owned());
                entry.value = VarValue::Array(arr);
            }
            VarValue::Unset => {
                let mut arr = IndexedArray::new();
                arr.set(0, value.to_owned());
                entry.value = VarValue::Array(arr);
            }
            VarValue::AssocArray(_) => {}
        }
    }

    pub fn is_array(&self, name: &str) -> bool {
        matches!(
            self.get_entry(name).map(|e| &e.value),
            Some(VarValue::Array(_))
        )
    }

    // ------------------------------------------------------------------
    // Associative arrays
    // ------------------------------------------------------------------

    pub fn clear_assoc(&mut self, name: &str) {
        let entry = self.get_entry_mut(name);
        if entry.readonly {
            return;
        }
        entry.value = VarValue::AssocArray(AssocMap::new());
    }

    pub fn declare_assoc(&mut self, name: &str) {
        // Check if the variable pre-exists as a non-assoc type.  Bash allocates
        // a smaller initial hash table (128 buckets) when converting a variable
        // that already exists in the symbol table, versus 1024 for a fresh create.
        let pre_existed_as_non_assoc = self.find_scope(name).map_or(false, |idx| {
            self.scopes[idx].vars.get(name).map_or(false, |e|
                !matches!(e.value, VarValue::AssocArray(_))
            )
        });
        let entry = self.get_entry_mut(name);
        match &entry.value {
            VarValue::AssocArray(_) => {}
            VarValue::Scalar(s) => {
                // Bash behaviour: `declare -A NAME` on an existing
                // scalar converts it to an assoc array with the prior
                // value stored at key "0" (bash uses key "0" here).
                let prev = s.clone();
                let mut map = AssocMap::new();
                map.insert("0".to_string(), prev);
                entry.value = VarValue::AssocArray(map);
                entry.initialized = true;
                entry.assoc_nbuckets = BASH_NBUCKETS_CONVERTED;
            }
            _ => {
                entry.value = VarValue::AssocArray(AssocMap::new());
                if pre_existed_as_non_assoc {
                    entry.assoc_nbuckets = BASH_NBUCKETS_CONVERTED;
                }
            }
        }
    }

    /// Create an empty associative array in the current (innermost)
    /// scope and mark it as local.  Used by `declare -A` / `typeset -A`
    /// inside a function body.
    pub fn declare_local_assoc(&mut self, name: &str) {
        let cur = self.current_idx();
        // Check if the variable pre-exists as a non-assoc type in the current scope.
        let pre_existed_as_non_assoc = self.scopes[cur].vars.get(name)
            .map_or(false, |e| !matches!(e.value, VarValue::AssocArray(_)));
        let entry = self
            .scopes[cur]
            .vars
            .entry(name.to_owned())
            .or_insert_with(VarEntry::new_unset);
        if entry.readonly {
            return;
        }
        match &entry.value {
            VarValue::AssocArray(_) => {}
            VarValue::Scalar(s) => {
                let prev = s.clone();
                let mut map = AssocMap::new();
                map.insert("0".to_string(), prev);
                entry.value = VarValue::AssocArray(map);
                entry.initialized = true;
                entry.assoc_nbuckets = BASH_NBUCKETS_CONVERTED;
            }
            _ => {
                entry.value = VarValue::AssocArray(AssocMap::new());
                if pre_existed_as_non_assoc {
                    entry.assoc_nbuckets = BASH_NBUCKETS_CONVERTED;
                }
            }
        }
        entry.local = true;
    }

    /// Mark a variable as initialized — used for bash-built-in assoc
    /// arrays like BASH_ALIASES / BASH_CMDS that should print with
    /// `=()` even when empty.
    pub fn mark_initialized(&mut self, name: &str) {
        let entry = self.get_entry_mut(name);
        entry.initialized = true;
    }

    pub fn set_assoc(&mut self, name: &str, key: &str, value: &str) {
        // Fast path: get a mutable entry in one pass, read attributes and
        // store in the same borrow.  Avoids the double scope-walk that the
        // old code did (one immutable get_entry + one mutable get_entry_mut).
        let entry = self.get_entry_mut(name);
        if entry.readonly {
            return;
        }
        // Read attributes from the entry.
        let is_int = entry.integer;
        let is_lower = entry.lowercase;
        let is_upper = entry.uppercase;
        let is_cap = entry.capitalize;

        // Apply transformations.  For the common case (no attributes) we take
        // the branch that just moves `value` as a new String.
        let stored_value: String = if is_int {
            // Need to evaluate as arithmetic — this requires re-borrowing self,
            // so fall back to the safe (slower) path only in this rare case.
            let v = value.trim().to_owned();
            // NLL ends the &mut borrow of `entry` at its last use above, so
            // we can re-borrow self to evaluate arithmetic without an
            // explicit drop().  drop(&mut T) is a no-op anyway — rustc warns.
            let n = crate::arithmetic::eval_expr(&v, self).unwrap_or(0);
            let s = n.to_string();
            let entry2 = self.get_entry_mut(name);
            if entry2.readonly { return; }
            match &mut entry2.value {
                VarValue::AssocArray(map) => { map.insert(key.to_owned(), s); }
                VarValue::Unset | VarValue::Scalar(_) => {
                    let mut map = AssocMap::new();
                    map.insert(key.to_owned(), n.to_string());
                    entry2.value = VarValue::AssocArray(map);
                }
                VarValue::Array(_) => {}
            }
            entry2.initialized = true;
            return;
        } else if is_lower {
            value.to_lowercase()
        } else if is_upper {
            value.to_uppercase()
        } else if is_cap {
            let mut chars = value.chars();
            match chars.next() {
                None => String::new(),
                Some(c) => {
                    let rest: String = chars.collect();
                    let mut result = String::new();
                    result.extend(c.to_uppercase());
                    result.push_str(&rest.to_lowercase());
                    result
                }
            }
        } else {
            value.to_owned()
        };
        // Now insert into the map.
        match &mut entry.value {
            VarValue::AssocArray(map) => {
                map.insert(key.to_owned(), stored_value);
            }
            VarValue::Unset | VarValue::Scalar(_) => {
                let mut map = AssocMap::new();
                map.insert(key.to_owned(), stored_value);
                entry.value = VarValue::AssocArray(map);
            }
            VarValue::Array(_) => {
                // Cannot write an assoc key into an indexed array.
            }
        }
        entry.initialized = true;
    }

    /// Remove a single element from an associative array.  `unset` builtin
    /// uses an internal helper that handles both array kinds; kept as the
    /// targeted public API.
    #[allow(dead_code)]
    pub fn unset_assoc_elem(&mut self, name: &str, key: &str) {
        if let Some(entry) = self.innermost_entry_with(name) {
            if entry.readonly {
                return;
            }
            if let VarValue::AssocArray(ref mut map) = entry.value {
                map.remove(key);
            }
        }
    }

    /// Remove a single element from an indexed array (by numeric index).
    /// See `unset_assoc_elem` for the rationale on the unused-but-public
    /// status.
    #[allow(dead_code)]
    pub fn unset_array_elem(&mut self, name: &str, idx: usize) {
        if let Some(entry) = self.innermost_entry_with(name) {
            if entry.readonly {
                return;
            }
            if let VarValue::Array(ref mut arr) = entry.value {
                let _ = arr.unset(idx);
            }
        }
    }

    /// Helper: get a mutable reference to the entry in the scope that
    /// actually defines it (innermost scope).  Returns None if not found.
    /// Currently every callsite uses `get_entry_mut` (which auto-creates);
    /// this no-create variant is kept for read-modify-write paths.
    #[allow(dead_code)]
    fn innermost_entry_with(&mut self, name: &str) -> Option<&mut VarEntry> {
        for scope in self.scopes.iter_mut().rev() {
            if scope.vars.contains_key(name) {
                return scope.vars.get_mut(name);
            }
        }
        None
    }

    pub fn get_assoc(&self, name: &str, key: &str) -> Option<String> {
        match &self.get_entry(name)?.value {
            VarValue::AssocArray(map) => map.get(key).cloned(),
            _ => None,
        }
    }

    /// Get all entries of an associative array in bash iteration order.
    pub fn get_assoc_entries(&self, name: &str) -> Vec<(String, String)> {
        let entry = self.get_entry(name);
        let nbuckets = entry.map_or(0, |e| e.assoc_nbuckets);
        match entry.map(|e| &e.value) {
            Some(VarValue::AssocArray(map)) => {
                let iter = if name == "BASH_ALIASES" {
                    bash_sorted_alias_entries(map)
                } else if name == "BASH_CMDS" {
                    bash_sorted_dynamic_entries(map)
                } else if nbuckets != 0 {
                    bash_sorted_entries_n(map, nbuckets)
                } else {
                    bash_sorted_entries(map)
                };
                iter.into_iter()
                    .map(|(k, v)| (k.clone(), v.clone()))
                    .collect()
            }
            _ => Vec::new(),
        }
    }

    pub fn is_assoc(&self, name: &str) -> bool {
        matches!(
            self.get_entry(name).map(|e| &e.value),
            Some(VarValue::AssocArray(_))
        )
    }

    /// Return (is_assoc, is_readonly) in a single scope-walk.
    /// Used by the subscript assignment hot path to avoid two lookups.
    pub fn assoc_readonly_flags(&self, name: &str) -> (bool, bool) {
        match self.get_entry(name) {
            Some(e) => (matches!(e.value, VarValue::AssocArray(_)), e.readonly),
            None => (false, false),
        }
    }

    // ------------------------------------------------------------------
    // Environment export
    // ------------------------------------------------------------------

    /// Collect all exported variables for passing to child processes.
    /// Alias used by exec.rs.
    pub fn exported_env(&self) -> HashMap<String, String> {
        self.get_exports()
    }

    /// Collect all exported scalar variables across all scopes (innermost wins).
    pub fn get_exports(&self) -> HashMap<String, String> {
        let mut result: HashMap<String, String> = HashMap::new();
        // Iterate outer → inner so that inner scopes override.
        for scope in &self.scopes {
            for (name, entry) in &scope.vars {
                if entry.exported {
                    if let VarValue::Scalar(ref s) = entry.value {
                        result.insert(name.clone(), s.clone());
                    }
                }
            }
        }
        result
    }

    // ------------------------------------------------------------------
    // Listing
    // ------------------------------------------------------------------

    /// Return all visible variables as (name, scalar-representation) pairs.
    /// Inner scopes shadow outer scopes.
    pub fn list_vars(&self) -> Vec<(String, String)> {
        let mut seen: HashMap<String, String> = HashMap::new();
        for scope in &self.scopes {
            for (name, entry) in &scope.vars {
                let repr = match &entry.value {
                    VarValue::Scalar(s) => s.clone(),
                    VarValue::Array(arr) => {
                        let dense: Vec<String> = arr.values();
                        format!("({})", dense.join(" "))
                    }
                    VarValue::AssocArray(map) => {
                        let mut pairs: Vec<String> = map
                            .iter()
                            .map(|(k, v)| format!("[{}]={}", k, v))
                            .collect();
                        pairs.sort();
                        format!("({})", pairs.join(" "))
                    }
                    VarValue::Unset => continue,
                };
                seen.insert(name.clone(), repr);
            }
        }
        let mut result: Vec<(String, String)> = seen.into_iter().collect();
        result.sort_by(|a, b| a.0.cmp(&b.0));
        result
    }

    /// Like `list_vars`, but only returns variables defined in the innermost
    /// (local) scope — used by `local` with no arguments.
    pub fn list_local_vars(&self) -> Vec<(String, String)> {
        let Some(scope) = self.scopes.last() else {
            return Vec::new();
        };
        let mut result: Vec<(String, String)> = Vec::new();
        for (name, entry) in &scope.vars {
            let repr = match &entry.value {
                VarValue::Scalar(s) => s.clone(),
                VarValue::Array(arr) => {
                    let dense: Vec<String> = arr.values();
                    format!("({})", dense.join(" "))
                }
                VarValue::AssocArray(map) => {
                    let mut pairs: Vec<String> = map
                        .iter()
                        .map(|(k, v)| format!("[{}]={}", k, v))
                        .collect();
                    pairs.sort();
                    format!("({})", pairs.join(" "))
                }
                VarValue::Unset => continue,
            };
            result.push((name.clone(), repr));
        }
        result.sort_by(|a, b| a.0.cmp(&b.0));
        result
    }

    /// Return variable names in all scopes that start with `prefix`.
    pub fn list_var_names_with_prefix(&self, prefix: &str) -> Vec<String> {
        let mut seen: std::collections::HashSet<String> = std::collections::HashSet::new();
        for scope in &self.scopes {
            for name in scope.vars.keys() {
                if name.starts_with(prefix) {
                    seen.insert(name.clone());
                }
            }
        }
        let mut result: Vec<String> = seen.into_iter().collect();
        result.sort();
        result
    }

    // ------------------------------------------------------------------
    // Positional parameters
    // ------------------------------------------------------------------

    /// Return the number of positional parameters.
    pub fn positional_count(&self) -> usize {
        self.positional_count
    }

    /// Get positional parameter $n (1-based).
    pub fn get_positional(&self, n: usize) -> Option<String> {
        self.get(&n.to_string())
    }

    /// Set positional parameter $n (1-based) in the global (bottom) scope.
    pub fn set_positional(&mut self, n: usize, value: &str) {
        let name = n.to_string();
        self.scopes[0]
            .vars
            .insert(name, VarEntry::new_scalar(value));
    }

    /// Return the first `count` positional parameters as a Vec.
    pub fn all_positional(&self, count: usize) -> Vec<String> {
        (1..=count)
            .map(|n| self.get_positional(n).unwrap_or_default())
            .collect()
    }

    // ------------------------------------------------------------------
    // Miscellaneous
    // ------------------------------------------------------------------

    /// Return the "length" of a variable: string length for scalars, element
    /// count for arrays.  ${#var} expansion uses an internal path that
    /// special-cases unset names; this public wrapper is for embedders.
    #[allow(dead_code)]
    pub fn var_length(&self, name: &str) -> usize {
        match self.get_entry(name).map(|e| &e.value) {
            Some(VarValue::Scalar(s)) => s.len(),
            Some(VarValue::Array(arr)) => arr.len_set(),
            Some(VarValue::AssocArray(map)) => map.len(),
            _ => 0,
        }
    }
}

impl Default for Variables {
    fn default() -> Self {
        Self::new()
    }
}
