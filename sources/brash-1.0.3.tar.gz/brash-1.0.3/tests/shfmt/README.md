# tests/shfmt — parser differential test against bash

This directory contains a parser-only differential test suite that verifies
brash parses shell scripts identically to bash.

## How it works

For each script in the corpus, the runner invokes both `bash -n` and
`brash -n` (parse-only, no execution) and compares exit codes:

- Both exit 0 → both parsers accepted the script — **PASS**
- Both exit non-zero → both parsers rejected the script — **PASS** (agreement on a parse error)
- Different exit codes → **FAIL** (parser parity mismatch)

Scripts where `brash -n` hangs (known brash quirk with top-level `while`/`until`
loops in `-n` mode) are counted separately as timeouts, not failures.

Scripts where brash is intentionally more permissive than bash (e.g., accepting
extglob patterns without an explicit `shopt -s extglob`) are listed as
*known differences* and do not contribute to the failure count.

## Corpus

| Source | Count | Notes |
|--------|-------|-------|
| `scripts/p*.sh` | 25 | Parser-stressing scripts covering the full bash syntax surface |
| `sh/cmd/shfmt/*.sh` | ~2 | shfmt's own bash scripts (clone required) |
| `../realworld/scripts/` | 38 | Existing realworld test scripts |

**Total: ~65 scripts**

### scripts/p*.sh — authored scripts

Each script targets a specific area of the bash parser:

| File | Coverage |
|------|----------|
| p01_heredocs.sh | Here-documents (all forms) |
| p02_param_expansion.sh | Parameter expansion (all operators) |
| p03_arithmetic.sh | Arithmetic expressions and commands |
| p04_redirection.sh | All redirection forms and fd operations |
| p05_conditionals.sh | if/elif/else, case, `[`, `[[` |
| p06_loops.sh | for-in, C-style for, while, until, select |
| p07_functions.sh | Function definitions and local variables |
| p08_arrays.sh | Indexed and associative arrays |
| p09_quoting.sh | All quoting mechanisms |
| p10_pipelines.sh | Pipelines and compound commands |
| p11_word_splitting.sh | Word splitting, glob expansion |
| p12_special_vars.sh | Special variables and builtins |
| p13_command_substitution.sh | Command and process substitution |
| p14_builtins.sh | Builtin commands |
| p15_patterns_extglob.sh | Pattern matching and glob options |
| p16_complex_strings.sh | Complex string handling |
| p17_error_handling.sh | Error handling patterns (set -e, traps) |
| p18_scope_subshell.sh | Variable scope and subshells |
| p19_process_control.sh | Job control and process management |
| p20_advanced_syntax.sh | Nameref, regex, advanced expansions |
| p21_edge_cases.sh | Edge cases and unusual constructs |
| p22_shfmt_canonical.sh | Derived from shfmt's canonical.sh |
| p23_realworld_patterns.sh | Real-world script patterns |
| p24_shfmt_extras.sh | Additional shfmt-inspired snippets |
| p25_line_continuations.sh | Line continuations and whitespace |

## Running

```sh
# Quick run (from repo root)
bash tests/shfmt/run.sh

# Verbose output
bash tests/shfmt/run.sh --verbose

# Override binaries
BASH=/usr/bin/bash BRASH=./target/debug/brash bash tests/shfmt/run.sh
```

## shfmt clone

The `sh/` directory is ignored by git. To optionally include shfmt's own
test files, clone it:

```sh
cd tests/shfmt
git clone --depth 1 https://github.com/mvdan/sh.git
```

shfmt's test corpus is primarily embedded in Go test files as string literals;
only a few standalone `.sh` files exist in the repository.

## Known differences

brash is intentionally more permissive than bash in some areas:

- **extglob always available**: brash accepts extended glob patterns (`!(x)`,
  `?(x)`, etc.) without requiring `shopt -s extglob` to be in effect at parse
  time.  `bash -n` rejects such patterns unless extglob is already on.

These are listed as `KNOWN` in the output and do not cause the test to fail.
