#!/bin/bash
# Parser stress: here-documents

cat <<EOF
simple heredoc
EOF

cat <<'EOF'
no $expansion here
EOF

cat <<-EOF
	indented heredoc
	with tabs
EOF

cat <<-'MARKER'
	literal $var in indented
MARKER

# Heredoc in pipeline
cat <<EOF | grep foo
foo bar
baz
EOF

# Multiple heredocs on one line
paste <(cat <<A
line1
A
) <(cat <<B
line2
B
)

# Heredoc with expansion
name=world
cat <<EOF
Hello ${name}
Value: $((1+2))
EOF

# Nested command in heredoc expansion
cat <<EOF
result: $(echo nested)
EOF
