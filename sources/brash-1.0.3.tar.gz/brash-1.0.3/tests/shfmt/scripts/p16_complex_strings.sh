#!/bin/bash
# Parser stress: complex string handling

# Multiline strings
x="line one
line two
line three"

# String with special chars
s1="tab:\there"
s2="null in: the middle"
s3="backslash: \\"
s4="dollar: \$var"

# String concatenation
a="hello"
b=" world"
c="${a}${b}"
d=${a}${b}

# String operations
str="Hello, World!"
echo ${#str}
echo ${str:7}
echo ${str:7:5}
echo ${str/World/Bash}
echo ${str,,}
echo ${str^^}
echo ${str^}

# printf formatting
printf '%s' "no newline"
printf '%q\n' "special 'chars' here"
printf '%b\n' "interpreted \t escape"
printf '%*d\n' 10 42
printf '%-*s|\n' 10 "left"

# Read into multiple vars
IFS=: read -r user pw uid gid info home shell <<< "root:x:0:0:root:/root:/bin/bash"
echo "$user $uid $home"

# Here-string with special content
grep . <<< $'line1\nline2\nline3'

# Multiline heredoc assign
text=$(cat <<'EOF'
first line
second line: $not_expanded
third line: `not backtick`
EOF
)
