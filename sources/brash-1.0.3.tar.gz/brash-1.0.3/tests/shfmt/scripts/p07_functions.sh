#!/bin/bash
# Parser stress: function definitions and calls

# POSIX function syntax
myfunc() {
    echo "function body"
}

# bash function keyword
function myfunc2 {
    echo "function with keyword"
}

# function keyword + parens
function myfunc3() {
    echo "both styles"
}

# Local variables
fn_local() {
    local x=10
    local -i count=0
    local -a arr
    local -A map
    local -r readonly_var=fixed
    echo "$x $count"
}

# Return value
fn_return() {
    return 0
}

fn_return_val() {
    return 42
}

# Recursive function
fib() {
    local n=$1
    if (( n <= 1 )); then
        echo $n
        return
    fi
    echo $(( $(fib $((n-1))) + $(fib $((n-2))) ))
}

# Function with redirections
fn_redir() {
    echo hello > /dev/null
} 2>/dev/null

# Nested function definition
outer() {
    inner() {
        echo "inner"
    }
    inner
}

# Function with getopts
parse_args() {
    local OPTIND opt
    while getopts "ab:c" opt; do
        case $opt in
            a) echo "a" ;;
            b) echo "b: $OPTARG" ;;
            c) echo "c" ;;
        esac
    done
    shift $((OPTIND-1))
}

# Calling functions
myfunc
myfunc2
myfunc3
fn_local
fn_return; echo $?
parse_args -a -b hello
