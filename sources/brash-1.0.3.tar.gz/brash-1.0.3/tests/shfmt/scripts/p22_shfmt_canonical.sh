#!/bin/bash
# Derived from shfmt's canonical.sh and other shfmt test snippets

# separate comment

! foo bar >a &

foo() { bar; }

{
    var1="some long value" # var1 comment
    var2=short             # var2 comment
}

if foo; then bar; fi

for foo in a b c; do
    bar
done

case $foo in
a) A ;;
b)
    B
    ;;
esac

foo | bar
foo &&
    $(bar) &&
    (more)

foo 2>&1
foo <<-EOF
    bar
EOF

$((3 + 4))

# Additional from shfmt parser tests
echo foo${bar}baz
echo "a ${b}c"
echo $(foo bar)
foo &>/dev/null
foo 2>/dev/null
foo |& bar
[[ -n $foo ]]
[[ $foo == bar ]]
((foo))
((foo++))
((foo, bar))
let foo=bar
foo=bar baz
foo=(bar baz)
foo[0]=bar
${foo[0]}
${foo[@]}
${!foo[@]}
${#foo}
${foo:0:5}
${foo/bar/baz}
${foo/#bar/baz}
${foo/%bar/baz}
${foo,,}
${foo^^}
x=(a b c)
echo "${x[@]}"
