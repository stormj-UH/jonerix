#!/bin/bash
# Parser stress: builtin commands

# read
read var
read -r var
read -p "prompt: " var
read -s var
read -t 0.1 var
read -n 1 var
read -a arr
read -d '' var
read -u 3 var

# echo / printf
echo hello
echo -n hello
echo -e "tab\there"
printf '%s\n' hello
printf '%d\n' 42

# source / dot
# source /dev/null
# . /dev/null

# eval
eval "echo hello"
eval 'x=5; echo $x'

# exec
# exec cat /dev/null

# trap
trap 'echo caught' INT
trap 'echo exit' EXIT
trap '' PIPE
trap - INT

# jobs, wait, disown
sleep 0 &
wait
sleep 0 &
disown

# type, which, command
type ls
type -a ls
type -t ls
command -v ls
command -p ls /dev/null

# compgen, complete (completion)
# compgen -c | head -5

# history
# history 5
# fc -l

# umask
umask 022
umask -S

# ulimit
ulimit -n

# times
# times

# getopts (inside function to avoid top-level while - brash -n quirk)
getopts_demo() {
    while getopts "ab:c" opt; do
        :
    done
}

# cd / pushd / popd
cd /tmp
cd -
pushd /tmp
popd

# dirs
dirs

# pwd
pwd
pwd -P

# hash
hash ls
hash -d ls
hash -r

# alias / unalias
alias ll='ls -la'
unalias ll 2>/dev/null || true
