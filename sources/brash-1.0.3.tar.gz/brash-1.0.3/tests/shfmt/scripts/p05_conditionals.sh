#!/bin/bash
# Parser stress: if/case/test constructs

# if/elif/else
if true; then
    echo a
elif false; then
    echo b
else
    echo c
fi

# Single-line if
if true; then echo yes; fi

# Negated condition
if ! false; then echo yes; fi

# test with [
if [ "$x" = "foo" ]; then echo yes; fi
if [ -f /etc/passwd ]; then echo yes; fi
if [ -z "" -a -n "x" ]; then echo yes; fi
if [ -z "" -o -n "x" ]; then echo yes; fi

# [[ extended test
if [[ $x == foo* ]]; then echo yes; fi
if [[ $x =~ ^foo[0-9]+$ ]]; then echo yes; fi
if [[ -f /etc/passwd && -r /etc/passwd ]]; then echo yes; fi
if [[ -z "" || -n "x" ]]; then echo yes; fi
if [[ ! -d /tmp ]]; then echo yes; fi

# case
case "$1" in
    foo)
        echo foo
        ;;
    bar|baz)
        echo barbaz
        ;;
    *)
        echo default
        ;;
esac

# case with fallthrough (;&)
case "$1" in
    a)
        echo a
        ;&
    b)
        echo b
        ;;&
    c)
        echo c
        ;;
esac

# Nested conditionals
if true; then
    if true; then
        echo nested
    fi
fi

# Conditional chaining
true && echo yes
false || echo no
true && false || echo fallback
