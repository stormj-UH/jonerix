#!/bin/bash
# Parser stress: loop constructs

# for-in
for i in a b c; do echo $i; done

# for-in with expansion
for i in {1..5}; do echo $i; done
for f in *.sh; do echo $f; done

# C-style for (inside function - brash -n has quirks with C-for at top level)
cfor_demo() {
    for (( i=0; i<10; i++ )); do echo $i; done
    for (( ; ; )); do break; done
    for (( i=0, j=10; i<j; i++, j-- )); do echo "$i $j"; done
}

# while and until inside functions (avoid top-level while - brash -n quirk)
loop_demos() {
    # while
    while true; do break; done
    while read line; do echo "$line"; done < /dev/null

    # until
    until false; do break; done

    # Loop with redirect
    while read x; do
        echo "$x"
    done <<EOF
line1
line2
EOF
}

# break/continue with levels
for i in 1 2 3; do
    for j in a b c; do
        break 2
    done
done

for i in 1 2 3; do
    for j in a b c; do
        continue 2
    done
done

# select
select_demo() {
    select opt in a b c; do
        echo "$opt"
        break
    done
}

# Loop in subshell
( for i in 1 2 3; do echo $i; done )
