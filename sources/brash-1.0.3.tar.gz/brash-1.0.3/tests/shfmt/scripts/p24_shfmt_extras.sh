#!/bin/bash
# Parser stress: snippets inspired by shfmt's parser test cases

# Arithmetic command forms
(( i = 0 ))
(( i += 1 ))
(( i++, j-- ))
(( a = b = c = 0 ))
(( arr[0] = 1 ))

# Various test expressions
[[ -v var ]]
[[ -R var ]]
[[ -o errexit ]]
[[ foo < bar ]]
[[ foo > bar ]]
[[ /tmp -nt /tmp ]]
[[ /tmp -ot /tmp ]]
[[ /tmp -ef /tmp ]]

# Unusual redirections
echo foo {n}>&1  2>/dev/null || true
cmd() { :; }
cmd {fd}<>/dev/null 2>/dev/null || true

# Here-doc edge cases
cat <<EOF
EOF

cat <<'EOF'
EOF

cat <<-"EOF"
EOF

# Semicolons and newlines edge cases
if true
then
true
fi

# while/until inside functions to avoid brash -n hang
loop_forms() {
    while true
    do
    break
    done

    until false
    do
    break
    done
}

# Multiple assignments
a=1 b=2 c=3 echo "$a $b $c"
export a=1 b=2

# Compound assignment
declare -A h=([key]=val [k2]=v2)
declare -a a=(1 2 3)

# Special case: bash-specific [[ features
[[ "${arr[@]}" =~ pattern ]]
[[ $'\n' == $'\n' ]]

# Variable name edge cases
_var=1
__var=1
VAR123=1
var_with_underscores=1
ALLCAPS=1

# Nested quotes
echo "${x:-"default value"}"
echo "${arr[$(echo 0)]}"

# Command with no args but redirections
> /dev/null

# Coprocess syntax
coproc { read x; echo "$x"; }
coproc named { read x; echo "$x"; }
