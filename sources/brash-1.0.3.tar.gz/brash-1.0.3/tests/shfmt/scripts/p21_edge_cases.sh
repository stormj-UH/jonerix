#!/bin/bash
# Parser stress: edge cases and unusual constructs

# Empty function body
noop() { :; }

# Semicolons
{ : ; }
( : ; )
if :; then :; fi
# while at top-level causes brash -n to hang; use inside function
while_demo() { while :; do break; done; }

# Newlines as separators
{
    :
}

if :
then
    :
fi

for x in a
do
    :
done

# Comments in various positions
x=1 # inline comment
# Full line comment
{ echo a # comment in block
}

# Odd spacing
x=1;y=2;z=3
echo  $x   $y   $z

# Assignments without value
declare x
local y 2>/dev/null || true
export z

# Empty list
for i in; do echo never; done 2>/dev/null || true

# Null command
:
: "$@"
: "noop with args"

# Last pipe element
true | :
false | :

# Pipeline in function
pipe_fn() { cat | grep . ; }

# Background in condition
if { sleep 0 & wait; }; then echo ok; fi

# Redirection only command
> /dev/null
< /dev/null cat

# Compound command as condition (inside function to avoid brash -n hang)
compound_while_demo() {
    while { read line; [[ -n $line ]]; } <<< "hello"; do
        echo "$line"
    done
}

# Semicolon-newline interaction
echo a ; \
echo b

# Long option names
shopt -s extglob
shopt --set extglob 2>/dev/null || true
