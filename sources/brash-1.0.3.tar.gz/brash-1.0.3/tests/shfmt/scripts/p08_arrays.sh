#!/bin/bash
# Parser stress: arrays and associative arrays

# Indexed array
arr=(a b c d e)
arr2=([0]=first [2]=third [4]=fifth)

# Assignment forms
arr[5]=f
arr+=(g h)

# Access forms
echo ${arr[0]}
echo ${arr[-1]}
echo ${arr[@]}
echo ${arr[*]}
echo "${arr[@]}"
echo "${arr[*]}"
echo ${#arr[@]}
echo ${!arr[@]}

# Slices
echo ${arr[@]:1:3}
echo ${arr[@]: -2}

# Patterns
echo ${arr[@]//a/A}
echo ${arr[@]#?}

# Associative array
declare -A map
map[key]=value
map=([k1]=v1 [k2]=v2)

echo ${map[k1]}
echo ${!map[@]}
echo ${#map[@]}

# Nested arrays via nameref
declare -n ref=arr
echo ${ref[@]}

# mapfile / readarray
mapfile -t lines <<EOF
line1
line2
line3
EOF
echo "${lines[@]}"

readarray -t words <<< "a b c"

# Array in loop
for item in "${arr[@]}"; do
    echo "$item"
done

# Array passed to function
fn_arr() {
    local -n _arr=$1
    echo "${_arr[@]}"
}
fn_arr arr
