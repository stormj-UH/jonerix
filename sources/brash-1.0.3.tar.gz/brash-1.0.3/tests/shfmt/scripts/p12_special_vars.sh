#!/bin/bash
# Parser stress: special variables and builtins

# Special parameters
echo $0    # script name
echo $1 $2 # positional
echo $@    # all args
echo $*    # all args as string
echo $#    # arg count
echo $?    # last exit status
echo $$    # current PID
echo $!    # last background PID
echo $_    # last argument

# IFS, PS1, PS2, etc
echo "$IFS"
echo "$BASH_VERSION"
echo "$LINENO"
echo "$FUNCNAME"
echo "$BASH_SOURCE"
echo "$PIPESTATUS"

# RANDOM and SECONDS
echo $RANDOM
echo $SECONDS

# BASH_LINENO, BASH_COMMAND
echo "${BASH_LINENO[@]}"
echo "$BASH_COMMAND"

# Shift
set -- a b c d e
shift
shift 2
echo $@

# set -e, -u, -x, -o
set -euo pipefail
set +euo pipefail
set -o errexit
set +o errexit

# declare and typeset
declare -i int_var=42
declare -r readonly=fixed
declare -x exported=val
declare -l lower=UPPER
declare -u upper=lower

# readonly
readonly myconst=42

# export
export PATH
export MYVAR=value

# unset
unset myvar
unset -f myfunc
unset -v myarray[0]

# printf
printf '%s\n' hello
printf '%d %f\n' 42 3.14
printf '%-10s %5d\n' label 42
