#!/bin/bash
# Parser stress: process control, job control

# Background and wait
sleep 0 &
PID=$!
wait $PID

# Multiple background jobs
sleep 0 &
sleep 0 &
wait

# Wait for specific PID
sleep 0 &
pid=$!
wait $pid
echo "exit: $?"

# Disown
sleep 60 &
pid=$!
kill $pid 2>/dev/null
disown $pid 2>/dev/null || true

# Jobs
sleep 0 &
jobs
jobs -l
jobs -p

# fg/bg (not safe to run but must parse)
# fg %1
# bg %1

# Kill
sleep 0 &
kill -0 $!
kill -TERM $! 2>/dev/null || true
wait $! 2>/dev/null || true

kill -l
kill -l TERM

# Signal numbers
kill -9 $$ 2>/dev/null || true
kill -s SIGTERM $$ 2>/dev/null || true

# Coprocess (parse only)
coproc mycoproc { cat; }
echo hi >&${mycoproc[1]}
read line <&${mycoproc[0]}
kill ${mycoproc_PID} 2>/dev/null || true

# exec redirection
exec 3>/dev/null
echo hello >&3
exec 3>&-

# SHLVL
echo "shell level: $SHLVL"
