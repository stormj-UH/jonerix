#!/bin/bash
# Parser stress: advanced syntax constructs

# Nameref (bash 4.3+)
declare -n nameref=target_var
target_var=42
echo $nameref
nameref=99
echo $target_var

# Associative array nameref
declare -A orig_map=([a]=1 [b]=2)
declare -n mapref=orig_map
echo ${mapref[a]}

# Nested parameter expansion
x=hello
y=x
echo ${!y}        # indirect: hello
echo ${!y#hel}    # hello -> indirect then trim? -> no, !name@

# @Q, @E, @P, @A, @a modifiers
var="hello world"
echo "${var@Q}"
echo "${var@E}"

# Regex in [[
if [[ "hello123" =~ ^[a-z]+[0-9]+$ ]]; then
    echo "BASH_REMATCH: ${BASH_REMATCH[0]}"
fi

# Compound assignment in (())
(( a=1, b=2, c=a+b ))

# String index assignment (not valid but parseable)
# str[0]=x  # actually array

# Multi-dimensional array simulation
declare -A matrix
matrix[0,0]=a
matrix[0,1]=b
matrix[1,0]=c

# Integer arithmetic with different bases
echo $(( 8#17 ))   # octal 17
echo $(( 16#ff ))  # hex ff
echo $(( 2#1010 )) # binary 1010

# Conditional assignment patterns
: ${DEFAULT:=value}
VAR=${VAR:-fallback}
REQUIRED=${REQUIRED:?must be set}

# String repeat (no native, but pattern)
repeat_str() {
    local str=$1 n=$2 result=
    for (( i=0; i<n; i++ )); do result+=$str; done
    echo "$result"
}

# Mapfile with callback
_process() { echo "Processing: $2"; }
mapfile -t -C _process -c 1 arr < /dev/null
