#!/bin/bash
# Parser stress: error handling patterns

# errexit handling
set -e
set +e

# ERR trap
trap 'echo "Error at line $LINENO"' ERR

# Return code check
cmd() { return 0; }
cmd || { echo "failed"; exit 1; }
cmd && echo "succeeded"

# Conditional with ||
do_thing() {
    false || return 1
    true || exit 1
}

# Subshell error isolation
(
    set -e
    false
    echo "not reached"
) || echo "subshell failed"

# errexit with functions
set -e
safe_cmd() {
    local rc=0
    some_cmd || rc=$?
    return $rc
} 2>/dev/null

# Pipefail
set -o pipefail
false | true || echo "pipe failed"
set +o pipefail

# nounset
set -u
: "${MYVAR:=default}"
set +u

# Trap EXIT for cleanup
cleanup() {
    echo "cleaning up"
}
trap cleanup EXIT

# Trap multiple signals
trap 'echo "interrupt"' INT QUIT TERM

# Error message function
die() {
    echo "ERROR: $*" >&2
    exit 1
}

# Assert
assert() {
    local cond="$1"
    eval "$cond" || die "assertion failed: $cond"
}
