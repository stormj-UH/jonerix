#!/bin/bash
# Parser stress: scope, subshells, and environment

# Variable scoping
x=global
fn() {
    local x=local
    echo "inside: $x"
}
fn
echo "outside: $x"

# Subshell inherits but isolates
y=parent
(
    echo "child sees: $y"
    y=child
    echo "child set: $y"
)
echo "parent after: $y"

# export to child processes
export EV=exported
bash -c 'echo $EV' 2>/dev/null || true

# env command
env VAR=val command -v true > /dev/null

# Subshell grouping
result=$(
    echo a
    echo b
    echo c
)

# Nested subshells
(
    (
        echo "deeply nested"
    )
)

# Subshell exit code
( exit 42 )
echo "subshell exited: $?"

# Fork bomb guard (parsing, not exec)
# bomb() { bomb | bomb & }

# Variable in different scopes
for i in 1 2 3; do
    (
        i=inner_$i
        echo $i
    )
    echo "outer: $i"
done

# BASH_SUBSHELL
echo "subshell depth: $BASH_SUBSHELL"
( echo "in subshell: $BASH_SUBSHELL" )

# Subshell with pipefail
(
    set -o pipefail
    false | true
) || echo "inner pipefail caught"
