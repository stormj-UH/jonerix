#!/bin/bash
# Parser stress: pipelines and compound commands

# Simple pipeline
echo hello | cat
echo hello | grep hello | head -1

# Negated pipeline
! echo hello | false

# Pipeline with time
time echo hello | cat

# Logical operators
true && echo yes
false || echo no
true && true && echo both
false || false || echo neither

# Compound: {}
{ echo a; echo b; }
{ echo a; echo b; } | cat
{ echo a; echo b; } > /dev/null
{ echo a
  echo b
}

# Compound: ()
(echo a; echo b)
(echo a; echo b) | cat
(echo a) | (echo b)

# Subshell variable isolation
x=outer
(x=inner; echo $x)
echo $x

# Pipeline exit status
pipeline_status() {
    false | true
    echo "last: $?"
    set -o pipefail
    false | true || echo "pipe failed"
    set +o pipefail
}

# Coprocess (bash 4+)
# coproc cat

# Background
sleep 0 &
wait $!

# Pipeline backgrounded
echo hello | cat &
wait

# Long pipeline
echo test | cat | cat | cat | cat | cat | wc -c
