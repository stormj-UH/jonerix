#!/bin/bash
# Parser stress: command substitution forms

# Modern form
x=$(echo hello)
y=$(date +%s)

# Nested
z=$(echo $(echo nested))
w=$(echo $(echo $(echo triple)))

# In assignment
var=$(cmd1; cmd2; echo final)

# In string
echo "result: $(echo hello)"
echo "count: $(ls | wc -l)"

# In array
arr=($(echo a b c))
arr2=($(seq 1 5))

# Old backtick form
old=`echo hello`
old2=`echo \`echo nested\``

# In arithmetic
echo $(( $(echo 5) + 3 ))

# Command substitution with heredoc
result=$(cat <<EOF
line1
line2
EOF
)

# With redirection inside
out=$(echo hello > /dev/null; echo world)

# In condition
if [ "$(echo yes)" = "yes" ]; then echo ok; fi

# Process substitution
diff <(echo hello) <(echo hello)
cat <(echo from_proc_sub)
wc -l < <(echo hello)

# Output to process sub
echo hello > >(cat)
tee >(cat > /dev/null) < /dev/null

# In function call
myfunc "$(echo arg)"

# Chained substitutions
result=$(echo $(echo $(date +%s)))
