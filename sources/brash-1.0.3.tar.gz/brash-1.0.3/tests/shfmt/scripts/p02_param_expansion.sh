#!/bin/bash
# Parser stress: parameter expansion forms

x=hello
: ${x}
: ${x:-default}
: ${x:=assign}
: ${x:?error msg}
: ${x:+alt}
: ${x#prefix}
: ${x##longest_prefix}
: ${x%suffix}
: ${x%%longest_suffix}
: ${x/pat/repl}
: ${x//pat/repl}
: ${x/#pat/repl}
: ${x/%pat/repl}
: ${#x}
: ${x:2}
: ${x:2:3}
: ${x^}
: ${x^^}
: ${x,}
: ${x,,}
: ${x@Q}
: ${x@E}
: ${x@P}
: ${x@A}
: ${x@a}

# Array expansions
arr=(a b c)
: ${arr[@]}
: ${arr[*]}
: ${arr[0]}
: ${#arr[@]}
: ${arr[@]:1:2}
: ${arr[@]//a/b}
: ${!arr[@]}

# Indirect
var=x
: ${!var}

# Nested expansion
: ${x:-${y:-default}}
