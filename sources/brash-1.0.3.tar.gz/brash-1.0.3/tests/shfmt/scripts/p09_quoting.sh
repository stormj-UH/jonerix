#!/bin/bash
# Parser stress: quoting mechanisms

# Double quotes
echo "hello world"
echo "with $var expansion"
echo "with $(cmd) substitution"
echo "with $((1+2)) arithmetic"
echo "escaped: \$ \` \\ \""
echo "newline: \n not expanded"

# Single quotes - nothing expanded
echo 'literal $var'
echo 'literal `cmd`'
echo 'literal $(cmd)'
echo 'has "double" quotes inside'

# Dollar-single-quote (ANSI-C quoting)
echo $'hello\tworld\n'
echo $'\x41\x42\x43'
echo $'A'
echo $'\101'  # octal A
echo $'escaped \'quote\''
echo $'backslash \\'

# Dollar-double-quote (locale translation)
echo $"translatable string"

# Quoting in assignment
x="value with spaces"
y='literal $dollar'
z=$'tab\there'

# Quote removal
echo ""
echo ''
echo $''

# Quoting in array
arr=("element one" 'element two' $'element\tthree')

# Adjacent quoting
echo "first"'second'"third"
echo abc"def"ghi

# Quoting with special chars
echo "pipe | in quotes"
echo "redirect > in quotes"
echo "semicolon ; in quotes"

# Word splitting affected by quoting
x="a b c"
echo $x   # splits
echo "$x" # no split
