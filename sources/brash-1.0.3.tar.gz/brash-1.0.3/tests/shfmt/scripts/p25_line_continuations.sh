#!/bin/bash
# Parser stress: line continuations and tricky whitespace

# Line continuation in various positions
echo foo \
    bar \
    baz

x=hello \
    world

if true \
    && false \
    || true; then
    echo yes
fi

for i in \
    1 2 3; do
    echo $i
done

# Continuation in strings
s="long string \
continued"

# Continuation after operator
result=$(echo foo \
    | grep foo \
    | head -1)

# Continuation in array
arr=(
    elem1
    elem2
    elem3
)

arr2=(elem1 \
    elem2 \
    elem3)

# Continuation in function
long_function_name() \
{
    echo "body"
}

# Continuation in case
case "$x" in
    foo | \
    bar)
        echo "foo or bar"
        ;;
esac

# ANSI-C quoting across continuation
x=$'\
hello'

# Continuation in here-doc delimiter (not valid but parse check)
# cat <<\
# EOF
# EOF

# Semicolon after newline
{
    echo a;
    echo b;
}

# Multiple semicolons (;; is only valid in case; this is a syntax error in bash)
# echo a;;  # intentionally omitted - bash syntax error
