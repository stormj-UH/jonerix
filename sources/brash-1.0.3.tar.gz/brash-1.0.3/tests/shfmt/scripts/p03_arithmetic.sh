#!/bin/bash
# Parser stress: arithmetic expressions

# Basic forms
echo $(( 1 + 2 ))
echo $(( 2 ** 10 ))
echo $(( 0xff & 0x0f ))
echo $(( 1 << 4 ))
echo $(( 100 >> 2 ))

# Conditional (ternary)
x=5
echo $(( x > 3 ? 1 : 0 ))

# Comma operator
echo $(( x=1, y=2, x+y ))

# Pre/post increment/decrement
(( x++ ))
(( ++x ))
(( x-- ))
(( --x ))

# let command
let a=1+2
let b=a*3

# Compound assignment operators
(( x += 10 ))
(( x -= 5 ))
(( x *= 2 ))
(( x /= 3 ))
(( x %= 7 ))
(( x **= 2 ))
(( x &= 0xff ))
(( x |= 0x100 ))
(( x ^= 0xaa ))
(( x <<= 1 ))
(( x >>= 1 ))

# Nested arithmetic
echo $(( (1 + 2) * (3 + 4) ))

# Arithmetic in array index
arr=(a b c d)
i=1
echo ${arr[i+1]}

# C-style for loop
for (( i=0; i<5; i++ )); do
    echo $i
done

# while arithmetic
n=10
while (( n > 0 )); do
    (( n-- ))
done
