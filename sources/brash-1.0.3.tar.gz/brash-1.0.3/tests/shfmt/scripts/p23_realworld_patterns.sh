#!/bin/bash
# Parser stress: real-world script patterns

# Script template
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Logging
log() { printf '[%s] %s\n' "$(date +%H:%M:%S)" "$*" >&2; }
warn() { log "WARN: $*"; }
error() { log "ERROR: $*"; exit 1; }

# Dependency check
require_cmd() {
    command -v "$1" >/dev/null 2>&1 || error "Required: $1"
}

# OS detection
detect_os() {
    case "$(uname -s)" in
        Linux*)   echo linux ;;
        Darwin*)  echo macos ;;
        MINGW*)   echo windows ;;
        *)        echo unknown ;;
    esac
}

# Version comparison
version_ge() {
    printf '%s\n%s' "$1" "$2" | sort -V | head -1 | grep -qF "$2"
}

# Retry with backoff
retry() {
    local max=$1 delay=$2
    shift 2
    local attempt=0
    while (( attempt < max )); do
        "$@" && return 0
        (( attempt++ ))
        sleep "$delay"
    done
    return 1
}

# String join
join() {
    local IFS="$1"
    shift
    echo "$*"
}

# Array contains
contains() {
    local item="$1"
    shift
    local elem
    for elem in "$@"; do
        [[ "$elem" == "$item" ]] && return 0
    done
    return 1
}

# Temp file cleanup
TMPDIR_WORK=$(mktemp -d)
trap 'rm -rf "$TMPDIR_WORK"' EXIT

# Config file parsing
parse_config() {
    local file="$1"
    while IFS='=' read -r key value; do
        key="${key%%#*}"      # strip comments
        key="${key//[[:space:]]/}"   # strip spaces
        [[ -z "$key" ]] && continue
        printf '%s=%s\n' "$key" "$value"
    done < "$file"
}

# Parallel execution
run_parallel() {
    local -a pids=()
    for arg in "$@"; do
        process "$arg" &
        pids+=($!)
    done
    local rc=0
    for pid in "${pids[@]}"; do
        wait "$pid" || rc=$?
    done
    return $rc
}

process() { echo "$1"; }
