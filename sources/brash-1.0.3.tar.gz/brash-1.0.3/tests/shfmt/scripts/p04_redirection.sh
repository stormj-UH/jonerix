#!/bin/bash
# Parser stress: redirection forms

# Basic redirections
cmd > /dev/null
cmd >> /dev/null
cmd < /dev/null
cmd 2> /dev/null
cmd 2>> /dev/null
cmd &> /dev/null
cmd &>> /dev/null

# File descriptor duplication
cmd 2>&1
cmd 1>&2
cmd 3>&1 1>/dev/null
cmd 2>&-

# Process substitution
diff <(sort file1) <(sort file2)
tee >(cat) >(wc -l) < /dev/null

# Here-string
grep foo <<< "foo bar baz"
read x <<< "hello world"

# noclobber override
cmd >| /dev/null

# Multiple redirections
cmd < /dev/null > /dev/null 2>&1

# Redirect in function
fn() {
    echo hello > /dev/null
    cat < /dev/null
}

# fd open/close in block
{
    exec 3</dev/null
    exec 3>&-
}

# Named fd
exec {myfd}>/dev/null
exec {myfd}>&-
