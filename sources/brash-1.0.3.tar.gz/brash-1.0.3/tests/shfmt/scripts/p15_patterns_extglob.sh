#!/bin/bash
# Parser stress: pattern matching and glob options
# Note: extglob patterns (!(x), ?(x), etc.) require shopt -s extglob at parse time
# in bash, so bash -n will reject them. This script avoids extglob patterns
# at the top level and in function bodies for -n parse-parity testing.

# Standard glob patterns in case (no extglob needed)
word=hello
case "$word" in
    h[aeiou]llo)   echo "vowel after h" ;;
    h*o)           echo "h..o" ;;
    *[[:digit:]]*)   echo "has digit" ;;
    [[:upper:]]*)    echo "starts upper" ;;
    [a-z]*)         echo "lowercase start" ;;
    *)              echo "other" ;;
esac

# Pattern in [[ ]] - string comparison patterns (no extglob needed)
if [[ foo == f* ]]; then echo "prefix match"; fi
if [[ bar != foo ]]; then echo "not equal"; fi
if [[ hello =~ ^[a-z]+$ ]]; then echo "regex match"; fi
if [[ "abc123" =~ ([a-z]+)([0-9]+) ]]; then
    echo "groups: ${BASH_REMATCH[1]} ${BASH_REMATCH[2]}"
fi

# Standard patterns in parameter expansion
x=foobarbaz
echo ${x/foo/}
echo ${x//[aeiou]/}
echo ${x#foo}
echo ${x##f*o}
echo ${x%baz}
echo ${x%%b*}

# Case with multiple patterns (no extglob)
for f in file.c file.h file.o README.md main.cpp; do
    case $f in
        *.c|*.h)  echo "$f: C source" ;;
        *.o)      echo "$f: object" ;;
        *.cpp)    echo "$f: C++ source" ;;
        *)        echo "$f: other" ;;
    esac
done

# Glob options (just the shopt calls, not the expansions)
shopt -s globstar
shopt -s nullglob
shopt -u nullglob
shopt -s nocaseglob
shopt -u nocaseglob
shopt -s dotglob
shopt -u dotglob
shopt -s extglob
shopt -u extglob
