#!/bin/bash
# Parser stress: word splitting and glob expansion

# IFS splitting
IFS=: path_copy=$PATH
IFS=, csv="a,b,c"
read -ra parts <<< "a:b:c"

# Glob patterns
# (these would match files; safe to parse)
echo *.sh
echo /tmp/*.log
echo /etc/*conf*
echo /usr/lib/**/*.so

# Extended globs are covered in p15_patterns_extglob.sh

# shopt options
shopt -s nullglob
shopt -u nullglob
shopt -s failglob
shopt -u failglob
shopt -s globstar

# Brace expansion
echo {a,b,c}
echo {1..5}
echo {01..10}
echo {a..z}
echo {A..Z..2}
echo pre{a,b,c}suf
echo {a,{b,c},d}

# Tilde expansion
echo ~
echo ~/dir
echo ~root
echo ~+
echo ~-

# Pathname expansion with character classes
echo /tmp/[abc]*
echo /tmp/[[:alpha:]]*
echo /tmp/[0-9]*

# nullglob, failglob (options)
shopt -s nullglob
shopt -u nullglob
