#!/usr/bin/env bash
# tests/shfmt/run.sh — parser-only differential test against bash
#
# For each script in the corpus, run both bash and brash with -n (parse-only,
# no execution).  Compare exit codes:  both 0 = pass,  both non-zero = pass,
# different = fail (parser parity mismatch).
#
# Usage:  bash tests/shfmt/run.sh [--verbose]
#
# Environment:
#   BASH   path to bash  (default: bash)
#   BRASH  path to brash (default: auto-detected from cargo target)

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"

VERBOSE=0
for arg in "$@"; do
    case "$arg" in
        --verbose|-v) VERBOSE=1 ;;
        --help|-h)
            echo "Usage: $0 [--verbose]"
            echo "  BASH=<path>   override bash binary"
            echo "  BRASH=<path>  override brash binary"
            exit 0
            ;;
    esac
done

# ---- Locate binaries --------------------------------------------------------

BASH="${BASH:-bash}"
if [[ -z "${BRASH:-}" ]]; then
    for candidate in \
        "$REPO_ROOT/target/release/brash" \
        "$REPO_ROOT/target/debug/brash"; do
        if [[ -x "$candidate" ]]; then
            BRASH="$candidate"
            break
        fi
    done
fi

if [[ -z "${BRASH:-}" ]]; then
    echo "ERROR: brash binary not found. Run 'cargo build --release' first." >&2
    exit 1
fi

if ! command -v "$BASH" >/dev/null 2>&1; then
    echo "ERROR: bash binary not found: $BASH" >&2
    exit 1
fi

BASH_VERSION_STR=$("$BASH" --version 2>&1 | head -1)
BRASH_VERSION_STR=$("$BRASH" --version 2>&1 | head -1)

# ---- Collect corpus ---------------------------------------------------------

# Primary: authored parser-stressing scripts
SCRIPTS_DIR="$SCRIPT_DIR/scripts"

# Secondary: shfmt's own .sh files (if clone present)
SHFMT_DIR="$SCRIPT_DIR/sh"

# Tertiary: existing realworld scripts
REALWORLD_DIR="$REPO_ROOT/tests/realworld/scripts"

declare -a CORPUS=()

# Add authored scripts
if [[ -d "$SCRIPTS_DIR" ]]; then
    while IFS= read -r f; do
        CORPUS+=("$f")
    done < <(find "$SCRIPTS_DIR" -name "*.sh" | sort)
fi

# Add shfmt's own .sh files — but only the canonical/example ones,
# not internal testdata files that may contain intentionally non-bash syntax.
if [[ -d "$SHFMT_DIR" ]]; then
    while IFS= read -r f; do
        # Skip shfmt-internal testdata (e.g. typedjson round-trip files
        # that intentionally contain syntax bash cannot parse)
        case "$f" in
            */typedjson/testdata/*) continue ;;
        esac
        CORPUS+=("$f")
    done < <(find "$SHFMT_DIR" -maxdepth 3 -name "*.sh" | sort)
fi

# Add realworld scripts
if [[ -d "$REALWORLD_DIR" ]]; then
    while IFS= read -r f; do
        CORPUS+=("$f")
    done < <(find "$REALWORLD_DIR" -name "*.sh" | sort)
fi

TOTAL=${#CORPUS[@]}
if (( TOTAL == 0 )); then
    echo "ERROR: no test scripts found" >&2
    exit 1
fi

# ---- Known differences ------------------------------------------------------
# Scripts where bash -n and brash -n are expected to disagree.
# These represent brash being more permissive (e.g., extglob always available).
# They are reported but do NOT contribute to the failure count.

declare -a KNOWN_DIFFS=(
    # brash accepts extglob patterns without explicit shopt -s extglob;
    # bash -n rejects them.  This is a documented brash extension.
    "tests/realworld/scripts/24_pattern_matching.sh"
)

is_known_diff() {
    local script="$1"
    local rel="${script#"$REPO_ROOT/"}"
    local kd
    for kd in "${KNOWN_DIFFS[@]}"; do
        [[ "$rel" == "$kd" ]] && return 0
    done
    return 1
}

# ---- Run tests --------------------------------------------------------------

PARSE_TIMEOUT=10  # seconds per script

pass=0
fail=0
timeout_count=0
known_diff_count=0

echo "Parser parity test: bash -n vs brash -n"
echo "bash:  $BASH_VERSION_STR"
echo "brash: $BRASH_VERSION_STR"
echo "corpus: $TOTAL scripts"
echo ""

for script in "${CORPUS[@]}"; do
    name="${script#"$REPO_ROOT/"}"  # relative path for display

    bash_rc=0
    brash_rc=0

    "$BASH" -n "$script" 2>/dev/null || bash_rc=$?

    if ! timeout "$PARSE_TIMEOUT" "$BRASH" -n "$script" >/dev/null 2>&1; then
        brash_rc=$?
        # timeout exits 124; treat any brash timeout as a known quirk
        if (( brash_rc == 124 )); then
            (( timeout_count++ )) || true
            if (( VERBOSE )); then
                printf "  TIMEOUT  %-60s (bash=%d, brash=timeout)\n" \
                    "$name" "$bash_rc"
            fi
            continue
        fi
    fi

    if (( bash_rc == brash_rc )); then
        (( pass++ )) || true
        if (( VERBOSE )); then
            printf "  PASS     %-60s (rc=%d)\n" "$name" "$bash_rc"
        fi
    elif is_known_diff "$script"; then
        (( known_diff_count++ )) || true
        if (( VERBOSE )); then
            printf "  KNOWN    %-60s (bash=%d, brash=%d)\n" \
                "$name" "$bash_rc" "$brash_rc"
        fi
    else
        (( fail++ )) || true
        printf "  FAIL     %-60s (bash=%d, brash=%d)\n" \
            "$name" "$bash_rc" "$brash_rc"
        if (( VERBOSE )); then
            echo "    bash stderr:  $("$BASH"  -n "$script" 2>&1 | head -2 || true)"
            echo "    brash stderr: $(timeout "$PARSE_TIMEOUT" "$BRASH" -n "$script" 2>&1 | head -2 || true)"
        fi
    fi
done

# ---- Summary ----------------------------------------------------------------

checked=$(( pass + fail + known_diff_count ))
parity_pct=0
if (( pass + fail > 0 )); then
    parity_pct=$(( pass * 100 / (pass + fail) ))
fi

echo ""
echo "=== Results ==="
echo "  total scripts:   $TOTAL"
echo "  checked:         $checked  (excluding $timeout_count brash timeouts)"
echo "  pass (parity):   $pass"
echo "  fail (mismatch): $fail"
echo "  known diffs:     $known_diff_count  (brash more permissive, expected)"
echo "  parser parity:   ${parity_pct}%"
echo ""

if (( fail > 0 )); then
    echo "FAIL: $fail unexpected parser parity mismatch(es)"
    exit 1
else
    echo "PASS: all $pass checked scripts parse identically (+ $known_diff_count known diffs)"
    exit 0
fi
