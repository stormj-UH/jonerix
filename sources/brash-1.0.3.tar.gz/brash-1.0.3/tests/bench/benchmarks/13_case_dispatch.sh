#!/usr/bin/env bash
# Case-pattern dispatch — common dispatch pattern.
classify() {
    case "$1" in
        red|blue|green) echo color ;;
        ada|bob|carol)  echo person ;;
        north|south|east|west) echo direction ;;
        small|medium|large) echo size ;;
        [0-9]*) echo number ;;
        *.txt|*.md) echo doc ;;
        *.sh|*.py|*.rs) echo code ;;
        *) echo other ;;
    esac
}

# Run lots of dispatches
total=0
for ((i = 0; i < 5000; i++)); do
    case $((i % 8)) in
        0) r=$(classify red) ;;
        1) r=$(classify ada) ;;
        2) r=$(classify north) ;;
        3) r=$(classify large) ;;
        4) r=$(classify "1234") ;;
        5) r=$(classify "foo.txt") ;;
        6) r=$(classify "bar.sh") ;;
        7) r=$(classify "unknown") ;;
    esac
    total=$((total + ${#r}))
done
echo $total
