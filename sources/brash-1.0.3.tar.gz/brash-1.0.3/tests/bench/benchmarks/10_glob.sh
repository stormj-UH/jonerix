#!/usr/bin/env bash
# Glob expansion against a generated directory.
tmpdir=$(mktemp -d)
cd "$tmpdir"
# create 500 files
for ((i = 0; i < 500; i++)); do
    : > "f_${i}.txt"
done
for ((i = 0; i < 100; i++)); do
    : > "x_${i}.md"
done

# Glob 100 times
total=0
for ((i = 0; i < 100; i++)); do
    matches=( *.txt )
    total=$((total + ${#matches[@]}))
done
echo $total

cd /
rm -rf "$tmpdir"
