#!/usr/bin/env bash
# String concatenation in a loop — Rust's String append should be O(amortized 1).
s=""
for ((i = 0; i < 5000; i++)); do
    s="${s}x"
done
echo "${#s}"
