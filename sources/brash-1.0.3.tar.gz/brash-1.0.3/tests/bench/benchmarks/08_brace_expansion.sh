#!/usr/bin/env bash
# Brace expansion — large literal expansion.
arr=({0001..2000})
echo "${#arr[@]}"
echo "${arr[1000]}"
