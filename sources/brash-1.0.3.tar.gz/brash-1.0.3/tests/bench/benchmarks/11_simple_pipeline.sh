#!/usr/bin/env bash
# Pipeline overhead — fork + pipe handling.
# Each pipe forks 3-4 processes; the shell that handles forks fastest wins.
n=0
for ((i = 0; i < 50; i++)); do
    out=$(echo "a b c d e" | tr ' ' '\n' | sort | head -1)
    n=$((n + ${#out}))
done
echo $n
