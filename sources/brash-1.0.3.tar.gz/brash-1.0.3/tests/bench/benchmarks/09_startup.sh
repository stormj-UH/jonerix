#!/usr/bin/env bash
# Shell startup + simple noop. Measures pure interpreter startup cost.
echo started
