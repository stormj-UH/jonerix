#!/usr/bin/env bash
# Tight arithmetic loop — pure interpreter overhead.
# Rust's compiled arithmetic vs bash's interpreted should favor brash.
n=0
for ((i = 0; i < 100000; i++)); do
    n=$((n + i * 2 - 1))
done
echo $n
