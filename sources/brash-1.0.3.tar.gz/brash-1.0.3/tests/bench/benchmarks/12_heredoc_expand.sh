#!/usr/bin/env bash
# Heredoc with variable expansion — tests heredoc body expansion overhead.
n=0
foo=hello
bar=world
baz=brash
for ((i = 0; i < 1000; i++)); do
    out=$(cat <<EOF
$foo $bar $baz $i
$foo$bar$baz
${#foo}${#bar}${#baz}
EOF
)
    n=$((n + ${#out}))
done
echo $n
