#!/usr/bin/env bash
# [[ str =~ regex ]] — Rust's regex crate is among the fastest regex engines.
hits=0
for ((i = 0; i < 5000; i++)); do
    s="abc${i}xyz_email_${i}@example.com"
    if [[ $s =~ ^[a-z0-9]+_email_[0-9]+@[a-z]+\.[a-z]+$ ]]; then
        hits=$((hits + 1))
    fi
done
echo "hits=$hits"
