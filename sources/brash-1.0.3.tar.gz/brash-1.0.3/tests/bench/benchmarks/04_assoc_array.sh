#!/usr/bin/env bash
# Associative array fills — HashMap insert performance.
declare -A m
for ((i = 0; i < 5000; i++)); do
    m[k_$i]=$((i * 3))
done

# Lookup — every Nth element
sum=0
for ((i = 0; i < 5000; i += 7)); do
    sum=$((sum + ${m[k_$i]}))
done
echo $sum
echo "${#m[@]}"
