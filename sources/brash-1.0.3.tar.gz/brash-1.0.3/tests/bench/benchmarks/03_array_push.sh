#!/usr/bin/env bash
# Array growth — Rust Vec::push is amortized O(1). Bash is also amortized O(1)
# but with higher per-op overhead.
arr=()
for ((i = 0; i < 10000; i++)); do
    arr+=("$i")
done
echo "${#arr[@]}"
echo "${arr[5000]}"
