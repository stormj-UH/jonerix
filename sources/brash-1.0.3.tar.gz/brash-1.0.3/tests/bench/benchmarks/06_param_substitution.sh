#!/usr/bin/env bash
# Parameter expansion ${var//pat/repl} — string scanning workload.
s="aaaaa_bbbbb_ccccc_ddddd_eeeee_fffff_ggggg_hhhhh_iiiii_jjjjj"
total=0
for ((i = 0; i < 2000; i++)); do
    out="${s//e/X}"
    total=$((total + ${#out}))
done
echo $total
