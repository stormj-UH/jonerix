#!/usr/bin/env bash
# Function call overhead.
add() { echo $(($1 + $2)); }

n=0
for ((i = 0; i < 5000; i++)); do
    n=$(($(add 1 $i) + 1))
done
echo $n
