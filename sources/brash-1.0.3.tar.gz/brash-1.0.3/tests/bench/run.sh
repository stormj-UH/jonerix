#!/usr/bin/env bash
# tests/bench/run.sh — head-to-head benchmark of brash vs bash.
#
# For each benchmark in tests/bench/benchmarks/, run it under both shells
# multiple times, take the median wall-clock time, and report the ratio.
#
# Usage:
#   tests/bench/run.sh           # run all benchmarks
#   tests/bench/run.sh foo bar   # run only foo, bar
#   ITER=10 tests/bench/run.sh   # 10 runs per benchmark (default 5)
#   WARM=1 tests/bench/run.sh    # 1 warmup run discarded (default 1)
#   BRASH_BIN=... BASH_BIN=...
#
# Output: per-benchmark "<name>  bash=Xms  brash=Yms  speedup=Zx [bash_wins|brash_wins]"

set -u

repo_root=$(cd "$(dirname "$0")/../.." && pwd)
bench_dir="$repo_root/tests/bench/benchmarks"

BRASH_BIN="${BRASH_BIN:-$repo_root/target/release/brash}"
BASH_BIN="${BASH_BIN:-/opt/homebrew/bin/bash}"
[ -x "$BASH_BIN" ] || BASH_BIN=/bin/bash
ITER="${ITER:-5}"
WARM="${WARM:-1}"

if [ ! -x "$BRASH_BIN" ]; then
    echo "ERROR: brash not found at $BRASH_BIN — run 'cargo build --release' first" >&2
    exit 2
fi
if [ ! -x "$BASH_BIN" ]; then
    echo "ERROR: bash not found at $BASH_BIN" >&2
    exit 2
fi

# pick benchmarks
if [ "$#" -gt 0 ]; then
    selected=()
    for arg in "$@"; do
        path="$bench_dir/$arg.sh"
        [ -f "$path" ] || path="$bench_dir/$arg"
        if [ -f "$path" ]; then
            selected+=("$path")
        else
            echo "WARN: no benchmark $arg" >&2
        fi
    done
else
    selected=()
    for f in "$bench_dir"/*.sh; do
        [ -f "$f" ] && selected+=("$f")
    done
fi

[ ${#selected[@]} -eq 0 ] && { echo "no benchmarks"; exit 0; }

# Use Python (always available) to compute median in float ms
median_ms() {
    python3 -c "
import sys, statistics
xs = [float(x) for x in sys.stdin.read().split() if x.strip()]
print(f'{statistics.median(xs):.2f}')
"
}

# Measure time of one shell+script invocation in milliseconds.
# Uses python's time.monotonic() for sub-ms precision (avoids `time` builtin
# which adds overhead and varies in format).
measure_one() {
    local sh=$1 script=$2
    python3 -c "
import subprocess, time, os, sys
sh, script = sys.argv[1], sys.argv[2]
env = {'HOME': os.environ.get('HOME',''), 'PATH': '/usr/bin:/bin:/usr/local/bin:/opt/homebrew/bin'}
t0 = time.monotonic()
subprocess.run([sh, script], env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False)
t1 = time.monotonic()
print(f'{(t1 - t0) * 1000:.3f}')
" "$sh" "$script"
}

bench_one() {
    local sh=$1 script=$2 iters=$3 warm=$4
    # Warmup
    for ((w = 0; w < warm; w++)); do
        measure_one "$sh" "$script" >/dev/null
    done
    # Measure
    local times=
    for ((i = 0; i < iters; i++)); do
        times="$times $(measure_one "$sh" "$script")"
    done
    echo "$times" | tr ' ' '\n' | median_ms
}

printf '%-30s  %10s  %10s  %10s  %s\n' name bash_ms brash_ms speedup verdict
printf '%-30s  %10s  %10s  %10s  %s\n' '---' '---' '---' '---' '---'

for script in "${selected[@]}"; do
    name=$(basename "$script" .sh)
    bash_ms=$(bench_one "$BASH_BIN"  "$script" "$ITER" "$WARM")
    brash_ms=$(bench_one "$BRASH_BIN" "$script" "$ITER" "$WARM")

    speedup=$(python3 -c "print(f'{$bash_ms / $brash_ms:.2f}')")
    if python3 -c "exit(0 if $speedup >= 1.0 else 1)" 2>/dev/null; then
        verdict="brash wins"
    else
        verdict="bash wins"
    fi
    printf '%-30s  %10s  %10s  %9sx  %s\n' "$name" "$bash_ms" "$brash_ms" "$speedup" "$verdict"
done
