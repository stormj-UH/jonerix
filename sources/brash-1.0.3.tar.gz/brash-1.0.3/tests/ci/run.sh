#!/usr/bin/env bash
# tests/ci/run.sh — Differential test runner for CI/CD shell pattern corpus.
#
# Runs each script under tests/ci/scripts/ under both bash and brash,
# comparing stdout, stderr, and exit code for byte-identical output.
#
# Usage:
#   tests/ci/run.sh                    # run all scripts
#   tests/ci/run.sh 01 06 11           # run by prefix or name (no .sh needed)
#   BRASH_BIN=/path/to/brash tests/ci/run.sh
#   BASH_BIN=/path/to/bash tests/ci/run.sh
#   VERBOSE=1 tests/ci/run.sh
#
# Output:
#   Per-script: PASS, FAIL <reason>, or HANG
#   Summary: "<passed>/<total> byte-identical"
#   Exit 0 if all pass, 1 if any fail/hang.

set -u

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
SCRIPTS_DIR="$SCRIPT_DIR/scripts"

BRASH_BIN="${BRASH_BIN:-$REPO_ROOT/target/release/brash}"
BASH_BIN="${BASH_BIN:-/opt/homebrew/bin/bash}"
[ -x "$BASH_BIN" ] || BASH_BIN=/bin/bash
TIMEOUT_SEC="${TIMEOUT_SEC:-30}"
VERBOSE="${VERBOSE:-}"

# --- Validate tools ---
if [ ! -x "$BRASH_BIN" ]; then
    echo "ERROR: brash not found at $BRASH_BIN — run 'cargo build --release' first" >&2
    exit 2
fi
if [ ! -x "$BASH_BIN" ]; then
    echo "ERROR: bash not found at $BASH_BIN" >&2
    exit 2
fi

# --- Locate timeout binary ---
if command -v timeout >/dev/null 2>&1; then
    TIMEOUT_CMD=timeout
elif command -v gtimeout >/dev/null 2>&1; then
    TIMEOUT_CMD=gtimeout
else
    TIMEOUT_CMD=
fi

run_with_timeout() {
    if [ -n "$TIMEOUT_CMD" ]; then
        "$TIMEOUT_CMD" "$TIMEOUT_SEC" "$@"
    else
        "$@"
    fi
}

# --- Select scripts ---
if [ "$#" -gt 0 ]; then
    selected=()
    for arg in "$@"; do
        # Allow "01", "01_output_passing", or "01_output_passing.sh"
        match=""
        for f in "$SCRIPTS_DIR"/*.sh; do
            base=$(basename "$f" .sh)
            case "$base" in
                "${arg}" | "${arg}_"* | *"${arg}"*) match="$f"; break ;;
            esac
        done
        if [ -n "$match" ]; then
            selected+=("$match")
        else
            echo "WARN: no script matches '$arg' under $SCRIPTS_DIR" >&2
        fi
    done
else
    selected=()
    for f in "$SCRIPTS_DIR"/*.sh; do
        [ -f "$f" ] && selected+=("$f")
    done
fi

[ ${#selected[@]} -eq 0 ] && { echo "no scripts to run"; exit 0; }

# --- Run loop ---
passed=0
failed=0
hung=0
total=${#selected[@]}

echo "bash:  $BASH_BIN"
echo "brash: $BRASH_BIN"
printf 'scripts: %d\n\n' "$total"

for script in "${selected[@]}"; do
    name=$(basename "$script" .sh)
    sandbox=$(mktemp -d)

    # Clean sandbox environment (mirrors realworld runner)
    BASE_ENV=(
        HOME="$HOME"
        PATH="/usr/bin:/bin:/usr/local/bin:/opt/homebrew/bin"
        TMPDIR="${TMPDIR:-/tmp}"
    )

    # Run bash baseline
    bash_out="$sandbox/bash.stdout"
    bash_err="$sandbox/bash.stderr"
    set +e
    (cd "$sandbox" && env -i "${BASE_ENV[@]}" \
        run_with_timeout "$BASH_BIN" "$script") \
        >"$bash_out" 2>"$bash_err"
    bash_rc=$?
    set -e

    # Run brash
    brash_out="$sandbox/brash.stdout"
    brash_err="$sandbox/brash.stderr"
    set +e
    (cd "$sandbox" && env -i "${BASE_ENV[@]}" \
        run_with_timeout "$BRASH_BIN" "$script") \
        >"$brash_out" 2>"$brash_err"
    brash_rc=$?
    set -e

    # Timeout check
    if [ "$brash_rc" -eq 124 ] || [ "$bash_rc" -eq 124 ]; then
        printf "HANG: %s (bash_rc=%d brash_rc=%d)\n" "$name" "$bash_rc" "$brash_rc"
        hung=$((hung + 1))
        rm -rf "$sandbox"
        continue
    fi

    # Diff
    stdout_diff="" stderr_diff="" rc_diff=""
    cmp -s "$bash_out"  "$brash_out"  || stdout_diff="stdout"
    cmp -s "$bash_err"  "$brash_err"  || stderr_diff="stderr"
    [ "$bash_rc" -eq "$brash_rc" ]    || rc_diff="rc"

    if [ -z "$stdout_diff" ] && [ -z "$stderr_diff" ] && [ -z "$rc_diff" ]; then
        printf "PASS: %s\n" "$name"
        passed=$((passed + 1))
        rm -rf "$sandbox"
        continue
    fi

    reasons=$(printf '%s %s %s' "$stdout_diff" "$stderr_diff" "$rc_diff" | tr -s ' ' | sed 's/^ //; s/ $//')
    printf "FAIL: %s [%s]\n" "$name" "$reasons"
    failed=$((failed + 1))

    if [ -n "$VERBOSE" ]; then
        if [ -n "$stdout_diff" ]; then
            echo "  --- stdout diff (bash vs brash) ---"
            diff -u "$bash_out" "$brash_out" | sed 's/^/  /' | head -40
        fi
        if [ -n "$stderr_diff" ]; then
            echo "  --- stderr diff ---"
            diff -u "$bash_err" "$brash_err" | sed 's/^/  /' | head -20
        fi
        if [ -n "$rc_diff" ]; then
            printf '  --- rc: bash=%d brash=%d ---\n' "$bash_rc" "$brash_rc"
        fi
    fi

    rm -rf "$sandbox"
done

echo ""
printf "=== %d passed, %d failed, %d hung, %d total — %d%% byte-identical ===\n" \
    "$passed" "$failed" "$hung" "$total" $(( passed * 100 / total ))

if [ "$failed" -ne 0 ] || [ "$hung" -ne 0 ]; then
    exit 1
fi
exit 0
