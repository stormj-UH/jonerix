#!/usr/bin/env bash
# 05_version_selection.sh — Setup-node / setup-python style version selection.
# Picks a toolchain version from a list, validates it, sets a fake PATH entry.

set -euo pipefail

REQUESTED_VERSION="${REQUESTED_VERSION:-3.11}"
TOOL="${TOOL:-python}"

# Available versions (would normally come from manifest.json in setup-node)
AVAILABLE_VERSIONS="3.8 3.9 3.10 3.11 3.12 3.13"

# Resolve semver-style "3" -> latest 3.x, "3.11" -> exact
resolve_version() {
    local requested="$1"
    local best=""
    for v in $AVAILABLE_VERSIONS; do
        case "$v" in
            "${requested}."*|"$requested")
                # Take last match (highest patch)
                best="$v"
                ;;
        esac
    done
    echo "$best"
}

resolved=$(resolve_version "$REQUESTED_VERSION")
if [ -z "$resolved" ]; then
    printf 'ERROR: version %s not found in available: %s\n' "$REQUESTED_VERSION" "$AVAILABLE_VERSIONS" >&2
    exit 1
fi

printf 'Resolved %s@%s -> %s\n' "$TOOL" "$REQUESTED_VERSION" "$resolved"

# Simulate tool install path
TOOL_PATH="/opt/hostedtoolcache/${TOOL}/${resolved}/x64/bin"
printf 'Tool path: %s\n' "$TOOL_PATH"

# Emit to GITHUB_PATH (simulated)
GITHUB_PATH_FILE=$(mktemp)
trap 'rm -f "$GITHUB_PATH_FILE"' EXIT
echo "$TOOL_PATH" >> "$GITHUB_PATH_FILE"
printf 'Added to PATH: %s\n' "$(cat "$GITHUB_PATH_FILE")"

# Validate binary name
case "$TOOL" in
    python)  bin_name="python${resolved%.*}" ;;   # python3.11 -> python3
    node)    bin_name="node" ;;
    go)      bin_name="go" ;;
    *)       bin_name="$TOOL" ;;
esac
printf 'Binary: %s/%s\n' "$TOOL_PATH" "$bin_name"

# Version pinning output
echo "version-pinned=${resolved}"

echo "version-selection: done"
