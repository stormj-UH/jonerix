#!/usr/bin/env bash
# 02_env_from_secrets.sh — Simulate reading CI "secrets" from a file and
# exporting them as environment variables (GitHub Actions secrets pattern).

set -euo pipefail

SECRETS_FILE=$(mktemp)
trap 'rm -f "$SECRETS_FILE"' EXIT

# Write deterministic "secrets" to the temp file
cat > "$SECRETS_FILE" <<'SECRETS'
API_KEY=supersecret-key-abc123
REGISTRY_USER=ci-robot
REGISTRY_PASS=hunter2
DEPLOY_TOKEN=tok-xyz789
SECRETS

# Read secrets and export as env vars (mask values in log output)
while IFS='=' read -r key value; do
    [ -z "$key" ] && continue
    printf 'Setting secret: %s=***\n' "$key"
    export "$key=$value"
done < "$SECRETS_FILE"

# Confirm vars are set (without printing values)
for var in API_KEY REGISTRY_USER REGISTRY_PASS DEPLOY_TOKEN; do
    val="${!var:-}"
    if [ -n "$val" ]; then
        printf 'verified: %s is set (length=%d)\n' "$var" "${#val}"
    fi
done

# Show registry login simulation (value hidden)
printf 'docker login -u %s -p ***\n' "$REGISTRY_USER"

echo "env-from-secrets: done"
