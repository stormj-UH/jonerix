#!/usr/bin/env bash
# 10_json_output.sh — Building JSON payloads via printf (no jq required).
# Models CI steps that emit structured data for downstream consumers.

set -euo pipefail

# Helper: JSON-escape a string (handle quotes and backslashes)
json_str() {
    local s="$1"
    s="${s//\\/\\\\}"
    s="${s//\"/\\\"}"
    printf '%s' "$s"
}

# Build a simple JSON object
build_status_json() {
    local status="$1" sha="$2" ref="$3" duration="$4"
    printf '{\n'
    printf '  "status": "%s",\n'   "$(json_str "$status")"
    printf '  "sha": "%s",\n'      "$(json_str "$sha")"
    printf '  "ref": "%s",\n'      "$(json_str "$ref")"
    printf '  "duration_sec": %s\n' "$duration"
    printf '}\n'
}

# Build a JSON array of test results
build_results_json() {
    printf '[\n'
    local first=1
    while IFS='|' read -r name status dur; do
        [ "$first" = "1" ] && first=0 || printf ',\n'
        printf '  {"name": "%s", "status": "%s", "duration": %s}' \
            "$(json_str "$name")" "$(json_str "$status")" "$dur"
    done
    printf '\n]\n'
}

echo "=== Build Status ==="
build_status_json "success" "abc123def456" "refs/heads/main" "42"

echo "=== Test Results ==="
printf '%s\n' \
    'test_auth|pass|0.12' \
    'test_db|pass|0.34' \
    'test_cache|pass|0.08' \
    'test_api|pass|0.55' \
    | build_results_json

# Nested JSON: matrix results
echo "=== Matrix Results ==="
printf '{\n'
printf '  "matrix": [\n'
first=1
for os in ubuntu macos windows; do
    for ver in "3.11" "3.12"; do
        [ "$first" = "1" ] && first=0 || printf ',\n'
        printf '    {"os": "%s", "version": "%s", "result": "pass"}' "$os" "$ver"
    done
done
printf '\n  ]\n'
printf '}\n'

echo "json-output: done"
