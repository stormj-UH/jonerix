#!/usr/bin/env bash
# 18_build_system_shell.sh — Build-system shell patterns.
# Covers compiler flag assembly, dependency resolution, multi-stage builds.

set -euo pipefail

SANDBOX=$(mktemp -d)
trap 'rm -rf "$SANDBOX"' EXIT

# Compiler flag assembly (common in Makefile-replacing CI scripts)
TARGET_OS="${TARGET_OS:-linux}"
TARGET_ARCH="${TARGET_ARCH:-amd64}"
BUILD_MODE="${BUILD_MODE:-release}"
ENABLE_CGO="${ENABLE_CGO:-0}"

echo "=== Compiler Configuration ==="
printf 'target: %s/%s\n' "$TARGET_OS" "$TARGET_ARCH"
printf 'mode:   %s\n' "$BUILD_MODE"

# Assemble flags
CFLAGS=""
LDFLAGS=""

case "$BUILD_MODE" in
    release)
        CFLAGS="-O2 -DNDEBUG"
        LDFLAGS="-s -w"
        ;;
    debug)
        CFLAGS="-g -O0 -DDEBUG"
        LDFLAGS=""
        ;;
    profile)
        CFLAGS="-O1 -pg"
        LDFLAGS="-pg"
        ;;
esac

# Arch-specific flags
case "$TARGET_ARCH" in
    amd64)  CFLAGS="$CFLAGS -march=x86-64" ;;
    arm64)  CFLAGS="$CFLAGS -march=armv8-a" ;;
    arm)    CFLAGS="$CFLAGS -march=armv7-a -mfpu=neon" ;;
esac

printf 'CFLAGS: %s\n'  "$CFLAGS"
printf 'LDFLAGS: %s\n' "$LDFLAGS"

echo ""
echo "=== Dependency Resolution ==="
# Simulate resolving transitive dependencies
declare -A DEPS
DEPS["myapp"]="libfoo libbar"
DEPS["libfoo"]="libz libssl"
DEPS["libbar"]="libz"
DEPS["libz"]=""
DEPS["libssl"]="libz"

resolve_deps() {
    local pkg="$1"
    local visited="$2"
    if echo " $visited " | grep -q " $pkg "; then
        return
    fi
    visited="$visited $pkg"
    local deps="${DEPS[$pkg]:-}"
    for dep in $deps; do
        resolve_deps "$dep" "$visited"
    done
    echo "$pkg"
}

echo "Resolved build order for myapp:"
resolve_deps "myapp" "" | awk '!seen[$0]++'

echo ""
echo "=== Multi-Stage Build Simulation ==="
stages=("deps" "build" "test" "package" "publish")
for i in "${!stages[@]}"; do
    stage="${stages[$i]}"
    stage_num=$((i + 1))
    printf 'Stage %d/%d: %s\n' "$stage_num" "${#stages[@]}" "$stage"
    # Each stage creates an output file
    echo "output-of-${stage}" > "$SANDBOX/stage-${stage}.out"
    size=$(wc -c < "$SANDBOX/stage-${stage}.out" | tr -d ' ')
    printf '  -> output: %db\n' "$size"
done

echo ""
echo "=== Version Bumping ==="
CURRENT_VERSION="2.1.3"
BUMP_TYPE="${BUMP_TYPE:-patch}"

IFS='.' read -r major minor patch <<< "$CURRENT_VERSION"
case "$BUMP_TYPE" in
    major) major=$((major + 1)); minor=0; patch=0 ;;
    minor) minor=$((minor + 1)); patch=0 ;;
    patch) patch=$((patch + 1)) ;;
esac
NEW_VERSION="${major}.${minor}.${patch}"
printf 'version: %s -> %s (%s bump)\n' "$CURRENT_VERSION" "$NEW_VERSION" "$BUMP_TYPE"

echo "build-system: done"
