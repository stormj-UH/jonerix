#!/usr/bin/env bash
# 14_changed_files.sh — Parse a simulated "git diff --name-only" output.
# Categorises changed files and triggers appropriate CI steps.

set -euo pipefail

# Simulate git diff --name-only output (deterministic fixture)
DIFF_OUTPUT=$(cat <<'DIFF'
src/auth/login.go
src/auth/token.go
src/db/migrations/0042_add_user_prefs.sql
frontend/src/components/LoginForm.tsx
frontend/src/components/LoginForm.test.tsx
frontend/package.json
docs/api/auth.md
.github/workflows/ci.yml
Makefile
DIFF
)

echo "=== Changed files ==="
echo "$DIFF_OUTPUT"
echo ""

# Categorise files
has_go=0
has_sql=0
has_frontend=0
has_docs=0
has_ci=0
has_build=0

go_files=()
sql_files=()
frontend_files=()

while IFS= read -r f; do
    [ -z "$f" ] && continue
    case "$f" in
        *.go)              has_go=1;       go_files+=("$f") ;;
        *.sql)             has_sql=1;      sql_files+=("$f") ;;
        frontend/*)        has_frontend=1; frontend_files+=("$f") ;;
        docs/*)            has_docs=1 ;;
        .github/workflows/*) has_ci=1 ;;
        Makefile|*.mk)     has_build=1 ;;
    esac
done <<< "$DIFF_OUTPUT"

echo "=== Change analysis ==="
printf 'go-changes:       %s (%d files)\n' "$([ $has_go = 1 ] && echo yes || echo no)" "${#go_files[@]}"
printf 'sql-migrations:   %s (%d files)\n' "$([ $has_sql = 1 ] && echo yes || echo no)" "${#sql_files[@]}"
printf 'frontend-changes: %s (%d files)\n' "$([ $has_frontend = 1 ] && echo yes || echo no)" "${#frontend_files[@]}"
printf 'doc-changes:      %s\n'  "$([ $has_docs = 1 ] && echo yes || echo no)"
printf 'ci-config-change: %s\n'  "$([ $has_ci = 1 ] && echo yes || echo no)"
printf 'build-change:     %s\n'  "$([ $has_build = 1 ] && echo yes || echo no)"

echo ""
echo "=== Required CI steps ==="
[ $has_go = 1 ]       && echo "  - go test ./..."
[ $has_sql = 1 ]      && echo "  - run database migrations"
[ $has_frontend = 1 ] && echo "  - npm test"
[ $has_docs = 1 ]     && echo "  - build documentation"
[ $has_ci = 1 ]       && echo "  - validate workflow syntax"
[ $has_build = 1 ]    && echo "  - rebuild make targets"

echo ""
echo "=== SQL migration files ==="
for f in "${sql_files[@]}"; do
    printf '  migrate: %s\n' "$f"
done

echo "changed-files: done"
