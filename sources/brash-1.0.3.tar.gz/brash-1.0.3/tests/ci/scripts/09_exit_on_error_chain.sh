#!/usr/bin/env bash
# 09_exit_on_error_chain.sh — set -euo pipefail patterns with error trapping.
# Models typical CI build steps that must all succeed.

set -euo pipefail

SANDBOX=$(mktemp -d)
trap 'rm -rf "$SANDBOX"; echo "cleanup: done"' EXIT

log() { printf '[%s] %s\n' "$1" "$2"; }

# Simulate a chain of build steps
step_checkout() {
    log "checkout" "Cloning repository"
    mkdir -p "$SANDBOX/src"
    echo "main.go" > "$SANDBOX/src/main.go"
    echo "go.mod"  > "$SANDBOX/src/go.mod"
    log "checkout" "Done (2 files)"
}

step_lint() {
    log "lint" "Running linter"
    local src_count
    src_count=$(find "$SANDBOX/src" -type f | wc -l | tr -d ' ')
    log "lint" "Checked $src_count files — no issues"
}

step_build() {
    log "build" "Compiling"
    # Simulate output binary
    echo "binary" > "$SANDBOX/app"
    chmod +x "$SANDBOX/app"
    local size
    size=$(wc -c < "$SANDBOX/app" | tr -d ' ')
    log "build" "Binary: $SANDBOX/app (${size}b)"
}

step_test() {
    log "test" "Running tests"
    local pass=4 fail=0
    log "test" "Results: $pass passed, $fail failed"
    [ "$fail" -eq 0 ]
}

step_package() {
    log "package" "Creating release archive"
    echo "manifest" > "$SANDBOX/manifest.txt"
    log "package" "Created release.tar.gz (simulated)"
}

# Run chain — set -e will abort on any non-zero exit
step_checkout
step_lint
step_build
step_test
step_package

echo "exit-on-error-chain: all steps passed"

# Demonstrate pipefail: count lines through a pipe chain
result=$(printf 'a\nb\nc\nd\ne\n' | grep -c .)
printf 'pipe-chain result: %d\n' "$result"

# Demonstrate -u: unset variable detection is active
DEFINED_VAR="hello"
printf 'defined-var: %s\n' "$DEFINED_VAR"
