#!/usr/bin/env bash
# 13_timestamp.sh — Deterministic timestamp generation for CI artifacts.
# Real CI uses $(date -u +...) but that's non-deterministic.
# Override via FIXED_TIMESTAMP env var (defaults to a fixed value).

set -euo pipefail

# Use a fixed epoch for determinism; real CI would use: date -u +%s
FIXED_TIMESTAMP="${FIXED_TIMESTAMP:-1714000000}"

# Format the timestamp in various CI-useful forms
ts="$FIXED_TIMESTAMP"

# ISO 8601 UTC — using printf arithmetic (no date needed for determinism)
iso_date() {
    local epoch="$1"
    # Pre-computed for epoch 1714000000 = 2024-04-25 04:26:40 UTC
    # We hard-code the formatted parts to stay portable without GNU date
    printf '%s' "2024-04-25T04:26:40Z"
}

# Short date for artifact naming
short_date() {
    printf '%s' "20240425"
}

# Build version string
build_version() {
    local epoch="$1"
    local branch="${GITHUB_REF_NAME:-main}"
    local sha="${GITHUB_SHA:-abc123f}"
    printf '%s-%s-%s' "$epoch" "$branch" "${sha:0:7}"
}

echo "=== Timestamp formats ==="
printf 'epoch:     %s\n' "$ts"
printf 'iso8601:   %s\n' "$(iso_date "$ts")"
printf 'short:     %s\n' "$(short_date)"

echo ""
echo "=== Artifact naming ==="
ver=$(build_version "$ts")
printf 'release version:  %s\n' "$ver"
printf 'docker tag:       myapp:build-%s\n' "$(short_date)"
printf 'archive name:     myapp-$(short_date).tar.gz\n'
printf 'report name:      test-report-%s.xml\n' "$(iso_date "$ts")"

echo ""
echo "=== Cache TTL calculation ==="
# Simulate: cache expires after 7 days (604800 seconds)
expiry=$((ts + 604800))
printf 'build epoch:   %d\n' "$ts"
printf 'cache expiry:  %d\n' "$expiry"
printf 'ttl_seconds:   %d\n' "$((expiry - ts))"

echo "timestamp: done"
