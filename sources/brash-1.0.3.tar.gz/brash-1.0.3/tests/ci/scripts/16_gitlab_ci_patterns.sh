#!/usr/bin/env bash
# 16_gitlab_ci_patterns.sh — GitLab CI shell patterns.
# Uses GitLab-specific env vars (CI_*, GL_*) with deterministic overrides.

set -euo pipefail

# GitLab CI environment (deterministic overrides)
CI="${CI:-true}"
CI_PROJECT_PATH="${CI_PROJECT_PATH:-mygroup/myapp}"
CI_PROJECT_NAME="${CI_PROJECT_NAME:-myapp}"
CI_COMMIT_REF_NAME="${CI_COMMIT_REF_NAME:-main}"
CI_COMMIT_SHORT_SHA="${CI_COMMIT_SHORT_SHA:-abc1234}"
CI_COMMIT_SHA="${CI_COMMIT_SHA:-abc1234def5678901234567890abcdef12345678}"
CI_PIPELINE_ID="${CI_PIPELINE_ID:-12345}"
CI_JOB_ID="${CI_JOB_ID:-67890}"
CI_JOB_STAGE="${CI_JOB_STAGE:-test}"
CI_ENVIRONMENT_NAME="${CI_ENVIRONMENT_NAME:-staging}"
CI_REGISTRY="${CI_REGISTRY:-registry.gitlab.com}"
CI_REGISTRY_IMAGE="${CI_REGISTRY_IMAGE:-registry.gitlab.com/mygroup/myapp}"
GITLAB_USER_LOGIN="${GITLAB_USER_LOGIN:-jsmith}"

echo "=== GitLab CI Job Info ==="
printf 'project:     %s\n' "$CI_PROJECT_PATH"
printf 'branch:      %s\n' "$CI_COMMIT_REF_NAME"
printf 'sha:         %s\n' "$CI_COMMIT_SHORT_SHA"
printf 'pipeline:    %d\n' "$CI_PIPELINE_ID"
printf 'job:         %d (stage: %s)\n' "$CI_JOB_ID" "$CI_JOB_STAGE"
printf 'triggered-by: %s\n' "$GITLAB_USER_LOGIN"

echo ""
echo "=== Container Registry Pattern ==="
IMAGE_TAG="${CI_REGISTRY_IMAGE}:${CI_COMMIT_SHORT_SHA}"
IMAGE_LATEST="${CI_REGISTRY_IMAGE}:latest"
printf 'build tag:  %s\n' "$IMAGE_TAG"
printf 'latest tag: %s\n' "$IMAGE_LATEST"

# Simulate docker login (using CI registry)
printf 'docker login -u %s -p $CI_REGISTRY_PASSWORD %s\n' \
    "$GITLAB_USER_LOGIN" "$CI_REGISTRY"

echo ""
echo "=== Branch Protection Rules ==="
# GitLab pattern: only deploy from protected branches
is_protected=0
case "$CI_COMMIT_REF_NAME" in
    main|master|release/*) is_protected=1 ;;
esac

if [ "$is_protected" = "1" ]; then
    printf 'deploy: allowed (protected branch: %s)\n' "$CI_COMMIT_REF_NAME"
else
    printf 'deploy: skipped (unprotected branch: %s)\n' "$CI_COMMIT_REF_NAME"
fi

echo ""
echo "=== Artifacts Pattern ==="
# GitLab artifacts with expiry
ARTIFACTS_DIR="artifacts"
printf 'artifacts:\n'
printf '  paths:\n'
printf '    - %s/\n' "$ARTIFACTS_DIR"
printf '  expire_in: 1 week\n'
printf '  reports:\n'
printf '    junit: %s/junit.xml\n' "$ARTIFACTS_DIR"
printf '    coverage_report:\n'
printf '      coverage_format: cobertura\n'
printf '      path: %s/coverage.xml\n' "$ARTIFACTS_DIR"

echo ""
echo "=== Environment URL ==="
# Dynamic environment URL pattern
ENV_URL="https://${CI_COMMIT_SHORT_SHA}.${CI_PROJECT_NAME}.staging.example.com"
printf 'environment: %s\n' "$CI_ENVIRONMENT_NAME"
printf 'url: %s\n' "$ENV_URL"

echo "gitlab-ci-patterns: done"
