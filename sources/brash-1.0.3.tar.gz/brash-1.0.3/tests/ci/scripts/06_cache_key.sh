#!/usr/bin/env bash
# 06_cache_key.sh — Cache key generation from file contents.
# Uses wc -c (byte count) for a deterministic, portable "hash".

set -euo pipefail

SANDBOX=$(mktemp -d)
trap 'rm -rf "$SANDBOX"' EXIT

# Create deterministic "lock files" (fixed content = reproducible wc -c)
cat > "$SANDBOX/package-lock.json" <<'EOF'
{"name":"myapp","version":"1.0.0","lockfileVersion":2,"requires":true,"packages":{"":{"name":"myapp","version":"1.0.0"}}}
EOF

cat > "$SANDBOX/requirements.txt" <<'EOF'
requests==2.31.0
flask==3.0.0
gunicorn==21.2.0
EOF

cat > "$SANDBOX/go.sum" <<'EOF'
github.com/pkg/errors v0.9.1 h1:FEBLx1zS214owpjy7qsBeixbURkuhQAwrK5UwLGTwt38=
github.com/pkg/errors v0.9.1/go.mod h1:bwawxfHBFNV+L2hUp1rHADufV3IMtnDRdf1r5NINEl0=
EOF

# Generate cache key from byte counts (deterministic substitute for sha256)
generate_cache_key() {
    local prefix="$1"
    shift
    local key_parts="$prefix"
    for f in "$@"; do
        local size
        size=$(wc -c < "$f" | tr -d ' ')
        key_parts="${key_parts}-${size}"
    done
    echo "$key_parts"
}

# Node cache key
node_key=$(generate_cache_key "node-v3" "$SANDBOX/package-lock.json")
printf 'cache-key[node]: %s\n' "$node_key"

# Python cache key
py_key=$(generate_cache_key "pip-v1" "$SANDBOX/requirements.txt")
printf 'cache-key[pip]: %s\n' "$py_key"

# Go cache key
go_key=$(generate_cache_key "go-v2" "$SANDBOX/go.sum")
printf 'cache-key[go]: %s\n' "$go_key"

# Multi-file composite key (combine byte counts of all lockfiles)
composite_key=$(generate_cache_key "composite" \
    "$SANDBOX/package-lock.json" \
    "$SANDBOX/requirements.txt" \
    "$SANDBOX/go.sum")
printf 'cache-key[composite]: %s\n' "$composite_key"

# Cache hit simulation
CACHE_HIT="${CACHE_HIT:-false}"
if [ "$CACHE_HIT" = "true" ]; then
    echo "cache: hit — restoring from cache"
else
    echo "cache: miss — will save after build"
fi

echo "cache-key: done"
