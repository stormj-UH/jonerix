#!/usr/bin/env bash
# 08_multiline_output.sh — Multi-line output passing via $GITHUB_OUTPUT.
# Uses the heredoc delimiter style: key<<EOF / content / EOF

set -euo pipefail

GITHUB_OUTPUT=$(mktemp)
REPORT_FILE=$(mktemp)
trap 'rm -f "$GITHUB_OUTPUT" "$REPORT_FILE"' EXIT

# Create a deterministic multi-line report
cat > "$REPORT_FILE" <<'REPORT'
Test Suite: unit
  PASS: test_auth (0.12s)
  PASS: test_db   (0.34s)
  FAIL: test_net  (1.00s) — connection refused
  PASS: test_ui   (0.08s)
Summary: 3 passed, 1 failed
REPORT

# Write multi-line value to GITHUB_OUTPUT using heredoc delimiter style
{
    echo "report<<GHADELIM"
    cat "$REPORT_FILE"
    echo "GHADELIM"
} >> "$GITHUB_OUTPUT"

# Also write a simple value after the multiline block
echo "status=failed" >> "$GITHUB_OUTPUT"
echo "failed_count=1" >> "$GITHUB_OUTPUT"

# Parse and display the output file
echo "=== GITHUB_OUTPUT contents ==="
cat "$GITHUB_OUTPUT"
echo "=== end ==="

# Simulate downstream step reading the multiline value
echo "=== Parsed outputs ==="
in_multiline=0
current_key=""
current_value=""
while IFS= read -r line; do
    if [ "$in_multiline" = "1" ]; then
        if [ "$line" = "GHADELIM" ]; then
            printf 'output[%s]: (%d lines)\n' "$current_key" \
                "$(echo "$current_value" | wc -l | tr -d ' ')"
            in_multiline=0
        else
            current_value="${current_value}${line}"$'\n'
        fi
    elif [[ "$line" == *"<<GHADELIM" ]]; then
        current_key="${line%<<GHADELIM}"
        current_value=""
        in_multiline=1
    elif [[ "$line" == *=* ]]; then
        key="${line%%=*}"
        val="${line#*=}"
        printf 'output[%s] = %s\n' "$key" "$val"
    fi
done < "$GITHUB_OUTPUT"

echo "multiline-output: done"
