#!/usr/bin/env bash
# 17_circleci_patterns.sh — CircleCI runner shell patterns.
# Uses CIRCLE_* env vars with deterministic overrides.

set -euo pipefail

# CircleCI environment (deterministic overrides)
CIRCLE_PROJECT_REPONAME="${CIRCLE_PROJECT_REPONAME:-myapp}"
CIRCLE_PROJECT_USERNAME="${CIRCLE_PROJECT_USERNAME:-myorg}"
CIRCLE_BRANCH="${CIRCLE_BRANCH:-main}"
CIRCLE_SHA1="${CIRCLE_SHA1:-abc123def456789012345678901234567890abcd}"
CIRCLE_BUILD_NUM="${CIRCLE_BUILD_NUM:-1234}"
CIRCLE_BUILD_URL="${CIRCLE_BUILD_URL:-https://circleci.com/gh/myorg/myapp/1234}"
CIRCLE_JOB="${CIRCLE_JOB:-test}"
CIRCLE_NODE_INDEX="${CIRCLE_NODE_INDEX:-0}"
CIRCLE_NODE_TOTAL="${CIRCLE_NODE_TOTAL:-4}"
CIRCLE_WORKFLOW_ID="${CIRCLE_WORKFLOW_ID:-wf-abc123}"

echo "=== CircleCI Job Info ==="
printf 'project:    %s/%s\n' "$CIRCLE_PROJECT_USERNAME" "$CIRCLE_PROJECT_REPONAME"
printf 'branch:     %s\n' "$CIRCLE_BRANCH"
printf 'sha:        %.8s\n' "$CIRCLE_SHA1"
printf 'build:      #%s\n' "$CIRCLE_BUILD_NUM"
printf 'job:        %s\n' "$CIRCLE_JOB"
printf 'workflow:   %s\n' "$CIRCLE_WORKFLOW_ID"

echo ""
echo "=== Parallelism / Test Splitting ==="
printf 'node: %d of %d\n' "$CIRCLE_NODE_INDEX" "$CIRCLE_NODE_TOTAL"

# Simulate test file splitting across nodes
ALL_TESTS=(
    "test_auth.py"
    "test_db.py"
    "test_api.py"
    "test_cache.py"
    "test_worker.py"
    "test_scheduler.py"
    "test_events.py"
    "test_reports.py"
)
total_tests=${#ALL_TESTS[@]}
# Assign tests to this node deterministically (round-robin)
echo "Tests assigned to node $CIRCLE_NODE_INDEX:"
for i in "${!ALL_TESTS[@]}"; do
    if [ $(( i % CIRCLE_NODE_TOTAL )) -eq "$CIRCLE_NODE_INDEX" ]; then
        printf '  %s\n' "${ALL_TESTS[$i]}"
    fi
done

echo ""
echo "=== Workspace Persistence ==="
# CircleCI workspace attach/persist pattern
WORKSPACE_DIR="${CIRCLE_WORKING_DIRECTORY:-/tmp/circle-workspace}"
printf 'workspace: %s\n' "$WORKSPACE_DIR"
printf 'persist: ./dist\n'
printf 'attach at: /workspace\n'

echo ""
echo "=== SSH Key Fingerprint ==="
# CircleCI SSH key addition pattern
FINGERPRINT="aa:bb:cc:dd:ee:ff:00:11:22:33:44:55:66:77:88:99"
printf 'add-ssh-key fingerprint: %s\n' "$FINGERPRINT"

echo ""
echo "=== Orb Invocation Pattern ==="
# Simulate an orb command output
printf 'orb: circleci/node@5.1.0\n'
printf '  command: install-packages\n'
printf '  with:\n'
printf '    pkg-manager: npm\n'
printf '    cache-version: v2\n'

echo "circleci-patterns: done"
