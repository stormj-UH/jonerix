#!/usr/bin/env bash
# 15_slack_notification.sh — Build a Slack-style notification payload.
# Assembles a Block Kit message JSON from CI environment variables.

set -euo pipefail

# Deterministic CI env (would be real in GH Actions)
GITHUB_WORKFLOW="${GITHUB_WORKFLOW:-CI Pipeline}"
GITHUB_RUN_ID="${GITHUB_RUN_ID:-9876543210}"
GITHUB_REPOSITORY="${GITHUB_REPOSITORY:-myorg/myapp}"
GITHUB_REF_NAME="${GITHUB_REF_NAME:-main}"
GITHUB_SHA="${GITHUB_SHA:-abc123def456789}"
GITHUB_ACTOR="${GITHUB_ACTOR:-jsmith}"
JOB_STATUS="${JOB_STATUS:-success}"

# Select emoji and color based on status
case "$JOB_STATUS" in
    success) status_emoji=":white_check_mark:" color="#28a745" ;;
    failure) status_emoji=":x:"               color="#dc3545" ;;
    cancelled) status_emoji=":warning:"       color="#ffc107" ;;
    *)       status_emoji=":question:"        color="#6c757d" ;;
esac

short_sha="${GITHUB_SHA:0:7}"
run_url="https://github.com/${GITHUB_REPOSITORY}/actions/runs/${GITHUB_RUN_ID}"

# Build Slack Block Kit payload via printf
build_slack_payload() {
    printf '{\n'
    printf '  "attachments": [\n'
    printf '    {\n'
    printf '      "color": "%s",\n' "$color"
    printf '      "blocks": [\n'
    printf '        {\n'
    printf '          "type": "section",\n'
    printf '          "text": {\n'
    printf '            "type": "mrkdwn",\n'
    printf '            "text": "%s *%s* — %s"\n' \
        "$status_emoji" "$GITHUB_WORKFLOW" "$JOB_STATUS"
    printf '          }\n'
    printf '        },\n'
    printf '        {\n'
    printf '          "type": "section",\n'
    printf '          "fields": [\n'
    printf '            {"type": "mrkdwn", "text": "*Repo:*\\n<%s|%s>"},\n' \
        "https://github.com/${GITHUB_REPOSITORY}" "$GITHUB_REPOSITORY"
    printf '            {"type": "mrkdwn", "text": "*Branch:*\\n`%s`"},\n' "$GITHUB_REF_NAME"
    printf '            {"type": "mrkdwn", "text": "*Commit:*\\n`%s`"},\n' "$short_sha"
    printf '            {"type": "mrkdwn", "text": "*Author:*\\n%s"}\n'    "$GITHUB_ACTOR"
    printf '          ]\n'
    printf '        },\n'
    printf '        {\n'
    printf '          "type": "actions",\n'
    printf '          "elements": [\n'
    printf '            {\n'
    printf '              "type": "button",\n'
    printf '              "text": {"type": "plain_text", "text": "View Run"},\n'
    printf '              "url": "%s"\n' "$run_url"
    printf '            }\n'
    printf '          ]\n'
    printf '        }\n'
    printf '      ]\n'
    printf '    }\n'
    printf '  ]\n'
    printf '}\n'
}

echo "=== Slack Notification Payload ==="
build_slack_payload

echo "slack-notification: done"
