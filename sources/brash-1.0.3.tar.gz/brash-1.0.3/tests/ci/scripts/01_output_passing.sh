#!/usr/bin/env bash
# 01_output_passing.sh — GitHub Actions $GITHUB_OUTPUT style output passing.
# Uses a temp file as the "output" channel.  Deterministic; no real GH env needed.

set -euo pipefail

GITHUB_OUTPUT=$(mktemp)
trap 'rm -f "$GITHUB_OUTPUT"' EXIT

# Single-value output
echo "result=success" >> "$GITHUB_OUTPUT"
echo "build_id=42" >> "$GITHUB_OUTPUT"
echo "sha=abc123def456" >> "$GITHUB_OUTPUT"

# Read back and display (simulates downstream step consuming outputs)
while IFS='=' read -r key value; do
    printf 'output[%s] = %s\n' "$key" "$value"
done < "$GITHUB_OUTPUT"

# Demonstrate conditional output
status=passed
if [ "$status" = "passed" ]; then
    echo "gate=open" >> "$GITHUB_OUTPUT"
else
    echo "gate=closed" >> "$GITHUB_OUTPUT"
fi

# Print only the gate line
grep '^gate=' "$GITHUB_OUTPUT" | while IFS='=' read -r k v; do
    printf 'gate output: %s\n' "$v"
done

echo "output-passing: done"
