#!/usr/bin/env bash
# 03_matrix_expansion.sh — Simulate GitHub Actions matrix strategy.
# Iterates over os x version combinations, dispatching with case.

set -euo pipefail

# Simulated matrix values (in real GH Actions these come from the matrix context)
MATRIX_OS_LIST="ubuntu-latest macos-latest windows-latest"
MATRIX_VERSION_LIST="3.9 3.11 3.12"

run_matrix_cell() {
    local os="$1" version="$2"

    # OS-specific setup (case dispatch on os)
    local install_cmd pkg_mgr
    case "$os" in
        ubuntu-latest)
            pkg_mgr="apt"
            install_cmd="apt-get install -y python${version}"
            ;;
        macos-latest)
            pkg_mgr="brew"
            install_cmd="brew install python@${version}"
            ;;
        windows-latest)
            pkg_mgr="choco"
            install_cmd="choco install python --version=${version}"
            ;;
        *)
            echo "ERROR: unknown OS $os"
            return 1
            ;;
    esac

    # Version-specific flags
    local extra_flags=""
    case "$version" in
        3.9)  extra_flags="--legacy-resolver" ;;
        3.11) extra_flags="--no-warn-script-location" ;;
        3.12) extra_flags="--break-system-packages" ;;
    esac

    printf '[matrix] os=%s version=%s pkg=%s flags=%s\n' \
        "$os" "$version" "$pkg_mgr" "${extra_flags:-(none)}"
    printf '  would run: %s\n' "$install_cmd"
}

# Expand the matrix
for os in $MATRIX_OS_LIST; do
    for version in $MATRIX_VERSION_LIST; do
        run_matrix_cell "$os" "$version"
    done
done

echo "matrix-expansion: done (9 cells)"
