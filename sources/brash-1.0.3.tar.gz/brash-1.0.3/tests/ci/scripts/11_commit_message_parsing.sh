#!/usr/bin/env bash
# 11_commit_message_parsing.sh — Parse CI tags from commit messages.
# Detects [skip ci], fixes #NNN, closes #NNN, breaking change markers.

set -euo pipefail

parse_commit() {
    local msg="$1"
    printf 'commit: %s\n' "$msg"

    # Skip CI detection
    if echo "$msg" | grep -qiE '\[skip[[:space:]]ci\]|\[ci[[:space:]]skip\]'; then
        echo "  skip-ci: YES"
    else
        echo "  skip-ci: no"
    fi

    # Issue references: fixes #NNN, closes #NNN, resolves #NNN
    local issues
    issues=$(echo "$msg" | grep -oiE '(fixes|closes|resolves)[[:space:]]+#[0-9]+' || true)
    if [ -n "$issues" ]; then
        echo "$issues" | while read -r ref; do
            issue_num=$(echo "$ref" | grep -o '#[0-9]*')
            action=$(echo "$ref" | awk '{print $1}' | tr '[:upper:]' '[:lower:]')
            printf '  issue-ref: %s %s\n' "$action" "$issue_num"
        done
    else
        echo "  issue-ref: none"
    fi

    # Conventional commit type
    local cc_type=""
    case "$msg" in
        feat:*|feat\(*) cc_type="feature" ;;
        fix:*|fix\(*)   cc_type="bugfix" ;;
        chore:*|chore\(*) cc_type="chore" ;;
        docs:*|docs\(*)   cc_type="docs" ;;
        test:*|test\(*)   cc_type="test" ;;
        refactor:*|refactor\(*) cc_type="refactor" ;;
        *) cc_type="other" ;;
    esac
    printf '  cc-type: %s\n' "$cc_type"

    # Breaking change marker
    if echo "$msg" | grep -qE 'BREAKING[[:space:]]CHANGE|!:'; then
        echo "  breaking: YES"
    else
        echo "  breaking: no"
    fi

    echo "---"
}

# Test cases — deterministic set of commit messages
parse_commit "feat(auth): add OAuth2 support"
parse_commit "fix(db): resolve connection pool leak fixes #123"
parse_commit "[skip ci] docs: update README"
parse_commit "chore!: drop Node 14 support BREAKING CHANGE"
parse_commit "fix: correct typo closes #456 closes #789"
parse_commit "[ci skip] bump version to 2.1.0"
parse_commit "refactor(core): extract parser module"

echo "commit-parsing: done"
