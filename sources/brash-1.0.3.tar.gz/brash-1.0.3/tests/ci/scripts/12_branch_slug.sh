#!/usr/bin/env bash
# 12_branch_slug.sh — Convert git refs to URL-safe slugs.
# refs/heads/feature/my-feature -> feature-my-feature

set -euo pipefail

slugify() {
    local ref="$1"
    # Strip refs/heads/ or refs/tags/ prefix
    local slug="${ref#refs/heads/}"
    slug="${slug#refs/tags/}"
    # Replace / with -
    slug="${slug//\//-}"
    # Replace non-alphanumeric (except -) with -
    slug=$(printf '%s' "$slug" | tr -cs '[:alnum:]-' '-')
    # Strip leading/trailing dashes
    slug="${slug#-}"
    slug="${slug%-}"
    # Lowercase
    slug=$(printf '%s' "$slug" | tr '[:upper:]' '[:lower:]')
    echo "$slug"
}

# Test a deterministic set of refs
REFS=(
    "refs/heads/main"
    "refs/heads/feature/add-oauth"
    "refs/heads/fix/123-login-bug"
    "refs/heads/release/v2.1.0"
    "refs/tags/v1.2.3"
    "refs/heads/HOTFIX/critical-patch"
    "refs/heads/user/john/experiment-branch"
    "refs/heads/dependabot/npm_and_yarn/lodash-4.17.21"
)

for ref in "${REFS[@]}"; do
    slug=$(slugify "$ref")
    printf 'ref: %-50s  slug: %s\n' "$ref" "$slug"
done

# Demonstrate use in Docker image tag generation
echo ""
echo "=== Docker tag examples ==="
for ref in "refs/heads/main" "refs/heads/feature/new-ui" "refs/tags/v3.0.0"; do
    slug=$(slugify "$ref")
    printf 'image: myapp:%s\n' "$slug"
done

echo "branch-slug: done"
