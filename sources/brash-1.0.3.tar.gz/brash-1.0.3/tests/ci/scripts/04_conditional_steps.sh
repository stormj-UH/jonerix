#!/usr/bin/env bash
# 04_conditional_steps.sh — Simulate GitHub Actions conditional steps.
# Uses RUNNER_OS / RUNNER_ARCH env overrides for determinism.

set -euo pipefail

# Override env for determinism (in real GH Actions these are set by the runner)
RUNNER_OS="${RUNNER_OS:-Linux}"
RUNNER_ARCH="${RUNNER_ARCH:-X64}"
GITHUB_REF="${GITHUB_REF:-refs/heads/main}"
GITHUB_EVENT_NAME="${GITHUB_EVENT_NAME:-push}"

printf 'Runner: %s/%s\n' "$RUNNER_OS" "$RUNNER_ARCH"
printf 'Ref: %s\n' "$GITHUB_REF"
printf 'Event: %s\n' "$GITHUB_EVENT_NAME"
echo "---"

# Step: OS-specific dependency install
if [ "$RUNNER_OS" = "Linux" ]; then
    echo "step[install-deps]: apt-get update (Linux)"
elif [ "$RUNNER_OS" = "macOS" ]; then
    echo "step[install-deps]: brew update (macOS)"
else
    echo "step[install-deps]: choco install (Windows)"
fi

# Step: only on x64
if [ "$RUNNER_ARCH" = "X64" ]; then
    echo "step[build-x64]: running 64-bit optimised build"
else
    echo "step[build-x64]: skipped (non-X64)"
fi

# Step: deploy only on push to main
if [ "$GITHUB_EVENT_NAME" = "push" ] && [ "$GITHUB_REF" = "refs/heads/main" ]; then
    echo "step[deploy]: deploying to production"
else
    echo "step[deploy]: skipped (not a push to main)"
fi

# Step: run tests always
echo "step[test]: running test suite"

# Step: notify only on failure (simulated with a flag)
STEP_STATUS="${STEP_STATUS:-success}"
if [ "$STEP_STATUS" != "success" ]; then
    echo "step[notify]: sending failure notification"
else
    echo "step[notify]: skipped (success)"
fi

echo "conditional-steps: done"
