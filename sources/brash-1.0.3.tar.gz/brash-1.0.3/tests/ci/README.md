# tests/ci — CI/CD Shell Pattern Differential Corpus

Differential test corpus for common CI/CD shell patterns, verifying that brash
produces byte-identical output to bash across 18 scripts covering GitHub
Actions, GitLab CI, CircleCI, and general build-system shell.

## Structure

```
tests/ci/
  run.sh              — differential runner
  scripts/
    01_output_passing.sh       — $GITHUB_OUTPUT key=value style
    02_env_from_secrets.sh     — secret masking and env injection
    03_matrix_expansion.sh     — matrix.os × matrix.version dispatch
    04_conditional_steps.sh    — RUNNER_OS / event / ref conditionals
    05_version_selection.sh    — setup-node/python version resolution
    06_cache_key.sh            — deterministic cache key from file sizes
    07_artifact_manifest.sh    — artifact listing and manifest generation
    08_multiline_output.sh     — key<<DELIM multiline GITHUB_OUTPUT
    09_exit_on_error_chain.sh  — set -euo pipefail step chain
    10_json_output.sh          — JSON payload building via printf
    11_commit_message_parsing.sh — [skip ci] / fixes #N / CC tags
    12_branch_slug.sh          — refs/heads/… to URL slug
    13_timestamp.sh            — deterministic timestamp / artifact naming
    14_changed_files.sh        — git diff --name-only categorisation
    15_slack_notification.sh   — Block Kit notification JSON assembly
    16_gitlab_ci_patterns.sh   — CI_* vars, registry, environments
    17_circleci_patterns.sh    — CIRCLE_* vars, parallelism, workspaces
    18_build_system_shell.sh   — compiler flags, dep order, version bumps
```

## Running

```bash
# All scripts
tests/ci/run.sh

# Specific scripts (by number prefix or name)
tests/ci/run.sh 01 06 11

# With a custom brash binary
BRASH_BIN=./target/debug/brash tests/ci/run.sh

# Verbose output on failure
VERBOSE=1 tests/ci/run.sh
```

## Design constraints

- **Deterministic**: no live `date`, `git`, or network calls. All
  non-deterministic values are injected via environment variables with
  fixed defaults.
- **Self-contained**: each script creates its own `mktemp` sandbox and
  cleans up on exit. No persistent side effects.
- **Portable**: only POSIX utilities (`printf`, `wc`, `find`, `grep`,
  `tr`, `sort`, `awk`) plus bash arrays/`[[`.
- **Isolated environment**: the runner uses `env -i` with a minimal
  `PATH` to prevent host environment leakage.

## Patterns covered

| # | Pattern | CI System |
|---|---------|-----------|
| 01 | `echo "k=v" >> $GITHUB_OUTPUT` | GitHub Actions |
| 02 | Secrets file → env vars (masked logging) | GitHub Actions |
| 03 | `matrix.os` × `matrix.version` case dispatch | GitHub Actions |
| 04 | `if [ "$RUNNER_OS" = "Linux" ]` step gating | GitHub Actions |
| 05 | Semver resolution, tool PATH injection | GitHub Actions |
| 06 | Cache key from file byte-counts | GitHub Actions |
| 07 | Artifact find + manifest + zip simulation | GitHub Actions |
| 08 | `key<<DELIM` multiline output blocks | GitHub Actions |
| 09 | `set -euo pipefail` sequential step chain | Any |
| 10 | JSON payload via `printf` (no jq) | Any |
| 11 | `[skip ci]`, `fixes #N`, conventional commit | Any |
| 12 | `refs/heads/feature/foo` → `feature-foo` slug | Any |
| 13 | Deterministic timestamp / artifact naming | Any |
| 14 | Changed-files categorisation, step gating | Any |
| 15 | Slack Block Kit notification assembly | GitHub Actions |
| 16 | `CI_*` registry, environments, branch rules | GitLab CI |
| 17 | `CIRCLE_*` parallelism, workspace, orbs | CircleCI |
| 18 | Compiler flags, dep ordering, version bump | Build systems |
