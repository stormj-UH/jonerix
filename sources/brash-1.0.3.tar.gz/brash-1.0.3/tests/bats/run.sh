#!/usr/bin/env bash
# tests/bats/run.sh — run bats-core self-tests under both bash and brash,
# report pass/fail counts for each.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
BATS_DIR="$SCRIPT_DIR/bats-core"
BRASH="$REPO_ROOT/target/release/brash"

# --- 1. Build brash if not present ---
if [[ ! -x "$BRASH" ]]; then
    echo "Building brash..."
    (cd "$REPO_ROOT" && cargo build --release)
fi

# --- 2. Clone bats-core if absent ---
if [[ ! -d "$BATS_DIR" ]]; then
    echo "Cloning bats-core..."
    git clone --depth 1 https://github.com/bats-core/bats-core.git "$BATS_DIR"
fi

BATS_BIN="$BATS_DIR/bin/bats"

# --- Helper: summarise a bats TAP output file ---
summarise() {
    local label="$1" file="$2"
    local pass fail skip
    pass=$(grep -c "^ok "     "$file" || true)
    fail=$(grep -c "^not ok " "$file" || true)
    skip=$(grep -c " # skip"  "$file" || true)
    echo "[$label]  pass=$pass  fail=$fail  skip=$skip"
}

# --- 3. Run under bash baseline ---
echo
echo "=== bash baseline ==="
cd "$BATS_DIR"
./bin/bats test/ > /tmp/bats-bash.summary 2>&1 || true
summarise "bash " /tmp/bats-bash.summary

# --- 4. Run under brash (BASH=brash makes bats spawn test processes via brash) ---
echo
echo "=== brash ==="
BASH="$BRASH" ./bin/bats test/ > /tmp/bats-brash.summary 2>&1 || true
summarise "brash" /tmp/bats-brash.summary

# --- 5. Diff failing tests ---
echo
echo "=== failures unique to brash (not present in bash) ==="
diff <(grep "^not ok" /tmp/bats-bash.summary  || true) \
     <(grep "^not ok" /tmp/bats-brash.summary || true) \
  | grep "^>" || echo "(none)"

echo
echo "=== failures unique to bash (fixed by brash) ==="
diff <(grep "^not ok" /tmp/bats-bash.summary  || true) \
     <(grep "^not ok" /tmp/bats-brash.summary || true) \
  | grep "^<" || echo "(none)"
