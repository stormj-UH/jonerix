#!/bin/bash
# Bashism: ${var^^} / ${var,,} / ${var^} / ${var,} case conversion
str="Hello World"

echo "${str^^}"
echo "${str,,}"

# First char only
echo "${str^}"
echo "${str,}"

lower="abcdefg"
echo "${lower^^}"

upper="ABCDEFG"
echo "${upper,,}"

# With pattern
mixed="Hello World"
echo "${mixed^^[aeiou]}"
echo "${mixed,,[AEIOU]}"

# Array elements
arr=(hello WORLD foo BAR)
echo "${arr[@]^^}"
echo "${arr[@],,}"
