#!/bin/bash
# Bashism: $(( )) arithmetic expansion
a=10
b=3

echo "sum=$(( a + b ))"
echo "diff=$(( a - b ))"
echo "prod=$(( a * b ))"
echo "quot=$(( a / b ))"
echo "mod=$(( a % b ))"
echo "pow=$(( a ** 2 ))"

# Hex and octal literals
echo "hex=$(( 0xFF ))"
echo "oct=$(( 010 ))"

# Ternary operator
x=7
echo "ternary=$(( x > 5 ? 100 : 200 ))"

# Nested
echo "nested=$(( (a + b) * 2 ))"
