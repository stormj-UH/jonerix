#!/bin/bash
# Bashism: <<- here-doc strips leading tabs (not spaces)
cat <<-EOF
	This line has a leading tab
	So does this one
	And this one
EOF

# Mixed: tabs stripped, spaces preserved
cat <<-'MARKER'
	    tab then spaces
	no extra spaces
MARKER

# In a function
show_help() {
	cat <<-HELP
		Usage: command [options]
		  -h  show help
		  -v  verbose
	HELP
}
show_help
