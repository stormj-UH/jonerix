#!/bin/bash
# Bashism: $'...' ANSI-C quoting
echo $'hello\tworld'
echo $'line1\nline2\nline3'
echo $'backslash: \\'
echo $'single quote: \''
echo $'null char omitted: a\x00b' | cat -v
echo $'\a' | cat -v
echo $'\e[0m' | cat -v
# Hex and octal escapes
echo $'\x48\x65\x6c\x6c\x6f'
echo $'\101\102\103'
# Unicode
echo $'ABC'
