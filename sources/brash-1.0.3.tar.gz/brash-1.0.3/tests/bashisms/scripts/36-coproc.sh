#!/bin/bash
# Bashism: coproc - coprocess
coproc MYPROC { cat; }

echo "hello coprocess" >&"${MYPROC[1]}"
read -r line <&"${MYPROC[0]}"
echo "got back: $line"

echo "second line" >&"${MYPROC[1]}"
read -r line2 <&"${MYPROC[0]}"
echo "got back: $line2"

# Close and wait
exec {MYPROC[1]}>&-
wait "$MYPROC_PID" 2>/dev/null || true
echo "coproc done"
