#!/bin/bash
# Bashism: declare -n (nameref / reference variables)
declare -n ref=myvar
myvar="original"
echo "via ref: $ref"

ref="modified"
echo "myvar now: $myvar"

# Nameref in functions (indirect return)
set_value() {
    declare -n _retvar="$1"
    _retvar="$2"
}

set_value result "computed value"
echo "result: $result"

# Array nameref
declare -a myarr=(a b c d)
declare -n aref=myarr
echo "aref[2]: ${aref[2]}"
echo "aref all: ${aref[@]}"

aref+=(e)
echo "myarr after append: ${myarr[@]}"
