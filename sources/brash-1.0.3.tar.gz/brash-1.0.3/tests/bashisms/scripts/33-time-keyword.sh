#!/bin/bash
# Bashism: time keyword with TIMEFORMAT
# We can't test actual timing values, but we can test TIMEFORMAT parsing

# TIMEFORMAT with fixed format - just verify it produces matching real/user/sys labels
TIMEFORMAT='real=%R user=%U sys=%S'
output=$( { time true; } 2>&1 )
# Check the output contains the expected labels
[[ "$output" == real=* ]] && echo "has real field"
[[ "$output" == *user=* ]] && echo "has user field"
[[ "$output" == *sys=* ]] && echo "has sys field"

# TIMEFORMAT with %P (CPU percentage) - just verify it produces output
TIMEFORMAT='elapsed: %R'
output=$( { time true; } 2>&1 )
echo "has elapsed: $([[ "$output" == *elapsed:* ]] && echo yes || echo no)"

# time a pipeline
TIMEFORMAT='%R'
elapsed=$( { time (echo a | cat | cat > /dev/null); } 2>&1 )
echo "pipeline timed: $([[ "$elapsed" =~ ^[0-9]+\.[0-9]+$ ]] && echo yes || echo no)"
