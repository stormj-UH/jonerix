#!/bin/bash
# Bashism: ${var@Q} ${var@E} ${var@P} ${var@A} parameter transformations
str='hello world "quoted" and $special'

# @Q - quoted form safe for reinput
echo "${str@Q}"

# @E - expand escape sequences
esc='hello\tworld\n'
echo "${esc@E}"

# @A - assignment statement form
myvar="test value"
echo "${myvar@A}"

# @a - attributes (empty for normal var)
echo "attr: '${myvar@a}'"

# @U - uppercase (bash 5.1+)
word="hello"
echo "${word@U}"

# @L - lowercase (bash 5.1+)
WORD="HELLO"
echo "${WORD@L}"
