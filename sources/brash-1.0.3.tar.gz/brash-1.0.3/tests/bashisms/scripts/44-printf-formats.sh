#!/bin/bash
# Bashism: printf with bash-specific formats
# %q - shell-quoted
printf "%q\n" "hello world"
printf "%q\n" 'it'"'"'s a "test"'
printf "%q\n" '$VAR and `backtick`'

# printf -v (variable assignment) - also in 19, but test format specifics
printf -v padded "%-10s|" "left"
echo "'$padded'"

printf -v padded "%10s|" "right"
echo "'$padded'"

# Repeat pattern: printf with no args after format loops
printf "%s\n" one two three

# %(datefmt)T - date/time format (use epoch 0 for determinism)
printf '%(%Y-%m-%d)T\n' 0

# -1 means current time (just check it produces output)
out=$(printf '%(%Y)T\n' -1)
[[ "$out" =~ ^[0-9]{4}$ ]] && echo "year format works"
