#!/bin/bash
# Bashism: export -f exports functions to child processes
my_func() {
    echo "I am my_func with arg: $1"
}

export -f my_func

# Verify it works in a child bash process
bash -c 'my_func hello'

# Export multiple functions
add() {
    echo $(( $1 + $2 ))
}
export -f add

bash -c 'add 3 4'

# declare -F lists functions; my_func should still be exported here
declare -F my_func > /dev/null && echo "my_func is declared"
