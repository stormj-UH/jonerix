#!/bin/bash
# Bashism: (( )) arithmetic command
x=5

(( x += 3 ))
echo "x=$x"

(( y = x * 2 ))
echo "y=$y"

if (( x > 7 )); then
    echo "x is greater than 7"
fi

# (( )) returns exit code based on arithmetic result
(( 0 )) && echo "zero is true" || echo "zero is false"
(( 1 )) && echo "one is true" || echo "one is false"

# Bitwise operations
(( z = 0xFF & 0x0F ))
echo "z=$z"
