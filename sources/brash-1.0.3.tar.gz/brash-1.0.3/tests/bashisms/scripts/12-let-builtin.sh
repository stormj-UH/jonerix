#!/bin/bash
# Bashism: let builtin for arithmetic
let x=5+3
echo "x=$x"

let y=x*2
echo "y=$y"

let "z = (x + y) / 3"
echo "z=$z"

# let returns 1 (failure) if result is 0
let "val = 0" || echo "val is zero (let returned non-zero)"
let "val = 1" && echo "val is non-zero (let returned zero)"

# Increment/decrement
let x++
echo "after x++: x=$x"

let x--
echo "after x--: x=$x"

# Multiple expressions
let a=1 b=2 c=a+b
echo "a=$a b=$b c=$c"
