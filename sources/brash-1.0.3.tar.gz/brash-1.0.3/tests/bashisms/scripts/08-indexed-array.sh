#!/bin/bash
# Bashism: indexed arrays
arr=(alpha beta gamma delta)

echo "element 0: ${arr[0]}"
echo "element 2: ${arr[2]}"
echo "all elements: ${arr[@]}"
echo "length: ${#arr[@]}"

# Assign by index
arr[4]="epsilon"
echo "element 4: ${arr[4]}"

# Slice
echo "slice: ${arr[@]:1:3}"

# Indices
echo "indices: ${!arr[@]}"

# Append
arr+=("zeta")
echo "after append: ${arr[@]}"

# Unset element
unset arr[1]
echo "after unset[1]: ${arr[@]}"
echo "indices after unset: ${!arr[@]}"
