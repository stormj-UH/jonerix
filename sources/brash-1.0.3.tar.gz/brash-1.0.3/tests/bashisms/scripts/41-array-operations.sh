#!/bin/bash
# Bashism: advanced array operations
arr=(10 20 30 40 50)

# Length of element vs array
echo "array length: ${#arr[@]}"
echo "element 0 length: ${#arr[0]}"

# Pattern substitution on all elements
echo "doubled: ${arr[@]/%/0}"

# Unset and sparse arrays
unset arr[2]
echo "after unset [2]: ${arr[@]}"
echo "indices: ${!arr[@]}"

# Negative indexing (bash 4.3+)
echo "last: ${arr[-1]}"
echo "second to last: ${arr[-2]}"

# Array in arithmetic
total=0
for v in "${arr[@]}"; do
    (( total += v ))
done
echo "total: $total"

# Copy array
arr2=("${arr[@]}")
echo "copy: ${arr2[@]}"

# Reverse iterate
for (( i=${#arr[@]}-1; i>=0; i-- )); do
    idx="${!arr[@]}"
    # Iterate by index instead
    break
done
indices=(${!arr[@]})
for (( i=${#indices[@]}-1; i>=0; i-- )); do
    echo -n "${arr[${indices[$i]}]} "
done
echo
