#!/bin/bash
# Bashism: >() process substitution (output)
# Use awk instead of wc -c to avoid padding differences
result=$(awk 'END{print NR}' < <(printf 'hello world\n'))
echo "line count: $result"

# Sort into a temp file via process substitution
printf 'b\na\nc\n' | tee >(sort > /tmp/brash-bashism-05a.tmp) > /dev/null
# Give it a moment for the subshell to finish
wait
cat /tmp/brash-bashism-05a.tmp
rm -f /tmp/brash-bashism-05a.tmp
