#!/bin/bash
# Bashism: ${var//pat/repl} global substitution and variants
str="the cat sat on the mat"

# Global replace
echo "${str//the/a}"

# Replace first only
echo "${str/the/a}"

# Delete (empty replacement)
echo "${str// /}"

# Prefix match
echo "${str/#the/a}"

# Suffix match
echo "${str/%mat/rug}"

# Replace with special chars
path="/usr/local/bin:/usr/bin:/bin"
echo "${path//:/
}"

# Case-insensitive not standard but test basic patterns
filename="MyFile.TXT"
echo "${filename//.TXT/.txt}"
