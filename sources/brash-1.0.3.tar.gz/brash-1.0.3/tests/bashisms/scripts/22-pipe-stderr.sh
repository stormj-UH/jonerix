#!/bin/bash
# Bashism: |& pipes both stdout and stderr
# |& is shorthand for 2>&1 |

# Capture both stdout and stderr
{ echo "stdout line"; echo "stderr line" >&2; } |& sort

# A command that writes to both
my_func() {
    echo "out1"
    echo "err1" >&2
    echo "out2"
    echo "err2" >&2
}
my_func |& grep -c "."
