#!/bin/bash
# Bashism: additional string parameter expansions
str="Hello, World!"

# ${#var} length
echo "length: ${#str}"

# ${var:offset} and ${var:offset:len} already in 14, but test edge cases
echo "from offset 7: ${str:7}"
echo "last 6: ${str: -6}"

# ${var/pattern/replacement}
echo "${str/World/Bash}"

# ${!prefix@} and ${!prefix*} - variable names with prefix
myvar1=a
myvar2=b
myvar3=c
echo "vars with myvar prefix: ${!myvar*}"

# ${var@Q} for quoting
special='it'"'"'s a "test" with $vars'
echo "${special@Q}"

# Default value expansions
unset undef
echo "${undef:-default}"
echo "${undef:=assigned}"
echo "$undef"

# Substitute if set
isset="value"
echo "${isset:+replacement}"

# Error if unset
echo "${isset:?"this should not error"}"
