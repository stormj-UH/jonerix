#!/bin/bash
# Bashism: {a,b,c} brace expansion (list form)
echo {apple,banana,cherry}

echo pre{fix,pend,lude}

echo {a,b}{1,2}

# Nested
echo {{A,B},{C,D}}

# With text around it
echo file.{txt,md,sh}
