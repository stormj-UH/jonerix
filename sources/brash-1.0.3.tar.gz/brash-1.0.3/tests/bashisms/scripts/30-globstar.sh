#!/bin/bash
# Bashism: ** globstar with shopt -s globstar
# Use a temp dir for determinism
TDIR=/tmp/brash-bashism-glob-$$
mkdir -p "$TDIR/a/b/c" "$TDIR/a/d" "$TDIR/e"
touch "$TDIR/a/b/c/deep.txt" "$TDIR/a/d/mid.txt" "$TDIR/e/top.txt" "$TDIR/root.txt"

shopt -s globstar

# Match all .txt files recursively (sorted)
for f in "$TDIR"/**/*.txt; do
    echo "${f#$TDIR/}"
done | sort

# Match all directories
for d in "$TDIR"/**/; do
    echo "${d#$TDIR/}" | sed 's|/$||'
done | grep -v '^$' | sort

shopt -u globstar
rm -rf "$TDIR"
