#!/bin/bash
# Bashism: extended trap signals (DEBUG, ERR)

# ERR trap
trap 'echo "ERR trap fired"' ERR
false 2>/dev/null || true
trap - ERR

# RETURN trap - verify it can be set (behavior varies between versions)
trap 'true' RETURN
trap - RETURN
echo "RETURN trap: settable"

# DEBUG trap (fires before each command)
count=0
trap '(( count++ )) || true' DEBUG
x=1
y=2
z=$(( x + y ))
trap - DEBUG
echo "debug count: $count"
echo "z=$z"

# SIGCHLD / child process tracking - just verify trap can be set
trap 'true' CHLD
trap - CHLD
echo "trap extended: ok"
