#!/bin/bash
# Bashism: BASH_REMATCH array from [[ =~ ]]
pattern='^([0-9]{4})-([0-9]{2})-([0-9]{2})$'
date_str="2024-03-15"

if [[ $date_str =~ $pattern ]]; then
    echo "full: ${BASH_REMATCH[0]}"
    echo "year: ${BASH_REMATCH[1]}"
    echo "month: ${BASH_REMATCH[2]}"
    echo "day: ${BASH_REMATCH[3]}"
fi

# BASH_REMATCH is read-only
# Multiple matches - BASH_REMATCH reflects last match
for str in "2024-01-01" "1999-12-31" "2000-06-15"; do
    if [[ $str =~ $pattern ]]; then
        echo "${BASH_REMATCH[1]}/${BASH_REMATCH[2]}/${BASH_REMATCH[3]}"
    fi
done
