#!/bin/bash
# Bashism: read -a (array), read -d (delimiter), read -r (no backslash)

# read -a reads into array
IFS=' ' read -r -a words <<< "one two three four five"
echo "count: ${#words[@]}"
echo "word[0]: ${words[0]}"
echo "word[2]: ${words[2]}"
echo "word[4]: ${words[4]}"

# read -d sets delimiter
IFS= read -r -d ':' field <<< "value:rest"
echo "field: $field"

# read with custom IFS
IFS=',' read -r -a csv <<< "alpha,beta,gamma"
echo "csv[0]: ${csv[0]}"
echo "csv[1]: ${csv[1]}"
echo "csv[2]: ${csv[2]}"

# read multiple variables
read -r first rest <<< "hello world foo"
echo "first: $first"
echo "rest: $rest"
