#!/bin/bash
# Bashism: <<< here-string
# Feed a string as stdin to a command
cat <<< "hello world"

# With variable
msg="the quick brown fox"
wc -w <<< "$msg"

# With command substitution
cat <<< "$(echo 'processed')"

# read from here-string
read -r line <<< "first line"
echo "read: $line"

# Multiple words - only one line
read -r a b c <<< "alpha beta gamma"
echo "a=$a b=$b c=$c"

# tr with here-string
tr '[:lower:]' '[:upper:]' <<< "hello world"
