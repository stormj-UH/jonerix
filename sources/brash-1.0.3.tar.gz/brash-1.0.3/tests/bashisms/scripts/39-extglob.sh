#!/bin/bash
# Bashism: extglob patterns (extended globbing)
shopt -s extglob

# ?(pattern) - zero or one
str="colour"
[[ $str == col?(o)ur ]] && echo "colour matches col?(o)ur"

# *(pattern) - zero or more
[[ "aaa" == *(a) ]] && echo "aaa matches *(a)"
[[ "" == *(a) ]] && echo "empty matches *(a)"

# +(pattern) - one or more
[[ "aaa" == +(a) ]] && echo "aaa matches +(a)"
[[ "abc" == +(a) ]] || echo "abc does not match +(a)"

# @(pattern) - exactly one
[[ "a" == @(a|b|c) ]] && echo "a matches @(a|b|c)"
[[ "d" == @(a|b|c) ]] || echo "d does not match @(a|b|c)"

# !(pattern) - not matching
[[ "hello" == !(world) ]] && echo "hello is not world"
[[ "world" == !(world) ]] || echo "world matches !(world) false"

# Use in parameter expansion
path="/usr/local/bin/myprogram"
echo "${path##*/+(/)}"

shopt -u extglob
