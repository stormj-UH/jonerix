#!/bin/bash
# Bashism: pushd / popd / dirs
# Use a fixed temp directory for determinism
TDIR=/tmp/brash-bashism-pushpop-$$
mkdir -p "$TDIR/a" "$TDIR/b" "$TDIR/c"

cd "$TDIR"
dirs -c  # clear dir stack

pushd a > /dev/null
pushd ../b > /dev/null
pushd ../c > /dev/null

# Show stack (replace actual path with placeholder for determinism)
dirs | sed "s|$TDIR|TDIR|g"

popd > /dev/null
echo "after popd 1: $(pwd | sed "s|$TDIR|TDIR|g")"

popd > /dev/null
echo "after popd 2: $(pwd | sed "s|$TDIR|TDIR|g")"

popd > /dev/null
echo "after popd 3: $(pwd | sed "s|$TDIR|TDIR|g")"

cd /tmp
rm -rf "$TDIR"
