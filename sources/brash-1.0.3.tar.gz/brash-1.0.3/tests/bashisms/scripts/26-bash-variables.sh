#!/bin/bash
# Bashism: BASH_VERSION, BASH_VERSINFO, LINENO, FUNCNAME, etc.

# BASH_VERSION should be set
echo "has BASH_VERSION: $( [[ -n "$BASH_VERSION" ]] && echo yes || echo no )"

# BASH_VERSINFO is an array
echo "major version: ${BASH_VERSINFO[0]}"
# Just check it's a number >= 4
[[ "${BASH_VERSINFO[0]}" -ge 4 ]] && echo "version >= 4"

# LINENO
echo "LINENO is a number: $( [[ "$LINENO" =~ ^[0-9]+$ ]] && echo yes || echo no )"

# FUNCNAME
my_func() {
    echo "FUNCNAME[0]: ${FUNCNAME[0]}"
    echo "FUNCNAME[1]: ${FUNCNAME[1]}"
}
my_func

# BASH_SUBSHELL
echo "subshell level: $BASH_SUBSHELL"
( echo "in subshell: $BASH_SUBSHELL" )

# BASHPID
echo "BASHPID is a number: $( [[ "$BASHPID" =~ ^[0-9]+$ ]] && echo yes || echo no )"
