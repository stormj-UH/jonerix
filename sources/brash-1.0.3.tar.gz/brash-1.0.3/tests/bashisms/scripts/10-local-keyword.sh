#!/bin/bash
# Bashism: local keyword for function-scoped variables
outer_var="global"

my_func() {
    local inner_var="local_value"
    local outer_var="shadowed"
    echo "inside: inner_var=$inner_var"
    echo "inside: outer_var=$outer_var"
}

my_func
echo "outside: outer_var=$outer_var"
# inner_var should not be set outside
echo "outside: inner_var=${inner_var:-unset}"

# local with arithmetic
counter() {
    local count=0
    local i
    for i in {1..5}; do
        (( count += i ))
    done
    echo "sum=$count"
}
counter
