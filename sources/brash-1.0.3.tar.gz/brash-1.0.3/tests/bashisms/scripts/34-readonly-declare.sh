#!/bin/bash
# Bashism: readonly with declare, typeset as alias
declare -r PI=3.14159
echo "PI=$PI"

# typeset is alias for declare
typeset myvar="typeset works"
echo "$myvar"

typeset -i counter=0
counter+=5
echo "counter=$counter"

# readonly keyword
readonly MAXVAL=100
echo "MAXVAL=$MAXVAL"

# Attempt to modify readonly (should fail)
{ PI=0; } 2>/dev/null && echo "modified PI" || echo "PI is readonly"
{ MAXVAL=0; } 2>/dev/null && echo "modified MAXVAL" || echo "MAXVAL is readonly"

# declare -p shows attributes
declare -p PI | grep -o '\-[a-zA-Z]*' | head -1
