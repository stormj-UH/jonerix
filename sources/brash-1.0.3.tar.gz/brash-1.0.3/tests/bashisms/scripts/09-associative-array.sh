#!/bin/bash
# Bashism: associative arrays (declare -A)
declare -A colors
colors[red]="#FF0000"
colors[green]="#00FF00"
colors[blue]="#0000FF"

echo "red: ${colors[red]}"
echo "green: ${colors[green]}"
echo "blue: ${colors[blue]}"

# Check key existence
if [[ -v colors[red] ]]; then
    echo "red key exists"
fi

# All keys (sorted for determinism)
keys=($(for k in "${!colors[@]}"; do echo "$k"; done | sort))
echo "keys: ${keys[@]}"

# All values (sorted for determinism)
vals=($(for k in "${keys[@]}"; do echo "${colors[$k]}"; done))
echo "values: ${vals[@]}"

echo "count: ${#colors[@]}"
