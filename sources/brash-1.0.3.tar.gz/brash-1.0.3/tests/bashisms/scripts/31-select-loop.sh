#!/bin/bash
# Bashism: select loop (menu generation)
# Feed input via stdin for determinism
PS3="Choose: "
select fruit in apple banana cherry; do
    echo "You chose: $fruit (REPLY=$REPLY)"
    break
done <<< "2"
