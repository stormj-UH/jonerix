#!/bin/bash
# Bashism: ${var:offset:length} substring expansion
str="Hello, World!"

echo "${str:0:5}"
echo "${str:7:5}"
echo "${str:7}"

# Negative offset (from end)
echo "${str: -6}"
echo "${str: -6:5}"

# Works on arrays too
arr=(zero one two three four five)
echo "${arr[@]:2:3}"
echo "${arr[@]: -2}"

# Positional parameters substring
set -- alpha beta gamma delta
echo "${@:2:2}"
echo "${@: -1}"
