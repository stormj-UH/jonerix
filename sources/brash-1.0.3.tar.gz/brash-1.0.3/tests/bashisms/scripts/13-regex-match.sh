#!/bin/bash
# Bashism: [[ =~ ]] regex matching and BASH_REMATCH
str="The quick brown fox 42"

if [[ $str =~ ([a-z]+)\ ([a-z]+)\ ([a-z]+) ]]; then
    echo "matched"
    echo "full match: ${BASH_REMATCH[0]}"
    echo "group 1: ${BASH_REMATCH[1]}"
    echo "group 2: ${BASH_REMATCH[2]}"
    echo "group 3: ${BASH_REMATCH[3]}"
fi

# Number pattern
if [[ $str =~ ([0-9]+)$ ]]; then
    echo "number at end: ${BASH_REMATCH[1]}"
fi

# No match
if [[ "hello" =~ ^[0-9]+$ ]]; then
    echo "is number"
else
    echo "not a number"
fi

# Email-like pattern
email="user@example.com"
if [[ $email =~ ^([^@]+)@([^@]+)$ ]]; then
    echo "user: ${BASH_REMATCH[1]}"
    echo "domain: ${BASH_REMATCH[2]}"
fi
