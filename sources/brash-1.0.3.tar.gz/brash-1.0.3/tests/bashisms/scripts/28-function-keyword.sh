#!/bin/bash
# Bashism: function keyword syntax (vs POSIX () form)
function greet {
    echo "Hello, $1!"
}
greet "World"

# Also valid with parens
function farewell() {
    echo "Goodbye, $1!"
}
farewell "World"

# Recursive function
function factorial {
    local n=$1
    if (( n <= 1 )); then
        echo 1
    else
        echo $(( n * $(factorial $(( n - 1 ))) ))
    fi
}
echo "5! = $(factorial 5)"

# Function with local array
function make_list {
    local -a items=("$@")
    local result=""
    local item
    for item in "${items[@]}"; do
        result+="$item "
    done
    echo "${result% }"
}
make_list alpha beta gamma
