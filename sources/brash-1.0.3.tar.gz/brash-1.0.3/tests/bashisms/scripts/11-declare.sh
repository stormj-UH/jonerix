#!/bin/bash
# Bashism: declare/typeset with attributes
declare -i num=42
echo "integer: $num"

# Integer attribute coerces arithmetic
num="10+5"
echo "after arith assign: $num"

# Readonly
declare -r CONST=100
echo "readonly: $CONST"

# Lowercase/uppercase attributes
declare -l lower_var="HELLO WORLD"
echo "lowercase: $lower_var"

declare -u upper_var="hello world"
echo "uppercase: $upper_var"

# Array declaration
declare -a my_arr=(one two three)
echo "array: ${my_arr[@]}"

# Print with declare -p
declare -p num | sed 's/declare -[^ ]*/declare -X/'
