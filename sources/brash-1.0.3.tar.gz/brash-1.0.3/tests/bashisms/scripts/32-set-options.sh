#!/bin/bash
# Bashism: set -o long-form options not in POSIX

# pipefail - pipeline fails if any command fails
set -o pipefail
false | echo "after false" | cat > /dev/null
echo "with pipefail, false|echo|cat exits: $?"
set +o pipefail

# noclobber - prevent accidental clobber
set -o noclobber
TMP=/tmp/brash-bashism-32.$$
echo "original" > "$TMP"
# Use $() to capture stderr too and check exit code only
( echo "clobber attempt" > "$TMP" ) 2>/dev/null
clobber_rc=$?
if [[ $clobber_rc -ne 0 ]]; then
    echo "clobber prevented"
else
    echo "clobber succeeded"
fi
rm -f "$TMP"
set +o noclobber

# Check pipefail and noclobber are settable (we already used them above)
set -o pipefail  && echo "pipefail: settable"; set +o pipefail
set -o noclobber && echo "noclobber: settable"; set +o noclobber
