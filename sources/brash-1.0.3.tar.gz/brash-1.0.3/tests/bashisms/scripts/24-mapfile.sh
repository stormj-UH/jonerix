#!/bin/bash
# Bashism: mapfile / readarray
mapfile -t lines <<< $'alpha\nbeta\ngamma\ndelta'
echo "count: ${#lines[@]}"
echo "line[0]: ${lines[0]}"
echo "line[2]: ${lines[2]}"

# readarray is alias for mapfile
readarray -t words <<< $'one\ntwo\nthree'
echo "words: ${words[@]}"

# mapfile with -n (max lines) and -s (skip lines)
mapfile -t -n 2 first2 <<< $'a\nb\nc\nd\ne'
echo "first2: ${first2[@]}"

mapfile -t -s 2 skip2 <<< $'a\nb\nc\nd\ne'
echo "skip2: ${skip2[@]}"

# From a command
mapfile -t nums < <(seq 1 5)
echo "nums: ${nums[@]}"
