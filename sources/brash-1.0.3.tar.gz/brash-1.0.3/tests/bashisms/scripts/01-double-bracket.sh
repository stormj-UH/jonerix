#!/bin/bash
# Bashism: [[ ]] extended test command
a="hello"
b="world"

if [[ "$a" == "hello" ]]; then
    echo "a is hello"
fi

if [[ "$b" != "hello" ]]; then
    echo "b is not hello"
fi

if [[ "$a" < "$b" ]]; then
    echo "a comes before b lexicographically"
fi

x=5
if [[ $x -gt 3 && $x -lt 10 ]]; then
    echo "x is between 3 and 10"
fi

# [[ does not word-split or glob-expand
var="hello world"
if [[ $var == "hello world" ]]; then
    echo "no word splitting in [["
fi
