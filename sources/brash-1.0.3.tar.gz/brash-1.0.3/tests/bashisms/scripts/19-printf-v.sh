#!/bin/bash
# Bashism: printf -v var (assign to variable instead of stdout)
printf -v greeting "Hello, %s!" "World"
echo "$greeting"

printf -v num "%05d" 42
echo "$num"

printf -v hex "0x%X" 255
echo "$hex"

# printf -v with array index
printf -v arr[0] "first"
printf -v arr[1] "second"
printf -v arr[2] "third"
echo "${arr[@]}"

# Using in function to return value
make_label() {
    local name="$1"
    local val="$2"
    printf -v "$name" "[%s]" "$val"
}
make_label myresult "hello"
echo "$myresult"
