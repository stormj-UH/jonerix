#!/bin/bash
# Bashism: <() process substitution (input)
# Use comm to compare two sorted lists without temp files
comm -3 \
    <(echo apple; echo banana; echo cherry) \
    <(echo apple; echo blueberry; echo cherry)

# Reading from process substitution with while loop
while IFS= read -r line; do
    echo "got: $line"
done < <(echo line1; echo line2; echo line3)
