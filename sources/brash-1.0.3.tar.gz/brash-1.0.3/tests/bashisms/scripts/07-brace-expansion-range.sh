#!/bin/bash
# Bashism: {n..m} brace expansion (range/sequence form)
echo {1..5}

echo {a..e}

echo {10..1}

# With step
echo {0..20..5}

echo {z..u}

# Zero-padded
echo {01..05}
