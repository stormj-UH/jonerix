#!/bin/bash
# Bashism: source builtin (vs POSIX . dot command)
# Both exist in bash; source is the bash keyword form

TMP=/tmp/brash-bashism-src-$$

# Write a file to source
cat > "$TMP" <<'EOF'
SOURCED_VAR="from sourced file"
sourced_func() {
    echo "sourced_func called with: $1"
}
EOF

source "$TMP"
echo "SOURCED_VAR=$SOURCED_VAR"
sourced_func "hello"

# source returns last command's exit code
cat > "$TMP" <<'EOF'
false
EOF
source "$TMP" && echo "source returned 0" || echo "source returned non-zero"

rm -f "$TMP"
