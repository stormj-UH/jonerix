#!/bin/bash
# Bashism: C-style for loop  for (( init; cond; incr ))
for (( i = 0; i < 5; i++ )); do
    echo "i=$i"
done

# Nested C-style for
for (( i = 1; i <= 3; i++ )); do
    for (( j = 1; j <= 3; j++ )); do
        printf "%d*%d=%d " $i $j $(( i * j ))
    done
    echo
done

# Count down
for (( n = 10; n > 0; n -= 3 )); do
    echo -n "$n "
done
echo

# Empty parts (infinite with break)
count=0
for (( ; ; )); do
    (( count++ ))
    (( count >= 3 )) && break
done
echo "count: $count"
