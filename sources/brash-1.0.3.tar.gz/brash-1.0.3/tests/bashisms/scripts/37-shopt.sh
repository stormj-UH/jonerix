#!/bin/bash
# Bashism: shopt (shell options - bash extension)

# Check some options exist and can be set/unset
shopt -s nocaseglob 2>/dev/null && echo "nocaseglob: set" || echo "nocaseglob: not available"
shopt -u nocaseglob 2>/dev/null

shopt -s extglob
echo "extglob enabled"

# extglob patterns in [[ ]] (not parameter expansion, which varies)
str="hello123world"
[[ $str == hello+([0-9])world ]] && echo "matched digits"
[[ $str == ?(foo)hello* ]] && echo "optional prefix"

# nullglob
shopt -s nullglob
arr=(/tmp/brash-no-such-file-*.xyz)
echo "nullglob count: ${#arr[@]}"
shopt -u nullglob

# dotglob
shopt -s dotglob
echo "dotglob: set"
shopt -u dotglob

# Print current shopt setting
shopt extglob | awk '{print $1, $2}'

shopt -u extglob
