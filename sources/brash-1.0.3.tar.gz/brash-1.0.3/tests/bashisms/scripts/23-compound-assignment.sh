#!/bin/bash
# Bashism: += compound assignment (strings, integers, arrays)

# String concatenation with +=
str="hello"
str+=" world"
echo "$str"

# Integer +=
declare -i num=10
num+=5
echo "num=$num"

# Array append with +=
arr=(one two three)
arr+=(four five)
echo "${arr[@]}"
echo "length: ${#arr[@]}"

# Chained
x=1
x+=2
x+=3
echo "x=$x"

# With arithmetic context
declare -i y=0
for i in {1..5}; do
    y+=$i
done
echo "sum=$y"
