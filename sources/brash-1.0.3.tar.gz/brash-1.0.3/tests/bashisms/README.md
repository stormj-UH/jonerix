# tests/bashisms — Bash-specific feature corpus

This directory contains a corpus of small scripts, each exercising a single
bash-specific feature (bashism) that `checkbashisms` would flag.  The purpose
is to validate that **brash** supports every listed bashism with output that is
byte-identical to the bash oracle.

## Running

```
bash tests/bashisms/run.sh
```

Add `--verbose` to see diffs on failures:

```
bash tests/bashisms/run.sh --verbose
```

### Environment overrides

| Variable | Default | Purpose |
|---|---|---|
| `BRASH_BIN` | `target/release/brash` | Path to the brash binary |
| `BRASH_BASH` | `runtime/alpine/bin/bash` or system bash | Bash oracle |
| `BRASH_RUNTIME_DIR` | `runtime/alpine` | Alpine runtime root |

## Scripts

| File | Bashism exercised |
|---|---|
| `01-double-bracket.sh` | `[[ ]]` extended test command (string/numeric/logical) |
| `02-arith-command.sh` | `(( ))` arithmetic command; exit code from result |
| `03-arith-expansion.sh` | `$(( ))` arithmetic expansion; hex/octal literals; ternary |
| `04-process-substitution-in.sh` | `<()` process substitution as input |
| `05-process-substitution-out.sh` | `>()` process substitution as output |
| `06-brace-expansion-list.sh` | `{a,b,c}` list brace expansion |
| `07-brace-expansion-range.sh` | `{n..m}` and `{n..m..step}` sequence brace expansion |
| `08-indexed-array.sh` | Indexed arrays: assignment, slicing, indices, append, unset |
| `09-associative-array.sh` | `declare -A` associative arrays |
| `10-local-keyword.sh` | `local` keyword for function-scoped variables |
| `11-declare.sh` | `declare` with `-i`, `-r`, `-l`, `-u`, `-a`, `-p` attributes |
| `12-let-builtin.sh` | `let` builtin for arithmetic |
| `13-regex-match.sh` | `[[ =~ ]]` regex matching with `BASH_REMATCH` |
| `14-substring-expansion.sh` | `${var:offset:len}` substring; negative offsets; arrays/positionals |
| `15-global-substitution.sh` | `${var//pat/repl}` global substitution; prefix/suffix forms |
| `16-case-conversion.sh` | `${var^^}` / `${var,,}` / `${var^}` / `${var,}` case conversion |
| `17-param-transform.sh` | `${var@Q}` `${var@E}` `${var@A}` `${var@U}` `${var@L}` transformations |
| `18-read-flags.sh` | `read -a` (array), `read -d` (delimiter), `read -r` |
| `19-printf-v.sh` | `printf -v var` assigns to variable; array index target |
| `20-ansi-c-quoting.sh` | `$'...'` ANSI-C quoting (escape sequences, hex, octal) |
| `21-here-string.sh` | `<<<` here-string |
| `22-pipe-stderr.sh` | `|&` pipes stdout+stderr together |
| `23-compound-assignment.sh` | `+=` compound assignment (strings, integers, arrays) |
| `24-mapfile.sh` | `mapfile` / `readarray` with `-t`, `-n`, `-s` flags |
| `25-pushd-popd.sh` | `pushd` / `popd` / `dirs` directory stack |
| `26-bash-variables.sh` | `BASH_VERSION`, `BASH_VERSINFO`, `LINENO`, `FUNCNAME`, `BASH_SUBSHELL`, `BASHPID` |
| `27-export-function.sh` | `export -f` exports functions to child processes |
| `28-function-keyword.sh` | `function` keyword syntax (with and without parens) |
| `29-heredoc-tab-strip.sh` | `<<-` here-doc with leading-tab stripping |
| `30-globstar.sh` | `**` globstar pattern with `shopt -s globstar` |
| `31-select-loop.sh` | `select` loop (menu) fed via here-string |
| `32-set-options.sh` | `set -o pipefail`, `noclobber`, `errtrace`, `functrace` |
| `33-time-keyword.sh` | `time` keyword with `TIMEFORMAT` |
| `34-readonly-declare.sh` | `readonly` and `typeset` as aliases for `declare -r` / `declare` |
| `35-bash-rematch.sh` | `BASH_REMATCH` array populated by `[[ =~ ]]` |
| `36-coproc.sh` | `coproc` coprocess with bidirectional I/O |
| `37-shopt.sh` | `shopt` options: `extglob`, `nullglob`, `dotglob`, `nocaseglob` |
| `38-nameref.sh` | `declare -n` nameref (indirect variable reference) |
| `39-extglob.sh` | Extended glob patterns: `?()` `*()` `+()` `@()` `!()` |
| `40-source-dot.sh` | `source` builtin (bash keyword form vs POSIX `.`) |
| `41-array-operations.sh` | Advanced array ops: negative indexing, pattern sub, sparse arrays |
| `42-string-operators.sh` | `${!prefix*}` name expansion; `${var@Q}`; default/error forms |
| `43-for-arith.sh` | C-style `for (( init; cond; incr ))` loop |
| `44-printf-formats.sh` | `printf %q`, `printf %(datefmt)T`, repeat-on-args behaviour |
| `45-trap-extended.sh` | `trap` with `ERR`, `RETURN`, `DEBUG`, `CHLD` pseudo-signals |
