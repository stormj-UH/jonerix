#!/bin/bash
# Test runner for brash bashisms corpus.
# Usage: bash tests/bashisms/run.sh [--verbose]
#
# Runs each script in tests/bashisms/scripts/ under both bash and brash,
# then compares stdout+stderr byte-identically.
# Reports N/N byte-identical at the end.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "$SCRIPT_DIR/../.." && pwd)"

BRASH_BIN="${BRASH_BIN:-$ROOT_DIR/target/release/brash}"
BRASH_RUNTIME_DIR="${BRASH_RUNTIME_DIR:-$ROOT_DIR/runtime/alpine}"
HOST_BASH="${BRASH_BASH:-}"

VERBOSE=0
if [[ "${1:-}" == "--verbose" || "${1:-}" == "-v" ]]; then
    VERBOSE=1
fi

# ------------------------------------------------------------------ setup ---

TMP_DIR="${TMPDIR:-/tmp}/brash-bashisms.$$"
mkdir -p "$TMP_DIR"
cleanup() { rm -rf "$TMP_DIR"; }
trap cleanup EXIT HUP INT TERM

# Locate bash oracle.
# Preference order:
#   1. Explicit BRASH_BASH env var
#   2. System bash (first on PATH) — only skip if caller explicitly prefers runtime
#   3. Runtime alpine bash (may be wrong arch on macOS/arm64 hosts)
if [[ -z "$HOST_BASH" ]]; then
    HOST_BASH="$(command -v bash 2>/dev/null || true)"
fi
if [[ -z "$HOST_BASH" && -x "$BRASH_RUNTIME_DIR/bin/bash" ]]; then
    HOST_BASH="$BRASH_RUNTIME_DIR/bin/bash"
fi
# Sanity-check: the binary must actually execute on this host
if [[ -n "$HOST_BASH" && -x "$HOST_BASH" ]]; then
    if ! "$HOST_BASH" -c 'true' >/dev/null 2>&1; then
        echo "WARNING: $HOST_BASH cannot execute on this host (wrong arch?), trying system bash" >&2
        HOST_BASH="$(command -v bash 2>/dev/null || true)"
    fi
fi
if [[ -z "$HOST_BASH" || ! -x "$HOST_BASH" ]]; then
    echo "ERROR: no usable bash found; set BRASH_BASH or ensure bash is in PATH" >&2
    exit 1
fi

# Locate brash
if [[ ! -x "$BRASH_BIN" ]]; then
    echo "ERROR: brash binary not found at $BRASH_BIN" >&2
    echo "       Run 'cargo build --release' in $ROOT_DIR first" >&2
    exit 1
fi

# ----------------------------------------------------------------- helpers ---

pass=0
fail=0
skip=0

run_one() {
    local script="$1"
    local name
    name="$(basename "$script")"

    local bash_out="$TMP_DIR/$name.bash.out"
    local brash_out="$TMP_DIR/$name.brash.out"

    # Run under bash oracle
    set +e
    "$HOST_BASH" "$script" >"$bash_out" 2>&1
    local bash_rc=$?
    BRASH_BASH="$HOST_BASH" "$BRASH_BIN" "$script" >"$brash_out" 2>&1
    local brash_rc=$?
    set -e

    # Compare exit codes
    if [[ "$bash_rc" -ne "$brash_rc" ]]; then
        (( fail++ )) || true
        printf "FAIL  %-50s  exit bash=%d brash=%d\n" "$name" "$bash_rc" "$brash_rc"
        if [[ "$VERBOSE" -eq 1 ]]; then
            echo "  bash output:"
            sed 's/^/    /' "$bash_out" | head -20
            echo "  brash output:"
            sed 's/^/    /' "$brash_out" | head -20
        fi
        return
    fi

    # Compare output byte-for-byte
    if cmp -s "$bash_out" "$brash_out"; then
        (( pass++ )) || true
        printf "PASS  %s\n" "$name"
    else
        (( fail++ )) || true
        printf "FAIL  %-50s  output differs\n" "$name"
        if [[ "$VERBOSE" -eq 1 ]]; then
            echo "  diff (bash vs brash):"
            diff -u "$bash_out" "$brash_out" | sed 's/^/    /' | head -40 || true
        fi
    fi
}

# ------------------------------------------------------------------- main ---

echo "brash bashisms test corpus"
echo "  bash oracle : $HOST_BASH ($("$HOST_BASH" --version | head -1))"
echo "  brash binary: $BRASH_BIN"
echo ""

scripts=()
while IFS= read -r -d '' f; do
    scripts+=("$f")
done < <(find "$SCRIPT_DIR/scripts" -name '*.sh' -print0 | sort -z)

total="${#scripts[@]}"

for script in "${scripts[@]}"; do
    run_one "$script"
done

echo ""
echo "Results: $pass/$total byte-identical ($fail failed)"

if [[ "$fail" -gt 0 ]]; then
    echo "Some tests failed. Re-run with --verbose for diffs."
    exit 1
fi
exit 0
