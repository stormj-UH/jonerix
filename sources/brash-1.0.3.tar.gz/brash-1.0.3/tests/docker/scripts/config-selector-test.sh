#!/usr/bin/env bash
# config-selector-test.sh — multi-tenant config profile selector pattern
# Pattern: CONFIG_PROFILE env var selects which config file to use
set -eu

# Use CWD-relative directories — no mktemp drift between bash/brash runs
rm -rf ./conf_test
CONF_DIR='./conf_test/configs'
mkdir -p "$CONF_DIR"

# Create mock config files for each profile
cat > "$CONF_DIR/development.conf" << 'EOF'
LOG_LEVEL=debug
MAX_CONNECTIONS=10
CACHE_ENABLED=false
REPLICA_COUNT=1
EOF

cat > "$CONF_DIR/staging.conf" << 'EOF'
LOG_LEVEL=info
MAX_CONNECTIONS=100
CACHE_ENABLED=true
REPLICA_COUNT=2
EOF

cat > "$CONF_DIR/production.conf" << 'EOF'
LOG_LEVEL=warn
MAX_CONNECTIONS=1000
CACHE_ENABLED=true
REPLICA_COUNT=5
EOF

cat > "$CONF_DIR/default.conf" << 'EOF'
LOG_LEVEL=info
MAX_CONNECTIONS=50
CACHE_ENABLED=false
REPLICA_COUNT=1
EOF

# ── Pattern 1: case statement profile selector ──
select_config_case() {
    local profile="${CONFIG_PROFILE:-default}"
    local conf_file

    case "$profile" in
        development|dev)
            conf_file="$CONF_DIR/development.conf"
            ;;
        staging|stage)
            conf_file="$CONF_DIR/staging.conf"
            ;;
        production|prod)
            conf_file="$CONF_DIR/production.conf"
            ;;
        *)
            echo "WARNING: unknown profile '$profile', using default" >&2
            conf_file="$CONF_DIR/default.conf"
            ;;
    esac

    echo "selected: $profile"
    cat "$conf_file"
    echo "---"
}

echo "=== case-statement profile selector ==="
CONFIG_PROFILE=development select_config_case
CONFIG_PROFILE=prod        select_config_case
CONFIG_PROFILE=staging     select_config_case
CONFIG_PROFILE=unknown     select_config_case
echo

# ── Pattern 2: file existence fallback chain ──
find_config_with_fallback() {
    local profile="${CONFIG_PROFILE:-}"
    local conf_file=""

    if [ -n "$profile" ] && [ -f "$CONF_DIR/$profile.conf" ]; then
        conf_file="$CONF_DIR/$profile.conf"
        echo "using profile config: $profile"
    elif [ -f "$CONF_DIR/default.conf" ]; then
        conf_file="$CONF_DIR/default.conf"
        echo "using default config"
    else
        echo "ERROR: no config found" >&2
        return 1
    fi

    grep '^LOG_LEVEL=' "$conf_file"
    grep '^MAX_CONNECTIONS=' "$conf_file"
}

echo "=== file-existence fallback chain ==="
CONFIG_PROFILE=production find_config_with_fallback
CONFIG_PROFILE=           find_config_with_fallback
CONFIG_PROFILE=nonexistent find_config_with_fallback
echo

# ── Pattern 3: environment overlay on base config ──
apply_env_overrides() {
    local base_conf="$1"
    echo "base config:"
    cat "$base_conf"
    echo

    local overrides_applied=0
    for varname in LOG_LEVEL MAX_CONNECTIONS CACHE_ENABLED REPLICA_COUNT; do
        if [ -n "${!varname:-}" ]; then
            echo "override: $varname=${!varname}"
            overrides_applied=$((overrides_applied + 1))
        fi
    done
    if [ "$overrides_applied" -eq 0 ]; then
        echo "no environment overrides"
    fi
}

echo "=== environment overlay ==="
unset LOG_LEVEL MAX_CONNECTIONS CACHE_ENABLED REPLICA_COUNT
apply_env_overrides "$CONF_DIR/default.conf"
echo
export LOG_LEVEL=debug MAX_CONNECTIONS=5
apply_env_overrides "$CONF_DIR/default.conf"
unset LOG_LEVEL MAX_CONNECTIONS

# Cleanup
rm -rf ./conf_test

echo "config-selector-test: done"
