#!/usr/bin/env bash
# postgres-test.sh — test postgres entrypoint helper patterns without initdb
# Exercises:
#   - file_env (env-from-file / Docker secrets pattern)
#   - _is_sourced detection
#   - indirect variable reference with ${!var}
#   - local var; var="$(cmd)" declare-and-assign pattern
#   - printf >&2 error messaging
#   - conditional initdb pattern (empty dir → init, non-empty → skip)
set -Eeo pipefail

# Use CWD-relative directories — no mktemp drift between bash/brash runs
rm -rf ./pg_test_data
mkdir -p ./pg_test_data/secrets

# ── file_env: the canonical Docker secrets / env-from-file pattern ──
file_env() {
    local var="$1"
    local fileVar="${var}_FILE"
    local def="${2:-}"
    if [ "${!var:-}" ] && [ "${!fileVar:-}" ]; then
        printf >&2 'error: both %s and %s are set (but are exclusive)\n' "$var" "$fileVar"
        exit 1
    fi
    local val="$def"
    if [ "${!var:-}" ]; then
        val="${!var}"
    elif [ "${!fileVar:-}" ]; then
        val="$(< "${!fileVar}")"
    fi
    export "$var"="$val"
    unset "$fileVar"
}

# Test 1: default value when nothing is set
unset DB_PASSWORD DB_PASSWORD_FILE
file_env 'DB_PASSWORD' 'changeme'
echo "file_env default: DB_PASSWORD='$DB_PASSWORD'"

# Test 2: value from env var directly
unset DB_PASSWORD DB_PASSWORD_FILE
export DB_PASSWORD='from-env'
file_env 'DB_PASSWORD' 'changeme'
echo "file_env from-var: DB_PASSWORD='$DB_PASSWORD'"

# Test 3: value from _FILE (Docker secrets pattern)
unset DB_PASSWORD DB_PASSWORD_FILE
printf 'secret-from-file' > ./pg_test_data/secrets/db_password
export DB_PASSWORD_FILE='./pg_test_data/secrets/db_password'
file_env 'DB_PASSWORD' 'changeme'
echo "file_env from-file: DB_PASSWORD='$DB_PASSWORD'"

# Test 4: conflict — both VAR and VAR_FILE set → error on stderr, exit 1
unset DB_PASSWORD DB_PASSWORD_FILE
export DB_PASSWORD='direct'
export DB_PASSWORD_FILE='./pg_test_data/secrets/db_password'
( file_env 'DB_PASSWORD' 'changeme' ) 2>&1 || true

# Reset
unset DB_PASSWORD DB_PASSWORD_FILE

echo

# ── _is_sourced detection ──
_is_sourced() {
    [ "${#FUNCNAME[@]}" -ge 2 ] \
        && [ "${FUNCNAME[0]}" = '_is_sourced' ] \
        && [ "${FUNCNAME[1]}" = 'source' ]
}

if _is_sourced; then
    echo "_is_sourced: yes (being sourced)"
else
    echo "_is_sourced: no (running directly)"
fi

echo

# ── indirect variable reference pattern ──
test_indirect_ref() {
    local VAR_NAME="$1"
    local val="${!VAR_NAME:-<unset>}"
    echo "indirect_ref(\$$VAR_NAME) = '$val'"
}

export POSTGRES_USER="pguser"
export POSTGRES_DB="mydb"
unset POSTGRES_PASSWORD

test_indirect_ref "POSTGRES_USER"
test_indirect_ref "POSTGRES_DB"
test_indirect_ref "POSTGRES_PASSWORD"

echo

# ── local var; var=$(cmd) pattern (avoids masking exit codes) ──
test_local_assign() {
    local uid
    uid="$(id -u)"
    # Use fixed output: just report root/non-root to avoid numeric uid drift
    echo "local_assign: uid obtained (type: $([ "$uid" = '0' ] && echo root || echo non-root))"
}
test_local_assign

echo

# ── conditional initdb pattern ──
test_initdb_conditional() {
    local datadir="$1"
    if [ -z "$(ls -A "$datadir" 2>/dev/null)" ]; then
        echo "initdb_check('$datadir'): directory empty → would run initdb"
    else
        echo "initdb_check('$datadir'): directory has data → skipping initialization"
    fi
}

mkdir -p ./pg_test_data/pgdata_empty ./pg_test_data/pgdata_existing
touch ./pg_test_data/pgdata_existing/PG_VERSION

test_initdb_conditional ./pg_test_data/pgdata_empty
test_initdb_conditional ./pg_test_data/pgdata_existing

# Cleanup
rm -rf ./pg_test_data

echo "postgres-test: done"
