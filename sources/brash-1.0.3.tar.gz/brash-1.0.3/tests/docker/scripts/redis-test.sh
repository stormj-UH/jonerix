#!/usr/bin/env bash
# redis-test.sh — test the redis entrypoint patterns without starting redis
# Exercises: prefix-strip param expansion, compound conditional with -a,
#            umask read + conditional set, exec-replacement pattern

set -e

# Pattern 1: prefix-strip to detect flag-like first arg
test_flag_detection() {
    local arg="$1"
    local result
    if [ "${arg#-}" != "$arg" ] || [ "${arg%.conf}" != "$arg" ]; then
        result="would prepend redis-server"
    else
        result="direct command: $arg"
    fi
    echo "flag_detection('$arg'): $result"
}

test_flag_detection "--save"
test_flag_detection "--port"
test_flag_detection "redis.conf"
test_flag_detection "myapp.conf"
test_flag_detection "redis-server"
test_flag_detection "bash"
test_flag_detection "/bin/sh"

echo

# Pattern 2: compound conditional with -a (AND) and id -u check
# Simulate the root-check pattern from redis entrypoint:
#   if [ "$1" = 'redis-server' -a "$(id -u)" = '0' ]; then
check_root_restart() {
    local cmd="$1"
    local uid="$2"  # simulated uid
    if [ "$cmd" = 'redis-server' ] && [ "$uid" = '0' ]; then
        echo "root_check('$cmd', uid=$uid): would exec gosu redis"
    else
        echo "root_check('$cmd', uid=$uid): running as-is"
    fi
}

check_root_restart "redis-server" "0"
check_root_restart "redis-server" "1000"
check_root_restart "bash" "0"

echo

# Pattern 3: umask read and conditional reset
test_umask_pattern() {
    local current_umask="$1"
    if [ "$current_umask" = '0022' ]; then
        echo "umask_check('$current_umask'): would set umask 0077"
    else
        echo "umask_check('$current_umask'): leaving umask unchanged"
    fi
}

test_umask_pattern "0022"
test_umask_pattern "0002"
test_umask_pattern "0077"

echo

# Pattern 4: exec replacement — exec "$@" pattern
# We simulate by exec-ing an echo command
simulate_exec_entrypoint() {
    local cmd="$@"
    echo "exec_pattern: about to exec: $cmd"
    # In real entrypoint this would be:  exec "$@"
    # We use a safe stand-in to demonstrate the pattern works
}

simulate_exec_entrypoint echo "redis-server" "--port" "6379"

echo "redis-test: done"
