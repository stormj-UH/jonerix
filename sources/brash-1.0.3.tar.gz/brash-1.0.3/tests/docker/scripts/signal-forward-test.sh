#!/usr/bin/env bash
# signal-forward-test.sh — signal forwarding pattern used in Docker entrypoints
# Pattern: trap SIGTERM/SIGINT, forward to child PID, wait for child
set -e

# ── Pattern 1: SIGTERM trap inspection ──
trap 'echo "SIGTERM received"' TERM
trap 'echo "SIGINT received"'  INT
trap 'echo "EXIT handler running"' EXIT

trap -p TERM
trap -p INT

# ── Pattern 2: trap with PID forwarding variable ──
child_pid=""

setup_signal_handlers() {
    trap 'echo "forwarding TERM to child"; [ -n "$child_pid" ] && kill -TERM "$child_pid" 2>/dev/null || true' TERM
    trap 'echo "forwarding INT to child";  [ -n "$child_pid" ] && kill -INT  "$child_pid" 2>/dev/null || true' INT
}

setup_signal_handlers
trap -p TERM
trap -p INT

# ── Pattern 3: wait loop with signal propagation ──
run_with_signal_forward() {
    # Spawn a short-lived background "daemon"
    ( sleep 0.05; echo "child: done" ) &
    child_pid=$!
    echo "launched child"

    wait "$child_pid"
    local exit_code=$?
    echo "child exited: rc=$exit_code"
    child_pid=""
    return "$exit_code"
}

run_with_signal_forward

echo

# ── Pattern 4: trap reset before exec ──
reset_traps_and_exec() {
    trap - TERM INT EXIT
    trap -p TERM
    trap -p INT
    echo "traps reset; ready to exec"
}

reset_traps_and_exec

echo "signal-forward-test: done"
