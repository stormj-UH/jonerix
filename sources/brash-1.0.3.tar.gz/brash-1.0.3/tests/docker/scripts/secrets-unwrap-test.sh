#!/usr/bin/env bash
# secrets-unwrap-test.sh — secrets/cert injection pattern used in Docker entrypoints
# Pattern: read cert/key from secret path, copy to runtime dir, set perms, exec
set -eu

# Use CWD-relative directories — no mktemp drift between bash/brash runs
rm -rf ./secrets_unwrap_test
SECRETS_DIR='./secrets_unwrap_test/secrets'
RUNTIME_DIR='./secrets_unwrap_test/runtime'
CERTS_DIR="$RUNTIME_DIR/certs"
mkdir -p "$SECRETS_DIR" "$CERTS_DIR"

# Create mock secrets (patterned test data — not real certs)
cat > "$SECRETS_DIR/tls.crt" << 'EOF'
-----BEGIN CERTIFICATE-----
MIIBazCCARGgAwIBAgIUFakeTestCert2024
(mock certificate data)
-----END CERTIFICATE-----
EOF

cat > "$SECRETS_DIR/tls.key" << 'EOF'
-----BEGIN RSA PRIVATE KEY-----
MIIBOgIBAAJBALFakeTestKey2024
(mock key data)
-----END RSA PRIVATE KEY-----
EOF

cat > "$SECRETS_DIR/ca.crt" << 'EOF'
-----BEGIN CERTIFICATE-----
MIIBWzCCAQWgAwIBAgIUFakeCA2024
(mock CA certificate)
-----END CERTIFICATE-----
EOF

printf 'db-secret-password-from-vault' > "$SECRETS_DIR/db_password"

# ── Pattern 1: cert unwrap — copy to runtime dir with secure perms ──
unwrap_tls_secrets() {
    local secrets_dir="$1"
    local certs_dir="$2"

    echo "unwrap_tls: copying certs to $certs_dir"

    for secret_file in "$secrets_dir"/*.crt "$secrets_dir"/*.key; do
        [ -f "$secret_file" ] || continue
        local basename
        basename="$(basename "$secret_file")"
        local dest="$certs_dir/$basename"
        cp "$secret_file" "$dest"
        case "$basename" in
            *.key)
                chmod 0600 "$dest"
                echo "  installed key: $basename (mode 0600)"
                ;;
            *.crt)
                chmod 0644 "$dest"
                echo "  installed cert: $basename (mode 0644)"
                ;;
        esac
    done
}

echo "=== TLS secrets unwrap ==="
unwrap_tls_secrets "$SECRETS_DIR" "$CERTS_DIR"
ls -la "$CERTS_DIR" | awk '{print $1, $NF}' | sort  # deterministic: perms + name only
echo

# ── Pattern 2: secret path validation before exec ──
validate_secrets() {
    local required_secrets=("$@")
    local missing=0

    for secret_path in "${required_secrets[@]}"; do
        if [ ! -f "$secret_path" ]; then
            echo "ERROR: required secret not found: $(basename "$secret_path")" >&2
            missing=$((missing + 1))
        elif [ ! -r "$secret_path" ]; then
            echo "ERROR: secret not readable: $(basename "$secret_path")" >&2
            missing=$((missing + 1))
        else
            echo "OK: secret available: $(basename "$secret_path")"
        fi
    done

    if [ "$missing" -gt 0 ]; then
        echo "ERROR: $missing required secrets missing — cannot start" >&2
        return 1
    fi
    echo "all required secrets present"
}

echo "=== secret validation before exec ==="
validate_secrets \
    "$SECRETS_DIR/tls.crt" \
    "$SECRETS_DIR/tls.key" \
    "$SECRETS_DIR/ca.crt" \
    "$SECRETS_DIR/db_password"
echo

echo "--- missing secret test ---"
validate_secrets \
    "$SECRETS_DIR/tls.crt" \
    "$SECRETS_DIR/nonexistent.key" 2>&1 || true
echo

# ── Pattern 3: DB password from secret file with export ──
echo "=== DB password from secret file ==="
load_db_secret() {
    local secret_path="$1"
    if [ -f "$secret_path" ] && [ -r "$secret_path" ]; then
        DB_PASSWORD="$(< "$secret_path")"
        export DB_PASSWORD
        echo "DB_PASSWORD loaded (${#DB_PASSWORD} chars)"
        [ -n "$DB_PASSWORD" ] || { echo "ERROR: empty secret file" >&2; return 1; }
    else
        echo "ERROR: DB_PASSWORD_FILE not readable: $secret_path" >&2
        return 1
    fi
}

load_db_secret "$SECRETS_DIR/db_password"
echo "DB_PASSWORD starts with: ${DB_PASSWORD:0:5}..."
unset DB_PASSWORD

echo

# ── Pattern 4: cert bundle assembly ──
echo "=== cert bundle assembly ==="
assemble_ca_bundle() {
    local bundle="$RUNTIME_DIR/ca-bundle.crt"
    local count=0
    printf '' > "$bundle"
    for cert in "$SECRETS_DIR"/*.crt; do
        [ -f "$cert" ] || continue
        cat "$cert" >> "$bundle"
        count=$((count + 1))
        echo "  appended: $(basename "$cert")"
    done
    chmod 0644 "$bundle"
    echo "bundle assembled: $count certificates"
}

assemble_ca_bundle

# Cleanup
rm -rf ./secrets_unwrap_test

echo "secrets-unwrap-test: done"
