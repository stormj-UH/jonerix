#!/usr/bin/env bash
# mysql-test.sh — test mysql/mariadb entrypoint patterns without mysqld
# Exercises:
#   - Logging functions (mysql_log/mysql_note/mysql_warn/mysql_error)
#   - file_env with indirect variable expansion
#   - docker_process_init_files dispatch table (case on extension)
#   - shopt -s nullglob behaviour
#   - Array-based mysql=( docker_process_sql ) pattern
set -eo pipefail
shopt -s nullglob

# Use CWD-relative directories — no mktemp drift between bash/brash runs
rm -rf ./mysql_test_data
mkdir -p ./mysql_test_data/initdb.d

# ── Logging functions (copied verbatim from mysql/mariadb entrypoint) ──
mysql_log() {
    local type="$1"; shift
    local text="$*"; if [ "$#" -eq 0 ]; then text="$(cat)"; fi
    # Use a fixed timestamp for deterministic output
    printf '2024-01-01T00:00:00+00:00 [%s] [Entrypoint]: %s\n' "$type" "$text"
}
mysql_note() { mysql_log Note "$@"; }
mysql_warn() { mysql_log Warn "$@" >&2; }
mysql_error() { mysql_log ERROR "$@" >&2; exit 1; }

mysql_note "Starting entrypoint test"
mysql_warn "This is a warning message"
echo "(mysql_error tested below via subshell)"
# Use a subshell ( ) so exit 1 doesn't kill the parent and EXIT trap doesn't fire.
( mysql_error "fatal condition" ) 2>./mysql_test_data/err.stderr || true
echo "mysql_error output: $(cat ./mysql_test_data/err.stderr)"

echo

# ── file_env with indirect variable expansion ──
file_env() {
    local var="$1"
    local fileVar="${var}_FILE"
    local def="${2:-}"
    if [ "${!var:-}" ] && [ "${!fileVar:-}" ]; then
        mysql_error "Both $var and $fileVar are set (but are exclusive)"
    fi
    local val="$def"
    if [ "${!var:-}" ]; then
        val="${!var}"
    elif [ "${!fileVar:-}" ]; then
        val="$(< "${!fileVar}")"
    fi
    export "$var"="$val"
    unset "$fileVar"
}

# Test with a secret file
unset MYSQL_ROOT_PASSWORD MYSQL_ROOT_PASSWORD_FILE
printf 'supersecret' > ./mysql_test_data/mysql_root_password
export MYSQL_ROOT_PASSWORD_FILE='./mysql_test_data/mysql_root_password'
file_env 'MYSQL_ROOT_PASSWORD' ''
echo "file_env MYSQL_ROOT_PASSWORD='$MYSQL_ROOT_PASSWORD'"
unset MYSQL_ROOT_PASSWORD MYSQL_ROOT_PASSWORD_FILE

echo

# ── docker_process_init_files: extension dispatch ──
# Mock docker_process_sql to avoid needing a real DB connection
docker_process_sql() {
    echo "  [sql] would execute SQL: $(cat)"
}

docker_process_init_files() {
    local mysql=( docker_process_sql )
    echo
    local f
    for f; do
        case "$f" in
            *.sh)
                if [ -x "$f" ]; then
                    mysql_note "entrypoint: running $f"
                    "$f"
                else
                    mysql_note "entrypoint: sourcing $f"
                    . "$f"
                fi
                ;;
            *.sql)
                mysql_note "entrypoint: running $f"
                docker_process_sql < "$f"
                echo
                ;;
            *.sql.gz)
                mysql_note "entrypoint: running $f"
                gunzip -c "$f" | docker_process_sql
                echo
                ;;
            *)
                mysql_warn "entrypoint: ignoring $f"
                ;;
        esac
        echo
    done
}

# Create test init files
INITDB_D='./mysql_test_data/initdb.d'

cat > "$INITDB_D/01-schema.sql" << 'SQLEOF'
CREATE TABLE users (id INT PRIMARY KEY, name VARCHAR(50));
SQLEOF

cat > "$INITDB_D/02-seed.sh" << 'SHEOF'
#!/bin/sh
echo "  [sh] seed script running"
SHEOF
chmod +x "$INITDB_D/02-seed.sh"

cat > "$INITDB_D/03-nosource.sh" << 'SHEOF'
#!/bin/sh
echo "  [sh] sourced (not exec)"
SHEOF
# NOT chmod +x — tests the source path

cat > "$INITDB_D/04-data.txt" << 'EOF'
# ignored file
EOF

# Run with nullglob: if no files match, the loop body doesn't execute
docker_process_init_files "$INITDB_D"/*.sql "$INITDB_D"/*.sh "$INITDB_D"/*.txt

echo

# ── nullglob: array expansion with no matches ──
echo "nullglob test (empty dir):"
EMPTY_D="./mysql_test_data/empty-initdb.d"
mkdir -p "$EMPTY_D"
files=( "$EMPTY_D"/*.sh )
echo "  files count: ${#files[@]}"
if [ "${#files[@]}" -eq 0 ]; then
    echo "  no .sh files found (nullglob working)"
fi

# Cleanup
rm -rf ./mysql_test_data

echo "mysql-test: done"
