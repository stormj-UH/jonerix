#!/usr/bin/env bash
# nginx-test.sh — test the nginx entrypoint script logic without starting nginx
# Exercises: conditional dir-scan, case on file extension, entrypoint_log function
set -e

# Use CWD-relative sandbox — run.sh cd's into a shared sandbox so both
# bash and brash see the same directory path (no mktemp -d drift).
ENTRYPOINT_D="./docker-entrypoint.d"
rm -rf "$ENTRYPOINT_D"
mkdir -p "$ENTRYPOINT_D"

# Create test files covering each case-arm in the nginx entrypoint
cat > "$ENTRYPOINT_D/10-hello.sh" << 'EOF'
#!/bin/sh
echo "init: hello from 10-hello.sh"
EOF
chmod +x "$ENTRYPOINT_D/10-hello.sh"

cat > "$ENTRYPOINT_D/20-noop.envsh" << 'EOF'
#!/bin/sh
echo "init: 20-noop.envsh sourced"
EOF
chmod +x "$ENTRYPOINT_D/20-noop.envsh"

cat > "$ENTRYPOINT_D/30-noexec.sh" << 'EOF'
#!/bin/sh
echo "should not run"
EOF
# intentionally NOT chmod +x — tests the "not executable" path

cat > "$ENTRYPOINT_D/40-other.txt" << 'EOF'
This is a config file
EOF

echo "30-noexec.sh not executable: $([ ! -x "$ENTRYPOINT_D/30-noexec.sh" ] && echo yes || echo no)"

# ── inline the nginx entrypoint logic ──

entrypoint_log() {
    if [ -z "${NGINX_ENTRYPOINT_QUIET_LOGS:-}" ]; then
        echo "$@"
    fi
}

FIRST_ARG="nginx"  # simulate being called as: entrypoint nginx

if [ "$FIRST_ARG" = "nginx" ] || [ "$FIRST_ARG" = "nginx-debug" ]; then
    if /usr/bin/find "$ENTRYPOINT_D" -mindepth 1 -maxdepth 1 -type f -print -quit 2>/dev/null | read v; then
        entrypoint_log "entrypoint: $ENTRYPOINT_D is not empty"

        find "$ENTRYPOINT_D" -follow -type f -print | sort | while read -r f; do
            # Strip leading ./ for deterministic output
            f_display="${f#./}"
            case "$f" in
                *.envsh)
                    if [ -x "$f" ]; then
                        entrypoint_log "entrypoint: Sourcing $f_display"
                        . "$f"
                    else
                        entrypoint_log "entrypoint: Ignoring $f_display, not executable"
                    fi
                    ;;
                *.sh)
                    if [ -x "$f" ]; then
                        entrypoint_log "entrypoint: Launching $f_display"
                        "$f"
                    else
                        entrypoint_log "entrypoint: Ignoring $f_display, not executable"
                    fi
                    ;;
                *) entrypoint_log "entrypoint: Ignoring $f_display";;
            esac
        done

        entrypoint_log "entrypoint: Configuration complete"
    else
        entrypoint_log "entrypoint: No files found, skipping configuration"
    fi
fi

echo "nginx-test: done"
