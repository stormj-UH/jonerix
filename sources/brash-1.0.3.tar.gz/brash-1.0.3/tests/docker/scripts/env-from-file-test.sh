#!/usr/bin/env bash
# env-from-file-test.sh — env-from-file / Docker secrets injection pattern
# Covers multiple variants seen across official Docker images.
set -eu

# Use CWD-relative directories — no mktemp drift between bash/brash runs
rm -rf ./secrets_test
mkdir -p ./secrets_test

# Create secret files
printf 'secret-password-123'  > ./secrets_test/db_password
printf 'my-api-key-xyz'       > ./secrets_test/api_key
printf 'admin'                > ./secrets_test/db_user
printf 'production'           > ./secrets_test/app_env

# ── Variant 1: postgres/mysql style file_env ──
file_env() {
    local var="$1"
    local fileVar="${var}_FILE"
    local def="${2:-}"
    if [ "${!var:-}" ] && [ "${!fileVar:-}" ]; then
        echo "error: both $var and $fileVar are set (but are exclusive)" >&2
        return 1
    fi
    local val="$def"
    if [ "${!var:-}" ]; then
        val="${!var}"
    elif [ "${!fileVar:-}" ]; then
        val="$(< "${!fileVar}")"
    fi
    export "$var"="$val"
    unset "$fileVar"
}

echo "=== file_env (postgres/mysql style) ==="

unset DB_PASSWORD DB_PASSWORD_FILE
export DB_PASSWORD_FILE='./secrets_test/db_password'
file_env DB_PASSWORD 'default-pw'
echo "DB_PASSWORD='$DB_PASSWORD'"

unset API_KEY API_KEY_FILE
export API_KEY='direct-value'
file_env API_KEY 'default-key'
echo "API_KEY='$API_KEY'"

unset DB_USER DB_USER_FILE
file_env DB_USER 'postgres'
echo "DB_USER='$DB_USER' (default used)"

echo

# ── Variant 2: simple _FILE suffix loop (Bitnami/custom style) ──
load_file_envs() {
    local var file_var val
    while IFS='=' read -r var _; do
        case "$var" in
            *_FILE)
                file_var="${var}"
                val_var="${var%_FILE}"
                if [ -z "${!val_var:-}" ]; then
                    if [ -r "${!file_var}" ]; then
                        export "$val_var"="$(< "${!file_var}")"
                        echo "loaded: $val_var from ${!file_var}"
                    fi
                fi
                ;;
        esac
    done < <(env)
}

echo "=== _FILE suffix loop ==="
unset DB_PASSWORD API_KEY DB_USER DB_PASSWORD_FILE API_KEY_FILE DB_USER_FILE
export DB_PASSWORD_FILE='./secrets_test/db_password'
export API_KEY_FILE='./secrets_test/api_key'
export DB_USER_FILE='./secrets_test/db_user'
load_file_envs | sort   # sort for deterministic ordering (env order varies)
echo "DB_PASSWORD='${DB_PASSWORD:-}'"
echo "API_KEY='${API_KEY:-}'"
echo "DB_USER='${DB_USER:-}'"

echo

# ── Variant 3: explicit path-to-var mapping ──
echo "=== explicit path mapping ==="
read_secret() {
    local varname="$1"
    local filepath="$2"
    if [ -r "$filepath" ]; then
        export "$varname"="$(< "$filepath")"
        echo "secret_read: $varname loaded"
    else
        echo "secret_read: WARNING $filepath not readable" >&2
    fi
}

unset APP_DB_PASS APP_ENV
read_secret APP_DB_PASS './secrets_test/db_password'
read_secret APP_ENV    './secrets_test/app_env'
read_secret MISSING_SECRET './secrets_test/nonexistent'
echo "APP_DB_PASS='${APP_DB_PASS:-}'"
echo "APP_ENV='${APP_ENV:-}'"

# Cleanup
rm -rf ./secrets_test

echo "env-from-file-test: done"
