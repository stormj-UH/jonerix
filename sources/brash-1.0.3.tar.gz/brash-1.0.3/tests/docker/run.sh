#!/usr/bin/env bash
# tests/docker/run.sh — differential test of brash vs bash on docker entrypoint patterns.
#
# Each script under tests/docker/scripts/*-test.sh is invoked under both shells in
# a shared sandbox directory.  Stdout, stderr, and exit code are diffed.  A "pass"
# means byte-identical output and matching exit codes.
#
# The corpus includes:
#   - Patterns extracted from real Docker entrypoints (nginx, postgres, mysql/mariadb,
#     redis, mongo, wordpress) fetched from docker-library GitHub repositories
#   - Five representative hand-written patterns (signal-forwarding, env-from-file,
#     conditional-initdb, config-selector, secrets-unwrap)
#
# Usage:
#   tests/docker/run.sh                    # run all scripts
#   tests/docker/run.sh nginx redis        # run only nginx-test and redis-test
#   BRASH_BIN=/path/to/brash tests/docker/run.sh
#   BASH_BIN=/path/to/bash tests/docker/run.sh
#   VERBOSE=1 tests/docker/run.sh
#
# Output:
#   Per-script: PASS, FAIL <reason>, or HANG
#   Summary:    "<passed>/<total> byte-identical"
#   Exit 0 if all pass, 1 if any fail/hang.

set -u

repo_root=$(cd "$(dirname "$0")/../.." && pwd)
scripts_dir="$repo_root/tests/docker/scripts"

BRASH_BIN="${BRASH_BIN:-$repo_root/target/release/brash}"
BASH_BIN="${BASH_BIN:-/opt/homebrew/bin/bash}"
[ -x "$BASH_BIN" ] || BASH_BIN=/bin/bash
TIMEOUT_SEC="${TIMEOUT_SEC:-30}"
VERBOSE="${VERBOSE:-}"

if [ ! -x "$BRASH_BIN" ]; then
    echo "ERROR: brash not found at $BRASH_BIN — run 'cargo build --release' first" >&2
    exit 2
fi
if [ ! -x "$BASH_BIN" ]; then
    echo "ERROR: bash not found at $BASH_BIN" >&2
    exit 2
fi

# ── select which scripts to run ──
if [ "$#" -gt 0 ]; then
    selected=()
    for arg in "$@"; do
        path="$scripts_dir/${arg}-test.sh"
        [ -f "$path" ] || path="$scripts_dir/$arg-test.sh"
        [ -f "$path" ] || path="$scripts_dir/$arg"
        if [ -f "$path" ]; then
            selected+=("$path")
        else
            echo "WARN: no test script for '$arg' under $scripts_dir" >&2
        fi
    done
else
    selected=()
    for f in "$scripts_dir"/*-test.sh; do
        [ -f "$f" ] && selected+=("$f")
    done
fi

[ ${#selected[@]} -eq 0 ] && { echo "no scripts to run"; exit 0; }

# ── locate timeout binary ──
if command -v timeout >/dev/null 2>&1; then
    TIMEOUT_CMD=timeout
elif command -v gtimeout >/dev/null 2>&1; then
    TIMEOUT_CMD=gtimeout
else
    TIMEOUT_CMD=
fi

run_with_timeout() {
    if [ -n "$TIMEOUT_CMD" ]; then
        "$TIMEOUT_CMD" "$TIMEOUT_SEC" "$@"
    else
        "$@"
    fi
}

passed=0
failed=0
hung=0
total=${#selected[@]}

echo "=== docker entrypoint differential test (brash vs bash) ==="
printf "  brash: %s\n" "$BRASH_BIN"
printf "  bash:  %s\n" "$BASH_BIN"
printf "  scripts: %d\n" "$total"
echo

for script in "${selected[@]}"; do
    name=$(basename "$script" -test.sh)

    # Both shells run in the SAME sandbox directory so CWD-relative paths
    # in test scripts produce identical output (no mktemp path drift).
    sandbox=$(mktemp -d)
    trap 'rm -rf "$sandbox"' EXIT

    bash_stdout="$sandbox/bash.stdout"
    bash_stderr="$sandbox/bash.stderr"

    if [ -n "$TIMEOUT_CMD" ]; then
        (cd "$sandbox" && env -i \
            HOME="$HOME" \
            PATH="/usr/bin:/bin:/usr/local/bin:/opt/homebrew/bin" \
            TMPDIR="${TMPDIR:-/tmp}" \
            "$TIMEOUT_CMD" "$TIMEOUT_SEC" "$BASH_BIN" "$script") \
            >"$bash_stdout" 2>"$bash_stderr"
    else
        (cd "$sandbox" && env -i \
            HOME="$HOME" \
            PATH="/usr/bin:/bin:/usr/local/bin:/opt/homebrew/bin" \
            TMPDIR="${TMPDIR:-/tmp}" \
            "$BASH_BIN" "$script") \
            >"$bash_stdout" 2>"$bash_stderr"
    fi
    bash_rc=$?

    brash_stdout="$sandbox/brash.stdout"
    brash_stderr="$sandbox/brash.stderr"

    if [ -n "$TIMEOUT_CMD" ]; then
        (cd "$sandbox" && env -i \
            HOME="$HOME" \
            PATH="/usr/bin:/bin:/usr/local/bin:/opt/homebrew/bin" \
            TMPDIR="${TMPDIR:-/tmp}" \
            "$TIMEOUT_CMD" "$TIMEOUT_SEC" "$BRASH_BIN" "$script") \
            >"$brash_stdout" 2>"$brash_stderr"
    else
        (cd "$sandbox" && env -i \
            HOME="$HOME" \
            PATH="/usr/bin:/bin:/usr/local/bin:/opt/homebrew/bin" \
            TMPDIR="${TMPDIR:-/tmp}" \
            "$BRASH_BIN" "$script") \
            >"$brash_stdout" 2>"$brash_stderr"
    fi
    brash_rc=$?

    trap - EXIT

    if [ "$bash_rc" -eq 124 ] || [ "$brash_rc" -eq 124 ]; then
        printf "HANG: %s (bash_rc=%d brash_rc=%d)\n" "$name" "$bash_rc" "$brash_rc"
        hung=$((hung + 1))
        rm -rf "$sandbox"
        continue
    fi

    stdout_diff=
    stderr_diff=
    rc_diff=
    cmp -s "$bash_stdout" "$brash_stdout" || stdout_diff=stdout
    cmp -s "$bash_stderr" "$brash_stderr" || stderr_diff=stderr
    [ "$bash_rc" -ne "$brash_rc" ] && rc_diff=rc

    if [ -z "$stdout_diff" ] && [ -z "$stderr_diff" ] && [ -z "$rc_diff" ]; then
        printf "PASS: %s\n" "$name"
        passed=$((passed + 1))
    else
        reasons=$(printf "%s %s %s" "$stdout_diff" "$stderr_diff" "$rc_diff" \
            | tr -s ' ' | sed 's/^ *//;s/ *$//')
        printf "FAIL: %s [%s]\n" "$name" "$reasons"
        failed=$((failed + 1))

        if [ -n "$VERBOSE" ]; then
            if [ -n "$stdout_diff" ]; then
                echo "  --- stdout diff (bash vs brash, first 40 lines) ---"
                diff -u "$bash_stdout" "$brash_stdout" | sed 's/^/  /' | head -40
            fi
            if [ -n "$stderr_diff" ]; then
                echo "  --- stderr diff ---"
                diff -u "$bash_stderr" "$brash_stderr" | sed 's/^/  /' | head -20
            fi
            if [ -n "$rc_diff" ]; then
                printf "  --- exit code: bash=%d brash=%d ---\n" "$bash_rc" "$brash_rc"
            fi
        fi
    fi

    rm -rf "$sandbox"
done

echo
printf "=== %d passed, %d failed, %d hung, %d total — %d%% byte-identical ===\n" \
    "$passed" "$failed" "$hung" "$total" $((passed * 100 / total))

if [ "$failed" -ne 0 ] || [ "$hung" -ne 0 ]; then
    exit 1
fi
exit 0
