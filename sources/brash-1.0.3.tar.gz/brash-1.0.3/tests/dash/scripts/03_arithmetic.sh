#!/bin/sh
# POSIX arithmetic expansion

# Basic ops
echo $((1 + 2))
echo $((10 - 3))
echo $((4 * 5))
echo $((17 / 5))
echo $((17 % 5))

# Precedence
echo $((2 + 3 * 4))
echo $((( 2 + 3 ) * 4))

# Variables in arithmetic
x=7
echo $((x + 1))
echo $((x * x))

# Comparison (returns 0 or 1)
echo $((5 > 3))
echo $((3 > 5))
echo $((5 == 5))
echo $((5 != 4))

# Bitwise
echo $((0xFF & 0x0F))
echo $((1 << 3))
echo $((16 >> 2))

# Unary
echo $((-5))
echo $((~0))

# Assignment in arithmetic
y=10
echo $((y += 5))
echo $y
