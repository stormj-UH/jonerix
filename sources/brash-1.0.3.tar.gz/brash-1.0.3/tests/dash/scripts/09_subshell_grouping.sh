#!/bin/sh
# Subshells, command grouping, command substitution

# Command substitution with $()
out=$(echo "substituted")
echo $out

# Nested command substitution
inner=$(echo "inner $(echo nested)")
echo $inner

# Backtick command substitution
out2=`echo backtick`
echo $out2

# Subshell (env changes don't leak)
x=outside
(x=inside; echo "in subshell: $x")
echo "outside subshell: $x"

# Command group { } (shares env)
x=before
{ x=after; echo "in group: $x"; }
echo "after group: $x"

# Subshell exit status
(exit 42)
echo "subshell exit: $?"

# Pipeline exit status (last command)
true | false
echo "pipe exit: $?"
false | true
echo "pipe exit: $?"

# Pipefail not POSIX, but last cmd status is
echo "piped" | cat | tr 'a-z' 'A-Z'

# Process substitution is NOT POSIX - skip

# Command substitution captures newlines (trailing stripped)
x=$(printf "line1\nline2\n")
echo "$x"

# Arithmetic in subshell
result=$(echo $((3 + 4)))
echo "arith: $result"

# Multiple commands in substitution
multi=$(echo a; echo b; echo c)
echo "$multi"
