#!/bin/sh
# POSIX glob patterns and case patterns

TMPDIR_LOCAL=/tmp/brash-posix-glob-$$
mkdir -p "$TMPDIR_LOCAL"

# Create test files
touch "$TMPDIR_LOCAL/file1.txt"
touch "$TMPDIR_LOCAL/file2.txt"
touch "$TMPDIR_LOCAL/script.sh"
touch "$TMPDIR_LOCAL/other"

# Basic glob
ls "$TMPDIR_LOCAL"/*.txt | while read f; do echo "txt: $(basename "$f")"; done | sort

# ? glob
ls "$TMPDIR_LOCAL"/file?.txt | while read f; do echo "file?: $(basename "$f")"; done | sort

# Character class
ls "$TMPDIR_LOCAL"/file[12].txt | while read f; do echo "class: $(basename "$f")"; done | sort

# Negated class
ls "$TMPDIR_LOCAL"/file[!3].txt 2>/dev/null | while read f; do echo "neg: $(basename "$f")"; done | sort

# * glob
ls "$TMPDIR_LOCAL"/* | while read f; do echo "all: $(basename "$f")"; done | sort

# case pattern matching
for f in .txt .sh .py ""; do
  case $f in
    .txt) echo "$f: text file" ;;
    .sh)  echo "$f: shell script" ;;
    .*) echo "$f: some dot file" ;;
    "")   echo "empty extension" ;;
    *)    echo "$f: other" ;;
  esac
done

# Pattern with special chars
check_pattern() {
  case $1 in
    a*b)  echo "starts a ends b" ;;
    *c*)  echo "contains c" ;;
    ???)  echo "exactly 3 chars" ;;
    *)    echo "no match" ;;
  esac
}
check_pattern "axyzb"
check_pattern "xcy"
check_pattern "abc"
check_pattern "abcdef"

rm -rf "$TMPDIR_LOCAL"
