#!/bin/sh
# POSIX parameter expansion forms

x=hello

# ${var:-default}
echo ${x:-default}
echo ${unset:-default_used}

# ${var:=default} - assign if unset
echo ${unset2:=assigned}
echo $unset2

# ${var:+alternate} - use alternate if set
echo ${x:+x_is_set}
echo ${unset3:+should_not_appear}

# ${var:?error} - error if unset (suppress stderr)
echo ${x:?error_msg}

# ${#var} - length
echo ${#x}

# Substring removal
path=/usr/local/bin/sh
echo ${path##*/}    # basename
echo ${path#*/}     # remove first /...
echo ${path%/*}     # dirname
echo ${path%%/*}    # remove all up to last / ... wait, %% removes longest suffix

# Pattern: remove up to first /
file=archive.tar.gz
echo ${file%%.*}    # remove longest suffix starting with .
echo ${file%.*}     # remove shortest suffix starting with .
echo ${file#*.}     # remove shortest prefix ending with .
echo ${file##*.}    # remove longest prefix ending with .
