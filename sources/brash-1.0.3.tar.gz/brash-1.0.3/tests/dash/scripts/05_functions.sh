#!/bin/sh
# POSIX functions

# Basic function definition and call
greet() {
  echo "hello $1"
}
greet world

# Return value
add() {
  return $(($1 + $2))
}
add 3 4
echo "add returned $?"

# Local variables
counter=global
increment() {
  local counter=0
  counter=$((counter + 1))
  echo "local counter=$counter"
}
increment
echo "global counter=$counter"

# Recursive function
fib() {
  if [ $1 -le 1 ]; then
    echo $1
    return
  fi
  a=$(fib $(($1 - 1)))
  b=$(fib $(($1 - 2)))
  echo $((a + b))
}
fib 7

# Function overrides
myfunc() { echo "v1"; }
myfunc
myfunc() { echo "v2"; }
myfunc

# $# inside function
argcount() {
  echo "got $# args"
}
argcount a b c d

# Unset function
cleanup() { echo "cleanup"; }
cleanup
unset -f cleanup
cleanup 2>/dev/null || echo "cleanup unset ok"
