#!/bin/sh
# POSIX control flow: if, while, for, case, until

# if/elif/else
x=5
if [ $x -gt 10 ]; then
  echo "big"
elif [ $x -gt 3 ]; then
  echo "medium"
else
  echo "small"
fi

# while loop
i=1
while [ $i -le 3 ]; do
  echo "while $i"
  i=$((i + 1))
done

# until loop
j=3
until [ $j -le 0 ]; do
  echo "until $j"
  j=$((j - 1))
done

# for loop with list
for item in apple banana cherry; do
  echo "item: $item"
done

# for loop with positional params
set -- x y z
for p do
  echo "pos: $p"
done

# case statement
color=blue
case $color in
  red)   echo "stop"  ;;
  green) echo "go"    ;;
  blue)  echo "sky"   ;;
  *)     echo "other" ;;
esac

# case with | alternation
val=3
case $val in
  1|2) echo "low" ;;
  3|4) echo "mid" ;;
  *)   echo "hi"  ;;
esac

# break and continue
for n in 1 2 3 4 5; do
  [ $n -eq 3 ] && continue
  [ $n -eq 5 ] && break
  echo "n=$n"
done

# Nested break with level
for a in 1 2; do
  for b in 1 2; do
    [ $a -eq 2 ] && [ $b -eq 1 ] && break 2
    echo "a=$a b=$b"
  done
done
