#!/bin/sh
# Edge cases from POSIX spec

# Empty for loop (no items)
for x in; do echo "should not print"; done
echo "empty for done"

# Case without match, no *)
val=z
case $val in
  a) echo "a" ;;
  b) echo "b" ;;
esac
echo "no match case done"

# Semicolon and newline equivalence
a=1; b=2
echo "$a $b"

# Command list with &&
true && echo "and-true"
false && echo "and-false-unreachable"
echo "after and-false"

# Command list with ||
false || echo "or-after-false"
true || echo "or-after-true-unreachable"

# Negation with !
! false && echo "negation works"
! true || echo "negation true"

# Compound command exit status
{ echo "group"; false; }
echo "group exit: $?"

# Redirection on compound command
TMPF=/tmp/brash-posix-edge-$$
{ echo "line1"; echo "line2"; } > "$TMPF"
cat "$TMPF"
rm -f "$TMPF"

# Set positional params with --
set -- -flag value rest
echo "dollar1=$1 dollar2=$2 dollar3=$3"

# Special parameter $0 is set
[ -n "$0" ] && echo "dollar0 is set"

# Empty string is false in [ -n ]
[ -n "" ] || echo "empty is not -n"

# IFS with empty
IFS=
x="abc"
for c in $x; do echo "char: $c"; done
IFS=' '

# Uninitialized var in arithmetic
echo $((undef_arith + 1))

# Background job (& operator)
(sleep 0; echo "bg done") &
wait
echo "wait complete"
