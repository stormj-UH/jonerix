#!/bin/sh
# POSIX trap and signal handling

# Basic trap on EXIT
trap 'echo "exit trap fired"' EXIT
echo "before exit"
# EXIT trap fires when script ends

# Trap on ERR is not POSIX - skip
# Trap on INT (don't test in non-interactive)

# Trap with empty handler (ignore signal concept via ERR workaround)
# Test trap reset
trap '' EXIT   # reset to ignore
echo "trap reset"
trap - EXIT    # restore default
echo "default restored"

# trap with command
trap 'echo trapped' USR1 2>/dev/null || true

# Reset all traps
trap - EXIT
