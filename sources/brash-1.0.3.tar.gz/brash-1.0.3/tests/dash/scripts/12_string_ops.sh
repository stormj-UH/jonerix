#!/bin/sh
# String operations via POSIX builtins and external commands

# String length via ${#var}
s="hello world"
echo ${#s}

# Substring via expr (POSIX)
echo $(expr substr "$s" 1 5 2>/dev/null || echo "${s%% *}")

# Case conversion via tr
echo "HELLO" | tr 'A-Z' 'a-z'
echo "hello" | tr 'a-z' 'A-Z'

# Count chars via expr or wc
echo "hello" | wc -c | tr -d ' '

# String contains test
str="the quick brown fox"
case "$str" in
  *quick*) echo "contains quick" ;;
  *) echo "no quick" ;;
esac

# String begins with
case "$str" in
  the*) echo "starts with the" ;;
  *) echo "no" ;;
esac

# String ends with
case "$str" in
  *fox) echo "ends with fox" ;;
  *) echo "no" ;;
esac

# Replace via tr (POSIX)
original="foo.bar.baz"
echo "$original" | tr '.' '_'

# Split on delimiter via IFS
line="a:b:c:d"
IFS=: read f1 f2 f3 f4 <<EOF
$line
EOF
echo "$f1 $f2 $f3 $f4"

# Join with delimiter
items="x y z"
joined=$(echo $items | tr ' ' '-')
echo $joined

# Numeric string comparison
a="10"
b="9"
if [ "$a" -gt "$b" ]; then echo "numeric: $a > $b"; fi
