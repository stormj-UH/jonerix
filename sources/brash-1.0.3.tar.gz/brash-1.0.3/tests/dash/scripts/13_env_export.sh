#!/bin/sh
# Environment, export, and variable scoping

# export makes var available to child
export MYVAR=exported_value
result=$(echo $MYVAR)
echo "exported: $result"

# Non-exported var not in child env (different process)
LOCAL_VAR=local_only
exported_check=$(env | grep "^LOCAL_VAR=" | wc -l | tr -d ' ')
echo "local not exported: $exported_check"

# Temp env for command
OUTPUT=$(TEMP_ENV=temp_val env | grep "^TEMP_ENV=")
echo "$OUTPUT"

# env builtin shows exported vars
export TESTVAR_ABC=testval
env | grep "^TESTVAR_ABC="

# unset removes variable
x=set
echo "before unset: ${x:-empty}"
unset x
echo "after unset: ${x:-empty}"

# unset -v and unset (variable)
myfunc() { echo "function"; }
myfunc
unset -f myfunc
myfunc 2>/dev/null || echo "function unset"

# PATH-style manipulation
PATH_SAVE=$PATH
export PATH=/fake/path:/also/fake
which ls 2>/dev/null || echo "ls not found in fake path"
export PATH=$PATH_SAVE

# readonly prevents modification (use subshell to isolate fatal error)
readonly CONST=42
(CONST=99 2>/dev/null; echo "unreachable") || true
echo "CONST=$CONST"

# export and readonly together (subshell for fatal-error isolation)
export readonly_export=val
readonly readonly_export
(readonly_export=other 2>/dev/null; echo "unreachable") || true
echo "readonly_export=$readonly_export"
