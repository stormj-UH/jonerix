#!/bin/sh
# POSIX builtins: test, [, echo, printf, read, set, shift, etc.

# test / [ builtin
[ 1 -eq 1 ] && echo "numeric eq"
[ "a" = "a" ] && echo "string eq"
[ "a" != "b" ] && echo "string ne"
[ -z "" ] && echo "empty string"
[ -n "x" ] && echo "non-empty string"
[ 5 -gt 3 ] && echo "greater than"
[ 3 -lt 5 ] && echo "less than"
[ 5 -ge 5 ] && echo "greater or equal"
[ 5 -le 5 ] && echo "less or equal"

# File tests
TMPF=/tmp/brash-posix-builtin-$$
touch "$TMPF"
[ -f "$TMPF" ] && echo "is file"
[ -e "$TMPF" ] && echo "exists"
[ ! -d "$TMPF" ] && echo "not directory"
rm "$TMPF"
[ ! -e "$TMPF" ] && echo "removed"

# String comparisons with -o and -a
[ "a" = "a" -a 1 -eq 1 ] && echo "and works"
[ "a" = "b" -o 1 -eq 1 ] && echo "or works"

# echo
echo "simple"
echo -n "no newline"
echo " after"

# printf
printf "%d %s %f\n" 42 hello 3.14
printf "%-10s|\n" left
printf "%10s|\n" right
printf "%05d\n" 42
printf "%x\n" 255

# set -e: exit on error
(set -e; false; echo "unreachable") || echo "set -e worked"

# set -u: error on unset variable
(set -u; echo ${definitely_unset_var} 2>/dev/null) || echo "set -u worked"

# set -f: disable globbing
(set -f; echo /tmp/*.sh) | grep -q '\*' && echo "set -f disables glob"

# shift
set -- a b c d
shift 2
echo "$@"

# eval
cmd="echo eval_output"
eval "$cmd"

# getopts (basic)
getopts_test() {
  while getopts "ab:c" opt "$@"; do
    case $opt in
      a) echo "flag a" ;;
      b) echo "flag b=$OPTARG" ;;
      c) echo "flag c" ;;
      ?) echo "unknown" ;;
    esac
  done
}
getopts_test -a -b value -c

# read builtin
echo "foo bar baz" | (read a b c; echo "read: $a | $b | $c")

# IFS splitting with read
echo "x:y:z" | (IFS=: read p q r; echo "$p $q $r")
