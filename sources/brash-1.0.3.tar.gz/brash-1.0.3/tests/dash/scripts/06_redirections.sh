#!/bin/sh
# POSIX redirections and here-docs

TMPDIR_LOCAL=/tmp/brash-dash-posix-$$
mkdir -p "$TMPDIR_LOCAL"

# Redirect stdout to file
echo "hello file" > "$TMPDIR_LOCAL/out.txt"
cat "$TMPDIR_LOCAL/out.txt"

# Append
echo "line1" > "$TMPDIR_LOCAL/app.txt"
echo "line2" >> "$TMPDIR_LOCAL/app.txt"
cat "$TMPDIR_LOCAL/app.txt"

# Redirect stdin from file
echo "from file" > "$TMPDIR_LOCAL/in.txt"
cat < "$TMPDIR_LOCAL/in.txt"

# Here-doc
cat <<EOF
here doc line1
here doc line2
EOF

# Here-doc with variable expansion
name=world
cat <<EOF
hello $name
EOF

# Here-doc with quoting (no expansion)
cat <<'EOF'
literal $name no expand
EOF

# Here-doc indented (not POSIX <<- but test <<)
cat <<EOF
  indented content
EOF

# Redirect stderr
(echo "err" >&2) 2> "$TMPDIR_LOCAL/err.txt"
cat "$TMPDIR_LOCAL/err.txt"

# Pipe
echo "pipe input" | tr 'a-z' 'A-Z'

# Pipe chain
echo "hello world" | tr ' ' '\n' | sort

# Multiple redirects in pipeline
echo "one two three" | tr ' ' '\n' | grep -v two

# /dev/null redirect
echo "discarded" > /dev/null
echo "kept"

rm -rf "$TMPDIR_LOCAL"
