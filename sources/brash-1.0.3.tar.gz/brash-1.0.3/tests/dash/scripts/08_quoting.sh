#!/bin/sh
# POSIX quoting rules

# Double quotes preserve most special chars but expand $, `, \
x=hello
echo "value is $x"
echo "dollar: \$x"
echo "backtick: \`echo hi\`"
echo "dollar backslash: \$x"

# Single quotes preserve everything
echo 'no $expansion here'
echo 'no `backtick` here'
echo 'dollar: $x'

# Backslash escaping outside quotes
echo hello\ world
echo \$x

# Word splitting
IFS=' '
words="one two three"
for w in $words; do echo "word: $w"; done

# No word splitting in double quotes
for w in "$words"; do echo "quoted: $w"; done

# Glob in double quotes (suppressed)
echo "/tmp/*.sh"

# Nested quotes
echo "outer 'inner single' end"
echo 'outer "inner double" end'

# Empty string
x=""
echo "empty=[$x]"

# Concatenation via adjacency
echo "con""cat""enate"
echo abc'def'ghi

# Quote removal
x='hello world'
echo $x       # word splits
echo "$x"     # no word split

# IFS with special chars
IFS=:
set -- a:b:c
echo "IFS split $1 $2 $3"
IFS=' '
