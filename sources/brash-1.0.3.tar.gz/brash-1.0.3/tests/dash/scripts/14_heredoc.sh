#!/bin/sh
# Here-doc variants (POSIX)

# Basic here-doc
cat <<EOF
line one
line two
EOF

# Here-doc with variable expansion
VAR=expanded
cat <<EOF
before $VAR after
EOF

# Quoted here-doc (no expansion)
cat <<'EOF'
no $expansion here
no `backtick` either
EOF

# Here-doc with leading whitespace (NOT stripped - that's <<-)
cat <<EOF
  has leading spaces
EOF

# Here-doc assigned to var via command sub
content=$(cat <<EOF
captured content
second line
EOF
)
echo "$content"

# Multiple here-docs in one line
cat <<EOF1; cat <<EOF2
first doc
EOF1
second doc
EOF2

# Here-doc in function
show_usage() {
  cat <<EOF
Usage: $0 [options]
  -h  help
  -v  verbose
EOF
}
show_usage

# Here-doc to a file
TMPF=/tmp/brash-heredoc-$$
cat > "$TMPF" <<EOF
file content line1
file content line2
EOF
cat "$TMPF"
rm -f "$TMPF"

# Here-string is NOT POSIX (bash extension) - skip
