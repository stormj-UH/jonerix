#!/bin/sh
# POSIX variable assignment, expansion, and special variables

# Basic assignment and echo
x=hello
echo $x

# Concatenation
a=foo
b=bar
echo ${a}${b}

# Unset variable is empty
echo "empty=[${unset_var}]"

# Export does not change value
export myvar=exported
echo $myvar

# Variable in subshell
result=$(echo inner)
echo $result

# Positional parameters
set -- alpha beta gamma
echo $1 $2 $3
echo $# positional params

# $@ vs $*
set -- one two three
for arg in "$@"; do echo arg=$arg; done

# Special var $$
pid=$$
[ "$pid" -gt 0 ] && echo "pid is positive"

# Last exit status
true
echo "true exit=$?"
false
echo "false exit=$?"

# Readonly - use subshell so assignment failure doesn't kill script
readonly RO=const
(RO=changed 2>/dev/null; echo "should not reach") || echo "readonly is immutable"
echo "readonly value: $RO"
