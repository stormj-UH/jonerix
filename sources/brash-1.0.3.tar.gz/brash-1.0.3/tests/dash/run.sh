#!/bin/sh
# tests/dash/run.sh - POSIX conformance test runner
#
# Runs brash against a corpus of POSIX-only shell scripts and compares
# stdout output against /bin/dash (the oracle). A pass means brash produces
# byte-identical stdout.
#
# Usage:
#   ./tests/dash/run.sh [--update] [--verbose] [pattern]
#
#   --update   Re-run oracle (dash) and overwrite .expected files
#   --verbose  Show diff for every failure
#   pattern    Only run scripts matching this glob pattern (e.g. "01_*")
#
# Oracle preference order:
#   1. /bin/dash   (present on Debian/Ubuntu; also macOS with Nix)
#   2. dash        (in PATH — Homebrew, etc.)
#   3. bash --posix (good POSIX substitute)
#
# Exit status: 0 if all tests pass, 1 if any fail.

set -u

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
SCRIPTS_DIR="$SCRIPT_DIR/scripts"

# ── locate brash ──────────────────────────────────────────────────────────────
BRASH="${BRASH:-$REPO_ROOT/target/release/brash}"
if [ ! -x "$BRASH" ]; then
    echo "ERROR: brash not found at $BRASH" >&2
    echo "Run: cargo build --release" >&2
    exit 1
fi

# ── locate oracle shell ───────────────────────────────────────────────────────
find_oracle() {
    if [ -x /bin/dash ];            then echo /bin/dash;            return; fi
    if command -v dash >/dev/null;  then command -v dash;           return; fi
    if command -v bash >/dev/null;  then echo "bash --posix";       return; fi
    echo ""; return
}

ORACLE_CMD="$(find_oracle)"
if [ -z "$ORACLE_CMD" ]; then
    echo "ERROR: no POSIX oracle found (need dash or bash)" >&2
    exit 1
fi

# ── parse flags ───────────────────────────────────────────────────────────────
UPDATE=0
VERBOSE=0
PATTERN="*.sh"

for arg in "$@"; do
    case "$arg" in
        --update)  UPDATE=1  ;;
        --verbose) VERBOSE=1 ;;
        --*)       echo "Unknown flag: $arg" >&2; exit 1 ;;
        *)         PATTERN="$arg" ;;
    esac
done

# ── update expected files if requested ───────────────────────────────────────
if [ "$UPDATE" -eq 1 ]; then
    echo "Updating expected files using oracle: $ORACLE_CMD"
    count=0
    for f in "$SCRIPTS_DIR"/$PATTERN; do
        [ "${f%.sh}" = "$f" ] && continue   # skip .expected files
        [ -f "$f" ] || continue
        expected="${f%.sh}.expected"
        # Run oracle, capture stdout only (stderr is not part of the contract)
        $ORACLE_CMD "$f" > "$expected" 2>/dev/null
        echo "  updated: $(basename "$expected")"
        count=$((count + 1))
    done
    echo "Updated $count expected files."
    exit 0
fi

# ── run tests ─────────────────────────────────────────────────────────────────
pass=0
fail=0
skip=0
total=0
fail_names=""

printf '\n%-40s %s\n' "TEST" "RESULT"
printf '%-40s %s\n' "$(printf '%0.s-' $(seq 1 40))" "------"

for f in "$SCRIPTS_DIR"/$PATTERN; do
    [ "${f%.sh}" = "$f" ] && continue   # skip non-.sh files
    [ -f "$f" ] || continue

    base="$(basename "$f" .sh)"
    expected="${f%.sh}.expected"
    total=$((total + 1))

    # Skip if no expected file
    if [ ! -f "$expected" ]; then
        printf '%-40s SKIP (no .expected)\n' "$base"
        skip=$((skip + 1))
        continue
    fi

    # Run brash, capture stdout (stderr deliberately discarded — error message
    # wording is not part of the POSIX contract)
    actual="$("$BRASH" "$f" 2>/dev/null)"
    exp="$(cat "$expected")"

    if [ "$actual" = "$exp" ]; then
        printf '%-40s PASS\n' "$base"
        pass=$((pass + 1))
    else
        printf '%-40s FAIL\n' "$base"
        fail=$((fail + 1))
        fail_names="$fail_names $base"

        if [ "$VERBOSE" -eq 1 ]; then
            echo "  --- expected ---"
            echo "$exp"    | head -20 | sed 's/^/  < /'
            echo "  --- brash ---"
            echo "$actual" | head -20 | sed 's/^/  > /'
            echo "  --- diff (first 15 lines) ---"
            _tmpA="/tmp/brash-dash-exp-$$"
            _tmpB="/tmp/brash-dash-got-$$"
            echo "$exp"    > "$_tmpA"
            echo "$actual" > "$_tmpB"
            diff "$_tmpA" "$_tmpB" | head -15 | sed 's/^/  /'
            rm -f "$_tmpA" "$_tmpB"
            echo ""
        fi
    fi
done

# ── summary ───────────────────────────────────────────────────────────────────
printf '\n%s\n' "════════════════════════════════════════════"
printf 'Oracle:  %s\n' "$ORACLE_CMD"
printf 'Brash:   %s\n' "$BRASH"
printf 'Total:   %d  Pass: %d  Fail: %d  Skip: %d\n' \
    "$total" "$pass" "$fail" "$skip"

if [ "$total" -gt 0 ]; then
    pct=$(( (pass * 100) / total ))
    printf 'POSIX conformance: %d%%\n' "$pct"
fi

if [ "$fail" -gt 0 ]; then
    printf '\nFailing tests:%s\n' "$fail_names" | tr ' ' '\n' | grep -v '^$' | sed 's/^/  /'
fi
printf '%s\n\n' "════════════════════════════════════════════"

# ── exit status ───────────────────────────────────────────────────────────────
[ "$fail" -eq 0 ]
