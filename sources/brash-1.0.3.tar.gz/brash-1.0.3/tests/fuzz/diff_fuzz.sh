#!/usr/bin/env bash
# tests/fuzz/diff_fuzz.sh — generate small random shell programs and compare
# brash vs bash output.
#
# Usage:
#   tests/fuzz/diff_fuzz.sh [N]
#     N = number of programs to generate (default 100)
#   FUZZ_SEED=42 tests/fuzz/diff_fuzz.sh
#   FUZZ_KEEP=1 tests/fuzz/diff_fuzz.sh   # keep divergent programs in tests/fuzz/divergences/
#   FUZZ_SAVE_ALL=1 tests/fuzz/diff_fuzz.sh  # save all generated programs (debug)
#
# A pass means: brash and bash produce byte-identical stdout AND stderr AND
# exit codes.  Divergent programs are printed and (with FUZZ_KEEP) saved.
#
# This is a *seeded* generator (no AFL, no instrumentation): we compose
# parser-stressing fragments at random.  Useful for catching parser/lexer
# divergences quickly; not a substitute for coverage-guided fuzzing.

set -u

repo_root=$(cd "$(dirname "$0")/../.." && pwd)
BRASH_BIN="${BRASH_BIN:-$repo_root/target/release/brash}"
BASH_BIN="${BASH_BIN:-/opt/homebrew/bin/bash}"
[ -x "$BASH_BIN" ] || BASH_BIN=/bin/bash
N="${1:-100}"
SEED="${FUZZ_SEED:-$$}"
DIVDIR="$repo_root/tests/fuzz/divergences"
SAVEALL="${FUZZ_SAVE_ALL:-}"
KEEP="${FUZZ_KEEP:-}"

[ -x "$BRASH_BIN" ] || { echo "ERROR: $BRASH_BIN not built"; exit 2; }

# Composable, parser-stressing fragments.  Each one is a small program that
# is (a) deterministic, (b) does not depend on filesystem/environment beyond
# what's set by the harness, (c) returns a defined exit code.
fragments=(
    'echo hello'
    'x=42; echo $x'
    'x=foo; y=$x$x; echo $y'
    'echo $((1+2*3))'
    'echo "${empty:-default}"'
    'a=10; echo $((a*a-1))'
    'for i in 1 2 3; do echo $i; done'
    'i=0; while [ $i -lt 3 ]; do echo $i; i=$((i+1)); done'
    'printf "%s,%s,%s\n" a b c'
    'echo $(echo nested)'
    'arr=(x y z); echo ${arr[1]} ${#arr[@]}'
    'arr=(a b c d); echo ${arr[@]:1:2}'
    's=hello; echo ${s/l/L} ${s//l/L}'
    's=abcdef; echo ${s%def} ${s#abc}'
    'echo {1..5}'
    'echo {a,b,c}'
    'a=1; b=2; if [ $a -lt $b ]; then echo less; else echo geq; fi'
    'case x in x) echo x;; *) echo other;; esac'
    'f() { echo "$1+$2"; }; f one two'
    'echo $(($((2**3)) + $((10/3))))'
    'a=hello; b=${a^}; c=${a^^}; echo $b $c'
    'IFS=, read -ra arr <<< "p,q,r"; echo ${#arr[@]} ${arr[1]}'
    'mapfile -t lines < <(printf "a\nb\nc\n"); echo ${#lines[@]}'
    'printf "[%5s]\n" abc'
    'printf "[%-5s]\n" abc'
    '{ echo a; echo b; } | sort -r'
    '(x=child; echo $x); echo parent-end'
    'set -- p q r; for a; do echo $a; done; echo $#'
    'foo() { local x=in; echo $x; }; x=out; foo; echo $x'
    'declare -i n=10; n+=5; echo $n'
    'echo $((0x10 + 16#ff))'
    'echo $((3 > 2)) $((1 < 2))'
    'a=foo; [[ $a == f* ]] && echo glob'
    'a=foo123; [[ $a =~ ^f[oa]+[0-9]+$ ]] && echo regex'
    's="  trim  "; t=${s#"${s%%[![:space:]]*}"}; t=${t%"${t##*[![:space:]]}"}; echo "[$t]"'
    'unset v; : ${v:=now-set}; echo $v'
    'echo a$"hello"b'
    'echo ${PATH:0:0}'   # empty slice
    'set -- a b c; shift; echo $@ $#'
    'p="/a/b/c.tar.gz"; echo ${p%%.*} ${p##*/}'
)

n_frags=${#fragments[@]}

# Simple seeded RNG using bash + AWK
rand_init() {
    awk_seed=$1
    rand_state=$awk_seed
}

rand() {
    # Linear congruential generator (deterministic given seed)
    rand_state=$(( (rand_state * 1103515245 + 12345) & 0x7fffffff ))
    echo $rand_state
}

rand_init "$SEED"

mkdir -p "$DIVDIR"

passed=0
diverged=0
hung=0

for ((iter = 1; iter <= N; iter++)); do
    # Compose 1-4 fragments
    n_pick=$(( $(rand) % 4 + 1 ))
    prog=
    for ((p = 0; p < n_pick; p++)); do
        idx=$(( $(rand) % n_frags ))
        prog="$prog
${fragments[$idx]}"
    done

    progfile=$(mktemp)
    printf '%s\n' "$prog" > "$progfile"

    # Run with hard limits to avoid hangs
    brash_out=$(mktemp); brash_err=$(mktemp)
    bash_out=$(mktemp);  bash_err=$(mktemp)

    if command -v timeout >/dev/null 2>&1; then
        T="timeout 5"
    elif command -v gtimeout >/dev/null 2>&1; then
        T="gtimeout 5"
    else
        T=
    fi

    env -i HOME="$HOME" PATH="/usr/bin:/bin:/usr/local/bin:/opt/homebrew/bin" \
        $T "$BRASH_BIN" "$progfile" > "$brash_out" 2> "$brash_err"
    brc=$?
    env -i HOME="$HOME" PATH="/usr/bin:/bin:/usr/local/bin:/opt/homebrew/bin" \
        $T "$BASH_BIN"  "$progfile" > "$bash_out"  2> "$bash_err"
    bashrc=$?

    if [ "$brc" -eq 124 ] || [ "$bashrc" -eq 124 ]; then
        hung=$((hung + 1))
        rm -f "$progfile" "$brash_out" "$brash_err" "$bash_out" "$bash_err"
        continue
    fi

    if cmp -s "$brash_out" "$bash_out" && cmp -s "$brash_err" "$bash_err" && [ "$brc" -eq "$bashrc" ]; then
        passed=$((passed + 1))
        if [ -n "$SAVEALL" ]; then
            cp "$progfile" "$DIVDIR/pass_${iter}.sh"
        fi
        rm -f "$progfile" "$brash_out" "$brash_err" "$bash_out" "$bash_err"
        continue
    fi

    diverged=$((diverged + 1))

    if [ -n "$KEEP" ]; then
        save="$DIVDIR/diverge_${iter}.sh"
        cp "$progfile" "$save"
        {
            echo "# brash rc=$brc"
            echo "# bash  rc=$bashrc"
            echo "# === program ==="
            cat "$progfile"
            echo "# === brash stdout ==="; cat "$brash_out"
            echo "# === bash  stdout ==="; cat "$bash_out"
            echo "# === brash stderr ==="; cat "$brash_err"
            echo "# === bash  stderr ==="; cat "$bash_err"
        } > "$save.report"
        echo "DIVERGE: saved to $save{,.report}"
    else
        echo "DIVERGE iter=$iter brc=$brc bashrc=$bashrc"
        if [ -s "$brash_out" ] || [ -s "$bash_out" ]; then
            diff <(cat "$bash_out") <(cat "$brash_out") | head -8 | sed 's/^/  /'
        fi
    fi

    rm -f "$progfile" "$brash_out" "$brash_err" "$bash_out" "$bash_err"
done

echo
printf '=== %d passed, %d diverged, %d hung, %d total — %d%% identical (seed=%s) ===\n' \
    "$passed" "$diverged" "$hung" "$N" $((passed * 100 / N)) "$SEED"

if [ "$diverged" -ne 0 ]; then
    exit 1
fi
exit 0
