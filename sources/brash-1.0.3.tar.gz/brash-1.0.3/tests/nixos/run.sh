#!/usr/bin/env bash
# tests/nixos/run.sh — differential test of brash vs bash on NixOS-style scripts.
#
# Each script under tests/nixos/scripts/ is invoked under both shells with
# identical, deterministic environment. Stdout, stderr, and exit code are diffed.
# A "pass" means byte-identical output and matching exit codes.
#
# Usage:
#   tests/nixos/run.sh                  # run all scripts
#   tests/nixos/run.sh 01 07            # run only 01_*.sh and 07_*.sh
#   BRASH_BIN=/path/to/brash tests/nixos/run.sh
#   BASH_BIN=/path/to/bash  tests/nixos/run.sh
#   VERBOSE=1               tests/nixos/run.sh
#
# Exit 0 if all pass, 1 if any fail/hang.

set -u

repo_root=$(cd "$(dirname "$0")/../.." && pwd)
scripts_dir="$repo_root/tests/nixos/scripts"

BRASH_BIN="${BRASH_BIN:-$repo_root/target/release/brash}"
BASH_BIN="${BASH_BIN:-/opt/homebrew/bin/bash}"
[ -x "$BASH_BIN" ] || BASH_BIN=/bin/bash
TIMEOUT_SEC="${TIMEOUT_SEC:-30}"
VERBOSE="${VERBOSE:-}"

if [ ! -x "$BRASH_BIN" ]; then
    echo "ERROR: brash not found at $BRASH_BIN — run 'cargo build --release' first" >&2
    exit 2
fi
if [ ! -x "$BASH_BIN" ]; then
    echo "ERROR: bash not found at $BASH_BIN" >&2
    exit 2
fi

# Select scripts to run
if [ "$#" -gt 0 ]; then
    selected=()
    for arg in "$@"; do
        # allow bare prefix like "01" or full name like "01_build_hook" or "01_build_hook.sh"
        found=
        for f in "$scripts_dir"/${arg}*.sh "$scripts_dir"/${arg}.sh; do
            if [ -f "$f" ]; then
                selected+=("$f")
                found=1
                break
            fi
        done
        if [ -z "$found" ]; then
            echo "WARN: no script matching '$arg' under $scripts_dir" >&2
        fi
    done
else
    selected=()
    for f in "$scripts_dir"/*.sh; do
        [ -f "$f" ] && selected+=("$f")
    done
fi

[ ${#selected[@]} -eq 0 ] && { echo "no scripts to run"; exit 0; }

passed=0
failed=0
hung=0
total=${#selected[@]}

# Locate timeout binary (gtimeout on macOS)
if command -v timeout >/dev/null 2>&1; then
    TIMEOUT_CMD=timeout
elif command -v gtimeout >/dev/null 2>&1; then
    TIMEOUT_CMD=gtimeout
else
    TIMEOUT_CMD=
fi

run_with_timeout() {
    if [ -n "$TIMEOUT_CMD" ]; then
        "$TIMEOUT_CMD" "$TIMEOUT_SEC" "$@"
    else
        "$@"
    fi
}

for script in "${selected[@]}"; do
    name=$(basename "$script" .sh)
    sandbox=$(mktemp -d)
    trap 'rm -rf "$sandbox"' EXIT

    brash_stdout="$sandbox/brash.stdout"
    brash_stderr="$sandbox/brash.stderr"
    bash_stdout="$sandbox/bash.stdout"
    bash_stderr="$sandbox/bash.stderr"

    # Common env: clean slate, deterministic PATH, no user-specific vars.
    # NIXOS_TEST_ROOT is set to the same fixed value for both shells so that
    # scripts that print paths rooted there produce identical output.
    common_env=(
        HOME="$HOME"
        PATH="/usr/bin:/bin:/usr/local/bin:/opt/homebrew/bin"
        TMPDIR="${TMPDIR:-/tmp}"
        TERM=dumb
        LANG=C
        LC_ALL=C
        NIXOS_TEST_ROOT=/root
    )

    # Each shell gets its own clean working directory so filesystem state
    # from the brash run cannot affect bash. NIXOS_TEST_ROOT points to a
    # pre-created subdirectory; scripts use it as their working root so the
    # *value* printed in output is the same for both shells even though the
    # actual filesystem path differs.
    mkdir -p "$sandbox/brash-wd" "$sandbox/bash-wd"
    mkdir -p "$sandbox/brash-wd/root" "$sandbox/bash-wd/root"

    # Run under brash
    (cd "$sandbox/brash-wd" && env -i "${common_env[@]}" \
        NIXOS_TEST_ROOT="$sandbox/brash-wd/root" \
        run_with_timeout "$BRASH_BIN" "$script") \
        > "$brash_stdout" 2> "$brash_stderr"
    brash_rc=$?
    # Normalise sandbox path out of output so brash-wd and bash-wd lines match
    sed -i.bak "s|$sandbox/brash-wd/root|TESTROOT|g; s|$sandbox/brash-wd|TESTSB|g" \
        "$brash_stdout" "$brash_stderr" 2>/dev/null || true

    # Run under bash
    (cd "$sandbox/bash-wd" && env -i "${common_env[@]}" \
        NIXOS_TEST_ROOT="$sandbox/bash-wd/root" \
        run_with_timeout "$BASH_BIN" "$script") \
        > "$bash_stdout" 2> "$bash_stderr"
    bash_rc=$?
    sed -i.bak "s|$sandbox/bash-wd/root|TESTROOT|g; s|$sandbox/bash-wd|TESTSB|g" \
        "$bash_stdout" "$bash_stderr" 2>/dev/null || true

    if [ "$brash_rc" -eq 124 ] || [ "$bash_rc" -eq 124 ]; then
        printf "HANG: %s (brash_rc=%d bash_rc=%d)\n" "$name" "$brash_rc" "$bash_rc"
        hung=$((hung + 1))
        rm -rf "$sandbox"
        trap - EXIT
        continue
    fi

    stdout_diff=
    stderr_diff=
    rc_diff=
    if ! cmp -s "$brash_stdout" "$bash_stdout"; then
        stdout_diff=stdout
    fi
    if ! cmp -s "$brash_stderr" "$bash_stderr"; then
        stderr_diff=stderr
    fi
    if [ "$brash_rc" -ne "$bash_rc" ]; then
        rc_diff=rc
    fi

    if [ -z "$stdout_diff" ] && [ -z "$stderr_diff" ] && [ -z "$rc_diff" ]; then
        printf "PASS: %s\n" "$name"
        passed=$((passed + 1))
        rm -rf "$sandbox"
        trap - EXIT
        continue
    fi

    reasons=$(printf '%s %s %s' "$stdout_diff" "$stderr_diff" "$rc_diff" | tr -s ' ' | sed 's/^ //;s/ $//')
    printf "FAIL: %s [%s]\n" "$name" "$reasons"
    failed=$((failed + 1))

    if [ -n "$VERBOSE" ]; then
        if [ -n "$stdout_diff" ]; then
            echo "  --- stdout diff (bash vs brash) ---"
            diff -u "$bash_stdout" "$brash_stdout" | sed 's/^/  /' | head -60
        fi
        if [ -n "$stderr_diff" ]; then
            echo "  --- stderr diff (bash vs brash) ---"
            diff -u "$bash_stderr" "$brash_stderr" | sed 's/^/  /' | head -30
        fi
        if [ -n "$rc_diff" ]; then
            printf "  --- rc  bash=%d  brash=%d ---\n" "$bash_rc" "$brash_rc"
        fi
    fi

    rm -rf "$sandbox"
    trap - EXIT
done

echo
printf "=== nixos corpus: %d passed, %d failed, %d hung / %d total (%d%% byte-identical) ===\n" \
    "$passed" "$failed" "$hung" "$total" $((passed * 100 / total))

if [ "$failed" -ne 0 ] || [ "$hung" -ne 0 ]; then
    exit 1
fi
exit 0
