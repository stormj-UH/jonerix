#!/usr/bin/env bash
# NixOS activation script: set up /etc symlinks idempotently.
# Mirrors nixos/modules/system/activation/activation-script.sh patterns.
set -euo pipefail

ROOT="${NIXOS_TEST_ROOT:-$PWD/root}"
mkdir -p "$ROOT"

ETC="$ROOT/etc"
NEW_ETC="$ROOT/new-etc"

mkdir -p "$ETC" "$NEW_ETC"

# Static /etc files for the new generation
declare -A etc_files=(
    ["hostname"]="nixos-test"
    ["locale.conf"]="LANG=en_US.UTF-8
LC_ALL=en_US.UTF-8"
    ["shells"]="/bin/sh
/bin/bash
/run/current-system/sw/bin/bash"
    ["nsswitch.conf"]="passwd:    files mymachines systemd
group:     files mymachines systemd
shadow:    files
hosts:     files mymachines dns myhostname
networks:  files
ethers:    files
services:  files
protocols: files"
    ["os-release"]='NAME="NixOS"
VERSION="23.11 (Tapir)"
ID=nixos
VERSION_CODENAME=tapir'
)

echo "=== preparing new-etc generation ==="
for name in "${!etc_files[@]}"; do
    echo "${etc_files[$name]}" > "$NEW_ETC/$name"
    echo "  staged: $name"
done | sort

echo
echo "=== activation: linking /etc files ==="

activated=0
unchanged=0
removed=0

# Activate each staged file
for name in $(ls "$NEW_ETC" | sort); do
    src="$NEW_ETC/$name"
    dst="$ETC/$name"

    if [ -L "$dst" ]; then
        current=$(readlink "$dst")
        if [ "$current" = "$src" ]; then
            echo "  skip (current): $name"
            unchanged=$((unchanged + 1))
            continue
        fi
        echo "  update: $name ($current -> $src)"
        ln -sf "$src" "$dst"
        activated=$((activated + 1))
    elif [ -f "$dst" ]; then
        # Regular file: back up and replace
        echo "  backup+replace: $name"
        cp "$dst" "$dst.bak"
        ln -sf "$src" "$dst"
        activated=$((activated + 1))
    else
        echo "  create: $name"
        ln -sf "$src" "$dst"
        activated=$((activated + 1))
    fi
done

echo
echo "=== verify /etc contents ==="
for name in $(ls "$NEW_ETC" | sort); do
    dst="$ETC/$name"
    if [ -L "$dst" ]; then
        echo "  OK (link): $name"
    else
        echo "  BAD: $name not a symlink"
    fi
done

echo
echo "=== idempotency: run activation again ==="
activated2=0
unchanged2=0
for name in $(ls "$NEW_ETC" | sort); do
    src="$NEW_ETC/$name"
    dst="$ETC/$name"
    if [ -L "$dst" ] && [ "$(readlink "$dst")" = "$src" ]; then
        unchanged2=$((unchanged2 + 1))
    else
        ln -sf "$src" "$dst"
        activated2=$((activated2 + 1))
    fi
done

echo "second pass: activated=$activated2 unchanged=$unchanged2"
[ "$activated2" -eq 0 ] && echo "  OK: fully idempotent"

echo
echo "=== read back key values ==="
echo "hostname:  $(cat "$ETC/hostname")"
echo "os-name:   $(grep '^NAME=' "$ETC/os-release" | cut -d= -f2)"

echo
echo "summary: activated=$activated unchanged=$unchanged"
echo "activation done"
