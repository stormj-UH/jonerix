#!/usr/bin/env bash
# NixOS-style propagated-build-inputs resolver.
# nixpkgs stores propagated deps in $out/nix-support/propagated-build-inputs
# and setup.sh walks the closure. This simulates that graph traversal.
set -euo pipefail

ROOT="${NIXOS_TEST_ROOT:-$PWD/root}"
mkdir -p "$ROOT"

STORE="$ROOT/store"

# Build a fake store: each pkg has a propagated-build-inputs file
# and an env-vars file that adds to PATH / PKG_CONFIG_PATH etc.

make_pkg() {
    local pkg=$1; shift
    local dir="$STORE/$pkg/nix-support"
    mkdir -p "$dir" "$STORE/$pkg/bin" "$STORE/$pkg/lib" "$STORE/$pkg/lib/pkgconfig"
    # propagated deps
    if [ $# -gt 0 ]; then
        echo "$@" | tr ' ' '\n' > "$dir/propagated-build-inputs"
    fi
    # env-vars contribution
    cat > "$dir/setup-hook.sh" <<EOF
addToSearchPath PATH "$STORE/$pkg/bin"
addToSearchPath PKG_CONFIG_PATH "$STORE/$pkg/lib/pkgconfig"
addToSearchPath LD_LIBRARY_PATH "$STORE/$pkg/lib"
EOF
    touch "$STORE/$pkg/bin/$pkg" "$STORE/$pkg/lib/lib${pkg}.so"
    cat > "$STORE/$pkg/lib/pkgconfig/${pkg}.pc" <<EOF
Name: $pkg
Version: 1.0
Libs: -L$STORE/$pkg/lib -l$pkg
Cflags: -I$STORE/$pkg/include
EOF
}

# Dependency graph:
#   myapp -> [openssl, zlib, glibc]
#   openssl -> [zlib, glibc]
#   zlib -> [glibc]
#   glibc -> []

make_pkg aaaa-glibc-2.35
make_pkg bbbb-zlib-1.2   aaaa-glibc-2.35
make_pkg cccc-openssl-3.0 bbbb-zlib-1.2 aaaa-glibc-2.35
make_pkg dddd-myapp-1.0  cccc-openssl-3.0 bbbb-zlib-1.2 aaaa-glibc-2.35

# Path accumulator (mimics addToSearchPath)
declare -A _path_sets=()

addToSearchPath() {
    local var=$1 val=$2
    local cur="${_path_sets[$var]:-}"
    # dedup
    case ":$cur:" in
        *":$val:"*) ;;
        *) _path_sets[$var]="${cur:+$cur:}$val" ;;
    esac
}

# BFS closure walk (mimics setup.sh's closureWalk)
declare -A _visited=()
_queue=()

enqueue_pkg() {
    local pkg=$1
    [ -n "${_visited[$pkg]:-}" ] && return
    _visited[$pkg]=1
    _queue+=("$pkg")
}

source_pkg() {
    local pkg=$1
    local hook="$STORE/$pkg/nix-support/setup-hook.sh"
    if [ -f "$hook" ]; then
        # source each hook line
        while IFS= read -r line; do
            eval "$line"
        done < "$hook"
    fi
}

walk_closure() {
    local root=$1
    enqueue_pkg "$root"

    local i=0
    while [ $i -lt ${#_queue[@]} ]; do
        local pkg="${_queue[$i]}"
        i=$((i + 1))

        echo "  processing: $pkg"
        source_pkg "$pkg"

        local inputs_file="$STORE/$pkg/nix-support/propagated-build-inputs"
        if [ -f "$inputs_file" ]; then
            while IFS= read -r dep; do
                [ -n "$dep" ] || continue
                enqueue_pkg "$dep"
            done < "$inputs_file"
        fi
    done
}

echo "=== walking closure from dddd-myapp-1.0 ==="
walk_closure dddd-myapp-1.0

echo
echo "=== resolved environment ==="
for var in PATH PKG_CONFIG_PATH LD_LIBRARY_PATH; do
    val="${_path_sets[$var]:-}"
    echo "$var="
    IFS=: read -ra parts <<< "$val"
    for p in "${parts[@]}"; do
        echo "  $p"
    done
done

echo
echo "=== verify all packages in closure ==="
expected=(aaaa-glibc-2.35 bbbb-zlib-1.2 cccc-openssl-3.0 dddd-myapp-1.0)
for pkg in "${expected[@]}"; do
    if [ -n "${_visited[$pkg]:-}" ]; then
        echo "  OK: $pkg"
    else
        echo "  MISS: $pkg"
    fi
done

echo
echo "propagated-build-inputs resolution done"
