#!/usr/bin/env bash
# NixOS-style multi-output split.
# nixpkgs multiple-outputs.sh moves bin/, share/, lib/, dev/ to separate
# output store paths and creates propagation stubs.
set -euo pipefail

ROOT="${NIXOS_TEST_ROOT:-$PWD/root}"
mkdir -p "$ROOT"

# Simulate a single "merged" build output
BUILD="$ROOT/build"
mkdir -p \
    "$BUILD/bin" \
    "$BUILD/lib" \
    "$BUILD/lib/pkgconfig" \
    "$BUILD/lib/cmake/TestPkg" \
    "$BUILD/include" \
    "$BUILD/share/doc/testpkg" \
    "$BUILD/share/man/man1" \
    "$BUILD/share/locale/en/LC_MESSAGES" \
    "$BUILD/share/testpkg" \
    "$BUILD/etc"

# Stub files
for b in testpkg testpkg-helper testpkg-ctl; do
    echo "#!/bin/sh" > "$BUILD/bin/$b"
    chmod +x "$BUILD/bin/$b"
done
echo "void testpkg_init(void){}" > "$BUILD/lib/libtestpkg.so.1"
ln -s "libtestpkg.so.1" "$BUILD/lib/libtestpkg.so"
cat > "$BUILD/lib/pkgconfig/testpkg.pc" <<'EOF'
Name: testpkg
Version: 1.0
Libs: -ltestpkg
Cflags: -I${includedir}
EOF
echo "include guard" > "$BUILD/include/testpkg.h"
echo "# TestPkg manual" > "$BUILD/share/man/man1/testpkg.1"
echo "copyright 2024" > "$BUILD/share/doc/testpkg/README"
echo "testpkg.po" > "$BUILD/share/locale/en/LC_MESSAGES/testpkg.mo"
echo "conffile" > "$BUILD/etc/testpkg.conf"

# Output directories: out, dev, doc, lib
outputs=(out dev doc lib)
declare -A out_dirs=(
    [out]="$ROOT/out"
    [dev]="$ROOT/dev"
    [doc]="$ROOT/doc"
    [lib]="$ROOT/lib"
)

for o in "${outputs[@]}"; do
    mkdir -p "${out_dirs[$o]}/nix-support"
done

# Movement rules (matches nixpkgs multiple-outputs.sh logic)
# Format: src_glob -> dest_output
move_to_output() {
    local src=$1 dest_name=$2
    local dest_dir="${out_dirs[$dest_name]}"
    local rel="${src#$BUILD/}"
    local dest_parent="$dest_dir/$(dirname "$rel")"
    mkdir -p "$dest_parent"
    mv "$src" "$dest_parent/"
    echo "  move [$dest_name]: $rel"
}

echo "=== multi-output split ==="

# dev output: includes, pkgconfig, cmake
echo "--- dev ---"
for f in $(find "$BUILD/include" -type f | sort); do
    move_to_output "$f" dev
done
for f in $(find "$BUILD/lib/pkgconfig" -type f | sort); do
    move_to_output "$f" dev
done
for f in $(find "$BUILD/lib/cmake" -type f | sort 2>/dev/null); do
    move_to_output "$f" dev
done

# doc output: share/doc, share/man
echo "--- doc ---"
for f in $(find "$BUILD/share/doc" -type f | sort); do
    move_to_output "$f" doc
done
for f in $(find "$BUILD/share/man" -type f | sort); do
    move_to_output "$f" doc
done

# lib output: libraries
echo "--- lib ---"
for f in $(find "$BUILD/lib" -maxdepth 1 \( -name '*.so*' -o -name '*.a' \) | sort); do
    move_to_output "$f" lib
done

# out output: everything remaining
echo "--- out (remainder) ---"
for f in $(find "$BUILD" -type f | sort); do
    move_to_output "$f" out
done

echo
echo "=== output manifests ==="
for o in "${outputs[@]}"; do
    dir="${out_dirs[$o]}"
    echo "[$o] $dir"
    find "$dir" -type f | grep -v nix-support | sort | sed 's|.*/'"$o"'/||' | sed 's/^/  /'
    # Write propagated outputs
    echo "${outputs[@]}" > "$dir/nix-support/propagated-build-inputs"
done

echo
echo "=== summary ==="
for o in "${outputs[@]}"; do
    count=$(find "${out_dirs[$o]}" -type f | grep -v nix-support | wc -l | tr -d ' ')
    echo "  $o: $count files"
done

echo
echo "multi-output split done"
