#!/usr/bin/env bash
# NixOS-style build hook: setup / configure / build / install phases.
# Deterministic: no timestamps, no random, no external deps.
set -euo pipefail

# ---------- phase infrastructure (mirrors nixpkgs stdenv) ----------

declare -a _phases=(setup configure build install)
currentPhase=

runPhase() {
    local phase=$1
    currentPhase=$phase
    echo "running phase: $phase"
    "$phase"Phase
    echo "phase done: $phase"
}

setupPhase() {
    echo "  [setup] creating build tree"
    mkdir -p "$TMPDIR/src" "$TMPDIR/build" "$TMPDIR/out/bin" "$TMPDIR/out/lib"
    echo "int main(void){ return 0; }" > "$TMPDIR/src/main.c"
    echo "void helper(void){}" > "$TMPDIR/src/helper.c"
    cat > "$TMPDIR/src/Makefile" <<'MAKEFILE'
all: main
main: main.c helper.c
	@echo "  CC main"
	@echo "(stub compile)"
helper.o: helper.c
	@echo "  CC helper.o"
MAKEFILE
}

configurePhase() {
    echo "  [configure] writing config.h"
    cat > "$TMPDIR/build/config.h" <<'EOF'
#define PACKAGE_NAME "testpkg"
#define PACKAGE_VERSION "1.0"
#define PREFIX "/nix/store/aaaa-testpkg"
EOF
    echo "  [configure] prefix=${PREFIX:-/nix/store/aaaa-testpkg}"
    echo "  [configure] features: ${NIX_FEATURES:-default}"
}

buildPhase() {
    echo "  [build] compiling sources"
    local src
    for src in "$TMPDIR/src"/*.c; do
        local base
        base=$(basename "$src" .c)
        echo "  CC $base.c -> $base.o"
    done
    echo "  LD main"
    touch "$TMPDIR/build/main"
}

installPhase() {
    echo "  [install] copying outputs"
    cp "$TMPDIR/build/main" "$TMPDIR/out/bin/testpkg"
    echo "  installed: $TMPDIR/out/bin/testpkg"
    local f
    for f in "$TMPDIR/out/bin"/*; do
        echo "  output: $(basename "$f")"
    done
}

# ---------- hook registration (mimics addToSearchPath etc.) ----------

declare -a _preConfigureHooks=()
declare -a _postConfigureHooks=()

addPreConfigureHook()  { _preConfigureHooks+=("$1"); }
addPostConfigureHook() { _postConfigureHooks+=("$1"); }

runHooks() {
    local hookVar=$1
    local hook
    eval "local -a hooks=(\"\${${hookVar}[@]}\")"
    for hook in "${hooks[@]}"; do
        echo "  hook: $hook"
        "$hook"
    done
}

checkHeaders() { echo "  [hook] checking headers"; }
stripDebug()   { echo "  [hook] stripping debug symbols (stub)"; }

addPreConfigureHook  checkHeaders
addPostConfigureHook stripDebug

# ---------- override configure to run hooks ----------

configurePhaseOrig=$(declare -f configurePhase)
configurePhase() {
    runHooks _preConfigureHooks
    eval "${configurePhaseOrig#configurePhaseOrig}"  # no-op; call inline
    configurePhase_inner
    runHooks _postConfigureHooks
}
configurePhase_inner() {
    echo "  [configure] writing config.h"
    cat > "$TMPDIR/build/config.h" <<'EOF'
#define PACKAGE_NAME "testpkg"
#define PACKAGE_VERSION "1.0"
#define PREFIX "/nix/store/aaaa-testpkg"
EOF
    echo "  [configure] prefix=${PREFIX:-/nix/store/aaaa-testpkg}"
    echo "  [configure] features: ${NIX_FEATURES:-default}"
}

# Redefine cleanly
configurePhase() {
    runHooks _preConfigureHooks
    configurePhase_inner
    runHooks _postConfigureHooks
}

# ---------- run all phases ----------
# Use a fixed subdir of $PWD (the runner's per-script sandbox) so paths are
# identical whether running under bash or brash.
TMPDIR="${NIXOS_TEST_ROOT:-$PWD}"/tmp
mkdir -p "$TMPDIR"

for phase in "${_phases[@]}"; do
    runPhase "$phase"
done

echo
echo "build complete"
