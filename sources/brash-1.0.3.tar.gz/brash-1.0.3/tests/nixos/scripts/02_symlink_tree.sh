#!/usr/bin/env bash
# NixOS-style symlink tree: ln -sf loops over a manifest.
# Mimics the linkFarm / symlinkJoin derivation pattern.
set -euo pipefail

ROOT="${NIXOS_TEST_ROOT:-$PWD/root}"
mkdir -p "$ROOT"

STORE="$ROOT/store/aaaa-pkg"
PROFILE="$ROOT/profile"

mkdir -p "$STORE/bin" "$STORE/lib" "$STORE/share/man/man1"
mkdir -p "$PROFILE/bin" "$PROFILE/lib" "$PROFILE/share/man/man1"

# Fake store entries
store_bins=(bash sh env cat ls grep sed awk)
for b in "${store_bins[@]}"; do
    touch "$STORE/bin/$b"
done
touch "$STORE/lib/libfoo.so.1"
touch "$STORE/lib/libbar.so.2"
touch "$STORE/share/man/man1/bash.1"

# Manifest: dest -> src  (tab-separated, sorted for determinism)
manifest=(
    "bin/bash    $STORE/bin/bash"
    "bin/sh      $STORE/bin/sh"
    "bin/env     $STORE/bin/env"
    "bin/cat     $STORE/bin/cat"
    "bin/ls      $STORE/bin/ls"
    "bin/grep    $STORE/bin/grep"
    "bin/sed     $STORE/bin/sed"
    "bin/awk     $STORE/bin/awk"
    "lib/libfoo.so.1   $STORE/lib/libfoo.so.1"
    "lib/libbar.so.2   $STORE/lib/libbar.so.2"
    "share/man/man1/bash.1  $STORE/share/man/man1/bash.1"
)

echo "=== creating symlink tree ==="
created=0
skipped=0
for entry in "${manifest[@]}"; do
    # split on whitespace
    dest=$(echo "$entry" | awk '{print $1}')
    src=$(echo "$entry" | awk '{print $2}')
    target="$PROFILE/$dest"

    if [ -L "$target" ] && [ "$(readlink "$target")" = "$src" ]; then
        echo "  skip (already linked): $dest"
        skipped=$((skipped + 1))
    else
        ln -sf "$src" "$target"
        echo "  link: $dest -> $src"
        created=$((created + 1))
    fi
done

echo
echo "=== verify links ==="
link_ok=0
link_bad=0
for entry in "${manifest[@]}"; do
    dest=$(echo "$entry" | awk '{print $1}')
    src=$(echo "$entry" | awk '{print $2}')
    target="$PROFILE/$dest"

    if [ -L "$target" ]; then
        actual=$(readlink "$target")
        if [ "$actual" = "$src" ]; then
            echo "  OK  $dest"
            link_ok=$((link_ok + 1))
        else
            echo "  BAD $dest -> $actual (expected $src)"
            link_bad=$((link_bad + 1))
        fi
    else
        echo "  MISSING $dest"
        link_bad=$((link_bad + 1))
    fi
done

echo
echo "=== idempotency check (re-run same manifest) ==="
created2=0
skipped2=0
for entry in "${manifest[@]}"; do
    dest=$(echo "$entry" | awk '{print $1}')
    src=$(echo "$entry" | awk '{print $2}')
    target="$PROFILE/$dest"

    if [ -L "$target" ] && [ "$(readlink "$target")" = "$src" ]; then
        skipped2=$((skipped2 + 1))
    else
        ln -sf "$src" "$target"
        created2=$((created2 + 1))
    fi
done

echo "second pass: created=$created2 skipped=$skipped2"

echo
echo "summary: created=$created skipped=$skipped ok=$link_ok bad=$link_bad"
