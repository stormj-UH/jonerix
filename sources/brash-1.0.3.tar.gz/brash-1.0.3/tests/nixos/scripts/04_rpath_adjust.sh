#!/usr/bin/env bash
# NixOS-style RPATH adjustment simulation.
# nixpkgs uses patchelf to rewrite RPATH; this script simulates the logic
# with text substitution on a fake ELF descriptor to keep it deterministic.
set -euo pipefail

ROOT="${NIXOS_TEST_ROOT:-$PWD/root}"
mkdir -p "$ROOT"

# Simulate an "elf descriptor" file (text representation of RPATH sections)
cat > "$ROOT/fake_elf.rpath" <<'EOF'
RPATH=/usr/lib:/usr/local/lib:/usr/lib/x86_64-linux-gnu
RUNPATH=/usr/lib:/usr/local/lib
NEEDED=libfoo.so.1
NEEDED=libbar.so.2
NEEDED=libc.so.6
EOF

# Store mappings: system path -> nix store path
declare -A store_map=(
    ["/usr/lib"]="/nix/store/aaaa-glibc-2.35/lib"
    ["/usr/local/lib"]="/nix/store/bbbb-openssl-3.0/lib"
    ["/usr/lib/x86_64-linux-gnu"]="/nix/store/cccc-zlib-1.2/lib"
)

# Dependency -> store derivation
declare -A dep_map=(
    ["libfoo.so.1"]="/nix/store/dddd-libfoo-1.0"
    ["libbar.so.2"]="/nix/store/eeee-libbar-2.0"
    ["libc.so.6"]="/nix/store/aaaa-glibc-2.35"
)

echo "=== original RPATH descriptor ==="
cat "$ROOT/fake_elf.rpath"

echo
echo "=== fixup phase: rewriting RPATHs ==="

# Read and rewrite each RPATH/RUNPATH line
new_rpath_parts=()
new_runpath_parts=()

while IFS= read -r line; do
    case "$line" in
        RPATH=*)
            rpath_val="${line#RPATH=}"
            IFS=: read -ra parts <<< "$rpath_val"
            for part in "${parts[@]}"; do
                mapped="${store_map[$part]:-}"
                if [ -n "$mapped" ]; then
                    echo "  RPATH: $part -> $mapped"
                    new_rpath_parts+=("$mapped")
                else
                    echo "  RPATH: $part (no mapping, keeping)"
                    new_rpath_parts+=("$part")
                fi
            done
            ;;
        RUNPATH=*)
            runpath_val="${line#RUNPATH=}"
            IFS=: read -ra parts <<< "$runpath_val"
            for part in "${parts[@]}"; do
                mapped="${store_map[$part]:-}"
                if [ -n "$mapped" ]; then
                    echo "  RUNPATH: $part -> $mapped"
                    new_runpath_parts+=("$mapped")
                else
                    echo "  RUNPATH: $part (no mapping, keeping)"
                    new_runpath_parts+=("$part")
                fi
            done
            ;;
    esac
done < "$ROOT/fake_elf.rpath"

echo
echo "=== resolving NEEDED libraries ==="
needed_paths=()
while IFS= read -r line; do
    case "$line" in
        NEEDED=*)
            lib="${line#NEEDED=}"
            store_path="${dep_map[$lib]:-MISSING}"
            echo "  $lib -> $store_path/lib/$lib"
            needed_paths+=("$store_path/lib")
            ;;
    esac
done < "$ROOT/fake_elf.rpath"

# Merge and deduplicate RPATH
declare -A seen=()
final_rpath=()
for p in "${new_rpath_parts[@]}" "${needed_paths[@]}"; do
    if [ -z "${seen[$p]:-}" ]; then
        final_rpath+=("$p")
        seen[$p]=1
    fi
done

# Build colon-separated string
IFS=: final_rpath_str="${final_rpath[*]}"

echo
echo "=== writing patched descriptor ==="
{
    echo "RPATH=$final_rpath_str"
    echo "RUNPATH=$(IFS=:; echo "${new_runpath_parts[*]}")"
    grep '^NEEDED=' "$ROOT/fake_elf.rpath"
} > "$ROOT/fake_elf_patched.rpath"

cat "$ROOT/fake_elf_patched.rpath"

echo
echo "=== verify no /usr paths remain in RPATH ==="
if grep -q '/usr/' "$ROOT/fake_elf_patched.rpath" 2>/dev/null; then
    remaining=$(grep '/usr/' "$ROOT/fake_elf_patched.rpath")
    echo "  WARN: still has /usr paths:"
    echo "$remaining" | sed 's/^/    /'
else
    echo "  OK: no /usr paths in RPATH/RUNPATH"
fi

echo
echo "fixup:rpath done"
