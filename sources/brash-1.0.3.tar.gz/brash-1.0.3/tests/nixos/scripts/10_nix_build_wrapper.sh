#!/usr/bin/env bash
# NixOS-style nix-build wrapper / build environment bootstrap.
# Simulates what the nix-build wrapper script does:
#   - sets up build environment variables
#   - sources setup hooks from dependencies
#   - runs genericBuild (all phases)
#   - handles buildInputs / nativeBuildInputs
set -euo pipefail

ROOT="${NIXOS_TEST_ROOT:-$PWD/root}"
mkdir -p "$ROOT"

STORE="$ROOT/store"
NIX_BUILD_TOP="$ROOT/build"
mkdir -p "$NIX_BUILD_TOP"

# Fake derivation attributes (would come from .drv in real nix)
name="testpkg-1.2.3"
version="1.2.3"
src="$STORE/src-aaaa/testpkg-1.2.3"
out="$ROOT/out/aaaa-testpkg-1.2.3"
dev="$ROOT/out/aaaa-testpkg-1.2.3-dev"
system="x86_64-linux"
builder="/nix/store/bash-5.2/bin/bash"

buildInputs=(
    "$STORE/aaaa-zlib-1.2"
    "$STORE/bbbb-openssl-3.0"
)
nativeBuildInputs=(
    "$STORE/cccc-cmake-3.27"
    "$STORE/dddd-pkg-config-0.29"
)

# Set up fake store entries with setup hooks
for pkg in "${buildInputs[@]}" "${nativeBuildInputs[@]}"; do
    pkgname=$(basename "$pkg")
    mkdir -p "$pkg/nix-support" "$pkg/bin" "$pkg/lib" "$pkg/lib/pkgconfig" "$pkg/include"
    cat > "$pkg/nix-support/setup-hook" <<EOF
# Setup hook for $pkgname
addToSearchPath PKG_CONFIG_PATH "$pkg/lib/pkgconfig"
addToSearchPath CMAKE_PREFIX_PATH "$pkg"
addToSearchPath CPATH "$pkg/include"
addToSearchPath LIBRARY_PATH "$pkg/lib"
echo "  [hook] sourced $pkgname"
EOF
done

mkdir -p "$src" "$out/bin" "$out/lib" "$out/share" "$dev/include" "$dev/lib/pkgconfig"

# Fake source
cat > "$src/CMakeLists.txt" <<'EOF'
cmake_minimum_required(VERSION 3.20)
project(testpkg VERSION 1.2.3)
add_executable(testpkg main.c)
install(TARGETS testpkg DESTINATION bin)
EOF
echo "int main(void){ return 0; }" > "$src/main.c"

# ---- setup.sh bootstrap simulation ----

declare -A _search_paths=()

addToSearchPath() {
    local var=$1 val=$2
    local cur="${_search_paths[$var]:-}"
    case ":$cur:" in
        *":$val:"*) ;;
        *) _search_paths[$var]="${cur:+$cur:}$val" ;;
    esac
}

echo "=== sourcing setup hooks ==="
all_inputs=("${buildInputs[@]}" "${nativeBuildInputs[@]}")
for pkg in "${all_inputs[@]}"; do
    hook="$pkg/nix-support/setup-hook"
    if [ -f "$hook" ]; then
        # Evaluate each line
        while IFS= read -r line; do
            # skip comments and blanks
            case "$line" in
                '#'*|'') continue ;;
                addToSearchPath*)
                    eval "$line"
                    ;;
                echo*)
                    eval "$line"
                    ;;
            esac
        done < "$hook"
    fi
done

echo
echo "=== build environment ==="
for var in PKG_CONFIG_PATH CMAKE_PREFIX_PATH CPATH LIBRARY_PATH; do
    val="${_search_paths[$var]:-}"
    echo "$var=${val:-(empty)}"
done

echo
echo "=== genericBuild ==="

echo "--- unpackPhase ---"
cp -r "$src" "$NIX_BUILD_TOP/src"
echo "  unpacked: $(ls "$NIX_BUILD_TOP/src")"
cd "$NIX_BUILD_TOP/src"

echo "--- patchPhase ---"
echo "  (no patches)"

echo "--- configurePhase ---"
echo "  cmake -DCMAKE_INSTALL_PREFIX=$out ."
echo "  (stub: writing build.ninja)"
cat > "$NIX_BUILD_TOP/src/build.ninja" <<EOF
rule CC
  command = gcc -c \$in -o \$out

rule LINK
  command = gcc \$in -o \$out

build testpkg.o: CC main.c
build testpkg: LINK testpkg.o
EOF

echo "--- buildPhase ---"
echo "  cmake --build . (stub)"
touch "$NIX_BUILD_TOP/src/testpkg"
echo "  built: testpkg"

echo "--- checkPhase ---"
echo "  ctest (stub): 0 tests, 0 failures"

echo "--- installPhase ---"
cp "$NIX_BUILD_TOP/src/testpkg" "$out/bin/testpkg"
echo "  installed: $out/bin/testpkg"

echo "--- fixupPhase ---"
# Simulate strip, patchelf, move-docs
echo "  strip: $out/bin/testpkg (stub)"
echo "  patchelf --set-rpath /nix/store/...: $out/bin/testpkg (stub)"
echo "  move: share/man -> $out/share/man"

echo
echo "=== output summary ==="
echo "name=$name"
echo "version=$version"
echo "out=$out"
find "$out" -type f | sort | sed "s|$out/||" | sed 's/^/  /'

echo
echo "nix-build wrapper done"
