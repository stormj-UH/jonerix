#!/usr/bin/env bash
# 09_compgen_combined_actions.sh — combining compgen actions.
# Tests: compgen -b -k (builtins+keywords), compgen -A (multiple actions via flags)

# builtins + keywords starting with "d"
compgen -b -k -- "d"

echo "---"

# keywords starting with "c"
compgen -k -- "c"

echo "---"

# builtins starting with "t"
compgen -b -- "t"

echo "---"

# builtins starting with "u"
compgen -b -- "u"

echo "---"

# keywords starting with "t"
compgen -k -- "t"

echo "---"

# All keywords (no prefix filter)
compgen -k
