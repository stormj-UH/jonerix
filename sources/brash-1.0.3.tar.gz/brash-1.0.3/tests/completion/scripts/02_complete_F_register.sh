#!/usr/bin/env bash
# 02_complete_F_register.sh — complete -F registers function-based completions.
# Tests: complete -F, complete -p, declare -F

# Define a completion function
_myapp_comp() {
    local cur="$2"
    case "$cur" in
        --*)
            COMPREPLY=(--help --version --verbose --debug --output)
            ;;
        *)
            COMPREPLY=(init build test deploy)
            ;;
    esac
}

# Register function-based completion
complete -F _myapp_comp myapp

# Verify registration
complete -p myapp

# Verify function exists
declare -F _myapp_comp

# Register another command with same function
complete -F _myapp_comp myapp2

# Print all registrations
complete -p myapp
complete -p myapp2
