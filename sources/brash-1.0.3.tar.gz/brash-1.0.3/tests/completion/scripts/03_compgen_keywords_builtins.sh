#!/usr/bin/env bash
# 03_compgen_keywords_builtins.sh — compgen enumerates keywords and builtins.
# Tests: compgen -k, compgen -b, compgen -A keyword, compgen -A builtin,
#        prefix filtering with --

# List keywords starting with "f"
compgen -k -- "f"

echo "---"

# List builtins starting with "e"
compgen -b -- "e"

echo "---"

# Combine: keywords and builtins starting with "e"
compgen -b -k -- "e"

echo "---"

# compgen -A keyword same as -k
compgen -A keyword -- "w"

echo "---"

# compgen -A builtin same as -b
compgen -A builtin -- "r"
