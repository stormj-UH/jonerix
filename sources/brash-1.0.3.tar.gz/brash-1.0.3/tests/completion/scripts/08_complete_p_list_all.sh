#!/usr/bin/env bash
# 08_complete_p_list_all.sh — complete -p lists all registered completions.
# Tests: complete -p (no args), complete -r, multiple registrations

# Register several completions
complete -W "add remove list" pkgtool
complete -F _inner_comp innerapp
complete -o nospace -W "http:// https:// ftp://" browser
complete -b mybuiltin_wrap
complete -a myalias_wrap

# List all registered completions (sorted for determinism)
complete -p | sort

echo "---"

# Remove one
complete -r pkgtool

# List remaining (sorted)
complete -p | sort
