#!/usr/bin/env bash
# 06_compgen_alias_setopt_shopt.sh — compgen enumerates aliases, setopts, shopts.
# Tests: compgen -A alias, compgen -A setopt, compgen -A shopt, compgen -A variable

# Create some aliases
alias myalias1='echo one'
alias myalias2='echo two'
alias myalias3='echo three'
alias other_alias='echo other'

# List aliases matching "my"
compgen -A alias -- "my"

echo "---"

# List aliases matching "other"
compgen -A alias -- "other"

echo "---"

# List setopts matching "noc"
compgen -A setopt -- "noc"

echo "---"

# List setopts matching "all"
compgen -A setopt -- "all"

echo "---"

# List shopts matching "ext"
compgen -A shopt -- "ext"

echo "---"

# List shopts matching "hist"
compgen -A shopt -- "hist"
