#!/usr/bin/env bash
# 05_complete_options.sh — complete with various -o options and shorthand actions.
# Tests: complete -o nospace, complete -o bashdefault, complete -o filenames,
#        multiple -o flags, shorthand action flags -a, -b, -c, -u, -v

# Test nospace option
complete -o nospace -W "foo/ bar/ baz/" pathcmd
complete -p pathcmd

echo "---"

# Test bashdefault option
complete -o bashdefault -W "alpha beta gamma" mybackup
complete -p mybackup

echo "---"

# Multiple options combined
complete -o nospace -o filenames -W "dir1/ dir2/ file1 file2" mymixed
complete -p mymixed

echo "---"

# Shorthand: -a (alias), -b (builtin), -c (command), -u (user), -v (variable)
complete -a aliascomplete
complete -p aliascomplete

echo "---"

complete -b builtincomplete
complete -p builtincomplete
