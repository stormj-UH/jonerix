#!/usr/bin/env bash
# 01_complete_W_register.sh — complete -W registers wordlist completions.
# Tests: complete -W, complete -p, complete -r
# Expected output is byte-identical between bash and brash.

# Register a wordlist completion
complete -W "start stop restart status reload" service

# Verify it was registered
complete -p service

# Overwrite it with a new wordlist
complete -W "on off toggle" service

# Verify the overwrite
complete -p service

# Remove the completion
complete -r service

# Verify empty (should print nothing)
complete -p service 2>&1 || true
