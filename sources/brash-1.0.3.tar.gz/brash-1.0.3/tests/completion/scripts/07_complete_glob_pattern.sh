#!/usr/bin/env bash
# 07_complete_glob_pattern.sh — complete -G (glob pattern) registration.
# Tests: complete -G, complete -p

# Register glob-based completion
complete -G "*.txt" texteditor
complete -p texteditor

echo "---"

# Register glob for multiple extensions via separate commands
complete -G "*.sh" shellscript
complete -p shellscript

echo "---"

# Register with -G combined with -W
complete -G "*.conf" -W "default custom advanced" configtool
complete -p configtool

echo "---"

# Register with -G and -o nospace
complete -G "*.log" -o nospace logreader
complete -p logreader

echo "---"

# Override a glob completion
complete -G "*.txt" myedit
complete -G "*.md" myedit
complete -p myedit
