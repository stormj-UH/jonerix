#!/usr/bin/env bash
# 10_comp_words_function.sh — completion function using COMP_WORDS/COMP_CWORD.
# Tests: complete -F with function reading COMP_WORDS/COMP_CWORD,
#        declare -F, compgen -A function

# Define a completion function that uses COMP_WORDS and COMP_CWORD
_mycli_complete() {
    local cur prev
    cur="${COMP_WORDS[COMP_CWORD]}"
    prev="${COMP_WORDS[COMP_CWORD-1]}"

    case "$prev" in
        --config|-c)
            COMPREPLY=(default production staging)
            return
            ;;
        --format|-f)
            COMPREPLY=(json yaml toml)
            return
            ;;
    esac

    case "$cur" in
        --*)
            COMPREPLY=(--help --version --config --format --verbose --dry-run)
            ;;
        -*)
            COMPREPLY=(-h -v -c -f -n)
            ;;
        *)
            COMPREPLY=(init run build test deploy clean)
            ;;
    esac
}

# Register for a command
complete -F _mycli_complete mycli

# Verify registration
complete -p mycli

echo "---"

# Verify function exists
declare -F _mycli_complete

echo "---"

# List functions matching "_mycli"
compgen -A function -- "_mycli"

echo "---"

# Define a second completion function
_git_simple() {
    COMPREPLY=(add commit push pull clone status log diff branch checkout)
}

complete -F _git_simple git_simple

# Both functions should appear
compgen -A function -- "_"
