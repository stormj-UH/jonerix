#!/usr/bin/env bash
# 04_compgen_function_variable.sh — compgen enumerates shell functions and variables.
# Tests: compgen -A function, compgen -A variable, declare -F

# Define some functions for testing
_alpha_completion() { COMPREPLY=(a b c); }
_beta_handler() { return 0; }
_gamma_proc() { echo "proc"; }

# List functions matching "_a"
compgen -A function -- "_a"

echo "---"

# List all our underscore functions
compgen -A function -- "_"

echo "---"

# Set some variables
_my_var1=hello
_my_var2=world
_other_var=test

# List variables matching "_my"
compgen -A variable -- "_my"

echo "---"

# declare -F shows function names
declare -F _alpha_completion
declare -F _beta_handler
