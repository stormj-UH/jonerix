#!/usr/bin/env bash
# tests/completion/run.sh — differential test of brash vs bash on completion builtins.
#
# Each script under tests/completion/scripts/ is sourced / executed under both
# bash and brash with an identical environment.  stdout, stderr, and exit code
# are diffed.  A "pass" means byte-identical output and matching exit codes.
#
# The scripts exercise:
#   01  complete -W (wordlist registration, -p, -r)
#   02  complete -F (function-based registration, declare -F)
#   03  compgen -k / -b / -A keyword / -A builtin with prefix filtering
#   04  compgen -A function / -A variable, declare -F
#   05  complete -o options (nospace, bashdefault, filenames) and shorthand actions
#   06  compgen -A alias / -A setopt / -A shopt
#   07  complete -G (glob pattern registration)
#   08  complete -p (list all), complete -r, multiple registrations
#   09  compgen combining -b -k flags
#   10  COMP_WORDS/COMP_CWORD usage inside completion functions
#
# Usage:
#   tests/completion/run.sh              # run all scripts
#   tests/completion/run.sh 01 03        # run only scripts 01 and 03 (prefix match)
#   BRASH_BIN=/path/to/brash tests/completion/run.sh
#   BASH_BIN=/path/to/bash  tests/completion/run.sh
#   VERBOSE=1 tests/completion/run.sh
#
# Output:
#   Per-script: PASS or FAIL <reason>
#   Summary: "<passed>/<total> byte-identical"
#   Exit 0 if all pass, 1 if any fail.

set -u

repo_root=$(cd "$(dirname "$0")/../.." && pwd)
scripts_dir="$repo_root/tests/completion/scripts"

BRASH_BIN="${BRASH_BIN:-$repo_root/target/release/brash}"
BASH_BIN="${BASH_BIN:-/opt/homebrew/bin/bash}"
[ -x "$BASH_BIN" ] || BASH_BIN=/bin/bash
TIMEOUT_SEC="${TIMEOUT_SEC:-10}"
VERBOSE="${VERBOSE:-}"

# ---------------------------------------------------------------------------
# Sanity checks
# ---------------------------------------------------------------------------
if [ ! -x "$BRASH_BIN" ]; then
    echo "ERROR: brash not found at $BRASH_BIN — run 'cargo build --release' first" >&2
    exit 2
fi
if [ ! -x "$BASH_BIN" ]; then
    echo "ERROR: bash not found at $BASH_BIN" >&2
    exit 2
fi

# ---------------------------------------------------------------------------
# Select scripts to run
# ---------------------------------------------------------------------------
if [ "$#" -gt 0 ]; then
    selected=()
    for arg in "$@"; do
        # Accept bare prefix (e.g. "01") or full path
        found=0
        for f in "$scripts_dir"/*.sh; do
            [ -f "$f" ] || continue
            name=$(basename "$f")
            case "$name" in
                "$arg"*) selected+=("$f"); found=1 ;;
            esac
        done
        if [ "$found" -eq 0 ]; then
            echo "WARN: no script matching '$arg' under $scripts_dir" >&2
        fi
    done
else
    selected=()
    for f in "$scripts_dir"/*.sh; do
        [ -f "$f" ] && selected+=("$f")
    done
fi

[ "${#selected[@]}" -eq 0 ] && { echo "no scripts to run"; exit 0; }

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
passed=0
failed=0
total=0

run_script() {
    local script="$1"
    local name
    name=$(basename "$script")
    total=$((total + 1))

    local tmp
    tmp=$(mktemp -d)
    local bash_out="$tmp/bash.out"
    local bash_err="$tmp/bash.err"
    local brash_out="$tmp/brash.out"
    local brash_err="$tmp/brash.err"

    # Run under bash
    local bash_rc=0
    if command -v timeout >/dev/null 2>&1; then
        timeout "$TIMEOUT_SEC" "$BASH_BIN" "$script" >"$bash_out" 2>"$bash_err" || bash_rc=$?
    else
        "$BASH_BIN" "$script" >"$bash_out" 2>"$bash_err" || bash_rc=$?
    fi

    # Run under brash
    local brash_rc=0
    if command -v timeout >/dev/null 2>&1; then
        timeout "$TIMEOUT_SEC" "$BRASH_BIN" "$script" >"$brash_out" 2>"$brash_err" || brash_rc=$?
    else
        "$BRASH_BIN" "$script" >"$brash_out" 2>"$brash_err" || brash_rc=$?
    fi

    # Compare exit codes
    if [ "$bash_rc" -ne "$brash_rc" ]; then
        printf "FAIL  %-45s  exit: bash=%d brash=%d\n" "$name" "$bash_rc" "$brash_rc"
        if [ -n "$VERBOSE" ]; then
            echo "  bash  stdout: $(cat "$bash_out")"
            echo "  brash stdout: $(cat "$brash_out")"
            echo "  bash  stderr: $(cat "$bash_err")"
            echo "  brash stderr: $(cat "$brash_err")"
        fi
        failed=$((failed + 1))
        rm -rf "$tmp"
        return
    fi

    # Compare stdout (byte-identical)
    if ! diff -q "$bash_out" "$brash_out" >/dev/null 2>&1; then
        printf "FAIL  %-45s  stdout differs\n" "$name"
        if [ -n "$VERBOSE" ]; then
            echo "  --- bash stdout"
            cat "$bash_out"
            echo "  --- brash stdout"
            cat "$brash_out"
            echo "  --- diff"
            diff "$bash_out" "$brash_out" || true
        fi
        failed=$((failed + 1))
        rm -rf "$tmp"
        return
    fi

    # Compare stderr (byte-identical)
    if ! diff -q "$bash_err" "$brash_err" >/dev/null 2>&1; then
        printf "FAIL  %-45s  stderr differs\n" "$name"
        if [ -n "$VERBOSE" ]; then
            echo "  --- bash stderr"
            cat "$bash_err"
            echo "  --- brash stderr"
            cat "$brash_err"
            echo "  --- diff"
            diff "$bash_err" "$brash_err" || true
        fi
        failed=$((failed + 1))
        rm -rf "$tmp"
        return
    fi

    printf "PASS  %s\n" "$name"
    passed=$((passed + 1))
    rm -rf "$tmp"
}

# ---------------------------------------------------------------------------
# Run
# ---------------------------------------------------------------------------
bash_ver=$("$BASH_BIN" --version 2>&1 | head -1)
brash_ver=$("$BRASH_BIN" --version 2>&1 | head -1)
echo "bash:  $BASH_BIN  ($bash_ver)"
echo "brash: $BRASH_BIN  ($brash_ver)"
echo "scripts: $scripts_dir"
echo ""

for script in "${selected[@]}"; do
    run_script "$script"
done

echo ""
echo "$passed/$total byte-identical"

[ "$failed" -eq 0 ]
