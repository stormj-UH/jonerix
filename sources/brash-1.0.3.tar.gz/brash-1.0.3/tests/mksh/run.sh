#!/bin/sh
# tests/mksh/run.sh — mksh-style POSIX subset differential corpus runner
#
# Runs each script in tests/mksh/scripts/ under brash and compares stdout
# against the pre-generated .expected file (produced by GNU bash as oracle).
#
# A "pass" means brash produces byte-identical stdout to the oracle.
#
# Usage:
#   ./tests/mksh/run.sh [--update] [--verbose] [pattern]
#
#   --update   Re-generate .expected files using GNU bash (the oracle)
#   --verbose  Show diffs on failure
#   pattern    Only run scripts matching this glob (e.g. "01_*")
#
# Oracle preference order:
#   1. /opt/homebrew/bin/bash  (macOS Homebrew — modern bash 5.x)
#   2. /usr/local/bin/bash
#   3. bash (in PATH)
#   4. /bin/bash
#
# Exit status: 0 if all pass, 1 if any fail.

set -u

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
SCRIPTS_DIR="$SCRIPT_DIR/scripts"

# ── locate brash ──────────────────────────────────────────────────────────────
BRASH="${BRASH:-$REPO_ROOT/target/release/brash}"
if [ ! -x "$BRASH" ]; then
    echo "ERROR: brash not found at $BRASH" >&2
    echo "Run: cargo build --release" >&2
    exit 1
fi

# ── locate oracle (GNU bash) ─────────────────────────────────────────────────
find_oracle() {
    for candidate in \
        /opt/homebrew/bin/bash \
        /usr/local/bin/bash \
        /bin/bash \
        bash; do
        if command -v "$candidate" > /dev/null 2>&1; then
            # Prefer bash 4+; warn if older but still use it
            echo "$candidate"
            return
        fi
    done
    echo ""
}

ORACLE="${ORACLE:-$(find_oracle)}"
if [ -z "$ORACLE" ]; then
    echo "ERROR: no bash oracle found" >&2
    exit 1
fi

# ── parse flags ───────────────────────────────────────────────────────────────
UPDATE=0
VERBOSE=0
PATTERN="*.sh"

for arg in "$@"; do
    case "$arg" in
        --update)  UPDATE=1  ;;
        --verbose) VERBOSE=1 ;;
        --*)       echo "Unknown flag: $arg" >&2; exit 1 ;;
        *)         PATTERN="$arg" ;;
    esac
done

# ── update expected files if requested ───────────────────────────────────────
if [ "$UPDATE" -eq 1 ]; then
    echo "Updating expected files using oracle: $ORACLE"
    count=0
    for f in "$SCRIPTS_DIR"/$PATTERN; do
        [ "${f%.sh}" = "$f" ] && continue
        [ -f "$f" ] || continue
        expected="${f%.sh}.expected"
        "$ORACLE" "$f" > "$expected" 2>/dev/null
        echo "  updated: $(basename "$expected")"
        count=$((count + 1))
    done
    echo "Updated $count expected files."
    exit 0
fi

# ── run tests ─────────────────────────────────────────────────────────────────
pass=0
fail=0
skip=0
total=0
fail_names=""

printf '\n%-45s %s\n' "TEST" "RESULT"
printf '%-45s %s\n' "$(printf '%0.s-' $(seq 1 45))" "------"

for f in "$SCRIPTS_DIR"/$PATTERN; do
    [ "${f%.sh}" = "$f" ] && continue   # skip non-.sh files
    [ -f "$f" ] || continue

    base="$(basename "$f" .sh)"
    expected="${f%.sh}.expected"
    total=$((total + 1))

    # Skip if no expected file
    if [ ! -f "$expected" ]; then
        printf '%-45s SKIP (no .expected)\n' "$base"
        skip=$((skip + 1))
        continue
    fi

    # Run brash, capture stdout (stderr deliberately discarded)
    actual="$("$BRASH" "$f" 2>/dev/null)"
    exp="$(cat "$expected")"

    if [ "$actual" = "$exp" ]; then
        printf '%-45s PASS\n' "$base"
        pass=$((pass + 1))
    else
        printf '%-45s FAIL\n' "$base"
        fail=$((fail + 1))
        fail_names="$fail_names $base"

        if [ "$VERBOSE" -eq 1 ]; then
            echo "  --- expected ---"
            echo "$exp"    | head -20 | sed 's/^/  < /'
            echo "  --- brash ---"
            echo "$actual" | head -20 | sed 's/^/  > /'
            echo "  --- diff (first 20 lines) ---"
            _tmpA=$(mktemp)
            _tmpB=$(mktemp)
            echo "$exp"    > "$_tmpA"
            echo "$actual" > "$_tmpB"
            diff "$_tmpA" "$_tmpB" | head -20 | sed 's/^/  /'
            rm -f "$_tmpA" "$_tmpB"
            echo ""
        fi
    fi
done

# ── summary ───────────────────────────────────────────────────────────────────
printf '\n%s\n' "════════════════════════════════════════════════"
printf 'Oracle:  %s\n' "$ORACLE"
printf 'Brash:   %s\n' "$BRASH"
printf 'Corpus:  mksh-style POSIX subset (ksh compatibility)\n'
printf 'Total:   %d  Pass: %d  Fail: %d  Skip: %d\n' \
    "$total" "$pass" "$fail" "$skip"

if [ "$total" -gt 0 ]; then
    pct=$(( (pass * 100) / total ))
    printf 'POSIX/ksh conformance: %d%%\n' "$pct"
fi

if [ "$fail" -gt 0 ]; then
    printf '\nFailing tests:\n'
    for name in $fail_names; do
        printf '  %s\n' "$name"
    done
fi
printf '%s\n\n' "════════════════════════════════════════════════"

# ── exit status ───────────────────────────────────────────────────────────────
[ "$fail" -eq 0 ]
