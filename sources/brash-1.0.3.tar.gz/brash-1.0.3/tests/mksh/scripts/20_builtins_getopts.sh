#!/bin/sh
# mksh corpus: getopts builtin

# Basic getopts
parse_opts() {
    OPTIND=1
    verbose=0
    output=""
    while getopts "vo:" opt; do
        case "$opt" in
            v) verbose=1 ;;
            o) output="$OPTARG" ;;
            ?) echo "unknown opt" ;;
        esac
    done
    echo "verbose=$verbose output=$output"
    shift $((OPTIND - 1))
    echo "remaining: $*"
}

parse_opts -v -o file.txt rest1 rest2
parse_opts -vo combined rest
parse_opts rest_only

# getopts with no options
parse_opts2() {
    OPTIND=1
    while getopts "ab" opt; do
        echo "opt: $opt"
    done
}
parse_opts2 -a -b -a

# OPTIND reset
OPTIND=1
set -- -x -y
while getopts "xy" o; do
    echo "got: $o"
done
