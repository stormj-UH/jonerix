#!/bin/sh
# mksh corpus: glob patterns in case and parameter expansion

# ? matches exactly one char
for s in a ab abc; do
    case "$s" in
        ?) echo "$s: one char" ;;
        ??) echo "$s: two chars" ;;
        *) echo "$s: more" ;;
    esac
done

# Character classes
for c in a1 b2 c3 d4 12; do
    case "$c" in
        [a-d][1-4]) echo "$c: letter+digit" ;;
        [0-9][0-9])  echo "$c: two digits"  ;;
        *)           echo "$c: other"        ;;
    esac
done

# Negated character class
for c in a b 1 2; do
    case "$c" in
        [!0-9]) echo "$c: not digit" ;;
        *)      echo "$c: digit"     ;;
    esac
done

# Pattern in parameter expansion
path=/usr/local/lib/libfoo.so.1.2
echo "${path##*/}"         # basename
echo "${path%.*}"          # strip last extension
echo "${path%%.*}"         # strip all extensions from /usr/...

# Glob in for loop (file system, use tmpdir)
tmpdir=$(mktemp -d)
trap 'rm -rf "$tmpdir"' EXIT
touch "$tmpdir/a.txt" "$tmpdir/b.txt" "$tmpdir/c.cfg"
count=0
for f in "$tmpdir"/*.txt; do
    [ -f "$f" ] && count=$((count+1))
done
echo "txt count: $count"
