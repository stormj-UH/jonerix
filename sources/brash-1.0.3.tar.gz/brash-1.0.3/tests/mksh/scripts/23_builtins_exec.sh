#!/bin/sh
# mksh corpus: exec builtin

# exec with redirect (doesn't replace process when used for redirect only)
tmpdir=$(mktemp -d)
trap 'rm -rf "$tmpdir"' EXIT

exec 4> "$tmpdir/fd4.txt"
echo "via fd4" >&4
exec 4>&-
cat "$tmpdir/fd4.txt"

# exec for input redirect
echo "input line" > "$tmpdir/input.txt"
exec 5< "$tmpdir/input.txt"
read line <&5
exec 5<&-
echo "read via fd5: $line"

# exec in subshell replaces that subshell's process
result=$(exec echo "exec replaced")
echo "$result"

# exec 3>&1 dup
exec 6>&1
echo "via fd6" >&6
exec 6>&-
