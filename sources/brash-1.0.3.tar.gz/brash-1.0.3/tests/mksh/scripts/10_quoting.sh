#!/bin/sh
# mksh corpus: quoting rules

# Single quotes: no expansion
echo 'no $expansion here'
echo 'no `backtick` either'

# Double quotes: expansion happens
var=hello
echo "value is $var"
echo "arith: $((2+2))"

# Double quotes preserve spaces in variable
msg="  spaced  "
echo "$msg"

# Backslash escaping
echo "newline: \n literal"
echo "tab: \t literal"
printf "newline: \n"
printf "tab: \t end\n"

# Word splitting with IFS
IFS=:
path="a:b:c"
for p in $path; do
    echo "path part: $p"
done
unset IFS

# Quoting prevents word splitting
IFS=:
items="x:y:z"
for i in "$items"; do
    echo "single item: $i"
done
unset IFS

# Empty string is a word
echo ${empty_var:-""}
args=""
set -- $args
echo "empty split: $#"
set -- "$args"
echo "quoted empty: $#"

# Backslash before newline continues line
result=foo\
bar
echo "$result"
