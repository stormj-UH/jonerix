#!/bin/sh
# mksh corpus: loops (for/while/until)

# For loop over word list
for item in a b c; do
    echo "item: $item"
done

# For loop over positional params
set -- x y z
for arg; do
    echo "arg: $arg"
done

# While loop
i=0
while [ "$i" -lt 5 ]; do
    echo "while: $i"
    i=$((i + 1))
done

# Until loop
j=5
until [ "$j" -eq 0 ]; do
    echo "until: $j"
    j=$((j - 1))
done

# Break from loop
for k in 1 2 3 4 5; do
    [ "$k" -eq 3 ] && break
    echo "k=$k"
done
echo "broke at 3"

# Continue in loop
for m in 1 2 3 4 5; do
    [ "$m" -eq 3 ] && continue
    echo "m=$m"
done

# Nested loops with break 2
outer=0
while [ "$outer" -lt 3 ]; do
    inner=0
    while [ "$inner" -lt 3 ]; do
        [ "$outer" -eq 1 ] && [ "$inner" -eq 1 ] && break 2
        echo "o=$outer i=$inner"
        inner=$((inner + 1))
    done
    outer=$((outer + 1))
done
echo "nested break done"
