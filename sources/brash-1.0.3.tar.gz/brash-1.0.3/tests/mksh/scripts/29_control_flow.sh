#!/bin/sh
# mksh corpus: if/elif/else, compound conditions

# Basic if
if true; then
    echo "true branch"
fi

# if/else
if false; then
    echo "should not print"
else
    echo "else branch"
fi

# if/elif/else
x=2
if [ "$x" -eq 1 ]; then
    echo "one"
elif [ "$x" -eq 2 ]; then
    echo "two"
else
    echo "other"
fi

# Nested if
a=yes
b=yes
if [ "$a" = "yes" ]; then
    if [ "$b" = "yes" ]; then
        echo "both yes"
    else
        echo "only a"
    fi
fi

# Short-circuit &&/||
true && echo "and true"
false && echo "should not" || echo "or fallback"

# String comparison in if
name=alice
if [ "$name" = "alice" ]; then
    echo "hello alice"
fi

# Arithmetic in if
n=10
if [ $((n % 2)) -eq 0 ]; then
    echo "$n is even"
fi

# if with command
if command -v ls > /dev/null 2>&1; then
    echo "ls available"
fi
