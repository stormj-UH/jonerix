#!/bin/sh
# mksh corpus: string operations via parameter expansion

# String length
s="hello world"
echo "${#s}"

# Concatenation (just expansion)
a=foo
b=bar
echo "${a}${b}"

# Case conversion via tr (POSIX portable)
echo "hello" | tr 'a-z' 'A-Z'
echo "WORLD" | tr 'A-Z' 'a-z'

# Trimming via parameter expansion
with_prefix="prefix_value"
echo "${with_prefix#prefix_}"

with_suffix="value_suffix"
echo "${with_suffix%_suffix}"

# Checking if string starts with prefix
check_prefix() {
    case "$1" in
        "$2"*) echo "starts with $2" ;;
        *)     echo "no prefix $2"   ;;
    esac
}
check_prefix "foobar" "foo"
check_prefix "foobar" "bar"

# Checking empty/nonempty
is_empty() {
    [ -z "$1" ] && echo "empty" || echo "nonempty"
}
is_empty ""
is_empty "x"

# Repeat a character via printf
printf '%0.s*' $(seq 1 5)
echo ""

# String contains via case
contains() {
    case "$1" in
        *"$2"*) echo "contains" ;;
        *)      echo "not contains" ;;
    esac
}
contains "foobar" "oba"
contains "foobar" "xyz"
