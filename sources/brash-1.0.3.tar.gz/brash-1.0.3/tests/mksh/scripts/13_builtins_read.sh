#!/bin/sh
# mksh corpus: read builtin

# Read a single line
echo "hello world" | read line
echo "line=[$line]"

# Read into multiple variables (splits on IFS)
echo "first second third" | read a b c
echo "a=$a b=$b c=$c"

# Read with leftover in last var
echo "one two three four" | read x rest
echo "x=$x rest=$rest"

# Read with custom IFS
IFS=: read f1 f2 f3 <<EOF
alpha:beta:gamma
EOF
echo "$f1 $f2 $f3"

# Read preserves leading/trailing if quoted properly
printf "  spaces  \n" | read trimmed
echo "trimmed=[$trimmed]"

# Read exit status: 0 on success
echo "data" | read var
echo "read exit: $?"

# Read from heredoc
read hd_line <<EOF
heredoc line
EOF
echo "hd=[$hd_line]"

# Read -r prevents backslash interpretation
printf 'back\\slash\n' | read -r raw
echo "raw=[$raw]"
