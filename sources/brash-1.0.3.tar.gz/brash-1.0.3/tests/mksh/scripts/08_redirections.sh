#!/bin/sh
# mksh corpus: redirections

tmpdir=$(mktemp -d)
trap 'rm -rf "$tmpdir"' EXIT

# Redirect stdout to file
echo "line1" > "$tmpdir/out.txt"
cat "$tmpdir/out.txt"

# Append to file
echo "line2" >> "$tmpdir/out.txt"
echo "line3" >> "$tmpdir/out.txt"
cat "$tmpdir/out.txt"

# Redirect stdin from file
echo "input content" > "$tmpdir/in.txt"
read line < "$tmpdir/in.txt"
echo "got: $line"

# Redirect stderr to /dev/null
( echo "ok" ; echo "err" >&2 ) 2>/dev/null

# Redirect both stdout and stderr to file
{ echo "out"; echo "err" >&2; } > "$tmpdir/both.txt" 2>&1
cat "$tmpdir/both.txt"

# Here-string via stdin pipe (POSIX compatible way)
echo "herestring test" | read hs
echo "hs=[${hs}]"

# Heredoc
cat <<'EOF'
literal $not_expanded
EOF

# Heredoc with variable expansion
name=world
cat <<EOF
hello ${name}
EOF

# Output redirection with exec
exec 3> "$tmpdir/fd3.txt"
echo "via fd3" >&3
exec 3>&-
cat "$tmpdir/fd3.txt"
