#!/bin/sh
# mksh corpus: multiline strings and handling

# printf with \n
printf "line1\nline2\nline3\n"

# Multiline variable (via heredoc capture)
text=$(cat <<EOF
first
second
third
EOF
)
echo "$text"

# Counting lines
echo "$text" | wc -l | tr -d ' \t'

# Iterating lines via while/read
echo "$text" | while read line; do
    echo ">> $line"
done

# printf to build a table
printf "%-10s %5s %5s\n" Name Score Grade
printf "%-10s %5d %5s\n" Alice 95 A
printf "%-10s %5d %5s\n" Bob   82 B
printf "%-10s %5d %5s\n" Carol 78 C

# Joining lines
joined=$(printf "%s\n" a b c | tr '\n' ',')
echo "${joined%,}"   # strip trailing comma
