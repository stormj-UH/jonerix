#!/bin/sh
# mksh corpus: local variables via subshell isolation
# (POSIX sh doesn't require 'local'; use bash's local since brash is bash-backed)

# bash 'local' keyword works in brash
outer_var=global

modify_local() {
    local outer_var=local_value
    echo "inside: $outer_var"
}
modify_local
echo "outside: $outer_var"

# local with no value preserves nothing from outer scope
local_test() {
    local mylocal
    echo "unset local: [${mylocal:-unset}]"
    mylocal=set
    echo "set local: $mylocal"
}
local_test
echo "after func: [${mylocal:-gone}]"

# Nested functions with local
outer_fn() {
    local x=outer
    inner_fn() {
        local x=inner
        echo "inner x: $x"
    }
    inner_fn
    echo "outer x: $x"
}
outer_fn

# local arithmetic
arith_fn() {
    local n=10
    n=$((n * 2))
    echo "local arith: $n"
}
arith_fn

# local array-like via set (POSIX-compatible)
# (using local for scalar only, since POSIX doesn't have arrays)
sum_fn() {
    local total=0
    for n in "$@"; do
        total=$((total + n))
    done
    echo "sum: $total"
}
sum_fn 1 2 3 4 5
