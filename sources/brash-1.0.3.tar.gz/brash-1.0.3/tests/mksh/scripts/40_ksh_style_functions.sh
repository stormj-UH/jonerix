#!/bin/sh
# mksh corpus: ksh-style function patterns and idioms

# ksh supports both styles; POSIX sh uses name() {}
# Using name() {} throughout (compatible with both ksh and POSIX sh)

# Stack-like idiom with functions
push() {
    eval "stack_${stack_size}=$1"
    stack_size=$((stack_size + 1))
}
pop() {
    [ "$stack_size" -gt 0 ] || { echo "empty stack"; return 1; }
    stack_size=$((stack_size - 1))
    eval "echo \$stack_${stack_size}"
    eval "unset stack_${stack_size}"
}

stack_size=0
push hello
push world
push "!"
echo "size: $stack_size"
pop; pop; pop

# Dispatch table via functions
cmd_start()  { echo "starting"; }
cmd_stop()   { echo "stopping"; }
cmd_status() { echo "status: running"; }

dispatch() {
    cmd="cmd_$1"
    if command -v "$cmd" > /dev/null 2>&1; then
        "$cmd"
    else
        echo "unknown command: $1"
    fi
}

dispatch start
dispatch stop
dispatch status
dispatch unknown

# Variadic function with shift
log() {
    level=$1; shift
    echo "[$level] $*"
}
log INFO "system started"
log WARN "low memory" "only 10mb left"
log ERROR "disk full"

# Function that returns a value via global
max() {
    if [ "$1" -ge "$2" ]; then
        RESULT=$1
    else
        RESULT=$2
    fi
}
max 7 3; echo "max(7,3)=$RESULT"
max 2 9; echo "max(2,9)=$RESULT"
