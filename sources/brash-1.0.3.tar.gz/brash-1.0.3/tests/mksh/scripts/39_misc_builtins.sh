#!/bin/sh
# mksh corpus: miscellaneous builtins (cd, pwd, true, false, colon, dot)

# true and false
true
echo "true: $?"
false
echo "false: $?"

# : (colon) is true
:
echo "colon: $?"

# : with arguments (ignored)
: ignored args here
echo "colon args: $?"

# pwd
current=$(pwd)
echo "pwd nonempty: $([ -n "$current" ] && echo yes)"

# cd and pwd
orig=$(pwd)
cd /tmp
echo "in tmp: $([ "$(pwd)" = "/tmp" ] && echo yes)"
cd "$orig"
echo "back: $([ "$(pwd)" = "$orig" ] && echo yes)"

# dot (.) to source
tmpdir=$(mktemp -d)
trap 'rm -rf "$tmpdir"' EXIT
echo 'sourced_var=from_source' > "$tmpdir/source_me.sh"
. "$tmpdir/source_me.sh"
echo "sourced: $sourced_var"

# readonly builtin
readonly RVAR=rval
echo "readonly: $RVAR"

# unalias (if any aliases set)
alias myalias=echo 2>/dev/null || true
unalias myalias 2>/dev/null || true
echo "unalias ok"

# times (just check it runs and outputs something)
times_out=$(times 2>&1)
echo "times ran: $([ -n "$times_out" ] && echo yes)"
