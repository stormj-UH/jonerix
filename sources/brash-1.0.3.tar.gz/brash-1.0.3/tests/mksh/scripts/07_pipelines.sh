#!/bin/sh
# mksh corpus: pipelines

# Basic pipeline
echo "hello world" | tr 'a-z' 'A-Z'

# Multi-stage pipeline
printf 'banana\napple\ncherry\n' | sort | head -2

# Pipeline exit status is last command
true | false
echo "pipe exit: $?"
false | true
echo "pipe exit: $?"

# Nested pipelines
echo "one two three" | tr ' ' '\n' | sort -r

# Pipeline with wc
printf 'a\nb\nc\nd\n' | wc -l | tr -d ' \t'
echo ""

# Pipeline with grep
printf 'foo\nbar\nbaz\nfoo2\n' | grep '^foo'

# Pipe into read
echo "key=value" | { read line; echo "read: $line"; }

# Pipeline feeding while loop
printf '1\n2\n3\n' | while read n; do
    echo "item $n"
done
