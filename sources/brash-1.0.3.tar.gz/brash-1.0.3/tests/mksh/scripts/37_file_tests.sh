#!/bin/sh
# mksh corpus: file test operators

tmpdir=$(mktemp -d)
trap 'rm -rf "$tmpdir"' EXIT

# Create test artifacts
echo "content" > "$tmpdir/regular"
mkdir "$tmpdir/subdir"
ln -s "$tmpdir/regular" "$tmpdir/symlink"
mkfifo "$tmpdir/fifo" 2>/dev/null || true

# -f regular file
[ -f "$tmpdir/regular" ] && echo "-f regular: yes"
[ -f "$tmpdir/subdir"  ] && echo "-f dir: yes" || echo "-f dir: no"

# -d directory
[ -d "$tmpdir/subdir"  ] && echo "-d subdir: yes"
[ -d "$tmpdir/regular" ] && echo "-d regular: yes" || echo "-d regular: no"

# -e exists
[ -e "$tmpdir/regular" ] && echo "-e regular: yes"
[ -e "$tmpdir/missing" ] && echo "-e missing: yes" || echo "-e missing: no"

# -s nonempty
[ -s "$tmpdir/regular" ] && echo "-s nonempty: yes"
echo -n "" > "$tmpdir/empty"
[ -s "$tmpdir/empty" ]   && echo "-s empty: yes" || echo "-s empty: no"

# -r readable (should be true for a file we created)
[ -r "$tmpdir/regular" ] && echo "-r readable: yes"

# -w writable
[ -w "$tmpdir/regular" ] && echo "-w writable: yes"

# -L symlink
[ -L "$tmpdir/symlink" ] && echo "-L symlink: yes"
[ -L "$tmpdir/regular" ] && echo "-L regular: yes" || echo "-L regular: no"

# -p fifo (only if mkfifo succeeded)
[ -p "$tmpdir/fifo" ] && echo "-p fifo: yes" || echo "-p fifo: no (or not supported)"
