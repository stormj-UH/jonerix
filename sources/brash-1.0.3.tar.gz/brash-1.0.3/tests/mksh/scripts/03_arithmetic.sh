#!/bin/sh
# mksh corpus: POSIX arithmetic expansion

echo $((1 + 2))
echo $((10 - 3))
echo $((4 * 5))
echo $((17 / 3))
echo $((17 % 3))

# Operator precedence
echo $((2 + 3 * 4))
echo $((2 * 3 + 4))

# Unary minus
echo $((-5 + 10))

# Parentheses
echo $(( (2 + 3) * 4 ))

# Bitwise
echo $((6 & 3))
echo $((6 | 3))
echo $((6 ^ 3))
echo $((~0))
echo $((1 << 3))
echo $((16 >> 2))

# Comparison returns 0 or 1
echo $((3 > 2))
echo $((2 > 3))
echo $((3 == 3))
echo $((3 != 4))

# Conditional (ternary)
echo $((1 ? 42 : 99))
echo $((0 ? 42 : 99))

# Variables in arithmetic
a=7
b=3
echo $((a + b))
echo $((a * b))
