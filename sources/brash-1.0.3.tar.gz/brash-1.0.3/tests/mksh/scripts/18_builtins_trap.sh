#!/bin/sh
# mksh corpus: trap builtin

# Trap EXIT
trap 'echo "EXIT trap fired"' EXIT

echo "before exit"

# Trap in subshell (does not affect parent)
( trap 'echo "sub EXIT"' EXIT; echo "in subshell" )

# Trap and reset
trap 'echo "INT handler"' INT
trap - INT   # reset INT
# (can't actually send INT in a test, just verify it didn't break)
echo "trap reset ok"

# Trap EXIT fires at end of script
echo "near end"
