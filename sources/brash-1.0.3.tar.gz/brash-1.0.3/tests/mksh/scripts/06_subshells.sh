#!/bin/sh
# mksh corpus: subshells and command grouping

# Subshell cannot modify parent environment
x=parent
(x=child)
echo "$x"

# Command substitution
out=$(echo hello; echo world)
echo "$out"

# Nested command substitution
inner=$(echo $(echo deep))
echo "$inner"

# Grouped commands with braces
{ echo a; echo b; echo c; } | while read line; do
    echo "got: $line"
done

# Subshell exit status
(exit 42)
echo "subshell exit: $?"

# Arithmetic in subshell
base=10
result=$( echo $(( base + 5 )) )
echo "$result"

# Subshell with cd doesn't affect parent
original_dir=$(pwd)
(cd /tmp)
echo "dir unchanged: $([ "$(pwd)" = "$original_dir" ] && echo yes || echo no)"

# Pipeline in subshell
count=$(printf 'a\nb\nc\n' | ( while read line; do echo "$line"; done ) | wc -l | tr -d ' ')
echo "lines: $count"
