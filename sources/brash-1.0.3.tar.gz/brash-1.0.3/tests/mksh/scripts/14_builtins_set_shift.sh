#!/bin/sh
# mksh corpus: set and shift builtins

# set positional params
set -- alpha beta gamma delta
echo "$1 $2 $3 $4"
echo "count: $#"

# shift by 1
shift
echo "after shift: $1 $2 $3"
echo "count: $#"

# shift by N
set -- a b c d e
shift 2
echo "shift 2: $1 $2 $3"

# set -e: exit on error (test in subshell)
result=$(set -e; echo before; true; echo after; )
echo "set-e ok: $result"

# set -- replaces all positional params
set -- one
set -- two three
echo "$1 $2"

# set with no args does not change positional params
set -- preserved
# (bare 'set' prints environment; skip that output as it's not portable)
echo "still: $1"

# $@ and $* behavior
set -- "a b" c d
echo "star: $*"
printf '"%s"\n' "$@"

# shift with $# = 0 should fail silently or not (POSIX says error; test in subshell)
set --
(shift 2>/dev/null; echo "shift on empty: $?") || echo "shift empty failed"
