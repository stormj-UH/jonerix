#!/bin/sh
# mksh corpus: function definitions and calls

# Basic function
greet() {
    echo "hello $1"
}
greet world

# Function with return value via exit status
is_even() {
    [ $(( $1 % 2 )) -eq 0 ]
}
is_even 4 && echo "4 is even"
is_even 3 && echo "3 is even" || echo "3 is odd"

# Function with local-equivalent (use subshell for isolation since POSIX doesn't guarantee local)
compute() {
    result=$(( $1 + $2 ))
    echo "$result"
}
echo $(compute 3 7)

# Recursive function
factorial() {
    if [ "$1" -le 1 ]; then
        echo 1
    else
        prev=$(factorial $(( $1 - 1 )))
        echo $(( $1 * prev ))
    fi
}
echo $(factorial 5)

# Function overrides another
say() { echo "first"; }
say() { echo "second"; }
say

# Positional params inside function don't leak out
set -- outer1 outer2
inside() {
    set -- inner1 inner2 inner3
    echo "inside: $1 $2 $3"
}
inside
echo "outside: $1 $2"
