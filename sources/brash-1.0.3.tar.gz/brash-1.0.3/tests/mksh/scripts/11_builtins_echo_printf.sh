#!/bin/sh
# mksh corpus: echo and printf builtins

# printf is portable
printf "hello\n"
printf "%s %s\n" foo bar
printf "%d\n" 42
printf "%05d\n" 7
printf "%-10s|\n" left
printf "%10s|\n" right
printf "%x\n" 255
printf "%o\n" 8
printf "%.3f\n" 3.14159

# printf with multiple args repeats format
printf "%s\n" a b c

# printf %b interprets backslash sequences
printf "%b\n" "line1\nline2"

# printf to variable (with command substitution)
out=$(printf "val=%d" 99)
echo "$out"

# echo basic
echo hello world

# echo with special chars (no flags, just literal output)
echo "tab	here"
