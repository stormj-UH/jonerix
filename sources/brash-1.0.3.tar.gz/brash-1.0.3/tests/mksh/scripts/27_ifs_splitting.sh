#!/bin/sh
# mksh corpus: IFS word splitting

# Default IFS (space, tab, newline)
str="one two three"
for w in $str; do
    echo "w=$w"
done

# Custom IFS colon
IFS=:
data="a:b:c"
for f in $data; do
    echo "f=$f"
done
unset IFS

# IFS as comma
IFS=,
csv="x,y,z"
set -- $csv
echo "$1 $2 $3"
unset IFS

# IFS with multiple chars (split on any of them)
IFS=":;"
mixed="a:b;c:d"
for v in $mixed; do
    echo "$v"
done
unset IFS

# Empty IFS: no splitting
IFS=""
nosplit="a b c"
for item in $nosplit; do
    echo "nosplit: $item"
done
unset IFS

# Null IFS splits into chars... actually POSIX: IFS="" means no splitting
# Verify via set --
IFS=""
val="abc"
set -- $val
echo "null IFS count: $#"
unset IFS

# Leading/trailing IFS whitespace ignored
IFS=" "
s="  hello  "
set -- $s
echo "trimmed: $1"
unset IFS
