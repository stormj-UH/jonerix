#!/bin/sh
# mksh corpus: arithmetic via $(()) and expr

# $(()) arithmetic
echo $((100 / 7))
echo $((100 % 7))
echo $((2 ** 10))

# Assignment inside $(())
x=5
echo $(( x += 3 ))
echo $x

# Increment idiom
i=0
i=$((i + 1))
i=$((i + 1))
echo "i=$i"

# Comparison
echo $((5 > 3))
echo $((5 < 3))
echo $((5 >= 5))
echo $((5 <= 4))
echo $((5 == 5))
echo $((5 != 4))

# Logical operators in arithmetic
echo $((1 && 1))
echo $((1 && 0))
echo $((0 || 1))
echo $((0 || 0))
echo $((! 0))
echo $((! 1))

# Hex and octal literals
echo $((0x1F))
echo $((0777))
echo $((2#1010))    # ksh/bash base-N: 1010 in binary = 10

# POSIX arithmetic uses let equivalent via $(())
a=10 b=20
echo $(( a > b ? a : b ))
