#!/bin/sh
# mksh corpus: environment and variable scoping

# Parent env is inherited by child
export PARENT_VAR=from_parent
result=$(sh -c 'echo $PARENT_VAR')
echo "inherited: $result"

# Unexported var not in child
LOCAL_ONLY=local
result2=$(sh -c 'echo "${LOCAL_ONLY:-not_inherited}"')
echo "not exported: $result2"

# Env override for single command
MY=original
MY=override sh -c 'echo $MY'
echo "parent unchanged: $MY"

# Multiple env assignments for single command
A=1 B=2 sh -c 'echo "$A $B"'

# Subshell sees current shell's vars (exported or not)
UNEXP=unexp_val
result3=$( echo "$UNEXP" )
echo "subshell sees: $result3"

# export -n removes export attribute but keeps var
export DEEXPORT=val
export -n DEEXPORT
# Var still accessible in this shell
echo "still here: $DEEXPORT"
# But child won't see it
result4=$(sh -c 'echo "${DEEXPORT:-gone}"')
echo "child sees: $result4"
