#!/bin/sh
# mksh corpus: exit and return builtins

# exit in subshell
(exit 0); echo "subshell exit 0: $?"
(exit 1); echo "subshell exit 1: $?"
(exit 42); echo "subshell exit 42: $?"

# return from function
myfunc() {
    echo "before return"
    return 5
    echo "after return (should not print)"
}
myfunc
echo "return status: $?"

# return 0 is success
ok_func() {
    return 0
}
ok_func && echo "return 0 is truthy"

# return non-zero is failure
fail_func() {
    return 1
}
fail_func || echo "return 1 is falsy"

# exit status propagates
run_sub() {
    (exit 7)
    return $?
}
run_sub
echo "propagated: $?"

# exit with $? (last status)
last_status_func() {
    false
    return $?
}
last_status_func
echo "last status: $?"
