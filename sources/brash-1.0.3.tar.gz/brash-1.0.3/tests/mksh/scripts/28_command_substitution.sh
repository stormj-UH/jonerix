#!/bin/sh
# mksh corpus: command substitution

# Basic $()
out=$(echo hello)
echo "$out"

# Nested command substitution
inner=$(echo $(echo nested))
echo "$inner"

# Command sub captures stdout only
result=$(echo stdout; echo stderr >&2)
echo "stdout only: $result"

# Command sub exit status (use var assignment — preserves $? from subshell)
x=$(true); echo "cmdsub true: $?"
x=$(false); echo "cmdsub false: $?"

# Command sub in arithmetic
n=$(echo 7)
echo $(( n * 6 ))

# Command sub with pipeline
words=$(printf 'c\nb\na\n' | sort)
echo "$words"

# Command sub preserves multi-line (trimmed trailing newlines)
multiline=$(printf 'line1\nline2\nline3')
echo "$multiline"

# Command sub with exit status in conditional
if result=$(echo "yes"); then
    echo "cmdsub in if: $result"
fi

# Backtick form (legacy but POSIX)
bt=`echo backtick`
echo "$bt"

# Nested backticks are awkward; use $() nesting instead
nested=$(echo $(echo deep))
echo "deep: $nested"
