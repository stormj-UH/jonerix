#!/bin/sh
# mksh corpus: error handling and exit status

# Boolean chaining
true && echo "true ok"
false || echo "false fallback"
true && false || echo "chain fallback"

# Exit status of compound commands
{ true; false; }
echo "group exit: $?"

{ false; true; }
echo "group exit2: $?"

# if tests exit status
if { echo "checking"; false; }; then
    echo "should not"
else
    echo "compound false"
fi

# Trap on ERR (bash extension, skip: POSIX doesn't require ERR trap)
# Instead test set -e behavior in subshell
(
    set -e
    echo "before"
    true
    echo "after true"
    # false would exit, but don't include that here
    echo "end"
)
echo "set-e subshell: $?"

# Pipestatus (bash-specific, skip)
# Test nested error
outer() {
    inner() { return 3; }
    inner
    return $?
}
outer
echo "nested return: $?"
