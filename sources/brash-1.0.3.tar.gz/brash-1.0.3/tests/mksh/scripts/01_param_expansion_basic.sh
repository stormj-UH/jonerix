#!/bin/sh
# mksh corpus: basic parameter expansion (POSIX subset)

x=hello
echo "${x}"

# Default value
echo "${undef:-default}"

# Default value - var is set but empty
empty=
echo "${empty:-fallback}"

# Assign default
echo "${newvar:=assigned}"
echo "${newvar}"

# Error if unset (suppress error by catching in subshell)
result=$(unset errvar; echo "${errvar:-ok_unset}")
echo "$result"

# Alternate value
set_var=yes
echo "${set_var:+alternate}"

# Unset var - alternate gives empty
echo "alt_unset=[${unset2:+should_not_appear}]"

# String length
str=abcdef
echo "${#str}"

# Length of unset is 0
echo "${#totally_unset}"
