#!/bin/sh
# mksh corpus: eval builtin

# Basic eval
eval "echo hello from eval"

# Eval with variable containing command
cmd="echo dynamic"
eval "$cmd"

# Eval builds and runs assignment
varname=myvar
eval "${varname}=42"
echo "$myvar"

# Eval with expansion
prefix=echo
eval "$prefix 'eval with prefix'"

# Eval processes multiple commands
eval "x=1; y=2; echo \$((x + y))"

# Eval with loop
eval 'for i in a b c; do echo $i; done'

# Eval exit status
eval "true"
echo "eval true: $?"
eval "false"
echo "eval false: $?"

# Eval in function
run_it() {
    eval "$1"
}
run_it "echo from function eval"
