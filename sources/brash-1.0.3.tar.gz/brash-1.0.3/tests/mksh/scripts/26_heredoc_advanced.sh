#!/bin/sh
# mksh corpus: heredoc variations

# Basic heredoc
cat <<EOF
line one
line two
EOF

# Heredoc with variable expansion
name=world
cat <<EOF
hello $name
EOF

# Heredoc with single-quoted delimiter (no expansion)
cat <<'EOF'
literal $name no expand
EOF

# Heredoc with dash (strip leading tabs)
cat <<-EOF
	tabbed line
	another tabbed
EOF

# Heredoc in a pipeline
cat <<EOF | tr 'a-z' 'A-Z'
lowercase text
EOF

# Heredoc as function argument
show() { cat; }
show <<EOF
function heredoc
EOF

# Multiple heredocs in sequence
cat <<EOF
first
EOF
cat <<EOF
second
EOF

# Heredoc with command substitution inside
val=$(cat <<EOF
captured
EOF
)
echo "val=$val"
