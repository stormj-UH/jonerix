#!/bin/sh
# mksh corpus: umask builtin

# Save and restore umask
old=$(umask)
echo "umask is set (not empty): $([ -n "$old" ] && echo yes)"

# Set umask and verify
umask 022
new=$(umask)
echo "umask 022: $new"

# Set symbolic umask
umask u=rwx,g=rx,o=rx
sym=$(umask)
echo "symbolic umask set: $([ -n "$sym" ] && echo yes)"

# Restore
umask "$old"
restored=$(umask)
echo "restored: $([ "$restored" = "$old" ] && echo yes)"

# umask -S gives symbolic form
umask 022
sym=$(umask -S)
echo "umask -S nonempty: $([ -n "$sym" ] && echo yes)"
