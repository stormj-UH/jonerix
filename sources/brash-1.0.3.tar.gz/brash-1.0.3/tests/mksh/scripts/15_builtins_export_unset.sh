#!/bin/sh
# mksh corpus: export, unset, readonly

# export makes var available to subprocesses
MY_VAR=hello
export MY_VAR
result=$(sh -c 'echo $MY_VAR')
echo "exported: $result"

# unset removes variable
foo=bar
unset foo
echo "unset: [${foo:-gone}]"

# export with assignment
export COMBO=combined
result2=$(sh -c 'echo $COMBO')
echo "combo: $result2"

# readonly prevents modification
readonly CONST=fixed
(CONST=changed 2>/dev/null; echo "still: $CONST")
echo "const: $CONST"

# unset of readonly should fail
(unset CONST 2>/dev/null; echo "${CONST:-unset}")
echo "after attempted unset: $CONST"

# export -p lists exports (just check it runs)
export TESTX=testval
export -p | grep TESTX | grep -c testval | tr -d ' '

# env inherits exports
export MYENV=myval
sh -c 'echo "env: $MYENV"'
