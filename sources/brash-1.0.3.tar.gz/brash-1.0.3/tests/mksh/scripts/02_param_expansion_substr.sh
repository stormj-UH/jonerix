#!/bin/sh
# mksh corpus: substring removal (POSIX subset)

path=/usr/local/bin/prog

# Remove shortest prefix matching pattern
echo "${path#/*/}"

# Remove longest prefix matching pattern
echo "${path##/*/}"

# Remove shortest suffix
echo "${path%/*}"

# Remove longest suffix
echo "${path%%/*}"

# Multiple ops
file=archive.tar.gz
echo "${file%.gz}"
echo "${file%%.*}"

# With positional params
set -- /home/user/doc.txt
echo "${1##*/}"
echo "${1%/*}"

# Prefix removal on variable containing wildcard chars in value
s="aabbc"
echo "${s#a}"
echo "${s##a*b}"
