#!/bin/sh
# mksh corpus: parameter expansion with error/message forms

# ${var:?msg} - error if unset or empty (catch in subshell)
result=$(VAR=set; echo "${VAR:?error}")
echo "set var: $result"

# ${var:?} without message (subshell catches error)
result2=$(V2=hello; echo "${V2:?}")
echo "no-msg var: $result2"

# Unset triggers error (subshell, so no exit)
(unset MISSING; echo "${MISSING:?missing!}" 2>/dev/null) || echo "caught error"

# ${var:-} with empty gives empty
EMPTY=""
echo "empty default: [${EMPTY:-}]"

# ${var:=} assigns if unset/empty
unset ASSIGNME
: ${ASSIGNME:=defaultval}
echo "assigned: $ASSIGNME"

# ${var:+} only if set and nonempty
SET=yes
echo "alt: ${SET:+replacement}"
NOTSET=""
echo "empty alt: [${NOTSET:+replacement}]"

# Nesting expansions
inner=hello
outer=${inner:-fallback}
echo "nested: $outer"

# ${#@} and ${#*} count positional params
set -- a b c d e
echo "len @: ${#@}"

# Indirect via eval (no nameref in POSIX)
varA=hello
pname=varA
eval "echo \${$pname}"
