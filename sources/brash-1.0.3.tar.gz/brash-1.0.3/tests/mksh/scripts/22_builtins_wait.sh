#!/bin/sh
# mksh corpus: wait builtin

# Wait for background job
(echo "bg job done") &
wait
echo "after wait"

# Wait for specific PID
(sleep 0.1; echo "pid job") &
pid=$!
wait $pid
echo "waited for pid: $?"

# Wait captures exit status of background job
(exit 5) &
wait $!
echo "bg exit: $?"

# Multiple background jobs
for i in 1 2 3; do
    (echo "job $i") &
done
wait
echo "all jobs done"
