#!/bin/sh
# mksh corpus: test / [ builtin

# String tests
[ "hello" = "hello" ] && echo "str eq"
[ "hello" != "world" ] && echo "str ne"
[ -n "nonempty" ] && echo "str nonempty"
[ -z "" ] && echo "str empty"
[ -z "$unset_v" ] && echo "unset is empty"

# Numeric tests
[ 5 -eq 5 ] && echo "eq"
[ 5 -ne 4 ] && echo "ne"
[ 5 -gt 4 ] && echo "gt"
[ 5 -ge 5 ] && echo "ge"
[ 4 -lt 5 ] && echo "lt"
[ 5 -le 5 ] && echo "le"

# File tests
tmpdir=$(mktemp -d)
trap 'rm -rf "$tmpdir"' EXIT

echo content > "$tmpdir/f"
[ -f "$tmpdir/f" ] && echo "is file"
[ -d "$tmpdir" ]   && echo "is dir"
[ -e "$tmpdir/f" ] && echo "exists"
[ -s "$tmpdir/f" ] && echo "nonempty file"
[ ! -f "$tmpdir/noexist" ] && echo "noexist not file"

# Compound tests
[ 1 -eq 1 ] && [ 2 -eq 2 ] && echo "both true"
[ 1 -eq 2 ] || [ 2 -eq 2 ] && echo "second true"

# Test with [[ not used (POSIX only)
a=abc
[ "$a" = "abc" ] && echo "bracket eq"

# Negation
[ ! 1 -eq 2 ] && echo "not eq"
