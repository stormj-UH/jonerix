#!/bin/sh
# mksh corpus: case statement and pattern matching

val=foo
case "$val" in
    foo) echo "matched foo" ;;
    bar) echo "matched bar" ;;
    *)   echo "default"     ;;
esac

# Glob patterns
for word in cat bat rat hat; do
    case "$word" in
        [cb]at) echo "$word: c or b at" ;;
        *at)    echo "$word: ends at"   ;;
        *)      echo "$word: other"     ;;
    esac
done

# Multiple patterns with |
for x in yes no maybe; do
    case "$x" in
        yes|no) echo "$x: boolean" ;;
        *)      echo "$x: unknown" ;;
    esac
done

# Numeric string matching
for n in 1 2 3 10; do
    case "$n" in
        [123]) echo "$n: single digit 1-3" ;;
        *)     echo "$n: other"            ;;
    esac
done

# Empty case (no match)
case "xyz" in
    abc) echo "matched" ;;
esac
echo "after empty case"
