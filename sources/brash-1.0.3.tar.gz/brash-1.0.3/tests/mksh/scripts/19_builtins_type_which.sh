#!/bin/sh
# mksh corpus: type builtin

# type for a builtin
type echo | grep -i 'builtin\|echo' | head -1 | grep -q 'echo' && echo "echo is known"

# type for an external command
type ls | grep -q 'ls' && echo "ls is known"

# type for a function
myfn() { echo "fn"; }
type myfn | grep -q 'function\|myfn' && echo "myfn is known"

# type exit status for unknown command
type __no_such_command_xyz__ 2>/dev/null
echo "unknown type exit: $?"

# command -v as POSIX alternative to type
command -v echo | grep -q 'echo' && echo "command -v echo works"

# command -v for function
command -v myfn | grep -q 'myfn' && echo "command -v myfn works"

# command runs without function lookup
myfn() { echo "overridden"; }
command echo "command bypasses functions: running echo"
