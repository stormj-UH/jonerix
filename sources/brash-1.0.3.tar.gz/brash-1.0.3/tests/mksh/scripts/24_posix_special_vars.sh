#!/bin/sh
# mksh corpus: special variables

# $$ is current PID (positive integer)
echo "pid positive: $([ $$ -gt 0 ] && echo yes)"

# $! is PID of last background job
(true) &
last=$!
echo "bg pid positive: $([ $last -gt 0 ] && echo yes)"
wait

# $? captures exit status
true;  echo "true: $?"
false; echo "false: $?"
(exit 7); echo "exit7: $?"

# $# count of positional params
set -- a b c d
echo "count: $#"

# $0 is script name (not empty)
echo "0 nonempty: $([ -n "$0" ] && echo yes)"

# $@ expands each param separately
set -- "a b" c
count=0
for p in "$@"; do
    count=$((count + 1))
done
echo "at count: $count"

# $* with IFS joins
IFS=,
set -- x y z
echo "$*"
unset IFS

# $- contains active flags
echo "flags nonempty: $([ -n "$-" ] && echo yes)"
