#!/bin/sh
# mksh corpus: positional parameters

set -- one two three four five

echo "$1"
echo "$2"
echo "${10:-none}"   # $10 - POSIX requires braces for 10+

# $# count
echo "count: $#"

# $* all as one word
echo "$*"

# $@ each separately
for p in "$@"; do
    echo "p=$p"
done

# shift
set -- a b c d e
shift
echo "after shift: $1 $# params"

shift 2
echo "after shift 2: $1 $# params"

# $@ with spaces in params
set -- "hello world" "foo bar" baz
echo "count with spaces: $#"
for p in "$@"; do
    echo "[$p]"
done

# ${@:2} not POSIX; use shift or positional tricks
# Instead: loop with index
set -- p q r s
n=2
i=0
for p in "$@"; do
    i=$((i+1))
    [ "$i" -ge "$n" ] && echo "from$n: $p"
done
