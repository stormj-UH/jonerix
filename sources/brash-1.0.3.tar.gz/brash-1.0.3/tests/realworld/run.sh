#!/usr/bin/env bash
# tests/realworld/run.sh — differential test of brash vs bash on real shell scripts.
#
# Each script under tests/realworld/scripts/ is invoked under both shells with
# identical environment.  Stdout, stderr, and exit code are diffed.  A "pass"
# means byte-identical output and matching exit codes.
#
# Usage:
#   tests/realworld/run.sh           # run all scripts
#   tests/realworld/run.sh foo bar   # run only foo.sh and bar.sh (without .sh suffix)
#   BRASH_BIN=/path/to/brash tests/realworld/run.sh
#   BASH_BIN=/path/to/bash tests/realworld/run.sh
#   VERBOSE=1 tests/realworld/run.sh
#
# Output:
#   Per-script: PASS, FAIL <reason>, or HANG
#   Summary line: "<passed>/<total> byte-identical"
#   Exit 0 if all pass, 1 if any fail/hang.

set -u

repo_root=$(cd "$(dirname "$0")/../.." && pwd)
scripts_dir="$repo_root/tests/realworld/scripts"

BRASH_BIN="${BRASH_BIN:-$repo_root/target/release/brash}"
BASH_BIN="${BASH_BIN:-/opt/homebrew/bin/bash}"
[ -x "$BASH_BIN" ] || BASH_BIN=/bin/bash
TIMEOUT_SEC="${TIMEOUT_SEC:-30}"
VERBOSE="${VERBOSE:-}"

if [ ! -x "$BRASH_BIN" ]; then
    echo "ERROR: brash not found at $BRASH_BIN — run 'cargo build --release' first" >&2
    exit 2
fi
if [ ! -x "$BASH_BIN" ]; then
    echo "ERROR: bash not found at $BASH_BIN" >&2
    exit 2
fi

# pick which scripts to run
if [ "$#" -gt 0 ]; then
    selected=()
    for arg in "$@"; do
        path="$scripts_dir/$arg.sh"
        [ -f "$path" ] || path="$scripts_dir/$arg"
        if [ -f "$path" ]; then
            selected+=("$path")
        else
            echo "WARN: no script $arg under $scripts_dir" >&2
        fi
    done
else
    selected=()
    for f in "$scripts_dir"/*.sh; do
        [ -f "$f" ] && selected+=("$f")
    done
fi

[ ${#selected[@]} -eq 0 ] && { echo "no scripts to run"; exit 0; }

passed=0
failed=0
hung=0
total=${#selected[@]}

# locate timeout binary (gtimeout on macOS)
if command -v timeout >/dev/null 2>&1; then
    TIMEOUT_CMD=timeout
elif command -v gtimeout >/dev/null 2>&1; then
    TIMEOUT_CMD=gtimeout
else
    TIMEOUT_CMD=
fi

run_with_timeout() {
    if [ -n "$TIMEOUT_CMD" ]; then
        "$TIMEOUT_CMD" "$TIMEOUT_SEC" "$@"
    else
        "$@"
    fi
}

for script in "${selected[@]}"; do
    name=$(basename "$script" .sh)
    sandbox=$(mktemp -d)
    trap 'rm -rf "$sandbox"' EXIT

    # Run brash
    brash_stdout="$sandbox/brash.stdout"
    brash_stderr="$sandbox/brash.stderr"
    (cd "$sandbox" && env -i HOME="$HOME" PATH="/usr/bin:/bin:/usr/local/bin:/opt/homebrew/bin" \
        TMPDIR="${TMPDIR:-/tmp}" run_with_timeout "$BRASH_BIN" "$script") \
        > "$brash_stdout" 2> "$brash_stderr"
    brash_rc=$?

    # Run bash
    bash_stdout="$sandbox/bash.stdout"
    bash_stderr="$sandbox/bash.stderr"
    (cd "$sandbox" && env -i HOME="$HOME" PATH="/usr/bin:/bin:/usr/local/bin:/opt/homebrew/bin" \
        TMPDIR="${TMPDIR:-/tmp}" run_with_timeout "$BASH_BIN" "$script") \
        > "$bash_stdout" 2> "$bash_stderr"
    bash_rc=$?

    if [ "$brash_rc" -eq 124 ] || [ "$bash_rc" -eq 124 ]; then
        printf "HANG: %s (brash_rc=%d bash_rc=%d)\n" "$name" "$brash_rc" "$bash_rc"
        hung=$((hung + 1))
        continue
    fi

    stdout_diff=
    stderr_diff=
    rc_diff=
    if ! cmp -s "$brash_stdout" "$bash_stdout"; then
        stdout_diff=stdout
    fi
    if ! cmp -s "$brash_stderr" "$bash_stderr"; then
        stderr_diff=stderr
    fi
    if [ "$brash_rc" -ne "$bash_rc" ]; then
        rc_diff=rc
    fi

    if [ -z "$stdout_diff" ] && [ -z "$stderr_diff" ] && [ -z "$rc_diff" ]; then
        printf "PASS: %s\n" "$name"
        passed=$((passed + 1))
        rm -rf "$sandbox"
        trap - EXIT
        continue
    fi

    reasons=$(echo "$stdout_diff $stderr_diff $rc_diff" | tr -s ' ')
    printf "FAIL: %s [%s]\n" "$name" "$reasons"
    failed=$((failed + 1))

    if [ -n "$VERBOSE" ]; then
        if [ -n "$stdout_diff" ]; then
            echo "  --- stdout diff ---"
            diff -u "$bash_stdout" "$brash_stdout" | sed 's/^/  /' | head -40
        fi
        if [ -n "$stderr_diff" ]; then
            echo "  --- stderr diff ---"
            diff -u "$bash_stderr" "$brash_stderr" | sed 's/^/  /' | head -40
        fi
        if [ -n "$rc_diff" ]; then
            echo "  --- rc bash=$bash_rc brash=$brash_rc ---"
        fi
    fi

    rm -rf "$sandbox"
    trap - EXIT
done

echo
printf "=== %d passed, %d failed, %d hung, %d total — %d%% byte-identical ===\n" \
    "$passed" "$failed" "$hung" "$total" $((passed * 100 / total))

if [ "$failed" -ne 0 ] || [ "$hung" -ne 0 ]; then
    exit 1
fi
exit 0
