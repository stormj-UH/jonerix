#!/usr/bin/env bash
# tests/realworld/popular/run.sh — differential test of brash vs bash on
# popular real-world shell scripts found on macOS developer machines.
#
# Each entry is a (script_path, args...) tuple referencing an absolute path
# to a shell script already installed on the system.  The script is invoked
# under both bash and brash with a clean environment; stdout, stderr, and exit
# code are compared byte-for-byte.  A "pass" means all three are identical.
#
# Usage:
#   tests/realworld/popular/run.sh           # run all entries
#   BRASH_BIN=/path/to/brash tests/realworld/popular/run.sh
#   BASH_BIN=/path/to/bash  tests/realworld/popular/run.sh
#   VERBOSE=1               tests/realworld/popular/run.sh
#
# Entries are skipped (not failed) when the referenced script does not exist
# on the current system — allowing the suite to run portably.
#
# Output:
#   Per-entry: PASS, FAIL <reason>, SKIP, or HANG
#   Summary:   "<passed>/<eligible> byte-identical  (<skipped> skipped)"
#   Exit 0 if all eligible entries pass, 1 if any fail or hang.

set -u

repo_root=$(cd "$(dirname "$0")/../../.." && pwd)

BRASH_BIN="${BRASH_BIN:-$repo_root/target/release/brash}"
BASH_BIN="${BASH_BIN:-/opt/homebrew/bin/bash}"
[ -x "$BASH_BIN" ] || BASH_BIN=/bin/bash
TIMEOUT_SEC="${TIMEOUT_SEC:-5}"
VERBOSE="${VERBOSE:-}"

if [ ! -x "$BRASH_BIN" ]; then
    echo "ERROR: brash not found at $BRASH_BIN — run 'cargo build --release' first" >&2
    exit 2
fi
if [ ! -x "$BASH_BIN" ]; then
    echo "ERROR: bash not found at $BASH_BIN" >&2
    exit 2
fi

# ---------------------------------------------------------------------------
# Corpus: space-separated  script_path  arg1 arg2 ...
# Each line is one test entry.  The script_path must be an absolute path to
# a shell script already installed on the system; if absent the entry is
# skipped.  Args must be deterministic (no PIDs, timestamps, $HOME paths).
# ---------------------------------------------------------------------------
ENTRIES=(
    # Homebrew package manager launcher
    "/opt/homebrew/bin/brew --version"

    # GNU bash bug-reporting helper (installed with Homebrew bash)
    "/opt/homebrew/bin/bashbug --version"

    # pyenv — popular Python version manager (shell script launcher)
    "/opt/homebrew/bin/pyenv --version"

    # pyenv commands subcommand — prints sorted list of available commands
    "/opt/homebrew/bin/pyenv commands"

    # OpenSSH ssh-copy-id — macOS system utility, prints usage on -h
    "/usr/bin/ssh-copy-id -h"

    # zipgrep — sh wrapper around unzip+egrep, prints usage with no args
    "/usr/bin/zipgrep"

    # zdiff — gzip-aware diff wrapper, prints usage on --help
    "/usr/bin/zdiff --help"

    # xml2-config — libxml2 build helper, prints version number
    "/usr/bin/xml2-config --version"

    # xslt-config — libxslt build helper, prints version number
    "/usr/bin/xslt-config --version"

    # libgcrypt-config — GnuPG crypto library config helper
    "/opt/homebrew/bin/libgcrypt-config --version"

    # freetype-config — FreeType font library config helper
    "/opt/homebrew/bin/freetype-config --version"

    # autopoint — gettext infrastructure helper, exercises case-arm
    # patterns split across line continuations
    "/opt/homebrew/bin/autopoint --help"

    # glibtoolize — libtool prepare helper, exercises `\<NL>` between
    # commands joined by `&&` and `$_G_*` style variable names
    "/opt/homebrew/bin/glibtoolize --help"

    # lzgrep — xz-aware grep wrapper, exercises case-arm pattern lists
    # broken across line continuations
    "/opt/homebrew/bin/lzgrep --help"
)

# ---------------------------------------------------------------------------
# locate timeout binary (gtimeout on macOS via Homebrew coreutils)
# ---------------------------------------------------------------------------
if command -v timeout >/dev/null 2>&1; then
    TIMEOUT_CMD=timeout
elif command -v gtimeout >/dev/null 2>&1; then
    TIMEOUT_CMD=gtimeout
else
    TIMEOUT_CMD=
fi

run_with_timeout() {
    if [ -n "$TIMEOUT_CMD" ]; then
        "$TIMEOUT_CMD" "$TIMEOUT_SEC" "$@"
    else
        "$@"
    fi
}

# ---------------------------------------------------------------------------
# Main loop
# ---------------------------------------------------------------------------
echo "=== popular shell-scripts differential test (brash vs bash) ==="
printf "  brash: %s\n" "$BRASH_BIN"
printf "  bash:  %s\n" "$BASH_BIN"
echo

passed=0
failed=0
hung=0
skipped=0

for entry in "${ENTRIES[@]}"; do
    # Split entry into script path and arguments.  The first word is the
    # script; remaining words are arguments.
    read -r -a parts <<< "$entry"
    script="${parts[0]}"
    args=("${parts[@]:1}")

    # Derive a short display name: basename of script + args
    name="$(basename "$script")"
    if [ "${#args[@]}" -gt 0 ]; then
        name="$name ${args[*]}"
    fi

    # Skip if the script is not installed on this system
    if [ ! -x "$script" ]; then
        printf "SKIP: %s (not installed)\n" "$name"
        skipped=$((skipped + 1))
        continue
    fi

    sandbox=$(mktemp -d)
    cleanup() { rm -rf "$sandbox"; }
    trap cleanup EXIT

    # Run under bash. NOTE: `env -i` blows away the shell environment INCLUDING
    # any shell functions, so we MUST NOT use the run_with_timeout function
    # here — env would try to exec it as a binary and fail with 127.  Instead
    # inline the timeout binary directly (or skip if none available).
    bash_stdout="$sandbox/bash.stdout"
    bash_stderr="$sandbox/bash.stderr"
    if [ -n "$TIMEOUT_CMD" ]; then
        (cd "$sandbox" && env -i \
            HOME="$HOME" \
            PATH="/usr/bin:/bin:/usr/local/bin:/opt/homebrew/bin" \
            TMPDIR="${TMPDIR:-/tmp}" \
            "$TIMEOUT_CMD" "$TIMEOUT_SEC" "$BASH_BIN" "$script" "${args[@]}") \
            >"$bash_stdout" 2>"$bash_stderr"
    else
        (cd "$sandbox" && env -i \
            HOME="$HOME" \
            PATH="/usr/bin:/bin:/usr/local/bin:/opt/homebrew/bin" \
            TMPDIR="${TMPDIR:-/tmp}" \
            "$BASH_BIN" "$script" "${args[@]}") \
            >"$bash_stdout" 2>"$bash_stderr"
    fi
    bash_rc=$?

    # Run under brash
    brash_stdout="$sandbox/brash.stdout"
    brash_stderr="$sandbox/brash.stderr"
    if [ -n "$TIMEOUT_CMD" ]; then
        (cd "$sandbox" && env -i \
            HOME="$HOME" \
            PATH="/usr/bin:/bin:/usr/local/bin:/opt/homebrew/bin" \
            TMPDIR="${TMPDIR:-/tmp}" \
            "$TIMEOUT_CMD" "$TIMEOUT_SEC" "$BRASH_BIN" "$script" "${args[@]}") \
            >"$brash_stdout" 2>"$brash_stderr"
    else
        (cd "$sandbox" && env -i \
            HOME="$HOME" \
            PATH="/usr/bin:/bin:/usr/local/bin:/opt/homebrew/bin" \
            TMPDIR="${TMPDIR:-/tmp}" \
            "$BRASH_BIN" "$script" "${args[@]}") \
            >"$brash_stdout" 2>"$brash_stderr"
    fi
    brash_rc=$?

    trap - EXIT

    # Detect hang (timeout exit code 124)
    if [ "$bash_rc" -eq 124 ] || [ "$brash_rc" -eq 124 ]; then
        printf "HANG: %s (bash_rc=%d brash_rc=%d)\n" "$name" "$bash_rc" "$brash_rc"
        hung=$((hung + 1))
        rm -rf "$sandbox"
        continue
    fi

    # Compare outputs
    stdout_diff=
    stderr_diff=
    rc_diff=
    cmp -s "$bash_stdout" "$brash_stdout" || stdout_diff=stdout
    cmp -s "$bash_stderr" "$brash_stderr" || stderr_diff=stderr
    [ "$bash_rc" -ne "$brash_rc" ] && rc_diff=rc

    if [ -z "$stdout_diff" ] && [ -z "$stderr_diff" ] && [ -z "$rc_diff" ]; then
        printf "PASS: %s\n" "$name"
        passed=$((passed + 1))
    else
        reasons=$(printf "%s %s %s" "$stdout_diff" "$stderr_diff" "$rc_diff" \
            | tr -s ' ' | sed 's/^ *//;s/ *$//')
        printf "FAIL: %s [%s]\n" "$name" "$reasons"
        failed=$((failed + 1))

        if [ -n "$VERBOSE" ]; then
            if [ -n "$stdout_diff" ]; then
                echo "  --- stdout diff (bash vs brash, first 30 lines) ---"
                diff -u "$bash_stdout" "$brash_stdout" | sed 's/^/  /' | head -30
            fi
            if [ -n "$stderr_diff" ]; then
                echo "  --- stderr diff ---"
                diff -u "$bash_stderr" "$brash_stderr" | sed 's/^/  /' | head -20
            fi
            if [ -n "$rc_diff" ]; then
                printf "  --- exit code: bash=%d brash=%d ---\n" "$bash_rc" "$brash_rc"
            fi
        fi
    fi

    rm -rf "$sandbox"
done

eligible=$((passed + failed + hung))
echo
printf "=== %d/%d byte-identical  (%d skipped, %d failed, %d hung) ===\n" \
    "$passed" "$eligible" "$skipped" "$failed" "$hung"

if [ "$failed" -ne 0 ] || [ "$hung" -ne 0 ]; then
    exit 1
fi
exit 0
