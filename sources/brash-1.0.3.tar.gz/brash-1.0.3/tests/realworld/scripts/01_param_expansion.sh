#!/usr/bin/env bash
# Parameter expansion forms.

# Default values
unset a
echo "${a:-default}"
echo "${a-default-no-colon}"
b=
echo "${b:-default-empty}"
echo "${b-default-no-colon-empty}"

# Assign default
unset c
: "${c:=now-set}"
echo "$c"

# Substring removal
path=/usr/local/bin/foo.sh
echo "${path%.sh}"
echo "${path%/*}"
echo "${path%%/*}"
echo "${path#*/}"
echo "${path##*/}"

# Substring substitution
s="abcabc"
echo "${s/abc/X}"
echo "${s//abc/X}"
echo "${s/#abc/X}"
echo "${s/%abc/X}"

# Length
echo "${#path}"

# Case conversion
upper="HELLO"
lower="hello"
echo "${upper,}"
echo "${upper,,}"
echo "${lower^}"
echo "${lower^^}"

# Array slicing
arr=(zero one two three four five)
echo "${arr[@]:1:3}"
echo "${arr[@]: -2}"

# Associative array
declare -A ah
ah[red]=1
ah[blue]=2
ah[green]=3
for k in red blue green; do
    echo "$k=${ah[$k]}"
done
echo "keys: ${!ah[@]}" | tr ' ' '\n' | sort | tr '\n' ' '
echo
