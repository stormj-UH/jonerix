#!/usr/bin/env bash
# Complex arithmetic patterns from real scripts.

# Bit manipulation
echo $((1 << 5))
echo $((255 & 0x0f))
echo $((0x100 | 0x010))
echo $((1 << 31))

# Comparisons returning 0/1
echo $((5 > 3))
echo $((5 < 3))
echo $((5 == 5))
echo $((5 != 5))

# Ternary
x=10
echo $((x > 5 ? 100 : 200))

# Compound assignment
y=10
((y += 5))
echo $y
((y *= 2))
echo $y
((y >>= 1))
echo $y

# Pre/post increment
z=0
echo $((z++))
echo $z
echo $((++z))
echo $z

# Deeply nested
echo $(( ( (1+2)*3 + (4-5)*6 ) / 7 ))

# Octal and hex
echo $((010))         # octal 8
echo $((0x10))        # hex 16
echo $((2#1010))      # binary 10
echo $((36#z))        # base-36 35

# Large numbers (i64 range)
echo $((1 << 62))
echo $((1 << 62 + 1 << 62))

# Negative
echo $((-5 + 3))
echo $((-(-5)))

# Modulo edge
echo $((-7 % 3))
echo $((7 % -3))

# Power
echo $((2 ** 10))
echo $((10 ** 0))
