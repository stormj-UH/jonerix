#!/usr/bin/env bash
# 18_signal_handling.sh — kill -l, signal name<->number, trap cycling

# kill -l: list all signals (trim to first 16 for stability)
kill -l | head -4

# Signal number to name
kill -l 1
kill -l 2
kill -l 9
kill -l 15

# Signal name to number
kill -l TERM
kill -l HUP
kill -l INT
kill -l KILL

# trap: set, inspect, clear
trap 'echo caught-USR1' USR1
trap -p USR1

# Reset trap
trap - USR1
trap -p USR1

# Trap on EXIT
trap 'echo exit-trap' EXIT
echo before-exit

# ERR trap: fires on non-zero exit
trap 'echo err-trap' ERR
false
true

# Clear ERR trap and EXIT trap before we go
trap - ERR
trap - EXIT

# Nested trap cycling: set/reset multiple signals
trap 'echo got-PIPE' PIPE
trap 'echo got-HUP' HUP
trap -p PIPE
trap -p HUP
trap - PIPE HUP
trap -p PIPE
trap -p HUP

# Trap with multi-statement body
trap 'x=1; y=2; echo "trap-multi x=$x y=$y"' USR2
trap -p USR2
trap - USR2

echo done
