#!/usr/bin/env bash
# 36_date_math.sh — date/time arithmetic in pure shell.
# No `date -d` (macOS incompatible). All calculations via integer arithmetic.

set -eu

# ── epoch-to-date decomposition ───────────────────────────────────────────────
# Decompose a Unix timestamp to Y/M/D H:M:S using Zeller/Julian arithmetic.
# Algorithm: civil_from_days from Howard Hinnant's date algorithms (public domain)

epoch_to_ymd() {
    local epoch=$1
    local z=$((epoch / 86400))
    [ "$epoch" -lt 0 ] && z=$(( (epoch - 86399) / 86400 ))

    # days since Mar 1, 0000 (shifted so leap day is at end of year)
    local era=$(( (z >= 0 ? z : z - 146096) / 146097 ))
    local doe=$(( z - era * 146097 ))
    local yoe=$(( (doe - doe/1460 + doe/36524 - doe/146096) / 365 ))
    local y=$(( yoe + era * 400 ))
    local doy=$(( doe - (365*yoe + yoe/4 - yoe/100) ))
    local mp=$(( (5*doy + 2) / 153 ))
    local d=$(( doy - (153*mp + 2)/5 + 1 ))
    local m=$(( mp < 10 ? mp + 3 : mp - 9 ))
    [ "$m" -le 2 ] && y=$((y + 1))

    printf '%04d-%02d-%02d' "$y" "$m" "$d"
}

epoch_to_hms() {
    local epoch=$1
    # handle negative epochs too
    local secs=$(( epoch % 86400 ))
    [ "$secs" -lt 0 ] && secs=$((secs + 86400))
    local h=$((secs / 3600))
    local m=$(( (secs % 3600) / 60 ))
    local s=$((secs % 60))
    printf '%02d:%02d:%02d' "$h" "$m" "$s"
}

echo "=== epoch decomposition ==="
# Use fixed epochs for determinism
for epoch in 0 86400 1000000000 1700000000 1735689600; do
    ymd=$(epoch_to_ymd "$epoch")
    hms=$(epoch_to_hms "$epoch")
    printf 'epoch %-12d -> %s %s\n' "$epoch" "$ymd" "$hms"
done

# ── duration formatting ───────────────────────────────────────────────────────
format_duration() {
    local seconds=$1
    local neg=0
    if [ "$seconds" -lt 0 ]; then
        neg=1
        seconds=$((-seconds))
    fi

    local days=$(( seconds / 86400 ))
    local rem=$(( seconds % 86400 ))
    local hours=$(( rem / 3600 ))
    local rem2=$(( rem % 3600 ))
    local minutes=$(( rem2 / 60 ))
    local secs=$(( rem2 % 60 ))

    local out=""
    [ "$days" -gt 0 ]    && out="${out}${days}d "
    [ "$hours" -gt 0 ]   && out="${out}${hours}h "
    [ "$minutes" -gt 0 ] && out="${out}${minutes}m "
    out="${out}${secs}s"

    [ "$neg" -eq 1 ] && out="-${out}"
    printf '%s' "$out"
}

echo ""
echo "=== duration formatting ==="
for secs in 0 1 59 60 61 3599 3600 3661 86399 86400 86401 90061 604800 2678400; do
    printf 'seconds %-8d -> %s\n' "$secs" "$(format_duration "$secs")"
done

# ── day-of-week calculation (Tomohiko Sakamoto) ───────────────────────────────
day_of_week() {
    local y=$1 m=$2 d=$3
    local t=(0 3 2 5 0 3 5 1 4 6 2 4)
    [ "$m" -lt 3 ] && y=$((y - 1))
    local idx=$((m - 1))
    local dow=$(( (y + y/4 - y/100 + y/400 + ${t[$idx]} + d) % 7 ))
    local days=("Sun" "Mon" "Tue" "Wed" "Thu" "Fri" "Sat")
    printf '%s' "${days[$dow]}"
}

echo ""
echo "=== day-of-week ==="
# known dates
for args in "2024 1 1" "2024 2 29" "2024 12 25" "2025 1 1" "2026 4 25" "1970 1 1"; do
    read -r y m d <<< "$args"
    dow=$(day_of_week "$y" "$m" "$d")
    printf '%04d-%02d-%02d is %s\n' "$y" "$m" "$d" "$dow"
done

# ── days between two dates ────────────────────────────────────────────────────
ymd_to_epoch_days() {
    # days since epoch for a Y/M/D (using same civil algorithm reversed)
    local y=$1 m=$2 d=$3
    # shift so Mar 1 is start of year
    if [ "$m" -le 2 ]; then
        y=$((y - 1))
        m=$((m + 9))
    else
        m=$((m - 3))
    fi
    local era=$(( (y >= 0 ? y : y - 399) / 400 ))
    local yoe=$(( y - era * 400 ))
    local doy=$(( (153*m + 2)/5 + d - 1 ))
    local doe=$(( yoe*365 + yoe/4 - yoe/100 + doy ))
    echo $(( era * 146097 + doe - 719468 ))
}

days_between() {
    local y1=$1 m1=$2 d1=$3
    local y2=$4 m2=$5 d2=$6
    local days1 days2
    days1=$(ymd_to_epoch_days "$y1" "$m1" "$d1")
    days2=$(ymd_to_epoch_days "$y2" "$m2" "$d2")
    echo $(( days2 - days1 ))
}

echo ""
echo "=== days between dates ==="
printf 'days 2024-01-01 to 2024-12-31: %d\n' "$(days_between 2024 1 1  2024 12 31)"
printf 'days 2024-02-28 to 2024-03-01: %d\n' "$(days_between 2024 2 28 2024 3 1)"
printf 'days 2023-02-28 to 2023-03-01: %d\n' "$(days_between 2023 2 28 2023 3 1)"
printf 'days 2000-01-01 to 2001-01-01: %d\n' "$(days_between 2000 1 1  2001 1 1)"
printf 'days 1970-01-01 to 2024-04-25: %d\n' "$(days_between 1970 1 1  2024 4 25)"

# ── ISO week number ───────────────────────────────────────────────────────────
iso_week() {
    local y=$1 m=$2 d=$3
    local day_of_year
    local month_days=(0 31 28 31 30 31 30 31 31 30 31 30 31)

    # leap year
    if [ $(( (y%4==0 && y%100!=0) || y%400==0 )) -eq 1 ]; then
        month_days[2]=29
    fi

    day_of_year=$d
    for (( i=1; i<m; i++ )); do
        day_of_year=$(( day_of_year + ${month_days[$i]} ))
    done

    local dow
    # 1=Mon ... 7=Sun (ISO)
    local dow_raw
    dow_raw=$(day_of_week "$y" "$m" "$d")
    case "$dow_raw" in
        Mon) dow=1 ;; Tue) dow=2 ;; Wed) dow=3 ;; Thu) dow=4 ;;
        Fri) dow=5 ;; Sat) dow=6 ;; Sun) dow=7 ;;
    esac

    local week=$(( (day_of_year - dow + 10) / 7 ))

    if [ "$week" -lt 1 ]; then
        week=$(iso_week $((y-1)) 12 31)
    elif [ "$week" -gt 52 ]; then
        # check if week 53 exists
        local dec28_dow
        dec28_dow=$(day_of_week "$y" 12 28)
        case "$dec28_dow" in
            Mon) dec28_dow=1 ;; Tue) dec28_dow=2 ;; Wed) dec28_dow=3 ;; Thu) dec28_dow=4 ;;
            Fri) dec28_dow=5 ;; Sat) dec28_dow=6 ;; Sun) dec28_dow=7 ;;
        esac
        [ "$week" -eq 53 ] && [ "$dec28_dow" -lt 4 ] && week=1
    fi
    echo "$week"
}

echo ""
echo "=== ISO week numbers ==="
for args in "2024 1 1" "2024 1 4" "2024 12 30" "2024 12 31" "2025 1 1"; do
    read -r y m d <<< "$args"
    w=$(iso_week "$y" "$m" "$d")
    printf '%04d-%02d-%02d -> week %02d\n' "$y" "$m" "$d" "$w"
done

echo "done"
