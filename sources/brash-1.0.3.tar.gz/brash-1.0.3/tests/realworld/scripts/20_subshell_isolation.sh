#!/usr/bin/env bash
# 20_subshell_isolation.sh — () exit propagation, var visibility, trap behavior

# Variable isolation: changes in subshell don't affect parent
x=parent
( x=child; echo "sub x=$x" )
echo "parent x=$x"

# Exit propagation: subshell exit code
( exit 42 )
echo "subshell exit: $?"

# set -e inside subshell does not affect parent
set +e
( set -e; false; echo "unreachable" )
echo "after set-e sub: $?"
echo "parent continues"

# Traps are not inherited by subshells
trap 'echo parent-trap' USR1
( trap -p USR1 )
trap - USR1

# Functions defined in parent are visible in subshell
greet() { echo "hello from $1"; }
( greet subshell )

# Variables set in subshell are not visible after
( newvar=42 )
echo "newvar visible: ${newvar:-not-set}"

# Nested subshells
(
    a=outer-sub
    (
        a=inner-sub
        echo "inner a=$a"
    )
    echo "outer a=$a"
)
echo "top a=${a:-unset}"

# Subshell with pipeline
result=$(echo hello | tr a-z A-Z)
echo "pipeline result=$result"

# Exit in subshell stops only subshell
(
    echo "before exit"
    exit 0
    echo "after exit"  # should not print
)
echo "parent still running"

# Redirections inside subshell
tmpfile=$(mktemp)
( echo "written in sub" > "$tmpfile" )
cat "$tmpfile"
rm -f "$tmpfile"

# cd in subshell doesn't affect parent
orig_dir=$PWD
( cd /tmp; echo "sub pwd: $(basename "$(pwd)")" )
echo "parent pwd same: $([ "$PWD" = "$orig_dir" ] && echo yes || echo no)"

echo done
