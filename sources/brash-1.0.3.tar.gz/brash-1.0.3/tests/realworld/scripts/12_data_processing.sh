#!/usr/bin/env bash
# Data-processing patterns: CSV-like, key-value, log parsing.

# CSV parsing without external tools
csv="alice,30,engineer
bob,25,designer
carol,35,manager"

while IFS=, read -r name age role; do
    echo "name=$name age=$age role=$role"
done <<< "$csv"

# Sum a column
total=0
while IFS=, read -r _ age _; do
    total=$((total + age))
done <<< "$csv"
echo "total age: $total"

# K=V env-style parsing
config="DEBUG=1
LEVEL=info
PORT=8080
HOST=localhost
# this is a comment
EMPTY=
"
while IFS='=' read -r k v; do
    [ -z "$k" ] && continue
    [ "${k#\#}" != "$k" ] && continue
    echo "$k -> [$v]"
done <<< "$config"

# Log line parsing (timestamp scrubbed for determinism)
logs="2024-01-01T00:00:01Z INFO  starting
2024-01-01T00:00:02Z DEBUG configuring
2024-01-01T00:00:03Z ERROR failed: x
2024-01-01T00:00:04Z INFO  retrying
2024-01-01T00:00:05Z INFO  done"

# Extract by level
echo "ERRORS:"
while IFS=' ' read -r _ level msg; do
    [ "$level" = "ERROR" ] && echo "  $msg"
done <<< "$logs"

# Count by level using assoc
declare -A counts
while IFS=' ' read -r _ level _; do
    counts[$level]=$((${counts[$level]:-0} + 1))
done <<< "$logs"
for level in DEBUG INFO ERROR; do
    echo "$level: ${counts[$level]:-0}"
done

# JSON-like nested via assoc emulation
declare -A user
user[name]=alice
user[age]=30
user[email]=alice@example.com
echo "user:"
for k in name age email; do
    echo "  $k: ${user[$k]}"
done

# Field extraction
record="user_id=42&name=alice&email=a@b.c"
IFS='&' read -ra fields <<< "$record"
for f in "${fields[@]}"; do
    k=${f%%=*}
    v=${f#*=}
    echo "  $k=$v"
done
