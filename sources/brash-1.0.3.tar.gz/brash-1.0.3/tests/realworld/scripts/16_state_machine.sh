#!/usr/bin/env bash
# State-machine patterns common in installers, init scripts.

state=INIT
transitions=()
log() { transitions+=("[$state] $*"); }

transition_to() {
    log "transitioning to $1"
    state=$1
}

# Simulate a state machine
log "started"
transition_to STARTING
log "preparing"
transition_to RUNNING
log "doing work"

# Process with conditional state
input=ok
case $input in
    ok|fine) transition_to STOPPING ;;
    error)   transition_to ERROR ;;
    *)       transition_to UNKNOWN ;;
esac

log "winding down"
transition_to STOPPED

# Print history
echo "transitions:"
for t in "${transitions[@]}"; do
    echo "  $t"
done

# Multi-stage processor
declare -A handlers
handlers[init]='echo "init handler"'
handlers[start]='echo "start handler"'
handlers[stop]='echo "stop handler"'
handlers[error]='echo "error: $1"'

dispatch() {
    local action=$1
    shift
    local handler=${handlers[$action]:-${handlers[error]}}
    eval "$handler" "$@"
}

dispatch init
dispatch start
dispatch stop
dispatch unknown "what is this"

# Simple FSM with table
fsm_step() {
    local cur=$1 evt=$2
    case "$cur:$evt" in
        idle:start)    echo running ;;
        running:pause) echo paused ;;
        running:stop)  echo stopped ;;
        paused:resume) echo running ;;
        paused:stop)   echo stopped ;;
        *) echo "$cur" ;;
    esac
}

cur=idle
for evt in start pause resume stop unknown; do
    next=$(fsm_step "$cur" "$evt")
    echo "$cur --$evt--> $next"
    cur=$next
done
