#!/usr/bin/env bash
# 34_color_formatting.sh — terminal colorizing patterns that respect
# $TERM / $NO_COLOR / $CI. Output is deterministic: NO_COLOR=1 is set.

# Force deterministic: no color
export NO_COLOR=1
export TERM=dumb

# ── color capability detection ────────────────────────────────────────────────
supports_color() {
    # respect NO_COLOR (https://no-color.org/)
    [ -n "${NO_COLOR-}" ] && return 1
    # respect CI environments that don't support ANSI
    [ -n "${CI-}" ] && return 1
    # check TERM
    case "${TERM-}" in
        dumb|"") return 1 ;;
    esac
    # check if stdout is a terminal
    [ -t 1 ] || return 1
    return 0
}

# initialize color variables based on capability
if supports_color; then
    RED=$'\e[31m'
    GREEN=$'\e[32m'
    YELLOW=$'\e[33m'
    BLUE=$'\e[34m'
    MAGENTA=$'\e[35m'
    CYAN=$'\e[36m'
    BOLD=$'\e[1m'
    DIM=$'\e[2m'
    UNDERLINE=$'\e[4m'
    RESET=$'\e[0m'
else
    RED="" GREEN="" YELLOW="" BLUE="" MAGENTA="" CYAN=""
    BOLD="" DIM="" UNDERLINE="" RESET=""
fi

echo "=== color capability ==="
if supports_color; then
    echo "color: enabled"
else
    echo "color: disabled"
fi

# ── log-level coloring ────────────────────────────────────────────────────────
log_debug()   { printf '%s[DEBUG]%s %s\n' "$DIM"     "$RESET" "$*"; }
log_info()    { printf '%s[INFO]%s  %s\n' "$CYAN"    "$RESET" "$*"; }
log_success() { printf '%s[OK]%s    %s\n' "$GREEN"   "$RESET" "$*"; }
log_warn()    { printf '%s[WARN]%s  %s\n' "$YELLOW"  "$RESET" "$*"; }
log_error()   { printf '%s[ERROR]%s %s\n' "$RED"     "$RESET" "$*"; }

echo ""
echo "=== log levels ==="
log_debug "loading configuration"
log_info "starting process"
log_success "connection established"
log_warn "deprecated API used"
log_error "disk quota exceeded"

# ── progress / spinner (deterministic, no tty) ────────────────────────────────
progress_bar() {
    local current=$1 total=$2 width=${3:-40}
    local filled=$(( current * width / total ))
    local empty=$(( width - filled ))
    local pct=$(( current * 100 / total ))

    local bar
    bar=$(printf '%*s' "$filled" '' | tr ' ' '#')
    bar="${bar}$(printf '%*s' "$empty" '' | tr ' ' '-')"

    printf '\r[%s] %3d%% (%d/%d)' "$bar" "$pct" "$current" "$total"
}

echo ""
echo "=== progress bar ==="
for step in 0 10 25 50 75 100; do
    progress_bar "$step" 100 20
    echo  # newline after each \r progress line
done

# ── table formatter ───────────────────────────────────────────────────────────
print_row() {
    local col_widths=("$@")
    # called after shift to get data; use a different approach
    :
}

table_header() {
    printf '%-20s %-10s %-8s %-12s\n' "NAME" "STATUS" "CODE" "DURATION"
    printf '%-20s %-10s %-8s %-12s\n' "----" "------" "----" "--------"
}

table_row() {
    local name=$1 status=$2 code=$3 duration=$4
    local status_colored
    case "$status" in
        PASS)    status_colored="${GREEN}${status}${RESET}" ;;
        FAIL)    status_colored="${RED}${status}${RESET}" ;;
        SKIP)    status_colored="${YELLOW}${status}${RESET}" ;;
        *)       status_colored="$status" ;;
    esac
    # no color so widths are plain
    printf '%-20s %-10s %-8s %-12s\n' "$name" "$status" "$code" "$duration"
}

echo ""
echo "=== table formatter ==="
table_header
table_row "test_login"       "PASS" "0"   "0.42s"
table_row "test_auth_fail"   "FAIL" "1"   "0.18s"
table_row "test_register"    "PASS" "0"   "0.91s"
table_row "test_long_name_x" "SKIP" "0"   "0.00s"
table_row "test_payment"     "PASS" "0"   "1.23s"

# ── section headers ───────────────────────────────────────────────────────────
section() {
    local title=$1
    local width=60
    local line
    line=$(printf '%*s' "$width" '' | tr ' ' '=')
    printf '\n%s%s%s\n' "$BOLD" "$line" "$RESET"
    printf '%s  %s%s\n' "$BOLD" "$title" "$RESET"
    printf '%s%s%s\n' "$BOLD" "$line" "$RESET"
}

section "Build Summary"
echo "  Scripts compiled:  42"
echo "  Warnings:           3"
echo "  Errors:             0"

section "Test Results"
echo "  Total:  5"
echo "  Passed: 4"
echo "  Failed: 1"
echo "  Skipped: 1"

echo ""
echo "done"
