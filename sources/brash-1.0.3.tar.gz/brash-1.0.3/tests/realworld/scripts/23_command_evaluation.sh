#!/usr/bin/env bash
# 23_command_evaluation.sh — eval, builtin, command, type -a, hash management

# eval: basic
eval 'x=42; echo "eval x=$x"'

# eval: builds a command from parts
cmd="echo"
arg="hello from eval"
eval "$cmd '$arg'"

# eval: variable assignment via eval
varname="myvar"
eval "${varname}=world"
echo "myvar=$myvar"

# eval: arithmetic
eval 'result=$((3 + 4 * 5))'
echo "eval arith=$result"

# builtin: call shell builtin explicitly (bypasses function of same name)
echo() { printf "wrapped-echo: %s\n" "$*"; }
builtin echo "via builtin echo"
unset -f echo   # restore

# command: run command, bypass functions
ls_func() { echo "ls wrapper"; }
# Don't actually shadow ls; instead demonstrate command vs function
greet() { echo "function greet: $*"; }
greet "test"
command -v greet   # shows function
command -v ls      # shows path

# type -a: shows all definitions
type -a echo
type -a true

# type for builtins and keywords
type -t echo
type -t if
type -t ls
type -t cd

# hash: manually add a command to hash table
# First clear any cached entries
hash -r
# Cache 'ls' explicitly
hash ls
hash -t ls 2>/dev/null | grep -c 'ls' | xargs -I{} echo "hash ls found: {}"

# hash -d: remove specific entry
hash -d ls 2>/dev/null
echo "hash -d done"

# command -v vs which
command -v cd
command -v echo
command -v if 2>/dev/null || echo "if: not found via command -v"

# eval with array
eval 'arr=(one two three)'
echo "eval arr[1]=${arr[1]}"

# eval with loop
eval 'for i in a b c; do echo "eval-loop: $i"; done'

# command --: prevent flag interpretation
command -- echo "no flags here"

echo done
