#!/usr/bin/env bash
# Text processing patterns: word counting, frequency, transformations.

text="the quick brown fox jumps over the lazy dog
the dog was not amused by the fox
the fox jumped again and again"

# Word count
echo "lines: $(echo "$text" | wc -l | tr -d ' ')"
echo "words: $(echo "$text" | wc -w | tr -d ' ')"
echo "chars: $(echo "$text" | wc -c | tr -d ' ')"

# Most common word (poor man's `sort | uniq -c | sort -nr`)
declare -A wc_map
for w in $text; do
    wc_map[$w]=$((${wc_map[$w]:-0} + 1))
done

# Print sorted by count, deterministic
for k in "${!wc_map[@]}"; do
    printf '%d %s\n' "${wc_map[$k]}" "$k"
done | sort -rn -k1 | head -5

# Reverse lines
echo "reversed:"
echo "$text" | sed -n '1!G;h;$p'

# Replace word
echo "${text//the/THE}" | head -2

# Simple template
template="Hello, %NAME%!  You are %AGE% years old."
fill_template() {
    local s=$1
    s=${s//%NAME%/$2}
    s=${s//%AGE%/$3}
    echo "$s"
}
fill_template "$template" alice 30
fill_template "$template" bob 25

# Word lengths
for w in quick brown fox; do
    printf '%s %d\n' "$w" "${#w}"
done

# Toggle case
upper="${text^^}"
echo "${upper:0:30}..."
lower="${text,,}"
echo "${lower:0:30}..."
