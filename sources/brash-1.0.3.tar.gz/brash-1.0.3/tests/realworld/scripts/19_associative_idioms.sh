#!/usr/bin/env bash
# 19_associative_idioms.sh — declare -A patterns, key membership, iteration

# Basic declare -A
declare -A colors
colors[red]="#ff0000"
colors[green]="#00ff00"
colors[blue]="#0000ff"

echo "red=${colors[red]}"
echo "green=${colors[green]}"
echo "blue=${colors[blue]}"

# Key membership test
if [[ -v colors[red] ]]; then
    echo "red exists"
fi
if [[ ! -v colors[purple] ]]; then
    echo "purple absent"
fi

# All keys (sorted for determinism)
keys=("${!colors[@]}")
IFS=$'\n' sorted=($(sort <<<"${keys[*]}")); unset IFS
echo "keys: ${sorted[*]}"

# All values (sorted for determinism)
vals=("${colors[@]}")
IFS=$'\n' svals=($(sort <<<"${vals[*]}")); unset IFS
echo "values: ${svals[*]}"

# Count
echo "count=${#colors[@]}"

# Unset a key
unset 'colors[green]'
echo "after unset count=${#colors[@]}"
if [[ ! -v colors[green] ]]; then
    echo "green gone"
fi

# Inline initialisation
declare -A sizes=([small]=1 [medium]=5 [large]=10)
echo "medium=${sizes[medium]}"

# Integer-valued associative array
declare -Ai scores
scores[alice]=10
scores[bob]=20
((scores[alice] += 5))
echo "alice=${scores[alice]}"

# Iterate in sorted key order
declare -A table=([c]=3 [a]=1 [b]=2)
for k in $(echo "${!table[@]}" | tr ' ' '\n' | sort); do
    echo "$k=${table[$k]}"
done

# Nested-style: key with spaces
declare -A meta
meta["first name"]="Ada"
meta["last name"]="Lovelace"
echo "first=${meta["first name"]}"
echo "last=${meta["last name"]}"

echo done
