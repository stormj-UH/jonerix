#!/usr/bin/env bash
# Quoting variations: single, double, $'...', mixed.

# Single quotes are literal
echo 'no $expansion here'

# Double quotes expand vars and command sub
foo=value
echo "expand: $foo"
echo "command sub: $(echo nested)"

# ANSI-C $'...' expands escapes
echo $'tab:\there'
echo $'newline:\nhere'
echo $'unicode:é'

# Backslash escaping
echo \$dollar
echo "esc \$ stays escaped in DQ"

# Mixed quoting concatenation
echo "a"'b'"c"

# Empty arguments
set -- '' 'x' '' 'y'
echo "args=$#"
for a in "$@"; do
    echo "arg=[$a]"
done

# Word splitting with IFS
IFS=:
str="one:two:three"
for w in $str; do
    echo "w=$w"
done
unset IFS

# Glob (with deterministic content)
tmpdir=$(mktemp -d)
cd "$tmpdir"
touch a.txt b.txt c.md
for f in *.txt; do
    echo "$f"
done
echo "noglob: ${nonexistent:-default}"
cd /
rm -rf "$tmpdir"

# Nested expansions
nested='hello'
echo "${nested}${nested}"

# Special vars
echo "shell name: $0" | sed 's|.*/||'
echo "args: $#"
