#!/usr/bin/env bash
# 22_redirection_patterns.sh — &>, 2>&1, fd dup, exec redirects

tmpdir=$(mktemp -d)
trap 'rm -rf "$tmpdir"' EXIT

# Basic stdout redirect
echo "hello" > "$tmpdir/out.txt"
cat "$tmpdir/out.txt"

# Append
echo "line1" > "$tmpdir/app.txt"
echo "line2" >> "$tmpdir/app.txt"
cat "$tmpdir/app.txt"

# Stderr to file
( echo "err-msg" >&2 ) 2> "$tmpdir/err.txt"
cat "$tmpdir/err.txt"

# Combined &> (stdout+stderr to same file)
( echo "stdout"; echo "stderr" >&2 ) &> "$tmpdir/both.txt"
sort "$tmpdir/both.txt"

# 2>&1 ordering: stderr merged into stdout
{ echo "out"; echo "err" >&2; } 2>&1 | sort

# Redirect stdout to stderr
echo "this goes to stderr" >&2
echo "this goes to stdout"

# Here-string redirect
tr a-z A-Z <<< "hello world"

# Stdin from file
echo "file content" > "$tmpdir/input.txt"
tr a-z A-Z < "$tmpdir/input.txt"

# exec redirect: redirect shell's stdout
exec 3>&1          # save stdout
exec > "$tmpdir/redir.txt"
echo "redirected output"
exec >&3           # restore stdout
exec 3>&-          # close fd 3
cat "$tmpdir/redir.txt"

# exec redirect: redirect shell's stderr
exec 4>&2
exec 2> "$tmpdir/redir_err.txt"
echo "stderr via exec" >&2
exec 2>&4
exec 4>&-
cat "$tmpdir/redir_err.txt"

# Pipe with explicit fds
{ echo "from-3" >&3; echo "from-stdout"; } 3>&1 | sort

# Redirect in subshell doesn't affect parent
exec 5>&1
( exec > /dev/null; echo "invisible" )
echo "still visible" >&5
exec 5>&-

# /dev/null sink
echo "discarded" > /dev/null
echo "kept"

# Read from fd
echo "fd-content" > "$tmpdir/fdfile.txt"
exec 6< "$tmpdir/fdfile.txt"
read -u 6 line
echo "read from fd6: $line"
exec 6<&-

echo done
