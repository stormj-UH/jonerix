#!/usr/bin/env bash
# Recursive function patterns: fib, hanoi, ackermann (small), tree walks.

# Fibonacci
fib() {
    if [ "$1" -le 1 ]; then echo "$1"; return; fi
    local a=$(fib $(($1 - 1)))
    local b=$(fib $(($1 - 2)))
    echo $((a + b))
}
for i in 0 1 2 3 4 5 6 7 8 9 10; do
    echo "fib($i) = $(fib $i)"
done

# Iterative fib for verification
ifib() {
    local n=$1 a=0 b=1 t=0 i=0
    while [ $i -lt $n ]; do
        t=$((a + b))
        a=$b
        b=$t
        i=$((i + 1))
    done
    echo $a
}
echo "ifib(15) = $(ifib 15)"

# Towers of Hanoi
moves=()
hanoi() {
    local n=$1 src=$2 dst=$3 via=$4
    if [ "$n" -gt 0 ]; then
        hanoi $((n - 1)) "$src" "$via" "$dst"
        moves+=("$src->$dst")
        hanoi $((n - 1)) "$via" "$dst" "$src"
    fi
}
hanoi 3 A C B
echo "hanoi 3-disc moves: ${#moves[@]}"
for m in "${moves[@]}"; do echo "  $m"; done

# Ackermann (small inputs only)
ack() {
    local m=$1 n=$2
    if [ "$m" -eq 0 ]; then echo $((n + 1)); return; fi
    if [ "$n" -eq 0 ]; then ack $((m - 1)) 1; return; fi
    local inner=$(ack $m $((n - 1)))
    ack $((m - 1)) "$inner"
}
echo "ack(0,5) = $(ack 0 5)"
echo "ack(1,5) = $(ack 1 5)"
echo "ack(2,3) = $(ack 2 3)"
echo "ack(3,3) = $(ack 3 3)"

# Tree traversal (encoded as flat arrays)
declare -A tree
tree[1]="2 3"
tree[2]="4 5"
tree[3]="6"
tree[4]=""
tree[5]=""
tree[6]="7 8"
tree[7]=""
tree[8]=""

dfs() {
    local node=$1 depth=$2
    local pad=""
    local i=0
    while [ $i -lt $depth ]; do pad="${pad}  "; i=$((i + 1)); done
    echo "${pad}node $node"
    local children="${tree[$node]:-}"
    for c in $children; do
        dfs "$c" $((depth + 1))
    done
}
echo "DFS from 1:"
dfs 1 0
