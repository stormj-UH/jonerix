#!/usr/bin/env bash
# 27_special_chars.sh — backslash escaping, $'...' ANSI-C quoting, mixed quoting in heredocs

# Backslash escaping in double quotes
echo "tab:\there"
echo "newline:\nembedded"     # \n is NOT special in double-quotes (literal backslash-n)
echo "dollar: \$var"
echo "backslash: \\"
echo "quote: \""

# Backslash in single quotes: all literal
echo 'tab:\there'
echo 'newline:\n'
echo 'dollar: $var'
echo 'backslash: \\'

# $'...' ANSI-C quoting
echo $'tab:\there'            # literal tab
echo $'newline:\nline2'       # literal newline
echo $'bell:\a' | cat -v      # \a = BEL (07)
echo $'backspace:\b' | cat -v # \b = BS (08)
echo $'escape:\e[0m' | cat -v # \e = ESC (1b)
echo $'null:\0end' | cat -v   # \0 = NUL
echo $'hex:\x41\x42\x43'      # ABC
echo $'octal:\101\102\103'    # ABC
echo $'unicode:AB'  # AB
echo $'quote:\''              # single quote
echo $'backslash:\\'          # backslash

# Mixed quoting
var="world"
echo "hello $var"
echo 'hello $var'             # literal $var
echo "hello "'"'"$var"'"'     # double-single-double mix

# Heredoc: mixed quoting inside
cat << 'EOF'
literal: $var \n \t
EOF

cat << EOF
expanded: $var
literal backslash-n: \n
EOF

# Heredoc with $'...' not interpolated (it's just literal in heredoc body)
cat << EOF
dollar-squote: $'not ansi'
EOF

# Backslash continuation in strings
long="first \
second"
echo "$long"

# Backslash in variable names (not valid) — test backslash in values
path_val="/usr/local/bin:/opt/homebrew/bin"
echo "${path_val//:/ }"

# Special chars in array elements
arr=($'one\ttwo' "three four" 'five$six')
echo "arr[0]=${arr[0]}" | cat -v
echo "arr[1]=${arr[1]}"
echo "arr[2]=${arr[2]}"

# printf with escape sequences
printf '%s\n' $'a\tb\tc'      # printf gets literal tab-separated
printf '%b\n' 'a\tb\tc'       # %b interprets backslash sequences

# Quoting in case patterns
val=$'line1\nline2'
case $val in
    *$'\n'*) echo "contains newline" ;;
    *)       echo "no newline" ;;
esac

# Backslash in here-string
tr a-z A-Z <<< $'hello\nworld'

echo done
