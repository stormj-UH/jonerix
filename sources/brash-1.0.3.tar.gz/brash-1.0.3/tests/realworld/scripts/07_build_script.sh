#!/usr/bin/env bash
# Mimics common build/CI script patterns.

set -euo pipefail

# Logging helpers
log()    { printf '[%s] %s\n' "$(date -u +%H:%M)" "$*" 2>/dev/null || printf '[--:--] %s\n' "$*"; }
section() { printf '\n=== %s ===\n' "$*"; }

# Argument parsing
verbose=
clean=
target=all
while [ $# -gt 0 ]; do
    case "$1" in
        -v|--verbose) verbose=1 ;;
        -c|--clean)   clean=1 ;;
        -t|--target)  target=$2; shift ;;
        --target=*)   target="${1#*=}" ;;
        --) shift; break ;;
        -*) echo "unknown flag: $1" >&2; exit 1 ;;
        *)  break ;;
    esac
    shift
done

# Set defaults from env or hardcoded
: "${BUILD_DIR:=build}"
: "${PARALLEL:=4}"

section "config"
echo "target=$target"
echo "verbose=${verbose:-no}"
echo "clean=${clean:-no}"
echo "BUILD_DIR=$BUILD_DIR"
echo "PARALLEL=$PARALLEL"

# Mock build steps
declare -a built=()
build_target() {
    local t=$1
    [ -n "$verbose" ] && echo "  building $t..."
    built+=("$t")
}

section "build"
case "$target" in
    all|both)
        build_target lib
        build_target bin
        ;;
    lib)
        build_target lib
        ;;
    bin)
        build_target bin
        ;;
    *)
        echo "unknown target: $target" >&2
        exit 2
        ;;
esac

section "summary"
echo "built ${#built[@]} target(s):"
for t in "${built[@]}"; do
    echo "  - $t"
done

# Status retrieval style
status_for() {
    local t=$1
    case "$t" in
        lib) echo "OK" ;;
        bin) echo "OK" ;;
        *)   echo "UNKNOWN" ;;
    esac
}

for t in "${built[@]}"; do
    s=$(status_for "$t")
    printf '  %-8s %s\n' "$t" "$s"
done

# Final
section "done"
echo "ok"
