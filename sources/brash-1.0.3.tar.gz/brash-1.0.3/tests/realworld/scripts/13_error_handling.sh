#!/usr/bin/env bash
# Error handling: set -e propagation, traps, error rollup.

set -eu

# Function that fails predictably
fail_cmd() {
    return $1
}

# Capture in conditional — set -e doesn't exit on this
if fail_cmd 5; then echo "ok"; else echo "failed with $?"; fi

# Capture via $? after command list
fail_cmd 7 || rc=$?
echo "captured rc=$rc"

# Pipefail
set -o pipefail
result=$(false | true; echo "rc=$?")
set +o pipefail
echo "with pipefail: $result"

set +o pipefail
result=$(false | true; echo "rc=$?")
echo "without pipefail: $result"

# Trap-based cleanup
cleanup() {
    echo "cleanup: $1"
}
tmp=/tmp/brash-test-cleanup-XXX
trap 'cleanup "EXIT signal"' EXIT
trap 'cleanup "ERR signal"' ERR

# Error rollup pattern
errors=0
check() {
    if "$@"; then
        return 0
    fi
    errors=$((errors + 1))
    echo "FAIL: $*"
}

check true
check true
check false 2>/dev/null
check fail_cmd 0
check fail_cmd 3 2>/dev/null

echo "errors: $errors"

# Default values for required args
must() {
    local val="${1:?missing arg}"
    echo "got: $val"
}
must hello

# Conditional cleanup
needed_setup=
trap '
    [ -n "$needed_setup" ] && echo "tearing down setup"
' EXIT

needed_setup=1
echo "need setup is set"
