#!/usr/bin/env bash
# Patterns common in dotfile/profile setup scripts.

# Add to PATH only if missing
prepend_path() {
    case ":$PATH:" in
        *":$1:"*) ;;
        *) PATH="$1:$PATH" ;;
    esac
}

prepend_path /usr/local/bin
prepend_path /opt/special/bin
prepend_path /usr/local/bin   # dup, should not double
echo "PATH segments: $(echo "$PATH" | tr : '\n' | grep -c .)"

# Aliases ignored when not interactive — but defining them is fine
alias ll='ls -la'
alias la='ls -A'

# Function-style aliases
mkcd() { mkdir -p "$1" && cd "$1" || return; }
extract() {
    case "$1" in
        *.tar.gz|*.tgz) tar -xzf "$1" ;;
        *.tar.bz2)      tar -xjf "$1" ;;
        *.tar)          tar -xf "$1" ;;
        *.zip)          unzip -q "$1" ;;
        *)              echo "don't know: $1" >&2; return 1 ;;
    esac
}

# Test the case dispatch (no real extraction)
type_for() {
    case "$1" in
        *.tar.gz|*.tgz) echo gzip ;;
        *.tar.bz2)      echo bzip2 ;;
        *.tar)          echo tar ;;
        *.zip)          echo zip ;;
        *)              echo unknown ;;
    esac
}
echo "$(type_for foo.tar.gz)"
echo "$(type_for foo.zip)"
echo "$(type_for foo.txt)"

# Source guard pattern
LOADED_SOMETHING=${LOADED_SOMETHING:-}
if [ -z "$LOADED_SOMETHING" ]; then
    LOADED_SOMETHING=1
    echo "loading first time"
fi
if [ -n "$LOADED_SOMETHING" ]; then
    echo "second pass skipped"
fi

# Detect interactive
if [[ $- == *i* ]]; then
    echo "interactive"
else
    echo "non-interactive"
fi

# Color helpers (don't actually emit ANSI in non-TTY scripts)
if [ -t 1 ]; then
    RED=$'\e[31m'; NC=$'\e[0m'
else
    RED=; NC=
fi
echo "${RED}red${NC}word"

# Useful function: read a config file
read_kv() {
    local f=$1
    while IFS='=' read -r k v; do
        [ -n "$k" ] && [ "${k#\#}" = "$k" ] && echo "kv: $k=$v"
    done < "$f"
}

tmpconf=$(mktemp)
cat > "$tmpconf" <<'EOF'
# comment
key1=value1
key2=value2

key3=value with spaces
EOF
read_kv "$tmpconf"
rm -f "$tmpconf"

# Final line
echo "done"
