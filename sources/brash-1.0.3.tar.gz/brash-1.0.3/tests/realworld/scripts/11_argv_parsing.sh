#!/usr/bin/env bash
# Argument parsing patterns common in scripts.

# Set up some "args"
set -- --verbose --target=foo --count 5 --no-color file1 file2

verbose=
target=
count=1
color=1
positional=()

while [ $# -gt 0 ]; do
    case "$1" in
        -v|--verbose) verbose=1 ;;
        --target)     target=$2; shift ;;
        --target=*)   target=${1#--target=} ;;
        --count)      count=$2; shift ;;
        --count=*)    count=${1#--count=} ;;
        --color)      color=1 ;;
        --no-color)   color= ;;
        --) shift; while [ $# -gt 0 ]; do positional+=("$1"); shift; done; break ;;
        -*) echo "unknown: $1" >&2; exit 1 ;;
        *)  positional+=("$1") ;;
    esac
    shift
done

echo "verbose=${verbose:-no}"
echo "target=$target"
echo "count=$count"
echo "color=${color:-no}"
echo "positional count=${#positional[@]}"
for p in "${positional[@]}"; do
    echo "  positional: $p"
done

# getopts style
parse_short() {
    local OPTIND=1 opt v= o=
    while getopts "vo:" opt; do
        case $opt in
            v) v=1 ;;
            o) o=$OPTARG ;;
            \?) echo "bad option" >&2 ;;
        esac
    done
    shift $((OPTIND - 1))
    echo "v=$v o=$o args:$*"
}

parse_short -v -o output.txt file1 file2

# Argument count guards
require_n() {
    if [ $# -lt $1 ]; then
        echo "need at least $1 args, got $(($# - 1))" >&2
        return 2
    fi
}
require_n 2 a b c && echo "ok 2-of-3"
require_n 3 a 2>&1
echo "rc=$?"
