#!/usr/bin/env bash
# Basic bash features: variables, simple commands, control flow.
# Designed to produce identical output under bash and brash.

set -e

# Variables
foo=hello
bar="$foo world"
echo "$bar"

# Arithmetic
x=5
y=$((x * 2 + 1))
echo "y=$y"

# Conditionals
if [ "$y" -eq 11 ]; then
    echo "match"
else
    echo "no match"
fi

# For loop
sum=0
for i in 1 2 3 4 5; do
    sum=$((sum + i))
done
echo "sum=$sum"

# While loop
n=3
while [ "$n" -gt 0 ]; do
    echo "n=$n"
    n=$((n - 1))
done

# Case
case $bar in
    hello*) echo "starts with hello" ;;
    world*) echo "starts with world" ;;
    *) echo "other" ;;
esac

# Functions
greet() {
    echo "greeting: $1"
}
greet brash

# Return code
false || echo "false ran"
true && echo "true ran"

# Substring
s="hello brash world"
echo "${s:6:5}"

# Length
echo "${#s}"

# Array
arr=(a b c d)
echo "${arr[2]}"
echo "${#arr[@]}"
echo "${arr[@]}"
