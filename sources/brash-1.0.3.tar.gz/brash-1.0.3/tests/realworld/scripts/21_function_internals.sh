#!/usr/bin/env bash
# 21_function_internals.sh — local namespacing, recursion, nested calls

# Basic local scoping
outer_val=global
modify() {
    local outer_val=local
    echo "inside modify: outer_val=$outer_val"
}
modify
echo "after modify: outer_val=$outer_val"

# local with -i (integer)
calc() {
    local -i n=$1
    local -i m=$2
    echo $(( n * m ))
}
calc 6 7

# local array
arr_func() {
    local -a items=("$@")
    echo "count=${#items[@]}"
    echo "first=${items[0]}"
}
arr_func apple banana cherry

# Recursion: factorial
fact() {
    local -i n=$1
    if (( n <= 1 )); then
        echo 1
    else
        local -i sub
        sub=$(fact $((n - 1)))
        echo $(( n * sub ))
    fi
}
echo "5!=$(fact 5)"
echo "7!=$(fact 7)"

# Recursion: fibonacci
fib() {
    local -i n=$1
    if (( n <= 1 )); then
        echo $n
    else
        local -i a b
        a=$(fib $((n - 1)))
        b=$(fib $((n - 2)))
        echo $(( a + b ))
    fi
}
echo "fib(8)=$(fib 8)"

# Nested function calls
double() { echo $(( $1 * 2 )); }
quad() { echo $(double $(double $1)); }
echo "quad(3)=$(quad 3)"

# Function shadowing a builtin name (local to scope)
# Use a non-critical builtin name pattern
my_echo() { echo "wrapped: $*"; }
my_echo hello world

# $FUNCNAME inside function
show_name() {
    echo "funcname=${FUNCNAME[0]}"
    inner_show
}
inner_show() {
    echo "inner funcname=${FUNCNAME[0]}"
    echo "caller funcname=${FUNCNAME[1]}"
}
show_name

# Return value propagation
check_even() {
    local -i n=$1
    (( n % 2 == 0 ))
}
check_even 4 && echo "4 is even"
check_even 7 || echo "7 is odd"

# Functions can modify globals when no local declared
counter=0
increment() { counter=$((counter + 1)); }
increment; increment; increment
echo "counter=$counter"

# Unset function
temp_func() { echo "temp"; }
temp_func
unset -f temp_func
type temp_func 2>&1 | grep -c "not found" | xargs -I{} echo "unset ok: {}"

echo done
