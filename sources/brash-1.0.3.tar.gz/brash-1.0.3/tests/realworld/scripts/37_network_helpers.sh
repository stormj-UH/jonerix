#!/usr/bin/env bash
# 37_network_helpers.sh — URL parsing, IP address arithmetic,
# CIDR mask manipulation — all purely in bash arithmetic (no external tools
# beyond printf/echo).

set -eu

# ── URL parser ────────────────────────────────────────────────────────────────
parse_url() {
    local url=$1

    # extract scheme
    local scheme="${url%%://*}"
    local rest="${url#*://}"

    # extract fragment
    local fragment=""
    if [[ "$rest" == *"#"* ]]; then
        fragment="${rest##*#}"
        rest="${rest%#*}"
    fi

    # extract query
    local query=""
    if [[ "$rest" == *"?"* ]]; then
        query="${rest#*?}"
        rest="${rest%%\?*}"
    fi

    # extract path (after first /)
    local authority="$rest"
    local path=""
    if [[ "$rest" == */* ]]; then
        authority="${rest%%/*}"
        path="/${rest#*/}"
    fi

    # extract userinfo
    local userinfo=""
    local hostport="$authority"
    if [[ "$authority" == *"@"* ]]; then
        userinfo="${authority%%@*}"
        hostport="${authority#*@}"
    fi

    # extract port
    local host="$hostport"
    local port=""
    # handle IPv6 [::1]:port
    if [[ "$hostport" == "["* ]]; then
        host="${hostport%%]*}"
        host="${host#[}"
        local after_bracket="${hostport#*]}"
        [[ "$after_bracket" == ":"* ]] && port="${after_bracket#:}"
    elif [[ "$hostport" == *":"* ]]; then
        host="${hostport%%:*}"
        port="${hostport##*:}"
    fi

    # extract user/password
    local user="" password=""
    if [[ -n "$userinfo" ]]; then
        user="${userinfo%%:*}"
        [[ "$userinfo" == *":"* ]] && password="${userinfo#*:}"
    fi

    printf 'scheme=%s\n' "$scheme"
    printf 'user=%s\n' "$user"
    printf 'password=%s\n' "$password"
    printf 'host=%s\n' "$host"
    printf 'port=%s\n' "$port"
    printf 'path=%s\n' "$path"
    printf 'query=%s\n' "$query"
    printf 'fragment=%s\n' "$fragment"
}

echo "=== URL parser ==="
urls=(
    "https://example.com/path/to/page"
    "http://user:pass@db.example.com:5432/mydb?ssl=true&timeout=30"
    "ftp://files.example.org/pub/file.tar.gz"
    "https://api.example.com/v1/users?page=2&limit=50#results"
    "ssh://git@github.com:22/user/repo.git"
)

for url in "${urls[@]}"; do
    echo "--- $url"
    parse_url "$url"
done

# ── IP address to integer ─────────────────────────────────────────────────────
ip_to_int() {
    local ip=$1
    local a b c d
    IFS=. read -r a b c d <<< "$ip"
    echo $(( (a << 24) | (b << 16) | (c << 8) | d ))
}

int_to_ip() {
    local n=$1
    printf '%d.%d.%d.%d\n' \
        $(( (n >> 24) & 255 )) \
        $(( (n >> 16) & 255 )) \
        $(( (n >>  8) & 255 )) \
        $(( n & 255 ))
}

echo ""
echo "=== IP <-> integer ==="
for ip in "0.0.0.0" "1.2.3.4" "10.0.0.1" "192.168.1.100" "255.255.255.255"; do
    n=$(ip_to_int "$ip")
    back=$(int_to_ip "$n")
    printf '%-18s -> %-12d -> %s\n' "$ip" "$n" "$back"
done

# ── CIDR mask operations ──────────────────────────────────────────────────────
prefix_to_mask() {
    local prefix=$1
    if [ "$prefix" -eq 0 ]; then
        echo 0
    else
        # build mask: prefix 1-bits left-justified in 32-bit word
        echo $(( ( (1 << 32) - 1 ) ^ ( (1 << (32 - prefix)) - 1 ) ))
    fi
}

cidr_network() {
    local ip=$1 prefix=$2
    local ip_int mask
    ip_int=$(ip_to_int "$ip")
    mask=$(prefix_to_mask "$prefix")
    echo $(( ip_int & mask ))
}

cidr_broadcast() {
    local ip=$1 prefix=$2
    local net_int mask hostmask
    net_int=$(cidr_network "$ip" "$prefix")
    mask=$(prefix_to_mask "$prefix")
    hostmask=$(( mask ^ 0xffffffff ))
    echo $(( net_int | hostmask ))
}

cidr_host_count() {
    local prefix=$1
    local host_bits=$(( 32 - prefix ))
    if [ "$host_bits" -ge 32 ]; then
        echo "unlimited"
    elif [ "$host_bits" -le 1 ]; then
        echo 0
    else
        echo $(( (1 << host_bits) - 2 ))
    fi
}

cidr_contains() {
    local ip=$1 cidr_ip=$2 prefix=$3
    local ip_int net_int
    ip_int=$(ip_to_int "$ip")
    net_int=$(cidr_network "$cidr_ip" "$prefix")
    mask=$(prefix_to_mask "$prefix")
    [ $(( ip_int & mask )) -eq "$net_int" ]
}

echo ""
echo "=== CIDR operations ==="
networks=(
    "192.168.1.0/24"
    "10.0.0.0/8"
    "172.16.0.0/12"
    "192.168.0.0/16"
    "10.10.20.0/30"
)

for cidr in "${networks[@]}"; do
    ip="${cidr%/*}"
    prefix="${cidr#*/}"
    net_int=$(cidr_network "$ip" "$prefix")
    bcast_int=$(cidr_broadcast "$ip" "$prefix")
    net_addr=$(int_to_ip "$net_int")
    bcast_addr=$(int_to_ip "$bcast_int")
    first=$(int_to_ip $(( net_int + 1 )) )
    last=$(int_to_ip $(( bcast_int - 1 )) )
    hosts=$(cidr_host_count "$prefix")
    printf 'CIDR: %-20s network: %-16s broadcast: %-16s first: %-16s last: %-16s hosts: %s\n' \
        "$cidr" "$net_addr" "$bcast_addr" "$first" "$last" "$hosts"
done

echo ""
echo "=== CIDR membership ==="
test_cases=(
    "192.168.1.50  192.168.1.0  24"
    "192.168.2.1   192.168.1.0  24"
    "10.5.6.7      10.0.0.0     8"
    "172.31.255.1  172.16.0.0   12"
    "172.32.0.1    172.16.0.0   12"
)

for tc in "${test_cases[@]}"; do
    read -r test_ip net_ip prefix <<< "$tc"
    if cidr_contains "$test_ip" "$net_ip" "$prefix"; then
        result="YES"
    else
        result="NO"
    fi
    printf '%-16s in %s/%-3s? %s\n' "$test_ip" "$net_ip" "$prefix" "$result"
done

echo "done"
