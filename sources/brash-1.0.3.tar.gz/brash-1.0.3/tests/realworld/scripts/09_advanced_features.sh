#!/usr/bin/env bash
# Advanced features that real scripts use.

# Brace expansion
echo {1..5}
echo {a..e}
echo {01..10}      # zero-padded
echo {1..10..2}    # step
echo a{b,c,d}e

# Process substitution with diff-like usage
join_lines() {
    paste -d, "$1" "$2"
}
f1=$(mktemp); f2=$(mktemp)
printf 'a\nb\nc\n' > "$f1"
printf '1\n2\n3\n' > "$f2"
join_lines "$f1" "$f2"
rm -f "$f1" "$f2"

# Indirect expansion
target_var=PATH
echo "indirect: ${!target_var:0:6}"

# Read with multiple variables
read -r a b c <<< "x y z"
echo "a=$a b=$b c=$c"

# Read into array
read -ra arr <<< "p q r s"
echo "arr len=${#arr[@]}"
echo "arr[2]=${arr[2]}"

# Mapfile / readarray
mapfile -t lines < <(printf 'one\ntwo\nthree\n')
echo "mapped count=${#lines[@]}"
echo "second=${lines[1]}"

# printf format strings
printf 'str=%s int=%d hex=%x\n' hello 42 255
printf '[%10s]\n' x
printf '[%-10s]\n' x
printf '[%.3s]\n' helloworld

# Arithmetic expansion variants
((x = 10))
echo "x=$x"
((x++))
echo "x=$x"
((x = (1 + 2) * 3))
echo "x=$x"
echo $((5 ** 2))
echo $((10 % 3))

# Conditional with [[ ]]
x=hello
if [[ $x == h* ]]; then echo "starts h"; fi
if [[ $x =~ ^h.+o$ ]]; then echo "regex match"; fi
if [[ -n $x && -z "" ]]; then echo "logic"; fi

# Globbing
shopt -s nullglob 2>/dev/null
tmpdir=$(mktemp -d)
cd "$tmpdir"
touch file1.txt file2.txt other.md
matches=( *.txt )
echo "txt count: ${#matches[@]}"
no_match=( *.zzz )
echo "zzz count: ${#no_match[@]}"
cd /
rm -rf "$tmpdir"
shopt -u nullglob 2>/dev/null

# Heredoc with tab-strip
cat <<-END
	first line
	second line
END

# Local vars
outer() {
    local x=outer-val
    inner
    echo "after inner: x=$x"
}
inner() {
    local x=inner-val
    echo "in inner: x=$x"
}
outer

# Subshell isolation
y=parent
( y=child; echo "in subshell: $y" )
echo "after subshell: $y"

# Status pipeline
false | true
echo "pipefail off: $?"
set -o pipefail
false | true
echo "pipefail on: $?"
set +o pipefail
