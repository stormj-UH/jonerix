#!/usr/bin/env bash
# Loop variations and control flow.

# Arithmetic for-loop
for ((i = 1; i <= 5; i++)); do
    printf "%d " "$i"
done
echo

# Brace-expansion for-loop
for x in {a,b,c}{1,2}; do
    printf "%s " "$x"
done
echo

# C-style continue/break
sum=0
for ((i = 1; i <= 10; i++)); do
    if [ $((i % 2)) -eq 0 ]; then
        continue
    fi
    if [ "$i" -gt 7 ]; then
        break
    fi
    sum=$((sum + i))
done
echo "sum=$sum"

# Until
n=0
until [ "$n" -ge 3 ]; do
    echo "n=$n"
    n=$((n + 1))
done

# Select-like loop simulated with case
choices=(apple banana cherry)
for c in "${choices[@]}"; do
    case $c in
        apple)  echo "fruit:apple" ;;
        banana) echo "fruit:banana" ;;
        cherry) echo "fruit:cherry" ;;
    esac
done

# Nested loops with labels via break N
for i in 1 2 3; do
    for j in a b c; do
        if [ "$j" = "b" ] && [ "$i" -eq 2 ]; then
            break 2
        fi
        echo "$i$j"
    done
done

# Recursive function
factorial() {
    if [ "$1" -le 1 ]; then
        echo 1
        return
    fi
    local prev=$(factorial $(($1 - 1)))
    echo $(( $1 * prev ))
}
echo "5! = $(factorial 5)"

# Exit code propagation
check() {
    [ "$1" -gt 0 ]
}
if check 5; then echo "5>0"; fi
if ! check 0; then echo "!0>0"; fi

# Trap
trap 'echo trap-cleanup' EXIT
echo "before exit"
