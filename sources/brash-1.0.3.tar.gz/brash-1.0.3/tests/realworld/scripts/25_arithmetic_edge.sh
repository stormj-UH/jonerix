#!/usr/bin/env bash
# 25_arithmetic_edge.sh — overflow at i64 boundary, division-by-zero, truncation

# Basic arithmetic
echo $((10 + 3))
echo $((10 - 3))
echo $((10 * 3))
echo $((10 / 3))   # truncation toward zero
echo $((10 % 3))

# Negative truncation (toward zero, not floor)
echo $((-10 / 3))
echo $((-10 % 3))
echo $((10 / -3))
echo $((10 % -3))

# i64 max: 2^63 - 1 = 9223372036854775807
echo $((9223372036854775807))

# i64 overflow wraps (bash silently wraps to negative)
echo $((9223372036854775807 + 1))

# i64 min: -2^63 = -9223372036854775808
echo $((-9223372036854775808))

# Underflow
echo $((-9223372036854775808 - 1))

# Multiplication overflow
echo $((9223372036854775807 * 2))

# Division by zero: bash prints error to stderr, returns 1; value of expression is undefined
# Capture just the exit code and stderr indicator
( result=$((5 / 0)) ) 2>/dev/null
echo "div0 exit=$?"

( result=$((5 % 0)) ) 2>/dev/null
echo "mod0 exit=$?"

# Bitwise operators
echo $((0xFF & 0x0F))       # AND  = 15
echo $((0xF0 | 0x0F))       # OR   = 255
echo $((0xFF ^ 0xF0))       # XOR  = 15
echo $((~0))                 # NOT  = -1
echo $((1 << 8))             # shift left  = 256
echo $((256 >> 4))           # shift right = 16

# Exponentiation
echo $((2 ** 10))            # 1024
echo $((3 ** 3))             # 27

# Ternary operator
echo $((1 ? 42 : 99))
echo $((0 ? 42 : 99))

# Comma operator (last value returned)
echo $((x=1, y=2, x+y))

# Pre/post increment
n=5
echo $((n++))    # 5, then n becomes 6
echo $n
echo $((++n))    # n becomes 7, echo 7
echo $n

# Pre/post decrement
m=10
echo $((m--))    # 10, then m becomes 9
echo $m
echo $((--m))    # m becomes 8, echo 8
echo $m

# Hex, octal, binary literals
echo $((0x1A))     # 26
echo $((010))      # 8 (octal)
echo $((2#1010))   # 10 (binary)

# Large multiplication that stays in bounds
echo $((1000000 * 1000000))     # 1e12, fits in i64

# Nested arithmetic
echo $(( (2 + 3) * (4 - 1) ))

echo done
