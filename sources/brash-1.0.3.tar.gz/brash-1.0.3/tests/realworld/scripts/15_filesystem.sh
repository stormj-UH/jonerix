#!/usr/bin/env bash
# Filesystem patterns: temp dirs, pattern walks, attribute checks.
# Use a sandbox to keep deterministic.

set -e

sandbox=$(mktemp -d)
cd "$sandbox"

# Create a tree
mkdir -p src/lib src/bin docs tests/unit tests/integration
touch src/lib/a.rs src/lib/b.rs src/bin/main.rs docs/README.md
touch tests/unit/test1.sh tests/unit/test2.sh tests/integration/itest.sh
touch .hidden Makefile

# List by type
echo "all dirs:"
find . -type d 2>/dev/null | sort

echo "all .rs files:"
find . -name '*.rs' -type f 2>/dev/null | sort

echo "all .sh files:"
find . -name '*.sh' -type f 2>/dev/null | sort

# File checks
[ -d src ] && echo "src is dir"
[ -f Makefile ] && echo "Makefile exists"
[ -e .hidden ] && echo ".hidden exists"
[ ! -e missing ] && echo "missing absent"
[ -r Makefile ] && echo "Makefile readable"
[ -w Makefile ] && echo "Makefile writable"

# File counts
n_rs=$(find . -name '*.rs' -type f 2>/dev/null | wc -l | tr -d ' ')
n_sh=$(find . -name '*.sh' -type f 2>/dev/null | wc -l | tr -d ' ')
echo "rs files: $n_rs"
echo "sh files: $n_sh"

# Glob with matching
shopt -s nullglob
rs_files=( **/*.rs )
echo "globstar count: ${#rs_files[@]}"
shopt -u nullglob

# Recursive operation simulation
process_dir() {
    local dir=$1
    local depth=$2
    local f
    for f in "$dir"/*; do
        [ -e "$f" ] || continue
        local pad=""
        local i=0
        while [ $i -lt $depth ]; do pad="${pad}  "; i=$((i+1)); done
        if [ -d "$f" ]; then
            echo "${pad}D $(basename "$f")"
            process_dir "$f" $((depth + 1))
        else
            echo "${pad}F $(basename "$f")"
        fi
    done
}
process_dir src 0

# Cleanup
cd /
rm -rf "$sandbox"
echo "done"
