#!/usr/bin/env bash
# 33_argparse.sh — common bash argument-parsing patterns:
# getopts (short), manual long-opts, and a mini "argparse library" style.

set -eu

# ── getopts: short options ────────────────────────────────────────────────────
parse_short() {
    local OPTIND=1
    local verbose=0 output="-" count=1 dryrun=0

    while getopts ":vo:n:d" opt "$@"; do
        case "$opt" in
            v) verbose=1 ;;
            o) output="$OPTARG" ;;
            n) count="$OPTARG" ;;
            d) dryrun=1 ;;
            :) echo "ERROR: option -$OPTARG requires an argument" >&2; return 1 ;;
            \?) echo "ERROR: unknown option -$OPTARG" >&2; return 1 ;;
        esac
    done
    shift $((OPTIND - 1))

    echo "verbose=$verbose output=$output count=$count dryrun=$dryrun"
    echo "remaining args: $*"
}

echo "=== getopts short ==="
parse_short -v -o /tmp/out.txt -n 5 -- file1 file2
parse_short -d file3
parse_short

# ── manual long options parser ────────────────────────────────────────────────
parse_long() {
    local verbose=0 output="-" format="plain" help=0
    local args=("$@")
    local i=0

    while [ "$i" -lt "${#args[@]}" ]; do
        local arg="${args[$i]}"
        case "$arg" in
            --verbose)      verbose=1 ;;
            --output=*)     output="${arg#--output=}" ;;
            --output)       i=$((i+1)); output="${args[$i]}" ;;
            --format=*)     format="${arg#--format=}" ;;
            --format)       i=$((i+1)); format="${args[$i]}" ;;
            --help)         help=1 ;;
            --)             i=$((i+1)); break ;;
            --*)            echo "ERROR: unknown option $arg" >&2; return 1 ;;
            *)              break ;;
        esac
        i=$((i+1))
    done

    # remaining positional args
    local positional=()
    while [ "$i" -lt "${#args[@]}" ]; do
        positional+=("${args[$i]}")
        i=$((i+1))
    done

    echo "verbose=$verbose output=$output format=$format help=$help"
    if [ "${#positional[@]}" -gt 0 ]; then
        echo "positional: ${positional[*]}"
    else
        echo "positional: (none)"
    fi
}

echo ""
echo "=== manual long opts ==="
parse_long --verbose --output=/dev/null --format json -- input.csv
parse_long --format=tsv --help
parse_long

# ── mini argparse library ─────────────────────────────────────────────────────
# Defines argument specifications and validates against them
declare -A ARG_DEFAULTS
declare -A ARG_REQUIRED
declare -A ARG_PARSED

arg_define() {
    # arg_define <name> <default> <required>
    local name=$1 default=$2 required=${3:-no}
    ARG_DEFAULTS["$name"]="$default"
    ARG_REQUIRED["$name"]="$required"
    ARG_PARSED["$name"]="$default"
}

arg_parse() {
    local i=0
    local args=("$@")
    local positional=()

    while [ "$i" -lt "${#args[@]}" ]; do
        local arg="${args[$i]}"
        case "$arg" in
            --*=*)
                local key="${arg#--}"; key="${key%%=*}"
                local val="${arg#*=}"
                if [ -n "${ARG_DEFAULTS[$key]+x}" ]; then
                    ARG_PARSED["$key"]="$val"
                else
                    echo "WARNING: unknown arg --$key" >&2
                fi
                ;;
            --*)
                local key="${arg#--}"
                if [ -n "${ARG_DEFAULTS[$key]+x}" ]; then
                    i=$((i+1))
                    ARG_PARSED["$key"]="${args[$i]}"
                else
                    echo "WARNING: unknown arg --$key" >&2
                fi
                ;;
            --)
                i=$((i+1))
                while [ "$i" -lt "${#args[@]}" ]; do
                    positional+=("${args[$i]}")
                    i=$((i+1))
                done
                break
                ;;
            *)
                positional+=("$arg")
                ;;
        esac
        i=$((i+1))
    done

    # validate required
    local ok=1
    for key in "${!ARG_REQUIRED[@]}"; do
        if [ "${ARG_REQUIRED[$key]}" = "yes" ] && [ -z "${ARG_PARSED[$key]}" ]; then
            echo "ERROR: required argument --$key is missing" >&2
            ok=0
        fi
    done
    [ "$ok" -eq 0 ] && return 1

    echo "parsed args:"
    for key in $(printf '%s\n' "${!ARG_PARSED[@]}" | sort); do
        echo "  --$key = ${ARG_PARSED[$key]}"
    done
    if [ "${#positional[@]}" -gt 0 ]; then
        echo "  positional: ${positional[*]}"
    fi
}

echo ""
echo "=== mini argparse library ==="
arg_define "host"    "localhost" no
arg_define "port"    "8080"      no
arg_define "user"    ""          yes
arg_define "verbose" "false"     no

arg_parse --host db.example.com --port 5432 --user admin --verbose true extra1 extra2

echo "done"
