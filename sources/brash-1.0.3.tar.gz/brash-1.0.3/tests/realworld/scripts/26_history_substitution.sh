#!/usr/bin/env bash
# 26_history_substitution.sh — history builtins (non-interactive safe subset)
# Note: !! and !$ expansion only works in interactive shells; here we test the
# history builtin itself (history -s, history -d, history -c, history -n,
# HISTSIZE, HISTFILE) which are available in all shells.

# Disable history expansion (safe in scripts) but keep the history builtin
set +H

HISTFILE=/dev/null
HISTSIZE=50

# Add entries manually
history -s "echo first"
history -s "echo second"
history -s "echo third"

# List all entries
history

echo "---"

# history -d: delete entry by line number (1-based)
history -d 2
history

echo "---"

# history -c: clear history
history -c
history
echo "history cleared"

echo "---"

# Re-populate
history -s "alpha"
history -s "beta"
history -s "gamma"
history -s "delta"

# history N: show last N entries
history 2

echo "---"

# HISTSIZE controls max entries (set to small value)
HISTSIZE=3
history -c
for entry in one two three four five; do
    history -s "$entry"
done
# Only last 3 should appear
history

echo "---"

# Check $HISTSIZE and $HISTFILE are set
echo "HISTSIZE=$HISTSIZE"
echo "HISTFILE=/dev/null: $([ "$HISTFILE" = /dev/null ] && echo yes || echo no)"

# fc -l: list history (same as history in most cases)
history -c
history -s "first-fc"
history -s "second-fc"
fc -l

echo done
