#!/usr/bin/env bash
# Mimics patterns found in autoconf-generated configure scripts:
# variable detection, conditional caching, case-style branching.

set -e

# Common configure-style globals
prefix=/usr/local
exec_prefix='${prefix}'
bindir='${exec_prefix}/bin'

# Substitution like autoconf does
expand_path() {
    local p="$1"
    eval "p=\"$p\""
    eval "p=\"$p\""
    echo "$p"
}
echo "bindir=$(expand_path "$bindir")"

# Feature detection
have_cmd() {
    command -v "$1" >/dev/null 2>&1
}

if have_cmd ls; then
    echo "have ls"
fi
if ! have_cmd zzznonexistent_xyz; then
    echo "no zzz"
fi

# AC_CHECK style
checking() { printf 'checking %s... ' "$1"; }
result()   { printf '%s\n' "$1"; }

checking "for /bin/sh"; result "yes"
checking "build system type"; result "$(uname -s)" | head -c 20

# Case-based config
case "$(uname -s)" in
    Linux*)  os=linux ;;
    Darwin*) os=darwin ;;
    *)       os=unknown ;;
esac
echo "os-token=$os"

# Cache file simulation
cache_get() {
    local var=$1
    eval "echo \"\$cv_$var\""
}
cache_set() {
    local var=$1 val=$2
    eval "cv_$var=\$val"
}

cache_set test_var 42
echo "cached: $(cache_get test_var)"

# Conditional logic with command groups
{ have_cmd grep && have_cmd sort; } && echo "have grep+sort"

# Defining symbols
DEFS=
add_def() { DEFS="$DEFS -D$1"; }
add_def HAVE_FOO
add_def HAVE_BAR
add_def 'PACKAGE="brash"'
echo "DEFS:${DEFS}"

# Substitutions table
substitute() {
    local s="$1"
    s="${s//@PREFIX@/$prefix}"
    s="${s//@OS@/$os}"
    echo "$s"
}
substitute 'install to @PREFIX@ on @OS@'

# Final report (counts)
warning_count=0
error_count=0
warn() { warning_count=$((warning_count + 1)); echo "warning: $*" >&2; }
err()  { error_count=$((error_count + 1));   echo "error: $*"   >&2; }

warn "fake warn 1"
warn "fake warn 2"
echo "warns=$warning_count errs=$error_count"
