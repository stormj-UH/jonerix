#!/usr/bin/env bash
# Common string-manipulation idioms used in real shell scripts.

# Trim whitespace
s="  hello  "
trim() {
    local v="$1"
    v="${v#"${v%%[![:space:]]*}"}"
    v="${v%"${v##*[![:space:]]}"}"
    printf '%s' "$v"
}
echo "[$(trim "$s")]"

# Split path
fullpath="/var/log/messages.1.gz"
dir="${fullpath%/*}"
file="${fullpath##*/}"
basename="${file%%.*}"
echo "dir=$dir"
echo "file=$file"
echo "basename=$basename"

# Multiple extensions
extensions() {
    local f="$1"
    local exts=
    while [[ "$f" == *.* ]]; do
        exts="${f##*.}.$exts"
        f="${f%.*}"
    done
    echo "${exts%.}"
}
echo "exts: $(extensions "archive.tar.gz")"

# Replace all occurrences
csv="a,b,c,d"
echo "${csv//,/|}"

# Conditional default with command
host="${HOSTNAME:-$(hostname 2>/dev/null || echo unknown)}"
[ -n "$host" ] && echo "have host"

# Convert array to string and back
arr=(foo bar baz)
joined=$(IFS=,; echo "${arr[*]}")
echo "joined=$joined"

IFS=, read -ra back <<< "$joined"
echo "back-count=${#back[@]}"
echo "back-elem-1=${back[1]}"

# Numeric checks
is_int() {
    [[ "$1" =~ ^-?[0-9]+$ ]]
}
is_int 42 && echo "42 is int"
is_int -7 && echo "-7 is int"
is_int 3.14 || echo "3.14 not int"

# Path-like list manipulation (PATH-style)
P="/a:/b:/c:/b:/d"
# de-dup preserving order
dedup_path() {
    local IFS=:
    local out=()
    local seen=()
    for d in $1; do
        local found=
        for s in "${seen[@]}"; do
            [ "$s" = "$d" ] && { found=1; break; }
        done
        [ -n "$found" ] || { out+=("$d"); seen+=("$d"); }
    done
    local IFS=:
    echo "${out[*]}"
}
echo "dedup: $(dedup_path "$P")"

# Hex/dec conversions
echo "$((0x10))"
echo "$((16#ff))"
printf '%x\n' 255
