#!/usr/bin/env bash
# I/O redirection, pipes, here-docs.

# Simple pipe
echo "a b c d" | tr ' ' '\n' | sort | head -2

# Multi-stage pipe
seq 1 10 | awk 'NR % 2 == 0' | tr '\n' ' '
echo

# Here-doc
cat <<EOF
This is a heredoc.
Variables expand: $HOME (we replaced this).
Backslash escapes: \$ -> dollar.
EOF

# Quoted heredoc (no expansion)
cat <<'EOF'
literal $HOME stays as is
EOF

# Here-string
read line <<< "from here-string"
echo "$line"

# Redirect to file
tmpf=$(mktemp)
echo "line 1" > "$tmpf"
echo "line 2" >> "$tmpf"
echo "line 3" >> "$tmpf"
wc -l < "$tmpf" | tr -d ' '
cat "$tmpf"
rm -f "$tmpf"

# Process substitution
diff <(echo a; echo b; echo c) <(echo a; echo b; echo d) | grep '^[<>]'

# Tee
out=$(echo hello | tee /dev/null)
echo "tee out: $out"
