#!/usr/bin/env bash
# 35_structured_logging.sh — structured-log emit patterns:
# JSON-like via printf, log levels, syslog facility selection, log rotation checks.

set -eu

# ── configuration ─────────────────────────────────────────────────────────────
LOG_LEVEL="${LOG_LEVEL:-info}"
LOG_FORMAT="${LOG_FORMAT:-json}"
SERVICE_NAME="myapp"
SERVICE_VERSION="2.1.0"
HOSTNAME_MOCK="web-01"   # mock hostname for determinism

# ── log level ordering ────────────────────────────────────────────────────────
level_value() {
    case "$1" in
        debug) echo 0 ;;
        info)  echo 1 ;;
        warn)  echo 2 ;;
        error) echo 3 ;;
        fatal) echo 4 ;;
        *)     echo 1 ;;
    esac
}

should_log() {
    local msg_level=$1
    local configured=$(level_value "$LOG_LEVEL")
    local requested=$(level_value "$msg_level")
    [ "$requested" -ge "$configured" ]
}

# ── JSON structured logger ────────────────────────────────────────────────────
# deterministic: no timestamps, no PIDs
log_json() {
    local level=$1; shift
    local message=$1; shift
    local extra_kvs=${1:-}

    should_log "$level" || return 0

    # build JSON fields
    local fields
    printf -v fields '{"level":"%s","service":"%s","version":"%s","host":"%s","msg":%s' \
        "$level" "$SERVICE_NAME" "$SERVICE_VERSION" "$HOSTNAME_MOCK" \
        "$(json_str "$message")"

    if [ -n "$extra_kvs" ]; then
        fields="$fields,$extra_kvs"
    fi
    fields="${fields}}"

    printf '%s\n' "$fields"
}

# escape a string for JSON
json_str() {
    local s=$1
    # backslash, then double-quote, then control chars we care about
    s="${s//\\/\\\\}"
    s="${s//\"/\\\"}"
    s="${s//$'\n'/\\n}"
    s="${s//$'\t'/\\t}"
    printf '"%s"' "$s"
}

echo "=== JSON structured logging ==="
log_json "debug" "debug message ignored at info level"
log_json "info"  "server started" '"port":8080,"proto":"http"'
log_json "warn"  "slow query detected" '"query_ms":1523,"table":"users"'
log_json "error" "connection refused" '"peer":"db:5432","retry":3'

# ── key-value (logfmt) logger ─────────────────────────────────────────────────
log_kv() {
    local level=$1; shift
    should_log "$level" || return 0
    local msg=$1; shift

    printf 'level=%s service=%s host=%s msg="%s"' \
        "$level" "$SERVICE_NAME" "$HOSTNAME_MOCK" "$msg"

    # additional key=value pairs passed as arguments
    while [ "$#" -gt 0 ]; do
        printf ' %s' "$1"
        shift
    done
    printf '\n'
}

echo ""
echo "=== logfmt (key=value) ==="
log_kv "info"  "request handled"  "method=GET" "path=/api/v1/users" "status=200" "duration_ms=42"
log_kv "warn"  "rate limit hit"   "client_ip=192.168.1.100" "limit=100" "window=60s"
log_kv "error" "unhandled exception" "error=NullPointerException" "goroutine=42"

# ── syslog facility/severity selection ───────────────────────────────────────
# In real scripts: logger -p local0.info "message"
# We print what would be invoked.

SYSLOG_FACILITY="${SYSLOG_FACILITY:-local0}"

syslog_priority() {
    local facility=$1 severity=$2
    # syslog facility numbers
    local fac_num
    case "$facility" in
        kern)    fac_num=0 ;;
        user)    fac_num=1 ;;
        mail)    fac_num=2 ;;
        daemon)  fac_num=3 ;;
        auth)    fac_num=4 ;;
        syslog)  fac_num=5 ;;
        lpr)     fac_num=6 ;;
        news)    fac_num=7 ;;
        local0)  fac_num=16 ;;
        local1)  fac_num=17 ;;
        local2)  fac_num=18 ;;
        local3)  fac_num=19 ;;
        local4)  fac_num=20 ;;
        local5)  fac_num=21 ;;
        local6)  fac_num=22 ;;
        local7)  fac_num=23 ;;
        *)       fac_num=1 ;;
    esac
    # syslog severity numbers
    local sev_num
    case "$severity" in
        emerg)   sev_num=0 ;;
        alert)   sev_num=1 ;;
        crit)    sev_num=2 ;;
        err)     sev_num=3 ;;
        warning) sev_num=4 ;;
        notice)  sev_num=5 ;;
        info)    sev_num=6 ;;
        debug)   sev_num=7 ;;
        *)       sev_num=6 ;;
    esac
    echo $(( fac_num * 8 + sev_num ))
}

emit_syslog() {
    local severity=$1; shift
    local message="$*"
    local prio
    prio=$(syslog_priority "$SYSLOG_FACILITY" "$severity")
    printf 'logger -p %s.%s -t %s <%d> "%s"\n' \
        "$SYSLOG_FACILITY" "$severity" "$SERVICE_NAME" "$prio" "$message"
}

echo ""
echo "=== syslog facility dispatch ==="
emit_syslog info "service started"
emit_syslog warning "configuration deprecated"
emit_syslog err "failed to bind socket"
emit_syslog debug "cache miss for key xyz"

# ── log rotation check ────────────────────────────────────────────────────────
check_log_rotation() {
    local logfile=$1 max_size_kb=$2
    # mock: file sizes
    declare -A MOCK_SIZES
    MOCK_SIZES["/var/log/myapp/app.log"]=512
    MOCK_SIZES["/var/log/myapp/error.log"]=8192
    MOCK_SIZES["/var/log/myapp/access.log"]=102400

    local size_kb="${MOCK_SIZES[$logfile]:-0}"
    if [ "$size_kb" -gt "$max_size_kb" ]; then
        echo "rotate: $logfile (${size_kb}KB > ${max_size_kb}KB)"
    else
        echo "ok: $logfile (${size_kb}KB <= ${max_size_kb}KB)"
    fi
}

echo ""
echo "=== log rotation ==="
for logfile in /var/log/myapp/app.log /var/log/myapp/error.log /var/log/myapp/access.log; do
    check_log_rotation "$logfile" 1024
done

echo "done"
