#!/usr/bin/env bash
# 28_git_hooks.sh — emulate common git pre-commit and pre-push hook patterns.
# No actual git invocations; mock vars simulate the hook environment.

set -eu

# ── mock environment (what git sets when invoking hooks) ──────────────────────
GIT_DIR=".git"
GIT_WORK_TREE="."
COMMIT_SOURCE=""        # empty = normal commit
MERGE_HEAD=""           # empty = not a merge

# ── pre-commit: staged-file validation ───────────────────────────────────────
# In real hooks this would be: git diff --cached --name-only --diff-filter=ACM
# We mock with a static list.
staged_files=(
    "src/main.c"
    "src/util.c"
    "include/util.h"
    "README.md"
    "scripts/build.sh"
)

check_trailing_whitespace() {
    local file=$1
    # simulate: grep -P '\s+$' "$file" — we just check the name pattern
    case "$file" in
        *.sh|*.c|*.h) echo "check-whitespace: $file ok" ;;
        *.md)         echo "check-whitespace: $file skipped (markdown)" ;;
        *)            echo "check-whitespace: $file ok" ;;
    esac
}

check_file_size() {
    local file=$1 limit_kb=500
    # mock: all files are small
    echo "check-size: $file < ${limit_kb}KB ok"
}

errors=0
for f in "${staged_files[@]}"; do
    check_trailing_whitespace "$f"
    check_file_size "$f"
done

# ── check for debug statements left in code ──────────────────────────────────
check_debug_patterns() {
    local file=$1
    local debug_found=0
    # simulate pattern matching (no actual file read)
    case "$file" in
        *main.c) debug_found=0 ;;
        *util.c) debug_found=0 ;;
        *)       debug_found=0 ;;
    esac
    if [ "$debug_found" -eq 1 ]; then
        echo "ERROR: debug statement found in $file" >&2
        errors=$((errors + 1))
    fi
}

for f in "${staged_files[@]}"; do
    case "$f" in *.c|*.h) check_debug_patterns "$f" ;; esac
done

# ── pre-commit: branch name protection ───────────────────────────────────────
CURRENT_BRANCH="feature/add-logging"   # mock; real: git symbolic-ref --short HEAD
protected_branches="main master release"

branch_is_protected() {
    local branch=$1
    for b in $protected_branches; do
        [ "$branch" = "$b" ] && return 0
    done
    return 1
}

if branch_is_protected "$CURRENT_BRANCH"; then
    echo "ERROR: direct commit to protected branch $CURRENT_BRANCH" >&2
    errors=$((errors + 1))
else
    echo "branch-check: $CURRENT_BRANCH is not protected, ok"
fi

# ── pre-commit: commit message lint (from COMMIT_EDITMSG simulation) ─────────
COMMIT_MSG="feat(logging): add structured JSON log output

Adds a structured logger that emits JSON lines to stderr.
Refs #42"

check_commit_msg() {
    local msg=$1
    local first_line
    first_line=$(printf '%s' "$msg" | head -1)
    local len=${#first_line}

    # conventional commits pattern check
    if printf '%s' "$first_line" | grep -qE '^(feat|fix|docs|style|refactor|test|chore|perf|ci|build|revert)(\([^)]+\))?: .+'; then
        echo "commit-msg: conventional commit ok (${len} chars)"
    else
        echo "commit-msg: WARNING — does not match conventional commits format"
    fi

    # length check
    if [ "$len" -gt 72 ]; then
        echo "commit-msg: WARNING — first line too long ($len > 72)"
    fi
}

check_commit_msg "$COMMIT_MSG"

# ── pre-push: remote/ref validation ──────────────────────────────────────────
# pre-push receives lines on stdin: <local-ref> <local-sha1> <remote-ref> <remote-sha1>
# We simulate with a here-string
PUSH_INPUT="refs/heads/feature/add-logging abc1234 refs/heads/feature/add-logging 0000000
refs/heads/feature/add-logging abc1234 refs/heads/main def5678"

echo "$PUSH_INPUT" | while read -r local_ref local_sha remote_ref remote_sha; do
    # extract branch name from ref
    remote_branch="${remote_ref#refs/heads/}"
    if printf '%s ' "$protected_branches" | grep -qw "$remote_branch"; then
        echo "pre-push: BLOCK push to protected branch $remote_branch"
    else
        echo "pre-push: allow push $local_ref -> $remote_ref"
    fi
done

# ── summary ──────────────────────────────────────────────────────────────────
if [ "$errors" -eq 0 ]; then
    echo "pre-commit: all checks passed"
else
    echo "pre-commit: $errors error(s) found"
fi
