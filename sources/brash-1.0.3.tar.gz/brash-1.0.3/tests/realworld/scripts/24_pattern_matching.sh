#!/usr/bin/env bash
# 24_pattern_matching.sh — extglob !(?), case patterns, [[ =~ ]] capture groups

shopt -s extglob

# extglob: ?(pattern) — zero or one
x="color"
[[ $x == col?(ou)r ]] && echo "?(ou) matched color"
x="colour"
[[ $x == col?(ou)r ]] && echo "?(ou) matched colour"

# extglob: *(pattern) — zero or more
x="aaa"
[[ $x == *(a) ]] && echo "*(a) matched aaa"
x=""
[[ $x == *(a) ]] && echo "*(a) matched empty"

# extglob: +(pattern) — one or more
x="bbb"
[[ $x == +(b) ]] && echo "+(b) matched bbb"
x=""
[[ $x == +(b) ]] || echo "+(b) did not match empty"

# extglob: @(pattern) — exactly one
x="cat"
[[ $x == @(cat|dog) ]] && echo "@(cat|dog) matched cat"
x="bird"
[[ $x == @(cat|dog) ]] || echo "@(cat|dog) did not match bird"

# extglob: !(pattern) — anything except
x="foo"
[[ $x == !(bar) ]] && echo "!(bar) matched foo"
x="bar"
[[ $x == !(bar) ]] || echo "!(bar) did not match bar"

# extglob in case
for word in file.c file.h file.o README.md; do
    case $word in
        *.@(c|h))    echo "$word: source" ;;
        *.o)         echo "$word: object" ;;
        !(*.*)  )    echo "$word: no extension" ;;
        *)           echo "$word: other" ;;
    esac
done

# case: multiple patterns per clause
for val in 1 2 3 4 5; do
    case $val in
        1|3|5) echo "$val: odd" ;;
        2|4)   echo "$val: even" ;;
    esac
done

# case: glob patterns
for s in hello HELLO world 123; do
    case $s in
        [A-Z]*)  echo "$s: uppercase start" ;;
        [0-9]*)  echo "$s: numeric start" ;;
        *)       echo "$s: other" ;;
    esac
done

# [[ =~ ]]: basic regex match
str="2024-01-15"
if [[ $str =~ ^([0-9]{4})-([0-9]{2})-([0-9]{2})$ ]]; then
    echo "date matched"
    echo "year=${BASH_REMATCH[1]}"
    echo "month=${BASH_REMATCH[2]}"
    echo "day=${BASH_REMATCH[3]}"
fi

# [[ =~ ]]: no match
str="not-a-date"
if [[ $str =~ ^[0-9]{4}-[0-9]{2}-[0-9]{2}$ ]]; then
    echo "should not match"
else
    echo "correctly did not match"
fi

# [[ =~ ]]: partial match (anchored vs unanchored)
str="hello world"
[[ $str =~ world ]] && echo "unanchored world match"
[[ $str =~ ^world ]] || echo "anchored ^world no match"

# Parameter expansion with extglob: strip patterns
path="/usr/local/bin/bash"
echo "${path##*/}"         # basename
echo "${path%/*}"          # dirname-like

filename="archive.tar.gz"
echo "${filename%%.*}"     # strip all extensions
echo "${filename#*.}"      # strip first extension

# extglob in ${} parameter
name="file.tar.gz"
echo "${name%.+(gz|bz2)}"  # strip .gz or .bz2

echo done
