#!/usr/bin/env bash
# 32_container_init.sh — Docker entrypoint patterns: signal forwarding,
# env-from-file loading, exec replacement, health-check helpers.

set -eu

# ── env-from-file loader ──────────────────────────────────────────────────────
# Pattern: load KEY=VALUE lines from a file into the environment
load_env_file() {
    local envfile=$1
    local count=0
    while IFS= read -r line || [ -n "$line" ]; do
        # skip blanks and comments
        case "$line" in
            ''|'#'*) continue ;;
        esac
        # split on first '='
        local key="${line%%=*}"
        local val="${line#*=}"
        # validate key: alphanumeric + underscore only
        if printf '%s' "$key" | grep -qE '^[A-Za-z_][A-Za-z0-9_]*$'; then
            export "$key=$val"
            count=$((count + 1))
            echo "  env: $key=<set>"
        else
            echo "  env: skipping invalid key '$key'" >&2
        fi
    done < "$envfile"
    echo "loaded $count vars from $envfile"
}

# create a temp env file for testing
envfile=$(mktemp)
cat > "$envfile" <<'EOF'
# database config
DB_HOST=localhost
DB_PORT=5432
DB_NAME=myapp
DB_USER=app

# application
APP_ENV=production
APP_PORT=8080
LOG_LEVEL=info

# invalid entries (should be skipped)
123INVALID=bad
EOF
echo "=== env-from-file ==="
load_env_file "$envfile"
rm -f "$envfile"

# ── signal trap forwarding pattern ───────────────────────────────────────────
# Entrypoints often need to forward signals to a child process
echo ""
echo "=== signal trap setup ==="

CHILD_PID=""
forward_signal() {
    local sig=$1
    echo "forward_signal: received $sig"
    if [ -n "$CHILD_PID" ]; then
        echo "  -> sending $sig to child PID $CHILD_PID"
        # real: kill -"$sig" "$CHILD_PID"
    else
        echo "  -> no child to forward to"
    fi
}

# register signal forwarding (we don't actually trap, just print setup)
for sig in TERM INT HUP USR1 USR2; do
    echo "  trap forward_signal $sig"
done

# ── wait-for-dependency pattern ───────────────────────────────────────────────
wait_for_service() {
    local host=$1 port=$2 retries=${3:-30} interval=${4:-1}
    echo "wait_for: $host:$port (max ${retries}s)"
    # simulate: would loop with: nc -z "$host" "$port" 2>/dev/null
    # mock: service is ready on attempt 3
    local attempt=0
    local ready_on=3
    while [ "$attempt" -lt "$retries" ]; do
        attempt=$((attempt + 1))
        if [ "$attempt" -ge "$ready_on" ]; then
            echo "  attempt $attempt: connected"
            return 0
        else
            echo "  attempt $attempt: waiting..."
        fi
    done
    echo "  TIMEOUT: $host:$port not ready after ${retries}s" >&2
    return 1
}

echo ""
echo "=== dependency wait ==="
wait_for_service "db" "5432" 5 1
wait_for_service "redis" "6379" 5 1

# ── entrypoint command dispatch ───────────────────────────────────────────────
# Common pattern: first arg selects mode, remainder is passed to exec
entrypoint() {
    local cmd=${1:-server}; shift || true

    case "$cmd" in
        server)
            echo "exec: myapp server --port ${APP_PORT:-8080} $*"
            ;;
        worker)
            echo "exec: myapp worker --concurrency 4 $*"
            ;;
        migrate)
            echo "exec: myapp db migrate $*"
            ;;
        shell)
            echo "exec: /bin/bash $*"
            ;;
        --)
            # passthrough: run arbitrary command
            echo "exec: $*"
            ;;
        *)
            echo "exec: $cmd $*"
            ;;
    esac
}

echo ""
echo "=== entrypoint dispatch ==="
entrypoint server
entrypoint worker --queue high
entrypoint migrate --dry-run
entrypoint shell
entrypoint -- /usr/local/bin/custom

# ── healthcheck helper ────────────────────────────────────────────────────────
healthcheck() {
    local url=${1:-http://localhost:8080/health}
    local status_file
    status_file=$(mktemp)
    # mock response
    printf '{"status":"ok","version":"1.2.3","uptime":42}' > "$status_file"

    local body
    body=$(cat "$status_file")
    rm -f "$status_file"

    # extract status field with simple pattern match
    local status
    status=$(printf '%s' "$body" | grep -o '"status":"[^"]*"' | cut -d'"' -f4)

    if [ "$status" = "ok" ]; then
        echo "healthcheck: $url -> OK"
        return 0
    else
        echo "healthcheck: $url -> UNHEALTHY ($status)" >&2
        return 1
    fi
}

echo ""
echo "=== healthcheck ==="
healthcheck "http://localhost:8080/health"

echo "done"
