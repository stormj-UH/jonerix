#!/usr/bin/env bash
# 30_package_manager.sh — apt/dpkg postinst, brew install, pip hook patterns.
# Mocks tool detection, conditional install, upgrade logic.

set -eu

# ── mock tool availability (no real commands) ─────────────────────────────────
MOCK_INSTALLED="bash curl git python3 make gcc"
MOCK_MISSING="rustup jq fzf bat ripgrep"

has_cmd() {
    local cmd=$1
    # simulate: command -v "$cmd" >/dev/null 2>&1
    for c in $MOCK_INSTALLED; do
        [ "$c" = "$cmd" ] && return 0
    done
    return 1
}

# ── dpkg postinst: standard phase dispatch ───────────────────────────────────
postinst_configure() {
    local pkg=$1 version=$2
    echo "postinst: configure $pkg $version"

    # create system user if needed
    if ! grep -qw "^${pkg}:" /dev/null 2>/dev/null; then
        echo "adduser --system --no-create-home --group $pkg"
    fi

    # set up default config
    local conf="/etc/$pkg/$pkg.conf"
    echo "install -d -m 0755 /etc/$pkg"
    echo "install -m 0640 /usr/share/doc/$pkg/examples/$pkg.conf $conf || true"

    # enable and start service
    echo "systemctl enable $pkg.service 2>/dev/null || update-rc.d $pkg defaults"
}

postinst() {
    local action=${1:-configure}
    local old_version=${2:-}
    case "$action" in
        configure)
            postinst_configure "myservice" "1.2.3"
            if [ -n "$old_version" ]; then
                echo "upgrade from $old_version: running migrations"
            else
                echo "fresh install: seeding database"
            fi
            ;;
        abort-upgrade)   echo "postinst: abort-upgrade from ${old_version:-unknown}" ;;
        abort-remove)    echo "postinst: abort-remove" ;;
        abort-deconfigure) echo "postinst: abort-deconfigure" ;;
        *)               echo "postinst: unexpected action $action" ;;
    esac
}

echo "=== dpkg postinst scenarios ==="
postinst configure ""
postinst configure "1.1.0"
postinst abort-upgrade "1.1.0"

# ── brew install: cask/formula pattern ───────────────────────────────────────
HOMEBREW_PREFIX="${HOMEBREW_PREFIX:-/opt/homebrew}"
HOMEBREW_CELLAR="${HOMEBREW_CELLAR:-$HOMEBREW_PREFIX/Cellar}"

brew_install() {
    local formula=$1 version=$2
    local keg="$HOMEBREW_CELLAR/$formula/$version"

    echo "==> Installing $formula"
    echo "mkdir -p $keg/bin $keg/lib $keg/include"
    echo "make install PREFIX=$keg"
    echo "ln -sf $keg/bin/$formula $HOMEBREW_PREFIX/bin/$formula"

    # post-install: caveats
    case "$formula" in
        openssl@3)
            echo "==> Caveats: add to pkg-config path"
            echo "  export PKG_CONFIG_PATH=\"$keg/lib/pkgconfig:\$PKG_CONFIG_PATH\""
            ;;
        python@3.12)
            echo "==> Caveats: unversioned symlinks"
            echo "  $HOMEBREW_PREFIX/bin/python3 -> $keg/bin/python3.12"
            ;;
        *)
            echo "==> No caveats"
            ;;
    esac
}

echo "=== brew install scenarios ==="
brew_install "openssl@3" "3.2.1"
brew_install "python@3.12" "3.12.2"
brew_install "ripgrep" "14.1.0"

# ── pip wheel postinstall hook ────────────────────────────────────────────────
PIP_INSTALL_SCRIPTS=(
    "setup_db.py"
    "compile_assets.py"
    "generate_schemas.py"
)

pip_postinstall() {
    local pkg=$1 version=$2
    echo "=== pip postinstall: $pkg $version ==="

    # check python version constraint
    local py_version="3.11"
    local min_py="3.8"

    version_ok() {
        # simple major.minor comparison (no bc, no sort -V)
        local v1_maj=${1%%.*} v1_min=${1#*.}
        local v2_maj=${2%%.*} v2_min=${2#*.}
        [ "$v1_maj" -gt "$v2_maj" ] && return 0
        [ "$v1_maj" -eq "$v2_maj" ] && [ "$v1_min" -ge "$v2_min" ] && return 0
        return 1
    }

    if version_ok "$py_version" "$min_py"; then
        echo "python $py_version >= $min_py: ok"
    else
        echo "python $py_version < $min_py: unsupported" >&2
        return 1
    fi

    # run entry-point scripts
    for s in "${PIP_INSTALL_SCRIPTS[@]}"; do
        echo "running post-install hook: $s"
    done
}

pip_postinstall "mypackage" "2.4.1"

# ── detect and install missing tools ─────────────────────────────────────────
echo "=== tool detection ==="
required_tools="bash curl git python3 make gcc jq fzf"
missing=()

for tool in $required_tools; do
    if has_cmd "$tool"; then
        echo "  [ok] $tool"
    else
        echo "  [missing] $tool"
        missing+=("$tool")
    fi
done

if [ "${#missing[@]}" -gt 0 ]; then
    echo "need to install: ${missing[*]}"
else
    echo "all required tools present"
fi

echo "done"
