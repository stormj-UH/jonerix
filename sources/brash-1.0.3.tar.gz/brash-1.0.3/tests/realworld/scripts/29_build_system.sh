#!/usr/bin/env bash
# 29_build_system.sh — shell snippets that mirror what 'make' invokes as recipe lines.
# Patterns: source list iteration, dependency scanning, incremental build logic.

set -eu

# ── mock build variables (what make would export) ────────────────────────────
CC="gcc"
CFLAGS="-O2 -Wall -Wextra"
LDFLAGS="-lm"
PREFIX="/usr/local"
OBJDIR="build/obj"
BINDIR="build/bin"
SRCS="src/main.c src/util.c src/parser.c src/lexer.c"
HDRS="include/util.h include/parser.h include/lexer.h"

# ── utility: derive object file path from source ─────────────────────────────
obj_for() {
    local src=$1
    local base
    base=$(basename "$src" .c)
    printf '%s/%s.o' "$OBJDIR" "$base"
}

# ── compile each source (dry-run: print command, don't run) ──────────────────
compile_step() {
    local src=$1
    local obj
    obj=$(obj_for "$src")
    echo "$CC $CFLAGS -c $src -o $obj"
}

echo "=== compile phase ==="
for f in $SRCS; do
    compile_step "$f"
done

# ── link step ────────────────────────────────────────────────────────────────
all_objs=""
for f in $SRCS; do
    o=$(obj_for "$f")
    all_objs="$all_objs $o"
done
# trim leading space
all_objs="${all_objs# }"

echo "=== link phase ==="
echo "$CC $LDFLAGS $all_objs -o $BINDIR/myapp"

# ── install step (make install pattern) ──────────────────────────────────────
install_files() {
    local dest=$1; shift
    for f in "$@"; do
        echo "install -m 0755 $f $dest/$(basename "$f")"
    done
}

echo "=== install phase ==="
install_files "$PREFIX/bin"  "$BINDIR/myapp"
install_files "$PREFIX/include" $HDRS

# ── dependency generation (makedepend pattern) ───────────────────────────────
echo "=== dependency scan ==="
for src in $SRCS; do
    obj=$(obj_for "$src")
    # simulate deps: each .c depends on same-name .h if it exists in HDRS
    base=$(basename "$src" .c)
    deps="$obj: $src"
    for hdr in $HDRS; do
        hname=$(basename "$hdr" .h)
        [ "$hname" = "$base" ] && deps="$deps $hdr"
    done
    echo "$deps"
done

# ── phony targets simulation ──────────────────────────────────────────────────
MAKECMDGOALS="${MAKECMDGOALS:-all}"

run_target() {
    local target=$1
    case "$target" in
        all)     echo "target all: compile + link" ;;
        clean)   echo "target clean: rm -rf build/" ;;
        install) echo "target install: copy to $PREFIX" ;;
        test)    echo "target test: run test suite" ;;
        dist)    echo "target dist: create tarball" ;;
        *)       echo "target $target: unknown" ;;
    esac
}

echo "=== make targets ==="
for t in all clean install test dist bogus; do
    run_target "$t"
done

# ── recursive make pattern ────────────────────────────────────────────────────
SUBDIRS="lib core cli tests"
echo "=== recursive make ==="
for subdir in $SUBDIRS; do
    echo "make -C $subdir $MAKECMDGOALS"
done

# ── conditional feature flags ─────────────────────────────────────────────────
WITH_SSL="${WITH_SSL:-yes}"
WITH_ZLIB="${WITH_ZLIB:-yes}"
WITH_LTO="${WITH_LTO:-no}"

echo "=== feature flags ==="
extra_cflags=""
extra_ldflags=""

if [ "$WITH_SSL" = "yes" ]; then
    extra_cflags="$extra_cflags -DUSE_SSL"
    extra_ldflags="$extra_ldflags -lssl -lcrypto"
fi
if [ "$WITH_ZLIB" = "yes" ]; then
    extra_cflags="$extra_cflags -DUSE_ZLIB"
    extra_ldflags="$extra_ldflags -lz"
fi
if [ "$WITH_LTO" = "yes" ]; then
    extra_cflags="$extra_cflags -flto"
    extra_ldflags="$extra_ldflags -flto"
fi

echo "CFLAGS: $CFLAGS${extra_cflags}"
echo "LDFLAGS: $LDFLAGS${extra_ldflags}"

echo "done"
