# Configure script differential tests

This directory contains a differential harness that runs real GNU autoconf-generated
`configure` scripts under both bash and brash with `--help`, then checks that
stdout, stderr, and exit code are byte-identical.  Autoconf-generated configure
scripts are among the densest real-world consumers of bash: they use heredocs,
complex case patterns, arithmetic, nested subshells, and many POSIX corner cases —
making them an effective proxy for real-world drop-in compatibility.

## Corpus

| Script    | Source                                            | configure size |
|-----------|---------------------------------------------------|----------------|
| gnu-hello | https://ftp.gnu.org/gnu/hello/hello-2.12.tar.gz   | ~648 KB        |
| gnu-make  | https://ftp.gnu.org/gnu/make/make-4.4.1.tar.gz    | ~471 KB        |
| gnu-bash  | https://ftp.gnu.org/gnu/bash/bash-5.2.tar.gz      | ~620 KB        |
| gnu-sed   | https://ftp.gnu.org/gnu/sed/sed-4.9.tar.gz        | ~1.2 MB        |
| gnu-gzip  | https://ftp.gnu.org/gnu/gzip/gzip-1.13.tar.gz     | ~891 KB        |

`configure --help` was chosen deliberately: it exercises the full help-text
generation and option-parsing logic without touching the host system (no
compiler probing, no filesystem mutations).  This makes the test hermetic and
fast (each run takes under one second).

## Running

```sh
# First build brash:
cargo build --release

# Then run the harness (downloads tarballs on first run, caches them):
tests/realworld/configure/run.sh

# Verbose mode shows diffs on failures:
VERBOSE=1 tests/realworld/configure/run.sh

# Skip re-downloading if .cache/ is already populated:
SKIP_DOWNLOAD=1 tests/realworld/configure/run.sh
```

Tarballs are extracted and cached in `.cache/` (git-ignored).  Re-running
without `SKIP_DOWNLOAD` re-downloads only missing tarballs.

## Scoring

A "pass" means byte-identical stdout + stderr + matching exit code between
bash and brash.  The summary line reports the percentage:

```
=== 5 passed, 0 failed, 0 hung, 0 skipped, 5 total — 100% byte-identical ===
```
