#!/usr/bin/env bash
# tests/realworld/configure/run.sh — differential test of brash vs bash on real configure scripts.
#
# Downloads 5 GNU autoconf-generated configure scripts, extracts each source
# tree, and runs "configure --help" from within that tree under both bash and
# brash.  Diffs stdout, stderr, and exit code.  A "pass" means byte-identical
# output and matching exit codes.
#
# configure scripts detect their own source directory at startup, so they must
# run from within their own extracted source tree — not as an external script
# path.  This harness extracts each tarball (once) into .cache/<name>/ and
# runs ./configure --help from there.
#
# Usage:
#   tests/realworld/configure/run.sh              # run all 5 scripts
#   BRASH_BIN=/path/to/brash tests/realworld/configure/run.sh
#   VERBOSE=1 tests/realworld/configure/run.sh    # show diffs on failures
#   SKIP_DOWNLOAD=1 tests/realworld/configure/run.sh  # skip re-download
#
# Output:
#   Per-script: PASS, FAIL <reason>, SKIP, or HANG
#   Summary: "<passed>/<total> byte-identical"
#   Exit 0 if all pass, 1 if any fail/hang.

set -u

script_dir=$(cd "$(dirname "$0")" && pwd)
repo_root=$(cd "$script_dir/../../.." && pwd)
cache_dir="$script_dir/.cache"
mkdir -p "$cache_dir"

BRASH_BIN="${BRASH_BIN:-$repo_root/target/release/brash}"
BASH_BIN="${BASH_BIN:-/opt/homebrew/bin/bash}"
[ -x "$BASH_BIN" ] || BASH_BIN=/bin/bash
TIMEOUT_SEC="${TIMEOUT_SEC:-60}"
VERBOSE="${VERBOSE:-}"
SKIP_DOWNLOAD="${SKIP_DOWNLOAD:-}"

if [ ! -x "$BRASH_BIN" ]; then
    echo "ERROR: brash not found at $BRASH_BIN — run 'cargo build --release' first" >&2
    exit 2
fi
if [ ! -x "$BASH_BIN" ]; then
    echo "ERROR: bash not found at $BASH_BIN" >&2
    exit 2
fi

# locate timeout binary (gtimeout on macOS via homebrew coreutils)
if command -v timeout >/dev/null 2>&1; then
    TIMEOUT_CMD=timeout
elif command -v gtimeout >/dev/null 2>&1; then
    TIMEOUT_CMD=gtimeout
else
    TIMEOUT_CMD=
fi

run_with_timeout() {
    if [ -n "$TIMEOUT_CMD" ]; then
        "$TIMEOUT_CMD" "$TIMEOUT_SEC" "$@"
    else
        "$@"
    fi
}

# ---------------------------------------------------------------------------
# Corpus: (name, tarball_url, top-level-dir-within-tar)
# Each tarball's top-level directory contains the configure script.
# ---------------------------------------------------------------------------
declare -a NAMES URLS TOPDIRS

NAMES+=(gnu-hello)
URLS+=( "https://ftp.gnu.org/gnu/hello/hello-2.12.tar.gz")
TOPDIRS+=("hello-2.12")

NAMES+=(gnu-make)
URLS+=( "https://ftp.gnu.org/gnu/make/make-4.4.1.tar.gz")
TOPDIRS+=("make-4.4.1")

NAMES+=(gnu-bash)
URLS+=( "https://ftp.gnu.org/gnu/bash/bash-5.2.tar.gz")
TOPDIRS+=("bash-5.2")

NAMES+=(gnu-sed)
URLS+=( "https://ftp.gnu.org/gnu/sed/sed-4.9.tar.gz")
TOPDIRS+=("sed-4.9")

NAMES+=(gnu-gzip)
URLS+=( "https://ftp.gnu.org/gnu/gzip/gzip-1.13.tar.gz")
TOPDIRS+=("gzip-1.13")

# ---------------------------------------------------------------------------
# Download + extract phase — extracts each tarball into .cache/<name>/
# ---------------------------------------------------------------------------
prepare_source() {
    local name="$1" url="$2" topdir="$3"
    local tarball="$cache_dir/${name}.tar.gz"
    local srcdir="$cache_dir/${name}"

    # If fully extracted and not re-download mode, skip
    if [ -f "$srcdir/configure" ] && [ -n "$SKIP_DOWNLOAD" ]; then
        return 0
    fi
    if [ -f "$srcdir/configure" ] && [ -f "$tarball" ]; then
        return 0
    fi

    if [ ! -f "$tarball" ] || [ ! -s "$tarball" ]; then
        printf "  downloading %s ... " "$name"
        if ! curl -fsSL --max-time 120 -o "$tarball" "$url" 2>/dev/null; then
            printf "FAILED\n"
            rm -f "$tarball"
            return 1
        fi
        printf "ok\n"
    fi

    printf "  extracting %s ... " "$name"
    rm -rf "$srcdir"
    mkdir -p "$srcdir"
    if ! tar -xzf "$tarball" -C "$cache_dir" "$topdir/configure" 2>/dev/null; then
        printf "FAILED\n"
        rm -rf "$srcdir"
        return 1
    fi
    # Move configure into srcdir
    if [ -f "$cache_dir/$topdir/configure" ]; then
        cp "$cache_dir/$topdir/configure" "$srcdir/configure"
        rm -rf "$cache_dir/$topdir"
    else
        printf "FAILED (no configure in tar)\n"
        return 1
    fi
    printf "ok\n"
    return 0
}

echo "=== configure --help differential test (brash vs bash) ==="
printf "  brash: %s\n" "$BRASH_BIN"
printf "  bash:  %s\n" "$BASH_BIN"
echo

passed=0
failed=0
hung=0
skipped=0
total=${#NAMES[@]}

for i in "${!NAMES[@]}"; do
    name="${NAMES[$i]}"
    url="${URLS[$i]}"
    topdir="${TOPDIRS[$i]}"
    srcdir="$cache_dir/${name}"

    if ! prepare_source "$name" "$url" "$topdir"; then
        printf "SKIP: %s (download/extract failed)\n" "$name"
        skipped=$((skipped + 1))
        continue
    fi

    sandbox=$(mktemp -d)
    out_dir="$sandbox"

    # Run bash configure --help from within srcdir
    bash_stdout="$out_dir/bash.stdout"
    bash_stderr="$out_dir/bash.stderr"
    (cd "$srcdir" && env -i HOME="$HOME" PATH="/usr/bin:/bin:/usr/local/bin:/opt/homebrew/bin" \
        TMPDIR="${TMPDIR:-/tmp}" \
        run_with_timeout "$BASH_BIN" ./configure --help) \
        > "$bash_stdout" 2> "$bash_stderr"
    bash_rc=$?

    # Run brash configure --help from within srcdir
    brash_stdout="$out_dir/brash.stdout"
    brash_stderr="$out_dir/brash.stderr"
    (cd "$srcdir" && env -i HOME="$HOME" PATH="/usr/bin:/bin:/usr/local/bin:/opt/homebrew/bin" \
        TMPDIR="${TMPDIR:-/tmp}" \
        run_with_timeout "$BRASH_BIN" ./configure --help) \
        > "$brash_stdout" 2> "$brash_stderr"
    brash_rc=$?

    if [ "$brash_rc" -eq 124 ] || [ "$bash_rc" -eq 124 ]; then
        printf "HANG: %s (brash_rc=%d bash_rc=%d)\n" "$name" "$brash_rc" "$bash_rc"
        hung=$((hung + 1))
        rm -rf "$sandbox"
        continue
    fi

    stdout_diff=
    stderr_diff=
    rc_diff=
    if ! cmp -s "$brash_stdout" "$bash_stdout"; then
        stdout_diff=stdout
    fi
    if ! cmp -s "$brash_stderr" "$bash_stderr"; then
        stderr_diff=stderr
    fi
    if [ "$brash_rc" -ne "$bash_rc" ]; then
        rc_diff=rc
    fi

    if [ -z "$stdout_diff" ] && [ -z "$stderr_diff" ] && [ -z "$rc_diff" ]; then
        printf "PASS: %s\n" "$name"
        passed=$((passed + 1))
    else
        reasons=$(printf "%s %s %s" "$stdout_diff" "$stderr_diff" "$rc_diff" | tr -s ' ' | sed 's/^ *//;s/ *$//')
        printf "FAIL: %s [%s]\n" "$name" "$reasons"
        failed=$((failed + 1))

        if [ -n "$VERBOSE" ]; then
            if [ -n "$stdout_diff" ]; then
                echo "  --- stdout diff (bash→brash, first 40 lines) ---"
                diff -u "$bash_stdout" "$brash_stdout" | sed 's/^/  /' | head -40
            fi
            if [ -n "$stderr_diff" ]; then
                echo "  --- stderr diff ---"
                diff -u "$bash_stderr" "$brash_stderr" | sed 's/^/  /' | head -20
            fi
            if [ -n "$rc_diff" ]; then
                printf "  --- exit code: bash=%d brash=%d ---\n" "$bash_rc" "$brash_rc"
            fi
        fi
    fi

    rm -rf "$sandbox"
done

echo
printf "=== %d passed, %d failed, %d hung, %d skipped, %d total — %d%% byte-identical ===\n" \
    "$passed" "$failed" "$hung" "$skipped" "$total" \
    $(( total > 0 ? passed * 100 / total : 0 ))

if [ "$failed" -ne 0 ] || [ "$hung" -ne 0 ]; then
    exit 1
fi
exit 0
