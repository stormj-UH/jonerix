#!/bin/sh
# tests/binsh/run.sh — brash-as-/bin/sh smoke test harness
#
# Usage:
#   ./tests/binsh/run.sh                     # compare brash vs /bin/sh
#   BRASH=/path/to/brash ./tests/binsh/run.sh
#   ./tests/binsh/run.sh --brash-only         # just run under brash
#   ./tests/binsh/run.sh --syssh-only         # just run under system sh
#
# Exit code: 0 if all tests pass identically, non-zero otherwise.

set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
SCRIPTS_DIR="$SCRIPT_DIR/scripts"

# ---- locate brash ----
if test -z "$BRASH"; then
    # Auto-detect: walk up from tests/binsh looking for target/release/brash
    _dir="$SCRIPT_DIR"
    while test "$_dir" != "/"; do
        if test -x "$_dir/target/release/brash"; then
            BRASH="$_dir/target/release/brash"
            break
        fi
        _dir=$(dirname "$_dir")
    done
fi

if test -z "$BRASH" || ! test -x "$BRASH"; then
    echo "ERROR: brash binary not found. Set BRASH=/path/to/brash or run 'cargo build --release' first." >&2
    exit 1
fi

SYSSH=/bin/sh

echo "brash:  $BRASH"
echo "syssh:  $SYSSH"
echo "scripts: $SCRIPTS_DIR"
echo ""

# ---- mode flags ----
BRASH_ONLY=0
SYSSH_ONLY=0
for arg in "$@"; do
    case "$arg" in
        --brash-only) BRASH_ONLY=1 ;;
        --syssh-only) SYSSH_ONLY=1 ;;
    esac
done

# ---- sandbox: put a 'sh' symlink on PATH pointing to brash ----
SANDBOX=$(mktemp -d)
trap 'rm -rf "$SANDBOX"' EXIT
ln -s "$BRASH" "$SANDBOX/sh"

# ---- helpers ----
PASS=0
FAIL=0
SKIP=0
FAIL_LIST=""

run_one() {
    _script="$1"
    _name=$(basename "$_script")
    _outdir=$(mktemp -d)

    # Run under brash (sandboxed PATH so shebang #!/bin/sh hits brash)
    if test "$SYSSH_ONLY" = "0"; then
        PATH="$SANDBOX:$PATH" "$BRASH" "$_script" \
            > "$_outdir/brash.out" 2> "$_outdir/brash.err"
        _brash_exit=$?
    fi

    # Run under system /bin/sh
    if test "$BRASH_ONLY" = "0"; then
        "$SYSSH" "$_script" \
            > "$_outdir/syssh.out" 2> "$_outdir/syssh.err"
        _syssh_exit=$?
    fi

    if test "$BRASH_ONLY" = "1"; then
        if test "$_brash_exit" = "0"; then
            echo "PASS (brash-only): $_name"
            PASS=$((PASS + 1))
        else
            echo "FAIL (brash exit=$_brash_exit): $_name"
            echo "  stderr: $(cat "$_outdir/brash.err")"
            FAIL=$((FAIL + 1))
            FAIL_LIST="$FAIL_LIST $_name"
        fi
    elif test "$SYSSH_ONLY" = "1"; then
        if test "$_syssh_exit" = "0"; then
            echo "PASS (syssh-only): $_name"
            PASS=$((PASS + 1))
        else
            echo "FAIL (syssh exit=$_syssh_exit): $_name"
            echo "  stderr: $(cat "$_outdir/syssh.err")"
            FAIL=$((FAIL + 1))
            FAIL_LIST="$FAIL_LIST $_name"
        fi
    else
        # Compare outputs
        _stdout_match=1
        _exit_match=1

        if ! diff -q "$_outdir/brash.out" "$_outdir/syssh.out" >/dev/null 2>&1; then
            _stdout_match=0
        fi
        if test "$_brash_exit" != "$_syssh_exit"; then
            _exit_match=0
        fi

        if test "$_stdout_match" = "1" && test "$_exit_match" = "1"; then
            echo "PASS: $_name"
            PASS=$((PASS + 1))
        else
            echo "FAIL: $_name"
            if test "$_exit_match" = "0"; then
                echo "  exit codes differ: brash=$_brash_exit syssh=$_syssh_exit"
            fi
            if test "$_stdout_match" = "0"; then
                echo "  stdout differs:"
                diff "$_outdir/syssh.out" "$_outdir/brash.out" | head -20 | sed 's/^/    /'
            fi
            FAIL=$((FAIL + 1))
            FAIL_LIST="$FAIL_LIST $_name"
        fi
    fi

    rm -rf "$_outdir"
}

# ---- main loop ----
for script in "$SCRIPTS_DIR"/*.sh; do
    test -f "$script" || continue
    run_one "$script"
done

# ---- summary ----
echo ""
echo "==============================="
TOTAL=$((PASS + FAIL + SKIP))
echo "Results: $PASS/$TOTAL passed"
if test "$FAIL" -gt 0; then
    echo "Failed: $FAIL_LIST"
fi
echo "==============================="

test "$FAIL" = "0"
