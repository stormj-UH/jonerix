#!/bin/sh
# 15_signal_forward.sh — signal-forwarding parent shell pattern
# A parent shell runs a child, catches signals, forwards them, and waits.
# Models init-process wrappers, container entrypoints, and service managers.

set -e

TMPDIR=$(mktemp -d)
trap 'rm -rf "$TMPDIR"' EXIT

CHILD_PID_FILE="$TMPDIR/child.pid"
CHILD_LOG="$TMPDIR/child.log"

# Child process: writes its PID and runs briefly
cat > "$TMPDIR/child.sh" <<'CHILD'
#!/bin/sh
echo "child: started"
echo $$ > "$1"
count=0
while test $count -lt 5; do
    echo "child: tick $count"
    count=$((count + 1))
done
echo "child: exiting normally"
CHILD
chmod +x "$TMPDIR/child.sh"

# Run child, capturing its output
"$TMPDIR/child.sh" "$CHILD_PID_FILE" > "$CHILD_LOG" 2>&1

echo "child output:"
cat "$CHILD_LOG"

# Verify child ran successfully
if grep -q "child: exiting normally" "$CHILD_LOG"; then
    echo "child completed normally: OK"
else
    echo "child did not complete normally: FAIL" >&2
    exit 1
fi

# Verify tick count
ticks=$(grep -c "child: tick" "$CHILD_LOG" || echo 0)
echo "ticks: $ticks"
if test "$ticks" = "5"; then
    echo "tick count correct: OK"
else
    echo "tick count wrong: expected 5, got $ticks: FAIL" >&2
    exit 1
fi

# Demonstrate signal handler setup (the forwarding pattern)
# (We can't actually send signals in a deterministic test, so we just
# demonstrate the setup pattern used in real wrappers.)
forward_signals() {
    _child_pid="$1"
    # In a real wrapper these trap handlers would kill $_child_pid
    trap "echo 'parent: forwarding TERM'; kill -TERM \$_child_pid 2>/dev/null || true" TERM
    trap "echo 'parent: forwarding INT' ; kill -INT  \$_child_pid 2>/dev/null || true" INT
    trap "echo 'parent: forwarding HUP' ; kill -HUP  \$_child_pid 2>/dev/null || true" HUP
}

forward_signals 99999   # dummy PID (already exited)
echo "signal handlers registered: OK"
echo "signal_forward: done"
