#!/bin/sh
# 10_rsync_flags.sh — rsync flag-builder pattern
# Builds an rsync command line from configuration variables, as many
# deployment scripts do. Does not actually run rsync (deterministic).

set -e

# Config
VERBOSE=1
DELETE=1
COMPRESS=0
CHECKSUM=0
EXCLUDE_LIST="*.log *.tmp .git"
SSH_PORT=22
SSH_KEY=""
BANDWIDTH_LIMIT=""

build_rsync_flags() {
    flags="-a"

    if test "$VERBOSE" = "1"; then
        flags="$flags -v"
    fi
    if test "$DELETE" = "1"; then
        flags="$flags --delete"
    fi
    if test "$COMPRESS" = "1"; then
        flags="$flags -z"
    fi
    if test "$CHECKSUM" = "1"; then
        flags="$flags --checksum"
    fi
    if test -n "$BANDWIDTH_LIMIT"; then
        flags="$flags --bwlimit=$BANDWIDTH_LIMIT"
    fi

    # SSH options
    ssh_opts=""
    if test "$SSH_PORT" != "22"; then
        ssh_opts="-p $SSH_PORT"
    fi
    if test -n "$SSH_KEY"; then
        ssh_opts="$ssh_opts -i $SSH_KEY"
    fi
    if test -n "$ssh_opts"; then
        flags="$flags -e 'ssh $ssh_opts'"
    fi

    # Exclude list
    for pat in $EXCLUDE_LIST; do
        flags="$flags --exclude='$pat'"
    done

    echo "$flags"
}

FLAGS=$(build_rsync_flags)
echo "rsync flags: $FLAGS"

# Verify mandatory flags present
case "$FLAGS" in
    *-a*)    echo "flag -a: present" ;;
    *)       echo "flag -a: MISSING" >&2; exit 1 ;;
esac
case "$FLAGS" in
    *--delete*) echo "flag --delete: present" ;;
    *)          echo "flag --delete: MISSING" >&2; exit 1 ;;
esac
case "$FLAGS" in
    *--exclude=*.log*) echo "exclude *.log: present" ;;
    *)                 echo "exclude *.log: MISSING" >&2; exit 1 ;;
esac

echo "rsync_flags: OK"
