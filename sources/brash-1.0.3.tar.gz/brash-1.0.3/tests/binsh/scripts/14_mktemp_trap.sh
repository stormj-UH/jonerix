#!/bin/sh
# 14_mktemp_trap.sh — mktemp + trap cleanup pattern
# The canonical POSIX way to ensure temp files are removed on exit/signal.

# Note: we do NOT set -e here intentionally, to test that trap fires
# even on non-zero exit.

WORKDIR=""

cleanup() {
    if test -n "$WORKDIR" && test -d "$WORKDIR"; then
        rm -rf "$WORKDIR"
        echo "cleanup: done"
    fi
}

# Register cleanup for normal exit and common signals
trap cleanup EXIT
trap cleanup INT
trap cleanup TERM

WORKDIR=$(mktemp -d)
echo "workdir: created"

# Create some temp files
echo "data1" > "$WORKDIR/tmp1.dat"
echo "data2" > "$WORKDIR/tmp2.dat"
mkdir -p "$WORKDIR/subdir"
echo "sub"  > "$WORKDIR/subdir/sub.dat"

echo "created files:"
find "$WORKDIR" -type f | sort | while read f; do
    echo "  $(basename "$f")"
done

# Simulate doing work that might fail partway through
do_work() {
    echo "work: step 1"
    echo "step1" > "$WORKDIR/step1.out"
    echo "work: step 2"
    echo "step2" > "$WORKDIR/step2.out"
    echo "work: complete"
    return 0
}

do_work

# Verify workdir still exists during script lifetime
if test -d "$WORKDIR"; then
    echo "workdir exists during run: OK"
else
    echo "workdir vanished during run: FAIL" >&2
    exit 1
fi

# Record path for post-exit check
SAVEDDIR="$WORKDIR"

echo "exiting normally"
# trap EXIT will fire here and clean up
