#!/bin/sh
# 05_npm_postinstall.sh — npm postinstall native module + permissions pattern
# Models what node-gyp / node_modules/.bin setup scripts do.
# No actual compilation; uses file creation to simulate build artefacts.

set -e

TMPDIR=$(mktemp -d)
trap 'rm -rf "$TMPDIR"' EXIT

PKG_ROOT="$TMPDIR/node_modules/mypkg"
BUILD_DIR="$PKG_ROOT/build/Release"
BIN_DIR="$PKG_ROOT/.bin"

mkdir -p "$BUILD_DIR" "$BIN_DIR"

# Simulate a build step (normally node-gyp build)
echo "building native module..."
printf 'ELF_FAKE_BINARY\n' > "$BUILD_DIR/mypkg.node"
echo "native module build: OK"

# Set permissions as npm postinstall scripts do
chmod 755 "$BUILD_DIR/mypkg.node"

# Create bin wrapper script
cat > "$BIN_DIR/mypkg-cli" <<'WRAPPER'
#!/bin/sh
exec node "$(dirname "$0")/../lib/cli.js" "$@"
WRAPPER
chmod 755 "$BIN_DIR/mypkg-cli"

# Verify permissions (print relative path for deterministic output)
check_perm() {
    _file="$1"
    _rel="${_file#$TMPDIR/}"
    _got=$(ls -l "$_file" | cut -c1-10)
    echo "perm $_rel: $_got"
}

check_perm "$BUILD_DIR/mypkg.node"
check_perm "$BIN_DIR/mypkg-cli"

# Verify wrapper is executable
if test -x "$BIN_DIR/mypkg-cli"; then
    echo "wrapper executable: OK"
else
    echo "wrapper executable: FAIL" >&2
    exit 1
fi

echo "postinstall: done"
