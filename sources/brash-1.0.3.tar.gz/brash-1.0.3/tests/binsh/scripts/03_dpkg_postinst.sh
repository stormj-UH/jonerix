#!/bin/sh
# 03_dpkg_postinst.sh — dpkg postinst idempotent symlink + alternatives pattern
# Models the standard Debian postinst for a binary package.
# Runs in a tmpdir so no real system paths are touched.

set -e

TMPDIR=$(mktemp -d)
trap 'rm -rf "$TMPDIR"' EXIT

PKG=mypackage
VER=1.2.3
BINDIR="$TMPDIR/usr/bin"
ALTDIR="$TMPDIR/etc/alternatives"
INSTDIR="$TMPDIR/usr/lib/$PKG"

mkdir -p "$BINDIR" "$ALTDIR" "$INSTDIR"

# Simulate installed binary
printf '#!/bin/sh\necho "%s %s"\n' "$PKG" "$VER" > "$INSTDIR/myprog"
chmod +x "$INSTDIR/myprog"

# Idempotent symlink creation (dpkg pattern)
# rel_path: strip TMPDIR prefix for deterministic output
rel() { echo "${1#$TMPDIR/}"; }

update_symlink() {
    _link="$1"
    _target="$2"
    if [ -L "$_link" ]; then
        _current=$(readlink "$_link")
        if [ "$_current" = "$_target" ]; then
            echo "symlink already correct: $(rel "$_link") -> $(rel "$_target")"
            return 0
        fi
        echo "updating symlink: $(rel "$_link") -> $(rel "$_target") (was $(rel "$_current"))"
        rm "$_link"
    elif [ -e "$_link" ]; then
        echo "ERROR: $(rel "$_link") exists but is not a symlink" >&2
        return 1
    fi
    ln -s "$_target" "$_link"
    echo "created symlink: $(rel "$_link") -> $(rel "$_target")"
}

update_symlink "$BINDIR/myprog"    "$INSTDIR/myprog"
update_symlink "$ALTDIR/myprog"    "$INSTDIR/myprog"

# Second call is idempotent
update_symlink "$BINDIR/myprog"    "$INSTDIR/myprog"

# Simulate update-alternatives registration
register_alternative() {
    _name="$1"
    _link="$2"
    _path="$3"
    _prio="$4"
    _altlink="$ALTDIR/$_name"
    if [ ! -L "$_altlink" ] || [ "$(readlink "$_altlink")" != "$_path" ]; then
        ln -sf "$_path" "$_altlink"
        echo "update-alternatives: installing $(rel "$_link") $_name $(rel "$_path") $_prio"
    else
        echo "update-alternatives: already registered $_name -> $(rel "$_path")"
    fi
}

register_alternative "myprog" "$BINDIR/myprog" "$INSTDIR/myprog" 100
register_alternative "myprog" "$BINDIR/myprog" "$INSTDIR/myprog" 100

echo "postinst: configure $PKG $VER done"
