#!/bin/sh
# 04_dpkg_confdiff.sh — dpkg conffile diff and merge pattern
# Models the ucf/dpkg conffile-handling logic (three-way check).
# Uses only diff (POSIX), no bashisms.

set -e

TMPDIR=$(mktemp -d)
trap 'rm -rf "$TMPDIR"' EXIT

ORIG="$TMPDIR/orig.conf"
CURRENT="$TMPDIR/current.conf"
NEW="$TMPDIR/new.conf"
RESULT="$TMPDIR/result.conf"

# Write original config
cat > "$ORIG" <<'EOF'
# mypackage config
log_level=info
max_connections=100
timeout=30
EOF

# Current (user has changed log_level)
cat > "$CURRENT" <<'EOF'
# mypackage config
log_level=debug
max_connections=100
timeout=30
EOF

# New version from package (adds a new key)
cat > "$NEW" <<'EOF'
# mypackage config
log_level=info
max_connections=100
timeout=30
retry_count=3
EOF

conffile_action() {
    # Check if user modified the file
    if diff -q "$ORIG" "$CURRENT" >/dev/null 2>&1; then
        echo "conffile: no user changes, installing new"
        cp "$NEW" "$RESULT"
    elif diff -q "$NEW" "$ORIG" >/dev/null 2>&1; then
        echo "conffile: package unchanged, keeping current"
        cp "$CURRENT" "$RESULT"
    else
        echo "conffile: both user and package changed, showing diff"
        diff "$CURRENT" "$NEW" || true
        echo "conffile: keeping current (user wins)"
        cp "$CURRENT" "$RESULT"
    fi
}

conffile_action

echo "--- result ---"
cat "$RESULT"

# Verify result has user's log_level=debug (user change preserved)
if grep -q "log_level=debug" "$RESULT"; then
    echo "conffile: user change preserved: OK"
else
    echo "conffile: user change NOT preserved: FAIL" >&2
    exit 1
fi
