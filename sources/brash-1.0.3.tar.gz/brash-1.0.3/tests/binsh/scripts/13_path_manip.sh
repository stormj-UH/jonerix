#!/bin/sh
# 13_path_manip.sh — PATH deduplication and prepend patterns
# Used by install scripts, shell rc files, and package managers.

set -e

# Prepend a directory to PATH if not already present
path_prepend() {
    _dir="$1"
    case ":$PATH:" in
        *":$_dir:"*) echo "already in PATH: $_dir" ;;
        *)
            PATH="$_dir:$PATH"
            echo "prepended: $_dir"
            ;;
    esac
    export PATH
}

# Append a directory to PATH if not already present
path_append() {
    _dir="$1"
    case ":$PATH:" in
        *":$_dir:"*) echo "already in PATH: $_dir" ;;
        *)
            PATH="$PATH:$_dir"
            echo "appended: $_dir"
            ;;
    esac
    export PATH
}

# Deduplicate PATH preserving order
path_dedup() {
    _new=""
    _old_IFS="$IFS"
    IFS=:
    for _dir in $PATH; do
        IFS="$_old_IFS"
        if test -z "$_dir"; then
            continue
        fi
        case ":$_new:" in
            *":$_dir:"*) ;;   # already seen
            *) _new="${_new:+$_new:}$_dir" ;;
        esac
        IFS=:
    done
    IFS="$_old_IFS"
    echo "$_new"
}

# Start with a known PATH
PATH=/usr/bin:/bin
export PATH

echo "initial PATH=$PATH"

path_prepend /usr/local/bin
echo "after prepend: PATH=$PATH"

path_prepend /usr/local/bin   # idempotent
echo "after idempotent prepend: PATH=$PATH"

path_append /opt/myapp/bin
echo "after append: PATH=$PATH"

path_append /opt/myapp/bin    # idempotent
echo "after idempotent append: PATH=$PATH"

# Add duplicates manually to test dedup
PATH="/usr/bin:/bin:/usr/local/bin:/usr/bin:/bin:/opt/myapp/bin"
echo "before dedup: PATH=$PATH"

DEDUPED=$(path_dedup)
echo "after dedup: PATH=$DEDUPED"

# Verify no duplicates
segment_count=$(echo "$DEDUPED" | tr ':' '\n' | sort | uniq -d | wc -l | tr -d ' ')
if test "$segment_count" = "0"; then
    echo "path_manip: no duplicates after dedup: OK"
else
    echo "path_manip: duplicates found after dedup: FAIL" >&2
    exit 1
fi
