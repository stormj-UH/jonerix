#!/bin/sh
# 11_tar_extract.sh — tar extract-and-process pattern
# Creates a tarball, extracts it, processes files (chmod, rename, checksum).

set -e

TMPDIR=$(mktemp -d)
trap 'rm -rf "$TMPDIR"' EXIT

SRC="$TMPDIR/src"
DIST="$TMPDIR/dist"
EXTRACT="$TMPDIR/extract"

mkdir -p "$SRC" "$DIST" "$EXTRACT"

# Create source files
echo "hello world"    > "$SRC/hello.txt"
echo "#!/bin/sh"      > "$SRC/run.sh"
echo "echo running"  >> "$SRC/run.sh"
echo "config=value"   > "$SRC/app.conf"

# Create tarball
tar -C "$TMPDIR" -czf "$DIST/package.tar.gz" src

echo "created: $(ls -1 "$DIST")"

# Extract
tar -xzf "$DIST/package.tar.gz" -C "$EXTRACT"

echo "extracted files:"
find "$EXTRACT/src" -type f | sort | while read f; do
    echo "  $(basename "$f")"
done

# Process: make .sh files executable, print sizes
find "$EXTRACT/src" -name "*.sh" -type f | while read f; do
    chmod +x "$f"
    echo "chmod +x $(basename "$f")"
done

# Verify checksums match originals
for name in hello.txt run.sh app.conf; do
    orig=$(cksum "$SRC/$name" | awk '{print $1}')
    extr=$(cksum "$EXTRACT/src/$name" | awk '{print $1}')
    if test "$orig" = "$extr"; then
        echo "checksum $name: OK"
    else
        echo "checksum $name: MISMATCH (orig=$orig extr=$extr)" >&2
        exit 1
    fi
done

echo "tar_extract: all checks passed: OK"
