#!/bin/sh
# 17_test_runner.sh — simple test runner pattern
# Runs each script in a directory, collects pass/fail, prints summary.
# This is the meta-test: a test runner written in POSIX sh.

set -e

TMPDIR=$(mktemp -d)
trap 'rm -rf "$TMPDIR"' EXIT

TESTS_DIR="$TMPDIR/tests"
mkdir -p "$TESTS_DIR"

# Write some mini test scripts
cat > "$TESTS_DIR/t01_true.sh" <<'EOF'
#!/bin/sh
exit 0
EOF

cat > "$TESTS_DIR/t02_arithmetic.sh" <<'EOF'
#!/bin/sh
result=$(expr 6 \* 7)
test "$result" = "42" || exit 1
exit 0
EOF

cat > "$TESTS_DIR/t03_string.sh" <<'EOF'
#!/bin/sh
x="hello"
y="world"
z="${x} ${y}"
test "$z" = "hello world" || exit 1
exit 0
EOF

cat > "$TESTS_DIR/t04_pipeline.sh" <<'EOF'
#!/bin/sh
result=$(echo "ONE TWO THREE" | tr '[:upper:]' '[:lower:]')
test "$result" = "one two three" || exit 1
exit 0
EOF

cat > "$TESTS_DIR/t05_case.sh" <<'EOF'
#!/bin/sh
val="apple"
case "$val" in
    apple)  echo "matched apple" ;;
    banana) echo "matched banana" ;;
    *)      echo "no match"; exit 1 ;;
esac
exit 0
EOF

chmod +x "$TESTS_DIR"/*.sh

# --- Runner ---
PASS=0
FAIL=0
ERRORS=""

for test_script in "$TESTS_DIR"/*.sh; do
    name=$(basename "$test_script")
    if sh "$test_script" >/dev/null 2>&1; then
        echo "PASS: $name"
        PASS=$((PASS + 1))
    else
        echo "FAIL: $name"
        FAIL=$((FAIL + 1))
        ERRORS="$ERRORS $name"
    fi
done

echo "---"
echo "passed: $PASS"
echo "failed: $FAIL"

if test "$FAIL" != "0"; then
    echo "failing tests:$ERRORS" >&2
    exit 1
fi

echo "test_runner: all $PASS tests passed: OK"
