#!/bin/sh
# 08_yaml_parser.sh — YAML-style flat key:value config parser in shell
# Handles key: value, skips comments and blank lines. POSIX only.

set -e

TMPDIR=$(mktemp -d)
trap 'rm -rf "$TMPDIR"' EXIT

CONFIG="$TMPDIR/config.yaml"

cat > "$CONFIG" <<'EOF'
# Application config
host: localhost
port: 8080
debug: false

# Database
db_host: db.internal
db_port: 5432
db_name: myapp

# Empty value key
prefix:
EOF

# Parser: reads key: value lines into shell variables via eval-safe output
yaml_get() {
    _file="$1"
    _key="$2"
    # Match "key: value" or "key:" (empty value), ignore comments/blanks
    grep "^${_key}:" "$_file" | sed "s/^${_key}:[[:space:]]*//" | head -1
}

host=$(yaml_get "$CONFIG" host)
port=$(yaml_get "$CONFIG" port)
debug=$(yaml_get "$CONFIG" debug)
db_host=$(yaml_get "$CONFIG" db_host)
db_port=$(yaml_get "$CONFIG" db_port)
db_name=$(yaml_get "$CONFIG" db_name)
prefix=$(yaml_get "$CONFIG" prefix)

echo "host=$host"
echo "port=$port"
echo "debug=$debug"
echo "db_host=$db_host"
echo "db_port=$db_port"
echo "db_name=$db_name"
echo "prefix='$prefix'"

# Validate
test "$host"    = "localhost"  || { echo "FAIL host"    >&2; exit 1; }
test "$port"    = "8080"       || { echo "FAIL port"    >&2; exit 1; }
test "$debug"   = "false"      || { echo "FAIL debug"   >&2; exit 1; }
test "$db_port" = "5432"       || { echo "FAIL db_port" >&2; exit 1; }
test "$prefix"  = ""           || { echo "FAIL prefix"  >&2; exit 1; }

echo "yaml_parser: all keys parsed correctly: OK"
