#!/bin/sh
# 02_autoconf_feature.sh — autoconf feature-check patterns
# Mimics the AC_CHECK_PROG / AC_CHECK_HEADER patterns used in configure.
# Uses only POSIX constructs; output is fully deterministic via fixed PATH.

# Deterministic PATH — only look in /usr/bin and /bin
PATH=/usr/bin:/bin
export PATH

ac_prog_found() {
    _prog="$1"
    _old_IFS="$IFS"
    IFS=:
    for _dir in $PATH; do
        IFS="$_old_IFS"
        if test -f "$_dir/$_prog" && test -x "$_dir/$_prog"; then
            echo "yes"
            return 0
        fi
    done
    IFS="$_old_IFS"
    echo "no"
    return 1
}

echo "checking for cc... $(ac_prog_found cc)"
echo "checking for gcc... $(ac_prog_found gcc)"
echo "checking for awk... $(ac_prog_found awk)"
echo "checking for sed... $(ac_prog_found sed)"
echo "checking for grep... $(ac_prog_found grep)"
echo "checking for tr... $(ac_prog_found tr)"

# Simulate a header existence check by testing for a placeholder
# (always yields "no" deterministically when absent)
ac_header_check() {
    _hdr="$1"
    # We can't actually compile, so we simulate with a known-absent sentinel
    case "$_hdr" in
        stdio.h)    echo "yes" ;;
        nonexist.h) echo "no"  ;;
        *)          echo "no"  ;;
    esac
}

echo "checking stdio.h usability... $(ac_header_check stdio.h)"
echo "checking nonexist.h usability... $(ac_header_check nonexist.h)"

echo "configure: done"
