#!/bin/sh
# 01_autoconf_sanity.sh — autoconf configure opening lines
# Mimics the sanity-check and environment-detection preamble of an
# autoconf-generated configure script. Fully POSIX-compliant.

as_nl='
'
export as_nl

# Check that IFS is not broken by locale
IFS=" 	$as_nl"

# Make sure CDPATH is not set in a troublesome way
(unset CDPATH) >/dev/null 2>&1 && unset CDPATH

# Check the shell can handle the basic constructs used by configure
if test "x$1" = x--version; then
    echo "configure (test) 1.0"
    exit 0
fi

# as_me: name of the script without path
as_me=configure

echo "$as_me: starting sanity check"

# Verify arithmetic
expr 1 + 1 >/dev/null 2>&1 || {
    echo "$as_me: ERROR: expr does not work" >&2
    exit 1
}

# Verify test command with string comparisons
test "abc" = "abc" || {
    echo "$as_me: ERROR: test string comparison broken" >&2
    exit 1
}

# Verify that we can unset a variable
as_var=TMPVAR
eval "as_val=\${$as_var+set}"
(eval "unset $as_var") >/dev/null 2>&1

# Verify printf or echo usability
as_echo_n_body='printf %s "$1"'
as_echo_n="sh -c '$as_echo_n_body' --"

# Detect build system
build_os=$(uname -s 2>/dev/null | tr '[:upper:]' '[:lower:]' || echo "unknown")

echo "$as_me: build_os=$build_os"
echo "$as_me: sanity check PASSED"
