#!/bin/sh
# 16_bg_job_manager.sh — background job manager pattern
# Starts multiple background jobs, tracks their PIDs, waits for all,
# collects exit statuses. POSIX-only.
# Worker stdout is captured to files (background output ordering is
# non-deterministic); only the final summary is printed.

set -e

TMPDIR=$(mktemp -d)
trap 'rm -rf "$TMPDIR"' EXIT

# Worker: writes a result file and a log file
worker() {
    _id="$1"
    _outfile="$2"
    _logfile="$3"
    {
        echo "worker $_id: started"
        result=$(expr "$_id" \* 2)
        echo "$result" > "$_outfile"
        echo "worker $_id: done (result=$result)"
    } > "$_logfile" 2>&1
}

echo "starting background workers..."

PIDS=""
for i in 1 2 3 4; do
    outfile="$TMPDIR/result.$i"
    logfile="$TMPDIR/log.$i"
    worker "$i" "$outfile" "$logfile" &
    pid=$!
    PIDS="$PIDS $pid"
done
echo "launched 4 workers"

# Wait for all jobs and collect statuses
fail_count=0
for pid in $PIDS; do
    if wait "$pid"; then
        : # ok
    else
        fail_count=$((fail_count + 1))
    fi
done

# Print worker logs in deterministic order
for i in 1 2 3 4; do
    cat "$TMPDIR/log.$i"
done

# Collect results
echo "--- results ---"
total=0
for i in 1 2 3 4; do
    val=$(cat "$TMPDIR/result.$i")
    echo "worker $i result: $val"
    total=$((total + val))
done

echo "total: $total"
expected=$((1*2 + 2*2 + 3*2 + 4*2))
if test "$total" = "$expected"; then
    echo "bg_job_manager: total correct ($total): OK"
else
    echo "bg_job_manager: expected $expected got $total: FAIL" >&2
    exit 1
fi

if test "$fail_count" = "0"; then
    echo "bg_job_manager: all workers succeeded: OK"
else
    echo "bg_job_manager: $fail_count workers failed: FAIL" >&2
    exit 1
fi
