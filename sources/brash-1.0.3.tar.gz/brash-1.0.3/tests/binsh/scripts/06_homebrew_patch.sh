#!/bin/sh
# 06_homebrew_patch.sh — Homebrew formula patch-and-recompile pattern
# Models the patch application step used in Homebrew formula installs.

set -e

TMPDIR=$(mktemp -d)
trap 'rm -rf "$TMPDIR"' EXIT

SRC="$TMPDIR/src"
mkdir -p "$SRC"

# Write a "source file"
cat > "$SRC/config.h" <<'EOF'
#define VERSION "1.0.0"
#define MAX_BUF 1024
#define FEATURE_OLD 1
EOF

# Write a patch (unified diff)
cat > "$TMPDIR/fix.patch" <<'EOF'
--- a/config.h
+++ b/config.h
@@ -1,3 +1,4 @@
 #define VERSION "1.0.0"
 #define MAX_BUF 1024
-#define FEATURE_OLD 1
+#define FEATURE_OLD 0
+#define FEATURE_NEW 1
EOF

echo "applying patch..."
patch -d "$SRC" -p1 < "$TMPDIR/fix.patch"

echo "--- patched config.h ---"
cat "$SRC/config.h"

# Verify expected result
if grep -q "FEATURE_NEW 1" "$SRC/config.h" && grep -q "FEATURE_OLD 0" "$SRC/config.h"; then
    echo "patch applied correctly: OK"
else
    echo "patch result incorrect: FAIL" >&2
    exit 1
fi

# Simulate a "compile" step (just touch an artefact)
touch "$SRC/config.o"
echo "compile step: OK (simulated)"
