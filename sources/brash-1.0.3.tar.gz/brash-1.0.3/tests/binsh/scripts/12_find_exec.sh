#!/bin/sh
# 12_find_exec.sh — find -exec emulation patterns
# Uses find with -exec and a while-read loop (both POSIX patterns).

set -e

TMPDIR=$(mktemp -d)
trap 'rm -rf "$TMPDIR"' EXIT

# Create a directory tree
mkdir -p "$TMPDIR/a/b" "$TMPDIR/a/c" "$TMPDIR/d"
echo "file1" > "$TMPDIR/a/f1.txt"
echo "file2" > "$TMPDIR/a/b/f2.txt"
echo "data"  > "$TMPDIR/a/c/data.dat"
echo "file4" > "$TMPDIR/d/f4.txt"
echo "other" > "$TMPDIR/d/other.log"

echo "=== find -exec pattern ==="
# Find all .txt files and print their basenames via -exec
find "$TMPDIR" -name "*.txt" -type f -exec basename {} \; | sort

echo "=== while read loop pattern ==="
# Alternative: find | while read (POSIX)
find "$TMPDIR" -name "*.txt" -type f | sort | while read f; do
    echo "found: $(basename "$f") in $(basename "$(dirname "$f")")"
done

echo "=== find -exec with multiple operations ==="
# Prepend a header line to each .txt file
find "$TMPDIR" -name "*.txt" -type f -exec sh -c '
    f="$1"
    tmp="$f.tmp"
    echo "# processed" > "$tmp"
    cat "$f" >> "$tmp"
    mv "$tmp" "$f"
' _ {} \;

# Verify header was added
count=0
find "$TMPDIR" -name "*.txt" -type f | while read f; do
    first=$(head -1 "$f")
    if test "$first" = "# processed"; then
        count=$((count + 1))
    fi
done

# Count .txt files
n=$(find "$TMPDIR" -name "*.txt" -type f | wc -l | tr -d ' ')
echo "processed $n .txt files"

# Verify count
if test "$n" = "3"; then
    echo "find_exec: count correct: OK"
else
    echo "find_exec: expected 3 txt files, got $n: FAIL" >&2
    exit 1
fi
