#!/bin/sh
# 07_version_bump.sh — Cargo.toml-style version bumping via sed
# Mimics what release scripts do when bumping semantic version strings.

set -e

TMPDIR=$(mktemp -d)
trap 'rm -rf "$TMPDIR"' EXIT

TOML="$TMPDIR/Cargo.toml"

cat > "$TOML" <<'EOF'
[package]
name = "mylib"
version = "1.2.3"
edition = "2021"
description = "A test library"

[dependencies]
serde = { version = "1.0", features = ["derive"] }

[dev-dependencies]
mylib-test = "1.2.3"
EOF

bump_version() {
    _file="$1"
    _old="$2"
    _new="$3"

    # Only replace first occurrence of version = "OLD" (the package itself)
    # Use a temp file (POSIX sed -i is not portable; use tmp file)
    _tmp="${_file}.tmp"
    sed "s/^version = \"${_old}\"/version = \"${_new}\"/" "$_file" > "$_tmp"
    mv "$_tmp" "$_file"
}

echo "before:"
grep "^version" "$TOML"

bump_version "$TOML" "1.2.3" "1.3.0"

echo "after:"
grep "^version" "$TOML"

# Verify
NEWVER=$(grep "^version" "$TOML" | sed 's/version = "\(.*\)"/\1/')
if test "$NEWVER" = "1.3.0"; then
    echo "version bump: OK"
else
    echo "version bump: FAIL (got '$NEWVER')" >&2
    exit 1
fi

# Bump patch level only
bump_version "$TOML" "1.3.0" "1.3.1"
echo "after patch bump:"
grep "^version" "$TOML"
