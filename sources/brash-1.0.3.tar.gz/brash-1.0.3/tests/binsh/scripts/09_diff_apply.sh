#!/bin/sh
# 09_diff_apply.sh — diff-and-apply pattern (generate diff, apply with patch)
# Models the pattern used by many deployment scripts.

set -e

TMPDIR=$(mktemp -d)
trap 'rm -rf "$TMPDIR"' EXIT

BEFORE="$TMPDIR/before.txt"
AFTER="$TMPDIR/after.txt"
PATCH="$TMPDIR/changes.patch"
WORK="$TMPDIR/work.txt"

cat > "$BEFORE" <<'EOF'
server {
    listen 80;
    server_name example.com;
    root /var/www/html;
}
EOF

cat > "$AFTER" <<'EOF'
server {
    listen 443 ssl;
    server_name example.com;
    root /var/www/html;
    ssl_certificate /etc/ssl/cert.pem;
}
EOF

# Generate the patch (use fixed filenames a/ b/ to avoid tmpdir paths in output)
diff -u --label a/before.txt --label b/after.txt "$BEFORE" "$AFTER" > "$PATCH" || true

echo "--- generated patch ---"
cat "$PATCH"

# Apply to a copy of before (redirect patch's "patching file ..." message)
cp "$BEFORE" "$WORK"
patch "$WORK" < "$PATCH" >/dev/null

echo "--- result ---"
cat "$WORK"

# Verify the result matches $AFTER
if diff -q "$WORK" "$AFTER" >/dev/null 2>&1; then
    echo "diff-apply: result matches expected: OK"
else
    echo "diff-apply: result does NOT match expected: FAIL" >&2
    diff "$WORK" "$AFTER" >&2
    exit 1
fi
