# tests/binsh — brash-as-/bin/sh smoke corpus

Simulates replacing `/bin/sh` with `brash` by sandboxing `sh` on `PATH`
and running a corpus of POSIX-only scripts that mirror real-world `/bin/sh`
consumers (autoconf, dpkg, npm, Homebrew, etc.).

## Running

```sh
# From repo root — build first, then run
cargo build --release
BRASH=target/release/brash /bin/sh tests/binsh/run.sh
```

Or, if `BRASH` is not set, the runner auto-detects `target/release/brash`
by walking up from the script location.

```sh
# Brash-only (no comparison)
./tests/binsh/run.sh --brash-only

# System /bin/sh only
./tests/binsh/run.sh --syssh-only
```

Exit code is `0` when every script produces identical stdout and exit code
under both brash and `/bin/sh`.

## How it works

`run.sh` creates a temporary sandbox directory, symlinks `brash` into it as
`sh`, and prepends it to `PATH`. Each script is then run twice — once as
`brash script.sh`, once as `/bin/sh script.sh` — and their stdout and exit
codes are compared with `diff`.

## Scripts

| # | File | Category |
|---|------|----------|
| 01 | `01_autoconf_sanity.sh` | autoconf configure opening / sanity-check |
| 02 | `02_autoconf_feature.sh` | autoconf AC_CHECK_PROG / AC_CHECK_HEADER patterns |
| 03 | `03_dpkg_postinst.sh` | dpkg postinst — idempotent symlink + alternatives |
| 04 | `04_dpkg_confdiff.sh` | dpkg conffile diff and merge (three-way check) |
| 05 | `05_npm_postinstall.sh` | npm postinstall — native module build + permissions |
| 06 | `06_homebrew_patch.sh` | Homebrew formula patch-and-recompile |
| 07 | `07_version_bump.sh` | Cargo.toml-style version bumping with sed |
| 08 | `08_yaml_parser.sh` | flat key:value YAML config parser in shell |
| 09 | `09_diff_apply.sh` | generate patch with diff, apply with patch |
| 10 | `10_rsync_flags.sh` | rsync flag builder from config variables |
| 11 | `11_tar_extract.sh` | tar create / extract / checksum verify |
| 12 | `12_find_exec.sh` | find -exec and find | while read patterns |
| 13 | `13_path_manip.sh` | PATH prepend / append / deduplication |
| 14 | `14_mktemp_trap.sh` | mktemp + trap EXIT/INT/TERM cleanup |
| 15 | `15_signal_forward.sh` | signal-forwarding parent shell / entrypoint |
| 16 | `16_bg_job_manager.sh` | background job manager: launch, wait, collect |
| 17 | `17_test_runner.sh` | simple test runner (run-each-collect-results) |

## Constraints

- Every script uses `#!/bin/sh` and is strictly POSIX-compliant — no bashisms.
- Output is deterministic: no embedded tmpdir paths, no PIDs, no timestamps.
- Each script exits `0` on success, non-zero on failure.
- Identical output is required from both brash and the system `/bin/sh`.
