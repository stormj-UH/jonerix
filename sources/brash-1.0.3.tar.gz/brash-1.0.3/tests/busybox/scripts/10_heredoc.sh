#!/bin/sh
# 10_heredoc.sh - Heredoc variants

# Basic heredoc
cat <<EOF
line one
line two
EOF

# Heredoc with variable expansion
name=world
cat <<EOF
hello $name
answer is $((6 * 7))
EOF

# Quoted heredoc - no expansion
cat <<'EOF'
no $expansion
no $(command)
literal \n
EOF

# Indented heredoc (using dash - <<-)
cat <<-EOF
	indented body
	another indented line
EOF

# Heredoc to a variable via read
read line <<EOF
single line value
EOF
echo "read: $line"

# Multiple heredocs in sequence
cat <<A
first
A
cat <<B
second
B

# Heredoc with special chars
cat <<EOF
tab:	here
dollar: \$HOME
EOF
# Note: \\ in unquoted heredoc body has shell-specific handling, skipped here
