#!/bin/sh
# 25_set_opts.sh - set options behavior

# set -e (errexit) - subshell test
(
    set -e
    echo "before"
    true
    echo "after true"
    # false would exit the subshell
)
echo "set -e subshell exited cleanly: $?"

# set -e with if statement (if condition not subject to errexit)
(
    set -e
    if false; then echo "yes"; else echo "no"; fi
    echo "after if-false with -e"
)

# set -u (nounset)
(
    set -u
    x=defined
    echo "x=$x"
    echo "nounset active"
)

# set -f (noglob)
(
    set -f
    echo *.sh
    # Should print literal *.sh in /tmp or wherever we are... be safe
)
# After set -f exit, globs work again
result=$(echo "*.sh" | cat)
echo "literal: $result"

# set -x can be verified by stderr, skip here

# set -v verbose - skip (affects stderr)

# set -- to reset positional params
set -- one two three
echo "$#: $*"
set --
echo "$#: $*"

# $- flags
(
    set -eu
    # Check $- contains e and u
    case "$-" in
        *e*) echo "e flag set" ;;
    esac
    case "$-" in
        *u*) echo "u flag set" ;;
    esac
)
