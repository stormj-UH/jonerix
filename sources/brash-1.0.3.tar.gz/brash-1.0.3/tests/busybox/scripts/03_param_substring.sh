#!/bin/sh
# 03_param_substring.sh - String trimming expansions

path=/usr/local/bin/program.sh

# Remove shortest suffix match
echo "${path%/*}"
# Remove longest suffix match
echo "${path%%/*}"
# Remove shortest prefix match
echo "${path#*/}"
# Remove longest prefix match
echo "${path##*/}"

# With a variable extension
ext=sh
echo "${path%.${ext}}"

# Trimming with patterns
s=aabbccaabb
echo "${s#a*b}"
echo "${s##a*b}"
echo "${s%b*a}"
echo "${s%%b*a}"
