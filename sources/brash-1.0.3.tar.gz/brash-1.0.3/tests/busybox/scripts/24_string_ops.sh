#!/bin/sh
# 24_string_ops.sh - String operations through parameter expansion and tr

# String length via parameter expansion
s="hello world"
echo ${#s}

# Manual string operations via parameter expansion
# "index of" - find position of first 'l' (not portable, use case workaround)
# Instead test useful patterns

# Extract extension
extract_ext() {
    case "$1" in
        *.*)  echo "${1##*.}" ;;
        *)    echo "" ;;
    esac
}
echo $(extract_ext "file.txt")
echo $(extract_ext "archive.tar.gz")
echo $(extract_ext "noext")

# String comparison
s1="apple"
s2="banana"
if [ "$s1" \< "$s2" ]; then echo "apple < banana"; fi
if [ "$s2" \> "$s1" ]; then echo "banana > apple"; fi

# String contains (using case)
contains() {
    case "$1" in
        *"$2"*) return 0 ;;
        *) return 1 ;;
    esac
}
contains "hello world" "world" && echo "contains world"
contains "hello world" "xyz"   && echo "fail" || echo "no xyz"

# Trim leading spaces via parameter expansion loop
ltrim() {
    local s="$1"
    while case "$s" in " "*) true;; *) false;; esac; do
        s="${s# }"
    done
    echo "$s"
}
result=$(ltrim "   hello")
echo "ltrim: [$result]"

# Repeat a character N times (busybox pattern)
repeat() {
    local str="" i=0
    while [ $i -lt "$2" ]; do
        str="${str}${1}"
        i=$((i + 1))
    done
    echo "$str"
}
echo $(repeat "-" 5)
echo $(repeat "ab" 3)

# Case conversion via tr
upper() { echo "$1" | tr 'a-z' 'A-Z'; }
lower() { echo "$1" | tr 'A-Z' 'a-z'; }
echo $(upper "Hello World")
echo $(lower "Hello World")

# Remove all occurrences of char via tr -d
echo "hello world" | tr -d 'l'

# Translate
echo "hello" | tr 'a-z' 'A-Z'
