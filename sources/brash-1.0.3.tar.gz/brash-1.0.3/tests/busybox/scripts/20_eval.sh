#!/bin/sh
# 20_eval.sh - eval builtin

# Basic eval
eval "echo hello from eval"

# eval builds a command
cmd="echo"
arg="world"
eval "$cmd $arg"

# eval expands variables
x=42
eval "echo x is \$x"

# eval in loops for dynamic variable names
for i in 1 2 3; do
    eval "var$i=value$i"
done
eval "echo \$var1 \$var2 \$var3"

# eval with multiple statements
eval "a=1; b=2; echo \$((a+b))"

# eval can set positional params
eval set -- "alpha beta gamma"
echo "$1 $2 $3"

# eval exit status
eval "true"
echo "eval true: $?"
eval "false"
echo "eval false: $?"

eval "(exit 5)"
echo "eval exit 5: $?"
