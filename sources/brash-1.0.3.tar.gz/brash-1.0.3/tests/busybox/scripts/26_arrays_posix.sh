#!/bin/sh
# 26_arrays_posix.sh - POSIX array simulation via positional params and IFS

# POSIX sh has no arrays but uses positional params as arrays

# Set positional params as array
set -- apple banana cherry date elderberry
echo "count: $#"
echo "first: $1"
echo "last: $5"
echo "all: $*"

# Iterate
for fruit in "$@"; do
    echo "fruit: $fruit"
done

# Shift through
while [ $# -gt 0 ]; do
    echo "pop: $1"
    shift
done
echo "empty: $#"

# Simulate push/pop via set
set -- a b c
set -- "$@" d    # push d
echo "after push: $*"

# IFS-delimited pseudo-array
LIST="alpha:beta:gamma:delta"
OIFS=$IFS
IFS=:
set -- $LIST
IFS=$OIFS
echo "from IFS split:"
for x in "$@"; do
    echo "  $x"
done

# Newline-separated list via heredoc
while read item; do
    echo "item: $item"
done << 'EOF'
first
second
third
EOF
