#!/bin/sh
# 23_builtins.sh - Various builtins: type, command, hash, etc.

# type builtin
type echo
type cd
type type

# command builtin
command -v echo
command -v cd

# command -p uses default PATH
command -p echo "via -p"

# Set options
set -n 2>/dev/null; true  # no-exec mode would stop things - skip
# Test -e (errexit via subshell)
(set -e; true; echo "after true")

# set -u (nounset)
(
    set -u
    defined=yes
    echo "defined: $defined"
)

# export
myvar=hello
export myvar
# Subshell inherits it
(echo "inherited: $myvar")

# unset
myvar=hello
unset myvar
echo "after unset: ${myvar:-gone}"

# readonly
readonly ROval=42
echo "readonly: $ROval"
# Trying to assign fails
(readonly RO2=first; RO2=second 2>/dev/null; echo "ro2=$RO2")

# alias (posix sh supports it in interactive, but let's test basic)
alias ll='echo alias_ll'
ll
unalias ll

# pwd
(cd /tmp && pwd)

# : (colon - true/null command)
: ; echo "colon exit: $?"
: this does nothing
echo "after colon: $?"
