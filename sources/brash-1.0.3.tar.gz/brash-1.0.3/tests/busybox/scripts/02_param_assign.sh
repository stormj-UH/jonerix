#!/bin/sh
# 02_param_assign.sh - Parameter assignment expansion forms

unset a
echo "${a:=assigned}"
echo "$a"

unset b
echo "${b=assigned}"
echo "$b"

# :? and ? forms - test with set variable
c=hello
echo "${c:?should not error}"
echo "${c?should not error}"

# Nested expansion
base=hello
echo "${base%lo}world"
echo "${base#hel}"
