#!/bin/sh
# 14_read_builtin.sh - read builtin behavior

# Basic read
echo "one two three" | read a b c
# Note: in POSIX sh, pipe creates subshell so vars don't propagate
# Use process substitution or heredoc instead

read a b c << 'EOF'
one two three
EOF
echo "a=$a b=$b c=$c"

# Read with leftover into last var
read first rest << 'EOF'
alpha beta gamma delta
EOF
echo "first=$first rest=$rest"

# Read single var gets whole line
read line << 'EOF'
  leading spaces
EOF
echo "line=[$line]"

# Read with IFS
IFS=: read user pass uid gid << 'EOF'
root:x:0:0
EOF
echo "user=$user uid=$uid"
IFS=" "

# Read empty line
read empty << 'EOF'

EOF
echo "empty=[$empty]"

# Multiple reads from same file
read l1 << 'EOF'
first line
second line
EOF
echo "l1=$l1"

# Read with -r flag (raw - no backslash processing)
read -r rawline << 'EOF'
hello\nworld
EOF
echo "raw=[$rawline]"

# Without -r, backslash-newline continues line (but in heredoc it's literal)
read noraw << 'EOF'
hello
EOF
echo "noraw=[$noraw]"
