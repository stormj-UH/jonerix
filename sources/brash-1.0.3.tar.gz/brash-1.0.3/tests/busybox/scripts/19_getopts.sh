#!/bin/sh
# 19_getopts.sh - getopts builtin

# Simple flags
parse_flags() {
    while getopts "abc" opt; do
        case "$opt" in
            a) echo "flag a" ;;
            b) echo "flag b" ;;
            c) echo "flag c" ;;
            ?) echo "unknown: $opt" ;;
        esac
    done
    shift $((OPTIND - 1))
    echo "remaining: $*"
}
parse_flags -a -b remaining args
OPTIND=1

# Flags with arguments
parse_with_args() {
    while getopts "f:o:" opt; do
        case "$opt" in
            f) echo "file: $OPTARG" ;;
            o) echo "output: $OPTARG" ;;
            ?) echo "unknown: $opt" ;;
        esac
    done
    shift $((OPTIND - 1))
}
parse_with_args -f input.txt -o output.txt
OPTIND=1

# Combined flags
parse_flags -abc rest
OPTIND=1

# No flags - just args
parse_flags noflags here
OPTIND=1

# Stop at --
parse_flags -a -- -b -c
OPTIND=1
