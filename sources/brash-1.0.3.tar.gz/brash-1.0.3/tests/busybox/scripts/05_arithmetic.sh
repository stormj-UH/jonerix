#!/bin/sh
# 05_arithmetic.sh - POSIX arithmetic expansion

echo $((1 + 2))
echo $((10 - 3))
echo $((4 * 5))
echo $((17 / 4))
echo $((17 % 4))

# Operator precedence
echo $((2 + 3 * 4))
echo $((10 - 2 * 3 + 1))

# Unary operators
echo $((-5))
echo $((+5))

# Bitwise
echo $((0xFF & 0x0F))
echo $((0xF0 | 0x0F))
echo $((0xFF ^ 0x0F))
echo $((~0 & 0xFF))
echo $((1 << 4))
echo $((256 >> 3))

# Comparison (returns 0 or 1)
echo $((3 > 2))
echo $((2 > 3))
echo $((3 >= 3))
echo $((3 <= 2))
echo $((3 == 3))
echo $((3 != 4))

# Logical
echo $((1 && 1))
echo $((1 && 0))
echo $((0 || 1))
echo $((0 || 0))
echo $((! 0))
echo $((! 1))

# Ternary
echo $((1 ? 42 : 0))
echo $((0 ? 42 : 99))

# Variable in arithmetic
n=7
echo $((n * n))
echo $((n + 1))
