#!/bin/sh
# 17_special_vars.sh - Special variables $$, $!, $?, $-, $0

# $? - exit status
true;  echo "true exit: $?"
false; echo "false exit: $?"
(exit 42); echo "exit 42: $?"

# $$ - current PID (just verify it's a number)
pid=$$
[ "$pid" -gt 0 ] && echo "pid is positive"

# $0 - script name
[ -n "$0" ] && echo "\$0 is set"

# $- - current option flags
# In non-interactive shell these vary, just check it's set
echo "\$- is set: $([ -n "$-" ] && echo yes || echo no)"

# Last background pid $!
sleep 0 &
bgpid=$!
wait "$bgpid"
echo "bg exit: $?"
[ "$bgpid" -gt 0 ] && echo "bg pid positive"

# Positional parameter shifting
set -- a b c d e
echo "before: $*"
shift
echo "after shift 1: $*"
shift 2
echo "after shift 3: $*"
echo "\$#: $#"

# $@ vs $* in quotes
set -- "one two" three
echo "quoted \$@:"
for x in "$@"; do echo "  [$x]"; done
echo "quoted \$*:"
for x in "$*"; do echo "  [$x]"; done
