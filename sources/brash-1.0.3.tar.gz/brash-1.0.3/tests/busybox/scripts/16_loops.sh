#!/bin/sh
# 16_loops.sh - for/while/until loops with break/continue

# Basic for
for i in 1 2 3 4 5; do
    echo "$i"
done

# for with glob (using safe predictable list)
for w in alpha beta gamma; do
    echo "word: $w"
done

# while loop
n=1
while [ "$n" -le 5 ]; do
    echo "while: $n"
    n=$((n + 1))
done

# until loop
n=5
until [ "$n" -le 0 ]; do
    echo "until: $n"
    n=$((n - 1))
done

# break in loop
for i in 1 2 3 4 5; do
    [ "$i" -eq 3 ] && break
    echo "break loop: $i"
done
echo "after break"

# continue in loop
for i in 1 2 3 4 5; do
    [ "$i" -eq 3 ] && continue
    echo "continue loop: $i"
done

# break N - break outer loop
for i in 1 2 3; do
    for j in a b c; do
        [ "$i" -eq 2 ] && [ "$j" = "b" ] && break 2
        echo "$i$j"
    done
done
echo "after break 2"

# Nested loops
for i in 1 2; do
    for j in A B; do
        echo "${i}${j}"
    done
done

# while read loop
count=0
while read line; do
    count=$((count + 1))
done << 'EOF'
line one
line two
line three
EOF
echo "lines: $count"
