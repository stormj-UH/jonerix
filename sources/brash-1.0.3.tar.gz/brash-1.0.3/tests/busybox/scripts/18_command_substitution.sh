#!/bin/sh
# 18_command_substitution.sh - Command substitution forms

# $() form
result=$(echo hello)
echo "result: $result"

# Backtick form
result=`echo world`
echo "result: $result"

# Nested $()
inner=$(echo "inner")
outer=$(echo "outer: $(echo "$inner")")
echo "$outer"

# Trailing newlines stripped
result=$(printf "hello\n\n\n")
echo "[$result]"

# Command sub in assignment
today=$(printf "fixed-date")
echo "today: $today"

# Command sub in comparison
if [ "$(echo hello)" = "hello" ]; then
    echo "comsub in test"
fi

# Command sub with pipes
upper=$(echo "hello world" | tr 'a-z' 'A-Z')
echo "upper: $upper"

# Command sub for arithmetic
n=$(( 3 + 4 ))
echo "arith result: $n"

# Backtick with escaping
result=`echo \`echo nested\``
echo "nested backtick: $result"

# Command sub exit status - test via actual command failures
result=$(true); echo "comsub true: $?"
result=$(false); echo "comsub false: $?"
result=$(grep nonexistent /dev/null 2>/dev/null); echo "comsub grep miss: $?"
