#!/bin/sh
# 27_error_handling.sh - Error handling patterns common in ash/busybox

# die function pattern
die() {
    echo "ERROR: $1" >&2
    return 1
}

# Check with ||
true  || die "should not fire"
echo "after true ||: ok"

false || echo "false triggered fallback"

# check function
check() {
    "$@" || { echo "FAILED: $*" >&2; return 1; }
}
check true  && echo "check true ok"
check false && echo "fail" || echo "check false caught"

# Cleanup pattern with trap
run_with_cleanup() {
    local tmpfile=/tmp/brash_bb_err_$$
    trap "rm -f $tmpfile" EXIT
    echo "data" > "$tmpfile"
    echo "tmpfile exists: $([ -f "$tmpfile" ] && echo yes)"
    # trap fires on exit
}
(run_with_cleanup)

# Pipefail pattern (not POSIX but commonly supported)
# Just test basic pipe failure detection
pipe_result() {
    (exit 1) | true
    echo "basic pipe: $?"
}
pipe_result

# && / || chains
mkdir /tmp/brash_bb_testdir_$$ &&
    echo "mkdir ok" &&
    rmdir /tmp/brash_bb_testdir_$$ &&
    echo "rmdir ok" ||
    echo "something failed"

# Error-safe default: ${var:-default}
unset CONFIG
cfg="${CONFIG:-/etc/hosts}"
[ -n "$cfg" ] && echo "cfg has value"

# Retry-like pattern
attempt=0
while [ $attempt -lt 3 ]; do
    attempt=$((attempt + 1))
    [ $attempt -eq 2 ] && echo "succeeded on attempt $attempt" && break
done
