#!/bin/sh
# 08_ifs_splitting.sh - IFS-driven word splitting

# Default IFS (space/tab/newline)
data="  foo   bar   baz  "
for w in $data; do
    echo "word: $w"
done

# Custom IFS - colon separator (like PATH)
IFS=:
path="usr:local:bin"
for part in $path; do
    echo "part: $part"
done

# Reset IFS
IFS="
"
echo "reset done"

# IFS with multiple chars
IFS=:,
list="a:b,c:d,e"
for item in $list; do
    echo "item: $item"
done

# Restore default
IFS="
"

# Empty fields with IFS
IFS=:
parts=":a::b:"
set -- $parts
echo "count: $#"
for p in "$@"; do
    echo "p=[$p]"
done

IFS="
"

# read uses IFS
echo "one two three" | (IFS=" "; read a b c; echo "a=$a b=$b c=$c")
