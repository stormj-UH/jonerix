#!/bin/sh
# 30_posix_compliance.sh - Various POSIX compliance tests

# 1. $IFS affects word splitting in for/case expansion
IFS=,
for w in a,b,c; do
    echo "split: $w"
done
IFS=" "

# 2. Tilde expansion
home_ref=~
[ -n "$home_ref" ] && echo "tilde expands"
[ "$home_ref" = "$HOME" ] && echo "tilde equals HOME"

# 3. export -p lists exported vars
export TESTVAR_BB=hello
export -p | grep TESTVAR_BB | grep -q TESTVAR_BB && echo "export -p works"

# 4. Unset vs empty var behavior
unset UNDEF_VAR
EMPTY_VAR=""
echo "unset: ${UNDEF_VAR:-undef}"
echo "empty: ${EMPTY_VAR:-empty}"
echo "empty no-colon: ${EMPTY_VAR-notunset}"

# 5. exec redirect without exec-ing a command (fd redirect only)
exec 4>/tmp/brash_bb_exec_fd_$$
echo "to fd4" >&4
exec 4>&-
cat /tmp/brash_bb_exec_fd_$$
rm /tmp/brash_bb_exec_fd_$$

# 6. Wait for background job
(sleep 0; exit 42) &
wait $!
echo "bg job exit: $?"

# 7. Word splitting does not occur inside double quotes
x="a b c"
set -- "$x"
echo "quoted: $#"    # should be 1

set -- $x
echo "unquoted: $#"  # should be 3

# 8. Pathname expansion order (sort order)
(
    cd /tmp
    mkdir -p brash_bb_glob_$$
    touch brash_bb_glob_$$/c.txt brash_bb_glob_$$/a.txt brash_bb_glob_$$/b.txt
    for f in brash_bb_glob_$$/*.txt; do
        echo "$(basename $f)"
    done
    rm -rf brash_bb_glob_$$
)

# 9. Newline in variable
nl="line1
line2"
echo "$nl"

# 10. Subshell does not affect parent env
myenv=parent
(myenv=child; echo "child: $myenv")
echo "parent: $myenv"
