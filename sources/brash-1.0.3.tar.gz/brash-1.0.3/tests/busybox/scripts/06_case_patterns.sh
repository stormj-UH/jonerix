#!/bin/sh
# 06_case_patterns.sh - case statement pattern matching

for word in cat bat rat hat zap; do
    case "$word" in
        cat) echo "exact: $word" ;;
        [bh]at) echo "char-class: $word" ;;
        r*) echo "glob-star: $word" ;;
        *) echo "default: $word" ;;
    esac
done

# Multiple patterns per arm
for val in yes no maybe; do
    case "$val" in
        yes|y|YES) echo "affirmative" ;;
        no|n|NO)   echo "negative" ;;
        *)         echo "unknown: $val" ;;
    esac
done

# Numeric-ish strings
for n in 0 1 9 10 99; do
    case "$n" in
        0)       echo "zero" ;;
        [1-9])   echo "single digit: $n" ;;
        [1-9][0-9]) echo "two digits: $n" ;;
        *)       echo "other: $n" ;;
    esac
done

# Wildcard patterns
for s in foo .foo foo.bar .hidden; do
    case "$s" in
        .*)  echo "hidden: $s" ;;
        *.bar) echo "bar file: $s" ;;
        *)   echo "plain: $s" ;;
    esac
done
