#!/bin/sh
# 04_param_length.sh - Parameter length and positional params

# String length
s="hello world"
echo "${#s}"

# Empty and unset
empty=""
echo "${#empty}"
unset undef
echo "${#undef}"

# Positional parameters
set -- alpha beta gamma
echo "$#"
echo "$1"
echo "$2"
echo "$3"
echo "${#1}"
echo "${#2}"

# $@ and $*
echo "$@"
echo "$*"
