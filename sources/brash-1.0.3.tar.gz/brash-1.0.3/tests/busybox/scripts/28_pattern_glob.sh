#!/bin/sh
# 28_pattern_glob.sh - Pattern matching and globbing

# case with complex patterns
for s in "file.txt" "image.jpg" "archive.tar.gz" "Makefile" ".hidden" "no-ext"; do
    case "$s" in
        *.txt)      echo "text: $s" ;;
        *.jpg|*.png|*.gif) echo "image: $s" ;;
        *.tar.*)    echo "archive: $s" ;;
        [A-Z]*)     echo "capital: $s" ;;
        .*)         echo "hidden: $s" ;;
        *-*)        echo "hyphen: $s" ;;
        *)          echo "other: $s" ;;
    esac
done

# Parameter expansion with patterns
url="https://example.com/path/to/page.html"
echo "${url##*/}"          # basename
echo "${url%/*}"           # dirname-like
echo "${url#*://}"         # strip protocol
echo "${url%%/*}"          # protocol only... wait, protocol is before ://

proto="${url%%:*}"
echo "proto: $proto"
rest="${url#*://}"
echo "rest: $rest"
host="${rest%%/*}"
echo "host: $host"

# Null glob behavior - use set -f to test literal
(set -f; for f in *.nonexistent_ext_xyz; do echo "glob: $f"; done)

# Character classes in case
for c in a A 1 _ " "; do
    case "$c" in
        [[:lower:]]) echo "lower: $c" ;;
        [[:upper:]]) echo "upper: $c" ;;
        [[:digit:]]) echo "digit: $c" ;;
        [[:space:]]) echo "space" ;;
        *)           echo "other: $c" ;;
    esac
done
