#!/bin/sh
# 15_functions.sh - Functions including local, recursion

greet() {
    echo "hello $1"
}
greet world
greet "POSIX shell"

# Return value
add() {
    echo $(($1 + $2))
}
result=$(add 3 4)
echo "3+4=$result"

# Local variables (busybox ash supports local)
outer=global
test_local() {
    local outer=local_val
    echo "inside: outer=$outer"
}
test_local
echo "outside: outer=$outer"

# Recursive function
factorial() {
    if [ "$1" -le 1 ]; then
        echo 1
    else
        prev=$(factorial $(($1 - 1)))
        echo $(($1 * prev))
    fi
}
echo "5! = $(factorial 5)"

# Function that modifies positional params
show_args() {
    echo "nargs: $#"
    for a in "$@"; do
        echo "  arg: $a"
    done
}
show_args one "two three" four

# Function overrides builtin (then restore)
true() { echo "custom true"; }
true
unset -f true
true
echo "after unset: $?"

# Function return status
check_positive() {
    [ "$1" -gt 0 ] && return 0 || return 1
}
check_positive 5  && echo "5 is positive"
check_positive -1 && echo "fail" || echo "-1 not positive"
