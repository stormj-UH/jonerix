#!/bin/sh
# 13_printf.sh - printf format strings

# Basic formats
printf "%s\n" "hello"
printf "%d\n" 42
printf "%f\n" 3.14
printf "%e\n" 12345.6789
printf "%g\n" 0.00123
printf "%g\n" 12345.0
printf "%x\n" 255
printf "%X\n" 255
printf "%o\n" 8
printf "%c\n" 65

# Width and precision
printf "%10s\n" "right"
printf "%-10s|\n" "left"
printf "%05d\n" 42
printf "%.3f\n" 3.14159
printf "%10.3f\n" 3.14159

# Multiple args - format repeats
printf "%s " a b c
printf "\n"

# Escape sequences
printf "tab:\there\n"
printf "newline:\nhere\n"
printf "backslash:\\\n"
printf "percent: 100%%\n"

# Octal and hex in strings
printf "\101\102\103\n"
printf "\x41\x42\x43\n"

# Integer formats
printf "%+d\n" 42
printf "%+d\n" -42
printf "% d\n" 42
