#!/bin/sh
# 07_test_primaries.sh - test / [ all primaries

# String tests
[ "hello" = "hello" ] && echo "str eq pass" || echo "str eq fail"
[ "hello" = "world" ] && echo "str eq pass" || echo "str eq fail"
[ "hello" != "world" ] && echo "str ne pass" || echo "str ne fail"
[ -n "hello" ] && echo "-n nonempty" || echo "-n fail"
[ -z "" ] && echo "-z empty" || echo "-z fail"
[ -z "x" ] && echo "-z fail" || echo "-z nonempty"

# Integer tests
[ 5 -eq 5 ] && echo "int eq" || echo "int ne"
[ 5 -ne 6 ] && echo "int ne" || echo "int eq"
[ 3 -lt 5 ] && echo "3 lt 5" || echo "fail"
[ 5 -gt 3 ] && echo "5 gt 3" || echo "fail"
[ 3 -le 3 ] && echo "3 le 3" || echo "fail"
[ 4 -ge 4 ] && echo "4 ge 4" || echo "fail"
[ 5 -lt 3 ] && echo "fail" || echo "5 not lt 3"

# Compound with -a and -o
[ 1 -eq 1 -a 2 -eq 2 ] && echo "-a both true" || echo "fail"
[ 1 -eq 2 -a 2 -eq 2 ] && echo "fail" || echo "-a one false"
[ 1 -eq 2 -o 2 -eq 2 ] && echo "-o second true" || echo "fail"
[ 1 -eq 2 -o 3 -eq 4 ] && echo "fail" || echo "-o both false"

# Negation
[ ! 1 -eq 2 ] && echo "not ne pass" || echo "fail"

# File tests - use /dev/null which always exists
[ -e /dev/null ] && echo "-e /dev/null" || echo "fail"
[ -f /dev/null ] && echo "-f /dev/null" || echo "not regular"
[ -c /dev/null ] && echo "-c /dev/null is char" || echo "fail"

# /etc/hosts is a regular file on both macOS and Linux
[ -f /etc/hosts ] && echo "-f /etc/hosts" || echo "fail"
[ -r /etc/hosts ] && echo "-r /etc/hosts" || echo "fail"
