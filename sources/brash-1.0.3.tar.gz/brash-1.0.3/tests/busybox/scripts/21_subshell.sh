#!/bin/sh
# 21_subshell.sh - Subshell and command grouping

# Subshell isolation
x=outer
(x=inner; echo "subshell x=$x")
echo "after subshell x=$x"

# Command grouping with { }
{ echo "grouped 1"; echo "grouped 2"; }

# Grouped output redirect
{ echo "line1"; echo "line2"; } > /tmp/brash_bb_subsh_$$
cat /tmp/brash_bb_subsh_$$
rm /tmp/brash_bb_subsh_$$

# Subshell exit status
(exit 7)
echo "subshell exit: $?"

# Subshell can't affect parent's cd
(cd /tmp; echo "in subshell: pwd=$(pwd)")
echo "parent dir unchanged: $(pwd | grep -c brash)"

# Nested subshells
(
    x=level1
    (
        x=level2
        echo "innermost: $x"
    )
    echo "middle: $x"
)
echo "outer: $x"

# Command group with pipe
{ echo "a"; echo "b"; echo "c"; } | sort -r

# Subshell with trap (trap doesn't propagate)
(
    trap 'echo subshell trap' EXIT
    echo "in subshell"
)
echo "after subshell (no trap output expected here)"

# ( ) vs { } syntax
result=$(echo "via comsub")
echo "$result"
