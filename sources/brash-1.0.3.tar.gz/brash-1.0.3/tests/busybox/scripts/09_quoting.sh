#!/bin/sh
# 09_quoting.sh - Quoting edge cases

# Double-quote preserves spaces
x="hello   world"
echo "$x"
echo $x

# Single-quote suppresses all expansion
echo 'no $expansion here'
echo 'no $(command here)'

# Backslash escaping
echo "tab:\there"
echo "newline first line\nsecond line"
echo a\ b\ c
echo "quote: \""
echo 'backslash: \'

# Mixing quote styles
echo "it's"'a "test"'

# Null strings in expansions
empty=""
echo "before${empty}after"

# Dollar in various positions
echo "$?"
true
echo "$?"
false
echo "$?"

# Quoted dollar
echo "\$HOME"
echo '$HOME'

# Command substitution in double quotes
echo "ls is: $(echo hello)"

# Arithmetic in double quotes
echo "2+2=$(( 2 + 2 ))"
