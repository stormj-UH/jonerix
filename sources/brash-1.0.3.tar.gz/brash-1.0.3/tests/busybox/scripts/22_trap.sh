#!/bin/sh
# 22_trap.sh - trap builtin

# EXIT trap
(
    trap 'echo exit trap fired' EXIT
    echo "doing work"
)

# ERR trap - fires on non-zero exit (bash/ash support)
# Use a controlled form to avoid portability issues
# Just test EXIT and signals we can raise

# Trap resets on function call
trap_test() {
    echo "in function"
}

(
    trap 'echo outer exit' EXIT
    trap_test
    echo "back in main"
)

# trap with list
(
    trap 'echo caught; exit 0' INT TERM
    echo "traps set"
    # Can't actually send a signal here portably, just show it ran
)

# trap - (reset to default)
(
    trap 'echo should not fire' EXIT
    trap - EXIT
    echo "trap reset"
)

# trap '' (ignore)
(
    trap '' EXIT
    echo "ignored exit trap"
)

echo "all trap tests done"
