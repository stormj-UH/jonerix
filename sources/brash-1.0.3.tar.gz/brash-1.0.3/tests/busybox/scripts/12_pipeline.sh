#!/bin/sh
# 12_pipeline.sh - Pipeline and exit status

# Basic pipeline
echo "hello world" | tr 'a-z' 'A-Z'

# Pipeline exit status is last command's
echo "abc" | grep abc
echo "exit: $?"

echo "abc" | grep xyz
echo "exit: $?"

# Negated pipeline with !
! echo "abc" | grep abc
echo "negated exit: $?"

# Pipeline with multiple stages
printf "cherry\napple\nbanana\n" | sort | head -2

# Pipelines don't share variable scope
x=outer
echo test | (read line; x=inner; echo "inner x=$x")
echo "outer x=$x"

# Subshell in pipeline
(echo sub1; echo sub2) | sort -r

# Command grouping in pipeline
{ echo grouped1; echo grouped2; } | sort

# Pipe to while loop
count=0
printf "a\nb\nc\n" | while read line; do
    count=$((count + 1))
    echo "$count: $line"
done
