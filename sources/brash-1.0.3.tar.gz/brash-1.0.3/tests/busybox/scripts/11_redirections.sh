#!/bin/sh
# 11_redirections.sh - Redirection variants

# Basic output redirect
echo hello > /tmp/brash_bb_redir_$$
cat /tmp/brash_bb_redir_$$
rm /tmp/brash_bb_redir_$$

# Append redirect
echo first  > /tmp/brash_bb_redir_$$
echo second >> /tmp/brash_bb_redir_$$
cat /tmp/brash_bb_redir_$$
rm /tmp/brash_bb_redir_$$

# stderr redirect
(echo err >&2) 2>/tmp/brash_bb_redir_$$
cat /tmp/brash_bb_redir_$$
rm /tmp/brash_bb_redir_$$

# stdout+stderr to same file
(echo out; echo err >&2) >/tmp/brash_bb_redir_$$ 2>&1
sort /tmp/brash_bb_redir_$$
rm /tmp/brash_bb_redir_$$

# Redirect stdin from file
echo "from file" > /tmp/brash_bb_redir_$$
read line < /tmp/brash_bb_redir_$$
echo "read: $line"
rm /tmp/brash_bb_redir_$$

# /dev/null
echo "this disappears" > /dev/null
echo "after devnull"

# fd duplication
exec 3>/tmp/brash_bb_redir_$$
echo "to fd3" >&3
exec 3>&-
cat /tmp/brash_bb_redir_$$
rm /tmp/brash_bb_redir_$$

# Here-string redirect
read w <<< "just a word"
echo "word: $w"

echo done
