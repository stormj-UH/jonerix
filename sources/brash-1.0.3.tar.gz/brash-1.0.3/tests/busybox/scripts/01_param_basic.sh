#!/bin/sh
# 01_param_basic.sh - Basic parameter expansion

x=hello
echo "${x}"
echo "${#x}"

unset y
echo "${y:-default}"
echo "${y-notset}"
echo "${y:+isset}"
echo "${y+notset}"

y=
echo "${y:-empty}"
echo "${y-notempty}"
echo "${y:+isset}"
echo "${y+notunset}"

y=value
echo "${y:-default}"
echo "${y:+isset}"
echo "${y+notunset}"
