#!/bin/sh
# 29_arithmetic2.sh - Advanced arithmetic: compound assignment, bases

# Compound assignment operators
n=10
: $((n += 5));  echo "n+=5: $n"
: $((n -= 3));  echo "n-=3: $n"
: $((n *= 2));  echo "n*=2: $n"
: $((n /= 4));  echo "n/=4: $n"
: $((n %= 3));  echo "n%=3: $n"
: $((n = 8));   echo "n=8: $n"
: $((n <<= 2)); echo "n<<=2: $n"
: $((n >>= 1)); echo "n>>=1: $n"

# Pre/post increment/decrement
n=5
echo $((n++))   # returns 5, n becomes 6
echo "after n++: $n"
echo $((n--))   # returns 6, n becomes 5
echo "after n--: $n"
echo $((++n))   # returns 6, n becomes 6
echo "after ++n: $n"
echo $((--n))   # returns 5, n becomes 5
echo "after --n: $n"

# Different bases
echo $((0x1F))    # hex 31
echo $((017))     # octal 15
echo $((2#1010))  # base-2 = 10

# Arithmetic in for-loop style  (not C-style, use while)
i=0
while [ $i -lt 5 ]; do
    printf "%d " $i
    i=$((i + 1))
done
echo

# Large numbers
echo $((2 ** 16 - 1))  # some shells don't support **
# fallback: just use direct
echo $((65535))
echo $((1073741824))   # 2^30

# Signed arithmetic
echo $((-1 * -1))
echo $((-(3 + 4)))
