#!/bin/sh
# tests/busybox/run.sh — busybox ash-style POSIX conformance test runner
#
# Tests brash against a corpus of 30 POSIX shell scripts covering ash/busybox
# strong areas: parameter expansion, arithmetic, case patterns, IFS splitting,
# quoting, heredocs, redirections, pipelines, printf, read, functions, loops,
# getopts, eval, subshells, traps, builtins, and POSIX compliance patterns.
#
# Each .sh script has a pre-generated .expected file produced by the bash oracle.
# A test passes when brash stdout matches the .expected file byte-for-byte.
#
# Usage:
#   ./tests/busybox/run.sh [--update] [--verbose] [pattern]
#
#   --update    Re-run oracle (bash) and overwrite .expected files
#   --verbose   Show diff for every failure
#   pattern     Only run scripts matching this glob (default: *.sh)
#
# Oracle preference:
#   1. bash 5.x  (present on macOS via Homebrew; on Linux distros)
#   2. dash      (present on Debian/Ubuntu)
#   3. bash      (from PATH)
#
# Exit status: 0 if all tests pass, 1 if any fail.

set -u

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
SCRIPTS_DIR="$SCRIPT_DIR/scripts"

# ── locate brash ──────────────────────────────────────────────────────────────
BRASH="${BRASH:-$REPO_ROOT/target/release/brash}"
if [ ! -x "$BRASH" ]; then
    echo "ERROR: brash not found at $BRASH" >&2
    echo "Run: cargo build --release" >&2
    exit 1
fi

# ── locate oracle shell ───────────────────────────────────────────────────────
find_oracle() {
    # Prefer bash 5.x for modern POSIX compliance
    if command -v bash >/dev/null 2>&1; then
        echo "bash"
        return
    fi
    if [ -x /bin/dash ]; then
        echo "/bin/dash"
        return
    fi
    if command -v dash >/dev/null 2>&1; then
        command -v dash
        return
    fi
    echo ""
}

ORACLE="$(find_oracle)"
if [ -z "$ORACLE" ]; then
    echo "ERROR: no POSIX oracle found (need bash or dash)" >&2
    exit 1
fi

# ── parse flags ───────────────────────────────────────────────────────────────
UPDATE=0
VERBOSE=0
PATTERN="*.sh"

for arg in "$@"; do
    case "$arg" in
        --update)  UPDATE=1  ;;
        --verbose) VERBOSE=1 ;;
        --*)       echo "Unknown flag: $arg" >&2; exit 1 ;;
        *)         PATTERN="$arg" ;;
    esac
done

# ── update expected files if requested ───────────────────────────────────────
if [ "$UPDATE" -eq 1 ]; then
    echo "Updating expected files using oracle: $ORACLE"
    count=0
    for f in "$SCRIPTS_DIR"/$PATTERN; do
        [ "${f%.sh}" = "$f" ] && continue   # skip .expected etc.
        [ -f "$f" ] || continue
        expected="${f%.sh}.expected"
        $ORACLE "$f" > "$expected" 2>/dev/null
        echo "  updated: $(basename "$expected")"
        count=$((count + 1))
    done
    echo "Updated $count expected files."
    exit 0
fi

# ── run tests ─────────────────────────────────────────────────────────────────
pass=0
fail=0
skip=0
total=0
fail_names=""

printf '\n%-45s %s\n' "TEST" "RESULT"
printf '%-45s %s\n' "$(printf '%0.s-' $(seq 1 45))" "------"

for f in "$SCRIPTS_DIR"/$PATTERN; do
    [ "${f%.sh}" = "$f" ] && continue   # skip non-.sh files
    [ -f "$f" ] || continue

    base="$(basename "$f" .sh)"
    expected="${f%.sh}.expected"
    total=$((total + 1))

    if [ ! -f "$expected" ]; then
        printf '%-45s SKIP (no .expected)\n' "$base"
        skip=$((skip + 1))
        continue
    fi

    # Run brash; stderr is discarded — error message wording is not
    # part of the POSIX contract
    actual="$("$BRASH" "$f" 2>/dev/null)"
    exp="$(cat "$expected")"

    if [ "$actual" = "$exp" ]; then
        printf '%-45s PASS\n' "$base"
        pass=$((pass + 1))
    else
        printf '%-45s FAIL\n' "$base"
        fail=$((fail + 1))
        fail_names="$fail_names $base"

        if [ "$VERBOSE" -eq 1 ]; then
            echo "  --- expected ---"
            echo "$exp"    | head -20 | sed 's/^/  < /'
            echo "  --- brash ---"
            echo "$actual" | head -20 | sed 's/^/  > /'
            echo "  --- diff (first 20 lines) ---"
            _tmpA="/tmp/brash-bb-exp-$$"
            _tmpB="/tmp/brash-bb-got-$$"
            echo "$exp"    > "$_tmpA"
            echo "$actual" > "$_tmpB"
            diff "$_tmpA" "$_tmpB" | head -20 | sed 's/^/  /'
            rm -f "$_tmpA" "$_tmpB"
            echo ""
        fi
    fi
done

# ── summary ───────────────────────────────────────────────────────────────────
printf '\n%s\n' "══════════════════════════════════════════════════"
printf 'Suite:   busybox ash-style POSIX conformance\n'
printf 'Oracle:  %s\n' "$ORACLE"
printf 'Brash:   %s\n' "$BRASH"
printf 'Total:   %d  Pass: %d  Fail: %d  Skip: %d\n' \
    "$total" "$pass" "$fail" "$skip"

if [ "$total" -gt 0 ]; then
    pct=$(( (pass * 100) / total ))
    printf 'Conformance: %d%%\n' "$pct"
fi

if [ "$fail" -gt 0 ]; then
    printf '\nFailing tests:\n'
    for n in $fail_names; do
        printf '  %s\n' "$n"
    done
fi

printf '%s\n\n' "══════════════════════════════════════════════════"

# ── exit status ───────────────────────────────────────────────────────────────
[ "$fail" -eq 0 ]
