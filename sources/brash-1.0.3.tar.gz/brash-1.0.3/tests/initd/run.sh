#!/usr/bin/env bash
# tests/initd/run.sh — differential test: LSB-format init.d scripts under bash vs brash.
#
# Each script under tests/initd/scripts/ is invoked once per ACTIONS list.
# Stdout, stderr, and exit code are compared between bash and brash.
# A "pass" means byte-identical output and matching exit codes for ALL actions.
#
# Usage:
#   tests/initd/run.sh               # run all scripts, all actions
#   tests/initd/run.sh 00_syslog     # run only 00_syslog.sh (without .sh suffix)
#   BRASH_BIN=/path/to/brash tests/initd/run.sh
#   BASH_BIN=/path/to/bash  tests/initd/run.sh
#   VERBOSE=1               tests/initd/run.sh
#
# Output:
#   Per-script/action: PASS or FAIL <reason>
#   Summary line: "<passed>/<total> byte-identical"
#   Exit 0 if all pass, 1 if any fail/hang.

set -u

repo_root=$(cd "$(dirname "$0")/../.." && pwd)
scripts_dir="$repo_root/tests/initd/scripts"

BRASH_BIN="${BRASH_BIN:-$repo_root/target/release/brash}"
BASH_BIN="${BASH_BIN:-/opt/homebrew/bin/bash}"
[ -x "$BASH_BIN" ] || BASH_BIN=/bin/bash
TIMEOUT_SEC="${TIMEOUT_SEC:-15}"
VERBOSE="${VERBOSE:-}"

# Actions exercised against every script. "status" is the safest universal action.
# We also include the invalid-usage path to check error messages.
ACTIONS="status start stop restart"
INVALID_ACTION="__invalid_action__"

if [ ! -x "$BRASH_BIN" ]; then
    echo "ERROR: brash not found at $BRASH_BIN — run 'cargo build --release' first" >&2
    exit 2
fi
if [ ! -x "$BASH_BIN" ]; then
    echo "ERROR: bash not found at $BASH_BIN" >&2
    exit 2
fi

# Locate timeout binary (gtimeout on macOS, timeout on Linux)
if command -v gtimeout >/dev/null 2>&1; then
    TIMEOUT_CMD=gtimeout
elif command -v timeout >/dev/null 2>&1; then
    TIMEOUT_CMD=timeout
else
    TIMEOUT_CMD=
fi

run_with_timeout() {
    if [ -n "$TIMEOUT_CMD" ]; then
        "$TIMEOUT_CMD" "$TIMEOUT_SEC" "$@"
    else
        "$@"
    fi
}

# Build list of scripts to run
if [ "$#" -gt 0 ]; then
    selected=()
    for arg in "$@"; do
        path="$scripts_dir/$arg.sh"
        [ -f "$path" ] || path="$scripts_dir/$arg"
        if [ -f "$path" ]; then
            selected+=("$path")
        else
            echo "WARN: no script $arg under $scripts_dir" >&2
        fi
    done
else
    selected=()
    for f in "$scripts_dir"/*.sh; do
        [ -f "$f" ] && selected+=("$f")
    done
fi

[ "${#selected[@]}" -eq 0 ] && { echo "no scripts to run"; exit 0; }

passed=0
failed=0
hung=0
# total = scripts * (actions + invalid)
action_list="$ACTIONS $INVALID_ACTION"
action_count=$(echo $action_list | wc -w | tr -d ' ')
total=$(( ${#selected[@]} * action_count ))

run_one() {
    local script="$1"
    local action="$2"
    local name
    name=$(basename "$script" .sh)
    local label="${name}/${action}"

    local sandbox
    sandbox=$(mktemp -d)

    # Run brash
    local brash_stdout="$sandbox/brash.stdout"
    local brash_stderr="$sandbox/brash.stderr"
    (cd "$sandbox" && env -i \
        HOME="$HOME" \
        PATH="/usr/bin:/bin:/usr/local/bin:/opt/homebrew/bin" \
        TMPDIR="${TMPDIR:-/tmp}" \
        run_with_timeout "$BRASH_BIN" "$script" "$action") \
        > "$brash_stdout" 2> "$brash_stderr"
    local brash_rc=$?

    # Run bash
    local bash_stdout="$sandbox/bash.stdout"
    local bash_stderr="$sandbox/bash.stderr"
    (cd "$sandbox" && env -i \
        HOME="$HOME" \
        PATH="/usr/bin:/bin:/usr/local/bin:/opt/homebrew/bin" \
        TMPDIR="${TMPDIR:-/tmp}" \
        run_with_timeout "$BASH_BIN" "$script" "$action") \
        > "$bash_stdout" 2> "$bash_stderr"
    local bash_rc=$?

    if [ "$brash_rc" -eq 124 ] || [ "$bash_rc" -eq 124 ]; then
        printf "HANG: %s (brash_rc=%d bash_rc=%d)\n" "$label" "$brash_rc" "$bash_rc"
        hung=$((hung + 1))
        rm -rf "$sandbox"
        return
    fi

    local stdout_diff= stderr_diff= rc_diff=
    cmp -s "$brash_stdout" "$bash_stdout" || stdout_diff=stdout
    cmp -s "$brash_stderr" "$bash_stderr" || stderr_diff=stderr
    [ "$brash_rc" -eq "$bash_rc" ]        || rc_diff="rc(bash=$bash_rc,brash=$brash_rc)"

    if [ -z "$stdout_diff" ] && [ -z "$stderr_diff" ] && [ -z "$rc_diff" ]; then
        printf "PASS: %s\n" "$label"
        passed=$((passed + 1))
    else
        local reasons
        reasons=$(printf '%s %s %s' "$stdout_diff" "$stderr_diff" "$rc_diff" | tr -s ' ' | sed 's/^ //;s/ $//')
        printf "FAIL: %s [%s]\n" "$label" "$reasons"
        failed=$((failed + 1))

        if [ -n "$VERBOSE" ]; then
            if [ -n "$stdout_diff" ]; then
                echo "  --- stdout diff (bash vs brash) ---"
                diff -u "$bash_stdout" "$brash_stdout" | sed 's/^/  /' | head -30
            fi
            if [ -n "$stderr_diff" ]; then
                echo "  --- stderr diff (bash vs brash) ---"
                diff -u "$bash_stderr" "$brash_stderr" | sed 's/^/  /' | head -30
            fi
            if [ -n "$rc_diff" ]; then
                echo "  --- $rc_diff ---"
            fi
        fi
    fi

    rm -rf "$sandbox"
}

# Run all combinations
for script in "${selected[@]}"; do
    for action in $action_list; do
        run_one "$script" "$action"
    done
done

echo
printf "=== %d passed, %d failed, %d hung, %d total — %d%% byte-identical ===\n" \
    "$passed" "$failed" "$hung" "$total" \
    "$(( total > 0 ? passed * 100 / total : 0 ))"

if [ "$failed" -ne 0 ] || [ "$hung" -ne 0 ]; then
    exit 1
fi
exit 0
