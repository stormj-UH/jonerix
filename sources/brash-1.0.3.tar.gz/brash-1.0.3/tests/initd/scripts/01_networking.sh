#!/bin/sh
# /etc/init.d/networking - LSB init script for network interfaces
### BEGIN INIT INFO
# Provides:          networking
# Required-Start:    mountkernfs $local_fs
# Required-Stop:     $local_fs
# Default-Start:     S
# Default-Stop:      0 6
# Short-Description: Raise network interfaces
# Description:       Raises or lowers all configured network interfaces.
### END INIT INFO

# Inline mock of /lib/lsb/init-functions
log_daemon_msg() { printf '%s: %s' "$1" "${2:-}"; }
log_end_msg()    { if [ "$1" -eq 0 ]; then echo " ok"; else echo " failed"; fi; }
log_progress_msg() { printf ' %s' "$1"; }
log_warning_msg()  { echo "Warning: $1" >&2; }
log_failure_msg()  { echo "Failure: $1" >&2; }
log_success_msg()  { echo "Success: $1"; }

NAME=networking
DESC="network interfaces"
IFACES="lo eth0 eth1"

do_start() {
    for iface in $IFACES; do
        echo "  Raising $iface"
    done
    return 0
}

do_stop() {
    for iface in $IFACES; do
        echo "  Lowering $iface"
    done
    return 0
}

do_status() {
    echo "Configured interfaces: $IFACES"
    return 0
}

case "$1" in
    start)
        log_daemon_msg "Configuring" "$DESC"
        do_start
        log_end_msg $?
        ;;
    stop)
        log_daemon_msg "Deconfiguring" "$DESC"
        do_stop
        log_end_msg $?
        ;;
    restart|force-reload)
        do_stop
        do_start
        ;;
    status)
        do_status
        ;;
    *)
        echo "Usage: $0 {start|stop|restart|force-reload|status}" >&2
        exit 1
        ;;
esac
exit 0
