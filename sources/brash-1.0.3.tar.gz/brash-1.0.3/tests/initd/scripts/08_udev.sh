#!/bin/sh
# /etc/init.d/udev - LSB init script for udev device manager
### BEGIN INIT INFO
# Provides:          udev
# Required-Start:    mountkernfs
# Required-Stop:
# Default-Start:     S
# Default-Stop:
# Short-Description: Start udev - the device manager
# Description:       udev is the device manager for the Linux 2.6 kernel.
#                    Primarily, it manages device nodes in /dev.
#                    It also handles all user space events raised when hardware
#                    is added or removed from the system.
### END INIT INFO

# Inline mock of /lib/lsb/init-functions
log_daemon_msg() { printf '%s: %s' "$1" "${2:-}"; }
log_end_msg()    { if [ "$1" -eq 0 ]; then echo " ok"; else echo " failed"; fi; }
log_progress_msg() { printf ' %s' "$1"; }
log_warning_msg()  { echo "Warning: $1" >&2; }
log_failure_msg()  { echo "Failure: $1" >&2; }
log_success_msg()  { echo "Success: $1"; }

NAME=udevd
DAEMON=/sbin/udevd
DESC="udev Kernel Device Manager"
PIDFILE=/var/run/udev/udevd.pid
UDEV_ROOT=/dev

KERNEL=$(uname -r 2>/dev/null || echo "unknown")
KERNEL_MAJOR=${KERNEL%%.*}

make_extra_nodes() {
    echo "  Making extra static nodes"
}

load_rules() {
    echo "  Loading udev rules"
}

do_start() {
    make_extra_nodes
    load_rules
    echo "Starting $DESC ($NAME) kernel=$KERNEL"
    return 0
}

do_stop() {
    echo "Stopping $DESC ($NAME)"
    return 0
}

case "$1" in
    start)
        log_daemon_msg "Starting" "$DESC"
        do_start
        log_end_msg $?
        ;;
    stop)
        log_daemon_msg "Stopping" "$DESC"
        do_stop
        log_end_msg $?
        ;;
    restart)
        do_stop
        do_start
        ;;
    reload|force-reload)
        log_daemon_msg "Reloading" "$DESC"
        echo "Reloading udev rules"
        log_end_msg 0
        ;;
    status)
        echo "$NAME: not running (test environment)"
        exit 3
        ;;
    *)
        echo "Usage: $0 {start|stop|restart|reload|force-reload|status}" >&2
        exit 1
        ;;
esac
exit 0
