#!/bin/sh
# /etc/init.d/ntp - LSB init script for NTP time synchronization
### BEGIN INIT INFO
# Provides:          ntp
# Required-Start:    $syslog $local_fs
# Required-Stop:     $syslog $local_fs
# Default-Start:     2 3 4 5
# Default-Stop:      0 1 6
# Short-Description: Network Time Protocol daemon
# Description:       NTP, the Network Time Protocol, is used to keep the
#                    computer clocks synchronized with time servers.
### END INIT INFO

# Inline mock of /lib/lsb/init-functions
log_daemon_msg() { printf '%s: %s' "$1" "${2:-}"; }
log_end_msg()    { if [ "$1" -eq 0 ]; then echo " ok"; else echo " failed"; fi; }
log_progress_msg() { printf ' %s' "$1"; }
log_warning_msg()  { echo "Warning: $1" >&2; }
log_failure_msg()  { echo "Failure: $1" >&2; }
log_success_msg()  { echo "Success: $1"; }

NAME=ntpd
DAEMON=/usr/sbin/ntpd
DESC="Network Time Protocol daemon"
PIDFILE=/var/run/ntpd.pid
NTPD_OPTS="-g"

do_start() {
    echo "Starting $DESC ($NAME)"
    return 0
}

do_stop() {
    echo "Stopping $DESC ($NAME)"
    return 0
}

do_wait_for_sync() {
    # In real ntp scripts, this polls ntptime/ntpq
    echo "  Time sync: not waiting in test environment"
    return 0
}

case "$1" in
    start)
        log_daemon_msg "Starting" "$DESC"
        do_start
        log_end_msg $?
        ;;
    stop)
        log_daemon_msg "Stopping" "$DESC"
        do_stop
        log_end_msg $?
        ;;
    restart|force-reload)
        do_stop
        do_start
        ;;
    reload)
        log_daemon_msg "Reloading" "$DESC"
        echo "Sending HUP to $NAME"
        log_end_msg $?
        ;;
    status)
        echo "$NAME: not running (test environment)"
        exit 3
        ;;
    wait-sync)
        do_wait_for_sync
        ;;
    *)
        echo "Usage: $0 {start|stop|restart|reload|force-reload|status|wait-sync}" >&2
        exit 1
        ;;
esac
exit 0
