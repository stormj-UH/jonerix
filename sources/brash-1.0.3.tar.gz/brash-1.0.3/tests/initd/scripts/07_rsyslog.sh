#!/bin/sh
# /etc/init.d/rsyslog - LSB init script for rsyslog
### BEGIN INIT INFO
# Provides:          rsyslog syslog
# Required-Start:    $local_fs $network $remote_fs
# Required-Stop:     $local_fs $network $remote_fs
# Default-Start:     2 3 4 5
# Default-Stop:      0 1 6
# Short-Description: Enhanced system logging and kernel message trapping daemon
# Description:       Rsyslog is an enhanced multi-threaded syslogd supporting,
#                    among others, MySQL, syslog/tcp, RFC 3195, permitted
#                    sender lists, filtering on any message part, and fine
#                    grain output format control.
### END INIT INFO

# Inline mock of /lib/lsb/init-functions
log_daemon_msg() { printf '%s: %s' "$1" "${2:-}"; }
log_end_msg()    { if [ "$1" -eq 0 ]; then echo " ok"; else echo " failed"; fi; }
log_progress_msg() { printf ' %s' "$1"; }
log_warning_msg()  { echo "Warning: $1" >&2; }
log_failure_msg()  { echo "Failure: $1" >&2; }
log_success_msg()  { echo "Success: $1"; }

NAME=rsyslogd
DAEMON=/usr/sbin/rsyslogd
DESC="enhanced syslogd"
PIDFILE=/var/run/rsyslogd.pid
RSYSLOG_CONF=/etc/rsyslog.conf

# Default options; can be overridden in /etc/default/rsyslog
RSYSLOG_OPTIONS=""

check_config() {
    echo "  Config check: ok"
    return 0
}

do_start() {
    check_config || return 1
    echo "Starting $DESC ($NAME)"
    return 0
}

do_stop() {
    echo "Stopping $DESC ($NAME)"
    return 0
}

do_reload() {
    echo "Reloading $DESC ($NAME)"
    return 0
}

case "$1" in
    start)
        log_daemon_msg "Starting" "$DESC"
        do_start
        log_end_msg $?
        ;;
    stop)
        log_daemon_msg "Stopping" "$DESC"
        do_stop
        log_end_msg $?
        ;;
    restart|force-reload)
        do_stop
        do_start
        ;;
    reload)
        log_daemon_msg "Reloading" "$DESC"
        do_reload
        log_end_msg $?
        ;;
    rotate)
        log_daemon_msg "Rotating" "$DESC"
        echo "Sending USR1 to $NAME"
        log_end_msg 0
        ;;
    status)
        echo "$NAME: not running (test environment)"
        exit 3
        ;;
    *)
        echo "Usage: $0 {start|stop|restart|reload|force-reload|rotate|status}" >&2
        exit 1
        ;;
esac
exit 0
