#!/bin/sh
# /etc/init.d/postfix - LSB init script for Postfix MTA
### BEGIN INIT INFO
# Provides:          postfix mail-transport-agent
# Required-Start:    $local_fs $remote_fs $syslog $named $network
# Required-Stop:     $local_fs $remote_fs $syslog $named $network
# Default-Start:     2 3 4 5
# Default-Stop:      0 1 6
# Short-Description: Postfix Mail Transport Agent
# Description:       Postfix is Wietse Venema's mail transport agent that
#                    started life as an alternative to the widely-used Sendmail
#                    program.
### END INIT INFO

# Inline mock of /lib/lsb/init-functions
log_daemon_msg() { printf '%s: %s' "$1" "${2:-}"; }
log_end_msg()    { if [ "$1" -eq 0 ]; then echo " ok"; else echo " failed"; fi; }
log_progress_msg() { printf ' %s' "$1"; }
log_warning_msg()  { echo "Warning: $1" >&2; }
log_failure_msg()  { echo "Failure: $1" >&2; }
log_success_msg()  { echo "Success: $1"; }

NAME=postfix
DAEMON=/usr/sbin/postfix
DESC="Postfix Mail Transport Agent"
PIDFILE=/var/spool/postfix/pid/master.pid

# Check if the config directory exists
check_config_dir() {
    QUEUE_DIR=/var/spool/postfix
    echo "  Queue dir: $QUEUE_DIR"
    return 0
}

# Verify main.cf
check_main_cf() {
    echo "  main.cf: ok (test environment)"
    return 0
}

do_start() {
    check_config_dir
    check_main_cf
    echo "Starting $DESC ($NAME)"
    return 0
}

do_stop() {
    echo "Stopping $DESC ($NAME)"
    return 0
}

do_reload() {
    echo "Reloading $DESC ($NAME)"
    return 0
}

do_flush() {
    echo "Flushing mail queue"
    return 0
}

case "$1" in
    start)
        log_daemon_msg "Starting" "$DESC"
        do_start
        log_end_msg $?
        ;;
    stop)
        log_daemon_msg "Stopping" "$DESC"
        do_stop
        log_end_msg $?
        ;;
    restart|force-reload)
        do_stop
        do_start
        ;;
    reload)
        log_daemon_msg "Reloading" "$DESC"
        do_reload
        log_end_msg $?
        ;;
    flush)
        log_daemon_msg "Flushing" "$DESC"
        do_flush
        log_end_msg $?
        ;;
    check)
        echo "Checking Postfix configuration"
        echo "  Configuration: ok (test environment)"
        ;;
    status)
        echo "$NAME: not running (test environment)"
        exit 3
        ;;
    *)
        echo "Usage: $0 {start|stop|restart|reload|force-reload|flush|check|status}" >&2
        exit 1
        ;;
esac
exit 0
