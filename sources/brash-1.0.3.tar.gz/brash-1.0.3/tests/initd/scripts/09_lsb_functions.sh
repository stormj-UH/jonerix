#!/bin/sh
# /etc/init.d/lsb-test - Test that exercises LSB init-functions API surface
### BEGIN INIT INFO
# Provides:          lsb-test
# Required-Start:
# Required-Stop:
# Default-Start:     2 3 4 5
# Default-Stop:      0 1 6
# Short-Description: Test LSB init-functions API coverage
# Description:       Exercises every function in the lsb init-functions
#                    library (inline mocked) to verify API compatibility.
### END INIT INFO

# Inline mock of /lib/lsb/init-functions — full API surface
log_daemon_msg() {
    if [ "$#" -lt 2 ]; then
        printf '%s' "$1"
    else
        printf '%s: %s' "$1" "$2"
    fi
}
log_end_msg() {
    if [ "$1" -eq 0 ]; then
        echo " . ok"
    else
        echo " . failed (rc=$1)"
    fi
}
log_begin_msg() { printf '%s...' "$1"; }
log_success_msg() { echo " OK"; }
log_failure_msg() { echo " FAILED: $1" >&2; }
log_warning_msg() { echo " WARNING: $1" >&2; }
log_progress_msg() { printf '  %s\n' "$1"; }
log_end_msg_pre() { :; }
status_of_proc() {
    local name="${2:-$1}"
    echo "$name is not running"
    return 3
}
start_daemon() {
    echo "start_daemon: would start $1"
    return 0
}
killproc() {
    echo "killproc: would kill $1"
    return 0
}
pidofproc() {
    echo ""
    return 3
}

NAME=lsb-test
DESC="LSB API test service"

do_test() {
    echo "--- LSB function coverage test ---"

    log_begin_msg "Testing log_begin_msg"
    log_success_msg

    log_daemon_msg "Testing log_daemon_msg" "$NAME"
    log_end_msg 0

    log_daemon_msg "Testing log_end_msg failure"
    log_end_msg 1

    log_progress_msg "progress point 1"
    log_progress_msg "progress point 2"

    log_warning_msg "this is a warning"

    pid=$(pidofproc /usr/sbin/notreal)
    echo "pidofproc rc=$?"

    status_of_proc /usr/sbin/notreal "notreal"
    echo "status_of_proc rc=$?"

    start_daemon /usr/sbin/notreal
    echo "start_daemon rc=$?"

    killproc /usr/sbin/notreal
    echo "killproc rc=$?"

    echo "--- done ---"
}

case "$1" in
    start)
        log_daemon_msg "Starting" "$DESC"
        echo "ok"
        log_end_msg 0
        ;;
    stop)
        log_daemon_msg "Stopping" "$DESC"
        echo "ok"
        log_end_msg 0
        ;;
    restart|force-reload)
        echo "Restarting $DESC"
        ;;
    status)
        status_of_proc "$NAME" "$NAME"
        exit $?
        ;;
    test)
        do_test
        ;;
    *)
        echo "Usage: $0 {start|stop|restart|force-reload|status|test}" >&2
        exit 1
        ;;
esac
exit 0
