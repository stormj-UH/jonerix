#!/bin/sh
# /etc/init.d/apache2 - LSB init script for Apache HTTP server
### BEGIN INIT INFO
# Provides:          apache2
# Required-Start:    $local_fs $remote_fs $network $syslog
# Required-Stop:     $local_fs $remote_fs $network $syslog
# Default-Start:     2 3 4 5
# Default-Stop:      0 1 6
# X-Interactive:     true
# Short-Description: Start/stop apache2 web server
# Description:       This script manages the apache2 HTTP daemon.
### END INIT INFO

# Inline mock of /lib/lsb/init-functions
log_daemon_msg() { printf '%s: %s' "$1" "${2:-}"; }
log_end_msg()    { if [ "$1" -eq 0 ]; then echo " ok"; else echo " failed"; fi; }
log_progress_msg() { printf ' %s' "$1"; }
log_warning_msg()  { echo "Warning: $1" >&2; }
log_failure_msg()  { echo "Failure: $1" >&2; }
log_success_msg()  { echo "Success: $1"; }

NAME=apache2
DAEMON=/usr/sbin/apache2
DESC="Apache HTTP Server"
PIDFILE=/var/run/apache2/apache2.pid
ENV="env -i LANG=C PATH=/usr/local/bin:/usr/bin:/bin"

APACHE2CTL=/usr/sbin/apache2ctl
APACHE_CONFDIR=/etc/apache2
APACHE_ENVVARS="$APACHE_CONFDIR/envvars"

check_syntax() {
    echo "  Syntax check: ok"
    return 0
}

do_start() {
    check_syntax || return 1
    echo "Starting $DESC ($NAME)"
    return 0
}

do_stop() {
    echo "Stopping $DESC ($NAME)"
    return 0
}

do_graceful() {
    echo "Gracefully restarting $DESC ($NAME)"
    return 0
}

do_graceful_stop() {
    echo "Gracefully stopping $DESC ($NAME)"
    return 0
}

case "$1" in
    start)
        log_daemon_msg "Starting" "$DESC"
        do_start
        log_end_msg $?
        ;;
    stop)
        log_daemon_msg "Stopping" "$DESC"
        do_stop
        log_end_msg $?
        ;;
    graceful-stop)
        log_daemon_msg "Gracefully stopping" "$DESC"
        do_graceful_stop
        log_end_msg $?
        ;;
    restart)
        do_stop
        do_start
        ;;
    reload|force-reload|graceful)
        log_daemon_msg "Reloading" "$DESC"
        do_graceful
        log_end_msg $?
        ;;
    status)
        echo "$NAME: not running (test environment)"
        exit 3
        ;;
    *)
        echo "Usage: $0 {start|stop|graceful-stop|restart|reload|force-reload|graceful|status}" >&2
        exit 1
        ;;
esac
exit 0
