#!/bin/sh
# /etc/init.d/cron - LSB init script for cron scheduler
### BEGIN INIT INFO
# Provides:          cron
# Required-Start:    $syslog $time $local_fs
# Required-Stop:     $syslog $time $local_fs
# Default-Start:     2 3 4 5
# Default-Stop:      0 1 6
# Short-Description: Regular background program processing daemon
# Description:       cron is a standard UNIX program that runs user-specified
#                    programs at periodic scheduled times.
### END INIT INFO

# Inline mock of /lib/lsb/init-functions
log_daemon_msg() { printf '%s: %s' "$1" "${2:-}"; }
log_end_msg()    { if [ "$1" -eq 0 ]; then echo " ok"; else echo " failed"; fi; }
log_progress_msg() { printf ' %s' "$1"; }
log_warning_msg()  { echo "Warning: $1" >&2; }
log_failure_msg()  { echo "Failure: $1" >&2; }
log_success_msg()  { echo "Success: $1"; }

NAME=cron
DAEMON=/usr/sbin/cron
DESC="periodic command scheduler"
PIDFILE=/var/run/crond.pid

do_start() {
    echo "Starting $DESC ($NAME)"
    return 0
}

do_stop() {
    echo "Stopping $DESC ($NAME)"
    return 0
}

do_reload() {
    echo "Reloading $DESC configuration"
    return 0
}

case "$1" in
    start)
        log_daemon_msg "Starting" "$DESC"
        do_start
        log_end_msg $?
        ;;
    stop)
        log_daemon_msg "Stopping" "$DESC"
        do_stop
        log_end_msg $?
        ;;
    reload)
        log_daemon_msg "Reloading" "$DESC"
        do_reload
        log_end_msg $?
        ;;
    restart|force-reload)
        do_stop
        do_start
        ;;
    status)
        echo "$NAME: not running (test environment)"
        exit 3
        ;;
    *)
        echo "Usage: $0 {start|stop|restart|reload|force-reload|status}" >&2
        exit 1
        ;;
esac
exit 0
