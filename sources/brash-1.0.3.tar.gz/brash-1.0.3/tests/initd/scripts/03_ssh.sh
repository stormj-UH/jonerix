#!/bin/sh
# /etc/init.d/ssh - LSB init script for OpenSSH server
### BEGIN INIT INFO
# Provides:          ssh
# Required-Start:    $remote_fs $syslog
# Required-Stop:     $remote_fs $syslog
# Default-Start:     2 3 4 5
# Default-Stop:
# Short-Description: OpenBSD Secure Shell server
# Description:       OpenSSH is a free implementation of the Secure Shell
#                    protocol as specified by the IETF secsh working group.
#                    Provides the server.
### END INIT INFO

# Inline mock of /lib/lsb/init-functions
log_daemon_msg() { printf '%s: %s' "$1" "${2:-}"; }
log_end_msg()    { if [ "$1" -eq 0 ]; then echo " ok"; else echo " failed"; fi; }
log_progress_msg() { printf ' %s' "$1"; }
log_warning_msg()  { echo "Warning: $1" >&2; }
log_failure_msg()  { echo "Failure: $1" >&2; }
log_success_msg()  { echo "Success: $1"; }

NAME=sshd
DAEMON=/usr/sbin/sshd
DESC="OpenBSD Secure Shell server"
PIDFILE=/var/run/sshd.pid
SSHD_OPTS=""

check_privsep_dir() {
    if [ ! -d /var/run/sshd ]; then
        echo "  Would create /var/run/sshd privilege separation directory"
    fi
}

check_config() {
    echo "  Configuration check: ok"
    return 0
}

export_host_keys() {
    echo "  Host keys: ok"
}

do_start() {
    check_privsep_dir
    export_host_keys
    check_config
    echo "Starting $DESC ($NAME)"
    return 0
}

do_stop() {
    echo "Stopping $DESC ($NAME)"
    return 0
}

do_reload() {
    echo "Reloading $DESC configuration"
    return 0
}

case "$1" in
    start)
        log_daemon_msg "Starting" "$DESC"
        do_start
        log_end_msg $?
        ;;
    stop)
        log_daemon_msg "Stopping" "$DESC"
        do_stop
        log_end_msg $?
        ;;
    reload|force-reload)
        log_daemon_msg "Reloading" "$DESC"
        do_reload
        log_end_msg $?
        ;;
    restart)
        do_stop
        do_start
        ;;
    status)
        echo "$NAME: not running (test environment)"
        exit 3
        ;;
    try-restart)
        echo "$NAME: not running, nothing to restart"
        exit 0
        ;;
    *)
        echo "Usage: $0 {start|stop|restart|reload|force-reload|status|try-restart}" >&2
        exit 1
        ;;
esac
exit 0
