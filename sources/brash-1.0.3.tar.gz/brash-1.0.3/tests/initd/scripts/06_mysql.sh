#!/bin/sh
# /etc/init.d/mysql - LSB init script for MySQL database server
### BEGIN INIT INFO
# Provides:          mysql
# Required-Start:    $local_fs $remote_fs $syslog
# Required-Stop:     $local_fs $remote_fs $syslog
# Should-Start:      $network
# Should-Stop:
# Default-Start:     2 3 4 5
# Default-Stop:      0 1 6
# Short-Description: Start and stop the mysql database server daemon
# Description:       Controls the main MySQL database server daemon "mysqld"
#                    and its wrapper script "mysqld_safe".
### END INIT INFO

# Inline mock of /lib/lsb/init-functions
log_daemon_msg() { printf '%s: %s' "$1" "${2:-}"; }
log_end_msg()    { if [ "$1" -eq 0 ]; then echo " ok"; else echo " failed"; fi; }
log_progress_msg() { printf ' %s' "$1"; }
log_warning_msg()  { echo "Warning: $1" >&2; }
log_failure_msg()  { echo "Failure: $1" >&2; }
log_success_msg()  { echo "Success: $1"; }

NAME=mysql
DAEMON=/usr/sbin/mysqld
DESC="MySQL database server"
PIDFILE=/var/run/mysqld/mysqld.pid
DATADIR=/var/lib/mysql
MYSQLD_SAFE=/usr/bin/mysqld_safe
MYSQL_CONF=/etc/mysql/mysql.conf.d/mysqld.cnf

check_for_upstart() {
    return 1
}

parse_server_arguments() {
    echo "  Server arguments: defaults"
}

wait_for_ready() {
    echo "  Waiting for MySQL: (test environment)"
    return 0
}

do_start() {
    parse_server_arguments
    echo "Starting $DESC ($NAME)"
    return 0
}

do_stop() {
    echo "Stopping $DESC ($NAME)"
    return 0
}

# Extract specific option from MySQL config
get_config() {
    local group="$1"
    local option="$2"
    echo "(test-value)"
}

case "$1" in
    start)
        log_daemon_msg "Starting" "$DESC"
        do_start
        log_end_msg $?
        ;;
    stop)
        log_daemon_msg "Stopping" "$DESC"
        do_stop
        log_end_msg $?
        ;;
    restart)
        do_stop
        do_start
        ;;
    reload|force-reload)
        log_daemon_msg "Reloading" "$DESC"
        echo "Sending HUP to $NAME"
        log_end_msg 0
        ;;
    status)
        echo "$NAME: not running (test environment)"
        exit 3
        ;;
    *)
        echo "Usage: $0 {start|stop|restart|reload|force-reload|status}" >&2
        exit 1
        ;;
esac
exit 0
