#!/bin/sh
# /etc/init.d/dbus - LSB init script for D-Bus message bus daemon
### BEGIN INIT INFO
# Provides:          dbus
# Required-Start:    $syslog $local_fs
# Required-Stop:     $syslog $local_fs
# Default-Start:     2 3 4 5
# Default-Stop:
# Short-Description: D-Bus systemwide message bus
# Description:       D-Bus is a simple interprocess messaging system, used
#                    for sending messages between applications.
### END INIT INFO

# Inline mock of /lib/lsb/init-functions
log_daemon_msg() { printf '%s: %s' "$1" "${2:-}"; }
log_end_msg()    { if [ "$1" -eq 0 ]; then echo " ok"; else echo " failed"; fi; }
log_progress_msg() { printf ' %s' "$1"; }
log_warning_msg()  { echo "Warning: $1" >&2; }
log_failure_msg()  { echo "Failure: $1" >&2; }
log_success_msg()  { echo "Success: $1"; }

NAME=dbus
DAEMON=/usr/bin/dbus-daemon
DESC="D-Bus System Message Bus"
PIDFILE=/var/run/dbus/pid
UUIDFILE=/var/lib/dbus/machine-id

create_machineid() {
    if [ ! -f "$UUIDFILE" ]; then
        echo "  Would create machine-id at $UUIDFILE"
    else
        echo "  machine-id exists"
    fi
}

create_directories() {
    echo "  Creating /var/run/dbus"
}

do_start() {
    create_machineid
    create_directories
    echo "Starting $DESC ($NAME)"
    return 0
}

do_stop() {
    echo "Stopping $DESC ($NAME)"
    return 0
}

case "$1" in
    start)
        log_daemon_msg "Starting" "$DESC"
        do_start
        log_end_msg $?
        ;;
    stop)
        log_daemon_msg "Stopping" "$DESC"
        do_stop
        log_end_msg $?
        ;;
    restart)
        do_stop
        do_start
        ;;
    reload|force-reload)
        log_daemon_msg "Reloading" "$DESC"
        echo "Sending HUP to $NAME"
        log_end_msg 0
        ;;
    status)
        echo "$NAME: not running (test environment)"
        exit 3
        ;;
    *)
        echo "Usage: $0 {start|stop|restart|reload|force-reload|status}" >&2
        exit 1
        ;;
esac
exit 0
