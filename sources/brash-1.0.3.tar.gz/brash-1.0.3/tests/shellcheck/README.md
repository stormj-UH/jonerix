# tests/shellcheck — bash snippet differential harness

Differential testing of brash vs bash using ~170 curated bash snippets
that cover the same areas shellcheck (the static analyzer) tests.

## What it does

For each snippet the harness runs it under both bash and brash and compares
exit codes.  A test passes when both shells agree — we care about
parse/execution success, not stdout.

The snippets cover:

- Parameter expansion (all forms: `${x:-d}`, `${x#p}`, `${x^^}`, `${!n}`, …)
- Quoting: double, single, `$'...'` ANSI-C escapes, `$"..."` locale strings
- Brace expansion: sequences, numeric ranges with step, zero-padding
- Command substitution: `$(...)` and backtick, nested
- Arithmetic: `$((...))`, `((...))`, C operators, hex/octal, ternary, bitwise
- Process substitution: `<(...)`, `>(...)` via `tee`
- Here-documents (basic, indented `<<-`, quoted `<<'EOF'`, expanding) and here-strings
- `[[ ]]` conditionals: string ops, regex `=~`, glob, file tests, `-v`, `&&`/`||`
- Indexed arrays: slice, negative index, `mapfile`/`readarray`
- Associative arrays: declare, keys, length
- Functions: args, `local`, `return`, recursion, `local -n` nameref
- Loops: `for`/`in`, C-style `for`, `while`, `until`, `break`, `continue`
- Pipelines and redirection: append, fd duplication, noclobber, `lastpipe`
- Special variables: `$*`, `$@`, `$#`, `$$`, `$!`, `${PIPESTATUS[@]}`, `$LINENO`, `${FUNCNAME[@]}`
- `declare`/`typeset`: `-i`, `-r`, `-x`, `-u`, `-l`, `-p`
- Builtins: `printf`, `read`, `eval`, `source`, `getopts`, `set -e/u`, `trap`, `type`, `command`, `compgen`
- Subshells, brace-groups, variable scoping
- Shopts: `extglob` (`?(…)`, `+(…)`, `@(…)`), `nocasematch`, `dotglob`, `nullglob`, `globstar`, `lastpipe`
- Coprocesses (`coproc`)

## Running

```sh
# From repo root — brash must be built first:
cargo build --release

bash tests/shellcheck/run.sh
```

Or override the paths:

```sh
BRASH=/path/to/brash BASH_CMD=/bin/bash bash tests/shellcheck/run.sh
```

## Ignoring the upstream shellcheck repo

If you want to clone shellcheck for reference, place it at
`tests/shellcheck/shellcheck/` — that path is already in `.gitignore`.

```sh
cd tests/shellcheck
git clone --depth 1 https://github.com/koalaman/shellcheck.git
```
