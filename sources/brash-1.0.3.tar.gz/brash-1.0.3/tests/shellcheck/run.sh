#!/usr/bin/env bash
# tests/shellcheck/run.sh — differential test harness comparing brash vs bash
# on ~100 bash snippets drawn from areas shellcheck typically covers.
#
# For each snippet: run under bash, run under brash, compare exit codes.
# A snippet "passes" when both produce the same exit code.
# We do NOT compare stdout/stderr — only whether parsing+execution succeeds.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
BRASH="${BRASH:-$REPO_ROOT/target/release/brash}"
BASH="${BASH_CMD:-$(command -v bash)}"

# Build brash if needed
if [[ ! -x "$BRASH" ]]; then
    echo "Building brash..."
    (cd "$REPO_ROOT" && cargo build --release)
fi

if [[ ! -x "$BASH" ]]; then
    echo "ERROR: bash not found at $BASH" >&2
    exit 1
fi

pass=0
fail=0
skip=0
failures=()

# run_snippet <label> <snippet>
# Returns 0 if both shells agree on exit code, 1 otherwise.
run_snippet() {
    local label="$1"
    local snippet="$2"

    local bash_ec brash_ec
    bash_ec=0
    brash_ec=0

    # Run under bash; capture exit code; suppress output
    "$BASH" -c "$snippet" >/dev/null 2>&1 || bash_ec=$?
    # Run under brash
    "$BRASH" -c "$snippet" >/dev/null 2>&1 || brash_ec=$?

    if [[ "$bash_ec" == "$brash_ec" ]]; then
        (( pass++ )) || true
    else
        (( fail++ )) || true
        failures+=("FAIL [$label]: bash=$bash_ec brash=$brash_ec  snippet: $snippet")
    fi
    return 0
}

# ---------------------------------------------------------------------------
# SNIPPET DEFINITIONS
# Each call: run_snippet "category/name" 'bash code'
# ---------------------------------------------------------------------------

# --- 1. Basic parameter expansion ---
run_snippet "param/simple"           'x=hello; echo "$x"'
run_snippet "param/default"          'unset v; echo "${v:-default}"'
run_snippet "param/assign-default"   'unset v; echo "${v:=assigned}"; echo "$v"'
run_snippet "param/error-if-unset"   'x=set; echo "${x:?must be set}"'
run_snippet "param/alt-value"        'x=set; echo "${x:+alternate}"'
run_snippet "param/length"           'x=hello; echo "${#x}"'
run_snippet "param/substring"        'x=abcdef; echo "${x:2:3}"'
run_snippet "param/substring-neg"    'x=abcdefgh; echo "${x: -3}"'
run_snippet "param/strip-prefix"     'x=hello_world; echo "${x#hello_}"'
run_snippet "param/strip-prefix-max" 'x=aabba; echo "${x##a*b}"'
run_snippet "param/strip-suffix"     'x=hello_world; echo "${x%_world}"'
run_snippet "param/strip-suffix-max" 'x=hello.tar.gz; echo "${x%%.*}"'
run_snippet "param/replace-first"    'x=aabbcc; echo "${x/bb/XX}"'
run_snippet "param/replace-all"      'x=aabbccbb; echo "${x//bb/XX}"'
run_snippet "param/replace-prefix"   'x=hello; echo "${x/#he/HE}"'
run_snippet "param/replace-suffix"   'x=hello; echo "${x/%lo/LO}"'
run_snippet "param/upper-first"      'x=hello; echo "${x^}"'
run_snippet "param/upper-all"        'x=hello; echo "${x^^}"'
run_snippet "param/lower-first"      'x=HELLO; echo "${x,}"'
run_snippet "param/lower-all"        'x=HELLO; echo "${x,,}"'
run_snippet "param/indirect"         'a=hello; b=a; echo "${!b}"'
run_snippet "param/nameref-prefix"   'aa=1; ab=2; echo "${!a@}"'

# --- 2. Quoting ---
run_snippet "quote/double"           'x="hello world"; echo "$x"'
run_snippet "quote/single"           "echo 'hello world'"
run_snippet "quote/mixed"            'echo "it'"'"'s fine"'
run_snippet "quote/dollar-single"    "echo \$'hello\\tworld'"
run_snippet "quote/dollar-dq"        'x=hi; echo $"$x"'
run_snippet "quote/escape-newline"   'echo "line1\nline2"'
run_snippet "quote/backslash-dq"     'x=5; echo "value is \"$x\""'

# --- 3. Brace expansion ---
run_snippet "brace/sequence"         'echo {a,b,c}'
run_snippet "brace/numeric"          'echo {1..5}'
run_snippet "brace/numeric-step"     'echo {0..10..2}'
run_snippet "brace/alpha"            'echo {a..e}'
run_snippet "brace/nested"           'echo {{a,b},{c,d}}'
run_snippet "brace/prefix-suffix"    'echo pre{x,y}suf'
run_snippet "brace/zero-pad"         'echo {01..05}'

# --- 4. Command substitution ---
run_snippet "cmdsub/backtick"        'echo `echo hello`'
run_snippet "cmdsub/dollar-paren"    'echo $(echo hello)'
run_snippet "cmdsub/nested"          'echo $(echo $(echo hi))'
run_snippet "cmdsub/with-pipe"       'echo $(printf "%s\n" a b c | wc -l)'
run_snippet "cmdsub/assign"          'x=$(echo hello); echo "$x"'

# --- 5. Arithmetic ---
run_snippet "arith/basic"            'echo $((1 + 2))'
run_snippet "arith/var"              'x=5; echo $((x * 2))'
run_snippet "arith/nested"           'echo $(( $(echo 3) + 4 ))'
run_snippet "arith/assign"           '(( x = 5 )); echo $x'
run_snippet "arith/incr"             'x=0; (( x++ )); echo $x'
run_snippet "arith/ternary"          'echo $(( 1 ? 42 : 0 ))'
run_snippet "arith/bitwise"          'echo $(( 5 & 3 ))'
run_snippet "arith/hex"              'echo $(( 0xff ))'
run_snippet "arith/octal"            'echo $(( 010 ))'
run_snippet "arith/shift"            'echo $(( 1 << 4 ))'
run_snippet "arith/modulo"           'echo $(( 10 % 3 ))'
run_snippet "arith/unary-minus"      'x=5; echo $(( -x ))'

# --- 6. Process substitution ---
run_snippet "procsub/input"          'diff <(echo a) <(echo a)'
run_snippet "procsub/output"         'tee >(cat > /dev/null) <<< hello > /dev/null'
run_snippet "procsub/wc-lines"       'wc -l < <(printf "a\nb\nc\n")'

# --- 7. Here-documents and here-strings ---
run_snippet "heredoc/basic"          'cat <<EOF
hello
EOF'
run_snippet "heredoc/indented"       'cat <<-EOF
	hello
	EOF'
run_snippet "heredoc/quoted"         "cat <<'EOF'
\$no_expand
EOF"
run_snippet "heredoc/expand"         'x=hi; cat <<EOF
$x
EOF'
run_snippet "herestring/basic"       'cat <<< "hello"'
run_snippet "herestring/var"         'x=hello; cat <<< "$x"'

# --- 8. Conditional expressions ([[ ]]) ---
run_snippet "cond/string-eq"         '[[ hello == hello ]]'
run_snippet "cond/string-ne"         '[[ hello != world ]]'
run_snippet "cond/string-lt"         '[[ a < b ]]'
run_snippet "cond/regex"             '[[ foobar =~ foo.* ]]'
run_snippet "cond/glob"              '[[ foobar == foo* ]]'
run_snippet "cond/file-exists"       '[[ -e /dev/null ]]'
run_snippet "cond/file-regular"      '[[ -f /dev/null ]]'
run_snippet "cond/and-or"            '[[ 1 == 1 && 2 == 2 ]]'
run_snippet "cond/negation"          '[[ ! 1 == 2 ]]'
run_snippet "cond/int-eq"            '[[ 5 -eq 5 ]]'
run_snippet "cond/int-gt"            '[[ 6 -gt 5 ]]'
run_snippet "cond/unary-n"           '[[ -n "hello" ]]'
run_snippet "cond/unary-z"           '[[ -z "" ]]'
run_snippet "cond/var-set"           'x=1; [[ -v x ]]'

# --- 9. Arrays ---
run_snippet "array/basic"            'a=(1 2 3); echo "${a[0]}"'
run_snippet "array/all-elems"        'a=(x y z); echo "${a[@]}"'
run_snippet "array/length"           'a=(a b c d); echo "${#a[@]}"'
run_snippet "array/slice"            'a=(0 1 2 3 4); echo "${a[@]:1:3}"'
run_snippet "array/append"           'a=(1 2); a+=(3 4); echo "${a[@]}"'
run_snippet "array/indices"          'a=(x y z); echo "${!a[@]}"'
run_snippet "array/unset-elem"       'a=(1 2 3); unset "a[1]"; echo "${a[@]}"'
run_snippet "array/negative-idx"     'a=(1 2 3); echo "${a[-1]}"'
run_snippet "array/mapfile"          'mapfile -t lines <<< $'"'"'a\nb\nc'"'"'; echo "${#lines[@]}"'
run_snippet "array/readarray"        'readarray -t arr < <(printf "x\ny\n"); echo "${arr[1]}"'

# --- 10. Associative arrays ---
run_snippet "assoc/basic"            'declare -A h=([key]=val); echo "${h[key]}"'
run_snippet "assoc/assign"           'declare -A h; h[foo]=bar; echo "${h[foo]}"'
run_snippet "assoc/keys"             'declare -A h=([a]=1 [b]=2); echo "${!h[@]}" | tr " " "\n" | sort | tr "\n" " "'
run_snippet "assoc/length"           'declare -A h=([a]=1 [b]=2 [c]=3); echo "${#h[@]}"'

# --- 11. Functions ---
run_snippet "func/basic"             'f() { echo hello; }; f'
run_snippet "func/args"              'f() { echo "$1 $2"; }; f hello world'
run_snippet "func/local"             'f() { local x=5; echo $x; }; f'
run_snippet "func/return"            'f() { return 42; }; f; echo $?'
run_snippet "func/recursive"         'fact(){ [[ $1 -le 1 ]] && echo 1 || echo $(( $1 * $(fact $(( $1-1 )) ) )); }; fact 5'
run_snippet "func/nameref"           'f() { local -n ref=$1; ref=99; }; x=0; f x; echo $x'

# --- 12. Loops ---
run_snippet "loop/for-in"            'for i in a b c; do echo $i; done'
run_snippet "loop/for-c"             'for (( i=0; i<3; i++ )); do echo $i; done; true'
run_snippet "loop/while"             'i=0; while (( i<3 )); do echo $i; (( i++ )); done'
run_snippet "loop/until"             'i=3; until (( i<=0 )); do echo $i; (( i-- )); done'
run_snippet "loop/break"             'for i in 1 2 3; do [[ $i == 2 ]] && break; echo $i; done'
run_snippet "loop/continue"          'for i in 1 2 3; do [[ $i == 2 ]] && continue; echo $i; done'
run_snippet "loop/for-glob"          'for f in /dev/null /dev/zero; do [[ -e "$f" ]] && echo ok; done'

# --- 13. ANSI-C $'...' escapes ---
run_snippet "ansi/tab"               "echo \$'hello\\tworld'"
run_snippet "ansi/newline"           "echo \$'line1\\nline2'"
run_snippet "ansi/hex"               "echo \$'\\x41'"
run_snippet "ansi/octal"             "echo \$'\\101'"
run_snippet "ansi/unicode"           "echo \$'\\u0041'"
run_snippet "ansi/backslash"         "echo \$'back\\\\slash'"
run_snippet "ansi/single-quote"      "echo \$'it\\'s'"

# --- 14. Pipelines and redirection ---
run_snippet "pipe/basic"             'echo hello | cat'
run_snippet "pipe/multiple"          'echo hello | tr a-z A-Z | cat'
run_snippet "pipe/lastpipe"          'shopt -s lastpipe; echo hello | read x; echo "${x:-empty}"'
run_snippet "redir/stdout"           'echo hello > /dev/null'
run_snippet "redir/append"           'echo hello >> /dev/null'
run_snippet "redir/stderr"           'echo error >&2'
run_snippet "redir/stderr-to-stdout" '{ echo out; echo err >&2; } 2>&1 | cat'
run_snippet "redir/fd"               'exec 3>/dev/null; echo hi >&3; exec 3>&-'
run_snippet "redir/here-redirect"    'while IFS= read -r line; do echo "$line"; done < <(echo hello)'
run_snippet "redir/noclobber"        'f=$(mktemp); rm "$f"; set -o noclobber; echo hi > "$f"; rm -f "$f"'

# --- 15. Special variables ---
run_snippet "special/dollar-star"    'set -- a b c; echo "$*"'
run_snippet "special/dollar-at"      'set -- a b c; echo "$@"'
run_snippet "special/dollar-hash"    'set -- a b c; echo "$#"'
run_snippet "special/dollar-zero"    'echo "$0"'
run_snippet "special/dollar-dollar"  'echo "$$" | grep -E "^[0-9]+$"'
run_snippet "special/dollar-bang"    'true & wait $!; echo $?'
run_snippet "special/dollar-q"       'echo "exit=$?"'
run_snippet "special/pipestatus"     'true | false | true; echo "${PIPESTATUS[@]}"'
run_snippet "special/lineno"         'echo "$LINENO" | grep -E "^[0-9]+$"'
run_snippet "special/funcname"       'f(){ echo "${FUNCNAME[0]}"; }; f'

# --- 16. declare / typeset ---
run_snippet "declare/integer"        'declare -i x=5+3; echo $x'
run_snippet "declare/readonly"       'declare -r x=5; echo $x'
run_snippet "declare/export"         'declare -x MYVAR=hello; echo "$MYVAR"'
run_snippet "declare/upper"          'declare -u x=hello; echo "$x"'
run_snippet "declare/lower"          'declare -l x=HELLO; echo "$x"'
run_snippet "declare/print"          'x=5; declare -p x'

# --- 17. Builtins ---
run_snippet "builtin/printf"         'printf "%s %d\n" hello 42'
run_snippet "builtin/read-var"       'echo "hello" | (read x; echo "$x")'
run_snippet "builtin/read-array"     'echo "a b c" | (read -a arr; echo "${arr[1]}")'
run_snippet "builtin/eval"           'x=hello; eval "echo \$x"'
run_snippet "builtin/source-stdin"   'source /dev/stdin <<< "echo sourced"'
run_snippet "builtin/getopts"        'f(){ while getopts "ab:" opt; do echo "$opt $OPTARG"; done; }; f -a -b val'
run_snippet "builtin/set-e"          'set -e; true; echo ok'
run_snippet "builtin/set-u"          'set -u; x=1; echo "$x"'
run_snippet "builtin/trap"           'trap "echo trapped" EXIT; true'
run_snippet "builtin/type"           'type echo | grep -q echo'
run_snippet "builtin/command"        'command -v bash > /dev/null'
run_snippet "builtin/compgen"        'foo() { :; }; compgen -A function -X "!f*" -- f'

# --- 18. Subshells and grouping ---
run_snippet "group/subshell"         '( x=inner; echo "$x" )'
run_snippet "group/brace"            '{ x=outer; echo "$x"; }'
run_snippet "group/subshell-no-leak" 'x=outer; ( x=inner ); echo "$x"'
run_snippet "group/pipeline-sub"     'x=$(echo hello | tr a-z A-Z); echo "$x"'

# --- 19. String operations / printf ---
run_snippet "string/printf-fmt"      'printf "%05d\n" 42'
run_snippet "string/printf-hex"      'printf "%x\n" 255'
run_snippet "string/printf-octal"    'printf "%o\n" 8'
run_snippet "string/printf-n"        'printf "hello"; printf " world\n"'
run_snippet "string/printf-star"     'printf "%*d\n" 5 42'

# --- 20. Edge cases shellcheck specifically tests ---
run_snippet "edge/empty-string"      '[[ "" == "" ]]'
run_snippet "edge/spaces-in-var"     'x="a b c"; [[ "$x" == "a b c" ]]'
run_snippet "edge/glob-noglob"       'set -f; x="*"; echo $x'
run_snippet "edge/word-split-ifs"    'IFS=:; x="a:b:c"; for i in $x; do echo $i; done'
run_snippet "edge/null-byte-skip"    'printf "a\0b" | cat | wc -c | grep -qE "[0-9]"'
run_snippet "edge/nested-subshell"   'echo $(( $(echo 3) + $(echo 4) ))'
run_snippet "edge/unset-array"       'a=(1 2 3); unset a; echo "${a[@]:-empty}"'
run_snippet "edge/assoc-in-subshell" 'declare -A h=([a]=1); ( echo "${h[a]}" )'
run_snippet "edge/extglob"           'shopt -s extglob; x=foobar; [[ "$x" == ?(foo)bar ]]'
run_snippet "edge/extglob-plus"      'shopt -s extglob; x=foofoofoo; [[ "$x" == +(foo) ]]'
run_snippet "edge/extglob-at"        'shopt -s extglob; x=foo; [[ "$x" == @(foo|bar) ]]'
run_snippet "edge/nocasematch"       'shopt -s nocasematch; shopt -q nocasematch'
run_snippet "edge/dotglob"           'shopt -s dotglob; a=(*); echo "${#a[@]}" | grep -qE "[0-9]"'
run_snippet "edge/nullglob"          'shopt -s nullglob; a=(/nonexistent/path*); echo "${#a[@]}"'
run_snippet "edge/globstar"          'shopt -s globstar; echo ** | wc -w | grep -qE "[0-9]"'
run_snippet "edge/coprocess"         'coproc CAT { cat; }; echo hi >&"${CAT[1]}"; read line <&"${CAT[0]}"; echo "$line"; kill "$CAT_PID" 2>/dev/null; wait "$CAT_PID" 2>/dev/null; true'

# ---------------------------------------------------------------------------
# REPORT
# ---------------------------------------------------------------------------
total=$(( pass + fail ))
echo
echo "===== shellcheck differential test results ====="
echo "  bash:   $BASH"
echo "  brash:  $BRASH"
echo
printf "  PASS %d / %d  (%d%%)\n" "$pass" "$total" "$(( total > 0 ? pass * 100 / total : 0 ))"
echo "  FAIL $fail / $total"
echo

if [[ ${#failures[@]} -gt 0 ]]; then
    echo "--- Failing snippets ---"
    for f in "${failures[@]}"; do
        echo "  $f"
    done
    echo
fi

if [[ $fail -gt 0 ]]; then
    exit 1
fi
exit 0
