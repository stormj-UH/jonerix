#!/bin/zsh

set -eu

SCRIPT_DIR=${0:A:h}
ROOT_DIR=${SCRIPT_DIR:h}
BRASH_BIN=${BRASH_BIN:-"$ROOT_DIR/target/release/brash"}
BRASH_RUNTIME_DIR=${BRASH_RUNTIME_DIR:-"$ROOT_DIR/runtime/alpine"}
HOST_BASH=${BRASH_BASH:-}
TMP_DIR=${TMPDIR:-/tmp}/brash-smoke.$$
mkdir -p "$TMP_DIR"

cleanup() {
    rm -rf "$TMP_DIR"
}

trap cleanup EXIT HUP INT TERM

if [ -z "$HOST_BASH" ] && [ -x "$BRASH_RUNTIME_DIR/bin/bash" ]; then
    HOST_BASH=$BRASH_RUNTIME_DIR/bin/bash
fi

if [ -z "$HOST_BASH" ]; then
    sh "$ROOT_DIR/scripts/install-alpine-runtime.sh"
    HOST_BASH=$BRASH_RUNTIME_DIR/bin/bash
fi

if [ -z "$HOST_BASH" ] || [ ! -x "$HOST_BASH" ]; then
    printf 'brash: smoke tests require a GNU Bash binary via BRASH_BASH or the bundled runtime\n' >&2
    exit 1
fi

if [ ! -x "$BRASH_BIN" ]; then
    cargo build --release
fi

if [ ! -x "$BRASH_BIN" ]; then
    printf 'brash: compiled launcher missing or not executable: %s\n' "$BRASH_BIN" >&2
    exit 1
fi

run_case() {
    label=$1
    stdin_file=$2
    shift 2

    expected_stdout=${TMP_DIR}/${label}.expected.out
    expected_stderr=${TMP_DIR}/${label}.expected.err
    actual_stdout=${TMP_DIR}/${label}.actual.out
    actual_stderr=${TMP_DIR}/${label}.actual.err

    set +e
    if [ -n "$stdin_file" ]; then
        "$HOST_BASH" "$@" <"$stdin_file" >"$expected_stdout" 2>"$expected_stderr"
        expected_status=$?
        BRASH_BASH="$HOST_BASH" "$BRASH_BIN" "$@" <"$stdin_file" >"$actual_stdout" 2>"$actual_stderr"
        actual_status=$?
    else
        "$HOST_BASH" "$@" >"$expected_stdout" 2>"$expected_stderr"
        expected_status=$?
        BRASH_BASH="$HOST_BASH" "$BRASH_BIN" "$@" >"$actual_stdout" 2>"$actual_stderr"
        actual_status=$?
    fi
    set -e

    if [ "$expected_status" -ne "$actual_status" ]; then
        printf 'brash: smoke failure (%s): expected exit %s, got %s\n' \
            "$label" "$expected_status" "$actual_status" >&2
        exit 1
    fi

    if ! cmp -s "$expected_stdout" "$actual_stdout"; then
        printf 'brash: smoke failure (%s): stdout mismatch\n' "$label" >&2
        diff -u "$expected_stdout" "$actual_stdout" >&2 || true
        exit 1
    fi

    if ! cmp -s "$expected_stderr" "$actual_stderr"; then
        printf 'brash: smoke failure (%s): stderr mismatch\n' "$label" >&2
        diff -u "$expected_stderr" "$actual_stderr" >&2 || true
        exit 1
    fi
}

SCRIPT_FILE=${TMP_DIR}/argv.sh
STDIN_FILE=${TMP_DIR}/stdin.sh

cat >"$SCRIPT_FILE" <<'EOF'
printf '%s\n' "$0"
printf '%s\n' "$#"
printf '%s\n' "$1"
printf '%s\n' "$2"
EOF

cat >"$STDIN_FILE" <<'EOF'
printf '%s/%s\n' "$1" "$2"
EOF

chmod 755 "$SCRIPT_FILE"

run_case version '' --version
run_case command-string '' -lc 'printf "%s\n" "$BASH_VERSION"; printf "%s\n" "$BASH_SUBSHELL"'
run_case stdin-mode "$STDIN_FILE" -s one 'two three'
run_case argv-script '' "$SCRIPT_FILE" one 'two three'

printf 'brash: smoke tests passed\n'
