#!/bin/zsh

set -eu

SCRIPT_DIR=${0:A:h}
ROOT_DIR=${SCRIPT_DIR:h}
BRASH_BIN=${BRASH_BIN:-"$ROOT_DIR/target/release/brash"}

BRASH_CACHE_DIR=${BRASH_CACHE_DIR:-"$ROOT_DIR/.cache"}
BRASH_TEST_WORKDIR=${BRASH_TEST_WORKDIR:-"$BRASH_CACHE_DIR/bash-suite"}
BASH_TEST_VERSION=${BASH_TEST_VERSION:-5.3}
BASH_SOURCE_URL=${BASH_SOURCE_URL:-"https://ftp.gnu.org/gnu/bash/bash-${BASH_TEST_VERSION}.tar.gz"}

mkdir -p "$BRASH_CACHE_DIR" "$BRASH_TEST_WORKDIR"

extract_archive() {
    archive_path=$1
    destination=$2
    toybox tar -xzf "$archive_path" -C "$destination"
}

if [ ! -x "$BRASH_BIN" ]; then
    cargo build --release
fi

if [ ! -x "$BRASH_BIN" ]; then
    printf 'brash: launcher is missing or not executable: %s\n' "$BRASH_BIN" >&2
    exit 1
fi

if [ ! -x "${BRASH_RUNTIME_DIR:-"$ROOT_DIR/runtime/alpine"}/bin/bash" ] && [ -z "${BRASH_BASH:-}" ]; then
    printf 'brash: bundled runtime missing, bootstrapping it first\n'
    sh "$ROOT_DIR/scripts/install-alpine-runtime.sh"
fi

CONFIG_SHELL=${BRASH_BASH:-"${BRASH_RUNTIME_DIR:-"$ROOT_DIR/runtime/alpine"}/bin/bash"}
PATH="${BRASH_RUNTIME_DIR:-"$ROOT_DIR/runtime/alpine"}/usr/bin:${BRASH_RUNTIME_DIR:-"$ROOT_DIR/runtime/alpine"}/bin:${PATH}"
export PATH

# Ensure /bin/sh is a Bourne-compatible shell. zsh as /bin/sh can hang on
# autoconf helper scripts (e.g. config.sub).
if [ -x "$CONFIG_SHELL" ]; then
    case "$(readlink /bin/sh 2>/dev/null)" in
        *zsh*) ln -sf "$CONFIG_SHELL" /bin/sh 2>/dev/null || true ;;
    esac
fi

# Ensure CC can link on systems without gcc runtime (e.g. clang-only Alpine)
if [ -z "${CC:-}" ]; then
    _test_c=$(mktemp /tmp/cc-test-XXXXXX.c)
    echo 'int main(){return 0;}' > "$_test_c"
    if cc --rtlib=compiler-rt -B/lib/gcc/aarch64-alpine-linux-musl/15.2.0 -o /dev/null "$_test_c" 2>/dev/null; then
        CC="cc --rtlib=compiler-rt -B/lib/gcc/aarch64-alpine-linux-musl/15.2.0"
        export CC
    fi
    rm -f "$_test_c"
fi

if command -v curl >/dev/null 2>&1; then
    fetch_cmd='curl -fsSL'
elif command -v wget >/dev/null 2>&1; then
    fetch_cmd='wget -qO-'
else
    printf 'brash: need curl or wget to download the Bash test suite\n' >&2
    exit 1
fi

SOURCE_TARBALL=${BRASH_CACHE_DIR}/bash-${BASH_TEST_VERSION}.tar.gz
SOURCE_DIR=${BRASH_TEST_WORKDIR}/bash-${BASH_TEST_VERSION}

if [ ! -f "$SOURCE_TARBALL" ]; then
    if [ "$fetch_cmd" = 'curl -fsSL' ]; then
        curl -fsSL "$BASH_SOURCE_URL" -o "$SOURCE_TARBALL"
    else
        wget -qO "$SOURCE_TARBALL" "$BASH_SOURCE_URL"
    fi
fi

rm -rf "$SOURCE_DIR"
mkdir -p "$SOURCE_DIR"
extract_archive "$SOURCE_TARBALL" "$BRASH_TEST_WORKDIR"

cd "$SOURCE_DIR"

if [ ! -f Makefile ]; then
    printf 'brash: configuring upstream Bash test tree with %s\n' "$CONFIG_SHELL"
    "$CONFIG_SHELL" ./configure
fi

# Prefer GNU make over bmake
if command -v gmake >/dev/null 2>&1; then
    MAKE=gmake
elif make --version 2>/dev/null | grep -q 'GNU Make'; then
    MAKE=make
else
    printf 'brash: GNU make is required to build the Bash test tree\n' >&2
    exit 1
fi

printf 'brash: building upstream Bash test tree\n'
"$MAKE" -j"$(getconf _NPROCESSORS_ONLN 2>/dev/null || echo 1)"
mv bash bash.upstream
ln -sf "$BRASH_BIN" bash

printf 'brash: running official Bash tests via %s\n' "$BRASH_BIN"
"$MAKE" tests THIS_SH="$PWD/bash" TEST_SHELL="$PWD/bash"
