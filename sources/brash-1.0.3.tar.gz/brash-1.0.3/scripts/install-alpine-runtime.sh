#!/bin/zsh

set -eu

SCRIPT_DIR=${0:A:h}
ROOT_DIR=${SCRIPT_DIR:h}

BRASH_RUNTIME_DIR=${BRASH_RUNTIME_DIR:-"$ROOT_DIR/runtime/alpine"}
BRASH_CACHE_DIR=${BRASH_CACHE_DIR:-"$ROOT_DIR/.cache"}
ALPINE_BRANCH=${ALPINE_BRANCH:-v3.23}
ALPINE_MIRROR=${ALPINE_MIRROR:-https://dl-cdn.alpinelinux.org/alpine}

ARCH=${ARCH:-aarch64}
case "$ARCH" in
    aarch64|arm64|aarch64-*|arm64-*)
        ARCH=aarch64
        ;;
    x86_64|amd64|x86_64-*|amd64-*)
        ARCH=x86_64
        ;;
    *)
        printf 'brash: unsupported architecture: %s\n' "$ARCH" >&2
        exit 1
        ;;
esac

REPO_URL=${ALPINE_MIRROR%/}/${ALPINE_BRANCH}/main/${ARCH}
INDEX_CACHE=${BRASH_CACHE_DIR}/APKINDEX-${ALPINE_BRANCH}-${ARCH}.tar.gz
WORK_DIR=${TMPDIR:-/tmp}/brash-apk.$$
INDEX_DIR=${WORK_DIR}/index

cleanup() {
    rm -rf "$WORK_DIR"
}

trap cleanup EXIT HUP INT TERM

mkdir -p "$BRASH_RUNTIME_DIR" "$BRASH_CACHE_DIR" "$INDEX_DIR"
printf 'brash: resolved architecture %s\n' "$ARCH"

fetch() {
    url=$1
    output=$2
    if command -v curl >/dev/null 2>&1; then
        curl -fsSL "$url" -o "$output"
        return 0
    fi
    if command -v wget >/dev/null 2>&1; then
        wget -qO "$output" "$url"
        return 0
    fi
    printf 'brash: need curl or wget to fetch %s\n' "$url" >&2
    exit 1
}

extract_archive() {
    archive_path=$1
    destination=$2
    toybox tar -xzf "$archive_path" -C "$destination"
}

write_package_manifest() {
    manifest_path=$1
    python3 - "$INDEX_DIR/APKINDEX" "$manifest_path" <<'PY'
import pathlib
import sys

index_path = pathlib.Path(sys.argv[1])
manifest_path = pathlib.Path(sys.argv[2])
required = ["ncurses-libs", "readline", "bash", "mawk", "pcre2", "grep", "diffutils", "make"]
versions = {}

for block in index_path.read_text().split("\n\n"):
    lines = block.splitlines()
    package = next((line[2:] for line in lines if line.startswith("P:")), None)
    if package not in required:
        continue
    version = next((line[2:] for line in lines if line.startswith("V:")), None)
    if version:
        versions[package] = version

missing = [name for name in required if name not in versions]
if missing:
    raise SystemExit(f"missing packages in APKINDEX: {', '.join(missing)}")

manifest_path.write_text(
    "".join(f"{name}={versions[name]}\n" for name in required)
)
PY
}

ensure_index() {
    printf 'brash: fetching Alpine index from %s\n' "$REPO_URL"
    fetch "$REPO_URL/APKINDEX.tar.gz" "$INDEX_CACHE"
    extract_archive "$INDEX_CACHE" "$INDEX_DIR"
}

extract_apk() {
    apk_path=$1
    extract_archive "$apk_path" "$BRASH_RUNTIME_DIR"
}

download_and_extract() {
    package_name=$1
    version=$2
    apk_name=${package_name}-${version}.apk
    apk_path=${BRASH_CACHE_DIR}/${apk_name}

    if [ ! -f "$apk_path" ]; then
        printf 'brash: downloading %s\n' "$apk_name" >&2
        fetch "$REPO_URL/$apk_name" "$apk_path"
    fi

    printf 'brash: extracting %s\n' "$apk_name" >&2
    extract_apk "$apk_path"
    printf '%s=%s\n' "$package_name" "$version"
}

ensure_index
MANIFEST_FILE=${WORK_DIR}/packages.txt
write_package_manifest "$MANIFEST_FILE"

INFO_FILE=${BRASH_RUNTIME_DIR}/.runtime-info
{
    printf 'repo=%s\n' "$REPO_URL"
    printf 'arch=%s\n' "$ARCH"
    while IFS='=' read -r package_name version; do
        [ -n "$package_name" ] || continue
        download_and_extract "$package_name" "$version"
    done < "$MANIFEST_FILE"
} > "$INFO_FILE"

if [ ! -x "$BRASH_RUNTIME_DIR/bin/bash" ] && [ -x "$BRASH_RUNTIME_DIR/usr/bin/bash" ]; then
    mkdir -p "$BRASH_RUNTIME_DIR/bin"
    ln -sf ../usr/bin/bash "$BRASH_RUNTIME_DIR/bin/bash"
fi

if [ ! -x "$BRASH_RUNTIME_DIR/bin/awk" ] && [ -x "$BRASH_RUNTIME_DIR/usr/bin/mawk" ]; then
    mkdir -p "$BRASH_RUNTIME_DIR/bin"
    ln -sf ../usr/bin/mawk "$BRASH_RUNTIME_DIR/bin/awk"
fi

if [ ! -x "$BRASH_RUNTIME_DIR/bin/bash" ]; then
    printf 'brash: failed to install bash runtime into %s\n' "$BRASH_RUNTIME_DIR" >&2
    exit 1
fi

printf 'brash: installed bundled runtime in %s\n' "$BRASH_RUNTIME_DIR"
