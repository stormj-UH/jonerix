#!/bin/bash

set -eu

BRASH_RUNTIME_DIR=${BRASH_RUNTIME_DIR:-/workspace/brash/runtime/alpine}
BRASH_CACHE_DIR=${BRASH_CACHE_DIR:-/workspace/brash/.cache}
BRASH_BIN=${BRASH_BIN:-/workspace/brash/target/release/brash}
BASH_TEST_VERSION=${BASH_TEST_VERSION:-5.3}
BASH_SOURCE_URL=${BASH_SOURCE_URL:-"https://ftp.gnu.org/gnu/bash/bash-${BASH_TEST_VERSION}.tar.gz"}

export LD_LIBRARY_PATH="${BRASH_RUNTIME_DIR}/lib:${BRASH_RUNTIME_DIR}/usr/lib"
export PATH="${BRASH_RUNTIME_DIR}/usr/bin:${BRASH_RUNTIME_DIR}/bin:/bin:/usr/bin:${PATH}"

CONFIG_SHELL="${BRASH_RUNTIME_DIR}/bin/bash"

# Fix /bin/sh if it points to zsh (zsh hangs on autoconf helper scripts)
case "$(readlink /bin/sh 2>/dev/null)" in
    *zsh*) ln -sf "$CONFIG_SHELL" /bin/sh ;;
esac

# Ensure CC can link (clang-only Alpine without gcc runtime)
if [ -z "${CC:-}" ]; then
    _test_c=$(mktemp /tmp/cc-test-XXXXXX.c)
    echo 'int main(){return 0;}' > "$_test_c"
    if cc --rtlib=compiler-rt -B/lib/gcc/aarch64-alpine-linux-musl/15.2.0 -o /dev/null "$_test_c" 2>/dev/null; then
        CC="cc --rtlib=compiler-rt -B/lib/gcc/aarch64-alpine-linux-musl/15.2.0"
        export CC
        echo "brash: using CC=$CC"
    fi
    rm -f "$_test_c"
fi

if [ ! -x "$BRASH_BIN" ]; then
    echo "brash: binary not found at $BRASH_BIN" >&2
    exit 1
fi

if [ ! -x "$CONFIG_SHELL" ]; then
    echo "brash: bash runtime not found at $CONFIG_SHELL" >&2
    exit 1
fi

# Prefer GNU make
if command -v gmake >/dev/null 2>&1; then
    MAKE=gmake
elif make --version 2>/dev/null | grep -q 'GNU Make'; then
    MAKE=make
else
    echo "brash: GNU make is required" >&2
    exit 1
fi

BRASH_TEST_WORKDIR="${BRASH_CACHE_DIR}/bash-suite"
SOURCE_TARBALL="${BRASH_CACHE_DIR}/bash-${BASH_TEST_VERSION}.tar.gz"
SOURCE_DIR="${BRASH_TEST_WORKDIR}/bash-${BASH_TEST_VERSION}"

mkdir -p "$BRASH_CACHE_DIR" "$BRASH_TEST_WORKDIR"

if [ ! -f "$SOURCE_TARBALL" ]; then
    echo "brash: downloading Bash ${BASH_TEST_VERSION} source"
    curl -fsSL "$BASH_SOURCE_URL" -o "$SOURCE_TARBALL"
fi

rm -rf "$SOURCE_DIR"
mkdir -p "$SOURCE_DIR"
toybox tar -xzf "$SOURCE_TARBALL" -C "$BRASH_TEST_WORKDIR"
echo "brash: extracted bash source"

cd "$SOURCE_DIR"

echo "brash: configuring with $CONFIG_SHELL"
"$CONFIG_SHELL" ./configure
echo "brash: configure done"

echo "brash: building"
"$MAKE" -j"$(getconf _NPROCESSORS_ONLN 2>/dev/null || echo 1)"
echo "brash: build done"

mv bash bash.upstream
ln -sf "$BRASH_BIN" bash

echo "brash: running official Bash tests via $BRASH_BIN"
"$MAKE" tests THIS_SH="$PWD/bash" TEST_SHELL="$PWD/bash"
