# brash design rules

This document captures the non-negotiable engineering rules for `brash`. They exist because they have already been violated at least once and the violation cost us either a regression or a portability break.

## §1 Prime Directive — clean room

`brash` is a clean-room Rust reimplementation of GNU Bash 5.3. **No GNU Bash C source code may be referenced at any point.** Permitted references are:

- the Bash 5.3 manual and `bash(1)` man page
- the POSIX shell specification (IEEE Std 1003.1)
- behavioural black-box testing against the GNU Bash binary (the differential corpora under `tests/`)

Anyone who has read Bash source code in the last 24 months should not write code in this repo. Reviewers should treat any commit that quotes Bash source as an automatic block.

## §2 Zero Warnings — `cargo build --release` is silent

**Every commit on `main` must produce zero warnings on `cargo build --release` for the default targets** (host macOS, x86_64-unknown-linux-musl, aarch64-unknown-linux-musl, x86_64-unknown-linux-gnu, aarch64-unknown-linux-gnu).

The build output should be:

```
   Compiling brash vX.Y.Z (…)
    Finished `release` profile [optimized] target(s) in N.NNs
```

— and nothing else.  No `warning:` lines, including:

- `unused_imports`, `unused_variables`, `unused_assignments`, `unused_labels`
- `dead_code` in any of its forms (functions, fields, variants, methods, constants)
- `unreachable_patterns`
- `deprecated` (third-party API or otherwise)
- `non_snake_case`, `non_camel_case_types`
- any future lint that becomes warn-by-default in a stable Rust release

### Why this rule

Warnings *are* signal — every warning that gets ignored hides a real one underneath it.  The previous v0.x build emitted 39 warnings and one of them was the `bracket_ops` dead store that had been quietly broken since the `[[ ]]` path was refactored.  Another was the deprecated `libc::iconv` block that needs an actual fix before libc 1.0 lands.  Once the noise floor was nonzero we stopped reading any of it; a clean build forces every new warning to be addressed at the moment it is introduced.

### How to comply

1. **Fix the underlying issue if it is one.** Unused imports, dead labels, dead local variables, `drop(&mut T)` no-ops — these are bugs, not stylistic concerns. Delete or repair the code. Never silence them with an attribute.
2. **Suppress with the narrowest possible `#[allow(...)]` if the warning is genuinely unavoidable.** Acceptable reasons include: deprecated upstream API we still need until a migration lands; an unreachable match arm we keep for forward-compatibility with a feature-gated enum variant; a public API surface kept for external callers when no in-tree caller exists yet.
3. **Every `#[allow(...)]` must carry a comment** explaining what the warning was, why suppression is preferred over a fix, and what would let us remove the suppression later.
4. **Module-level `#![allow(dead_code)]` is allowed only for genuinely library-style modules** with many `pub fn` items as a deliberate API surface (today: `src/expand.rs`).  Such files must contain a doc comment explaining the rationale.  **Crate-level `#![allow(...)]` is forbidden.**

### Checking before pushing

```sh
cargo build --release 2>&1 | grep -c '^warning:'
# expected output: 0
```

If a commit fails this check, the commit is incomplete.  Either fix the warning or annotate it with `#[allow(...)]` + a comment, and amend the commit.

## §3 Tests are the source of truth — corpora over unit tests

`brash`'s compatibility target is empirical, not theoretical.  The authoritative test set is:

```sh
bash tests/all-corpora.sh
```

— 17 differential suites covering the upstream Bash 5.3 test corpus, dash POSIX, busybox, mksh, shellcheck, shfmt, real-world scripts (Homebrew, pyenv, autotools-generated `--help` output, init.d scripts, NixOS hooks, docker-entrypoint, GitHub Actions, bash-completion, fuzzed scripts).

`cargo test` may report a small set of legacy unit-test failures whose fixtures have drifted out of sync with the executor.  These do **not** gate releases — the integration corpora do.  When a unit test conflicts with a corpus, the corpus wins.

A regression in any corpus blocks merge.  A failure in `cargo test` that is not also a failure in any corpus is by definition a stale fixture.

## §4 Portable libc usage

`brash` runs on macOS, Linux/glibc, Linux/musl, and *BSD.  `libc-rs` exposes platform-specific differences in two notable places we have already tripped over:

- **rlimit constants and `getrlimit`/`setrlimit`** are typed `u32` (`__rlimit_resource_t`) on glibc Linux and `c_int` (i32) elsewhere.  `src/builtins.rs` introduces a local `RlimitResource` type alias gated on `(target_os = "linux", target_env = "gnu")`.  Any new code that touches rlimit must use this alias.
- **WaitStatus** has additional ptrace-only variants (`PtraceEvent`, `PtraceSyscall`) when nix's `ptrace` feature is on.  We don't enable that feature, so the trailing `Ok(_) => {}` arm is unreachable on every supported target.  Keep it defensively, with `#[allow(unreachable_patterns)]` per match.

When in doubt about a libc symbol's portability, check the `libc-rs` source for `cfg(target_os = …)` or `cfg(target_env = …)` blocks before committing.

## §5 Performance discipline

`brash` ships at v1.0.0 with **7/13** hot-path benchmarks beating bash on `ITER=10` median wall-clock (`tests/bench/run.sh`).  Any commit that drops the brash-wins count below 7 requires either:

- a bench number in the commit message demonstrating that the regression is acceptable (e.g. correctness fix that costs 5% on one bench but unblocks 6 corpora), or
- an explicit roll-back plan in the commit message.

The `0.x → 1.0.0` perf landing was the cherry-pick of the `sonnet-perf4` branch (ahash for hot maps, exec-in-place pipeline forks, `Rc<FuncDef>`, FUNCNAME/BASH_SOURCE lazy sync, Cow<str> in run_string).  The `sonnet-perf5` branch was rejected at the same time because, although it scored 10/13 wins, it broke 17 bash-suite tests via an over-aggressive light-sync path.  This is the canonical cautionary tale for §3 — perf wins that break corpora are not wins.

## §6 Process — committing and releasing

- **No `Co-Authored-By` trailers from real humans.**  AI-coauthor trailers (`Claude Opus`, `Claude Sonnet`) are fine and expected.
- **Commits are not signed.**  This is intentional and matches the surrounding monorepo policy.
- **Release tags follow `vX.Y.Z` semver.**  Major bumps require a working group of corpora results and bench numbers in the commit body; minor bumps require corpora green; patch bumps require the changed-area's tests green.
- **Source tarballs for jpkg.**  Each release tag also gets a `git archive --format=tar.gz --prefix=brash-X.Y.Z/ vX.Y.Z` uploaded to GitHub `stormj-UH/jonerix` releases under tag `source-brash-vX.Y.Z`.  The jpkg recipe at `jonerix/packages/core/brash/recipe.toml` references that GitHub URL with the tarball's sha256.
