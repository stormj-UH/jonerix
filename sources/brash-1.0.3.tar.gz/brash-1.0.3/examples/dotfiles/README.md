# brash dotfiles

Drop-in `~/.brashrc` and `~/.brash_profile` matching the macOS zsh default
prompt, suitable for logging into a brash interactive shell on Linux/macOS.

## Files

- `brashrc` — interactive-shell init (prompt, aliases, history, options).
  Copy to `~/.brashrc`.
- `brash_profile` — login-shell init.  Sources `.brashrc`, sets PATH.
  Copy to `~/.brash_profile`.

## Prompt

The PS1 in `brashrc` is `\u@\h \W % ` which renders as:

```
jonerik@<host> <last-cwd-component> %
```

Examples:
- in `$HOME`           → `jonerik@pi5 ~ %`
- in `/tmp`            → `jonerik@pi5 tmp %`
- in `~/Desktop/brash` → `jonerik@pi5 brash %`

This is byte-equivalent to the macOS default zsh prompt
`%n@%m %1~ %# ` (with literal `%` for non-root instead of `$`).

## Install on a fresh machine

```sh
# After cloning + building brash:
git clone <brash-repo> && cd brash
cargo build --release
sudo install -m 755 target/release/brash /usr/local/bin/brash

# Drop the dotfiles
cp examples/dotfiles/brashrc        ~/.brashrc
cp examples/dotfiles/brash_profile  ~/.brash_profile

# Try it interactively
brash -i

# To make it the login shell:
sudo grep -qxF /usr/local/bin/brash /etc/shells \
    || echo /usr/local/bin/brash | sudo tee -a /etc/shells
chsh -s /usr/local/bin/brash
```

## Customising

The `brashrc` aliases ls/grep with `--color=auto` if GNU coreutils are
present (Linux), else `-G` (BSD on macOS).  Edit to taste — the PS1 line
is the first non-comment.
