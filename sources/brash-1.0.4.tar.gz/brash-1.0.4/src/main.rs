mod lexer;
mod parser;
mod expand;
mod exec;
mod builtins;
mod vars;
mod trap;
mod arithmetic;
mod history;

use std::env;
use std::fs;
use std::io::{self, Read, Write};
use std::os::unix::ffi::OsStrExt;
use std::process;
use std::sync::atomic::{AtomicI32, Ordering};

fn is_test_mode() -> bool {
    std::env::var("BRASH_TEST_MODE").map(|v| !v.is_empty()).unwrap_or(false)
}

fn version_string() -> String {
    if is_test_mode() {
        format!(
            "GNU bash, version 5.3.0(1)-release ({}-unknown-linux-musl)",
            std::env::consts::ARCH
        )
    } else {
        format!("brash, version {}", env!("CARGO_PKG_VERSION"))
    }
}

/// Print the usage+options block bash emits after an invalid
/// invocation flag (bash source: `usage.c`).
fn print_invocation_usage() {
    let name = exec::shell_name();
    eprintln!("{} [GNU long option] [option] ...", name);
    eprintln!("{} [GNU long option] [option] script-file ...", name);
    eprintln!("GNU long options:");
    for lo in &[
        "--debug", "--debugger", "--dump-po-strings", "--dump-strings",
        "--help", "--init-file", "--login", "--noediting", "--noprofile",
        "--norc", "--posix", "--pretty-print", "--rcfile",
        "--restricted", "--verbose", "--version",
    ] {
        eprintln!("\t{}", lo);
    }
    eprintln!("Shell options:");
    eprintln!("\t-ilrsD or -c command or -O shopt_option\t\t(invocation only)");
    eprintln!("\t-abefhkmnptuvxBCEHPT or -o option");
}

fn argv_string(arg: &std::ffi::OsStr) -> String {
    expand::encode_raw_bytes(arg.as_bytes())
}

static EDITOR_SIGNAL: AtomicI32 = AtomicI32::new(0);

extern "C" fn editor_signal_handler(sig: libc::c_int) {
    EDITOR_SIGNAL.store(sig, Ordering::Relaxed);
    if sig >= 0 && (sig as usize) < exec::SIG_MAX {
        exec::PENDING_SIGNALS[sig as usize].fetch_add(1, Ordering::Relaxed);
    }
}

struct TtyEditorGuard {
    fd: i32,
    old_termios: libc::termios,
    old_sigint: libc::sigaction,
    old_sigquit: libc::sigaction,
}

impl TtyEditorGuard {
    fn install(fd: i32) -> io::Result<Self> {
        unsafe {
            let mut old_termios: libc::termios = std::mem::zeroed();
            if libc::tcgetattr(fd, &mut old_termios) != 0 {
                return Err(io::Error::last_os_error());
            }
            let mut raw = old_termios;
            raw.c_lflag &= !(libc::ICANON | libc::ECHO);
            raw.c_cc[libc::VMIN] = 1;
            raw.c_cc[libc::VTIME] = 0;
            if libc::tcsetattr(fd, libc::TCSAFLUSH, &raw) != 0 {
                return Err(io::Error::last_os_error());
            }

            let mut new_sa: libc::sigaction = std::mem::zeroed();
            let mut old_sigint: libc::sigaction = std::mem::zeroed();
            let mut old_sigquit: libc::sigaction = std::mem::zeroed();
            new_sa.sa_sigaction = editor_signal_handler as usize;
            libc::sigemptyset(&mut new_sa.sa_mask);
            new_sa.sa_flags = 0;
            if libc::sigaction(libc::SIGINT, &new_sa, &mut old_sigint) != 0 {
                let _ = libc::tcsetattr(fd, libc::TCSAFLUSH, &old_termios);
                return Err(io::Error::last_os_error());
            }
            if libc::sigaction(libc::SIGQUIT, &new_sa, &mut old_sigquit) != 0 {
                let _ = libc::sigaction(libc::SIGINT, &old_sigint, std::ptr::null_mut());
                let _ = libc::tcsetattr(fd, libc::TCSAFLUSH, &old_termios);
                return Err(io::Error::last_os_error());
            }

            Ok(Self {
                fd,
                old_termios,
                old_sigint,
                old_sigquit,
            })
        }
    }
}

impl Drop for TtyEditorGuard {
    fn drop(&mut self) {
        unsafe {
            let _ = libc::tcsetattr(self.fd, libc::TCSAFLUSH, &self.old_termios);
            let _ = libc::sigaction(libc::SIGINT, &self.old_sigint, std::ptr::null_mut());
            let _ = libc::sigaction(libc::SIGQUIT, &self.old_sigquit, std::ptr::null_mut());
        }
    }
}

#[derive(Copy, Clone, Debug)]
enum EditorKey {
    Up,
    Down,
    Left,
    Right,
    Home,
    End,
    Delete,
}

fn read_stdin_byte() -> io::Result<Option<u8>> {
    let mut byte = [0u8; 1];
    let n = unsafe { libc::read(libc::STDIN_FILENO, byte.as_mut_ptr() as *mut libc::c_void, 1) };
    if n == 0 {
        Ok(None)
    } else if n < 0 {
        Err(io::Error::last_os_error())
    } else {
        Ok(Some(byte[0]))
    }
}

fn read_stdin_byte_timeout(timeout_ms: i32) -> io::Result<Option<u8>> {
    let mut pfd = libc::pollfd {
        fd: libc::STDIN_FILENO,
        events: libc::POLLIN,
        revents: 0,
    };
    let rc = unsafe { libc::poll(&mut pfd, 1, timeout_ms) };
    if rc < 0 {
        return Err(io::Error::last_os_error());
    }
    if rc == 0 || (pfd.revents & libc::POLLIN) == 0 {
        return Ok(None);
    }
    read_stdin_byte()
}

fn read_escape_key() -> io::Result<Option<EditorKey>> {
    let Some(second) = read_stdin_byte_timeout(25)? else {
        return Ok(None);
    };
    match second {
        b'[' => {
            let mut seq = Vec::new();
            while let Some(b) = read_stdin_byte_timeout(25)? {
                seq.push(b);
                if matches!(b, b'A'..=b'Z' | b'a'..=b'z' | b'~') {
                    break;
                }
            }
            let Some(final_byte) = seq.last().copied() else {
                return Ok(None);
            };
            match final_byte {
                b'A' => Ok(Some(EditorKey::Up)),
                b'B' => Ok(Some(EditorKey::Down)),
                b'C' => Ok(Some(EditorKey::Right)),
                b'D' => Ok(Some(EditorKey::Left)),
                b'H' => Ok(Some(EditorKey::Home)),
                b'F' => Ok(Some(EditorKey::End)),
                b'~' => {
                    let code = String::from_utf8_lossy(&seq[..seq.len().saturating_sub(1)]);
                    match code.as_ref() {
                        "1" | "7" => Ok(Some(EditorKey::Home)),
                        "3" => Ok(Some(EditorKey::Delete)),
                        "4" | "8" => Ok(Some(EditorKey::End)),
                        _ => Ok(None),
                    }
                }
                _ => Ok(None),
            }
        }
        b'O' => match read_stdin_byte_timeout(25)? {
            Some(b'H') => Ok(Some(EditorKey::Home)),
            Some(b'F') => Ok(Some(EditorKey::End)),
            _ => Ok(None),
        },
        _ => Ok(None),
    }
}

fn decode_editor_input(first: u8) -> io::Result<Vec<char>> {
    let needed = match first {
        0x00..=0x7f => 1,
        0xc0..=0xdf => 2,
        0xe0..=0xef => 3,
        0xf0..=0xf7 => 4,
        _ => 1,
    };
    let mut bytes = vec![first];
    while bytes.len() < needed {
        match read_stdin_byte()? {
            Some(byte) => bytes.push(byte),
            None => break,
        }
    }
    Ok(String::from_utf8_lossy(&bytes).chars().collect())
}

fn redraw_editor_line<W: Write>(
    out: &mut W,
    prompt: &str,
    current: &[char],
    cursor: usize,
) -> io::Result<()> {
    let line: String = current.iter().collect();
    let prefix: String = current.iter().take(cursor).collect();
    write!(out, "\r{}{}\x1b[K\r{}{}", prompt, line, prompt, prefix)?;
    out.flush()
}

fn main() {
    let mut shell = exec::Shell::new();
    let args: Vec<String> = env::args_os()
        .map(|arg| argv_string(arg.as_os_str()))
        .collect();
    // In BRASH_TEST_MODE, keep the real argv[0] for shell variables like $0,
    // but still use the test-mode shell_name() for user-facing banners.
    let raw_argv0 = args.first().map(|s| s.as_str()).unwrap_or("brash");
    let argv0: &str = if is_test_mode() {
        exec::shell_name()
    } else {
        raw_argv0
    };

    // When invoked as "sh" (basename of argv[0] is "sh"), bash automatically
    // enables POSIX mode.  Mirror that behaviour here.
    {
        let base = std::path::Path::new(raw_argv0.trim_start_matches('-'))
            .file_name()
            .and_then(|s| s.to_str())
            .unwrap_or(raw_argv0);
        if base == "sh" {
            shell.posix_mode = true;
            shell.vars.posix_mode = true;
        }
    }

    init_shell_vars(&mut shell, raw_argv0);

    // Inherit environment
    for (k, v) in env::vars() {
        if exec::is_valid_identifier_pub(&k) {
            shell.export_var(&k, &v);
        } else {
            shell.inherited_env.insert(k, v);
        }
    }

    // Import exported functions from BASH_FUNC_name%% environment variables.
    // These are set by `export -f` in a parent shell.
    // Security: only import if the value starts with "() " (valid function body).
    // Strip any code that follows the closing `}` of the function (CVE-2014-6271).
    import_bash_funcs(&mut shell);

    if args.len() > 1 && (args[1] == "--version" || args[1] == "-version") {
        println!("{}", version_string());
        if is_test_mode() {
            println!("Copyright (C) 2025 Free Software Foundation, Inc.");
            println!("License GPLv3+: GNU GPL version 3 or later <http://gnu.org/licenses/gpl.html>");
            println!();
            println!("This is free software; you are free to change and redistribute it.");
            println!("There is NO WARRANTY, to the extent permitted by law.");
        }
        process::exit(0);
    }

    if args.len() > 1 && (args[1] == "--help" || args[1] == "-help") {
        eprintln!("{}", version_string());
        eprintln!("Usage:\t{} [GNU long option] [option] ...", argv0);
        eprintln!("\t{} [GNU long option] [option] script-file ...", argv0);
        process::exit(0);
    }

    let mut idx = 1;
    let mut is_login = raw_argv0.starts_with('-');
    shell.is_login_shell = is_login;
    let mut is_command = false;
    let mut command_string: Option<String> = None;
    let mut stdin_mode = false;
    let mut script_file: Option<String> = None;
    let bash_compat_startup = uses_bash_startup_files(raw_argv0);

    while idx < args.len() {
        match args[idx].as_str() {
            "-l" | "--login" => { is_login = true; shell.is_login_shell = true; }
            "-c" => {
                is_command = true;
                idx += 1;
                if idx >= args.len() {
                    // bash: "bash: -c: option requires an argument"
                    // (just the error line, no usage block)
                    eprintln!("{}: -c: option requires an argument", exec::shell_name());
                    process::exit(2);
                }
                command_string = Some(args[idx].clone());
                idx += 1;
                if idx < args.len() {
                    shell.set_var("0", &args[idx]);
                    // ARG0 explicitly given after the -c command:
                    // bash uses it as the error-message prefix instead
                    // of the literal "-c".
                    shell.script_name = args[idx].clone();
                    idx += 1;
                } else if let Ok(argv0) = std::env::var("BASH_ARGV0") {
                    // BASH_ARGV0 in the env overrides the default $0 for
                    // -c invocations.
                    if !argv0.is_empty() {
                        shell.set_var("0", &argv0);
                        shell.script_name = argv0;
                    }
                }
                // Otherwise the global default at the bottom of init
                // (argv[0] basename, with BRASH_TEST_MODE substitution)
                // applies.
                let mut pos = 1;
                while idx < args.len() {
                    shell.set_var(&format!("{}", pos), &args[idx]);
                    pos += 1;
                    idx += 1;
                }
                shell.vars.positional_count = pos - 1;
                break;
            }
            "-s" => {
                stdin_mode = true;
                idx += 1;
                let mut pos = 1;
                while idx < args.len() {
                    shell.set_var(&format!("{}", pos), &args[idx]);
                    pos += 1;
                    idx += 1;
                }
                shell.vars.positional_count = pos - 1;
                break;
            }
            "-i" => { shell.interactive = true; }
            "--norc" => { shell.norc = true; }
            "--noprofile" => { shell.noprofile = true; }
            "--posix" => {
                shell.posix_mode = true;
                // In POSIX mode, aliases are always expanded (not dependent on
                // interactive shell state). This matches bash's behavior.
                shell.shopt.insert("expand_aliases".to_string());
            }
            // Known long options brash doesn't fully implement but
            // should pass the invocation suite by being recognized
            // (bash accepts them).
            "--debug" | "--debugger"
            | "--dump-po-strings" | "--dump-strings"
            | "--noediting" | "--verbose" | "--restricted" => {
                // Silently accept; no-op for now.
            }
            "--pretty-print" => {
                shell.pretty_print_mode = true;
            }
            "--init-file" | "--rcfile" => {
                // Takes an arg — skip it
                idx += 1;
            }
            "-o" => {
                // -o optname: set shell option
                idx += 1;
                if idx < args.len() {
                    let opt = &args[idx];
                    match opt.as_str() {
                        "posix" => {
                            shell.posix_mode = true;
                            shell.shopt.insert("expand_aliases".to_string());
                        }
                        _ => shell.set_option(opt),
                    }
                }
            }
            "+o" => {
                // +o optname: disable shell option.
                idx += 1;
                if idx < args.len() {
                    let opt = &args[idx];
                    match opt.as_str() {
                        "posix" => {
                            shell.posix_mode = false;
                            shell.shopt.remove("expand_aliases");
                        }
                        _ => shell.unset_option(opt),
                    }
                }
            }
            "-O" => {
                // -O optname: enable shopt option at startup.
                idx += 1;
                if idx < args.len() {
                    let opt = &args[idx];
                    if builtins::SHOPT_OPTIONS.contains(&opt.as_str()) {
                        shell.shopt.insert(opt.clone());
                    } else {
                        eprintln!("{}: line 0: {}: invalid shell option name",
                            exec::shell_name(), opt);
                        process::exit(2);
                    }
                }
            }
            "+O" => {
                // +O optname: disable shopt option at startup.
                idx += 1;
                if idx < args.len() {
                    let opt = &args[idx];
                    if builtins::SHOPT_OPTIONS.contains(&opt.as_str()) {
                        shell.shopt.remove(opt.as_str());
                    } else {
                        eprintln!("{}: line 0: {}: invalid shell option name",
                            exec::shell_name(), opt);
                        process::exit(2);
                    }
                }
            }
            "--" => { break; }
            s if s.starts_with("--") => {
                // Unknown long option — reject like bash.  Known ones
                // are handled above (--norc, --noprofile, --posix).
                eprintln!("{}: {}: invalid option", exec::shell_name(), s);
                print_invocation_usage();
                process::exit(2);
            }
            s if s.starts_with('-') || s.starts_with('+') => {
                let prefix = if s.starts_with('-') { "-" } else { "+" };
                let chars: Vec<char> = s[1..].chars().collect();
                let mut has_c = false;
                for &ch in &chars {
                    if ch == 'c' && prefix == "-" {
                        has_c = true;
                        continue;
                    }
                    // Validate — bash's short-flag alphabet is:
                    // abefhikmnoprstuvxBCEHPT for -/+ forms, plus D, O.
                    // Anything else is "invalid option".
                    if !matches!(ch,
                        'a' | 'b' | 'e' | 'f' | 'h' | 'i' | 'k' | 'l' | 'm'
                      | 'n' | 'o' | 'p' | 'r' | 's' | 't' | 'u' | 'v' | 'x'
                      | 'B' | 'C' | 'D' | 'E' | 'H' | 'O' | 'P' | 'T')
                    {
                        eprintln!("{}: -{}: invalid option",
                            exec::shell_name(), ch);
                        print_invocation_usage();
                        process::exit(2);
                    }
                    let flag = format!("{}{}", prefix, ch);
                    if prefix == "-" {
                        if ch == 'i' {
                            shell.interactive = true;
                        } else if ch == 'l' {
                            is_login = true;
                            shell.is_login_shell = true;
                        }
                        shell.set_option(&flag);
                    } else {
                        shell.unset_option(&flag);
                    }
                }
                if has_c {
                    // Handle -c combined with other flags (e.g., -ce, -xc)
                    is_command = true;
                    idx += 1;
                    if idx < args.len() {
                        command_string = Some(args[idx].clone());
                        idx += 1;
                        if idx < args.len() {
                            shell.set_var("0", &args[idx]);
                            shell.script_name = args[idx].clone();
                            idx += 1;
                        }
                        let mut pos = 1;
                        while idx < args.len() {
                            shell.set_var(&format!("{}", pos), &args[idx]);
                            pos += 1;
                            idx += 1;
                        }
                        shell.vars.positional_count = pos - 1;
                    }
                    break;
                }
            }
            _ => {
                script_file = Some(args[idx].clone());
                shell.script_name = args[idx].clone();
                shell.set_var("0", &args[idx]);
                idx += 1;
                let mut pos = 1;
                while idx < args.len() {
                    shell.set_var(&format!("{}", pos), &args[idx]);
                    pos += 1;
                    idx += 1;
                }
                shell.vars.positional_count = pos - 1;
                break;
            }
        }
        idx += 1;
    }

    // Apply BASHOPTS/SHELLOPTS after command-line flags so an
    // exported SHELLOPTS re-enables options that `+B` / `+o ...`
    // turned off, matching bash.
    inherit_shellopts_env(&mut shell);

    let stdin_is_tty = atty_stdin();
    let interactive_startup = !is_command && script_file.is_none() && !stdin_mode
        && (shell.interactive || stdin_is_tty);
    if interactive_startup {
        prepare_interactive_shell(&mut shell);
    }

    // Source startup files
    if !shell.norc && !is_command && script_file.is_none() && !stdin_mode {
        if is_login && !shell.noprofile {
            // Login shell: source /etc/profile, then profile files
            for f in &["/etc/profile"] {
                source_startup_file(&mut shell, f, !bash_compat_startup);
            }
            let home = env::var("HOME").unwrap_or_default();
            // Try brash-specific profile first, then bash-compatible ones
            let brash_profile = format!("{}/.brash_profile", home);
            if !source_startup_file(&mut shell, &brash_profile, false) {
                if bash_compat_startup {
                    for f in &[
                        format!("{}/.bash_profile", home),
                        format!("{}/.bash_login", home),
                        format!("{}/.profile", home),
                    ] {
                        if source_startup_file(&mut shell, f, false) {
                            break; // only source the first one found
                        }
                    }
                } else {
                    source_startup_file(&mut shell, &format!("{}/.profile", home), true);
                }
            }
        } else if interactive_startup {
            // Interactive non-login: source rc files
            let home = env::var("HOME").unwrap_or_default();
            // Try brash-specific rc first, then bash-compatible
            let brashrc = format!("{}/.brashrc", home);
            let bashrc = format!("{}/.bashrc", home);
            if !source_startup_file(&mut shell, &brashrc, false) && bash_compat_startup {
                source_startup_file(&mut shell, &bashrc, false);
            }
        }
    }

    if is_command {
        if let Some(cmd) = command_string {
            shell.c_mode = true;
            shell.c_string = Some(cmd.clone());
            shell.run_string(&cmd);
            let status = shell.run_exit_trap();
            if is_login {
                run_bash_logout(&mut shell, bash_compat_startup);
            }
            process::exit(status);
        }
        process::exit(0);
    }

    if let Some(mut path) = script_file {
        // Bash: when the script filename contains no `/`, it's looked
        // up via PATH the same as a command name.  This lets things
        // like `bash ls` → `bash /bin/ls` (which then fails with
        // "cannot execute binary file" for binaries in PATH).
        if !path.contains('/') && !std::path::Path::new(&path).exists() {
            let search = env::var("PATH").unwrap_or_default();
            for dir in search.split(':') {
                if dir.is_empty() { continue; }
                let candidate = format!("{}/{}", dir, path);
                if std::path::Path::new(&candidate).exists() {
                    path = candidate;
                    break;
                }
            }
        }
        match fs::read_to_string(&path) {
            Ok(content) => {
                shell.run_string(&content);
                let status = shell.run_exit_trap();
                process::exit(status);
            }
            Err(e) => {
                // If `read_to_string` failed due to non-UTF-8
                // content, fall back to reading as bytes.  If the
                // raw bytes look binary (NUL in first 512 bytes or
                // ELF/Mach-O magic), match bash's \"cannot execute
                // binary file\" diagnostic and exit 126.
                if matches!(e.kind(), std::io::ErrorKind::InvalidData) {
                    if let Ok(bytes) = fs::read(&path) {
                        let probe_len = bytes.len().min(512);
                        let looks_binary = bytes[..probe_len].contains(&0u8)
                            || bytes.starts_with(b"\x7fELF")
                            || bytes.starts_with(&[0xcf, 0xfa, 0xed, 0xfe])
                            || bytes.starts_with(&[0xfe, 0xed, 0xfa, 0xcf])
                            || bytes.starts_with(&[0xfe, 0xed, 0xfa, 0xce])
                            || bytes.starts_with(&[0xce, 0xfa, 0xed, 0xfe]);
                        if looks_binary {
                            eprintln!("{}: {}: cannot execute binary file", path, path);
                            process::exit(126);
                        }
                        // Not binary — interpret as bytes via
                        // from_utf8_lossy so stray bytes get replaced
                        // but the script still runs.
                        let s = String::from_utf8_lossy(&bytes);
                        shell.run_string(&s);
                        let status = shell.run_exit_trap();
                        process::exit(status);
                    }
                }
                // Bash emits "<argv0>: <path>: <msg>" where <msg>
                // is the short error string (no "(os error N)"
                // suffix).  Convert from std::io::Error wording.
                let msg = match e.raw_os_error() {
                    Some(libc::EISDIR) => "Is a directory".to_string(),
                    Some(libc::ENOENT) => "No such file or directory".to_string(),
                    Some(libc::EACCES) => "Permission denied".to_string(),
                    Some(libc::EIO) => "Input/output error".to_string(),
                    _ => e.kind().to_string(),
                };
                // Bash uses the script PATH as the program name in
                // script-load errors (because $0 is set to the path).
                eprintln!("{}: {}: {}", path, path, msg);
                process::exit(1);
            }
        }
    }

    if stdin_mode || (!shell.interactive && !stdin_is_tty) {
        // Stream stdin line-by-line using unbuffered FD reads so that child
        // processes spawned by the script can consume their own stdin bytes
        // (matches bash behavior for `bash < script`, `sh ./run-input-test`).
        // Accumulate lines until the partial buffer looks like a complete
        // statement; tokenize/execute, then continue.
        let mut buf = String::new();
        loop {
            let mut byte = [0u8; 1];
            let n = unsafe { libc::read(0, byte.as_mut_ptr() as *mut libc::c_void, 1) };
            if n <= 0 {
                // EOF or error: run any remaining buffered text
                if !buf.is_empty() { shell.run_string(&buf); buf.clear(); }
                break;
            }
            buf.push(byte[0] as char);
            if byte[0] == b'\n' {
                if stdin_buffer_is_complete(&buf) {
                    shell.run_string(&buf);
                    buf.clear();
                }
            }
        }
        let status = shell.run_exit_trap();
        process::exit(status);
    }

    // Interactive
    prepare_interactive_shell(&mut shell);
    if let Some(sz) = shell.get_var("HISTSIZE") {
        if let Ok(n) = sz.parse::<usize>() {
            shell.history.max_size = n;
        }
    }
    let startup_histfile = shell.get_var("HISTFILE").filter(|s| !s.is_empty());
    if let Some(path) = startup_histfile.as_deref() {
        shell.remember_history_file(path);
        let _ = shell.history.read_from_file_with_options(path, history_file_options(&shell));
    }
    if !atty_stdin() {
        let stdin = io::stdin();
        let mut stdin = stdin.lock();
        let mut stderr = io::stderr();
        let mut pending = String::new();
        let mut current = String::new();
        let mut nav = InteractiveHistoryState::default();
        let mut queued: Option<u8> = None;
        let mut prompt_shown = false;
        loop {
            if shell.exit_flag || shell.return_flag {
                break;
            }
            if !prompt_shown {
                let prompt_raw = if pending.is_empty() {
                    shell.get_var("PS1").unwrap_or_else(|| "\\$ ".to_string())
                } else {
                    shell.get_var("PS2").unwrap_or_else(|| "> ".to_string())
                };
                let _ = write!(stderr, "{}", shell.expand_prompt(&prompt_raw));
                let _ = stderr.flush();
                prompt_shown = true;
            }
            let byte = if let Some(b) = queued.take() {
                b
            } else {
                let mut buf = [0u8; 1];
                match stdin.read(&mut buf) {
                    Ok(0) | Err(_) => {
                        if !current.is_empty() || !pending.is_empty() {
                            submit_interactive_line(&mut shell, &mut pending, &mut current);
                        }
                        let _ = writeln!(stderr, "exit");
                        break;
                    }
                    Ok(_) => buf[0],
                }
            };
            match byte {
                b'\n' => {
                    let _ = writeln!(stderr);
                    submit_interactive_line(&mut shell, &mut pending, &mut current);
                    nav.clear();
                    prompt_shown = false;
                }
                0x10 => {
                    if let Some(entry) = nav.previous(&shell, &current) {
                        current = entry;
                    }
                }
                0x0e => {
                    if let Some(entry) = nav.next(&shell, &current) {
                        current = entry;
                    }
                }
                0x12 => {
                    let mut needle = String::new();
                    loop {
                        let mut buf = [0u8; 1];
                        match stdin.read(&mut buf) {
                            Ok(0) | Err(_) => break,
                            Ok(_) if buf[0] < 0x20 || buf[0] == 0x7f => {
                                queued = Some(buf[0]);
                                break;
                            }
                            Ok(_) => needle.push(buf[0] as char),
                        }
                    }
                    if let Some(entry) = nav.search(&shell, &needle) {
                        current = entry;
                    }
                }
                0x0f => {
                    if !current.is_empty() || !pending.is_empty() {
                        submit_interactive_line(&mut shell, &mut pending, &mut current);
                    }
                    current = nav.next_after_operate().unwrap_or_default();
                }
                b'\r' => {}
                byte => {
                    nav.clear();
                    current.push(byte as char);
                    let _ = write!(stderr, "{}", byte as char);
                    let _ = stderr.flush();
                }
            }
        }
        save_history_file(&mut shell);
        let status = shell.run_exit_trap();
        process::exit(status);
    }
    let stdin = io::stdin();
    let mut stdout = io::stdout();
    if let Ok(_tty_guard) = TtyEditorGuard::install(libc::STDIN_FILENO) {
        let mut pending = String::new();
        let mut current: Vec<char> = Vec::new();
        let mut cursor = 0usize;
        let mut nav = InteractiveHistoryState::default();
        let mut prompt_shown = false;
        let mut prompt = String::new();
        loop {
            if shell.exit_flag || shell.return_flag {
                break;
            }

            if !prompt_shown {
                if pending.is_empty() {
                    if let Some(prompt_command) = shell.get_var("PROMPT_COMMAND") {
                        if !prompt_command.is_empty() {
                            shell.run_string(&prompt_command);
                            if shell.exit_flag || shell.return_flag {
                                break;
                            }
                        }
                    }
                }

                let prompt_raw = if pending.is_empty() {
                    shell.get_var("PS1").unwrap_or_else(|| "\\$ ".to_string())
                } else {
                    shell.get_var("PS2").unwrap_or_else(|| "> ".to_string())
                };
                prompt = shell.expand_prompt(&prompt_raw);
                let _ = write!(stdout, "{}", prompt);
                let _ = stdout.flush();
                prompt_shown = true;
            }

            let byte = match read_stdin_byte() {
                Ok(Some(byte)) => byte,
                Ok(None) => {
                    if !current.is_empty() || !pending.is_empty() {
                        let _ = write!(stdout, "\r\n");
                        let _ = stdout.flush();
                        let mut line: String = current.iter().collect();
                        submit_interactive_line(&mut shell, &mut pending, &mut line);
                        current.clear();
                    } else {
                        let _ = writeln!(stdout, "exit");
                    }
                    break;
                }
                Err(err) if err.kind() == io::ErrorKind::Interrupted => {
                    let sig = EDITOR_SIGNAL.swap(0, Ordering::Relaxed);
                    if sig == libc::SIGINT || sig == libc::SIGQUIT {
                        let trap_name = if sig == libc::SIGINT { "INT" } else { "QUIT" };
                        if shell.traps.get(trap_name).is_some() {
                            shell.check_pending_signals();
                            if shell.exit_flag || shell.return_flag {
                                break;
                            }
                        } else if sig == libc::SIGINT {
                            shell.last_status = 128 + libc::SIGINT;
                        }
                        let _ = write!(stdout, "\r\n");
                        let _ = stdout.flush();
                        pending.clear();
                        current.clear();
                        cursor = 0;
                        nav.clear();
                        prompt_shown = false;
                    }
                    continue;
                }
                Err(_) => break,
            };

            let mut needs_redraw = false;
            match byte {
                b'\n' | b'\r' => {
                    let _ = write!(stdout, "\r\n");
                    let _ = stdout.flush();
                    let mut line: String = current.iter().collect();
                    submit_interactive_line(&mut shell, &mut pending, &mut line);
                    current.clear();
                    cursor = 0;
                    nav.clear();
                    prompt_shown = false;
                }
                0x01 => {
                    cursor = 0;
                    needs_redraw = true;
                }
                0x02 => {
                    if cursor > 0 {
                        cursor -= 1;
                        needs_redraw = true;
                    }
                }
                0x04 => {
                    if current.is_empty() && pending.is_empty() {
                        let _ = writeln!(stdout, "exit");
                        break;
                    }
                    if cursor < current.len() {
                        current.remove(cursor);
                        nav.clear();
                        needs_redraw = true;
                    }
                }
                0x05 => {
                    cursor = current.len();
                    needs_redraw = true;
                }
                0x06 => {
                    if cursor < current.len() {
                        cursor += 1;
                        needs_redraw = true;
                    }
                }
                0x08 | 0x7f => {
                    if cursor > 0 {
                        cursor -= 1;
                        current.remove(cursor);
                        nav.clear();
                        needs_redraw = true;
                    }
                }
                0x0b => {
                    if cursor < current.len() {
                        current.truncate(cursor);
                        nav.clear();
                        needs_redraw = true;
                    }
                }
                0x0c => {
                    let _ = write!(stdout, "\x1b[2J\x1b[H");
                    needs_redraw = true;
                }
                0x0e => {
                    let current_line: String = current.iter().collect();
                    if let Some(entry) = nav.next(&shell, &current_line) {
                        current = entry.chars().collect();
                        cursor = current.len();
                        needs_redraw = true;
                    }
                }
                0x0f => {
                    if !current.is_empty() || !pending.is_empty() {
                        let _ = write!(stdout, "\r\n");
                        let _ = stdout.flush();
                        let mut line: String = current.iter().collect();
                        submit_interactive_line(&mut shell, &mut pending, &mut line);
                    }
                    let next = nav.next_after_operate().unwrap_or_default();
                    current = next.chars().collect();
                    cursor = current.len();
                    prompt_shown = false;
                }
                0x10 => {
                    let current_line: String = current.iter().collect();
                    if let Some(entry) = nav.previous(&shell, &current_line) {
                        current = entry.chars().collect();
                        cursor = current.len();
                        needs_redraw = true;
                    }
                }
                0x12 => {
                    let mut needle = String::new();
                    loop {
                        match read_stdin_byte() {
                            Ok(Some(next)) if next < 0x20 || next == 0x7f => break,
                            Ok(Some(next)) => {
                                match decode_editor_input(next) {
                                    Ok(chars) => {
                                        for ch in chars {
                                            needle.push(ch);
                                        }
                                    }
                                    Err(_) => break,
                                }
                            }
                            Ok(None) | Err(_) => break,
                        }
                    }
                    if let Some(entry) = nav.search(&shell, &needle) {
                        current = entry.chars().collect();
                        cursor = current.len();
                        needs_redraw = true;
                    }
                }
                0x15 => {
                    if cursor > 0 {
                        current.drain(..cursor);
                        cursor = 0;
                        nav.clear();
                        needs_redraw = true;
                    }
                }
                0x1b => {
                    if let Ok(Some(key)) = read_escape_key() {
                        match key {
                            EditorKey::Up => {
                                let current_line: String = current.iter().collect();
                                if let Some(entry) = nav.previous(&shell, &current_line) {
                                    current = entry.chars().collect();
                                    cursor = current.len();
                                    needs_redraw = true;
                                }
                            }
                            EditorKey::Down => {
                                let current_line: String = current.iter().collect();
                                if let Some(entry) = nav.next(&shell, &current_line) {
                                    current = entry.chars().collect();
                                    cursor = current.len();
                                    needs_redraw = true;
                                }
                            }
                            EditorKey::Left => {
                                if cursor > 0 {
                                    cursor -= 1;
                                    needs_redraw = true;
                                }
                            }
                            EditorKey::Right => {
                                if cursor < current.len() {
                                    cursor += 1;
                                    needs_redraw = true;
                                }
                            }
                            EditorKey::Home => {
                                cursor = 0;
                                needs_redraw = true;
                            }
                            EditorKey::End => {
                                cursor = current.len();
                                needs_redraw = true;
                            }
                            EditorKey::Delete => {
                                if cursor < current.len() {
                                    current.remove(cursor);
                                    nav.clear();
                                    needs_redraw = true;
                                }
                            }
                        }
                    }
                }
                byte if byte < 0x20 => {}
                byte => {
                    nav.clear();
                    if let Ok(inserted) = decode_editor_input(byte) {
                        let count = inserted.len();
                        current.splice(cursor..cursor, inserted);
                        cursor += count;
                        needs_redraw = true;
                    }
                }
            }

            if needs_redraw {
                let _ = redraw_editor_line(&mut stdout, &prompt, &current, cursor);
            }
        }
    } else {
        let mut buf = String::new();
        loop {
            if shell.exit_flag || shell.return_flag {
                break;
            }

            if buf.is_empty() {
                if let Some(prompt_command) = shell.get_var("PROMPT_COMMAND") {
                    if !prompt_command.is_empty() {
                        shell.run_string(&prompt_command);
                        if shell.exit_flag || shell.return_flag {
                            break;
                        }
                    }
                }
            }

            let prompt_raw = if buf.is_empty() {
                shell.get_var("PS1").unwrap_or_else(|| "\\$ ".to_string())
            } else {
                shell.get_var("PS2").unwrap_or_else(|| "> ".to_string())
            };
            let prompt = shell.expand_prompt(&prompt_raw);
            let _ = write!(stdout, "{}", prompt);
            let _ = stdout.flush();

            let mut line = String::new();
            match stdin.read_line(&mut line) {
                Ok(0) => {
                    if !buf.is_empty() {
                        shell.run_string(&buf);
                        buf.clear();
                    }
                    break;
                }
                Ok(_) => {
                    buf.push_str(&line);
                    if stdin_buffer_is_complete(&buf) {
                        shell.run_string(&buf);
                        buf.clear();
                    }
                }
                Err(_) => break,
            }
        }
    }
    save_history_file(&mut shell);
    process::exit(shell.last_status);
}

/// Returns true if the buffered text so far looks like a complete shell
/// statement (no open quotes, heredocs, compound commands, or backslash
/// continuation). Used when streaming stdin line-by-line to decide when to
/// flush a chunk to run_string.
fn stdin_buffer_is_complete(buf: &str) -> bool {
    // Trailing backslash-newline: incomplete
    if buf.ends_with("\\\n") { return false; }

    let chars: Vec<char> = buf.chars().collect();
    let mut i = 0usize;
    let n = chars.len();
    let mut in_single = false;
    let mut in_double = false;
    let mut in_backtick = false;
    let mut paren_depth: i32 = 0;     // (
    let mut brace_depth: i32 = 0;     // {
    let mut dparen_depth: i32 = 0;    // $(( or (( ; tracked but approximate
    let mut compound_depth: i32 = 0;  // if/while/for/until/case nesting count
    // Heredoc tracking: once we see <<DELIM (or <<-DELIM), we accumulate
    // lines until a line equals DELIM.
    let mut pending_heredocs: Vec<(String, bool)> = Vec::new();
    let mut at_line_start = true;

    while i < n {
        let c = chars[i];

        // Handle heredoc-body: if we're at the start of a line and have
        // pending heredocs, check whether the line matches the oldest delim.
        if at_line_start && !pending_heredocs.is_empty()
            && !in_single && !in_double && !in_backtick {
            // Read the current line
            let mut j = i;
            while j < n && chars[j] != '\n' { j += 1; }
            let line: String = chars[i..j].iter().collect();
            let (delim, strip_tabs) = &pending_heredocs[0];
            let check = if *strip_tabs { line.trim_start_matches('\t') } else { line.as_str() };
            if check == delim.as_str() {
                pending_heredocs.remove(0);
            }
            i = j;
            if i < n { i += 1; } // skip the \n
            at_line_start = true;
            continue;
        }

        if in_single {
            if c == '\'' { in_single = false; }
            i += 1;
            at_line_start = c == '\n';
            continue;
        }
        if in_double {
            if c == '\\' && i + 1 < n { i += 2; continue; }
            if c == '"' { in_double = false; }
            i += 1;
            at_line_start = c == '\n';
            continue;
        }
        if in_backtick {
            if c == '\\' && i + 1 < n { i += 2; continue; }
            if c == '`' { in_backtick = false; }
            i += 1;
            at_line_start = c == '\n';
            continue;
        }

        match c {
            '\\' if i + 1 < n => { i += 2; at_line_start = false; continue; }
            '#' => {
                // Comment to end of line
                while i < n && chars[i] != '\n' { i += 1; }
                continue;
            }
            '\'' => { in_single = true; i += 1; continue; }
            '"' => { in_double = true; i += 1; continue; }
            '`' => { in_backtick = true; i += 1; continue; }
            '(' => {
                if i + 1 < n && chars[i + 1] == '(' {
                    dparen_depth += 1; i += 2; continue;
                }
                paren_depth += 1; i += 1; at_line_start = false; continue;
            }
            ')' => {
                if dparen_depth > 0 && i + 1 < n && chars[i + 1] == ')' {
                    dparen_depth -= 1; i += 2; continue;
                }
                paren_depth -= 1; i += 1; at_line_start = false; continue;
            }
            '{' => { brace_depth += 1; i += 1; at_line_start = false; continue; }
            '}' => { brace_depth -= 1; i += 1; at_line_start = false; continue; }
            '<' if i + 1 < n && chars[i + 1] == '<' => {
                // Check for heredoc: `<<` or `<<-` possibly followed by delim
                let mut j = i + 2;
                let strip_tabs = j < n && chars[j] == '-';
                if strip_tabs { j += 1; }
                // Skip whitespace
                while j < n && (chars[j] == ' ' || chars[j] == '\t') { j += 1; }
                // Read delim, stripping any surrounding quotes
                let mut delim = String::new();
                let mut quote = None;
                if j < n && (chars[j] == '\'' || chars[j] == '"') {
                    quote = Some(chars[j]); j += 1;
                }
                while j < n {
                    let d = chars[j];
                    if let Some(q) = quote {
                        if d == q { j += 1; break; }
                        delim.push(d); j += 1;
                    } else {
                        if d.is_whitespace() || "()<>|&;".contains(d) { break; }
                        if d == '\\' && j + 1 < n { delim.push(chars[j+1]); j += 2; continue; }
                        delim.push(d); j += 1;
                    }
                }
                if !delim.is_empty() {
                    pending_heredocs.push((delim, strip_tabs));
                }
                i = j;
                at_line_start = false;
                continue;
            }
            '\n' => {
                // At newline boundary, check for compound word starters on
                // the next statement.
                i += 1;
                at_line_start = true;
                continue;
            }
            _ => {
                // Reserved word lookups (at the start of a statement)
                if at_line_start && c.is_alphabetic() {
                    // Read identifier
                    let mut j = i;
                    while j < n && (chars[j].is_alphanumeric() || chars[j] == '_') { j += 1; }
                    let word: String = chars[i..j].iter().collect();
                    match word.as_str() {
                        "if" | "while" | "until" | "for" | "select" | "case" => {
                            compound_depth += 1;
                        }
                        "fi" | "done" | "esac" => {
                            compound_depth -= 1;
                        }
                        _ => {}
                    }
                    i = j;
                    at_line_start = false;
                    continue;
                }
                at_line_start = false;
                i += 1;
            }
        }
    }

    !in_single && !in_double && !in_backtick
        && paren_depth <= 0 && brace_depth <= 0
        && dparen_depth <= 0 && compound_depth <= 0
        && pending_heredocs.is_empty()
}

#[derive(Default)]
struct InteractiveHistoryState {
    snapshot: Vec<String>,
    cursor: Option<usize>,
    saved_current: Option<String>,
}

impl InteractiveHistoryState {
    fn clear(&mut self) {
        self.snapshot.clear();
        self.cursor = None;
        self.saved_current = None;
    }

    fn ensure_snapshot(&mut self, shell: &exec::Shell) {
        if self.snapshot.is_empty() {
            self.snapshot = shell.history.entries.iter()
                .map(|entry| entry.line.clone())
                .collect();
        }
    }

    fn previous(&mut self, shell: &exec::Shell, current: &str) -> Option<String> {
        self.ensure_snapshot(shell);
        if self.snapshot.is_empty() {
            return None;
        }
        if self.cursor.is_none() {
            self.saved_current = Some(current.to_string());
        }
        let next_idx = match self.cursor {
            Some(idx) if idx > 0 => idx - 1,
            Some(_) => 0,
            None => self.snapshot.len().saturating_sub(1),
        };
        self.cursor = Some(next_idx);
        self.snapshot.get(next_idx).cloned()
    }

    fn next(&mut self, shell: &exec::Shell, current: &str) -> Option<String> {
        self.ensure_snapshot(shell);
        let idx = self.cursor?;
        let next_idx = idx + 1;
        if next_idx >= self.snapshot.len() {
            self.cursor = None;
            return Some(self.saved_current.take().unwrap_or_else(|| current.to_string()));
        }
        self.cursor = Some(next_idx);
        self.snapshot.get(next_idx).cloned()
    }

    fn search(&mut self, shell: &exec::Shell, needle: &str) -> Option<String> {
        self.ensure_snapshot(shell);
        if self.snapshot.is_empty() {
            return None;
        }
        let idx = self.snapshot.iter().rposition(|entry| entry.contains(needle))?;
        self.cursor = Some(idx);
        self.snapshot.get(idx).cloned()
    }

    fn next_after_operate(&mut self) -> Option<String> {
        let idx = self.cursor?;
        let next_idx = idx + 1;
        if next_idx >= self.snapshot.len() {
            self.cursor = None;
            return None;
        }
        self.cursor = Some(next_idx);
        self.snapshot.get(next_idx).cloned()
    }
}

fn submit_interactive_line(shell: &mut exec::Shell, pending: &mut String, current: &mut String) {
    if current.is_empty() && pending.is_empty() {
        return;
    }
    pending.push_str(current);
    pending.push('\n');
    current.clear();
    if stdin_buffer_is_complete(pending) {
        shell.run_string(pending);
        pending.clear();
    }
}

fn history_file_options(shell: &exec::Shell) -> history::HistoryFileOptions {
    history::HistoryFileOptions {
        comment_char: shell.get_var("histchars")
            .and_then(|s| s.chars().nth(2))
            .unwrap_or('#'),
        write_timestamps: shell.vars.has_entry("HISTTIMEFORMAT"),
        histfile_size: shell.get_var("HISTFILESIZE")
            .and_then(|s| s.parse::<usize>().ok()),
    }
}

fn save_history_file(shell: &mut exec::Shell) {
    let Some(path) = shell.get_var("HISTFILE").filter(|s| !s.is_empty()) else {
        return;
    };
    shell.remember_history_file(&path);
    let opts = history_file_options(shell);
    let _ = shell.history.write_to_file_with_options(&path, false, opts);
}

fn init_shell_vars(shell: &mut exec::Shell, argv0: &str) {
    shell.set_var("BASH", &env::current_exe().unwrap_or_default().to_string_lossy());
    shell.set_var("BASH_VERSION", "5.3.0(1)-release");
    shell.set_var("BASH_VERSINFO", "5");
    shell.set_var("SHELL", argv0);

    // Bash uses the basename of argv[0] as $0 for error messages when
    // no script is being run and no explicit name is passed (e.g. `-c`).
    // When BASH_ARGV0 is set (exported from a parent), bash uses that
    // as $0 instead, ignoring the actual argv[0].  Mirror that.
    let argv0_from_env = std::env::var("BASH_ARGV0").ok();
    let argv0_basename: String = if let Some(s) = &argv0_from_env {
        s.clone()
    } else {
        let base = std::path::Path::new(argv0.trim_start_matches('-'))
            .file_name()
            .and_then(|s| s.to_str())
            .unwrap_or(argv0)
            .to_string();
        // In BRASH_TEST_MODE, the binary basename "brash" is rewritten to
        // exec::shell_name() ("bash") so error messages match bash's
        // wording.  Non-default invocation names (set via `exec -a NAME`,
        // login shells with leading `-`, etc.) pass through unchanged.
        let normalized = if base == "brash" {
            exec::shell_name().to_string()
        } else {
            base
        };
        if argv0.starts_with('-') {
            format!("-{}", normalized)
        } else {
            normalized
        }
    };
    shell.set_var("0", &argv0_basename);
    // bash initialises `$_` to the absolute pathname of the shell or
    // script at startup.  Subsequent commands update it to the last
    // argument of the previous command.  Use the resolved binary path
    // when available so `${_+…}` and `${_:-…}` behave like bash for
    // tests like exp1.sub that reference `$_` early.
    if let Some(cur_exe) = std::env::current_exe().ok().and_then(|p| p.to_str().map(String::from)) {
        shell.set_var("_", &cur_exe);
    } else {
        shell.set_var("_", &argv0_basename);
    }
    shell.set_var("BASH_ARGV0", &argv0_basename);
    shell.set_var("BASH_SUBSHELL", "0");
    shell.set_var("BASHPID", &format!("{}", process::id()));
    shell.set_var("PPID", &format!("{}", nix::unistd::getppid()));
    shell.set_var("UID", &format!("{}", nix::unistd::getuid()));
    shell.set_var("EUID", &format!("{}", nix::unistd::geteuid()));
    shell.set_var("HOSTNAME", &nix::unistd::gethostname()
        .map(|h| h.to_string_lossy().to_string()).unwrap_or_default());
    shell.set_var("OSTYPE", "linux-musl");
    shell.set_var("MACHTYPE", &format!("{}-unknown-linux-musl", env::consts::ARCH));
    shell.set_var("HOSTTYPE", env::consts::ARCH);
    shell.set_var("IFS", " \t\n");
    // PS1 is only set automatically in interactive shells; when running
    // a script (non-interactive) bash leaves PS1 unset (empty).
    // Tests that examine the environment rely on this.
    if shell.interactive {
        shell.set_var("PS1", "\\$ ");
    } else {
        // Leave PS1 unset so `$PS1` expands to empty.
    }
    shell.set_var("PS2", "> ");
    shell.set_var("PS4", "+ ");
    shell.set_var("LINENO", "0");
    shell.set_var("SHLVL", &{
        let cur: i32 = env::var("SHLVL").unwrap_or_default().parse().unwrap_or(0);
        format!("{}", cur + 1)
    });
    shell.set_var("OPTERR", "1");
    shell.set_var("OPTIND", "1");
    shell.set_var("COMP_WORDBREAKS", " \t\n\"'><=;|&(:");

    // Built-in empty associative arrays that bash always declares.
    // These show up in `declare -A` output even when no aliases /
    // tracked commands exist yet.
    shell.vars.declare_assoc("BASH_ALIASES");
    shell.vars.declare_assoc("BASH_CMDS");
    shell.vars.mark_initialized("BASH_ALIASES");
    shell.vars.mark_initialized("BASH_CMDS");

    // GROUPS array: supplementary group IDs for the current user
    {
        let ngroups = unsafe { libc::getgroups(0, std::ptr::null_mut()) };
        if ngroups > 0 {
            let mut gids = vec![0 as libc::gid_t; ngroups as usize];
            let actual = unsafe { libc::getgroups(ngroups, gids.as_mut_ptr()) };
            if actual > 0 {
                gids.truncate(actual as usize);
                let group_strs: Vec<String> = gids.iter().map(|g| g.to_string()).collect();
                shell.vars.set_array("GROUPS", group_strs);
            }
        }
    }
}

fn atty_stdin() -> bool {
    unsafe { libc::isatty(0) != 0 }
}

fn prepare_interactive_shell(shell: &mut exec::Shell) {
    shell.interactive = true;
    shell.opts.history = true; // histexpand (-H) enabled by default in interactive mode
    shell.opts.history_facility = true; // history recording is enabled by default in interactive mode
    shell.shopt.insert("expand_aliases".to_string()); // enabled by default in interactive mode
}

fn uses_bash_startup_files(argv0: &str) -> bool {
    // BRASH_TEST_MODE means the bash test suite is driving us — it expects
    // bash-compatible startup-file behaviour (.bash_profile / .bash_logout
    // / etc.) so the upstream invocation.tests fixture matches.  Without
    // this short-circuit, the `--login -c 'logout'` sub-test fails because
    // brash refuses to source $HOME/.bash_logout.
    if is_test_mode() {
        return true;
    }
    let name = std::path::Path::new(argv0.trim_start_matches('-'))
        .file_name()
        .and_then(|s| s.to_str())
        .unwrap_or(argv0);
    name == "bash"
}

fn source_startup_file(shell: &mut exec::Shell, path: &str, hide_bash_identity: bool) -> bool {
    let Ok(content) = fs::read_to_string(path) else {
        return false;
    };

    let saved_source_depth = shell.source_depth;
    let saved_return_flag = shell.return_flag;
    let saved_bash = hide_bash_identity.then(|| shell.get_var("BASH"));
    let saved_bash_version = hide_bash_identity.then(|| shell.get_var("BASH_VERSION"));
    let saved_bash_versinfo = hide_bash_identity.then(|| shell.get_var("BASH_VERSINFO"));
    if hide_bash_identity {
        shell.vars.unset("BASH");
        shell.vars.unset("BASH_VERSION");
        shell.vars.unset("BASH_VERSINFO");
    }
    shell.source_depth += 1;
    shell.run_string(&content);
    shell.source_depth = saved_source_depth;
    if shell.return_flag {
        shell.return_flag = saved_return_flag;
    }
    if let Some(saved) = saved_bash {
        restore_startup_var(shell, "BASH", saved);
    }
    if let Some(saved) = saved_bash_version {
        restore_startup_var(shell, "BASH_VERSION", saved);
    }
    if let Some(saved) = saved_bash_versinfo {
        restore_startup_var(shell, "BASH_VERSINFO", saved);
    }
    true
}

fn restore_startup_var(shell: &mut exec::Shell, name: &str, value: Option<String>) {
    match value {
        Some(v) => shell.set_var(name, &v),
        None => shell.vars.unset(name),
    }
}

/// Source ~/.bash_logout on login-shell exit (or ~/.brash_logout if
/// present, preferred).  Bash sources this file before the shell
/// terminates for `-l` / `--login` invocations.
fn run_bash_logout(shell: &mut exec::Shell, bash_compat_startup: bool) {
    if shell.noprofile {
        return;
    }
    let home = env::var("HOME").unwrap_or_default();
    if home.is_empty() {
        return;
    }
    // The `logout` / `exit` builtin sets `exit_flag`, which would
    // short-circuit `run_string`.  Temporarily clear it so the
    // logout script body can execute.
    let saved_exit_flag = shell.exit_flag;
    shell.exit_flag = false;
    let brash_logout = format!("{}/.brash_logout", home);
    if !source_startup_file(shell, &brash_logout, false) && bash_compat_startup {
        source_startup_file(shell, &format!("{}/.bash_logout", home), false);
    }
    shell.exit_flag = saved_exit_flag;
}

/// Apply BASHOPTS / SHELLOPTS from the parent environment.  This must
/// run AFTER command-line flag processing so that an exported
/// SHELLOPTS containing `braceexpand` can re-enable it even when the
/// caller passed `+B`, matching bash semantics.
fn inherit_shellopts_env(shell: &mut exec::Shell) {
    if let Ok(v) = env::var("BASHOPTS") {
        for opt in v.split(':') {
            if !opt.is_empty() && builtins::SHOPT_OPTIONS.contains(&opt) {
                shell.shopt.insert(opt.to_string());
            }
        }
    }
    if let Ok(v) = env::var("SHELLOPTS") {
        // SHELLOPTS lists the options the parent considers enabled.
        // Additively enable each one in the child; leave defaults
        // alone.  (Bash doesn't strictly forbid default-on options
        // from being on in a child whose parent had them off.)
        for opt in v.split(':') {
            if !opt.is_empty() {
                shell.set_option(opt);
            }
        }
    }
}

/// Import shell functions exported by a parent shell via BASH_FUNC_name%% env vars.
/// This implements function inheritance across exec() boundaries.
fn import_bash_funcs(shell: &mut exec::Shell) {
    // Collect the relevant env vars first to avoid borrowing issues
    let bash_funcs: Vec<(String, String)> = env::vars()
        .filter(|(k, _)| k.starts_with("BASH_FUNC_") && k.ends_with("%%"))
        .collect();

    for (key, value) in bash_funcs {
        // Extract function name from BASH_FUNC_name%%
        let func_name = &key["BASH_FUNC_".len()..key.len() - "%%".len()];

        // Security: reject names with newlines, leading/trailing whitespace, or spaces
        if func_name.contains('\n') || func_name.contains(' ') || func_name.contains('\t') {
            continue;
        }
        // Reject empty names
        if func_name.is_empty() {
            continue;
        }

        // Security (CVE-2014-6271): value must start with "() " or "() {"
        // to be a valid function definition; anything else is ignored.
        let trimmed = value.trim_start();
        if !trimmed.starts_with("()") {
            continue;
        }

        // Security (CVE-2014-6271): reject if there is any code after the
        // closing `}` of the function body. Bash 5.x rejects such values entirely.
        if !is_clean_func_body(trimmed) {
            continue;
        }

        // Build the function definition source and parse it.
        // The value is "() { body }" and we prepend the function name.
        let func_src = format!("{} {}", func_name, trimmed);

        // Parse and register the function, ignoring any parse errors
        shell.define_function_from_src(func_name, &func_src);

        // Keep the BASH_FUNC_name%% var exported so it propagates further
    }
}

/// Return true iff the function body value has no code after the closing `}`.
/// CVE-2014-6271: values like `() { safe; } ; evil` must be rejected.
fn is_clean_func_body(src: &str) -> bool {
    let bytes = src.as_bytes();
    let mut i = 0;
    let n = bytes.len();

    // Skip `()` and whitespace before `{`
    while i < n && (bytes[i] == b'(' || bytes[i] == b')' || bytes[i] == b' ' || bytes[i] == b'\t') {
        i += 1;
    }

    // If not a brace-group body, accept it as-is (subshell body, etc.)
    if i >= n || bytes[i] != b'{' {
        return true;
    }

    // Find the matching outer `}` tracking brace depth and quoting
    let mut depth = 0usize;
    let mut in_single_quote = false;
    let mut in_double_quote = false;
    let mut end: Option<usize> = None;

    while i < n {
        let c = bytes[i];
        if in_single_quote {
            if c == b'\'' { in_single_quote = false; }
        } else if in_double_quote {
            if c == b'\\' { i += 1; } // skip escaped char
            else if c == b'"' { in_double_quote = false; }
        } else {
            match c {
                b'\'' => in_single_quote = true,
                b'"'  => in_double_quote = true,
                b'\\' => { i += 1; }
                b'#' => {
                    // Skip comment to end of line
                    while i < n && bytes[i] != b'\n' { i += 1; }
                }
                b'{' => depth += 1,
                b'}' => {
                    depth -= 1;
                    if depth == 0 {
                        end = Some(i + 1);
                        break;
                    }
                }
                _ => {}
            }
        }
        i += 1;
    }

    // The closing `}` must exist and everything after it must be either
    // whitespace/newlines or one-or-more file-descriptor redirections that
    // bash itself emits when pretty-printing a function body (e.g.
    // `() { … } 1>&2`, `() { … } 2>&1 1>/dev/null`).  Any other trailing
    // content (commands, pipes, etc.) indicates a CVE-2014-6271 style
    // injection and must be rejected.
    match end {
        None => false, // no closing `}` found
        Some(close) => is_trailing_whitespace_or_redirects(&bytes[close..]),
    }
}

/// Recognise whitespace optionally followed by one or more shell redirections.
/// Valid redirection forms:
///   [fd]<target         [fd]>target        [fd]>>target
///   [fd]<&[fd|-]        [fd]>&[fd|-]       [fd]<>target
///   [fd]>|target        &>target           &>>target
/// The target word must be a "safe" token: no shell metacharacters that
/// could introduce new commands (`;`, `|`, `&` without `>`, backticks,
/// `$(`, etc.).
fn is_trailing_whitespace_or_redirects(bytes: &[u8]) -> bool {
    let n = bytes.len();
    let mut i = 0;
    // Skip leading whitespace.
    while i < n && matches!(bytes[i], b' ' | b'\t' | b'\n' | b'\r') { i += 1; }
    while i < n {
        // Optional leading fd digits (for `1>`, `2>&1`, etc.)
        let start = i;
        while i < n && bytes[i].is_ascii_digit() { i += 1; }
        // Also accept `&>` / `&>>`
        if i == start && i < n && bytes[i] == b'&' && i + 1 < n && bytes[i + 1] == b'>' {
            i += 1;
        }
        // Require a redirect operator starting with `<` or `>`.
        if i >= n { return false; }
        match bytes[i] {
            b'<' | b'>' => {}
            _ => return false,
        }
        // Consume the operator: `<`, `<<`, `<<-`, `<&`, `<>`, `>`, `>>`, `>&`, `>|`
        let op_start = i;
        i += 1;
        if i < n {
            match bytes[i] {
                b'<' | b'>' | b'&' | b'|' => { i += 1; }
                _ => {}
            }
            // `<<-`
            if bytes[op_start] == b'<' && i - op_start == 2 && i < n && bytes[i] == b'-' {
                i += 1;
            }
        }
        // Optional whitespace between op and target
        while i < n && matches!(bytes[i], b' ' | b'\t') { i += 1; }
        // Consume the target word: accept digits, `-`, simple filename chars,
        // or the special `&-` / `-`.  Reject anything that could start a new
        // command.
        let target_start = i;
        while i < n {
            match bytes[i] {
                b' ' | b'\t' | b'\n' | b'\r' => break,
                // Characters that could begin a new command or introduce
                // substitution — reject.
                b';' | b'|' | b'&' | b'`' | b'(' | b')' | b'{' | b'}'
                | b'#' | b'$' | b'"' | b'\'' | b'\\' => return false,
                _ => { i += 1; }
            }
        }
        if i == target_start { return false; } // empty target
        // Skip whitespace / newlines between redirects
        while i < n && matches!(bytes[i], b' ' | b'\t' | b'\n' | b'\r') { i += 1; }
    }
    true
}
