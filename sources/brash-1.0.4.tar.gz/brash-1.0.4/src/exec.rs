use crate::parser::*;
use crate::lexer::RedirectOp;
use crate::expand;
use crate::builtins;
use crate::vars::Variables;
use crate::trap::TrapHandler;

/// ahash-backed maps for hot shell state (functions, aliases, shopt, hash_table).
/// Anywhere we still want std::collections types we reach for them fully
/// qualified so this module's namespace stays small and the unused-import
/// warning stays clean.
type AHashMap<K, V> = ahash::AHashMap<K, V>;
type AHashSet<T> = ahash::AHashSet<T>;
use std::ffi::CString;
use std::io::{Read, Write};
use std::os::unix::io::{RawFd, IntoRawFd as StdIntoRawFd, FromRawFd};
use std::sync::atomic::{AtomicI32, Ordering};

use nix::unistd::{fork, ForkResult, execvp, pipe, dup2, close, Pid};
use nix::sys::wait::{waitpid, WaitStatus, WaitPidFlag};
use nix::sys::signal::{signal, SigHandler, Signal};

// ---------------------------------------------------------------------------
// Bash-impersonation test mode
//
// When the env var `BRASH_TEST_MODE` is set (to any non-empty value), brash
// reports its self-name as "bash" in user-facing output: the default `$0`,
// the "{}: …" error prefix, the --version / --help banners, etc.  This
// lets the bash test suite diff brash's output against bash's hard-coded
// `.right` files without having to rename the binary.
// ---------------------------------------------------------------------------

/// Self-name used in error messages and defaults.  Cached after first
/// call; pass-through to `"bash"` in `BRASH_TEST_MODE`.
pub fn shell_name() -> &'static str {
    use std::sync::OnceLock;
    static NAME: OnceLock<&'static str> = OnceLock::new();
    NAME.get_or_init(|| match std::env::var("BRASH_TEST_MODE") {
        Ok(v) if !v.is_empty() => "bash",
        _ => "brash",
    })
}

thread_local! {
    /// Thread-local script name + line number for error messages emitted
    /// from stateless expand helpers that don't have a Shell reference.
    /// Set by execute_simple before each word expansion.
    pub static CURRENT_ERR_PREFIX: std::cell::RefCell<String> = std::cell::RefCell::new(String::new());

    /// Glob-related shopt flags mirrored here so stateless expand
    /// helpers (`pathname_expand`, `extglob_pathname_expand`) can
    /// consult them without a Shell reference.  Updated by the main
    /// command loop before word expansion.
    pub static GLOB_SHOPTS: std::cell::Cell<GlobShopts> = std::cell::Cell::new(GlobShopts {
        dotglob: false,
        nocaseglob: false,
        nocasematch: false,
        nullglob: false,
        failglob: false,
        globstar: false,
        extglob: false,
        globskipdots: true,
        patsub_replacement: true,
    });

    /// Dynamic glob-related variables mirrored here so stateless
    /// expand helpers can honor them without a Shell reference.
    pub static GLOB_RUNTIME: std::cell::RefCell<GlobRuntime> = std::cell::RefCell::new(GlobRuntime::default());

    /// POSIX mode (`set -o posix`) — mirrored here so the lexer can
    /// honour posix parsing rules (e.g. `'` inside `${...}` within
    /// `"..."` is literal) without a Variables reference.  Updated
    /// by `run_string` / `run_string_segmented` before tokenizing.
    pub static POSIX_MODE: std::cell::Cell<bool> = std::cell::Cell::new(false);

    /// Alias/function/shopt state mirrored here so stateless expansion
    /// helpers can execute nested command substitutions with the same
    /// parser-visible runtime as the active shell.
    pub static CMDSUB_EXPAND_RUNTIME: std::cell::RefCell<ExpandCmdsubRuntime> =
        std::cell::RefCell::new(ExpandCmdsubRuntime::default());
}

#[derive(Copy, Clone, Debug)]
pub struct GlobShopts {
    pub dotglob: bool,
    pub nocaseglob: bool,
    pub nocasematch: bool,
    pub nullglob: bool,
    pub failglob: bool,
    pub globstar: bool,
    /// `shopt -s extglob` enables extended-glob `?(…)|*(…)|+(…)|@(…)|!(…)`
    /// patterns.  The lexer/parser handle extglob tokens unconditionally
    /// today (matching bash's behaviour when this option is off but a
    /// pattern is recognisable as extglob), so the flag is captured but
    /// not yet consulted at match time.
    #[allow(dead_code)]
    pub extglob: bool,
    /// When true (bash 5.2+ default), pattern matches exclude the
    /// `.` and `..` directory entries even for patterns starting
    /// with `.`.  When false, those entries are included.
    pub globskipdots: bool,
    /// When true (bash 5.2+ default), `&` in the replacement string of
    /// `${var/pat/repl}` expands to the matched text (like sed).  When
    /// false, `&` is literal.
    pub patsub_replacement: bool,
}

#[derive(Clone, Debug, Default)]
pub struct GlobRuntime {
    pub globignore: Option<String>,
    pub globsort: Option<String>,
}

#[derive(Clone, Debug, Default)]
pub struct ExpandCmdsubRuntime {
    pub aliases: AHashMap<String, String>,
    pub functions: AHashMap<String, std::rc::Rc<FuncDef>>,
    pub shopt: AHashSet<String>,
}

/// Like `shell_name()` but includes the current script name and line
/// number when available (matching `Shell::err_prefix_with_line`).
/// Stateless helpers inside expand.rs call this for bash-style error
/// messages.
pub fn shell_name_with_line() -> String {
    CURRENT_ERR_PREFIX.with(|p| {
        let p = p.borrow();
        if !p.is_empty() {
            p.clone()
        } else {
            shell_name().to_string()
        }
    })
}

/// Resolve command-substitution markers in a stateless expansion helper by
/// running them in a throwaway shell seeded from the current variables. This
/// is enough for literal `$(...)` written in an array subscript, while values
/// produced by parameter expansion remain plain text and are not re-expanded.
pub fn resolve_cmdsubs_for_expand(s: &str, vars: &mut Variables) -> String {
    if !s.contains("\x00CMDSUB\x00")
        && !s.contains(expand::QCMDSUB_MARKER)
        && !s.contains(expand::FUNSUB_MARKER)
        && !s.contains(expand::QFUNSUB_MARKER)
        && !s.contains(expand::REPLYSUB_MARKER)
        && !s.contains(expand::QREPLYSUB_MARKER)
    {
        return s.to_string();
    }
    let mut shell = Shell::new();
    shell.vars = vars.clone();
    shell.posix_mode = vars.posix_mode;
    shell.vars.posix_mode = vars.posix_mode;
    CMDSUB_EXPAND_RUNTIME.with(|runtime| {
        let runtime = runtime.borrow();
        shell.aliases = runtime.aliases.clone();
        shell.functions = runtime.functions.clone();
        shell.shopt = runtime.shopt.clone();
    });
    let resolved = shell.resolve_cmdsubs(s);
    vars.set("?", &shell.last_status.to_string());
    resolved
}

pub fn expand_prompt_for_expand(prompt_raw: &str, vars: &mut Variables) -> String {
    let mut shell = Shell::new();
    shell.vars = vars.clone();
    shell.posix_mode = vars.posix_mode;
    shell.vars.posix_mode = vars.posix_mode;
    CMDSUB_EXPAND_RUNTIME.with(|runtime| {
        let runtime = runtime.borrow();
        shell.aliases = runtime.aliases.clone();
        shell.functions = runtime.functions.clone();
        shell.shopt = runtime.shopt.clone();
    });
    let mut expanded = shell.expand_prompt(prompt_raw);
    if prompt_raw.starts_with('!') && expanded.starts_with('!') {
        let num = shell.prompt_command_number().to_string();
        expanded.replace_range(0..1, &num);
    }
    vars.set("?", &shell.last_status.to_string());
    expanded
}

const PROMPT_LITERAL_BACKSLASH: char = '\u{E013}';

fn restore_prompt_literals(s: String) -> String {
    s.chars()
        .map(|c| if c == PROMPT_LITERAL_BACKSLASH { '\\' } else { c })
        .collect()
}

fn is_empty_arraylike_quoted_segment(segment: &str) -> bool {
    if segment == "$@" || segment == "${@}" {
        return true;
    }
    if let Some(inner) = segment.strip_prefix("${").and_then(|s| s.strip_suffix('}')) {
        return inner == "@"
            || inner.ends_with("[@]")
            || inner.ends_with("[*]");
    }
    false
}

fn token_preserves_empty_field_with_empty_at(token: &str) -> bool {
    let chars: Vec<char> = token.chars().collect();
    let mut i = 0usize;
    while i < chars.len() {
        match chars[i] {
            '\\' => i += 2,
            '\'' => return true,
            '"' => {
                i += 1;
                let start = i;
                while i < chars.len() {
                    if chars[i] == '\\' {
                        i += 2;
                        continue;
                    }
                    if chars[i] == '"' {
                        break;
                    }
                    i += 1;
                }
                let segment: String = chars[start..i.min(chars.len())].iter().collect();
                if !is_empty_arraylike_quoted_segment(&segment) {
                    return true;
                }
                if i < chars.len() {
                    i += 1;
                }
            }
            _ => i += 1,
        }
    }
    false
}

/// Collect each contiguous double- or single-quoted region in `token` as
/// `(content, contains_at_dollar)`.  Used by the `"…$@…"` word-collapse
/// heuristic to decide whether other-than-`$@` quoted material is present.
fn collect_quoted_regions(token: &str) -> Vec<(String, bool)> {
    let chars: Vec<char> = token.chars().collect();
    let n = chars.len();
    let mut out: Vec<(String, bool)> = Vec::new();
    let mut i = 0usize;
    while i < n {
        if chars[i] == '\\' && i + 1 < n {
            i += 2;
            continue;
        }
        if chars[i] == '"' {
            i += 1;
            let start = i;
            while i < n {
                if chars[i] == '\\' && i + 1 < n { i += 2; continue; }
                if chars[i] == '"' { break; }
                i += 1;
            }
            let segment: String = chars[start..i.min(n)].iter().collect();
            let has_at = segment.contains("$@") || segment.contains("${@}");
            out.push((segment, has_at));
            if i < n { i += 1; }
        } else if chars[i] == '\'' {
            i += 1;
            let start = i;
            while i < n && chars[i] != '\'' { i += 1; }
            let segment: String = chars[start..i.min(n)].iter().collect();
            out.push((segment, false));
            if i < n { i += 1; }
        } else {
            i += 1;
        }
    }
    out
}

/// True if `token` has any unquoted literal characters (alphanumeric,
/// punctuation other than `$`/`\\`/quotes) outside of `"…"`/`'…'` regions.
/// Used by the `"…$@…"` collapse heuristic.
fn has_unquoted_literal_outside_quotes(token: &str) -> bool {
    let chars: Vec<char> = token.chars().collect();
    let n = chars.len();
    let mut i = 0usize;
    while i < n {
        if chars[i] == '\\' && i + 1 < n {
            // Backslash-escaped chars outside quotes are literal text.
            return true;
        }
        if chars[i] == '"' {
            i += 1;
            while i < n {
                if chars[i] == '\\' && i + 1 < n { i += 2; continue; }
                if chars[i] == '"' { break; }
                i += 1;
            }
            if i < n { i += 1; }
            continue;
        }
        if chars[i] == '\'' {
            i += 1;
            while i < n && chars[i] != '\'' { i += 1; }
            if i < n { i += 1; }
            continue;
        }
        // Outside quotes.  `$` starts an expansion; skip past `$NAME` or
        // `${...}` ref without counting as literal.
        if chars[i] == '$' && i + 1 < n {
            if chars[i + 1] == '{' {
                i += 2;
                let mut depth = 1usize;
                while i < n && depth > 0 {
                    match chars[i] {
                        '\\' if i + 1 < n => i += 2,
                        '{' => { depth += 1; i += 1; }
                        '}' => { depth -= 1; i += 1; }
                        _ => i += 1,
                    }
                }
                continue;
            }
            if chars[i + 1].is_alphanumeric() || chars[i + 1] == '_' || chars[i + 1] == '@'
                || chars[i + 1] == '*' || chars[i + 1] == '#' || chars[i + 1] == '?'
                || chars[i + 1] == '$' || chars[i + 1] == '!' || chars[i + 1] == '-'
            {
                i += 2;
                while i < n && (chars[i].is_alphanumeric() || chars[i] == '_') {
                    i += 1;
                }
                continue;
            }
        }
        // Any other char outside quotes is literal text.
        return true;
    }
    false
}

/// Strip `$NAME` and `${...}` parameter references from a token, returning
/// the remaining literal characters.  Used to distinguish between explicit
/// empty quoted regions and dollar-expansion empties when collapsing
/// `"…$@…"` words.
fn strip_dollar_refs(token: &str) -> String {
    let chars: Vec<char> = token.chars().collect();
    let n = chars.len();
    let mut out = String::with_capacity(token.len());
    let mut i = 0usize;
    while i < n {
        if chars[i] == '\\' && i + 1 < n {
            out.push(chars[i]);
            out.push(chars[i + 1]);
            i += 2;
            continue;
        }
        if chars[i] == '$' && i + 1 < n {
            if chars[i + 1] == '{' {
                i += 2;
                let mut depth = 1usize;
                while i < n && depth > 0 {
                    match chars[i] {
                        '\\' if i + 1 < n => i += 2,
                        '{' => { depth += 1; i += 1; }
                        '}' => { depth -= 1; i += 1; }
                        _ => i += 1,
                    }
                }
                continue;
            }
            if chars[i + 1].is_alphanumeric() || chars[i + 1] == '_' || chars[i + 1] == '@'
                || chars[i + 1] == '*' || chars[i + 1] == '#' || chars[i + 1] == '?'
                || chars[i + 1] == '$' || chars[i + 1] == '!' || chars[i + 1] == '-'
            {
                i += 2;
                while i < n && (chars[i].is_alphanumeric() || chars[i] == '_') {
                    i += 1;
                }
                continue;
            }
        }
        out.push(chars[i]);
        i += 1;
    }
    out
}

// ---------------------------------------------------------------------------
// Pending-signal delivery mechanism
//
// We use an array of AtomicI32 to record signals received asynchronously.
// The slot index is the signal number (0..63).  The value is a count of
// how many times the signal has been received since the last check.
// A custom raw C signal handler increments the appropriate slot.
// ---------------------------------------------------------------------------

/// Maximum signal number we track.
pub const SIG_MAX: usize = 64;

/// Per-signal pending count (signal number → count).
pub static PENDING_SIGNALS: [AtomicI32; SIG_MAX] = {
    // const fn can't call AtomicI32::new in an array initialiser on stable, so
    // we use a macro-generated literal.
    const ZERO: AtomicI32 = AtomicI32::new(0);
    [ZERO; SIG_MAX]
};

/// The raw C signal handler that records a pending signal.
/// SAFETY: only touches an AtomicI32 array — safe for async signal context.
extern "C" fn record_signal(sig: libc::c_int) {
    if sig >= 0 && (sig as usize) < SIG_MAX {
        PENDING_SIGNALS[sig as usize].fetch_add(1, Ordering::Relaxed);
    }
}

/// Install the pending-signal recorder for signal number `sig`.
/// Called by `builtin_trap` when a non-empty action is set for a real signal.
pub fn install_trap_handler(sig_num: i32) {
    if sig_num <= 0 || sig_num as usize >= SIG_MAX {
        return;
    }
    unsafe {
        let mut sa: libc::sigaction = std::mem::zeroed();
        sa.sa_sigaction = record_signal as usize;
        libc::sigemptyset(&mut sa.sa_mask);
        sa.sa_flags = libc::SA_RESTART;
        libc::sigaction(sig_num, &sa, std::ptr::null_mut());
    }
}

// ---------------------------------------------------------------------------
// SavedFd — used to save/restore file descriptors around redirections
// ---------------------------------------------------------------------------

struct SavedFd {
    original_fd: RawFd,
    saved_fd: RawFd,
}

struct BoolRestoreGuard {
    slot: *mut bool,
    saved: bool,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub enum BackgroundJobState {
    Running,
    Stopped(i32),
    Done(i32),
    Signaled(i32),
}

#[derive(Clone, Debug)]
pub struct BackgroundJobInfo {
    pub job_id: usize,
    pub pid: i32,
    pub command: String,
    pub state: BackgroundJobState,
    pub started_without_job_control: bool,
}

impl BackgroundJobInfo {
    pub fn is_running(&self) -> bool {
        matches!(self.state, BackgroundJobState::Running)
    }

    pub fn is_stopped(&self) -> bool {
        matches!(self.state, BackgroundJobState::Stopped(_))
    }

    pub fn is_completed(&self) -> bool {
        matches!(
            self.state,
            BackgroundJobState::Done(_) | BackgroundJobState::Signaled(_)
        )
    }

    pub fn wait_status(&self) -> Option<i32> {
        match self.state {
            BackgroundJobState::Done(status) => Some(status),
            BackgroundJobState::Signaled(sig) => Some(128 + sig),
            _ => None,
        }
    }
}

impl BoolRestoreGuard {
    fn reset(slot: &mut bool) -> Self {
        let saved = *slot;
        *slot = false;
        Self { slot, saved }
    }
}

impl Drop for BoolRestoreGuard {
    fn drop(&mut self) {
        unsafe {
            *self.slot = self.saved;
        }
    }
}

// ---------------------------------------------------------------------------
// ShellOpts — all set/unset-able shell flags
// ---------------------------------------------------------------------------

#[derive(Clone)]
pub struct ShellOpts {
    pub errexit: bool,    // -e
    pub nounset: bool,    // -u
    pub xtrace: bool,     // -x
    pub verbose: bool,    // -v
    pub noexec: bool,     // -n
    pub noglob: bool,     // -f
    pub noclobber: bool,  // -C
    pub allexport: bool,  // -a
    pub braceexpand: bool, // -B (on by default)
    pub hashall: bool,    // -h
    pub monitor: bool,    // -m
    pub notify: bool,     // -b
    pub pipefail: bool,
    pub errtrace: bool,   // -E
    pub functrace: bool,  // -T
    pub physical: bool,   // -P
    pub privileged: bool, // -p
    pub history: bool,    // -H
    pub onecmd: bool,     // -t
    /// -k: place all name=value words in the environment of simple
    /// commands, not just those that precede the command name.  Also
    /// affects how bare \`name=value\` words are treated when no
    /// command follows.
    pub keyword_assign: bool,
    // Interactive-only flags we track for compat with `set -o`/`shopt -o`
    // output even though they don't affect non-interactive execution.
    pub emacs: bool,
    pub vi: bool,
    pub history_facility: bool,  // `set -o history`
    pub ignoreeof: bool,
    pub nolog: bool,
    pub interactive_comments: bool,
}

impl Default for ShellOpts {
    fn default() -> Self {
        ShellOpts {
            errexit: false,
            nounset: false,
            xtrace: false,
            verbose: false,
            noexec: false,
            noglob: false,
            noclobber: false,
            allexport: false,
            braceexpand: true, // on by default per bash
            hashall: true,     // -h on by default
            monitor: false,
            notify: false,
            pipefail: false,
            errtrace: false,
            functrace: false,
            physical: false,
            privileged: false,
            history: false,    // -H on by default only in interactive mode
            onecmd: false,
            keyword_assign: false,
            emacs: false,
            vi: false,
            history_facility: false,
            ignoreeof: false,
            nolog: false,
            interactive_comments: true,
        }
    }
}

// ---------------------------------------------------------------------------
// Shell — the main shell state object
// ---------------------------------------------------------------------------

pub struct Shell {
    pub vars: Variables,
    pub inherited_env: AHashMap<String, String>,
    pub last_status: i32,
    /// Variable names currently in "tempenv" state — set by a prefix
    /// assignment on a function call.  Used by `typeset NAME` inside
    /// the function to decide whether to inherit the value into the
    /// new local (bash: `var=hello func; f(){ typeset var; }`).
    pub tempenv_names: AHashSet<String>,
    pub local_option_snapshots: Vec<Option<(ShellOpts, bool)>>,
    /// Cached count of positional parameters ($1, $2, …).  Today $# is
    /// computed on-demand from the `0`/`1`/… entries in `vars`, so this
    /// counter is set but never read.  Kept for the planned positional-
    /// param fast path that avoids the linear scan.
    #[allow(dead_code)]
    pub positional_count: usize,
    pub interactive: bool,
    pub norc: bool,
    pub noprofile: bool,
    pub posix_mode: bool,
    /// Was brash invoked as a login shell (`-l`/`--login`, or argv[0]
    /// starts with `-`)?  Controls whether `logout` is a no-op or an
    /// error.
    pub is_login_shell: bool,
    /// True when running with -c (command string mode)
    pub c_mode: bool,
    /// The original -c command string (for error messages)
    pub c_string: Option<String>,
    /// When true (`--pretty-print`), parse the input and emit the
    /// formatted AST instead of executing.
    pub pretty_print_mode: bool,
    pub functions: AHashMap<String, std::rc::Rc<FuncDef>>,
    /// Set of function names marked readonly via `readonly -f NAME`.
    pub readonly_functions: AHashSet<String>,
    /// When this process is a forked subshell, the line of the closing `)`
    /// of the subshell we are running.  Used to attribute subshell-scoped
    /// fatal errors to the correct source line (bash convention).
    pub subshell_end_lineno: usize,
    pub aliases: AHashMap<String, String>,
    pub traps: TrapHandler,
    pub opts: ShellOpts,
    pub loop_depth: usize,
    pub break_count: usize,
    pub continue_count: usize,
    pub return_flag: bool,
    pub exit_flag: bool,
    /// Abort the remainder of the current semicolon-separated list until the
    /// next newline/EOF, but keep executing later top-level lines.
    abort_list_until_newline: bool,
    /// Used by `command` when invoking POSIX special builtins so they
    /// do not take the shell-fatal path reserved for direct invocation.
    pub suppress_special_builtin_fatal: bool,
    /// Set to true after the EXIT trap has been executed, to prevent
    /// running it twice (once via do_exit and once in execute_subshell).
    pub exit_trap_done: bool,
    pub pipestatus: Vec<i32>,
    pub last_bg_pid: Option<u32>,
    bg_jobs: Vec<BackgroundJobInfo>,
    next_bg_job_id: usize,
    current_bg_job_id: Option<usize>,
    previous_bg_job_id: Option<usize>,
    pub original_pid: u32,
    pub start_time: std::time::Instant,
    pub shopt: AHashSet<String>,
    pub dirstack: Vec<String>,
    pub bash_command: String,
    /// When non-empty, the source text of the line that invoked the
    /// currently-running `$(…)` command substitution.  Child cmdsub
    /// shells use this (inherited via fork) to print the outer line as
    /// the "offending source" in parse-error messages, matching bash's
    /// behaviour of emitting the enclosing script line rather than the
    /// cmdsub body.
    pub parent_source_line: String,
    /// Outer line number to attribute parse errors to when we're
    /// running a cmdsub child.  0 = use the child's own lineno.  Bash
    /// reports the line of the `$(…)` invocation in the enclosing
    /// script, not the line within the cmdsub body.
    pub parent_lineno: usize,
    pub script_name: String,  // actual script filename for error messages (separate from $0)
    /// When > 0, set -e exits are suppressed (used for if/while/until conditions).
    pub suppress_errexit: usize,
    /// True when the last executed pipeline was prefixed with `!` (negated).
    /// Set-e should not trigger for such commands.
    pub last_was_negated: bool,
    /// Call stack for FUNCNAME/BASH_SOURCE/BASH_LINENO.
    /// Bottom of the stack is "main" (top-level script).
    pub funcname_stack: Vec<String>,
    /// BASH_SOURCE in bash order: [0] is the current frame, last is main.
    pub bash_source_stack: Vec<String>,
    /// BASH_LINENO in bash order: [0] is the current frame's call site, last is 0.
    pub bash_lineno_stack: Vec<usize>,
    /// BASH_ARGC in bash order: [0] is the current frame's argument count.
    pub bash_argc_stack: Vec<usize>,
    /// Flattened BASH_ARGV contents with the current frame's arguments first,
    /// each frame stored in reverse argument order (matching bash).
    pub bash_argv_stack: Vec<String>,
    /// Guard to prevent recursive DEBUG trap invocation.
    in_debug_trap: bool,
    /// When > 0, execute_simple skips LINENO update from the parsed command
    /// lineno. Used so that $LINENO in a DEBUG trap string refers to the
    /// triggering command's line, not the trap string's own parse line.
    suppress_lineno_update: usize,
    /// When true, heredoc-terminated-by-EOF warnings from tokenization are
    /// suppressed. Used when re-parsing command substitution content where
    /// the outer parse already emitted the appropriate warnings.
    suppress_heredoc_warnings: bool,
    /// Pending heredoc warnings to emit before commands at or after these lines.
    pending_heredoc_warnings: Vec<crate::lexer::HeredocWarning>,
    /// Aliases currently being expanded (to prevent circular alias recursion).
    expanding_aliases: AHashSet<String>,
    /// Name of the currently active coproc array (e.g. "COPROC" or user-given).
    coproc_name: Option<String>,
    /// PID of the currently active coproc child, for cleanup tracking.
    coproc_pid: Option<i32>,
    /// Child PIDs from process substitutions in redirects, to be reaped later.
    procsub_children: Vec<Pid>,
    /// Incremented whenever a command substitution completes. Used to detect
    /// whether assignment RHS expansion contained any command substitutions.
    cmdsub_counter: u64,
    /// Internal character index for getopts processing of combined options
    /// (e.g. `-abc`). Reset to 0 when OPTIND changes externally.
    pub getopts_charindex: usize,
    /// Last OPTIND value seen by getopts, used to detect external changes.
    pub getopts_last_optind: usize,
    /// Restricted shell mode (`set -r` / `bash -r`). Once set, cannot be unset.
    pub restricted: bool,
    /// Hash table mapping command names to full paths (`hash -p`).
    pub hash_table: AHashMap<String, String>,
    /// Hit counts for hashed commands (incremented on each execution).
    pub hash_hits: AHashMap<String, u32>,
    /// Builtins disabled via `enable -n`.
    pub disabled_builtins: AHashSet<String>,
    /// History list (the in-memory history).
    pub history: crate::history::HistoryList,
    /// Most recent non-empty history file path that this shell loaded or used.
    remembered_history_file: Option<String>,
    /// Raw command line most recently recorded in history for the current execution.
    pub current_history_line: Option<String>,
    /// Last history substitution (old, new) for :& and :g& modifiers.
    pub hist_last_subst: Option<(String, String)>,
    /// Nesting depth of `eval` calls, for error message formatting.
    pub eval_depth: usize,
    /// Nesting depth of sourced files (`.` / `source`), so `return` can
    /// distinguish top-level scripts from sourced contexts.
    pub source_depth: usize,
    /// The original eval string (for error messages showing the offending command).
    pub eval_string: Option<String>,
    /// File descriptor for xtrace output (BASH_XTRACEFD). None = stderr (fd 2).
    pub xtrace_fd: Option<RawFd>,
    /// Functions that have been given the trace attribute (`declare -ft`).
    /// The DEBUG and RETURN traps are inherited by these functions even without functrace.
    pub traced_functions: AHashSet<String>,
    /// Nesting depth of the RETURN trap invocation guard.
    in_return_trap: bool,
    /// When > 0, we are inside a non-traced function where DEBUG/RETURN traps
    /// should not fire (unless the function has the trace attribute or functrace is on).
    pub in_untraced_function: usize,
    /// Stack of DEBUG trap action strings that were active when entering untraced functions.
    /// Used so that if the function changes the DEBUG trap, the new trap fires (it's not
    /// the inherited one). One entry per untraced function nesting level.
    suppressed_debug_actions: Vec<Option<String>>,
    /// Signals that were SIG_IGN at shell startup (inherited from parent).
    /// These cannot be trapped or reset by the shell (POSIX requirement).
    pub startup_ignored_signals: AHashSet<String>,
    /// True when we are executing inside a pipeline child process or command
    /// substitution. ERR trap should not fire in these contexts — only the
    /// outer shell fires ERR trap for pipeline/cmdsub results.
    /// Note: explicit ( ) subshells DO inherit and fire the ERR trap.
    in_pipeline_or_cmdsub: bool,
    /// Nesting depth for xtrace PS4 expansion. Each function call or trap body
    /// increases this by 1. The leading `+` characters in PS4 are repeated by
    /// this depth (bash behavior: depth 1 = `+`, depth 2 = `++`, etc.).
    xtrace_depth: usize,
    /// True when we are inside a signal trap body (prevents reentrancy).
    pub in_signal_trap: bool,
    /// The signal number that triggered the most recently fired trap.
    /// Stored in BASH_TRAPSIG.
    bash_trapsig: i32,
    /// When in_function_trap is true, a `return` inside the trap body
    /// should propagate to exit the currently-executing function.
    pub in_function_trap: bool,
    /// The value of $? at the time the signal trap was entered.
    /// Used by `return` (no arg) inside a signal trap: POSIX requires the
    /// function to exit with the pre-trap status, not the trap body's status.
    pub signal_trap_entry_status: i32,
    /// Set by `command exec` when it dispatches a bare `exec` builtin, so the
    /// outer simple-command path knows to keep its redirections permanent.
    pub exec_redirects_permanent: bool,
    /// Registered programmable completion specs from the `complete` builtin.
    /// Stored in insertion order; callers sort these into bash's hash-bucket
    /// walk order when printing.
    pub completions: Vec<(String, CompletionSpec)>,
    /// Line of the innermost function body `{` currently being executed.
    /// Set by execute_group when inside a function (funcname_stack non-empty).
    /// Used by execute_select to report errors at the `{` line as bash does.
    func_body_open_lineno: usize,
    /// True when funcname_stack/bash_source_stack/bash_lineno_stack have changed
    /// since the last call to sync_stack_trace_arrays(). Skip the sync when false.
    pub(crate) stack_trace_dirty: bool,
    /// Set by execute_pipeline in the forked child when the pipeline element
    /// is a Simple command — allows run_external to exec in-place (no inner
    /// fork) instead of fork+exec.  Reset to false by execute_simple so it
    /// only fires for the outermost command dispatch.
    exec_in_place: bool,
}

#[derive(Clone, Default)]
pub struct CompletionSpec {
    pub action_flags: Vec<char>,
    pub named_action: Option<String>,
    pub globpat: Option<String>,
    pub wordlist: Option<String>,
    pub function_name: Option<String>,
    pub command: Option<String>,
    pub filterpat: Option<String>,
    pub prefix: Option<String>,
    pub suffix: Option<String>,
    pub options: Vec<String>,
}

impl Shell {
    // -----------------------------------------------------------------------
    // Constructor
    // -----------------------------------------------------------------------

    pub fn new() -> Self {
        let mut shopt = AHashSet::new();
        // bash 5.3 enables these shopt options by default.  Order
        // matches /tmp/bash-decomp/ for reference.
        for opt in &[
            "checkwinsize", "cmdhist", "complete_fullquote", "extquote",
            "force_fignore", "globasciiranges", "globskipdots",
            "hostcomplete", "interactive_comments", "patsub_replacement",
            "progcomp", "promptvars", "sourcepath",
        ] {
            shopt.insert((*opt).to_string());
        }
        // expand_aliases is off by default in non-interactive mode (like bash).
        // It is enabled in main.rs when the shell enters interactive mode.

        let cwd = std::env::current_dir()
            .map(|p| p.to_string_lossy().to_string())
            .unwrap_or_default();

        let mut shell = Shell {
            vars: Variables::new(),
            inherited_env: AHashMap::new(),
            last_status: 0,
            tempenv_names: AHashSet::new(),
            local_option_snapshots: Vec::new(),
            positional_count: 0,
            interactive: false,
            norc: false,
            noprofile: false,
            posix_mode: false,
            is_login_shell: false,
            c_mode: false,
            c_string: None,
            pretty_print_mode: false,
            functions: AHashMap::new(),
            readonly_functions: AHashSet::new(),
            subshell_end_lineno: 0,
            aliases: AHashMap::new(),
            traps: TrapHandler::new(),
            opts: ShellOpts::default(),
            loop_depth: 0,
            break_count: 0,
            continue_count: 0,
            return_flag: false,
            exit_flag: false,
            abort_list_until_newline: false,
            suppress_special_builtin_fatal: false,
            exit_trap_done: false,
            pipestatus: vec![0],
            last_bg_pid: None,
            bg_jobs: Vec::new(),
            next_bg_job_id: 1,
            current_bg_job_id: None,
            previous_bg_job_id: None,
            original_pid: std::process::id(),
            start_time: std::time::Instant::now(),
            shopt,
            dirstack: vec![cwd],
            bash_command: String::new(),
            parent_source_line: String::new(),
            parent_lineno: 0,
            script_name: String::new(),
            suppress_errexit: 0,
            last_was_negated: false,
            funcname_stack: Vec::new(),
            bash_source_stack: Vec::new(),
            bash_lineno_stack: Vec::new(),
            bash_argc_stack: Vec::new(),
            bash_argv_stack: Vec::new(),
            in_debug_trap: false,
            suppress_lineno_update: 0,
            suppress_heredoc_warnings: false,
            pending_heredoc_warnings: Vec::new(),
            expanding_aliases: AHashSet::new(),
            coproc_name: None,
            coproc_pid: None,
            procsub_children: Vec::new(),
            cmdsub_counter: 0,
            getopts_charindex: 0,
            getopts_last_optind: 0,
            restricted: false,
            hash_table: AHashMap::new(),
            hash_hits: AHashMap::new(),
            disabled_builtins: AHashSet::new(),
            history: crate::history::HistoryList::new(),
            remembered_history_file: None,
            current_history_line: None,
            hist_last_subst: None,
            eval_depth: 0,
            source_depth: 0,
            eval_string: None,
            xtrace_fd: None,
            traced_functions: AHashSet::new(),
            in_return_trap: false,
            in_untraced_function: 0,
            suppressed_debug_actions: Vec::new(),
            startup_ignored_signals: AHashSet::new(),
            in_pipeline_or_cmdsub: false,
            xtrace_depth: 1,
            in_signal_trap: false,
            bash_trapsig: 0,
            in_function_trap: false,
            signal_trap_entry_status: 0,
            exec_redirects_permanent: false,
            completions: Vec::new(),
            func_body_open_lineno: 0,
            stack_trace_dirty: true,
            exec_in_place: false,
        };
        // Detect signals that are SIG_IGN at startup.
        // POSIX: signals ignored at shell startup cannot be trapped or reset.
        // We track them internally but do NOT populate the trap table with them
        // (bash does not show them in `trap` or `trap -p` output).
        shell.startup_ignored_signals = Self::detect_startup_ignored_signals();
        shell
    }

    /// Detect which signals are currently SIG_IGN at shell startup.
    /// These cannot be trapped or reset (POSIX: signals ignored at exec cannot be caught).
    fn detect_startup_ignored_signals() -> AHashSet<String> {
        use crate::trap::TrapHandler;
        let mut ignored = AHashSet::new();
        // Check all real signals we know about (use platform-specific numbers).
        let signal_names = &[
            "HUP", "INT", "QUIT", "ILL", "TRAP", "ABRT", "FPE", "KILL",
            "SEGV", "PIPE", "ALRM", "TERM", "USR1", "USR2", "CHLD",
            "CONT", "STOP", "TSTP", "TTIN", "TTOU",
        ];
        for &name in signal_names {
            let num = match TrapHandler::signal_name_to_num(name) {
                Some(n) if n > 0 => n,
                _ => continue,
            };
            // Use sigaction to check if signal is SIG_IGN
            let mut sa: libc::sigaction = unsafe { std::mem::zeroed() };
            let ret = unsafe { libc::sigaction(num, std::ptr::null(), &mut sa) };
            if ret == 0 {
                let handler = sa.sa_sigaction;
                // SIG_IGN = 1 on Linux/macOS
                if handler == libc::SIG_IGN {
                    // Convert name to canonical internal form
                    let internal = TrapHandler::normalise_pub(name);
                    ignored.insert(internal);
                }
            }
        }
        ignored
    }

    /// Error prefix: script name if running a script, otherwise "brash"
    pub fn err_prefix(&self) -> String {
        if !self.script_name.is_empty() {
            self.script_name.clone()
        } else {
            self.get_var("0").unwrap_or_else(|| shell_name().to_string())
        }
    }

    /// Error prefix including "line N:" for use in command-not-found and similar errors.
    /// Bash includes the line number when running a script (non-interactive).
    pub fn err_prefix_with_line(&self) -> String {
        let base = self.err_prefix();
        if !self.interactive {
            // Use get_scalar_str to borrow the LINENO string without cloning.
            let lineno = self.vars.get_scalar_str("LINENO").unwrap_or("0");
            format!("{}: line {}", base, lineno)
        } else {
            base
        }
    }

    /// Error prefix for SYNTAX/PARSER errors.  Unlike runtime errors,
    /// bash 5.3 inserts a literal `-c` between the shell name and
    /// `line N` when running with `-c CMD …` — even when an explicit
    /// ARG0 was given.  Use this for `[[ … ]]` parse errors,
    /// `unexpected EOF` messages, and similar parser-level reports.
    pub fn err_prefix_with_line_for_syntax(&self) -> String {
        if self.c_mode {
            let lineno = self.get_var("LINENO").unwrap_or_else(|| "0".to_string());
            return format!("{}: -c: line {}", shell_name(), lineno);
        }
        self.err_prefix_with_line()
    }

    fn reporting_lineno(&self, lineno: usize) -> usize {
        if lineno > 0 && self.subshell_end_lineno > 0 {
            lineno + 1
        } else {
            lineno
        }
    }

    /// Add a line to the history list, respecting HISTCONTROL and HISTIGNORE.
    pub fn history_add(&mut self, line: String) -> bool {
        if !self.opts.history_facility {
            return false;
        }
        let histcontrol = self.get_var("HISTCONTROL").unwrap_or_default();
        let histignore = self.get_var("HISTIGNORE").unwrap_or_default();
        if crate::history::should_skip(&line, &self.history, &histcontrol, &histignore) {
            return false;
        }
        // erasedups: remove earlier duplicate entries
        if histcontrol.contains("erasedups") {
            self.history.remove_matching_line(&line);
        }
        // Update HISTSIZE from environment
        if let Some(sz) = self.get_var("HISTSIZE") {
            if let Ok(n) = sz.parse::<usize>() {
                self.history.max_size = n;
            }
        }
        self.history.add(line);
        true
    }

    pub fn remember_history_file(&mut self, path: &str) {
        if !path.is_empty() {
            self.remembered_history_file = Some(path.to_string());
        }
    }

    pub fn remembered_history_file(&self) -> Option<&str> {
        self.remembered_history_file.as_deref()
    }

    /// Print an xtrace line to the xtrace file descriptor (BASH_XTRACEFD or stderr).
    /// This is the single choke-point for all xtrace output.
    fn xtrace_print(&self, msg: &str) {
        use std::io::Write;
        if let Some(fd) = self.xtrace_fd {
            // Write to the given file descriptor
            let mut f = unsafe { std::fs::File::from_raw_fd(fd) };
            let _ = write!(f, "{}", msg);
            // Don't close the fd — forget the File so it doesn't drop/close
            std::mem::forget(f);
        } else {
            eprint!("{}", msg);
        }
    }

    /// Emit any pending heredoc-terminated-by-EOF warnings whose
    /// trigger_line is <= the given command line number (so the warning
    /// fires when the command that owns the heredoc executes, matching
    /// bash's parse-time emission).  Also emits all remaining warnings
    /// when `up_to_line` is 0 (e.g. at end of execution).
    fn emit_pending_heredoc_warnings(&mut self, up_to_line: usize) {
        if self.pending_heredoc_warnings.is_empty() {
            return;
        }
        let prefix = self.err_prefix();
        let mut remaining = Vec::new();
        for w in self.pending_heredoc_warnings.drain(..) {
            if up_to_line == 0 || w.trigger_line <= up_to_line {
                match w.kind {
                    crate::lexer::HeredocWarningKind::DelimitedByEof => {
                        if w.comsub {
                            eprintln!(
                                "{}: command substitution: line {}: warning: here-document at line {} delimited by end-of-file (wanted `{}')",
                                prefix, w.eof_line, w.heredoc_start_line, w.wanted
                            );
                        } else {
                            eprintln!(
                                "{}: line {}: warning: here-document at line {} delimited by end-of-file (wanted `{}')",
                                prefix, w.eof_line, w.heredoc_start_line, w.wanted
                            );
                        }
                    }
                    crate::lexer::HeredocWarningKind::CmdSubUnterminated { count } => {
                        let noun = if count == 1 {
                            "here-document"
                        } else {
                            "here-documents"
                        };
                        eprintln!(
                            "{}: line {}: warning: command substitution: {} unterminated {}",
                            prefix, w.eof_line, count, noun
                        );
                    }
                }
            } else {
                remaining.push(w);
            }
        }
        self.pending_heredoc_warnings = remaining;
    }

    fn posix_hint_for_input(&self, input: &str) -> bool {
        self.posix_mode
            || input.contains("set -o posix")
            || input.contains("--posix")
    }

    fn alias_tokenization_aliases(&self, posix_hint: bool) -> Option<AHashMap<String, String>> {
        if self.aliases.is_empty()
            || !(self.shopt.contains("expand_aliases") || posix_hint)
        {
            return None;
        }

        // In POSIX mode, reserved words must not be expanded as aliases.
        if self.posix_mode || posix_hint {
            static RESERVED_WORDS: &[&str] = &[
                "if", "then", "else", "elif", "fi",
                "case", "esac", "for", "select", "while", "until",
                "do", "done", "in", "function", "time",
                "coproc", "!", "{", "}",
            ];
            let mut filtered = self.aliases.clone();
            for rw in RESERVED_WORDS {
                filtered.remove(*rw);
            }
            Some(filtered)
        } else {
            Some(self.aliases.clone())
        }
    }

    fn tokenize_with_runtime_aliases(&self, input: &str) -> crate::lexer::TokenizeResult {
        let posix_hint = self.posix_hint_for_input(input);
        POSIX_MODE.with(|p| p.set(posix_hint));
        if let Some(aliases) = self.alias_tokenization_aliases(posix_hint) {
            crate::lexer::tokenize_with_aliases(input, &aliases)
        } else {
            crate::lexer::tokenize_with_warnings(input)
        }
    }

    fn alias_expansion_active_for_input(&self, input: &str) -> bool {
        let posix_hint = self.posix_hint_for_input(input);
        self.alias_tokenization_aliases(posix_hint).is_some()
    }

    fn has_toplevel_eof_heredoc_warning(&self, input: &str) -> bool {
        if !self.alias_expansion_active_for_input(input) {
            return false;
        }
        let result = self.tokenize_with_runtime_aliases(input);
        result.heredoc_warnings.iter().any(|w| {
            matches!(w.kind, crate::lexer::HeredocWarningKind::DelimitedByEof)
                && !w.comsub
                && w.trigger_line == w.heredoc_start_line
        })
    }

    fn exact_dollar_paren_inner(word: &str) -> Option<&str> {
        // Arithmetic expansions $((…)) are never command substitutions even
        // though they start with `$(` and end with `)`.  Skip them so that
        // `<<` operators inside an arithmetic expression are not mistaken for
        // here-document operators.
        if word.starts_with("$((") {
            return None;
        }
        if word.starts_with("$(") && word.ends_with(')') && word.len() >= 3 {
            Some(&word[2..word.len() - 1])
        } else {
            None
        }
    }

    fn heredoc_command_sub_marker(word: &str) -> Option<String> {
        let inner = Self::exact_dollar_paren_inner(word)?;
        if Self::extract_heredoc_delimiters(inner).is_empty() {
            return None;
        }
        Some(format!("\x00CMDSUB\x00{}\x00", inner))
    }

    fn extract_heredoc_delimiters(input: &str) -> Vec<(String, usize)> {
        Self::extract_heredoc_delimiter_specs(input)
            .into_iter()
            .map(|(delim, line, _)| (delim, line))
            .collect()
    }

    fn extract_heredoc_delimiter_specs(input: &str) -> Vec<(String, usize, bool)> {
        let chars: Vec<char> = input.chars().collect();
        let mut result = Vec::new();
        let mut i = 0usize;
        let mut line = 0usize;

        while i < chars.len() {
            match chars[i] {
                '\n' => {
                    line += 1;
                    i += 1;
                }
                '\\' => {
                    if i + 1 < chars.len() && chars[i + 1] == '\n' {
                        line += 1;
                    }
                    i = (i + 2).min(chars.len());
                }
                '\'' => {
                    i += 1;
                    while i < chars.len() {
                        if chars[i] == '\'' {
                            i += 1;
                            break;
                        }
                        if chars[i] == '\n' {
                            line += 1;
                        }
                        i += 1;
                    }
                }
                '"' => {
                    i += 1;
                    while i < chars.len() {
                        match chars[i] {
                            '"' => {
                                i += 1;
                                break;
                            }
                            '\\' => {
                                if i + 1 < chars.len() && chars[i + 1] == '\n' {
                                    line += 1;
                                }
                                i = (i + 2).min(chars.len());
                            }
                            '\n' => {
                                line += 1;
                                i += 1;
                            }
                            _ => i += 1,
                        }
                    }
                }
                '<' if i + 1 < chars.len()
                    && chars[i + 1] == '<'
                    && chars.get(i + 2).copied() != Some('<') =>
                {
                    i += 2;
                    let strip_tabs = chars.get(i).copied() == Some('-');
                    if strip_tabs {
                        i += 1;
                    }
                    while i < chars.len() && matches!(chars[i], ' ' | '\t') {
                        i += 1;
                    }
                    if let Some(delim) = Self::read_heredoc_delimiter_chars(&chars, &mut i) {
                        let found = Self::heredoc_delimiter_found_after_line(
                            input,
                            line,
                            &delim,
                            strip_tabs,
                        );
                        result.push((delim, line, found));
                    }
                }
                _ => i += 1,
            }
        }

        result
    }

    fn heredoc_delimiter_found_after_line(
        input: &str,
        operator_line: usize,
        delim: &str,
        strip_tabs: bool,
    ) -> bool {
        input
            .split('\n')
            .enumerate()
            .skip(operator_line + 1)
            .any(|(_, line)| {
                let candidate = if strip_tabs {
                    line.trim_start_matches('\t')
                } else {
                    line
                };
                candidate == delim
            })
    }

    fn read_heredoc_delimiter_chars(chars: &[char], i: &mut usize) -> Option<String> {
        let mut delim = String::new();
        match chars.get(*i).copied() {
            Some('\'') => {
                *i += 1;
                while *i < chars.len() && chars[*i] != '\'' {
                    delim.push(chars[*i]);
                    *i += 1;
                }
                if *i < chars.len() {
                    *i += 1;
                }
            }
            Some('"') => {
                *i += 1;
                while *i < chars.len() && chars[*i] != '"' {
                    if chars[*i] == '\\' && *i + 1 < chars.len() {
                        *i += 1;
                    }
                    if *i < chars.len() {
                        delim.push(chars[*i]);
                        *i += 1;
                    }
                }
                if *i < chars.len() {
                    *i += 1;
                }
            }
            Some('\\') => {
                *i += 1;
                while *i < chars.len()
                    && !matches!(chars[*i], ' ' | '\t' | '\n' | ';' | '&' | '|' | '<' | '>' | '(' | ')')
                {
                    if chars[*i] == '\\' && *i + 1 < chars.len() {
                        *i += 1;
                    }
                    delim.push(chars[*i]);
                    *i += 1;
                }
            }
            Some(_) => {
                while *i < chars.len()
                    && !matches!(chars[*i], ' ' | '\t' | '\n' | ';' | '&' | '|' | '<' | '>' | '(' | ')')
                {
                    delim.push(chars[*i]);
                    *i += 1;
                }
            }
            None => {}
        }

        if delim.is_empty() {
            None
        } else {
            Some(delim)
        }
    }

    fn command_sub_heredoc_delimiters_from_tokens(
        tokens: &[crate::lexer::Token],
    ) -> Vec<Vec<(String, usize, bool)>> {
        let mut result = Vec::new();
        for token in tokens {
            match token {
                crate::lexer::Token::CommandSub(word) => {
                    if let Some(inner) = Self::exact_dollar_paren_inner(word) {
                        let delims = Self::extract_heredoc_delimiter_specs(inner);
                        if !delims.is_empty() {
                            result.push(delims);
                        }
                    }
                }
                crate::lexer::Token::Concat(parts) => {
                    for part in parts {
                        if let Some(inner) = Self::exact_dollar_paren_inner(part) {
                            let delims = Self::extract_heredoc_delimiter_specs(inner);
                            if !delims.is_empty() {
                                result.push(delims);
                            }
                        }
                    }
                }
                _ => {}
            }
        }
        result
    }

    fn supplement_cmdsub_heredoc_warnings(result: &mut crate::lexer::TokenizeResult) {
        let cmdsub_delims = Self::command_sub_heredoc_delimiters_from_tokens(&result.tokens);
        if cmdsub_delims.is_empty() {
            return;
        }

        let cmdsub_warnings: Vec<(usize, usize, usize, usize)> = result.heredoc_warnings
            .iter()
            .filter_map(|w| match w.kind {
                crate::lexer::HeredocWarningKind::CmdSubUnterminated { count } => Some((
                    w.trigger_line,
                    w.eof_line,
                    w.heredoc_start_line,
                    count,
                )),
                _ => None,
            })
            .collect();

        let mut delim_index = 0usize;
        for (trigger_line, eof_line, comsub_line, count) in cmdsub_warnings {
            while delim_index < cmdsub_delims.len() {
                let delims = &cmdsub_delims[delim_index];
                delim_index += 1;
                if delims.len() < count {
                    continue;
                }
                let missing_delims: Vec<_> = delims
                    .iter()
                    .filter(|(_, _, found)| !*found)
                    .collect();
                if missing_delims.is_empty() {
                    break;
                }

                let existing = result.heredoc_warnings
                    .iter()
                    .filter(|w| {
                        matches!(w.kind, crate::lexer::HeredocWarningKind::DelimitedByEof)
                            && w.trigger_line == trigger_line
                            && w.eof_line == eof_line
                    })
                    .count();

                for (delim, line_offset, _) in missing_delims
                    .into_iter()
                    .skip(existing)
                    .take(count.saturating_sub(existing))
                {
                    result.heredoc_warnings.push(crate::lexer::HeredocWarning {
                        heredoc_start_line: comsub_line + line_offset,
                        eof_line,
                        wanted: delim.clone(),
                        comsub: false,
                        trigger_line,
                        kind: crate::lexer::HeredocWarningKind::DelimitedByEof,
                    });
                }
                break;
            }
        }
    }

    // -----------------------------------------------------------------------
    // Variable helpers
    // -----------------------------------------------------------------------

    pub fn set_var(&mut self, name: &str, value: &str) {
        // Hot-path: LINENO is set very frequently (every loop iteration in
        // arith for-loops, etc.).  When the new value matches the existing
        // one, skip the readonly/prefix recomputation and the hash-map
        // re-insert entirely.  This is sound because LINENO is not user-
        // readonly and its only side-effect is updating self.vars.error_prefix
        // — which is identical when the value didn't change.
        if name == "LINENO" {
            // Use get_scalar_str to avoid cloning: LINENO is always a scalar.
            if self.vars.get_scalar_str(name).map(|s| s == value).unwrap_or(false) {
                return;
            }
        }
        // BASH_ARGV0 is a special dynamic variable: setting it changes $0
        if name == "BASH_ARGV0" {
            self.vars.set("0", value);
            return;
        }
        // Ignore assignments to read-only / noassign dynamic variables
        if name == "BASHPID" || name == "EPOCHSECONDS" || name == "EPOCHREALTIME"
           || name == "FUNCNAME" || name == "GROUPS" {
            return;
        }
        // BASH_XTRACEFD: reroute xtrace output to a specific FD
        if name == "BASH_XTRACEFD" {
            if value.is_empty() {
                // Unsetting / clearing: revert to stderr
                self.xtrace_fd = None;
            } else {
                match value.trim().parse::<i32>() {
                    Ok(fd) if fd >= 0 => {
                        // Verify the fd is actually open by trying to dup it
                        let test = unsafe { libc::fcntl(fd, libc::F_GETFD) };
                        if test == -1 {
                            // Invalid / not open
                            eprintln!("{}: BASH_XTRACEFD: {}: invalid value for trace file descriptor",
                                self.err_prefix_with_line(), fd);
                            // Don't update xtrace_fd — silently ignore
                        } else {
                            self.xtrace_fd = Some(fd);
                        }
                    }
                    _ => {
                        eprintln!("{}: BASH_XTRACEFD: {}: invalid value for trace file descriptor",
                            self.err_prefix_with_line(), value.trim());
                    }
                }
            }
            // Still store the value in vars
            let prefix = self.err_prefix_with_line();
            self.vars.error_prefix = prefix;
            self.vars.set(name, value);
            return;
        }
        // Setting POSIXLY_CORRECT enables POSIX mode (matches bash behavior)
        if name == "POSIXLY_CORRECT" && !value.is_empty() {
            self.posix_mode = true;
            self.vars.posix_mode = true;
            self.shopt.insert("expand_aliases".to_string());
        }
        if name == "IGNOREEOF" {
            self.opts.ignoreeof = !value.is_empty();
        }
        // Update error prefix for readonly diagnostics.  Check readonly BEFORE
        // computing err_prefix_with_line (which allocates) so the common case
        // (non-readonly variable) pays zero allocation.
        if self.vars.is_readonly(name) {
            let prefix = self.err_prefix_with_line();
            self.vars.error_prefix = prefix;
            let readonly_name = self.vars.resolve_nameref(name).unwrap_or_else(|| name.to_string());
            eprintln!("{}: {}: readonly variable", self.err_prefix_with_line(), readonly_name);
            self.last_status = 1;
            if self.loop_depth > 0 {
                if self.posix_mode {
                    self.exit_flag = true;
                } else {
                    self.break_count = 1;
                }
            } else if !self.interactive {
                self.abort_current_list_until_newline();
            }
            return;
        }
        // Fast path for the overwhelmingly common case: a simple scalar
        // with no special attributes (no nameref, no integer, no case-
        // transform).  try_set_scalar_fast avoids nameref resolution,
        // resolve_nameref String allocation, and the full coercion chain.
        // Exclude locale variables (they need sync_process_locale), LINENO
        // (needs error_prefix refresh), and allexport mode (needs export flag).
        if !name.contains('[') && name != "LINENO" && !self.opts.allexport
            && !matches!(name, "LC_ALL" | "LC_CTYPE" | "LANG")
        {
            if self.vars.try_set_scalar_fast(name, value) {
                return;
            }
        }
        // Not readonly: still keep error_prefix fresh so subsequent calls
        // (e.g. nameref diagnostics inside vars.set) see the right line.
        let prefix = self.err_prefix_with_line();
        self.vars.error_prefix = prefix;
        self.vars.set(name, value);
        // If we just set LINENO, refresh error_prefix so that subsequent
        // argument expansions (e.g. nameref circular-reference warnings emitted
        // inside vars.set / resolve_nameref) use the correct source line.
        if name == "LINENO" {
            let prefix = self.err_prefix_with_line();
            self.vars.error_prefix = prefix;
        }
        if self.opts.allexport {
            self.vars.export(name);
        }
    }

    /// Returns a variable value, handling all special bash variables.
    pub fn get_var(&self, name: &str) -> Option<String> {
        match name {
            "?" => Some(self.last_status.to_string()),
            "$" => Some(self.original_pid.to_string()),
            "!" => self.last_bg_pid.map(|p| p.to_string()),
            "BASHPID" => {
                // Always return the current process ID (changes in subshells)
                Some(std::process::id().to_string())
            }
            "BASH_ARGV0" => {
                // BASH_ARGV0 reflects $0
                self.vars.get("0").or_else(|| Some(String::new()))
            }
            "BASH_COMMAND" => {
                Some(self.bash_command.clone())
            }
            "SECONDS" => Some(self.start_time.elapsed().as_secs().to_string()),
            "EPOCHSECONDS" => {
                let epoch = std::time::SystemTime::now()
                    .duration_since(std::time::UNIX_EPOCH)
                    .unwrap_or_default()
                    .as_secs();
                Some(epoch.to_string())
            }
            "EPOCHREALTIME" => {
                let dur = std::time::SystemTime::now()
                    .duration_since(std::time::UNIX_EPOCH)
                    .unwrap_or_default();
                Some(format!("{}.{:06}", dur.as_secs(), dur.subsec_micros()))
            }
            "LINENO" => self.vars.get("LINENO").or_else(|| Some("0".to_string())),
            "PIPESTATUS" => {
                // Return as space-separated for simple use; array handling is in expand
                Some(
                    self.pipestatus
                        .iter()
                        .map(|s| s.to_string())
                        .collect::<Vec<_>>()
                        .join(" "),
                )
            }
            "PWD" => {
                // Prefer the logical $PWD stored in the variable table (set by cd/pushd);
                // fall back to the physical current directory only if PWD was never set.
                self.vars.get("PWD")
                    .or_else(|| std::env::current_dir().ok().map(|p| p.to_string_lossy().to_string()))
            }
            _ => self.vars.get(name),
        }
    }

    pub fn export_var(&mut self, name: &str, value: &str) {
        // Route through `set_var` so the dynamic-variable hooks
        // (BASH_ARGV0 → $0, BASH_XTRACEFD, RANDOM seed, etc.) fire.
        self.set_var(name, value);
        self.vars.export(name);
    }

    pub fn abort_current_list_until_newline(&mut self) {
        self.abort_list_until_newline = true;
        if self.last_status == 0 {
            self.last_status = 1;
        }
    }

    fn reset_bg_job_ids_if_empty(&mut self) {
        if self.bg_jobs.is_empty() {
            self.next_bg_job_id = 1;
            self.current_bg_job_id = None;
            self.previous_bg_job_id = None;
        }
    }

    fn recompute_background_job_markers(&mut self) {
        if self.bg_jobs.is_empty() {
            self.current_bg_job_id = None;
            self.previous_bg_job_id = None;
            return;
        }

        let current = self
            .current_bg_job_id
            .filter(|job_id| self.bg_jobs.iter().any(|job| job.job_id == *job_id))
            .or_else(|| {
                self.bg_jobs
                    .iter()
                    .rev()
                    .find(|job| job.is_stopped())
                    .or_else(|| self.bg_jobs.last())
                    .map(|job| job.job_id)
            });
        let previous = self
            .previous_bg_job_id
            .filter(|job_id| {
                Some(*job_id) != current && self.bg_jobs.iter().any(|job| job.job_id == *job_id)
            })
            .or_else(|| {
                self.bg_jobs
                    .iter()
                    .rev()
                    .find(|job| Some(job.job_id) != current)
                    .map(|job| job.job_id)
            });

        self.current_bg_job_id = current;
        self.previous_bg_job_id = previous;
    }

    fn select_background_job(&mut self, job_id: usize) {
        if !self.bg_jobs.iter().any(|job| job.job_id == job_id) {
            self.recompute_background_job_markers();
            return;
        }
        if self.current_bg_job_id != Some(job_id) {
            self.previous_bg_job_id = self.current_bg_job_id;
            self.current_bg_job_id = Some(job_id);
        }
        if self.previous_bg_job_id == self.current_bg_job_id {
            self.previous_bg_job_id = self
                .bg_jobs
                .iter()
                .rev()
                .find(|job| Some(job.job_id) != self.current_bg_job_id)
                .map(|job| job.job_id);
        }
    }

    fn set_background_job_state(&mut self, pid: i32, state: BackgroundJobState) -> bool {
        let mut selected = None;
        let mut updated = false;
        if let Some(job) = self.bg_jobs.iter_mut().find(|job| job.pid == pid) {
            job.state = state.clone();
            if matches!(state, BackgroundJobState::Stopped(_)) {
                selected = Some(job.job_id);
            }
            updated = true;
        }
        if let Some(job_id) = selected {
            self.select_background_job(job_id);
        }
        updated
    }

    pub fn record_background_job_pub(
        &mut self,
        pid: i32,
        command: String,
        started_without_job_control: bool,
    ) {
        self.refresh_background_jobs_pub();
        let command = command.split_whitespace().collect::<Vec<_>>().join(" ");
        if self.bg_jobs.iter().any(|job| job.pid == pid) {
            self.last_bg_pid = Some(pid as u32);
            self.vars.set("!", &pid.to_string());
            return;
        }
        let job_id = self.next_bg_job_id;
        self.next_bg_job_id += 1;
        self.bg_jobs.push(BackgroundJobInfo {
            job_id,
            pid,
            command,
            state: BackgroundJobState::Running,
            started_without_job_control,
        });
        self.select_background_job(job_id);
        self.last_bg_pid = Some(pid as u32);
        self.vars.set("!", &pid.to_string());
    }

    pub fn refresh_background_jobs_pub(&mut self) {
        loop {
            // The trailing `Ok(_) => {}` arm catches the ptrace-only WaitStatus
            // variants (PtraceEvent, PtraceSyscall) that nix exposes only when
            // the `ptrace` cargo feature is on.  We don't enable that feature,
            // so the arm is unreachable on every target we currently build for —
            // we keep it for forward compatibility if nix ever adds more
            // variants.
            #[allow(unreachable_patterns)]
            match waitpid(
                Pid::from_raw(-1),
                Some(
                    WaitPidFlag::WNOHANG
                        | WaitPidFlag::WUNTRACED
                        | WaitPidFlag::WCONTINUED,
                ),
            ) {
                Ok(WaitStatus::Exited(pid, status)) => {
                    let _ = self.set_background_job_state(
                        pid.as_raw(),
                        BackgroundJobState::Done(status),
                    );
                }
                Ok(WaitStatus::Signaled(pid, sig, _)) => {
                    let _ = self.set_background_job_state(
                        pid.as_raw(),
                        BackgroundJobState::Signaled(sig as i32),
                    );
                }
                Ok(WaitStatus::Stopped(pid, sig)) => {
                    let _ = self.set_background_job_state(
                        pid.as_raw(),
                        BackgroundJobState::Stopped(sig as i32),
                    );
                }
                Ok(WaitStatus::Continued(pid)) => {
                    let _ = self.set_background_job_state(
                        pid.as_raw(),
                        BackgroundJobState::Running,
                    );
                }
                Ok(WaitStatus::StillAlive) => break,
                Err(nix::errno::Errno::ECHILD) => break,
                Err(nix::errno::Errno::EINTR) => {
                    self.check_pending_signals();
                    continue;
                }
                Err(_) => break,
                // Linux-only ptrace variants — ignore.
                Ok(_) => {}
            }
        }
        self.recompute_background_job_markers();
        self.reset_bg_job_ids_if_empty();
    }

    pub fn remove_background_job_pid_pub(&mut self, pid: i32) {
        self.bg_jobs.retain(|job| job.pid != pid);
        self.recompute_background_job_markers();
        self.reset_bg_job_ids_if_empty();
        // Clean up coproc variables when the coproc child exits.
        self.cleanup_coproc_on_exit_pub(pid);
    }

    pub fn remove_background_job_by_id_pub(&mut self, job_id: usize) -> bool {
        let before = self.bg_jobs.len();
        self.bg_jobs.retain(|job| job.job_id != job_id);
        self.recompute_background_job_markers();
        self.reset_bg_job_ids_if_empty();
        self.bg_jobs.len() != before
    }

    pub fn clear_background_jobs_pub(&mut self, running_only: bool) {
        self.refresh_background_jobs_pub();
        if running_only {
            self.bg_jobs.retain(|job| !job.is_running());
        } else {
            self.bg_jobs.clear();
        }
        self.recompute_background_job_markers();
        self.reset_bg_job_ids_if_empty();
    }

    pub fn background_job_pids_pub(&mut self) -> Vec<i32> {
        self.refresh_background_jobs_pub();
        self.bg_jobs
            .iter()
            .filter(|job| !job.is_completed())
            .map(|job| job.pid)
            .collect()
    }

    pub fn background_jobs_pub(&mut self) -> Vec<BackgroundJobInfo> {
        self.refresh_background_jobs_pub();
        self.bg_jobs.clone()
    }

    pub fn get_background_job_pub(&mut self, job_id: usize) -> Option<BackgroundJobInfo> {
        self.refresh_background_jobs_pub();
        self.bg_jobs.iter().find(|job| job.job_id == job_id).cloned()
    }

    pub fn get_background_job_by_pid_pub(&mut self, pid: i32) -> Option<BackgroundJobInfo> {
        self.refresh_background_jobs_pub();
        self.bg_jobs.iter().find(|job| job.pid == pid).cloned()
    }

    pub fn get_current_background_job_pub(&mut self) -> Option<BackgroundJobInfo> {
        self.refresh_background_jobs_pub();
        self.current_bg_job_id
            .and_then(|job_id| self.bg_jobs.iter().find(|job| job.job_id == job_id).cloned())
    }

    pub fn get_previous_background_job_pub(&mut self) -> Option<BackgroundJobInfo> {
        self.refresh_background_jobs_pub();
        self.previous_bg_job_id
            .and_then(|job_id| self.bg_jobs.iter().find(|job| job.job_id == job_id).cloned())
    }

    pub fn current_background_job_id_pub(&mut self) -> Option<usize> {
        self.refresh_background_jobs_pub();
        self.current_bg_job_id
    }

    pub fn previous_background_job_id_pub(&mut self) -> Option<usize> {
        self.refresh_background_jobs_pub();
        self.previous_bg_job_id
    }

    pub fn in_forked_subshell_pub(&self) -> bool {
        std::process::id() != self.original_pid
    }

    pub fn last_trap_signal_pub(&self) -> i32 {
        self.bash_trapsig
    }

    pub fn select_background_job_pub(&mut self, job_id: usize) -> bool {
        self.refresh_background_jobs_pub();
        if self.bg_jobs.iter().any(|job| job.job_id == job_id) {
            self.select_background_job(job_id);
            true
        } else {
            false
        }
    }

    pub fn mark_background_job_running_pub(&mut self, pid: i32) -> bool {
        self.set_background_job_state(pid, BackgroundJobState::Running)
    }

    pub fn mark_background_job_stopped_pub(&mut self, pid: i32, sig: i32) -> bool {
        self.set_background_job_state(pid, BackgroundJobState::Stopped(sig))
    }

    pub fn mark_background_job_done_pub(&mut self, pid: i32, status: i32) -> bool {
        self.set_background_job_state(pid, BackgroundJobState::Done(status))
    }

    pub fn mark_background_job_signaled_pub(&mut self, pid: i32, sig: i32) -> bool {
        self.set_background_job_state(pid, BackgroundJobState::Signaled(sig))
    }

    pub fn resolve_job_spec_pub(&mut self, spec: &str) -> Option<BackgroundJobInfo> {
        self.refresh_background_jobs_pub();
        let body = spec.strip_prefix('%')?;
        if body.is_empty() || body == "+" || body == "%" {
            return self.get_current_background_job_pub();
        }
        if body == "-" {
            return self.get_previous_background_job_pub();
        }
        if let Ok(job_id) = body.parse::<usize>() {
            return self.get_background_job_pub(job_id);
        }
        if let Some(needle) = body.strip_prefix('?') {
            return self
                .bg_jobs
                .iter()
                .rev()
                .find(|job| job.command.contains(needle))
                .cloned();
        }
        self.bg_jobs
            .iter()
            .rev()
            .find(|job| job.command.starts_with(body))
            .cloned()
    }

    /// Handle `name+=value` (append assignment).
    /// For string variables: concatenate.
    /// For integer variables: arithmetic addition.
    /// For arrays: append element.
    pub fn append_var(&mut self, name: &str, value: &str) -> bool {
        fn eval_append_operand(shell: &Shell, expr: &str) -> Result<i64, ()> {
            let trimmed = expr.trim();
            if trimmed.is_empty() {
                return Ok(0);
            }
            match crate::arithmetic::eval_expr(trimmed, &shell.vars) {
                Ok(n) => Ok(n),
                Err(msg) => {
                    let display = if msg.contains("(error token is") {
                        msg
                    } else if msg == "arithmetic syntax error: operand expected"
                        || msg.contains("arithmetic syntax error: operand expected")
                    {
                        Shell::synthesize_arith_error_token(trimmed, &msg)
                    } else {
                        msg
                    };
                    eprintln!("{}: {}: {}", shell.err_prefix_with_line(), trimmed, display);
                    Err(())
                }
            }
        }
        if self.vars.is_local_self_nameref_exact(name) {
            let prefix = self.err_prefix_with_line();
            eprintln!("{}: warning: {}: maximum nameref depth (8) exceeded",
                prefix, name);
            let current = self.vars.with_local_binding_hidden(name, |vars| {
                vars.get(name).unwrap_or_default()
            }).unwrap_or_default();
            let new_val = format!("{}{}", current, value);
            let _ = self.vars.with_local_binding_hidden(name, |vars| {
                vars.error_prefix = prefix.clone();
                vars.set(name, &new_val);
            });
            return true;
        }
        let raw_is_integer = self.vars.get_entry_is_integer_raw(name);
        if let Some(target) = self.vars.resolve_nameref(name) {
            if target != name {
                if let Some(bracket_pos) = target.find('[') {
                    if target.ends_with(']') {
                        let base = &target[..bracket_pos];
                        let idx_str = &target[bracket_pos + 1..target.len().saturating_sub(1)];
                        if self.vars.is_assoc(base) {
                            let key = crate::expand::expand_assoc_subscript_key_pub(idx_str, &mut self.vars);
                            let current = self.vars.get_assoc(base, &key).unwrap_or_default();
                            let is_integer = raw_is_integer || self.vars.get_entry_is_integer(base);
                            let new_val = if is_integer {
                                let a = match eval_append_operand(self, &current) {
                                    Ok(n) => n,
                                    Err(()) => return false,
                                };
                                let b = match eval_append_operand(self, value) {
                                    Ok(n) => n,
                                    Err(()) => return false,
                                };
                                (a + b).to_string()
                            } else {
                                format!("{}{}", current, value)
                            };
                            self.vars.set_assoc(base, &key, &new_val);
                            return true;
                        }
                        let idx_expanded = expand::expand_arith_vars(idx_str, &mut self.vars);
                        if let Ok(idx) = crate::arithmetic::eval_expr_mut(&idx_expanded, &mut self.vars) {
                            let resolved = if idx < 0 {
                                match self.vars.array_max_index(base) {
                                    Some(max_idx) => {
                                        let len = (max_idx + 1) as i64;
                                        let real = len + idx;
                                        if real < 0 {
                                            eprintln!("{}: {}[{}]: bad array subscript",
                                                self.err_prefix_with_line(), base, idx_str);
                                            return false;
                                        }
                                        real as usize
                                    }
                                    None => {
                                        eprintln!("{}: {}[{}]: bad array subscript",
                                            self.err_prefix_with_line(), base, idx_str);
                                        return false;
                                    }
                                }
                            } else {
                                idx as usize
                            };
                            let current = self.vars.get_array_element(base, resolved).unwrap_or_default();
                            let is_integer = raw_is_integer || self.vars.get_entry_is_integer(base);
                            let new_val = if is_integer {
                                let cur_num = match eval_append_operand(self, &current) {
                                    Ok(n) => n,
                                    Err(()) => return false,
                                };
                                let add_num = match eval_append_operand(self, value) {
                                    Ok(n) => n,
                                    Err(()) => return false,
                                };
                                (cur_num + add_num).to_string()
                            } else {
                                format!("{}{}", current, value)
                            };
                            self.vars.set_array_element_raw(base, resolved, &new_val);
                            return true;
                        }
                    }
                }
            }
        }
        // Handle array element: name[idx]+=value
        if let Some(bracket_pos) = name.find('[') {
            let base = &name[..bracket_pos];
            let idx_str = &name[bracket_pos + 1..name.len().saturating_sub(1)];
            // Associative array: key is a string, not an arithmetic
            // expression.  Expand parameter references then use the
            // result verbatim.
            if self.vars.is_assoc(base) {
                let key = crate::expand::expand_assoc_subscript_key_pub(idx_str, &mut self.vars);
                let is_integer = raw_is_integer || self.vars.get_entry_is_integer(base);
                let current = self.vars.get_assoc(base, &key).unwrap_or_default();
                let new_val = if is_integer {
                    let a = match eval_append_operand(self, &current) {
                        Ok(n) => n,
                        Err(()) => return false,
                    };
                    let b = match eval_append_operand(self, value) {
                        Ok(n) => n,
                        Err(()) => return false,
                    };
                    (a + b).to_string()
                } else {
                    format!("{}{}", current, value)
                };
                self.vars.set_assoc(base, &key, &new_val);
                return true;
            }
            let idx_expanded = expand::expand_arith_vars(idx_str, &mut self.vars);
            if let Ok(idx) = crate::arithmetic::eval_expr_mut(&idx_expanded, &mut self.vars) {
                let resolved = if idx < 0 {
                    match self.vars.array_max_index(base) {
                        Some(max_idx) => {
                            let len = (max_idx + 1) as i64;
                            let real = len + idx;
                            if real < 0 {
                                eprintln!("{}: {}[{}]: bad array subscript",
                                    self.err_prefix_with_line(), base, idx_str);
                                return false;
                            }
                            real as usize
                        }
                        None => {
                            eprintln!("{}: {}[{}]: bad array subscript",
                                self.err_prefix_with_line(), base, idx_str);
                            return false;
                        }
                    }
                } else {
                    idx as usize
                };
                let is_integer = raw_is_integer || self.vars.get_entry_is_integer(base);
                let current = self.vars.get_array_element(base, resolved)
                    .unwrap_or_default();
                let new_val = if is_integer {
                    let cur_num = match eval_append_operand(self, &current) {
                        Ok(n) => n,
                        Err(()) => return false,
                    };
                    let add_num = match eval_append_operand(self, value) {
                        Ok(n) => n,
                        Err(()) => return false,
                    };
                    (cur_num + add_num).to_string()
                } else {
                    format!("{}{}", current, value)
                };
                self.vars.set_array_element_raw(base, resolved, &new_val);
            }
            return true;
        }

        // For scalar integer variables, do arithmetic addition.
        // For scalar non-integer variables, concatenate.
        // For integer arrays (no subscript), add to element [0].
        // For associative arrays (no subscript), set key "0".
        let is_integer = raw_is_integer || self.vars.get_entry_is_integer(name);
        if self.vars.is_assoc(name) {
            // Scalar += on assoc array: set key "0" to (old_val + new_val or concat)
            let current = self.vars.get_assoc(name, "0").unwrap_or_default();
            let new_val = if is_integer {
                let a = match eval_append_operand(self, &current) {
                    Ok(n) => n,
                    Err(()) => return false,
                };
                let b = match eval_append_operand(self, value) {
                    Ok(n) => n,
                    Err(()) => return false,
                };
                (a + b).to_string()
            } else {
                format!("{}{}", current, value)
            };
            self.vars.set_assoc(name, "0", &new_val);
            return true;
        }
        let is_integer_array = is_integer && self.vars.is_array(name);
        if is_integer_array {
            // Scalar += on an integer array: add to element [0]
            let current = self.vars.get_array_element(name, 0)
                .unwrap_or_default();
            let cur_num = match eval_append_operand(self, &current) {
                Ok(n) => n,
                Err(()) => return false,
            };
            let add_num = match eval_append_operand(self, value) {
                Ok(n) => n,
                Err(()) => return false,
            };
            let new_val = (cur_num + add_num).to_string();
            self.vars.set_array_element_raw(name, 0, &new_val);
            return true;
        }
        let current = self.get_var(name).unwrap_or_default();
        let new_val = if is_integer {
            // Arithmetic addition: "old + new"
            let cur_num = match eval_append_operand(self, &current) {
                Ok(n) => n,
                Err(()) => return false,
            };
            let add_num = match eval_append_operand(self, value) {
                Ok(n) => n,
                Err(()) => return false,
            };
            (cur_num + add_num).to_string()
        } else {
            // String concatenation
            format!("{}{}", current, value)
        };
        self.set_var(name, &new_val);
        true
    }

    fn normalize_arith_error_display(expr: &str) -> String {
        let chars: Vec<char> = expr.chars().collect();
        let mut out = String::new();
        let mut i = 0usize;
        while i < chars.len() {
            if chars[i] == '\\' {
                let mut j = i;
                while j < chars.len() && chars[j] == '\\' {
                    j += 1;
                }
                if j < chars.len() && matches!(chars[j], '"' | '\'' | '\\') {
                    out.push(chars[j]);
                    i = j + 1;
                    continue;
                }
            }
            out.push(chars[i]);
            i += 1;
        }
        out
    }

    fn normalize_arith_error_expr(expr: &str) -> String {
        let chars: Vec<char> = expr.chars().collect();
        let mut out = String::new();
        let mut i = 0usize;
        while i < chars.len() {
            if chars[i] == '\\' {
                out.push(chars[i]);
                if i + 1 < chars.len() {
                    out.push(chars[i + 1]);
                    i += 2;
                } else {
                    i += 1;
                }
                continue;
            }
            if chars[i] == '"' {
                i += 1;
                while i < chars.len() {
                    if chars[i] == '\\' && i + 1 < chars.len() {
                        out.push(chars[i + 1]);
                        i += 2;
                        continue;
                    }
                    if chars[i] == '"' {
                        i += 1;
                        break;
                    }
                    out.push(chars[i]);
                    i += 1;
                }
                continue;
            }
            out.push(chars[i]);
            i += 1;
        }
        out
    }

    fn print_assignment_arith_error(&mut self, value: &str) {
        if let Some(payload) = Self::extract_arith_error(value) {
            let (expr, msg) = Self::split_arith_payload(&payload);
            if expr.is_empty() {
                eprintln!("{}: {}", self.err_prefix_with_line(), msg);
            } else {
                let normalized = Self::normalize_arith_error_display(&expr);
                let err_msg = if msg.contains("(error token is") {
                    msg
                } else {
                    Self::synthesize_arith_error_token(&normalized, &msg)
                };
                eprintln!("{}: {}: {}", self.err_prefix_with_line(), normalized.trim_start(), err_msg);
            }
        }
    }

    fn expand_live_nofork_double_quoted_word(&mut self, token: &str) -> Option<String> {
        if token.len() < 2 || !token.starts_with('"') || !token.ends_with('"') {
            return None;
        }
        if token.contains("$@")
            || token.contains("${@}")
            || token.contains("[@]")
            || token.contains('\u{FFFF}')
            || token.contains('\u{FFFE}')
        {
            return None;
        }

        let chars: Vec<char> = token.chars().collect();
        let end_limit = chars.len().saturating_sub(1);
        let mut i = 1usize;
        let mut seg_start = 1usize;
        let mut out = String::new();
        let mut saw_live = false;

        while i < end_limit {
            match chars[i] {
                '\\' => {
                    i += 1;
                    if i < end_limit {
                        i += 1;
                    }
                }
                '`' => {
                    let (_, advance) = expand::collect_backtick_pub(&chars, i + 1);
                    i += 1 + advance;
                }
                '$' if i + 1 < end_limit => match chars[i + 1] {
                    '\'' => {
                        i += 2;
                        while i < end_limit {
                            match chars[i] {
                                '\\' if i + 1 < end_limit => i += 2,
                                '\'' => {
                                    i += 1;
                                    break;
                                }
                                _ => i += 1,
                            }
                        }
                    }
                    '(' => {
                        let (_, advance, _) = expand::collect_paren_cmd_pub(&chars, i + 2);
                        i += 2 + advance;
                    }
                    '{' => {
                        let live = chars
                            .get(i + 2)
                            .copied()
                            .map(|c| c.is_whitespace() || c == '|')
                            .unwrap_or(false);
                        let advance = if live {
                            saw_live = true;
                            if seg_start < i {
                                let prefix: String = chars[seg_start..i].iter().collect();
                                let wrapped = format!("\"{}\"", prefix);
                                let expanded = expand::expand_word_nosplit(&wrapped, &mut self.vars);
                                let resolved =
                                    self.resolve_cmdsubs(&expanded).replace("\x00EMPTY_AT\x00", "");
                                out.push_str(&resolved);
                            }
                            let (_, advance, _) = expand::collect_brace_cmdsub_body_pub(&chars, i + 2);
                            let seg_end = i + 2 + advance;
                            let segment: String = chars[i..seg_end].iter().collect();
                            let wrapped = format!("\"{}\"", segment);
                            let expanded = expand::expand_word_nosplit(&wrapped, &mut self.vars);
                            let resolved =
                                self.resolve_cmdsubs(&expanded).replace("\x00EMPTY_AT\x00", "");
                            out.push_str(&resolved);
                            seg_start = seg_end;
                            i = seg_end;
                            continue;
                        } else {
                            let (_, advance, _) = expand::collect_brace_body_pub(&chars, i + 2, true);
                            advance
                        };
                        i += 2 + advance;
                    }
                    _ => i += 1,
                },
                _ => i += 1,
            }
        }

        if !saw_live {
            return None;
        }

        if seg_start < end_limit {
            let suffix: String = chars[seg_start..end_limit].iter().collect();
            let wrapped = format!("\"{}\"", suffix);
            let expanded = expand::expand_word_nosplit(&wrapped, &mut self.vars);
            let resolved = self.resolve_cmdsubs(&expanded).replace("\x00EMPTY_AT\x00", "");
            out.push_str(&resolved);
        }
        Some(out)
    }

    /// Assign to a variable, handling `NAME[idx]=value` array element syntax.
    pub fn assign_var_or_element_pub(&mut self, name: &str, value: &str) {
        if let Some(bracket_pos) = name.find('[') {
            if name.ends_with(']') {
                let base = &name[..bracket_pos];
                let idx_str = &name[bracket_pos + 1..name.len().saturating_sub(1)];
                if !base.is_empty() && self.vars.is_nameref(base) {
                    let raw_target = self.vars.get_nameref_target(base)
                        .or_else(|| self.vars.get_raw_scalar(base))
                        .unwrap_or_default();
                    if raw_target.is_empty()
                        || !crate::vars::Variables::is_valid_nameref_target(&raw_target)
                    {
                        eprintln!("{}: `{}': not a valid identifier",
                            self.err_prefix_with_line(), raw_target);
                        return;
                    }
                    if parse_subscripted_name_pub(&raw_target).is_some() {
                        eprintln!("{}: `{}': not a valid identifier",
                            self.err_prefix_with_line(), raw_target);
                        return;
                    }
                }
                if !base.is_empty() && !self.vars.is_assoc(base) {
                    if idx_str.is_empty() {
                        eprintln!("{}: {}[]: bad array subscript",
                            self.err_prefix_with_line(), base);
                        return;
                    }
                    if idx_str == "*" || idx_str == "@" {
                        eprintln!("{}: {}[{}]: bad array subscript",
                            self.err_prefix_with_line(), base, idx_str);
                        return;
                    }
                    if idx_str.contains("$(") || idx_str.contains('"')
                        || idx_str.contains('\'') || idx_str.contains(' ')
                        || idx_str.contains('\t')
                    {
                        match crate::arithmetic::eval_expr_mut(idx_str, &mut self.vars) {
                            Ok(idx) => {
                                let resolved = if idx < 0 {
                                    match self.vars.array_max_index(base) {
                                        Some(max_idx) => {
                                            let len = (max_idx + 1) as i64;
                                            let real = len + idx;
                                            if real < 0 {
                                                eprintln!("{}: {}[{}]: bad array subscript",
                                                    self.err_prefix_with_line(), base, idx_str);
                                                return;
                                            }
                                            real as usize
                                        }
                                        None => {
                                            eprintln!("{}: {}[{}]: bad array subscript",
                                                self.err_prefix_with_line(), base, idx_str);
                                            return;
                                        }
                                    }
                                } else {
                                    idx as usize
                                };
                                self.vars.set_array_element(base, resolved, value);
                                return;
                            }
                            Err(err) => {
                                eprintln!("{}: {}: {}",
                                    self.err_prefix_with_line(), idx_str.trim_start(), err);
                                return;
                            }
                        }
                    }
                }
            }
        }
        self.assign_var_or_element(name, value);
    }

    pub fn assign_var_or_element(&mut self, name: &str, value: &str) {
        // For simple scalar names (no `[`) the error-prefix is only needed if
        // the variable turns out to be readonly (rare).  We defer computing it
        // until then to avoid the String allocation on every hot-path call.
        // For subscripted names we compute it upfront because set_array_element
        // may need it for diagnostics.
        if let Some(bracket_pos) = name.find('[') {
            // Compute the error-prefix now for array-element diagnostics.
            let prefix = self.err_prefix_with_line();
            self.vars.error_prefix = prefix;
            if name.ends_with(']') {
                let base = &name[..bracket_pos];
                if !base.is_empty() && self.vars.is_nameref(base) {
                    let raw_target = self.vars.get_nameref_target(base)
                        .or_else(|| self.vars.get_raw_scalar(base))
                        .unwrap_or_default();
                    if raw_target.is_empty()
                        || !crate::vars::Variables::is_valid_nameref_target(&raw_target)
                    {
                        eprintln!("{}: `{}': not a valid identifier", self.err_prefix_with_line(), raw_target);
                        self.last_status = 1;
                        return;
                    }
                    if parse_subscripted_name_pub(&raw_target).is_some() {
                        eprintln!("{}: `{}': not a valid identifier", self.err_prefix_with_line(), raw_target);
                        self.last_status = 1;
                        return;
                    }
                }
            }
        }
        // Subscripted assignment with a compound-array value (that
        // starts with \x00ARRAY\x00 from the parser) is an error:
        // `arr[idx]=(list)` means "assign a list to one element",
        // which bash rejects with "cannot assign list to array member".
        if let Some(bracket_pos) = name.find('[') {
            let base = &name[..bracket_pos];
            if value.starts_with("\x00ARRAY\x00") {
                eprintln!("{}: {}: cannot assign list to array member",
                    self.err_prefix_with_line(), name);
                self.last_status = 1;
                return;
            }
            let _ = base;
        }
        if let Some(bracket_pos) = name.find('[') {
            let base = &name[..bracket_pos];
            // Noassign variables: silently ignore
            if base == "GROUPS" || base == "FUNCNAME"
               || base == "BASH_VERSINFO" {
                return;
            }
            let idx_str = &name[bracket_pos + 1..name.len().saturating_sub(1)];
            // DIRSTACK: allow assignment to modify the internal dirstack
            if base == "DIRSTACK" {
                if let Ok(n) = idx_str.parse::<usize>() {
                    if n < self.dirstack.len() {
                        self.dirstack[n] = value.to_string();
                    }
                }
                return;
            }
            // BASH_ALIASES: special associative array mirroring the alias table
            if base == "BASH_ALIASES" {
                let key = crate::expand::remove_quotes(idx_str);
                fn bad_alias_ch(c: char) -> bool {
                    matches!(c, '"'|'$'|'&'|'\''|'('|')'|'/'|';'|'<'|'>'|'\\'|'`'|'|'|' '|'\t'|'\n')
                }
                if key.is_empty() || key.chars().any(bad_alias_ch) {
                    eprintln!("{}: `{}': invalid alias name", self.err_prefix_with_line(), key);
                } else {
                    self.aliases.insert(key, value.to_string());
                }
                return;
            }
            if base == "BASH_CMDS" {
                let key = crate::expand::remove_quotes(idx_str);
                if !key.is_empty() {
                    self.hash_table.insert(key, value.to_string());
                }
                return;
            }
            // Bash checks subscript validity BEFORE the readonly check,
            // so `readonly c[100]; c[-2]=4` reports
            // "c[-2]: bad array subscript" rather than
            // "c: readonly variable".  Pre-compute whether the subscript
            // would fail so we emit the right error.
            // Single scope-walk to get both is_assoc and is_readonly.
            let (is_assoc, is_readonly_flag) = self.vars.assoc_readonly_flags(base);
            let bad_subscript: bool = if idx_str.is_empty() {
                true
            } else if !is_assoc && (idx_str == "*" || idx_str == "@") {
                true
            } else if !is_assoc {
                let idx_expanded = if idx_str.trim_start().starts_with("$((")
                    && idx_str.trim_end().ends_with("))")
                {
                    self.expand_word_nosplit(idx_str)
                } else {
                    crate::expand::expand_index_subscript_word_pub(idx_str, &mut self.vars)
                };
                match crate::arithmetic::eval_expr(&idx_expanded, &self.vars) {
                    Ok(idx) if idx < 0 => {
                        match self.vars.array_max_index(base) {
                            Some(max_idx) => {
                                let real = (max_idx as i64 + 1) + idx;
                                real < 0
                            }
                            None => true,
                        }
                    }
                    Ok(_) => false,
                    Err(_) => true,
                }
            } else {
                false
            };
            if !bad_subscript && is_readonly_flag {
                eprintln!("{}: {}: readonly variable",
                    self.err_prefix_with_line(), base);
                self.last_status = 1;
                if self.loop_depth > 0 {
                    if self.posix_mode {
                        self.exit_flag = true;
                    } else {
                        self.break_count = 1;
                    }
                } else if !self.interactive {
                    self.abort_current_list_until_newline();
                }
                return;
            }
            if is_assoc {
                // Associative array: key is a string.  The subscript
                // undergoes full parameter expansion like a
                // double-quoted word, and the outer `"..."`/`'...'`
                // around the whole subscript is stripped (bash treats
                // the key as "the word inside the brackets").
                //
                // Tilde expansion applies to LITERAL `~` in the
                // source — `A[~]=42` → `A[/home/user]=42` — but
                // NOT to `~` that comes out of `\$var` expansion
                // (bash doesn't re-expand after `\$`).
                let key = crate::expand::expand_assoc_subscript_key_pub(idx_str, &mut self.vars);
                self.vars.set_assoc(base, &key, value);
            } else {
                // Indexed array: evaluate as arithmetic expression.
                // Bash allows negative subscripts when the array already
                // has set elements: `arr[-1]` refers to the last element
                // (highest assigned index).  When the array is empty or
                // unset, a negative subscript is an error.
                // Empty subscript `b[]=…` is always a bad subscript.
                if idx_str.is_empty() {
                    eprintln!("{}: {}[]: bad array subscript",
                        self.err_prefix_with_line(), base);
                    self.last_status = 1;
                    return;
                }
                // `b[*]=…` / `b[@]=…` are bad numeric subscripts.
                if idx_str == "*" || idx_str == "@" {
                    eprintln!("{}: {}[{}]: bad array subscript",
                        self.err_prefix_with_line(), base, idx_str);
                    self.last_status = 1;
                    return;
                }
                let normalized_idx = idx_str.replace("\\\"", "\"").replace("\\'", "'");
                let normalized_trimmed = normalized_idx.trim();
                if normalized_idx != idx_str
                    && ((normalized_trimmed.starts_with('"') && normalized_trimmed.ends_with('"'))
                        || (normalized_trimmed.starts_with('\'') && normalized_trimmed.ends_with('\'')))
                {
                    eprintln!(
                        "{}: {}: arithmetic syntax error: operand expected (error token is \"{}\")",
                        self.err_prefix_with_line(),
                        normalized_trimmed,
                        normalized_trimmed
                    );
                    self.last_status = 1;
                    self.abort_current_list_until_newline();
                    return;
                }
                let idx_expanded = if idx_str.trim_start().starts_with("$((")
                    && idx_str.trim_end().ends_with("))")
                {
                    self.expand_word_nosplit(idx_str)
                } else {
                    crate::expand::expand_index_subscript_word_pub(idx_str, &mut self.vars)
                };
                if idx_expanded.trim().is_empty() {
                    self.vars.set_array_element(base, 0, value);
                    return;
                }
                if let Ok(idx) = crate::arithmetic::eval_expr_mut(&idx_expanded, &mut self.vars) {
                    let resolved = if idx < 0 {
                        match self.vars.array_max_index(base) {
                            Some(max_idx) => {
                                let len = (max_idx + 1) as i64;
                                let real = len + idx;
                                if real < 0 {
                                    eprintln!("{}: {}[{}]: bad array subscript",
                                        self.err_prefix_with_line(), base, idx_str);
                                    self.last_status = 1;
                                    return;
                                }
                                Some(real as usize)
                            }
                            None => {
                                eprintln!("{}: {}[{}]: bad array subscript",
                                    self.err_prefix_with_line(), base, idx_str);
                                self.last_status = 1;
                                return;
                            }
                        }
                    } else {
                        Some(idx as usize)
                    };
                    if let Some(u) = resolved {
                        self.vars.set_array_element(base, u, value);
                    }
                } else {
                    let err = crate::arithmetic::eval_expr(&idx_expanded, &self.vars)
                        .err()
                        .unwrap_or_else(|| "arithmetic syntax error: operand expected".to_string());
                    eprintln!("{}: {}: {}", self.err_prefix_with_line(), idx_expanded.trim_start(), err);
                    self.last_status = 1;
                    if err.contains("operand expected") {
                        self.abort_current_list_until_newline();
                    }
                }
            }
        } else {
            self.set_var(name, value);
        }
    }

    // -----------------------------------------------------------------------
    // Option management (set -e, set +x, etc.)
    // -----------------------------------------------------------------------

    pub fn set_option(&mut self, flag: &str) {
        match flag {
            "-e" | "errexit" => self.opts.errexit = true,
            "-u" | "nounset" => self.opts.nounset = true,
            "-x" | "xtrace" => self.opts.xtrace = true,
            "-v" | "verbose" => self.opts.verbose = true,
            "-n" | "noexec" => self.opts.noexec = true,
            "-f" | "noglob" => self.opts.noglob = true,
            "-C" | "noclobber" => self.opts.noclobber = true,
            "-a" | "allexport" => self.opts.allexport = true,
            "-B" | "braceexpand" => self.opts.braceexpand = true,
            "-h" | "hashall" => self.opts.hashall = true,
            "-m" | "monitor" => self.opts.monitor = true,
            "-b" | "notify" => self.opts.notify = true,
            "pipefail" => self.opts.pipefail = true,
            "-E" | "errtrace" => self.opts.errtrace = true,
            "-T" | "functrace" => self.opts.functrace = true,
            "-P" | "physical" => self.opts.physical = true,
            "-p" | "privileged" => self.opts.privileged = true,
            "-H" | "histexpand" => self.opts.history = true,
            "-t" | "onecmd" => self.opts.onecmd = true,
            "-k" | "keyword" => self.opts.keyword_assign = true,
            "-r" | "restricted" => {
                self.restricted = true;
                self.shopt.insert("restricted_shell".to_string());
            }
            "posix" => {
                self.posix_mode = true;
                self.shopt.insert("expand_aliases".to_string());
            }
            // Interactive-only options: brash tracks the flag state for
            // `set -o` output compatibility but doesn't implement the
            // feature itself.
            "emacs" => self.opts.emacs = true,
            "vi" => self.opts.vi = true,
            "history" => {
                self.opts.history_facility = true;
                // When `set -o history` is enabled, load HISTFILE if set.
                if let Some(histfile) = self.get_var("HISTFILE") {
                    if !histfile.is_empty() {
                        self.remember_history_file(&histfile);
                        let histfile_opts = crate::history::HistoryFileOptions {
                            comment_char: self.get_var("histchars")
                                .and_then(|s| s.chars().nth(2))
                                .unwrap_or('#'),
                            ..Default::default()
                        };
                        let _ = self.history.read_from_file_with_options(&histfile, histfile_opts);
                    }
                }
            }
            "ignoreeof" => {
                self.opts.ignoreeof = true;
                // Bash synchronises IGNOREEOF with the ignoreeof option:
                // `set -o ignoreeof` makes IGNOREEOF=10 if unset/empty.
                let cur = self.get_var("IGNOREEOF").unwrap_or_default();
                if cur.is_empty() {
                    self.set_var("IGNOREEOF", "10");
                }
            }
            "nolog" => self.opts.nolog = true,
            "interactive-comments" => self.opts.interactive_comments = true,
            _ => {}
        }
    }

    pub fn unset_option(&mut self, flag: &str) {
        // strip leading '+' when called from set +e style
        let flag = if flag.starts_with('+') {
            &flag[1..]
        } else if flag.starts_with('-') {
            &flag[1..]
        } else {
            flag
        };
        match flag {
            "e" | "errexit" => self.opts.errexit = false,
            "u" | "nounset" => self.opts.nounset = false,
            "x" | "xtrace" => self.opts.xtrace = false,
            "v" | "verbose" => self.opts.verbose = false,
            "n" | "noexec" => self.opts.noexec = false,
            "f" | "noglob" => self.opts.noglob = false,
            "C" | "noclobber" => self.opts.noclobber = false,
            "a" | "allexport" => self.opts.allexport = false,
            "B" | "braceexpand" => self.opts.braceexpand = false,
            "h" | "hashall" => self.opts.hashall = false,
            "m" | "monitor" => self.opts.monitor = false,
            "b" | "notify" => self.opts.notify = false,
            "pipefail" => self.opts.pipefail = false,
            "E" | "errtrace" => self.opts.errtrace = false,
            "T" | "functrace" => self.opts.functrace = false,
            "P" | "physical" => self.opts.physical = false,
            "p" | "privileged" => self.opts.privileged = false,
            "H" | "histexpand" => self.opts.history = false,
            "t" | "onecmd" => self.opts.onecmd = false,
            "k" | "keyword" => self.opts.keyword_assign = false,
            "posix" => {
                self.posix_mode = false;
                self.shopt.remove("expand_aliases");
            }
            "emacs" => self.opts.emacs = false,
            "vi" => self.opts.vi = false,
            "history" => self.opts.history_facility = false,
            "ignoreeof" => {
                self.opts.ignoreeof = false;
                // `set +o ignoreeof` clears IGNOREEOF.
                self.vars.unset("IGNOREEOF");
            }
            "nolog" => self.opts.nolog = false,
            "interactive-comments" => self.opts.interactive_comments = false,
            _ => {}
        }
    }

    // -----------------------------------------------------------------------
    // run_string — tokenize, parse, and execute a string
    // -----------------------------------------------------------------------

    pub fn run_string(&mut self, input: &str) -> i32 {
        if self.pretty_print_mode {
            // Parse-only mode: format the AST and print it.
            let tokens = crate::lexer::tokenize(input);
            match crate::parser::parse(tokens) {
                Ok(cmd) => {
                    let mut out = String::new();
                    crate::builtins::format_command_into_pub(&mut out, &cmd, 0);
                    print!("{}", out);
                    if out.ends_with("\n\n") {
                        // already matches bash's extra blank line
                    } else if out.ends_with('\n') {
                        println!();
                    } else {
                        println!();
                        println!();
                    }
                    return 0;
                }
                Err(_) => return 1,
            }
        }
        if self.opts.verbose {
            eprint!("{}", input);
            if !input.ends_with('\n') {
                eprintln!();
            }
        }

        // Use incremental (segment-based) tokenization when alias expansion
        // might be relevant: either there are existing aliases to expand, or
        // the input might define new aliases. This allows aliases defined on
        // one line to be available for subsequent lines.
        // Only do this for multi-line input (single-line doesn't benefit).
        // Heuristic: an input turns on posix-mode mid-stream if a
        // line BEGINS with `set -o posix` (or `set -o` followed by
        // other opts, or `shopt`).  Substring matches would fire on
        // things like `-c 'set -o posix; ...'` which is a literal
        // string inside another command — not a runtime toggle at
        // the outer level.
        let line_starts_with_posix_toggle = |s: &str| -> bool {
            s.lines().any(|line| {
                let t = line.trim_start();
                t.starts_with("set -o posix") || t.starts_with("set +o posix")
                    || t.starts_with("set -o ") || t.starts_with("shopt ")
                    || t.starts_with("shopt\t") || t == "shopt"
            })
        };
        let needs_incremental = input.contains('\n') && (
            (!self.aliases.is_empty() && self.shopt.contains("expand_aliases"))
            || input.contains("expand_aliases")
            || input.contains("alias ")
            || input.contains("alias\t")
            || input.contains("alias\n")
            || line_starts_with_posix_toggle(input)
        );
        if needs_incremental {
            return self.run_string_segmented(input);
        }

        self.run_string_inner(input)
    }

    /// Segment-based incremental execution: split input into top-level segments,
    /// tokenize each, parse, and execute. This allows aliases defined on one line
    /// to be used on the next.
    fn run_string_segmented(&mut self, input: &str) -> i32 {
        let segments = Self::split_toplevel_segments(input);
        let mut last_status = self.last_status;
        let mut line_offset: usize = 0;
        let mut index: usize = 0;

        while index < segments.len() {
            if self.exit_flag {
                break;
            }
            let mut seg = segments[index].clone();
            let mut consumed = 1usize;
            let trimmed = seg.trim();
            if trimmed.is_empty() {
                line_offset += seg.chars().filter(|&c| c == '\n').count();
                index += consumed;
                continue;
            }

            while index + consumed < segments.len()
                && self.has_toplevel_eof_heredoc_warning(&seg)
            {
                seg.push_str(&segments[index + consumed]);
                consumed += 1;
            }

            let padded = if line_offset > 0 {
                let mut s = "\n".repeat(line_offset);
                s.push_str(&seg);
                s
            } else {
                seg
            };
            last_status = self.run_string_inner(&padded);
            line_offset += segments[index..index + consumed]
                .iter()
                .map(|s| s.chars().filter(|&c| c == '\n').count())
                .sum::<usize>();
            index += consumed;
            if self.exit_flag {
                break;
            }
            // In -c mode, syntax errors are fatal (stop processing)
            if last_status == 2 && self.c_mode {
                break;
            }
        }
        last_status
    }

    /// Split input into segments at top-level newlines (newlines not inside
    /// quotes, heredocs, command substitutions, or multi-line compound commands).
    fn split_toplevel_segments(input: &str) -> Vec<String> {
        let chars: Vec<char> = input.chars().collect();
        let len = chars.len();
        let mut segments = Vec::new();
        let mut start = 0;
        let mut i = 0;
        // Track nesting for compound commands
        let mut paren_depth: i32 = 0;
        // Track brace-group nesting { ... }
        let mut brace_depth: i32 = 0;
        // Track keywords that require closing keywords
        let mut compound_depth: i32 = 0;
        let mut in_heredoc = false;
        let mut heredoc_delim = String::new();
        // Track number of single-quote pairs processed in current segment.
        // Used to distinguish orphan quotes (from alias expansion) from real
        // multi-line quotes that are part of concatenated quote structures.
        let mut sq_pairs_in_segment: usize = 0;

        while i < len {
            match chars[i] {
                '\\' if i + 1 < len => {
                    i += 2; // skip escaped character
                }
                '\'' => {
                    // Single quote: skip to matching close.
                    // Heuristic for alias-related orphan quotes: when a '
                    // is preceded by a word character AND there are no
                    // previously-paired single quotes in the current segment,
                    // it may be an orphan from alias expansion (e.g., `foo bar'`
                    // where foo is alias for `echo 'Error:`). In that case,
                    // treat it as literal to avoid merging unrelated lines.
                    // When there ARE previous quote pairs in the segment (e.g.,
                    // `-c '...foo='two words'` — the `words'` is a real quote
                    // start), always pair it.
                    let preceded_by_word = i > 0 && {
                        let prev = chars[i - 1];
                        prev.is_alphanumeric() || prev == '_'
                    };
                    if preceded_by_word && sq_pairs_in_segment == 0 {
                        // Likely an orphan quote from alias expansion
                        i += 1;
                    } else {
                        i += 1;
                        while i < len && chars[i] != '\'' {
                            i += 1;
                        }
                        if i < len { i += 1; } // skip closing '
                        sq_pairs_in_segment += 1;
                    }
                }
                '"' => {
                    // Double quote: skip to matching close (handling backslashes
                    // and ${...} bodies where single-quotes can span lines).
                    i += 1;
                    'dq: while i < len {
                        match chars[i] {
                            '"' => { i += 1; break 'dq; }
                            '\\' if i + 1 < len => { i += 2; }
                            '$' if i + 1 < len && chars[i + 1] == '{' => {
                                // ${...} inside DQ: skip its body with proper
                                // single-quote handling (SQ can span lines).
                                i += 2; // skip ${
                                let mut bdepth: i32 = 1;
                                while i < len && bdepth > 0 {
                                    match chars[i] {
                                        '\\' if i + 1 < len => { i += 2; }
                                        '\'' => {
                                            // SQ inside ${}: span to next '
                                            // regardless of newlines.
                                            i += 1;
                                            while i < len && chars[i] != '\'' {
                                                i += 1;
                                            }
                                            if i < len { i += 1; }
                                        }
                                        '"' => {
                                            // Nested DQ inside ${}: recurse-skip.
                                            i += 1;
                                            while i < len && chars[i] != '"' {
                                                if chars[i] == '\\' && i + 1 < len {
                                                    i += 2;
                                                } else {
                                                    i += 1;
                                                }
                                            }
                                            if i < len { i += 1; }
                                        }
                                        '$' if i + 1 < len && chars[i + 1] == '{' => {
                                            bdepth += 1; i += 2;
                                        }
                                        '}' => { bdepth -= 1; i += 1; }
                                        _ => { i += 1; }
                                    }
                                }
                            }
                            _ => { i += 1; }
                        }
                    }
                }
                '$' if i + 1 < len && chars[i + 1] == '\'' => {
                    // $'...' ANSI-C quoting: skip to matching close
                    i += 2;
                    while i < len && chars[i] != '\'' {
                        if chars[i] == '\\' && i + 1 < len {
                            i += 2;
                        } else {
                            i += 1;
                        }
                    }
                    if i < len { i += 1; }
                }
                '$' if i + 1 < len && chars[i + 1] == '{' => {
                    // `${...}` parameter expansion: skip over the
                    // entire `{...}` so its `{` / `}` don't bump the
                    // outer brace_depth.  Inside we still honour
                    // quoted regions (single + double quotes) and
                    // recursive `${...}`.
                    i += 2; // skip `${`
                    let mut inner_depth: i32 = 1;
                    while i < len && inner_depth > 0 {
                        match chars[i] {
                            '\\' if i + 1 < len => { i += 2; }
                            '\'' => {
                                i += 1;
                                while i < len && chars[i] != '\'' { i += 1; }
                                if i < len { i += 1; }
                            }
                            '"' => {
                                i += 1;
                                while i < len && chars[i] != '"' {
                                    if chars[i] == '\\' && i + 1 < len {
                                        i += 2;
                                    } else {
                                        i += 1;
                                    }
                                }
                                if i < len { i += 1; }
                            }
                            '$' if i + 1 < len && chars[i + 1] == '{' => {
                                // Nested ${…} — track its brace pair.
                                inner_depth += 1;
                                i += 2;
                            }
                            '{' => { i += 1; }
                            '}' => { inner_depth -= 1; i += 1; }
                            _ => { i += 1; }
                        }
                    }
                }
                '(' => { paren_depth += 1; i += 1; }
                ')' => { paren_depth = (paren_depth - 1).max(0); i += 1; }
                '`' => {
                    // Backtick command substitution: skip to matching close
                    i += 1;
                    while i < len && chars[i] != '`' {
                        if chars[i] == '\\' && i + 1 < len {
                            i += 2;
                        } else {
                            i += 1;
                        }
                    }
                    if i < len { i += 1; }
                }
                '#' => {
                    // Comment: skip to end of line
                    // But only if preceded by whitespace or at start
                    let is_comment = if i == start {
                        true
                    } else {
                        let prev = chars[i - 1];
                        prev == ' ' || prev == '\t' || prev == '\n' || prev == ';'
                            || prev == '|' || prev == '&' || prev == '(' || prev == ')'
                    };
                    if is_comment {
                        while i < len && chars[i] != '\n' {
                            i += 1;
                        }
                    } else {
                        i += 1;
                    }
                }
                '<' if i + 1 < len && chars[i + 1] == '<' => {
                    // Heredoc: need to track delimiter
                    i += 2;
                    // Skip <<- (strip tabs)
                    if i < len && chars[i] == '-' { i += 1; }
                    // Skip whitespace
                    while i < len && (chars[i] == ' ' || chars[i] == '\t') { i += 1; }
                    // Read delimiter
                    let mut delim = String::new();
                    let mut quoted = false;
                    if i < len && (chars[i] == '\'' || chars[i] == '"') {
                        let q = chars[i];
                        quoted = true;
                        i += 1;
                        while i < len && chars[i] != q {
                            delim.push(chars[i]);
                            i += 1;
                        }
                        if i < len { i += 1; } // skip closing quote
                    } else if i < len && chars[i] == '\\' {
                        // Quoted with backslash
                        quoted = true;
                        i += 1;
                        while i < len && !chars[i].is_whitespace() && chars[i] != '\n' {
                            if chars[i] == '\\' && i + 1 < len {
                                delim.push(chars[i + 1]);
                                i += 2;
                            } else {
                                delim.push(chars[i]);
                                i += 1;
                            }
                        }
                    } else {
                        while i < len && !chars[i].is_whitespace() && chars[i] != '\n'
                            && chars[i] != ';' && chars[i] != '&' && chars[i] != '|' {
                            delim.push(chars[i]);
                            i += 1;
                        }
                    }
                    let _ = quoted;
                    if !delim.is_empty() {
                        in_heredoc = true;
                        heredoc_delim = delim;
                    }
                }
                '\n' => {
                    if in_heredoc {
                        // Inside heredoc: skip lines until we find the delimiter
                        i += 1; // skip this newline
                        loop {
                            // Read the next line
                            let line_start = i;
                            while i < len && chars[i] != '\n' {
                                i += 1;
                            }
                            let line: String = chars[line_start..i].iter().collect();
                            let trimmed_line = line.trim();
                            if trimmed_line == heredoc_delim || line == heredoc_delim {
                                in_heredoc = false;
                                if i < len { i += 1; } // skip newline after delimiter
                                break;
                            }
                            if i >= len {
                                in_heredoc = false;
                                break;
                            }
                            i += 1; // skip newline
                        }
                        continue;
                    }

                    if paren_depth == 0 && compound_depth == 0 && brace_depth == 0 {
                        // Check if segment ends with `()` (function definition)
                        // — don't split, the body follows on next line
                        let seg_so_far: String = chars[start..i].iter().collect();
                        let trimmed_seg = seg_so_far.trim_end();
                        // Detect function definitions whose body opens
                        // on the next line:
                        //   `name ()` / `name()`  (posix style)
                        //   `function`            (keyword alone)
                        //   `function name`       (bash-style, `{` on
                        //                          next line)
                        let is_fn_header = trimmed_seg.ends_with("()")
                            || trimmed_seg == "function"
                            || trimmed_seg.starts_with("function ")
                            || trimmed_seg.starts_with("function\t");
                        // Most trailing `&` segments need to stay open for the
                        // segmented runner's background-job bookkeeping, but a
                        // bare history expansion token like `!-2:g&` is a
                        // complete command and must not absorb the next line.
                        let hist_event_with_amp = trimmed_seg.starts_with('!')
                            && trimmed_seg.ends_with('&');
                        let continues_after_newline = (trimmed_seg.ends_with('&')
                                && !hist_event_with_amp)
                            || trimmed_seg.ends_with('|')
                            || trimmed_seg.ends_with("&&")
                            || trimmed_seg.ends_with("||")
                            || trimmed_seg.ends_with("|&");
                        if is_fn_header || continues_after_newline {
                            // Function definition continues on next line
                            i += 1;
                        } else {
                            // Top-level newline: split here
                            i += 1; // include the newline
                            let segment: String = chars[start..i].iter().collect();
                            segments.push(segment);
                            start = i;
                            sq_pairs_in_segment = 0;
                        }
                    } else {
                        i += 1;
                    }
                }
                '{' => {
                    // Track opening braces at word boundaries (not inside ${...})
                    let at_word_start = i == 0 || {
                        let prev = chars[i - 1];
                        prev == ' ' || prev == '\t' || prev == '\n' || prev == ';'
                            || prev == '|' || prev == '&' || prev == '(' || prev == ')'
                    };
                    if at_word_start {
                        brace_depth += 1;
                    }
                    i += 1;
                }
                '}' => {
                    // Track closing braces at word boundaries
                    let at_word_start = i == 0 || {
                        let prev = chars[i - 1];
                        prev == ' ' || prev == '\t' || prev == '\n' || prev == ';'
                            || prev == '|' || prev == '&' || prev == '(' || prev == ')'
                    };
                    if at_word_start && brace_depth > 0 {
                        brace_depth -= 1;
                    }
                    i += 1;
                }
                _ => {
                    // Track compound command keywords at word boundaries
                    if paren_depth == 0 {
                        let at_word_start = i == 0 || {
                            let prev = chars[i - 1];
                            prev == ' ' || prev == '\t' || prev == '\n' || prev == ';'
                                || prev == '|' || prev == '&' || prev == '(' || prev == ')'
                        };
                        if at_word_start {
                            let remaining: String = chars[i..].iter().collect();
                            // Check for opening keywords: if, while, until, for, case, select
                            for kw in &["if ", "if\t", "if\n",
                                       "while ", "while\t", "while\n",
                                       "until ", "until\t", "until\n",
                                       "for ", "for\t", "for\n",
                                       "case ", "case\t", "case\n",
                                       "select ", "select\t", "select\n"] {
                                if remaining.starts_with(kw) {
                                    compound_depth += 1;
                                    break;
                                }
                            }
                            // Check for closing keywords: fi, done, esac
                            for kw in &["fi", "done", "esac"] {
                                if remaining.starts_with(kw) {
                                    let after = chars.get(i + kw.len()).copied();
                                    if after.is_none() || after == Some(' ') || after == Some('\t')
                                        || after == Some('\n') || after == Some(';')
                                        || after == Some('|') || after == Some('&')
                                        || after == Some(')') || after == Some('#')
                                        || after == Some('\'') || after == Some('"') {
                                        compound_depth = (compound_depth - 1).max(0);
                                        break;
                                    }
                                }
                            }
                        }
                    }
                    i += 1;
                }
            }
        }

        // Remaining input
        if start < len {
            let segment: String = chars[start..].iter().collect();
            if !segment.trim().is_empty() {
                segments.push(segment);
            }
        }

        segments
    }

    fn run_string_inner(&mut self, input: &str) -> i32 {
        let _abort_flag_guard = BoolRestoreGuard::reset(&mut self.abort_list_until_newline);
        // ---- History expansion ----
        // Apply history expansion when both `set -o history` (history_facility)
        // and `set -H` (histexpand / opts.history) are active.
        // We also need to add commands to history.
        // History expansion applies per top-level command, before parsing.
        // ---- History recording and expansion ----
        // History recording: when set -o history (history_facility) is on.
        // History expansion: additionally requires set -H (histexpand / opts.history).
        // Both are skipped inside pipelines/cmdsubs and for empty lines.
        if !self.in_pipeline_or_cmdsub {
            self.current_history_line = None;
        }
        let input_owned: std::borrow::Cow<str> = if self.opts.history_facility && !self.in_pipeline_or_cmdsub && self.eval_depth == 0 {
            let raw_input = input.trim_start_matches('\n'); // strip leading newline padding
            // `trimmed`: fully stripped (used only for the empty-input guard).
            // `hist_line`: leading whitespace and trailing newlines removed, but
            // trailing spaces preserved — this is what gets stored in history and
            // expanded (bash preserves trailing spaces when recording/expanding
            // history entries, but strips trailing newlines).
            let trimmed = raw_input.trim();
            let hist_line = raw_input.trim_start()
                .strip_suffix('\n')
                .unwrap_or(raw_input.trim_start());

            if trimmed.is_empty() {
                std::borrow::Cow::Borrowed(input)
            } else if self.opts.history {
                // History expansion is active (set -H)
                let histchars_val = self.get_var("histchars").unwrap_or_else(|| "!^#".to_string());
                let script_name = self.err_prefix();
                // Compute lineno from the leading newlines in `input` (the segment's
                // line offset in the script). `leading` is the count of '\n' chars
                // prepended by run_string_segmented to preserve line numbering — so
                // the actual script line is leading+1 (1-based). If there are no
                // leading newlines (script starts on line 1 or we're in -c/-e mode),
                // fall back to the current LINENO variable.
                let leading = input.bytes().take_while(|&b| b == b'\n').count();
                let lineno = if leading > 0 {
                    leading + 1
                } else {
                    self.get_var("LINENO").unwrap_or_else(|| "0".to_string())
                        .parse::<usize>().unwrap_or(0)
                };

                let mut last_subst = self.hist_last_subst.clone();
                let expand_result = crate::history::expand(&self.history, hist_line, &script_name, lineno, &histchars_val, &mut last_subst, self.posix_mode);
                self.hist_last_subst = last_subst;
                match expand_result {
                    crate::history::HistExpResult::Expanded(expanded) => {
                        // Echo the expanded command (bash echoes it before executing).
                        // For multi-line compound commands, bash only echoes the lines
                        // where expansion actually occurred — compare original to expanded
                        // line by line and only print lines that differ.
                        if hist_line.contains('\n') {
                            let orig_lines: Vec<&str> = hist_line.split('\n').collect();
                            let exp_lines: Vec<&str> = expanded.split('\n').collect();
                            let max = orig_lines.len().max(exp_lines.len());
                            for k in 0..max {
                                let orig = orig_lines.get(k).copied().unwrap_or("");
                                let exp = exp_lines.get(k).copied().unwrap_or("");
                                if orig != exp {
                                    eprintln!("{}", exp);
                                }
                            }
                        } else {
                            eprintln!("{}", expanded);
                        }
                        // Add the expanded command to history
                        if self.history_add(expanded.clone()) {
                            self.current_history_line = Some(expanded.clone());
                        }
                        let leading = input.len() - raw_input.len();
                        let mut new_input = "\n".repeat(leading);
                        new_input.push_str(&expanded);
                        std::borrow::Cow::Owned(new_input)
                    }
                    crate::history::HistExpResult::PrintOnly(expanded) => {
                        // :p modifier: print but don't execute
                        println!("{}", expanded);
                        // Add to history
                        if self.history_add(expanded.clone()) {
                            self.current_history_line = Some(expanded.clone());
                        }
                        return self.last_status; // don't execute
                    }
                    crate::history::HistExpResult::Error(e) => {
                        // Format: {script}: line {N}: {error_msg}
                        eprintln!("{}: line {}: {}", script_name, lineno, e);
                        self.last_status = 1;
                        return 1;
                    }
                    crate::history::HistExpResult::NoOp => {
                        // No expansion: record as-is (filtered by HISTCONTROL/HISTIGNORE)
                        let recorded = hist_line.to_string();
                        if self.history_add(recorded.clone()) {
                            self.current_history_line = Some(recorded);
                        }
                        std::borrow::Cow::Borrowed(input)
                    }
                }
            } else {
                // history_facility on but histexpand off: just record the line
                let recorded = hist_line.to_string();
                if self.history_add(recorded.clone()) {
                    self.current_history_line = Some(recorded);
                }
                std::borrow::Cow::Borrowed(input)
            }
        } else {
            // Fast path: no history — avoid heap allocation by borrowing input directly.
            std::borrow::Cow::Borrowed(input)
        };
        let input: &str = &input_owned;
        // ---- End history recording and expansion ----

        // Publish posix_mode to the lexer's thread-local so its
        // brace-expansion reader can honour the "'  is literal inside
        // ${...} within "..." " posix rule at parse time.  When the
        // caller's posix_mode is off but the input ITSELF turns it
        // on (e.g. `set -o posix; recho ...`), publish posix=true so
        // the lexer still gets the right rule for the later parts of
        // the same input.  The runtime `posix_mode` flag is flipped
        // by `set -o posix` as usual after the lexer has already
        // run, but the thread-local only affects parsing of brace
        // expansions and a false-positive here is harmless (the old
        // non-posix brace parse was also the forgiving interpretation
        // of posix).
        let mut result = self.tokenize_with_runtime_aliases(input);
        Self::supplement_cmdsub_heredoc_warnings(&mut result);
        let tokens = result.tokens;

        // Queue heredoc-terminated-by-EOF warnings to be emitted at the right
        // time during execution (unless suppressed for command sub re-parse).
        if !self.suppress_heredoc_warnings {
            self.pending_heredoc_warnings.extend(result.heredoc_warnings);
        }

        // If there are comsub EOF errors (unmatched `$(`), emit all pending
        // heredoc warnings, then the errors, and return status 2.
        if !result.comsub_eof_errors.is_empty() && !self.suppress_heredoc_warnings {
            self.emit_pending_heredoc_warnings(0);
            let prefix = self.err_prefix();
            for err in &result.comsub_eof_errors {
                eprintln!(
                    "{}: line {}: unexpected EOF while looking for matching `)'",
                    prefix, err.eof_line
                );
            }
            self.last_status = 2;
            return 2;
        }

        // If the here-document count limit was exceeded, report the error.
        if let Some(lineno) = result.heredoc_max_exceeded_line {
            let prefix = self.err_prefix();
            eprintln!("{}: line {}: maximum here-document count exceeded", prefix, lineno);
            self.last_status = 2;
            return 2;
        }

        // Array-literal parse error: `test=(first & second)` etc.
        // Bash reports the syntax error and the offending line, but
        // continues executing subsequent statements (the failed
        // assignment merely produces a non-zero exit status for the
        // enclosing command list).
        if let Some((tok, lineno)) = &result.array_literal_bad_token {
            let prefix = self.err_prefix();
            eprintln!("{}: line {}: syntax error near unexpected token `{}'",
                prefix, lineno, tok);
            // Print the offending source line, matching bash's
            // _print_offending_line diagnostic.
            let offending = input
                .lines()
                .nth(lineno.saturating_sub(1))
                .unwrap_or("")
                .to_string();
            eprintln!("{}: line {}: `{}'", prefix, lineno, offending);
            // Fall through: don't return.  The parser will have
            // dropped the malformed assignment but the tokens for
            // subsequent statements are still in the stream and
            // should continue executing.  We remember the error
            // below and force `$?` to 1 for the stand-in command.
        }

        // If `${ ` (dollar-brace-space) was encountered, bash 5.3+ treats this as a
        // group command syntax requiring a matching `}`. Since brash doesn't implement
        // this syntax, emit the "unexpected EOF while looking for matching `}'" error.
        if let Some(_dbs_lineno) = result.dollar_brace_space_line {
            if !self.suppress_heredoc_warnings {
                self.emit_pending_heredoc_warnings(0);
                let prefix = self.err_prefix();
                if self.eval_depth > 0 {
                    // Inside eval, use "eval: line <LINENO+1>:" format where LINENO
                    // is the script line of the eval command. Bash 5.3+ advances its
                    // internal line counter by 1 after processing the `${ ` construct
                    // through to EOF.
                    let lineno = self.get_var("LINENO").unwrap_or_else(|| "0".to_string());
                    let lineno_num: usize = lineno.parse().unwrap_or(0);
                    eprintln!(
                        "{}: eval: line {}: unexpected EOF while looking for matching `}}'",
                        prefix, lineno_num + 1
                    );
                } else {
                    eprintln!(
                        "{}: line {}: unexpected EOF while looking for matching `}}'",
                        prefix, _dbs_lineno
                    );
                }
                self.last_status = 2;
                return 2;
            }
        }

        // If a `${…}` brace expansion was opened but never closed (EOF reached
        // with brace depth > 0), emit the same "unexpected EOF while looking for
        // matching `}'" error that bash produces.
        if let Some(ub_lineno) = result.unclosed_brace_line {
            self.emit_pending_heredoc_warnings(0);
            let prefix = self.err_prefix();
            eprintln!(
                "{}: line {}: unexpected EOF while looking for matching `}}'",
                prefix, ub_lineno
            );
            self.last_status = 2;
            return 2;
        }

        if tokens.is_empty() {
            return self.last_status;
        }

        let cmd = match crate::parser::parse(tokens.clone()) {
            Ok(c) => c,
            Err(e) => {
                // When a multi-line segment fails to parse (e.g., because an
                // alias converted a keyword into a simple command, splitting
                // a compound command), try executing individual lines up to
                // the point of failure. This mimics bash's incremental
                // parsing behavior.
                if e.lineno > 1 && input.contains('\n') {
                    // Find the token boundary where the parser first reaches
                    // the error line. Multi-line tokens like assignment words
                    // that contain `$(...)` bodies can span several source
                    // lines without producing standalone Newline tokens.
                    let token_line_advance = |tok: &crate::lexer::Token| -> usize {
                        match tok {
                            crate::lexer::Token::Newline
                            | crate::lexer::Token::AliasNewline
                            | crate::lexer::Token::LineCont => 1,
                            crate::lexer::Token::SingleQuoted(s)
                            | crate::lexer::Token::DoubleQuoted(s)
                            | crate::lexer::Token::DollarSingleQuoted(s)
                            | crate::lexer::Token::CommandSub(s)
                            | crate::lexer::Token::ArithSub(s)
                            | crate::lexer::Token::ProcessSub(s)
                            | crate::lexer::Token::BraceGroup(s)
                            | crate::lexer::Token::ExtGlob(s) => {
                                s.chars().filter(|&c| c == '\n').count()
                            }
                            crate::lexer::Token::Concat(parts) => parts
                                .iter()
                                .map(|part| part.chars().filter(|&c| c == '\n').count())
                                .sum(),
                            crate::lexer::Token::AssignWord(_, _, value) => {
                                value.chars().filter(|&c| c == '\n').count()
                            }
                            _ => 0,
                        }
                    };

                    let mut current_line = 1usize;
                    let mut split_pos = 0;
                    for (idx, tok) in tokens.iter().enumerate() {
                        if current_line >= e.lineno {
                            split_pos = idx;
                            break;
                        }
                        current_line += token_line_advance(tok);
                    }
                    if split_pos > 0 {
                        let pre_tokens: Vec<_> = tokens[..split_pos].to_vec();
                        if let Ok(pre_cmd) = crate::parser::parse(pre_tokens) {
                            self.execute(&pre_cmd);
                        }
                    }
                }
                // Flush pending heredoc warnings before the error message.
                self.emit_pending_heredoc_warnings(0);
                if self.c_mode {
                    // When inside a cmdsub child (forked from an outer
                    // -c invocation), bash attributes the error to the
                    // OUTER -c line, not the line within the cmdsub
                    // body.  Prefer `parent_lineno` when set.
                    let base_lineno = if self.in_pipeline_or_cmdsub && self.parent_lineno > 0 {
                        self.parent_lineno
                    } else {
                        e.lineno
                    };
                    // Rewrite child-side EOF errors when inside a `$(...)`
                    // / `` `...` `` command substitution.  Bash's parser
                    // is one-pass: it only sees the closing `)` of the
                    // cmdsub, so an unclosed compound inside is reported
                    // as "syntax error near unexpected token `)`".  Map
                    // both styles brash might emit (the explicit
                    // unexpected-EOF wording with the opener keyword,
                    // and the bare `Eof` token) to the `)` form.
                    let msg_base = if self.in_pipeline_or_cmdsub {
                        let msg = e.message.replace(
                            "syntax error near unexpected token `Eof'",
                            "syntax error near unexpected token `)'",
                        );
                        if msg.starts_with("syntax error: unexpected end of file from `") {
                            "syntax error near unexpected token `)'".to_string()
                        } else {
                            msg
                        }
                    } else {
                        e.message.clone()
                    };
                    // Inside a `$(...)` command substitution, bash
                    // appends " while looking for matching `)'", BUT
                    // only when the unexpected token is something other
                    // than `)` itself.  When the token IS `)` (i.e. the
                    // cmdsub's own close), bash omits the trailer.
                    let msg = if self.in_pipeline_or_cmdsub
                        && msg_base.starts_with("syntax error near unexpected token")
                        && !msg_base.starts_with("syntax error near unexpected token `)'")
                    {
                        format!("{} while looking for matching `)'", msg_base)
                    } else {
                        msg_base.clone()
                    };
                    let is_unexpected_eof = msg_base.starts_with("syntax error: unexpected end of file from");
                    let eof_advance = usize::from(is_unexpected_eof && !input.ends_with('\n'));
                    let lineno = base_lineno + eof_advance;
                    // Allow the parser to encode a multi-line error by
                    // embedding "\n" in the message — prefix each line
                    // with the same header (matching bash's two-line
                    // errors for arith-for etc.).
                    //
                    // Special case: parse_double_bracket emits
                    // `\x00DBRACKET_EOF\x00<start_line>\x00<msg>` to
                    // request a bash-style two-line `[[ … ]]` EOF error
                    // with different line numbers per line.
                    if let Some(rest) = msg.strip_prefix("\x00DBRACKET_EOF\x00") {
                        let (start_line_str, first_msg) = match rest.split_once('\x00') {
                            Some((a, b)) => (a, b),
                            None => (rest, ""),
                        };
                        eprintln!("{}: -c: line {}: {}", self.err_prefix(), lineno, first_msg);
                        eprintln!(
                            "{}: -c: line {}: syntax error: unexpected end of file from `[[' command on line {}",
                            self.err_prefix(),
                            lineno + 1,
                            start_line_str
                        );
                    } else if let Some(rest) = msg.strip_prefix("\x00DBRACKET_TOK\x00") {
                        // Three-line bash-style [[ … ]] syntax error.
                        let parts: Vec<&str> = rest.splitn(3, '\x00').collect();
                        if parts.len() == 3 {
                            let reconstruction = parts[0];
                            let offending = parts[1];
                            let primary_msg = parts[2];
                            eprintln!("{}: -c: line {}: {}", self.err_prefix(), lineno, primary_msg);
                            eprintln!("{}: -c: line {}: syntax error near `{}'", self.err_prefix(), lineno, offending);
                            eprintln!("{}: -c: line {}: `{}'", self.err_prefix(), lineno, reconstruction);
                        }
                    } else {
                        for line in msg.split('\n') {
                            eprintln!("{}: -c: line {}: {}", self.err_prefix(), lineno, line);
                        }
                    }
                    // Print the offending command line for c-mode syntax errors.
                    if msg_base.starts_with("syntax error") && !msg_base.contains('\n') && !is_unexpected_eof {
                        // Prefer parent's source line (set across the
                        // cmdsub fork) over our own c_string.
                        let mut offending = if !self.parent_source_line.is_empty() {
                            self.parent_source_line.clone()
                        } else if let Some(ref cs) = self.c_string {
                            cs.lines().nth(lineno.saturating_sub(1)).unwrap_or("").to_string()
                        } else {
                            String::new()
                        };
                        if msg_base == "syntax error: arithmetic expression required" {
                            if let Some(start) = offending.find("((") {
                                offending = offending[start..].to_string();
                            }
                        }
                        eprintln!("{}: -c: line {}: `{}'", self.err_prefix(), lineno, offending);
                    }
                } else if self.eval_depth > 0 {
                    // Inside eval, bash formats the error as:
                    //   <script>: eval: line <LINENO>: <message>
                    // The parse error's line numbers are relative to the eval string;
                    // map them back to script lines using the current LINENO.
                    let lineno = self.get_var("LINENO").unwrap_or_else(|| "0".to_string());
                    let lineno_num: usize = lineno.parse().unwrap_or(0);
                    // Adjust parse-error line references: "line 1" in eval string
                    // corresponds to the LINENO of the eval command in the script.
                    // Also compute bash's effective line number: bash advances its internal
                    // line counter when processing eval strings. If the eval string ends
                    // with a backslash (attempted line continuation), bash reads 2 more
                    // "lines" from its input stream, advancing LINENO by 2.
                    let trailing_backslashes = input.trim_end_matches(|c: char| c == ' ' || c == '\t')
                        .chars().rev()
                        .take_while(|&c| c == '\\')
                        .count();
                    let bash_lineno_advance = if trailing_backslashes % 2 == 1 { 2usize } else { 0usize };
                    let is_unexpected_eof = e.message.starts_with("syntax error: unexpected end of file from ");
                    // bash's `eof_advance` only applies when the input lacks
                    // both a trailing newline AND a trailing backslash —
                    // otherwise the backslash already accounts for the
                    // implicit EOF newline.
                    let eof_advance = usize::from(
                        is_unexpected_eof
                            && !input.ends_with('\n')
                            && trailing_backslashes == 0
                    );
                    let effective_lineno = lineno_num + bash_lineno_advance + eof_advance;
                    let msg = if e.lineno <= 1 {
                        // Replace any "on line 1" references with script line
                        e.message.replace(" on line 1", &format!(" on line {}", lineno_num))
                    } else {
                        e.message.clone()
                    };
                    eprintln!("{}: eval: line {}: {}", self.err_prefix(), effective_lineno, msg);
                    // Print the offending command line for "syntax error near unexpected token" errors
                    if e.message.starts_with("syntax error near unexpected token") {
                        if let Some(ref es) = self.eval_string {
                            let offending_line = es.lines().next().unwrap_or("");
                            eprintln!("{}: eval: line {}: `{}'", self.err_prefix(), effective_lineno, offending_line);
                        }
                    }
                } else {
                    // Inside `$(…)` command substitution: the parser
                    // runs out at EOF instead of hitting the enclosing
                    // `)`.  Bash, parsing in one pass, reports `)` as
                    // the unexpected token.  Rewrite our message when
                    // we know we're in a cmdsub to match bash's output.
                    let mut msg = e.message.clone();
                    if self.in_pipeline_or_cmdsub {
                        msg = msg.replace(
                            "syntax error near unexpected token `Eof'",
                            "syntax error near unexpected token `)'",
                        );
                        // Bash treats unclosed compound commands inside
                        // `$(...)` as "syntax error near unexpected
                        // token `)'" rather than "unexpected end of
                        // file from `KEYWORD' command on line N".
                        if msg.starts_with("syntax error: unexpected end of file from `") {
                            msg = "syntax error near unexpected token `)'".to_string();
                        }
                    }
                    let lineno = e.lineno;
                    let is_unexpected_token = msg
                        .starts_with("syntax error near unexpected token");
                    let is_unexpected_eof = msg
                        .starts_with("syntax error: unexpected end of file from ");
                    let reported_lineno = if is_unexpected_eof {
                        input.chars().filter(|&c| c == '\n').count()
                            + 1
                            + usize::from(!input.ends_with('\n'))
                    } else {
                        lineno
                    };
                    if (is_unexpected_token || is_unexpected_eof) && reported_lineno > 0 {
                        eprintln!("{}: line {}: {}", self.err_prefix(), reported_lineno, msg);
                        // Bash's `_print_offending_line` prints the current
                        // `shell_input_line` (the enclosing script line
                        // as actually typed), not the `$(…)` body we may
                        // be parsing.  Prefer `parent_source_line` —
                        // inherited from the parent across the fork for
                        // cmdsub child shells — when it's set.
                        if is_unexpected_token {
                            let offending = if !self.parent_source_line.is_empty() {
                                self.parent_source_line.clone()
                            } else {
                                input
                                    .lines()
                                    .nth(reported_lineno.saturating_sub(1))
                                    .unwrap_or("")
                                    .to_string()
                            };
                            eprintln!("{}: line {}: `{}'", self.err_prefix(), reported_lineno, offending);
                        }
                    } else {
                        eprintln!("{}: {}", self.err_prefix(), msg);
                    }
                }
                self.last_status = 2;
                return 2;
            }
        };

        let status = self.execute(&cmd);
        self.last_status = status;

        // Flush any remaining heredoc warnings that weren't emitted during
        // execution (e.g. warnings whose eof_line > last command's lineno).
        self.emit_pending_heredoc_warnings(0);

        if self.opts.errexit && status != 0 && self.suppress_errexit == 0 && !self.last_was_negated {
            if !self.interactive {
                self.exit_flag = true;
            }
        }

        self.last_status
    }

    // -----------------------------------------------------------------------
    // execute — dispatch on Command variant
    // -----------------------------------------------------------------------

    pub fn execute(&mut self, cmd: &Command) -> i32 {
        if self.exit_flag {
            return self.last_status;
        }
        match cmd {
            Command::Simple(c) => self.execute_simple(c),
            Command::Pipeline(p) => self.execute_pipeline(p),
            Command::List(l) => self.execute_list(l),
            Command::If(c) => self.execute_if(c),
            Command::While(c) => self.execute_while(c),
            Command::Until(c) => self.execute_until(c),
            Command::For(c) => self.execute_for(c),
            Command::Case(c) => self.execute_case(c),
            Command::Group(c) => self.execute_group(c),
            Command::Subshell(c) => self.execute_subshell(c),
            Command::FuncDef(c) => self.execute_func_def(c),
            Command::ArithFor(c) => self.execute_arith_for(c),
            Command::ArithEval(expr, lineno) => {
                if *lineno > 0 {
                    self.set_var("LINENO", &lineno.to_string());
                }
                self.sync_dynamic_vars();
                if !self.in_debug_trap {
                    self.bash_command = format!("(( {} ))", expr.trim());
                }
                let trap_status = self.fire_debug_trap();
                if self.shopt.contains("extdebug") && trap_status == 2 {
                    return 0;
                }
                // Expand $var / ${var} references before arithmetic evaluation,
                // just like bash does. Do this BEFORE xtrace so that xtrace
                // shows the expanded expression (e.g. "42" not "$var").
                // Mark arithmetic context so nameref errors include the "((" prefix.
                self.vars.in_arith_cmd = true;
                let expanded = expand::expand_arith_vars(expr, &mut self.vars);
                // xtrace: bash prints "+ (( expanded_expr ))"
                if self.opts.xtrace {
                    let ps4_raw = self.get_var("PS4").unwrap_or_else(|| "+ ".to_string());
                    let ps4 = self.expand_ps4(&ps4_raw);
                    self.xtrace_print(&format!("{}(( {} ))\n", ps4, expanded));
                }
                // Empty `(())` is valid; bash evaluates it to 0 and returns 1.
                if expanded.trim().is_empty() {
                    return 1;
                }
                let arith_result = crate::arithmetic::eval_expr_mut(&expanded, &mut self.vars);
                self.vars.in_arith_cmd = false;
                match arith_result {
                    Ok(v) => if v != 0 { 0 } else { 1 },
                    Err(e) => {
                        // Unwrap INNER marker if present to get the real message.
                        let clean_e = Self::unwrap_inner_error_msg(&e);
                        // For nounset and recursion errors, bash prints just
                        // "varname: msg" without the "((:  expr : " prefix.
                        let is_nounset = clean_e.ends_with(": unbound variable");
                        let is_recursion = clean_e.contains(": expression recursion level exceeded");
                        let is_bad_array_subscript = clean_e.ends_with("bad array subscript");
                        if is_nounset || is_recursion {
                            eprintln!("{}: {}", self.err_prefix_with_line(), clean_e);
                            if is_nounset {
                                self.exit_flag = true;
                            }
                        } else if is_bad_array_subscript {
                            eprintln!("{}: {}", self.err_prefix_with_line(), clean_e);
                            eprintln!("{}: {}", self.err_prefix_with_line(), clean_e);
                        } else {
                            eprintln!("{}", self.format_arith_err(&expanded, &e));
                        }
                        1
                    }
                }
            }
            Command::Coproc(c) => self.execute_coproc(c),
            Command::Select(c) => self.execute_select(c),
            Command::Time(_posix, inner) => {
                // Unwrap nested `time` keywords — only the outermost one
                // emits timing output (matching bash behaviour).
                let mut target = inner.as_ref();
                while let Command::Time(_p, nested) = target {
                    target = nested.as_ref();
                }
                let start = std::time::Instant::now();
                let status = self.execute(target);
                let elapsed = start.elapsed();
                let secs = elapsed.as_secs_f64();
                // Use TIMEFORMAT if set, otherwise default bash format
                if let Some(fmt) = self.vars.get("TIMEFORMAT") {
                    // Simple TIMEFORMAT: %R = real, %U = user, %S = sys
                    // %[p][l]R where p is precision (default 3), l is long
                    let output = format_timeformat(&fmt, secs, 0.0, 0.0);
                    eprintln!("{}", output);
                } else {
                    eprintln!("\nreal\t{:.3}", secs);
                    eprintln!("user\t{:.3}", 0.0f64);
                    eprintln!("sys\t{:.3}", 0.0f64);
                }
                status
            }
            Command::Not(inner) => {
                // The ! operator negates the exit status.  Set-e must not trigger
                // for the inner command (POSIX: "! pipeline" doesn't cause exit).
                // We also clear exit_flag set by the inner command, because the
                // negated result may be 0 (success) which should not cause exit.
                self.suppress_errexit += 1;
                let status = self.execute(inner);
                self.suppress_errexit -= 1;
                // Clear any exit_flag set by the inner command; the negated
                // status will be re-evaluated by the caller.
                self.exit_flag = false;
                if status == 0 { 1 } else { 0 }
            }
        }
    }

    // -----------------------------------------------------------------------
    // execute_simple — the workhorse for simple commands
    // -----------------------------------------------------------------------

    fn simple_command_warning_line(cmd: &SimpleCommand) -> usize {
        if cmd.lineno == 0 {
            return 0;
        }

        let assignment_lines: usize = cmd.assignments
            .iter()
            .map(|a| a.value.chars().filter(|&c| c == '\n').count())
            .sum();
        let word_lines: usize = cmd.words
            .iter()
            .map(|w| w.chars().filter(|&c| c == '\n').count())
            .sum();
        let redirect_lines: usize = cmd.redirects
            .iter()
            .map(|r| r.target.chars().filter(|&c| c == '\n').count())
            .sum();

        cmd.lineno + assignment_lines + word_lines + redirect_lines
    }

    fn execute_simple(&mut self, cmd: &SimpleCommand) -> i32 {
        // Emit warnings due by the simple command's final source line so
        // multi-line command-substitution words warn before command output.
        self.emit_pending_heredoc_warnings(Self::simple_command_warning_line(cmd));

        // Update LINENO to reflect the line number of this command.
        // Skip when suppress_lineno_update > 0 (inside a DEBUG trap's direct
        // command text) so $LINENO in the trap body refers to the triggering
        // command's line, not the trap string's parsed line.
        if cmd.lineno > 0 && self.suppress_lineno_update == 0 {
            self.set_var("LINENO", &cmd.lineno.to_string());
        }
        self.check_pending_signals();
        if self.exit_flag {
            return self.last_status;
        }
        // A completely empty command (no words, no assignments, no redirects)
        // is a no-op produced by parsing an empty or comment-only segment.
        // Bash does not fire the DEBUG trap for such null commands.
        if cmd.words.is_empty() && cmd.assignments.is_empty() && cmd.redirects.is_empty() {
            return 0;
        }
        // Set BASH_COMMAND to the command being executed.  Skip this
        // inside a DEBUG/ERR trap body — bash preserves BASH_COMMAND
        // as the command that triggered the trap so the trap action
        // can introspect it.
        if !cmd.words.is_empty() && !self.in_debug_trap {
            self.bash_command = cmd.words.join(" ");
        }
        // Fire the DEBUG trap before executing this command.
        // With extdebug, a return value of 2 means "skip this command".
        {
            let trap_status = self.fire_debug_trap();
            if self.shopt.contains("extdebug") && trap_status == 2 {
                return 0;
            }
        }

        if self.opts.noexec {
            return 0;
        }

        // Alias expansion is now handled at the lexer level (tokenize_with_aliases).
        // The lexer splices alias text into the character stream before tokenization,
        // which correctly handles quoting boundaries, compound commands from aliases,
        // and trailing-space chaining.

        // Expand all words.
        // [[ ... ]] does NOT undergo word splitting or pathname expansion.
        // For [[ X == pattern ]] the pattern word is pattern-expanded so
        // quoted/escaped metacharacters (\\*, '*', "*") stay literal.
        // Update the thread-local error prefix so stateless expand
        // helpers that need "SCRIPT: line N:" for error messages can
        // reach it.
        {
            let prefix = self.err_prefix_with_line();
            CURRENT_ERR_PREFIX.with(|p| *p.borrow_mut() = prefix);
        }
        let is_double_bracket = cmd.words.first().map(|w| w.as_str()) == Some("[[");
        // When the command is an "assignment builtin" (declare/typeset/
        // local/export/readonly), bash treats arguments of the form
        // `NAME=VALUE` or `NAME+=VALUE` as assignments, expanding VALUE
        // with tilde-in-assign semantics and WITHOUT word splitting.
        let assign_builtin = matches!(cmd.words.first().map(|s| s.as_str()),
            Some("declare") | Some("typeset") | Some("local")
            | Some("export") | Some("readonly"));

        // set -k: pre-scan RAW cmd.words to identify assignment-form
        // words so they participate in the sequential prefix-assignment
        // scope (e.g. `a=$HOME` sees a prior `HOME=...` prefix).  Bash
        // applies set -k to words in ANY position, including after a
        // command name.  We extract these raw words here and process
        // them alongside cmd.assignments below.  Words that *look* like
        // assignments after expansion (because of `$FOO` expanding to
        // `name=value`) are still handled in the post-expansion pass.
        let mut raw_setk_assigns: Vec<(String, String, bool)> = Vec::new();
        let raw_words: Vec<String> = if self.opts.keyword_assign && !is_double_bracket {
            cmd.words.iter().filter_map(|w| {
                if is_valid_assign_word(w) {
                    let (n, v, a) = parse_assign_word(w);
                    raw_setk_assigns.push((n, v, a));
                    None
                } else {
                    Some(w.clone())
                }
            }).collect()
        } else {
            cmd.words.iter().cloned().collect()
        };
        let mut expanded_words: Vec<String> = Vec::new();
        // [[ ... ]] uses a lazy, short-circuit-aware expansion so that
        // the right side of `||` (or left side of `&&`) is never expanded
        // when the short-circuit condition is already met.  This matches
        // bash behavior where `[[ true || ${H*} ]]` never evaluates ${H*}.
        if is_double_bracket {
            // inner_raw is the words between "[[" and "]]"
            let n = raw_words.len();
            let inner_raw = if n >= 2 { &raw_words[1..n-1] } else { &raw_words[0..0] };
            match self.expand_double_bracket_lazy(inner_raw) {
                Some(w) => {
                    // The split-redirect post-processing happens later
                    expanded_words = w;
                }
                None => {
                    // Expansion error in an unskippable sub-expression.
                    self.last_status = 1;
                    return 1;
                }
            }
        }
        // Note: `[[ … ]]` pattern-RHS detection (`==`, `=`, `!=`, `=~`)
        // happens in execute_double_bracket — not here.  Earlier revisions
        // of this function carried a local bracket_ops table; it was dead
        // by the time the [[ ]] path moved to its own function.
        for (idx, word) in raw_words.iter().enumerate() {
            if is_double_bracket {
                // Already expanded above — skip
                continue;
            } else if assign_builtin && idx > 0 && is_assign_builtin_arg(word) {
                // `NAME=value` / `NAME+=value` / `NAME[subscript]=value`
                // for assignment builtins — expand without word-splitting.
                // Use Normal-mode expansion (not AssignValue) so the
                // first `=` in the word is treated as the assignment
                // boundary, enabling tilde on the right-hand side.
                //
                // Special case for compound array literals: `NAME=(...)`.
                // Elements inside `(...)` were recorded by the lexer
                // with `\x1F` separators BEFORE expansion, so each raw
                // element still contains its `$var`/`$(cmd)` references.
                // Each element must be expanded WITH field-splitting so
                // `NAME=($v)` where $v="a b c" produces 3 elements.
                // Process the ARRAY body on the raw word (pre-expansion)
                // so element boundaries are preserved.
                if let Some(eq) = word.find('=') {
                    let (prefix, rhs) = word.split_at(eq);
                    let rhs = &rhs[1..]; // skip '='
                    let (name_part, append_part) = if prefix.ends_with('+') {
                        (&prefix[..prefix.len()-1], "+=")
                    } else {
                        (prefix, "=")
                    };
                    let assoc_target = {
                        let base_name = parse_subscripted_name(name_part)
                            .map(|(base, _)| base)
                            .unwrap_or_else(|| name_part.to_string());
                        self.vars.is_assoc(&base_name)
                            || raw_words.iter().take(idx).skip(1).any(|arg| {
                                arg.starts_with('-') && arg.contains('A')
                            })
                    };
                    if let Some(body) = rhs.strip_prefix("\x00ARRAY\x00") {
                        let new_elements: Vec<String> = if body.is_empty() {
                            Vec::new()
                        } else {
                            body.split('\x1F')
                                .flat_map(|e| {
                                    if assoc_target {
                                        self.expand_assoc_compound_assign_element(e)
                                    } else {
                                        self.expand_compound_assign_element_passwd(e)
                                    }
                                })
                                .collect()
                        };
                        let new_body = new_elements.join("\x1F");
                        expanded_words.push(format!("{}{}\x00ARRAY\x00{}", name_part, append_part, new_body));
                    } else {
                        let expanded_rhs = if assoc_target {
                            self.expand_word_nosplit_assign(rhs)
                        } else {
                            self.expand_word_nosplit_assign_passwd(rhs)
                        };
                        expanded_words.push(format!("{}{}{}", name_part, append_part, expanded_rhs));
                    }
                } else {
                    expanded_words.push(self.expand_word_nosplit(word));
                }
            } else {
                let mut parts = self.expand_word(word);
                expanded_words.append(&mut parts);
            }
        }

        // Inside `[[ ... ]]`, the lexer tokenises `> X` and `< X` as a
        // Redirect token whose target is embedded in the same string
        // (e.g. `"> 7"` with a space between operator and target).
        // Split these back into two separate tokens so the conditional
        // evaluator sees them as `">"` / `"<"` and `"7"`.
        if is_double_bracket {
            let mut split_words: Vec<String> = Vec::with_capacity(expanded_words.len());
            for w in expanded_words {
                if (w.starts_with("> ") || w.starts_with("< ")) && w.len() > 2 {
                    split_words.push(w[..1].to_string()); // the operator
                    split_words.push(w[2..].to_string()); // the target
                } else {
                    split_words.push(w);
                }
            }
            expanded_words = split_words;
        }

        // If expansion produced an error marker (e.g. unmatched command
        // substitution, set -u on an unset variable), skip execution.
        // For non-interactive shells under `set -u`, an unbound variable
        // is a fatal error that exits the shell with status 127.
        if expanded_words.iter().any(|w| w.contains("\x00NOUNSET_ERROR\x00")) {
            if !self.interactive {
                self.last_status = 127;
                self.exit_flag = true;
                return self.last_status;
            }
            self.last_status = 1;
            return 1;
        }
        if expanded_words.iter().any(|w| w.contains("\x00EXPAND_ERROR\x00")) {
            self.last_status = 1;
            // POSIX: a fatal expansion error (bad substitution, etc.) in
            // a non-interactive shell exits the shell.  Bash applies this
            // when `set -o posix` is active.
            if self.posix_mode && !self.interactive {
                self.exit_flag = true;
            }
            return 1;
        }

        // If a cmdsub child exited with status 2 during expansion (parse
        // error in `$(…)` body), the parent script must also halt.
        // Don't run the surrounding command (e.g. `echo ""`) before the
        // outer executor unwinds.
        if self.exit_flag {
            return self.last_status;
        }

        // Check for arithmetic error sentinels (from failed $((...)) ).
        // The error message was already printed by expand_word — we just
        // need to abort execution and return status 1.
        // In POSIX mode, an arithmetic error is fatal for non-interactive
        // shells: the shell exits immediately with status 127, matching
        // bash's behaviour when invoked as "sh".
        for w in &expanded_words {
            if w.contains("\x00ARITH_ERR\x00") {
                if self.posix_mode && !self.interactive {
                    self.last_status = 127;
                    self.exit_flag = true;
                    return 127;
                }
                self.last_status = 1;
                return 1;
            }
        }

        // Assignment side-effects triggered during word expansion (for example
        // `${name:=word}` on a readonly variable) are fatal to the current
        // non-interactive shell context, even before a command is selected.
        if self.abort_list_until_newline && !self.interactive && self.in_forked_subshell_pub() {
            self.last_status = 1;
            self.exit_flag = true;
            return 1;
        }

        // Collect prefix assignments (VAR=val before command)
        let mut env_overrides: Vec<(String, String, bool)> = Vec::new(); // (name, value, append)
        let mut array_assigns: Vec<(String, Vec<String>, bool)> = Vec::new(); // (name, elements, append)
        // Save last_status so $? in assignment RHS sees the previous command's
        // exit status.  After expansion, we track whether any command
        // substitution updated last_status (via the `had_cmdsub` flag) to
        // correctly compute the pure-assignment return value.
        let pre_assign_status = self.last_status;
        let cmdsub_before = self.cmdsub_counter;
        let has_command_words = !expanded_words.is_empty();
        // Bash: later prefix assignments see earlier ones, e.g.
        // `K=foo A=\$K cmd` sets A=foo in cmd's env.  Push a
        // scratch scope while expanding the value of each prefix
        // assignment and set the already-expanded earlier prefix
        // values into that scope.  We pop the scope BEFORE running
        // the command (the values still get passed via
        // `env_overrides` so the child process sees them).
        let has_setk_assigns = !raw_setk_assigns.is_empty();
        // The temp scope is needed so that later assignments in the same
        // statement can see earlier ones (e.g. `A=1 B=$A cmd`).  With
        // exactly ONE scalar assignment and no set-k extras the sequencing
        // machinery is never needed; skip the push/pop to avoid one
        // HashMap allocation and a sync_process_locale call per iteration.
        let single_scalar_assign = !has_setk_assigns
            && cmd.assignments.len() == 1
            && cmd.assignments.iter().all(|a| !a.value.starts_with("\x00ARRAY\x00"));
        let prefix_scope_pushed = !single_scalar_assign
            && ((!cmd.assignments.is_empty()
                && cmd.assignments.iter().any(|a| !a.value.starts_with("\x00ARRAY\x00")))
                || has_setk_assigns);
        if prefix_scope_pushed {
            self.vars.push_scope();
        }
        for assign in &cmd.assignments {
            let key = assign.name.clone();
            if has_command_words && !is_valid_identifier_pub(&key) {
                eprintln!("{}: `{}': not a valid identifier",
                    self.err_prefix_with_line(), key);
                continue;
            }
            // Restricted shell: block assignment to PATH, SHELL, ENV, BASH_ENV
            if self.restricted {
                let base_name = key.split('[').next().unwrap_or(&key);
                if base_name == "PATH" || base_name == "SHELL" || base_name == "ENV" || base_name == "BASH_ENV" {
                    eprintln!("{}: {}: readonly variable", self.err_prefix_with_line(), base_name);
                    self.last_status = 1;
                    return 1;
                }
                // BASH_CMDS: in restricted mode, block values containing '/'
                if base_name == "BASH_CMDS" {
                    let val = self.expand_word_nosplit_assign(&assign.value);
                    if val.contains('/') {
                        eprintln!("{}: {}: restricted", self.err_prefix_with_line(), val);
                        self.last_status = 1;
                        return 1;
                    }
                    // If value doesn't contain '/', check if it's a valid command in PATH
                    if !val.is_empty() {
                        let path_var = self.get_var("PATH").unwrap_or_default();
                        let mut found = false;
                        for dir in path_var.split(':') {
                            let candidate = format!("{}/{}", dir, &val);
                            if std::path::Path::new(&candidate).is_file() {
                                found = true;
                                break;
                            }
                        }
                        if !found {
                            eprintln!("{}: {}: not found", self.err_prefix_with_line(), val);
                            self.last_status = 1;
                            return 1;
                        }
                    }
                    continue; // Skip BASH_CMDS assignment (not really supported)
                }
            }
            if assign.value.starts_with("\x00ARRAY\x00") {
                // Array assignment: name=( ... ) or name+=( ... )
                // Elements are separated by \x1F (ASCII unit separator) to avoid
                // confusion with spaces inside elements like $' ' (ANSI-C quoting).
                let content = &assign.value["\x00ARRAY\x00".len()..];
                let elements: Vec<String> = if content.is_empty() {
                    Vec::new()
                } else {
                    let raw_elems: Vec<&str> = content.split('\x1F').collect();
                    let mut result = Vec::new();
                    for w in raw_elems {
                        let expanded = if self.vars.is_assoc(&key) {
                            self.expand_assoc_compound_assign_element(w)
                        } else {
                            self.expand_compound_assign_element(w)
                        };
                        result.extend(expanded);
                    }
                    result
                };
                array_assigns.push((key, elements, assign.append));
            } else {
                let val = if self.is_assoc_assign_target(&key) {
                    self.expand_word_nosplit_assoc_assign(&assign.value)
                } else {
                    self.expand_word_nosplit_assign_passwd(&assign.value)
                };
                if val.contains("\x00ARITH_ERR\x00") {
                    self.print_assignment_arith_error(&val);
                    self.last_status = 1;
                    return 1;
                }
                // Publish into the scratch scope so the next
                // assignment's RHS expansion sees it.  Use
                // `set_local` so the new value lives in the pushed
                // scope only (not in the global scope where plain
                // `set` would stash it for a brand-new name).
                // Skip the set if the target is readonly — otherwise
                // set_local triggers a spurious "readonly variable"
                // error, then env_overrides triggers ANOTHER one
                // below when the command actually runs.  Let
                // env_overrides emit the single authoritative error.
                // Only publish to the temp scope for sequential visibility
                // (so later assignments can read earlier ones).  When there
                // is only a single assignment the temp scope is not pushed
                // and set_local would incorrectly write into the live scope.
                if prefix_scope_pushed && !self.vars.is_readonly(&key) {
                    self.vars.set_local(&key, &val);
                }
                env_overrides.push((key, val, assign.append));
            }
        }
        // set -k raw assignments (extracted before word expansion above)
        // are now expanded with the sequential prefix scope still active
        // so that their RHS sees the prior prefix assignments.
        for (key, raw_val, append) in &raw_setk_assigns {
            if has_command_words && !is_valid_identifier_pub(key) {
                eprintln!("{}: `{}': not a valid identifier",
                    self.err_prefix_with_line(), key);
                continue;
            }
            let val = if self.is_assoc_assign_target(key) {
                self.expand_word_nosplit_assoc_assign(raw_val)
            } else {
                self.expand_word_nosplit_assign_passwd(raw_val)
            };
            if val.contains("\x00ARITH_ERR\x00") {
                self.print_assignment_arith_error(&val);
                self.last_status = 1;
                return 1;
            }
            if !self.vars.is_readonly(key) {
                self.vars.set_local(key, &val);
            }
            env_overrides.push((key.clone(), val, *append));
        }
        if prefix_scope_pushed {
            self.vars.pop_scope();
        }
        let had_cmdsub = self.cmdsub_counter != cmdsub_before;

        // set -k post-expansion: command words that LOOK like assignments
        // after expansion (e.g. `$FOO` expanding to `name=value`) are also
        // promoted to assignments.  Note that raw assignment-form words
        // are already handled above via raw_setk_assigns.
        if self.opts.keyword_assign && !expanded_words.is_empty() {
            let mut kept: Vec<String> = Vec::new();
            for w in expanded_words.drain(..) {
                if is_valid_assign_word(&w) {
                    let (name, value, append) = parse_assign_word(&w);
                    env_overrides.push((name, value, append));
                } else {
                    kept.push(w);
                }
            }
            *&mut expanded_words = kept;
        }

        // If no command words — just do assignments in the shell
        if expanded_words.is_empty() {
            // Pure assignment: return status is 0 unless a command
            // substitution in the RHS changed it (e.g. x=$(false)).
            if !had_cmdsub && !self.abort_list_until_newline {
                self.last_status = 0;
            }
            // xtrace: emit one line per assignment (like bash)
            // Bash shows the pre-expansion form of assignments (raw tokens).
            if self.opts.xtrace {
                let ps4_raw = self.get_var("PS4").unwrap_or_else(|| "+ ".to_string());
                let ps4 = self.expand_ps4(&ps4_raw);
                for assign in &cmd.assignments {
                    let op = if assign.append { "+=" } else { "=" };
                    if assign.value.starts_with("\x00ARRAY\x00") {
                        // Array assignment: print raw elements as bash would
                        // For $'...' ANSI-C tokens, expand and re-quote as single-quoted
                        let content = &assign.value["\x00ARRAY\x00".len()..];
                        let raw_elems: Vec<String> = if content.is_empty() {
                            Vec::new()
                        } else {
                            content.split('\x1F')
                                .map(|e| format_array_element_for_xtrace(e))
                                .collect()
                        };
                        let elems_str = raw_elems.join(" ");
                        self.xtrace_print(&format!("{}{}{}({})\n", ps4, assign.name, op, elems_str));
                    } else {
                        // Scalar: print raw value (pre-expansion)
                        self.xtrace_print(&format!("{}{}{}{}\n", ps4, assign.name, op, assign.value));
                    }
                }
            }
            for (k, v, append) in &env_overrides {
                if *append {
                    if !self.append_var(k, v) {
                        self.last_status = 1;
                        return 1;
                    }
                } else {
                    // Clear any stale abort flag before this assignment so
                    // only the CURRENT assign_var_or_element can set it.
                    self.vars.nameref_invalid_target_abort = false;
                    self.assign_var_or_element(k, v);
                    // If vars.set() rejected the value as an invalid nameref
                    // target (e.g. `foo=7*6` when foo is an unresolved
                    // nameref), bash aborts the rest of the `;`-separated
                    // list.  Trigger that here and clear the flag.
                    if self.vars.nameref_invalid_target_abort {
                        self.vars.nameref_invalid_target_abort = false;
                        self.last_status = 1;
                        self.abort_current_list_until_newline();
                    }
                }
                if self.opts.allexport {
                    // Export the base name
                    let base = k.split('[').next().unwrap_or(k);
                    self.vars.export(base);
                }
            }
            if self.abort_list_until_newline && !self.interactive && self.in_forked_subshell_pub() {
                self.last_status = 1;
                self.exit_flag = true;
                return 1;
            }
            for (k, elements, arr_append) in &array_assigns {
                let resolved_name = if self.vars.is_nameref(k) {
                    self.vars.resolve_nameref(k).unwrap_or_else(|| k.clone())
                } else {
                    k.clone()
                };
                if self.vars.is_nameref(k)
                    && resolved_name.contains('[')
                    && resolved_name.ends_with(']')
                {
                    eprintln!("{}: `{}': not a valid identifier",
                        self.err_prefix_with_line(), resolved_name);
                    self.last_status = 1;
                    continue;
                }
                let k = resolved_name.as_str();
                // Subscripted name + compound value is illegal: bash
                // rejects `arr[i]=(list)` with "cannot assign list to
                // array member".  Check upfront; the rest of the
                // handling assumes `k` is a bare name.
                if k.contains('[') && k.ends_with(']') {
                    eprintln!("{}: {}: cannot assign list to array member",
                        self.err_prefix_with_line(), k);
                    self.last_status = 1;
                    continue;
                }
                // Readonly check: compound array assignment to a
                // readonly variable is an error.
                if self.vars.is_readonly(k) {
                    eprintln!("{}: {}: readonly variable",
                        self.err_prefix_with_line(), k);
                    self.last_status = 1;
                    continue;
                }
                let _ = arr_append; // used below
                let is_int = self.vars.get_entry_is_integer(k);
                if self.vars.is_assoc(k) {
                    // Associative array: parse [key]=value pairs
                    if !arr_append {
                        // Full assignment replaces
                        self.vars.clear_assoc(k);
                    }
                    // Bash 5.2+ kv-pair syntax: if NO element begins with
                    // `[`, treat the element list as alternating
                    // key/value pairs (`foo=(k1 v1 k2 v2)`).
                    let any_bracket = elements.iter()
                        .any(|e| !is_compound_bare_elem(e) && e.starts_with('['));
                    if !any_bracket && !elements.is_empty() {
                        let mut i = 0;
                        while i < elements.len() {
                            let raw_key = strip_compound_bare_elem(&elements[i]);
                            let key = crate::expand::expand_tilde_assoc_assign(raw_key, &self.vars);
                            if key.is_empty() {
                                let shown = if raw_key.is_empty() { "\"\"" } else { raw_key };
                                eprintln!("{}: {}: bad array subscript",
                                    self.err_prefix_with_line(), shown);
                                self.last_status = 1;
                                i += 2;
                                continue;
                            }
                            let raw_val = if i + 1 < elements.len() {
                                strip_compound_bare_elem(&elements[i + 1])
                            } else {
                                ""
                            };
                            let val = crate::expand::expand_tilde_assoc_assign(raw_val, &self.vars);
                            self.vars.set_assoc(k, &key, &val);
                            i += 2;
                        }
                        continue;
                    }
                    for elem in elements {
                        if !is_compound_bare_elem(elem) {
                        if let Some((key2, val, elem_append)) = parse_bracket_assign_ext(elem) {
                            // Tilde expansion in keys and values (bash 5.2+).
                            let expanded_key = crate::expand::expand_tilde_assoc_assign(&key2, &self.vars);
                            let expanded_val = crate::expand::expand_tilde_assoc_assign(&val, &self.vars);
                            if elem_append {
                                let existing = self.vars.get_assoc(k, &expanded_key).unwrap_or_default();
                                let combined = if is_int {
                                    let a = crate::arithmetic::eval_expr(existing.trim(), &self.vars).unwrap_or(0);
                                    let b = crate::arithmetic::eval_expr(expanded_val.trim(), &self.vars).unwrap_or(0);
                                    (a + b).to_string()
                                } else {
                                    format!("{}{}", existing, expanded_val)
                                };
                                self.vars.set_assoc(k, &expanded_key, &combined);
                            } else {
                                self.vars.set_assoc(k, &expanded_key, &expanded_val);
                            }
                        } else if *arr_append {
                            // scalar += on assoc array: set key "0"
                            self.vars.set_assoc(k, "0", strip_compound_bare_elem(elem));
                        } else {
                            // Bare element in assoc compound assign is
                            // an error: "must use subscript when
                            // assigning associative array".
                            eprintln!("{}: {}: {}: must use subscript when assigning associative array",
                                self.err_prefix_with_line(), k, strip_compound_bare_elem(elem));
                        }
                        } else if *arr_append {
                            self.vars.set_assoc(k, "0", strip_compound_bare_elem(elem));
                        } else {
                            eprintln!("{}: {}: {}: must use subscript when assigning associative array",
                                self.err_prefix_with_line(), k, strip_compound_bare_elem(elem));
                        }
                    }
                } else {
                    // Indexed array: handle [idx]=value, [idx]+=value, and plain values
                    let has_bracket = elements.iter()
                        .any(|e| !is_compound_bare_elem(e) && e.starts_with('['));
                    if has_bracket {
                        if !arr_append {
                            self.vars.set_array(k, Vec::new()); // reset only for non-append
                        }
                        // Track next index for bare values (following
                        // bash semantics when mixing `[i]=v` and plain
                        // elements: bare items use max_assigned_idx + 1).
                        let mut next_idx: usize = self.vars.array_max_index(k)
                            .map(|m| m + 1).unwrap_or(0);
                        // Bash aborts the whole compound assignment on
                        // the first bad element, so we do the same.
                        let mut aborted = false;
                        for elem in elements {
                            if aborted { break; }
                            if is_compound_bare_elem(elem) {
                                let elem = strip_compound_bare_elem(elem);
                                let final_val = if is_int {
                                    crate::arithmetic::eval_expr(elem.trim(), &self.vars)
                                        .map(|n| n.to_string()).unwrap_or_else(|_| elem.to_string())
                                } else {
                                    elem.to_string()
                                };
                                self.vars.set_array_element_raw(k, next_idx, &final_val);
                                next_idx += 1;
                            } else if let Some((idx_str, val, elem_append)) = parse_bracket_assign_ext(elem) {
                                // Empty subscript: `[]=val` is bad.
                                if idx_str.is_empty() {
                                    eprintln!("{}: []={}: bad array subscript",
                                        self.err_prefix_with_line(), val);
                                    self.last_status = 1;
                                    aborted = true;
                                    continue;
                                }
                                // `[*]=` / `[@]=` — non-numeric index
                                if idx_str == "*" || idx_str == "@" {
                                    eprintln!("{}: [{}]={}: cannot assign to non-numeric index",
                                        self.err_prefix_with_line(), idx_str, val);
                                    self.last_status = 1;
                                    aborted = true;
                                    continue;
                                }
                                let idx_expanded_raw = if idx_str.contains("$(")
                                    || idx_str.contains('"') || idx_str.contains('\'')
                                    || idx_str.contains(' ') || idx_str.contains('\t')
                                {
                                    idx_str.to_string()
                                } else {
                                    expand::expand_arith_vars(&idx_str, &mut self.vars)
                                };
                                // Strip C0 control chars (0x01-0x1F) from the subscript
                                // expression before arithmetic evaluation — bash does this
                                // internally (they are CTLNUL / internal markers that must
                                // not appear in arithmetic input).  DEL (0x7F) is kept; the
                                // arithmetic lexer handles it as an "invalid operator".
                                let idx_expanded: String = idx_expanded_raw.chars()
                                    .filter(|&c| !((c as u32) >= 0x01 && (c as u32) <= 0x1F))
                                    .collect();
                                let idx_num = match crate::arithmetic::eval_expr(
                                    &idx_expanded,
                                    &self.vars) {
                                    Ok(n) => n,
                                    Err(err) => {
                                        eprintln!("{}: {}: {}",
                                            self.err_prefix_with_line(), idx_expanded.trim_start(), err);
                                        self.last_status = 1;
                                        aborted = true;
                                        continue;
                                    }
                                };
                                // Negative index — resolve relative to
                                // max; error if result is negative.
                                let idx = if idx_num < 0 {
                                    match self.vars.array_max_index(k) {
                                        Some(m) => {
                                            let real = (m + 1) as i64 + idx_num;
                                            if real < 0 {
                                                eprintln!("{}: [{}]={}: bad array subscript",
                                                    self.err_prefix_with_line(), idx_str, val);
                                                self.last_status = 1;
                                                aborted = true;
                                                continue;
                                            }
                                            real as usize
                                        }
                                        None => {
                                            eprintln!("{}: [{}]={}: bad array subscript",
                                                self.err_prefix_with_line(), idx_str, val);
                                            self.last_status = 1;
                                            aborted = true;
                                            continue;
                                        }
                                    }
                                } else { idx_num as usize };
                                next_idx = idx + 1;
                                let final_val = if elem_append {
                                    // [idx]+=val: read current and append/add
                                    let old = self.vars.get_array_element(k, idx)
                                        .unwrap_or_default();
                                    if is_int {
                                        let a = crate::arithmetic::eval_expr(old.trim(), &self.vars).unwrap_or(0);
                                        let b = crate::arithmetic::eval_expr(val.trim(), &self.vars).unwrap_or(0);
                                        (a + b).to_string()
                                    } else {
                                        format!("{}{}", old, val)
                                    }
                                } else if is_int {
                                    // Integer array: evaluate value as arithmetic
                                    crate::arithmetic::eval_expr(val.trim(), &self.vars)
                                        .map(|n| n.to_string()).unwrap_or_else(|_| val.clone())
                                } else {
                                    val.clone()
                                };
                                self.vars.set_array_element_raw(k, idx, &final_val);
                            } else {
                                // plain value without [idx]= prefix:
                                // use the running next_idx cursor so
                                // `([5]=x y)` yields [5]=x [6]=y.
                                let final_val = if is_int {
                                    crate::arithmetic::eval_expr(strip_compound_bare_elem(elem).trim(), &self.vars)
                                        .map(|n| n.to_string()).unwrap_or_else(|_| strip_compound_bare_elem(elem).to_string())
                                } else {
                                    strip_compound_bare_elem(elem).to_string()
                                };
                                self.vars.set_array_element_raw(k, next_idx, &final_val);
                                next_idx += 1;
                            }
                        }
                    } else if *arr_append {
                        // x+=( elem1 elem2 ) — append elements to existing array
                        for elem in elements {
                            let final_val = if is_int {
                                crate::arithmetic::eval_expr(strip_compound_bare_elem(elem).trim(), &self.vars)
                                    .map(|n| n.to_string()).unwrap_or_else(|_| strip_compound_bare_elem(elem).to_string())
                            } else {
                                strip_compound_bare_elem(elem).to_string()
                            };
                            self.vars.push_array(k, &final_val);
                        }
                    } else {
                        // Full replacement
                        if is_int {
                            let coerced: Vec<String> = elements.iter().map(|e| {
                                crate::arithmetic::eval_expr(strip_compound_bare_elem(e).trim(), &self.vars)
                                    .map(|n| n.to_string()).unwrap_or_else(|_| strip_compound_bare_elem(e).to_string())
                            }).collect();
                            self.vars.set_array(k, coerced);
                        } else {
                            self.vars.set_array(
                                k,
                                elements.iter().map(|e| strip_compound_bare_elem(e).to_string()).collect(),
                            );
                        }
                    }
                }
            }
            // Handle redirects with no command (e.g. `> file`)
            if self.restricted && !cmd.redirects.is_empty() {
                for redir in &cmd.redirects {
                    match redir.op {
                        RedirectOp::Output | RedirectOp::Append | RedirectOp::Clobber
                        | RedirectOp::AndOutput | RedirectOp::AndAppend => {
                            let target = self.expand_word_nosplit(&redir.target);
                            eprintln!("{}: {}: restricted: cannot redirect output",
                                self.err_prefix_with_line(), target);
                            self.last_status = 1;
                            return 1;
                        }
                        _ => {}
                    }
                }
            }
            if !cmd.redirects.is_empty() {
                match self.setup_redirects(&cmd.redirects) {
                    Ok(saved) => {
                        self.restore_redirects(saved);
                        // Return the last_status set by any command substitutions
                        return self.last_status;
                    }
                    Err(_) => {
                        // Error already printed by setup_redirects (before restore).
                        return 1;
                    }
                }
            }
            // Return last_status to reflect exit status of any command substitutions
            return self.last_status;
        }

        // Restore last_status for the command execution (pre-assignment state)
        self.last_status = pre_assign_status;

        // Resolve process substitutions <(cmd) / >(cmd) in words and redirects
        let (procsub_pids, procsub_fds, resolved_redirects) = if is_double_bracket {
            self.resolve_procsubs_redirects(&cmd.redirects)
        } else {
            self.resolve_procsubs(&mut expanded_words, &cmd.redirects)
        };
        // Replace cmd.redirects with resolved versions for the rest of execution
        let cmd_redirects = resolved_redirects;

        // Alias expansion (only for interactive / first word)
        let command_name = &expanded_words[0].clone();

        // Restricted shell: block commands containing '/'
        if self.restricted && command_name.contains('/') {
            eprintln!("{}: {}: restricted: cannot specify `/' in command names",
                self.err_prefix_with_line(), command_name);
            self.cleanup_procsubs(&procsub_pids, &procsub_fds);
            self.last_status = 1;
            return 1;
        }

        // Restricted shell: block output redirections
        if self.restricted {
            for redir in &cmd_redirects {
                match redir.op {
                    RedirectOp::Output | RedirectOp::Append | RedirectOp::Clobber
                    | RedirectOp::AndOutput | RedirectOp::AndAppend => {
                        let target = self.expand_word_nosplit(&redir.target);
                        eprintln!("{}: {}: restricted: cannot redirect output",
                            self.err_prefix_with_line(), target);
                        self.cleanup_procsubs(&procsub_pids, &procsub_fds);
                        self.last_status = 1;
                        return 1;
                    }
                    _ => {}
                }
            }
        }

        // xtrace
        if self.opts.xtrace {
            let ps4_raw = self.get_var("PS4").unwrap_or_else(|| "+ ".to_string());
            let ps4 = self.expand_ps4(&ps4_raw);
            // Bash traces each prefix assignment (VAR=val cmd) as a separate line
            // before tracing the command itself.
            for (k, v, append) in &env_overrides {
                let op = if *append { "+=" } else { "=" };
                self.xtrace_print(&format!("{}{}{}{}\n", ps4, k, op, v));
            }
            // Trace the command itself — quote each word as bash does.
            // Inside `[[ ... ]]` bash does NOT quote the structural operators
            // (]], &&, ||, !, (, )) because they're reserved words / operators,
            // not ordinary arguments.
            //
            // Bash also splits compound `[[ A && B ]]` into separate trace
            // lines: `[[ A ]]` and `[[ B ]]`.  Do the same here: find
            // top-level `&&` and `||` tokens and emit one trace line per
            // sub-expression.
            if is_double_bracket {
                // Build sub-expression slices split at top-level && / ||.
                // "Top-level" means paren depth 0 (not inside `( ... )`).
                let inner: &[String] = if expanded_words.len() >= 2 {
                    // Strip leading "[[" and trailing "]]"
                    &expanded_words[1..expanded_words.len().saturating_sub(1)]
                } else {
                    &expanded_words[..]
                };
                let mut depth: usize = 0;
                let mut sub_start = 0;
                let mut sub_exprs: Vec<&[String]> = Vec::new();
                for (i, w) in inner.iter().enumerate() {
                    match w.as_str() {
                        "(" => depth += 1,
                        ")" if depth > 0 => depth -= 1,
                        "&&" | "||" if depth == 0 => {
                            sub_exprs.push(&inner[sub_start..i]);
                            sub_start = i + 1;
                        }
                        _ => {}
                    }
                }
                sub_exprs.push(&inner[sub_start..]);
                for sub in sub_exprs {
                    let mut parts: Vec<String> = vec!["[[".to_string()];
                    for w in sub {
                        if matches!(w.as_str(),
                            "]]" | "&&" | "||" | "!" | "(" | ")"
                            | "==" | "=" | "!=" | "=~"
                            | "<" | ">"
                            | "-a" | "-o"
                            | "-eq" | "-ne" | "-lt" | "-le" | "-gt" | "-ge"
                            | "-ef" | "-nt" | "-ot"
                            | "-z" | "-n" | "-e" | "-f" | "-d" | "-r" | "-w" | "-x"
                            | "-s" | "-L" | "-h" | "-p" | "-S" | "-b" | "-c"
                            | "-g" | "-u" | "-k" | "-O" | "-G" | "-N" | "-t"
                            | "-v" | "-R")
                        {
                            parts.push(w.clone());
                        } else {
                            parts.push(shell_quote_xtrace(w));
                        }
                    }
                    parts.push("]]".to_string());
                    self.xtrace_print(&format!("{}{}\n", ps4, parts.join(" ")));
                }
            } else {
                let quoted_words: Vec<String> = expanded_words.iter().enumerate().map(|(i, w)| {
                    if i == 0 {
                        w.clone()
                    } else {
                        shell_quote_xtrace(w)
                    }
                }).collect();
                self.xtrace_print(&format!("{}{}\n", ps4, quoted_words.join(" ")));
            }
        }

        // POSIX mode: special builtins take precedence over functions.
        // Default mode: functions take precedence over (non-special) builtins.
        // The `command` builtin bypasses function lookup — callers strip it
        // before reaching here, so this check only applies to direct calls.
        let is_special_builtin = builtins::is_posix_special_builtin(command_name);
        let func_first = !self.posix_mode || !is_special_builtin;
        if func_first && self.functions.contains_key(command_name) {
            // Fall through to the function-dispatch block below by skipping
            // the builtin branch for names that have both a function and a
            // (non-special) builtin entry.
        } else if command_name.starts_with('%') && expanded_words.len() == 1 {
            let saved = match self.setup_redirects(&cmd_redirects) {
                Ok(s) => s,
                Err(_) => {
                    self.cleanup_procsubs(&procsub_pids, &procsub_fds);
                    return 1;
                }
            };
            let status = builtins::run_job_spec_command_pub(self, command_name);
            self.last_status = status;
            self.restore_redirects(saved);
            self.cleanup_procsubs(&procsub_pids, &procsub_fds);
            return status;
        } else if builtins::is_builtin_enabled(self, command_name) {
            // Set up redirects, run builtin, restore
            let saved = match self.setup_redirects(&cmd_redirects) {
                Ok(s) => s,
                Err(_) => {
                    if self.posix_mode && builtins::is_posix_special_builtin(command_name) {
                        self.exit_flag = true;
                    }
                    self.cleanup_procsubs(&procsub_pids, &procsub_fds);
                    return 1;
                }
            };

            // Decide which prefix-assigned vars are "captured" by the builtin.
            // Bash makes prefix assignments persist when the builtin is an
            // assignment-taking builtin (export, readonly, declare, typeset,
            // local, alias) and its non-flag arguments reference the name.
            // POSIX mode: all prefix assignments to POSIX special builtins
            // persist regardless.
            let is_assignment_builtin = matches!(
                command_name.as_str(),
                "export" | "readonly" | "declare" | "typeset" | "local" | "alias"
            );
            let posix_special = builtins::is_posix_special_builtin(command_name);
            let captured_names: std::collections::HashSet<String> = if self.posix_mode && posix_special {
                // POSIX mode: every prefix assignment persists.
                env_overrides.iter().map(|(k, _, _)| k.clone()).collect()
            } else if is_assignment_builtin {
                // Scan args to decide capture policy:
                //   - export/readonly: capture any prefix var named as
                //     a non-flag argument (their job is to affect that
                //     variable's attributes).
                //   - declare/typeset/local/alias: only capture when an
                //     attribute-setting flag (-x/-r/-i/-a/-A/-l/-u/-c/-n)
                //     appears, OR the name carries an explicit `=value`.
                //     Plain `declare NAME` / `typeset NAME` does NOT
                //     capture — matches bash's `z=y typeset z` (z empty
                //     after) vs `z=y typeset -x z` (z=y persists).
                let name_captures_always = matches!(
                    command_name.as_str(), "export" | "readonly"
                );
                let mut has_attr_flag = false;
                for arg in &expanded_words[1..] {
                    if !(arg.starts_with('-') || arg.starts_with('+')) { continue; }
                    if arg == "--" { break; }
                    // Any combined flag with x/r/i/a/A/l/u/c/n counts.
                    if arg[1..].chars().any(|c|
                        matches!(c, 'x' | 'r' | 'i' | 'a' | 'A' | 'l' | 'u' | 'c' | 'n'))
                    {
                        has_attr_flag = true;
                    }
                }
                let mut names = std::collections::HashSet::new();
                for arg in &expanded_words[1..] {
                    if arg.starts_with('-') || arg.starts_with('+') {
                        if arg == "--" { continue; }
                        continue;
                    }
                    let has_value = arg.contains('=');
                    // For declare/typeset/local/alias, only capture when
                    // we see an attribute flag or an explicit assignment.
                    if !name_captures_always && !has_attr_flag && !has_value {
                        continue;
                    }
                    let name = match arg.find('=') {
                        Some(i) => &arg[..i],
                        None => arg.as_str(),
                    };
                    let name = match name.find('[') {
                        Some(i) => &name[..i],
                        None => name,
                    };
                    if !name.is_empty() {
                        names.insert(name.to_string());
                    }
                }
                names
            } else {
                std::collections::HashSet::new()
            };

            // Temporarily apply env overrides.  For names we expect to be
            // captured by the builtin, also export them (bash semantics:
            // prefix assignments to assignment-builtins inherit -x).
            let mut saved_vals: Vec<(String, String, crate::vars::RawBindingSnapshot, bool, bool)> = Vec::new();
            let mut readonly_prefix_error = false;
            for (k, v, append) in &env_overrides {
                let storage_key = if self.vars.is_nameref(k) {
                    self.vars.resolve_nameref(k)
                        .filter(|t| !t.contains('['))
                        .unwrap_or_else(|| k.clone())
                } else {
                    k.clone()
                };
                // A readonly var can't be re-assigned; set_var would
                // emit "readonly variable" now, and the restore
                // below would emit it again.  Let the emit happen
                // once (below) and skip the save/restore for this
                // key.
                if self.vars.is_readonly(&storage_key) {
                    self.set_var(k, v); // emits the single error
                    readonly_prefix_error = true;
                    continue;
                }
                let old = self.vars.snapshot_raw_bindings(&storage_key);
                let captured = captured_names.contains(k);
                let was_exported = self.vars.is_exported(&storage_key);
                saved_vals.push((k.clone(), storage_key.clone(), old, captured, was_exported));
                if *append {
                    if !self.append_var(&storage_key, v) {
                        self.last_status = 1;
                        return 1;
                    }
                } else {
                    self.set_var(&storage_key, v);
                }
                // If the builtin is expected to capture (e.g. `readonly var`,
                // `export var`), also mark exported during the builtin so
                // that the persisted var ends up with the -x attribute, as
                // bash does.
                if !was_exported {
                    self.vars.export(&storage_key);
                }
            }
            // For assignment-taking builtins inside a function, add the
            // prefix-assigned names to tempenv_names so that a bare
            // `typeset NAME` inside captures the prefix value as a
            // local (bash's `z=y typeset z` inside a func → local z=y).
            let mut saved_tempenv: Vec<String> = Vec::new();
            let builtin_tempenv_active =
                is_assignment_builtin && self.vars.in_function_scope();
            // Record which prefix names already lived in the current
            // function-local scope (so we can skip the restore if the
            // builtin leaves them as locals — typeset re-scoped them).
            let prefix_local_before: std::collections::HashSet<String> =
                env_overrides.iter()
                    .filter(|(k, _, _)| self.vars.is_local_pub(k))
                    .map(|(k, _, _)| k.clone())
                    .collect();
            if builtin_tempenv_active {
                for (k, _, _) in &env_overrides {
                    if self.tempenv_names.insert(k.clone()) {
                        saved_tempenv.push(k.clone());
                    }
                }
            }

            // POSIX mode: a readonly-variable assignment-prefix error
            // aborts the builtin invocation.  $? = 1, and if the builtin
            // is a POSIX special builtin (or we're in a subshell), the
            // shell/subshell exits.
            if readonly_prefix_error && self.posix_mode {
                self.last_status = 1;
                if posix_special || self.subshell_end_lineno > 0 {
                    self.exit_flag = true;
                }
                self.restore_redirects(saved);
                self.cleanup_procsubs(&procsub_pids, &procsub_fds);
                return 1;
            }
            let status = builtins::run(self, &expanded_words, &raw_words);
            self.last_status = status;
            // Detect names that the builtin promoted into a function-local
            // (typeset/declare/local NAME captures the current value).
            // We skip restore for any prefix-assigned name that ends up
            // local after the builtin — unless it was already local
            // before.  When a name was ALREADY local and the builtin
            // did a fresh local-promotion, `is_local_pub` reports local
            // both before and after; to distinguish, we compare the
            // current value against the prefix value — if equal, the
            // builtin just re-localised with the prefix value and we
            // should not restore.
            let captured_into_local: std::collections::HashSet<String> = env_overrides
                .iter()
                .filter(|(k, _, _)| self.vars.is_local_pub(k))
                .filter(|(k, v, _)| {
                    let now = self.vars.get(k).unwrap_or_default();
                    !prefix_local_before.contains(k) || &now == v
                })
                .map(|(k, _, _)| k.clone())
                .collect();
            // Clear the tempenv markers we added.
            for n in &saved_tempenv {
                self.tempenv_names.remove(n);
            }

            // Restore prefix assignments that weren't captured by the builtin.
            // In POSIX mode, ALL prefix assignments to POSIX special builtins
            // are captured (set in the captured_names set above), and
            // non-special builtins behave like non-POSIX (restore unless
            // captured by assignment-builtin semantics).  Names that were
            // promoted into function-locals by a `typeset NAME` call (via
            // the tempenv path above) also skip the restore — the local
            // is the new authoritative storage for those names.
            for (raw_key, storage_key, old_snapshot, captured, _was_exported) in saved_vals.iter().rev() {
                if *captured && !captured_into_local.contains(raw_key) {
                    continue;
                }
                if captured_into_local.contains(raw_key) {
                    self.vars.restore_outer_raw_bindings(storage_key, old_snapshot.clone());
                    continue;
                }
                self.vars.restore_raw_bindings(storage_key, old_snapshot.clone());
            }

            // Special case: `exec` with no command and redirections makes the
            // redirections permanent for the shell — don't restore them.
            let is_exec_permanent =
                (command_name == "exec" && expanded_words.len() == 1)
                    || std::mem::take(&mut self.exec_redirects_permanent);
            if is_exec_permanent {
                // For each saved entry, close the saved dup (we won't restore),
                // and close procsub parent fds that are still open on the
                // parent side (we duped them into the redirect target, so the
                // parent-side fd is no longer needed).  But DO leave the
                // redirect target fd open — that's what "permanent" means.
                for sfd in saved {
                    if sfd.saved_fd >= 0 {
                        unsafe { libc::close(sfd.saved_fd); }
                    } else if sfd.saved_fd == -1 {
                        // Procsub parent fd marker: close the (now-redundant)
                        // parent-side fd.
                        let _ = close(sfd.original_fd);
                    }
                    // saved_fd == -2: target fd wasn't previously open — don't
                    //                 close it; that's exactly the fd we want
                    //                 to keep permanent.
                }
                // Don't cleanup_procsubs (we already closed the parent fds
                // above), but do keep the child pids registered for later
                // reaping.
            } else {
                self.restore_redirects(saved);
                self.cleanup_procsubs(&procsub_pids, &procsub_fds);
            }
            // Fire ERR trap if builtin failed
            if status != 0 && !self.exit_flag {
                self.fire_err_trap();
            }
            return status;
        }

        // Check for function
        if let Some(func) = self.functions.get(command_name).cloned() {
            let saved = match self.setup_redirects(&cmd_redirects) {
                Ok(s) => s,
                Err(_) => {
                    // setup_redirects already printed the error.
                    self.cleanup_procsubs(&procsub_pids, &procsub_fds);
                    return 1;
                }
            };

            // Temporarily apply env overrides for the function call.
            // Track the value we assigned so we can tell later whether the
            // function body modified the variable via a special builtin
            // (in which case the modified value must persist in POSIX mode).
            // Also export the var during the function call so child
            // processes (e.g. `printenv` invoked inside the function) see
            // it — bash treats prefix assignments to a command, function,
            // or builtin as exported for the duration of the call.
            let mut saved_vals: Vec<(String, String, crate::vars::RawBindingSnapshot, String, bool)> = Vec::new();
            for (k, v, append) in &env_overrides {
                let storage_key = if self.vars.is_nameref(k) {
                    self.vars.resolve_nameref(k)
                        .filter(|t| !t.contains('['))
                        .unwrap_or_else(|| k.clone())
                } else {
                    k.clone()
                };
                let old = self.vars.snapshot_raw_bindings(&storage_key);
                let was_exported = self.vars.is_exported(&storage_key);
                let applied = if *append {
                    if !self.append_var(&storage_key, v) {
                        self.last_status = 1;
                        return 1;
                    }
                    self.vars.get(&storage_key).unwrap_or_default()
                } else {
                    // When a nameref has an unresolved/empty target the
                    // storage_key falls back to the nameref's own name.
                    // In that case bash stores the value directly as the
                    // nameref's own scalar (suspending nameref semantics
                    // for the duration of the function call) rather than
                    // trying to retarget it to the assigned value.
                    let nameref_unresolved = self.vars.is_nameref(k)
                        && self.vars.resolve_nameref(k).is_none();
                    if nameref_unresolved && storage_key == *k {
                        self.vars.set_value_direct_bypass_nameref(k, v);
                    } else {
                        self.set_var(&storage_key, v);
                    }
                    v.clone()
                };
                if !was_exported {
                    self.vars.export(&storage_key);
                }
                saved_vals.push((k.clone(), storage_key, old, applied, was_exported));
            }
            // Mark these names as "tempenv" so that inside the function,
            // `typeset NAME` (no value) inherits their current value
            // (bash's `var=hello func; f(){ typeset var; }` → var=hello).
            let saved_tempenv: Vec<String> = env_overrides.iter()
                .map(|(k, _, _)| k.clone())
                .filter(|n| self.tempenv_names.insert(n.clone()))
                .collect();

            let status = self.call_function(&func, &expanded_words[1..], cmd.lineno);

            // Clear the tempenv marker we added.
            for n in &saved_tempenv {
                self.tempenv_names.remove(n);
            }

            // Prefix-assignment variables to a *function* call are transient
            // in non-POSIX mode.  In POSIX mode, we still restore them —
            // BUT only if the function body did not override them via a
            // special-builtin prefix assignment (whose effect must stick).
            for (_raw_key, storage_key, old_snapshot, applied, was_exported) in saved_vals.iter().rev() {
                let current = self.vars.get(storage_key);
                let touched_by_inner = current.as_deref() != Some(applied.as_str());
                if self.posix_mode && touched_by_inner {
                    // Inner special-builtin change wins — but still clear
                    // the transient export flag we added.
                    if !was_exported { self.vars.unexport(storage_key); }
                    continue;
                }
                self.vars.restore_raw_bindings(storage_key, old_snapshot.clone());
                if !was_exported { self.vars.unexport(storage_key); }
            }

            self.restore_redirects(saved);
            self.cleanup_procsubs(&procsub_pids, &procsub_fds);
            return status;
        }

        // Check for `command_not_found_handle`: if the command is not
        // in PATH and not a function/builtin, and a function by that
        // name exists, invoke it with the original command + args as
        // positional parameters.  This lets tests simulate hook-style
        // "command not found" behavior.
        if !command_name.contains('/')
            && self.functions.contains_key("command_not_found_handle")
            && !path_command_exists(command_name, &self.get_var("PATH").unwrap_or_default())
        {
            // Block recursive invocation: temporarily remove the handler.
            let handler = self.functions.remove("command_not_found_handle").unwrap();
            let status = self.call_function(&handler, &expanded_words, cmd.lineno);
            self.functions.insert("command_not_found_handle".to_string(), handler);
            self.cleanup_procsubs(&procsub_pids, &procsub_fds);
            if status != 0 {
                self.last_status = status;
                self.fire_err_trap();
            }
            return status;
        }

        // External command — fork + exec
        let mut readonly_prefix_error = false;
        for (k, _, _) in &env_overrides {
            if self.vars.is_readonly(k) {
                let readonly_name = self.vars.resolve_nameref(k).unwrap_or_else(|| k.clone());
                eprintln!("{}: {}: readonly variable", self.err_prefix_with_line(), readonly_name);
                readonly_prefix_error = true;
            }
        }
        // POSIX mode: a readonly-variable assignment-prefix error aborts
        // the command altogether — the command itself is not invoked, and
        // $? is set to non-zero (bash uses 1).  In a subshell, the
        // subshell exits.  Outside POSIX mode, bash prints the error but
        // still tries to invoke the command (matching the existing path).
        if readonly_prefix_error && self.posix_mode {
            self.cleanup_procsubs(&procsub_pids, &procsub_fds);
            self.last_status = 1;
            if self.subshell_end_lineno > 0 {
                self.exit_flag = true;
            }
            return 1;
        }
        let status = self.run_external(command_name, &expanded_words, &env_overrides, &cmd_redirects, false);
        self.cleanup_procsubs(&procsub_pids, &procsub_fds);
        // Fire ERR trap if status != 0 and conditions are met.
        if status != 0 {
            self.last_status = status;
            self.fire_err_trap();
        }
        status
    }

    /// Public wrapper for run_external for use by builtins (e.g. `command`).
    pub fn run_external_pub(&mut self, args: &[String], env_overrides: &[(String, String, bool)], redirects: &[Redirect], background: bool) -> i32 {
        if args.is_empty() { return 0; }
        self.run_external(&args[0].clone(), args, env_overrides, redirects, background)
    }

    /// Fork and exec an external command. `background` means don't waitpid.
    fn run_external(
        &mut self,
        _name: &str,
        args: &[String],
        env_overrides: &[(String, String, bool)],
        redirects: &[Redirect],
        background: bool,
    ) -> i32 {
        if self.opts.noexec {
            return 0;
        }

        // Check the hash table: if the command name has a hashed path, use it.
        let hashed_args: Vec<String>;
        let effective_args = if !args.is_empty() && !args[0].contains('/') {
            if let Some(hashed_path) = self.hash_table.get(&args[0]).cloned() {
                if self.shopt.contains("checkhash") && !std::path::Path::new(&hashed_path).exists() {
                    self.hash_table.remove(&args[0]);
                    self.hash_hits.remove(&args[0]);
                    if let Some(path) = crate::builtins::find_in_path(self, &args[0]) {
                        if self.opts.hashall {
                            self.hash_table.insert(
                                args[0].clone(),
                                crate::builtins::normalize_hashed_command_path(&path),
                            );
                        }
                        hashed_args = std::iter::once(path)
                            .chain(args[1..].iter().cloned())
                            .collect();
                        &hashed_args
                    } else {
                        args
                    }
                } else {
                    // Increment hit counter for this hashed command
                    let cmd_name = args[0].clone();
                    *self.hash_hits.entry(cmd_name).or_insert(0) += 1;
                    hashed_args = std::iter::once(hashed_path)
                        .chain(args[1..].iter().cloned())
                        .collect();
                    &hashed_args
                }
            } else if let Some(path) = crate::builtins::find_in_path(self, &args[0]) {
                if self.opts.hashall {
                    self.hash_table.insert(
                        args[0].clone(),
                        crate::builtins::normalize_hashed_command_path(&path),
                    );
                }
                hashed_args = std::iter::once(path)
                    .chain(args[1..].iter().cloned())
                    .collect();
                &hashed_args
            } else {
                args
            }
        } else {
            args
        };

        // Build the argv for execvp.
        // decode_raw_bytes converts PUA-encoded bytes (from $'\x{HH}') back
        // to actual raw bytes for the C layer.
        let c_args: Vec<CString> = effective_args
            .iter()
            .map(|s| {
                let raw = expand::decode_raw_bytes(s);
                CString::new(raw).unwrap_or_default()
            })
            .collect();

        if c_args.is_empty() {
            return 127;
        }

        let cmd_name = c_args[0].clone();

        // Snapshot the environment to pass to the child.
        // For append overrides (k+=v), compute the appended value from the current env.
        let mut env_map: AHashMap<String, String> = self.exported_env();
        for (k, v, append) in env_overrides {
            let storage_key = if self.vars.is_nameref(k) {
                self.vars.resolve_nameref(k)
                    .filter(|t| !t.contains('['))
                    .unwrap_or_else(|| k.clone())
            } else {
                k.clone()
            };
            if *append {
                let current = env_map.get(&storage_key).cloned()
                    .or_else(|| self.vars.get(&storage_key))
                    .unwrap_or_default();
                let is_int = self.vars.get_entry_is_integer(&storage_key);
                let new_val = if is_int {
                    let a = crate::arithmetic::eval_expr(current.trim(), &self.vars).unwrap_or(0);
                    let b = crate::arithmetic::eval_expr(v.trim(), &self.vars).unwrap_or(0);
                    (a + b).to_string()
                } else {
                    format!("{}{}", current, v)
                };
                // Bash makes prefix assignments visible to the command even if
                // the var wasn't previously exported (the temp scope acts like
                // a one-shot export for the duration of the command).  Mirror
                // the non-append branch by always inserting when the prefix
                // names the storage var directly.
                if storage_key == *k || self.vars.is_exported(&storage_key) {
                    env_map.insert(storage_key, new_val);
                }
            } else {
                if storage_key == *k || self.vars.is_exported(&storage_key) {
                    env_map.insert(storage_key, v.clone());
                }
            }
        }

        let redirects_cloned: Vec<Redirect> = redirects.to_vec();

        // Exec-in-place optimisation: when the pipeline explicitly marked this
        // as a simple-command fork (exec_in_place=true), skip the inner fork
        // and exec the external command directly in the current process.
        // This halves the fork count for external commands in pipelines
        // (bash does the same thing internally).  The flag is only set for
        // Command::Simple pipeline elements, never for while-loops or
        // functions, so it cannot fire incorrectly mid-loop.
        if self.exec_in_place && !background && redirects_cloned.is_empty() {
            self.exec_in_place = false; // consume the flag
            // Set up the inherited environment for the exec'd process.
            for (k, _) in std::env::vars().collect::<Vec<_>>() {
                std::env::remove_var(&k);
            }
            for (k, v) in &env_map {
                std::env::set_var(k, v);
            }

            // Same shebang check as in the forked path.
            {
                let path_str = cmd_name.to_string_lossy();
                if !path_str.contains('\0') {
                    if let Ok(mut f) = std::fs::File::open(path_str.as_ref()) {
                        use std::io::Read as IoRead;
                        let mut header = [0u8; 2];
                        if f.read_exact(&mut header).is_ok() && header != [b'#', b'!'] {
                            let mut buf = vec![0u8; 512];
                            let n = f.read(&mut buf).unwrap_or(0);
                            if !buf[..n].contains(&0u8) {
                                let brash_path = std::env::current_exe()
                                    .ok()
                                    .and_then(|p| CString::new(p.to_string_lossy().as_bytes()).ok());
                                if let Some(brash_exe) = brash_path {
                                    let new_args: Vec<CString> = std::iter::once(brash_exe.clone())
                                        .chain(c_args.iter().cloned())
                                        .collect();
                                    let _ = nix::unistd::execvp(&brash_exe, &new_args);
                                }
                            }
                        }
                    }
                }
            }

            let _ = execvp(&cmd_name, &c_args);
            // execvp only returns on error
            let cmd_str = cmd_name.to_string_lossy();
            let err = std::io::Error::last_os_error();
            match err.raw_os_error() {
                Some(libc::ENOENT) => {
                    if let Some((interp, bad_err)) = check_bad_interpreter(&cmd_str) {
                        eprintln!("{}: {}: {}: bad interpreter: {}",
                            self.err_prefix(), cmd_str, interp, bad_err);
                        std::process::exit(127);
                    }
                    let shown_word = if effective_args[0].contains('/') {
                        &effective_args[0]
                    } else {
                        &args[0]
                    };
                    let shown = format_raw_diagnostic_word(shown_word);
                    if shown_word.contains('/') {
                        eprintln!("{}: {}: No such file or directory",
                            self.err_prefix_with_line(), shown);
                    } else {
                        eprintln!("{}: {}: command not found",
                            self.err_prefix_with_line(), shown);
                    }
                    std::process::exit(127);
                }
                Some(libc::EACCES) => {
                    eprintln!("{}: {}: Permission denied", self.err_prefix_with_line(), cmd_str);
                    std::process::exit(126);
                }
                _ => {
                    eprintln!("{}: {}: {}", self.err_prefix_with_line(), cmd_str, err);
                    std::process::exit(126);
                }
            }
        }

        match unsafe { fork() } {
            Ok(ForkResult::Child) => {
                // Re-establish default signal handling in child
                unsafe {
                    let _ = signal(Signal::SIGINT, SigHandler::SigDfl);
                    let _ = signal(Signal::SIGQUIT, SigHandler::SigDfl);
                    let _ = signal(Signal::SIGTERM, SigHandler::SigDfl);
                    let _ = signal(Signal::SIGPIPE, SigHandler::SigDfl);
                    let _ = signal(Signal::SIGCHLD, SigHandler::SigDfl);
                }

                if background {
                    redirect_stdin_to_devnull();
                }

                // Apply redirects in child
                for redir in &redirects_cloned {
                    if let Err(e) = apply_redirect_in_child(redir, self) {
                        eprintln!("{}: {}", self.err_prefix_with_line(), e);
                        std::process::exit(1);
                    }
                }

                // Set up environment
                // Clear environment first, then set from our env_map
                for (k, _) in std::env::vars().collect::<Vec<_>>() {
                    std::env::remove_var(&k);
                }
                for (k, v) in &env_map {
                    std::env::set_var(k, v);
                }

                // Pre-flight check for shell scripts without a shebang.
                // On macOS, execvp(3) automatically falls back to /bin/sh for
                // files that produce ENOEXEC, which would run them through the
                // system shell rather than through brash.  To prevent this and
                // ensure shell scripts are always run through brash, we detect
                // scripts without a shebang before calling execvp and exec brash
                // directly as the interpreter.
                {
                    let path_str = cmd_name.to_string_lossy();
                    if !path_str.contains('\0') {
                        if let Ok(mut f) = std::fs::File::open(path_str.as_ref()) {
                            use std::io::Read as IoRead;
                            let mut header = [0u8; 2];
                            if f.read_exact(&mut header).is_ok() {
                                if header != [b'#', b'!'] {
                                    // No shebang — determine if the file is executable text.
                                    // Check if it is a regular (non-binary) file by looking
                                    // for a NUL byte in the first 512 bytes.
                                    let mut buf = vec![0u8; 512];
                                    let n = f.read(&mut buf).unwrap_or(0);
                                    let has_nul = buf[..n].contains(&0u8);
                                    if !has_nul {
                                        // Looks like a shell script — re-exec with brash.
                                        let brash_path = std::env::current_exe()
                                            .ok()
                                            .and_then(|p| CString::new(p.to_string_lossy().as_bytes()).ok());
                                        if let Some(brash_exe) = brash_path {
                                            let new_args: Vec<CString> = std::iter::once(brash_exe.clone())
                                                .chain(c_args.iter().cloned())
                                                .collect();
                                            let _ = nix::unistd::execvp(&brash_exe, &new_args);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // exec
                let _ = execvp(&cmd_name, &c_args);

                // execvp only returns on error
                let cmd_str = cmd_name.to_string_lossy();
                // Check what kind of error
                let err = std::io::Error::last_os_error();
                match err.raw_os_error() {
                    Some(libc::ENOENT) => {
                        // If the file exists but has a `#!interp`
                        // shebang pointing to a missing interpreter,
                        // format the error as bash does:
                        //   `<script>: <interp>: bad interpreter: <err>`
                        if let Some((interp, bad_err)) = check_bad_interpreter(&cmd_str) {
                            eprintln!("{}: {}: {}: bad interpreter: {}",
                                self.err_prefix(), cmd_str, interp, bad_err);
                            std::process::exit(127);
                        }
                        // Bash: pathlike invocations (containing `/`)
                        // get "No such file or directory"; bare names
                        // that aren't found via PATH get the generic
                        // "command not found".
                        let shown_word = if effective_args[0].contains('/') {
                            &effective_args[0]
                        } else {
                            &args[0]
                        };
                        let shown = format_raw_diagnostic_word(shown_word);
                        if shown_word.contains('/') {
                            eprintln!("{}: {}: No such file or directory",
                                self.err_prefix_with_line(), shown);
                        } else {
                            eprintln!("{}: {}: command not found",
                                self.err_prefix_with_line(), shown);
                        }
                        std::process::exit(127);
                    }
                    Some(libc::EACCES) => {
                        eprintln!("{}: {}: Permission denied", self.err_prefix_with_line(), cmd_str);
                        std::process::exit(126);
                    }
                    _ => {
                        eprintln!("{}: {}: {}", self.err_prefix_with_line(), cmd_str, err);
                        std::process::exit(126);
                    }
                }
            }
                Ok(ForkResult::Parent { child }) => {
                    // Refresh the tilde-home cache to the current $HOME value.
                    // Bash refreshes its tilde-home cache after every fork, so
                    // subsequent ~ expansions in the parent reflect $HOME at
                    // fork time.
                    self.vars.refresh_home_cache();
                    if background {
                        self.record_background_job_pub(
                            child.as_raw(),
                            args.join(" "),
                            !self.opts.monitor,
                        );
                        // Don't wait; collect later via SIGCHLD / explicit wait
                        return 0;
                    }
                self.wait_for_child(child)
            }
            Err(e) => {
                eprintln!("{}: fork failed: {}", crate::exec::shell_name(), e);
                1
            }
        }
    }

    /// Wait for a child process and return its exit status.
    fn wait_for_child(&mut self, pid: Pid) -> i32 {
        loop {
            match waitpid(pid, None) {
                Ok(WaitStatus::Exited(_, status)) => {
                    self.last_status = status;
                    return status;
                }
                Ok(WaitStatus::Signaled(_, sig, _)) => {
                    let status = 128 + sig as i32;
                    self.last_status = status;
                    return status;
                }
                Ok(WaitStatus::Stopped(_, _)) => {
                    // Job control: stopped — return 128+SIGTSTP for now
                    return 128 + Signal::SIGTSTP as i32;
                }
                Ok(_) => continue,
                Err(nix::errno::Errno::EINTR) => {
                    // A signal interrupted the wait. Check for pending traps
                    // (e.g. SIGCHLD from a background job completing, or USR1
                    // sent to the shell).  Then retry waitpid.
                    self.check_pending_signals();
                    if self.exit_flag || self.return_flag {
                        // Trap caused shell exit or function return; stop waiting.
                        return self.last_status;
                    }
                    continue;
                }
                Err(_) => return 1,
            }
        }
    }

    // -----------------------------------------------------------------------
    // execute_pipeline
    // -----------------------------------------------------------------------

    fn execute_pipeline(&mut self, pipeline: &Pipeline) -> i32 {
        let cmds = &pipeline.commands;
        if cmds.is_empty() {
            return 0;
        }
        if cmds.len() == 1 {
            let status = if pipeline.negated {
                // ! pipeline: suppress errexit inside the pipeline
                self.suppress_errexit += 1;
                let s = self.execute(&cmds[0]);
                self.suppress_errexit -= 1;
                // Clear any exit_flag set by the inner command due to errexit;
                // the negated result will be re-evaluated by the caller.
                self.exit_flag = false;
                s
            } else {
                self.last_was_negated = false;
                self.execute(&cmds[0])
            };
            let result = if pipeline.negated { if status == 0 { 1 } else { 0 } } else { status };
            // Signal to the caller that this was a negated pipeline (set-e should not trigger)
            if pipeline.negated { self.last_was_negated = true; }
            self.pipestatus = vec![status];
            self.last_status = result;
            return result;
        }

        // Check if lastpipe is enabled (run last cmd in current shell)
        let lastpipe = self.shopt.contains("lastpipe") && !self.interactive;

        // Multiple commands: create pipes
        // For N commands we need N-1 pipes
        let n = cmds.len();
        let mut pipes: Vec<(RawFd, RawFd)> = Vec::new();
        for _ in 0..n - 1 {
            match pipe() {
                Ok((r, w)) => pipes.push((r.into_raw_fd(), w.into_raw_fd())),
                Err(e) => {
                    eprintln!("{}: pipe: {}", crate::exec::shell_name(), e);
                    return 1;
                }
            }
        }

        let mut child_pids: Vec<Option<Pid>> = Vec::new();

        let last_idx = n - 1;
        for (i, cmd) in cmds.iter().enumerate() {
            // Determine read end (stdin for this command)
            let stdin_fd: Option<RawFd> = if i == 0 { None } else { Some(pipes[i - 1].0) };
            // Determine write end (stdout for this command)
            let stdout_fd: Option<RawFd> = if i == n - 1 { None } else { Some(pipes[i].1) };

            // If lastpipe is set and this is the last command, run it in
            // the current shell instead of forking.
            if lastpipe && i == last_idx {
                child_pids.push(None); // placeholder – no child pid
                continue; // we'll run the last command after forking the rest
            }

            // Clone the command so we can send it into the child
            let cmd_clone = cmd.clone();

            match unsafe { fork() } {
                Ok(ForkResult::Child) => {
                    // Re-establish default signal disposition
                    unsafe {
                        let _ = signal(Signal::SIGINT, SigHandler::SigDfl);
                        let _ = signal(Signal::SIGQUIT, SigHandler::SigDfl);
                        let _ = signal(Signal::SIGPIPE, SigHandler::SigDfl);
                        let _ = signal(Signal::SIGCHLD, SigHandler::SigDfl);
                    }

                    // Dup stdin/stdout as needed
                    if let Some(rfd) = stdin_fd {
                        let _ = dup2(rfd, 0);
                    }
                    if let Some(wfd) = stdout_fd {
                        let _ = dup2(wfd, 1);
                        // |& also redirects stderr to the pipe
                        if i < pipeline.pipe_stderr.len() && pipeline.pipe_stderr[i] {
                            let _ = dup2(wfd, 2);
                        }
                    }

                    // Close all pipe ends in child.  When stdin was closed
                    // before the pipeline, pipe() may allocate fd 0 (or 1)
                    // as a pipe endpoint.  Only skip closing if we actually
                    // dup2'd something onto that fd — otherwise the pipe fd
                    // collides with the standard fd and must be closed.
                    let keep_fd0 = stdin_fd.is_some() && stdin_fd.unwrap() == 0;
                    let keep_fd1 = stdout_fd.is_some() && stdout_fd.unwrap() == 1;
                    for (r, w) in &pipes {
                        if !(*r == 0 && keep_fd0) && !(*r == 1 && keep_fd1) {
                            let _ = close(*r);
                        }
                        if !(*w == 0 && keep_fd0) && !(*w == 1 && keep_fd1) {
                            let _ = close(*w);
                        }
                    }

                    // Pipeline children are subshell environments: they do not
                    // inherit the parent's EXIT trap. ERR trap also does not
                    // fire inside pipeline children.
                    self.traps.remove("EXIT");
                    self.exit_trap_done = false;
                    self.in_pipeline_or_cmdsub = true;

                    // Exec-in-place: when the pipeline element is a simple
                    // command, allow run_external to exec directly rather than
                    // fork+exec.  This flag is cleared by execute_simple after
                    // expansions are done, right before the exec call, so it
                    // cannot accidentally fire inside nested compound commands.
                    if matches!(cmd_clone, Command::Simple(_)) {
                        self.exec_in_place = true;
                    }

                    // For a negated pipeline (! cmd1 | cmd2), suppress set-e for all
                    // pipeline components (the negation means set-e can't fire on the result).
                    // For non-negated pipelines, set-e applies normally within each subshell.
                    let is_last = i == last_idx;
                    if pipeline.negated && !is_last {
                        self.suppress_errexit += 1;
                    }
                    let status = self.execute(&cmd_clone);
                    // Run EXIT trap if it was set inside this pipeline component
                    if !self.exit_trap_done {
                        self.exit_trap_done = true;
                        if let Some(trap_cmd) = self.traps.get_exit_trap() {
                            let trap_cmd = trap_cmd.clone();
                            self.run_string(&trap_cmd);
                        }
                    }
                    let final_status = if self.exit_flag {
                        self.last_status
                    } else {
                        status
                    };
                    std::process::exit(final_status);
                }
                Ok(ForkResult::Parent { child }) => {
                    child_pids.push(Some(child));
                }
                Err(e) => {
                    eprintln!("{}: fork: {}", crate::exec::shell_name(), e);
                    child_pids.push(None);
                }
            }
        }

        // If lastpipe, run the last command in the current shell with
        // stdin redirected from the last pipe's read end.
        if lastpipe {
            // Close all pipe write ends in parent first, so writers can
            // detect when the read end closes.
            for (_, w) in &pipes {
                let _ = close(*w);
            }
            // Also close read ends we don't need (all except the last one)
            for j in 0..pipes.len().saturating_sub(1) {
                let _ = close(pipes[j].0);
            }

            // Redirect stdin from the last pipe read end
            let last_pipe_read = pipes[last_idx - 1].0;
            let saved_stdin = if last_pipe_read == 0 {
                // pipe() allocated fd 0 itself (stdin was closed).  fd 0 is
                // already the pipe read end — no dup2 needed, but we must not
                // close it either.  Mark saved_stdin as None so we close fd 0
                // afterwards (restore "stdin closed" state).
                None
            } else {
                let s = nix::unistd::dup(0).ok();
                let _ = dup2(last_pipe_read, 0);
                let _ = close(last_pipe_read);
                s
            };

            let status = self.execute(&cmds[last_idx]);

            // Restore stdin
            if let Some(saved) = saved_stdin {
                let _ = dup2(saved, 0);
                let _ = close(saved);
            } else {
                // stdin was not open before the pipeline (e.g. after
                // `exec 0<&-`).  Close the pipe fd we dup2'd onto fd 0
                // so it goes back to being closed.
                let _ = close(0);
            }

            // Wait for all children
            let mut statuses: Vec<i32> = vec![0; child_pids.len()];
            for (idx, pid_opt) in child_pids.iter().enumerate() {
                if let Some(pid) = pid_opt {
                    statuses[idx] = self.wait_for_child(*pid);
                }
            }
            statuses[last_idx] = status;

            self.pipestatus = statuses.clone();

            let final_status = if self.opts.pipefail {
                statuses.iter().rev().find(|&&s| s != 0).copied().unwrap_or(0)
            } else {
                status
            };

            let result = if pipeline.negated {
                if final_status == 0 { 1 } else { 0 }
            } else {
                final_status
            };

            self.last_status = result;
            return result;
        }

        // Parent: close all pipe fds
        for (r, w) in &pipes {
            let _ = close(*r);
            let _ = close(*w);
        }

        // Wait for all children
        let mut statuses: Vec<i32> = vec![0; child_pids.len()];
        for (idx, pid_opt) in child_pids.iter().enumerate() {
            if let Some(pid) = pid_opt {
                statuses[idx] = self.wait_for_child(*pid);
            }
        }

        self.pipestatus = statuses.clone();

        let final_status = if self.opts.pipefail {
            // Return the rightmost non-zero status, or 0 if all succeeded
            statuses.iter().rev().find(|&&s| s != 0).copied().unwrap_or(0)
        } else {
            *statuses.last().unwrap_or(&0)
        };

        let result = if pipeline.negated {
            if final_status == 0 { 1 } else { 0 }
        } else {
            final_status
        };

        if pipeline.negated { self.last_was_negated = true; }
        self.last_status = result;
        // Fire ERR trap for multi-command pipeline failures (single-command
        // pipelines fire from execute_simple).
        if result != 0 && !pipeline.negated {
            // Ensure LINENO reflects the pipeline's line number before firing
            // the ERR trap so that $LINENO in the trap body is correct.
            // Use the lineno of the first command in the pipeline.
            if let Some(Command::Simple(sc)) = pipeline.commands.first() {
                if sc.lineno > 0 {
                    self.set_var("LINENO", &sc.lineno.to_string());
                }
            }
            self.fire_err_trap();
        }
        result
    }

    // -----------------------------------------------------------------------
    // execute_list — handle ; & && ||
    // -----------------------------------------------------------------------

    fn execute_list(&mut self, list: &List) -> i32 {
        let mut last_status = 0;
        // prev_op tracks the operator BEFORE the current entry.
        // The op field is the operator AFTER the entry's command (the separator
        // that follows it in the source).  So entry[i].op tells us how to
        // connect entry[i] to entry[i+1].  For the very first entry there is
        // no preceding operator, so we treat it as Semi (always run).
        let mut prev_op = ListOp::Semi;

        for entry in &list.entries {
            if self.exit_flag {
                return self.last_status;
            }

            if self.abort_list_until_newline {
                if matches!(prev_op, ListOp::Newline | ListOp::Last) {
                    self.abort_list_until_newline = false;
                } else {
                    prev_op = entry.op.clone();
                    if matches!(entry.op, ListOp::Newline | ListOp::Last) {
                        self.abort_list_until_newline = false;
                    }
                    continue;
                }
            }

            // Decide whether to run this entry based on the PREVIOUS op.
            let should_run = match prev_op {
                ListOp::And => last_status == 0,
                ListOp::Or  => last_status != 0,
                _           => true,
            };

            if should_run {
                if matches!(entry.op, ListOp::Amp) {
                    // Run in background: fork and don't wait
                    let cmd_clone = entry.command.clone();
                    match unsafe { fork() } {
                        Ok(ForkResult::Child) => {
                            unsafe {
                                let _ = signal(Signal::SIGINT, SigHandler::SigDfl);
                                let _ = signal(Signal::SIGQUIT, SigHandler::SigDfl);
                            }
                            redirect_stdin_to_devnull();

                            // Subshell elision + exec-in-place for backgrounded
                            // commands.  The bg fork itself already provides the
                            // process-isolation a subshell would, so a `(...)`
                            // body inside the bg context can be inlined here:
                            // apply the subshell's redirects to this child's
                            // fds, drop the EXIT trap (subshells don't inherit
                            // it), bump BASH_SUBSHELL, then run the body.  And
                            // when the resulting command is a single Simple
                            // external, set exec_in_place so run_external execs
                            // directly instead of fork+exec.
                            //
                            // Without this, `cmd &` leaves one brash layer
                            // between the script and the program, and
                            // `( cmd ) &` or `( exec cmd ) >LOG &` leaves
                            // *two*.  After elision the process tree matches
                            // bash: script → program directly, with $! the
                            // program's pid (or, for non-exec subshell bodies
                            // that aren't Simple, a single bg-wrapper that
                            // exits when the body does).
                            let mut command_to_run = cmd_clone;
                            if let Command::Subshell(sub) = command_to_run.clone() {
                                for redir in &sub.redirects {
                                    if let Err(e) = apply_redirect_in_child(redir, self) {
                                        eprintln!("{}: {}", self.err_prefix_with_line(), e);
                                        std::process::exit(1);
                                    }
                                }
                                self.traps.remove("EXIT");
                                self.exit_trap_done = false;
                                let subshell_n: usize = self.get_var("BASH_SUBSHELL")
                                    .and_then(|s| s.parse().ok())
                                    .unwrap_or(0);
                                self.set_var("BASH_SUBSHELL", &(subshell_n + 1).to_string());
                                command_to_run = (*sub.body).clone();
                            }
                            // If the body is a List of one statement, unwrap
                            // it so a Simple body inside `( cmd )` is visible
                            // to the exec_in_place check below.  Only the
                            // terminator-style ListOps (Last / Semi / Newline)
                            // are safe to elide — &, &&, || introduce control
                            // flow that we must preserve.
                            if let Command::List(list) = &command_to_run {
                                if list.entries.len() == 1
                                    && matches!(
                                        list.entries[0].op,
                                        ListOp::Last | ListOp::Semi | ListOp::Newline
                                    )
                                {
                                    command_to_run = list.entries[0].command.clone();
                                }
                            }
                            if matches!(command_to_run, Command::Simple(_)) {
                                self.exec_in_place = true;
                            }
                            let status = self.execute(&command_to_run);
                            std::process::exit(status);
                        }
                        Ok(ForkResult::Parent { child }) => {
                            let mut job_text = String::new();
                            crate::builtins::format_command_into_pub(&mut job_text, &cmd_clone, 0);
                            self.record_background_job_pub(
                                child.as_raw(),
                                job_text.trim_end().to_string(),
                                !self.opts.monitor,
                            );
                            last_status = 0;
                            self.last_status = 0;
                        }
                        Err(e) => {
                            eprintln!("{}: fork: {}", crate::exec::shell_name(), e);
                            last_status = 1;
                        }
                    }
                } else {
                    // Suppress errexit only for the LHS of && or || (i.e., when this
                    // command's result is used as a condition to decide whether to run
                    // the next command). The RHS (prev_op is && or ||) is NOT suppressed
                    // — it's the final executed command and should trigger set -e on failure.
                    let is_lhs_of_andor = matches!(entry.op, ListOp::And | ListOp::Or);
                    if is_lhs_of_andor { self.suppress_errexit += 1; }
                    last_status = self.execute(&entry.command);
                    if is_lhs_of_andor { self.suppress_errexit -= 1; }
                    self.last_status = last_status;
                    // Deliver any pending signals (e.g. from kill -USR1 $$)
                    self.check_pending_signals();
                    last_status = self.last_status;
                }

                if self.exit_flag || self.return_flag {
                    return last_status;
                }

                // set -e: trigger for any failed command that is NOT:
                // - the LHS of && or || (its result is used as a condition)
                // - inside a nested suppress context
                // - a negated pipeline
                if self.opts.errexit && last_status != 0 && self.suppress_errexit == 0
                    && !self.last_was_negated
                    && !matches!(entry.op, ListOp::And | ListOp::Or)
                {
                    if !self.interactive {
                        self.exit_flag = true;
                        return last_status;
                    }
                }
                self.last_was_negated = false;
            }

            prev_op = entry.op.clone();

            if self.return_flag || self.break_count > 0 || self.continue_count > 0 {
                return last_status;
            }
        }

        last_status
    }

    // -----------------------------------------------------------------------
    // execute_if
    // -----------------------------------------------------------------------

    fn execute_if(&mut self, cmd: &IfCmd) -> i32 {
        if cmd.lineno > 0 {
            self.set_var("LINENO", &self.reporting_lineno(cmd.lineno).to_string());
        }
        let saved = match self.setup_redirects(&cmd.redirects) {
            Ok(s) => s,
            Err(e) => {
                if !e.is_empty() {
                    eprintln!("{}: {}", self.err_prefix_with_line(), e);
                }
                self.last_status = 1;
                self.fire_err_trap();
                return 1;
            }
        };

        // Evaluate condition — failing commands in the condition don't cause
        // the shell to exit under set -e.  We use a "suppress exit" counter
        // rather than modifying opts.errexit so that `set +e` / `set -e` inside
        // the condition affects the shell state persistently.
        let cond_status = {
            self.suppress_errexit += 1;
            let s = self.execute(&cmd.condition);
            self.suppress_errexit -= 1;
            s
        };

        let status = if cond_status == 0 {
            self.execute(&cmd.then_body)
        } else {
            let mut result = None;

            // Check elif branches
            for (elif_cond, elif_body) in &cmd.elif_parts {
                let cond = {
                    self.suppress_errexit += 1;
                    let s = self.execute(elif_cond);
                    self.suppress_errexit -= 1;
                    s
                };
                if cond == 0 {
                    result = Some(self.execute(elif_body));
                    break;
                }
            }

            if let Some(r) = result {
                r
            } else if let Some(else_branch) = &cmd.else_body {
                self.execute(else_branch)
            } else {
                0
            }
        };

        self.restore_redirects(saved);
        status
    }

    // -----------------------------------------------------------------------
    // execute_while
    // -----------------------------------------------------------------------

    fn execute_while(&mut self, cmd: &WhileCmd) -> i32 {
        if cmd.lineno > 0 {
            self.set_var("LINENO", &self.reporting_lineno(cmd.lineno).to_string());
        }
        let saved = match self.setup_redirects(&cmd.redirects) {
            Ok(s) => s,
            Err(e) => {
                if !e.is_empty() {
                    eprintln!("{}: {}", self.err_prefix_with_line(), e);
                }
                self.last_status = 1;
                self.fire_err_trap();
                return 1;
            }
        };

        let mut last_status = 0;
        self.loop_depth += 1;

        loop {
            if self.exit_flag {
                break;
            }

            // Check for pending signals between iterations.
            // This allows signal traps (e.g. kill -USR1 $$) to interrupt loops.
            self.check_pending_signals();
            if self.return_flag || self.exit_flag {
                break;
            }

            // Condition — set -e suppressed for the condition test
            let cond = {
                self.suppress_errexit += 1;
                let s = self.execute(&cmd.condition);
                self.suppress_errexit -= 1;
                s
            };

            if cond != 0 {
                break;
            }

            last_status = self.execute(&cmd.body);

            if self.break_count > 0 {
                self.break_count -= 1;
                break;
            }
            if self.continue_count > 0 {
                self.continue_count -= 1;
                if self.continue_count > 0 {
                    break; // propagate to outer loop
                }
                continue;
            }
            if self.return_flag || self.exit_flag {
                break;
            }
        }

        self.loop_depth -= 1;
        self.restore_redirects(saved);
        last_status
    }

    // -----------------------------------------------------------------------
    // execute_until
    // -----------------------------------------------------------------------

    fn execute_until(&mut self, cmd: &UntilCmd) -> i32 {
        if cmd.lineno > 0 {
            self.set_var("LINENO", &self.reporting_lineno(cmd.lineno).to_string());
        }
        let saved = match self.setup_redirects(&cmd.redirects) {
            Ok(s) => s,
            Err(e) => {
                if !e.is_empty() {
                    eprintln!("{}: {}", self.err_prefix_with_line(), e);
                }
                self.last_status = 1;
                self.fire_err_trap();
                return 1;
            }
        };

        let mut last_status = 0;
        self.loop_depth += 1;

        loop {
            if self.exit_flag {
                break;
            }

            let cond = {
                self.suppress_errexit += 1;
                let s = self.execute(&cmd.condition);
                self.suppress_errexit -= 1;
                s
            };

            if cond == 0 {
                // until loops until condition is true (non-zero means keep going)
                break;
            }

            last_status = self.execute(&cmd.body);

            if self.break_count > 0 {
                self.break_count -= 1;
                break;
            }
            if self.continue_count > 0 {
                self.continue_count -= 1;
                if self.continue_count > 0 {
                    break;
                }
                continue;
            }
            if self.return_flag || self.exit_flag {
                break;
            }
        }

        self.loop_depth -= 1;
        self.restore_redirects(saved);
        last_status
    }

    // -----------------------------------------------------------------------
    // execute_for
    // -----------------------------------------------------------------------

    fn execute_for(&mut self, cmd: &ForCmd) -> i32 {
        // Update LINENO so the error message (and any DEBUG trap) refers
        // to the line where the `for` starts.
        if cmd.lineno > 0 {
            self.set_var("LINENO", &cmd.lineno.to_string());
        }
        self.sync_dynamic_vars();
        if !self.in_debug_trap {
            let words = cmd.words.as_ref().map(|w| w.join(" ")).unwrap_or_default();
            if words.is_empty() {
                self.bash_command = format!("for {}", cmd.var);
            } else {
                self.bash_command = format!("for {} in {}", cmd.var, words);
            }
        }
        // Validate variable name: must be a valid shell identifier
        if !is_valid_identifier(&cmd.var) {
            eprintln!("{}: `{}': not a valid identifier", self.err_prefix_with_line(), cmd.var);
            // In POSIX mode, an invalid for-loop variable name is a
            // fatal shell error — exit immediately.
            if self.posix_mode {
                self.exit_flag = true;
                self.last_status = 1;
            }
            return 1;
        }

        let saved = match self.setup_redirects(&cmd.redirects) {
            Ok(s) => s,
            Err(e) => {
                if !e.is_empty() {
                    eprintln!("{}: {}", self.err_prefix_with_line(), e);
                }
                self.last_status = 1;
                self.fire_err_trap();
                return 1;
            }
        };

        // Expand the word list
        let words: Vec<String> = match &cmd.words {
            None => {
                // `for x; do` iterates over positional parameters
                (1..=self.vars.positional_count)
                    .map(|i| self.get_var(&i.to_string()).unwrap_or_default())
                    .collect()
            }
            Some(word_list) => {
                let mut result = Vec::new();
                for w in word_list {
                    let mut expanded = self.expand_word(w);
                    result.append(&mut expanded);
                }
                result
            }
        };

        // xtrace: capture the word list for display (already expanded above)
        let xtrace_words = words.clone();

        let mut last_status = 0;
        self.loop_depth += 1;

        for word in words {
            if self.exit_flag {
                break;
            }
            if cmd.lineno > 0 {
                self.set_var("LINENO", &cmd.lineno.to_string());
            }
            let trap_status = self.fire_debug_trap();
            if self.shopt.contains("extdebug") && trap_status == 2 {
                continue;
            }

            // xtrace: bash prints "+ for VAR in word1 word2 ..." once per iteration
            if self.opts.xtrace {
                let ps4 = self.get_var("PS4").unwrap_or_else(|| "+ ".to_string());
                let word_str = if xtrace_words.is_empty() {
                    String::new()
                } else {
                    format!(" {}", xtrace_words.join(" "))
                };
                self.xtrace_print(&format!("{}for {} in{}\n", ps4, cmd.var, word_str));
            }

            // Bash semantics: `for ref in ...` with ref being a nameref
            // retargets the nameref (sets ref's target to the iteration
            // word), rather than writing through to the current target.
            // This lets `for ref in first second` point ref at `first`,
            // then `second`, etc., so `${!ref}` yields the current name
            // and `$ref` yields the target's value.
            if self.vars.is_nameref(&cmd.var) {
                if !self.vars.set_nameref_target(&cmd.var, &word) {
                    last_status = 1;
                    if self.posix_mode {
                        self.exit_flag = true;
                    }
                    break;
                }
            } else {
                if self.vars.is_readonly(&cmd.var) {
                    eprintln!("{}: {}: readonly variable", self.err_prefix_with_line(), cmd.var);
                    last_status = 1;
                    if self.posix_mode {
                        self.exit_flag = true;
                    }
                    break;
                }
                self.set_var(&cmd.var, &word);
            }

            last_status = self.execute(&cmd.body);

            if self.break_count > 0 {
                self.break_count -= 1;
                break;
            }
            if self.continue_count > 0 {
                self.continue_count -= 1;
                if self.continue_count > 0 {
                    break;
                }
                continue;
            }
            if self.return_flag || self.exit_flag {
                break;
            }

            if self.opts.errexit && last_status != 0 && self.suppress_errexit == 0 {
                if !self.interactive {
                    self.exit_flag = true;
                    break;
                }
            }
        }

        self.loop_depth -= 1;
        self.restore_redirects(saved);
        last_status
    }

    // -----------------------------------------------------------------------
    // execute_select — minimal select implementation
    // -----------------------------------------------------------------------

    fn execute_select(&mut self, cmd: &SelectCmd) -> i32 {
        use std::io::{self, BufRead, Write};

        // Validate variable name BEFORE updating LINENO.
        // Bash reports this error at the function body `{` line when inside a
        // function (not at the `select` line); outside functions it uses the
        // select line.  We implement this by:
        //  - inside a function: LINENO is already the `{` line set by execute_group;
        //    do not overwrite it before the check.
        //  - outside a function: set LINENO to the select line for the check.
        let inside_function = !self.funcname_stack.is_empty();
        if !inside_function {
            if cmd.lineno > 0 {
                self.set_var("LINENO", &cmd.lineno.to_string());
            }
        } else if self.func_body_open_lineno > 0 {
            // Inside a function: make sure LINENO reflects the body-opener line
            // so that err_prefix_with_line() reports it correctly.
            self.set_var("LINENO", &self.func_body_open_lineno.to_string());
        }
        if !is_valid_identifier(&cmd.var) {
            eprintln!("{}: `{}': not a valid identifier", self.err_prefix_with_line(), cmd.var);
            if self.posix_mode {
                self.exit_flag = true;
                self.last_status = 1;
            }
            return 1;
        }

        // Now set LINENO to the select statement line for the rest of execution.
        if cmd.lineno > 0 {
            self.set_var("LINENO", &cmd.lineno.to_string());
        }

        let saved = match self.setup_redirects(&cmd.redirects) {
            Ok(s) => s,
            Err(e) => {
                if !e.is_empty() {
                    eprintln!("{}: {}", self.err_prefix_with_line(), e);
                }
                self.last_status = 1;
                self.fire_err_trap();
                return 1;
            }
        };

        // Expand the word list
        let words: Vec<String> = match &cmd.words {
            None => {
                (1..=self.vars.positional_count)
                    .map(|i| self.get_var(&i.to_string()).unwrap_or_default())
                    .collect()
            }
            Some(word_list) => {
                let mut result = Vec::new();
                for w in word_list {
                    let mut expanded = self.expand_word(w);
                    result.append(&mut expanded);
                }
                result
            }
        };

        if words.is_empty() {
            self.restore_redirects(saved);
            return 0;
        }

        let mut last_status = 0;
        self.loop_depth += 1;

        let stdin = io::stdin();

        loop {
            if self.exit_flag || self.return_flag {
                break;
            }

            for (i, w) in words.iter().enumerate() {
                eprint!("{}) {}\n", i + 1, w);
            }
            let prompt = self.get_var("PS3").unwrap_or_else(|| "#? ".to_string());
            let prompt = self.expand_prompt(&prompt);
            eprint!("{}", prompt);
            let _ = io::stderr().flush();

            // Read a line from stdin
            let mut line = String::new();
            let n = stdin.lock().read_line(&mut line).unwrap_or(0);
            if n == 0 {
                // EOF
                break;
            }

            let reply = line.trim();
            self.set_var("REPLY", reply);

            // Try to parse as number
            if let Ok(num) = reply.parse::<usize>() {
                if num >= 1 && num <= words.len() {
                    if self.vars.is_readonly(&cmd.var) {
                        eprintln!("{}: {}: readonly variable", self.err_prefix_with_line(), cmd.var);
                        last_status = 1;
                        if self.posix_mode {
                            self.exit_flag = true;
                        }
                        break;
                    }
                    // If the select variable is a nameref with an unresolved
                    // target, the assignment will fail with "not a valid
                    // identifier".  Bash breaks out of the select loop in
                    // this case rather than executing the body.
                    let nameref_unresolved = self.vars.is_nameref(&cmd.var)
                        && self.vars.resolve_nameref(&cmd.var).is_none();
                    self.set_var(&cmd.var, &words[num - 1]);
                    if nameref_unresolved {
                        last_status = 1;
                        break;
                    }
                } else {
                    if self.vars.is_readonly(&cmd.var) {
                        eprintln!("{}: {}: readonly variable", self.err_prefix_with_line(), cmd.var);
                        last_status = 1;
                        if self.posix_mode {
                            self.exit_flag = true;
                        }
                        break;
                    }
                    self.set_var(&cmd.var, "");
                }
            } else {
                if self.vars.is_readonly(&cmd.var) {
                    eprintln!("{}: {}: readonly variable", self.err_prefix_with_line(), cmd.var);
                    last_status = 1;
                    if self.posix_mode {
                        self.exit_flag = true;
                    }
                    break;
                }
                self.set_var(&cmd.var, "");
            }

            last_status = self.execute(&cmd.body);

            if self.break_count > 0 {
                self.break_count -= 1;
                break;
            }
            if self.continue_count > 0 {
                self.continue_count -= 1;
                if self.continue_count > 0 {
                    break;
                }
                continue;
            }
            if self.return_flag || self.exit_flag {
                break;
            }
        }

        self.loop_depth -= 1;
        self.restore_redirects(saved);
        last_status
    }

    // -----------------------------------------------------------------------
    // execute_case
    // -----------------------------------------------------------------------

    fn execute_case(&mut self, cmd: &CaseCmd) -> i32 {
        // Update LINENO to reflect the case statement's source line.
        if cmd.lineno > 0 {
            self.set_var("LINENO", &self.reporting_lineno(cmd.lineno).to_string());
        }
        self.sync_dynamic_vars();
        if !self.in_debug_trap {
            self.bash_command = format!("case {} in", cmd.word);
        }
        let trap_status = self.fire_debug_trap();
        if self.shopt.contains("extdebug") && trap_status == 2 {
            return 0;
        }
        let saved = match self.setup_redirects(&cmd.redirects) {
            Ok(s) => s,
            Err(e) => {
                eprintln!("{}: {}", self.err_prefix_with_line(), e);
                return 1;
            }
        };

        let word = self.expand_word_nosplit(&cmd.word);
        // Check for arithmetic expansion error in the case word
        if let Some(err) = Self::extract_arith_error(&word) {
            let lineno = self.get_var("LINENO").unwrap_or_else(|| "0".to_string());
            let (_expr, msg) = Self::split_arith_payload(&err);
            eprintln!("{}: line {}: {}", self.err_prefix(), lineno, msg);
            self.restore_redirects(saved);
            return 1;
        }

        // xtrace: bash prints "+ case WORD in"
        if self.opts.xtrace {
            let ps4 = self.get_var("PS4").unwrap_or_else(|| "+ ".to_string());
            self.xtrace_print(&format!("{}case {} in\n", ps4, word));
        }

        let mut final_status = 0;
        let mut fall_through = false;

        for arm in &cmd.arms {
            if arm.lineno > 0 {
                self.set_var("LINENO", &self.reporting_lineno(arm.lineno).to_string());
            }
            let mut matched = fall_through;
            if !matched {
                for pattern in &arm.patterns {
                    let expanded_pat = self.expand_case_pattern_word(pattern);
                    // Check for arithmetic expansion error in the pattern
                    if let Some(err) = Self::extract_arith_error(&expanded_pat) {
                        let lineno = self.get_var("LINENO").unwrap_or_else(|| "0".to_string());
                        let (_expr, msg) = Self::split_arith_payload(&err);
                        eprintln!("{}: line {}: {}", self.err_prefix(), lineno, msg);
                        self.restore_redirects(saved);
                        return 1;
                    }
                    if fnmatch_pattern(&expanded_pat, &word) {
                        matched = true;
                        break;
                    }
                }
            }

            if matched {
                let status = if let Some(ref body) = arm.body {
                    self.execute(body)
                } else {
                    0
                };
                final_status = status;
                // Handle ;; vs ;& vs ;;&
                match arm.terminator {
                    CaseTerminator::Break => {
                        break;
                    }
                    CaseTerminator::FallThrough => {
                        // ;& — execute next arm's body without testing pattern
                        fall_through = true;
                        continue;
                    }
                    CaseTerminator::Continue => {
                        // ;;& — test remaining patterns normally
                        fall_through = false;
                        continue;
                    }
                }
            }
        }

        self.restore_redirects(saved);
        final_status
    }

    /// If `e` contains an INNER marker (`\x00INNER\x00<inner>\x1F<msg>\x00`),
    /// return just the `<msg>` portion.  Otherwise return `e` unchanged.
    fn unwrap_inner_error_msg(e: &str) -> String {
        const INNER_PREFIX: &str = "\x00INNER\x00";
        if let Some(start) = e.find(INNER_PREFIX) {
            let rest = &e[start + INNER_PREFIX.len()..];
            if let Some(end) = rest.find('\x00') {
                let payload = &rest[..end];
                if let Some(sep) = payload.find('\x1F') {
                    return payload[sep+1..].to_string();
                }
            }
        }
        e.to_string()
    }

    /// Extract an arithmetic error payload from the `\x00ARITH_ERR\x00`
    /// sentinel.  The payload is either `<msg>` or `<expr>\x1F<msg>`.
    /// Returns the full payload for use with format_arith_err.
    fn extract_arith_error(s: &str) -> Option<String> {
        const PREFIX: &str = "\x00ARITH_ERR\x00";
        if let Some(start) = s.find(PREFIX) {
            let msg_start = start + PREFIX.len();
            let msg_end = s[msg_start..].find('\x00').map(|p| msg_start + p).unwrap_or(s.len());
            Some(s[msg_start..msg_end].to_string())
        } else {
            None
        }
    }

    /// Given the ARITH_ERR payload (either `<msg>` or `<expr>\x1F<msg>`),
    /// return (expr, msg).  If no expr is embedded, expr is empty.
    fn split_arith_payload(payload: &str) -> (String, String) {
        if let Some(i) = payload.find('\x1F') {
            (payload[..i].to_string(), payload[i + 1..].to_string())
        } else {
            (String::new(), payload.to_string())
        }
    }

    /// Synthesize bash's `(error token is "X")` suffix for an arithmetic
    /// error message, based on the expression.  If the message already
    /// contains that suffix, return as-is.  Otherwise derive a token
    /// from the expression (the trailing bit after the last operator).
    fn synthesize_arith_error_token(expr: &str, msg: &str) -> String {
        let normalized_expr = Self::normalize_arith_error_display(expr);
        let cooked_expr = Self::normalize_arith_error_expr(&normalized_expr);
        let base_msg = msg
            .split(" (error token is ")
            .next()
            .unwrap_or(msg)
            .trim_end();
        let trimmed_norm = normalized_expr.trim_start();
        let trimmed_cooked = cooked_expr.trim_start();
        let needs_resynth = msg.contains("(error token is")
            && base_msg.contains("operand expected")
            && (msg.contains("\\\"")
                || (trimmed_norm.contains('"') && trimmed_cooked != trimmed_norm));
        if msg.contains("(error token is") && !needs_resynth {
            return Self::normalize_arith_error_display(msg);
        }
        // Bash's "attempted assignment to non-variable" uses the LHS+op
        // as the token.  For "division by 0" it's "0 " (the divisor
        // plus any trailing whitespace).  For base errors it's the
        // whole base#value token.  Use heuristics per-message.
        if base_msg == "division by 0" || base_msg == "modulo by 0" {
            let tok = arith_err_token_at_zero(trimmed_cooked);
            return format!("{} (error token is \"{}\")", base_msg, tok);
        }
        if base_msg == "invalid arithmetic base"
            || base_msg == "invalid integer constant"
            || base_msg == "value too great for base"
            || base_msg == "invalid number"
        {
            // The token is the whole base#value expression (or what
            // looks like one at the end).
            let tok = normalized_expr.trim();
            return format!("{} (error token is \"{}\")", base_msg, tok);
        }
        // "arithmetic syntax error: operand expected" without a
        // specific token: bash appends `(error token is "TOKEN")`
        // where TOKEN is usually the first non-whitespace char/run
        // at which the parser failed.  Our arith lexer doesn't
        // preserve that position here, so fall back to the trimmed
        // expression when it's short enough to be the token — good
        // enough for the common `${#:%}` / `${foo:+}` cases.
        //
        // When the payload was formed as `"<name>: <expr>"` (by
        // `apply_substring`), the visible token is just the tail
        // after the last `": "` — extract it here so the error line
        // reads `#: %: ... (error token is "%")` rather than
        // `... (error token is "#: %")`.
        if base_msg == "arithmetic syntax error: operand expected" {
            if trimmed_norm.starts_with('"')
                && trimmed_norm.ends_with('"')
                && trimmed_cooked.is_empty()
            {
                return format!(
                    "{} (error token is \"{}\")",
                    base_msg, trimmed_norm
                );
            }
            let source = if trimmed_norm.contains('"') || trimmed_norm.contains('\'') {
                trimmed_cooked
            } else {
                trimmed_norm
            };
            let source_trimmed = source.trim();
            if source_trimmed.len() == 1
                && source.chars().last().map(|c| c.is_whitespace()).unwrap_or(false)
                && "+-*/%&|^<>!~?:".contains(source_trimmed)
            {
                return format!("{} (error token is \"{}\")", base_msg, source);
            }
            let tok = source_trimmed;
            if !tok.is_empty() {
                let final_tok = match tok.rfind(": ") {
                    Some(i) => tok[i + 2..].trim(),
                    None => tok,
                };
                // Special case: if the inner expression ends with a binary
                // operator (e.g. "4 + "), the error token is that trailing
                // operator.  Bash preserves any trailing whitespace present
                // in the ORIGINAL expression, but doesn't invent one when
                // the expression ends flush against the operator.
                //   "4 + "   → token "+ "
                //   "4 +"    → token "+"
                //   "%"      → token "%"
                // Only trigger the operator-tail extraction if the
                // expression has something BEFORE the operator (otherwise
                // the token IS the whole expr).
                let trimmed_inner = source.trim_end();
                if let Some(last_ch) = trimmed_inner.chars().last() {
                    if "+-*/%&|^<>!~".contains(last_ch) && trimmed_inner.len() > 1 {
                        // Extract the trailing operator from the original expr,
                        // preserving trailing whitespace (if any).
                        let op_start = source.rfind(last_ch).unwrap_or(0);
                        let op_tok = &source[op_start..];
                        return format!("{} (error token is \"{}\")", base_msg, op_tok);
                    }
                }
                return format!("{} (error token is \"{}\")", base_msg, final_tok);
            }
        }
        // Fallback: no token info.
        Self::normalize_arith_error_display(msg)
    }

    fn arith_error_token_from_msg(msg: &str) -> Option<String> {
        let marker = "(error token is \"";
        let start = msg.find(marker)? + marker.len();
        let rest = &msg[start..];
        let end = rest.find("\")")?;
        Some(rest[..end].to_string())
    }

    fn escape_quoted_arith_display(expr: &str) -> String {
        let chars: Vec<char> = expr.chars().collect();
        let mut out = String::new();
        let mut in_subscript = false;
        for (idx, ch) in chars.iter().copied().enumerate() {
            if matches!(ch, '\\' | '$') {
                out.push('\\');
                out.push(ch);
                continue;
            }
            match ch {
                '[' => {
                    if in_subscript {
                        out.push('\\');
                    }
                    out.push('[');
                    in_subscript = true;
                }
                ']' => {
                    if in_subscript {
                        let has_later_close = chars[idx + 1..].contains(&']');
                        if has_later_close {
                            out.push('\\');
                        } else {
                            in_subscript = false;
                        }
                    }
                    out.push(']');
                }
                _ => out.push(ch),
            }
        }
        out
    }

    fn escape_numeric_invalid_operator_expr(expr: &str, err_msg: &str) -> String {
        if !err_msg.contains("invalid arithmetic operator") {
            return expr.to_string();
        }
        if !expr.chars().next().map(|c| c.is_ascii_digit()).unwrap_or(false) {
            return expr.to_string();
        }
        expr.replace(']', "\\]").replace('[', "\\[")
    }

    fn rewrite_numeric_invalid_operator_token(err_msg: &str, escaped_expr: &str) -> String {
        if !err_msg.contains("invalid arithmetic operator") {
            return err_msg.to_string();
        }
        if !escaped_expr.chars().next().map(|c| c.is_ascii_digit()).unwrap_or(false) {
            return err_msg.to_string();
        }
        let Some(start) = err_msg.find("(error token is \"") else {
            return err_msg.to_string();
        };
        let prefix_len = "(error token is \"".len();
        let token_start = start + prefix_len;
        let Some(rel_end) = err_msg[token_start..].find("\")") else {
            return err_msg.to_string();
        };
        let token_end = token_start + rel_end;
        let escaped_token = escaped_expr
            .trim_start_matches(|c: char| c.is_ascii_digit())
            .to_string();
        let mut rewritten = err_msg.to_string();
        rewritten.replace_range(token_start..token_end, &escaped_token);
        rewritten
    }

    // -----------------------------------------------------------------------
    // execute_group — { list; }
    // -----------------------------------------------------------------------

    fn execute_group(&mut self, cmd: &GroupCmd) -> i32 {
        // Update LINENO and fire the DEBUG trap at the opening `{`, just as bash does.
        if cmd.lineno > 0 && self.suppress_lineno_update == 0 {
            self.set_var("LINENO", &cmd.lineno.to_string());
            self.sync_dynamic_vars();
        }
        // Track the function body opener line so that execute_select can report
        // errors at the `{` line (matching bash's behaviour for select inside functions).
        let saved_func_body_open_lineno = self.func_body_open_lineno;
        if !self.funcname_stack.is_empty() && cmd.lineno > 0 {
            self.func_body_open_lineno = cmd.lineno;
        }
        // Fire DEBUG trap before the group body (but only inside traced contexts).
        // Only fire if we are inside a function (funcname_stack non-empty) to avoid
        // firing for top-level brace groups (bash only fires for compound commands in
        // function bodies).
        if !self.funcname_stack.is_empty() {
            self.fire_debug_trap();
        }
        let saved = match self.setup_redirects(&cmd.redirects) {
            Ok(s) => s,
            Err(e) => {
                eprintln!("{}: {}", self.err_prefix_with_line(), e);
                return 1;
            }
        };
        let status = self.execute(&cmd.body);
        self.restore_redirects(saved);
        // Restore the outer func_body_open_lineno (handles nested brace groups).
        self.func_body_open_lineno = saved_func_body_open_lineno;
        status
    }

    // -----------------------------------------------------------------------
    // execute_subshell — ( list )
    // -----------------------------------------------------------------------

    fn execute_subshell(&mut self, cmd: &SubshellCmd) -> i32 {
        match unsafe { fork() } {
            Ok(ForkResult::Child) => {
                // Subshell-level fatal errors (e.g. POSIX-mode
                // `break`-as-function) are attributed to the closing `)`
                // line per bash convention.  Record it on the shell so
                // execute_func_def can pick it up.
                if cmd.end_lineno > 0 {
                    self.subshell_end_lineno = cmd.end_lineno;
                }
                // In subshell: apply redirects, execute, exit
                unsafe {
                    let _ = signal(Signal::SIGINT, SigHandler::SigDfl);
                    let _ = signal(Signal::SIGQUIT, SigHandler::SigDfl);
                }

                // Apply redirects in child
                for redir in &cmd.redirects {
                    if let Err(e) = apply_redirect_in_child(redir, self) {
                        eprintln!("{}: {}", self.err_prefix_with_line(), e);
                        std::process::exit(1);
                    }
                }

                // Subshells do NOT inherit the parent's EXIT trap.
                // The subshell can set its own EXIT trap inside its body.
                // Explicit ( ) subshells DO inherit ERR traps (bash behavior).
                self.traps.remove("EXIT");
                self.exit_trap_done = false;
                // Note: do NOT set in_pipeline_or_cmdsub=true here; explicit
                // subshells inherit and fire the ERR trap normally.

                // Increment BASH_SUBSHELL
                let subshell_n: usize = self
                    .get_var("BASH_SUBSHELL")
                    .and_then(|s| s.parse().ok())
                    .unwrap_or(0);
                self.set_var("BASH_SUBSHELL", &(subshell_n + 1).to_string());

                let status = self.execute(&cmd.body);
                // Run EXIT trap if it hasn't been run yet (do_exit runs it for `exit`
                // builtin calls; here we handle normal completion and set-e exits).
                if !self.exit_trap_done {
                    self.exit_trap_done = true;
                    if let Some(trap_cmd) = self.traps.get_exit_trap() {
                        let trap_cmd = trap_cmd.clone();
                        // Temporarily clear exit_flag so the trap body can execute
                        // (set-e may have set it before the EXIT trap runs).
                        let saved_exit_flag = self.exit_flag;
                        self.exit_flag = false;
                        self.run_string(&trap_cmd);
                        // Restore exit_flag unless the trap body itself called exit/do_exit
                        // (which sets exit_flag=true via do_exit).
                        if !self.exit_flag {
                            self.exit_flag = saved_exit_flag;
                        }
                    }
                }
                let final_status = if self.exit_flag {
                    self.last_status
                } else {
                    status
                };
                std::process::exit(final_status);
            }
            Ok(ForkResult::Parent { child }) => self.wait_for_child(child),
            Err(e) => {
                eprintln!("{}: fork: {}", crate::exec::shell_name(), e);
                1
            }
        }
    }

    // -----------------------------------------------------------------------
    // execute_coproc — coproc [NAME] command
    // -----------------------------------------------------------------------

    fn execute_coproc(&mut self, cmd: &CoprocCmd) -> i32 {
        if cmd.lineno > 0 {
            self.set_var("LINENO", &cmd.lineno.to_string());
        }
        let name = cmd.name.clone().unwrap_or_else(|| "COPROC".to_string());
        if !is_valid_identifier_pub(&name) {
            eprintln!("{}: `{}': not a valid identifier", self.err_prefix_with_line(), name);
            return 1;
        }
        if self.vars.is_nameref(&name) {
            let raw = self.vars.get_raw_scalar(&name).unwrap_or_default();
            if raw.is_empty() {
                eprintln!("{}: warning: {}: removing nameref attribute",
                    self.err_prefix_with_line(), name);
                self.vars.strip_nameref_value(&name);
            } else if !Variables::is_valid_nameref_target(&raw) {
                eprintln!("{}: `{}': not a valid identifier", self.err_prefix_with_line(), raw);
                return 1;
            } else if parse_subscripted_name_pub(&raw).is_some() {
                eprintln!("{}: `{}': not a valid identifier", self.err_prefix_with_line(), raw);
                return 1;
            }
        }
        let pid_var = format!("{}_PID", name);
        let readonly_name = self.vars.resolve_nameref(&name).unwrap_or_else(|| name.clone());
        // When the coproc array variable is readonly: bash emits the "readonly
        // variable" error but still forks the child process.  The child runs
        // its body; the parent skips the variable assignments (they'd fail
        // anyway).  When the child exits (during `wait`), bash tries to unset
        // the coproc vars and emits "cannot unset: readonly variable" for NAME.
        let name_is_readonly = self.vars.is_readonly(&name);
        let pid_is_readonly = self.vars.is_readonly(&pid_var);
        if name_is_readonly {
            eprintln!("{}: {}: readonly variable", self.err_prefix_with_line(), readonly_name);
        } else if pid_is_readonly {
            // The NAME_PID variable is readonly but NAME is not — also an
            // error that still allows the child to run (bash behaviour matches
            // the NAME-is-readonly case).
            let readonly_pid = self.vars.resolve_nameref(&pid_var).unwrap_or_else(|| pid_var.clone());
            eprintln!("{}: {}: readonly variable", self.err_prefix_with_line(), readonly_pid);
        }

        // Create two pipes:
        //   parent_read  <- child_write  (child stdout -> parent reads)
        //   child_read   <- parent_write (parent writes -> child stdin)
        let (child_stdout_r, child_stdout_w) = match pipe() {
            Ok(p) => (p.0.into_raw_fd(), p.1.into_raw_fd()),
            Err(e) => {
                eprintln!("{}: coproc: pipe: {}", crate::exec::shell_name(), e);
                return 1;
            }
        };
        let (child_stdin_r, child_stdin_w) = match pipe() {
            Ok(p) => (p.0.into_raw_fd(), p.1.into_raw_fd()),
            Err(e) => {
                eprintln!("{}: coproc: pipe: {}", crate::exec::shell_name(), e);
                return 1;
            }
        };

        match unsafe { fork() } {
            Ok(ForkResult::Child) => {
                unsafe {
                    // Wire child stdin to read end of parent->child pipe
                    libc::dup2(child_stdin_r, 0);
                    libc::close(child_stdin_r);
                    libc::close(child_stdin_w);

                    // Wire child stdout to write end of child->parent pipe
                    libc::dup2(child_stdout_w, 1);
                    libc::close(child_stdout_w);
                    libc::close(child_stdout_r);

                    let _ = signal(Signal::SIGINT, SigHandler::SigDfl);
                    let _ = signal(Signal::SIGQUIT, SigHandler::SigDfl);
                }

                let status = self.execute(&cmd.body);
                std::process::exit(status);
            }
            Ok(ForkResult::Parent { child }) => {
                // Close the child-side ends
                unsafe {
                    libc::close(child_stdin_r);
                    libc::close(child_stdout_w);
                }

                // Move fds to high numbers like bash:
                //   read fd (from child stdout) -> 63
                //   write fd (to child stdin)   -> 60
                const COPROC_READ_FD: RawFd = 63;
                const COPROC_WRITE_FD: RawFd = 60;

                let read_fd = if child_stdout_r != COPROC_READ_FD {
                    let rc = unsafe { libc::dup2(child_stdout_r, COPROC_READ_FD) };
                    if rc >= 0 {
                        unsafe { libc::close(child_stdout_r); }
                        COPROC_READ_FD
                    } else {
                        child_stdout_r
                    }
                } else {
                    child_stdout_r
                };

                let write_fd = if child_stdin_w != COPROC_WRITE_FD {
                    let rc = unsafe { libc::dup2(child_stdin_w, COPROC_WRITE_FD) };
                    if rc >= 0 {
                        unsafe { libc::close(child_stdin_w); }
                        COPROC_WRITE_FD
                    } else {
                        child_stdin_w
                    }
                } else {
                    child_stdin_w
                };

                // Clear FD_CLOEXEC — these fds must be inheritable so that
                // builtins like read/echo can use them via redirections.
                unsafe {
                    libc::fcntl(read_fd, libc::F_SETFD, 0);
                    libc::fcntl(write_fd, libc::F_SETFD, 0);
                }

                // Only set NAME array and NAME_PID when they are not readonly.
                if !name_is_readonly {
                    // Set NAME array: NAME[0] = read_fd, NAME[1] = write_fd
                    self.vars.set_array_element(&name, 0, &read_fd.to_string());
                    self.vars.set_array_element(&name, 1, &write_fd.to_string());
                }
                if !pid_is_readonly {
                    // Set NAME_PID = child pid
                    self.set_var(&pid_var, &(child.as_raw() as u32).to_string());
                }

                // Track this as a background process
                self.last_bg_pid = Some(child.as_raw() as u32);

                // Remember coproc name and PID for fd move tracking and cleanup.
                self.coproc_name = Some(name);
                self.coproc_pid = Some(child.as_raw());

                0
            }
            Err(e) => {
                eprintln!("{}: coproc: fork: {}", crate::exec::shell_name(), e);
                unsafe {
                    libc::close(child_stdin_r);
                    libc::close(child_stdin_w);
                    libc::close(child_stdout_r);
                    libc::close(child_stdout_w);
                }
                1
            }
        }
    }

    /// Called when a background process with the given PID exits (via wait).
    /// If this PID is the active coproc child, clean up the coproc array and
    /// PID variables.  Bash unsets NAME and NAME_PID when the coproc exits;
    /// if NAME is readonly, it emits "cannot unset: readonly variable".
    pub fn cleanup_coproc_on_exit_pub(&mut self, pid: i32) {
        let coproc_pid = match self.coproc_pid {
            Some(p) => p,
            None => return,
        };
        if pid != coproc_pid {
            return;
        }
        let name = match self.coproc_name.take() {
            Some(n) => n,
            None => return,
        };
        self.coproc_pid = None;
        // When name is a nameref, bash cleans up the resolved target, not
        // the nameref itself.  The nameref variable stays intact after cleanup.
        let resolved = self.vars.resolve_nameref(&name)
            .filter(|t| !t.contains('['));
        let effective_name = resolved.as_deref().unwrap_or(name.as_str());
        let pid_var = format!("{}_PID", effective_name);
        // Try to unset effective_name (the coproc array).
        if self.vars.is_readonly(effective_name) {
            eprintln!("{}: {}: cannot unset: readonly variable",
                self.err_prefix_with_line(), effective_name);
        } else {
            self.vars.force_unset(effective_name);
        }
        // Try to unset effective_name_PID.  For readonly-declared-no-value
        // vars, force_unset removes the entry (making declare -p say "not found").
        self.vars.force_unset(&pid_var);
    }

    /// After a move-fd redirect (e.g. `exec 4<&63-`), check if the moved fd
    /// belongs to the active coproc and update the array element to -1.
    fn update_coproc_fd_after_move(&mut self, target: &str) {
        if !target.ends_with('-') || target.len() <= 1 {
            return;
        }
        let name = match &self.coproc_name {
            Some(n) => n.clone(),
            None => return,
        };
        let num_str = &target[..target.len() - 1];
        let moved_fd: i32 = match num_str.parse() {
            Ok(n) => n,
            Err(_) => return,
        };
        if let Some(arr) = self.vars.get_array(&name) {
            for (i, val) in arr.iter().enumerate() {
                if val.parse::<i32>().ok() == Some(moved_fd) {
                    self.vars.set_array_element(&name, i, "-1");
                }
            }
        }
    }

    // -----------------------------------------------------------------------
    // execute_func_def — define a function
    // -----------------------------------------------------------------------

    fn execute_func_def(&mut self, cmd: &FuncDef) -> i32 {
        // Keep LINENO in sync with the function-definition's source line
        // so that error messages emitted below (and from the function's
        // body when eventually called) use the correct line number.
        if cmd.lineno > 0 {
            self.set_var("LINENO", &cmd.lineno.to_string());
        }
        // Bash rejects function names that contain shell metacharacters
        // like `$`, backticks, quotes, redirection operators, etc., both in
        // the `name()` shorthand form and with the `function` keyword.
        // Plain identifier-invalid names (like `11111` or `a.b`) are
        // permitted when declared with `function`.
        if !is_valid_function_name(&cmd.name) {
            let prefix = self.err_prefix_with_line();
            eprintln!("{}: `{}': not a valid identifier", prefix, cmd.name);
            self.last_status = 1;
            return 1;
        }
        // POSIX mode: defining a function with the same name as a POSIX
        // special builtin is a fatal error — the (sub)shell terminates.
        if self.posix_mode && crate::builtins::is_posix_special_builtin(&cmd.name) {
            // Bash attributes this error to the end of the enclosing
            // subshell (if any), not the function-definition line.  Use
            // the stored subshell_end_lineno when available.
            let line = if self.subshell_end_lineno > 0 {
                self.subshell_end_lineno
            } else {
                cmd.lineno
            };
            let base = self.err_prefix();
            eprintln!("{}: line {}: `{}': is a special builtin", base, line, cmd.name);
            self.last_status = 1;
            self.exit_flag = true;
            return 1;
        }
        // Readonly functions cannot be redefined.  Bash emits
        // "NAME: readonly function" and returns 1 for the
        // definition attempt.
        if self.readonly_functions.contains(&cmd.name) {
            let base = self.err_prefix_with_line();
            eprintln!("{}: {}: readonly function", base, cmd.name);
            self.last_status = 1;
            return 1;
        }
        self.functions.insert(cmd.name.clone(), std::rc::Rc::new(cmd.clone()));
        0
    }

    /// Parse a function definition from source text and register it.
    /// Used when importing BASH_FUNC_name%% environment variables.
    /// Silently ignores parse errors (security: don't crash on malformed input).
    pub fn define_function_from_src(&mut self, name: &str, src: &str) {
        let tokens = crate::lexer::tokenize(src);
        match crate::parser::parse(tokens) {
            Ok(cmd) => {
                if let crate::parser::Command::FuncDef(f) = cmd {
                    self.functions.insert(name.to_string(), std::rc::Rc::new(f));
                }
                // If it parsed but wasn't a FuncDef, ignore silently
            }
            Err(_) => {} // ignore parse errors for security
        }
    }

    // -----------------------------------------------------------------------
    // execute_arith_for — (( init; cond; step )) body
    // -----------------------------------------------------------------------

    /// Format an arithmetic error in bash-compatible style for for(( )) loops:
    ///   <script>: line <N>: ((: <expr_trimmed> : <error_msg>
    /// where <error_msg> is reformatted from raw arithmetic errors.
    fn arith_for_error(&self, expanded_expr: &str, raw_err: &str) -> String {
        self.format_arith_err(expanded_expr, raw_err)
    }



    /// Format an arithmetic error to match bash's
    ///   <script>: line <N>: ((: <expr> : <msg> (error token is "<tok>")
    /// wording.  Accepts either a raw message (e.g. "division by 0") or
    /// one that already contains an "(error token is \"...\")" suffix.
    pub fn format_arith_err(&self, expanded_expr: &str, raw_err: &str) -> String {
        let prefix = self.err_prefix_with_line();
        // Unwrap INNER marker if present (from recursive variable evaluation).
        // The inner marker is \x00INNER\x00<inner_expr>\x1F<msg>\x00.
        const INNER_PREFIX: &str = "\x00INNER\x00";
        if let Some(start) = raw_err.find(INNER_PREFIX) {
            let rest = &raw_err[start + INNER_PREFIX.len()..];
            if let Some(end) = rest.find('\x00') {
                let payload = &rest[..end];
                if let Some(sep) = payload.find('\x1F') {
                    let inner_expr = &payload[..sep];
                    let inner_msg = &payload[sep+1..];
                    let escaped_inner =
                        Self::escape_numeric_invalid_operator_expr(inner_expr, inner_msg);
                    let expr_display = escaped_inner.trim_start();
                    let err_msg = if inner_msg.contains("(error token is") {
                        Self::rewrite_numeric_invalid_operator_token(inner_msg, &escaped_inner)
                    } else {
                        Self::synthesize_arith_error_token(inner_expr, inner_msg)
                    };
                    return format!("{}: {}: {}", prefix, expr_display, err_msg);
                }
            }
        }
        if raw_err.contains("not a valid identifier") {
            return format!("{}: ((: {}", prefix, raw_err);
        }
        if raw_err.contains("operand expected")
            && expanded_expr.trim_start().starts_with('\'')
        {
            let cooked = crate::arithmetic::preprocess_arith_diagnostic_expr(
                expanded_expr,
                &self.vars,
            );
            let rendered = Self::escape_quoted_arith_display(
                &Self::normalize_arith_error_display(&cooked),
            );
            let expr_display = rendered.trim_start();
            return format!(
                "{}: ((: {}: arithmetic syntax error: operand expected (error token is \"{} \")",
                prefix,
                expr_display,
                expr_display.trim_end()
            );
        }
        let normalized_expr = Self::normalize_arith_error_display(expanded_expr);
        let cooked_expr = Self::normalize_arith_error_expr(&normalized_expr);
        let expr_display = if raw_err.contains("operand expected")
            && normalized_expr.contains('\'')
            && normalized_expr.trim_start().starts_with('\'')
        {
            Self::arith_error_token_from_msg(raw_err).unwrap_or_else(|| normalized_expr.clone())
        } else if raw_err.contains("operand expected")
            && normalized_expr.contains('"')
            && !normalized_expr.trim_start().starts_with('"')
        {
            cooked_expr.trim_start().to_string()
        } else {
            normalized_expr.trim_start().to_string()
        };
        let err_msg = if raw_err.contains("(error token is") {
            Self::normalize_arith_error_display(raw_err)
        } else if raw_err == "division by 0"
            || raw_err.contains("division by 0")
            || raw_err.contains("division by zero")
        {
            // Division-by-0 token is the `0` at the divisor position
            // plus any trailing whitespace from the expression.
            let token = arith_err_token_at_zero(cooked_expr.trim_start());
            format!("division by 0 (error token is \"{}\")", token)
        } else if raw_err.contains("modulo by 0") || raw_err.contains("modulo by zero") {
            let token = arith_err_token_at_zero(cooked_expr.trim_start());
            format!("modulo by 0 (error token is \"{}\")", token)
        } else if raw_err == "arithmetic syntax error: operand expected"
            || raw_err.contains("arithmetic syntax error: operand expected")
        {
            // Synthesize a token from the expression.
            Self::synthesize_arith_error_token(cooked_expr.trim_start(), raw_err)
        } else {
            raw_err.to_string()
        };
        format!("{}: ((: {}: {}", prefix, expr_display, err_msg)
    }

    fn execute_arith_for(&mut self, cmd: &ArithForCmd) -> i32 {
        // Update LINENO to the for(( )) command's line number.
        if cmd.lineno > 0 {
            self.set_var("LINENO", &cmd.lineno.to_string());
        }
        self.sync_dynamic_vars();
        if !self.in_debug_trap {
            self.bash_command = format!("for (( {}; {}; {} ))", cmd.init, cmd.cond, cmd.step);
        }
        let saved = match self.setup_redirects(&cmd.redirects) {
            Ok(s) => s,
            Err(e) => {
                eprintln!("{}: {}", self.err_prefix_with_line(), e);
                return 1;
            }
        };

        // xtrace: trace init expression
        if self.opts.xtrace && !cmd.init.trim().is_empty() {
            let ps4 = self.get_var("PS4").unwrap_or_else(|| "+ ".to_string());
            self.xtrace_print(&format!("{}(( {} ))\n", ps4, cmd.init));
        }

        // Evaluate init expression (expand $var references first).
        // An error in init aborts the loop entirely (matching bash).
        let init_expanded = expand::expand_arith_vars(&cmd.init, &mut self.vars);
        if !init_expanded.trim().is_empty() {
            if let Err(e) = crate::arithmetic::eval_expr_mut(&init_expanded, &mut self.vars) {
                // bash 5.3 fires the DEBUG trap before reporting an
                // init-time arithmetic error so the trap sees the
                // construct one last time.  The normal per-iteration
                // DEBUG-fire path doesn't run when init aborts.
                let _ = self.fire_debug_trap();
                eprintln!("{}", self.arith_for_error(&init_expanded, &e));
                self.restore_redirects(saved);
                return 1;
            }
        }

        let mut last_status = 0;
        self.loop_depth += 1;

        // Cache the LINENO string once: cmd.lineno is the same for every
        // iteration of this for-loop, and set_var("LINENO", ...) is called
        // up to 4 times per iteration.  Avoids 4 String allocations per
        // iter in tight arith for-loops.
        let lineno_str = if cmd.lineno > 0 {
            cmd.lineno.to_string()
        } else {
            String::new()
        };

        // Pre-check whether cond and step need $-expansion on each iteration.
        // For the common case `for ((i = 0; i < N; i++))` neither expression
        // contains `$`, `` ` ``, or `[`, so expand_arith_vars is a no-op.
        fn needs_expand(s: &str) -> bool {
            s.contains('$') || s.contains('`') || s.contains('[')
        }
        let cond_needs_expand = needs_expand(&cmd.cond);
        let step_needs_expand = needs_expand(&cmd.step);

        // Pre-lex cond and step (once) when they don't need per-iteration
        // expansion.  eval_expr_mut_from_lexed re-uses the token Vec by
        // cloning — cheaper than re-running the Lexer on each iteration.
        let cond_lexed = if !cond_needs_expand && !cmd.cond.trim().is_empty() {
            Some(crate::arithmetic::LexedExpr::lex(&cmd.cond))
        } else {
            None
        };
        let step_lexed = if !step_needs_expand && !cmd.step.trim().is_empty() {
            Some(crate::arithmetic::LexedExpr::lex(&cmd.step))
        } else {
            None
        };

        // Pre-analyse the loop body: when it is a plain
        // `VAR=$((expr))` command (single scalar assignment, no words,
        // no redirects, expr has no command-substitution or ${default}),
        // we can pre-lex `expr` once and bypass the full execute() +
        // expand_word_nosplit_assign_passwd path on every iteration.
        //
        // `body_fast` holds `(var_name, arith_expr_str, LexedExpr, body_lineno_str)`.
        let body_fast: Option<(String, String, crate::arithmetic::LexedExpr, String)> =
            if let crate::parser::Command::Simple(ref sc) = *cmd.body {
                if sc.words.is_empty() && sc.redirects.is_empty()
                    && sc.assignments.len() == 1
                    && !sc.assignments[0].append
                {
                    let a = &sc.assignments[0];
                    let v = a.value.trim();
                    // Must be a pure $((expr)) with no cmd-sub inside.
                    if v.starts_with("$((") && v.ends_with("))")
                        && !v.contains('`') && !v.contains("${")
                    {
                        let has_cmdsub = v.as_bytes().windows(2).enumerate().any(|(i, w)| {
                            w == b"$(" && v.as_bytes().get(i + 2).copied() != Some(b'(')
                        });
                        if !has_cmdsub {
                            // Strip outer `$(( ... ))` to get the raw expression.
                            let inner = &v[3..v.len() - 2];
                            let body_lineno = if sc.lineno > 0 {
                                sc.lineno.to_string()
                            } else {
                                String::new()
                            };
                            Some((
                                a.name.clone(),
                                inner.to_string(),
                                crate::arithmetic::LexedExpr::lex(inner),
                                body_lineno,
                            ))
                        } else { None }
                    } else { None }
                } else { None }
            } else { None };

        loop {
            if self.exit_flag {
                break;
            }

            if cmd.lineno > 0 {
                self.set_var("LINENO", &lineno_str);
            }
            let trap_status = self.fire_debug_trap();
            if self.shopt.contains("extdebug") && trap_status == 2 {
                last_status = 0;
                break;
            }
            if cmd.lineno > 0 {
                self.set_var("LINENO", &lineno_str);
            }
            let trap_status = self.fire_debug_trap();
            if self.shopt.contains("extdebug") && trap_status == 2 {
                last_status = 0;
                break;
            }

            // xtrace: trace condition expression
            if self.opts.xtrace && !cmd.cond.trim().is_empty() {
                let ps4 = self.get_var("PS4").unwrap_or_else(|| "+ ".to_string());
                self.xtrace_print(&format!("{}(( {} ))\n", ps4, cmd.cond));
            }

            // Evaluate condition; a result of 0 means false (exit loop).
            // An empty condition is always-true (like C's for(;;)).
            if !cmd.cond.trim().is_empty() {
                let cond_result = if let Some(lexed) = &cond_lexed {
                    // Fast path: use pre-lexed tokens (avoids re-running the Lexer).
                    crate::arithmetic::eval_expr_mut_from_lexed(lexed, &cmd.cond, &mut self.vars)
                } else {
                    let cond_str = expand::expand_arith_vars(&cmd.cond, &mut self.vars);
                    crate::arithmetic::eval_expr_mut(&cond_str, &mut self.vars)
                };
                match cond_result {
                    Ok(cond_val) => {
                        if cond_val == 0 {
                            last_status = 1; // (( expr )) returns 1 when expr is 0
                            break;
                        }
                    }
                    Err(e) => {
                        eprintln!("{}", self.arith_for_error(&cmd.cond, &e));
                        last_status = 1;
                        break;
                    }
                }
            }

            // Execute the loop body.  Use the pre-lexed fast path when
            // available (body is a plain `VAR=$((expr))` assignment) and no
            // tracing/debug features are active that need execute() semantics.
            let use_body_fast = body_fast.is_some()
                && !self.opts.xtrace
                && !self.opts.noexec
                && self.traps.get("DEBUG").is_none()
                && self.traps.get("ERR").is_none();
            last_status = if use_body_fast {
                let (ref var_name, ref expr_str, ref lexed, ref body_lineno) = body_fast.as_ref().unwrap();
                // Update LINENO for the body command (matches execute_simple).
                if !body_lineno.is_empty() && self.suppress_lineno_update == 0 {
                    self.set_var("LINENO", body_lineno);
                }
                // Evaluate the pre-lexed arithmetic expression directly.
                match crate::arithmetic::eval_expr_mut_from_lexed(lexed, expr_str, &mut self.vars) {
                    Ok(val) => {
                        let s = val.to_string();
                        if !self.vars.try_set_scalar_fast(var_name, &s) {
                            // Slow path for exotic vars (nameref, integer, etc.)
                            self.set_var(var_name, &s);
                        }
                        0 // pure assignment always returns 0
                    }
                    Err(e) => {
                        eprintln!("{}", self.arith_for_error(expr_str, &e));
                        1
                    }
                }
            } else {
                self.execute(&cmd.body)
            };

            if self.break_count > 0 {
                self.break_count -= 1;
                break;
            }
            if self.continue_count > 0 {
                self.continue_count -= 1;
                if self.continue_count > 0 {
                    break;
                }
                // evaluate step then continue; error in step terminates the loop
                if self.opts.xtrace && !cmd.step.trim().is_empty() {
                    let ps4 = self.get_var("PS4").unwrap_or_else(|| "+ ".to_string());
                    self.xtrace_print(&format!("{}(( {} ))\n", ps4, cmd.step));
                }
                if !cmd.step.trim().is_empty() {
                    let step_result = if let Some(lexed) = &step_lexed {
                        crate::arithmetic::eval_expr_mut_from_lexed(lexed, &cmd.step, &mut self.vars)
                    } else {
                        let step_str = expand::expand_arith_vars(&cmd.step, &mut self.vars);
                        crate::arithmetic::eval_expr_mut(&step_str, &mut self.vars)
                    };
                    if let Err(e) = step_result {
                        eprintln!("{}", self.arith_for_error(&cmd.step, &e));
                        last_status = 1;
                        break;
                    }
                }
                continue;
            }
            if self.return_flag || self.exit_flag {
                break;
            }

            // xtrace: trace step expression
            if self.opts.xtrace && !cmd.step.trim().is_empty() {
                let ps4 = self.get_var("PS4").unwrap_or_else(|| "+ ".to_string());
                self.xtrace_print(&format!("{}(( {} ))\n", ps4, cmd.step));
            }

            // Evaluate step expression; error terminates the loop.
            if !cmd.step.trim().is_empty() {
                let step_result = if let Some(lexed) = &step_lexed {
                    // Fast path: use pre-lexed tokens.
                    crate::arithmetic::eval_expr_mut_from_lexed(lexed, &cmd.step, &mut self.vars)
                } else {
                    let step_str = expand::expand_arith_vars(&cmd.step, &mut self.vars);
                    crate::arithmetic::eval_expr_mut(&step_str, &mut self.vars)
                };
                if let Err(e) = step_result {
                    eprintln!("{}", self.arith_for_error(&cmd.step, &e));
                    last_status = 1;
                    break;
                }
            }
        }

        self.loop_depth -= 1;
        self.restore_redirects(saved);
        last_status
    }

    // -----------------------------------------------------------------------
    // Redirect management
    // -----------------------------------------------------------------------

    /// Set up redirections, saving original fds so they can be restored.
    ///
    /// If any redirect fails, the error message is written to stderr **before**
    /// the already-applied redirects are restored.  This matches bash, which
    /// reports the error to the currently-active stderr — e.g. `2>&1 >&$v`
    /// with a bad `$v` writes the "Bad file descriptor" message to the pipe
    /// (the target of `2>&1`), not to the outer terminal.  The returned
    /// `Err(_)` payload is therefore a bare marker (no message); callers must
    /// NOT print it again.
    fn setup_redirects(&mut self, redirects: &[Redirect]) -> Result<Vec<SavedFd>, String> {
        let mut saved: Vec<SavedFd> = Vec::new();

        for redir in redirects {
            // Bash attributes redirect-time errors to the line where the
            // redirect operator appears, not the line of the surrounding
            // command (e.g. `done > file` failures report the `done` line,
            // not the `for` line).  Update LINENO to the redirect's lineno
            // before each open so err_prefix_with_line() picks it up.
            //
            // Special case: when running inside an explicit `( … )` subshell
            // bash attributes redirect-time errors to the closing-paren line
            // of the surrounding subshell rather than the redirect's own
            // line — see redir12.sub.  Honour that when subshell_end_lineno
            // has been recorded by the subshell-fork path.
            if redir.lineno > 0 {
                let reported = if self.subshell_end_lineno > 0 {
                    self.subshell_end_lineno
                } else {
                    redir.lineno
                };
                self.set_var("LINENO", &reported.to_string());
                self.sync_dynamic_vars();
            }
            // Resolve process substitution in redirect targets
            if Self::contains_procsub(&redir.target) {
                let mut child_pids: Vec<Pid> = Vec::new();
                let mut parent_fds: Vec<RawFd> = Vec::new();
                let resolved = self.resolve_procsub_in_str(
                    &redir.target, &mut child_pids, &mut parent_fds);
                let mut resolved_redir = redir.clone();
                resolved_redir.target = resolved;
                let saved_len_before = saved.len();
                let result = self.apply_redirect(&resolved_redir, &mut saved);
                // If the redirect's target fd happens to coincide with one of
                // the procsub parent fds, the saved dup captured a reference
                // to the pipe.  Restoring it would leak the pipe's fd after
                // the procsub-cleanup closes the original.  Detect this and
                // convert the saved entry to a "close on restore" marker so
                // the redirect's target fd is properly closed at the end.
                let target_fd = resolved_redir
                    .fd
                    .unwrap_or_else(|| default_fd_for_op(&resolved_redir.op));
                if parent_fds.contains(&target_fd) {
                    for entry in saved.iter_mut().skip(saved_len_before) {
                        if entry.original_fd == target_fd && entry.saved_fd >= 0 {
                            unsafe { libc::close(entry.saved_fd); }
                            entry.saved_fd = -2;
                        }
                    }
                }
                // Store procsub info in saved fds for cleanup
                for &fd in &parent_fds {
                    // If the procsub parent fd was overwritten by the redirect
                    // target, we don't need to close it separately — the
                    // SavedFd{-2} entry above will handle it.
                    if fd == target_fd {
                        continue;
                    }
                    saved.push(SavedFd { original_fd: fd, saved_fd: -1 });
                }
                // Store child pids for reaping in procsub_children
                for pid in child_pids {
                    self.procsub_children.push(pid);
                }
                if let Err(e) = result {
                    // Print BEFORE restoring so the error lands on the
                    // redirected stderr (e.g. the pipe, after 2>&1).
                    eprintln!("{}: {}", self.err_prefix_with_line(), e);
                    self.restore_redirects(saved);
                    return Err(String::new());
                }
            } else {
                let result = self.apply_redirect(redir, &mut saved);
                if let Err(e) = result {
                    eprintln!("{}: {}", self.err_prefix_with_line(), e);
                    self.restore_redirects(saved);
                    return Err(String::new());
                }
            }
        }

        Ok(saved)
    }

    fn apply_redirect(&mut self, redir: &Redirect, saved: &mut Vec<SavedFd>) -> Result<(), String> {
        // Expand the target word; heredocs use special expansion rules
        let target = match &redir.op {
            RedirectOp::Heredoc | RedirectOp::HeredocStrip if redir.heredoc_quoted => {
                // Quoted heredoc: no expansion at all
                redir.target.clone()
            }
            RedirectOp::Heredoc | RedirectOp::HeredocStrip => {
                // Unquoted heredoc: expand $var/$(cmd)/backtick only, preserve " and '
                let expanded = expand::expand_heredoc(&redir.target, &mut self.vars);
                self.resolve_cmdsubs(&expanded)
            }
            _ => {
                // Non-heredoc redirect: the target is expanded and then
                // (unlike normal word expansion) the shell checks that
                // only ONE field results.  If multiple words are
                // produced, bash errors: "<word>: ambiguous redirect".
                let expanded = self.expand_word_nosplit(&redir.target);
                // For here-strings, the \u{FFFE} sentinel from "$@" should
                // become a plain space (no field splitting in this context).
                let target = if matches!(&redir.op, RedirectOp::HereString) {
                    expanded.replace('\u{FFFE}', " ")
                } else {
                    expanded
                };
                // Check for ambiguous redirect — word splitting on IFS.
                // Only applies to file-like redirects (Input, Output,
                // Append, InputOutput, Clobber, AndOutput, AndAppend).
                // Here-strings <<< don't undergo word splitting at all;
                // the RHS is fed verbatim to the FD.  Dup targets (<&n,
                // >&n) can contain `-` but should be single-word anyway.
                if matches!(&redir.op,
                    RedirectOp::Input | RedirectOp::Output | RedirectOp::Append
                    | RedirectOp::InputOutput | RedirectOp::Clobber
                    | RedirectOp::AndOutput | RedirectOp::AndAppend)
                    || output_dup_uses_file_form(redir, &target)
                {
                    let ifs = self.vars.get("IFS").unwrap_or_else(|| " \t\n".to_string());
                    let fields = expand::word_split(&target, &ifs);
                    let count = fields.iter().filter(|f| !f.is_empty()).count();
                    if count > 1 {
                        return Err(format!("{}: ambiguous redirect", redir.target));
                    }
                }
                target
            }
        };

        // Bash `{name}<file` named-FD form: allocate a fresh FD >= 10
        // and store its number in the shell variable.  This does NOT
        // touch the standard fds and does NOT participate in restore.
        if let Some(varname) = redir.varfd.as_ref() {
            // For heredocs with varfd, we need to feed the content
            // via a temp file and redirect its fd to the variable.
            if matches!(&redir.op, RedirectOp::Heredoc | RedirectOp::HeredocStrip | RedirectOp::HereString) {
                return self.apply_varfd_heredoc(varname, &redir.op, &target, saved);
            }
            return self.apply_varfd_redirect(varname, &redir.op, &target, saved);
        }

        let fd = redir.fd.unwrap_or_else(|| default_fd_for_op(&redir.op));
        let redirects_both_output_streams =
            matches!(&redir.op, RedirectOp::AndOutput | RedirectOp::AndAppend)
                || output_dup_uses_file_form(redir, &target);

        // Save the original fd. If the fd wasn't previously open, remember
        // that (saved_fd = -2) so restore_redirects will close it rather
        // than leave it leaking — bash restores a previously-closed fd
        // by closing it, not by leaving the redirect-side fd open.
        push_saved_fd(saved, fd);
        if redirects_both_output_streams && fd != 2 {
            push_saved_fd(saved, 2);
        }

        match &redir.op {
            RedirectOp::Input => {
                // < file
                open_and_dup(&target, libc::O_RDONLY, 0o644, fd, self.opts.noclobber)?;
            }
            RedirectOp::Output => {
                // > file
                if self.opts.noclobber {
                    // Check if file exists
                    if std::path::Path::new(&target).exists() {
                        return Err(format!("{}: cannot overwrite existing file", target));
                    }
                }
                open_and_dup(
                    &target,
                    libc::O_WRONLY | libc::O_CREAT | libc::O_TRUNC,
                    0o644,
                    fd,
                    false,
                )?;
            }
            RedirectOp::Append => {
                // >> file
                open_and_dup(
                    &target,
                    libc::O_WRONLY | libc::O_CREAT | libc::O_APPEND,
                    0o644,
                    fd,
                    false,
                )?;
            }
            RedirectOp::InputOutput => {
                // <> file — open for reading and writing
                open_and_dup(
                    &target,
                    libc::O_RDWR | libc::O_CREAT,
                    0o644,
                    fd,
                    false,
                )?;
            }
            RedirectOp::InputDup => {
                // <&n or <&-
                dup_fd_with_label(&target, fd, &redir.target)?;
                // Track coproc fd moves: if source fd was a coproc fd and was
                // moved (trailing -), update the coproc array element to -1.
                self.update_coproc_fd_after_move(&target);
            }
            RedirectOp::OutputDup if output_dup_uses_file_form(redir, &target) => {
                // 1>&word / >&word with a non-fd word is the historical
                // "redirect both stdout and stderr to file" form in bash.
                open_and_dup(
                    &target,
                    libc::O_WRONLY | libc::O_CREAT | libc::O_TRUNC,
                    0o644,
                    1,
                    false,
                )?;
                let _ = unsafe { libc::dup2(1, 2) };
            }
            RedirectOp::OutputDup => {
                // >&n or >&-
                dup_fd_with_label(&target, fd, &redir.target)?;
                self.update_coproc_fd_after_move(&target);
            }
            RedirectOp::Clobber => {
                // >| file — force overwrite even with noclobber
                open_and_dup(
                    &target,
                    libc::O_WRONLY | libc::O_CREAT | libc::O_TRUNC,
                    0o644,
                    fd,
                    false,
                )?;
            }
            RedirectOp::Heredoc | RedirectOp::HeredocStrip => {
                // Here-document: use a temp file to avoid pipe-buffer deadlock
                // when the content exceeds the OS pipe buffer size.
                // Decode PUA-encoded raw bytes back to actual bytes.
                let raw = expand::decode_raw_bytes(&target);
                heredoc_via_tmpfile(&raw, fd)?;
            }
            RedirectOp::HereString => {
                // <<< word — write word + newline via temp file.
                // Decode PUA-encoded raw bytes back to their original bytes
                // so that e.g. $'\xff' in a here-string produces byte 0xFF.
                let content = format!("{}\n", target);
                let raw = expand::decode_raw_bytes(&content);
                heredoc_via_tmpfile(&raw, fd)?;
            }
            RedirectOp::AndOutput => {
                // &> file — redirect both stdout and stderr
                open_and_dup(
                    &target,
                    libc::O_WRONLY | libc::O_CREAT | libc::O_TRUNC,
                    0o644,
                    1,
                    false,
                )?;
                let _ = unsafe { libc::dup2(1, 2) };
            }
            RedirectOp::AndAppend => {
                // &>> file — append both stdout and stderr
                open_and_dup(
                    &target,
                    libc::O_WRONLY | libc::O_CREAT | libc::O_APPEND,
                    0o644,
                    1,
                    false,
                )?;
                let _ = unsafe { libc::dup2(1, 2) };
            }
        }

        Ok(())
    }

    /// Apply a `{name}<<DELIM` / `{name}<<<word` heredoc-style
    /// redirect.  Writes the content to a temp file and stores the
    /// resulting fd (>= 10) in the named variable.
    fn apply_varfd_heredoc(
        &mut self,
        varname: &str,
        op: &RedirectOp,
        content: &str,
        saved: &mut Vec<SavedFd>,
    ) -> Result<(), String> {
        if self.vars.is_readonly(varname) {
            eprintln!("{}: {}: readonly variable",
                self.err_prefix_with_line(), varname);
            return Err(format!("{}: cannot assign fd to variable", varname));
        }
        let body = if matches!(op, RedirectOp::HereString) {
            format!("{}\n", content)
        } else {
            content.to_string()
        };
        let raw = expand::decode_raw_bytes(&body);
        let raw_bytes: &[u8] = raw.as_slice();
        // mkstemp a temp file, write, unlink, rewind, fcntl to >= 10.
        let path = std::ffi::CString::new("/tmp/brash_vfd_XXXXXX")
            .map_err(|e| e.to_string())?;
        let path_raw = path.into_raw();
        let tmp_fd = unsafe { libc::mkstemp(path_raw) };
        if tmp_fd < 0 {
            let _ = unsafe { std::ffi::CString::from_raw(path_raw) };
            return Err(format!("{{{}}}: mkstemp: {}", varname, std::io::Error::last_os_error()));
        }
        unsafe { libc::unlink(path_raw) };
        let _ = unsafe { std::ffi::CString::from_raw(path_raw) };
        // Write body.
        let n = raw_bytes.len();
        let mut off = 0usize;
        while off < n {
            let w = unsafe {
                libc::write(
                    tmp_fd,
                    raw_bytes[off..].as_ptr() as *const libc::c_void,
                    n - off,
                )
            };
            if w < 0 {
                let err = std::io::Error::last_os_error();
                unsafe { libc::close(tmp_fd) };
                return Err(format!("{{{}}}: write: {}", varname, err));
            }
            if w == 0 { break; }
            off += w as usize;
        }
        // Rewind to start.
        unsafe { libc::lseek(tmp_fd, 0, libc::SEEK_SET) };
        // Move to fd >= 10 and close original.
        let new_fd = unsafe { libc::fcntl(tmp_fd, libc::F_DUPFD_CLOEXEC, 10) };
        unsafe { libc::close(tmp_fd) };
        if new_fd < 0 {
            return Err(format!("{{{}}}: cannot allocate fd", varname));
        }
        self.set_var(varname, &new_fd.to_string());
        if self.shopt.contains("varredir_close") {
            saved.push(SavedFd { original_fd: new_fd, saved_fd: -2 });
        }
        Ok(())
    }

    /// Apply a bash `{name}<file` / `{name}>file` style named-FD
    /// redirect.  Opens `target` with the appropriate flags, moves the
    /// result to a fresh FD >= 10, and stores that FD number in the
    /// shell variable `name`.  Does not need to save/restore existing
    /// standard fds — the allocation is on a previously unused fd.
    fn apply_varfd_redirect(
        &mut self,
        varname: &str,
        op: &RedirectOp,
        target: &str,
        saved: &mut Vec<SavedFd>,
    ) -> Result<(), String> {
        // `{var}>&-` or `{var}<&-` — close the fd currently stored in $var.
        // If the variable is unset or not a valid fd number, bash errors
        // with "varname: ambiguous redirect".
        if (matches!(op, RedirectOp::InputDup | RedirectOp::OutputDup)) && target == "-" {
            // Support `{arr[N]}<&-` — resolve the array element.
            let val = if let Some(br) = varname.find('[') {
                let base = &varname[..br];
                let idx_str = &varname[br + 1..varname.len().saturating_sub(1)];
                if let Ok(idx) = idx_str.parse::<usize>() {
                    self.vars.get_array_element(base, idx)
                } else {
                    None
                }
            } else {
                self.get_var(varname)
            };
            match val {
                Some(v) => match v.parse::<i32>() {
                    Ok(fd) => {
                        unsafe { libc::close(fd) };
                        return Ok(());
                    }
                    Err(_) => {
                        return Err(format!("{}: ambiguous redirect", varname));
                    }
                },
                None => {
                    return Err(format!("{}: ambiguous redirect", varname));
                }
            }
        }

        let (flags, is_dup) = match op {
            RedirectOp::Input => (libc::O_RDONLY, false),
            RedirectOp::Output | RedirectOp::Clobber => {
                (libc::O_WRONLY | libc::O_CREAT | libc::O_TRUNC, false)
            }
            RedirectOp::Append => (libc::O_WRONLY | libc::O_CREAT | libc::O_APPEND, false),
            RedirectOp::InputOutput => (libc::O_RDWR | libc::O_CREAT, false),
            RedirectOp::InputDup | RedirectOp::OutputDup => (0, true),
            other => {
                return Err(format!("{{{}}}: unsupported redirect op {:?}", varname, other));
            }
        };

        // Open (or duplicate) first so that a file-creating redirect
        // still creates the file even when the variable is readonly.
        // Bash opens the file then errors with "cannot assign fd" for a
        // readonly target — the side effect (file creation) persists.
        let new_fd: i32;
        if is_dup {
            // {name}<&M or {name}>&M — duplicate existing FD M to a
            // fresh slot.  A trailing `-` on the target means MOVE:
            // duplicate then close the original (bash semantics for
            // `<&N-` / `>&N-`).
            let (src_str, move_fd) = if let Some(rest) = target.strip_suffix('-') {
                (rest, true)
            } else {
                (target, false)
            };
            let src: i32 = src_str.parse().map_err(|_| {
                format!("{{{}}}: {}: ambiguous redirect", varname, target)
            })?;
            new_fd = unsafe { libc::fcntl(src, libc::F_DUPFD_CLOEXEC, 10) };
            if new_fd < 0 {
                return Err(format!("{{{}}}: {}: bad fd", varname, target));
            }
            if move_fd {
                unsafe { libc::close(src) };
            }
        } else {
            // Open the file.
            let cpath = std::ffi::CString::new(target)
                .map_err(|_| format!("{{{}}}: invalid filename", varname))?;
            let fd_opened = unsafe { libc::open(cpath.as_ptr(), flags, 0o644) };
            if fd_opened < 0 {
                let err = std::io::Error::last_os_error();
                // Use bash-style message (no "(os error N)" suffix).
                return Err(format!("{}: {}", target, bash_io_error_str(&err)));
            }
            // Move to fd >= 10.
            new_fd = unsafe { libc::fcntl(fd_opened, libc::F_DUPFD_CLOEXEC, 10) };
            if new_fd < 0 {
                // F_DUPFD_CLOEXEC failure — typically because we hit the
                // process fd limit (ulimit -n).  Bash emits two lines:
                //   script: redirection error: cannot duplicate fd: <errno>
                //   script: line N: <target>: <errno>
                // The first is a standalone "redirection error" header
                // printed without the line-number prefix, the second is
                // the usual line-prefixed message against the target
                // filename.
                let err = std::io::Error::last_os_error();
                let errstr = bash_io_error_str(&err);
                eprintln!("{}: redirection error: cannot duplicate fd: {}",
                    self.err_prefix(), errstr);
                unsafe { libc::close(fd_opened) };
                return Err(format!("{}: {}", target, errstr));
            }
            unsafe { libc::close(fd_opened) };
        }

        // Now apply the variable-write side effect — reject if readonly.
        // Bash emits BOTH "name: readonly variable" and "name: cannot
        // assign fd to variable" in this case.  We close the just-opened
        // fd so we don't leak it.
        if self.vars.is_readonly(varname) {
            unsafe { libc::close(new_fd) };
            eprintln!("{}: {}: readonly variable",
                self.err_prefix_with_line(), varname);
            return Err(format!("{}: cannot assign fd to variable", varname));
        }

        // When the variable is a nameref with an unresolved target, bash
        // treats the fd number as a new nameref target (since it's an
        // unresolved nameref assignment).  But fd numbers like "10" are
        // not valid identifiers, so the assignment fails.  Bash emits:
        //   exec: '<fd>': not a valid identifier
        //   <varname>: cannot assign fd to variable
        // We close the fd and emit both lines here to match.
        if self.vars.is_nameref(varname) && self.vars.resolve_nameref(varname).is_none() {
            unsafe { libc::close(new_fd) };
            eprintln!("{}: exec: `{}': not a valid identifier",
                self.err_prefix_with_line(), new_fd);
            return Err(format!("{}: cannot assign fd to variable", varname));
        }

        self.set_var(varname, &new_fd.to_string());
        if self.shopt.contains("varredir_close") {
            saved.push(SavedFd { original_fd: new_fd, saved_fd: -2 });
        }
        Ok(())
    }

    /// Restore saved file descriptors after redirections.
    fn restore_redirects(&mut self, saved: Vec<SavedFd>) {
        // Restore in reverse order
        for sfd in saved.into_iter().rev() {
            if sfd.saved_fd == -1 {
                // This is a procsub parent fd that needs closing
                let _ = close(sfd.original_fd);
                continue;
            }
            if sfd.saved_fd == -2 {
                // The target fd wasn't open before the redirect, so we can't
                // restore it to anything — just close it to avoid leaking the
                // newly-opened descriptor.
                let _ = close(sfd.original_fd);
                continue;
            }
            unsafe {
                libc::dup2(sfd.saved_fd, sfd.original_fd);
                libc::close(sfd.saved_fd);
            }
        }
        // Don't reap procsub children here - let wait builtin collect them
        self.procsub_children.clear();
    }

    // -----------------------------------------------------------------------
    // Command substitution  $( cmd ) or `cmd`
    // -----------------------------------------------------------------------

    fn execute_command_sub(&mut self, cmd_str: &str) -> String {
        let trimmed_cmd = cmd_str.trim();
        if let Some(path_expr) = trimmed_cmd.strip_prefix('<') {
            let expanded = self.expand_word_nosplit(path_expr.trim());
            let ifs = self.vars.get("IFS").unwrap_or_else(|| " \t\n".to_string());
            let fields = expand::word_split(&expanded, &ifs);
            let field_count = fields.iter().filter(|f| !f.is_empty()).count();
            if field_count > 1 {
                eprintln!("{}: {}: ambiguous redirect", self.err_prefix_with_line(), path_expr.trim());
                self.last_status = 1;
                self.cmdsub_counter += 1;
                return String::new();
            }

            let mut path = expanded;
            if !self.posix_mode && !self.opts.noglob {
                let globbed = expand::pathname_expand(&path);
                if globbed.len() > 1 {
                    eprintln!("{}: {}: ambiguous redirect", self.err_prefix_with_line(), path_expr.trim());
                    self.last_status = 1;
                    self.cmdsub_counter += 1;
                    return String::new();
                }
                if let Some(first) = globbed.into_iter().next() {
                    path = first;
                }
            }

            if !path.is_empty() {
                match std::fs::read(&path) {
                    Ok(bytes) => {
                        let trimmed = bytes
                            .iter()
                            .rposition(|&b| b != b'\n')
                            .map(|idx| &bytes[..=idx])
                            .unwrap_or(&[][..]);
                        self.last_status = 0;
                        self.cmdsub_counter += 1;
                        return crate::expand::encode_raw_bytes(trimmed);
                    }
                    Err(err) => {
                        match err.kind() {
                            std::io::ErrorKind::NotFound => {
                                eprintln!("{}: {}: No such file or directory", self.err_prefix_with_line(), path);
                            }
                            std::io::ErrorKind::PermissionDenied => {
                                eprintln!("{}: {}: Permission denied", self.err_prefix_with_line(), path);
                            }
                            _ => {
                                eprintln!("{}: {}: {}", self.err_prefix_with_line(), path, err);
                            }
                        }
                        self.last_status = 1;
                        self.cmdsub_counter += 1;
                        return String::new();
                    }
                }
            }
        }
        // Save the current enclosing source line so that — if the
        // cmdsub body fails to parse — the forked child can print the
        // outer line (matching bash's `_print_offending_line` which
        // shows `_shell_input_line`, not the `$(…)` body).
        //
        // `bash_command` holds the currently-executing command's
        // serialised form, which is a close-enough proxy for the
        // source line the user typed.  It's cleared in the parent
        // after this call completes so that subsequent non-cmdsub
        // errors don't mistakenly inherit it.
        let saved_parent_line = std::mem::take(&mut self.parent_source_line);
        let saved_parent_lineno = std::mem::replace(&mut self.parent_lineno, 0);
        // Capture the outer LINENO so child parse errors report the
        // enclosing script/command line rather than a line index inside
        // the cmdsub body.
        self.parent_lineno = self
            .get_var("LINENO")
            .and_then(|s| s.parse().ok())
            .unwrap_or(0);
        // Prefer the actual `-c` source line when available; for scripts and
        // interactive commands, fall back to the current serialized command.
        self.parent_source_line = if self.c_mode && self.parent_lineno > 0 {
            self.c_string
                .as_ref()
                .and_then(|src| src.lines().nth(self.parent_lineno.saturating_sub(1)))
                .unwrap_or("")
                .to_string()
        } else {
            // Use just the first line of bash_command.  A pre-existing lexer
            // bug (nested backtick + `}` ambiguity) sometimes slurps multiple
            // source lines into one command word; printing the whole thing as
            // the "offending line" would cascade into garbage output.
            self.bash_command
                .lines()
                .next()
                .unwrap_or("")
                .to_string()
        };

        // Create a pipe to capture stdout of the subshell
        let (read_fd, write_fd) = match pipe() {
            Ok(p) => (p.0.into_raw_fd(), p.1.into_raw_fd()),
            Err(e) => {
                eprintln!("{}: command substitution pipe: {}", crate::exec::shell_name(), e);
                return String::new();
            }
        };

        match unsafe { fork() } {
            Ok(ForkResult::Child) => {
                unsafe {
                    // Redirect stdout to write end of pipe
                    libc::dup2(write_fd, 1);
                    libc::close(write_fd);
                    libc::close(read_fd);

                    let _ = signal(Signal::SIGINT, SigHandler::SigDfl);
                    let _ = signal(Signal::SIGPIPE, SigHandler::SigDfl);
                }

                // Increment BASH_SUBSHELL
                let n: usize = self
                    .get_var("BASH_SUBSHELL")
                    .and_then(|s| s.parse().ok())
                    .unwrap_or(0);
                self.set_var("BASH_SUBSHELL", &(n + 1).to_string());

                // Command substitution does not inherit errexit (set -e) in non-posix mode.
                // In posix mode (set -o posix), cmd subs DO inherit set -e.
                // Any explicit `set -e` inside the $(...) will re-enable it.
                if !self.posix_mode && !self.shopt.contains("inherit_errexit") {
                    self.opts.errexit = false;
                }
                // Command substitutions are subshell-like: ERR trap does not fire
                // inside them (matches bash behavior).
                self.in_pipeline_or_cmdsub = true;

                // Suppress heredoc warnings: the outer parse already emitted
                // any heredoc-terminated-by-EOF warnings for this content.
                self.suppress_heredoc_warnings = true;
                // Clear any inherited pending warnings from the parent.
                self.pending_heredoc_warnings.clear();
                // Reset alias expansion tracking in the subshell so that aliases
                // being expanded in the parent can be expanded again here.
                self.expanding_aliases.clear();

                // Offset line numbers inside the cmdsub body so errors
                // report the outer-script line.  If the cmdsub opened
                // on outer line N, prepending N-1 newlines makes body
                // line 1 be reported as N.  Bash does equivalent
                // bookkeeping via shell_input_line_index offsets.
                let cmd_body = cmd_str.trim_start_matches(|c| matches!(c, ' ' | '\t' | '\n'));
                let status = if self.parent_lineno > 1 {
                    // Avoid a heap allocation in the common case where the cmd
                    // body is small: build the padded string once with exact capacity.
                    let pad = self.parent_lineno - 1;
                    let mut s = String::with_capacity(pad + cmd_body.len());
                    for _ in 0..pad { s.push('\n'); }
                    s.push_str(cmd_body);
                    self.run_string(&s)
                } else {
                    self.run_string(cmd_body)
                };
                std::process::exit(status);
            }
            Ok(ForkResult::Parent { child }) => {
                unsafe {
                    libc::close(write_fd);
                }
                // Refresh tilde-home cache: bash updates the cache at every
                // fork (including command substitutions), so subsequent ~
                // expansions in the parent reflect current $HOME.
                self.vars.refresh_home_cache();

                // Read all output from child
                let mut output = Vec::new();
                let mut buf = [0u8; 4096];
                loop {
                    let n = unsafe {
                        libc::read(read_fd, buf.as_mut_ptr() as *mut libc::c_void, buf.len())
                    };
                    if n <= 0 {
                        break;
                    }
                    output.extend_from_slice(&buf[..n as usize]);
                }
                unsafe { libc::close(read_fd); }

                let child_status = self.wait_for_child(child);
                self.cmdsub_counter += 1;

                // Bash halts the outer parser when a `$(…)` body is
                // syntactically invalid (child exits with status 2 from
                // `parser_error`).  The subsequent commands in the
                // enclosing script are NOT executed.  Propagate this
                // via `exit_flag`.
                if child_status == 2 {
                    self.exit_flag = true;
                    self.last_status = 2;
                }

                // Restore parent's enclosing source line / lineno markers.
                self.parent_source_line = saved_parent_line;
                self.parent_lineno = saved_parent_lineno;

                // Strip trailing newlines (bash behavior)
                let s = String::from_utf8_lossy(&output).into_owned();
                s.trim_end_matches('\n').to_string()
            }
            Err(e) => {
                eprintln!("{}: fork: {}", crate::exec::shell_name(), e);
                unsafe {
                    libc::close(read_fd);
                    libc::close(write_fd);
                }
                String::new()
            }
        }
    }

    fn execute_nofork_command_sub(&mut self, cmd_str: &str, reply_only: bool) -> String {
        let saved_return_flag = self.return_flag;
        let saved_reply = if reply_only { self.vars.get("REPLY") } else { None };
        let saved_source_depth = self.source_depth;
        let saved_parent_line = std::mem::take(&mut self.parent_source_line);
        let saved_parent_lineno = std::mem::replace(&mut self.parent_lineno, 0);
        let saved_in_pipeline_or_cmdsub = self.in_pipeline_or_cmdsub;

        self.local_option_snapshots.push(None);
        self.vars.push_scope();
        self.source_depth += 1;
        self.in_pipeline_or_cmdsub = true;

        let mut saved_stdout: RawFd = -1;
        let mut read_fd: RawFd = -1;
        let mut write_fd: RawFd = -1;
        if !reply_only {
            match pipe() {
                Ok((r, w)) => {
                    read_fd = r.into_raw_fd();
                    write_fd = w.into_raw_fd();
                }
                Err(e) => {
                    eprintln!("{}: command substitution pipe: {}", crate::exec::shell_name(), e);
                    self.vars.pop_scope();
                    self.local_option_snapshots.pop();
                    self.source_depth = saved_source_depth;
                    return String::new();
                }
            }
            saved_stdout = unsafe { libc::dup(1) };
            if saved_stdout < 0 {
                eprintln!("{}: dup: {}", crate::exec::shell_name(), std::io::Error::last_os_error());
                unsafe {
                    libc::close(read_fd);
                    libc::close(write_fd);
                }
                self.vars.pop_scope();
                self.local_option_snapshots.pop();
                self.source_depth = saved_source_depth;
                return String::new();
            }
            unsafe {
                libc::dup2(write_fd, 1);
            }
        }

        self.parent_lineno = self
            .get_var("LINENO")
            .and_then(|s| s.parse().ok())
            .unwrap_or(0);
        self.parent_source_line = if self.c_mode && self.parent_lineno > 0 {
            self.c_string
                .as_ref()
                .and_then(|src| src.lines().nth(self.parent_lineno.saturating_sub(1)))
                .unwrap_or("")
                .to_string()
        } else {
            self.bash_command
                .lines()
                .next()
                .unwrap_or("")
                .to_string()
        };
        let padded = if self.parent_lineno > 0 {
            let newline_pad = if cmd_str.contains('\n') {
                self.parent_lineno
            } else {
                self.parent_lineno.saturating_sub(1)
            };
            let mut s = "\n".repeat(newline_pad);
            s.push_str(cmd_str);
            s
        } else {
            cmd_str.to_string()
        };
        let status = if !self.posix_mode && !self.shopt.contains("inherit_errexit") {
            self.suppress_errexit += 1;
            let s = self.run_string(&padded);
            self.suppress_errexit -= 1;
            s
        } else {
            self.run_string(&padded)
        };
        let final_status = if self.return_flag { self.last_status } else { status };
        self.return_flag = saved_return_flag;

        let reply_result = if reply_only {
            self.vars.get("REPLY").unwrap_or_default()
        } else {
            String::new()
        };

        let output_result = if reply_only {
            String::new()
        } else {
            let _ = std::io::stdout().flush();
            unsafe {
                libc::dup2(saved_stdout, 1);
                libc::close(saved_stdout);
                libc::close(write_fd);
            }
            let mut bytes = Vec::new();
            let mut reader = unsafe { std::fs::File::from_raw_fd(read_fd) };
            let _ = reader.read_to_end(&mut bytes);
            let trimmed = bytes
                .iter()
                .rposition(|&b| b != b'\n')
                .map(|idx| &bytes[..=idx])
                .unwrap_or(&[][..]);
            crate::expand::encode_raw_bytes(trimmed)
        };

        self.vars.pop_scope();
        self.source_depth = saved_source_depth;
        self.parent_source_line = saved_parent_line;
        self.parent_lineno = saved_parent_lineno;
        self.in_pipeline_or_cmdsub = saved_in_pipeline_or_cmdsub;
        if let Some(Some((saved_opts, saved_posix_mode))) = self.local_option_snapshots.pop() {
            self.opts = saved_opts;
            self.posix_mode = saved_posix_mode;
            self.vars.posix_mode = self.posix_mode;
            if self.opts.ignoreeof {
                self.vars.set_raw("IGNOREEOF", "10");
            } else {
                self.vars.force_unset("IGNOREEOF");
            }
            self.sync_dynamic_vars();
        }

        if reply_only {
            match saved_reply {
                Some(v) => self.vars.set("REPLY", &v),
                None => self.vars.unset("REPLY"),
            }
        }

        self.last_status = final_status;
        self.cmdsub_counter += 1;
        if reply_only { reply_result } else { output_result }
    }

    // -----------------------------------------------------------------------
    // Word expansion
    // -----------------------------------------------------------------------

    /// Sync dynamic shell variables into the variable store so that
    /// expand.rs (which only sees &Variables) can access them.
    /// Publish the current glob-related shopt flags into the thread-
    /// local `GLOB_SHOPTS` cell so stateless expand helpers can read
    /// them without a Shell reference.
    fn sync_glob_shopts(&self) {
        GLOB_SHOPTS.with(|c| c.set(GlobShopts {
            dotglob: self.shopt.contains("dotglob"),
            nocaseglob: self.shopt.contains("nocaseglob"),
            nocasematch: self.shopt.contains("nocasematch"),
            nullglob: self.shopt.contains("nullglob"),
            failglob: self.shopt.contains("failglob"),
            globstar: self.shopt.contains("globstar"),
            extglob: self.shopt.contains("extglob"),
            globskipdots: self.shopt.contains("globskipdots"),
            patsub_replacement: self.shopt.contains("patsub_replacement"),
        }));
        GLOB_RUNTIME.with(|r| {
            *r.borrow_mut() = GlobRuntime {
                globignore: self.vars.get("GLOBIGNORE").filter(|s| !s.is_empty()),
                globsort: self.vars.get("GLOBSORT"),
            };
        });
    }

    fn sync_dynamic_vars(&mut self) {
        self.sync_glob_shopts();
        CMDSUB_EXPAND_RUNTIME.with(|runtime| {
            *runtime.borrow_mut() = ExpandCmdsubRuntime {
                aliases: self.aliases.clone(),
                functions: self.functions.clone(),
                shopt: self.shopt.clone(),
            };
        });
        self.vars.posix_mode = self.posix_mode;
        self.vars.nounset = self.opts.nounset;
        self.vars.localvar_unset = self.shopt.contains("localvar_unset");
        self.vars.set("?", &self.last_status.to_string());
        self.vars.set("$", &self.original_pid.to_string());
        if let Some(pid) = self.last_bg_pid {
            self.vars.set("!", &pid.to_string());
        }
        self.vars.set("SECONDS", &self.start_time.elapsed().as_secs().to_string());
        // BASHPID: current process ID (changes in subshells)
        self.vars.set("BASHPID", &std::process::id().to_string());
        // EPOCHSECONDS & EPOCHREALTIME
        let now = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap_or_default();
        self.vars.set("EPOCHSECONDS", &now.as_secs().to_string());
        self.vars.set("EPOCHREALTIME", &format!("{}.{:06}", now.as_secs(), now.subsec_micros()));
        // BASH_ARGV0 → reflects $0
        if let Some(arg0) = self.vars.get("0") {
            self.vars.set("BASH_ARGV0", &arg0);
        }
        // BASH_COMMAND
        if !self.bash_command.is_empty() {
            let cmd = self.bash_command.clone();
            self.vars.set("BASH_COMMAND", &cmd);
        }
        // PIPESTATUS array
        let ps: Vec<String> = self.pipestatus.iter().map(|s| s.to_string()).collect();
        self.vars.set_array("PIPESTATUS", ps);
        // Bash exposes an empty DIRSTACK until pushd/popd populate it.
        let dirstack = if self.dirstack.len() <= 1 {
            Vec::new()
        } else {
            self.dirstack.clone()
        };
        self.vars.set_array("DIRSTACK", dirstack);
        self.vars.declare_assoc("BASH_ALIASES");
        self.vars.clear_assoc("BASH_ALIASES");
        for (name, value) in self.aliases.clone() {
            self.vars.set_assoc("BASH_ALIASES", &name, &value);
        }
        self.vars.mark_initialized("BASH_ALIASES");
        self.vars.declare_assoc("BASH_CMDS");
        self.vars.clear_assoc("BASH_CMDS");
        for (name, value) in self.hash_table.clone() {
            self.vars.set_assoc("BASH_CMDS", &name, &value);
        }
        self.vars.mark_initialized("BASH_CMDS");
        // BASH_ARGC / BASH_ARGV reflect the current function-call stack.
        self.vars.set_array(
            "BASH_ARGC",
            self.bash_argc_stack.iter().map(|n| n.to_string()).collect(),
        );
        self.vars.set_array("BASH_ARGV", self.bash_argv_stack.clone());
        self.sync_stack_trace_arrays();
        // $- : current option flags (single-char flags that are enabled)
        // Order matches bash's internal flag ordering (from flags.c alist).
        {
            let mut flags = String::new();
            if self.opts.allexport    { flags.push('a'); }
            if self.opts.notify       { flags.push('b'); }
            if self.opts.noexec       { flags.push('n'); }
            if self.opts.noglob       { flags.push('f'); }
            if self.opts.xtrace       { flags.push('x'); }
            if self.opts.verbose      { flags.push('v'); }
            if self.opts.errexit      { flags.push('e'); }
            if self.opts.nounset      { flags.push('u'); }
            if self.opts.monitor      { flags.push('m'); }
            if self.opts.hashall      { flags.push('h'); }
            if self.interactive       { flags.push('i'); }
            if self.opts.privileged   { flags.push('p'); }
            if self.opts.onecmd       { flags.push('t'); }
            if self.opts.braceexpand  { flags.push('B'); }
            if self.opts.noclobber    { flags.push('C'); }
            if self.opts.errtrace     { flags.push('E'); }
            if self.opts.history      { flags.push('H'); }
            if self.opts.physical     { flags.push('P'); }
            if self.opts.functrace    { flags.push('T'); }
            if self.c_mode            { flags.push('c'); }
            if self.opts.keyword_assign { flags.push('k'); }
            self.vars.set("-", &flags);
        }
        // SHELLOPTS: colon-separated list of `set -o` options that are
        // currently on.  Bash keeps this synchronised with the flag
        // state (and marks it readonly).
        {
            let mut names: Vec<&str> = Vec::new();
            if self.opts.allexport    { names.push("allexport"); }
            if self.opts.braceexpand  { names.push("braceexpand"); }
            if self.opts.emacs        { names.push("emacs"); }
            if self.opts.errexit      { names.push("errexit"); }
            if self.opts.errtrace     { names.push("errtrace"); }
            if self.opts.functrace    { names.push("functrace"); }
            if self.opts.hashall      { names.push("hashall"); }
            if self.opts.history      { names.push("histexpand"); }
            if self.opts.history_facility { names.push("history"); }
            if self.opts.ignoreeof    { names.push("ignoreeof"); }
            if self.opts.interactive_comments { names.push("interactive-comments"); }
            if self.opts.keyword_assign { names.push("keyword"); }
            if self.opts.monitor      { names.push("monitor"); }
            if self.opts.noclobber    { names.push("noclobber"); }
            if self.opts.noexec       { names.push("noexec"); }
            if self.opts.noglob       { names.push("noglob"); }
            if self.opts.nolog        { names.push("nolog"); }
            if self.opts.notify       { names.push("notify"); }
            if self.opts.nounset      { names.push("nounset"); }
            if self.opts.onecmd       { names.push("onecmd"); }
            if self.opts.physical     { names.push("physical"); }
            if self.opts.pipefail     { names.push("pipefail"); }
            if self.posix_mode        { names.push("posix"); }
            if self.opts.privileged   { names.push("privileged"); }
            if self.opts.verbose      { names.push("verbose"); }
            if self.opts.vi           { names.push("vi"); }
            if self.opts.xtrace       { names.push("xtrace"); }
            self.vars.set_raw("SHELLOPTS", &names.join(":"));
            self.vars.set_readonly("SHELLOPTS");
        }
        // BASHOPTS: colon-separated list of `shopt` options currently on.
        {
            let mut shopts: Vec<String> = self.shopt.iter().cloned().collect();
            shopts.sort();
            self.vars.set_raw("BASHOPTS", &shopts.join(":"));
            self.vars.set_readonly("BASHOPTS");
        }
        // PWD: prefer the logical path already stored in $PWD; only fall
        // back to the physical current_dir() when PWD has never been set.
        if self.vars.get("PWD").is_none() {
            if let Ok(cwd) = std::env::current_dir() {
                self.vars.set("PWD", &cwd.to_string_lossy());
            }
        }
    }

    /// Expand a word with field splitting and glob expansion.
    /// Resolves command substitution markers between expansion and word splitting
    /// so that CMDSUB markers aren't broken by IFS splitting.
    fn expand_word(&mut self, word: &str) -> Vec<String> {
        self.sync_dynamic_vars();
        self.apply_assign_defaults(word);

        if let Some(resolved) = self.expand_live_nofork_double_quoted_word(word) {
            return vec![resolved];
        }

        let brace_expanded = expand::brace_expand(word);
        let mut fields: Vec<String> = Vec::new();

        for token in &brace_expanded {
            // Expand all parameter/arithmetic/tilde/command substitutions.
            // Use expand_all_for_split when the token will undergo word
            // splitting, so that IFS-whitespace inside quotes is marked with
            // CTLESC and preserved across splitting.
            let will_split = expand::has_expansion_chars(token) && !expand::is_fully_quoted(token);
            let expanded = if let Some(marker) = Self::heredoc_command_sub_marker(token) {
                marker
            } else if will_split {
                expand::expand_all_for_split(token, &mut self.vars)
            } else {
                expand::expand_all(token, &mut self.vars)
            };
            // Resolve CMDSUB markers BEFORE word splitting
            let resolved = self.resolve_cmdsubs(&expanded);
            let resolved_for_split = resolved.replace("\x00EMPTY_AT\x00", "");

            // Detect arithmetic errors before field splitting can
            // fragment the sentinel across multiple words.
            if let Some(err) = Self::extract_arith_error(&resolved) {
                let (expr, msg) = Self::split_arith_payload(&err);
                let mut msg_with_token = Self::synthesize_arith_error_token(&expr, &msg);
                if expr.is_empty() {
                    eprintln!("{}: {}", self.err_prefix_with_line(), msg_with_token);
                } else {
                    // Bash preserves trailing whitespace for expression-level
                    // errors (division by 0, assignment to non-variable, etc.)
                    // but strips it for token-level errors (invalid
                    // arithmetic base, invalid integer constant, …).
                    let is_tokenizer_err = msg.starts_with("invalid arithmetic base")
                        || msg.starts_with("invalid integer constant")
                        || msg.starts_with("invalid number")
                        || msg.starts_with("value too great for base");
                    let normalized_expr = Self::normalize_arith_error_display(&expr);
                    let display_expr = if is_tokenizer_err {
                        normalized_expr.trim().to_string()
                    } else {
                        normalized_expr.trim_start().to_string()
                    };
                    if !msg_with_token.contains("(error token is")
                        && msg.contains("operand expected")
                        && display_expr.trim_start().starts_with('"')
                    {
                        msg_with_token = format!(
                            "{} (error token is \"{}\")",
                            msg.trim_end(),
                            display_expr
                        );
                    }
                    // Bash omits the <expr>: prefix for errors that
                    // already name the variable (readonly, etc.), so the
                    // error reads "line N: xx: readonly variable" rather
                    // than "line N: xx=5: xx: readonly variable".
                    // Also skip expr for "unbound variable" and "expression
                    // recursion level exceeded" — bash prints just the varname.
                    let skip_expr = msg.ends_with(": readonly variable")
                        || msg.ends_with(": unbound variable")
                        || msg.contains(": expression recursion level exceeded")
                        || msg.contains("not a valid identifier");
                    if skip_expr {
                        eprintln!("{}: {}",
                            self.err_prefix_with_line(), msg_with_token);
                    } else {
                        eprintln!("{}: {}: {}",
                            self.err_prefix_with_line(),
                            display_expr, msg_with_token);
                    }
                }
                self.last_status = 1;
                // Unbound variable in arithmetic (set -u) is fatal — exit the
                // current shell/subshell, matching bash behaviour.
                let is_fatal = msg.ends_with(": unbound variable");
                if is_fatal {
                    self.exit_flag = true;
                }
                if msg.contains("operand expected") {
                    self.abort_current_list_until_newline();
                }
                return vec![format!("\x00ARITH_ERR\x00{}\x00", err)];
            }

            if will_split {
                if Self::is_single_procsub_word(&resolved_for_split) {
                    if !self.opts.noglob {
                        fields.extend(expand::pathname_expand(&resolved));
                    } else {
                        fields.push(resolved);
                    }
                    continue;
                }
                let ifs = self.vars.get("IFS").unwrap_or_else(|| " \t\n".to_string());
                let split_source = Self::protect_procsub_ifs(&resolved_for_split, &ifs);
                let split_fields = expand::word_split(&split_source, &ifs);
                // Bash rule: if the word contains ANY quoted portion
                // (even empty, e.g. `$x""` with x unset), the result is
                // ONE empty field — not zero fields.  Ordinary unquoted
                // empty expansions (`$x`) collapse to zero fields.
                if split_fields.is_empty() {
                    if resolved.contains("\x00EMPTY_AT\x00") {
                        if token_preserves_empty_field_with_empty_at(token) {
                            fields.push(String::new());
                        }
                    } else if expand::word_has_quoting_pub(token) {
                        fields.push(String::new());
                    }
                } else {
                    for field in split_fields {
                        if !self.opts.noglob {
                            fields.extend(expand::pathname_expand(&field));
                        } else {
                            fields.push(field);
                        }
                    }
                }
            } else if !expand::is_fully_quoted(token) {
                if !self.opts.noglob {
                    fields.extend(expand::pathname_expand(&resolved));
                } else {
                    fields.push(resolved);
                }
            } else {
                // "$@" inside double quotes: expand_all joins positional
                // parameters with \u{FFFF} (quoted form, preserves
                // empties) or \u{FFFE} (fall-through for older code
                // paths that predate the distinction).  We split on
                // either to produce one word per positional parameter.
                if resolved.contains('\u{FFFF}') {
                    for part in resolved.split('\u{FFFF}') {
                        fields.push(part.to_string());
                    }
                } else if resolved.contains('\u{FFFE}') {
                    for part in resolved.split('\u{FFFE}') {
                        fields.push(part.to_string());
                    }
                } else if resolved.contains("\x00EMPTY_AT\x00") {
                    // "$@" with 0 positional args: produce nothing
                    // — UNLESS the original token has other quoted
                    // regions adjacent to the $@, in which case bash
                    // emits ONE empty field.  Examples:
                    //   set --; recho "$@"        → 0 args
                    //   set --; recho ''"$@"      → 1 arg  (<>)
                    //   set --; recho "$@"''      → 1 arg  (<>)
                    //   set --; recho ''"$@"''    → 1 arg  (<>)
                    let remainder = resolved.replace("\x00EMPTY_AT\x00", "");
                    if !remainder.is_empty() {
                        fields.push(remainder);
                    } else {
                        let pure_empty_arraylike = token.starts_with('"')
                            && token.ends_with('"')
                            && token.chars().filter(|&c| c == '"').count() == 2
                            && {
                                let bare = &token[1..token.len().saturating_sub(1)];
                                bare == "$@"
                                    || bare == "${@}"
                                    || (bare.starts_with("${")
                                        && bare.ends_with('}')
                                        && {
                                            let inner = &bare[2..bare.len() - 1];
                                            inner == "@"
                                                || inner.ends_with("[@]")
                                                || inner.ends_with("[*]")
                                        })
                            };
                        if !pure_empty_arraylike && expand::word_has_quoting_pub(token) {
                            // Token has non-`\$@` quoted material.
                            //
                            // Bash rule: when `$@` (or `${@}`) shares a
                            // single double-quoted region with ONLY other
                            // expansions that all expanded to empty, the
                            // empty `$@` consumes the whole word — 0
                            // fields.  But if the token has any OTHER
                            // quoted region (a separate `"…"`/`'…'` block)
                            // or unquoted literal text outside the `$@`
                            // region, that material preserves one empty
                            // field.
                            //
                            // Heuristic: scan the token for quoted
                            // regions; if any region (other than the one
                            // containing $@) exists, preserve 1 empty
                            // field.  If `$@` is the only quoted region
                            // and everything else in it is dollar-refs
                            // (which all expanded to empty since
                            // `remainder` was empty), produce 0 fields.
                            let regions = collect_quoted_regions(token);
                            // Classify each region.  Three categories:
                            //   * "pure $@" — region is exactly `$@` or
                            //     `${@}` (also `${@:N}` etc. are array-
                            //     like in this no-op-result sense)
                            //   * "operator form" — region contains a
                            //     `${name OP …}` form (`:- := :+ :? - = + ?
                            //     # ## % %% / //`); operator-form
                            //     expansions ALWAYS preserve a field when
                            //     they expand to empty inside `"…"`,
                            //     even if the result happens to flow
                            //     from an empty `$@`.
                            //   * "literal-or-empty-refs" — bare
                            //     `$VAR` references and/or quote chars
                            //     only.  Same collapse rules as a bare
                            //     `$@`.
                            let region_is_pure_at = |segment: &str| -> bool {
                                let s = segment.trim();
                                s == "$@" || s == "${@}"
                            };
                            let region_has_operator_param_expansion = |segment: &str| -> bool {
                                // Look for `${...OP...}` forms where OP
                                // is one of the parameter-expansion
                                // operators.  We don't need to fully
                                // parse — just detect the presence of
                                // such an expansion in the region.
                                let chars: Vec<char> = segment.chars().collect();
                                let n = chars.len();
                                let mut i = 0usize;
                                while i + 2 < n {
                                    if chars[i] == '$' && chars[i + 1] == '{' {
                                        // Scan to matching `}` while
                                        // looking for an operator char.
                                        let mut j = i + 2;
                                        let mut depth = 1usize;
                                        let mut saw_op = false;
                                        // Skip the leading `!` for
                                        // indirect / `#` for length —
                                        // those are NOT operators in this
                                        // sense.
                                        while j < n && depth > 0 {
                                            match chars[j] {
                                                '\\' if j + 1 < n => j += 2,
                                                '{' => { depth += 1; j += 1; }
                                                '}' => { depth -= 1; j += 1; }
                                                ':' | '-' | '+' | '=' | '?' | '#' | '%' | '/' | '^' | ',' | '@'
                                                    if depth == 1 && j > i + 2 =>
                                                {
                                                    saw_op = true;
                                                    j += 1;
                                                }
                                                _ => j += 1,
                                            }
                                        }
                                        if saw_op {
                                            return true;
                                        }
                                        i = j;
                                        continue;
                                    }
                                    i += 1;
                                }
                                false
                            };
                            let mut has_other_region = false;
                            // A region has "other" content if it contains
                            // literal text NOT consumed by dollar-ref
                            // stripping.
                            for (region_text, _has_at) in &regions {
                                let stripped = strip_dollar_refs(region_text);
                                if !stripped.chars().all(|c| c == '"' || c == '\'') {
                                    has_other_region = true;
                                    break;
                                }
                                // Operator-form parameter expansions
                                // ALWAYS preserve a field when they expand
                                // to empty inside `"…"`.
                                if region_has_operator_param_expansion(region_text) {
                                    has_other_region = true;
                                    break;
                                }
                            }
                            // Multiple quoted regions: if not ALL are
                            // pure `$@`/`${@}`, at least one preserves
                            // an empty field.
                            if regions.len() > 1 {
                                let all_pure_at = regions.iter().all(|(seg, _)| region_is_pure_at(seg));
                                if !all_pure_at {
                                    has_other_region = true;
                                }
                            }
                            // Or: the token has unquoted literal text
                            // outside the quoted regions.
                            if has_unquoted_literal_outside_quotes(token) {
                                has_other_region = true;
                            }
                            if has_other_region {
                                fields.push(String::new());
                            }
                        }
                    }
                } else {
                    fields.push(resolved);
                }
            }
        }

        if fields.is_empty() {
            return Vec::new();
        }
        // Strip any CTLESC quote-escape markers and QNULL / EMPTY_AT markers
        // that leaked through to the final fields.
        for f in &mut fields {
            if f.contains(expand::CTLESC) {
                *f = f.replace(expand::CTLESC, "");
            }
            if f.contains("\x00QNULL\x00") {
                *f = f.replace("\x00QNULL\x00", "");
            }
            if f.contains("\x00EMPTY_AT\x00") {
                *f = f.replace("\x00EMPTY_AT\x00", "");
            }
        }
        fields
    }

    /// Expand a word without field splitting (for assignment RHS, redirect targets, etc.)
    fn expand_word_nosplit(&mut self, word: &str) -> String {
        self.sync_dynamic_vars();
        self.apply_assign_defaults(word);
        if let Some(resolved) = self.expand_live_nofork_double_quoted_word(word) {
            return resolved;
        }
        let result = if let Some(marker) = Self::heredoc_command_sub_marker(word) {
            marker
        } else {
            expand::expand_word_nosplit(word, &mut self.vars)
        };
        let result = self.resolve_cmdsubs(&result);
        result.replace("\x00EMPTY_AT\x00", "")
    }

    fn expand_word_nosplit_no_cmdsub(&mut self, word: &str) -> String {
        self.sync_dynamic_vars();
        self.apply_assign_defaults(word);
        let result = expand::expand_word_nosplit(word, &mut self.vars);
        result.replace("\x00EMPTY_AT\x00", "")
    }

    /// Public wrapper around `expand_word_nosplit` for use by builtins.
    pub fn expand_word_nosplit_pub(&mut self, word: &str) -> String {
        self.expand_word_nosplit(word)
    }

    /// Public wrapper around `expand_word_nosplit_no_cmdsub` for use by builtins.
    pub fn expand_word_nosplit_no_cmdsub_pub(&mut self, word: &str) -> String {
        self.expand_word_nosplit_no_cmdsub(word)
    }

    /// Expand a word without field splitting, in assignment context (tilde
    /// after `:` / `=` is expanded even in POSIX mode).
    fn expand_word_nosplit_assign(&mut self, word: &str) -> String {
        self.sync_dynamic_vars();
        self.apply_assign_defaults(word);
        let result = if let Some(marker) = Self::heredoc_command_sub_marker(word) {
            marker
        } else {
            expand::expand_word_nosplit_assign(word, &mut self.vars)
        };
        self.resolve_cmdsubs(&result)
    }

    fn expand_word_nosplit_assign_passwd(&mut self, word: &str) -> String {
        // Fast path: pure arithmetic expression — no $(...), no `...`,
        // no ${...} defaults, no process substitution.  Skip the expensive
        // sync_dynamic_vars / apply_assign_defaults / resolve_cmdsubs calls.
        // A word that is exactly `$((expr))` (no command sub inside) is a
        // simple arith expansion.  Check for nested `$(` cmd-sub by looking
        // for `$(` NOT immediately followed by another `(`.
        let trimmed = word.trim();
        if trimmed.starts_with("$((") && trimmed.ends_with("))") && !trimmed.contains('`') && !trimmed.contains("${") {
            // Ensure no command substitution `$(` inside: scan for "$(" where
            // the next char is NOT `(`.
            let has_cmdsub = trimmed.as_bytes().windows(2).enumerate().any(|(i, w)| {
                w == b"$(" && trimmed.as_bytes().get(i + 2).copied() != Some(b'(')
            });
            if !has_cmdsub {
                return expand::expand_word_nosplit_assign_passwd(word, &mut self.vars);
            }
        }
        self.sync_dynamic_vars();
        self.apply_assign_defaults(word);
        let result = if let Some(marker) = Self::heredoc_command_sub_marker(word) {
            marker
        } else {
            expand::expand_word_nosplit_assign_passwd(word, &mut self.vars)
        };
        self.resolve_cmdsubs(&result)
    }

    /// Expand a word for associative-array assignment values. These use the
    /// normal passwd-home tilde policy instead of ordinary assignment-value
    /// HOME semantics, while still avoiding field splitting.
    fn expand_word_nosplit_assoc_assign(&mut self, word: &str) -> String {
        self.sync_dynamic_vars();
        self.apply_assign_defaults(word);
        let result = if let Some(marker) = Self::heredoc_command_sub_marker(word) {
            marker
        } else {
            expand::expand_word_nosplit(word, &mut self.vars)
        };
        self.resolve_cmdsubs(&result)
    }

    /// Public no-split assignment-context expansion.  Currently no in-tree
    /// caller — kept as the canonical public entry for assignment-RHS
    /// expansion in builtin extensions and tests.
    #[allow(dead_code)]
    pub fn expand_word_nosplit_assign_pub(&mut self, word: &str) -> String {
        self.expand_word_nosplit_assign(word)
    }

    /// Public helper for builtins to expand a word with field splitting and glob.
    /// Used by builtin_readonly / builtin_export / builtin_declare when
    /// they need to expand array element values from the \x00ARRAY\x00 sentinel.
    pub fn expand_word_for_builtin(&mut self, word: &str) -> String {
        self.expand_word_nosplit_assign(word)
    }

    fn is_assoc_assign_target(&self, name: &str) -> bool {
        if let Some(bracket_pos) = name.find('[') {
            if name.ends_with(']') {
                let base = &name[..bracket_pos];
                return !base.is_empty() && self.vars.is_assoc(base);
            }
        }
        false
    }

    fn expand_compound_assign_element(&mut self, elem: &str) -> Vec<String> {
        const COMPOUND_BARE_PREFIX: &str = "\x00COMPOUND_BARE\x00";
        if let Some((key, val, append)) = parse_bracket_assign_ext(elem) {
            let key = self.expand_word_nosplit_no_cmdsub(&key);
            let val = self.expand_word_nosplit_assign_passwd(&val);
            let op = if append { "+=" } else { "=" };
            return vec![format!("[{}]{}{}", key, op, val)];
        }
        // Bare elements still undergo the normal unquoted expansion path, but
        // keep a marker so callers can distinguish "literal [k]=v syntax in
        // the source" from an expanded word that merely *became* "[k]=v".
        self.expand_word(elem)
            .into_iter()
            .map(|w| format!("{}{}", COMPOUND_BARE_PREFIX, w))
            .collect()
    }

    fn expand_compound_assign_element_passwd(&mut self, elem: &str) -> Vec<String> {
        const COMPOUND_BARE_PREFIX: &str = "\x00COMPOUND_BARE\x00";
        if let Some((key, val, append)) = parse_bracket_assign_ext(elem) {
            let key = self.expand_word_nosplit_no_cmdsub(&key);
            let val = self.expand_word_nosplit_assign_passwd(&val);
            let op = if append { "+=" } else { "=" };
            return vec![format!("[{}]{}{}", key, op, val)];
        }
        self.expand_word(elem)
            .into_iter()
            .map(|w| format!("{}{}", COMPOUND_BARE_PREFIX, w))
            .collect()
    }

    fn expand_assoc_compound_assign_element(&mut self, elem: &str) -> Vec<String> {
        const COMPOUND_BARE_PREFIX: &str = "\x00COMPOUND_BARE\x00";
        if let Some((key, val, append)) = parse_bracket_assign_ext(elem) {
            let key = self.expand_word_nosplit_no_cmdsub(&key);
            let val = self.expand_word_nosplit_assoc_assign(&val);
            let op = if append { "+=" } else { "=" };
            return vec![format!("[{}]{}{}", key, op, val)];
        }
        vec![format!(
            "{}{}",
            COMPOUND_BARE_PREFIX,
            self.expand_word_nosplit_assoc_assign(elem)
        )]
    }

    pub fn expand_compound_assign_element_pub(&mut self, elem: &str) -> Vec<String> {
        self.expand_compound_assign_element(elem)
    }

    fn expand_reparsed_compound_assign_element(&mut self, elem: &str) -> Vec<String> {
        if let Some((key, val, append)) = parse_bracket_assign_ext(elem) {
            let key = self.expand_word_nosplit_no_cmdsub(&key);
            let val = self.expand_word_nosplit_assoc_assign(&val);
            let op = if append { "+=" } else { "=" };
            return vec![format!("[{}]{}{}", key, op, val)];
        }
        vec![self.expand_word_nosplit_assoc_assign(elem)]
    }

    pub fn expand_reparsed_compound_assign_element_pub(&mut self, elem: &str) -> Vec<String> {
        self.expand_reparsed_compound_assign_element(elem)
    }

    fn prompt_hostname(&self, short: bool) -> String {
        let host = self.get_var("HOSTNAME").unwrap_or_default();
        if short {
            host.split('.').next().unwrap_or("").to_string()
        } else {
            host
        }
    }

    fn prompt_pwd(&self, basename_only: bool) -> String {
        let pwd = self.get_var("PWD")
            .or_else(|| std::env::current_dir().ok().map(|p| p.to_string_lossy().to_string()))
            .unwrap_or_default();
        let home = self.get_var("HOME").unwrap_or_default();
        let display = if !home.is_empty() && (pwd == home || pwd.starts_with(&(home.clone() + "/"))) {
            format!("~{}", &pwd[home.len()..])
        } else {
            pwd
        };
        if !basename_only {
            return display;
        }
        if display == "/" || display == "~" {
            return display;
        }
        display.rsplit('/').next().unwrap_or(&display).to_string()
    }

    fn prompt_version_short(&self) -> String {
        let full = self
            .get_var("BASH_VERSION")
            .filter(|s| !s.is_empty())
            .unwrap_or_else(|| env!("CARGO_PKG_VERSION").to_string());
        let mut parts = full.split('.');
        match (parts.next(), parts.next()) {
            (Some(major), Some(minor)) => format!("{}.{}", major, minor),
            _ => full.to_string(),
        }
    }

    fn prompt_command_number(&self) -> usize {
        self.history.total_added + 1
    }

    fn prompt_tty_name(&self) -> String {
        unsafe {
            let tty = libc::ttyname(libc::STDIN_FILENO);
            if tty.is_null() {
                return String::new();
            }
            let name = std::ffi::CStr::from_ptr(tty).to_string_lossy().to_string();
            name.rsplit('/').next().unwrap_or("").to_string()
        }
    }

    fn prompt_time(&self, fmt: &str) -> String {
        unsafe {
            let mut now: libc::time_t = 0;
            libc::time(&mut now);
            let mut tm: libc::tm = std::mem::zeroed();
            if libc::localtime_r(&now, &mut tm).is_null() {
                return String::new();
            }
            let cfmt = match CString::new(fmt) {
                Ok(v) => v,
                Err(_) => return String::new(),
            };
            let mut buf = vec![0u8; 128];
            let written = libc::strftime(
                buf.as_mut_ptr() as *mut libc::c_char,
                buf.len(),
                cfmt.as_ptr(),
                &tm,
            );
            if written == 0 {
                String::new()
            } else {
                String::from_utf8_lossy(&buf[..written]).to_string()
            }
        }
    }

    fn decode_prompt_escapes(&self, prompt_raw: &str) -> String {
        let chars: Vec<char> = prompt_raw.chars().collect();
        let mut out = String::new();
        let mut i = 0usize;
        while i < chars.len() {
            if chars[i] != '\\' {
                out.push(chars[i]);
                i += 1;
                continue;
            }
            i += 1;
            if i >= chars.len() {
                out.push('\\');
                break;
            }
            match chars[i] {
                'a' => out.push('\x07'),
                'd' => out.push_str(&self.prompt_time("%a %b %d")),
                'D' => {
                    if i + 1 < chars.len() && chars[i + 1] == '{' {
                        i += 2;
                        let start = i;
                        while i < chars.len() && chars[i] != '}' {
                            i += 1;
                        }
                        let fmt: String = chars[start..i.min(chars.len())].iter().collect();
                        out.push_str(&self.prompt_time(&fmt));
                    } else {
                        out.push_str("\\D");
                        continue;
                    }
                }
                'e' => out.push('\x1b'),
                'h' => out.push_str(&self.prompt_hostname(true)),
                'H' => out.push_str(&self.prompt_hostname(false)),
                'j' => out.push('0'),
                'l' => out.push_str(&self.prompt_tty_name()),
                'n' => out.push('\n'),
                'r' => out.push('\r'),
                's' => out.push_str(shell_name()),
                't' => out.push_str(&self.prompt_time("%H:%M:%S")),
                'T' => out.push_str(&self.prompt_time("%I:%M:%S")),
                '@' => out.push_str(&self.prompt_time("%I:%M %p")),
                'A' => out.push_str(&self.prompt_time("%H:%M")),
                'u' => out.push_str(&self.get_var("USER").unwrap_or_default()),
                'v' => out.push_str(&self.prompt_version_short()),
                'V' => out.push_str(env!("CARGO_PKG_VERSION")),
                'w' => out.push_str(&self.prompt_pwd(false)),
                'W' => out.push_str(&self.prompt_pwd(true)),
                '!' | '#' => out.push_str(&self.prompt_command_number().to_string()),
                '$' => out.push(if unsafe { libc::geteuid() } == 0 { '#' } else { '$' }),
                '[' => {
                    let start = i + 1;
                    let mut end = start;
                    let mut found = false;
                    while end + 1 < chars.len() {
                        if chars[end] == '\\' && chars[end + 1] == ']' {
                            found = true;
                            break;
                        }
                        end += 1;
                    }
                    if found {
                        let inner_raw: String = chars[start..end].iter().collect();
                        let decoded_inner = self.decode_prompt_escapes(&inner_raw);
                        if !decoded_inner.is_empty() {
                            if decoded_inner.contains('\x01') || decoded_inner.contains('\x02') {
                                out.push_str(&decoded_inner);
                            } else {
                                out.push('\x01');
                                out.push_str(&decoded_inner);
                                out.push('\x02');
                            }
                        }
                        i = end + 1;
                    } else {
                        out.push_str("\\[");
                    }
                }
                ']' => out.push('\x02'),
                '\\' => out.push(PROMPT_LITERAL_BACKSLASH),
                '0'..='7' => {
                    let mut value = chars[i].to_digit(8).unwrap_or(0);
                    let mut consumed = 1usize;
                    while consumed < 3 && i + consumed < chars.len() {
                        match chars[i + consumed].to_digit(8) {
                            Some(d) => {
                                value = value * 8 + d;
                                consumed += 1;
                            }
                            None => break,
                        }
                    }
                    out.push(char::from_u32(value).unwrap_or('\0'));
                    i += consumed - 1;
                }
                other => out.push(other),
            }
            i += 1;
        }
        out
    }

    pub fn expand_prompt(&mut self, prompt_raw: &str) -> String {
        let decoded = self.decode_prompt_escapes(prompt_raw);
        let expanded = if self.shopt.contains("promptvars") {
            self.expand_word_nosplit(&decoded)
        } else {
            decoded
        };
        restore_prompt_literals(expanded)
    }

    /// Public helper for builtins to expand a word with field splitting + glob.
    /// Handles $@ expansion into multiple elements, ANSI-C quoting, globs etc.
    /// Currently every in-tree caller uses internal `expand_word`;
    /// kept as the public re-entry point for external builtin authors.
    #[allow(dead_code)]
    pub fn expand_word_pub(&mut self, word: &str) -> Vec<String> {
        self.expand_word(word)
    }

    /// Expand a case pattern word, preserving unquoted backslashes as glob escapes.
    fn expand_case_pattern_word(&mut self, word: &str) -> String {
        self.sync_dynamic_vars();
        let result = expand::expand_case_pattern(word, &mut self.vars);
        self.resolve_cmdsubs(&result)
    }

    /// Pre-scan a word for `${name:=default}` and `${name=default}` patterns,
    /// performing the assignment so that subsequent expansion finds the variable
    /// already set.  This compensates for `expand_all` not having mutable access.
    fn apply_assign_defaults(&mut self, word: &str) {
        // Fast exit: only words containing `${` can have := / = defaults.
        if !word.contains("${") {
            return;
        }
        let chars: Vec<char> = word.chars().collect();
        let n = chars.len();
        let mut i = 0;
        // Track whether we're inside "..." so the default-word expansion
        // picks up the right quoting context (e.g. `'` literal vs SQ).
        let mut in_dquote = false;
        let mut in_squote = false;

        while i < n {
            let ch = chars[i];
            if in_squote {
                if ch == '\'' { in_squote = false; }
                i += 1;
                continue;
            }
            if ch == '\\' && i + 1 < n {
                i += 2;
                continue;
            }
            if ch == '\'' && !in_dquote {
                in_squote = true;
                i += 1;
                continue;
            }
            if ch == '"' {
                in_dquote = !in_dquote;
                i += 1;
                continue;
            }
            // Look for ${
            if ch == '$' && i + 1 < n && chars[i + 1] == '{' {
                let start = i + 2;
                // Find matching }
                let mut depth = 1;
                let mut j = start;
                while j < n && depth > 0 {
                    if chars[j] == '{' { depth += 1; }
                    if chars[j] == '}' { depth -= 1; }
                    if depth > 0 { j += 1; }
                }
                if depth == 0 {
                    let inner: String = chars[start..j].iter().collect();
                    // Check for := or = operator
                    self.try_assign_default(&inner, in_dquote);
                }
                i = j + 1;
            } else {
                i += 1;
            }
        }
    }

    /// If `inner` matches `name:=word` or `name=word`, and the variable is
    /// unset (or empty for `:=`), assign the default value.  `in_dquote`
    /// indicates the `${...}` sits inside an outer double-quoted string,
    /// which changes how the default word's quotes are interpreted.
    fn try_assign_default(&mut self, inner: &str, in_dquote: bool) {
        let is_assignable = |name: &str| {
            if expand::is_valid_varname(name) {
                return true;
            }
            parse_subscripted_name_pub(name)
                .map(|(base, _)| expand::is_valid_varname(&base))
                .unwrap_or(false)
        };
        let lookup_target = |shell: &mut Shell, name: &str| -> Option<String> {
            if let Some((base, sub)) = parse_subscripted_name_pub(name) {
                if shell.vars.is_assoc(&base) {
                    let key = crate::expand::expand_assoc_subscript_key_pub(&sub, &mut shell.vars);
                    return shell.vars.get_assoc(&base, &key);
                }
                if sub.is_empty() || sub == "*" || sub == "@" {
                    return None;
                }
                let expanded = crate::expand::expand_index_subscript_word_pub(&sub, &mut shell.vars);
                let idx_num = match crate::arithmetic::eval_expr_mut(&expanded, &mut shell.vars) {
                    Ok(n) => n,
                    Err(_) => return None,
                };
                let idx = if idx_num < 0 {
                    match shell.vars.array_max_index(&base) {
                        Some(max_idx) => {
                            let real = (max_idx as i64 + 1) + idx_num;
                            if real < 0 {
                                return None;
                            }
                            real as usize
                        }
                        None => return None,
                    }
                } else {
                    idx_num as usize
                };
                return shell.vars.get_array_element(&base, idx);
            }
            shell.get_var(name)
        };
        let assign_target = |shell: &mut Shell, name: &str, value: &str| {
            if let Some((base, sub)) = parse_subscripted_name_pub(name) {
                if shell.vars.is_assoc(&base) {
                    let key = if sub == "@" || sub == "*" {
                        sub
                    } else {
                        crate::expand::expand_assoc_subscript_key_pub(&sub, &mut shell.vars)
                    };
                    shell.vars.set_assoc(&base, &key, value);
                    return;
                }
                if sub.is_empty() || sub == "*" || sub == "@" {
                    return;
                }
                let expanded = crate::expand::expand_index_subscript_word_pub(&sub, &mut shell.vars);
                if let Ok(idx_num) = crate::arithmetic::eval_expr_mut(&expanded, &mut shell.vars) {
                    let idx = if idx_num < 0 {
                        match shell.vars.array_max_index(&base) {
                            Some(max_idx) => {
                                let real = (max_idx as i64 + 1) + idx_num;
                                if real < 0 {
                                    return;
                                }
                                real as usize
                            }
                            None => return,
                        }
                    } else {
                        idx_num as usize
                    };
                    shell.vars.set_array_element(&base, idx, value);
                }
                return;
            }
            shell.set_var(name, value);
        };
        let Some((name, default, assign_if_null)) = Self::split_assign_default_op(inner) else {
            return;
        };
        if !is_assignable(&name) {
            return;
        }
        if assign_if_null {
            let val = lookup_target(self, &name);
            if val.is_none() || val.as_deref() == Some("") {
                let stored = expand::expand_param_assign_word(default, &mut self.vars, in_dquote);
                let stored = self.resolve_cmdsubs(&stored);
                assign_target(self, &name, &stored);
            }
            return;
        }
        if lookup_target(self, &name).is_none() {
            let stored = expand::expand_param_assign_word(default, &mut self.vars, in_dquote);
            let stored = self.resolve_cmdsubs(&stored);
            assign_target(self, &name, &stored);
        }
    }

    fn split_assign_default_op(inner: &str) -> Option<(String, &str, bool)> {
        let bytes = inner.as_bytes();
        if bytes.is_empty() {
            return None;
        }
        let first = bytes[0] as char;
        if !first.is_ascii_alphabetic() && first != '_' {
            return None;
        }

        let mut end = 1usize;
        while end < bytes.len() {
            let c = bytes[end] as char;
            if c.is_ascii_alphanumeric() || c == '_' {
                end += 1;
            } else {
                break;
            }
        }
        if end < bytes.len() && bytes[end] == b'[' {
            let sub_end = find_subscript_end(inner, true)
                .or_else(|| find_subscript_end(inner, false))?;
            end = sub_end + 1;
        }

        let name = inner[..end].to_string();
        let rest = &inner[end..];
        if let Some(default) = rest.strip_prefix(":=") {
            return Some((name, default, true));
        }
        if let Some(default) = rest.strip_prefix('=') {
            return Some((name, default, false));
        }
        None
    }

    fn quote_cmdsub_result(&self, result: &str) -> String {
        if result.is_empty() {
            return "\x00QNULL\x00".to_string();
        }
        let ifs = self.vars.get("IFS").unwrap_or_else(|| " \t\n".to_string());
        let mut out = String::with_capacity(result.len());
        for ch in result.chars() {
            if ifs.contains(ch) || matches!(ch, '*' | '?' | '[' | '\\') {
                out.push(expand::CTLESC);
            }
            out.push(ch);
        }
        out
    }

    /// Resolve \x00CMDSUB\x00body\x00 markers by executing the command and
    /// replacing the marker with stdout output.
    fn resolve_cmdsubs(&mut self, s: &str) -> String {
        if !s.contains('\x00') {
            return s.to_string();
        }
        #[derive(Copy, Clone)]
        enum CmdsubKind {
            Forked,
            Nofork,
            Reply,
        }
        let mut out = String::new();
        let mut rest = s;
        loop {
            let mut next: Option<(usize, bool, usize, CmdsubKind)> = None;
            for (marker, quoted_ctx, kind) in [
                ("\x00CMDSUB\x00", false, CmdsubKind::Forked),
                (expand::QCMDSUB_MARKER, true, CmdsubKind::Forked),
                (expand::FUNSUB_MARKER, false, CmdsubKind::Nofork),
                (expand::QFUNSUB_MARKER, true, CmdsubKind::Nofork),
                (expand::REPLYSUB_MARKER, false, CmdsubKind::Reply),
                (expand::QREPLYSUB_MARKER, true, CmdsubKind::Reply),
            ] {
                if let Some(pos) = rest.find(marker) {
                    let replace = match next {
                        Some((best, _, _, _)) => pos < best,
                        None => true,
                    };
                    if replace {
                        next = Some((pos, quoted_ctx, marker.len(), kind));
                    }
                }
            }
            let Some((start, quoted_ctx, marker_len, kind)) = next else {
                break;
            };
            out.push_str(&rest[..start]);
            let after_marker = &rest[start + marker_len..];
            if let Some(end) = after_marker.find('\x00') {
                let cmd_body = &after_marker[..end];
                let result = match kind {
                    CmdsubKind::Forked => self.execute_command_sub(cmd_body),
                    CmdsubKind::Nofork => self.execute_nofork_command_sub(cmd_body, false),
                    CmdsubKind::Reply => self.execute_nofork_command_sub(cmd_body, true),
                };
                if quoted_ctx {
                    out.push_str(&self.quote_cmdsub_result(&result));
                } else {
                    out.push_str(&result);
                }
                rest = &after_marker[end + 1..];
            } else {
                // Malformed marker, output as-is
                out.push_str(&rest[start..]);
                break;
            }
        }
        out.push_str(rest);
        out
    }

    // -----------------------------------------------------------------------
    // Process substitution  <(cmd) / >(cmd)
    // -----------------------------------------------------------------------

    /// Set up process substitution for a single `<(cmd)` or `>(cmd)` token.
    /// Returns the `/dev/fd/N` path that replaces the token, and pushes any
    /// child PIDs / parent-side fds that must be cleaned up afterwards.
    fn setup_procsub(
        &mut self,
        token: &str,
        child_pids: &mut Vec<Pid>,
        parent_fds: &mut Vec<RawFd>,
    ) -> Result<String, String> {
        let is_input = token.starts_with("<(");
        let inner = &token[2..token.len() - 1]; // strip <( ) or >( )

        let (rd_owned, wr_owned) = pipe().map_err(|e| format!("pipe: {}", e))?;
        let rd: RawFd = rd_owned.into_raw_fd();
        let wr: RawFd = wr_owned.into_raw_fd();

        match unsafe { fork() } {
            Ok(ForkResult::Child) => {
                unsafe {
                    let _ = signal(Signal::SIGINT, SigHandler::SigDfl);
                    let _ = signal(Signal::SIGQUIT, SigHandler::SigDfl);
                    let _ = signal(Signal::SIGTERM, SigHandler::SigDfl);
                    let _ = signal(Signal::SIGPIPE, SigHandler::SigDfl);
                }
                if is_input {
                    // <(cmd): child writes to pipe, parent reads
                    let _ = close(rd);
                    let _ = dup2(wr, 1); // stdout -> write end
                    let _ = close(wr);
                } else {
                    // >(cmd): child reads from pipe, parent writes
                    let _ = close(wr);
                    let _ = dup2(rd, 0); // stdin -> read end
                    let _ = close(rd);
                }
                let status = self.run_string(inner);
                std::process::exit(status);
            }
            Ok(ForkResult::Parent { child }) => {
                // Set $! to the last process substitution PID (bash compat)
                self.last_bg_pid = Some(child.as_raw() as u32);
                self.vars.set("!", &child.as_raw().to_string());
                child_pids.push(child);
                if is_input {
                    let _ = close(wr);
                    parent_fds.push(rd);
                    Ok(format!("/dev/fd/{}", rd))
                } else {
                    let _ = close(rd);
                    parent_fds.push(wr);
                    Ok(format!("/dev/fd/{}", wr))
                }
            }
            Err(e) => Err(format!("fork: {}", e)),
        }
    }

    /// Check if a string contains a process substitution.  These are marked
    /// at lex-time with PUA characters U+E010 (for `<(`) and U+E011 (for
    /// `>(`), followed by the inner command text and a U+E012 terminator.
    /// This distinguishes real process substitutions from literal `<(` or
    /// `>(` that may appear in a word via backslash escaping or variable
    /// expansion.
    fn contains_procsub(s: &str) -> bool {
        s.contains('\u{E010}') || s.contains('\u{E011}')
    }

    fn protect_procsub_ifs(s: &str, ifs: &str) -> String {
        let mut out = String::with_capacity(s.len());
        let mut in_procsub = false;
        for ch in s.chars() {
            match ch {
                '\u{E010}' | '\u{E011}' => {
                    in_procsub = true;
                    out.push(ch);
                }
                '\u{E012}' => {
                    in_procsub = false;
                    out.push(ch);
                }
                _ => {
                    if in_procsub && ifs.contains(ch) {
                        out.push(expand::CTLESC);
                    }
                    out.push(ch);
                }
            }
        }
        out
    }

    fn is_single_procsub_word(s: &str) -> bool {
        let mut chars = s.chars();
        let Some(first) = chars.next() else {
            return false;
        };
        if !matches!(first, '\u{E010}' | '\u{E011}') {
            return false;
        }
        let mut saw_end = false;
        for ch in chars {
            if ch == '\u{E012}' {
                if saw_end {
                    return false;
                }
                saw_end = true;
                continue;
            }
            if saw_end {
                return false;
            }
        }
        saw_end
    }

    /// Replace all process-substitution markers in a string with
    /// `/dev/fd/N` paths, spawning the substitution children.
    fn resolve_procsub_in_str(
        &mut self,
        s: &str,
        child_pids: &mut Vec<Pid>,
        parent_fds: &mut Vec<RawFd>,
    ) -> String {
        let mut out = String::new();
        let chars: Vec<char> = s.chars().collect();
        let n = chars.len();
        let mut i = 0;

        while i < n {
            if chars[i] == '\u{E010}' || chars[i] == '\u{E011}' {
                let dir_ch = if chars[i] == '\u{E010}' { '<' } else { '>' };
                i += 1; // skip the marker
                let start = i;
                while i < n && chars[i] != '\u{E012}' { i += 1; }
                let inner: String = chars[start..i].iter().collect();
                if i < n { i += 1; } // skip terminator
                let token = format!("{}({})", dir_ch, inner);
                match self.setup_procsub(&token, child_pids, parent_fds) {
                    Ok(path) => out.push_str(&path),
                    Err(e) => {
                        eprintln!("{}: {}", self.err_prefix_with_line(), e);
                        out.push_str(&token);
                    }
                }
            } else {
                out.push(chars[i]);
                i += 1;
            }
        }
        out
    }

    /// Scan `words` for process substitution tokens and replace them with
    /// `/dev/fd/N` paths.  Also handle process substitutions in redirect
    /// targets.  Returns (child pids, parent fds to close, transformed redirects).
    fn resolve_procsubs(
        &mut self,
        words: &mut Vec<String>,
        redirects: &[Redirect],
    ) -> (Vec<Pid>, Vec<RawFd>, Vec<Redirect>) {
        let mut child_pids: Vec<Pid> = Vec::new();
        let mut parent_fds: Vec<RawFd> = Vec::new();

        // Process substitution in word arguments
        for word in words.iter_mut() {
            if Self::contains_procsub(word) {
                *word = self.resolve_procsub_in_str(word, &mut child_pids, &mut parent_fds);
            }
        }

        // Process substitution in redirect targets
        let mut new_redirects: Vec<Redirect> = Vec::new();
        for redir in redirects {
            let target = &redir.target;
            if Self::contains_procsub(target) {
                let resolved = self.resolve_procsub_in_str(target, &mut child_pids, &mut parent_fds);
                let mut r = redir.clone();
                r.target = resolved;
                new_redirects.push(r);
            } else {
                new_redirects.push(redir.clone());
            }
        }

        (child_pids, parent_fds, new_redirects)
    }

    fn resolve_procsubs_redirects(
        &mut self,
        redirects: &[Redirect],
    ) -> (Vec<Pid>, Vec<RawFd>, Vec<Redirect>) {
        let mut child_pids: Vec<Pid> = Vec::new();
        let mut parent_fds: Vec<RawFd> = Vec::new();
        let mut new_redirects: Vec<Redirect> = Vec::new();
        for redir in redirects {
            let target = &redir.target;
            if Self::contains_procsub(target) {
                let resolved = self.resolve_procsub_in_str(target, &mut child_pids, &mut parent_fds);
                let mut r = redir.clone();
                r.target = resolved;
                new_redirects.push(r);
            } else {
                new_redirects.push(redir.clone());
            }
        }
        (child_pids, parent_fds, new_redirects)
    }

    /// Close parent-side fds for process substitutions so children see EOF.
    /// Children are NOT reaped here to allow `wait $!` to get their status.
    /// They will be collected as zombies by future waitpid calls.
    fn cleanup_procsubs(&mut self, _child_pids: &[Pid], parent_fds: &[RawFd]) {
        // Close parent-side pipe fds so children see EOF
        for &fd in parent_fds {
            let _ = close(fd);
        }
    }

    // -----------------------------------------------------------------------
    // PS4 expansion helper
    // -----------------------------------------------------------------------

    /// Expand PS4 for xtrace output.  Performs variable substitution so that
    /// constructs like `+[$LINENO] ` expand correctly.
    /// The first character of PS4 is repeated xtrace_depth times (bash behavior:
    /// at nesting level 1 the leading char appears once; at level 2 twice, etc.).
    fn expand_ps4(&mut self, ps4_raw: &str) -> String {
        let expanded = self.expand_prompt(ps4_raw);
        // Replicate the leading character by xtrace_depth.
        // bash: "Each occurrence of the first character of $PS4 is replaced by the
        // current level of indirection."
        let depth = self.xtrace_depth;
        if depth <= 1 || expanded.is_empty() {
            return expanded;
        }
        let first = expanded.chars().next().unwrap();
        // Repeat first char (depth) times then append the rest
        let rest = &expanded[first.len_utf8()..];
        format!("{}{}", first.to_string().repeat(depth), rest)
    }

    // -----------------------------------------------------------------------
    // DEBUG trap support
    // -----------------------------------------------------------------------

    /// Fire the DEBUG trap if one is set.  Returns the trap command's exit
    /// status (0 when no trap is registered).  The caller should check the
    /// return value when `extdebug` is enabled: a return of 2 means "skip
    /// execution of the current simple command".
    fn fire_debug_trap(&mut self) -> i32 {
        // Prevent recursive invocation (the trap body itself runs commands).
        if self.in_debug_trap {
            return 0;
        }
        // DEBUG trap is not active inside non-traced functions
        // (unless functrace is on) — BUT only if the trap action has not changed
        // since entering the function (i.e. the function set its own DEBUG trap).
        let trap_cmd = match self.traps.get("DEBUG") {
            Some(cmd) if !cmd.is_empty() => cmd.to_owned(),
            _ => return 0,
        };
        if self.in_pipeline_or_cmdsub && !self.opts.functrace {
            return 0;
        }
        if self.in_untraced_function > 0 && !self.opts.functrace {
            // Check if the current DEBUG trap is the same as the inherited one.
            // If the function changed the DEBUG trap, we allow it to fire.
            let inherited = self.suppressed_debug_actions.last()
                .and_then(|o| o.as_deref())
                .unwrap_or("");
            if trap_cmd == inherited {
                return 0;
            }
        }

        self.in_debug_trap = true;
        // Suppress LINENO updates for the trap command text itself so that
        // $LINENO expansions in the trap body refer to the triggering line.
        // Functions called from the trap will decrement this, re-enabling
        // LINENO tracking inside the function body.
        self.suppress_lineno_update += 1;
        // Save and restore last_status so the DEBUG trap doesn't clobber $?
        let saved_status = self.last_status;
        let saved_lineno = self.vars.get("LINENO");
        let status = self.run_string(&trap_cmd);
        // The trap's own exit status is what we return for extdebug checking,
        // but we restore $? to its pre-trap value so the main script flow
        // is not affected.
        self.last_status = saved_status;
        if let Some(lineno) = saved_lineno {
            self.vars.set("LINENO", &lineno);
        } else {
            self.vars.unset("LINENO");
        }
        self.suppress_lineno_update -= 1;
        self.in_debug_trap = false;
        status
    }

    // -----------------------------------------------------------------------
    // ERR trap support
    // -----------------------------------------------------------------------

    /// Fire the ERR trap if one is set and conditions are met.
    /// The ERR trap fires when:
    ///   - A command returns a non-zero exit status
    ///   - The ERR trap is set (non-empty)
    ///   - We are not suppressing errexit (i.e., not inside an if/while/until
    ///     condition, not inside `!` prefix, not inside `&&`/`||` context)
    ///   - The last command was not negated (`!`)
    ///   - We are not already inside an ERR trap (no recursive ERR traps)
    ///   - We are not inside a non-traced function (unless functrace is on)
    fn fire_err_trap(&mut self) {
        // Don't fire ERR trap recursively (ERR trap body fails → no nested ERR)
        if self.in_debug_trap {
            return;
        }
        // Don't fire ERR trap inside subshells (pipeline children, ( ), etc.)
        // The parent shell fires ERR trap for the overall pipeline/subshell result.
        if self.in_pipeline_or_cmdsub {
            return;
        }
        // ERR trap doesn't fire when errexit is suppressed (if conditions, etc.)
        if self.suppress_errexit > 0 {
            return;
        }
        // ERR trap doesn't fire after negated commands
        if self.last_was_negated {
            return;
        }
        // Bash 5.3 fires ERR trap inside functions by default.
        // The old documented behavior (ERR not inherited without errtrace)
        // was changed; bash 5.3 inherits ERR into functions unconditionally.
        let trap_cmd = match self.traps.get("ERR") {
            Some(cmd) if !cmd.is_empty() => cmd.to_owned(),
            _ => return,
        };
        // Guard against recursive ERR trap: reuse in_debug_trap flag
        self.in_debug_trap = true;
        self.suppress_lineno_update += 1;
        self.xtrace_depth += 1;
        let saved_status = self.last_status;
        let saved_lineno = self.vars.get("LINENO");
        // When ERR fires inside a function, bash reports the CALLER's line
        // number (where the function was invoked), not the line inside the
        // function body.  Set LINENO to the caller's line before running
        // the trap body.
        if self.in_untraced_function > 0 {
            if let Some(&caller_line) = self.bash_lineno_stack.first() {
                if caller_line > 0 {
                    self.vars.set("LINENO", &caller_line.to_string());
                }
            }
        }
        // Preserve BASH_COMMAND during the trap body so $BASH_COMMAND
        // inside the trap refers to the failing command, not to the
        // trap action itself.  Bash keeps the original in place until
        // the trap returns.
        let saved_bash_command = self.bash_command.clone();
        self.run_string(&trap_cmd);
        self.bash_command = saved_bash_command;
        self.last_status = saved_status;
        if let Some(lineno) = saved_lineno {
            self.vars.set("LINENO", &lineno);
        } else {
            self.vars.unset("LINENO");
        }
        self.xtrace_depth -= 1;
        self.suppress_lineno_update -= 1;
        self.in_debug_trap = false;
    }

    // -----------------------------------------------------------------------
    // [[ ]] short-circuit lazy evaluation
    // -----------------------------------------------------------------------

    /// Expand a single raw word in [[ ]] context (no word-splitting, no
    /// pathname expansion; pattern words use special expansion rules).
    /// `prev_op` is the raw preceding token to detect `=~`/`==`/`!=`/`=`.
    fn expand_double_bracket_word(&mut self, word: &str, prev_op: &str) -> String {
        let bracket_ops = ["==", "=", "!=", "=~"];
        let is_regex_rhs = prev_op == "=~";
        let is_pattern_rhs = bracket_ops.contains(&prev_op);
        if is_regex_rhs {
            expand::expand_regex_pattern(word, &mut self.vars)
        } else if is_pattern_rhs {
            expand::expand_case_pattern(word, &mut self.vars)
        } else {
            self.expand_word_nosplit(word)
        }
    }

    /// Expand a slice of raw [[ ]] words (without "[[" and "]]" at the
    /// ends) into a fully-expanded word list, with short-circuit semantics
    /// for top-level `||` and `&&`.  Returns `None` if an expansion error
    /// occurred in a non-skippable sub-expression (caller should abort).
    /// Returns `Some(words)` with the fully-expanded word list on success.
    ///
    /// Each sub-expression between top-level `||`/`&&` tokens is expanded
    /// and evaluated in order; if the short-circuit condition is met, the
    /// remaining sub-expressions are left unexpanded.  This prevents bash
    /// expansions that would produce errors (like `${H*}`) from running when
    /// they appear on the skipped side of `||`/`&&`.
    fn expand_double_bracket_lazy(
        &mut self,
        // The words between "[[" and "]]" (exclusive)
        inner_raw: &[String],
    ) -> Option<Vec<String>> {
        // Find top-level || and && tokens (at paren depth 0).
        // We collect them as (index, op) pairs.
        let mut depth: usize = 0;
        let mut sep_positions: Vec<(usize, &str)> = Vec::new();
        for (i, w) in inner_raw.iter().enumerate() {
            match w.as_str() {
                "(" => depth += 1,
                ")" if depth > 0 => depth -= 1,
                "||" | "&&" if depth == 0 => sep_positions.push((i, w.as_str())),
                _ => {}
            }
        }

        // If no top-level separators, just expand all words normally.
        if sep_positions.is_empty() {
            let mut expanded = vec!["[[".to_string()];
            let n = inner_raw.len();
            for i in 0..n {
                let prev_op = if i > 0 { inner_raw[i - 1].as_str() } else { "" };
                let e = self.expand_double_bracket_word(&inner_raw[i], prev_op);
                if e.contains("\x00EXPAND_ERROR\x00") { return None; }
                expanded.push(e);
            }
            expanded.push("]]".to_string());
            return Some(expanded);
        }

        // Split inner_raw into sub-expressions and separators.
        // sub_exprs[i] is the raw words between sep_positions[i-1] and sep_positions[i].
        // separators[i] is the operator between sub_exprs[i] and sub_exprs[i+1].
        let mut sub_ranges: Vec<(usize, usize)> = Vec::new(); // (start, end) in inner_raw
        let mut separators: Vec<&str> = Vec::new();
        let mut start = 0;
        for &(pos, op) in &sep_positions {
            sub_ranges.push((start, pos));
            separators.push(op);
            start = pos + 1;
        }
        sub_ranges.push((start, inner_raw.len()));

        // Expand sub-expressions lazily, short-circuiting as appropriate.
        // We need to build the FULL expanded word list (for the evaluator),
        // but we stop expanding at the point of short-circuit.
        //
        // Strategy: expand each sub-expression in order.  After each one,
        // do a mini-eval to determine if short-circuit applies.
        let mut all_expanded: Vec<String> = vec!["[[".to_string()];
        let mut short_circuit_result: Option<i32> = None;

        for (idx, &(start, end)) in sub_ranges.iter().enumerate() {
            // Expand this sub-expression's words.
            let mut sub_expanded: Vec<String> = Vec::new();
            for i in start..end {
                let prev_op = if i > start {
                    inner_raw[i - 1].as_str()
                } else if i > 0 {
                    inner_raw[i - 1].as_str()
                } else {
                    ""
                };
                let e = self.expand_double_bracket_word(&inner_raw[i], prev_op);
                if e.contains("\x00EXPAND_ERROR\x00") {
                    // Expansion error in this sub-expression.
                    // Check if we already have a short-circuit result that
                    // makes this sub-expression unreachable.
                    if short_circuit_result.is_some() {
                        // We can skip this sub-expression entirely.
                        // Don't add it to all_expanded; the evaluator won't
                        // see it. Just stop expanding.
                        all_expanded.push("]]".to_string());
                        // Splice the partial result into all_expanded using
                        // the short-circuit answer from prev rounds.
                        // Actually we need to return a minimal valid expression.
                        // Build a fake result: [[ ]] with just the already-
                        // expanded words, which the caller will evaluate.
                        return Some(all_expanded);
                    }
                    // Error in an expression we must evaluate.
                    return None;
                }
                sub_expanded.push(e);
            }
            all_expanded.extend_from_slice(&sub_expanded);

            // After this sub-expression, decide if we short-circuit.
            if idx < separators.len() {
                let sep = separators[idx];
                // Do a quick eval of all_expanded so far to decide.
                // Build a temporary [[ ... ]] word list for the evaluator.
                let mut tmp_words: Vec<String> = all_expanded.clone();
                tmp_words.push("]]".to_string());
                let eval_words: Vec<String> = tmp_words.clone();
                // Split redirect-embedded tokens just like the main path.
                let eval_words_clean: Vec<String> = eval_words.into_iter().flat_map(|w| {
                    if (w.starts_with("> ") || w.starts_with("< ")) && w.len() > 2 {
                        vec![w[..1].to_string(), w[2..].to_string()]
                    } else {
                        vec![w]
                    }
                }).collect();
                let sub_status = crate::builtins::run(self, &eval_words_clean, &eval_words_clean);
                match (sep, sub_status == 0) {
                    ("||", true) => {
                        // Left side of || is true: short-circuit, return true.
                        short_circuit_result = Some(0);
                    }
                    ("&&", false) => {
                        // Left side of && is false: short-circuit, return false.
                        short_circuit_result = Some(1);
                    }
                    _ => {
                        // Add separator to expanded list for full evaluation.
                        all_expanded.push(sep.to_string());
                    }
                }
                if short_circuit_result.is_some() {
                    // Stop expanding remaining sub-expressions.
                    all_expanded.push("]]".to_string());
                    return Some(all_expanded);
                }
            }
        }
        all_expanded.push("]]".to_string());
        Some(all_expanded)
    }

    // -----------------------------------------------------------------------
    // Async signal delivery
    // -----------------------------------------------------------------------

    /// Check for pending signals (set by the raw signal handler) and fire
    /// their trap actions.  Called after every command executes.
    /// Returns true if any trap was fired.
    pub fn check_pending_signals(&mut self) -> bool {
        if self.in_signal_trap {
            return false; // no reentrancy
        }
        let mut fired = false;
        for sig_num in 1..SIG_MAX as i32 {
            let count = PENDING_SIGNALS[sig_num as usize].swap(0, Ordering::Relaxed);
            if count <= 0 {
                continue;
            }
            // Get the trap action for this signal
            let sig_name = match TrapHandler::signal_num_to_name(sig_num) {
                Some(n) => n.to_string(),
                None => continue,
            };
            let trap_cmd = match self.traps.get(&sig_name) {
                Some(cmd) if !cmd.is_empty() => cmd.to_owned(),
                _ => {
                    // No trap set — put count back (shouldn't happen if we
                    // only install the handler when a trap is set, but be safe).
                    continue;
                }
            };
            // Fire the trap once per pending count
            for _ in 0..count {
                self.bash_trapsig = sig_num;
                self.set_var("BASH_TRAPSIG", &sig_num.to_string());
                let saved_status = self.last_status;
                // Record the pre-trap status so that `return` (no arg) inside
                // the trap body uses the value of $? at trap entry, not the
                // modified value after executing trap body commands.
                self.signal_trap_entry_status = saved_status;
                self.in_signal_trap = true;
                let is_in_func = !self.funcname_stack.is_empty();
                self.in_function_trap = is_in_func;
                self.run_string(&trap_cmd);
                self.in_signal_trap = false;
                let trap_set_return = self.in_function_trap && self.return_flag;
                self.in_function_trap = false;
                // If `return` was used in the trap and we're in a function,
                // keep return_flag set so the calling function exits.
                // The function's exit status is whatever last_status was set to
                // by do_return (either explicit N or signal_trap_entry_status).
                if !trap_set_return {
                    // Not returning from a function: restore last_status to
                    // saved_status so the trap doesn't change $?.
                    if !self.return_flag {
                        self.last_status = saved_status;
                    }
                }
                // If the trap body called exit or set exit_flag, stop processing.
                if self.exit_flag {
                    break;
                }
            }
            fired = true;
            if self.exit_flag || self.return_flag {
                break;
            }
        }
        fired
    }

    // -----------------------------------------------------------------------
    // Function calling
    // -----------------------------------------------------------------------

    /// Sync the FUNCNAME/BASH_SOURCE/BASH_LINENO arrays from the current
    /// function/source stacks. No-ops when stacks haven't changed since last sync.
    pub(crate) fn sync_stack_trace_arrays(&mut self) {
        if !self.stack_trace_dirty {
            return;
        }
        self.stack_trace_dirty = false;
        if self.funcname_stack.is_empty() {
            // At top level, bash leaves FUNCNAME with the array attribute
            // but empty (uninitialized).  `declare -p` shows `declare -a
            // FUNCNAME` without the `=()` value-list trailer.  brash was
            // unsetting it instead, which caused declare -p output to
            // omit the line entirely (4 array-test diffs).
            //
            // Use declare_array — which sets the array attribute without
            // marking the entry initialized — so the print path keeps
            // the bare `declare -a FUNCNAME` form.  But first unset any
            // previous value (from when we were inside a function) so
            // declare_array starts from VarValue::Unset.
            self.vars.unset("FUNCNAME");
            self.vars.declare_array("FUNCNAME");
        } else {
            // FUNCNAME is a stack array: [0] = current function, [1] = caller, ...
            let mut arr: Vec<String> = self.funcname_stack.iter().rev().cloned().collect();
            arr.push("main".to_string());
            self.vars.set_array("FUNCNAME", arr);
        }
        let sources = if self.bash_source_stack.is_empty() {
            if self.script_name.is_empty() {
                Vec::new()
            } else {
                vec![self.script_name.clone()]
            }
        } else {
            self.bash_source_stack.clone()
        };
        let linenos = if self.bash_lineno_stack.is_empty() {
            vec!["0".to_string()]
        } else {
            self.bash_lineno_stack.iter().map(|n| n.to_string()).collect()
        };
        self.vars.set_array("BASH_SOURCE", sources);
        self.vars.set_array("BASH_LINENO", linenos);
    }

    pub(crate) fn push_untraced_debug_context(&mut self) {
        self.in_untraced_function += 1;
        let current_debug = self.traps.get("DEBUG").map(|s| s.to_owned());
        self.suppressed_debug_actions.push(current_debug);
    }

    pub(crate) fn pop_untraced_debug_context(&mut self) {
        self.in_untraced_function = self.in_untraced_function.saturating_sub(1);
        self.suppressed_debug_actions.pop();
    }

    pub(crate) fn fire_sourced_return_trap(&mut self, caller_lineno: usize) {
        if self.in_return_trap || self.in_debug_trap {
            return;
        }
        let Some(trap_cmd) = self.traps.get("RETURN").map(|s| s.to_owned()) else {
            return;
        };
        if trap_cmd.is_empty() {
            return;
        }
        self.in_return_trap = true;
        let saved_return_flag = self.return_flag;
        let saved_lineno = self.vars.get("LINENO");
        if caller_lineno > 0 {
            self.set_var("LINENO", &caller_lineno.to_string());
        }
        self.push_untraced_debug_context();
        self.suppress_lineno_update += 1;
        self.run_string(&trap_cmd);
        if let Some(lineno) = saved_lineno {
            self.vars.set("LINENO", &lineno);
        } else {
            self.vars.unset("LINENO");
        }
        self.suppress_lineno_update -= 1;
        self.pop_untraced_debug_context();
        self.return_flag = saved_return_flag;
        self.in_return_trap = false;
    }

    /// Call a shell function, setting up and tearing down positional parameters.
    fn call_function(&mut self, func: &FuncDef, args: &[String], caller_lineno: usize) -> i32 {
        // Enforce FUNCNEST — bash refuses to enter a function if this depth
        // would be exceeded.  Default limit is 0 (unlimited) in bash 5; the
        // func.tests suite explicitly sets FUNCNEST=20 / 100 to test.
        let funcnest_limit: usize = self.get_var("FUNCNEST")
            .and_then(|s| s.trim().parse::<usize>().ok())
            .unwrap_or(0);
        if funcnest_limit > 0 && self.funcname_stack.len() >= funcnest_limit {
            let prefix = self.err_prefix_with_line();
            eprintln!(
                "{}: {}: maximum function nesting level exceeded ({})",
                prefix, func.name, funcnest_limit
            );
            self.last_status = 1;
            return 1;
        }

        // Save positional parameters
        let saved_count = self.vars.positional_count;
        let mut saved_pos: Vec<(String, Option<String>)> = Vec::new();
        for i in 1..=saved_count {
            let key = i.to_string();
            saved_pos.push((key.clone(), self.vars.get(&key)));
        }

        // Set new positional parameters
        self.vars.positional_count = args.len();
        for (i, arg) in args.iter().enumerate() {
            self.vars.set_positional(i + 1, arg);
        }
        // Unset any old positional params beyond new count
        for i in (args.len() + 1)..=(saved_count) {
            self.vars.unset(&i.to_string());
        }

        // Push function/source caller metadata for FUNCNAME/BASH_*.
        let current_source = if let Some(src) = self.bash_source_stack.first() {
            src.clone()
        } else {
            self.script_name.clone()
        };
        if self.bash_source_stack.is_empty() && !current_source.is_empty() {
            self.bash_source_stack.push(current_source.clone());
            self.bash_lineno_stack.push(0);
        }
        self.bash_source_stack.insert(0, current_source);
        self.bash_lineno_stack.insert(0, caller_lineno);
        self.bash_argc_stack.insert(0, args.len());
        for arg in args {
            self.bash_argv_stack.insert(0, arg.clone());
        }

        // Push function name onto the call stack and sync FUNCNAME array
        self.funcname_stack.push(func.name.clone());
        self.stack_trace_dirty = true;
        // In cmdsub/pipeline children without active debug/return traps or
        // functrace, skip the entry sync — the function body rarely reads
        // FUNCNAME, and the child process will exit before any caller checks.
        // The exit sync is also skipped (see below), saving all 6 allocations.
        // We must sync when functrace is on (RETURN trap reads FUNCNAME) or
        // when a DEBUG trap is set (fired inside the function body).
        let needs_sync = !self.in_pipeline_or_cmdsub
            || self.opts.functrace
            || self.traps.get("DEBUG").is_some()
            || self.traps.get("RETURN").is_some();
        if needs_sync {
            self.sync_stack_trace_arrays();
        }

        // Clear return flag before function body
        let saved_return = self.return_flag;
        self.return_flag = false;

        // Clear signal-trap context for nested function calls: `return` without
        // args inside functions called FROM a signal trap should use the function's
        // own $? (last_status), not the signal_trap_entry_status.
        let saved_in_signal_trap = self.in_signal_trap;
        self.in_signal_trap = false;

        // Inside a function body, LINENO should track the function's own lines,
        // even when the function was called from a DEBUG trap.  Save and clear
        // the suppress_lineno_update counter so execute_simple updates LINENO
        // normally inside the function.
        let saved_suppress_lineno = self.suppress_lineno_update;
        self.suppress_lineno_update = 0;

        // Save and reset getopts internal state so that functions with
        // `typeset OPTIND=1` get their own getopts context.
        let saved_getopts_charindex = self.getopts_charindex;
        let saved_getopts_last_optind = self.getopts_last_optind;
        self.getopts_charindex = 0;
        self.getopts_last_optind = 0;

        // Track whether DEBUG/RETURN traps are active in this function.
        // extdebug enables debugger semantics (e.g. DEBUG status 2 skips the
        // current command), but it does not by itself inherit DEBUG/RETURN
        // traps into functions; `set -T` / `functrace` or the function trace
        // attribute controls that.
        let func_has_trace = self.opts.functrace
            || self.traced_functions.contains(&func.name);
        if !func_has_trace {
            // Remember the current DEBUG trap action; if the function changes
            // it, the new action will be allowed to fire (it's no longer
            // "inherited").
            self.push_untraced_debug_context();
        }

        // Push a new variable scope so that `local`/`typeset`/`declare`
        // inside the function is isolated and automatically discarded on return.
        self.local_option_snapshots.push(None);
        self.vars.push_scope();

        let mut status = self.execute(&func.body);

        // Check for pending signals (e.g. kill -USR1 $$) that were not yet
        // delivered when the function body ran.  We check here, while the
        // funcname_stack still contains the function name, so that `return N`
        // inside a signal trap correctly scopes to this function.
        if !self.return_flag && !self.exit_flag {
            self.check_pending_signals();
            if self.return_flag || self.exit_flag {
                status = self.last_status;
            }
        }

        // Pop the function's local variable scope before restoring anything else.
        self.vars.pop_scope();
        if let Some(Some((saved_opts, saved_posix_mode))) = self.local_option_snapshots.pop() {
            self.opts = saved_opts;
            self.posix_mode = saved_posix_mode;
            self.vars.posix_mode = self.posix_mode;
            if self.opts.ignoreeof {
                self.vars.set_raw("IGNOREEOF", "10");
            } else {
                self.vars.force_unset("IGNOREEOF");
            }
            self.sync_dynamic_vars();
        }

        // Restore untraced function depth and suppressed debug action stack
        if !func_has_trace {
            self.pop_untraced_debug_context();
        }

        // Fire RETURN trap if functrace is on or the function has the trace
        // attribute.
        // The trap fires in the calling scope (after the function's scope is popped).
        if (self.opts.functrace || self.traced_functions.contains(&func.name))
            && !self.in_return_trap
            && !self.in_debug_trap
        {
            if let Some(trap_cmd) = self.traps.get("RETURN").map(|s| s.to_owned()) {
                if !trap_cmd.is_empty() {
                    self.in_return_trap = true;
                    let saved_return_flag = self.return_flag;
                    let saved_lineno = self.vars.get("LINENO");
                    self.set_var("LINENO", &func.start_lineno.to_string());
                    self.suppress_lineno_update += 1;
                    self.run_string(&trap_cmd);
                    if let Some(lineno) = saved_lineno {
                        self.vars.set("LINENO", &lineno);
                    } else {
                        self.vars.unset("LINENO");
                    }
                    self.suppress_lineno_update -= 1;
                    self.return_flag = saved_return_flag;
                    self.in_return_trap = false;
                }
            }
        }

        // Restore getopts internal state
        self.getopts_charindex = saved_getopts_charindex;
        self.getopts_last_optind = saved_getopts_last_optind;

        // Restore suppress_lineno_update
        self.suppress_lineno_update = saved_suppress_lineno;

        // Pop function/source metadata from the call stack and sync arrays.
        self.funcname_stack.pop();
        if !self.bash_source_stack.is_empty() {
            self.bash_source_stack.remove(0);
        }
        if !self.bash_lineno_stack.is_empty() {
            self.bash_lineno_stack.remove(0);
        }
        if !self.bash_argc_stack.is_empty() {
            let argc = self.bash_argc_stack.remove(0);
            let drain_len = argc.min(self.bash_argv_stack.len());
            self.bash_argv_stack.drain(0..drain_len);
        }
        if caller_lineno > 0 {
            self.set_var("LINENO", &caller_lineno.to_string());
        }
        self.stack_trace_dirty = true;
        // Skip exit sync when we're back at top level inside a cmdsub/pipeline
        // child with no active traps — the subshell will exit or the next
        // function call will re-sync on entry.
        let needs_exit_sync = !self.funcname_stack.is_empty()
            || !self.in_pipeline_or_cmdsub
            || self.opts.functrace
            || self.traps.get("DEBUG").is_some()
            || self.traps.get("RETURN").is_some();
        if needs_exit_sync {
            self.sync_stack_trace_arrays();
        }

        // Capture return status from `return` builtin (stored in last_status by builtin)
        let final_status = if self.return_flag {
            self.last_status
        } else {
            status
        };

        // Restore return flag and signal-trap context
        self.return_flag = saved_return;
        self.in_signal_trap = saved_in_signal_trap;

        // Restore positional parameters
        self.vars.positional_count = saved_count;
        for (key, val) in saved_pos {
            match val {
                Some(v) => {
                    if let Ok(idx) = key.parse::<usize>() {
                        self.vars.set_positional(idx, &v);
                    } else {
                        self.set_var(&key, &v);
                    }
                }
                None => self.vars.unset(&key),
            }
        }
        for i in (saved_count + 1)..=args.len() {
            self.vars.unset(&i.to_string());
        }

        self.last_status = final_status;
        final_status
    }
}

// ---------------------------------------------------------------------------
// Pipe helper — get the raw fd from a nix pipe fd
// ---------------------------------------------------------------------------

// OwnedFd from nix::pipe() implements std::os::unix::io::IntoRawFd directly.

// ---------------------------------------------------------------------------
// Free functions for redirect handling
// ---------------------------------------------------------------------------

/// Parse a `[key]=value` element from a compound array assignment.
/// Returns `Some((key, value))` if the element matches `[...]=...`, else `None`.
/// Return true if `w` has the shape `NAME=...` or `NAME+=...` where
/// NAME is a valid shell identifier.  Used by `set -k` to decide if a
/// post-expansion word should be re-interpreted as an assignment.
/// Check whether an argument to an assignment builtin (declare/export/
/// readonly/local/typeset) looks like an assignment: `NAME=VAL`,
/// `NAME+=VAL`, or `NAME[SUBSCRIPT]=VAL` (with any subscript chars).
/// These arguments get tilde-in-assign expansion without word splitting.
fn is_assign_builtin_arg(w: &str) -> bool {
    let bytes = w.as_bytes();
    if bytes.is_empty() { return false; }
    let first = bytes[0] as char;
    if !first.is_ascii_alphabetic() && first != '_' { return false; }
    let mut i = 1;
    while i < bytes.len() {
        let c = bytes[i] as char;
        if c.is_ascii_alphanumeric() || c == '_' {
            i += 1;
        } else if c == '[' {
            // Subscript — accept anything until matching `]` followed
            // by `=` or `+=`.
            let mut depth = 1i32;
            i += 1;
            while i < bytes.len() && depth > 0 {
                match bytes[i] {
                    b'[' => depth += 1,
                    b']' => depth -= 1,
                    _ => {}
                }
                i += 1;
            }
            if i < bytes.len() && bytes[i] == b'=' { return true; }
            if i + 1 < bytes.len() && bytes[i] == b'+' && bytes[i + 1] == b'=' { return true; }
            return false;
        } else if c == '=' {
            return true;
        } else if c == '+' && i + 1 < bytes.len() && bytes[i + 1] == b'=' {
            return true;
        } else {
            return false;
        }
    }
    false
}

fn is_valid_assign_word(w: &str) -> bool {
    let bytes = w.as_bytes();
    if bytes.is_empty() { return false; }
    let first = bytes[0] as char;
    if !first.is_ascii_alphabetic() && first != '_' { return false; }
    let mut i = 1;
    while i < bytes.len() {
        let c = bytes[i] as char;
        if c.is_ascii_alphanumeric() || c == '_' {
            i += 1;
        } else if c == '=' {
            return true;
        } else if c == '+' && i + 1 < bytes.len() && bytes[i + 1] == b'=' {
            return true;
        } else {
            return false;
        }
    }
    false
}

/// Given a `NAME=value` or `NAME+=value` word, return (name, value,
/// append) parts.  Assumes `is_valid_assign_word` returned true.
fn parse_assign_word(w: &str) -> (String, String, bool) {
    // Find the `=` (or `+=`).
    let eq = w.find('=').unwrap_or(w.len());
    let name_end = if eq > 0 && &w[eq.saturating_sub(1)..eq] == "+" {
        eq - 1
    } else {
        eq
    };
    let append = name_end < eq;
    let name = w[..name_end].to_string();
    let value = if eq < w.len() { w[eq + 1..].to_string() } else { String::new() };
    (name, value, append)
}

/// Return the "error token" string that bash would report for an
/// arithmetic divide-by-zero at a terminal `0` in `expr`.
/// For an expression like `LINENO / 0 ` the token is `"0 "` (including
/// the trailing space); for `i < 4/0` it's `"0"`.
fn arith_err_token_at_zero(expr: &str) -> String {
    // Find the last `0` (the divisor) and take from there to end.
    if let Some(pos) = expr.rfind('0') {
        expr[pos..].to_string()
    } else {
        "0".to_string()
    }
}

/// Return true if `cmd` (a simple name, no slashes) exists as an
/// executable file in any PATH directory.  Used to decide whether
/// `command_not_found_handle` should fire.
fn path_command_exists(cmd: &str, path_var: &str) -> bool {
    for dir in path_var.split(':') {
        if dir.is_empty() { continue; }
        let candidate = format!("{}/{}", dir, cmd);
        if let Ok(md) = std::fs::metadata(&candidate) {
            if md.is_file() {
                use std::os::unix::fs::PermissionsExt;
                if md.permissions().mode() & 0o111 != 0 {
                    return true;
                }
            }
        }
    }
    false
}

fn parse_bracket_assign(elem: &str) -> Option<(String, String)> {
    parse_bracket_assign_ext(elem).map(|(key, val, _)| (key, val))
}

fn skip_nested_parens(bytes: &[u8], mut i: usize) -> usize {
    let mut depth = 1i32;
    while i < bytes.len() {
        match bytes[i] {
            b'\\' => {
                i += if i + 1 < bytes.len() { 2 } else { 1 };
            }
            b'\'' => {
                i += 1;
                while i < bytes.len() {
                    if bytes[i] == b'\'' {
                        i += 1;
                        break;
                    }
                    i += 1;
                }
            }
            b'"' => {
                i += 1;
                while i < bytes.len() {
                    if bytes[i] == b'\\' && i + 1 < bytes.len() {
                        i += 2;
                        continue;
                    }
                    if bytes[i] == b'"' {
                        i += 1;
                        break;
                    }
                    i += 1;
                }
            }
            b'$' if i + 1 < bytes.len() && bytes[i + 1] == b'(' => {
                i = skip_nested_parens(bytes, i + 2);
            }
            b'$' if i + 2 < bytes.len() && bytes[i + 1] == b'(' && bytes[i + 2] == b'(' => {
                i = skip_nested_parens(bytes, i + 3);
            }
            b'(' => {
                depth += 1;
                i += 1;
            }
            b')' => {
                depth -= 1;
                i += 1;
                if depth == 0 {
                    break;
                }
            }
            _ => i += 1,
        }
    }
    i
}

fn skip_nested_braces(bytes: &[u8], mut i: usize) -> usize {
    let mut depth = 1i32;
    while i < bytes.len() {
        match bytes[i] {
            b'\\' => {
                i += if i + 1 < bytes.len() { 2 } else { 1 };
            }
            b'\'' => {
                i += 1;
                while i < bytes.len() {
                    if bytes[i] == b'\'' {
                        i += 1;
                        break;
                    }
                    i += 1;
                }
            }
            b'"' => {
                i += 1;
                while i < bytes.len() {
                    if bytes[i] == b'\\' && i + 1 < bytes.len() {
                        i += 2;
                        continue;
                    }
                    if bytes[i] == b'"' {
                        i += 1;
                        break;
                    }
                    i += 1;
                }
            }
            b'$' if i + 1 < bytes.len() && bytes[i + 1] == b'{' => {
                i = skip_nested_braces(bytes, i + 2);
            }
            b'$' if i + 1 < bytes.len() && bytes[i + 1] == b'(' => {
                i = skip_nested_parens(bytes, i + 2);
            }
            b'{' => {
                depth += 1;
                i += 1;
            }
            b'}' => {
                depth -= 1;
                i += 1;
                if depth == 0 {
                    break;
                }
            }
            _ => i += 1,
        }
    }
    i
}

fn find_subscript_end(name: &str, honor_quotes: bool) -> Option<usize> {
    let br = name.find('[')?;
    let bytes = name.as_bytes();
    let mut depth = 1i32;
    let mut in_sq = false;
    let mut in_dq = false;
    let mut i = br + 1;
    while i < bytes.len() {
        let b = bytes[i];
        if honor_quotes && in_sq {
            if b == b'\'' {
                in_sq = false;
            }
            i += 1;
            continue;
        }
        if honor_quotes && in_dq {
            if b == b'\\' && i + 1 < bytes.len() {
                i += 2;
                continue;
            }
            if b == b'"' {
                in_dq = false;
            }
            i += 1;
            continue;
        }
        match b {
            b'\\' => {
                i += if i + 1 < bytes.len() { 2 } else { 1 };
                continue;
            }
            b'\'' if honor_quotes => {
                in_sq = true;
                i += 1;
                continue;
            }
            b'"' if honor_quotes => {
                in_dq = true;
                i += 1;
                continue;
            }
            b'$' if i + 1 < bytes.len() && bytes[i + 1] == b'(' => {
                i = skip_nested_parens(bytes, i + 2);
                continue;
            }
            b'$' if i + 1 < bytes.len() && bytes[i + 1] == b'{' => {
                i = skip_nested_braces(bytes, i + 2);
                continue;
            }
            b'[' => depth += 1,
            b']' => {
                depth -= 1;
                if depth == 0 {
                    return Some(i);
                }
            }
            _ => {}
        }
        i += 1;
    }
    None
}

fn find_subscript_end_relaxed(name: &str) -> Option<usize> {
    let br = name.find('[')?;
    let end = name.rfind(']')?;
    if end > br {
        Some(end)
    } else {
        None
    }
}

fn parse_subscripted_name(name: &str) -> Option<(String, String)> {
    let br = name.find('[')?;
    let base = &name[..br];
    if base.is_empty() {
        return None;
    }
    for honor_quotes in [true, false] {
        if let Some(end) = find_subscript_end(name, honor_quotes) {
            if end + 1 == name.len() {
                return Some((base.to_string(), name[br + 1..end].to_string()));
            }
        }
    }
    if let Some(end) = find_subscript_end_relaxed(name) {
        if end + 1 == name.len() {
            return Some((base.to_string(), name[br + 1..end].to_string()));
        }
    }
    None
}

fn parse_subscripted_name_strict(name: &str) -> Option<(String, String)> {
    let br = name.find('[')?;
    let base = &name[..br];
    if base.is_empty() {
        return None;
    }
    // First try honour-quote parsing — this respects single/double quotes
    // inside the subscript and only finds an end after balanced quotes.
    if let Some(end) = find_subscript_end(name, true) {
        if end + 1 == name.len() {
            return Some((base.to_string(), name[br + 1..end].to_string()));
        }
    }
    // Fall back to ignore-quote parsing only when the subscript contains
    // no quote characters.  bash rejects unbalanced apostrophes/quotes
    // such as `a[80's]` with "not a valid identifier"; matching that
    // means refusing to fall back when quote chars are present.
    let inner_after_br = &name[br + 1..];
    if inner_after_br.chars().any(|c| c == '\'' || c == '"') {
        return None;
    }
    if let Some(end) = find_subscript_end(name, false) {
        if end + 1 == name.len() {
            return Some((base.to_string(), name[br + 1..end].to_string()));
        }
    }
    None
}

fn parse_subscripted_name_assoc_once(name: &str) -> Option<(String, String)> {
    if let Some(parsed) = parse_subscripted_name_strict(name) {
        return Some(parsed);
    }
    let br = name.find('[')?;
    let base = &name[..br];
    if base.is_empty() {
        return None;
    }
    let end = name.rfind(']')?;
    if end + 1 != name.len() {
        return None;
    }
    if name[br + 1..end].contains(']') {
        return None;
    }
    Some((base.to_string(), name[br + 1..end].to_string()))
}

fn is_compound_bare_elem(elem: &str) -> bool {
    elem.starts_with("\x00COMPOUND_BARE\x00")
}

fn strip_compound_bare_elem<'a>(elem: &'a str) -> &'a str {
    elem.strip_prefix("\x00COMPOUND_BARE\x00").unwrap_or(elem)
}

/// Extended parse for `[key]=value` or `[key]+=value` from compound array assignments.
/// Returns `Some((key, value, append))` where `append` is true for `[key]+=value`.
fn parse_bracket_assign_ext(elem: &str) -> Option<(String, String, bool)> {
    if !elem.starts_with('[') {
        return None;
    }
    let bytes = elem.as_bytes();
    for honor_quotes in [true, false] {
        if let Some(i) = find_subscript_end(elem, honor_quotes) {
            if i + 2 < bytes.len() && bytes[i + 1] == b'+' && bytes[i + 2] == b'=' {
                let key = elem[1..i].to_string();
                let val = elem[i + 3..].to_string();
                return Some((key, val, true));
            }
            if i + 1 < bytes.len() && bytes[i + 1] == b'=' {
                let key = elem[1..i].to_string();
                let val = elem[i + 2..].to_string();
                return Some((key, val, false));
            }
        }
    }
    if let Some(i) = elem.rfind(']') {
        if i + 2 < bytes.len() && bytes[i + 1] == b'+' && bytes[i + 2] == b'=' {
            let key = elem[1..i].to_string();
            let val = elem[i + 3..].to_string();
            return Some((key, val, true));
        }
        if i + 1 < bytes.len() && bytes[i + 1] == b'=' {
            let key = elem[1..i].to_string();
            let val = elem[i + 2..].to_string();
            return Some((key, val, false));
        }
    }
    None
}

/// Public wrapper for `parse_bracket_assign` used by the declare builtin.
/// Returns `Some((key, value))` if `elem` matches `[key]=value`.
pub fn parse_bracket_assign_pub(elem: &str) -> Option<(String, String)> {
    parse_bracket_assign(elem)
}

/// Public wrapper for `parse_bracket_assign_ext` — returns the append flag too.
pub fn parse_bracket_assign_ext_pub(elem: &str) -> Option<(String, String, bool)> {
    parse_bracket_assign_ext(elem)
}

pub fn parse_subscripted_name_pub(name: &str) -> Option<(String, String)> {
    parse_subscripted_name(name)
}

pub fn parse_subscripted_name_strict_pub(name: &str) -> Option<(String, String)> {
    parse_subscripted_name_strict(name)
}

pub fn parse_subscripted_name_assoc_once_pub(name: &str) -> Option<(String, String)> {
    parse_subscripted_name_assoc_once(name)
}

/// Check if a string is a valid shell identifier (for variable names, etc.)
fn is_valid_identifier(s: &str) -> bool {
    if s.is_empty() {
        return false;
    }
    let mut chars = s.chars();
    let first = chars.next().unwrap();
    if !first.is_alphabetic() && first != '_' {
        return false;
    }
    chars.all(|c| c.is_alphanumeric() || c == '_')
}

/// Public wrapper for `is_valid_identifier`.
pub fn is_valid_identifier_pub(s: &str) -> bool {
    is_valid_identifier(s)
}

fn default_fd_for_op(op: &RedirectOp) -> RawFd {
    match op {
        RedirectOp::Input | RedirectOp::InputDup | RedirectOp::Heredoc
        | RedirectOp::HeredocStrip | RedirectOp::HereString | RedirectOp::InputOutput => 0,
        _ => 1,
    }
}

/// Convert a Rust I/O error to a bash-compatible error string (no "(os error N)" suffix).
fn bash_io_error_str(err: &std::io::Error) -> &'static str {
    match err.raw_os_error() {
        Some(libc::ENOENT)  => "No such file or directory",
        Some(libc::EACCES)  => "Permission denied",
        Some(libc::EISDIR)  => "Is a directory",
        Some(libc::ENOTDIR) => "Not a directory",
        Some(libc::EROFS)   => "Read-only file system",
        Some(libc::EEXIST)  => "File exists",
        Some(libc::EPERM)   => "Operation not permitted",
        Some(libc::ENOTEMPTY) => "Directory not empty",
        #[cfg(target_os = "macos")]
        Some(libc::ENXIO)   => "Device not configured",
        // Note: ENXIO / EIO on macOS typically produce
        // "Device not configured" / "Input/output error", but the
        // bash test suite's .right files reference Linux strings.
        // Keep our mapping loose so existing tests continue to match
        // where the platform-specific text would diverge.
        Some(libc::EIO)     => "Input/output error",
        Some(libc::EBADF)   => "Bad file descriptor",
        Some(libc::EINVAL)  => "Invalid argument",
        Some(libc::EPIPE)   => "Broken pipe",
        Some(libc::ENOSPC)  => "No space left on device",
        Some(libc::EMFILE)  => "Too many open files",
        _                   => "I/O error",
    }
}

fn redirect_stdin_to_devnull() {
    // Bash redirects an asynchronous command's stdin to /dev/null only when
    // the shell's stdin is interactive (a tty).  When stdin has already been
    // redirected (e.g. a `for ... done < heredoc` body), the backgrounded
    // child inherits the redirected fd and we must NOT clobber it with
    // /dev/null — otherwise reads inside the body see EOF.  Test with
    // `isatty(0)`: TTY → safe to swap; not-TTY → leave inherited fd alone.
    if unsafe { libc::isatty(0) } == 0 {
        return;
    }
    let cpath = CString::new("/dev/null").unwrap();
    let fd = unsafe { libc::open(cpath.as_ptr(), libc::O_RDONLY) };
    if fd >= 0 {
        unsafe {
            let _ = libc::dup2(fd, 0);
            if fd != 0 {
                let _ = libc::close(fd);
            }
        }
    }
}

/// Open a file and dup2 it onto `target_fd`.
fn open_and_dup(
    path: &str,
    flags: libc::c_int,
    mode: libc::mode_t,
    target_fd: RawFd,
    _noclobber: bool,
) -> Result<(), String> {
    let cpath = CString::new(path).map_err(|e| e.to_string())?;
    let fd = unsafe { libc::open(cpath.as_ptr(), flags, mode as libc::c_uint) };
    if fd < 0 {
        let err = std::io::Error::last_os_error();
        // Format as bash-style message (no "(os error N)" suffix)
        let msg = bash_io_error_str(&err);
        return Err(format!("{}: {}", path, msg));
    }
    if fd != target_fd {
        let rc = unsafe { libc::dup2(fd, target_fd) };
        unsafe { libc::close(fd); }
        if rc < 0 {
            return Err(std::io::Error::last_os_error().to_string());
        }
    }
    Ok(())
}

fn is_fd_dup_target(target: &str) -> bool {
    if target == "-" {
        return true;
    }

    let num_str = if target.ends_with('-') && target.len() > 1 {
        &target[..target.len() - 1]
    } else {
        target
    };

    matches!(num_str.parse::<RawFd>(), Ok(n) if n >= 0)
}

fn output_dup_uses_file_form(redir: &Redirect, target: &str) -> bool {
    matches!(redir.op, RedirectOp::OutputDup)
        && redir.varfd.is_none()
        && redir.fd.unwrap_or(1) == 1
        && !target.is_empty()
        && !is_fd_dup_target(target)
}

fn push_saved_fd(saved: &mut Vec<SavedFd>, fd: RawFd) {
    // Keep shell-private restore fds out of the user-visible low range so
    // redirects like `echo >&3` or `exec 10>&1` don't accidentally target the
    // shell's own saved duplicates.
    let saved_fd = unsafe { libc::fcntl(fd, libc::F_DUPFD_CLOEXEC, 64) };
    let saved_fd = if saved_fd >= 0 {
        saved_fd
    } else {
        unsafe { libc::dup(fd) }
    };
    if saved_fd >= 0 {
        saved.push(SavedFd { original_fd: fd, saved_fd });
    } else {
        saved.push(SavedFd {
            original_fd: fd,
            saved_fd: -2,
        });
    }
}

/// Like `dup_fd` but takes a separate `label` used in error messages —
/// e.g. `$v` when the user wrote `>&$v` and `target` is the expanded
/// value.  Bash's error reports the original text, not the expansion.
fn dup_fd_with_label(target: &str, fd: RawFd, label: &str) -> Result<(), String> {
    if target == "-" {
        // Close the fd
        unsafe { libc::close(fd); }
        return Ok(());
    }

    // Check for move-fd syntax: digits followed by '-'
    let (num_str, close_source) = if target.ends_with('-') && target.len() > 1 {
        (&target[..target.len() - 1], true)
    } else {
        (target, false)
    };

    let n: RawFd = num_str.parse().map_err(|_| format!("{}: ambiguous redirect", label))?;
    // Negative fds are never valid — bash treats them as ambiguous
    // redirects, not as an fd it tries to dup.  Bash uses the EXPANDED
    // value (e.g. "-1") in this specific error, not the raw redirect
    // word — so use `target` here instead of `label`.
    if n < 0 {
        return Err(format!("{}: ambiguous redirect", target));
    }
    let rc = unsafe { libc::dup2(n, fd) };
    if rc < 0 {
        return Err(format!("{}: Bad file descriptor", label));
    }

    // If move-fd syntax was used, close the source fd after duplication.
    // Only close if the source and destination are different; dup2 with
    // identical fds is a no-op that must not close the fd.
    if close_source && n != fd {
        unsafe { libc::close(n); }
    }

    Ok(())
}

/// Write `content` to an anonymous temp file and dup2 the read fd onto `target_fd`.
///
/// The file is unlinked immediately so it is cleaned up automatically once the
/// fd is closed.  This avoids the pipe-buffer deadlock that occurs when the
/// heredoc body is larger than the OS pipe buffer (typically 64 KB on macOS).
fn heredoc_via_tmpfile(content: &[u8], target_fd: RawFd) -> Result<(), String> {
    // Create a temp file, write the content, unlink it, then seek back to the
    // start so the reader sees the full body.
    let path = CString::new("/tmp/brash_heredoc_XXXXXX").map_err(|e| e.to_string())?;
    let raw = path.into_raw();
    let tmp_fd = unsafe { libc::mkstemp(raw) };
    if tmp_fd < 0 {
        // reclaim the CString to avoid a leak
        let _ = unsafe { CString::from_raw(raw) };
        return Err(format!("heredoc: mkstemp failed: {}", std::io::Error::last_os_error()));
    }
    // Unlink the temp file immediately — the fd keeps the data alive.
    unsafe { libc::unlink(raw); }
    // Reclaim the CString so it is freed.
    let _ = unsafe { CString::from_raw(raw) };

    // Write all content.
    let mut written: usize = 0;
    while written < content.len() {
        let n = unsafe {
            libc::write(
                tmp_fd,
                content[written..].as_ptr() as *const libc::c_void,
                content.len() - written,
            )
        };
        if n < 0 {
            let err = std::io::Error::last_os_error();
            unsafe { libc::close(tmp_fd); }
            return Err(format!("heredoc: write: {}", err));
        }
        if n == 0 {
            break;
        }
        written += n as usize;
    }

    // Seek back to the beginning so the reader sees the full content.
    if unsafe { libc::lseek(tmp_fd, 0, libc::SEEK_SET) } < 0 {
        let err = std::io::Error::last_os_error();
        unsafe { libc::close(tmp_fd); }
        return Err(format!("heredoc: lseek: {}", err));
    }

    // Wire it up to the requested fd.
    if tmp_fd != target_fd {
        let rc = unsafe { libc::dup2(tmp_fd, target_fd) };
        unsafe { libc::close(tmp_fd); }
        if rc < 0 {
            return Err(format!("heredoc: dup2: {}", std::io::Error::last_os_error()));
        }
    }

    Ok(())
}

/// Apply a redirect directly in the child process (no save/restore).
fn apply_redirect_in_child(redir: &Redirect, shell: &mut Shell) -> Result<(), String> {
    // Resolve process substitutions in redirect targets
    let effective_target = if Shell::contains_procsub(&redir.target) {
        let mut child_pids: Vec<Pid> = Vec::new();
        let mut parent_fds: Vec<RawFd> = Vec::new();
        shell.resolve_procsub_in_str(&redir.target, &mut child_pids, &mut parent_fds)
    } else {
        redir.target.clone()
    };
    let target = match &redir.op {
        RedirectOp::Heredoc | RedirectOp::HeredocStrip if redir.heredoc_quoted => {
            effective_target
        }
        RedirectOp::Heredoc | RedirectOp::HeredocStrip => {
            let expanded = expand::expand_heredoc(&effective_target, &mut shell.vars);
            shell.resolve_cmdsubs(&expanded)
        }
        _ => {
            let expanded = shell.expand_word_nosplit(&effective_target);
            let target = if matches!(&redir.op, RedirectOp::HereString) {
                expanded.replace('\u{FFFE}', " ")
            } else {
                expanded
            };
            // Ambiguous-redirect check: bash word-splits the redirect
            // target and errors if it yields >1 field.
            if matches!(&redir.op,
                RedirectOp::Input | RedirectOp::Output | RedirectOp::Append
                | RedirectOp::InputOutput | RedirectOp::Clobber
                | RedirectOp::AndOutput | RedirectOp::AndAppend)
                || output_dup_uses_file_form(redir, &target)
            {
                let ifs = shell.vars.get("IFS").unwrap_or_else(|| " \t\n".to_string());
                let fields = expand::word_split(&target, &ifs);
                let count = fields.iter().filter(|f| !f.is_empty()).count();
                if count > 1 {
                    return Err(format!("{}: ambiguous redirect", redir.target));
                }
            }
            target
        }
    };
    let fd = redir.fd.unwrap_or_else(|| default_fd_for_op(&redir.op));

    match &redir.op {
        RedirectOp::Input => {
            open_and_dup(&target, libc::O_RDONLY, 0o644, fd, false)?;
        }
        RedirectOp::Output => {
            open_and_dup(
                &target,
                libc::O_WRONLY | libc::O_CREAT | libc::O_TRUNC,
                0o644,
                fd,
                false,
            )?;
        }
        RedirectOp::Append => {
            open_and_dup(
                &target,
                libc::O_WRONLY | libc::O_CREAT | libc::O_APPEND,
                0o644,
                fd,
                false,
            )?;
        }
        RedirectOp::InputOutput => {
            open_and_dup(&target, libc::O_RDWR | libc::O_CREAT, 0o644, fd, false)?;
        }
        RedirectOp::InputDup => {
            dup_fd_with_label(&target, fd, &redir.target)?;
        }
        RedirectOp::OutputDup if output_dup_uses_file_form(redir, &target) => {
            open_and_dup(
                &target,
                libc::O_WRONLY | libc::O_CREAT | libc::O_TRUNC,
                0o644,
                1,
                false,
            )?;
            unsafe { libc::dup2(1, 2); }
        }
        RedirectOp::OutputDup => {
            dup_fd_with_label(&target, fd, &redir.target)?;
        }
        RedirectOp::Clobber => {
            open_and_dup(
                &target,
                libc::O_WRONLY | libc::O_CREAT | libc::O_TRUNC,
                0o644,
                fd,
                false,
            )?;
        }
        RedirectOp::Heredoc | RedirectOp::HeredocStrip => {
            // Use a temp file to avoid pipe-buffer deadlock.
            heredoc_via_tmpfile(target.as_bytes(), fd)?;
        }
        RedirectOp::HereString => {
            // <<< word — write word + newline via temp file
            let content = format!("{}\n", target);
            heredoc_via_tmpfile(content.as_bytes(), fd)?;
        }
        RedirectOp::AndOutput => {
            open_and_dup(
                &target,
                libc::O_WRONLY | libc::O_CREAT | libc::O_TRUNC,
                0o644,
                1,
                false,
            )?;
            unsafe { libc::dup2(1, 2); }
        }
        RedirectOp::AndAppend => {
            open_and_dup(
                &target,
                libc::O_WRONLY | libc::O_CREAT | libc::O_APPEND,
                0o644,
                1,
                false,
            )?;
            unsafe { libc::dup2(1, 2); }
        }
    }

    Ok(())
}

// ---------------------------------------------------------------------------
// fnmatch — case pattern matching using glob-style patterns
// ---------------------------------------------------------------------------

/// Match a bash case pattern against a string.
/// Supports * ? [...] character classes and — when extglob is on —
/// the extended glob operators ?(…), *(…), +(…), @(…), !(…).
fn fnmatch_pattern(pattern: &str, subject: &str) -> bool {
    // Special case: '*' matches everything
    if pattern == "*" {
        return true;
    }
    // If the pattern contains any extglob prefix (?*+@! followed by
    // '('), delegate to the extglob-capable matcher in builtins.rs
    // which recurses through the alternatives.  This keeps the plain
    // case fast while covering the extended-glob tests.
    if has_extglob(pattern) {
        return crate::builtins::glob_match_pub(pattern, subject);
    }
    fnmatch_chars(pattern.as_bytes(), subject.as_bytes())
}

fn has_extglob(pat: &str) -> bool {
    let bytes = pat.as_bytes();
    for i in 0..bytes.len().saturating_sub(1) {
        let c = bytes[i];
        if matches!(c, b'?' | b'*' | b'+' | b'@' | b'!') && bytes[i + 1] == b'(' {
            return true;
        }
    }
    false
}

fn fnmatch_chars(pat: &[u8], sub: &[u8]) -> bool {
    if pat.is_empty() {
        return sub.is_empty();
    }

    match pat[0] {
        b'*' => {
            // Match zero or more characters
            for i in 0..=sub.len() {
                if fnmatch_chars(&pat[1..], &sub[i..]) {
                    return true;
                }
            }
            false
        }
        b'?' => {
            // Match exactly one character
            if sub.is_empty() {
                false
            } else {
                fnmatch_chars(&pat[1..], &sub[1..])
            }
        }
        b'[' => {
            // Character class
            if sub.is_empty() {
                return false;
            }
            let (matched, consumed) = match_char_class(&pat[1..], sub[0]);
            if matched {
                fnmatch_chars(&pat[1 + consumed..], &sub[1..])
            } else {
                false
            }
        }
        b'\\' if pat.len() > 1 => {
            // Escaped character — match literally
            if sub.is_empty() {
                false
            } else if sub[0] == pat[1] {
                fnmatch_chars(&pat[2..], &sub[1..])
            } else {
                false
            }
        }
        c => {
            if sub.is_empty() {
                false
            } else if sub[0] == c {
                fnmatch_chars(&pat[1..], &sub[1..])
            } else {
                false
            }
        }
    }
}

/// Parse a bracket expression `...] ` and return
/// (matched, bytes_consumed_excluding_leading_bracket).
///
/// Supports POSIX character classes `[:name:]`, collating symbols `[.name.]`,
/// and equivalence classes `[=c=]`.
fn match_char_class(pat: &[u8], ch: u8) -> (bool, usize) {
    let n = pat.len();
    let mut i = 0;
    let negate = i < n && (pat[i] == b'!' || pat[i] == b'^');
    if negate {
        i += 1;
    }

    let mut matched = false;
    let mut found_close = false;
    let mut first = true; // ']' as first char is literal, not close

    while i < n {
        if pat[i] == b']' && !first {
            found_close = true;
            i += 1;
            break;
        }
        first = false;

        // --- POSIX class / collating / equivalence ---
        if pat[i] == b'[' && i + 1 < n {
            match pat[i + 1] {
                b':' => {
                    // POSIX character class [:name:]
                    match parse_posix_class(pat, i, ch) {
                        PosixClassResult::Valid(class_matched, after) => {
                            if class_matched { matched = true; }
                            i = after;
                            continue;
                        }
                        PosixClassResult::InvalidName(after) => {
                            // Bash 5.3 parses `[:...:]` as a class-form
                            // even when the name is unknown — it just
                            // adds no characters to the match set.  Skip
                            // past the whole `[:name:]` so the inner `]`
                            // doesn't prematurely close the outer bracket.
                            i = after;
                            continue;
                        }
                        PosixClassResult::Unterminated => {
                            // No :] found — treat leading '[' as literal
                            if ch == b'[' { matched = true; }
                            i += 1;
                            continue;
                        }
                    }
                }
                b'.' => {
                    // Collating symbol [.name.]
                    if let Some((coll_ch, after)) = parse_collating_symbol(pat, i) {
                        // Check for range: [.x.]-y
                        if after < n && pat[after] == b'-'
                            && after + 1 < n && pat[after + 1] != b']'
                        {
                            let (range_end, after_range) = parse_range_endpoint(pat, after + 1);
                            if let (Some(lo), Some(hi)) = (coll_ch, range_end) {
                                if ch >= lo && ch <= hi { matched = true; }
                            }
                            i = after_range;
                        } else if let Some(c) = coll_ch {
                            if c == ch { matched = true; }
                            i = after;
                        } else {
                            // Unknown collating symbol — skip it
                            i = after;
                        }
                        continue;
                    }
                    // Malformed — treat '[' as literal
                    if ch == b'[' { matched = true; }
                    i += 1;
                    continue;
                }
                b'=' => {
                    // Equivalence class [=c=]
                    if let Some((equiv_ch, after)) = parse_equiv_class(pat, i) {
                        if let Some(c) = equiv_ch {
                            // In C locale, equivalence class matches exact character
                            if c == ch { matched = true; }
                        }
                        i = after;
                        continue;
                    }
                    // Malformed — treat '[' as literal
                    if ch == b'[' { matched = true; }
                    i += 1;
                    continue;
                }
                _ => {
                    // Just a literal '['
                    // But check for range first: [-y
                    if i + 2 < n && pat[i + 1] == b'-' && pat[i + 2] != b']' {
                        // Actually pat[i] is '[', pat[i+1] would need to be checked
                        // but here pat[i+1] is something else; fall through to literal
                    }
                    if ch == b'[' { matched = true; }
                    i += 1;
                    continue;
                }
            }
        }

        // Backslash escape inside bracket expression
        if pat[i] == b'\\' && i + 1 < n {
            let lit = pat[i + 1];
            // Check for range: \x-y
            if i + 3 < n && pat[i + 2] == b'-' && pat[i + 3] != b']' {
                let (range_end, after) = parse_range_endpoint(pat, i + 3);
                if let Some(hi) = range_end {
                    if ch >= lit && ch <= hi { matched = true; }
                }
                i = after;
            } else {
                if lit == ch { matched = true; }
                i += 2;
            }
            continue;
        }

        // Character range: a-z (but not if '-' is last before ']')
        if i + 2 < n && pat[i + 1] == b'-' && pat[i + 2] != b']' {
            let lo = pat[i];
            let (range_end, after) = parse_range_endpoint(pat, i + 2);
            if let Some(hi) = range_end {
                if ch >= lo && ch <= hi { matched = true; }
            }
            i = after;
            continue;
        }

        // Plain literal character
        if pat[i] == ch { matched = true; }
        i += 1;
    }

    if !found_close {
        // Malformed bracket expression — treat '[' as literal
        return (ch == b'[', 0);
    }

    let result = if negate { !matched } else { matched };
    (result, i)
}

/// Result of trying to parse a `[:name:]` POSIX character class.
enum PosixClassResult {
    /// Valid class, (matched, index_after).
    Valid(bool, usize),
    /// Properly formed `[:name:]` but the name is not recognised — the
    /// enclosing bracket expression is invalid per POSIX.
    InvalidName(usize),
    /// Unterminated `[:…` — no `:]` found; treat `[` as literal.
    Unterminated,
}

/// Try to parse a POSIX character class `[:name:]` starting at `pat[start]`.
fn parse_posix_class(pat: &[u8], start: usize, ch: u8) -> PosixClassResult {
    // pat[start] == '[', pat[start+1] == ':'
    let mut i = start + 2;
    let n = pat.len();
    // Find closing :]
    while i + 1 < n {
        if pat[i] == b':' && pat[i + 1] == b']' {
            let name = &pat[start + 2..i];
            let m = match name {
                b"alpha"  => (ch as char).is_ascii_alphabetic(),
                b"digit"  => (ch as char).is_ascii_digit(),
                b"alnum"  => (ch as char).is_ascii_alphanumeric(),
                b"upper"  => (ch as char).is_ascii_uppercase(),
                b"lower"  => (ch as char).is_ascii_lowercase(),
                b"space"  => matches!(ch, b' ' | b'\t' | b'\n' | b'\r' | 0x0b | 0x0c),
                b"blank"  => ch == b' ' || ch == b'\t',
                b"punct"  => (ch as char).is_ascii_punctuation(),
                b"print"  => ch >= 0x20 && ch <= 0x7e,
                b"cntrl"  => ch < 0x20 || ch == 0x7f,
                b"graph"  => ch > 0x20 && ch <= 0x7e,
                b"xdigit" => (ch as char).is_ascii_hexdigit(),
                b"ascii"  => ch <= 0x7f,
                _ => return PosixClassResult::InvalidName(i + 2),
            };
            return PosixClassResult::Valid(m, i + 2);
        }
        i += 1;
    }
    PosixClassResult::Unterminated
}

/// Try to parse a collating symbol `[.name.]` starting at `pat[start]`.
/// Returns Some((resolved_char_option, index_after_closing_bracket)).
/// If the collating symbol is unknown, the char is None but parsing still succeeds.
fn parse_collating_symbol(pat: &[u8], start: usize) -> Option<(Option<u8>, usize)> {
    // pat[start] == '[', pat[start+1] == '.'
    let mut i = start + 2;
    let n = pat.len();
    while i + 1 < n {
        if pat[i] == b'.' && pat[i + 1] == b']' {
            let name = &pat[start + 2..i];
            let ch = resolve_collating_name(name);
            return Some((ch, i + 2));
        }
        i += 1;
    }
    None // unterminated
}

/// Resolve a collating symbol name to its character.
fn resolve_collating_name(name: &[u8]) -> Option<u8> {
    // Single character collating symbols: [.a.] [.-.]
    if name.len() == 1 {
        return Some(name[0]);
    }
    // Named collating symbols (POSIX C locale names)
    match name {
        b"NUL" | b"nul"                       => Some(0x00),
        b"SOH" | b"soh"                       => Some(0x01),
        b"STX" | b"stx"                       => Some(0x02),
        b"ETX" | b"etx"                       => Some(0x03),
        b"EOT" | b"eot"                       => Some(0x04),
        b"ENQ" | b"enq"                       => Some(0x05),
        b"ACK" | b"ack"                       => Some(0x06),
        b"BEL" | b"alert" | b"bel"           => Some(0x07),
        b"BS" | b"backspace" | b"bs"          => Some(0x08),
        b"HT" | b"tab" | b"ht"               => Some(0x09),
        b"LF" | b"newline" | b"lf"           => Some(0x0a),
        b"VT" | b"vertical-tab" | b"vt"      => Some(0x0b),
        b"FF" | b"form-feed" | b"ff"         => Some(0x0c),
        b"CR" | b"carriage-return" | b"cr"    => Some(0x0d),
        b"SO" | b"so"                         => Some(0x0e),
        b"SI" | b"si"                         => Some(0x0f),
        b"DLE" | b"dle"                       => Some(0x10),
        b"DC1" | b"dc1"                       => Some(0x11),
        b"DC2" | b"dc2"                       => Some(0x12),
        b"DC3" | b"dc3"                       => Some(0x13),
        b"DC4" | b"dc4"                       => Some(0x14),
        b"NAK" | b"nak"                       => Some(0x15),
        b"SYN" | b"syn"                       => Some(0x16),
        b"ETB" | b"etb"                       => Some(0x17),
        b"CAN" | b"can"                       => Some(0x18),
        b"EM" | b"em"                         => Some(0x19),
        b"SUB" | b"sub"                       => Some(0x1a),
        b"ESC" | b"escape" | b"esc"          => Some(0x1b),
        b"IS4" | b"is4"                       => Some(0x1c),
        b"IS3" | b"is3"                       => Some(0x1d),
        b"IS2" | b"is2"                       => Some(0x1e),
        b"IS1" | b"is1"                       => Some(0x1f),
        b"space"                              => Some(b' '),
        b"exclamation-mark"                   => Some(b'!'),
        b"quotation-mark"                     => Some(b'"'),
        b"number-sign"                        => Some(b'#'),
        b"dollar-sign"                        => Some(b'$'),
        b"percent-sign"                       => Some(b'%'),
        b"ampersand"                          => Some(b'&'),
        b"apostrophe"                         => Some(b'\''),
        b"left-parenthesis"                   => Some(b'('),
        b"right-parenthesis"                  => Some(b')'),
        b"asterisk"                           => Some(b'*'),
        b"plus-sign"                          => Some(b'+'),
        b"comma"                              => Some(b','),
        b"hyphen" | b"hyphen-minus"           => Some(b'-'),
        b"period" | b"full-stop"              => Some(b'.'),
        b"slash" | b"solidus"                 => Some(b'/'),
        b"zero"                               => Some(b'0'),
        b"one"                                => Some(b'1'),
        b"two"                                => Some(b'2'),
        b"three"                              => Some(b'3'),
        b"four"                               => Some(b'4'),
        b"five"                               => Some(b'5'),
        b"six"                                => Some(b'6'),
        b"seven"                              => Some(b'7'),
        b"eight"                              => Some(b'8'),
        b"nine"                               => Some(b'9'),
        b"colon"                              => Some(b':'),
        b"semicolon"                          => Some(b';'),
        b"less-than-sign"                     => Some(b'<'),
        b"equals-sign"                        => Some(b'='),
        b"greater-than-sign"                  => Some(b'>'),
        b"question-mark"                      => Some(b'?'),
        b"commercial-at"                      => Some(b'@'),
        b"left-square-bracket"                => Some(b'['),
        b"backslash" | b"reverse-solidus"     => Some(b'\\'),
        b"right-square-bracket"               => Some(b']'),
        b"circumflex" | b"circumflex-accent"  => Some(b'^'),
        b"underscore" | b"low-line"           => Some(b'_'),
        b"grave-accent"                       => Some(b'`'),
        b"left-curly-bracket"                 => Some(b'{'),
        b"vertical-line"                      => Some(b'|'),
        b"right-curly-bracket"                => Some(b'}'),
        b"tilde"                              => Some(b'~'),
        b"DEL" | b"del"                       => Some(0x7f),
        _ => None, // unknown collating symbol
    }
}

/// Try to parse an equivalence class `[=c=]` starting at `pat[start]`.
/// Returns Some((char_option, index_after_closing_bracket)).
fn parse_equiv_class(pat: &[u8], start: usize) -> Option<(Option<u8>, usize)> {
    // pat[start] == '[', pat[start+1] == '='
    let mut i = start + 2;
    let n = pat.len();
    while i + 1 < n {
        if pat[i] == b'=' && pat[i + 1] == b']' {
            let name = &pat[start + 2..i];
            // In C locale, equivalence class matches the exact character
            let ch = if name.len() == 1 { Some(name[0]) } else { None };
            return Some((ch, i + 2));
        }
        i += 1;
    }
    None // unterminated
}

/// Parse a range endpoint, which may be a collating symbol `[.x.]` or plain char.
/// Returns (resolved_char, index_after_endpoint).
fn parse_range_endpoint(pat: &[u8], start: usize) -> (Option<u8>, usize) {
    let n = pat.len();
    if start >= n {
        return (None, start);
    }
    // Collating symbol as range endpoint
    if start + 1 < n && pat[start] == b'[' && pat[start + 1] == b'.' {
        if let Some((ch, after)) = parse_collating_symbol(pat, start) {
            return (ch, after);
        }
    }
    // Backslash escape
    if pat[start] == b'\\' && start + 1 < n {
        return (Some(pat[start + 1]), start + 2);
    }
    // Plain character
    (Some(pat[start]), start + 1)
}

// ---------------------------------------------------------------------------
// Public helper: execute_command_sub is called from expand.rs
// ---------------------------------------------------------------------------

impl Shell {
    /// Public wrapper so expand.rs can call command substitution.
    /// Currently unused — expand.rs reaches `execute_command_sub` through
    /// internal helpers; this entry stays public for external callers.
    #[allow(dead_code)]
    pub fn command_sub(&mut self, cmd_str: &str) -> String {
        self.execute_command_sub(cmd_str)
    }

    /// Public wrapper for process pipeline status array.  PIPESTATUS is read
    /// directly from `vars` in the rest of the tree; this public read accessor
    /// is kept for external introspection (debuggers, test runners).
    #[allow(dead_code)]
    pub fn get_pipestatus(&self) -> &[i32] {
        &self.pipestatus
    }

    /// Retrieve exported environment as a map (used by builtins like `env`).
    pub fn exported_env(&self) -> AHashMap<String, String> {
        let mut env = self.inherited_env.clone();
        env.extend(self.vars.exported_env());
        env
    }

    /// Encode the active short-flag set options (`-e`, `-u`, `-x`, …) as a
    /// concatenated string.  $- expansion uses an internal helper today;
    /// this public form is kept for parity with the planned `set -o` JSON
    /// dump.
    #[allow(dead_code)]
    pub fn get_option_string(&self) -> String {
        let mut s = String::new();
        if self.opts.allexport  { s.push('a'); }
        if self.opts.notify     { s.push('b'); }
        if self.opts.errexit    { s.push('e'); }
        if self.opts.noglob     { s.push('f'); }
        if self.opts.hashall    { s.push('h'); }
        if self.opts.history    { s.push('H'); }
        if self.opts.monitor    { s.push('m'); }
        if self.opts.noexec     { s.push('n'); }
        if self.opts.noclobber  { s.push('C'); }
        if self.opts.xtrace     { s.push('x'); }
        if self.opts.verbose    { s.push('v'); }
        if self.opts.nounset    { s.push('u'); }
        if self.opts.onecmd     { s.push('t'); }
        if self.opts.physical   { s.push('P'); }
        if self.opts.privileged { s.push('p'); }
        if self.opts.errtrace   { s.push('E'); }
        if self.opts.functrace  { s.push('T'); }
        s
    }

    /// Called by `break` builtin.
    pub fn do_break(&mut self, n: usize) {
        let count = if n == 0 { 1 } else { n };
        if self.loop_depth > 0 {
            self.break_count = count.min(self.loop_depth);
        } else if !self.posix_mode {
            // POSIX allows `break` outside a loop to silently no-op.
            eprintln!(
                "{}: break: only meaningful in a `for', `while', or `until' loop",
                self.err_prefix_with_line()
            );
        }
    }

    /// Called by `continue` builtin.
    pub fn do_continue(&mut self, n: usize) {
        let count = if n == 0 { 1 } else { n };
        if self.loop_depth > 0 {
            self.continue_count = count.min(self.loop_depth);
        } else if !self.posix_mode {
            eprintln!(
                "{}: continue: only meaningful in a `for', `while', or `until' loop",
                self.err_prefix_with_line()
            );
        }
    }

    /// Called by `return` builtin.
    pub fn do_return(&mut self, status: i32) {
        self.last_status = status;
        self.return_flag = true;
    }

    /// Run the EXIT trap (if any) and return the final exit status.
    /// Called when the shell is about to terminate from main.rs.
    pub fn run_exit_trap(&mut self) -> i32 {
        let saved_status = self.last_status;
        if !self.exit_trap_done {
            self.exit_trap_done = true;
            if let Some(trap_cmd) = self.traps.get_exit_trap() {
                let trap_cmd = trap_cmd.clone();
                // Temporarily clear exit_flag so the trap body can execute.
                let saved_exit_flag = self.exit_flag;
                self.exit_flag = false;
                self.run_string(&trap_cmd);
                if !self.exit_flag {
                    self.exit_flag = saved_exit_flag;
                }
            }
        }
        // Return the pre-trap status unless the trap body explicitly called
        // `exit N` (do_exit sets exit_flag and updates last_status to N).
        // Also return the trap-modified status if the trap explicitly called exit.
        if self.exit_flag {
            // Trap called exit N: use the trap's status
            self.last_status
        } else {
            // Normal completion: restore pre-trap status
            self.last_status = saved_status;
            saved_status
        }
    }

    /// Called by `exit` builtin.
    pub fn do_exit(&mut self, status: i32) {
        self.last_status = status;
        // Run EXIT trap BEFORE setting exit_flag, so that execute() doesn't
        // short-circuit when the trap body calls commands.
        if !self.exit_trap_done {
            self.exit_trap_done = true;
            if let Some(trap_cmd) = self.traps.get_exit_trap() {
                let trap_cmd = trap_cmd.clone();
                self.run_string(&trap_cmd);
            }
        }
        self.exit_flag = true;
    }
}

/// Format a TIMEFORMAT string.
/// Supports %[p]R (real), %[p]U (user), %[p]S (sys) where p is precision (0-3).
fn format_timeformat(fmt: &str, real: f64, user: f64, sys: f64) -> String {
    let mut result = String::new();
    let chars: Vec<char> = fmt.chars().collect();
    let mut i = 0;
    while i < chars.len() {
        if chars[i] == '%' {
            i += 1;
            // Parse optional precision
            let mut prec = 2usize; // default precision for TIMEFORMAT
            if i < chars.len() && chars[i].is_ascii_digit() {
                prec = (chars[i] as u8 - b'0') as usize;
                i += 1;
            }
            if i < chars.len() {
                match chars[i] {
                    'R' => { result.push_str(&format!("{:.prec$}", real, prec = prec)); i += 1; }
                    'U' => { result.push_str(&format!("{:.prec$}", user, prec = prec)); i += 1; }
                    'S' => { result.push_str(&format!("{:.prec$}", sys, prec = prec)); i += 1; }
                    'P' => {
                        // Percentage: (user+sys)/real * 100
                        let pct = if real > 0.0 { (user + sys) / real * 100.0 } else { 0.0 };
                        result.push_str(&format!("{:.prec$}", pct, prec = prec));
                        i += 1;
                    }
                    '%' => { result.push('%'); i += 1; }
                    _ => { result.push('%'); } // unknown, push % and retry
                }
            }
        } else {
            result.push(chars[i]);
            i += 1;
        }
    }
    result
}

// ---------------------------------------------------------------------------
// AST serialiser — convert a parsed function body back to shell source text.
// Used by `export -f` to build the BASH_FUNC_name%% environment variable.
// ---------------------------------------------------------------------------

use crate::parser::{Command as AstCommand, SimpleCommand,
                    List, ListOp, IfCmd, WhileCmd, UntilCmd, ForCmd,
                    CaseCmd, CaseTerminator, GroupCmd, SubshellCmd,
                    SelectCmd, ArithForCmd, FuncDef as AstFuncDef};

/// Bash rejects function names containing any of these characters,
/// both in the `name()` shorthand and with the `function` keyword.
/// Allowed special characters include `=`, `.`, digits, letters, underscore.
/// A name is invalid if it contains metacharacters that could start
/// substitution or redirection in bash.
fn is_valid_function_name(name: &str) -> bool {
    if name.is_empty() {
        return false;
    }
    for c in name.chars() {
        match c {
            '$' | '`' | '\\' | '"' | '\''
            | '<' | '>' | '(' | ')' | '&' | '|'
            | ';' | '\n' | '\t' | ' '
            | '#' | '{' | '}' => return false,
            _ => {}
        }
    }
    true
}

/// If the file at `path` has a `#!INTERP [args]` shebang and INTERP
/// does not exist / isn't executable, return `(INTERP, err_string)`
/// so the caller can format a bash-style "bad interpreter" message.
/// Returns None for non-shebang files or when the interpreter is OK.
fn check_bad_interpreter(path: &str) -> Option<(String, String)> {
    let content = std::fs::read(path).ok()?;
    if content.len() < 2 || content[0] != b'#' || content[1] != b'!' {
        return None;
    }
    // Read up to end of first line.
    let line_end = content[2..].iter().position(|&b| b == b'\n')
        .map(|p| p + 2).unwrap_or(content.len());
    let line: &[u8] = &content[2..line_end];
    // Skip leading whitespace.
    let start = line.iter().position(|&b| b != b' ' && b != b'\t').unwrap_or(line.len());
    // Interpreter is up to next whitespace.
    let end_of_interp = line[start..].iter().position(|&b| b == b' ' || b == b'\t')
        .map(|p| p + start).unwrap_or(line.len());
    let interp_bytes = &line[start..end_of_interp];
    if interp_bytes.is_empty() {
        return None;
    }
    let interp = String::from_utf8_lossy(interp_bytes).to_string();
    // Try to stat the interpreter.
    match std::fs::metadata(&interp) {
        Err(e) => {
            let msg = match e.raw_os_error() {
                Some(libc::ENOENT) => "No such file or directory".to_string(),
                Some(libc::EACCES) => "Permission denied".to_string(),
                _ => e.kind().to_string(),
            };
            Some((interp, msg))
        }
        Ok(_) => None,
    }
}

/// POSIX identifier: `[a-zA-Z_][a-zA-Z0-9_]*`.  Used in POSIX mode where
/// bash also rejects names like `11111`, `a.b`, or `a=2`.  Currently the
/// validators in `is_valid_identifier_pub` cover the same shape; kept for
/// future POSIX-mode-specific checks where bash diverges further.
#[allow(dead_code)]
fn is_posix_identifier(name: &str) -> bool {
    let mut chars = name.chars();
    let first = match chars.next() {
        Some(c) => c,
        None => return false,
    };
    if !first.is_ascii_alphabetic() && first != '_' {
        return false;
    }
    chars.all(|c| c.is_ascii_alphanumeric() || c == '_')
}

pub fn serialize_command(cmd: &AstCommand) -> String {
    match cmd {
        AstCommand::Simple(s) => serialize_simple(s),
        AstCommand::Pipeline(p) => serialize_pipeline(p),
        AstCommand::List(l) => serialize_list(l),
        AstCommand::If(i) => serialize_if(i),
        AstCommand::While(w) => serialize_while(w),
        AstCommand::Until(u) => serialize_until(u),
        AstCommand::For(f) => serialize_for(f),
        AstCommand::Case(c) => serialize_case(c),
        AstCommand::Group(g) => serialize_group(g),
        AstCommand::Subshell(s) => serialize_subshell(s),
        AstCommand::FuncDef(f) => serialize_funcdef(f),
        AstCommand::ArithEval(expr, _) => format!("(( {} ))", expr),
        AstCommand::ArithFor(a) => serialize_arith_for(a),
        AstCommand::Select(s) => serialize_select(s),
        AstCommand::Time(_posix, c) => format!("time {}", serialize_command(c)),
        AstCommand::Not(c) => format!("! {}", serialize_command(c)),
        AstCommand::Coproc(cop) => {
            let name_part = if let Some(n) = &cop.name { format!(" {}", n) } else { String::new() };
            format!("coproc{} {}", name_part, serialize_command(&cop.body))
        }
    }
}

pub fn deparse_procsub_markers(s: &str) -> String {
    let mut out = String::new();
    let chars: Vec<char> = s.chars().collect();
    let mut i = 0;
    while i < chars.len() {
        match chars[i] {
            '\u{E010}' | '\u{E011}' => {
                let dir = if chars[i] == '\u{E010}' { '<' } else { '>' };
                i += 1;
                let start = i;
                while i < chars.len() && chars[i] != '\u{E012}' {
                    i += 1;
                }
                let inner: String = chars[start..i].iter().collect();
                if i < chars.len() && chars[i] == '\u{E012}' {
                    i += 1;
                }
                out.push(dir);
                out.push('(');
                out.push_str(&inner);
                out.push(')');
            }
            c => {
                out.push(c);
                i += 1;
            }
        }
    }
    out
}

fn serialize_simple(s: &SimpleCommand) -> String {
    let mut parts: Vec<String> = Vec::new();
    for a in &s.assignments {
        let op = if a.append { "+=" } else { "=" };
        parts.push(format!("{}{}{}", a.name, op, deparse_procsub_markers(&a.value)));
    }
    for w in &s.words {
        parts.push(deparse_procsub_markers(w));
    }
    let mut result = parts.join(" ");
    for r in &s.redirects {
        result.push(' ');
        result.push_str(&serialize_redirect(r));
    }
    append_heredoc_bodies(&mut result, &s.redirects);
    result
}

fn serialize_pipeline(p: &Pipeline) -> String {
    let mut parts: Vec<String> = Vec::new();
    for (i, cmd) in p.commands.iter().enumerate() {
        parts.push(serialize_command(cmd));
        if i + 1 < p.commands.len() {
            let sep = if p.pipe_stderr.get(i).copied().unwrap_or(false) { "|&" } else { "|" };
            parts.push(sep.to_string());
        }
    }
    let body = parts.join(" ");
    if p.negated { format!("! {}", body) } else { body }
}

fn serialize_list(l: &List) -> String {
    let mut result = String::new();
    let last_idx = l.entries.len().saturating_sub(1);
    for (i, entry) in l.entries.iter().enumerate() {
        if i > 0 && !result.ends_with('\n') {
            result.push(' ');
        }
        result.push_str(&serialize_command(&entry.command));
        // When the preceding entry rendered a heredoc (trailing newline
        // from its delimiter-line), skip the `;` separator — bash does.
        let rendered_heredoc = result.ends_with('\n');
        // Don't emit a terminator for the final entry — callers
        // (e.g. `serialize_group`) wrap the body and add their own `;`.
        // Emitting one here produces stray `;;` in output like
        // `{ echo a; echo b;; }`, which then mis-parses when round-tripped.
        if i == last_idx {
            // Preserve `&` / `&&` / `||` as they're semantically meaningful
            // even at the tail of a list.  Only skip trailing `;`/newline.
            match entry.op {
                ListOp::Amp => result.push('&'),
                ListOp::And => result.push_str(" &&"),
                ListOp::Or => result.push_str(" ||"),
                _ => {}
            }
            continue;
        }
        if rendered_heredoc {
            // Preserve semantically meaningful connectors only
            match entry.op {
                ListOp::Amp => result.push('&'),
                ListOp::And => result.push_str("&&"),
                ListOp::Or  => result.push_str("||"),
                _ => {}
            }
            continue;
        }
        match entry.op {
            ListOp::Semi | ListOp::Last => result.push(';'),
            ListOp::Amp => result.push('&'),
            ListOp::And => result.push_str(" &&"),
            ListOp::Or  => result.push_str(" ||"),
            ListOp::Newline => result.push(';'),
        }
    }
    result
}

fn serialize_if(i: &IfCmd) -> String {
    let mut s = format!("if {}; then {}",
        serialize_command(&i.condition),
        serialize_command(&i.then_body));
    for (cond, body) in &i.elif_parts {
        s.push_str(&format!("; elif {}; then {}", serialize_command(cond), serialize_command(body)));
    }
    if let Some(else_body) = &i.else_body {
        s.push_str(&format!("; else {}", serialize_command(else_body)));
    }
    s.push_str("; fi");
    for r in &i.redirects { s.push(' '); s.push_str(&serialize_redirect(r)); }
    s
}

fn serialize_while(w: &WhileCmd) -> String {
    let mut s = format!("while {}; do {}; done",
        serialize_command(&w.condition), serialize_command(&w.body));
    for r in &w.redirects { s.push(' '); s.push_str(&serialize_redirect(r)); }
    s
}

fn serialize_until(u: &UntilCmd) -> String {
    let mut s = format!("until {}; do {}; done",
        serialize_command(&u.condition), serialize_command(&u.body));
    for r in &u.redirects { s.push(' '); s.push_str(&serialize_redirect(r)); }
    s
}

fn serialize_for(f: &ForCmd) -> String {
    let words = f
        .words
        .as_deref()
        .unwrap_or(&[])
        .iter()
        .map(|w| deparse_procsub_markers(w))
        .collect::<Vec<_>>()
        .join(" ");
    let mut s = format!("for {} in {}; do {}; done", f.var, words, serialize_command(&f.body));
    for r in &f.redirects { s.push(' '); s.push_str(&serialize_redirect(r)); }
    s
}

fn serialize_arith_for(a: &ArithForCmd) -> String {
    let mut s = format!("for (( {}; {}; {} )); do {}; done",
        a.init, a.cond, a.step, serialize_command(&a.body));
    for r in &a.redirects { s.push(' '); s.push_str(&serialize_redirect(r)); }
    s
}

fn serialize_case(c: &CaseCmd) -> String {
    let mut s = format!("case {} in", deparse_procsub_markers(&c.word));
    for arm in &c.arms {
        let pats = arm.patterns.join(" | ");
        let body_str = arm.body.as_ref()
            .map(|b| serialize_command(b))
            .unwrap_or_default();
        let term = match arm.terminator {
            CaseTerminator::Break => ";;",
            CaseTerminator::FallThrough => ";&",
            CaseTerminator::Continue => ";;&",
        };
        s.push_str(&format!(" ({}) {} {}", pats, body_str, term));
    }
    s.push_str(" esac");
    for r in &c.redirects { s.push(' '); s.push_str(&serialize_redirect(r)); }
    s
}

fn serialize_group(g: &GroupCmd) -> String {
    let mut s = format!("{{ {}; }}", serialize_command(&g.body));
    for r in &g.redirects { s.push(' '); s.push_str(&serialize_redirect(r)); }
    s
}

fn serialize_subshell(s: &SubshellCmd) -> String {
    let mut result = format!("( {} )", serialize_command(&s.body));
    for r in &s.redirects { result.push(' '); result.push_str(&serialize_redirect(r)); }
    result
}

fn serialize_select(s: &SelectCmd) -> String {
    let words = s
        .words
        .as_deref()
        .unwrap_or(&[])
        .iter()
        .map(|w| deparse_procsub_markers(w))
        .collect::<Vec<_>>()
        .join(" ");
    let mut result = format!("select {} in {}; do {}; done", s.var, words, serialize_command(&s.body));
    for r in &s.redirects { result.push(' '); result.push_str(&serialize_redirect(r)); }
    result
}

fn serialize_funcdef(f: &AstFuncDef) -> String {
    let body_str = serialize_command(&f.body);
    let mut s = format!("{} () {}", f.name, body_str);
    for r in &f.redirects { s.push(' '); s.push_str(&serialize_redirect(r)); }
    s
}

fn serialize_redirect(r: &Redirect) -> String {
    // When pretty-printing dup redirects (>&, <&, <>) bash always emits the
    // source fd explicitly, defaulting to 1 for `>&` and 0 for `<&`/`<>`.
    let fd = if let Some(varname) = r.varfd.as_ref() {
        format!("{{{}}}", varname)
    } else {
        match r.fd {
            Some(f) => f.to_string(),
            None => match r.op {
                RedirectOp::OutputDup => "1".to_string(),
                RedirectOp::InputDup | RedirectOp::InputOutput => "0".to_string(),
                _ => String::new(),
            },
        }
    };
    let op = match r.op {
        RedirectOp::Input => "<",
        RedirectOp::Output => ">",
        RedirectOp::Append => ">>",
        RedirectOp::InputDup => "<&",
        RedirectOp::OutputDup => ">&",
        RedirectOp::InputOutput => "<>",
        RedirectOp::Clobber => ">|",
        RedirectOp::AndOutput => "&>",
        RedirectOp::AndAppend => "&>>",
        RedirectOp::Heredoc => "<<",
        RedirectOp::HeredocStrip => "<<-",
        RedirectOp::HereString => "<<<",
    };
    // For heredocs, r.target is the *body*; the word after `<<` is the
    // delimiter.  Emit only "<<DELIM" here — the body and terminating
    // delimiter are appended at a higher level (see
    // serialize_redirects_with_heredocs) so other redirects on the
    // same command stay on the same line as `<<DELIM`.
    if matches!(r.op, RedirectOp::Heredoc | RedirectOp::HeredocStrip) {
        let delim = r.heredoc_delimiter.as_deref().unwrap_or("EOF");
        return format!("{}{}{}", fd, op, delim);
    }
    format!("{}{}{}", fd, op, deparse_procsub_markers(&r.target))
}

/// Append heredoc bodies + terminating delimiters to the already-
/// rendered command text.  The output format matches bash's
/// `declare -f`:
///   cmd <<DELIM > otherfile
///   body
///   DELIM
/// even when the heredoc is not the last redirect on the line.
fn append_heredoc_bodies(rendered: &mut String, redirects: &[Redirect]) {
    for r in redirects {
        if matches!(r.op, RedirectOp::Heredoc | RedirectOp::HeredocStrip) {
            let delim = r.heredoc_delimiter.as_deref().unwrap_or("EOF");
            let body = if r.target.ends_with('\n') {
                r.target.clone()
            } else {
                format!("{}\n", r.target)
            };
            rendered.push('\n');
            rendered.push_str(&body);
            rendered.push_str(delim);
            rendered.push('\n');
        }
    }
}

/// Quote a value for xtrace output (command word display).
/// Matches bash's xtrace quoting:
/// - Non-printable chars (tab, newline, etc.) → $'\t', $'\n', etc. (ANSI-C style)
/// - Special shell chars (|, &, ;, etc.) → single-quoted
/// - Strings containing single quotes → escaped form
fn shell_quote_xtrace(s: &str) -> String {
    if s.is_empty() {
        return "''".to_string();
    }

    let bytes = crate::expand::decode_raw_bytes(s);
    let needs_ansi_c = bytes.iter().any(|&b| b < 0x20 || b == 0x7f || b >= 0x80);
    if needs_ansi_c {
        let mut inner = String::new();
        for b in bytes {
            match b {
                0x07 => inner.push_str("\\a"),
                0x08 => inner.push_str("\\b"),
                b'\t' => inner.push_str("\\t"),
                b'\n' => inner.push_str("\\n"),
                0x0b => inner.push_str("\\v"),
                0x0c => inner.push_str("\\f"),
                b'\r' => inner.push_str("\\r"),
                0x1b => inner.push_str("\\e"),
                b'\\' => inner.push_str("\\\\"),
                b'\'' => inner.push_str("\\'"),
                b if b < 0x20 || b == 0x7f || b >= 0x80 => {
                    inner.push_str(&format!("\\{:03o}", b));
                }
                b => inner.push(b as char),
            }
        }
        return format!("$'{}'", inner);
    }

    // Check if the string needs quoting
    let needs_quote = s.chars().any(|c| matches!(c, ' ' | '\'' | '"' | '\\' |
        '|' | '&' | ';' | '(' | ')' | '<' | '>' | '`' | '$' | '!' | '{' | '}' | '[' | ']' | '*' | '?'));
    if !needs_quote {
        return s.to_string();
    }
    // Use single quotes, escaping single quotes with '\''
    format!("'{}'", s.replace('\'', "'\\''"))
}

pub(crate) fn format_raw_diagnostic_word(s: &str) -> String {
    let bytes = crate::expand::decode_raw_bytes(s);
    if bytes.iter().any(|&b| b < 0x20 || b == 0x7f || b >= 0x80) {
        let mut out = String::from("$'");
        for b in bytes {
            match b {
                0x07 => out.push_str("\\a"),
                0x08 => out.push_str("\\b"),
                b'\t' => out.push_str("\\t"),
                b'\n' => out.push_str("\\n"),
                0x0b => out.push_str("\\v"),
                0x0c => out.push_str("\\f"),
                b'\r' => out.push_str("\\r"),
                0x1b => out.push_str("\\e"),
                b'\\' => out.push_str("\\\\"),
                b'\'' => out.push_str("\\'"),
                b if b < 0x20 || b == 0x7f || b >= 0x80 => out.push_str(&format!("\\{:03o}", b)),
                b => out.push(b as char),
            }
        }
        out.push('\'');
        out
    } else {
        s.to_string()
    }
}

/// Convert a raw array element token (as stored from lexer) to bash xtrace display format.
/// This handles ANSI-C quoting ($'...') by expanding escape sequences and re-quoting.
fn format_array_element_for_xtrace(token: &str) -> String {
    // Check if it's ANSI-C quoting: $'...'
    if token.starts_with("$'") && token.ends_with('\'') && token.len() >= 3 {
        // Expand the ANSI-C escape sequences inside $'...'
        let inner = &token[2..token.len()-1];
        let expanded = expand_ansi_c_inner(inner);
        // Re-quote as single-quoted string with literal chars
        // (This may include literal tabs/newlines which bash displays as-is)
        format!("'{}'", expanded)
    } else {
        // Return as-is (backslash-escaped tokens, normal words)
        token.to_string()
    }
}

/// Expand ANSI-C escape sequences in the inner content of $'...' (without the surrounding quotes).
/// Returns the expanded string with literal characters.
pub fn expand_ansi_c_inner(s: &str) -> String {
    let mut result = String::new();
    let chars: Vec<char> = s.chars().collect();
    let mut i = 0;
    while i < chars.len() {
        if chars[i] == '\\' && i + 1 < chars.len() {
            i += 1;
            match chars[i] {
                'a' => { result.push('\x07'); i += 1; }
                'b' => { result.push('\x08'); i += 1; }
                'e' | 'E' => { result.push('\x1B'); i += 1; }
                'f' => { result.push('\x0C'); i += 1; }
                'n' => { result.push('\n'); i += 1; }
                'r' => { result.push('\r'); i += 1; }
                't' => { result.push('\t'); i += 1; }
                'v' => { result.push('\x0B'); i += 1; }
                '\\' => { result.push('\\'); i += 1; }
                '\'' => { result.push('\''); i += 1; }
                '"' => { result.push('"'); i += 1; }
                '?' => { result.push('?'); i += 1; }
                'x' => {
                    // Hex escape \xHH
                    i += 1;
                    let mut hex = String::new();
                    while i < chars.len() && chars[i].is_ascii_hexdigit() && hex.len() < 2 {
                        hex.push(chars[i]);
                        i += 1;
                    }
                    if let Ok(n) = u8::from_str_radix(&hex, 16) {
                        result.push(n as char);
                    }
                }
                c @ '0'..='7' => {
                    // Octal escape
                    let mut oct = String::from(c);
                    i += 1;
                    while i < chars.len() && matches!(chars[i], '0'..='7') && oct.len() < 3 {
                        oct.push(chars[i]);
                        i += 1;
                    }
                    if let Ok(n) = u8::from_str_radix(&oct, 8) {
                        result.push(n as char);
                    }
                }
                c => { result.push('\\'); result.push(c); i += 1; }
            }
        } else {
            result.push(chars[i]);
            i += 1;
        }
    }
    result
}
