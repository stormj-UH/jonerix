/// Bash arithmetic expression evaluator.
///
/// Evaluates expressions as used in $(( )), (( )), `let`, and `declare -i`.
/// All values are 64-bit signed integers, matching bash behaviour on 64-bit
/// platforms.
///
/// Operator precedence (low → high) follows C / bash:
///  1. comma            ,
///  2. assignment       = += -= *= /= %= **= &= |= ^= <<= >>=
///  3. ternary          ? :
///  4. logical-or       ||
///  5. logical-and      &&
///  6. bitwise-or       |
///  7. bitwise-xor      ^
///  8. bitwise-and      &
///  9. equality         == !=
/// 10. relational       < > <= >=
/// 11. shift            << >>
/// 12. additive         + -
/// 13. multiplicative   * / %
/// 14. exponentiation   ** (right-associative)
/// 15. unary            ! ~ + - ++ -- (prefix)
/// 16. postfix          ++ --  (highest)
/// 17. primary          literals, names, ( expr )

use crate::vars::Variables;
use std::borrow::Cow;
use std::cell::RefCell;

// ---------------------------------------------------------------------------
// Public entry point
// ---------------------------------------------------------------------------

/// Maximum recursion depth for variable expression evaluation.
/// Bash uses a limit around 1024; we use the same.
const EXPR_RECURSION_LIMIT: usize = 1024;

thread_local! {
    /// Tracks the current arithmetic expression recursion depth.
    /// Incremented when we recursively evaluate a variable's value as an
    /// arithmetic expression; decremented when done.
    static ARITH_DEPTH: std::cell::Cell<usize> = std::cell::Cell::new(0);
    static ARITH_ALLOW_CMDSUB: std::cell::Cell<bool> = std::cell::Cell::new(true);
    static ARITH_ALLOW_SIDE_EFFECTS: std::cell::Cell<bool> = std::cell::Cell::new(true);
    static ARITH_STRICT_EMPTY_SUBSCRIPT: std::cell::Cell<bool> = std::cell::Cell::new(true);
    static ARITH_ASSOC_EXPAND_ONCE: std::cell::Cell<bool> = std::cell::Cell::new(false);
}

/// A pre-lexed arithmetic expression — lex once, evaluate many times.
///
/// When an expression is known to be stable (no `$`/backtick/`[` that could
/// change its textual form between evaluations), caller can lex it once and
/// call `eval_expr_mut_from_lexed` on each use.  The token Vec is cloned per
/// evaluation, which is cheaper than re-running the Lexer.
pub struct LexedExpr {
    tokens: Vec<Token>,
    lex_error: Option<String>,
}

impl LexedExpr {
    /// Lex `expr` into a reusable token list.  `expr` should already be
    /// the expanded (post-`expand_arith_vars`) form.
    pub fn lex(expr: &str) -> Self {
        let mut lexer = Lexer::new(expr);
        let mut tokens = Vec::new();
        let mut lex_error: Option<String> = None;
        loop {
            match lexer.next_token() {
                Ok(Token::Eof) => { tokens.push(Token::Eof); break; }
                Ok(t) => tokens.push(t),
                Err(e) => {
                    tokens.push(Token::Eof);
                    lex_error = Some(e);
                    break;
                }
            }
        }
        LexedExpr { tokens, lex_error }
    }
}

/// Evaluate a pre-lexed arithmetic expression with assignment write-back.
/// Equivalent to `eval_expr_mut(expr, vars)` but re-uses existing tokens
/// by borrowing them (zero extra allocation).
pub fn eval_expr_mut_from_lexed<'t>(
    lexed: &'t LexedExpr,
    orig_expr: &str,
    vars: &mut Variables,
) -> Result<i64, String> {
    let trimmed = orig_expr.trim();
    if trimmed.is_empty() {
        return Ok(0);
    }
    let sink: &mut dyn VarSink = &mut MutSink {
        vars,
        last_resolved: RefCell::new(None),
    };
    // Borrow the pre-lexed tokens — no clone, no Vec alloc.
    let lex_error = lexed.lex_error.clone(); // Option<String>: only allocates on error
    let mut parser = Parser {
        tokens: std::borrow::Cow::Borrowed(lexed.tokens.as_slice()),
        pos: 0,
        vars: sink,
        dry_run_depth: 0,
        lex_error,
        orig_expr,
        _phantom: std::marker::PhantomData,
    };
    parser.parse_top()
}

/// Evaluate a bash arithmetic expression and return the result.
///
/// Variable reads and writes are performed through `vars`.  Passing `vars` as
/// a shared reference means write-back of assignments is handled via an
/// internal `VarSink` trait; callers that need assignments to be reflected back
/// should use `eval_expr_mut`.
pub fn eval_expr(expr: &str, vars: &Variables) -> Result<i64, String> {
    // Empty or whitespace-only expressions evaluate to 0 (bash behaviour).
    let trimmed = expr.trim();
    if trimmed.is_empty() {
        return Ok(0);
    }
    let cooked = preprocess_arith_quotes(expr, vars);
    // Cow::Borrowed means no change — skip the recursive re-evaluation.
    let effective: &str = &cooked;
    if effective != expr {
        return eval_expr(effective, vars);
    }
    // We need mutable access to write variables during assignment operations.
    // Because the public signature only provides `&Variables` we evaluate in
    // read-only mode: assignment operators still compute the new value and
    // return it, but the write-back is silently dropped.  For full assignment
    // support use `eval_expr_mut`.
    let sink: &mut dyn VarSink = &mut ReadOnlySink { vars };
    let mut parser = Parser::new(expr, sink);
    parser.parse_top()
}

/// Like `eval_expr` but also writes assignments back into `vars`.
pub fn eval_expr_mut(expr: &str, vars: &mut Variables) -> Result<i64, String> {
    // Empty or whitespace-only expressions evaluate to 0 (bash behaviour).
    let trimmed = expr.trim();
    if trimmed.is_empty() {
        return Ok(0);
    }
    let cooked = preprocess_arith_quotes(expr, vars);
    let effective: &str = &cooked;
    if effective != expr {
        return eval_expr_mut(effective, vars);
    }
    let sink: &mut dyn VarSink = &mut MutSink {
        vars,
        last_resolved: RefCell::new(None),
    };
    let mut parser = Parser::new(expr, sink);
    parser.parse_top()
}

pub fn eval_expr_mut_no_cmdsub(expr: &str, vars: &mut Variables) -> Result<i64, String> {
    eval_expr_mut_no_cmdsub_mode(expr, vars, false)
}

pub fn eval_expr_mut_no_cmdsub_assoc_once(expr: &str, vars: &mut Variables) -> Result<i64, String> {
    eval_expr_mut_no_cmdsub_mode(expr, vars, true)
}

fn eval_expr_mut_no_cmdsub_mode(
    expr: &str,
    vars: &mut Variables,
    assoc_expand_once: bool,
) -> Result<i64, String> {
    let trimmed = expr.trim();
    if trimmed.is_empty() {
        return Ok(0);
    }
    let cooked = preprocess_arith_quotes(expr, vars);
    let effective: &str = &cooked;
    if effective != expr {
        return eval_expr_mut_no_cmdsub_mode(effective, vars, assoc_expand_once);
    }
    ARITH_ALLOW_CMDSUB.with(|flag| {
        let old = flag.replace(false);
        let strict_old = ARITH_STRICT_EMPTY_SUBSCRIPT.with(|strict| strict.replace(false));
        let assoc_old = ARITH_ASSOC_EXPAND_ONCE.with(|assoc| assoc.replace(assoc_expand_once));
        let sink: &mut dyn VarSink = &mut MutSink {
            vars,
            last_resolved: RefCell::new(None),
        };
        let mut parser = Parser::new(expr, sink);
        let result = parser.parse_top();
        ARITH_ASSOC_EXPAND_ONCE.with(|assoc| assoc.set(assoc_old));
        ARITH_STRICT_EMPTY_SUBSCRIPT.with(|strict| strict.set(strict_old));
        flag.set(old);
        result
    })
}

pub fn preprocess_arith_diagnostic_expr(expr: &str, vars: &Variables) -> String {
    preprocess_arith_quotes(expr, vars).into_owned()
}

fn preprocess_arith_quotes<'e>(expr: &'e str, vars: &Variables) -> Cow<'e, str> {
    // Fast path: no `'` or `"` anywhere → preprocessing is a no-op.
    // This dominates real-world arithmetic (`$((i+1))`, `$((arr[i]))`,
    // etc.) and the per-char scan in the inner functions is hot when
    // arithmetic is in a tight loop.
    if !expr.contains('\'') && !expr.contains('"') {
        return Cow::Borrowed(expr);
    }
    let single = preprocess_arith_single_quotes(expr, vars);
    Cow::Owned(preprocess_arith_double_quotes(&single))
}

fn expand_single_quoted_arith_fragment(fragment: &str, vars: &Variables) -> String {
    let chars: Vec<char> = fragment.chars().collect();
    let mut out = String::new();
    let mut i = 0usize;
    while i < chars.len() {
        if chars[i] != '$' {
            out.push(chars[i]);
            i += 1;
            continue;
        }
        if i + 1 >= chars.len() {
            out.push('$');
            i += 1;
            continue;
        }
        let next = chars[i + 1];
        if next == '{' {
            let start = i + 2;
            let mut j = start;
            while j < chars.len()
                && (chars[j].is_ascii_alphanumeric() || chars[j] == '_')
            {
                j += 1;
            }
            if j < chars.len() && chars[j] == '}' && j > start {
                let name: String = chars[start..j].iter().collect();
                out.push_str(&vars.get(&name).unwrap_or_default());
                i = j + 1;
                continue;
            }
        } else if next.is_ascii_alphabetic() || next == '_' {
            let start = i + 1;
            let mut j = start;
            while j < chars.len()
                && (chars[j].is_ascii_alphanumeric() || chars[j] == '_')
            {
                j += 1;
            }
            let name: String = chars[start..j].iter().collect();
            out.push_str(&vars.get(&name).unwrap_or_default());
            i = j;
            continue;
        } else if next.is_ascii_digit() {
            out.push_str(&vars.get(&next.to_string()).unwrap_or_default());
            i += 2;
            continue;
        } else {
            let value = match next {
                '#' => vars.positional_count().to_string(),
                '?' => vars.get("?").unwrap_or_else(|| "0".to_string()),
                '$' => vars.get("$").unwrap_or_else(|| "0".to_string()),
                '!' => vars.get("!").unwrap_or_default(),
                '@' | '*' => vars.all_positional(vars.positional_count()).join(" "),
                '-' => vars.get("-").unwrap_or_default(),
                '_' => vars.get("_").unwrap_or_default(),
                _ => String::new(),
            };
            if !value.is_empty() || matches!(next, '#' | '?' | '$' | '!' | '@' | '*' | '-' | '_')
            {
                out.push_str(&value);
                i += 2;
                continue;
            }
        }
        out.push('$');
        i += 1;
    }
    out
}

fn preprocess_arith_single_quotes(expr: &str, vars: &Variables) -> String {
    let chars: Vec<char> = expr.chars().collect();
    let mut out = String::new();
    let mut i = 0usize;
    let mut changed = false;
    let mut square_depth = 0i32;
    while i < chars.len() {
        if chars[i] == '[' {
            square_depth += 1;
            out.push(chars[i]);
            i += 1;
            continue;
        }
        if chars[i] == ']' && square_depth > 0 {
            square_depth -= 1;
            out.push(chars[i]);
            i += 1;
            continue;
        }
        if chars[i] == '\\' {
            out.push(chars[i]);
            if i + 1 < chars.len() {
                out.push(chars[i + 1]);
                i += 2;
            } else {
                i += 1;
            }
            continue;
        }
        if chars[i] == '\'' && square_depth == 0 {
            let start = i + 1;
            let mut end = start;
            while end < chars.len() && chars[end] != '\'' {
                end += 1;
            }
            if end < chars.len() {
                changed = true;
                out.push('\'');
                let inner: String = chars[start..end].iter().collect();
                out.push_str(&expand_single_quoted_arith_fragment(&inner, vars));
                out.push('\'');
                i = end + 1;
                continue;
            }
        }
        out.push(chars[i]);
        i += 1;
    }
    if changed { out } else { expr.to_string() }
}

fn preprocess_arith_double_quotes(expr: &str) -> String {
    let chars: Vec<char> = expr.chars().collect();
    let mut out = String::new();
    let mut i = 0usize;
    let mut changed = false;
    let mut square_depth = 0i32;
    while i < chars.len() {
        if chars[i] == '[' {
            square_depth += 1;
            out.push(chars[i]);
            i += 1;
            continue;
        }
        if chars[i] == ']' && square_depth > 0 {
            square_depth -= 1;
            out.push(chars[i]);
            i += 1;
            continue;
        }
        if chars[i] == '\\' {
            out.push(chars[i]);
            if i + 1 < chars.len() {
                out.push(chars[i + 1]);
                i += 2;
            } else {
                i += 1;
            }
            continue;
        }
        if chars[i] == '"' && square_depth == 0 {
            changed = true;
            i += 1;
            while i < chars.len() {
                if chars[i] == '\\' && i + 1 < chars.len() {
                    out.push(chars[i + 1]);
                    i += 2;
                    continue;
                }
                if chars[i] == '"' {
                    i += 1;
                    break;
                }
                out.push(chars[i]);
                i += 1;
            }
            continue;
        }
        out.push(chars[i]);
        i += 1;
    }
    if changed { out } else { expr.to_string() }
}

fn eval_expr_raw(expr: &str, vars: &Variables) -> Result<i64, String> {
    let trimmed = expr.trim();
    if trimmed.is_empty() {
        return Ok(0);
    }
    let sink: &mut dyn VarSink = &mut ReadOnlySink { vars };
    let mut parser = Parser::new(expr, sink);
    parser.parse_top()
}

fn eval_array_subscript_expr(expr: &str, vars: &Variables) -> Result<i64, String> {
    let assoc_once = ARITH_ASSOC_EXPAND_ONCE.with(|flag| flag.get());
    let strict_empty = ARITH_STRICT_EMPTY_SUBSCRIPT.with(|flag| flag.get());
    if assoc_once && !strict_empty && (expr.contains('"') || expr.contains('\'')) {
        eval_expr_raw(expr, vars)
    } else {
        eval_expr(expr, vars)
    }
}

fn strip_outer_quotes(expr: &str) -> String {
    if expr.len() >= 2 {
        let bytes = expr.as_bytes();
        if (bytes[0] == b'"' && bytes[expr.len() - 1] == b'"')
            || (bytes[0] == b'\'' && bytes[expr.len() - 1] == b'\'')
        {
            return expr[1..expr.len() - 1].to_string();
        }
    }
    expr.to_string()
}

fn normalize_assoc_literal_operand(sub: &str) -> String {
    strip_outer_quotes(&normalize_escaped_arith_quotes(sub))
}

fn has_balanced_outer_single_quotes(sub: &str) -> bool {
    let trimmed = sub.trim();
    trimmed.len() >= 2 && trimmed.starts_with('\'') && trimmed.ends_with('\'')
}

fn wrap_assoc_bad_subscript(arr: &str, sub: &str) -> String {
    let prefix = sub
        .char_indices()
        .find_map(|(idx, ch)| ch.is_whitespace().then_some(sub[..idx].to_string()))
        .unwrap_or_else(|| sub.to_string());
    let token = prefix
        .rsplit_once(',')
        .map(|(_, tail)| tail)
        .unwrap_or(prefix.as_str())
        .to_string();
    wrap_inner_arith(
        &format!("{}[{}", arr, prefix),
        format!("bad array subscript (error token is \"{}\")", token),
    )
}

fn assoc_key_for_eval_checked(arr: &str, sub: &str, vars: &mut Variables) -> Result<String, String> {
    let literal = ARITH_ALLOW_CMDSUB.with(|flag| !flag.get());
    let assoc_expand_once = ARITH_ASSOC_EXPAND_ONCE.with(|flag| flag.get());
    if literal && assoc_expand_once && sub.contains("$(") && sub.contains(']') {
        return Err(wrap_assoc_bad_subscript(arr, sub));
    }
    Ok(assoc_key_for_eval(sub, vars))
}

fn malformed_assoc_subscript_error(name: &str, vars: &Variables) -> Option<String> {
    let literal = ARITH_ALLOW_CMDSUB.with(|flag| !flag.get());
    let assoc_expand_once = ARITH_ASSOC_EXPAND_ONCE.with(|flag| flag.get());
    if !(literal && assoc_expand_once) || name.ends_with(']') {
        return None;
    }
    let br = name.find('[')?;
    let arr = &name[..br];
    if arr.is_empty() || !vars.is_assoc(arr) {
        return None;
    }
    let sub = &name[br + 1..];
    if sub.contains("$(") && sub.contains(']') {
        Some(wrap_assoc_bad_subscript(arr, sub))
    } else {
        None
    }
}

fn assoc_key_from_expanded(expr: &str) -> String {
    normalize_assoc_literal_operand(expr)
}

fn assoc_key_for_eval(sub: &str, vars: &mut Variables) -> String {
    let literal = ARITH_ALLOW_CMDSUB.with(|flag| !flag.get());
    let assoc_expand_once = ARITH_ASSOC_EXPAND_ONCE.with(|flag| flag.get());
    if literal && assoc_expand_once {
        // With assoc_expand_once, the subscript is treated verbatim:
        // unescape `\"` → `"` and `\\` → `\` but DO NOT strip outer quotes.
        // bash 5.3 keeps `a[" "]` as the 3-char key `" "` rather than
        // stripping to a single space.
        return normalize_escaped_arith_quotes(sub);
    }
    if literal || has_balanced_outer_single_quotes(sub) {
        normalize_assoc_literal_operand(sub)
    } else {
        let expanded = expand_arith_for_eval(sub, vars);
        assoc_key_from_expanded(&expanded)
    }
}

fn normalize_escaped_arith_quotes(expr: &str) -> String {
    let chars: Vec<char> = expr.chars().collect();
    let mut out = String::new();
    let mut i = 0usize;
    while i < chars.len() {
        if chars[i] == '\\' && i + 1 < chars.len() {
            match chars[i + 1] {
                '"' | '\'' | '\\' => {
                    out.push(chars[i + 1]);
                    i += 2;
                    continue;
                }
                _ => {}
            }
        }
        out.push(chars[i]);
        i += 1;
    }
    out
}

/// Evaluate a variable's string value as an arithmetic sub-expression,
/// with recursion depth tracking to detect circular references.
/// `var_name` is used only in error messages.
fn eval_var_value(value: &str, vars: &Variables, _var_name: &str) -> Result<i64, String> {
    let trimmed = value.trim();
    // Fast path: plain integer.
    if let Ok(n) = trimmed.parse::<i64>() {
        return Ok(n);
    }
    // Empty value → 0.
    if trimmed.is_empty() {
        return Ok(0);
    }
    // Recursively evaluate as arithmetic expression.
    let depth = ARITH_DEPTH.with(|d| d.get());
    if depth >= EXPR_RECURSION_LIMIT {
        // Bash names the VALUE being expanded (the expression that caused
        // the recursion to bottom out), not the outer variable name.
        let tok = trimmed;
        return Err(format!(
            "{}: expression recursion level exceeded (error token is \"{}\")",
            tok, tok
        ));
    }
    ARITH_DEPTH.with(|d| d.set(depth + 1));
    let mut vars_shadow = vars.clone();
    let expanded = expand_arith_for_eval(trimmed, &mut vars_shadow);
    let result = eval_expr(&expanded, vars);
    ARITH_DEPTH.with(|d| d.set(depth));
    // When the inner expression fails, wrap the error to include the inner
    // expression as context.  The outer caller (exec.rs format_arith_err)
    // will see \x00INNER\x00<inner_expr>\x1F<msg>\x00 and use the inner
    // expression for display instead of the outer one.
    match result {
        Ok(v) => Ok(v),
        Err(e) => {
            // If the error already contains inner-expr wrapping, pass through.
            if e.contains("\x00INNER\x00") {
                return Err(e);
            }
            // Use value.trim_start() for display (preserves trailing space
            // so errors like "4 + " show the trailing space in the token).
            Err(format!("\x00INNER\x00{}\x1F{}\x00", value.trim_start(), e))
        }
    }
}

fn eval_var_value_mut(value: &str, vars: &mut Variables, _var_name: &str) -> Result<i64, String> {
    let trimmed = value.trim();
    if let Ok(n) = trimmed.parse::<i64>() {
        return Ok(n);
    }
    if trimmed.is_empty() {
        return Ok(0);
    }
    let depth = ARITH_DEPTH.with(|d| d.get());
    if depth >= EXPR_RECURSION_LIMIT {
        let tok = trimmed;
        return Err(format!(
            "{}: expression recursion level exceeded (error token is \"{}\")",
            tok, tok
        ));
    }
    ARITH_DEPTH.with(|d| d.set(depth + 1));
    let expanded = expand_arith_for_eval(trimmed, vars);
    let result = eval_expr_mut(&expanded, vars);
    ARITH_DEPTH.with(|d| d.set(depth));
    match result {
        Ok(v) => Ok(v),
        Err(e) => {
            if e.contains("\x00INNER\x00") {
                return Err(e);
            }
            Err(format!("\x00INNER\x00{}\x1F{}\x00", value.trim_start(), e))
        }
    }
}

fn wrap_inner_arith(expr: &str, err: String) -> String {
    if err.contains("\x00INNER\x00") {
        err
    } else {
        format!("\x00INNER\x00{}\x1F{}\x00", expr.trim_start(), err)
    }
}

fn expand_arith_for_eval(expr: &str, vars: &mut Variables) -> String {
    ARITH_ALLOW_CMDSUB.with(|flag| {
        if flag.get() {
            crate::expand::expand_arith_vars(expr, vars)
        } else {
            crate::expand::expand_arith_vars_no_cmdsub(expr, vars)
        }
    })
}

// ---------------------------------------------------------------------------
// VarSink trait – abstracts read/write over Variables
// ---------------------------------------------------------------------------

trait VarSink {
    /// Look up a variable and return its arithmetic value.
    /// Returns Err for recursion limit exceeded, nounset errors, or
    /// invalid arithmetic sub-expressions embedded in variable values.
    fn get(&mut self, name: &str) -> Result<i64, String>;
    fn set(&mut self, name: &str, value: i64) -> Result<(), String>;
}

#[derive(Clone)]
enum ResolvedSubscript {
    Indexed(String, usize),
    Assoc(String, String),
}

struct ReadOnlySink<'a> {
    vars: &'a Variables,
}

impl<'a> VarSink for ReadOnlySink<'a> {
    fn get(&mut self, name: &str) -> Result<i64, String> {
        // Nounset check: if set -u is active, unset variables are an error.
        if self.vars.nounset {
            let is_subscripted = name.contains('[');
            let plain = if is_subscripted { &name[..name.find('[').unwrap()] } else { name };
            if !self.vars.is_set(plain) {
                return Err(format!("{}: unbound variable", plain));
            }
        }
        // Fast path: plain scalar variable (no subscript, no nameref, not RANDOM).
        // Inline the integer-parse hot path to avoid any String allocation.
        if !name.contains('[') && name != "RANDOM" {
            if let Some(s) = self.vars.get_scalar_str(name) {
                let trimmed = s.trim();
                if let Ok(n) = trimmed.parse::<i64>() {
                    return Ok(n);
                }
                if trimmed.is_empty() {
                    return Ok(0);
                }
                return eval_var_value(s, self.vars, name);
            }
        }
        let val = lookup_subscripted(self.vars, name)?.unwrap_or_default();
        eval_var_value(&val, self.vars, name)
    }
    fn set(&mut self, name: &str, _value: i64) -> Result<(), String> {
        // Check for readonly even though we can't write — the caller needs to
        // know that the assignment would have been rejected.
        if self.vars.is_readonly(name) {
            return Err(format!("{}: readonly variable", name));
        }
        // Non-readonly writes are silently discarded (read-only evaluation mode).
        Ok(())
    }
}

struct MutSink<'a> {
    vars: &'a mut Variables,
    last_resolved: RefCell<Option<(String, ResolvedSubscript)>>,
}

impl<'a> VarSink for MutSink<'a> {
    fn get(&mut self, name: &str) -> Result<i64, String> {
        // Nounset check: if set -u is active, unset variables are an error.
        if self.vars.nounset {
            let is_subscripted = name.contains('[');
            let plain = if is_subscripted { &name[..name.find('[').unwrap()] } else { name };
            if !self.vars.is_set(plain) {
                return Err(format!("{}: unbound variable", plain));
            }
        }

        // Fast path for the overwhelmingly common case: plain scalar variable
        // with no subscript, no nameref, and not RANDOM.  Bypasses the
        // resolve_subscripted_target + lookup_subscripted round-trip (which
        // allocates an Option<String>) by borrowing the stored &str directly.
        // If the stored value is a plain integer (the common case in arith loops),
        // parse it directly without cloning the String or calling eval_var_value.
        let allow_side_effects = ARITH_ALLOW_SIDE_EFFECTS.with(|flag| flag.get());
        if !name.contains('[') && name != "RANDOM" {
            if let Some(s) = self.vars.get_scalar_str(name) {
                let trimmed = s.trim();
                // Hot path: value is a plain integer — parse without any alloc.
                if let Ok(n) = trimmed.parse::<i64>() {
                    return Ok(n);
                }
                // Value is empty → 0.
                if trimmed.is_empty() {
                    return Ok(0);
                }
                // Slow path: value is an arithmetic expression (nameref-resolved
                // value or integer-type variable) — copy and recurse.
                let owned = s.to_owned();
                return if allow_side_effects {
                    eval_var_value_mut(&owned, self.vars, name)
                } else {
                    eval_var_value(&owned, self.vars, name)
                };
            }
        }

        let val = if let Some(target) = resolve_subscripted_target(self.vars, name)? {
            *self.last_resolved.borrow_mut() = Some((name.to_string(), target.clone()));
            lookup_resolved(self.vars, &target).unwrap_or_default()
        } else {
            lookup_subscripted(self.vars, name)?.unwrap_or_default()
        };
        if allow_side_effects {
            eval_var_value_mut(&val, self.vars, name)
        } else {
            eval_var_value(&val, self.vars, name)
        }
    }
    fn set(&mut self, name: &str, value: i64) -> Result<(), String> {
        if self.vars.is_readonly(name) {
            return Err(format!("{}: readonly variable", name));
        }

        // Fast path for plain scalar variable (no subscript, not in last_resolved cache).
        // Avoids the heavy nameref/integer/case-transform machinery in vars.set() for
        // the overwhelmingly common `i++`, `n=expr` case.
        if !name.contains('[') && self.last_resolved.borrow().is_none() {
            if self.vars.try_set_scalar_fast(name, &value.to_string()) {
                return Ok(());
            }
        }

        let cached = {
            let mut slot = self.last_resolved.borrow_mut();
            if slot.as_ref().map(|(raw, _)| raw.as_str()) == Some(name) {
                slot.take().map(|(_, target)| target)
            } else {
                None
            }
        };
        let resolved = match cached {
            Some(target) => Some(target),
            None => resolve_subscripted_target(self.vars, name)?,
        };
        if let Some(target) = resolved {
            match target {
                ResolvedSubscript::Indexed(arr, idx) => {
                    self.vars.set_array_element(&arr, idx, &value.to_string());
                    return Ok(());
                }
                ResolvedSubscript::Assoc(arr, key) => {
                    self.vars.set_assoc(&arr, &key, &value.to_string());
                    return Ok(());
                }
            }
        }
        // Subscripted assign: `a[3] = 7` → set_array_element / set_assoc.
        if let Some(br) = name.find('[') {
            if name.ends_with(']') {
                let arr = &name[..br];
                let sub = &name[br + 1..name.len() - 1];
                if !arr.is_empty() {
                    if self.vars.is_assoc(arr) {
                        let key = assoc_key_for_eval_checked(arr, sub, self.vars)?;
                        self.vars.set_assoc(arr, &key, &value.to_string());
                        return Ok(());
                    }
                    // Indexed array: evaluate subscript arithmetically.
                    let sub_expanded = expand_arith_for_eval(sub, self.vars);
                    if sub_expanded.is_empty() {
                        return Err(format!("{}[]: bad array subscript", arr));
                    }
                    let idx = match eval_array_subscript_expr(&sub_expanded, self.vars) {
                        Ok(n) => n,
                        Err(err) => return Err(wrap_inner_arith(&sub_expanded, err)),
                    };
                    let u = if idx < 0 {
                        match self.vars.array_max_index(arr) {
                            Some(max_idx) => {
                                let real = (max_idx + 1) as i64 + idx;
                                if real < 0 {
                                    return Err(format!("{}: bad array subscript", arr));
                                }
                                real as usize
                            }
                            None => return Err(format!("{}: bad array subscript", arr)),
                        }
                    } else {
                        idx as usize
                    };
                    self.vars.set_array_element(arr, u, &value.to_string());
                    return Ok(());
                }
            }
        }
        self.vars.set(name, &value.to_string());
        Ok(())
    }
}

/// Look up a possibly-subscripted variable name (`a`, `a[3]`, `a[i+1]`,
/// `assoc[key]`) and return the string value, or None if the name
/// doesn't resolve.
fn lookup_subscripted(vars: &Variables, name: &str) -> Result<Option<String>, String> {
    if let Some(err) = malformed_assoc_subscript_error(name, vars) {
        return Err(err);
    }
    if let Some(br) = name.find('[') {
        if name.ends_with(']') {
            let arr = &name[..br];
            let sub = &name[br + 1..name.len() - 1];
            if !arr.is_empty() {
                if vars.is_assoc(arr) {
                    let mut vars_shadow = vars.clone();
                    let key = assoc_key_for_eval_checked(arr, sub, &mut vars_shadow)?;
                    return Ok(vars.get_assoc(arr, &key));
                }
                // Indexed array with arithmetic subscript.
                if ARITH_STRICT_EMPTY_SUBSCRIPT.with(|flag| flag.get())
                    && matches!(sub, "\"\"" | "''")
                {
                    return Err(format!("`{}[]': not a valid identifier", arr));
                }
                let mut vars_shadow = vars.clone();
                let normalized_sub = normalize_escaped_arith_quotes(sub);
                let sub_expanded = expand_arith_for_eval(&normalized_sub, &mut vars_shadow);
                if sub_expanded.is_empty() {
                    return Err(format!("{}[]: bad array subscript", arr));
                }
                let idx = match eval_array_subscript_expr(&sub_expanded, vars) {
                    Ok(n) => n,
                    Err(err) => return Err(wrap_inner_arith(&sub_expanded, err)),
                };
                let u = if idx < 0 {
                    match vars.array_max_index(arr) {
                        Some(max_idx) => {
                            let real = (max_idx + 1) as i64 + idx;
                            if real < 0 {
                                return Err(format!("{}: bad array subscript", arr));
                            }
                            real as usize
                        }
                        None => return Err(format!("{}: bad array subscript", arr)),
                    }
                } else {
                    idx as usize
                };
                return Ok(vars.get_array_element(arr, u));
            }
        }
    }
    Ok(vars.get(name))
}

fn resolve_subscripted_target(vars: &Variables, name: &str) -> Result<Option<ResolvedSubscript>, String> {
    if let Some(err) = malformed_assoc_subscript_error(name, vars) {
        return Err(err);
    }
    if let Some(br) = name.find('[') {
        if name.ends_with(']') {
            let arr = &name[..br];
            let sub = &name[br + 1..name.len() - 1];
            if !arr.is_empty() {
                if vars.is_assoc(arr) {
                    let mut vars_shadow = vars.clone();
                    let key = assoc_key_for_eval_checked(arr, sub, &mut vars_shadow)?;
                    return Ok(Some(ResolvedSubscript::Assoc(arr.to_string(), key)));
                }
                if ARITH_STRICT_EMPTY_SUBSCRIPT.with(|flag| flag.get())
                    && matches!(sub, "\"\"" | "''")
                {
                    return Err(format!("`{}[]': not a valid identifier", arr));
                }
                let mut vars_shadow = vars.clone();
                let normalized_sub = normalize_escaped_arith_quotes(sub);
                let sub_expanded = expand_arith_for_eval(&normalized_sub, &mut vars_shadow);
                if sub_expanded.is_empty() {
                    return Err(format!("{}[]: bad array subscript", arr));
                }
                let idx = match eval_array_subscript_expr(&sub_expanded, vars) {
                    Ok(n) => n,
                    Err(err) => return Err(wrap_inner_arith(&sub_expanded, err)),
                };
                let u = if idx < 0 {
                    match vars.array_max_index(arr) {
                        Some(max_idx) => {
                            let real = (max_idx + 1) as i64 + idx;
                            if real < 0 {
                                return Err(format!("{}: bad array subscript", arr));
                            }
                            real as usize
                        }
                        None => return Err(format!("{}: bad array subscript", arr)),
                    }
                } else {
                    idx as usize
                };
                return Ok(Some(ResolvedSubscript::Indexed(arr.to_string(), u)));
            }
        }
    }
    Ok(None)
}

fn lookup_resolved(vars: &Variables, target: &ResolvedSubscript) -> Option<String> {
    match target {
        ResolvedSubscript::Indexed(arr, idx) => vars.get_array_element(arr, *idx),
        ResolvedSubscript::Assoc(arr, key) => vars.get_assoc(arr, key),
    }
}

// ---------------------------------------------------------------------------
// Lexer / tokeniser
// ---------------------------------------------------------------------------

#[derive(Debug, Clone, PartialEq)]
enum Token {
    // Literals
    Number(i64),
    MinOverflow(String),
    Ident(String),

    // Two-character operators
    PlusPlus,    // ++
    MinusMinus,  // --
    StarStar,    // **
    LtLt,        // <<
    GtGt,        // >>
    LtEq,        // <=
    GtEq,        // >=
    EqEq,        // ==
    BangEq,      // !=
    AmpAmp,      // &&
    PipePipe,    // ||
    PlusEq,      // +=
    MinusEq,     // -=
    StarEq,      // *=
    SlashEq,     // /=
    PercentEq,   // %=
    AmpEq,       // &=
    PipeEq,      // |=
    CaretEq,     // ^=
    LtLtEq,      // <<=
    GtGtEq,      // >>=
    StarStarEq,  // **=

    // Single-character operators / punctuation
    Plus,
    Minus,
    Star,
    Slash,
    Percent,
    Amp,
    Pipe,
    Caret,
    Bang,
    Tilde,
    Lt,
    Gt,
    Eq,
    Question,
    Colon,
    Comma,
    LParen,
    RParen,

    Eof,
}

struct Lexer<'a> {
    chars: std::iter::Peekable<std::str::Chars<'a>>,
}

impl<'a> Lexer<'a> {
    fn new(s: &'a str) -> Self {
        Lexer {
            chars: s.chars().peekable(),
        }
    }

    fn peek(&mut self) -> Option<char> {
        self.chars.peek().copied()
    }

    fn advance(&mut self) -> Option<char> {
        self.chars.next()
    }

    fn skip_whitespace(&mut self) {
        // Bash treats regular whitespace AND C0 control chars (0x01-0x1F) as
        // transparent separators — they are silently consumed.
        // DEL (0x7F) is NOT skipped here; it generates "invalid arithmetic
        // operator" when encountered (handled in the _ arm of next_token).
        while matches!(self.peek(), Some(c) if c == ' ' || c == '\t' || c == '\n' || c == '\r'
            || (c as u32 >= 0x01 && c as u32 <= 0x1F))
        {
            self.advance();
        }
    }

    /// Read the next token.  Returns `Err` on malformed input.
    fn next_token(&mut self) -> Result<Token, String> {
        self.skip_whitespace();
        let ch = match self.peek() {
            None => return Ok(Token::Eof),
            Some(c) => c,
        };

        // ---- Numbers -------------------------------------------------------
        if ch.is_ascii_digit() {
            return self.read_number();
        }

        // ---- Identifiers ---------------------------------------------------
        if ch.is_ascii_alphabetic() || ch == '_' {
            return Ok(self.read_ident());
        }

        self.advance(); // consume the leading character

        let tok = match ch {
            ']' => {
                let mut tok_str = "]".to_string();
                while let Some(c) = self.peek() {
                    tok_str.push(c);
                    self.advance();
                }
                return Err(format!(
                    "arithmetic syntax error: invalid arithmetic operator (error token is \"{}\")",
                    tok_str
                ));
            }
            // DEL (0x7F) and other non-printable chars that are not C0
            // whitespace generate "invalid arithmetic operator".  The error
            // token starts with the consumed character and includes the rest
            // of the expression (with C0 chars stripped from display).
            c if (c as u32) == 0x7F => {
                let mut tok_str = c.to_string();
                while let Some(next) = self.peek() {
                    // Skip C0 controls (0x01-0x1F) in the collected error token
                    if (next as u32) >= 0x01 && (next as u32) <= 0x1F {
                        self.advance();
                        continue;
                    }
                    tok_str.push(next);
                    self.advance();
                }
                return Err(format!(
                    "arithmetic syntax error: invalid arithmetic operator (error token is \"{}\")",
                    tok_str
                ));
            }
            '(' => Token::LParen,
            ')' => Token::RParen,
            '?' => Token::Question,
            ':' => Token::Colon,
            ',' => Token::Comma,
            '~' => Token::Tilde,
            '+' => match self.peek() {
                Some('+') => { self.advance(); Token::PlusPlus }
                Some('=') => { self.advance(); Token::PlusEq }
                _ => Token::Plus,
            },
            '-' => match self.peek() {
                Some('-') => { self.advance(); Token::MinusMinus }
                Some('=') => { self.advance(); Token::MinusEq }
                _ => Token::Minus,
            },
            '*' => match self.peek() {
                Some('*') => {
                    self.advance();
                    if self.peek() == Some('=') { self.advance(); Token::StarStarEq }
                    else { Token::StarStar }
                }
                Some('=') => { self.advance(); Token::StarEq }
                _ => Token::Star,
            },
            '/' => match self.peek() {
                Some('=') => { self.advance(); Token::SlashEq }
                _ => Token::Slash,
            },
            '%' => match self.peek() {
                Some('=') => { self.advance(); Token::PercentEq }
                _ => Token::Percent,
            },
            '&' => match self.peek() {
                Some('&') => { self.advance(); Token::AmpAmp }
                Some('=') => { self.advance(); Token::AmpEq }
                _ => Token::Amp,
            },
            '|' => match self.peek() {
                Some('|') => { self.advance(); Token::PipePipe }
                Some('=') => { self.advance(); Token::PipeEq }
                _ => Token::Pipe,
            },
            '^' => match self.peek() {
                Some('=') => { self.advance(); Token::CaretEq }
                _ => Token::Caret,
            },
            '!' => match self.peek() {
                Some('=') => { self.advance(); Token::BangEq }
                _ => Token::Bang,
            },
            '<' => match self.peek() {
                Some('<') => {
                    self.advance();
                    if self.peek() == Some('=') { self.advance(); Token::LtLtEq }
                    else { Token::LtLt }
                }
                Some('=') => { self.advance(); Token::LtEq }
                _ => Token::Lt,
            },
            '>' => match self.peek() {
                Some('>') => {
                    self.advance();
                    if self.peek() == Some('=') { self.advance(); Token::GtGtEq }
                    else { Token::GtGt }
                }
                Some('=') => { self.advance(); Token::GtEq }
                _ => Token::Gt,
            },
            '=' => match self.peek() {
                Some('=') => { self.advance(); Token::EqEq }
                _ => Token::Eq,
            },
            // `$` followed by an identifier — e.g. `$iv` — is a literal
            // dollar sign in arithmetic context (should have been expanded
            // before evaluation). Report it with the full `$name` as the
            // error token, matching bash's diagnostic.
            '$' => {
                let mut tok_str = "$".to_string();
                if self.peek() == Some('(') {
                    tok_str.push(self.advance().unwrap());
                    let mut depth = 1i32;
                    while let Some(c) = self.peek() {
                        tok_str.push(c);
                        self.advance();
                        match c {
                            '(' => depth += 1,
                            ')' => {
                                depth -= 1;
                                if depth == 0 {
                                    break;
                                }
                            }
                            '\\' => {
                                if let Some(next) = self.peek() {
                                    tok_str.push(next);
                                    self.advance();
                                }
                            }
                            '\'' | '"' => {
                                let quote = c;
                                while let Some(next) = self.peek() {
                                    tok_str.push(next);
                                    self.advance();
                                    if next == quote {
                                        break;
                                    }
                                    if next == '\\' {
                                        if let Some(esc) = self.peek() {
                                            tok_str.push(esc);
                                            self.advance();
                                        }
                                    }
                                }
                            }
                            _ => {}
                        }
                    }
                } else {
                    while matches!(self.peek(), Some(c) if c.is_ascii_alphanumeric() || c == '_') {
                        tok_str.push(self.advance().unwrap());
                    }
                }
                // Also capture trailing whitespace in token to match bash
                // (e.g. "$iv " → error token "$iv ")
                while self.peek() == Some(' ') || self.peek() == Some('\t') {
                    tok_str.push(self.advance().unwrap());
                }
                return Err(format!(
                    "arithmetic syntax error: operand expected (error token is \"{}\")",
                    tok_str
                ));
            }
            // Single/double quotes in arithmetic are invalid.
            '\'' | '"' => {
                let mut tok_str = ch.to_string();
                // Collect the rest of the quoted string for the error token.
                let close = ch;
                while let Some(c) = self.peek() {
                    tok_str.push(c);
                    self.advance();
                    if c == close { break; }
                }
                // Append trailing space if next is whitespace (bash includes it).
                if matches!(self.peek(), Some(' ') | Some('\t')) {
                    tok_str.push(' ');
                }
                return Err(format!(
                    "arithmetic syntax error: operand expected (error token is \"{}\")",
                    tok_str
                ));
            }
            _ => return Err("arithmetic syntax error: operand expected".to_owned()),
        };

        Ok(tok)
    }

    fn read_number(&mut self) -> Result<Token, String> {
        // Collect the raw number string first.  Bash's base-64 encoding
        // uses `@` (62) and `_` (63) as digits, so accept both here.
        let mut raw = String::new();
        while matches!(self.peek(), Some(c) if c.is_ascii_alphanumeric() || c == '#' || c == '_' || c == '@') {
            raw.push(self.advance().unwrap());
        }

        match parse_integer_literal(&raw) {
            Ok(value) => Ok(Token::Number(value)),
            Err(_err) if raw == "9223372036854775808" => Ok(Token::MinOverflow(raw)),
            Err(err) => Err(err),
        }
    }

    fn read_ident(&mut self) -> Token {
        let mut name = String::new();
        while matches!(self.peek(), Some(c) if c.is_ascii_alphanumeric() || c == '_') {
            name.push(self.advance().unwrap());
        }
        // Array subscript: capture `[...]` as part of the ident so
        // `a[1]`, `a[i+1]`, etc. look up array elements in the
        // eval phase.  Track nested `[...]` depth and stop at the
        // matching `]`.
        if self.peek() == Some('[') {
            let mut depth = 1i32;
            let mut quote: Option<char> = None;
            name.push(self.advance().unwrap());
            while depth > 0 {
                match self.peek() {
                    None => break,
                    Some(c) if quote.is_some() => {
                        let current_quote = quote.unwrap();
                        name.push(self.advance().unwrap());
                        if c == '\\' && current_quote == '"' {
                            if let Some(next) = self.peek() {
                                name.push(self.advance().unwrap());
                                if next == current_quote {
                                    continue;
                                }
                            }
                        } else if c == current_quote {
                            quote = None;
                        }
                    }
                    Some('\\') if quote.is_none() => {
                        // Backslash outside quotes: consume the backslash and
                        // the following character as literals WITHOUT entering
                        // quote mode. This ensures `\"` in `a[\" \"]` does NOT
                        // set double-quote mode, so the closing `]` is still
                        // recognised as a bracket.
                        name.push(self.advance().unwrap()); // consume '\'
                        if self.peek().is_some() {
                            name.push(self.advance().unwrap()); // consume escaped char
                        }
                    }
                    Some('\'') | Some('"') => {
                        let c = self.advance().unwrap();
                        quote = Some(c);
                        name.push(c);
                    }
                    Some('[') => { depth += 1; name.push(self.advance().unwrap()); }
                    Some(']') => {
                        depth -= 1;
                        name.push(self.advance().unwrap());
                        if depth == 0 {
                            if self.should_extend_assoc_subscript_tail() {
                                self.extend_assoc_subscript_tail(&mut name);
                            }
                            break;
                        }
                    }
                    Some(_) => { name.push(self.advance().unwrap()); }
                }
            }
        }
        Token::Ident(name)
    }

    fn should_extend_assoc_subscript_tail(&self) -> bool {
        let literal = ARITH_ALLOW_CMDSUB.with(|flag| !flag.get());
        let assoc_expand_once = ARITH_ASSOC_EXPAND_ONCE.with(|flag| flag.get());
        if !(literal && assoc_expand_once) {
            return false;
        }
        let remainder: String = self.chars.clone().collect();
        remainder.starts_with(',')
            && remainder.contains("$(")
    }

    fn extend_assoc_subscript_tail(&mut self, name: &mut String) {
        let mut quote: Option<char> = None;
        while let Some(c) = self.peek() {
            name.push(self.advance().unwrap());
            if let Some(current_quote) = quote {
                if c == '\\' && current_quote == '"' {
                    if let Some(next) = self.peek() {
                        name.push(self.advance().unwrap());
                        if next == current_quote {
                            continue;
                        }
                    }
                } else if c == current_quote {
                    quote = None;
                }
                continue;
            }
            match c {
                '\'' | '"' => quote = Some(c),
                ']' if self.assoc_subscript_tail_terminates() => break,
                _ => {}
            }
        }
    }

    fn assoc_subscript_tail_terminates(&self) -> bool {
        matches!(
            self.chars.clone().next(),
            None
                | Some(' ')
                | Some('\t')
                | Some('\n')
                | Some('\r')
                | Some('+')
                | Some('-')
                | Some('*')
                | Some('/')
                | Some('%')
                | Some('&')
                | Some('|')
                | Some('^')
                | Some('<')
                | Some('>')
                | Some(')')
                | Some('?')
                | Some(':')
        )
    }
}

/// Parse integer literals in the forms bash supports:
///   decimal    42
///   octal      0755
///   hex        0xFF  0XFF
///   base#value 16#FF  8#77  2#1010
fn parse_integer_literal(s: &str) -> Result<i64, String> {
    // base#value (bash-specific form).  A second `#` in the digits
    // section is not permitted — bash reports "invalid number
    // (error token is \"<literal>\")".  The error token bash
    // includes is the original literal.
    let invalid_num = |lit: &str| format!("invalid number (error token is \"{}\")", lit);
    if let Some(hash_pos) = s.find('#') {
        let base_str = &s[..hash_pos];
        let digits = &s[hash_pos + 1..];
        if digits.contains('#') {
            return Err(invalid_num(s));
        }
        if digits.is_empty() {
            return Err("invalid integer constant".to_owned());
        }
        // Leading 0 on the base (e.g. `0#4`) is not a valid base.
        if base_str.is_empty() || (base_str.starts_with('0') && base_str.len() > 1)
            || (base_str == "0")
        {
            return Err(invalid_num(s));
        }
        let base = base_str
            .parse::<u32>()
            .map_err(|_| invalid_num(s))?;
        if base < 2 || base > 64 {
            return Err("invalid arithmetic base".to_owned());
        }
        return i64_from_str_radix(digits, base);
    }

    // Hex 0x...
    if s.starts_with("0x") || s.starts_with("0X") {
        if s.len() == 2 {
            return Err("invalid integer constant".to_owned());
        }
        return i64_from_str_radix(&s[2..], 16);
    }

    // Octal 0...
    if s.starts_with('0') && s.len() > 1 {
        return i64_from_str_radix(&s[1..], 8);
    }

    // Decimal
    i64_from_str_radix(s, 10).map_err(|e| {
        if e == "value too great for base" {
            invalid_num(s)
        } else {
            e
        }
    })
}

/// Parse `digits` in the given `radix`, supporting base-64 digit sets.
/// Bash-compatible error wordings:
/// - if a digit value is >= radix: "value too great for base"
/// - if a character isn't a valid digit at all: "invalid number"
fn i64_from_str_radix(digits: &str, radix: u32) -> Result<i64, String> {
    let mut result: u64 = 0;
    for ch in digits.chars() {
        // Distinguish "character not a digit anywhere" from
        // "character is a digit but out of range for this base".
        let any_digit = match ch {
            '0'..='9' => true,
            'a'..='z' | 'A'..='Z' | '@' | '_' => true,
            _ => false,
        };
        let digit_val = match digit_value(ch, radix) {
            Some(v) => v,
            None if any_digit => {
                return Err("value too great for base".to_owned());
            }
            None => {
                return Err("invalid number".to_owned());
            }
        };
        result = result
            .wrapping_mul(radix as u64)
            .wrapping_add(digit_val as u64);
    }
    Ok(result as i64)
}

fn digit_value(ch: char, radix: u32) -> Option<u32> {
    // Bash's rules:
    // - For bases ≤ 36, both `a-z` and `A-Z` map to 10-35 (case-
    //   insensitive), matching the standard hex convention.
    // - For bases > 36, bash switches to base-64 encoding where
    //   `a-z` is 10-35, `A-Z` is 36-61, `@` is 62 and `_` is 63.
    let v = if radix <= 36 {
        match ch {
            '0'..='9' => (ch as u32) - ('0' as u32),
            'a'..='z' => (ch as u32) - ('a' as u32) + 10,
            'A'..='Z' => (ch as u32) - ('A' as u32) + 10,
            _ => return None,
        }
    } else {
        match ch {
            '0'..='9' => (ch as u32) - ('0' as u32),
            'a'..='z' => (ch as u32) - ('a' as u32) + 10,
            'A'..='Z' => (ch as u32) - ('A' as u32) + 36,
            '@' => 62,
            '_' => 63,
            _ => return None,
        }
    };
    if v < radix { Some(v) } else { None }
}

// ---------------------------------------------------------------------------
// Parser
// ---------------------------------------------------------------------------

struct Parser<'s, 'v, 't> {
    /// The input tokens, fully lexed upfront for simplicity.
    /// Borrowed from a LexedExpr when available (no Vec alloc), owned otherwise.
    tokens: std::borrow::Cow<'t, [Token]>,
    pos: usize,
    vars: &'v mut dyn VarSink,
    /// When >0, we're parsing an inert sub-expression (e.g. the untaken
    /// branch of a ternary). Reads still work but writes (assignments,
    /// postfix ++/--) are suppressed so side effects only happen on the
    /// live path.
    dry_run_depth: usize,
    /// Captured tokenizer error (e.g. "invalid arithmetic base") that
    /// should surface if parsing reaches the bad token.  Parsers that
    /// hit EOF unexpectedly will prefer this message over the generic
    /// "operand expected".
    lex_error: Option<String>,
    /// The original expression string, for error token extraction.
    orig_expr: &'s str,
    _phantom: std::marker::PhantomData<&'s ()>,
}

impl<'s, 'v, 't> Parser<'s, 'v, 't> {
    fn orig_expr_has_internal_markers(&self) -> bool {
        self.orig_expr
            .chars()
            .any(|c| c == crate::expand::CTLESC || ('\u{E000}'..='\u{F8FF}').contains(&c))
    }

    fn new(expr: &'s str, vars: &'v mut dyn VarSink) -> Parser<'s, 'v, 'static> {
        // Lex everything up-front so we can do look-ahead cheaply.
        let mut lexer = Lexer::new(expr);
        let mut tokens: Vec<Token> = Vec::new();
        let mut lex_error: Option<String> = None;
        loop {
            match lexer.next_token() {
                Ok(Token::Eof) => { tokens.push(Token::Eof); break; }
                Ok(t) => tokens.push(t),
                Err(e) => {
                    // Save the tokenizer's specific error for the
                    // parser to surface when it hits the bad position.
                    tokens.push(Token::Eof);
                    lex_error = Some(e);
                    break;
                }
            }
        }
        Parser {
            tokens: std::borrow::Cow::Owned(tokens),
            pos: 0,
            vars,
            dry_run_depth: 0,
            lex_error,
            orig_expr: expr,
            _phantom: std::marker::PhantomData,
        }
    }

    fn peek(&self) -> &Token {
        self.tokens.get(self.pos).unwrap_or(&Token::Eof)
    }

    fn peek2(&self) -> &Token {
        self.tokens.get(self.pos + 1).unwrap_or(&Token::Eof)
    }

    fn advance(&mut self) -> &Token {
        let t = &self.tokens[self.pos];
        if self.pos + 1 < self.tokens.len() {
            self.pos += 1;
        }
        t
    }

    fn expect(&mut self, expected: &Token) -> Result<(), String> {
        if self.peek() == expected {
            self.advance();
            Ok(())
        } else {
            // Bash-compat error wordings:
            //   missing `)'              — when expecting RParen
            //   `:' expected for conditional expression — ternary `? :`
            //   expression expected       — generic fall-through
            let msg = match expected {
                Token::RParen => "missing `)'".to_owned(),
                Token::Colon  => "`:' expected for conditional expression".to_owned(),
                _ => "expression expected".to_owned(),
            };
            Err(msg)
        }
    }

    fn get_var_value(&mut self, name: &str) -> Result<i64, String> {
        if self.dry_run_depth > 0 {
            return Ok(0);
        }
        ARITH_ALLOW_SIDE_EFFECTS.with(|flag| {
            let old = flag.replace(true);
            let result = self.vars.get(name);
            flag.set(old);
            result
        })
    }

    // ------------------------------------------------------------------
    // Grammar (recursive descent)
    // ------------------------------------------------------------------

    /// Top-level entry point: parse the full expression and check for leftover tokens.
    /// Called only by `eval_expr` / `eval_expr_mut` (i.e. at the top of evaluation, not
    /// from within recursive sub-expressions like `(expr)` or ternary).
    pub fn parse_top(&mut self) -> Result<i64, String> {
        let val = self.parse_comma()?;
        if matches!(self.peek(), Token::Eof) {
            if let Some(e) = self.lex_error.take() {
                if self.orig_expr_has_internal_markers() {
                    return Ok(val);
                }
                return Err(e);
            }
        }
        // Check for leftover tokens — indicates a syntax error.
        // E.g. `7=4` leaves `=4` unconsumed; `7++` leaves `++` unconsumed.
        if !matches!(self.peek(), Token::Eof) {
            let tok = self.peek().clone();
            // Produce a bash-compatible error message.
            let token_str = match &tok {
                Token::Eq              => "=".to_string(),
                Token::PlusPlus        => "+ ".to_string(),  // bash shows "+ " for ++
                Token::MinusMinus      => "- ".to_string(),
                Token::EqEq            => "==".to_string(),
                Token::BangEq          => "!=".to_string(),
                Token::Plus            => "+".to_string(),
                Token::Minus           => "-".to_string(),
                Token::Star            => "*".to_string(),
                Token::Slash           => "/".to_string(),
                Token::Percent         => "%".to_string(),
                Token::LParen          => "(".to_string(),
                Token::RParen          => ")".to_string(),
                Token::Comma           => ",".to_string(),
                Token::Question        => "?".to_string(),
                Token::Colon           => ":".to_string(),
                Token::Amp             => "&".to_string(),
                Token::Pipe            => "|".to_string(),
                Token::AmpAmp          => "&&".to_string(),
                Token::PipePipe        => "||".to_string(),
                Token::Lt              => "<".to_string(),
                Token::Gt              => ">".to_string(),
                Token::LtEq            => "<=".to_string(),
                Token::GtEq            => ">=".to_string(),
                Token::LtLt            => "<<".to_string(),
                Token::GtGt            => ">>".to_string(),
                Token::Bang            => "!".to_string(),
                Token::Tilde           => "~".to_string(),
                Token::Caret           => "^".to_string(),
                Token::Ident(s)        => s.clone(),
                Token::Number(n)       => n.to_string(),
                Token::MinOverflow(s)  => s.clone(),
                // Fall back to Debug repr for any token we haven't
                // explicitly mapped — but log it so we notice and
                // add proper mappings over time.
                other                  => format!("{:?}", other),
            };
            // `--EXPR ++` or `++EXPR --` etc. → postfix ++ / -- on a
            // non-lvalue is "assignment requires lvalue" (not just "operand
            // expected"). The operator name precedes the message.
            if matches!(tok, Token::PlusPlus | Token::MinusMinus) {
                let op_name = if matches!(tok, Token::PlusPlus) { "++" } else { "--" };
                // The error token includes trailing whitespace from the original.
                let tok_text = if matches!(tok, Token::PlusPlus) { "++ " } else { "-- " };
                return Err(format!(
                    "{}: assignment requires lvalue (error token is \"{}\")", op_name, tok_text
                ));
            }
            // `NUMBER = ...` or `EXPR += ...` etc. → attempted assignment
            // to non-variable.  Derive the error token from the original
            // expression (preserves spacing), or from the remaining tokens.
            let is_assign_op = matches!(tok,
                Token::Eq | Token::PlusEq | Token::MinusEq | Token::StarEq |
                Token::SlashEq | Token::PercentEq | Token::AmpEq | Token::PipeEq |
                Token::CaretEq | Token::LtLtEq | Token::GtGtEq | Token::StarStarEq
            );
            if is_assign_op {
                // Build the error token: op_text + remaining tokens + trailing space.
                let op_text = match &tok {
                    Token::Eq        => "=",
                    Token::PlusEq    => "+=",
                    Token::MinusEq   => "-=",
                    Token::StarEq    => "*=",
                    Token::SlashEq   => "/=",
                    Token::PercentEq => "%=",
                    Token::AmpEq     => "&=",
                    Token::PipeEq    => "|=",
                    Token::CaretEq   => "^=",
                    Token::LtLtEq    => "<<=",
                    Token::GtGtEq    => ">>=",
                    Token::StarStarEq=> "**=",
                    _                => "=",
                };
                if matches!(tok, Token::Eq) {
                    // For bare `=`, use the original expression to preserve
                    // spacing (e.g. `= 43 ` vs `=43 `).
                    let rest = extract_eq_suffix(self.orig_expr);
                    return Err(format!(
                        "attempted assignment to non-variable (error token is \"{}\")", rest
                    ));
                }
                // For compound ops (+=, -=, etc.), extract from original.
                let rest = extract_compound_assign_suffix(self.orig_expr, op_text);
                return Err(format!(
                    "attempted assignment to non-variable (error token is \"{}\")", rest
                ));
            }
            // When the leftover token is an identifier (e.g. `a b` or
            // `x=9 y=41`), bash says "arithmetic syntax error in expression"
            // and the error token is the entire remaining text.
            if let Token::Ident(ident_name) = &tok {
                let rest = extract_ident_suffix(self.orig_expr, ident_name);
                return Err(format!(
                    "arithmetic syntax error in expression (error token is \"{}\")", rest
                ));
            }
            return Err(format!(
                "arithmetic syntax error: operand expected (error token is \"{}\")", token_str
            ));
        }
        Ok(val)
    }

    /// Internal parse_expr used recursively (e.g. in ternary `? expr :`, parentheses).
    /// Does NOT check for leftover tokens — the caller is responsible for consuming
    /// any closing delimiter (e.g. `)` in `(expr)`).
    pub fn parse_expr(&mut self) -> Result<i64, String> {
        self.parse_comma()
    }

    // Level 1: comma  expr, expr  — evaluates both, returns right
    fn parse_comma(&mut self) -> Result<i64, String> {
        let mut val = self.parse_assign()?;
        while self.peek() == &Token::Comma {
            self.advance();
            val = self.parse_assign()?;
        }
        Ok(val)
    }

    // Level 2: assignment (right-associative)
    fn parse_assign(&mut self) -> Result<i64, String> {
        // We need lookahead to distinguish  x = expr  from  x == expr  etc.
        // An assignment LHS is always a bare identifier.
        if let Token::Ident(name) = self.peek().clone() {
            let assign_op = match self.peek2() {
                Token::Eq       => Some(AssignOp::Set),
                Token::PlusEq   => Some(AssignOp::Add),
                Token::MinusEq  => Some(AssignOp::Sub),
                Token::StarEq   => Some(AssignOp::Mul),
                Token::SlashEq  => Some(AssignOp::Div),
                Token::PercentEq=> Some(AssignOp::Rem),
                Token::StarStarEq=>Some(AssignOp::Pow),
                Token::AmpEq    => Some(AssignOp::BitAnd),
                Token::PipeEq   => Some(AssignOp::BitOr),
                Token::CaretEq  => Some(AssignOp::BitXor),
                Token::LtLtEq   => Some(AssignOp::Shl),
                Token::GtGtEq   => Some(AssignOp::Shr),
                _ => None,
            };
            if let Some(op) = assign_op {
                self.advance(); // consume ident
                self.advance(); // consume operator
                // If the RHS is empty (Eof), produce a bash-compatible error.
                // If the lexer captured a specific error (e.g. `$iv` is
                // invalid), surface that instead of the generic op-string error.
                if matches!(self.peek(), Token::Eof) {
                    if let Some(e) = self.lex_error.take() {
                        return Err(e);
                    }
                    let op_str = match op {
                        AssignOp::Set    => "=",
                        AssignOp::Add    => "+=",
                        AssignOp::Sub    => "-=",
                        AssignOp::Mul    => "*=",
                        AssignOp::Div    => "/=",
                        AssignOp::Rem    => "%=",
                        AssignOp::Pow    => "**=",
                        AssignOp::BitAnd => "&=",
                        AssignOp::BitOr  => "|=",
                        AssignOp::BitXor => "^=",
                        AssignOp::Shl    => "<<=",
                        AssignOp::Shr    => ">>=",
                    };
                    return Err(format!(
                        "arithmetic syntax error: operand expected (error token is \"{}\")", op_str
                    ));
                }
                let rhs = self.parse_assign()?; // right-associative
                // In a dry-run branch (untaken side of ternary), we parse
                // the expression to consume tokens but must not mutate
                // variables. Return the computed value anyway — it's used
                // locally and then discarded by the ternary.
                let new_val = match op {
                    AssignOp::Set    => rhs,
                    AssignOp::Add    => self.get_var_value(&name)?.wrapping_add(rhs),
                    AssignOp::Sub    => self.get_var_value(&name)?.wrapping_sub(rhs),
                    AssignOp::Mul    => self.get_var_value(&name)?.wrapping_mul(rhs),
                    AssignOp::Div    => {
                        if rhs == 0 { return Err("division by 0".to_owned()); }
                        self.get_var_value(&name)?.wrapping_div(rhs)
                    }
                    AssignOp::Rem    => {
                        if rhs == 0 { return Err("modulo by zero".to_owned()); }
                        self.get_var_value(&name)?.wrapping_rem(rhs)
                    }
                    AssignOp::Pow    => pow_i64(self.get_var_value(&name)?, rhs)?,
                    AssignOp::BitAnd => self.get_var_value(&name)? & rhs,
                    AssignOp::BitOr  => self.get_var_value(&name)? | rhs,
                    AssignOp::BitXor => self.get_var_value(&name)? ^ rhs,
                    AssignOp::Shl    => checked_shl(self.get_var_value(&name)?, rhs)?,
                    AssignOp::Shr    => checked_shr(self.get_var_value(&name)?, rhs)?,
                };
                if self.dry_run_depth == 0 {
                    self.vars.set(&name, new_val)?;
                }
                return Ok(new_val);
            }
        }
        self.parse_ternary()
    }

    // Level 3: ternary  cond ? then : else
    //
    // Bash evaluates only the taken branch for its side effects; the other
    // branch is parsed (to consume tokens) but its assignments / ++ / --
    // must not mutate. We mark the untaken branch with dry_run_depth so
    // writes are suppressed. Note: when we're already in a dry-run context,
    // both branches stay dry.
    fn parse_ternary(&mut self) -> Result<i64, String> {
        let cond = self.parse_logical_or()?;
        if self.peek() == &Token::Question {
            self.advance(); // consume ?
            let take_then = cond != 0;
            let already_dry = self.dry_run_depth > 0;
            if !take_then && !already_dry { self.dry_run_depth += 1; }
            // If the very next token is `:` or Eof, the then-branch is empty.
            // Bash says "expression expected (error token is ": <rest>")".
            let then_val = if matches!(self.peek(), Token::Colon | Token::Eof) {
                let rest = extract_colon_suffix(self.orig_expr);
                return Err(format!("expression expected (error token is \"{}\")", rest));
            } else {
                self.parse_expr()?
            };
            if !take_then && !already_dry { self.dry_run_depth -= 1; }
            // expect the `:` separator; if missing, attach the then-val text
            // as the error token (bash: "`:' expected … (error token is "20 ")")
            let colon_result = self.expect(&Token::Colon);
            if let Err(e) = colon_result {
                // Find the then-branch text in orig_expr for the error token.
                let tok = extract_then_branch_token(self.orig_expr);
                return Err(format!("{} (error token is \"{}\")", e, tok));
            }
            if take_then && !already_dry { self.dry_run_depth += 1; }
            // If the else-branch is empty (Eof), bash says "expression expected
            // (error token is ": ")" pointing to the consumed colon.
            let else_val = if matches!(self.peek(), Token::Eof) {
                let rest = extract_colon_suffix_from_end(self.orig_expr);
                return Err(format!("expression expected (error token is \"{}\")", rest));
            } else {
                self.parse_ternary()? // right-associative
            };
            if take_then && !already_dry { self.dry_run_depth -= 1; }
            return Ok(if take_then { then_val } else { else_val });
        }
        Ok(cond)
    }

    // Level 4: ||
    fn parse_logical_or(&mut self) -> Result<i64, String> {
        let mut val = self.parse_logical_and()?;
        while self.peek() == &Token::PipePipe {
            self.advance();
            // Short-circuit: if LHS is already truthy, parse RHS in
            // dry-run mode so assignments don't mutate vars.
            let already_dry = self.dry_run_depth > 0;
            let short = val != 0;
            if short && !already_dry { self.dry_run_depth += 1; }
            let rhs = self.parse_logical_and()?;
            if short && !already_dry { self.dry_run_depth -= 1; }
            val = if val != 0 || rhs != 0 { 1 } else { 0 };
        }
        Ok(val)
    }

    // Level 5: &&
    fn parse_logical_and(&mut self) -> Result<i64, String> {
        let mut val = self.parse_bitwise_or()?;
        while self.peek() == &Token::AmpAmp {
            self.advance();
            // Short-circuit: if LHS is already falsy, parse RHS in
            // dry-run mode so assignments don't mutate vars.
            let already_dry = self.dry_run_depth > 0;
            let short = val == 0;
            if short && !already_dry { self.dry_run_depth += 1; }
            let rhs = self.parse_bitwise_or()?;
            if short && !already_dry { self.dry_run_depth -= 1; }
            val = if val != 0 && rhs != 0 { 1 } else { 0 };
        }
        Ok(val)
    }

    // Level 6: |
    fn parse_bitwise_or(&mut self) -> Result<i64, String> {
        let mut val = self.parse_bitwise_xor()?;
        while self.peek() == &Token::Pipe {
            self.advance();
            let rhs = self.parse_bitwise_xor()?;
            val |= rhs;
        }
        Ok(val)
    }

    // Level 7: ^
    fn parse_bitwise_xor(&mut self) -> Result<i64, String> {
        let mut val = self.parse_bitwise_and()?;
        while self.peek() == &Token::Caret {
            self.advance();
            let rhs = self.parse_bitwise_and()?;
            val ^= rhs;
        }
        Ok(val)
    }

    // Level 8: &
    fn parse_bitwise_and(&mut self) -> Result<i64, String> {
        let mut val = self.parse_equality()?;
        while self.peek() == &Token::Amp {
            self.advance();
            let rhs = self.parse_equality()?;
            val &= rhs;
        }
        Ok(val)
    }

    // Level 9: == !=
    fn parse_equality(&mut self) -> Result<i64, String> {
        let mut val = self.parse_relational()?;
        loop {
            match self.peek() {
                Token::EqEq => {
                    self.advance();
                    let rhs = self.parse_relational()?;
                    val = if val == rhs { 1 } else { 0 };
                }
                Token::BangEq => {
                    self.advance();
                    let rhs = self.parse_relational()?;
                    val = if val != rhs { 1 } else { 0 };
                }
                _ => break,
            }
        }
        Ok(val)
    }

    // Level 10: < > <= >=
    fn parse_relational(&mut self) -> Result<i64, String> {
        let mut val = self.parse_shift()?;
        loop {
            match self.peek() {
                Token::Lt => {
                    self.advance();
                    let rhs = self.parse_shift()?;
                    val = if val < rhs { 1 } else { 0 };
                }
                Token::Gt => {
                    self.advance();
                    let rhs = self.parse_shift()?;
                    val = if val > rhs { 1 } else { 0 };
                }
                Token::LtEq => {
                    self.advance();
                    let rhs = self.parse_shift()?;
                    val = if val <= rhs { 1 } else { 0 };
                }
                Token::GtEq => {
                    self.advance();
                    let rhs = self.parse_shift()?;
                    val = if val >= rhs { 1 } else { 0 };
                }
                _ => break,
            }
        }
        Ok(val)
    }

    // Level 11: << >>
    fn parse_shift(&mut self) -> Result<i64, String> {
        let mut val = self.parse_additive()?;
        loop {
            match self.peek() {
                Token::LtLt => {
                    self.advance();
                    let rhs = self.parse_additive()?;
                    val = checked_shl(val, rhs)?;
                }
                Token::GtGt => {
                    self.advance();
                    let rhs = self.parse_additive()?;
                    val = checked_shr(val, rhs)?;
                }
                _ => break,
            }
        }
        Ok(val)
    }

    // Level 12: + -
    fn parse_additive(&mut self) -> Result<i64, String> {
        let mut val = self.parse_multiplicative()?;
        loop {
            match self.peek() {
                Token::Plus => {
                    self.advance();
                    val = val.wrapping_add(self.parse_multiplicative()?);
                }
                Token::Minus => {
                    self.advance();
                    val = val.wrapping_sub(self.parse_multiplicative()?);
                }
                // `4+++a` tokenizes as `4 ++ + a` with maximal-munch, but
                // bash treats it as `4 + (++a)`.  When we see `PlusPlus`
                // in binary position followed by an ident (or more ++/--),
                // the `PlusPlus` was wrongly merged from a binary `+` and
                // a prefix `++`.  Split it: advance past `PlusPlus`, then
                // look at what follows.  If the next token is `Plus` or
                // `Ident`, we have `4 + (+ ident_or_more)`.  We replace
                // the consumed `PlusPlus` conceptually with one `+` binary
                // and then reparse from the remaining tokens.
                //
                // Concrete: `4+++a` → `[4, ++, +, a]`.  After parsing 4,
                // pos=1 (at ++). We want to treat as binary + then ++a.
                // The RHS starting at pos=1 needs to see PlusPlus then a.
                // So: replace `[++, +, a]` with `[++, a]` (dropping the
                // extra `+`) — but that also loses the unary `+`.  Actually
                // bash treats `+++a` = `++(+a)` with a=incr(a) ... No.
                // Let's check: `4+++a` = `4+(++a)` where `++` increments a.
                // Tokens: `[++, +, a]` → treat `++` as consumed binary,
                // then see `+ a` — which is `+a` = unary-plus(a) = a.
                // But we need `++a`.  The real issue: bash sees `4+++a` as
                // `4 + (++ a)` not `4 + (+ a)`.
                //
                // The simplest fix: when we see `PlusPlus` in binary context
                // and the NEXT token (peek2) is `Ident` (potentially via
                // another `+`), split `PlusPlus` → consume first `+` as
                // binary, INSERT another `Plus` for the prefix, producing
                // effectively `4 + + (PlusPlus a)` ... but we don't have
                // another PlusPlus.  Actually the original tokens are
                // `[PlusPlus, Plus, Ident]`.  Replace that with
                // `[Plus, PlusPlus, Ident]`? No, parse_unary would then
                // see Plus (unary +) then PlusPlus Ident = ++(a) = correct!
                //
                // So: swap tokens at pos and pos+1 (PlusPlus ↔ Plus),
                // then fall through to the normal Plus binary handler.
                Token::PlusPlus if matches!(self.tokens.get(self.pos + 1), Some(Token::Plus) | Some(Token::Minus)) => {
                    // Swap PlusPlus and the following +/- so that the binary
                    // operator is `+` and the RHS starts with PlusPlus.
                    // Cow::to_mut() clones only if borrowed (rare edge case).
                    self.tokens.to_mut().swap(self.pos, self.pos + 1);
                    // Now peek is `Plus` (the binary operator). Fall through
                    // to the next iteration which will handle Token::Plus.
                    continue;
                }
                Token::MinusMinus if matches!(self.tokens.get(self.pos + 1), Some(Token::Plus) | Some(Token::Minus)) => {
                    // Similarly: `4---a` = `4 - (-- a)`.
                    // Tokens: [MinusMinus, Minus, Ident]. Swap to [Minus, MinusMinus, Ident].
                    self.tokens.to_mut().swap(self.pos, self.pos + 1);
                    continue;
                }
                _ => break,
            }
        }
        Ok(val)
    }

    // Level 13: * / %
    fn parse_multiplicative(&mut self) -> Result<i64, String> {
        let mut val = self.parse_exponent()?;
        loop {
            match self.peek() {
                Token::Star => {
                    self.advance();
                    val = val.wrapping_mul(self.parse_exponent()?);
                }
                Token::Slash => {
                    self.advance();
                    let rhs = self.parse_exponent()?;
                    if rhs == 0 { return Err("division by 0".to_owned()); }
                    val = val.wrapping_div(rhs);
                }
                Token::Percent => {
                    self.advance();
                    let rhs = self.parse_exponent()?;
                    if rhs == 0 { return Err("modulo by zero".to_owned()); }
                    val = val.wrapping_rem(rhs);
                }
                _ => break,
            }
        }
        Ok(val)
    }

    // Level 14: ** (right-associative)
    fn parse_exponent(&mut self) -> Result<i64, String> {
        let base = self.parse_unary()?;
        if self.peek() == &Token::StarStar {
            self.advance();
            let exp = self.parse_exponent()?; // right-associative
            return pow_i64(base, exp);
        }
        Ok(base)
    }

    // Level 15: prefix unary  ! ~ + - ++ --
    fn parse_unary(&mut self) -> Result<i64, String> {
        match self.peek().clone() {
            Token::Bang => {
                self.advance();
                let val = self.parse_unary()?;
                return Ok(if val == 0 { 1 } else { 0 });
            }
            Token::Tilde => {
                self.advance();
                let val = self.parse_unary()?;
                return Ok(!val);
            }
            Token::Plus => {
                self.advance();
                return self.parse_unary();
            }
            Token::Minus => {
                self.advance();
                if let Token::MinOverflow(_) = self.peek().clone() {
                    self.advance();
                    return Ok(i64::MIN);
                }
                let val = self.parse_unary()?;
                return Ok(val.wrapping_neg());
            }
            Token::PlusPlus => {
                // Prefix ++: increment then return new value.
                self.advance();
                if let Token::Ident(name) = self.peek().clone() {
                    self.advance();
                    let new_val = self.get_var_value(&name)?.wrapping_add(1);
                    if self.dry_run_depth == 0 {
                        self.vars.set(&name, new_val)?;
                    }
                    return Ok(new_val);
                }
                // Bash: `++7` parses as two unary `+` signs (a no-op),
                // not as prefix-increment of a literal.  Recurse into
                // parse_unary so the rest of the expression is
                // evaluated as `+ (+ EXPR)`.
                let val = self.parse_unary()?;
                return Ok(val);
            }
            Token::MinusMinus => {
                // Prefix --: decrement then return new value.
                self.advance();
                if let Token::Ident(name) = self.peek().clone() {
                    self.advance();
                    let new_val = self.get_var_value(&name)?.wrapping_sub(1);
                    if self.dry_run_depth == 0 {
                        self.vars.set(&name, new_val)?;
                    }
                    return Ok(new_val);
                }
                // Bash: `--7` parses as two unary `-` signs (a no-op
                // giving the positive value), not as prefix-decrement
                // of a literal.
                let val = self.parse_unary()?;
                return Ok(val);
            }
            _ => {}
        }
        self.parse_postfix()
    }

    // Level 16: postfix ++ --
    fn parse_postfix(&mut self) -> Result<i64, String> {
        let val = self.parse_primary()?;
        // Postfix ++ / -- on a non-ident (e.g. a number literal like `7++`)
        // is a syntax error — the operator requires an lvalue.
        // (Idents handle their own postfix in parse_primary.)
        if matches!(self.peek(), Token::PlusPlus | Token::MinusMinus) {
            if matches!(self.tokens.get(self.pos + 1), Some(Token::Plus) | Some(Token::Minus)) {
                return Ok(val);
            }
            // Bash shows "+ " for ++ and "- " for -- in these error messages.
            let op = if matches!(self.peek(), Token::PlusPlus) { "+ " } else { "- " };
            return Err(format!("arithmetic syntax error: operand expected (error token is \"{}\")", op));
        }
        Ok(val)
    }

    // Level 17: primary — literals, identifiers (with postfix), parentheses
    fn parse_primary(&mut self) -> Result<i64, String> {
        match self.peek().clone() {
            Token::Number(n) => {
                self.advance();
                Ok(n)
            }
            Token::MinOverflow(raw) => {
                self.advance();
                Err(format!("invalid number (error token is \"{}\")", raw))
            }
            Token::Ident(name) => {
                self.advance();
                let current = self.get_var_value(&name)?;
                // Check for postfix ++ / --
                match self.peek() {
                    Token::PlusPlus => {
                        self.advance();
                        if self.dry_run_depth == 0 {
                            self.vars.set(&name, current.wrapping_add(1))?;
                        }
                        Ok(current) // return the value BEFORE increment
                    }
                    Token::MinusMinus => {
                        self.advance();
                        if self.dry_run_depth == 0 {
                            self.vars.set(&name, current.wrapping_sub(1))?;
                        }
                        Ok(current) // return the value BEFORE decrement
                    }
                    _ => Ok(current),
                }
            }
            Token::LParen => {
                self.advance(); // consume (
                let val = self.parse_expr()?;
                self.expect(&Token::RParen)?;
                Ok(val)
            }
            // Bash's error for running out of operand/operator is
            // "arithmetic syntax error: operand expected".  But if
            // the lexer had a specific error (e.g. "invalid
            // arithmetic base"), surface that instead.
            _ => {
                if let Some(e) = self.lex_error.take() {
                    return Err(e);
                }
                Err("arithmetic syntax error: operand expected".to_owned())
            }
        }
    }
}

/// Find the first bare `=` in `expr` (not part of `==`, `!=`, `<=`, `>=`,
/// `+=`, `-=`, `*=`, `/=`, `%=`, `^=`, `&=`, `|=`, `<<=`, `>>=`, `**=`)
/// and return the substring from that `=` to the end of `expr`, including
/// a trailing space if not already present (bash style).
fn extract_eq_suffix(expr: &str) -> String {
    let bytes = expr.as_bytes();
    let n = bytes.len();
    let mut i = 0;
    while i < n {
        if bytes[i] == b'=' {
            // Check it's not `==` (next char is also `=`).
            let next_is_eq = i + 1 < n && bytes[i+1] == b'=';
            if next_is_eq { i += 1; continue; }
            // Check it's not a compound-assignment suffix (e.g. `+=`, `-=`, `*=` …).
            // The compound-assign operators are exactly ONE operator character
            // immediately before `=`.  We must NOT skip if the preceding two
            // characters are the same (e.g. `++=` → `++` then bare `=`,
            // not `+=` preceded by another `+`).
            let prev_ch = if i > 0 { bytes[i-1] } else { 0 };
            let prev2_ch = if i > 1 { bytes[i-2] } else { 0 };
            let prev_forms_compound = match prev_ch {
                b'!' | b'<' | b'>' | b'+' | b'-' | b'*' | b'/' | b'%' | b'^' | b'&' | b'|' => true,
                _ => false,
            };
            // If prev_ch is `+` but prev2_ch is also `+`, then we have `++=` which
            // should be read as `++` then `=` (postfix increment then bare assign).
            // Similarly for `--=`.  Only apply the compound-assign skip when the
            // preceding character uniquely forms the 2-char compound operator.
            let really_compound = prev_forms_compound && prev_ch != prev2_ch;
            if !really_compound {
                // Found a bare `=`. Return from here to end, with trailing space.
                let suffix = &expr[i..];
                if suffix.ends_with(' ') {
                    return suffix.to_string();
                } else {
                    return format!("{} ", suffix);
                }
            }
        }
        i += 1;
    }
    // Fallback: return "= " if no bare = found
    "= ".to_string()
}

/// Extract the text from the first `:` in `expr` to end (for ternary then-empty error).
/// Returns ": <rest> " with trailing space.
fn extract_colon_suffix(expr: &str) -> String {
    if let Some(pos) = expr.find(':') {
        let suffix = &expr[pos..];
        if suffix.ends_with(' ') { suffix.to_string() } else { format!("{} ", suffix) }
    } else {
        ": ".to_string()
    }
}

/// Extract the text from the LAST `:` in `expr` to end (for ternary else-empty error).
/// Returns ": " with trailing space.
fn extract_colon_suffix_from_end(expr: &str) -> String {
    if let Some(pos) = expr.rfind(':') {
        let suffix = &expr[pos..];
        if suffix.ends_with(' ') { suffix.to_string() } else { format!("{} ", suffix) }
    } else {
        ": ".to_string()
    }
}

/// Extract the last non-empty word before a `:` or Eof in `expr` for the
/// "`:' expected for conditional expression (error token is "X ")"" message.
/// Returns the last word (trimmed) with trailing space.
fn extract_then_branch_token(expr: &str) -> String {
    // The then-branch value is the last token before end-of-input or before `:`.
    // Find the last word character run in expr (trimmed).
    let trimmed = expr.trim_end();
    // Walk back from the end, collect non-whitespace chars.
    let mut tok = String::new();
    for ch in trimmed.chars().rev() {
        if ch.is_whitespace() && !tok.is_empty() { break; }
        if !ch.is_whitespace() { tok.push(ch); }
    }
    let word: String = tok.chars().rev().collect();
    if word.is_empty() { "? ".to_string() } else { format!("{} ", word) }
}

/// Find the leftover identifier suffix in `expr`.  Used when an expression
/// like `a b` or `x=9 y=41` leaves a trailing identifier unparsed.
/// Returns the substring from the first occurrence of `ident` (searching
/// from right to handle duplicates) to the end, with trailing space.
fn extract_ident_suffix(expr: &str, ident: &str) -> String {
    // Find the rightmost occurrence of the ident as a whole word.
    // We search from right to left so that for `x=9 y=41` we find `y=41`.
    let bytes = expr.as_bytes();
    let ident_bytes = ident.as_bytes();
    let n = bytes.len();
    let m = ident_bytes.len();
    // Search from right
    if n >= m {
        let mut i = n - m;
        loop {
            if bytes[i..i+m] == *ident_bytes {
                // Verify it's a word boundary: prev char is non-ident
                let ok_before = i == 0 || !matches!(bytes[i-1], b'a'..=b'z' | b'A'..=b'Z' | b'0'..=b'9' | b'_');
                if ok_before {
                    // Return the suffix as-is (preserving trailing space from
                    // original expression, e.g. " x=9 y=41 " → "y=41 ").
                    // Do NOT add trailing space if not already there — bash
                    // only includes trailing space when the expression has it.
                    return expr[i..].to_string();
                }
            }
            if i == 0 { break; }
            i -= 1;
        }
    }
    // Fallback: just the ident
    ident.to_string()
}

/// Find the first occurrence of a compound assignment operator `op` (e.g. "+=")
/// in `expr` and return the substring from that operator to end.
/// Trailing whitespace from the original expression is preserved as-is;
/// no extra trailing space is added (bash only includes trailing space
/// when the expression itself has it).
fn extract_compound_assign_suffix(expr: &str, op: &str) -> String {
    // Search for the op string
    if let Some(pos) = expr.find(op) {
        return expr[pos..].to_string();
    }
    op.to_string()
}

// ---------------------------------------------------------------------------
// Operator helpers
// ---------------------------------------------------------------------------

#[derive(Debug, Clone, Copy)]
enum AssignOp {
    Set,
    Add,
    Sub,
    Mul,
    Div,
    Rem,
    Pow,
    BitAnd,
    BitOr,
    BitXor,
    Shl,
    Shr,
}

fn pow_i64(base: i64, exp: i64) -> Result<i64, String> {
    if exp < 0 {
        // Bash errors on negative exponent in integer arithmetic:
        // `$((2**-1))` → "exponent less than 0".  Earlier brash
        // silently returned 0; match the bash diagnostic instead.
        return Err(format!(
            "exponent less than 0 (error token is \"{} \")", exp.wrapping_neg()
        ));
    }
    let mut result: i64 = 1;
    let mut b = base;
    let mut e = exp as u64;
    while e > 0 {
        if e & 1 == 1 {
            result = result.wrapping_mul(b);
        }
        b = b.wrapping_mul(b);
        e >>= 1;
    }
    Ok(result)
}

fn checked_shl(val: i64, shift: i64) -> Result<i64, String> {
    if shift < 0 || shift >= 64 {
        return Ok(0);
    }
    Ok(val.wrapping_shl(shift as u32))
}

fn checked_shr(val: i64, shift: i64) -> Result<i64, String> {
    if shift < 0 || shift >= 64 {
        return Ok(0);
    }
    // Arithmetic (signed) right-shift, matching bash behaviour.
    Ok(val >> (shift as u32))
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use super::*;
    use crate::vars::Variables;

    fn eval(expr: &str) -> i64 {
        let vars = Variables::new();
        eval_expr(expr, &vars).expect("eval failed")
    }

    fn eval_mut(expr: &str, vars: &mut Variables) -> i64 {
        eval_expr_mut(expr, vars).expect("eval_mut failed")
    }

    // --- Literals ---

    #[test]
    fn test_decimal() {
        assert_eq!(eval("42"), 42);
        assert_eq!(eval("0"), 0);
    }

    #[test]
    fn test_hex() {
        assert_eq!(eval("0xff"), 255);
        assert_eq!(eval("0X1A"), 26);
    }

    #[test]
    fn test_octal() {
        assert_eq!(eval("010"), 8);
        assert_eq!(eval("0777"), 511);
    }

    #[test]
    fn test_base_hash() {
        assert_eq!(eval("16#FF"), 255);
        assert_eq!(eval("2#1010"), 10);
        assert_eq!(eval("8#17"), 15);
    }

    // --- Arithmetic ---

    #[test]
    fn test_add_sub() {
        assert_eq!(eval("3 + 4"), 7);
        assert_eq!(eval("10 - 3"), 7);
    }

    #[test]
    fn test_mul_div_rem() {
        assert_eq!(eval("6 * 7"), 42);
        assert_eq!(eval("10 / 3"), 3);
        assert_eq!(eval("10 % 3"), 1);
    }

    #[test]
    fn test_power() {
        assert_eq!(eval("2 ** 10"), 1024);
        assert_eq!(eval("3 ** 3"), 27);
    }

    #[test]
    fn test_unary() {
        assert_eq!(eval("-5"), -5);
        assert_eq!(eval("+5"), 5);
        assert_eq!(eval("!0"), 1);
        assert_eq!(eval("!1"), 0);
        assert_eq!(eval("~0"), -1);
    }

    // --- Bitwise ---

    #[test]
    fn test_bitwise() {
        assert_eq!(eval("0 | 0"), 0);
        assert_eq!(eval("12 & 10"), 8);
        assert_eq!(eval("12 | 10"), 14);
        assert_eq!(eval("12 ^ 10"), 6);
        assert_eq!(eval("1 << 4"), 16);
        assert_eq!(eval("32 >> 2"), 8);
    }

    // --- Comparison / logical ---

    #[test]
    fn test_comparison() {
        assert_eq!(eval("3 < 4"), 1);
        assert_eq!(eval("4 < 3"), 0);
        assert_eq!(eval("3 == 3"), 1);
        assert_eq!(eval("3 != 4"), 1);
        assert_eq!(eval("3 <= 3"), 1);
        assert_eq!(eval("4 >= 5"), 0);
    }

    #[test]
    fn test_logical() {
        assert_eq!(eval("1 && 1"), 1);
        assert_eq!(eval("1 && 0"), 0);
        assert_eq!(eval("0 || 1"), 1);
        assert_eq!(eval("0 || 0"), 0);
    }

    // --- Ternary ---

    #[test]
    fn test_ternary() {
        assert_eq!(eval("1 ? 10 : 20"), 10);
        assert_eq!(eval("0 ? 10 : 20"), 20);
    }

    // --- Comma ---

    #[test]
    fn test_comma() {
        assert_eq!(eval("1, 2, 3"), 3);
    }

    // --- Parentheses ---

    #[test]
    fn test_parens() {
        assert_eq!(eval("(2 + 3) * 4"), 20);
        assert_eq!(eval("2 * (3 + 4)"), 14);
    }

    // --- Variable references ---

    #[test]
    fn test_variable_read() {
        let mut vars = Variables::new();
        vars.set("x", "7");
        assert_eq!(eval_expr("x + 1", &vars).unwrap(), 8);
    }

    // --- Assignments ---

    #[test]
    fn test_assignment() {
        let mut vars = Variables::new();
        let result = eval_mut("x = 5", &mut vars);
        assert_eq!(result, 5);
        assert_eq!(vars.get("x"), Some("5".to_owned()));
    }

    #[test]
    fn test_compound_assignment() {
        let mut vars = Variables::new();
        vars.set("x", "10");
        eval_mut("x += 5", &mut vars);
        assert_eq!(vars.get("x"), Some("15".to_owned()));
        eval_mut("x *= 2", &mut vars);
        assert_eq!(vars.get("x"), Some("30".to_owned()));
        eval_mut("x -= 10", &mut vars);
        assert_eq!(vars.get("x"), Some("20".to_owned()));
        eval_mut("x /= 4", &mut vars);
        assert_eq!(vars.get("x"), Some("5".to_owned()));
    }

    // --- Pre/postfix ---

    #[test]
    fn test_prefix_increment() {
        let mut vars = Variables::new();
        vars.set("n", "3");
        let r = eval_mut("++n", &mut vars);
        assert_eq!(r, 4);
        assert_eq!(vars.get("n"), Some("4".to_owned()));
    }

    #[test]
    fn test_postfix_increment() {
        let mut vars = Variables::new();
        vars.set("n", "3");
        let r = eval_mut("n++", &mut vars);
        assert_eq!(r, 3);                             // old value returned
        assert_eq!(vars.get("n"), Some("4".to_owned())); // but var updated
    }

    #[test]
    fn test_postfix_decrement() {
        let mut vars = Variables::new();
        vars.set("n", "5");
        let r = eval_mut("n--", &mut vars);
        assert_eq!(r, 5);
        assert_eq!(vars.get("n"), Some("4".to_owned()));
    }

    #[test]
    fn test_assoc_single_quoted_subscript_stays_literal() {
        let mut vars = Variables::new();
        vars.declare_assoc("assoc");
        vars.set("key", "x],b[$(echo uname >&2)");

        eval_expr_mut("assoc['$key']++", &mut vars).expect("single-quoted assoc increment");

        assert_eq!(vars.get_assoc("assoc", "$key"), Some("1".to_owned()));
        assert_eq!(vars.get_assoc("assoc", "x],b[$(echo uname >&2)"), None);
    }

    #[test]
    fn test_assoc_double_quoted_subscript_expands() {
        let mut vars = Variables::new();
        vars.declare_assoc("assoc");
        vars.set("key", "x],b[$(echo uname >&2)");

        eval_expr_mut("assoc[\"$key\"]++", &mut vars).expect("double-quoted assoc increment");

        assert_eq!(
            vars.get_assoc("assoc", "x],b[$(echo uname >&2)"),
            Some("1".to_owned())
        );
        assert_eq!(vars.get_assoc("assoc", "$key"), None);
    }

    #[test]
    fn test_assoc_expand_once_single_quoted_subscript_stays_literal() {
        // In assoc_expand_once mode, subscripts are treated verbatim (the
        // caller already expanded them).  `$var` stays literal; `'$var'`
        // keeps its quotes as part of the key.
        let mut vars = Variables::new();
        vars.set("var", "']");
        vars.declare_assoc("assoc");
        vars.set_integer("assoc");

        eval_expr_mut_no_cmdsub_assoc_once("assoc[$var]=1", &mut vars)
            .expect("assoc[$var]=1");
        eval_expr_mut_no_cmdsub_assoc_once("assoc[$var]+=1", &mut vars)
            .expect("assoc[$var]+=1");
        eval_expr_mut_no_cmdsub_assoc_once("assoc['$var']++", &mut vars)
            .expect("assoc['$var']++");
        eval_expr_mut_no_cmdsub_assoc_once("assoc[$var]++", &mut vars)
            .expect("assoc[$var]++");

        // $var is literal key in assoc_expand_once mode (not expanded to "']")
        assert_eq!(vars.get_assoc("assoc", "$var"), Some("3".to_owned()));
        // '$var' (with quotes) is a separate key
        assert_eq!(vars.get_assoc("assoc", "'$var'"), Some("1".to_owned()));
    }

    // --- Error cases ---

    #[test]
    fn test_div_by_zero() {
        let vars = Variables::new();
        assert!(eval_expr("1 / 0", &vars).is_err());
    }

    #[test]
    fn test_mod_by_zero() {
        let vars = Variables::new();
        assert!(eval_expr("5 % 0", &vars).is_err());
    }

    // --- Operator precedence ---

    #[test]
    fn test_precedence() {
        assert_eq!(eval("2 + 3 * 4"), 14);       // * before +
        assert_eq!(eval("2 ** 3 ** 2"), 512);     // ** is right-associative: 2**(3**2) = 2**9
        assert_eq!(eval("10 - 2 - 3"), 5);        // left-to-right: (10-2)-3
    }
}
