//! Block-device I/O for jfsck.
//!
//! Every jfsck backend reads and writes the underlying device through
//! this one crate, which keeps the on-disk-format code free of syscalls
//! and lets the test suite inject in-memory backings. The surface is
//! intentionally tiny: read a block, write a block, flush, length.

#![forbid(unsafe_op_in_unsafe_fn)]
#![deny(clippy::pedantic, missing_docs)]
#![allow(clippy::module_name_repetitions)]

use std::fs::{File, OpenOptions};
use std::io::{Read, Seek, SeekFrom, Write};
use std::path::Path;

/// Error type returned by every [`BlockDev`] method. Wraps `io::Error`
/// plus a small tag for where a failure happened so higher layers can
/// surface actionable diagnostics without a full backtrace.
#[derive(Debug)]
pub struct IoError {
    /// Logical block offset at which the error occurred, when known.
    pub block: Option<u64>,
    /// Underlying OS error.
    pub source: std::io::Error,
    /// Human phase tag (`"read"`, `"write"`, `"flush"`, `"open"`).
    pub phase: &'static str,
}

impl std::fmt::Display for IoError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self.block {
            Some(b) => write!(f, "{} at block {}: {}", self.phase, b, self.source),
            None => write!(f, "{}: {}", self.phase, self.source),
        }
    }
}

impl std::error::Error for IoError {
    fn source(&self) -> Option<&(dyn std::error::Error + 'static)> {
        Some(&self.source)
    }
}

/// Abstract block-addressable device.
///
/// Block size is fixed at construction — callers (the fs backends) pick
/// their natural unit. ext2/3/4 uses 1 KiB, 2 KiB, or 4 KiB; FAT32 on a
/// Pi typically uses 512 B or 4 KiB. Mismatched block sizes are not a
/// concern here; pass the value from the on-disk superblock.
pub trait BlockDev {
    /// Returns the block size in bytes.
    fn block_size(&self) -> usize;

    /// Returns the total number of blocks on the device.
    fn num_blocks(&self) -> u64;

    /// Read a single block into `buf`. `buf.len()` must equal
    /// [`block_size`](Self::block_size).
    ///
    /// # Errors
    ///
    /// Returns [`IoError`] if the seek or read fails, or if the block
    /// is past the end of the device.
    fn read_block(&mut self, block: u64, buf: &mut [u8]) -> Result<(), IoError>;

    /// Write a single block from `buf`. `buf.len()` must equal
    /// [`block_size`](Self::block_size).
    ///
    /// # Errors
    ///
    /// Returns [`IoError`] if the seek, write, or flush fails, or the
    /// block is past the end of the device.
    fn write_block(&mut self, block: u64, buf: &[u8]) -> Result<(), IoError>;

    /// Flush any buffered writes to the underlying device.
    ///
    /// # Errors
    ///
    /// Returns [`IoError`] on I/O failure.
    fn flush(&mut self) -> Result<(), IoError>;

    /// Read arbitrary bytes at an arbitrary device offset. This is the
    /// "escape hatch" used by filesystem backends whose on-disk block
    /// size doesn't match the device's block size — e.g. an ext4 image
    /// with 1 KiB fs blocks opened through a 512-byte sector device.
    ///
    /// The default implementation is provided in terms of
    /// [`read_block`](Self::read_block) but implementations that can
    /// service partial reads directly (e.g. `FileDev` via `pread`)
    /// should override it for speed.
    ///
    /// # Errors
    ///
    /// Returns [`IoError`] if any underlying block read fails or the
    /// request would cross the end of the device.
    fn read_at(&mut self, offset: u64, buf: &mut [u8]) -> Result<(), IoError> {
        let bs = self.block_size() as u64;
        if bs == 0 {
            return Err(IoError {
                block: None,
                source: std::io::Error::from(std::io::ErrorKind::InvalidInput),
                phase: "read",
            });
        }
        let mut cur = offset;
        let mut out_idx = 0usize;
        let end = offset + buf.len() as u64;
        let mut block_buf = vec![0u8; self.block_size()];
        while cur < end {
            let block = cur / bs;
            let within = (cur % bs) as usize;
            self.read_block(block, &mut block_buf)?;
            let copy = std::cmp::min((end - cur) as usize, self.block_size() - within);
            buf[out_idx..out_idx + copy].copy_from_slice(&block_buf[within..within + copy]);
            cur += copy as u64;
            out_idx += copy;
        }
        Ok(())
    }

    /// Write arbitrary bytes at an arbitrary device offset. Mirror of
    /// [`read_at`] for the write side. Default implementation uses a
    /// read-modify-write loop through [`read_block`] / [`write_block`];
    /// `FileDev` overrides with a direct `seek` + `write_all`.
    ///
    /// # Errors
    ///
    /// Returns [`IoError`] on any underlying block failure, or
    /// `PermissionDenied` wrapped if the device was opened read-only.
    fn write_at(&mut self, offset: u64, buf: &[u8]) -> Result<(), IoError> {
        let bs = self.block_size() as u64;
        if bs == 0 {
            return Err(IoError {
                block: None,
                source: std::io::Error::from(std::io::ErrorKind::InvalidInput),
                phase: "write",
            });
        }
        let mut cur = offset;
        let mut in_idx = 0usize;
        let end = offset + buf.len() as u64;
        let mut block_buf = vec![0u8; self.block_size()];
        while cur < end {
            let block = cur / bs;
            let within = (cur % bs) as usize;
            let copy = std::cmp::min((end - cur) as usize, self.block_size() - within);
            // Only need to read-modify-write when we're not overwriting
            // a full block. Full-block writes can skip the read.
            if within != 0 || copy != self.block_size() {
                self.read_block(block, &mut block_buf)?;
            }
            block_buf[within..within + copy].copy_from_slice(&buf[in_idx..in_idx + copy]);
            self.write_block(block, &block_buf)?;
            cur += copy as u64;
            in_idx += copy;
        }
        Ok(())
    }
}

/// Simple file-backed [`BlockDev`]. Works on a real block device (SD
/// card partition, loop device, etc.) or on a regular file holding a
/// filesystem image — the kernel handles both identically via `read`
/// and `pread`.
pub struct FileDev {
    file: File,
    block_size: usize,
    num_blocks: u64,
    read_only: bool,
}

impl FileDev {
    /// Open a block device or filesystem image at `path` with the given
    /// block size. `read_only` maps to `O_RDONLY` versus `O_RDWR`.
    ///
    /// # Errors
    ///
    /// Returns [`IoError`] if the open or metadata lookup fails.
    pub fn open(path: &Path, block_size: usize, read_only: bool) -> Result<Self, IoError> {
        let file = OpenOptions::new()
            .read(true)
            .write(!read_only)
            .open(path)
            .map_err(|e| IoError { block: None, source: e, phase: "open" })?;
        let meta = file
            .metadata()
            .map_err(|e| IoError { block: None, source: e, phase: "open" })?;
        // Regular files: metadata.len() is the size. **Block devices
        // are different**: on Linux `stat()` of a block-device FD
        // returns st_size = 0 because the "size" lives behind
        // BLKGETSIZE64 and isn't an stat field. `seek(SeekFrom::End)`
        // does work on block devices though — the kernel reports the
        // device length that way. Try the cheap path first, fall back
        // to seek-to-end.
        let mut total = meta.len();
        if total == 0 {
            let mut f = file.try_clone()
                .map_err(|e| IoError { block: None, source: e, phase: "open" })?;
            total = f.seek(SeekFrom::End(0))
                .map_err(|e| IoError { block: None, source: e, phase: "open" })?;
            f.seek(SeekFrom::Start(0))
                .map_err(|e| IoError { block: None, source: e, phase: "open" })?;
        }
        let num_blocks = total / block_size as u64;
        Ok(Self { file, block_size, num_blocks, read_only })
    }

    /// Returns `true` if the device was opened read-only.
    #[must_use]
    pub fn is_read_only(&self) -> bool {
        self.read_only
    }
}

impl BlockDev for FileDev {
    fn block_size(&self) -> usize { self.block_size }
    fn num_blocks(&self) -> u64 { self.num_blocks }

    fn read_block(&mut self, block: u64, buf: &mut [u8]) -> Result<(), IoError> {
        assert_eq!(buf.len(), self.block_size, "buf size must equal block_size");
        if block >= self.num_blocks {
            return Err(IoError {
                block: Some(block),
                source: std::io::Error::from(std::io::ErrorKind::UnexpectedEof),
                phase: "read",
            });
        }
        let offset = block * self.block_size as u64;
        self.file.seek(SeekFrom::Start(offset))
            .map_err(|e| IoError { block: Some(block), source: e, phase: "read" })?;
        self.file.read_exact(buf)
            .map_err(|e| IoError { block: Some(block), source: e, phase: "read" })
    }

    fn write_block(&mut self, block: u64, buf: &[u8]) -> Result<(), IoError> {
        assert_eq!(buf.len(), self.block_size, "buf size must equal block_size");
        if self.read_only {
            return Err(IoError {
                block: Some(block),
                source: std::io::Error::from(std::io::ErrorKind::PermissionDenied),
                phase: "write",
            });
        }
        if block >= self.num_blocks {
            return Err(IoError {
                block: Some(block),
                source: std::io::Error::from(std::io::ErrorKind::UnexpectedEof),
                phase: "write",
            });
        }
        let offset = block * self.block_size as u64;
        self.file.seek(SeekFrom::Start(offset))
            .map_err(|e| IoError { block: Some(block), source: e, phase: "write" })?;
        self.file.write_all(buf)
            .map_err(|e| IoError { block: Some(block), source: e, phase: "write" })
    }

    fn flush(&mut self) -> Result<(), IoError> {
        self.file
            .flush()
            .and_then(|_| self.file.sync_data())
            .map_err(|e| IoError { block: None, source: e, phase: "flush" })
    }

    fn read_at(&mut self, offset: u64, buf: &mut [u8]) -> Result<(), IoError> {
        // File-backed devices can service any byte-range read directly
        // via seek + read_exact; we don't need to paginate through
        // block reads. Much faster on images with small fs block size.
        self.file
            .seek(SeekFrom::Start(offset))
            .map_err(|e| IoError { block: None, source: e, phase: "read" })?;
        self.file
            .read_exact(buf)
            .map_err(|e| IoError { block: None, source: e, phase: "read" })
    }

    fn write_at(&mut self, offset: u64, buf: &[u8]) -> Result<(), IoError> {
        if self.read_only {
            return Err(IoError {
                block: None,
                source: std::io::Error::from(std::io::ErrorKind::PermissionDenied),
                phase: "write",
            });
        }
        self.file
            .seek(SeekFrom::Start(offset))
            .map_err(|e| IoError { block: None, source: e, phase: "write" })?;
        self.file
            .write_all(buf)
            .map_err(|e| IoError { block: None, source: e, phase: "write" })
    }
}

/// In-memory device backing, used by the test suite. Not exposed to
/// the binary crates.
#[cfg(test)]
pub(crate) struct MemDev {
    bytes: Vec<u8>,
    block_size: usize,
}

#[cfg(test)]
impl MemDev {
    pub(crate) fn new(size: usize, block_size: usize) -> Self {
        Self { bytes: vec![0u8; size], block_size }
    }
}

#[cfg(test)]
impl BlockDev for MemDev {
    fn block_size(&self) -> usize { self.block_size }
    fn num_blocks(&self) -> u64 { (self.bytes.len() / self.block_size) as u64 }
    fn read_block(&mut self, block: u64, buf: &mut [u8]) -> Result<(), IoError> {
        let off = block as usize * self.block_size;
        buf.copy_from_slice(&self.bytes[off..off + self.block_size]);
        Ok(())
    }
    fn write_block(&mut self, block: u64, buf: &[u8]) -> Result<(), IoError> {
        let off = block as usize * self.block_size;
        self.bytes[off..off + self.block_size].copy_from_slice(buf);
        Ok(())
    }
    fn flush(&mut self) -> Result<(), IoError> { Ok(()) }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn mem_roundtrip() {
        let mut d = MemDev::new(4096, 512);
        let mut buf = vec![0u8; 512];
        buf[0] = 0xab;
        buf[511] = 0xcd;
        d.write_block(3, &buf).unwrap();
        let mut read = vec![0u8; 512];
        d.read_block(3, &mut read).unwrap();
        assert_eq!(read[0], 0xab);
        assert_eq!(read[511], 0xcd);
    }
}
