//! `jfsck` — top-level filesystem checker dispatcher.
//!
//! Looks at the filesystem type (from `-t <type>`, or auto-detected
//! by peeking at the device) and runs the matching backend. This is
//! the direct analogue of the `fsck` driver from util-linux, scoped
//! to exactly the filesystems a Raspberry Pi uses: ext2/3/4 on the
//! root partition and FAT32 on `/boot`.
//!
//! When invoked as `fsck.ext4`, `fsck.vfat`, etc. (via symlink), the
//! backend is chosen from argv[0] — no `-t` required. That matches
//! the calling convention `mount -a` and `systemd-fsck@.service`
//! expect.

use std::path::{Path, PathBuf};
use std::process::ExitCode;

/// Program version; kept in sync with the workspace version so a
/// single `cargo pkgid` query tells everything.
const VERSION: &str = env!("CARGO_PKG_VERSION");

#[derive(Debug, Default)]
struct Args {
    fs_type: Option<String>,
    device: Option<PathBuf>,
    /// `-n`: no-op / read-only. Nothing on disk is modified.
    no_action: bool,
    /// `-y`: assume yes to all prompts. Implies repair.
    assume_yes: bool,
    /// `-V`: show version and exit.
    show_version: bool,
    /// `-h`: show help and exit.
    show_help: bool,
    /// `-f`: force check even if filesystem is marked clean.
    force: bool,
}

fn usage() {
    eprintln!("Usage: jfsck [-t <type>] [-n|-y] [-f] [-V] <device>");
    eprintln!();
    eprintln!("  -t <type>   Filesystem type (ext2, ext3, ext4, vfat, fat, msdos)");
    eprintln!("              Defaults to detection or argv[0] suffix.");
    eprintln!("  -n          Read-only / no-action mode (report only).");
    eprintln!("  -y          Assume yes to all prompts (implies repair).");
    eprintln!("  -f          Force check even if filesystem is marked clean.");
    eprintln!("  -V          Show version and exit.");
    eprintln!();
    eprintln!("Exit codes (e2fsck-compatible):");
    eprintln!("  0           No errors.");
    eprintln!("  1           Errors corrected.");
    eprintln!("  4           Errors left uncorrected.");
    eprintln!("  8           Operational error.");
    eprintln!("  16          Usage or syntax error.");
}

fn parse_args() -> Result<Args, ()> {
    let mut a = Args::default();
    let mut it = std::env::args().skip(1).peekable();
    while let Some(arg) = it.next() {
        match arg.as_str() {
            "-h" | "--help" => { a.show_help = true; }
            "-V" | "--version" => { a.show_version = true; }
            "-n" => { a.no_action = true; }
            "-y" => { a.assume_yes = true; }
            "-f" => { a.force = true; }
            "-t" => {
                let v = it.next().ok_or_else(|| eprintln!("-t requires an argument"))?;
                a.fs_type = Some(v);
            }
            s if s.starts_with('-') => {
                eprintln!("unknown option: {}", s);
                return Err(());
            }
            _ => {
                if a.device.is_some() {
                    eprintln!("jfsck: one device at a time for now");
                    return Err(());
                }
                a.device = Some(PathBuf::from(arg));
            }
        }
    }
    Ok(a)
}

/// If argv[0] looks like `fsck.<type>`, return `<type>`.
fn fs_type_from_argv0() -> Option<String> {
    let argv0 = std::env::args().next()?;
    let stem = Path::new(&argv0).file_name()?.to_string_lossy().into_owned();
    stem.strip_prefix("fsck.")
        .or_else(|| stem.strip_prefix("jfsck."))
        .map(|s| s.to_string())
}

/// Backend dispatch. `fs_type` is already lowercased.
fn run_backend(fs_type: &str, device: &Path, no_action: bool, repair: bool) -> i32 {
    match fs_type {
        "ext2" | "ext3" | "ext4" => run_ext(device, no_action, repair),
        "vfat" | "fat" | "msdos" | "fat32" => run_fat(device, no_action, repair),
        other => {
            eprintln!("jfsck: unsupported filesystem type '{}'", other);
            eprintln!("       supported: ext2, ext3, ext4, vfat, fat, msdos");
            16
        }
    }
}

fn run_ext(device: &Path, no_action: bool, repair: bool) -> i32 {
    // -n always overrides -y: a read-only check request wins. Otherwise
    // open writable when repair was requested so journal replay can
    // actually write back.
    let read_only = no_action || !repair;
    let mut dev = match jfsck_io::FileDev::open(device, 4096, read_only) {
        Ok(d) => d,
        Err(e) => { eprintln!("jfsck: open {}: {}", device.display(), e); return 8; }
    };
    let report = if repair && !no_action {
        match jfsck_ext::check_and_repair(&mut dev) {
            Ok(r) => r,
            Err(e) => { eprintln!("jfsck: ext4 repair: {}", e); return 8; }
        }
    } else {
        match jfsck_ext::check_ro(&mut dev) {
            Ok(r) => r,
            Err(e) => { eprintln!("jfsck: ext4 check: {}", e); return 8; }
        }
    };
    print_ext_report(&report);
    // e2fsck returns 1 when it corrected something, 4 when there are
    // errors it didn't/couldn't fix. Repair paths we currently run:
    // journal replay and orphan inode cleanup. Either firing counts
    // as "errors corrected".
    let repaired = report.findings().iter().any(|f| {
        matches!(f.kind, "journal_replayed" | "orphan_cleanup_complete")
    });
    if repaired && report.exit_code() <= 4 {
        1
    } else {
        report.exit_code()
    }
}

fn run_fat(device: &Path, no_action: bool, repair: bool) -> i32 {
    let read_only = no_action || !repair;
    let mut dev = match jfsck_io::FileDev::open(device, 512, read_only) {
        Ok(d) => d,
        Err(e) => { eprintln!("jfsck: open {}: {}", device.display(), e); return 8; }
    };
    let report = if repair && !no_action {
        match jfsck_fat::check_and_repair(&mut dev) {
            Ok(r) => r,
            Err(e) => { eprintln!("jfsck: fat repair: {}", e); return 8; }
        }
    } else {
        match jfsck_fat::check_ro(&mut dev) {
            Ok(r) => r,
            Err(e) => { eprintln!("jfsck: fat check: {}", e); return 8; }
        }
    };
    print_fat_report(&report);
    // Same exit-code contract as the ext backend: 1 when we actually
    // fixed something, otherwise pass through.
    let repaired = report.findings().iter().any(|f| {
        matches!(f.kind,
            "fat_mirror_reconciled"
            | "lost_clusters_freed"
            | "fsinfo_updated"
            | "fat_repair_complete"
        )
    });
    if repaired && report.exit_code() <= 4 { 1 } else { report.exit_code() }
}

fn print_ext_report(r: &jfsck_ext::Report) {
    let findings = r.findings();
    if findings.is_empty() {
        println!("jfsck: clean");
        return;
    }
    for f in findings {
        println!("[{:?}] {}: {}", f.severity, f.kind, f.detail);
    }
}

fn print_fat_report(r: &jfsck_fat::Report) {
    let findings = r.findings();
    if findings.is_empty() {
        println!("jfsck: clean");
        return;
    }
    for f in findings {
        println!("[{:?}] {}: {}", f.severity, f.kind, f.detail);
    }
}

fn main() -> ExitCode {
    let args = match parse_args() {
        Ok(a) => a,
        Err(()) => { usage(); return ExitCode::from(16); }
    };
    if args.show_help { usage(); return ExitCode::from(0); }
    if args.show_version {
        println!("jfsck {} — clean-room BSD-2-Clause fsck for Raspberry Pi", VERSION);
        return ExitCode::from(0);
    }
    let Some(device) = args.device else {
        usage();
        return ExitCode::from(16);
    };

    let fs_type = args
        .fs_type
        .or_else(fs_type_from_argv0)
        .unwrap_or_else(|| "ext4".to_string())
        .to_lowercase();

    let code = run_backend(&fs_type, &device, args.no_action, args.assume_yes);
    ExitCode::from(u8::try_from(code).unwrap_or(8))
}
