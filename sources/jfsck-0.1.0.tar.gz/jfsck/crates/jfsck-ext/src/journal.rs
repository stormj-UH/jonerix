//! JBD2 journal — detection and structural inspection.
//!
//! ext3 and ext4 use a journaling layer called **JBD** (or **JBD2**
//! for ext4). The journal lives inside a reserved inode of the
//! filesystem itself (conventionally inode 8, addressed by
//! `s_journal_inum` in the superblock) and records pending metadata
//! updates so they can be replayed after an unclean shutdown.
//!
//! The dominant real-world Pi case is: power cut while the filesystem
//! was doing something. On next boot the kernel replays the journal
//! before mounting, bringing metadata back to a consistent state. If
//! the kernel didn't get a chance to replay (mount with `noload`,
//! partial kernel init, etc.), `fsck` has to do it.
//!
//! This module implements **Phase 2.a**: detect that replay is
//! needed, parse the journal header, and report what's outstanding.
//! Actually applying a replay (writing metadata blocks back from
//! journal content) is **Phase 2.b**, gated behind a writable mount.
//!
//! ## JBD2 on-disk layout
//!
//! Journal block 0 is the journal superblock (not to be confused with
//! the ext filesystem superblock). It's 1024 bytes, all big-endian
//! (yes — the one place in ext4 where fields are stored BE), with
//! the following fields we care about:
//!
//!   h_magic       0xc03b3998
//!   h_blocktype   4 = journal superblock v2
//!   s_blocksize   block size used by the journal (typically fs blocksize)
//!   s_maxlen      total blocks in the journal
//!   s_first       first block of log (right after this SB)
//!   s_sequence    first valid sequence number to replay
//!   s_start       first block of outstanding transaction; 0 = clean

use crate::superblock::{Superblock, feature};
use crate::{Finding, Severity, Report};
use jfsck_io::BlockDev;

/// Journal superblock magic. Note big-endian on disk — we compare
/// after `from_be_bytes`.
pub const JBD2_MAGIC: u32 = 0xc03b_3998;

/// Minimum journal block type we understand (JBD2 v2 superblock).
pub const JBD2_SB_V2_BLOCKTYPE: u32 = 4;
/// Older JBD v1 superblock; also valid.
pub const JBD2_SB_V1_BLOCKTYPE: u32 = 3;

/// Parsed journal superblock (the subset jfsck cares about).
#[derive(Debug, Clone)]
pub struct JournalSuper {
    /// Magic — must be [`JBD2_MAGIC`].
    pub magic: u32,
    /// 3 = v1 (no checksums), 4 = v2 (with feature flags).
    pub blocktype: u32,
    /// Block size the journal uses (bytes).
    pub blocksize: u32,
    /// Total blocks in the journal.
    pub maxlen: u32,
    /// First log block (right after this superblock).
    pub first: u32,
    /// Sequence of first outstanding transaction; 0 means clean.
    pub sequence: u32,
    /// First block of oldest outstanding transaction; 0 means clean.
    pub start: u32,
}

impl JournalSuper {
    /// True if the journal has recorded uncommitted work. A clean
    /// journal has `start == 0`.
    #[must_use]
    pub fn needs_replay(&self) -> bool {
        self.start != 0
    }
}

/// Fetch the block-pointer list from an inode's `i_block[0..60]`.
/// For a non-extents journal inode this is 15 × 4-byte pointers,
/// which for a small journal (typical up to 128 MiB) covers every
/// block directly or via one indirect block.
///
/// The journal inode is almost always large enough to require extents
/// on modern ext4. Handle both: if extent magic is present we walk
/// the extent tree's leaf; otherwise we use the direct/indirect
/// pointers.
fn journal_first_block_of_file(
    inode_block: &[u8; 60],
) -> Option<u64> {
    let magic = u16::from_le_bytes([inode_block[0], inode_block[1]]);
    if magic == crate::inode::EXT4_EXTENT_MAGIC {
        // ext4_extent_header: magic(2) entries(2) max(2) depth(2) gen(4)
        // followed by `entries` × 12-byte ext4_extent records.
        //
        // A leaf extent layout:
        //   le32 ee_block  (logical block in file)
        //   le16 ee_len
        //   le16 ee_start_hi
        //   le32 ee_start_lo
        //
        // We take the first leaf extent's ee_start and assume the
        // journal occupies a contiguous range (true for every
        // journal emitted by mke2fs). Depth > 0 trees are handled
        // later; they're rare for journal files under 128 MiB.
        // Extent header layout:
        //   +0  eh_magic (u16)
        //   +2  eh_entries (u16)
        //   +4  eh_max (u16)   ← not depth!
        //   +6  eh_depth (u16)
        //   +8  eh_generation (u32)
        let entries = u16::from_le_bytes([inode_block[2], inode_block[3]]);
        let depth = u16::from_le_bytes([inode_block[6], inode_block[7]]);
        if depth != 0 || entries == 0 {
            return None;
        }
        // First extent sits at offset 12 within i_block.
        let ext = &inode_block[12..12 + 12];
        let ee_start_hi = u16::from_le_bytes([ext[6], ext[7]]);
        let ee_start_lo = u32::from_le_bytes([ext[8], ext[9], ext[10], ext[11]]);
        Some((u64::from(ee_start_hi) << 32) | u64::from(ee_start_lo))
    } else {
        // Legacy: i_block[0] is the first direct block pointer.
        let b = u32::from_le_bytes([inode_block[0], inode_block[1], inode_block[2], inode_block[3]]);
        if b == 0 { None } else { Some(u64::from(b)) }
    }
}

/// Read the inode struct for the journal, then follow its first
/// block pointer to fetch the journal superblock.
///
/// # Errors
///
/// Propagates device I/O errors.
pub fn read_journal_super<D: BlockDev>(
    dev: &mut D,
    sb: &Superblock,
    journal_inode_no: u32,
) -> Result<Option<JournalSuper>, Box<dyn std::error::Error>> {
    // Locate the inode. inode_no starts at 1; divide into its group
    // and offset within the inode table.
    let ino = u64::from(journal_inode_no);
    let group_idx = (ino - 1) / u64::from(sb.inodes_per_group);
    let offset_in_group = (ino - 1) % u64::from(sb.inodes_per_group);

    // We need the group descriptor for `group_idx`. Re-read just that
    // entry from the GDT rather than depending on the full walker.
    let desc_size = if sb.feature_incompat & feature::INCOMPAT_64BIT != 0 && sb.desc_size >= 32 {
        sb.desc_size
    } else {
        32
    };
    let block_size = sb.block_size();
    let gdt_start_block = if block_size == 1024 { 2 } else { 1 };
    let gdt_byte_off =
        gdt_start_block * block_size + group_idx * u64::from(desc_size);

    let mut gd_buf = vec![0u8; desc_size as usize];
    dev.read_at(gdt_byte_off, &mut gd_buf)?;
    let gd = crate::group::GroupDesc::parse(&gd_buf, desc_size);

    // Read the inode.
    let isize = u64::from(sb.inode_size.max(128));
    let inode_byte_off = gd.inode_table * block_size + offset_in_group * isize;
    let mut ibuf = vec![0u8; isize as usize];
    dev.read_at(inode_byte_off, &mut ibuf)?;
    let ino_struct = crate::inode::parse(&ibuf);

    let Some(first_block) = journal_first_block_of_file(&ino_struct.i_block) else {
        return Ok(None);
    };

    // Journal superblock lives at the first byte of the first
    // journal block, whatever the journal's own blocksize is.
    // Since the journal blocksize is normally the fs blocksize, we
    // just use that; mismatch is a phase-3 edge case.
    let mut jb = vec![0u8; 1024];
    dev.read_at(first_block * block_size, &mut jb)?;
    Ok(Some(parse(&jb)))
}

/// Parse a 1024-byte journal superblock buffer. JBD2 fields are
/// **big-endian** on disk.
#[must_use]
pub fn parse(b: &[u8]) -> JournalSuper {
    JournalSuper {
        magic:     u32_be(b, 0x00),
        blocktype: u32_be(b, 0x04),
        blocksize: u32_be(b, 0x0c),
        maxlen:    u32_be(b, 0x10),
        first:     u32_be(b, 0x14),
        sequence:  u32_be(b, 0x18),
        start:     u32_be(b, 0x1c),
    }
}

/// Inspect the journal and report what's outstanding.
///
/// If the filesystem has no journal (`!feature_compat.HAS_JOURNAL`),
/// this is a no-op. Otherwise we fetch the journal superblock and
/// report whether replay is needed.
///
/// # Errors
///
/// Propagates device I/O errors.
pub fn inspect<D: BlockDev>(
    dev: &mut D,
    sb: &Superblock,
    report: &mut Report,
) -> Result<(), Box<dyn std::error::Error>> {
    if sb.feature_compat & feature::COMPAT_HAS_JOURNAL == 0 {
        return Ok(());
    }

    // NEEDS_RECOVER is the kernel's signal that the journal had
    // outstanding work at the last unmount. Our own journal SB
    // check below is the authoritative answer; NEEDS_RECOVER is a
    // hint that lets us trigger replay without parsing first.
    let needs_recover = sb.feature_incompat & feature::INCOMPAT_RECOVER != 0;
    if needs_recover {
        report.push(Finding {
            severity: Severity::Warn,
            kind: "needs_journal_recovery",
            detail: "INCOMPAT_RECOVER set: journal replay required before clean mount".into(),
        });
    }

    // `s_journal_inum` lives at offset 0xe0 in the ext2/3/4 superblock;
    // we didn't parse it in Superblock yet, so re-read that field
    // directly. An 8 is the e2fsprogs default.
    let mut sb_bytes = [0u8; 1024];
    dev.read_at(1024, &mut sb_bytes)?;
    let journal_inum = u32::from_le_bytes([
        sb_bytes[0xe0], sb_bytes[0xe1], sb_bytes[0xe2], sb_bytes[0xe3],
    ]);
    if journal_inum == 0 {
        report.push(Finding {
            severity: Severity::Warn,
            kind: "has_journal_but_no_inode",
            detail: "HAS_JOURNAL set but s_journal_inum is 0".into(),
        });
        return Ok(());
    }

    let jsb = match read_journal_super(dev, sb, journal_inum)? {
        Some(j) => j,
        None => {
            report.push(Finding {
                severity: Severity::Error,
                kind: "journal_block_not_found",
                detail: format!("journal inode {} has no resolvable data block", journal_inum),
            });
            return Ok(());
        }
    };

    if jsb.magic != JBD2_MAGIC {
        report.push(Finding {
            severity: Severity::Error,
            kind: "bad_journal_magic",
            detail: format!("journal superblock magic {:#010x}, expected {:#010x}",
                            jsb.magic, JBD2_MAGIC),
        });
        return Ok(());
    }

    if jsb.blocktype != JBD2_SB_V1_BLOCKTYPE && jsb.blocktype != JBD2_SB_V2_BLOCKTYPE {
        report.push(Finding {
            severity: Severity::Error,
            kind: "bad_journal_blocktype",
            detail: format!("journal superblock blocktype {}, expected 3 or 4", jsb.blocktype),
        });
        return Ok(());
    }

    if jsb.needs_replay() {
        report.push(Finding {
            severity: Severity::Error,
            kind: "journal_replay_pending",
            detail: format!(
                "journal has outstanding transactions: start block {}, sequence {}",
                jsb.start, jsb.sequence,
            ),
        });
    } else if !needs_recover {
        // Both the inode-flag and the journal itself agree: clean.
        // Nothing to report.
    }

    Ok(())
}

fn u32_be(b: &[u8], off: usize) -> u32 {
    u32::from_be_bytes([b[off], b[off + 1], b[off + 2], b[off + 3]])
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn clean_journal_detected() {
        let mut b = [0u8; 1024];
        b[0..4].copy_from_slice(&JBD2_MAGIC.to_be_bytes());
        b[4..8].copy_from_slice(&4u32.to_be_bytes());  // v2
        b[0x0c..0x10].copy_from_slice(&4096u32.to_be_bytes());
        b[0x10..0x14].copy_from_slice(&32768u32.to_be_bytes());
        b[0x14..0x18].copy_from_slice(&1u32.to_be_bytes());
        // start=0 → clean
        let j = parse(&b);
        assert_eq!(j.magic, JBD2_MAGIC);
        assert!(!j.needs_replay());
    }

    #[test]
    fn dirty_journal_detected() {
        let mut b = [0u8; 1024];
        b[0..4].copy_from_slice(&JBD2_MAGIC.to_be_bytes());
        b[0x1c..0x20].copy_from_slice(&5u32.to_be_bytes()); // start != 0
        let j = parse(&b);
        assert!(j.needs_replay());
    }
}
