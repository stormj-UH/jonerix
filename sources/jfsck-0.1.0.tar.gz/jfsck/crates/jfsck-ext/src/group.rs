//! Block group descriptors.
//!
//! After the superblock, an ext filesystem is divided into block
//! groups of `s_blocks_per_group` blocks each. A group descriptor
//! table — one entry per group — records where each group's block
//! bitmap, inode bitmap, and inode table live, plus running counts
//! of free blocks, free inodes, and used directories.
//!
//! On-disk entry size is 32 bytes for ext2/3 and for ext4 without
//! INCOMPAT_64BIT; 64 bytes once 64BIT is set (the extra half holds
//! the `_hi` extensions to every address and count field plus a
//! few bitmap-checksum fields). `s_desc_size` in the superblock is
//! the authoritative width; we honour it rather than the feature bit.
//!
//! Group descriptor tables live in the blocks immediately following
//! the superblock block: for 1 KiB block size, blocks 1..=N; for >=2
//! KiB block size, blocks 1..=N where block 0 already contains the
//! superblock. `sparse_super` places backup copies of the GDT at
//! groups 0, 1, 3^n, 5^n, 7^n — we read only the primary here.

use crate::{Finding, Severity, Report};
use crate::superblock::{Superblock, feature};
use jfsck_io::BlockDev;

/// Parsed group descriptor in host byte order. Fields are named to
/// mirror the kernel UAPI with the `bg_` prefix dropped.
#[derive(Debug, Clone)]
pub struct GroupDesc {
    /// Starting block of this group's block bitmap.
    pub block_bitmap: u64,
    /// Starting block of this group's inode bitmap.
    pub inode_bitmap: u64,
    /// First block of this group's inode table.
    pub inode_table: u64,
    /// Free blocks in this group.
    pub free_blocks_count: u32,
    /// Free inodes in this group.
    pub free_inodes_count: u32,
    /// Directories in this group.
    pub used_dirs_count: u32,
    /// Flags: bit 0 = INODE_UNINIT, bit 1 = BLOCK_UNINIT, bit 2 = ITABLE_ZEROED.
    pub flags: u16,
    /// crc16 of the descriptor itself (legacy GDT_CSUM algorithm).
    pub checksum: u16,
}

/// Group descriptor flags (`bg_flags`).
pub mod gd_flag {
    /// Inode table unused entries need no scanning.
    pub const INODE_UNINIT: u16 = 0x0001;
    /// Block bitmap is all-free; not yet materialised.
    pub const BLOCK_UNINIT: u16 = 0x0002;
    /// Inode table has been zeroed (ext4 fast-init).
    pub const ITABLE_ZEROED: u16 = 0x0004;
}

impl GroupDesc {
    /// Parse a single descriptor from raw bytes. Accepts 32- or
    /// 64-byte `buf` depending on `desc_size`.
    #[must_use]
    pub fn parse(buf: &[u8], desc_size: u16) -> Self {
        // 32-byte fields (always present).
        let block_bitmap_lo     = u32_le(buf, 0x00);
        let inode_bitmap_lo     = u32_le(buf, 0x04);
        let inode_table_lo      = u32_le(buf, 0x08);
        let free_blocks_lo      = u16_le(buf, 0x0c);
        let free_inodes_lo      = u16_le(buf, 0x0e);
        let used_dirs_lo        = u16_le(buf, 0x10);
        let flags               = u16_le(buf, 0x12);
        let checksum            = u16_le(buf, 0x1e);

        // 64-byte fields (only when desc_size >= 64 AND 64BIT feature).
        let (block_bitmap_hi, inode_bitmap_hi, inode_table_hi,
             free_blocks_hi,  free_inodes_hi,  used_dirs_hi) =
            if desc_size >= 64 && buf.len() >= 64 {
                (
                    u32_le(buf, 0x20),
                    u32_le(buf, 0x24),
                    u32_le(buf, 0x28),
                    u16_le(buf, 0x2c),
                    u16_le(buf, 0x2e),
                    u16_le(buf, 0x30),
                )
            } else {
                (0, 0, 0, 0, 0, 0)
            };

        GroupDesc {
            block_bitmap: (u64::from(block_bitmap_hi) << 32) | u64::from(block_bitmap_lo),
            inode_bitmap: (u64::from(inode_bitmap_hi) << 32) | u64::from(inode_bitmap_lo),
            inode_table:  (u64::from(inode_table_hi)  << 32) | u64::from(inode_table_lo),
            free_blocks_count:
                (u32::from(free_blocks_hi) << 16) | u32::from(free_blocks_lo),
            free_inodes_count:
                (u32::from(free_inodes_hi) << 16) | u32::from(free_inodes_lo),
            used_dirs_count:
                (u32::from(used_dirs_hi) << 16) | u32::from(used_dirs_lo),
            flags,
            checksum,
        }
    }

    /// Validate this descriptor against the superblock. `group_idx` is
    /// the group's index (0-based) within the filesystem.
    pub fn validate(&self, group_idx: u64, sb: &Superblock, report: &mut Report) {
        let bpg = u64::from(sb.blocks_per_group);
        let first = u64::from(sb.first_data_block) + group_idx * bpg;
        // Last block in the group (inclusive). The final group is
        // potentially short; we clamp against the total block count.
        let last = std::cmp::min(first + bpg - 1, sb.blocks_count().saturating_sub(1));

        // BLOCK_UNINIT groups don't materialise their block bitmap;
        // skip the range check for that slot in that case.
        let skip_block_bitmap  = self.flags & gd_flag::BLOCK_UNINIT != 0;
        let skip_inode_bitmap  = self.flags & gd_flag::INODE_UNINIT != 0;

        // `flex_bg` pools multiple groups' bitmaps and inode tables
        // into a single "leader" group. When this feature is on, the
        // per-group in-range check is wrong: group N's bitmap may
        // legitimately live inside group 0's block range. We fall back
        // to a device-wide range check (handled below via
        // `inode_table_overrun`-style overflow) and skip the strict
        // per-group assertion. See docs/ext4-notes.md §flex_bg.
        let flex_bg =
            sb.feature_incompat & crate::superblock::feature::INCOMPAT_FLEX_BG != 0;

        if !skip_block_bitmap && !flex_bg {
            self.check_in_group(
                "block_bitmap", group_idx, self.block_bitmap, first, last, report,
            );
        }
        if !skip_inode_bitmap && !flex_bg {
            self.check_in_group(
                "inode_bitmap", group_idx, self.inode_bitmap, first, last, report,
            );
        }
        if !flex_bg {
            // The inode table always exists on disk (the metadata blocks
            // are reserved even when uninitialised); validate when the
            // layout is non-flex.
            self.check_in_group(
                "inode_table", group_idx, self.inode_table, first, last, report,
            );
        }

        // Under flex_bg we still insist the inode table fits inside the
        // device at all — catches descriptor-level corruption even when
        // we can't predict which group the table lives in.
        let it_blocks = u64::from(sb.inodes_per_group) * u64::from(sb.inode_size);
        let it_blocks = it_blocks.div_ceil(sb.block_size());
        let device_last_block = sb.blocks_count().saturating_sub(1);
        if self.inode_table + it_blocks.saturating_sub(1) > device_last_block {
            report.push(Finding {
                severity: Severity::Error,
                kind: "inode_table_overrun",
                detail: format!(
                    "group {}: inode table at {} spans {} blocks, past device end {}",
                    group_idx, self.inode_table, it_blocks, device_last_block,
                ),
            });
        }

        // Free counts must be <= capacity.
        if self.free_blocks_count > sb.blocks_per_group {
            report.push(Finding {
                severity: Severity::Error,
                kind: "free_blocks_exceeds_bpg",
                detail: format!(
                    "group {}: free_blocks_count = {}, blocks_per_group = {}",
                    group_idx, self.free_blocks_count, sb.blocks_per_group,
                ),
            });
        }
        if self.free_inodes_count > sb.inodes_per_group {
            report.push(Finding {
                severity: Severity::Error,
                kind: "free_inodes_exceeds_ipg",
                detail: format!(
                    "group {}: free_inodes_count = {}, inodes_per_group = {}",
                    group_idx, self.free_inodes_count, sb.inodes_per_group,
                ),
            });
        }
    }

    fn check_in_group(
        &self, what: &'static str, group_idx: u64, block: u64,
        first: u64, last: u64, report: &mut Report,
    ) {
        if block == 0 {
            report.push(Finding {
                severity: Severity::Error,
                kind: "gd_zero_block",
                detail: format!("group {}: {} block is 0", group_idx, what),
            });
            return;
        }
        if block < first || block > last {
            report.push(Finding {
                severity: Severity::Error,
                kind: "gd_out_of_range",
                detail: format!(
                    "group {}: {} at {} outside group range [{}, {}]",
                    group_idx, what, block, first, last,
                ),
            });
        }
    }
}

/// Read and validate the entire group descriptor table.
///
/// Returns the parsed descriptors so later passes (inode table walk,
/// bitmap verification) don't have to re-read them.
///
/// # Errors
///
/// Propagates device I/O errors.
pub fn read_and_validate<D: BlockDev>(
    dev: &mut D,
    sb: &Superblock,
    report: &mut Report,
) -> Result<Vec<GroupDesc>, Box<dyn std::error::Error>> {
    // Descriptor size. Kernel honours s_desc_size when the 64BIT
    // feature is on, falls back to 32 otherwise.
    let desc_size = if sb.feature_incompat & feature::INCOMPAT_64BIT != 0
        && sb.desc_size >= 32
    {
        sb.desc_size
    } else {
        32
    };

    let groups = sb.group_count();
    let block_size = sb.block_size();
    let per_block = block_size / u64::from(desc_size);
    let gdt_blocks = (groups).div_ceil(per_block);

    // GDT starts at the block right after the superblock block. For
    // a 1 KiB filesystem the superblock lives at block 1 (after the
    // padding at 0), so GDT starts at block 2. For all larger block
    // sizes the superblock shares block 0 with the 1024-byte padding,
    // so GDT starts at block 1.
    let gdt_start = if block_size == 1024 { 2 } else { 1 };

    let mut descs = Vec::with_capacity(groups as usize);
    // Byte-level read of the whole GDT. Works whatever the device
    // sector size is; fs block size drives the layout math.
    let total_bytes = gdt_blocks * block_size;
    let gdt_offset = gdt_start * block_size;
    let mut buf = vec![0u8; total_bytes as usize];
    dev.read_at(gdt_offset, &mut buf)?;

    for bi in 0..gdt_blocks {
        let on_this_block = std::cmp::min(per_block, groups - bi * per_block);
        for di in 0..on_this_block {
            let off = (bi * block_size + di * u64::from(desc_size)) as usize;
            let end = off + usize::from(desc_size);
            if end > buf.len() {
                report.push(Finding {
                    severity: Severity::Fatal,
                    kind: "gdt_overflow",
                    detail: format!("desc_size {} doesn't fit block_size {}", desc_size, block_size),
                });
                return Ok(descs);
            }
            let gd = GroupDesc::parse(&buf[off..end], desc_size);
            let group_idx = bi * per_block + di;
            gd.validate(group_idx, sb, report);
            descs.push(gd);
        }
    }

    // Summed free counts should equal the superblock totals. Minor
    // mismatches are Warn; gross mismatches are Error. "gross" here
    // means a delta larger than a single bitmap block's worth.
    let sum_free_blocks: u64 = descs.iter().map(|g| u64::from(g.free_blocks_count)).sum();
    let sum_free_inodes: u32 = descs.iter().map(|g| g.free_inodes_count).sum();

    let sb_free_blocks =
        if sb.feature_incompat & feature::INCOMPAT_64BIT != 0 {
            (u64::from(sb.free_blocks_count_hi) << 32) | u64::from(sb.free_blocks_count_lo)
        } else {
            u64::from(sb.free_blocks_count_lo)
        };
    if sum_free_blocks != sb_free_blocks {
        let delta = sb_free_blocks.abs_diff(sum_free_blocks);
        let sev = if delta > 8 * sb.block_size() { Severity::Error } else { Severity::Warn };
        report.push(Finding {
            severity: sev,
            kind: "free_blocks_mismatch",
            detail: format!(
                "superblock free_blocks = {}, sum of group descs = {}",
                sb_free_blocks, sum_free_blocks,
            ),
        });
    }
    if sum_free_inodes != sb.free_inodes_count {
        report.push(Finding {
            severity: Severity::Warn,
            kind: "free_inodes_mismatch",
            detail: format!(
                "superblock free_inodes = {}, sum of group descs = {}",
                sb.free_inodes_count, sum_free_inodes,
            ),
        });
    }

    Ok(descs)
}

fn u16_le(b: &[u8], off: usize) -> u16 {
    u16::from_le_bytes([b[off], b[off + 1]])
}

fn u32_le(b: &[u8], off: usize) -> u32 {
    u32::from_le_bytes([b[off], b[off + 1], b[off + 2], b[off + 3]])
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parse_zero_desc() {
        let buf = [0u8; 64];
        let g = GroupDesc::parse(&buf, 64);
        assert_eq!(g.block_bitmap, 0);
        assert_eq!(g.inode_bitmap, 0);
        assert_eq!(g.inode_table, 0);
        assert_eq!(g.flags, 0);
    }

    #[test]
    fn parse_with_hi_fields() {
        let mut buf = [0u8; 64];
        // block_bitmap_lo = 100, block_bitmap_hi = 1 → total 0x1_0000_0064
        buf[0..4].copy_from_slice(&100u32.to_le_bytes());
        buf[0x20..0x24].copy_from_slice(&1u32.to_le_bytes());
        let g = GroupDesc::parse(&buf, 64);
        assert_eq!(g.block_bitmap, 0x1_0000_0064);
    }

    #[test]
    fn flag_decoding() {
        let mut buf = [0u8; 32];
        buf[0x12..0x14].copy_from_slice(&(gd_flag::BLOCK_UNINIT | gd_flag::INODE_UNINIT).to_le_bytes());
        let g = GroupDesc::parse(&buf, 32);
        assert!(g.flags & gd_flag::BLOCK_UNINIT != 0);
        assert!(g.flags & gd_flag::INODE_UNINIT != 0);
    }
}
