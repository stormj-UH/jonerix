//! Superblock parsing and self-validation.
//!
//! The superblock is the single most important structure in an ext
//! filesystem: it names every sizing constant (block size, blocks per
//! group, inodes per group, total block count) and every feature flag
//! that changes the meaning of the rest of the layout. Get this wrong
//! and nothing else matters.
//!
//! On-disk layout: the primary superblock lives at byte offset 1024
//! and is exactly 1024 bytes long. ext2 used the first ~264 bytes;
//! ext3 and ext4 grew it out to cover journal info, 64-bit block
//! fields, checksum, encryption, and so on. Fields past the end used
//! by an older filesystem are simply zero — read them and you get
//! sensible defaults.

use crate::{Finding, Severity, Report};
use jfsck_io::BlockDev;

/// `s_magic` value that identifies this as an ext2/3/4 filesystem.
pub const EXT_SUPER_MAGIC: u16 = 0xEF53;

/// Minimum block size exponent stored in `s_log_block_size`; the real
/// block size is `1024 << s_log_block_size`, so 0 → 1 KiB, 1 → 2 KiB,
/// 2 → 4 KiB, 3 → 8 KiB. 4 KiB is almost universal on a Pi.
pub const EXT_LOG_BLOCK_SIZE_MAX: u32 = 6; // up to 64 KiB

/// File-system state flags stored in `s_state`.
pub mod state {
    /// Cleanly unmounted — no journal replay or checks needed.
    pub const CLEAN: u16 = 0x0001;
    /// Errors detected — last mount saw corruption.
    pub const HAS_ERRORS: u16 = 0x0002;
    /// Orphan list is non-empty — inodes waiting for delete cleanup.
    pub const ORPHAN_FS: u16 = 0x0004;
}

/// Parsed superblock. Fields mirror the on-disk names where it helps
/// readers cross-reference the kernel header, with the `s_` prefix
/// stripped. Everything is stored in host byte order after reading.
#[derive(Debug, Clone)]
pub struct Superblock {
    // -- Core sizing (ext2 era) --
    /// Total inodes.
    pub inodes_count: u32,
    /// Total blocks (low 32 bits; see `blocks_count_hi` for ext4).
    pub blocks_count_lo: u32,
    /// Reserved blocks for the superuser (low 32).
    pub r_blocks_count_lo: u32,
    /// Free blocks (low 32).
    pub free_blocks_count_lo: u32,
    /// Free inodes.
    pub free_inodes_count: u32,
    /// First data block (always 1 for 1KiB blocks, 0 otherwise).
    pub first_data_block: u32,
    /// Block size is `1024 << log_block_size`.
    pub log_block_size: u32,
    /// Blocks per group.
    pub blocks_per_group: u32,
    /// Inodes per group.
    pub inodes_per_group: u32,
    /// Filesystem state (see [`state`] module).
    pub state: u16,
    /// Magic — must be [`EXT_SUPER_MAGIC`].
    pub magic: u16,
    /// Minor revision.
    pub minor_rev_level: u16,
    /// Major revision — 0 = original ext2, 1 = dynamic rev (separate inode size).
    pub rev_level: u32,
    /// Inode size in bytes. Always 128 on rev 0; 256 typical on ext4.
    pub inode_size: u16,

    // -- Feature bitmaps --
    /// Compat features — kernels that don't understand these can still mount.
    pub feature_compat: u32,
    /// Incompat features — kernels that don't understand these must NOT mount.
    pub feature_incompat: u32,
    /// RO-compat features — kernels that don't understand must mount read-only.
    pub feature_ro_compat: u32,

    // -- 64-bit block count extension (ext4) --
    /// Upper 32 bits of blocks_count when INCOMPAT_64BIT is set.
    pub blocks_count_hi: u32,
    /// Upper 32 bits of r_blocks_count.
    pub r_blocks_count_hi: u32,
    /// Upper 32 bits of free_blocks_count.
    pub free_blocks_count_hi: u32,

    /// Descriptor size in bytes — 32 for old, 64 for INCOMPAT_64BIT.
    pub desc_size: u16,
}

impl Superblock {
    /// Total block count, combining `_lo` and `_hi` when
    /// `INCOMPAT_64BIT` is set.
    #[must_use]
    pub fn blocks_count(&self) -> u64 {
        if self.feature_incompat & feature::INCOMPAT_64BIT != 0 {
            (u64::from(self.blocks_count_hi) << 32) | u64::from(self.blocks_count_lo)
        } else {
            u64::from(self.blocks_count_lo)
        }
    }

    /// Block size in bytes.
    #[must_use]
    pub fn block_size(&self) -> u64 {
        1024u64 << self.log_block_size
    }

    /// Number of block groups.
    #[must_use]
    pub fn group_count(&self) -> u64 {
        let bpg = u64::from(self.blocks_per_group);
        // (blocks_count + blocks_per_group - 1) / blocks_per_group,
        // biased by first_data_block so the last group may be short.
        let effective = self.blocks_count() - u64::from(self.first_data_block);
        (effective + bpg - 1) / bpg
    }

    /// Cross-check internal consistency and append findings.
    pub fn validate(&self, report: &mut Report) {
        // Revision level.
        if self.rev_level > 1 {
            report.push(Finding {
                severity: Severity::Error,
                kind: "bad_rev_level",
                detail: format!("superblock rev_level {}", self.rev_level),
            });
        }

        // Block size exponent.
        if self.log_block_size > EXT_LOG_BLOCK_SIZE_MAX {
            report.push(Finding {
                severity: Severity::Fatal,
                kind: "bad_block_size",
                detail: format!(
                    "log_block_size = {} (max {})",
                    self.log_block_size, EXT_LOG_BLOCK_SIZE_MAX
                ),
            });
        }

        // Blocks per group must be exactly 8 * block_size (one bitmap
        // block covers 8 × block_size bits = that many blocks). The
        // only exception is the flex_bg feature, which groups blocks
        // differently but keeps the individual group math the same.
        let expected_bpg = 8 * self.block_size();
        if u64::from(self.blocks_per_group) != expected_bpg {
            report.push(Finding {
                severity: Severity::Error,
                kind: "bad_blocks_per_group",
                detail: format!(
                    "blocks_per_group = {}, expected 8 * block_size = {}",
                    self.blocks_per_group, expected_bpg
                ),
            });
        }

        // Inode count must be a multiple of inodes per group.
        if self.inodes_count % self.inodes_per_group != 0 {
            report.push(Finding {
                severity: Severity::Warn,
                kind: "inodes_count_not_aligned",
                detail: format!(
                    "inodes_count = {} not a multiple of inodes_per_group = {}",
                    self.inodes_count, self.inodes_per_group
                ),
            });
        }

        // Inode size sanity. 128 for rev 0 (fixed), otherwise 128..block_size,
        // and always a power of two.
        if self.rev_level == 0 {
            if self.inode_size != 128 {
                report.push(Finding {
                    severity: Severity::Error,
                    kind: "bad_inode_size_rev0",
                    detail: format!("inode_size = {} on rev 0 fs", self.inode_size),
                });
            }
        } else if self.inode_size < 128
            || !u64::from(self.inode_size).is_power_of_two()
            || u64::from(self.inode_size) > self.block_size()
        {
            report.push(Finding {
                severity: Severity::Error,
                kind: "bad_inode_size",
                detail: format!(
                    "inode_size = {} (must be a power of two, 128..={})",
                    self.inode_size,
                    self.block_size()
                ),
            });
        }

        // Uncleanly unmounted: journal replay will be required.
        if self.state & state::CLEAN == 0 {
            report.push(Finding {
                severity: Severity::Warn,
                kind: "not_clean",
                detail: "filesystem was not cleanly unmounted".into(),
            });
        }
        if self.state & state::HAS_ERRORS != 0 {
            report.push(Finding {
                severity: Severity::Error,
                kind: "has_errors_flag",
                detail: "superblock has-errors flag is set".into(),
            });
        }
        if self.state & state::ORPHAN_FS != 0 {
            report.push(Finding {
                severity: Severity::Warn,
                kind: "orphan_list_nonempty",
                detail: "orphan inode list is non-empty; needs cleanup".into(),
            });
        }
    }
}

/// ext feature bits. Constants come from the Linux UAPI public header
/// `<linux/ext2_fs.h>` / `<linux/ext4_fs.h>` — on-disk format, not
/// library API.
pub mod feature {
    // COMPAT
    /// Directory preallocation.
    pub const COMPAT_DIR_PREALLOC: u32 = 0x0001;
    /// AFS server inodes.
    pub const COMPAT_IMAGIC_INODES: u32 = 0x0002;
    /// Has a journal (ext3/4).
    pub const COMPAT_HAS_JOURNAL: u32 = 0x0004;
    /// Extended attributes in use.
    pub const COMPAT_EXT_ATTR: u32 = 0x0008;
    /// Non-standard inode size for large_file support.
    pub const COMPAT_RESIZE_INODE: u32 = 0x0010;
    /// Hashed directory indexes.
    pub const COMPAT_DIR_INDEX: u32 = 0x0020;

    // INCOMPAT
    /// Compressed files (unused).
    pub const INCOMPAT_COMPRESSION: u32 = 0x0001;
    /// Filetype field in directory entries.
    pub const INCOMPAT_FILETYPE: u32 = 0x0002;
    /// Needs journal recovery.
    pub const INCOMPAT_RECOVER: u32 = 0x0004;
    /// Journal device (external).
    pub const INCOMPAT_JOURNAL_DEV: u32 = 0x0008;
    /// Meta block groups.
    pub const INCOMPAT_META_BG: u32 = 0x0010;
    /// Extents (ext4).
    pub const INCOMPAT_EXTENTS: u32 = 0x0040;
    /// 48-bit block addressing (ext4).
    pub const INCOMPAT_64BIT: u32 = 0x0080;
    /// Multiple mount protection.
    pub const INCOMPAT_MMP: u32 = 0x0100;
    /// Flexible block groups.
    pub const INCOMPAT_FLEX_BG: u32 = 0x0200;

    // RO_COMPAT
    /// Sparse superblocks.
    pub const RO_COMPAT_SPARSE_SUPER: u32 = 0x0001;
    /// Files > 2 GiB.
    pub const RO_COMPAT_LARGE_FILE: u32 = 0x0002;
    /// B-tree directories.
    pub const RO_COMPAT_BTREE_DIR: u32 = 0x0004;
    /// GDT checksum.
    pub const RO_COMPAT_GDT_CSUM: u32 = 0x0010;
    /// Huge files (>= 2 TiB).
    pub const RO_COMPAT_HUGE_FILE: u32 = 0x0008;
    /// Metadata checksum.
    pub const RO_COMPAT_METADATA_CSUM: u32 = 0x0400;
}

/// Read and parse the primary superblock at device offset 1024.
///
/// This function reads as many 512-byte sectors as needed to cover the
/// full 1024-byte superblock, then parses the little-endian fields.
/// The block size of `dev` only matters for alignment; we reslice the
/// buffer ourselves.
///
/// # Errors
///
/// Returns an error if the device read fails or the buffer is too
/// short to contain a superblock.
pub fn read_primary<D: BlockDev>(dev: &mut D) -> Result<Superblock, Box<dyn std::error::Error>> {
    // Superblock is 1024 bytes at byte offset 1024 — always, on every
    // ext filesystem regardless of block size. Byte-level read bypasses
    // the device's own block-size quantisation.
    let mut buf = [0u8; 1024];
    dev.read_at(1024, &mut buf)?;
    Ok(parse(&buf))
}

/// Parse a 1024-byte superblock buffer. Infallible once we've agreed
/// the bytes are there; magic validation is the caller's job so it can
/// attach structured findings.
#[must_use]
pub fn parse(b: &[u8]) -> Superblock {
    Superblock {
        inodes_count:        u32_le(b, 0x00),
        blocks_count_lo:     u32_le(b, 0x04),
        r_blocks_count_lo:   u32_le(b, 0x08),
        free_blocks_count_lo:u32_le(b, 0x0c),
        free_inodes_count:   u32_le(b, 0x10),
        first_data_block:    u32_le(b, 0x14),
        log_block_size:      u32_le(b, 0x18),
        blocks_per_group:    u32_le(b, 0x20),
        inodes_per_group:    u32_le(b, 0x28),
        // (+0x34 s_wtime, +0x38 s_mnt_count, ...)
        state:               u16_le(b, 0x3a),
        magic:               u16_le(b, 0x38), // s_magic at +0x38
        minor_rev_level:     u16_le(b, 0x3e),
        rev_level:           u32_le(b, 0x4c),
        inode_size:          u16_le(b, 0x58),
        feature_compat:      u32_le(b, 0x5c),
        feature_incompat:    u32_le(b, 0x60),
        feature_ro_compat:   u32_le(b, 0x64),
        blocks_count_hi:     u32_le(b, 0x150),
        r_blocks_count_hi:   u32_le(b, 0x154),
        free_blocks_count_hi:u32_le(b, 0x158),
        desc_size:           u16_le(b, 0xfe),
    }
}

fn u16_le(b: &[u8], off: usize) -> u16 {
    u16::from_le_bytes([b[off], b[off + 1]])
}

fn u32_le(b: &[u8], off: usize) -> u32 {
    u32::from_le_bytes([b[off], b[off + 1], b[off + 2], b[off + 3]])
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parse_minimal_sb() {
        // Hand-crafted minimal superblock: magic + blocks + log_block_size.
        let mut b = [0u8; 1024];
        // inodes_count = 8
        b[0x00..0x04].copy_from_slice(&8u32.to_le_bytes());
        // blocks_count = 32
        b[0x04..0x08].copy_from_slice(&32u32.to_le_bytes());
        // log_block_size = 2 → 4 KiB
        b[0x18..0x1c].copy_from_slice(&2u32.to_le_bytes());
        // blocks_per_group = 8 * 4096 = 32768
        b[0x20..0x24].copy_from_slice(&32768u32.to_le_bytes());
        // inodes_per_group = 8
        b[0x28..0x2c].copy_from_slice(&8u32.to_le_bytes());
        // state = CLEAN
        b[0x3a..0x3c].copy_from_slice(&1u16.to_le_bytes());
        // magic = 0xEF53
        b[0x38..0x3a].copy_from_slice(&EXT_SUPER_MAGIC.to_le_bytes());
        // rev_level = 1
        b[0x4c..0x50].copy_from_slice(&1u32.to_le_bytes());
        // inode_size = 256
        b[0x58..0x5a].copy_from_slice(&256u16.to_le_bytes());

        let sb = parse(&b);
        assert_eq!(sb.magic, EXT_SUPER_MAGIC);
        assert_eq!(sb.block_size(), 4096);
        assert_eq!(sb.blocks_count(), 32);
        assert_eq!(sb.inode_size, 256);
    }
}
