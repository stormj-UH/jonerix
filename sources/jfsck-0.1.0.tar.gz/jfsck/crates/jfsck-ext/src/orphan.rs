//! Orphan inode list walker.
//!
//! When a file is unlinked while still open (a common Linux idiom)
//! the kernel can't free its blocks until the last file descriptor
//! is closed. To survive a crash between "last close" and "blocks
//! released", ext keeps a linked list of those pending-delete inodes
//! rooted at `s_last_orphan` in the superblock. Each entry's `dtime`
//! field doubles as the link to the next orphan. A clean unmount
//! flushes the list to zero.
//!
//! When `s_last_orphan != 0`, `e2fsck` walks the chain, truncates
//! each inode's data blocks, and removes it from the list. Our job
//! in Phase 2.a is just to walk + report — writing cleanup is
//! Phase 2.b.
//!
//! The kernel also supports a newer `orphan_file` feature (an
//! on-disk file holding the list instead of a linked-list through
//! inodes). We do not handle that yet; Pi distros don't enable it.

use crate::superblock::{Superblock, feature};
use crate::{Finding, Severity, Report};
use jfsck_io::BlockDev;

/// Walk the orphan chain and report each entry. Bounded iteration
/// to avoid infinite loops if `dtime` forms a cycle. Returns the
/// number of orphans seen.
///
/// # Errors
///
/// Propagates device I/O errors.
pub fn walk<D: BlockDev>(
    dev: &mut D,
    sb: &Superblock,
    report: &mut Report,
) -> Result<u64, Box<dyn std::error::Error>> {
    // orphan_file feature is incompat; if set, skip (not implemented).
    const INCOMPAT_ORPHAN_FILE: u32 = 0x1000;
    if sb.feature_incompat & INCOMPAT_ORPHAN_FILE != 0 {
        report.push(Finding {
            severity: Severity::Warn,
            kind: "orphan_file_not_supported",
            detail: "orphan_file feature is set; linked-list walker skipped".into(),
        });
        return Ok(0);
    }

    // s_last_orphan lives at offset 0x44 in the superblock. We didn't
    // park it in Superblock; reach into the raw bytes directly.
    let mut sb_bytes = [0u8; 1024];
    dev.read_at(1024, &mut sb_bytes)?;
    let last_orphan = u32::from_le_bytes([
        sb_bytes[0x44], sb_bytes[0x45], sb_bytes[0x46], sb_bytes[0x47],
    ]);
    if last_orphan == 0 {
        return Ok(0);
    }

    // Descriptor size.
    let desc_size = if sb.feature_incompat & feature::INCOMPAT_64BIT != 0 && sb.desc_size >= 32 {
        sb.desc_size
    } else {
        32
    };
    let block_size = sb.block_size();
    let gdt_start_block = if block_size == 1024 { 2 } else { 1 };
    let isize = u64::from(sb.inode_size.max(128));

    // Walk. Bound iteration at `inodes_count` — a correctly-formed
    // list can never be longer; anything more is corruption (cycle).
    let mut count = 0u64;
    let mut cur = last_orphan;
    let mut seen = std::collections::HashSet::<u32>::new();

    while cur != 0 {
        // Cycle detection: if we've visited this node before, report
        // and bail. Otherwise a malformed list hangs us here.
        if !seen.insert(cur) {
            report.push(Finding {
                severity: Severity::Error,
                kind: "orphan_list_cycle",
                detail: format!("orphan list contains a cycle at inode {}", cur),
            });
            break;
        }
        if u64::from(cur) > u64::from(sb.inodes_count) {
            report.push(Finding {
                severity: Severity::Error,
                kind: "orphan_list_out_of_range",
                detail: format!(
                    "orphan list points to inode {} but inodes_count = {}",
                    cur, sb.inodes_count,
                ),
            });
            break;
        }
        count += 1;

        // Fetch this inode and extract its i_dtime (which in the
        // orphan convention is the NEXT inode number, not a time).
        let ino_no = u64::from(cur);
        let group = (ino_no - 1) / u64::from(sb.inodes_per_group);
        let off = (ino_no - 1) % u64::from(sb.inodes_per_group);

        let gdt_off = gdt_start_block * block_size + group * u64::from(desc_size);
        let mut gd_buf = vec![0u8; desc_size as usize];
        dev.read_at(gdt_off, &mut gd_buf)?;
        let gd = crate::group::GroupDesc::parse(&gd_buf, desc_size);

        let inode_byte_off = gd.inode_table * block_size + off * isize;
        let mut ibuf = vec![0u8; isize as usize];
        dev.read_at(inode_byte_off, &mut ibuf)?;
        let ino_struct = crate::inode::parse(&ibuf);

        // dtime = next orphan in chain.
        cur = ino_struct.dtime;

        // Bound total iterations as an extra safety net.
        if count > u64::from(sb.inodes_count) {
            report.push(Finding {
                severity: Severity::Error,
                kind: "orphan_list_too_long",
                detail: format!("orphan list exceeds inodes_count = {}", sb.inodes_count),
            });
            break;
        }
    }

    if count > 0 {
        report.push(Finding {
            severity: Severity::Warn,
            kind: "orphan_inodes_pending",
            detail: format!("{} orphan inode(s) in pending-delete list", count),
        });
    }
    Ok(count)
}
