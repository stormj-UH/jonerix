//! Orphan list cleanup — write-back companion to `orphan::walk`.
//!
//! Phase 2.a's [`crate::orphan::walk`] reports what's in the list.
//! This module actually processes each entry:
//!
//!   1. Walk the inode's extent tree (or indirect-block chain) and
//!      free every data block in the appropriate group's block bitmap.
//!   2. Free the `i_file_acl` xattr block if present.
//!   3. Mark the inode's bit clear in its group's inode bitmap.
//!   4. Zero the inode table entry (preserving `dtime` as a headstone).
//!   5. Bump per-group `free_blocks_count` / `free_inodes_count` and
//!      the matching superblock totals.
//!   6. After the whole list is processed, set `s_last_orphan = 0` in
//!      the superblock so nothing asks about it again.
//!
//! Write ordering: we flush each group's bitmap + descriptor before
//! touching the next inode, and finally flush + rewrite the super-
//! block. A crash at any point leaves a partially-cleaned list, which
//! a subsequent fsck run picks up cleanly by re-walking from
//! `s_last_orphan`.
//!
//! Scope:
//!
//! - Handles extent-based files (the ext4 default — depth 0 or higher).
//! - Handles legacy ext2/3 direct + single-indirect pointers; double
//!   and triple indirect deferred.
//! - Handles xattr blocks via `i_file_acl_lo` / `i_file_acl_hi`.
//! - Handles regular files; directories are punted for phase 2.d
//!   because they contribute to parent link counts.

use crate::group::GroupDesc;
use crate::superblock::{Superblock, feature};
use crate::{Finding, Severity, Report};
use jfsck_io::BlockDev;

/// Run the full orphan cleanup pass. Returns the number of inodes
/// successfully freed. Every inode we touch is reported; anything we
/// can't handle (directory orphan, depth-N extent tree we don't
/// traverse yet, extern xattr inode, etc.) gets a finding and is
/// skipped so the next fsck run can pick it up.
///
/// # Errors
///
/// Propagates I/O errors. A mid-operation failure leaves behind a
/// partial state that's safe to re-run: the orphan list still points
/// to the remaining inodes; bitmaps may show already-freed blocks as
/// free (idempotent).
pub fn cleanup<D: BlockDev>(
    dev: &mut D,
    sb: &Superblock,
    report: &mut Report,
) -> Result<u64, Box<dyn std::error::Error>> {
    // If orphan_file (the modern, file-backed variant) is in use we
    // refuse to touch it — phase 2.a already reported the feature as
    // unsupported.
    const INCOMPAT_ORPHAN_FILE: u32 = 0x1000;
    if sb.feature_incompat & INCOMPAT_ORPHAN_FILE != 0 { return Ok(0); }

    // Fetch the chain head from the primary superblock bytes.
    let mut sb_raw = [0u8; 1024];
    dev.read_at(1024, &mut sb_raw)?;
    let mut cur = u32::from_le_bytes([sb_raw[0x44], sb_raw[0x45], sb_raw[0x46], sb_raw[0x47]]);
    if cur == 0 { return Ok(0); }

    let block_size = sb.block_size();
    let desc_size = if sb.feature_incompat & feature::INCOMPAT_64BIT != 0 && sb.desc_size >= 32 {
        sb.desc_size
    } else { 32 };
    let gdt_start_block = if block_size == 1024 { 2 } else { 1 };
    let isize = u64::from(sb.inode_size.max(128));

    // Running totals. We only touch the sb at the end of the pass.
    let mut freed_inodes: u64 = 0;
    let mut freed_blocks: u64 = 0;
    let mut cleared_stale_head = false;
    let mut seen = std::collections::HashSet::<u32>::new();

    while cur != 0 {
        if !seen.insert(cur) {
            report.push(Finding {
                severity: Severity::Error,
                kind: "orphan_cleanup_cycle",
                detail: format!("cycle at inode {}; truncating orphan chain here", cur),
            });
            // A cycle means at least part of the chain is corrupt.
            // We can't reason about what's downstream; clear the head
            // so the filesystem can be mounted. What survives is
            // already-freed orphans whose next-pointers dangle, which
            // is benign.
            cleared_stale_head = true;
            break;
        }
        if u64::from(cur) > u64::from(sb.inodes_count) {
            report.push(Finding {
                severity: Severity::Error,
                kind: "orphan_cleanup_out_of_range",
                detail: format!(
                    "orphan list head {} exceeds inodes_count {}; clearing stale pointer",
                    cur, sb.inodes_count,
                ),
            });
            // Classic "old corruption left garbage in s_last_orphan"
            // case. e2fsck clears it and calls that a fix.
            cleared_stale_head = true;
            break;
        }

        // Locate the inode.
        let ino_no = u64::from(cur);
        let group_idx = (ino_no - 1) / u64::from(sb.inodes_per_group);
        let off_in_group = (ino_no - 1) % u64::from(sb.inodes_per_group);

        let gdt_byte_off = gdt_start_block * block_size + group_idx * u64::from(desc_size);
        let mut gd_buf = vec![0u8; desc_size as usize];
        dev.read_at(gdt_byte_off, &mut gd_buf)?;
        let mut gd = GroupDesc::parse(&gd_buf, desc_size);

        let inode_byte_off = gd.inode_table * block_size + off_in_group * isize;
        let mut ibuf = vec![0u8; isize as usize];
        dev.read_at(inode_byte_off, &mut ibuf)?;
        let ino = crate::inode::parse(&ibuf);
        let next = ino.dtime;

        // Skip directories — phase 2.d will handle the parent nlink
        // accounting. Regular files, symlinks, devices, FIFOs,
        // sockets are all safe to free here.
        if matches!(ino.file_type(), Some(crate::inode::FileType::Directory)) {
            report.push(Finding {
                severity: Severity::Warn,
                kind: "orphan_directory_deferred",
                detail: format!("orphan inode {} is a directory; deferred to Phase 2.d", cur),
            });
            cur = next;
            continue;
        }

        // Walk data blocks and free them in the block bitmap.
        let fs_blocks = collect_file_blocks(dev, sb, &ino, &ibuf, isize as usize)?;

        // Also free the xattr block if present. `i_file_acl_lo` at
        // offset 0x68, `_hi` at 0x72 (u16). Zero means none.
        let acl_lo = u32::from_le_bytes([ibuf[0x68], ibuf[0x69], ibuf[0x6a], ibuf[0x6b]]);
        let acl_hi = if isize >= 0x74 {
            u16::from_le_bytes([ibuf[0x72], ibuf[0x73]])
        } else { 0 };
        let acl_block = (u64::from(acl_hi) << 32) | u64::from(acl_lo);

        let mut all_blocks = fs_blocks;
        if acl_block != 0 { all_blocks.push(acl_block); }

        // Free all collected blocks. We batch updates per-group so a
        // file spanning several groups still only hits each group's
        // bitmap once.
        let mut per_group: std::collections::HashMap<u64, Vec<u64>> =
            std::collections::HashMap::new();
        for b in &all_blocks {
            let g = (b - u64::from(sb.first_data_block)) / u64::from(sb.blocks_per_group);
            per_group.entry(g).or_default().push(*b);
        }

        for (g_idx, blocks_in_group) in &per_group {
            // Read the group descriptor for this group (it may differ
            // from the one the inode lives in).
            let bdoff = gdt_start_block * block_size + g_idx * u64::from(desc_size);
            let mut bdbuf = vec![0u8; desc_size as usize];
            dev.read_at(bdoff, &mut bdbuf)?;
            let mut bdg = GroupDesc::parse(&bdbuf, desc_size);

            // Read the block bitmap.
            let mut bmap = vec![0u8; block_size as usize];
            dev.read_at(bdg.block_bitmap * block_size, &mut bmap)?;

            let group_first =
                u64::from(sb.first_data_block) + g_idx * u64::from(sb.blocks_per_group);
            let mut this_group_freed = 0u32;
            for b in blocks_in_group {
                let bit = (b - group_first) as usize;
                if bit >= (block_size * 8) as usize { continue; }
                let byte = bit / 8;
                let mask = 1u8 << (bit % 8);
                if bmap[byte] & mask != 0 {
                    bmap[byte] &= !mask;
                    this_group_freed += 1;
                }
            }
            if this_group_freed > 0 {
                dev.write_at(bdg.block_bitmap * block_size, &bmap)?;
                bdg.free_blocks_count = bdg.free_blocks_count.saturating_add(this_group_freed);
                write_back_group_desc(dev, gdt_start_block, block_size, *g_idx, desc_size, &bdg)?;
                freed_blocks += u64::from(this_group_freed);
            }
        }

        // Free the inode bit in the inode bitmap, bump free_inodes_count.
        {
            let mut ibmap = vec![0u8; block_size as usize];
            dev.read_at(gd.inode_bitmap * block_size, &mut ibmap)?;
            let bit = off_in_group as usize;
            let byte = bit / 8;
            let mask = 1u8 << (bit % 8);
            if ibmap[byte] & mask != 0 {
                ibmap[byte] &= !mask;
                dev.write_at(gd.inode_bitmap * block_size, &ibmap)?;
                gd.free_inodes_count = gd.free_inodes_count.saturating_add(1);
                write_back_group_desc(dev, gdt_start_block, block_size, group_idx, desc_size, &gd)?;
                freed_inodes += 1;
            }
        }

        // Rewrite the inode: zero everything except dtime (serves as a
        // headstone so e2fsck-compat tools see "was deleted at T").
        let now = now_seconds();
        for b in ibuf.iter_mut() { *b = 0; }
        ibuf[0x14..0x18].copy_from_slice(&now.to_le_bytes()); // i_dtime
        dev.write_at(inode_byte_off, &ibuf)?;

        report.push(Finding {
            severity: Severity::Warn,
            kind: "orphan_cleaned",
            detail: format!(
                "inode {} freed ({} block(s) returned to bitmap)",
                cur, all_blocks.len(),
            ),
        });

        cur = next;
    }

    // Finalise. Two reasons to rewrite the superblock:
    //   1. We successfully freed one or more orphans — update free
    //      counts and zero s_last_orphan.
    //   2. We hit invalid chain content (cycle or out-of-range) and
    //      cleared the head to unblock future mounts.
    if freed_inodes > 0 || cleared_stale_head {
        dev.read_at(1024, &mut sb_raw)?;
        // s_last_orphan
        sb_raw[0x44..0x48].copy_from_slice(&0u32.to_le_bytes());

        // Bump free_inodes_count (u32 at 0x10).
        let mut fi = u32::from_le_bytes([sb_raw[0x10], sb_raw[0x11], sb_raw[0x12], sb_raw[0x13]]);
        fi = fi.saturating_add(u32::try_from(freed_inodes).unwrap_or(u32::MAX));
        sb_raw[0x10..0x14].copy_from_slice(&fi.to_le_bytes());

        // Bump free_blocks_count (low u32 at 0x0c; high u32 at 0x154 with 64BIT).
        let mut fb_lo = u32::from_le_bytes([sb_raw[0x0c], sb_raw[0x0d], sb_raw[0x0e], sb_raw[0x0f]]);
        let mut fb_hi =
            if sb.feature_incompat & feature::INCOMPAT_64BIT != 0 {
                u32::from_le_bytes([sb_raw[0x154], sb_raw[0x155], sb_raw[0x156], sb_raw[0x157]])
            } else { 0 };
        let mut fb = (u64::from(fb_hi) << 32) | u64::from(fb_lo);
        fb = fb.saturating_add(freed_blocks);
        fb_lo = fb as u32;
        fb_hi = (fb >> 32) as u32;
        sb_raw[0x0c..0x10].copy_from_slice(&fb_lo.to_le_bytes());
        if sb.feature_incompat & feature::INCOMPAT_64BIT != 0 {
            sb_raw[0x154..0x158].copy_from_slice(&fb_hi.to_le_bytes());
        }

        dev.write_at(1024, &sb_raw)?;
        dev.flush()?;

        if freed_inodes > 0 {
            report.push(Finding {
                severity: Severity::Warn,
                kind: "orphan_cleanup_complete",
                detail: format!(
                    "cleaned {} orphan inode(s), returning {} block(s) to the free pool",
                    freed_inodes, freed_blocks,
                ),
            });
        } else if cleared_stale_head {
            report.push(Finding {
                severity: Severity::Warn,
                kind: "orphan_cleanup_complete",
                detail: "cleared stale s_last_orphan pointer".into(),
            });
        }
    }

    Ok(freed_inodes)
}

/// Walk an inode's extent tree or indirect pointers and return every
/// filesystem block that backs the file's data. Also returns extent
/// index blocks (for depth > 0 trees) so the caller frees those too.
fn collect_file_blocks<D: BlockDev>(
    dev: &mut D,
    sb: &Superblock,
    ino: &crate::inode::Inode,
    ibuf: &[u8],
    _isize: usize,
) -> Result<Vec<u64>, Box<dyn std::error::Error>> {
    let block_size = sb.block_size();
    let mut out: Vec<u64> = Vec::new();

    if ino.uses_extents() {
        walk_extent_header(dev, &ino.i_block, block_size, &mut out)?;
    } else {
        // Legacy: direct pointers (0..11), single (12), double (13),
        // triple (14). We walk direct + single only — larger files
        // rarely go through this path on ext4 anyway.
        for i in 0..12 {
            let off = i * 4;
            let b = u32::from_le_bytes([
                ino.i_block[off], ino.i_block[off+1],
                ino.i_block[off+2], ino.i_block[off+3],
            ]);
            if b != 0 { out.push(u64::from(b)); }
        }
        let ind = u32::from_le_bytes([
            ino.i_block[48], ino.i_block[49],
            ino.i_block[50], ino.i_block[51],
        ]);
        if ind != 0 {
            out.push(u64::from(ind)); // the indirect block itself
            let mut ib = vec![0u8; block_size as usize];
            dev.read_at(u64::from(ind) * block_size, &mut ib)?;
            let entries = (block_size / 4) as usize;
            for i in 0..entries {
                let b = u32::from_le_bytes([ib[i*4], ib[i*4+1], ib[i*4+2], ib[i*4+3]]);
                if b == 0 { break; }
                out.push(u64::from(b));
            }
        }
    }
    let _ = ibuf;
    Ok(out)
}

/// Walk an extent header starting at `i_block[0..12]` (or at the top
/// of an index block). Depth > 0 means this is an index level and each
/// "extent" is really an index pointing to a lower-level block.
fn walk_extent_header<D: BlockDev>(
    dev: &mut D,
    header_bytes: &[u8],
    block_size: u64,
    out: &mut Vec<u64>,
) -> Result<(), Box<dyn std::error::Error>> {
    if header_bytes.len() < 12 { return Ok(()); }
    let magic   = u16::from_le_bytes([header_bytes[0], header_bytes[1]]);
    if magic != crate::inode::EXT4_EXTENT_MAGIC { return Ok(()); }
    let entries = u16::from_le_bytes([header_bytes[2], header_bytes[3]]);
    let depth   = u16::from_le_bytes([header_bytes[6], header_bytes[7]]);

    for i in 0..entries as usize {
        let base = 12 + i * 12;
        if base + 12 > header_bytes.len() { break; }
        if depth == 0 {
            // Leaf extent: log(4) len(2) hi(2) lo(4)
            let ee_len = u16::from_le_bytes([header_bytes[base+4], header_bytes[base+5]]);
            let ee_hi  = u16::from_le_bytes([header_bytes[base+6], header_bytes[base+7]]);
            let ee_lo  = u32::from_le_bytes([
                header_bytes[base+8], header_bytes[base+9],
                header_bytes[base+10], header_bytes[base+11],
            ]);
            // Uninitialised extents have ee_len >= 32768; the physical
            // blocks still exist and should still be freed.
            let real_len = (ee_len & 0x7fff) as u64;
            let start = (u64::from(ee_hi) << 32) | u64::from(ee_lo);
            for j in 0..real_len {
                out.push(start + j);
            }
        } else {
            // Index entry: log(4) leaf_lo(4) leaf_hi(2) unused(2)
            let leaf_lo = u32::from_le_bytes([
                header_bytes[base+4], header_bytes[base+5],
                header_bytes[base+6], header_bytes[base+7],
            ]);
            let leaf_hi = u16::from_le_bytes([header_bytes[base+8], header_bytes[base+9]]);
            let leaf = (u64::from(leaf_hi) << 32) | u64::from(leaf_lo);
            // The index block itself is metadata we need to free too.
            out.push(leaf);
            let mut child = vec![0u8; block_size as usize];
            dev.read_at(leaf * block_size, &mut child)?;
            walk_extent_header(dev, &child, block_size, out)?;
        }
    }
    Ok(())
}

/// Write a mutated `GroupDesc` back to the GDT. Only the fields we
/// actually change in this module (bitmaps' free counts, inode free
/// count) are serialised — block_bitmap / inode_table locations are
/// left as-is.
fn write_back_group_desc<D: BlockDev>(
    dev: &mut D,
    gdt_start_block: u64,
    block_size: u64,
    group_idx: u64,
    desc_size: u16,
    gd: &GroupDesc,
) -> Result<(), Box<dyn std::error::Error>> {
    let gdt_byte_off = gdt_start_block * block_size + group_idx * u64::from(desc_size);
    let mut gd_buf = vec![0u8; desc_size as usize];
    dev.read_at(gdt_byte_off, &mut gd_buf)?;

    // Low halves.
    gd_buf[0x0c..0x0e].copy_from_slice(&(gd.free_blocks_count as u16).to_le_bytes());
    gd_buf[0x0e..0x10].copy_from_slice(&(gd.free_inodes_count as u16).to_le_bytes());

    // Hi halves for 64-bit descriptors.
    if desc_size >= 64 && gd_buf.len() >= 64 {
        gd_buf[0x2c..0x2e].copy_from_slice(&((gd.free_blocks_count >> 16) as u16).to_le_bytes());
        gd_buf[0x2e..0x30].copy_from_slice(&((gd.free_inodes_count >> 16) as u16).to_le_bytes());
    }

    dev.write_at(gdt_byte_off, &gd_buf)?;
    Ok(())
}

fn now_seconds() -> u32 {
    use std::time::{SystemTime, UNIX_EPOCH};
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_secs() as u32)
        .unwrap_or(0)
}
