//! Findings and exit status reporting.
//!
//! A [`Report`] is an accumulator: every check appends [`Finding`]s as
//! it spots problems, and the driver collapses the accumulated list
//! into an `e2fsck`-compatible exit code at the end (0 clean, 1 fixed
//! some, 4 uncorrected left, 8 operational error).

/// Severity level of a single finding. Ordered: `Fatal > Error > Warn`.
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord)]
pub enum Severity {
    /// Cosmetic or low-impact — usage hint, missing optional feature.
    Warn,
    /// Real inconsistency the filesystem can live with but should fix.
    Error,
    /// Checker cannot proceed — bad magic, device too small, etc.
    Fatal,
}

/// A single observed issue.
#[derive(Debug, Clone)]
pub struct Finding {
    /// Level of concern.
    pub severity: Severity,
    /// Stable identifier — not localised; use for tests and tooling.
    pub kind: &'static str,
    /// Human-readable detail for console output.
    pub detail: String,
}

/// Accumulated findings from a single check run.
#[derive(Debug, Default)]
pub struct Report {
    findings: Vec<Finding>,
}

impl Report {
    /// Empty report.
    #[must_use]
    pub fn new() -> Self { Self::default() }

    /// Append a finding.
    pub fn push(&mut self, f: Finding) { self.findings.push(f); }

    /// Borrow the accumulated findings.
    #[must_use]
    pub fn findings(&self) -> &[Finding] { &self.findings }

    /// Highest severity observed, if any.
    #[must_use]
    pub fn max_severity(&self) -> Option<Severity> {
        self.findings.iter().map(|f| f.severity).max()
    }

    /// Map this report to an `e2fsck`-compatible exit code.
    /// 0 = clean, 4 = errors remain uncorrected, 8 = operational error.
    #[must_use]
    pub fn exit_code(&self) -> i32 {
        match self.max_severity() {
            None => 0,
            Some(Severity::Warn) => 0,
            Some(Severity::Error) => 4,
            Some(Severity::Fatal) => 8,
        }
    }
}
