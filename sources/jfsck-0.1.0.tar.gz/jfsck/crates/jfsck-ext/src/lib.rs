//! ext2/3/4 filesystem checker.
//!
//! The three filesystems share a common on-disk layout that grew
//! feature-by-feature: ext2 is the base, ext3 adds a journal, ext4
//! adds 48-bit block addresses, extents, flex block groups, and
//! metadata checksums among others. One code path handles all three by
//! reading the feature bitmasks in the superblock and picking the right
//! variant of each structure at walk time.
//!
//! This is a clean-room reimplementation. The on-disk layout constants
//! come from the public Linux kernel UAPI (`<linux/ext2_fs.h>` and
//! `<linux/ext4_fs.h>`), not from e2fsprogs source. Algorithms were
//! reconstructed from Ghidra decompilation of `e2fsck` and
//! `libext2fs.so.2` only.

#![forbid(unsafe_op_in_unsafe_fn)]
#![deny(missing_docs)]

pub mod backup_sb;
pub mod group;
pub mod inode;
pub mod journal;
pub mod journal_replay;
pub mod orphan;
pub mod orphan_cleanup;
pub mod report;
pub mod superblock;

pub use group::{GroupDesc, read_and_validate as read_group_descs};
pub use inode::{Inode, WalkStats};
pub use report::{Finding, Severity, Report};
pub use superblock::Superblock;

use jfsck_io::BlockDev;

/// Run a read-only check against the device. Populates a [`Report`]
/// with every issue found; returns the report so callers can decide
/// what to print and what (if anything) to repair.
///
/// # Errors
///
/// Returns an error only for I/O failures severe enough to prevent
/// checking (can't read the superblock, etc.). Filesystem-level
/// inconsistencies are *findings* in the [`Report`], not errors.
pub fn check_ro<D: BlockDev>(dev: &mut D) -> Result<Report, Box<dyn std::error::Error>> {
    let mut report = Report::new();

    // Phase A: superblock. Every ext filesystem starts at byte offset
    // 1024 on the device, regardless of block size, because ext2 was
    // designed to coexist with MBR/BIOS bootloaders at block 0.
    let primary = superblock::read_primary(dev)?;

    // Phase A.5: if the primary magic is wrong OR primary validation
    // fails fatally, fall back to a backup. Backups are sparse-layout
    // unless the filesystem was built without that feature (a RO
    // compat flag in the primary — which is itself what we're trying
    // to recover, so we assume sparse when the primary is unusable).
    let sb = if primary.magic != superblock::EXT_SUPER_MAGIC {
        report.push(Finding {
            severity: Severity::Error,
            kind: "primary_bad_magic",
            detail: format!(
                "primary superblock magic {:#06x}, expected {:#06x}; searching backups",
                primary.magic,
                superblock::EXT_SUPER_MAGIC,
            ),
        });
        // We don't know block size / bpg since the primary is garbage;
        // probe at Pi-typical defaults (4 KiB blocks, 32768 bpg).
        let dev_bytes = dev.num_blocks() * dev.block_size() as u64;
        let (bpg, lbs, total_g) = backup_sb::default_probe_params(dev_bytes);
        match backup_sb::find_backup(dev, bpg, lbs, total_g, true, &mut report)? {
            Some((_, sb)) => sb,
            None => return Ok(report), // no_usable_superblock already logged
        }
    } else {
        // Primary has valid magic. Validate structurally — if Fatal,
        // still worth a backup probe since the primary's numeric
        // fields might be trustworthy enough to use for the probe
        // parameters.
        let mut probe = Report::new();
        primary.validate(&mut probe);
        if matches!(probe.max_severity(), Some(Severity::Fatal)) {
            report.push(Finding {
                severity: Severity::Error,
                kind: "primary_structurally_bad",
                detail: "primary superblock fails structural checks; searching backups".into(),
            });
            // Replay the Fatal findings too so output is honest.
            for f in probe.findings() { report.push(f.clone()); }
            let bpg = primary.blocks_per_group.max(32_768);
            let lbs = primary.log_block_size.min(6);
            let total_g = primary.group_count().max(1);
            let sparse =
                primary.feature_ro_compat & superblock::feature::RO_COMPAT_SPARSE_SUPER != 0;
            match backup_sb::find_backup(dev, bpg, lbs, total_g, sparse || true, &mut report)? {
                Some((_, sb)) => sb,
                None => return Ok(report),
            }
        } else {
            // Primary good. Accept its findings (Warn/Error) into the
            // main report, and continue.
            for f in probe.findings() { report.push(f.clone()); }
            primary
        }
    };

    // Phase C: group descriptor table walk.
    let descs = match group::read_and_validate(dev, &sb, &mut report) {
        Ok(d) => d,
        Err(e) => {
            report.push(Finding {
                severity: Severity::Fatal,
                kind: "gdt_read_error",
                detail: format!("group descriptor table read: {}", e),
            });
            return Ok(report);
        }
    };

    // Phase D: inode table walk. Produces per-inode findings and a
    // `WalkStats` summary that later passes (pass4/5 equivalents) will
    // cross-reference.
    let _stats = match inode::walk_tables(dev, &sb, &descs, &mut report) {
        Ok(s) => s,
        Err(e) => {
            report.push(Finding {
                severity: Severity::Error,
                kind: "inode_walk_error",
                detail: format!("inode table walk: {}", e),
            });
            return Ok(report);
        }
    };

    // Phase E: journal inspection — determines whether replay is needed.
    // Actually applying a replay (writing metadata blocks back) is a
    // future Phase 2.b step gated on a writable mount; here we just
    // detect and report.
    if let Err(e) = journal::inspect(dev, &sb, &mut report) {
        report.push(Finding {
            severity: Severity::Warn,
            kind: "journal_inspect_error",
            detail: format!("journal inspection: {}", e),
        });
    }

    // Phase F: orphan list walk. Harmless on clean filesystems (the
    // list is empty); vital for diagnosing the "unclean shutdown
    // with open-unlinked file" case that dominates Pi power-cut
    // incidents.
    if let Err(e) = orphan::walk(dev, &sb, &mut report) {
        report.push(Finding {
            severity: Severity::Warn,
            kind: "orphan_walk_error",
            detail: format!("orphan list walk: {}", e),
        });
    }

    // Phase G (pending): inode + block bitmap reconcile (pass5 equiv).
    // Phase H (pending): directory hash tree + extent tree structural.
    // Phase I — actual journal replay — is implemented in
    // `check_and_repair` below; read-only mode can only *detect* the
    // need.

    Ok(report)
}

/// Like [`check_ro`] but allowed to write: replays the journal and
/// performs other repair actions when the device has been opened
/// writable. Designed for the `-y` / unattended-repair callpath.
///
/// The scope of "repair" right now is:
///
/// - **Journal replay** — write pending metadata transactions back
///   to their filesystem blocks, mark the journal clean, and clear
///   `INCOMPAT_RECOVER` on the fs superblock.
///
/// Future additions:
///
/// - Orphan inode truncation + unlink (Phase 2.c).
/// - Bitmap reconcile against the table walk (Phase 1's pass5 gap).
///
/// # Errors
///
/// Same contract as [`check_ro`]; only I/O failures bubble up, fs-
/// level anomalies become findings.
pub fn check_and_repair<D: BlockDev>(dev: &mut D) -> Result<Report, Box<dyn std::error::Error>> {
    // Run the full read-only inspection first so we have an accurate
    // picture of the filesystem before mutating it.
    let mut report = check_ro(dev)?;

    // If the read-only inspection hit anything Fatal, don't touch the
    // device — we probably can't trust the superblock we'd rely on.
    if matches!(report.max_severity(), Some(Severity::Fatal)) {
        report.push(Finding {
            severity: Severity::Warn,
            kind: "repair_aborted_fatal",
            detail: "skipping repair because read-only inspection found fatal issues".into(),
        });
        return Ok(report);
    }

    // Re-read the primary superblock for the replay pass. We already
    // used it read-only; reuse requires threading state through, and
    // the re-read is cheap.
    let sb = match superblock::read_primary(dev) {
        Ok(s) if s.magic == superblock::EXT_SUPER_MAGIC => s,
        _ => {
            report.push(Finding {
                severity: Severity::Warn,
                kind: "repair_no_primary",
                detail: "primary superblock not usable for repair".into(),
            });
            return Ok(report);
        }
    };

    match journal_replay::replay(dev, &sb, &mut report) {
        Ok(0) => {}
        Ok(_) => {
            // A replay happened. Ensure it's on disk before we
            // continue — the orphan cleanup below reads the freshly-
            // replayed superblock and inode state.
            let _ = dev.flush();
        }
        Err(e) => {
            report.push(Finding {
                severity: Severity::Error,
                kind: "journal_replay_failed",
                detail: format!("journal replay: {}", e),
            });
        }
    }

    // Phase 2.c: orphan list cleanup. Runs after journal replay so
    // orphan accounting reflects the post-replay state — the journal
    // may itself have appended to the orphan list, or cleared entries
    // that were already processed.
    //
    // Re-read the primary superblock: replay just mutated it.
    if let Ok(sb2) = superblock::read_primary(dev) {
        if sb2.magic == superblock::EXT_SUPER_MAGIC {
            match orphan_cleanup::cleanup(dev, &sb2, &mut report) {
                Ok(_) => {}
                Err(e) => {
                    report.push(Finding {
                        severity: Severity::Error,
                        kind: "orphan_cleanup_failed",
                        detail: format!("orphan cleanup: {}", e),
                    });
                }
            }
        }
    }

    Ok(report)
}
