//! Backup superblock recovery.
//!
//! Every ext filesystem keeps copies of the superblock in later block
//! groups so a corrupt primary can be rebuilt from a surviving backup.
//! Two layouts exist:
//!
//! - **Dense** (pre-`sparse_super`): a copy in every block group.
//! - **Sparse** (`RO_COMPAT_SPARSE_SUPER`, effectively universal on
//!   modern ext4): copies only at groups 0, 1, and at every power of
//!   3, 5, and 7. e.g. groups 3, 5, 7, 9, 25, 27, 49, 81, 125…
//!
//! When the primary superblock fails its magic / self-consistency
//! check, we look for a backup, validate it the same way, and use it
//! to reason about the filesystem. This is a **read-only recovery**;
//! we don't yet write the backup back over the primary.
//!
//! The backup copies live at the *first block* of each backing group
//! (followed immediately by that group's descriptor table — the two
//! travel together). For 1 KiB block size the first block of group g
//! is `g * blocks_per_group + 1`; for larger block sizes it is
//! `g * blocks_per_group`. In every case the superblock bytes are at
//! byte offset `group_start * block_size`, and within the block, at
//! the same `+0` alignment the primary uses once block 0 is skipped
//! (for 1 KiB) or the same start-of-block offset (for >= 2 KiB).
//!
//! This module handles only **search + parse**. Rebuilding the
//! primary from a valid backup is a phase-2.b task.

use crate::superblock::{self, Superblock, EXT_SUPER_MAGIC};
use crate::{Finding, Severity, Report};
use jfsck_io::BlockDev;

/// Maximum group index we'll probe when hunting for backups. The
/// sparse algorithm's density decays fast; 32 groups is more than
/// enough to cover any filesystem likely to appear on a Pi (up to
/// ~1 TiB at 32 MiB per group).
const MAX_BACKUP_GROUPS_TO_PROBE: u64 = 32;

/// Return the 1-based group indexes that would host a backup super-
/// block under `sparse_super`. Group 0 (primary) is omitted. The
/// standard rule: group 1, plus every power of 3, 5, or 7.
///
/// If `sparse` is false we return *every* group index, matching the
/// dense layout.
#[must_use]
pub fn backup_group_indexes(total_groups: u64, sparse: bool) -> Vec<u64> {
    let cap = total_groups.min(MAX_BACKUP_GROUPS_TO_PROBE + 1);
    if !sparse {
        return (1..cap).collect();
    }
    let mut v = vec![1u64];
    for &base in &[3u64, 5, 7] {
        let mut p = base;
        while p < cap {
            v.push(p);
            // Stop when next multiply would overflow or exceed cap.
            match p.checked_mul(base) {
                Some(n) if n < cap => p = n,
                _ => break,
            }
        }
    }
    v.sort_unstable();
    v.dedup();
    v
}

/// Search for a readable backup superblock. `blocks_per_group` and
/// `log_block_size` must already be known from *some* source — the
/// primary might supply them before we detect it's otherwise corrupt,
/// OR a caller can pass sensible defaults (1 KiB block size and the
/// e2fsprogs default 8192 blocks-per-group) when the primary is a
/// total loss.
///
/// Returns the first backup that passes magic + self-validation,
/// along with the group index it came from. Returns `None` if no
/// backup is found; findings are pushed to `report` in either case.
///
/// # Errors
///
/// Returns I/O errors from the device read.
pub fn find_backup<D: BlockDev>(
    dev: &mut D,
    blocks_per_group: u32,
    log_block_size: u32,
    total_groups: u64,
    sparse: bool,
    report: &mut Report,
) -> Result<Option<(u64, Superblock)>, Box<dyn std::error::Error>> {
    let block_size: u64 = 1024 << log_block_size;
    let bpg: u64 = u64::from(blocks_per_group);

    for &g in &backup_group_indexes(total_groups, sparse) {
        // First block of group g, in filesystem block units.
        let group_start_block = g * bpg;

        // Within that block, the superblock occupies the same 1024
        // bytes at the same position the primary does: offset 0 for
        // block_size >= 2048, offset 1024 for block_size == 1024.
        // (The 1024-byte skip in the primary is the MBR/BIOS padding
        //  that only exists in group 0.)
        let sb_byte_offset = if block_size == 1024 {
            group_start_block * block_size + 1024
        } else {
            group_start_block * block_size
        };

        let mut buf = [0u8; 1024];
        match dev.read_at(sb_byte_offset, &mut buf) {
            Ok(()) => {}
            Err(_) => continue, // past end of device, try next candidate
        }

        let sb = superblock::parse(&buf);
        if sb.magic != EXT_SUPER_MAGIC {
            continue;
        }

        // Backup has to agree with itself structurally before we trust it.
        let mut sub = Report::new();
        sb.validate(&mut sub);
        if matches!(sub.max_severity(), Some(Severity::Fatal)) {
            continue;
        }

        report.push(Finding {
            severity: Severity::Warn,
            kind: "backup_sb_used",
            detail: format!("recovered superblock from backup at group {}", g),
        });
        return Ok(Some((g, sb)));
    }

    report.push(Finding {
        severity: Severity::Fatal,
        kind: "no_usable_superblock",
        detail: format!(
            "primary superblock unreadable and no valid backup found in {} probed groups",
            backup_group_indexes(total_groups, sparse).len(),
        ),
    });
    Ok(None)
}

/// Recover the best-guess parameters we need to probe for backups
/// when the primary is a total loss. Most Pi-era ext4 filesystems
/// use 4 KiB blocks and 32768 blocks-per-group — that's what
/// `mke2fs.conf -T default` produces. Fall back to these when the
/// primary superblock can't be believed at all.
#[must_use]
pub fn default_probe_params(dev_bytes: u64) -> (u32, u32, u64) {
    // log_block_size = 2 → 4096 B blocks, the usual Pi default.
    const LOG_BLOCK_SIZE: u32 = 2;
    const BLOCKS_PER_GROUP: u32 = 32_768;
    let bs: u64 = 1024 << LOG_BLOCK_SIZE;
    let total_blocks = dev_bytes / bs;
    let total_groups = total_blocks.div_ceil(u64::from(BLOCKS_PER_GROUP));
    (BLOCKS_PER_GROUP, LOG_BLOCK_SIZE, total_groups)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn sparse_includes_group_1_and_powers() {
        // Probe cap is MAX_BACKUP_GROUPS_TO_PROBE (32); we only assert
        // on entries strictly inside that window.
        let v = backup_group_indexes(100, true);
        assert!(v.contains(&1));
        assert!(v.contains(&3));
        assert!(v.contains(&5));
        assert!(v.contains(&7));
        assert!(v.contains(&9));   // 3^2
        assert!(v.contains(&25));  // 5^2
        assert!(v.contains(&27));  // 3^3
        // 49 and beyond get clipped by MAX_BACKUP_GROUPS_TO_PROBE.
        assert!(!v.contains(&49));
        // No non-sparse entries.
        assert!(!v.contains(&2));
        assert!(!v.contains(&4));
        assert!(!v.contains(&6));
    }

    #[test]
    fn dense_is_contiguous() {
        let v = backup_group_indexes(10, false);
        assert_eq!(v, vec![1, 2, 3, 4, 5, 6, 7, 8, 9]);
    }

    #[test]
    fn capped_to_probe_limit() {
        let v = backup_group_indexes(1000, true);
        assert!(v.iter().all(|&g| g <= MAX_BACKUP_GROUPS_TO_PROBE));
    }
}
