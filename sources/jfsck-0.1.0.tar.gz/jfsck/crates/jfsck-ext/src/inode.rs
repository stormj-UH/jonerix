//! Inode parsing and per-inode structural validation.
//!
//! An inode is the fixed-size metadata record describing one file /
//! directory / symlink / device / socket / fifo. Every filesystem has
//! an inode table per block group, sized
//! `inodes_per_group * inode_size` bytes. Inode number 0 is reserved
//! (the "no inode" sentinel); numbering starts at 1.
//!
//! ext2/3 use a 128-byte inode. ext4 typically uses 256 bytes with an
//! `extra_isize` region holding high-precision timestamps and a CRC32C
//! of the inode itself. We parse the first 128 bytes — enough to
//! validate mode, link count, timestamps, and the block pointer
//! bookkeeping that upstream tests exercise.
//!
//! The block pointer layout differs by feature flags: legacy ext2/3
//! uses 15 direct/indirect pointers in `i_block[0..15]`; ext4 with
//! `INCOMPAT_EXTENTS` stores an extent tree header in the same space
//! (`ee_magic` = 0xF30A at `i_block[0..2]`). We detect which without
//! following the pointer graph — that's a phase-2 concern.

use crate::{Finding, Severity, Report};
use crate::group::GroupDesc;
use crate::superblock::Superblock;
use jfsck_io::BlockDev;

/// Mode bits we care about for sanity checking (POSIX).
pub mod mode {
    /// Mask for the file-type bits.
    pub const IFMT:  u16 = 0o170_000;
    /// Regular file.
    pub const IFREG: u16 = 0o100_000;
    /// Directory.
    pub const IFDIR: u16 = 0o040_000;
    /// Symbolic link.
    pub const IFLNK: u16 = 0o120_000;
    /// Character device.
    pub const IFCHR: u16 = 0o020_000;
    /// Block device.
    pub const IFBLK: u16 = 0o060_000;
    /// FIFO / named pipe.
    pub const IFIFO: u16 = 0o010_000;
    /// Unix domain socket.
    pub const IFSOCK: u16 = 0o140_000;
}

/// Extent-tree header magic stored at `i_block[0..2]` when the file
/// uses ext4 extents.
pub const EXT4_EXTENT_MAGIC: u16 = 0xF30A;

/// Parsed inode (first 128 bytes — the ext2-compatible core).
#[derive(Debug, Clone)]
pub struct Inode {
    /// File mode + type (see [`mode`]).
    pub mode: u16,
    /// Low 16 bits of UID.
    pub uid_lo: u16,
    /// File size (low 32 bits — ext4 extends with i_size_high).
    pub size_lo: u32,
    /// Access time (POSIX seconds since epoch).
    pub atime: u32,
    /// Inode change time.
    pub ctime: u32,
    /// Data modification time.
    pub mtime: u32,
    /// Deletion time (0 for live inodes).
    pub dtime: u32,
    /// Low 16 bits of GID.
    pub gid_lo: u16,
    /// Hard-link count.
    pub links_count: u16,
    /// 512-byte sector count (pre-HUGE_FILE); reused when HUGE_FILE set.
    pub blocks_lo: u32,
    /// Flags: IMMUTABLE, APPEND_ONLY, EXTENTS, etc.
    pub flags: u32,
    /// Raw `i_block[0..60]` — interpreted as extent tree if EXTENTS flag set,
    /// otherwise as 15 × 4-byte block pointers.
    pub i_block: [u8; 60],
}

impl Inode {
    /// File type category.
    #[must_use]
    pub fn file_type(&self) -> Option<FileType> {
        match self.mode & mode::IFMT {
            mode::IFREG  => Some(FileType::Regular),
            mode::IFDIR  => Some(FileType::Directory),
            mode::IFLNK  => Some(FileType::Symlink),
            mode::IFCHR  => Some(FileType::CharDev),
            mode::IFBLK  => Some(FileType::BlockDev),
            mode::IFIFO  => Some(FileType::Fifo),
            mode::IFSOCK => Some(FileType::Socket),
            0            => None,  // deleted / never used
            _            => Some(FileType::Unknown),
        }
    }

    /// True if this inode looks allocated (has a non-zero mode or
    /// links or blocks). "Never used" inodes are all-zero and should
    /// not be validated further.
    #[must_use]
    pub fn is_in_use(&self) -> bool {
        self.mode != 0 || self.links_count != 0 || self.blocks_lo != 0 || self.size_lo != 0
    }

    /// True if this inode uses ext4 extents rather than direct/indirect blocks.
    #[must_use]
    pub fn uses_extents(&self) -> bool {
        u16::from_le_bytes([self.i_block[0], self.i_block[1]]) == EXT4_EXTENT_MAGIC
    }
}

/// File-type discriminant.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum FileType {
    /// Regular file.
    Regular,
    /// Directory.
    Directory,
    /// Symbolic link.
    Symlink,
    /// Character device node.
    CharDev,
    /// Block device node.
    BlockDev,
    /// FIFO (named pipe).
    Fifo,
    /// Unix domain socket.
    Socket,
    /// Mode has a value we don't recognise.
    Unknown,
}

/// Parse an inode from a raw byte slice. Requires at least 128 bytes.
#[must_use]
pub fn parse(b: &[u8]) -> Inode {
    let mut i_block = [0u8; 60];
    i_block.copy_from_slice(&b[0x28..0x28 + 60]);
    Inode {
        mode:         u16_le(b, 0x00),
        uid_lo:       u16_le(b, 0x02),
        size_lo:      u32_le(b, 0x04),
        atime:        u32_le(b, 0x08),
        ctime:        u32_le(b, 0x0c),
        mtime:        u32_le(b, 0x10),
        dtime:        u32_le(b, 0x14),
        gid_lo:       u16_le(b, 0x18),
        links_count:  u16_le(b, 0x1a),
        blocks_lo:    u32_le(b, 0x1c),
        flags:        u32_le(b, 0x20),
        i_block,
    }
}

/// Walk every group's inode table and accumulate findings.
///
/// Skips groups flagged `INODE_UNINIT` — per ext4 semantics those
/// inodes are guaranteed to be all-zero without needing to read them.
/// A production checker would still read-and-verify those, but that's
/// the textbook "cheap first" shortcut that lines up with e2fsck's
/// behaviour in read-only mode too.
///
/// # Errors
///
/// Propagates device I/O errors.
pub fn walk_tables<D: BlockDev>(
    dev: &mut D,
    sb: &Superblock,
    descs: &[GroupDesc],
    report: &mut Report,
) -> Result<WalkStats, Box<dyn std::error::Error>> {
    let block_size = sb.block_size();
    let inode_size = u64::from(sb.inode_size);
    // ext4 rev 1+ uses a declared inode_size; if zero (rev 0) fall back to 128.
    let isize = if inode_size == 0 { 128 } else { inode_size };
    let inodes_per_block = block_size / isize;
    let inodes_per_group = u64::from(sb.inodes_per_group);
    let mut stats = WalkStats::default();

    let mut buf = vec![0u8; block_size as usize];
    let dev_bytes = dev.num_blocks() * dev.block_size() as u64;

    for (gi, gd) in descs.iter().enumerate() {
        // Skip uninitialised inode tables — by ext4 contract they
        // contain no live inodes.
        if gd.flags & crate::group::gd_flag::INODE_UNINIT != 0 {
            stats.uninit_groups += 1;
            continue;
        }

        let it_blocks = (inodes_per_group * isize).div_ceil(block_size);
        for ib in 0..it_blocks {
            let bno = gd.inode_table + ib;
            // Guard: filesystem block bno must fit within device length.
            // Comparison is byte-level since the device block size may
            // differ from the fs block size.
            let byte_off = bno * block_size;
            if byte_off + block_size > dev_bytes {
                report.push(Finding {
                    severity: Severity::Error,
                    kind: "inode_table_out_of_range",
                    detail: format!(
                        "group {}: inode table block {} past end of device",
                        gi, bno,
                    ),
                });
                break;
            }
            dev.read_at(byte_off, &mut buf)?;

            for ii in 0..inodes_per_block {
                let off = (ii * isize) as usize;
                // i_block lives at +0x28 and runs 60 bytes; we need ≥0x64.
                if off + 0x64 > buf.len() { break; }
                let inode_no =
                    gi as u64 * inodes_per_group + ib * inodes_per_block + ii + 1;
                let inode = parse(&buf[off..off + isize as usize]);

                if !inode.is_in_use() {
                    stats.unused_inodes += 1;
                    continue;
                }
                stats.used_inodes += 1;

                validate_inode(inode_no, &inode, sb, report, &mut stats);
            }
        }
    }

    Ok(stats)
}

fn validate_inode(
    inode_no: u64,
    ino: &Inode,
    _sb: &Superblock,
    report: &mut Report,
    stats: &mut WalkStats,
) {
    // File-type bits.
    match ino.file_type() {
        None => {
            // mode == 0 but is_in_use returned true — links/size/blocks
            // non-zero. That's a zombie record.
            report.push(Finding {
                severity: Severity::Error,
                kind: "zero_mode_in_use",
                detail: format!(
                    "inode {}: mode = 0 but links={} size={} blocks={}",
                    inode_no, ino.links_count, ino.size_lo, ino.blocks_lo,
                ),
            });
        }
        Some(FileType::Unknown) => {
            report.push(Finding {
                severity: Severity::Error,
                kind: "bad_file_type",
                detail: format!(
                    "inode {}: mode {:#o} has no recognised file-type bits",
                    inode_no, ino.mode,
                ),
            });
        }
        Some(FileType::Directory) => stats.directories += 1,
        _ => {}
    }

    // Deletion time semantics:
    //   - dtime == 0 AND links_count == 0  →  inode about to be freed
    //     (orphan list) OR a legitimate zero-link record after unlink
    //     while still open. Not a problem.
    //   - dtime != 0 AND links_count != 0  →  contradiction. Something
    //     wrote a delete time on a live file.
    if ino.dtime != 0 && ino.links_count != 0 {
        report.push(Finding {
            severity: Severity::Error,
            kind: "dtime_set_on_live",
            detail: format!(
                "inode {}: dtime = {} but links_count = {}",
                inode_no, ino.dtime, ino.links_count,
            ),
        });
    }

    // Timestamp sanity. ext2 timestamps are 32-bit unsigned seconds,
    // so the only obviously-invalid value is one past the current
    // year-2038 threshold AND backwards relative to ctime/mtime
    // pairings. We only reject the all-ones sentinel which is a
    // common hand-corruption signature.
    const POISON_TIME: u32 = 0xFFFF_FFFF;
    if ino.atime == POISON_TIME || ino.ctime == POISON_TIME || ino.mtime == POISON_TIME {
        report.push(Finding {
            severity: Severity::Warn,
            kind: "poison_timestamp",
            detail: format!(
                "inode {}: atime={} ctime={} mtime={} (0xffffffff)",
                inode_no, ino.atime, ino.ctime, ino.mtime,
            ),
        });
    }

    // Extent tree sanity: just the magic. Structural walk is phase 2.
    if ino.uses_extents() {
        stats.extent_inodes += 1;
        // Extent depth at i_block[2..4] must be <= 5 per the kernel
        // (EXT4_MAX_EXTENT_DEPTH). Out-of-range depth is corruption.
        // eh_depth is at offset 6 in the header (offsets: magic 0,
        // entries 2, max 4, depth 6, generation 8). Got this wrong
        // in an earlier draft — caught by a Pi-kernel journal inode
        // whose eh_max was 4, spuriously flagged as "depth 4 > 5" etc.
        let eh_depth = u16::from_le_bytes([ino.i_block[6], ino.i_block[7]]);
        if eh_depth > 5 {
            report.push(Finding {
                severity: Severity::Error,
                kind: "extent_depth_out_of_range",
                detail: format!(
                    "inode {}: extent header depth = {} (max 5)",
                    inode_no, eh_depth,
                ),
            });
        }
    }

    // Link count: 0 + dtime=0 was cleared above. Now flag absurdly
    // high values — ext4 allows up to 65000 but over that needs the
    // `dir_nlink` feature which we detect at SB-level.
    if ino.links_count == u16::MAX {
        report.push(Finding {
            severity: Severity::Error,
            kind: "links_count_max",
            detail: format!("inode {}: links_count = 65535 (max sentinel)", inode_no),
        });
    }
}

/// Aggregate stats produced by an inode-table walk. Useful for both
/// the report summary and for cross-checking against bitmaps in a
/// later pass.
#[derive(Debug, Default)]
pub struct WalkStats {
    /// Inodes with mode != 0 (or other signs of life).
    pub used_inodes: u64,
    /// Inodes that appear unallocated.
    pub unused_inodes: u64,
    /// Directories encountered.
    pub directories: u64,
    /// Files using the ext4 extent tree.
    pub extent_inodes: u64,
    /// Groups whose inode tables we skipped because of INODE_UNINIT.
    pub uninit_groups: u64,
}

fn u16_le(b: &[u8], off: usize) -> u16 {
    u16::from_le_bytes([b[off], b[off + 1]])
}

fn u32_le(b: &[u8], off: usize) -> u32 {
    u32::from_le_bytes([b[off], b[off + 1], b[off + 2], b[off + 3]])
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parse_all_zero() {
        let b = [0u8; 128];
        let i = parse(&b);
        assert_eq!(i.mode, 0);
        assert!(!i.is_in_use());
        assert_eq!(i.file_type(), None);
    }

    #[test]
    fn parse_regular_file() {
        let mut b = [0u8; 128];
        // S_IFREG | 0644
        b[0..2].copy_from_slice(&(mode::IFREG | 0o644).to_le_bytes());
        b[0x1a..0x1c].copy_from_slice(&1u16.to_le_bytes()); // 1 link
        let i = parse(&b);
        assert!(i.is_in_use());
        assert_eq!(i.file_type(), Some(FileType::Regular));
    }

    #[test]
    fn detect_extents_magic() {
        let mut b = [0u8; 128];
        b[0..2].copy_from_slice(&(mode::IFREG | 0o600).to_le_bytes());
        b[0x1a..0x1c].copy_from_slice(&1u16.to_le_bytes());
        // extent magic at i_block[0..2] — which is offset 0x28..0x2a.
        b[0x28..0x2a].copy_from_slice(&EXT4_EXTENT_MAGIC.to_le_bytes());
        let i = parse(&b);
        assert!(i.uses_extents());
    }
}
