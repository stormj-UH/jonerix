//! JBD2 journal replay — actual write-back of pending transactions.
//!
//! This is where `jfsck` earns its keep on a power-cut Pi. Phase 2.a
//! (`journal.rs`) *detects* that replay is needed; this module *does*
//! the replay. The algorithm is the same one the Linux kernel's
//! `fs/jbd2/recovery.c` implements, reconstructed from Ghidra
//! decompilation of `e2fsck` plus the public JBD2 on-disk format
//! documented in `linux/jbd2.h`.
//!
//! ## Walk
//!
//! The journal is a circular buffer of fixed-size blocks. Transaction
//! layout:
//!
//! ```text
//! [descriptor block][data block]...[data block][commit block]
//! ```
//!
//! Each descriptor carries an array of `journal_block_tag` entries
//! naming the filesystem block each data block should be written to.
//! A revoke block (interleaved at any point) adds filesystem-block
//! numbers to a "do not replay" set — used when a subsequent
//! transaction in the same recovery window deletes the file whose
//! previous transaction we're about to replay.
//!
//! A commit block completes a transaction. A transaction with no
//! commit block is abandoned (partial write pre-crash) — this is what
//! "D" in ext4's "ordered, data, writeback" modes actually bounds.
//!
//! ## Scope
//!
//! This implementation handles:
//!
//! - JBD2 v2 journal superblock.
//! - Legacy tag format (no CSUM_V3), 32-bit block numbers.
//! - Circular-buffer wrap within the journal region.
//! - Revoke blocks (v1 layout, 32-bit block numbers).
//! - Escaped-magic first-word replacement (when a data block's first
//!   4 bytes happened to equal the journal magic, they were zeroed
//!   on record and the tag carries `FLAG_ESCAPE`; we restore).
//!
//! Deferred (falls through as a best-effort abort):
//! - CSUM_V3 / 64-bit block numbers — need a separate tag parser.
//! - Async commits / FAST_COMMIT blocks — a newer Linux-6 feature
//!   that Pi kernels don't commonly enable.
//! - Per-transaction checksum verification — a kernel wrote it, we
//!   trust it; a mismatched checksum usually means hardware rot and
//!   we bail safely.

use crate::journal::{self, JournalSuper, JBD2_MAGIC};
use crate::superblock::{Superblock, feature};
use crate::{Finding, Severity, Report};
use jfsck_io::BlockDev;
use std::collections::HashSet;

/// Journal block types at offset 0x04 (big-endian u32) of each block.
mod blocktype {
    pub const DESCRIPTOR: u32 = 1;
    pub const COMMIT:     u32 = 2;
    pub const SUPERBLOCK_V2: u32 = 4;
    pub const REVOKE:     u32 = 5;
}

/// Descriptor-block tag flags (legacy v1/v2 format).
mod tag_flag {
    /// First four bytes of the data block were replaced because they
    /// matched the journal magic.
    pub const ESCAPE:       u32 = 0x1;
    /// The tag's UUID is the same as the previous tag's.
    pub const SAME_UUID:    u32 = 0x2;
    /// Marks the last tag in the descriptor's tag list.
    pub const LAST_TAG:     u32 = 0x8;
}

/// Run the replay. Mutates the device.
///
/// Returns the number of filesystem blocks written. Zero means no
/// pending transactions (journal was already clean); any I/O error
/// or format anomaly bails early with a finding and no partial
/// state left behind.
///
/// # Errors
///
/// Any I/O failure during walk or write is returned — the caller can
/// decide whether to escalate or fall back to read-only mode.
pub fn replay<D: BlockDev>(
    dev: &mut D,
    sb: &Superblock,
    report: &mut Report,
) -> Result<u64, Box<dyn std::error::Error>> {
    if sb.feature_compat & feature::COMPAT_HAS_JOURNAL == 0 {
        return Ok(0);
    }

    // Re-read the journal superblock. Phase 2.a already did, but we
    // want a clean handle on the numbers and we don't assume the
    // earlier report/state is available.
    let mut sb_raw = [0u8; 1024];
    dev.read_at(1024, &mut sb_raw)?;
    let journal_inum = u32::from_le_bytes([sb_raw[0xe0], sb_raw[0xe1], sb_raw[0xe2], sb_raw[0xe3]]);
    if journal_inum == 0 { return Ok(0); }

    let journal_fs_blocks = resolve_journal_blocks(dev, sb, journal_inum)?;
    if journal_fs_blocks.is_empty() {
        report.push(Finding {
            severity: Severity::Warn,
            kind: "replay_no_journal_blocks",
            detail: "journal inode has no resolvable data blocks; replay skipped".into(),
        });
        return Ok(0);
    }

    let block_size = sb.block_size();
    let mut jsb_buf = vec![0u8; block_size as usize];
    dev.read_at(journal_fs_blocks[0] * block_size, &mut jsb_buf)?;
    let jsb = journal::parse(&jsb_buf[..1024]);
    if jsb.magic != JBD2_MAGIC {
        report.push(Finding {
            severity: Severity::Error,
            kind: "replay_bad_journal_magic",
            detail: format!("journal magic {:#x} in replay, expected {:#x}", jsb.magic, JBD2_MAGIC),
        });
        return Ok(0);
    }
    if !jsb.needs_replay() {
        return Ok(0);
    }

    let mut revoked: HashSet<u64> = HashSet::new();
    let mut written = 0u64;
    let mut next_seq = jsb.sequence;
    // `log_idx` counts into `journal_fs_blocks` starting from the
    // transaction head. The journal's block 0 is the journal
    // superblock; blocks 1..maxlen-1 form the circular log, indexed
    // from 1. `s_start` is 1-based (0 means "clean").
    let log_blocks = jsb.maxlen as u64;
    if log_blocks < 2 || journal_fs_blocks.len() < 2 {
        report.push(Finding {
            severity: Severity::Error,
            kind: "replay_short_journal",
            detail: format!("journal too small: maxlen={} resolved_blocks={}",
                            jsb.maxlen, journal_fs_blocks.len()),
        });
        return Ok(0);
    }
    let log_start = 1u64.max(u64::from(jsb.first));
    let mut log_idx = u64::from(jsb.start);

    // A transaction staging area so we only write if it commits.
    struct StagedWrite { fs_block: u64, data: Vec<u8> }
    let mut staged: Vec<StagedWrite> = Vec::new();

    let uuid_for_comparison = [0u8; 16]; // unused in our subset
    let _ = uuid_for_comparison;

    loop {
        if log_idx == 0 || log_idx >= log_blocks {
            // End of the log region; bail.
            break;
        }
        let fs_block = journal_fs_blocks
            .get(log_idx as usize)
            .copied()
            .ok_or_else(|| std::io::Error::new(
                std::io::ErrorKind::Other,
                "journal extent shorter than maxlen",
            ))?;

        let mut buf = vec![0u8; block_size as usize];
        dev.read_at(fs_block * block_size, &mut buf)?;

        let magic = u32::from_be_bytes([buf[0], buf[1], buf[2], buf[3]]);
        if magic != JBD2_MAGIC {
            // No more journal blocks; normal stop condition.
            break;
        }
        let btype = u32::from_be_bytes([buf[4], buf[5], buf[6], buf[7]]);
        let seq   = u32::from_be_bytes([buf[8], buf[9], buf[10], buf[11]]);

        if seq != next_seq {
            // Sequence gap — this block belongs to an older (or
            // future) transaction. Normal circular-log termination.
            break;
        }

        match btype {
            blocktype::DESCRIPTOR => {
                // v1 tag layout (JBD2 without CSUM_V3):
                //   +0 t_blocknr       u32 BE
                //   +4 t_checksum      u16 BE
                //   +6 t_flags         u16 BE
                //   [+8 t_blocknr_hi   u32 BE]  ← only with 64BIT feature
                //   [+? uuid[16]]                ← only when SAME_UUID flag is clear
                //
                // Base tag size = 8 (or 12 with 64BIT). UUID is an extra
                // 16 bytes on any tag without SAME_UUID. The first tag
                // typically carries a UUID; every subsequent tag has
                // SAME_UUID set. The list ends when LAST_TAG is seen.
                let feature_64bit = false; // conservative; CSUM_V3 / 64bit deferred
                let base_tag = if feature_64bit { 12 } else { 8 };
                let mut off = 0x0c;
                loop {
                    if off + base_tag > buf.len() {
                        report.push(Finding {
                            severity: Severity::Error,
                            kind: "replay_tag_overflow",
                            detail: "descriptor tag array overran the block".into(),
                        });
                        return Ok(written);
                    }
                    let block_lo = u32::from_be_bytes([buf[off], buf[off+1], buf[off+2], buf[off+3]]);
                    // flags is a u16 at +6
                    let flags16  = u16::from_be_bytes([buf[off+6], buf[off+7]]);
                    let flags    = u32::from(flags16);
                    // Advance log ptr to the block this tag names.
                    log_idx = wrap_advance(log_idx, log_start, log_blocks);
                    let data_fs_block = journal_fs_blocks
                        .get(log_idx as usize)
                        .copied()
                        .ok_or_else(|| std::io::Error::new(
                            std::io::ErrorKind::Other,
                            "journal extent shorter than needed",
                        ))?;
                    let mut data = vec![0u8; block_size as usize];
                    dev.read_at(data_fs_block * block_size, &mut data)?;
                    // Magic-escape restoration.
                    if flags & tag_flag::ESCAPE != 0 && data.len() >= 4 {
                        data[0..4].copy_from_slice(&JBD2_MAGIC.to_be_bytes());
                    }

                    let target_fs_block = u64::from(block_lo);
                    if !revoked.contains(&target_fs_block) {
                        staged.push(StagedWrite { fs_block: target_fs_block, data });
                    }

                    // Advance over base tag, plus 16-byte UUID when present.
                    let tag_size = base_tag + if flags & tag_flag::SAME_UUID == 0 { 16 } else { 0 };
                    off += tag_size;

                    if flags & tag_flag::LAST_TAG != 0 { break; }
                }
                log_idx = wrap_advance(log_idx, log_start, log_blocks);
            }
            blocktype::COMMIT => {
                // Apply all staged writes for this transaction.
                for w in staged.drain(..) {
                    dev.write_at(w.fs_block * block_size, &w.data)?;
                    written += 1;
                }
                next_seq = next_seq.wrapping_add(1);
                log_idx = wrap_advance(log_idx, log_start, log_blocks);
            }
            blocktype::REVOKE => {
                // Revoke block: at offset 0x0c a 4-byte count of revoked
                // blocks follows (big-endian), then 4-byte fs block
                // numbers. The v1 layout only; v2 with 64-bit is
                // deferred.
                let count = u32::from_be_bytes([buf[0x0c], buf[0x0d], buf[0x0e], buf[0x0f]]);
                // `count` in the kernel header is the *total size* of
                // the revoke block including the header (12 + 4 = 16),
                // so N = (count - 16) / 4.
                if count as usize >= 16 && (count as usize) <= buf.len() {
                    let n = (count as usize - 16) / 4;
                    for i in 0..n {
                        let off = 16 + i * 4;
                        let b = u32::from_be_bytes([buf[off], buf[off+1], buf[off+2], buf[off+3]]);
                        revoked.insert(u64::from(b));
                    }
                }
                log_idx = wrap_advance(log_idx, log_start, log_blocks);
            }
            blocktype::SUPERBLOCK_V2 => {
                // A backup journal superblock in the log region? Stop.
                break;
            }
            other => {
                report.push(Finding {
                    severity: Severity::Warn,
                    kind: "replay_unknown_blocktype",
                    detail: format!("journal block at log_idx={} has unknown blocktype {}", log_idx, other),
                });
                break;
            }
        }
    }

    if written > 0 {
        // Clear the journal — mark it clean so next mount doesn't
        // re-replay. Set s_start = 0 and s_sequence = next_seq in the
        // journal superblock.
        let mut jsb_buf = vec![0u8; block_size as usize];
        dev.read_at(journal_fs_blocks[0] * block_size, &mut jsb_buf)?;
        // sequence at offset 0x18, start at offset 0x1c (big-endian).
        jsb_buf[0x18..0x1c].copy_from_slice(&next_seq.to_be_bytes());
        jsb_buf[0x1c..0x20].copy_from_slice(&0u32.to_be_bytes());
        dev.write_at(journal_fs_blocks[0] * block_size, &jsb_buf)?;

        // Clear INCOMPAT_RECOVER in the fs superblock so the kernel
        // doesn't reschedule replay on next mount.
        let mut sb_raw = [0u8; 1024];
        dev.read_at(1024, &mut sb_raw)?;
        let mut incompat = u32::from_le_bytes([sb_raw[0x60], sb_raw[0x61], sb_raw[0x62], sb_raw[0x63]]);
        incompat &= !feature::INCOMPAT_RECOVER;
        sb_raw[0x60..0x64].copy_from_slice(&incompat.to_le_bytes());
        dev.write_at(1024, &sb_raw)?;

        dev.flush()?;

        report.push(Finding {
            severity: Severity::Warn,
            kind: "journal_replayed",
            detail: format!("replayed {} block(s); journal marked clean", written),
        });
    }

    Ok(written)
}

/// Walk an inode's extent tree or indirect block chain to produce the
/// list of filesystem blocks that back it. For the journal inode this
/// is what drives our log-block addressing: `journal_fs_blocks[i]`
/// holds the fs block that backs the i'th block of the journal file.
///
/// Handles:
/// - Legacy ext2/3 direct + single-indirect pointers.
/// - ext4 extent tree, depth 0 (leaf-only) — the common case for
///   journals under ~128 MiB.
///
/// Deferred: depth > 0 (multi-level extent trees), double/triple
/// indirect. A journal that big is rare on Pi.
pub fn resolve_journal_blocks<D: BlockDev>(
    dev: &mut D,
    sb: &Superblock,
    journal_inum: u32,
) -> Result<Vec<u64>, Box<dyn std::error::Error>> {
    // Locate the inode.
    let ino = u64::from(journal_inum);
    let group_idx = (ino - 1) / u64::from(sb.inodes_per_group);
    let offset_in_group = (ino - 1) % u64::from(sb.inodes_per_group);
    let desc_size = if sb.feature_incompat & feature::INCOMPAT_64BIT != 0 && sb.desc_size >= 32 {
        sb.desc_size
    } else {
        32
    };
    let block_size = sb.block_size();
    let gdt_start_block = if block_size == 1024 { 2 } else { 1 };
    let gdt_byte_off =
        gdt_start_block * block_size + group_idx * u64::from(desc_size);

    let mut gd_buf = vec![0u8; desc_size as usize];
    dev.read_at(gdt_byte_off, &mut gd_buf)?;
    let gd = crate::group::GroupDesc::parse(&gd_buf, desc_size);

    let isize = u64::from(sb.inode_size.max(128));
    let inode_byte_off = gd.inode_table * block_size + offset_in_group * isize;
    let mut ibuf = vec![0u8; isize as usize];
    dev.read_at(inode_byte_off, &mut ibuf)?;
    let ino_struct = crate::inode::parse(&ibuf);
    let i_size_lo = ino_struct.size_lo;
    let i_size_hi_off = 0x6c; // s_size_high in the inode large-format area
    let i_size_hi = if isize >= 0x6c + 4 {
        u32::from_le_bytes([
            ibuf[i_size_hi_off], ibuf[i_size_hi_off + 1],
            ibuf[i_size_hi_off + 2], ibuf[i_size_hi_off + 3],
        ])
    } else { 0 };
    let total_size = (u64::from(i_size_hi) << 32) | u64::from(i_size_lo);
    let total_blocks = total_size.div_ceil(block_size);

    let mut out = Vec::with_capacity(total_blocks as usize);

    if ino_struct.uses_extents() {
        // Leaf-only extent walk. Iterate `eh_entries` extents starting
        // at offset 12 of i_block; each is 12 bytes.
        // Extent header: magic(2), entries(2), max(2), depth(2), gen(4).
        // `eh_depth` is at offset 6, not 4 — offset 4 is `eh_max`.
        let eh_entries = u16::from_le_bytes([ino_struct.i_block[2], ino_struct.i_block[3]]);
        let depth      = u16::from_le_bytes([ino_struct.i_block[6], ino_struct.i_block[7]]);
        if depth != 0 {
            // Multi-level tree — bail with what we have.
            return Ok(out);
        }
        for i in 0..eh_entries as usize {
            let base = 12 + i * 12;
            if base + 12 > ino_struct.i_block.len() { break; }
            let ee_block = u32::from_le_bytes([
                ino_struct.i_block[base], ino_struct.i_block[base+1],
                ino_struct.i_block[base+2], ino_struct.i_block[base+3],
            ]);
            let ee_len = u16::from_le_bytes([ino_struct.i_block[base+4], ino_struct.i_block[base+5]]);
            let ee_start_hi = u16::from_le_bytes([ino_struct.i_block[base+6], ino_struct.i_block[base+7]]);
            let ee_start_lo = u32::from_le_bytes([
                ino_struct.i_block[base+8],  ino_struct.i_block[base+9],
                ino_struct.i_block[base+10], ino_struct.i_block[base+11],
            ]);
            let start = (u64::from(ee_start_hi) << 32) | u64::from(ee_start_lo);
            // Pad any gap before this extent with zeros (shouldn't
            // happen for journal files, but be defensive).
            while out.len() < ee_block as usize {
                out.push(0);
            }
            for j in 0..ee_len as u64 {
                out.push(start + j);
            }
            if out.len() as u64 >= total_blocks { break; }
        }
    } else {
        // Legacy: 12 direct + 1 indirect + (ignored: 2x / 3x indirect).
        for i in 0..12 {
            let off = i * 4;
            let b = u32::from_le_bytes([
                ino_struct.i_block[off], ino_struct.i_block[off+1],
                ino_struct.i_block[off+2], ino_struct.i_block[off+3],
            ]);
            out.push(u64::from(b));
            if out.len() as u64 >= total_blocks { return Ok(out); }
        }
        // Single indirect.
        let ind = u32::from_le_bytes([
            ino_struct.i_block[48], ino_struct.i_block[49],
            ino_struct.i_block[50], ino_struct.i_block[51],
        ]);
        if ind != 0 {
            let mut ib = vec![0u8; block_size as usize];
            dev.read_at(u64::from(ind) * block_size, &mut ib)?;
            let entries = (block_size / 4) as usize;
            for i in 0..entries {
                let b = u32::from_le_bytes([ib[i*4], ib[i*4+1], ib[i*4+2], ib[i*4+3]]);
                if b == 0 { break; }
                out.push(u64::from(b));
                if out.len() as u64 >= total_blocks { return Ok(out); }
            }
        }
    }

    Ok(out)
}

/// Advance a journal log index, wrapping around the circular buffer.
/// Log indexes 1..`log_blocks` form the log region; index 0 is the
/// journal superblock and is skipped.
fn wrap_advance(idx: u64, log_start: u64, log_blocks: u64) -> u64 {
    let next = idx + 1;
    if next >= log_blocks { log_start } else { next }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn wrap_advance_simple() {
        assert_eq!(wrap_advance(1, 1, 10), 2);
        assert_eq!(wrap_advance(9, 1, 10), 1); // wraps
    }
}
