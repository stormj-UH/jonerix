//! Findings for the FAT backend. Mirror of the ext Report; kept here
//! rather than shared so neither backend has to depend on the other.

/// Severity level of a finding.
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord)]
pub enum Severity {
    /// Cosmetic or non-actionable.
    Warn,
    /// Inconsistency that should be repaired.
    Error,
    /// Checker cannot proceed.
    Fatal,
}

/// A single observed issue.
#[derive(Debug, Clone)]
pub struct Finding {
    /// Level of concern.
    pub severity: Severity,
    /// Stable identifier.
    pub kind: &'static str,
    /// Human detail.
    pub detail: String,
}

/// Accumulated findings.
#[derive(Debug, Default)]
pub struct Report {
    findings: Vec<Finding>,
}

impl Report {
    /// Empty report.
    #[must_use]
    pub fn new() -> Self { Self::default() }
    /// Append a finding.
    pub fn push(&mut self, f: Finding) { self.findings.push(f); }
    /// Borrow the list.
    #[must_use]
    pub fn findings(&self) -> &[Finding] { &self.findings }
    /// Highest severity, if any.
    #[must_use]
    pub fn max_severity(&self) -> Option<Severity> {
        self.findings.iter().map(|f| f.severity).max()
    }
    /// Exit code compatible with dosfstools `fsck.fat`.
    #[must_use]
    pub fn exit_code(&self) -> i32 {
        match self.max_severity() {
            None | Some(Severity::Warn) => 0,
            Some(Severity::Error) => 4,
            Some(Severity::Fatal) => 8,
        }
    }
}
