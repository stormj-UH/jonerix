//! FAT repair actions — the write-back half of Phase 3.
//!
//! Three things happen in a FAT repair pass:
//!
//!   1. **FAT mirror reconcile.** If FAT1 and FAT2 disagree, we keep
//!      FAT1 (the spec-authoritative copy) and overwrite FAT2 so the
//!      kernel reads consistent values either way. e2fsprogs' fsck.fat
//!      uses the same "prefer primary" policy by default.
//!
//!   2. **Lost cluster freeing.** Any cluster marked allocated in the
//!      FAT that wasn't reached by the directory walk has no owner.
//!      We zero its entry — the spec-defined "free" value. We do
//!      *not* try to reclaim to FILE####.REC files; data recovery is
//!      a forensic task, not something fsck should attempt. The
//!      correctness guarantee we care about — "no cluster is both
//!      allocated and unreferenced" — is fully met by freeing.
//!
//!   3. **FSInfo update.** After freeing lost clusters the cached
//!      free_count is stale; rewrite it to the true value and zero
//!      the next_free hint (forcing the kernel to rediscover it).
//!
//! We take the report for this pass as an output argument and append
//! findings there; the caller (the `-y` path) then checks whether we
//! made any repairs to decide the exit code.

use crate::boot_sector::BootSector;
use crate::fat::{FatTable, MASK_FAT32};
use crate::{Finding, Severity, Report};
use jfsck_io::BlockDev;
use std::collections::HashSet;

/// Summary of what was done. Zero everywhere means nothing to repair.
#[derive(Debug, Default, Clone, Copy)]
pub struct RepairStats {
    /// Entries copied from FAT1 over FAT2 to restore mirror agreement.
    pub fat_mirror_entries_fixed: u64,
    /// Lost clusters freed (entry zeroed).
    pub lost_clusters_freed: u64,
    /// True if FSInfo was rewritten.
    pub fsinfo_updated: bool,
}

/// Run all repair actions. The `reachable` set comes from the Phase-3
/// directory walk and tells us which clusters are live.
///
/// # Errors
///
/// Propagates I/O errors.
pub fn repair<D: BlockDev>(
    dev: &mut D,
    bs: &BootSector,
    fat: &FatTable,
    reachable: &HashSet<u32>,
    report: &mut Report,
) -> Result<RepairStats, Box<dyn std::error::Error>> {
    let mut stats = RepairStats::default();

    // ─── (1) FAT mirror reconcile ──────────────────────────────────
    if bs.num_fats >= 2 {
        stats.fat_mirror_entries_fixed += reconcile_fat_mirrors(dev, bs, fat)?;
        if stats.fat_mirror_entries_fixed > 0 {
            report.push(Finding {
                severity: Severity::Warn,
                kind: "fat_mirror_reconciled",
                detail: format!(
                    "FAT2 overwritten from FAT1 ({} entries changed)",
                    stats.fat_mirror_entries_fixed,
                ),
            });
        }
    }

    // ─── (2) Lost cluster freeing ──────────────────────────────────
    // Build the set of clusters to free: allocated in FAT but not in
    // `reachable`. We skip entries 0 and 1 (reserved by spec).
    let mut free_list: Vec<u32> = Vec::new();
    let end = fat.cluster_count() as u32 + 2;
    for cluster in 2u32..end {
        let v = match fat.entry(cluster) { Some(v) => v, None => break };
        if FatTable::is_free(v) || FatTable::is_bad(v) { continue; }
        if !reachable.contains(&cluster) {
            free_list.push(cluster);
        }
    }
    if !free_list.is_empty() {
        stats.lost_clusters_freed = free_from_fat(dev, bs, &free_list)? as u64;
        report.push(Finding {
            severity: Severity::Warn,
            kind: "lost_clusters_freed",
            detail: format!(
                "{} lost cluster(s) returned to the free pool",
                stats.lost_clusters_freed,
            ),
        });
    }

    // ─── (3) FSInfo update ─────────────────────────────────────────
    // Recompute the free count from the just-mutated FAT. We walk
    // the in-memory FatTable but add the count of clusters we freed
    // this pass (since the in-memory FAT hasn't been updated).
    let mut new_free = 0u64;
    for cluster in 2u32..end {
        if let Some(v) = fat.entry(cluster) {
            if FatTable::is_free(v) { new_free += 1; }
        }
    }
    new_free += stats.lost_clusters_freed;

    if stats.fat_mirror_entries_fixed > 0 || stats.lost_clusters_freed > 0 {
        write_fsinfo(dev, bs, new_free)?;
        stats.fsinfo_updated = true;
        report.push(Finding {
            severity: Severity::Warn,
            kind: "fsinfo_updated",
            detail: format!("FSInfo free_count set to {}", new_free),
        });
    }

    if stats.fat_mirror_entries_fixed > 0 || stats.lost_clusters_freed > 0 {
        report.push(Finding {
            severity: Severity::Warn,
            kind: "fat_repair_complete",
            detail: format!(
                "FAT mirror fixed {} entries, freed {} lost cluster(s), FSInfo={}",
                stats.fat_mirror_entries_fixed,
                stats.lost_clusters_freed,
                if stats.fsinfo_updated { "rewritten" } else { "unchanged" },
            ),
        });
        dev.flush()?;
    }

    Ok(stats)
}

/// Copy FAT1 over FAT2 (entry by entry, computed from `fat`). Returns
/// the number of entry changes.
fn reconcile_fat_mirrors<D: BlockDev>(
    dev: &mut D,
    bs: &BootSector,
    fat: &FatTable,
) -> Result<u64, Box<dyn std::error::Error>> {
    let sector_size = u64::from(bs.bytes_per_sector);
    let fat_sectors = u64::from(bs.fat_size());
    let fat_bytes = fat_sectors * sector_size;

    let fat1_off = u64::from(bs.reserved_sectors) * sector_size;
    let fat2_off = fat1_off + fat_bytes;

    // Re-serialise FAT1's in-memory view — `fat` holds entries masked
    // to 28 bits, but the high 4 bits on disk are reserved and the
    // kernel preserves them (CLN_SHUT etc. on entry 1). Reading FAT1
    // fresh and copying to FAT2 preserves them without any interpret-
    // ation.
    let mut buf = vec![0u8; fat_bytes as usize];
    dev.read_at(fat1_off, &mut buf)?;

    // Count differences for reporting.
    let mut fat2_buf = vec![0u8; fat_bytes as usize];
    dev.read_at(fat2_off, &mut fat2_buf)?;
    let mut diffs = 0u64;
    for i in 0..fat.cluster_count() + 2 {
        let o = i * 4;
        let a = u32::from_le_bytes([buf[o], buf[o+1], buf[o+2], buf[o+3]]) & MASK_FAT32;
        let b = u32::from_le_bytes([fat2_buf[o], fat2_buf[o+1], fat2_buf[o+2], fat2_buf[o+3]]) & MASK_FAT32;
        if a != b { diffs += 1; }
    }

    if diffs == 0 { return Ok(0); }

    dev.write_at(fat2_off, &buf)?;
    Ok(diffs)
}

/// Write zeros into each entry named in `cluster_list`, across both
/// FAT copies. Returns the count of entries actually modified.
fn free_from_fat<D: BlockDev>(
    dev: &mut D,
    bs: &BootSector,
    cluster_list: &[u32],
) -> Result<usize, Box<dyn std::error::Error>> {
    let sector_size = u64::from(bs.bytes_per_sector);
    let fat_sectors = u64::from(bs.fat_size());
    let fat_bytes = fat_sectors * sector_size;
    let fat1_off = u64::from(bs.reserved_sectors) * sector_size;

    let mut changed = 0usize;
    // Read-modify-write per FAT copy. For a batch of freeings it's
    // cheaper to load the whole FAT into RAM; typical Pi /boot FAT
    // is ~512 KiB so this is fine.
    let mut fat = vec![0u8; fat_bytes as usize];
    dev.read_at(fat1_off, &mut fat)?;
    for &c in cluster_list {
        let o = (c as usize) * 4;
        if o + 4 > fat.len() { continue; }
        let cur = u32::from_le_bytes([fat[o], fat[o+1], fat[o+2], fat[o+3]]);
        // Preserve the top 4 bits (the kernel uses them for flags on
        // entry 1 but on regular entries they should already be 0).
        let new = cur & 0xF000_0000; // zero the cluster value portion
        if new != cur {
            fat[o..o+4].copy_from_slice(&new.to_le_bytes());
            changed += 1;
        }
    }
    dev.write_at(fat1_off, &fat)?;

    if bs.num_fats >= 2 {
        let fat2_off = fat1_off + fat_bytes;
        dev.write_at(fat2_off, &fat)?;
    }

    Ok(changed)
}

/// Rewrite the FSInfo sector's free_count field and zero next_free so
/// the kernel rediscovers it.
fn write_fsinfo<D: BlockDev>(
    dev: &mut D,
    bs: &BootSector,
    new_free: u64,
) -> Result<(), Box<dyn std::error::Error>> {
    if bs.fs_info_sector == 0 || bs.fs_info_sector == 0xFFFF {
        return Ok(());
    }
    let sector_size = u64::from(bs.bytes_per_sector);
    let byte_off = u64::from(bs.fs_info_sector) * sector_size;
    let mut buf = vec![0u8; sector_size as usize];
    dev.read_at(byte_off, &mut buf)?;

    let capped = u32::try_from(new_free).unwrap_or(u32::MAX);
    buf[0x1e8..0x1ec].copy_from_slice(&capped.to_le_bytes());
    // next_free: 0xFFFFFFFF means "unknown, the kernel should rediscover".
    buf[0x1ec..0x1f0].copy_from_slice(&0xFFFF_FFFFu32.to_le_bytes());

    dev.write_at(byte_off, &buf)?;
    Ok(())
}
