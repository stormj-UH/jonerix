//! FAT table reader, cluster-chain walker, and FAT1/FAT2 cross-check.
//!
//! A FAT32 volume carries one or two copies of the FAT table in the
//! reserved region (blocks `reserved_sectors` onward). Each entry is
//! 32 bits on FAT32 (only the low 28 are the cluster number; the top
//! 4 are reserved). The value at entry N is:
//!
//!   - 0x00000000               — free
//!   - 0x00000002..=0x0FFFFFEF  — next cluster in chain
//!   - 0x0FFFFFF0..=0x0FFFFFF6  — reserved (never on Pi)
//!   - 0x0FFFFFF7               — bad cluster marker
//!   - 0x0FFFFFF8..=0x0FFFFFFF  — end of chain
//!
//! We expose two operations at this layer:
//!
//!   - `load` — read the active FAT into memory, compare against the
//!     backup FAT, and return the single source of truth for downstream
//!     consumers. Mismatches are reported.
//!   - `follow_chain` — given a start cluster, yield the sequence of
//!     clusters until an end-of-chain or cycle, bounded by the
//!     cluster count so a malformed chain can't loop forever.

use crate::boot_sector::BootSector;
use crate::{Finding, Severity, Report};
use jfsck_io::BlockDev;

/// End-of-chain threshold (FAT32). Any entry `>= EOC_MIN` is EOC.
pub const EOC_MIN_FAT32: u32 = 0x0FFF_FFF8;
/// Bad cluster marker (FAT32).
pub const BAD_FAT32:    u32 = 0x0FFF_FFF7;
/// Mask for the valid portion of a FAT32 entry (28 bits).
pub const MASK_FAT32:   u32 = 0x0FFF_FFFF;

/// In-memory image of the primary FAT. Index `i` holds the 28-bit
/// value at entry `i` (already masked). Entries 0 and 1 are reserved
/// by the spec: entry 0's low byte is the media descriptor, entry 1
/// carries end-of-chain + "error" flags.
pub struct FatTable {
    entries: Vec<u32>,
}

impl FatTable {
    /// Returns the number of clusters addressable, i.e. the length of
    /// the underlying vector minus the two reserved entries.
    #[must_use]
    pub fn cluster_count(&self) -> usize {
        self.entries.len().saturating_sub(2)
    }

    /// Returns the raw entry at `cluster` (already masked to 28 bits),
    /// or `None` if out of range.
    #[must_use]
    pub fn entry(&self, cluster: u32) -> Option<u32> {
        self.entries.get(cluster as usize).copied()
    }

    /// True iff the given entry value marks the end of a chain.
    #[must_use]
    pub fn is_eoc(entry: u32) -> bool {
        (entry & MASK_FAT32) >= EOC_MIN_FAT32
    }

    /// True iff the entry marks a bad cluster.
    #[must_use]
    pub fn is_bad(entry: u32) -> bool {
        (entry & MASK_FAT32) == BAD_FAT32
    }

    /// True iff the entry marks a free cluster.
    #[must_use]
    pub fn is_free(entry: u32) -> bool {
        (entry & MASK_FAT32) == 0
    }

    /// Iterate the chain starting at `start`, invoking `visit` once
    /// per cluster. The walk stops on end-of-chain, bad-cluster, or
    /// when `visit` returns `false`. Returns the number of clusters
    /// visited.
    ///
    /// Cycle detection: we cap the walk at the FAT's length. Anything
    /// longer is corruption — in practice chains loop by pointing an
    /// entry back at an earlier entry, so the cap bounds the damage.
    pub fn follow_chain(&self, start: u32, mut visit: impl FnMut(u32) -> bool) -> u32 {
        let max = self.entries.len() as u32;
        let mut cur = start;
        let mut count = 0u32;
        while cur >= 2 && (cur as usize) < self.entries.len() && count < max {
            if !visit(cur) { break; }
            let next = self.entries[cur as usize] & MASK_FAT32;
            if Self::is_eoc(next) || Self::is_bad(next) { break; }
            if next < 2 { break; } // free cluster mid-chain is corruption
            cur = next;
            count += 1;
        }
        count
    }
}

/// Load and cross-check both FAT copies. `bs` is the parsed boot
/// sector; we use `num_fats`, `reserved_sectors`, `fat_size()`, and
/// the cluster classification to bound the entry count.
///
/// Returns the primary FAT and logs any FAT1-vs-FAT2 divergences as
/// `fat_mirror_mismatch` findings (only when `num_fats == 2`).
///
/// # Errors
///
/// Propagates device I/O errors.
pub fn load<D: BlockDev>(
    dev: &mut D,
    bs: &BootSector,
    report: &mut Report,
) -> Result<FatTable, Box<dyn std::error::Error>> {
    let sector_size = u64::from(bs.bytes_per_sector);
    let fat_sectors = u64::from(bs.fat_size());
    let fat_bytes = fat_sectors * sector_size;
    let entries = fat_bytes / 4; // FAT32 = 4 bytes/entry

    // First FAT starts right after the reserved sectors.
    let fat1_off = u64::from(bs.reserved_sectors) * sector_size;
    let mut fat1 = vec![0u8; fat_bytes as usize];
    dev.read_at(fat1_off, &mut fat1)?;

    // Decode to u32 entries, masking to 28 bits.
    let mut primary = Vec::with_capacity(entries as usize);
    for i in 0..entries as usize {
        let o = i * 4;
        let v = u32::from_le_bytes([fat1[o], fat1[o + 1], fat1[o + 2], fat1[o + 3]]);
        primary.push(v & MASK_FAT32);
    }

    // If there's a second FAT, compare it byte-for-byte (masked).
    if bs.num_fats >= 2 {
        let fat2_off = fat1_off + fat_bytes;
        let mut fat2 = vec![0u8; fat_bytes as usize];
        dev.read_at(fat2_off, &mut fat2)?;
        let mut mismatches = 0u64;
        for i in 0..entries as usize {
            let o = i * 4;
            let a = primary[i];
            let b = u32::from_le_bytes([fat2[o], fat2[o + 1], fat2[o + 2], fat2[o + 3]])
                    & MASK_FAT32;
            if a != b { mismatches += 1; }
        }
        if mismatches > 0 {
            report.push(Finding {
                severity: Severity::Error,
                kind: "fat_mirror_mismatch",
                detail: format!(
                    "{} entry mismatch(es) between FAT1 and FAT2; using FAT1",
                    mismatches,
                ),
            });
        }
    }

    // Entry 0's low byte should equal the media descriptor and the
    // top nibble should be 0xF. Entry 1's low 28 bits should be EOC.
    // These are the cheapest "did anything touch this region" checks.
    if !primary.is_empty() {
        let e0 = primary[0];
        let expected_e0_lo = u32::from(bs.media);
        if (e0 & 0xff) != expected_e0_lo {
            report.push(Finding {
                severity: Severity::Warn,
                kind: "fat_entry0_media_mismatch",
                detail: format!(
                    "FAT entry 0 = {:#010x}, low byte {:#x} ≠ media {:#x}",
                    e0, e0 & 0xff, expected_e0_lo,
                ),
            });
        }
    }
    // Note: the original FAT32 spec asked entry 1 to be EOC, but
    // modern mkfs.fat / Linux overload the high bits with CLN_SHUT
    // (0x0800_0000) and HARD_ERROR (0x0400_0000) flags. Those values
    // fail a naive "is_eoc" test; we don't flag it because the
    // kernel reads the flag bits and ignores whether the remainder
    // forms an EOC value.

    Ok(FatTable { entries: primary })
}
