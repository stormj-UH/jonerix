//! Directory tree walker.
//!
//! FAT directories are a sequence of 32-byte entries. The byte at
//! offset 11 (the attribute byte) classifies each entry:
//!
//!   - 0x00  — unused; subsequent entries are also unused (end of
//!             list in scan order, per Microsoft spec).
//!   - 0xE5  — deleted; first name byte was overwritten.
//!   - else  — active: regular, directory, volume-label, LFN sub-entry.
//!
//! An LFN sub-entry has attributes == 0x0F. These cluster before the
//! short-name "canonical" entry they annotate.
//!
//! We don't need to decode names here. What we need is:
//!
//! 1. The cluster each active entry points at (for directories and
//!    files), so we can recurse and track "clusters reachable from
//!    the root". The FAT32 cluster pointer is split across two u16
//!    fields at offsets 0x14 (hi) and 0x1a (lo).
//! 2. Whether the entry is a subdirectory (attribute bit 4 set).
//! 3. Recognise '.' and '..' so we don't recurse back up the tree.

use crate::boot_sector::{BootSector, FatType};
use crate::fat::FatTable;
use crate::{Finding, Severity, Report};
use jfsck_io::BlockDev;

/// Directory-entry attribute bits from the short-name directory record
/// (byte offset 11). Combinations of the lower four bits form the
/// sentinel that marks an LFN sub-entry.
pub mod attr {
    /// Entry is read-only.
    pub const READ_ONLY: u8 = 0x01;
    /// Entry is hidden from default `DIR` listings.
    pub const HIDDEN:    u8 = 0x02;
    /// System file (firmware / OS reserved).
    pub const SYSTEM:    u8 = 0x04;
    /// Volume label entry in the root directory.
    pub const VOLUME_ID: u8 = 0x08;
    /// Entry is a subdirectory.
    pub const DIRECTORY: u8 = 0x10;
    /// Archive bit (backup utility flag).
    pub const ARCHIVE:   u8 = 0x20;
    /// Sentinel marking an LFN sub-entry
    /// (= READ_ONLY | HIDDEN | SYSTEM | VOLUME_ID).
    pub const LFN:       u8 = 0x0F;
}

/// Result of a tree walk: every cluster we reached (transitively) by
/// following directory entries out from the root. This is the key
/// input for lost-cluster detection — any cluster marked allocated
/// in the FAT but not in this set is lost.
pub struct WalkResult {
    /// Clusters reachable from the root directory's file graph.
    pub reachable: std::collections::HashSet<u32>,
    /// Count of plain-file entries (for stats).
    pub files: u64,
    /// Count of subdirectory entries (excluding '.'/'..').
    pub dirs: u64,
    /// Count of LFN sub-entries encountered (part of filenames).
    pub lfn_entries: u64,
}

/// Walk the directory tree starting at the root directory.
///
/// For FAT32, `bs.root_cluster` is the starting cluster of the root
/// directory — it lives in the data area like any other directory.
/// (FAT12/16 have a fixed-location root directory region instead;
/// supporting them is a small extension below the cluster walk, not
/// implemented yet because the Pi boot partition is always FAT32.)
///
/// # Errors
///
/// Propagates device I/O errors.
pub fn walk<D: BlockDev>(
    dev: &mut D,
    bs: &BootSector,
    fat: &FatTable,
    report: &mut Report,
) -> Result<WalkResult, Box<dyn std::error::Error>> {
    let mut result = WalkResult {
        reachable: std::collections::HashSet::new(),
        files: 0,
        dirs: 0,
        lfn_entries: 0,
    };

    if bs.fat_type() != FatType::Fat32 {
        // FAT12/16 root directory is fixed-position; scope-deferred.
        report.push(Finding {
            severity: Severity::Warn,
            kind: "fat1216_root_not_walked",
            detail: format!("{:?} root directory walker not yet implemented", bs.fat_type()),
        });
        return Ok(result);
    }

    if bs.root_cluster < 2 {
        report.push(Finding {
            severity: Severity::Error,
            kind: "fat32_bad_root_cluster",
            detail: format!("root_cluster = {}, must be >= 2", bs.root_cluster),
        });
        return Ok(result);
    }

    // Depth-first walk with a queue so an oversized tree doesn't blow
    // the stack. `to_visit` holds (cluster, is_root) pairs; the flag
    // just suppresses a warning if the root's first cluster is 0 for
    // some reason (shouldn't happen on a valid FAT32).
    let mut to_visit: Vec<u32> = vec![bs.root_cluster];
    let mut visited_dirs: std::collections::HashSet<u32> =
        std::collections::HashSet::new();

    while let Some(start_cluster) = to_visit.pop() {
        if !visited_dirs.insert(start_cluster) { continue; }
        // Every cluster of the directory itself is reachable.
        let chain = collect_chain(fat, start_cluster);
        for &c in &chain {
            result.reachable.insert(c);
        }
        // Read each cluster and scan its 32-byte entries.
        scan_directory(dev, bs, fat, &chain, &mut result, &mut to_visit, report)?;
    }

    Ok(result)
}

/// Collect the full cluster chain starting at `start`. The walker
/// bounds itself by the total FAT length so a malformed cycle can't
/// loop forever; detected cycles get pushed up as findings in the
/// caller.
fn collect_chain(fat: &FatTable, start: u32) -> Vec<u32> {
    let mut out = Vec::new();
    fat.follow_chain(start, |c| { out.push(c); true });
    out
}

fn scan_directory<D: BlockDev>(
    dev: &mut D,
    bs: &BootSector,
    fat: &FatTable,
    chain: &[u32],
    result: &mut WalkResult,
    to_visit: &mut Vec<u32>,
    report: &mut Report,
) -> Result<(), Box<dyn std::error::Error>> {
    let sector_size = u64::from(bs.bytes_per_sector);
    let cluster_bytes = u64::from(bs.sectors_per_cluster) * sector_size;
    let root_dir_sectors = u64::from(bs.root_dir_sectors());
    let data_start_sector =
        u64::from(bs.root_dir_start_sector()) + root_dir_sectors;

    for &cluster in chain {
        // Translate cluster number → byte offset in the data area.
        // First data cluster is 2, at sector `data_start_sector`.
        let byte_off = (data_start_sector
            + u64::from(cluster - 2) * u64::from(bs.sectors_per_cluster))
            * sector_size;

        let mut cbuf = vec![0u8; cluster_bytes as usize];
        dev.read_at(byte_off, &mut cbuf)?;

        // Iterate 32-byte entries.
        for entry in cbuf.chunks_exact(32) {
            match entry[0] {
                0x00 => return Ok(()),      // end of directory list
                0xE5 => continue,           // deleted
                _ => {}
            }
            let attrs = entry[11];

            // Skip LFN sub-entries (they describe the next short-name
            // entry, they don't name data clusters themselves).
            if attrs == attr::LFN {
                result.lfn_entries += 1;
                continue;
            }

            // Skip volume label entries; they carry no data cluster.
            if attrs & attr::VOLUME_ID != 0 {
                continue;
            }

            // Decode the start cluster: hi at +0x14 (u16), lo at +0x1a (u16).
            let cluster_hi = u16::from_le_bytes([entry[0x14], entry[0x15]]);
            let cluster_lo = u16::from_le_bytes([entry[0x1a], entry[0x1b]]);
            let start_cluster = (u32::from(cluster_hi) << 16) | u32::from(cluster_lo);

            // Skip '.' and '..' — they point back up; we'd infinite-
            // loop across the tree. Detected by the leading byte of
            // the name field being '.'.
            let is_dir = attrs & attr::DIRECTORY != 0;
            let is_dot = is_dir && entry[0] == b'.' && (entry[1] == b'.' || entry[1] == b' ');
            if is_dot { continue; }

            // 0- and 1-starts are legit for zero-length files (no data
            // clusters allocated), which means there's nothing to add
            // to `reachable`. Only chase cluster >= 2.
            if start_cluster >= 2 {
                // Check the FAT entry looks sensible.
                match fat.entry(start_cluster) {
                    Some(v) if FatTable::is_free(v) => {
                        report.push(Finding {
                            severity: Severity::Error,
                            kind: "dir_entry_into_free_cluster",
                            detail: format!(
                                "directory entry points at free cluster {}",
                                start_cluster,
                            ),
                        });
                        continue;
                    }
                    Some(v) if FatTable::is_bad(v) => {
                        report.push(Finding {
                            severity: Severity::Error,
                            kind: "dir_entry_into_bad_cluster",
                            detail: format!(
                                "directory entry points at bad cluster {}",
                                start_cluster,
                            ),
                        });
                        continue;
                    }
                    Some(_) => {}
                    None => {
                        report.push(Finding {
                            severity: Severity::Error,
                            kind: "dir_entry_out_of_range",
                            detail: format!(
                                "directory entry start cluster {} past FAT end",
                                start_cluster,
                            ),
                        });
                        continue;
                    }
                }

                // Walk the file's cluster chain into `reachable`.
                let mut visited = 0u32;
                fat.follow_chain(start_cluster, |c| {
                    result.reachable.insert(c);
                    visited += 1;
                    true
                });
                // Zero-length walk means a self-referential entry;
                // follow_chain will have bailed on the first cycle
                // check. Count that as reachable-of-one.

                if is_dir {
                    to_visit.push(start_cluster);
                    result.dirs += 1;
                } else {
                    result.files += 1;
                }
            } else if is_dir && start_cluster < 2 {
                // Directory entry claiming cluster 0 or 1 — corruption.
                report.push(Finding {
                    severity: Severity::Error,
                    kind: "subdir_zero_cluster",
                    detail: format!(
                        "subdirectory entry has invalid start cluster {}",
                        start_cluster,
                    ),
                });
            }
        }
    }
    Ok(())
}
