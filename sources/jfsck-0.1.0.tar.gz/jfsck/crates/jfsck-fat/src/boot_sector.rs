//! FAT boot sector (BPB) parsing and validation.
//!
//! The first 512 bytes of a FAT volume is the boot sector, and for
//! FAT32 the BIOS Parameter Block (BPB) extends into it further than
//! for FAT12/16. The layout differs between FAT32 and earlier variants
//! starting at offset 0x24 (where FAT32 replaces the early extended
//! BPB with a new set of fields).
//!
//! We detect FAT type from the volume's cluster count, not from any
//! header field — this is how the Microsoft spec says to do it and
//! also how fsck.fat does it in practice:
//!
//! ```text
//!   cluster_count < 4085           => FAT12
//!   4085 <= cluster_count < 65525  => FAT16
//!   cluster_count >= 65525         => FAT32
//! ```

use crate::{Finding, Severity, Report};
use jfsck_io::BlockDev;

/// Parsed boot sector. Only the fields actually used by fsck are
/// stored; the rest of the 512-byte block is ignored.
#[derive(Debug, Clone)]
pub struct BootSector {
    /// OEM name bytes (8 ASCII).
    pub oem_name: [u8; 8],
    /// Bytes per sector — 512, 1024, 2048, or 4096.
    pub bytes_per_sector: u16,
    /// Sectors per cluster — power of two, 1..=128.
    pub sectors_per_cluster: u8,
    /// Reserved sector count (includes the boot sector).
    pub reserved_sectors: u16,
    /// Number of FAT copies — 1 or 2.
    pub num_fats: u8,
    /// Root dir entries (FAT12/16 only; must be 0 on FAT32).
    pub root_entries: u16,
    /// 16-bit total sector count (0 if `total_sectors_32` used).
    pub total_sectors_16: u16,
    /// Media descriptor byte.
    pub media: u8,
    /// Sectors per FAT (FAT12/16 only; must be 0 on FAT32).
    pub fat_size_16: u16,
    /// Sectors per track (CHS geometry; not meaningful for us).
    pub sectors_per_track: u16,
    /// Heads (CHS geometry; not meaningful for us).
    pub num_heads: u16,
    /// Hidden sectors preceding this partition.
    pub hidden_sectors: u32,
    /// 32-bit total sector count (used if `total_sectors_16` is 0).
    pub total_sectors_32: u32,

    // FAT32-only fields from offset 0x24:
    /// Sectors per FAT (FAT32).
    pub fat_size_32: u32,
    /// Extended flags: b0-3 active FAT, b7 mirroring disabled.
    pub ext_flags: u16,
    /// Filesystem version.
    pub fs_version: u16,
    /// First cluster of the root directory.
    pub root_cluster: u32,
    /// Sector containing FSInfo.
    pub fs_info_sector: u16,
    /// Sector containing the backup boot sector.
    pub backup_boot_sector: u16,

    /// Signature at offset 510 — must be 0xAA55.
    pub signature: u16,
}

impl BootSector {
    /// True iff the on-disk signature is the required `0xAA55`.
    #[must_use]
    pub fn is_valid_signature(&self) -> bool {
        self.signature == 0xAA55
    }

    /// Bytes per cluster.
    #[must_use]
    pub fn cluster_size(&self) -> u32 {
        u32::from(self.bytes_per_sector) * u32::from(self.sectors_per_cluster)
    }

    /// Total sectors, preferring the 32-bit field when non-zero.
    #[must_use]
    pub fn total_sectors(&self) -> u32 {
        if self.total_sectors_32 != 0 {
            self.total_sectors_32
        } else {
            u32::from(self.total_sectors_16)
        }
    }

    /// Sectors occupied by a single FAT.
    #[must_use]
    pub fn fat_size(&self) -> u32 {
        if self.fat_size_16 != 0 {
            u32::from(self.fat_size_16)
        } else {
            self.fat_size_32
        }
    }

    /// Start sector of the root directory region (FAT12/16) or the
    /// data region (FAT32, where root_cluster lives in the data area).
    #[must_use]
    pub fn root_dir_start_sector(&self) -> u32 {
        u32::from(self.reserved_sectors) + u32::from(self.num_fats) * self.fat_size()
    }

    /// Sectors occupied by the fixed root directory (FAT12/16).
    /// Zero on FAT32.
    #[must_use]
    pub fn root_dir_sectors(&self) -> u32 {
        let bytes = u32::from(self.root_entries) * 32;
        bytes.div_ceil(u32::from(self.bytes_per_sector))
    }

    /// Total number of data-area clusters. This is the value used to
    /// classify the filesystem as FAT12/16/32.
    #[must_use]
    pub fn cluster_count(&self) -> u32 {
        let total = self.total_sectors();
        let root = self.root_dir_sectors();
        let data_start = self.root_dir_start_sector() + root;
        if total <= data_start { return 0; }
        (total - data_start) / u32::from(self.sectors_per_cluster)
    }

    /// Classify this volume as FAT12, FAT16, or FAT32.
    #[must_use]
    pub fn fat_type(&self) -> FatType {
        let c = self.cluster_count();
        if c < 4085 { FatType::Fat12 }
        else if c < 65525 { FatType::Fat16 }
        else { FatType::Fat32 }
    }

    /// Cross-check internal consistency; append to `report`.
    pub fn validate(&self, report: &mut Report) {
        // Bytes per sector must be a power of two, 512..=4096.
        if !matches!(self.bytes_per_sector, 512 | 1024 | 2048 | 4096) {
            report.push(Finding {
                severity: Severity::Fatal,
                kind: "bad_bytes_per_sector",
                detail: format!("bytes_per_sector = {}", self.bytes_per_sector),
            });
        }
        // Sectors per cluster must be a power of two, 1..=128.
        if self.sectors_per_cluster == 0
            || !self.sectors_per_cluster.is_power_of_two()
            || self.sectors_per_cluster > 128
        {
            report.push(Finding {
                severity: Severity::Fatal,
                kind: "bad_sectors_per_cluster",
                detail: format!("sectors_per_cluster = {}", self.sectors_per_cluster),
            });
        }
        // Cluster size must not exceed 32 KiB in the Microsoft spec
        // (larger values exist but corrupt older consumers).
        let cs = self.cluster_size();
        if cs > 32 * 1024 {
            report.push(Finding {
                severity: Severity::Warn,
                kind: "oversized_cluster",
                detail: format!("cluster_size = {} bytes (> 32 KiB)", cs),
            });
        }
        // Reserved sectors must be at least 1 (the boot sector). On
        // FAT32 conventionally 32.
        if self.reserved_sectors == 0 {
            report.push(Finding {
                severity: Severity::Fatal,
                kind: "zero_reserved_sectors",
                detail: "reserved_sectors = 0 (must include the boot sector)".into(),
            });
        }
        // num_fats: 1 or 2.
        if !matches!(self.num_fats, 1 | 2) {
            report.push(Finding {
                severity: Severity::Error,
                kind: "bad_num_fats",
                detail: format!("num_fats = {} (must be 1 or 2)", self.num_fats),
            });
        }
        // FAT32 invariants: root_entries must be 0, fat_size_16 must
        // be 0, fat_size_32 and root_cluster must be set.
        if self.fat_type() == FatType::Fat32 {
            if self.root_entries != 0 {
                report.push(Finding {
                    severity: Severity::Error,
                    kind: "fat32_nonzero_root_entries",
                    detail: format!("root_entries = {} on FAT32", self.root_entries),
                });
            }
            if self.fat_size_16 != 0 {
                report.push(Finding {
                    severity: Severity::Error,
                    kind: "fat32_fat_size_16_nonzero",
                    detail: format!("fat_size_16 = {} on FAT32", self.fat_size_16),
                });
            }
            if self.fat_size_32 == 0 {
                report.push(Finding {
                    severity: Severity::Fatal,
                    kind: "fat32_zero_fat_size_32",
                    detail: "fat_size_32 = 0 on FAT32".into(),
                });
            }
            if self.root_cluster < 2 {
                report.push(Finding {
                    severity: Severity::Error,
                    kind: "fat32_bad_root_cluster",
                    detail: format!("root_cluster = {} (must be >= 2)", self.root_cluster),
                });
            }
        }
    }
}

/// Which flavour of FAT this is, inferred from cluster count per MS.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum FatType {
    /// FAT12 — floppy era.
    Fat12,
    /// FAT16 — legacy.
    Fat16,
    /// FAT32 — Pi boot partition.
    Fat32,
}

/// Read the 512-byte boot sector from the start of the device.
///
/// # Errors
///
/// Propagates I/O errors.
pub fn read<D: BlockDev>(dev: &mut D) -> Result<BootSector, Box<dyn std::error::Error>> {
    let bs = dev.block_size();
    // The boot sector is 512 bytes; if the device block size is
    // 4 KiB, we read one block and use the first 512 bytes.
    let mut buf = vec![0u8; bs.max(512)];
    dev.read_block(0, &mut buf)?;
    Ok(parse(&buf[..512]))
}

/// Parse a 512-byte boot sector buffer.
#[must_use]
pub fn parse(b: &[u8]) -> BootSector {
    let mut oem = [0u8; 8];
    oem.copy_from_slice(&b[0x03..0x0b]);
    BootSector {
        oem_name:            oem,
        bytes_per_sector:    u16::from_le_bytes([b[0x0b], b[0x0c]]),
        sectors_per_cluster: b[0x0d],
        reserved_sectors:    u16::from_le_bytes([b[0x0e], b[0x0f]]),
        num_fats:            b[0x10],
        root_entries:        u16::from_le_bytes([b[0x11], b[0x12]]),
        total_sectors_16:    u16::from_le_bytes([b[0x13], b[0x14]]),
        media:               b[0x15],
        fat_size_16:         u16::from_le_bytes([b[0x16], b[0x17]]),
        sectors_per_track:   u16::from_le_bytes([b[0x18], b[0x19]]),
        num_heads:           u16::from_le_bytes([b[0x1a], b[0x1b]]),
        hidden_sectors:      u32_le(b, 0x1c),
        total_sectors_32:    u32_le(b, 0x20),
        fat_size_32:         u32_le(b, 0x24),
        ext_flags:           u16::from_le_bytes([b[0x28], b[0x29]]),
        fs_version:          u16::from_le_bytes([b[0x2a], b[0x2b]]),
        root_cluster:        u32_le(b, 0x2c),
        fs_info_sector:      u16::from_le_bytes([b[0x30], b[0x31]]),
        backup_boot_sector:  u16::from_le_bytes([b[0x32], b[0x33]]),
        signature:           u16::from_le_bytes([b[0x1fe], b[0x1ff]]),
    }
}

fn u32_le(b: &[u8], off: usize) -> u32 {
    u32::from_le_bytes([b[off], b[off + 1], b[off + 2], b[off + 3]])
}

#[cfg(test)]
mod tests {
    use super::*;

    fn minimal_fat32() -> Vec<u8> {
        let mut b = vec![0u8; 512];
        b[0x0b..0x0d].copy_from_slice(&512u16.to_le_bytes()); // bytes/sector
        b[0x0d] = 8;                                          // sectors/cluster
        b[0x0e..0x10].copy_from_slice(&32u16.to_le_bytes());  // reserved
        b[0x10] = 2;                                          // 2 FATs
        b[0x15] = 0xf8;                                       // media
        // Make the cluster count large enough to classify as FAT32.
        // 1 048 576 sectors - (32 reserved + 2*512 FAT) = 1 047 520
        // / 8 sec-per-cluster = 130 940 clusters, comfortably past
        // the 65 525 threshold.
        b[0x20..0x24].copy_from_slice(&1_048_576u32.to_le_bytes());  // total sectors 32
        b[0x24..0x28].copy_from_slice(&512u32.to_le_bytes());     // fat size 32
        b[0x2c..0x30].copy_from_slice(&2u32.to_le_bytes());       // root cluster
        b[0x1fe..0x200].copy_from_slice(&0xAA55u16.to_le_bytes());// signature
        b
    }

    #[test]
    fn parse_and_classify_fat32() {
        let b = minimal_fat32();
        let bs = parse(&b);
        assert!(bs.is_valid_signature());
        assert_eq!(bs.bytes_per_sector, 512);
        assert_eq!(bs.sectors_per_cluster, 8);
        assert_eq!(bs.cluster_size(), 4096);
        assert_eq!(bs.fat_type(), FatType::Fat32);
    }

    #[test]
    fn validate_minimal_fat32_clean() {
        let b = minimal_fat32();
        let bs = parse(&b);
        let mut rep = Report::new();
        bs.validate(&mut rep);
        for f in rep.findings() {
            panic!("unexpected finding: {:?}", f);
        }
    }
}
