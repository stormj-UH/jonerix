//! FSInfo sector verification.
//!
//! FAT32 volumes reserve a 512-byte "FSInfo" structure at the sector
//! named by `fs_info_sector` in the BPB (typically sector 1). It
//! caches two hints the kernel uses to skip the FAT scan on mount:
//!
//! ```text
//!   +0x000 : 0x41615252   — leading signature "RRaA"
//!   +0x1e4 : 0x61417272   — trailing signature "rrAa"
//!   +0x1e8 : free_count    — cached free cluster count, or 0xFFFF_FFFF
//!                            = "unknown, please recompute"
//!   +0x1ec : next_free     — cluster to start searching for free from
//!                            when allocating, or 0xFFFF_FFFF = unknown
//!   +0x1fe : 0xAA55        — trailing signature matching the boot sec
//! ```
//!
//! We verify the signatures, compare the cached free count to what
//! we actually computed from the FAT, and log mismatches. The `-y`
//! repair path (not yet wired for FAT) will rewrite the FSInfo sector
//! to match the truth.

use crate::boot_sector::BootSector;
use crate::{Finding, Severity, Report};
use jfsck_io::BlockDev;

/// "RRaA" at +0.
pub const LEAD_SIG:    u32 = 0x4161_5252;
/// "rrAa" at +0x1e4.
pub const STRUCT_SIG:  u32 = 0x6141_7272;
/// Boot-sector-style trailing signature at +0x1fe.
pub const TRAIL_SIG16: u16 = 0xaa55;

/// Sentinel meaning "unknown; recompute from the FAT".
pub const UNKNOWN:     u32 = 0xFFFF_FFFF;

/// Read the FSInfo sector, validate signatures, and compare the
/// cached free-count against `actual_free`.
///
/// # Errors
///
/// Propagates device I/O errors.
pub fn verify<D: BlockDev>(
    dev: &mut D,
    bs: &BootSector,
    actual_free: u64,
    report: &mut Report,
) -> Result<(), Box<dyn std::error::Error>> {
    if bs.fs_info_sector == 0 || bs.fs_info_sector == 0xFFFF {
        // The BPB says "no FSInfo"; not an error, just nothing to do.
        return Ok(());
    }
    let sector_size = u64::from(bs.bytes_per_sector);
    let byte_off = u64::from(bs.fs_info_sector) * sector_size;
    let mut buf = vec![0u8; sector_size as usize];
    dev.read_at(byte_off, &mut buf)?;

    let lead    = u32::from_le_bytes([buf[0x000], buf[0x001], buf[0x002], buf[0x003]]);
    let struc   = u32::from_le_bytes([buf[0x1e4], buf[0x1e5], buf[0x1e6], buf[0x1e7]]);
    let free    = u32::from_le_bytes([buf[0x1e8], buf[0x1e9], buf[0x1ea], buf[0x1eb]]);
    let next    = u32::from_le_bytes([buf[0x1ec], buf[0x1ed], buf[0x1ee], buf[0x1ef]]);
    let trail16 = u16::from_le_bytes([buf[0x1fe], buf[0x1ff]]);

    if lead != LEAD_SIG {
        report.push(Finding {
            severity: Severity::Error,
            kind: "fsinfo_bad_lead_sig",
            detail: format!("FSInfo lead signature {:#010x}, expected {:#010x}", lead, LEAD_SIG),
        });
    }
    if struc != STRUCT_SIG {
        report.push(Finding {
            severity: Severity::Error,
            kind: "fsinfo_bad_struct_sig",
            detail: format!("FSInfo struct signature {:#010x}, expected {:#010x}", struc, STRUCT_SIG),
        });
    }
    if trail16 != TRAIL_SIG16 {
        report.push(Finding {
            severity: Severity::Error,
            kind: "fsinfo_bad_trail_sig",
            detail: format!("FSInfo trail signature {:#06x}, expected {:#06x}", trail16, TRAIL_SIG16),
        });
    }

    if free != UNKNOWN && u64::from(free) != actual_free {
        // Drift is common and expected — the kernel updates FSInfo
        // lazily. On a mounted FS a delta of dozens or even hundreds
        // of clusters is routine. Only graduate to Error when the
        // mismatch exceeds ~1% of the total cluster count, which
        // indicates structural corruption rather than lag.
        let delta = if u64::from(free) > actual_free {
            u64::from(free) - actual_free
        } else {
            actual_free - u64::from(free)
        };
        let total_clusters = u64::from(bs.cluster_count());
        let threshold = (total_clusters / 100).max(64);
        let sev = if delta > threshold { Severity::Error } else { Severity::Warn };
        report.push(Finding {
            severity: sev,
            kind: "fsinfo_free_count_mismatch",
            detail: format!(
                "FSInfo free_count = {}, actual = {} (delta {}; threshold {})",
                free, actual_free, delta, threshold,
            ),
        });
    }

    // `next_free` is advisory. We report it for visibility but don't
    // treat any value as an error — even 0 or 0xFFFFFFFF are legal.
    let _ = next;

    Ok(())
}
