//! FAT12/16/32 filesystem checker.
//!
//! The Pi boot partition is always FAT32 on modern distros, formatted
//! with 512-byte or 4 KiB logical sectors and a single FAT copy (rarely
//! two). FAT12 / FAT16 are in scope only because they share 95% of the
//! checking code; we pay almost nothing to support them.
//!
//! Clean-room reimplementation derived from Ghidra decompilation of
//! `fsck.fat` (dosfstools 4.2, Alpine x86_64). On-disk layout constants
//! from Microsoft's public FAT32 specification and the Linux UAPI
//! `<linux/msdos_fs.h>`.

#![forbid(unsafe_op_in_unsafe_fn)]
#![deny(missing_docs)]

pub mod boot_sector;
pub mod dir;
pub mod fat;
pub mod fs_info;
pub mod repair;
pub mod report;

pub use boot_sector::BootSector;
pub use fat::FatTable;
pub use report::{Finding, Severity, Report};

use jfsck_io::BlockDev;

/// Run a read-only check against the device.
///
/// # Errors
///
/// Only I/O errors that prevent checking are returned; filesystem
/// inconsistencies are returned as findings in the report.
pub fn check_ro<D: BlockDev>(dev: &mut D) -> Result<Report, Box<dyn std::error::Error>> {
    let mut report = Report::new();
    let bs = boot_sector::read(dev)?;
    if !bs.is_valid_signature() {
        report.push(Finding {
            severity: Severity::Fatal,
            kind: "bad_boot_signature",
            detail: format!(
                "boot sector signature {:#06x}, expected 0xaa55",
                bs.signature
            ),
        });
        return Ok(report);
    }
    bs.validate(&mut report);

    // BPB fatal problems make every subsequent math unsound; bail
    // before we start reading the FAT at a nonsense offset.
    if matches!(report.max_severity(), Some(Severity::Fatal)) {
        return Ok(report);
    }

    // FAT traversal is scoped to FAT32 for now (the Pi boot
    // partition). FAT12/16 produce a Warn and skip.
    if bs.fat_type() != boot_sector::FatType::Fat32 {
        return Ok(report);
    }

    let fat = match fat::load(dev, &bs, &mut report) {
        Ok(f) => f,
        Err(e) => {
            report.push(Finding {
                severity: Severity::Error,
                kind: "fat_load_error",
                detail: format!("FAT read: {}", e),
            });
            return Ok(report);
        }
    };

    // Walk the directory tree from the root; collect every cluster
    // reachable from a live directory entry.
    let walk = match dir::walk(dev, &bs, &fat, &mut report) {
        Ok(w) => w,
        Err(e) => {
            report.push(Finding {
                severity: Severity::Error,
                kind: "dir_walk_error",
                detail: format!("directory walk: {}", e),
            });
            return Ok(report);
        }
    };

    // Lost-cluster detection: every cluster marked allocated in the
    // FAT that is NOT reachable from the walk is lost. Walk the FAT
    // linearly and compare. Also count free clusters for the FSInfo
    // reconcile that follows.
    let mut lost_clusters = 0u64;
    let mut free_clusters = 0u64;
    let mut bad_clusters  = 0u64;
    for cluster in 2u32..(fat.cluster_count() as u32 + 2) {
        let v = match fat.entry(cluster) { Some(v) => v, None => break };
        if fat::FatTable::is_free(v) {
            free_clusters += 1;
        } else if fat::FatTable::is_bad(v) {
            bad_clusters += 1;
        } else if !walk.reachable.contains(&cluster) {
            lost_clusters += 1;
        }
    }
    if lost_clusters > 0 {
        report.push(Finding {
            severity: Severity::Error,
            kind: "lost_clusters",
            detail: format!(
                "{} cluster(s) allocated in FAT but unreachable from the root",
                lost_clusters,
            ),
        });
    }

    // FSInfo reconcile: FAT32 caches free-cluster count and a
    // next-free hint in a dedicated sector. When the cached count
    // doesn't match our computed count it's usually harmless drift
    // (the kernel updates lazily), but gross mismatches point at
    // corruption.
    if let Err(e) = fs_info::verify(dev, &bs, free_clusters, &mut report) {
        report.push(Finding {
            severity: Severity::Warn,
            kind: "fs_info_verify_error",
            detail: format!("FSInfo verify: {}", e),
        });
    }

    let _ = bad_clusters; // reported indirectly via findings above
    Ok(report)
}

/// Write-allowed variant. Runs [`check_ro`] to produce findings,
/// then if any of the repairable conditions (FAT mirror mismatch,
/// lost clusters) are present, replays the directory walk to get a
/// reachability set and invokes [`repair::repair`] to fix them.
///
/// # Errors
///
/// I/O errors only; filesystem inconsistencies show up as findings.
pub fn check_and_repair<D: BlockDev>(dev: &mut D) -> Result<Report, Box<dyn std::error::Error>> {
    let mut report = check_ro(dev)?;
    if matches!(report.max_severity(), Some(Severity::Fatal)) {
        report.push(Finding {
            severity: Severity::Warn,
            kind: "repair_aborted_fatal",
            detail: "skipping FAT repair after fatal read-only finding".into(),
        });
        return Ok(report);
    }

    // Re-parse the boot sector and FAT; the directory walk needs a
    // reachable-set, and we've already confirmed the fs is FAT32.
    let bs = match boot_sector::read(dev) {
        Ok(b) if b.is_valid_signature() => b,
        _ => return Ok(report),
    };
    if bs.fat_type() != boot_sector::FatType::Fat32 { return Ok(report); }

    let fat = match fat::load(dev, &bs, &mut report) {
        Ok(f) => f,
        Err(e) => {
            report.push(Finding {
                severity: Severity::Error,
                kind: "fat_load_error",
                detail: format!("FAT read: {}", e),
            });
            return Ok(report);
        }
    };
    let walk = match dir::walk(dev, &bs, &fat, &mut report) {
        Ok(w) => w,
        Err(e) => {
            report.push(Finding {
                severity: Severity::Error,
                kind: "dir_walk_error",
                detail: format!("directory walk: {}", e),
            });
            return Ok(report);
        }
    };

    match repair::repair(dev, &bs, &fat, &walk.reachable, &mut report) {
        Ok(_) => {}
        Err(e) => {
            report.push(Finding {
                severity: Severity::Error,
                kind: "fat_repair_error",
                detail: format!("FAT repair: {}", e),
            });
        }
    }

    Ok(report)
}
