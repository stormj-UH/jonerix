#!/bin/sh
# Run the upstream e2fsprogs and dosfstools test fixtures against the
# current `jfsck` binary, classify every result, and print a pass/fail
# matrix. This is the correctness baseline we iterate against as we
# implement phase 1/2/3 features.
#
# For each upstream test we capture three axes:
#   exit    — did our binary exit with the same code as upstream expects?
#   no_crash — did we exit cleanly (not a crash / panic)?
#   output  — did our stdout match upstream's expect.1 byte-for-byte?
#
# Only `no_crash` is meaningful at phase-1 scaffolding time; `exit`
# matching follows once the find → classify paths are implemented;
# full `output` parity is a phase-3 polish goal once every finding has
# the e2fsck-format message text.
#
# Usage:  tests/run-upstream.sh [--e2|--fat|--both] [--verbose]

set -u
cd "$(dirname "$0")/.."
JFSCK=${JFSCK:-$PWD/target/release/jfsck}
[ -x "$JFSCK" ] || { echo "build jfsck first: cargo build --release"; exit 2; }

MODE=${1:-"--both"}
VERBOSE=${VERBOSE:-0}
[ "${2:-}" = "--verbose" ] && VERBOSE=1

# Per-test outcome buckets.
pass_exit=0
fail_exit=0
crashed=0
skipped=0
total=0

run_e2fsprogs() {
    # Each upstream test lives in tests/upstream/e2fsprogs/tests/<name>/.
    # The image is image.gz (compressed) or image (plain). Expected
    # output (if present) is expect.1 / expect.1.gz — we only check
    # exit code at this stage.
    echo "=== e2fsprogs tests ==="
    for d in tests/upstream/e2fsprogs/tests/f_* \
             tests/upstream/e2fsprogs/tests/d_* \
             tests/upstream/e2fsprogs/tests/r_*; do
        [ -d "$d" ] || continue
        name=$(basename "$d")
        total=$((total + 1))

        # Locate the filesystem image the test operates on.
        img=""
        if [ -f "$d/image.gz" ]; then
            tmp=/tmp/jfsck-$$-$name.img
            gunzip -c "$d/image.gz" > "$tmp" 2>/dev/null || { skipped=$((skipped+1)); continue; }
            img="$tmp"
        elif [ -f "$d/image" ]; then
            img="$d/image"
        else
            skipped=$((skipped + 1))
            continue
        fi

        # Upstream uses `-yf`; we force-check and pass -n (read-only) so
        # no fixture modifications leak into the working tree. We only
        # care whether our binary exits at all.
        out=$("$JFSCK" -t ext4 -n "$img" 2>&1)
        rc=$?
        [ "$img" = "/tmp/jfsck-$$-$name.img" ] && rm -f "$img"

        # Exit 139 / 134 / etc on macOS = SIGSEGV / SIGABRT = crash.
        if [ "$rc" -ge 128 ]; then
            crashed=$((crashed + 1))
            [ "$VERBOSE" = 1 ] && echo "CRASH  $name (rc=$rc)"
            continue
        fi

        # Most upstream tests expect 0 or 1 (either clean or fixed-some).
        # Since we're read-only we'll never return 1; we report 0, 4, or
        # 8. For baseline purposes we call a run "OK" if we produced a
        # useful exit code (0/4) rather than 8 (operational error).
        if [ "$rc" = 0 ] || [ "$rc" = 4 ]; then
            pass_exit=$((pass_exit + 1))
            [ "$VERBOSE" = 1 ] && echo "OK     $name (rc=$rc)"
        else
            fail_exit=$((fail_exit + 1))
            [ "$VERBOSE" = 1 ] && echo "FAIL   $name (rc=$rc)"
        fi
    done
}

run_dosfstools() {
    echo "=== dosfstools tests ==="
    # Their `.fsck` files are xxd-format hex dumps; convert to an image
    # with `xxd -r`, run jfsck on it. No need for their shell wrapper.
    if ! command -v xxd >/dev/null; then
        echo "xxd not available; skipping"
        return
    fi
    for f in tests/upstream/dosfstools/tests/check-*.fsck; do
        [ -f "$f" ] || continue
        name=$(basename "$f" .fsck)
        total=$((total + 1))

        tmp=/tmp/jfsck-$$-$name.img
        xxd -r "$f" "$tmp" 2>/dev/null || { skipped=$((skipped+1)); continue; }

        out=$("$JFSCK" -t vfat -n "$tmp" 2>&1)
        rc=$?
        rm -f "$tmp"

        if [ "$rc" -ge 128 ]; then
            crashed=$((crashed + 1))
            [ "$VERBOSE" = 1 ] && echo "CRASH  $name (rc=$rc)"
        elif [ "$rc" = 0 ] || [ "$rc" = 4 ]; then
            pass_exit=$((pass_exit + 1))
            [ "$VERBOSE" = 1 ] && echo "OK     $name (rc=$rc)"
        else
            fail_exit=$((fail_exit + 1))
            [ "$VERBOSE" = 1 ] && echo "FAIL   $name (rc=$rc)"
        fi
    done
}

case "$MODE" in
    --e2)   run_e2fsprogs ;;
    --fat)  run_dosfstools ;;
    --both) run_e2fsprogs; run_dosfstools ;;
    *) echo "usage: $0 [--e2|--fat|--both] [--verbose]"; exit 2 ;;
esac

echo
echo "=== summary ==="
echo "  total   : $total"
echo "  OK      : $pass_exit  (exited 0 or 4, no crash)"
echo "  FAIL    : $fail_exit  (exited 8 or misc non-OK)"
echo "  CRASH   : $crashed"
echo "  SKIPPED : $skipped  (missing fixture/xxd)"
if [ "$total" -gt 0 ]; then
    pct=$((pass_exit * 100 / total))
    echo "  OK rate : ${pct}%"
fi
