# jfsck

A BSD-2-Clause filesystem checker for the two filesystems a Raspberry
Pi actually uses: **ext4** on the root partition and **FAT32** on
`/boot`. Clean-room reimplementation in Rust, derived solely from
[Ghidra](https://ghidra-sre.org/) binary analysis of upstream
`e2fsck` and `fsck.fat`.

## Why this exists

- `e2fsck` (e2fsprogs) is GPL-2-only.
- `fsck.fat` (dosfstools) is GPL-3.
- [jonerix](https://github.com/stormj-UH/jonerix) ships only
  permissive-licensed runtime components, so the standard fsck tools
  can't be packaged.

`jfsck` fills that gap with exactly enough scope to keep a Pi boot-
and-root safe from power-loss corruption.

## Scope

Read [`docs/DESIGN.md`](docs/DESIGN.md) for the full story. Quick
version: ext4 + FAT32 on single-device volumes. No f2fs, no btrfs, no
network filesystems, no RAID, no LVM.

## Status

Pre-alpha. See the phase table in `docs/DESIGN.md`.

- Phase 1 (read-only validation): in progress
- Phase 2 (ext4 fixups): not started
- Phase 3 (FAT32 fixups): not started

## Building

```sh
cargo build --release
./target/release/jfsck -V
```

Binary is invoked either as `jfsck -t ext4 /dev/sda2` or via symlink
as `fsck.ext4 /dev/sda2` — same calling convention as
[util-linux](https://github.com/util-linux/util-linux) `fsck` expects.

## License

BSD-2-Clause. See [`LICENSE`](LICENSE).
