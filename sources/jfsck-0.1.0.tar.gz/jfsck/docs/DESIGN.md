# jfsck — clean-room filesystem checker for Raspberry Pi

## Scope

A Pi boots from an SD card with exactly two partitions in the typical
Raspberry Pi OS / jonerix layout:

1. **FAT32** — `/boot` or `/boot/firmware`. Holds `bootcode.bin`, the
   `start*.elf` GPU blobs, kernel images, `config.txt`, `cmdline.txt`,
   and device-tree blobs.
2. **ext4** — the root filesystem. Holds everything else.

`jfsck` targets exactly this surface — nothing more, nothing less.
f2fs, btrfs, xfs, and zfs are out of scope; if someone mounts one of
those on a Pi they already know enough to bring their own fsck.

## Non-goals

- Network filesystems (NFS, CIFS, 9P) — they don't use fsck.
- Encrypted volumes — LUKS owns integrity, not us; any ext4 beneath
  a decrypted LUKS device is in scope but LUKS metadata isn't.
- Multi-device filesystems (RAID, LVM). Pi SD cards are single-device.
- Resize / grow / shrink operations. Separate tool.

## Architecture

```
jfsck                          <- top-level dispatcher (like util-linux fsck)
 ├─ jfsck-ext                  <- backend: ext2/3/4 (clean-room reimpl of e2fsck)
 └─ jfsck-fat                  <- backend: FAT12/16/32 (clean-room reimpl of fsck.fat)
```

The dispatcher reads `/etc/fstab` (or takes `-t` / an explicit device)
and invokes the right backend. Backends share a block-device I/O
layer (`src/io.rs`) and a common report type.

## Sources

Clean-room reimplementation derived solely from Ghidra decompilation of:

- `e2fsck` (e2fsprogs 1.47.1, Alpine x86_64) — stripped ELF, 291KB
- `fsck.fat` (dosfstools 4.2, Alpine x86_64) — stripped ELF, 72KB
- `libext2fs.so.2` (e2fsprogs-libs 1.47.1) — on-disk format routines
- `libcom_err.so.2` — error string tables
- `libe2p.so.2` — ext2 feature flag strings

**No upstream source code is read at any point.** On-disk format
constants come from the public Linux UAPI (`<linux/ext2_fs.h>`,
`<linux/msdos_fs.h>`), which is kernel-tree interface, not a library.

## Phases

### Phase 1 — read-only validation

Enough to diagnose and report without fixing. Targets:

- ext4 superblock and group descriptor consistency
- ext4 inode table / bitmap consistency (block + inode bitmaps)
- ext4 directory hash trees (htree) structural walk
- ext4 extent tree structural walk (depth, bounds)
- FAT32 boot sector + FSInfo consistency
- FAT32 FAT table cross-verification (FAT1 vs FAT2)
- FAT32 directory entry chain walk
- FAT32 lost cluster detection

Exit codes: 0 clean, 4 uncorrected errors, 8 operational error (same
as e2fsck / fsck.fat).

### Phase 2 — ext4 fixups

- Journal replay (the dominant real-world case on a power-cut Pi)
- Orphan inode cleanup (ext4's delete list)
- Block / inode bitmap reconcile (recompute from table walk)
- Directory entry rec_len repair
- Superblock backup promotion when primary is corrupt
- Timestamp sanity (epoch-zero / future-dated)

### Phase 3 — FAT32 fixups

- Bad cluster marker reconcile
- Free cluster count repair in FSInfo
- Lost cluster → FILE0000.REC reclamation
- Directory entry cross-link resolution
- Short-name vs LFN consistency

### Deferred

- ext4 quota feature (rare on Pi)
- ext4 casefold / encrypt (rare on Pi)
- ext4 metadata_csum_seed validation (rare on Pi)
- FAT12/16 (legacy, Pi doesn't use)
- `fsck.ext2` / `fsck.ext3` as independent backends — ext4 code path
  handles all three since on-disk format is layered.

## License

BSD-2-Clause. No GPL input, no LGPL input.

## Repo layout (planned)

```
jfsck/
├── Cargo.toml                 # workspace
├── LICENSE                    # BSD-2-Clause
├── README.md
├── crates/
│   ├── jfsck/                 # top-level dispatcher binary
│   ├── jfsck-ext/             # ext2/3/4 backend
│   ├── jfsck-fat/             # FAT12/16/32 backend
│   └── jfsck-io/              # shared block-device I/O, buffer cache
├── docs/
│   ├── DESIGN.md              # this file
│   ├── ext4-notes.md          # ghidra observations
│   └── fat-notes.md
└── tests/
    ├── images/                # prepopulated fixture filesystems
    └── integration/           # end-to-end tests
```
