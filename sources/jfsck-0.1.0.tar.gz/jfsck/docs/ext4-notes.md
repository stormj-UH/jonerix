# ext4 — Ghidra observations

Derived from headless decompilation of `e2fsck` (e2fsprogs 1.47.1,
Alpine x86_64) at `/tmp/fsck-analysis/decompiled_e2fsck.bin.txt`. These
notes are architecture observations — public-facing algorithm shape
reconstructed from the binary — not verbatim code.

## Pass structure

Symbol addresses from `decompiled_e2fsck.bin.symbols.txt`:

| Entry point | Role |
|---|---|
| `e2fsck_pass1`  | Iterate every inode; build block + inode bitmaps; check per-inode structure (mode, size, links, timestamps). |
| `e2fsck_pass1e` | ext4-specific extent tree structural walk, called from pass1 when `INCOMPAT_EXTENTS` is set. |
| `e2fsck_pass1_dupblocks` | Duplicate-block resolution: inodes claiming the same block get their data duplicated or one copy marked bad. |
| `e2fsck_pass2`  | Walk directory blocks; validate entry records, filetype, name length, `rec_len`. |
| `e2fsck_pass3`  | Connectivity check: every non-orphan directory must reach `/` without a cycle. |
| `e2fsck_pass4`  | Reference count (`i_links_count`) vs actual directory links. |
| `e2fsck_pass5`  | Verify block + inode bitmaps against the tables built in pass1. |

jfsck will mirror this structure in `crates/jfsck-ext/src/pass/`:
`pass1.rs`, `pass2.rs`, etc. This is the *algorithm shape* that fell
out of the pragmatic design of ext4; every conforming checker (real
e2fsck, BSD `fsck_ext2fs`, Windows third-party tools) converges on
roughly the same five stages.

## Observations from decompiled helpers

- `ext2fs_check_directory` at `0x148620` gates every caller that walks
  a directory; returns `EISDIR`-family errors for malformed entries.
- `pass1_check_device_inode` / `pass1_check_symlink` are per-inode
  format-specific helpers, consistent with "one inode dispatcher per
  file type" (regular / dir / symlink / dev / socket / fifo).

## Features actually exercised on a Pi

`tune2fs -l` on a freshly-flashed Pi OS rootfs (aarch64, 2024-11 image)
reports:

```
Filesystem features:
  has_journal ext_attr resize_inode dir_index filetype
  needs_recovery extent 64bit flex_bg sparse_super large_file
  huge_file uninit_bg dir_nlink extra_isize metadata_csum
```

Decomposed:

- `has_journal` + `needs_recovery` — journal replay on uncleaned mount.
  This is the dominant real-world case on a power-cut Pi. **phase 2.**
- `ext_attr` — xattrs; used by systemd (security.capability, etc.).
  Structural walk only — we don't validate xattr semantics.
- `dir_index` — htree directory hash tree; requires hash verification
  during pass 2.
- `filetype` — directory entries carry a file-type byte. Simplifies
  pass 2.
- `extent` + `64bit` — ext4's 48-bit addressing and extent trees.
  **pass1e** handles the extent tree structural check.
- `flex_bg` — flex block groups; changes how the group descriptor
  table is laid out but not per-group math.
- `sparse_super` — superblock backups at groups 0, 1, 3^n, 5^n, 7^n
  instead of every group. Affects backup superblock recovery in
  phase 2.
- `large_file` + `huge_file` — 2 GiB and 16 TiB thresholds.
- `uninit_bg` — uninitialised block groups; their bitmaps don't
  exist until first write. Group descriptors carry
  `EXT4_BG_INODE_UNINIT` / `EXT4_BG_BLOCK_UNINIT` flags.
- `dir_nlink` — unlimited directory subdirectory count (reused
  `i_links_count` as an "unknown" marker at 1).
- `extra_isize` — 256-byte inodes with extended timestamp nanoseconds.
- `metadata_csum` — CRC32C over every metadata block. Mandatory to
  validate in phase 1 since mismatches indicate corruption.

Out of scope (not observed on standard Pi OS):

- `quota`, `project`, `encrypt`, `casefold`, `verity`, `orphan_file`.

## Group descriptor sizing

`s_desc_size` in the superblock is 32 bytes for legacy ext2/3 and
64 bytes once `INCOMPAT_64BIT` is set. Group descriptors live in
contiguous blocks starting at `first_data_block + 1`. When
`flex_bg` is on, the bitmaps and inode tables of up to
`2^s_log_groups_per_flex` groups are packed into one meta-group,
but each descriptor entry is still 64 bytes and read in order.

## Endianness

All on-disk ext4 fields are stored little-endian regardless of
host architecture. jfsck parses with explicit `u32::from_le_bytes`
so aarch64 Pi and x86_64 test host behave identically.
