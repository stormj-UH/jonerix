# FAT32 — Ghidra observations

Derived from headless decompilation of `fsck.fat` (dosfstools 4.2,
Alpine x86_64) at `/tmp/fsck-analysis/decompiled_fsck.fat.bin.txt`.

The binary is stripped so function names are `FUN_xxx`; structure
comes from call graph, data access patterns, and constants. Public
structure (boot sector layout, FAT math, cluster chains) comes from
Microsoft's FAT32 specification and `<linux/msdos_fs.h>` — those
aren't copyrighted interfaces.

## Checker stages observed

`fsck.fat` has a flatter architecture than `e2fsck`; the whole flow
is a single pass with helper sweeps:

1. **Read boot sector**, validate BPB fields, detect FAT type from
   cluster count.
2. **Read FATs**, cross-compare FAT1 and FAT2 when two copies exist.
3. **Walk the root directory**, recursively, following cluster
   chains from each dir entry.
4. **Detect lost clusters** by diffing "clusters on a chain" vs
   "clusters marked non-free in FAT". Lost clusters are collected into
   auto-named `FILE0000.REC`, `FILE0001.REC`, ... files in the root.
5. **FSInfo reconcile**: update the `free_cluster_count` and
   `next_free_cluster` hints at their sector offset (typically 1).

## Constants observed in decompilation

- 0xAA55 — boot sector signature at offset 510.
- 0x41615252 / 0x61417272 / 0xAA550000 — three FSInfo signatures.
- 0x0FFFFFF8 — end-of-chain marker (FAT32 data is in the low 28 bits).
- 0x0FFFFFF7 — bad cluster marker.
- Name-mangling for LFN: 13 UTF-16 code units per sub-entry across
  four "slot" entries of 32 bytes, with the 0x0F attribute byte.

## Features not in jfsck scope

- **dosfstools' "undelete"** mode. This looks at dir entries marked
  with 0xE5 and reconstructs short filenames. Out of scope — jfsck
  is a repair tool, not a forensic one.
- **Alien-file marker checks** (Atari, OS/2 long-name formats). Only
  Windows-compat LFN matters for a Pi boot partition.
- **Volume label cross-check**: dosfstools verifies the volume label
  in the boot sector matches the volume label entry in the root
  directory. Nice to have; deferred.

## What jfsck-fat phase 1 checks

Only the cheap, high-value structural checks:

1. Boot sector signature.
2. BPB numeric sanity (`bytes_per_sector` power-of-two 512..=4096,
   `sectors_per_cluster` power-of-two 1..=128, `cluster_size <= 32
   KiB`, non-zero `reserved_sectors`, `num_fats` in {1, 2}).
3. FAT32 invariants when cluster_count >= 65525: `root_entries == 0`,
   `fat_size_16 == 0`, `fat_size_32 > 0`, `root_cluster >= 2`.
4. FAT table bounds: `first_data_sector + cluster_count * sectors_per_cluster
   <= total_sectors`.

Phase 3 adds the FAT traversal, lost-cluster detection, and FSInfo
reconcile.
