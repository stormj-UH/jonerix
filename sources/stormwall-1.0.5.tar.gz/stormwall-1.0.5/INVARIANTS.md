# stormwall — Module Invariants

Security audit deliverable. Each section documents what must hold at all times
for the code to be correct and safe. Violations are bugs.

---

## netlink.rs

### Data invariants

- **`NlSocket.fd`** is a valid, open file descriptor from the time
  `NlSocket::open_protocol` returns until `Drop::drop` fires. No other code
  path closes it. The fd is `SOCK_CLOEXEC` so it is not inherited by child
  processes.

- **`NlSocket.portid`** holds the kernel-assigned nl_pid obtained via
  `getsockname` immediately after `bind`. It is 0 only if `getsockname`
  failed (treated as a non-fatal degeneracy; no message routing depends on the
  local portid).

- **`MsgBuilder.buf`** is always internally consistent: every complete message
  it contains has its `nlmsg_len` field correctly set before a new message
  begins. The invariant is maintained by the `begin_msg` / `end_msg` pair:
  `begin_msg` writes a zero-length placeholder and records the offset; `end_msg`
  patches the real length as `(current_len - pos) as u32`.

- **`MsgBuilder.seq`** is monotonically increasing within a builder instance.
  It starts at 1 and increments once per `write_nlmsghdr` call. It is never
  reset.

- **NLA length field is a `u16`**. `put_str`, `put_bytes`, `end_nested`, and
  `put_nested_raw` all call `.try_into().expect("netlink attribute exceeds 64KB")`
  on the computed length. Any attribute whose payload exceeds 65531 bytes
  (65535 − 4-byte header) causes a panic rather than silent truncation or
  wrap-around. This is the correct behaviour: the kernel would reject such an
  attribute regardless.

### Safety invariants

All `unsafe` blocks in this file call `libc` functions; none perform raw
pointer arithmetic or create references from raw pointers.

- **`socket(2)`** — valid AF_NETLINK/SOCK_RAW constants; return value checked
  before use.
- **`setsockopt(2)`** — pointer is to a stack-local `c_int`; size matches
  `mem::size_of::<c_int>()`; fd is validated before the call.
- **`sockaddr_nl` zero-init** — the struct has no invalid bit patterns; `mem::zeroed()`
  is well-defined. The family field is set before `bind`.
- **`bind(2)` / `getsockname(2)`** — pointer is to a fully-initialised
  `sockaddr_nl`; size parameter matches `mem::size_of::<sockaddr_nl>()`.
- **`send(2)`** — `buf.as_ptr()` is derived from a live, valid `Vec<u8>`
  allocation; `buf.len()` is the correct length; the pointer is not retained
  after return.
- **`recv(2)`** — `buf.as_mut_ptr()` is a writable slice of exactly `buf.len()`
  bytes; the fd is open and bound.
- **`close(2)` in Drop** — fd is open and has not been closed by any other path;
  `Drop` is called exactly once per `NlSocket`.
- **`if_indextoname(3)` in output.rs** — the buffer is `[0u8; IF_NAMESIZE]`
  which is the exact size the function requires; `idx != 0` is guaranteed by
  the early-return guard before the unsafe block.
- **`isatty(3)` in main.rs** — called with fd 0 (stdin), which is always a
  valid non-negative integer; the function only returns 0 or 1 and has no
  preconditions beyond a non-negative argument.

### Protocol invariants

- **Batch envelope**: every outgoing send must begin with `NFNL_MSG_BATCH_BEGIN`
  (type 0x10, res_id = NFNL_SUBSYS_NFTABLES) and end with `NFNL_MSG_BATCH_END`
  (type 0x11). Individual nf_tables messages between them use type
  `(NFNL_SUBSYS_NFTABLES << 8) | NFT_MSG_*`. Sending a raw `NFT_MSG_*` outside
  a batch results in ENOTSUP from the kernel.

- **nfgenmsg header**: every nftables message starts with a 4-byte nfgenmsg
  immediately following the 16-byte nlmsghdr. Layout: `[family:u8, version=0:u8,
  res_id=0:u16 BE]`. Batch begin/end use `[AF_UNSPEC=0, 0, NFNL_SUBSYS_NFTABLES
  BE]` in the res_id slot.

- **TLV alignment**: every attribute is 4-byte aligned. `pad4()` appends zero
  bytes after variable-length payloads (strings, byte arrays). Fixed-width
  attributes (u8, u16, u32, u64) compute their padding within their respective
  `put_*` helpers. `put_nested_raw` requires callers to pre-align the body.

- **`NLA_F_NESTED` flag** (bit 15): set on all nested attribute headers via
  `NLA_F_NESTED | attr_type`. The kernel enforces this on attributes it knows
  to be nested; missing it causes EINVAL.

- **`NFTA_LOOKUP_SET_ID` vs `NFTA_LOOKUP_FLAGS`**: IDs are 4 and 5 respectively
  per kernel 6.1 UAPI. Swapping them silently breaks negated set matches
  (`!= @set`). The constants are locked to the UAPI ordering with an explicit
  comment documenting the historical mixup.

- **Register selection**: `reg_for_width(w)` returns `NFT_REG32_00` for `w <= 4`
  and `NFT_REG_1` for `w > 4`. Using `NFT_REG32_00` for a 16-byte value causes
  the kernel to return EOVERFLOW.

- **`parse_attrs` borrow contract**: the returned `Vec<(u16, &[u8])>` borrows
  from the `data` slice passed in; its lifetime is tied to that slice. Callers
  must not let the parsed attributes outlive `data`. The NLA_F_NESTED and
  NLA_F_NET_BYTEORDER flag bits (top 2 bits of nla_type) are masked off before
  storage (`& 0x3FFF`). Malformed records (nla_len < 4 or extending past the
  buffer) stop the parser silently; no panic, no partial record.

- **`NFTA_QUOTA_CONSUMED`** is attribute ID 4, not 3. Slot 3 is a reserved PAD
  field in the kernel UAPI. Sending CONSUMED to slot 3 causes the kernel to
  silently discard it.

### Error handling contract

- `NlSocket::open` / `open_protocol` returns `Err(io::Error)` on any syscall
  failure. The fd is closed before returning on `bind` failure. Callers may
  treat a successful return as a guarantee of a bound, usable socket.
- `NlSocket::send` / `recv` return `Err` on negative return from the syscall.
  When `STORMWALL_NLDUMP` is set, `send` always returns `Ok(buf.len())` without
  touching the socket.
- `MsgBuilder` methods are infallible except where a length exceeds u16 range,
  in which case they panic. This is by design: overflow indicates a programmer
  error (constructing a single attribute larger than 64 KB), not a runtime
  condition.
- Attribute accessor helpers (`attr_str`, `attr_u32_be`, etc.) return a default
  value (empty string, 0) when the slice is too short. Callers must not treat
  these defaults as meaningful data without checking the attribute was actually
  present.

---

## ops.rs

### Data invariants

- **`NftCtx.batch`** is `Some(MsgBuilder)` between the first mutation command
  of a transaction and the send, and `None` otherwise. `begin_msg` / `end_msg`
  calls within a command encoder always reference the same `MsgBuilder` that
  was opened by the enclosing batch-begin.

- **`pending_sets`** keys are `(family: u8, table: String, set: String)` tuples.
  An entry exists if and only if a `NFT_MSG_NEWSET` for that set has been
  buffered in `batch` but not yet sent. The stored `SetInfo` reflects the
  declared key/data widths and types exactly as they will appear in the kernel
  after commit.

- **`pending_elem_keys`** maps the same key type to a set of already-buffered
  element keys (raw bytes). Its purpose is duplicate suppression for
  object-reference maps: the kernel increments a named object's refcount once
  per `NEWSETELEM`, so emitting the same key twice in one batch would leave
  the object un-deletable. The dedup applies only within a single batch; it
  is cleared between transactions.

- **`verdicts.len() == elements.len()` in `AnonSetPlan`**: enforced by a
  `debug_assert_eq!` in `emit_anon_sets`. For plain (non-vmap) anon sets,
  `verdicts` is always empty; for anon vmaps it has exactly one entry per
  element. This invariant lets the encoder use `plan.verdicts.get(i)` without
  bounds-check fallibility.

- **`anon_set_counter`** is monotonically non-decreasing within a process
  lifetime. It is never reset, so parallel anon sets inside one batch always
  get distinct `__setN` / `__mapN` names. The counter starts at 0 (no set
  allocated) and the first allocated name is `__set0` (counter bumped to 1,
  name is `counter - 1`).

- **`rule_id_counter`** is similarly monotonic. It starts at 0; the first rule
  emitted into a batch gets id 1. A value of 0 means "no id assigned".

- **`pending_rules`** maps `(family, table, chain)` to an ordered list of
  `NFTA_RULE_ID` values for rules buffered in the current batch. The order
  matches insertion order, which is the rule order within the chain. A
  subsequent `add rule ... index N` resolves N to `list[N]` and encodes it as
  `NFTA_RULE_POSITION_ID`.

### Safety invariants

`ops.rs` contains no `unsafe` code. All netlink encoding is delegated to
`MsgBuilder` methods.

### Protocol invariants

- **Anonymous set ordering**: for each rule containing anon sets, the
  `NFT_MSG_NEWSET` + `NFT_MSG_NEWSETELEM` messages for every anon set must
  precede the `NFT_MSG_NEWRULE` referencing them within the same batch. The
  kernel resolves `NFTA_LOOKUP_SET_ID` to an in-batch NEWSET during commit;
  out-of-order delivery causes ENOENT.

- **Anon-set name collision avoidance**: before emitting anon sets for a
  `replace rule` command, `bump_anon_counter_past_existing` performs a
  `NFT_MSG_GETSET` dump and advances `anon_set_counter` past any `__setN` /
  `__mapN` that already exist in the target table. Failure to do this causes
  the kernel to reject the NEWSET with EOPNOTSUPP because flags on an existing
  anonymous set cannot be re-declared.

- **Concat key re-encoding**: `reencode_concat_key` left-justifies narrow values
  within their 4-byte slot. The parser always produces u32 big-endian for all
  numeric values; the kernel expects narrow types (e.g. `inet_service`, 2 bytes)
  to occupy the first `width` bytes of the slot. Omitting this re-encoding
  causes the kernel to match the wrong bytes.

- **Data value byte order**: `reencode_data_value` distinguishes network-byte-order
  types (ipv4_addr=7, ipv6_addr=8, ether_addr=9, inet_service=13 — keep BE,
  truncate) from host-byte-order types (integer, mark, queue, etc. — reinterpret
  the parser's BE bytes as a numeric value and re-emit in native endian). Mixing
  these up produces rules that match on no packets or the wrong packets.

- **NEWSETELEM split threshold**: when a single set's elements would push the
  `NFTA_SET_ELEM_LIST_ELEMENTS` nest past 60 000 bytes (comfortably below the
  u16 nla_len ceiling of 65535), `emit_anon_sets` closes the current
  NEWSETELEM message and opens a new one for the same set. Both messages belong
  to the same batch and are atomically committed together.

- **Table→chain→rule containment**: the `validate_check` function enforces that
  every Add/Create/Insert/Replace for a chain, rule, set, or map references a
  table that was previously declared in the same command sequence. Rules
  additionally must reference an existing chain. Jump/goto verdicts must target
  a declared chain.

### Error handling contract

- Public methods return `io::Result<()>` or `io::Result<T>`. A netlink error
  ACK from the kernel is surfaced as `io::Error::from_raw_os_error(errno)`.
- `add_elements` and `delete_elements` call `probe_set_info` (a GETSET query)
  to discover key/data widths before encoding. If the set was added in the same
  batch (`pending_sets` has it), the probe is skipped and the buffered
  `SetInfo` is used. If neither source has the set, re-encoding falls back to
  the raw bytes the parser produced.
- Deferred duplicate-element suppression (`pending_elem_keys`) is silent: the
  duplicate NEWSETELEM is dropped without an error or warning, since re-adding
  the same key to an object-reference map in one transaction is semantically
  idempotent.

---

## output.rs

### Data invariants

- **`NUMERIC_PRIO` / `NUMERIC_PROTO`** are `AtomicBool` statics written once at
  startup by `set_numeric_flags` and read thereafter. No locking is needed
  because the process is single-threaded during output; `Ordering::Relaxed` is
  correct.

- **`RuleCtx`** is created fresh (`RuleCtx::new()`) at the start of each rule's
  expression list and discarded after the last expression. State accumulated in
  one rule (pending field, bitwise mask, proto context, stashed immediates,
  fib result, concat chain) must never bleed into the next rule. `ctx.clear()`
  resets the transient per-expression fields; `pending_imm`, `pending_fib`, and
  `pending_concat` are reset only by the consumers that drain them.

- **`RuleCtx.pending_imm`** maps destination register number (`u32`) to raw
  bytes. An entry exists for as long as the `immediate` expression that loaded
  the register has not been consumed. The `dup`, `fwd`, `tproxy`, and NAT
  renderers consume it; any expression that does not consume it leaves it
  available for the next consumer in the same rule.

### Safety invariants

- **`if_indextoname`** (in output.rs): the buffer is declared as
  `[0u8; libc::IF_NAMESIZE]`; `IF_NAMESIZE` is the exact size the C function
  writes into. The early-return guard `if idx == 0 { return None; }` ensures
  the function is never called with the sentinel "no interface" index. The
  function does not retain the pointer. The result pointer is checked for null
  before dereferencing.

### Protocol invariants

- All functions in this module are pure in the sense that they produce output
  on stdout and return no data that affects subsequent netlink messages. They
  read kernel-returned attribute lists but do not write to the socket or modify
  `NftCtx` state.

- **Userdata TLV format** (rule / chain comments): parsed as a type-length-value
  stream where each record is `[type:u8, len:u8, data:len bytes]`. Type 0 is
  a NUL-terminated comment string. The parser stops at the first type-0 record
  and discards any further entries. It bounds-checks `i + ln <= ud.len()` before
  slicing to prevent out-of-bounds reads on malformed kernel data.

- **`format_ipv6`** requires `v.len() >= 16`; returns `"::"` otherwise.
  Callers always pass 16-byte slices from kernel attribute payloads, but the
  guard makes the short-slice case safe rather than panicking.

- **Interval set rendering**: elements are sorted by `(value, end_flag DESC)`
  so that the end sentinel for range `[A, B)` immediately precedes the start
  of `[B, ...]`. The end sentinel byte value is decremented by 1
  (big-endian borrow) to recover the inclusive end before display.

### Error handling contract

- All `print_*` / `format_*` functions are infallible. They return `()` or
  `String` and do not propagate errors. If kernel data is malformed (short
  slices, invalid UTF-8, unknown type codes), the functions emit a best-effort
  placeholder (`"?"`, `"unknown"`, `"::"`) rather than panicking.
- `if_indextoname` returns `None` for index 0 or when the interface no longer
  exists; callers render the raw index as a fallback.

---

## parser.rs

### Data invariants

- **`Parser.pos`** is a non-decreasing index into `Parser.tokens`. It advances
  via `advance()` and is never decremented. `peek()` and `peek_offset(n)` are
  pure reads that return `""` when `pos` (or `pos + n`) is out of range.
  `at_end()` is `pos >= tokens.len()`. There is no seek-backward capability;
  `inject()` inserts a token at `pos` to synthesise forward lookahead.

- **`Parser.host_order_value`** and **`Parser.icmpv6_context`** are caller-set
  flags that bracket a single `parse_cmp_and_value` call. Callers are
  responsible for clearing them after the call. They are always `false` between
  top-level commands.

- **`Parser.deferred_errors`** accumulates validation errors found during
  expression parsing (which cannot return `Result`). It is checked and drained
  after each complete command. A non-empty list causes `parse()` to return the
  first error.

- **`Parser.pending_commands`** and **`Parser.pending_anon_chains`** are
  auxiliary queues drained by the outer `parse()` loop after each command:
  `pending_anon_chains` before the parent rule, `pending_commands` after it.
  At the end of a successful parse both are empty.

- **`anon_chain_counter`** is monotonically increasing within a parser session.
  Names are `__chain0`, `__chain1`, etc. A freshly constructed `Parser` starts
  at 0.

- **Tokenizer brace invariant**: `tokenize` tracks `brace_depth` and returns an
  error if it is positive at end-of-input. This prevents the parser from
  silently ignoring unclosed `{` blocks.

### Safety invariants

`parser.rs` contains no `unsafe` code. The one `unsafe` call is
`if_nametoindex` in the `dup`/`fwd` token handlers:

- **`if_nametoindex`**: `CString::new(name)` returns `None` (and the function
  returns `None`) if `name` contains an interior NUL. The CString is kept
  alive for the duration of the call. Return value 0 is mapped to `None`.

### Protocol invariants

- **`proto_num` match unreachable guard**: the arm
  `_ => unreachable!("proto_name guard mismatch")` at line 1530 is reached only
  if the outer `if tok == "tcp" || tok == "udp" || tok == "icmp" || tok == "icmpv6"`
  guard is true and the inner `match` fails to cover one of those four strings.
  Because the four arms of the inner match cover exactly those four strings, the
  `unreachable!` can never fire at runtime. It is a correctness assertion, not
  dead code: if a future edit adds a protocol to the outer guard without updating
  the inner match, the panic will surface immediately.

- **Colon disambiguation**: a `:` is absorbed into a word token only when the
  word so far contains a prior colon or a hex letter and consists exclusively of
  hex digits, colons, and dots (IPv6 address). Otherwise `:` is emitted as a
  separate token (map key separator). Pure-decimal words are never treated as
  IPv6 starts, so `10080:drop` tokenises as `["10080", ":", "drop"]`.

- **Dash disambiguation**: a `-` is a range separator (emitted as a standalone
  `-` token) when the current word is an IPv4-like (digits + dots) or IPv6-like
  (contains `:`) string and the next character starts an address. Otherwise it
  is absorbed into the word as a name separator (e.g. `foo-bar`).

- **Integer encoding**: by default `parse_value` encodes numeric literals as
  4-byte big-endian (network byte order). When `host_order_value` is set,
  values are encoded in native byte order. This distinction is critical for
  `meta mark` comparisons, which the kernel stores in host order.

### Error handling contract

- `parse(input)` returns `Result<Vec<Command>, String>`. The error string is
  human-readable and intended for direct display.
- Deferred errors (from expression sub-parsers) are flushed after each command;
  the first error terminates the parse.
- Unknown tokens in most positions cause the parser to skip or produce a
  best-effort partial command rather than hard-failing. This matches upstream
  nft's behaviour on forward-compatibility grounds, but it means callers should
  not assume a successful parse implies complete semantic correctness.

---

## pf_parser.rs

### Data invariants

- **Three output streams**: `headers` (table + chain declarations), `skip_rules`
  (set-skip `accept` rules), and `body_rules` (antispoof, pass, block, match).
  The final output order is `headers → overload_decls → meter_decls →
  skip_rules → body_rules`. This ordering ensures: sets exist before rules that
  reference them; skip rules fire before body rules in the `in` chain.

- **`ParseState.overload_seen` / `meter_seen`**: deduplication maps. An entry
  is inserted the first time a given overload table or meter set name is
  encountered; subsequent references skip the `add set` declaration. The
  corresponding `overload_decls` / `meter_decls` vecs hold exactly one entry
  per unique name.

- **`ParseState.queue_next_minor`** starts at `0x10`. The minor number 0 is
  reserved (qdisc handle `1:0`); starting at 16 leaves room without colliding.
  Each call to `queue_priority` for a new name increments it by 1.

- **Base chain emission**: the three lazy booleans `needs_in_chain`,
  `needs_scrub_chain`, `needs_out_chain` ensure each base chain is emitted at
  most once, as the first entries in `headers`. A pf file that contains no
  `pass`/`block` rules produces no `in` chain declaration.

- **Anchor chain ordering**: inline anchor bodies emit a regular chain command
  into `headers` before any rules for that anchor go into `body_rules`. The
  jump rule from the parent `in` chain is appended to `body_rules` after the
  anchor's rules, preserving last-match-wins pf semantics.

### Safety invariants

`pf_parser.rs` contains no `unsafe` code.

### Protocol invariants

- **PF → nftables family**: all synthesised commands use `NFPROTO_IPV4` (family
  2). The table is always named `"pf"`. This is a simplification of OpenBSD pf,
  which is protocol-agnostic; the current implementation only handles IPv4.

- **`build_filter_rule` error path**: the function returns `Result<Vec<Command>, String>`.
  Every early return on parse error propagates the error string up through
  `parse_pass_block` and ultimately out of `parse_file_inner`. No partial
  command is inserted into any output stream on error.

- **Overload-table ordering invariant**: `overload_decls` are spliced before
  `meter_decls`, which in turn precede `skip_rules` and `body_rules`. This
  matches the frozen strace reference output from upstream nft: overload sets
  (typed `ipv4_addr`, timeout-flagged) are declared before dynamic meter sets.

- **Rate-limit meter set name**: always `"rate_limit"` (matching the frozen
  strace corpus). If two `max-src-conn-rate` clauses appear in a pf file, they
  share the single `rate_limit` set. A caller that needs distinct meters per
  clause must use explicit named sets.

- **`limit_unit_seconds`**: maps pf time unit strings to seconds (1, 60, 3600,
  86400, 604800). Returns `Err(String)` for unrecognised units. The nftables
  wire value is `limit_rate / limit_unit` packets per second, stored as u64
  NBO in `NFTA_LIMIT_RATE` and `NFTA_LIMIT_UNIT`.

### Error handling contract

- `parse_file(input)` and `parse_file_full(input)` return `Result<_, String>`.
  Any unrecognised top-level pf keyword causes an immediate hard error of the
  form `"pf: unsupported top-level keyword \`<word>\`"`. This is intentional:
  silently ignoring an unknown directive could drop a security policy.
- Set and chain synthesis errors within `keep state (...)` clauses propagate as
  `String` errors through `parse_pass_block`.
- Successful return guarantees that all commands in the output vector are
  self-consistent: sets are declared before the rules that reference them, and
  base chains are declared before any rules are added to them.

---

## main.rs

### Data invariants

- **`Opts`** is constructed entirely from `env::args()` in `parse_opts` before
  any I/O occurs. It is immutable thereafter. No flag is toggled after the
  initial parse.

- **`--check` mode**: `validate_check` builds in-memory `tables` and `chains`
  `HashSet`s from the command sequence without sending any netlink messages.
  The sets are local to the function; no global state is modified.

- **`STORMWALL_TEST_MODE`**: read once at each call site via `test_mode()`.
  Affects only output strings (`--version`, JSON metainfo, prompt label).
  Does not affect netlink encoding, parsing, or any security-relevant path.

### Safety invariants

- **`isatty(3)` in interactive mode**: called with fd literal `0` (stdin). fd 0
  is always open in a normal process. The function has no preconditions beyond
  a non-negative integer argument and cannot corrupt memory. The result is used
  only to decide whether to print a prompt; it does not affect command parsing
  or execution.

### Protocol invariants

- **`-n` / `--numeric`** sets both `numeric_prio` and `numeric_proto`; `-nn`
  is accepted as a synonym. `-y` and `-p` set them independently. These flags
  are propagated to `NftCtx` fields and to `output::set_numeric_flags` before
  any command executes.

- **`STORMWALL_NLDUMP` environment variable**: when set, `NlSocket::send`
  appends a hex dump to the named file and returns early without sending to the
  kernel. This short-circuits the actual socket send for all messages, not just
  specific message types. Any test harness relying on this must not expect
  kernel-side effects.

- **`-c` / `--check` mode**: commands are parsed and `validate_check` is called,
  but `NftCtx` is not created and no netlink socket is opened. Errors from
  `validate_check` are reported to stderr with exit code 1; success exits 0.

### Error handling contract

- Parse errors from `parser::parse` or `pf_parser::parse_file` are printed to
  stderr as `"Error: <message>"` and the process exits with code 1.
- Netlink errors from `ops` methods are printed the same way.
- In interactive mode, errors are printed and the REPL continues; the session
  does not terminate on a single bad command.
- `--help` and `--version` exit with code 0 immediately after printing; no
  other processing occurs.
- Unrecognised flags stop argument parsing at the first unrecognised token;
  remaining tokens are collected into the `rest` vector and treated as inline
  nft commands. This matches upstream nft's `getopt`-style fallthrough.
