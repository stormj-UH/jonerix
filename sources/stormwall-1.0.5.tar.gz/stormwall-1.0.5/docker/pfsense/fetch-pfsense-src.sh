#!/bin/sh
# Fetch pfSense CE source files needed for the web UI.
# The PHP web files and include libraries are Apache 2.0 licensed.
#
# This script is run during Docker build or manually to populate
# /usr/local/www and /usr/local/etc/inc from upstream.
#
# Usage: ./fetch-pfsense-src.sh [target-dir]
#
# SPDX-License-Identifier: MIT

set -e

PFSENSE_REPO="https://github.com/pfsense/pfsense.git"
# Use the latest stable release branch (master has forward-references)
PFSENSE_BRANCH="RELENG_2_7_2"
TARGET="${1:-/usr/local}"

WORKDIR=$(mktemp -d)
trap 'rm -rf "$WORKDIR"' EXIT

printf 'Cloning pfSense CE (%s)...\n' "$PFSENSE_BRANCH"
git clone --depth 1 --branch "$PFSENSE_BRANCH" "$PFSENSE_REPO" "$WORKDIR/pfsense" 2>&1 || \
    git clone --depth 1 "$PFSENSE_REPO" "$WORKDIR/pfsense" 2>&1

# Create target directories
mkdir -p "$TARGET/www" "$TARGET/etc/inc" "$TARGET/sbin"

# Copy web UI files
printf 'Installing web UI to %s/www/\n' "$TARGET"

if [ -d "$WORKDIR/pfsense/src/usr/local/www" ]; then
    cp -a "$WORKDIR/pfsense/src/usr/local/www/." "$TARGET/www/"
fi

# Copy PHP include libraries
if [ -d "$WORKDIR/pfsense/src/etc/inc" ]; then
    cp -a "$WORKDIR/pfsense/src/etc/inc/." "$TARGET/etc/inc/"
fi

# Also grab files from /usr/local/etc/inc if present
if [ -d "$WORKDIR/pfsense/src/usr/local/etc/inc" ]; then
    cp -a "$WORKDIR/pfsense/src/usr/local/etc/inc/." "$TARGET/etc/inc/"
fi

# pfSense 2.7+ moved page-specific .inc files here (firewall_nat.inc,
# status_output.inc, diag_arp.inc, etc.)
if [ -d "$WORKDIR/pfsense/src/usr/local/pfSense/include/www" ]; then
    cp -a "$WORKDIR/pfsense/src/usr/local/pfSense/include/www/." "$TARGET/etc/inc/"
fi

# Copy pfSsh.php shell entry point
if [ -f "$WORKDIR/pfsense/src/usr/local/sbin/pfSsh.php" ]; then
    cp "$WORKDIR/pfsense/src/usr/local/sbin/pfSsh.php" "$TARGET/sbin/"
fi

printf 'pfSense CE web UI files installed.\n'
printf 'Files: %s\n' "$(find "$TARGET/www" -type f 2>/dev/null | wc -l)"
printf 'Includes: %s\n' "$(find "$TARGET/etc/inc" -type f 2>/dev/null | wc -l)"
