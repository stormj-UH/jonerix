<?php
/*
 * fix-php82-compat.php — patch pfSense PHP for PHP 8.2 + Linux compat.
 *
 * PHP 8.2 requires constant expressions in static variable initializers.
 * This script transforms:
 *   static $var = func_call();
 * into:
 *   static $var = null; if ($var === null) { $var = func_call(); }
 *
 * Also hooks mwexec() to rewrite FreeBSD paths to our shims.
 *
 * SPDX-License-Identifier: MIT
 */

$inc = '/usr/local/etc/inc';

// ── Explicit patches for known static initializers ──────────────

$static_patches = [
    ['gwlb.inc',
     'static $gateways = get_gateways(GW_CACHE_ALL);',
     'static $gateways = null; if ($gateways === null) { $gateways = get_gateways(GW_CACHE_ALL); }'],

    ['gwlb.inc',
     'static $gateways_status_cache = return_gateways_status(true);',
     'static $gateways_status_cache = null; if ($gateways_status_cache === null) { $gateways_status_cache = return_gateways_status(true); }'],

    ['filter.inc',
     'static $gateways = get_gateways();',
     'static $gateways = null; if ($gateways === null) { $gateways = get_gateways(); }'],

    ['filter.inc',
     'static $gateway_groups = config_get_path(\'gateways/gateway_group\', []);',
     'static $gateway_groups = null; if ($gateway_groups === null) { $gateway_groups = config_get_path(\'gateways/gateway_group\', []); }'],

    ['filter.inc',
     'static $order = array_flip(array_keys($this->order));',
     'static $order = null; if ($order === null) { $order = array_flip(array_keys($this->order)); }'],
];

$count = 0;
foreach ($static_patches as [$file, $search, $replace]) {
    $path = "$inc/$file";
    if (!file_exists($path)) {
        fprintf(STDERR, "  SKIP: $file not found\n");
        continue;
    }
    $content = file_get_contents($path);
    if (strpos($content, $search) === false) {
        fprintf(STDERR, "  SKIP: pattern not found in $file\n");
        continue;
    }
    $content = str_replace($search, $replace, $content);
    file_put_contents($path, $content);
    $count++;
    fprintf(STDERR, "  patched static-init in $file\n");
}

// ── filter.inc: closure in static initializer (multi-line) ──────
$path = "$inc/filter.inc";
if (file_exists($path)) {
    $content = file_get_contents($path);
    // static $trim_lines = function (...) { ... };
    // → static $trim_lines = null; if ($trim_lines === null) { $trim_lines = function (...) { ... }; }
    $content = preg_replace(
        '/static \$trim_lines = (function\s*\([^)]*\)\s*\{[^}]+\});/s',
        'static $trim_lines = null; if ($trim_lines === null) { $trim_lines = $1; }',
        $content,
        -1, $closure_count
    );
    if ($closure_count > 0) {
        file_put_contents($path, $content);
        $count += $closure_count;
        fprintf(STDERR, "  patched closure static-init in filter.inc\n");
    }
}

// ── syslog.inc: exec_command() in static initializers ───────────
$path = "$inc/syslog.inc";
if (file_exists($path)) {
    $content = file_get_contents($path);
    $content = preg_replace(
        '/static (\$\w+) = (exec_command\([^;]+\));/',
        'static $1 = null; if ($1 === null) { $1 = $2; }',
        $content,
        -1, $syslog_count
    );
    if ($syslog_count > 0) {
        file_put_contents($path, $content);
        $count += $syslog_count;
        fprintf(STDERR, "  patched $syslog_count static-init(s) in syslog.inc\n");
    }
}

// ── Generic catch-all regex ─────────────────────────────────────
// Catches any remaining static $var = func_call() patterns.
// Skips: null, true, false, array(...), [...], function(), strings, numbers.
$all_inc_files = glob("$inc/*.inc");
if ($all_inc_files === false) $all_inc_files = [];
foreach ($all_inc_files as $path) {
    $content = file_get_contents($path);
    $new_content = preg_replace_callback(
        '/^(\s*)static\s+(\$\w+)\s*=\s*(?!null|true|false|array\s*\(|\[|function\s*\(|"|\'|\d)([^;\n]+);/m',
        function($m) {
            $indent = $m[1];
            $var = $m[2];
            $expr = $m[3];
            return "{$indent}static {$var} = null; if ({$var} === null) { {$var} = {$expr}; }";
        },
        $content,
        -1, $generic_count
    );
    if ($generic_count > 0 && $new_content !== $content) {
        file_put_contents($path, $new_content);
        $count += $generic_count;
        fprintf(STDERR, "  patched $generic_count remaining static-init(s) in " . basename($path) . "\n");
    }
}

// ── Hook mwexec() to rewrite FreeBSD paths to our shims ────────
$path = "$inc/util.inc";
if (file_exists($path)) {
    $content = file_get_contents($path);
    $search = 'function mwexec($command, $nologentry = false, $clearsigmask = false, $background = false) {';
    $replace = "function mwexec(\$command, \$nologentry = false, \$clearsigmask = false, \$background = false) {\n\tif (function_exists('stormwall_patch_command')) { \$command = stormwall_patch_command(\$command); }";
    if (strpos($content, $search) !== false) {
        $content = str_replace($search, $replace, $content);
        file_put_contents($path, $content);
        $count++;
        fprintf(STDERR, "  patched mwexec() in util.inc\n");
    }
}

// ── PHP 8.2 type strictness: count(false), array_keys(null) ────
// status.php: get_backups() returns false when no backups exist
$path = '/usr/local/www/status.php';
if (file_exists($path)) {
    $content = file_get_contents($path);
    $content = str_replace(
        '$confvers = get_backups();',
        '$confvers = get_backups(); if (!is_array($confvers)) { $confvers = array(); }',
        $content
    );
    if (file_put_contents($path, $content)) {
        $count++;
        fprintf(STDERR, "  patched count(false) in status.php\n");
    }
}

// interfaces_assign.php: $portlist can be null — coerce before all uses
$path = '/usr/local/www/interfaces_assign.php';
if (file_exists($path)) {
    $content = file_get_contents($path);
    $content = str_replace(
        '/* Create a list of unused ports */',
        '/* Create a list of unused ports */' . "\n" . 'if (!is_array($portlist)) { $portlist = array(); }',
        $content
    );
    if (file_put_contents($path, $content)) {
        $count++;
        fprintf(STDERR, "  patched null portlist in interfaces_assign.php\n");
    }
}

// ── Create PEAR/Auth stubs (captive portal RADIUS, not needed) ──
// pfSense requires PEAR.php and Auth/RADIUS.php but they have PHP 8.2
// issues and are only needed for captive portal RADIUS auth.
$pear_stub = <<<'STUB'
<?php
// PEAR.php stub — stormwall Linux compat
// SPDX-License-Identifier: MIT
if (!class_exists('PEAR')) {
    class PEAR {
        public static function isError($data, $code = null) {
            if (!is_object($data)) return false;
            return ($data instanceof PEAR_Error);
        }
        public static function raiseError($message = null) {
            return new PEAR_Error($message);
        }
        public static function loadExtension($ext) {
            return extension_loaded($ext);
        }
    }
    class PEAR_Error {
        public $message;
        public function __construct($message = '') { $this->message = $message; }
        public function getMessage() { return $this->message; }
    }
}
STUB;
@mkdir("$inc", 0755, true);
file_put_contents("$inc/PEAR.php", $pear_stub);
fprintf(STDERR, "  created PEAR.php stub\n");

$radius_stub = <<<'STUB'
<?php
// Auth/RADIUS.php stub — stormwall Linux compat
// SPDX-License-Identifier: MIT
if (!class_exists('Auth_RADIUS')) {
    class Auth_RADIUS {
        public function start() { return false; }
        public function getError() { return 'RADIUS not available on stormwall'; }
    }
    class Auth_RADIUS_PAP extends Auth_RADIUS {
        public $password;
    }
    class Auth_RADIUS_CHAP_MD5 extends Auth_RADIUS {}
    class Auth_RADIUS_MSCHAPv1 extends Auth_RADIUS {}
    class Auth_RADIUS_MSCHAPv2 extends Auth_RADIUS {}
}
STUB;
@mkdir("$inc/Auth", 0755, true);
file_put_contents("$inc/Auth/RADIUS.php", $radius_stub);
fprintf(STDERR, "  created Auth/RADIUS.php stub\n");

$xmlrpc_stub = <<<'STUB'
<?php
// XML/RPC2/Client.php stub — stormwall Linux compat
// SPDX-License-Identifier: MIT
if (!class_exists('XML_RPC2_Client')) {
    class XML_RPC2_Client {
        public static function create($uri, $options = array()) {
            return new self();
        }
        public function __call($method, $args) {
            return false;
        }
    }
}
STUB;
@mkdir("$inc/XML/RPC2", 0755, true);
file_put_contents("$inc/XML/RPC2/Client.php", $xmlrpc_stub);
fprintf(STDERR, "  created XML/RPC2/Client.php stub\n");

// ── Create vendor/autoload.php stub (Composer not installed) ────
$autoload_stub = <<<'STUB'
<?php
// Composer autoload stub — stormwall Linux compat
// SPDX-License-Identifier: MIT
// Real Composer packages are not installed; this prevents fatal errors.
spl_autoload_register(function ($class) {
    // No-op autoloader — classes from vendor/ packages are not available.
});
STUB;
$www = '/usr/local/www';
@mkdir("$www/vendor", 0755, true);
file_put_contents("$www/vendor/autoload.php", $autoload_stub);
fprintf(STDERR, "  created vendor/autoload.php stub\n");

// ── Neutralize widget includes that need missing vendor classes ──
// These widgets depend on Composer packages (pfSense\Services\*) that
// aren't available without a full Composer install.
$widget_dir = "$www/widgets/include";
$broken_widgets = ['disks.inc'];
foreach ($broken_widgets as $widget) {
    $path = "$widget_dir/$widget";
    if (file_exists($path)) {
        file_put_contents($path, "<?php\n// Disabled: requires vendor packages not available on stormwall\n");
        fprintf(STDERR, "  neutralized widget $widget\n");
    }
}

fprintf(STDERR, "PHP 8.2 + Linux compat: $count patches applied.\n");
