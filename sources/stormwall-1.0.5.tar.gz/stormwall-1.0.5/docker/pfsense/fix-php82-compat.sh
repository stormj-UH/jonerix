#!/bin/sh
# Fix pfSense PHP code for PHP 8.2 compatibility and Linux integration.
# Runs during Docker build after pfSense source is copied.
# SPDX-License-Identifier: MIT

set -e

printf 'Patching pfSense PHP for PHP 8.2 compatibility...\n'
php82 /tmp/fix-php82-compat.php
printf 'Done.\n'
