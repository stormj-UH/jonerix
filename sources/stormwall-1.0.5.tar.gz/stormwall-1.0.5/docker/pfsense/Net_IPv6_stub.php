<?php
/**
 * Minimal Net_IPv6 stub for pfSense on PHP 8.2+.
 *
 * The PEAR Net_IPv6 package uses deprecated {} syntax for string
 * offsets that PHP 8 removed.  This stub provides the subset of
 * functions pfSense actually calls using PHP's built-in inet_pton/
 * inet_ntop and filter_var.
 *
 * SPDX-License-Identifier: MIT
 */

class Net_IPv6 {

    /**
     * Check if a string is a valid IPv6 address.
     */
    public static function checkIPv6($ip) {
        $ip = trim($ip);
        // Strip zone ID (%eth0 etc.)
        if (($pos = strpos($ip, '%')) !== false) {
            $ip = substr($ip, 0, $pos);
        }
        return filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6) !== false;
    }

    /**
     * Compress an IPv6 address to its shortest form.
     */
    public static function compress($ip, $force = false) {
        $ip = trim($ip);
        $zone = '';
        if (($pos = strpos($ip, '%')) !== false) {
            $zone = substr($ip, $pos);
            $ip = substr($ip, 0, $pos);
        }
        // Strip prefix length
        $prefix = '';
        if (($pos = strpos($ip, '/')) !== false) {
            $prefix = substr($ip, $pos);
            $ip = substr($ip, 0, $pos);
        }
        $bin = @inet_pton($ip);
        if ($bin === false) {
            return $ip . $prefix . $zone;
        }
        return inet_ntop($bin) . $prefix . $zone;
    }

    /**
     * Uncompress (expand) an IPv6 address to its full form.
     */
    public static function uncompress($ip) {
        $ip = trim($ip);
        $zone = '';
        if (($pos = strpos($ip, '%')) !== false) {
            $zone = substr($ip, $pos);
            $ip = substr($ip, 0, $pos);
        }
        $prefix = '';
        if (($pos = strpos($ip, '/')) !== false) {
            $prefix = substr($ip, $pos);
            $ip = substr($ip, 0, $pos);
        }
        $bin = @inet_pton($ip);
        if ($bin === false) {
            return $ip . $prefix . $zone;
        }
        $hex = bin2hex($bin);
        $full = implode(':', str_split($hex, 4));
        return $full . $prefix . $zone;
    }

    /**
     * Get the address type (link-local, global, etc.).
     */
    public static function getAddressType($ip) {
        $ip = trim($ip);
        if (($pos = strpos($ip, '%')) !== false) {
            $ip = substr($ip, 0, $pos);
        }
        if (($pos = strpos($ip, '/')) !== false) {
            $ip = substr($ip, 0, $pos);
        }
        $bin = @inet_pton($ip);
        if ($bin === false) return false;

        $hex = bin2hex($bin);
        $first16 = hexdec(substr($hex, 0, 4));

        if ($ip === '::1') return 2;          // NET_IPV6_LOOPBACK
        if ($ip === '::') return 1;           // NET_IPV6_UNSPECIFIED
        if (($first16 & 0xFFC0) === 0xFE80) return 4;  // NET_IPV6_LOCAL_LINK
        if (($first16 & 0xFFC0) === 0xFEC0) return 5;  // NET_IPV6_LOCAL_SITE
        if (($first16 & 0xFF00) === 0xFF00) return 3;   // NET_IPV6_MULTICAST
        return 6; // NET_IPV6_GLOBAL_UNICAST
    }

    /**
     * Remove the prefix length from an address.
     */
    public static function removeNetmaskSpec($ip) {
        if (($pos = strpos($ip, '/')) !== false) {
            return substr($ip, 0, $pos);
        }
        return $ip;
    }

    /**
     * Get the prefix length.
     */
    public static function getNetmaskSpec($ip) {
        if (($pos = strpos($ip, '/')) !== false) {
            return (int) substr($ip, $pos + 1);
        }
        return 128;
    }

    /**
     * Check if an address is in a subnet.
     */
    public static function isInNetmask($ip, $netmask) {
        $ip = self::removeNetmaskSpec($ip);
        $prefix = self::getNetmaskSpec($netmask);
        $network = self::removeNetmaskSpec($netmask);

        $ip_bin = @inet_pton($ip);
        $net_bin = @inet_pton($network);
        if ($ip_bin === false || $net_bin === false) return false;

        $ip_hex = bin2hex($ip_bin);
        $net_hex = bin2hex($net_bin);

        // Compare first $prefix bits via hex nibbles (each hex char = 4 bits)
        $full_nibbles = intdiv($prefix, 4);
        if (substr($ip_hex, 0, $full_nibbles) !== substr($net_hex, 0, $full_nibbles)) {
            return false;
        }
        // Check remaining bits in the partial nibble
        $remaining = $prefix % 4;
        if ($remaining > 0 && $full_nibbles < strlen($ip_hex)) {
            $ip_nibble = hexdec($ip_hex[$full_nibbles]);
            $net_nibble = hexdec($net_hex[$full_nibbles]);
            $mask = (~((1 << (4 - $remaining)) - 1)) & 0xF;
            if (($ip_nibble & $mask) !== ($net_nibble & $mask)) {
                return false;
            }
        }
        return true;
    }
}

// Define constants that pfSense expects
if (!defined('NET_IPV6_UNSPECIFIED'))    define('NET_IPV6_UNSPECIFIED', 1);
if (!defined('NET_IPV6_LOOPBACK'))       define('NET_IPV6_LOOPBACK', 2);
if (!defined('NET_IPV6_MULTICAST'))      define('NET_IPV6_MULTICAST', 3);
if (!defined('NET_IPV6_LOCAL_LINK'))     define('NET_IPV6_LOCAL_LINK', 4);
if (!defined('NET_IPV6_LOCAL_SITE'))     define('NET_IPV6_LOCAL_SITE', 5);
if (!defined('NET_IPV6_GLOBAL_UNICAST')) define('NET_IPV6_GLOBAL_UNICAST', 6);
