#!/bin/sh
# pfSense web UI container entrypoint
# SPDX-License-Identifier: MIT

set -e

# Generate self-signed cert if missing
if [ ! -f /etc/ssl/private/pfsense.crt ]; then
    printf 'Generating self-signed TLS certificate...\n'
    openssl req -x509 -nodes -days 3650 \
        -newkey rsa:2048 \
        -keyout /etc/ssl/private/pfsense.key \
        -out /etc/ssl/private/pfsense.crt \
        -subj "/CN=stormwall-pfsense/O=stormwall" \
        2>/dev/null
fi

# Bootstrap config.xml if not present
if [ ! -f /cf/conf/config.xml ]; then
    cp /cf/conf/config.xml.default /cf/conf/config.xml
    printf 'Initialized default config.xml\n'
fi

# pfSense uses both /conf and /cf/conf — symlink so both resolve
[ -e /conf ] || ln -s /cf/conf /conf
if [ ! -d /conf.default ]; then
    mkdir -p /conf.default
    cp /cf/conf/config.xml /conf.default/config.xml 2>/dev/null || true
fi

# /etc/inc symlink is created in Dockerfile

# Create FreeBSD-expected version files
printf '24.03-RELEASE\n' > /etc/version
printf '0\n' > /etc/version.patch
printf '%s\n' "$(date)" > /etc/version.buildtime
printf 'stormwall\n' > /etc/platform

# Create runtime directories pfSense expects
mkdir -p /var/db/pf /var/run /var/log /var/etc /tmp/captiveportal \
    /var/db/aliastables /var/dhcpd/var/run /usr/local/pkg /root \
    /var/db/rrd /usr/local/share/pfSense/menu

# Enable IP forwarding
if [ -w /proc/sys/net/ipv4/ip_forward ]; then
    printf '1' > /proc/sys/net/ipv4/ip_forward 2>/dev/null || true
fi
if [ -w /proc/sys/net/ipv6/conf/all/forwarding ]; then
    printf '1' > /proc/sys/net/ipv6/conf/all/forwarding 2>/dev/null || true
fi

# Start PHP-FPM
php-fpm82 -D

# Wait for php-fpm socket before starting nginx
i=0
while [ ! -S /var/run/php-fpm.sock ] && [ "$i" -lt 30 ]; do
    i=$((i + 1))
    sleep 0.1
done

# Start nginx in foreground
printf 'Starting stormwall-pfsense on https://0.0.0.0:443\n'
exec nginx -g 'daemon off;'
