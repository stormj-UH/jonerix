# pf-parity feature #10 — queueing via tc — implementation plan

## 0. Summary

Feature #10 is structurally different from the previous nine entries on the
pf-parity ladder. Every prior feature has compiled pf syntax down to nftables
expressions and pushed those down the existing `NETLINK_NETFILTER` pipe.
Queueing has no nftables target — the work product is `tc` qdiscs / classes /
filters living on `NETLINK_ROUTE`, a different netlink family with different
message types and a different attribute schema per qdisc discipline. The pf
rule body still emits an nftables expression (`meta priority set <handle>`),
but the receiving infrastructure for that priority value is built out-of-band
by stormwall talking `RTNLGRP_TC` directly.

Net effect: this is a second, smaller netlink client living next to the
existing one, plus a thin pf-side parser extension, plus an integration test
harness that strace-references iproute2's `tc` binary the same way feature #1
strace-referenced upstream `nft`.

Confidence: medium. The unknowns sit in HFSC curve encoding and in the bridge
between `meta priority` and `tc filter`. Everything else is mechanical.

## 1. Netlink architecture for `RTNLGRP_TC`

### 1.1 Module layout

Recommend a **new `src/tc.rs` module** rather than overloading `src/netlink.rs`.
Reasoning:

- `netlink.rs` currently couples three things that look generic but are
  actually nftables-specific: the socket is opened with protocol
  `NETLINK_NETFILTER` (line 664), `MsgBuilder::begin_msg` shifts
  `NFNL_SUBSYS_NFTABLES` into the high byte of `nlmsg_type` (line 827), and
  `write_nfgenmsg` writes an `nfgenmsg` header that `tc` does not use (it uses
  `tcmsg`, a different fixed-size header with `tcm_family`, `tcm_ifindex`,
  `tcm_handle`, `tcm_parent`, `tcm_info`).
- The lower-level primitives are genuinely shared and should be lifted, not
  duplicated.

Concretely, factor `netlink.rs` into:

- A small **`netlink_core`** layer (could stay in `netlink.rs` under a
  `pub mod core` or move to `src/netlink_core.rs`) holding: `align4`, the
  socket open/send/recv/poll/timeout helpers, `setsockopt` boilerplate
  (`SO_*BUFFORCE`, `NETLINK_NO_ENOBUFS`, `NETLINK_CAP_ACK`), the raw
  `nlmsghdr` writer, generic `put_u8/u16/u32/u64`, `put_str`, `put_bytes`,
  `begin_nested`/`end_nested`, `parse_attrs`, `check_ack`,
  `process_response`, the `STORMWALL_NLDUMP` hook (this is critical — the
  parity harness depends on it).
- The existing **`netlink.rs`** keeps the nftables-specific surface:
  `NFNL_SUBSYS_NFTABLES`, `begin_msg`, `write_nfgenmsg`, `batch_begin/end`,
  all the `NFTA_*` / `NFT_*` constants. `MsgBuilder` becomes
  nftables-flavoured.
- A new **`src/tc.rs`** holds: protocol constant `NETLINK_ROUTE = 0`,
  multicast group constants (`RTNLGRP_TC = 3`), message types
  (`RTM_NEWQDISC = 36`, `RTM_DELQDISC = 37`, `RTM_GETQDISC = 38`,
  `RTM_NEWTCLASS = 40`, etc.), the `tcmsg` writer, and a `TcMsgBuilder` that
  wraps `MsgBuilder`-equivalent primitives with the tc header.

Trade-offs:

- *Single shared `MsgBuilder` with a family enum*: cheaper diff, keeps NLDUMP
  path in one place, but couples nftables and tc constants in one struct and
  forces every attribute helper to know which protocol it's emitting for.
  Rejected — bad encapsulation.
- *Brand-new `tc.rs` that copies the socket helpers wholesale*: fastest
  landing PR1, but duplicates the env-dump short-circuit
  (`STORMWALL_NLDUMP`) which we know the test harness depends on, and now
  any fix lives in two places. Rejected.
- *Factor + new module (recommended)*: PR1 is slightly larger because of the
  refactor, but every later PR is cheaper and the test infrastructure works
  for free. Recommended.

### 1.2 What's shared, what's not

Shared (after the refactor):

- Socket open + buffer-forcing setsockopts. The 16 MB buffer rationale at
  netlink.rs:668–683 applies equally to tc — bulk class adds run hundreds of
  messages.
- `NETLINK_NO_ENOBUFS` and `NETLINK_CAP_ACK`. Both are `SOL_NETLINK`,
  family-agnostic.
- `nlmsghdr` byte layout, `align4`, generic NLA encoding, ACK parsing,
  `STORMWALL_NLDUMP`.
- The send/recv/poll loop and `process_response` callback shape.

Distinct:

- **Protocol family**: `socket(AF_NETLINK, ..., NETLINK_ROUTE)` vs
  `NETLINK_NETFILTER`.
- **Top message header**: nftables uses `nfgenmsg` (4 bytes: family, version,
  res_id BE u16). tc uses `tcmsg` (20 bytes on the wire: `tcm_family u8`,
  `__pad1 u8`, `__pad2 u16`, `tcm_ifindex i32`, `tcm_handle u32`,
  `tcm_parent u32`, `tcm_info u32`).
- **Message-type encoding**: nftables packs
  `(NFNL_SUBSYS_NFTABLES << 8) | msg_type` into `nlmsg_type`. rtnetlink
  writes `RTM_*` directly into `nlmsg_type` — no subsystem bits, no batching
  wrapper.
- **No batch wrapper**. There is no `NFNL_MSG_BATCH_BEGIN`/`END` for
  rtnetlink. Each tc message is its own transaction. This simplifies the
  builder — no `batch_begin/end` analogue is needed — and changes the
  failure model: each qdisc add is independently atomic from the kernel's
  view; failure mid-sequence leaves prior adds applied. Document a
  stormwall-side rollback strategy (issue `RTM_DELQDISC` for everything
  emitted so far on error) inside `src/tc.rs`.
- **ACK semantics**: rtnetlink sends `NLMSG_ERROR` with `error == 0` for ACK
  on `NLM_F_ACK` requests. The existing `check_ack` handles this generically
  (it's not nftables-specific) so it should move to the shared layer
  cleanly.
- **Dump semantics**: rtnetlink dumps (`RTM_GETQDISC` with
  `NLM_F_DUMP | NLM_F_ROOT | NLM_F_MATCH`) deliver multipart responses
  ending with `NLMSG_DONE` — same shape as nftables dumps, so
  `process_response_multi` (netlink.rs:1081) reuses cleanly.

### 1.3 One socket or two?

**Recommend: one socket per `NlSocket`-style handle, but do open a second
handle for tc.** Rationale:

- A single AF_NETLINK socket can only bind to one protocol family. You
  cannot multiplex `NETLINK_NETFILTER` and `NETLINK_ROUTE` on the same fd.
- Process-wide, two sockets is fine. They're cheap; the buffers are the only
  cost; and `ops.rs` already owns its `NlSocket` lifecycle from `NftCtx`.
- Keep them lazily opened. Add a `tc_sock: Option<TcSocket>` to `NftCtx` and
  open on first tc-emitting command. Most rulesets won't queue.
- Both sockets should set the same buffer / NO_ENOBUFS / CAP_ACK options.
  The `setsockopt` helper from the shared layer takes both fds.

## 2. pf → tc mapping table

The shape of every queueing rule is: one **root qdisc** per egress interface,
then a tree of **classes** under it, then **filters** that match
`meta priority` (set by the nftables side) and dispatch to a class.

### 2.1 Root qdisc selection

pf's grammar lets the user specify the discipline at the root:
`altq on em0 hfsc bandwidth 100Mb queue { ... }` or
`altq on em0 priq queue { ... }`. We map:

| pf root | tc root qdisc |
|---|---|
| `hfsc` | `RTM_NEWQDISC` with `TCA_KIND="hfsc"`, `TCA_OPTIONS` carrying `tc_hfsc_qopt { defcls }` |
| `cbq`  | **deferred** — parser accepts the keyword, emits a one-line stderr warning `pf: cbq is removed from upstream Linux ≥6.5; falling back to <fallback>`, then proceeds as if the user had written the fallback discipline. **Default fallback is `hfsc`.** CBQ was removed from upstream Linux around 6.5; the qdisc module no longer ships in many distros. Re-implementing the algorithm against current kernel uAPI is not worth the engineering cost when HFSC and HTB cover the same use cases more correctly. |
| `priq` | `TCA_KIND="prio"`, `TCA_OPTIONS=tc_prio_qopt { bands, priomap[16] }` |
| (no altq root, just `queue`) | default to `hfsc` to match modern pf-on-OpenBSD behaviour |

**Fallback override (user-controllable).** The cbq → hfsc substitution is a default, not a hardcode. A user with an existing pf.conf that legitimately wants HTB instead (e.g. they're carrying a CBQ ruleset over from old pf and want simpler rate semantics rather than HFSC's curve model) can change the default via, in order of precedence:

1. **Environment variable** `STORMWALL_PF_CBQ_FALLBACK=<kind>`. Values: `hfsc` (default), `htb`, `error` (refuse to translate; exit non-zero so a CI gate catches it). The check fires before any tc message is emitted.
2. **CLI flag** `--pf-cbq-fallback=<kind>`. Same value set; takes precedence over the env var. Stormwall's existing `--pf` flag lives next to this; both are `--pf-…` to keep the namespace clean.
3. **pf-syntax knob** `set stormwall-cbq-fallback htb` at the top of `pf.conf`. Stormwall-specific extension to pf's existing `set` directive. Lowest precedence so a global env var/CLI flag can override per-invocation. Defer this form to a follow-up if it complicates the parser; env var + CLI flag cover the common case.

The same mechanism applies generically to any future deferral — name the pattern `STORMWALL_PF_<FEATURE>_FALLBACK` so adding more deferrals (e.g. an unsupported HFSC curve form, or a tc qdisc that's gone from a specific kernel build) is just a new env var without re-architecting. Document the full set of fallback knobs in a dedicated `docs/pf-deferrals.md` once there are more than two.

### 2.2 Per-keyword mapping

| pf keyword | tc primitive | notes |
|---|---|---|
| `queue NAME` | `RTM_NEWTCLASS` under root, `TCA_KIND` = root's kind, classid `1:N` where N is allocated | NAME → numeric handle is stormwall's job; see §6 for the convention. |
| `bandwidth Xkb / XMb / XGb` | for HTB: `tc_htb_opt.rate` (bytes/sec, 32-bit; ceil = rate when no upper limit). For HFSC: `tc_hfsc_curve.m2` (long-term rate). For PRIO: ignored (PRIO is strict-priority, not rate-shaped). | pf uses bits/sec; tc uses bytes/sec. Conversion is `/ 8`. Beware overflow on 100+ Gb links — kernel switched to 64-bit rates in 4.x via `TCA_HTB_RATE64`/`TCA_HFSC_*64`. Use the 64-bit forms. |
| `qlimit N` | `TCA_OPTIONS.qlen = N` for the leaf qdisc that's auto-attached under each HFSC/HTB class (typically `pfifo` — set its `tc_fifo_qopt.limit`). | Default leaf is `pfifo` if not specified. |
| `priority N` | two paths: (a) when used as a **queue attribute** under PRIQ root, becomes the band index in `priomap`. (b) when used as a **rule action** (`pass ... priority N`), lowers to `meta priority set N` in nftables-land — no tc message at all. Disambiguate at parse time. |
| `hfsc(realtime BW, upperlimit BW, linkshare BW)` | three `tc_hfsc_curve` structs in `TCA_HFSC_RSC`, `TCA_HFSC_USC`, `TCA_HFSC_FSC`. Each curve is `{ m1, d, m2 }` — slope1 (bps), delay (us), slope2 (bps). pf's single-rate `realtime BW` maps to `{ m1=0, d=0, m2=BW/8 }`. The two-piece form `realtime (BW1 D BW2)` maps cleanly to all three fields. | This is the only shape with real complexity. The kernel reads m1 and m2 in bytes/sec, d in microseconds. |

### 2.3 Bridge: how `pass ... queue (bulk, urgent)` lowers

The challenge: a pf rule selects a queue *by name*, but the nftables datapath
only knows numeric u32 priorities, and the tc datapath only knows numeric
`1:M` classids. Stormwall owns the name → number map.

Lowering steps for
`pass out on em0 proto tcp to port 22 queue (bulk, urgent)`:

1. **Name resolution.** At parse time, stormwall has already seen
   `queue bulk { ... }` and `queue urgent { ... }` declarations and assigned
   each a `(prio_marker, classid)` pair. `bulk` might be `(0x10, 0x10010)`
   and `urgent` `(0x11, 0x10011)`.
2. **Two-queue semantics.** pf's `queue (default, ack)` syntax means
   "default for most traffic, but ACK-only TCP segments go to `ack`". For
   now, ignore the second queue and route everything to the first — note as
   a known limitation in the docs (matches what feature #1's TODO trail
   does for unsupported sub-features).
3. **nftables side.** The rule body gets one extra expression appended:
   `meta priority set 0x10`. Concretely a `payload` → `immediate` to
   `NFT_REG_1` plus a `meta set NFT_META_PRIORITY` — the existing IR's
   `Expr` enum should already grow a `MetaPrioritySet(u32)` variant,
   encoded by `ops.rs` as the standard meta-set expression (the
   `NFT_META_PRIORITY` constant is 0x07).
4. **tc side.** Once per stormwall-run, for the egress interface, emit one
   `RTM_NEWTFILTER` per declared queue. The filter is a `TCA_KIND="basic"`
   (or `"fw"`) filter that matches on `meta->priority == prio_marker` and
   points `TCA_BASIC_CLASSID` at the queue's classid. Result: any packet
   leaving the box on em0 with skb->priority == 0x10 lands in HTB/HFSC
   class `1:0010`, which shapes it.

This is the *only* fundamentally novel control-plane interaction. Everything
else is mechanical attribute encoding.

## 3. Reference sources

- **iproute2 (`tc` binary)**: GPL-2.0. **Cannot vendor.** Reference only by
  stracing the binary as a black-box producer of netlink bytes (same
  pattern the pf-parity harness already uses against upstream `nft` — see
  `tests/pf-parity.sh` which consumes `tests/pf-corpus/strace/*.strace`).
  We can read the source for kernel-API understanding (uAPI headers,
  attribute order conventions), but no code copying.
- **FreeBSD `pfctl`** (`/usr/src/sbin/pfctl/`): BSD-2-Clause, **usable as
  reference**. Their `pfctl_parser.c` and `pfctl_altq.c` show the
  source-side grammar we're matching, and their internal data structures
  map closely to what we need to lower from. Not a tc encoder but the
  canonical reference for *what the syntax means*.
- **OPNsense / pfSense shaper**: PHP/XML config glue, not Linux tc. Not
  useful.
- **Linux uAPI headers** (`linux/pkt_sched.h`, `linux/pkt_cls.h`,
  `linux/rtnetlink.h`): kernel headers carry their own GPL-2 +
  Linux-syscall-note exception. The syscall-note exception explicitly
  permits userland use. We may include constants and struct layouts via
  `libc` crate or by copying constants/struct definitions verbatim — same
  pattern as the `NFTA_*` constants already in `netlink.rs`.
- **`netlink-packet-route`** crate (Rust, MIT/Apache-2.0 dual): comprehensive
  rtnetlink encoder. **Permissive, usable for reference.** Their `src/tc/`
  subtree shows how a Rust client structures HFSC curve encoding. Read it;
  do not depend on it (stormwall's policy is no high-level netlink crates
  per the existing `netlink.rs` design).
- **`nftables` itself** has a `meta priority` expression encoder we already
  implement. No tc support — confirmed.
- **`qdiscman`** / **`cake-autorate`**: cake-autorate is bash + awk, not
  useful. qdiscman is moribund.
- **`rust-netlink`** crate ecosystem: MIT/Apache-2.0. Same status as
  `netlink-packet-route`.

Net: read `pfctl`, `netlink-packet-route`, and the kernel uAPI headers;
strace iproute2 for byte-level ground truth; vendor nothing.

## 4. Sub-PR breakdown

Estimated LoC includes tests. All PRs land green on castle (with appropriate
skip-on-no-tc fences) and on the Pi when it's reachable.

### PR1 — netlink-core refactor + tc scaffold (≈ 600 LoC)

- Extract shared primitives from `src/netlink.rs` into a `core` submodule
  (or `src/netlink_core.rs`). Keep all existing public paths working — the
  test corpus depends on them. This is mostly a mechanical move.
- New `src/tc.rs` with `TcSocket::open`, `TcMsgBuilder` (writes `nlmsghdr`
  then `tcmsg`), constants, and a single end-to-end smoke:
  `add_dummy_qdisc(ifindex)` emits `RTM_NEWQDISC` for `TCA_KIND="pfifo"`
  with `TCA_OPTIONS={limit:100}` on a stub interface, and
  `del_dummy_qdisc` removes it.
- Wire `STORMWALL_NLDUMP` through the tc socket the same way it works
  today for the netfilter socket.
- Test: a new `tests/tc-smoke.sh` that runs the dummy add+del under
  `STORMWALL_NLDUMP` and byte-diffs against a frozen iproute2 capture for
  `tc qdisc add dev lo root pfifo limit 100`.
- No pf-parser changes, no CLI surface changes. Internal-only. Lands green
  on any host because everything runs under NLDUMP, no kernel needed.

### PR2 — HTB qdisc + classes, `bandwidth` + `qlimit` (≈ 700 LoC)

- `tc::add_htb_root(ifindex, default_class)`,
  `tc::add_htb_class(ifindex, parent_classid, classid, rate, ceil)`,
  `tc::set_class_qlen(...)`.
- `pkt_sched.h` constants: `TCA_HTB_PARMS`, `TCA_HTB_INIT`,
  `TCA_HTB_RATE64`, `TCA_HTB_CEIL64`. Encode the rate-table struct
  (`tc_ratespec`).
- Tests: corpus of HTB rulesets, byte-diff vs
  `tc qdisc add dev lo root htb default 10` +
  `tc class add dev lo parent 1: classid 1:10 htb rate 10mbit`.
- No pf parser changes yet. Exercised via a new `--tc-debug` CLI escape
  hatch that takes a JSON spec and emits messages, OR via Rust unit tests
  calling `tc::add_htb_*` directly.

### PR3 — pf parser: `queue NAME { bandwidth ... qlimit ... }` declarations (≈ 500 LoC)

- Extend `src/pf_parser.rs` with a `parse_altq` and `parse_queue` for the
  OpenBSD `altq on <iface> hfsc/htb bandwidth Xb queue { ... }` block
  grammar (and the newer no-altq form).
- New IR variant: `Command::TcQueue { iface, parent: Option<String>, name,
  kind: QueueKind, bw: Option<u64>, qlimit: Option<u32>, ... }`. This sits
  alongside the existing nftables-flavoured `Command` variants because
  it's destined for a different netlink socket.
- `ops.rs` learns a tc-dispatch path: if the `Command` is a `TcQueue`,
  route to `tc::*` helpers instead of `MsgBuilder`. Open the tc socket
  lazily.
- Name-to-classid allocator lives in `pf_parser.rs` (see §6.1). Persists
  across parse for cross-references.
- Tests: pf-corpus gains `10a_queue_htb_bandwidth.pf` etc. Strace
  reference is `tc class add ...`.

### PR4 — PRIO qdisc + `priority` band selection (≈ 350 LoC)

- `tc::add_prio_qdisc(ifindex, bands, priomap[16])`. PRIO is the simplest
  qdisc: bands count, priomap maps skb->priority (16 buckets, one per skb
  tc_index value 0..15) to band 0..bands-1.
- pf grammar:
  `altq on em0 priq bandwidth Xb queue { q1 priority 7, q2 priority 3 }`.
  Lower to a single PRIO qdisc; the `priority` attribute populates one
  slot of `priomap`.
- The rule-action form `pass ... priority N` is also handled here: lowers
  to `meta priority set N`. The IR already has `Expr::MetaPrioritySet(u32)`
  from PR3 wiring (or add it here).

### PR5 — HFSC (≈ 800 LoC, the heavyweight)

- `tc::add_hfsc_qdisc`, `tc::add_hfsc_class`, with the three curve
  attributes (RSC/USC/FSC). Each is a `tc_service_curve { m1, d, m2 }`.
- pf grammar: `hfsc(realtime BW, upperlimit BW, linkshare BW)` and the
  two-piece `realtime (BW1 DELAY BW2)` form.
- HFSC is the discipline most pf users actually want; expect this PR to
  attract review.
- Risk: kernel HFSC has had API churn over the years (see `TCA_HFSC_*`
  history). Verify against Pi's 6.18 kernel.

### PR6 — rule action `queue (NAME)` + `meta priority set` wiring + tc filter dispatch (≈ 400 LoC)

- `pf_parser` recognises `... queue (NAME)` on `pass`/`block` rules.
  Resolves NAME → `prio_marker` via the allocator from PR3.
- Appends `Expr::MetaPrioritySet(prio_marker)` to the rule's expression
  list (nftables side).
- For each declared queue, emits one `RTM_NEWTFILTER` of kind `basic`
  matching on `meta->priority == prio_marker` and dispatching to the
  queue's classid.
- This is the integration PR — takes everything from PR2/3/4/5 and makes
  it actually route packets.
- Test: traffic test on Pi sends 22/tcp into a metered class, observes
  `tc -s class show` counters increment.

### PR7 — listing / decoding (`tc qdisc/class/filter show` equivalent) (≈ 500 LoC)

- `RTM_GETQDISC` + `RTM_GETTCLASS` + `RTM_GETTFILTER` dump handling. Reuse
  `process_response_multi` from the shared layer.
- Decode HTB/HFSC/PRIO/pfifo `TCA_OPTIONS` blobs into stormwall's
  `output.rs` printer style.
- pf `pfctl -s queue` analogue: `stormwall --pf -s queue`.
- Listing tests use `tc -s qdisc show` as the human-readable reference
  (text-diff is fine; we don't byte-diff our own output).

### Sequencing notes

PRs 1 and 2 have a hard dep order. PRs 3 / 4 / 5 are independent of each
other after PR2 lands and can ship in parallel. PR6 depends on at least one
of {3, 4, 5}. PR7 is independent and can be slipped wherever.

## 5. Test infrastructure

### 5.1 `tc-parity.sh` matrix

Same shape as `tests/pf-parity.sh`. For each `tests/tc-corpus/*.tc` file:

1. Run iproute2's `tc` once (offline, captured) under
   `strace -f -e trace=sendto -s 8192 -x` and freeze the netlink hex bytes
   into `tests/tc-corpus/strace/${name}.strace`.
2. Run `stormwall --pf --dump-tc -f $pf` (new `--dump-tc` flag, parallel to
   `--dump-exprs`) and emit hex.
3. Byte-diff, modulo seq numbers and the `nlmsg_pid` field (zero-out before
   compare, same scrub `pf-parity.sh` already does).

iproute2's GPL-2 status is fine for this use: stracing a black-box binary's
syscalls and writing our own emitter against the kernel uAPI is the same
posture as feature #1 against upstream `nft`. We do not link, do not derive
from source, do not vendor.

### 5.2 Per-feature monitor diff: `tc monitor`

`tc monitor` exists and subscribes to `RTNLGRP_TC` multicast group. It
prints `add qdisc / del qdisc / new class` events as the kernel applies
them. Pattern parallels `tests/monitor-diff.sh`:

```
sudo tc monitor > /tmp/$label.tc.raw &
sudo $BIN -f $rules
sudo tc qdisc del dev <iface> root  # cleanup; see §5.4
kill $monitor_pid
diff <(scrub /tmp/$label.nft.raw) <(scrub /tmp/$label.sw.raw)
```

Scrub rules: same as nft (zero handle numbers, anon-set names) plus zero
`tc_handle` low-byte where it's auto-assigned.

### 5.3 Host availability

- **Pi (`jonerix-tormenta`, aarch64, kernel 6.18)**: primary test host. 6.18
  has all qdisc modules in tree.
- **castle (Gentoo x86_64)**: uncertain. Verify with
  `find /lib/modules/$(uname -r)/kernel/net/sched -name 'sch_*.ko*'` and
  `cat /proc/net/psched` (latter must exist for `tc` to function at all).
  If `sch_htb`, `sch_hfsc`, `sch_prio`, `sch_pfifo` aren't present, castle
  does NLDUMP-only testing (no kernel apply).

### 5.4 Cleanup model

`nft flush ruleset` does NOT touch tc state. tc qdiscs persist across nft
flushes and across stormwall runs. Test harness must explicitly:

```
for if in $(ls /sys/class/net); do
    sudo tc qdisc del dev $if root 2>/dev/null || true
    sudo tc qdisc del dev $if ingress 2>/dev/null || true
done
```

This goes at the *top* of every tc test, not the bottom — `tc qdisc del
root` while a previous run's qdisc is mid-shaping a packet stream is
graceful, but we should not assume the prior run cleaned up. Add a
`setup_tc_clean()` helper in a new `tests/lib-tc.sh` and source from every
tc-touching test.

## 6. Risks and unknowns

### 6.1 Class-ID convention (the load-bearing one)

The `meta priority set <u32>` expression on the nftables side and the
`tc filter ... classid 1:N` on the tc side must agree on the u32 encoding,
or packets land in the default class and queueing silently no-ops.

Recommended convention:

- Reserve major handle `0x10` for the stormwall-managed root qdisc on each
  interface. (`1:0` in tc text form is the qdisc itself; classes hang off
  it as `1:1`, `1:2`, etc. Major number is arbitrary but must be
  consistent.)
- Allocate minor numbers `0x10..0xFFFE` for named queues, in declaration
  order.
- skb->priority u32 layout matches tc's `TC_H_MAKE(major, minor)` =
  `(major << 16) | minor`. So `meta priority set 0x100010` selects class
  `1:10`.
- `tc filter` of kind `basic` matches `meta priority` against this u32 and
  dispatches.

Document this in a doc-comment at the top of `src/tc.rs` with an ASCII art
diagram. Future maintainers will need it.

### 6.2 Pi kernel module availability

Check before merging PR1:

```
ssh jonerix-tormenta 'cat /proc/net/psched && \
  ls /lib/modules/$(uname -r)/kernel/net/sched/ | grep -E "sch_(htb|hfsc|prio|pfifo|fq_codel)"'
```

If `sch_hfsc.ko` is missing, PR5 cannot land integration tests against the
Pi. 6.18 should have all of them as in-tree modules; sanity check is cheap.

### 6.3 jonerix modprobe-shim

The auto-load gap surfaced during feature #1 (kernel modules not
auto-loaded on first netlink syscall) applies identically to tc. First
`RTM_NEWQDISC` with `TCA_KIND="hfsc"` will fail with `ENOENT` if `sch_hfsc`
isn't loaded.

Mitigations, pick one:

- Document the shim bug as a deployment prereq and require
  `modprobe sch_htb sch_hfsc sch_prio sch_pfifo` in stormwall's startup
  script. Lowest engineering cost; pushes the problem to ops.
- Have `tc.rs` invoke `modprobe` via fork/exec when it gets `ENOENT` on the
  first newqdisc and retry once. Self-healing; matches what iproute2 does
  internally. Recommended.
- Open a `/dev/null`-style bind-mount stub. Not viable.

Recommend option two with a fallback to the documented modprobe call in
the README.

### 6.4 64-bit rates

HTB and HFSC switched to 64-bit rate encoding around kernel 4.x. The legacy
`tc_ratespec.rate` is 32-bit and overflows above ~34 Gbit/s. Always emit
both the legacy 32-bit form (saturated to `~0u32` if larger) AND the
`TCA_HTB_RATE64` / `TCA_HFSC_*` 64-bit attribute, matching iproute2's
behaviour. Older kernels ignore the 64-bit attr; newer kernels prefer it.

### 6.5 Unknowns

- HFSC curve encoding details — specifically the m1/d/m2 → kernel internal
  slope conversion. Pin down by stracing iproute2 with several known-good
  service curves and decoding by hand. Budget half a day for PR5.
- `tc filter` of kind `basic` vs `fw` vs `u32` for the meta-priority match.
  `basic` is the cleanest match for our pattern but may not exist on every
  kernel config. Verify on Pi early.
- Whether stormwall should grow a notion of "ingress qdisc" for inbound
  shaping (pf has `queue` only on egress, so probably not — but verify
  against the OpenBSD reference).

## 7. Total scope

Engineering hours, end-to-end:

| Phase | Hours | Confidence |
|---|---|---|
| PR1 scaffold + refactor | 8–12 | high |
| PR2 HTB | 6–10 | high |
| PR3 pf parser `queue` decl | 8–12 | high |
| PR4 PRIO | 4–6 | high |
| PR5 HFSC | 16–24 | medium |
| PR6 integration (filter dispatch) | 8–12 | medium |
| PR7 listing | 8–12 | high |
| Test corpus + harness | 6–10 across PRs | high |
| **Total** | **64–98 hours** | **medium** |

Biggest unknowns sit in PR5 (HFSC curve details) and PR6 (the meta-priority
↔ tc filter handoff under real traffic on the Pi). Everything else is grunt
work against a documented kernel uAPI. CBQ stub deferral saves an estimated
15 hours that would otherwise be spent re-implementing a soon-to-be-removed
discipline.
