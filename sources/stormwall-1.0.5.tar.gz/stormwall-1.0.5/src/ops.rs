// (c) 2026 Jon-Erik G. Storm, Inc., a California Corporation,
// doing business as LAVA GOAT SOFTWARE.  MIT license.

use crate::netlink::*;
use crate::parser::*;
use crate::output;
use std::io;

/// Cached set metadata used by add_elements / delete_elements to
/// re-encode keys and data values that the parser produced at the
/// wrong width or byte order.
#[derive(Clone, Copy)]
struct SetInfo {
    interval: bool,
    key_len: u32,
    key_type: u32,
    data_len: u32,
    data_type: u32,
}

/// Unpack a 6-bit-slot packed dtype (NFTA_SET_KEY_TYPE) into per-slot
/// byte widths.  The packing is `(prev << 6) | type_id` with the
/// first selector in the MSB position.  Returns widths in selector
/// order.  For non-concat types the vec has a single element.
fn unpack_dtype_widths(packed: u32) -> Vec<u32> {
    if packed == 0 { return vec![4]; }
    let mut slots = Vec::new();
    let mut rem = packed;
    while rem > 0 {
        let tid = rem & 0x3f;
        slots.push(match tid {
            8  => 16, // ipv6_addr
            9  => 6,  // ether_addr
            12 => 1,  // icmp_type / icmpv6_type
            13 => 2,  // inet_service
            _  => 4,  // ipv4_addr, integer, mark, iface_index, …
        });
        rem >>= 6;
    }
    slots.reverse();
    slots
}

/// Re-encode a concatenated key so each 4-byte-padded slot has its
/// value left-justified at the slot's natural width.  The parser
/// always encodes numeric values as u32 BE, but the kernel expects
/// e.g. `inet_service` ports as u16 BE in the first two bytes of
/// the padded slot, not the last two.
fn reencode_concat_key(key: &[u8], packed_type: u32) -> Vec<u8> {
    let widths = unpack_dtype_widths(packed_type);
    if widths.len() <= 1 { return key.to_vec(); }
    let mut out = Vec::with_capacity(key.len());
    let mut off = 0usize;
    for &w in &widths {
        if off + 4 > key.len() { break; }
        let slot = &key[off..off+4];
        if w < 4 {
            // Narrow: the actual value sits in the last `w` bytes
            // of the u32 BE representation.  Move it to the front.
            let start = 4 - w as usize;
            out.extend_from_slice(&slot[start..4]);
            for _ in 0..(4 - w as usize) { out.push(0); }
        } else {
            out.extend_from_slice(slot);
        }
        off += 4;
    }
    if off < key.len() { out.extend_from_slice(&key[off..]); }
    out
}

/// Re-encode a data value for a set element.  The parser always
/// produces u32 BE bytes; this function narrows to `data_len` and
/// converts host-byte-order types (integer, mark, queue, …) from
/// BE to native endian.
fn reencode_data_value(bytes: &[u8], data_len: u32, data_type: u32) -> Vec<u8> {
    let dl = data_len as usize;
    if dl == 0 || bytes.is_empty() { return bytes.to_vec(); }
    // Network-byte-order types: keep big-endian, just resize.
    let is_net = matches!(data_type, 7 | 8 | 9 | 13);
    if is_net { return resize_key(bytes, data_len); }
    // Host-byte-order types: interpret the parser's BE bytes as
    // a numeric value, then re-encode in native endian.
    let mut val: u64 = 0;
    for &b in bytes { val = (val << 8) | b as u64; }
    match dl {
        1 => vec![val as u8],
        2 => (val as u16).to_ne_bytes().to_vec(),
        4 => (val as u32).to_ne_bytes().to_vec(),
        8 => val.to_ne_bytes().to_vec(),
        _ => resize_key(bytes, data_len),
    }
}

/// Resize a big-endian element key to `target_len` bytes.
/// If `key` is wider, strip leading (most-significant) bytes.
/// If `key` is narrower, zero-pad at the front.
/// This lets the parser produce u32 for all numeric values while
/// ops.rs trims to the actual set key width (e.g. 2 for inet_service).
fn resize_key(key: &[u8], target_len: u32) -> Vec<u8> {
    let tl = target_len as usize;
    if tl == 0 || key.len() == tl { return key.to_vec(); }
    if key.len() > tl {
        // Trim leading zero bytes (big-endian MSB).
        key[key.len() - tl..].to_vec()
    } else {
        // Zero-pad at front.
        let mut v = vec![0u8; tl - key.len()];
        v.extend_from_slice(key);
        v
    }
}

/// Map a human-readable conntrack state name to its NFTA_CT_TIMEOUT_DATA
/// child attribute ID for the given L4 protocol (IPPROTO_*). The IDs match
/// the kernel's per-protocol state enum order (1-based). Returns 0 for
/// unknown state/protocol combos so the caller can skip the attribute.
fn timeout_state_id(l4proto: u16, state: &str) -> u16 {
    match l4proto {
        6 /* TCP */ => match state {
            "syn_sent"    => CTA_TIMEOUT_TCP_SYN_SENT,
            "syn_recv"    => CTA_TIMEOUT_TCP_SYN_RECV,
            "established" => CTA_TIMEOUT_TCP_ESTABLISHED,
            "fin_wait"    => CTA_TIMEOUT_TCP_FIN_WAIT,
            "close_wait"  => CTA_TIMEOUT_TCP_CLOSE_WAIT,
            "last_ack"    => CTA_TIMEOUT_TCP_LAST_ACK,
            "time_wait"   => CTA_TIMEOUT_TCP_TIME_WAIT,
            "close"       => CTA_TIMEOUT_TCP_CLOSE,
            "syn_sent2"   => CTA_TIMEOUT_TCP_SYN_SENT2,
            "retrans"     => CTA_TIMEOUT_TCP_RETRANS,
            "unack"       => CTA_TIMEOUT_TCP_UNACK,
            _ => 0,
        },
        17 /* UDP */ => match state {
            "unreplied" => CTA_TIMEOUT_UDP_UNREPLIED,
            "replied"   => CTA_TIMEOUT_UDP_REPLIED,
            _ => 0,
        },
        _ => 0,
    }
}

#[derive(Clone)]
struct AnonSetPlan {
    name: String,
    set_id: u32,
    key_type: u32,
    key_len: u32,
    is_interval: bool,
    elements: Vec<(Vec<u8>, Option<Vec<u8>>)>,
    /// For anonymous verdict maps: one verdict per element
    /// (parallel to `elements`). Empty when this is a plain set.
    /// Each tuple is (code, chain_name) matching Expr::Verdict.
    verdicts: Vec<(i32, String)>,
}

pub struct NftCtx {
    sock: NlSocket,
    pub show_handles: bool,
    pub stateless: bool,
    #[allow(dead_code)]
    pub numeric_prio: bool,
    #[allow(dead_code)]
    pub numeric_proto: bool,
    pub json: bool,
    pub terse: bool,
    pub echo: bool,
    batch: Option<MsgBuilder>,
    // (family, table, set) → SetInfo for sets whose add_set call is
    // still buffered in the current batch.  add_elements uses this so
    // it treats a same-batch NEWSET as definitive (the kernel's GETSET
    // dump won't see it yet, so probe_set_info would miss the set).
    pending_sets: std::collections::HashMap<(u8, String, String), SetInfo>,
    // (family, table, set) → set of element keys already buffered in
    // the current batch.  When the same `add element` appears twice for
    // an object-reference map (type KEY : counter/quota/…), the kernel
    // increments the stateful object's refcount twice but a single
    // `delete element` only decrements it once, leaving the object busy
    // when the subsequent `delete counter` fires — even inside a single
    // atomic batch.  Dropping the duplicate NEWSETELEM message fixes
    // the double-refcount without changing observable behaviour
    // (idempotent re-add of the same key→objref in the same transaction
    // is a no-op from the user's perspective).
    pending_elem_keys: std::collections::HashMap<(u8, String, String), std::collections::HashSet<Vec<u8>>>,
    // Monotonic `__setN` allocator for anonymous sets created by
    // `ip saddr { a, b }` literals. Also doubles as the NFTA_SET_ID
    // counter (starts at 1 so 0 means "unset"). Never reset so
    // parallel anon sets inside one batch get distinct names.
    anon_set_counter: u32,
    // (family, table, chain) → ordered list of NFTA_RULE_ID values for
    // rules added in the current batch. Lets a subsequent `add rule …
    // index N` resolve N to the matching POSITION_ID even though those
    // earlier rules haven't been committed yet (so a GETRULE dump
    // would not see them).
    pending_rules: std::collections::HashMap<(u8, String, String), Vec<u32>>,
    // Monotonic NFTA_RULE_ID allocator. Each rule we emit in a batch
    // gets a fresh u32 so later messages can reference it via
    // NFTA_RULE_POSITION_ID.
    rule_id_counter: u32,
}

impl NftCtx {
    pub fn new() -> io::Result<Self> {
        Ok(NftCtx {
            sock: NlSocket::open()?,
            show_handles: false, stateless: false,
            numeric_prio: false, numeric_proto: false,
            json: false, terse: false, echo: false,
            batch: None,
            pending_sets: std::collections::HashMap::new(),
            pending_elem_keys: std::collections::HashMap::new(),
            anon_set_counter: 0,
            pending_rules: std::collections::HashMap::new(),
            rule_id_counter: 0,
        })
    }

    // Bump anon_set_counter past any `__setN`/`__mapN` already in the
    // target table. A previous `replace rule … { a, b }` leaves its
    // anon set installed (named `__set0` from a fresh nft process); a
    // following replace whose new rule also carries an anon set would
    // otherwise reuse the same name and the kernel rejects the NEWSET
    // with EOPNOTSUPP because flags can't be re-declared mid-table.
    // Real nft probes via GETSET dump and skips taken names — we mirror
    // that, only when the caller actually has anon sets to emit.
    fn bump_anon_counter_past_existing(&mut self, family: u8, table: &str) -> io::Result<()> {
        let mut max_n: i64 = -1;
        let tbl = table.to_string();
        self.dump(NFT_MSG_GETSET, family, |_, _| {}, |mt, _, data| {
            if mt != NFT_MSG_NEWSET { return; }
            let a = parse_attrs(data);
            let t = a.iter().find(|(t, _)| *t == NFTA_SET_TABLE)
                .map(|(_, v)| attr_str(v)).unwrap_or("");
            if t != tbl { return; }
            let name = a.iter().find(|(t, _)| *t == NFTA_SET_NAME)
                .map(|(_, v)| attr_str(v)).unwrap_or("");
            for prefix in &["__set", "__map"] {
                if let Some(suffix) = name.strip_prefix(prefix) {
                    if let Ok(n) = suffix.parse::<i64>() {
                        if n > max_n { max_n = n; }
                    }
                }
            }
        })?;
        if max_n >= 0 {
            let target = (max_n as u32).saturating_add(1);
            if self.anon_set_counter < target {
                self.anon_set_counter = target;
            }
        }
        Ok(())
    }

    // Lower Expr::AnonSet entries into Expr::Lookup plus a list of
    // AnonSetPlan records (NEWSET + NEWSETELEM messages that must
    // precede the rule in the same netlink batch). Shared between
    // add_rule and exec_replace so both `add rule ... { a, b }` and
    // `replace rule handle N ... { a, b }` work.
    fn lower_anon_sets(&mut self, in_exprs: &[Expr]) -> (Vec<Expr>, Vec<AnonSetPlan>) {
        use crate::netlink as nl;
        let mut anon_plans: Vec<AnonSetPlan> = Vec::new();
        let mut exprs: Vec<Expr> = Vec::with_capacity(in_exprs.len());
        let mut last_ctx_type: Option<(u32, u32)> = None;
        for e in in_exprs {
            match e {
                Expr::Payload { offset, len, base, .. } => {
                    last_ctx_type = Some(match (*base, *offset, *len) {
                        (b, 12, 4) | (b, 16, 4) if b == nl::NFT_PAYLOAD_NETWORK_HEADER => (7, 4),
                        (b, 8, 16) | (b, 24, 16) if b == nl::NFT_PAYLOAD_NETWORK_HEADER => (8, 16),
                        (b, 0, 2) | (b, 2, 2) if b == nl::NFT_PAYLOAD_TRANSPORT_HEADER => (13, 2),
                        (_, _, 1) => (12, 1),
                        (_, _, w) => (4, w),
                    });
                }
                Expr::Meta { key, width } => {
                    last_ctx_type = Some(match *key {
                        nl::NFT_META_MARK => (15, 4),
                        nl::NFT_META_IIFNAME | nl::NFT_META_OIFNAME => (16, 16),
                        nl::NFT_META_L4PROTO | nl::NFT_META_NFPROTO | nl::NFT_META_PROTOCOL => (12, 1),
                        nl::NFT_META_IIF | nl::NFT_META_OIF => (36, 4),
                        _ => (4, *width as u32),
                    });
                }
                Expr::Ct { width, .. } => { last_ctx_type = Some((4, *width as u32)); }
                // socket / rt loads — fall back to the same generic
                // (type=4, width) shape `meta cpu` / `meta cgroup`
                // already use, so anon-set lookups (`meta cpu { 0, 1 }`)
                // get a kernel-acceptable set type without a custom branch.
                Expr::Socket { width, .. } => { last_ctx_type = Some((4, *width as u32)); }
                Expr::Rt { width, .. } => { last_ctx_type = Some((4, *width as u32)); }
                _ => {}
            }
            match e {
                Expr::AnonSet { elements, width, inverted } => {
                    self.anon_set_counter = self.anon_set_counter.wrapping_add(1);
                    let n = self.anon_set_counter;
                    let name = format!("__set{}", n - 1);
                    let is_interval = elements.iter().any(|(_, end)| end.is_some());
                    let (key_type, key_len) = last_ctx_type.take().unwrap_or_else(|| match *width {
                        4  => (7u32,  4u32),
                        16 => (8u32,  16u32),
                        2  => (13u32, 2u32),
                        1  => (12u32, 1u32),
                        w  => (4u32,  w as u32),
                    });
                    anon_plans.push(AnonSetPlan {
                        name: name.clone(),
                        set_id: n, key_type, key_len, is_interval,
                        elements: elements.clone(),
                        verdicts: Vec::new(),
                    });
                    exprs.push(Expr::Lookup { set_name: name, inverted: *inverted, width: *width });
                }
                Expr::AnonVmap { pairs, width, packed_key_type } => {
                    self.anon_set_counter = self.anon_set_counter.wrapping_add(1);
                    let n = self.anon_set_counter;
                    let name = format!("__map{}", n - 1);
                    // Use the parser's packed_key_type when available
                    // (concat vmaps); fall back to width-based inference.
                    let (key_type, key_len) = if *packed_key_type != 0 {
                        (*packed_key_type, *width as u32)
                    } else {
                        last_ctx_type.take().unwrap_or_else(|| match *width {
                            4  => (7u32,  4u32),
                            16 => (8u32,  16u32),
                            2  => (13u32, 2u32),
                            1  => (12u32, 1u32),
                            w  => (4u32,  w as u32),
                        })
                    };
                    // For concat anon vmaps the parser widens `width` to
                    // cover all slots (e.g. 8 for ipv4_addr . ifindex).
                    // Use *width as the authoritative key length so the
                    // kernel allocates the correct set-element size.
                    let key_len = key_len.max(*width as u32);
                    let is_interval = pairs.iter().any(|(_, re, _, _)| re.is_some());
                    let elements: Vec<(Vec<u8>, Option<Vec<u8>>)> = pairs.iter()
                        .map(|(k, re, _c, _n)| (k.clone(), re.clone())).collect();
                    let verdicts: Vec<(i32, String)> = pairs.iter()
                        .map(|(_, _, c, cn)| (*c, cn.clone())).collect();
                    anon_plans.push(AnonSetPlan {
                        name: name.clone(),
                        set_id: n, key_type, key_len, is_interval,
                        elements, verdicts,
                    });
                    exprs.push(Expr::Vmap { set_name: name, width: *width, set_id: Some(n) });
                }
                _ => { exprs.push(e.clone()); }
            }
        }
        (exprs, anon_plans)
    }

    // Emit the NEWSET + NEWSETELEM preambles for an anon-set plan
    // batch into the MsgBuilder (which is either the shared
    // batch buffer or a fresh one per `send_batch` invocation).
    fn emit_anon_sets(msg: &mut MsgBuilder, family: u8, table: &str, plans: &[AnonSetPlan]) {
        for plan in plans {
            let is_vmap = !plan.verdicts.is_empty();
            let pset = msg.begin_msg(NFT_MSG_NEWSET, family, NLM_F_CREATE | NLM_F_ACK);
            msg.put_str(NFTA_SET_TABLE, table);
            msg.put_str(NFTA_SET_NAME, &plan.name);
            msg.put_u32_be(NFTA_SET_KEY_TYPE, plan.key_type);
            msg.put_u32_be(NFTA_SET_KEY_LEN, plan.key_len);
            let mut flags_v = NFT_SET_ANONYMOUS | NFT_SET_CONSTANT;
            if plan.is_interval { flags_v |= NFT_SET_INTERVAL; }
            if is_vmap { flags_v |= NFT_SET_MAP; }
            msg.put_u32_be(NFTA_SET_FLAGS, flags_v);
            if is_vmap {
                // NFT_DATA_VERDICT = 0xffffff00 (a mask, not a type index).
                // For verdict-valued sets the kernel sets dlen to the
                // verdict struct size itself, so we send DATA_LEN=0 —
                // matches upstream nft wire format verbatim.
                msg.put_u32_be(NFTA_SET_DATA_TYPE, 0xffffff00);
                msg.put_u32_be(NFTA_SET_DATA_LEN, 0);
            }
            msg.put_u32_be(NFTA_SET_ID, plan.set_id);
            msg.end_msg(pset);

            // NFTA_SET_ELEM_LIST_ELEMENTS uses a u16 nla_len → cap at
            // 65535 bytes. Split into multiple NEWSETELEM messages once
            // the current one approaches that ceiling. Same atomicity
            // guarantee since they live inside the same BATCH_*.
            const SPLIT_THRESHOLD: usize = 60000;
            let mut pelem = msg.begin_msg(NFT_MSG_NEWSETELEM, family, NLM_F_CREATE | NLM_F_ACK);
            msg.put_str(NFTA_SET_ELEM_LIST_TABLE, table);
            msg.put_str(NFTA_SET_ELEM_LIST_SET, &plan.name);
            let mut elist = msg.begin_nested(NFTA_SET_ELEM_LIST_ELEMENTS);
            debug_assert_eq!(plan.verdicts.len(), plan.elements.len(), "verdict/element count mismatch");
            for (i, (key, range_end)) in plan.elements.iter().enumerate() {
                if msg.buf.len() - pelem > SPLIT_THRESHOLD && msg.buf.len() > elist + 4 {
                    msg.end_nested(elist);
                    msg.end_msg(pelem);
                    pelem = msg.begin_msg(NFT_MSG_NEWSETELEM, family, NLM_F_CREATE | NLM_F_ACK);
                    msg.put_str(NFTA_SET_ELEM_LIST_TABLE, table);
                    msg.put_str(NFTA_SET_ELEM_LIST_SET, &plan.name);
                    elist = msg.begin_nested(NFTA_SET_ELEM_LIST_ELEMENTS);
                }
                let effective_end: Option<Vec<u8>> = if range_end.is_some() {
                    range_end.clone()
                } else if plan.is_interval {
                    Some(key.clone())
                } else { None };
                let ee = msg.begin_nested(NFTA_LIST_ELEM);
                msg.put_data_value(NFTA_SET_ELEM_KEY, key);
                if is_vmap {
                    let (code, chain) = plan.verdicts.get(i).expect("verdict/element count mismatch");
                    // DATA nested: NFTA_DATA_VERDICT nested with
                    // VERDICT_CODE and optional VERDICT_CHAIN.
                    let d = msg.begin_nested(NFTA_SET_ELEM_DATA);
                    let vd = msg.begin_nested(NFTA_DATA_VERDICT);
                    msg.put_u32_be(NFTA_VERDICT_CODE, *code as u32);
                    if !chain.is_empty() {
                        msg.put_str(NFTA_VERDICT_CHAIN, chain);
                    }
                    msg.end_nested(vd);
                    msg.end_nested(d);
                }
                msg.end_nested(ee);
                if let Some(end) = effective_end {
                    let mut end_plus = end.clone();
                    for byte in end_plus.iter_mut().rev() {
                        if *byte == 0xff { *byte = 0; } else { *byte += 1; break; }
                    }
                    let ee2 = msg.begin_nested(NFTA_LIST_ELEM);
                    msg.put_data_value(NFTA_SET_ELEM_KEY, &end_plus);
                    msg.put_u32_be(NFTA_SET_ELEM_FLAGS, NFT_SET_ELEM_INTERVAL_END);
                    msg.end_nested(ee2);
                }
            }
            msg.end_nested(elist);
            msg.end_msg(pelem);
        }
    }

    // ── Transactional batch mode ─────────────────────────────────
    // Buffer every NEW*/DEL* into one netlink batch so the whole
    // ruleset applies atomically. Any kernel ENOENT/EEXIST from
    // later messages rolls back earlier ones. Used for -f input.
    pub fn begin_txn(&mut self) {
        let mut m = MsgBuilder::new();
        m.batch_begin();
        self.batch = Some(m);
        self.pending_sets.clear();
        self.pending_elem_keys.clear();
        self.pending_rules.clear();
        self.rule_id_counter = 0;
    }

    pub fn commit_txn(&mut self) -> io::Result<()> {
        if let Some(mut m) = self.batch.take() {
            self.pending_sets.clear();
            self.pending_elem_keys.clear();
            self.pending_rules.clear();
            self.rule_id_counter = 0;
            // MsgBuilder starts at seq=1; batch_begin() uses one seq
            // (seq→2).  If no actual NFT messages were buffered, seq
            // is still 2 — an empty batch_begin + batch_end would get
            // no kernel ACK and we'd burn the full 200 ms recv timeout.
            // Skip the send entirely for read-only transactions.
            if m.current_seq() <= 2 {
                return Ok(());
            }
            // Snapshot the highest seq that the kernel will ACK
            // *before* batch_end appends BATCH_END (which goes up
            // without NLM_F_ACK, so the kernel won't reply to it).
            // Without this we'd wait the recv timeout after the last
            // real ACK hoping for a reply that never comes.
            let last_ack_seq = m.current_seq().saturating_sub(1);
            m.batch_end();
            let buf = m.finish();
            self.sock.send(&buf)?;
            let deadline = std::time::Instant::now() + std::time::Duration::from_secs(30);
            // Capture NLM_F_ECHO'd messages so callers can print
            // the rule they just added (with kernel-assigned handle)
            // — `-e` / --echo semantics.
            let echo = self.echo;
            let mut echoed: Vec<(u16, u8, Vec<u8>)> = Vec::new();
            let portid = self.sock.portid;
            let mut resp = Vec::with_capacity(65536);
            loop {
                if std::time::Instant::now() >= deadline { break; }
                let n = self.sock.recv_timeout_with_buf(&mut resp, 200)?;
                if n == 0 { break; }
                if echo {
                    let slice = &resp[..n];
                    let _ = process_response(slice, portid, |mt, fam, data| {
                        echoed.push((mt, fam, data.to_vec()));
                    })?;
                } else {
                    check_ack(&resp[..n])?;
                }
                // Walk the buffer for nlmsghdr.seq fields and exit as
                // soon as we've seen a reply for the last ACK-bearing
                // message. Caps the typical CLI op around the kernel's
                // own ACK round-trip (~10 ms) instead of bottoming out
                // at the 200 ms recv-fallback timeout.
                let mut off = 0usize;
                let mut highest_seen = 0u32;
                while off + 16 <= n {
                    let nl_len = u32::from_ne_bytes([resp[off], resp[off+1], resp[off+2], resp[off+3]]) as usize;
                    if nl_len < 16 || off + nl_len > n { break; }
                    let nl_seq = u32::from_ne_bytes([resp[off+8], resp[off+9], resp[off+10], resp[off+11]]);
                    if nl_seq > highest_seen { highest_seen = nl_seq; }
                    off += (nl_len + 3) & !3;
                }
                if highest_seen >= last_ack_seq { break; }
            }
            if echo { self.print_echoed(&echoed); }
        }
        Ok(())
    }

    fn print_echoed(&self, echoed: &[(u16, u8, Vec<u8>)]) {
        for (mt, fam, data) in echoed {
            let attrs = parse_attrs(data);
            match *mt {
                NFT_MSG_NEWRULE => {
                    let table = attrs.iter().find(|(t, _)| *t == NFTA_RULE_TABLE)
                        .map(|(_, v)| attr_str(v)).unwrap_or("");
                    let chain = attrs.iter().find(|(t, _)| *t == NFTA_RULE_CHAIN)
                        .map(|(_, v)| attr_str(v)).unwrap_or("");
                    let handle = attrs.iter().find(|(t, _)| *t == NFTA_RULE_HANDLE)
                        .map(|(_, v)| attr_u64_be(v)).unwrap_or(0);
                    println!("add rule {} {} {} # handle {}", family_str(*fam), table, chain, handle);
                }
                NFT_MSG_NEWTABLE => {
                    let name = attrs.iter().find(|(t, _)| *t == NFTA_TABLE_NAME)
                        .map(|(_, v)| attr_str(v)).unwrap_or("");
                    let handle = attrs.iter().find(|(t, _)| *t == NFTA_TABLE_HANDLE)
                        .map(|(_, v)| attr_u64_be(v)).unwrap_or(0);
                    println!("add table {} {} # handle {}", family_str(*fam), name, handle);
                }
                NFT_MSG_NEWCHAIN => {
                    let table = attrs.iter().find(|(t, _)| *t == NFTA_CHAIN_TABLE)
                        .map(|(_, v)| attr_str(v)).unwrap_or("");
                    let name = attrs.iter().find(|(t, _)| *t == NFTA_CHAIN_NAME)
                        .map(|(_, v)| attr_str(v)).unwrap_or("");
                    let handle = attrs.iter().find(|(t, _)| *t == NFTA_CHAIN_HANDLE)
                        .map(|(_, v)| attr_u64_be(v)).unwrap_or(0);
                    println!("add chain {} {} {} # handle {}", family_str(*fam), table, name, handle);
                }
                _ => {}
            }
        }
    }

    /// Send the queued batch to the kernel for validation only.
    /// Omits BATCH_END so the kernel validates each message (sending
    /// ACKs/NACKs) but never commits — the transaction is automatically
    /// aborted when the batch buffer ends without BATCH_END.
    #[allow(dead_code)]
    pub fn check_txn(&mut self) -> io::Result<()> {
        if let Some(m) = self.batch.take() {
            self.pending_sets.clear();
            self.pending_elem_keys.clear();
            self.pending_rules.clear();
            self.rule_id_counter = 0;
            if m.current_seq() <= 2 {
                return Ok(());
            }
            let last_ack_seq = m.current_seq().saturating_sub(1);
            // Intentionally NO batch_end() — kernel rolls back.
            let buf = m.finish();
            self.sock.send(&buf)?;
            let deadline = std::time::Instant::now() + std::time::Duration::from_secs(5);
            let mut resp = Vec::with_capacity(65536);
            loop {
                if std::time::Instant::now() >= deadline { break; }
                let n = self.sock.recv_timeout_with_buf(&mut resp, 200)?;
                if n == 0 { break; }
                check_ack(&resp[..n])?;
                let mut off = 0usize;
                let mut highest_seen = 0u32;
                while off + 16 <= n {
                    let nl_len = u32::from_ne_bytes([resp[off], resp[off+1], resp[off+2], resp[off+3]]) as usize;
                    if nl_len < 16 || off + nl_len > n { break; }
                    let nl_seq = u32::from_ne_bytes([resp[off+8], resp[off+9], resp[off+10], resp[off+11]]);
                    if nl_seq > highest_seen { highest_seen = nl_seq; }
                    off += (nl_len + 3) & !3;
                }
                if highest_seen >= last_ack_seq { break; }
            }
        }
        Ok(())
    }

    pub fn abort_txn(&mut self) {
        self.batch = None;
        self.pending_sets.clear();
        self.pending_elem_keys.clear();
        self.pending_rules.clear();
        self.rule_id_counter = 0;
    }

    pub fn exec(&mut self, cmd: &Command) -> io::Result<()> {
        match cmd.op {
            CmdOp::Add | CmdOp::Create => self.exec_add(cmd),
            CmdOp::Insert => self.exec_insert(cmd),
            CmdOp::Delete => self.exec_delete(cmd, false),
            CmdOp::Destroy => self.exec_delete(cmd, true),
            CmdOp::List => self.exec_list(cmd),
            CmdOp::Flush => self.exec_flush(cmd),
            CmdOp::Rename => self.exec_rename(cmd),
            CmdOp::Replace => self.exec_replace(cmd),
            CmdOp::Reset => self.exec_reset(cmd),
        }
    }

    // ── Batch send helper ───────────────────────────────────────

    fn send_batch(&mut self, build: impl FnOnce(&mut MsgBuilder)) -> io::Result<()> {
        if let Some(ref mut m) = self.batch {
            build(m);
            return Ok(());
        }
        let mut msg = MsgBuilder::new();
        msg.batch_begin();
        build(&mut msg);
        // The kernel ACKs every NEW*/DEL* in the batch but doesn't
        // ACK BATCH_BEGIN or BATCH_END (those go up without
        // NLM_F_ACK). Snapshot the seq counter *before* batch_end so
        // last_ack_seq matches the highest message that will actually
        // produce a reply — otherwise we'd wait the 200 ms timeout
        // hoping for an ACK on BATCH_END that never comes.
        let last_ack_seq = msg.current_seq().saturating_sub(1);
        msg.batch_end();
        let buf = msg.finish();
        self.sock.send(&buf)?;

        // STORMWALL_NLDUMP mode: send() above wrote the buffer to the
        // dump file and skipped the real syscall, so the kernel will
        // never reply. Skip the recv loop entirely.
        if std::env::var("STORMWALL_NLDUMP").is_ok() { return Ok(()); }

        let mut resp = Vec::with_capacity(65536);
        loop {
            let n = self.sock.recv_timeout_with_buf(&mut resp, 200)?;
            if n == 0 { break; }
            // Walk every nlmsghdr in the buffer: check_ack errors
            // out on a kernel error reply, and we track the highest
            // seq seen so we know when to stop.
            check_ack(&resp[..n])?;
            let mut off = 0usize;
            let mut highest_seen = 0u32;
            while off + 16 <= n {
                let nl_len = u32::from_ne_bytes([resp[off], resp[off+1], resp[off+2], resp[off+3]]) as usize;
                if nl_len < 16 || off + nl_len > n { break; }
                let nl_seq = u32::from_ne_bytes([resp[off+8], resp[off+9], resp[off+10], resp[off+11]]);
                if nl_seq > highest_seen { highest_seen = nl_seq; }
                off += (nl_len + 3) & !3;
            }
            if highest_seen >= last_ack_seq { break; }
        }
        Ok(())
    }

    // ── Dump helper ─────────────────────────────────────────────

    fn dump<F>(&mut self, msg_type: u16, family: u8,
               build_payload: impl FnOnce(&mut MsgBuilder, usize),
               mut handler: F) -> io::Result<()>
    where F: FnMut(u16, u8, &[u8])
    {
        let mut msg = MsgBuilder::new();
        // NLM_F_DUMP-only — NLM_F_ACK is not valid alongside NLM_F_DUMP;
        // the kernel responds with NLM_F_MULTI messages terminated by a
        // NLMSG_DONE. NFT_MSG_GETRULE_RESET in particular rejects the
        // request with EINVAL when ACK is also set.
        let pos = msg.begin_msg(msg_type, family, NLM_F_DUMP);
        build_payload(&mut msg, pos);
        msg.end_msg(pos);
        let buf = msg.finish();
        self.sock.send(&buf)?;

        let mut resp = Vec::with_capacity(65536);
        loop {
            let n = self.sock.recv_with_buf(&mut resp)?;
            if n == 0 { break; }
            let done = process_response(&resp[..n], self.sock.portid, &mut handler)?;
            if done { break; }
        }
        Ok(())
    }

    // ── Multi-dump collector ─────────────────────────────────────
    //
    // Send N dump requests sequentially (send+drain in a shared recv
    // loop keyed by nlmsg_seq), collecting each request's responses
    // into an indexed slot.  All N requests are built up-front into a
    // single send buffer; each request carries a unique seq (seq_base,
    // seq_base+1, …) so the drain loop can route responses to the
    // right slot.
    //
    // Netlink nf_tables enforces at most one active dump at a time per
    // socket: if the kernel returns EBUSY for request i it means the
    // previous dump hasn't completed yet and we must drain until
    // seq_base+i-1's DONE arrives before retrying.  multi_dump handles
    // this transparently by absorbing EBUSY on any slot and re-issuing
    // that slot's request once all prior slots are drained.
    //
    // In practice the kernel processes the entire send buffer before
    // we call recv, so the first request's response is already queued
    // when we start draining; subsequent requests that were EBUSY are
    // re-sent one at a time after we see the preceding DONE.  This
    // gives us at most N RTTs — the same as N sequential dump() calls
    // — but with better cache locality (one contiguous send buffer)
    // and a unified drain loop.
    //
    // Returns Vec<Vec<(msg_type, family, payload)>> indexed by request.
    fn multi_dump(
        &mut self,
        requests: Vec<(u16, u8, Box<dyn FnOnce(&mut MsgBuilder, usize)>)>,
    ) -> io::Result<Vec<Vec<(u16, u8, Vec<u8>)>>> {
        let n = requests.len();
        if n == 0 { return Ok(Vec::new()); }

        // Pre-build all request messages.  Each gets a unique seq so
        // we can demultiplex responses even if they arrive interleaved.
        // seq_base is the first seq assigned (MsgBuilder starts at 1).
        let mut msg = MsgBuilder::new();
        let seq_base = msg.current_seq();
        let mut request_bufs: Vec<Vec<u8>> = Vec::with_capacity(n);

        for (msg_type, family, build_payload) in requests {
            let mut m = MsgBuilder::new();
            // Borrow the seq from the shared allocator so seqs are
            // globally monotonic across all N slots.
            m.seq = msg.seq;
            let pos = m.begin_msg(msg_type, family, NLM_F_DUMP);
            build_payload(&mut m, pos);
            m.end_msg(pos);
            msg.seq = m.seq; // advance shared counter
            request_bufs.push(m.finish());
        }

        let mut results: Vec<Vec<(u16, u8, Vec<u8>)>> = (0..n).map(|_| Vec::new()).collect();
        let mut done_flags: Vec<bool> = vec![false; n];

        // Send the first request.
        self.sock.send(&request_bufs[0])?;
        let mut next_to_send: usize = 1; // index of next request not yet sent

        let mut resp = Vec::with_capacity(65536);
        loop {
            if done_flags.iter().all(|d| *d) { break; }

            let bytes = self.sock.recv_with_buf(&mut resp)?;
            if bytes == 0 { break; }

            {
                let results_ref = &mut results;
                let seq_base_copy = seq_base;
                process_response_multi(
                    &resp[..bytes],
                    seq_base_copy,
                    n,
                    &mut done_flags,
                    |idx, mt, fam, payload| {
                        results_ref[idx].push((mt, fam, payload.to_vec()));
                    },
                )?;
            }

            // After each recv, send the next pending request if the
            // immediately preceding slot is now done (i.e. its DONE
            // arrived, meaning the kernel is ready for the next dump).
            while next_to_send < n && done_flags[next_to_send - 1] {
                self.sock.send(&request_bufs[next_to_send])?;
                next_to_send += 1;
            }
        }

        Ok(results)
    }

    // ── Add ─────────────────────────────────────────────────────

    fn exec_add(&mut self, cmd: &Command) -> io::Result<()> {
        match cmd.obj {
            CmdObj::Table => self.add_table(cmd),
            CmdObj::Chain => self.add_chain(cmd),
            CmdObj::Rule => self.add_rule(cmd, false),
            CmdObj::Set | CmdObj::Map => {
                self.add_set(cmd)?;
                // Handle inline `elements = { ... }` in the set declaration.
                if !cmd.elements.is_empty() {
                    self.add_elements(cmd)?;
                }
                Ok(())
            }
            CmdObj::Element => self.add_elements(cmd),
            CmdObj::Counter | CmdObj::Quota | CmdObj::Limit => self.add_object(cmd),
            CmdObj::CtHelper | CmdObj::CtTimeout | CmdObj::CtExpect
            | CmdObj::Synproxy | CmdObj::Secmark | CmdObj::Tunnel => self.add_object(cmd),
            CmdObj::Flowtable => self.add_flowtable(cmd),
            _ => Err(io::Error::new(io::ErrorKind::Other, "unsupported add target")),
        }
    }

    fn exec_insert(&mut self, cmd: &Command) -> io::Result<()> {
        if matches!(cmd.obj, CmdObj::Rule) { self.add_rule(cmd, true) }
        else { Err(io::Error::new(io::ErrorKind::Other, "insert only for rules")) }
    }

    fn add_table(&mut self, cmd: &Command) -> io::Result<()> {
        let family = cmd.family;
        let name = cmd.table.clone();
        // When `has_flags` is true, send the explicit value. When
        // false and op is `add`, send flags=0 so an existing dormant
        // table is re-awakened (matches upstream libnftables behavior).
        // For `create` (which fails on existing), omitting is fine.
        let flags = if cmd.table_spec.has_flags {
            Some(cmd.table_spec.flags)
        } else if matches!(cmd.op, CmdOp::Add) {
            Some(0)
        } else {
            None
        };
        // `create` (vs plain `add`) asks the kernel to fail with EEXIST
        // when the object is already present — the tests rely on this
        // for duplicate-detection assertions.
        let mut nlm_flags = NLM_F_CREATE | NLM_F_ACK;
        if matches!(cmd.op, CmdOp::Create) { nlm_flags |= NLM_F_EXCL; }
        if self.echo { nlm_flags |= NLM_F_ECHO; }
        let comment = if cmd.has_comment { Some(cmd.comment.clone()) } else { None };
        self.send_batch(|msg| {
            let pos = msg.begin_msg(NFT_MSG_NEWTABLE, family, nlm_flags);
            msg.put_str(NFTA_TABLE_NAME, &name);
            if let Some(f) = flags { msg.put_u32_be(NFTA_TABLE_FLAGS, f); }
            // Table comment: NFTA_TABLE_USERDATA with TLV encoding.
            if let Some(ref c) = comment {
                let cb = c.as_bytes();
                let mut tlv = Vec::with_capacity(cb.len() + 3);
                tlv.push(0u8);
                tlv.push((cb.len() + 1) as u8);
                tlv.extend_from_slice(cb);
                tlv.push(0u8);
                msg.put_bytes(NFTA_TABLE_USERDATA, &tlv);
            }
            msg.end_msg(pos);
        })
    }

    fn add_chain(&mut self, cmd: &Command) -> io::Result<()> {
        let family = cmd.family;
        let table = cmd.table.clone();
        let chain = cmd.chain.clone();
        let spec = cmd.chain_spec.clone();
        let comment = if cmd.has_comment { Some(cmd.comment.clone()) } else { None };
        let mut nlm_flags = NLM_F_CREATE | NLM_F_ACK;
        if matches!(cmd.op, CmdOp::Create) { nlm_flags |= NLM_F_EXCL; }
        if self.echo { nlm_flags |= NLM_F_ECHO; }
        self.send_batch(|msg| {
            let pos = msg.begin_msg(NFT_MSG_NEWCHAIN, family, nlm_flags);
            msg.put_str(NFTA_CHAIN_TABLE, &table);
            msg.put_str(NFTA_CHAIN_NAME, &chain);

            if spec.is_base {
                msg.put_str(NFTA_CHAIN_TYPE, &spec.chain_type);

                let hook_nest = msg.begin_nested(NFTA_CHAIN_HOOK);
                // The hook number depends on the address family:
                //   arp:    0=input, 1=output, 2=forward
                //   netdev: 0=ingress, 1=egress
                //   inet:   0-4 = pre/in/fwd/out/post, 5=ingress
                //   rest:   NF_INET_* (0-4)
                let hooknum = if family == NFPROTO_ARP {
                    match spec.hook.as_str() {
                        "input" => Some(0), "output" => Some(1),
                        "forward" => Some(2), _ => None,
                    }
                } else if spec.hook == "ingress" && family == NFPROTO_INET {
                    Some(5)
                } else {
                    hook_from_str(&spec.hook)
                };
                if let Some(h) = hooknum {
                    msg.put_u32_be(NFTA_HOOK_HOOKNUM, h);
                }
                if spec.has_priority {
                    msg.put_u32_be(NFTA_HOOK_PRIORITY, spec.priority as u32);
                }
                if spec.has_device {
                    msg.put_str(NFTA_HOOK_DEV, &spec.device);
                }
                msg.end_nested(hook_nest);
            }
            if spec.has_policy {
                let policy = if spec.policy == "drop" { NF_DROP as u32 } else { NF_ACCEPT as u32 };
                msg.put_u32_be(NFTA_CHAIN_POLICY, policy);
            }
            // Chain comment stored as NFTA_CHAIN_USERDATA with the same
            // TLV encoding rules use for NFTA_RULE_USERDATA:
            //   [u8 type=0][u8 len][bytes][NUL]
            // NFTNL_UDATA_CHAIN_COMMENT = 0.
            if let Some(ref c) = comment {
                let cb = c.as_bytes();
                let mut tlv = Vec::with_capacity(cb.len() + 3);
                tlv.push(0u8);                       // type: CHAIN_COMMENT
                tlv.push((cb.len() + 1) as u8);      // length: string + NUL
                tlv.extend_from_slice(cb);
                tlv.push(0u8);                       // NUL terminator
                msg.put_bytes(NFTA_CHAIN_USERDATA, &tlv);
            }
            if spec.is_binding {
                msg.put_u32_be(NFTA_CHAIN_FLAGS, NFT_CHAIN_BINDING);
            }
            if spec.has_chain_id {
                msg.put_u32_be(NFTA_CHAIN_ID, spec.chain_id);
            }
            msg.end_msg(pos);
        })
    }

    fn add_rule(&mut self, cmd: &Command, insert: bool) -> io::Result<()> {
        let family = cmd.family;
        let table = cmd.table.clone();
        let chain = cmd.chain.clone();
        let comment = if cmd.has_comment { Some(cmd.comment.clone()) } else { None };

        let has_anon = cmd.exprs.iter().any(|e| matches!(e,
            Expr::AnonSet { .. } | Expr::AnonVmap { .. }));
        if has_anon {
            // The probe uses a fresh dump message on self.sock — it does
            // not touch self.batch, so it's safe to call even when the
            // CLI's outer atomic batch is mid-build.
            let _ = self.bump_anon_counter_past_existing(family, &table);
        }
        let (mut exprs, anon_plans) = self.lower_anon_sets(&cmd.exprs);

        // Dynset expressions that reference a set created in the same
        // batch need NFTA_DYNSET_SET_ID so the kernel can look up the
        // not-yet-committed set from the pending transaction list.
        for expr in &mut exprs {
            if let Expr::Dynset { set_name, set_id, .. } = expr {
                let key = (family, table.clone(), set_name.clone());
                if self.pending_sets.contains_key(&key) {
                    *set_id = Some(1);
                }
            }
        }

        // Resolve `index N` → handle (or position_id, for in-batch
        // refs). nft(8) documents `index` as the 0-based ordinal in
        // the chain. The Nth rule may be either committed (visible to
        // GETRULE) or queued in this batch (tracked in pending_rules);
        // committed rules win first, then in-batch ones extend the
        // ordering.
        enum AnchorRef { Committed(u64), InBatch(u32) }
        let anchor: Option<AnchorRef> = if cmd.has_rule_index && cmd.rule_index >= 0 {
            let idx = cmd.rule_index as usize;
            let t = table.clone();
            let c = chain.clone();
            let mut handles: Vec<u64> = Vec::new();
            self.dump(NFT_MSG_GETRULE, family, |msg, pos| {
                msg.put_str(NFTA_RULE_TABLE, &t);
                msg.put_str(NFTA_RULE_CHAIN, &c);
                msg.end_msg(pos);
            }, |mt, _, data| {
                if mt == NFT_MSG_NEWRULE {
                    let a = parse_attrs(data);
                    if let Some((_, v)) = a.iter().find(|(t, _)| *t == NFTA_RULE_HANDLE) {
                        handles.push(attr_u64_be(v));
                    }
                }
            })?;
            let key = (family, table.clone(), chain.clone());
            let in_batch_ids = self.pending_rules.get(&key).cloned().unwrap_or_default();
            let total = handles.len() + in_batch_ids.len();
            if idx < handles.len() {
                Some(AnchorRef::Committed(handles[idx]))
            } else if idx < total {
                Some(AnchorRef::InBatch(in_batch_ids[idx - handles.len()]))
            } else {
                return Err(io::Error::new(
                    io::ErrorKind::InvalidInput,
                    format!("index {} out of range ({} rules in chain)", idx, total),
                ));
            }
        } else if cmd.has_handle { Some(AnchorRef::Committed(cmd.handle)) } else { None };
        let mut flags = NLM_F_CREATE | NLM_F_ACK | if insert { 0 } else { NLM_F_APPEND };
        if self.echo { flags |= NLM_F_ECHO; }

        // Allocate a fresh NFTA_RULE_ID so any subsequent in-batch
        // command can reference this rule by position_id. Counter
        // resets at batch start (cleared with pending_rules above).
        self.rule_id_counter = self.rule_id_counter.wrapping_add(1);
        let rule_id = self.rule_id_counter;
        self.pending_rules
            .entry((family, table.clone(), chain.clone()))
            .or_insert_with(Vec::new)
            .push(rule_id);

        let table_ref = table.clone();
        self.send_batch(|msg| {
            Self::emit_anon_sets(msg, family, &table_ref, &anon_plans);

            let pos = msg.begin_msg(NFT_MSG_NEWRULE, family, flags);
            msg.put_str(NFTA_RULE_TABLE, &table);
            msg.put_str(NFTA_RULE_CHAIN, &chain);
            match anchor {
                Some(AnchorRef::Committed(h)) => msg.put_u64_be(NFTA_RULE_POSITION, h),
                Some(AnchorRef::InBatch(id)) => msg.put_u32_be(NFTA_RULE_POSITION_ID, id),
                None => {}
            }
            msg.put_u32_be(NFTA_RULE_ID, rule_id);
            if let Some(ref c) = comment {
                // USERDATA is a sequence of (u8 type, u8 length, bytes) TLVs.
                // NFTNL_UDATA_RULE_COMMENT == 0; the comment is stored as a
                // NUL-terminated string whose length (including the NUL) is
                // the TLV length. Raw bytes without this framing are ignored
                // by every downstream consumer (including stormwall's own
                // list formatter) and appear as an unparseable blob.
                let cb = c.as_bytes();
                let mut tlv = Vec::with_capacity(cb.len() + 3);
                tlv.push(0u8);                       // type: RULE_COMMENT
                tlv.push((cb.len() + 1) as u8);      // length: string + NUL
                tlv.extend_from_slice(cb);
                tlv.push(0u8);                       // NUL terminator
                msg.put_bytes(NFTA_RULE_USERDATA, &tlv);
            }

            // Tproxy: when the user writes `tproxy to :PORT` without a
            // family qualifier, the parser records NFPROTO_UNSPEC (0).
            // The kernel rejects UNSPEC for ip / ip6 tables — it needs
            // the concrete L3 family. Infer it from the table family.
            // For inet tables UNSPEC means "match any L3" and is kept.
            for expr in &mut exprs {
                if let Expr::Tproxy { family: f, .. } = expr {
                    if *f == NFPROTO_UNSPEC as u32 && family != NFPROTO_INET {
                        *f = family as u32;
                    }
                }
            }

            // Expressions — try AOT template first; fall back to per-Expr encoding.
            if let Some(tpl) = crate::templates::try_match(&exprs) {
                msg.put_nested_raw(NFTA_RULE_EXPRESSIONS, tpl.bytes);
            } else {
                let exprs_nest = msg.begin_nested(NFTA_RULE_EXPRESSIONS);
                for expr in &exprs {
                    compile_expr(msg, expr);
                }
                msg.end_nested(exprs_nest);
            }
            msg.end_msg(pos);
        })
    }

    // ── Delete ──────────────────────────────────────────────────

    fn exec_delete(&mut self, cmd: &Command, destroy: bool) -> io::Result<()> {
        let family = cmd.family;
        match cmd.obj {
            CmdObj::Table => {
                let name = cmd.table.clone();
                let by_handle = cmd.has_handle;
                let handle = cmd.handle;
                // For delete-by-handle: kernel's lookup-by-handle is
                // global (no family check), and upstream nft filters
                // userspace-side. Pre-check the family match so
                // `delete table inet handle $ip_handle` becomes
                // ENOENT. Always run the dump — dumps go over the
                // socket directly and don't care about the pending
                // batch buffer; they see kernel-committed state.
                // destroy always falls through here too (silent
                // success if missing).
                if by_handle {
                    let mut match_found = false;
                    self.dump(NFT_MSG_GETTABLE, family, |_, _| {}, |mt, _, data| {
                        if mt != NFT_MSG_NEWTABLE { return; }
                        let a = parse_attrs(data);
                        let h = a.iter().find(|(t, _)| *t == NFTA_TABLE_HANDLE)
                            .map(|(_, v)| attr_u64_be(v)).unwrap_or(0);
                        if h == handle { match_found = true; }
                    })?;
                    if !match_found {
                        if destroy { return Ok(()); }
                        return Err(io::Error::from_raw_os_error(libc::ENOENT));
                    }
                } else if destroy {
                    let name_s = name.clone();
                    let mut exists = false;
                    self.dump(NFT_MSG_GETTABLE, family, |_, _| {}, |mt, _, data| {
                        if mt != NFT_MSG_NEWTABLE { return; }
                        let a = parse_attrs(data);
                        let n = a.iter().find(|(t, _)| *t == NFTA_TABLE_NAME)
                            .map(|(_, v)| attr_str(v)).unwrap_or("");
                        if n == name_s { exists = true; }
                    })?;
                    if !exists { return Ok(()); }
                }
                self.send_batch(|msg| {
                    let pos = msg.begin_msg(NFT_MSG_DELTABLE, family, NLM_F_ACK);
                    if by_handle {
                        msg.put_u64_be(NFTA_TABLE_HANDLE, handle);
                    } else {
                        msg.put_str(NFTA_TABLE_NAME, &name);
                    }
                    msg.end_msg(pos);
                })
            }
            CmdObj::Chain => {
                let table = cmd.table.clone();
                let chain = cmd.chain.clone();
                let by_handle = cmd.has_handle;
                let handle = cmd.handle;
                // `destroy chain` must succeed even when the chain
                // doesn't exist. Some kernels reject
                // NFT_MSG_DESTROYCHAIN outright (observed EINVAL on
                // 6.1 arm64), so we pre-check existence via GETCHAIN
                // and either skip or fall through to DELCHAIN. DEL
                // is used as the wire opcode in both cases so the
                // batch-buffer commit still carries a valid message.
                if destroy {
                    let table_s = table.clone();
                    let chain_s = chain.clone();
                    let mut exists = false;
                    self.dump(NFT_MSG_GETCHAIN, family, |_, _| {}, |mt, _, data| {
                        if mt != NFT_MSG_NEWCHAIN { return; }
                        let a = parse_attrs(data);
                        let t = a.iter().find(|(t, _)| *t == NFTA_CHAIN_TABLE)
                            .map(|(_, v)| attr_str(v)).unwrap_or("");
                        if by_handle {
                            let h = a.iter().find(|(t, _)| *t == NFTA_CHAIN_HANDLE)
                                .map(|(_, v)| attr_u64_be(v)).unwrap_or(0);
                            if t == table_s && h == handle { exists = true; }
                        } else {
                            let c = a.iter().find(|(t, _)| *t == NFTA_CHAIN_NAME)
                                .map(|(_, v)| attr_str(v)).unwrap_or("");
                            if t == table_s && c == chain_s { exists = true; }
                        }
                    })?;
                    if !exists { return Ok(()); }
                }
                self.send_batch(|msg| {
                    let pos = msg.begin_msg(NFT_MSG_DELCHAIN, family, NLM_F_ACK);
                    msg.put_str(NFTA_CHAIN_TABLE, &table);
                    if by_handle {
                        msg.put_u64_be(NFTA_CHAIN_HANDLE, handle);
                    } else {
                        msg.put_str(NFTA_CHAIN_NAME, &chain);
                    }
                    msg.end_msg(pos);
                })
            }
            CmdObj::Rule => {
                let table = cmd.table.clone();
                let chain = cmd.chain.clone();
                let handle = cmd.handle;
                if destroy {
                    let table_s = table.clone();
                    let chain_s = chain.clone();
                    let mut exists = false;
                    self.dump(NFT_MSG_GETRULE, family, |msg, pos| {
                        msg.put_str(NFTA_RULE_TABLE, &table_s);
                        msg.put_str(NFTA_RULE_CHAIN, &chain_s);
                        msg.end_msg(pos);
                    }, |mt, _, data| {
                        if mt != NFT_MSG_NEWRULE { return; }
                        let a = parse_attrs(data);
                        let h = a.iter().find(|(t, _)| *t == NFTA_RULE_HANDLE)
                            .map(|(_, v)| attr_u64_be(v)).unwrap_or(0);
                        if h == handle { exists = true; }
                    })?;
                    if !exists { return Ok(()); }
                }
                self.send_batch(|msg| {
                    let pos = msg.begin_msg(NFT_MSG_DELRULE, family, NLM_F_ACK);
                    msg.put_str(NFTA_RULE_TABLE, &table);
                    msg.put_str(NFTA_RULE_CHAIN, &chain);
                    msg.put_u64_be(NFTA_RULE_HANDLE, handle);
                    msg.end_msg(pos);
                })
            }
            CmdObj::Set | CmdObj::Map => {
                let table = cmd.table.clone();
                let set_name = cmd.set_name.clone();
                let by_handle = cmd.has_handle;
                let handle = cmd.handle;
                if destroy && !by_handle {
                    let tn = table.clone(); let sn = set_name.clone();
                    let mut exists = false;
                    self.dump(NFT_MSG_GETSET, family, |_, _| {}, |mt, _, data| {
                        if mt != NFT_MSG_NEWSET { return; }
                        let a = parse_attrs(data);
                        let t = a.iter().find(|(t, _)| *t == NFTA_SET_TABLE)
                            .map(|(_, v)| attr_str(v)).unwrap_or("");
                        let n = a.iter().find(|(t, _)| *t == NFTA_SET_NAME)
                            .map(|(_, v)| attr_str(v)).unwrap_or("");
                        if t == tn && n == sn { exists = true; }
                    })?;
                    if !exists { return Ok(()); }
                }
                self.send_batch(|msg| {
                    let pos = msg.begin_msg(NFT_MSG_DELSET, family, NLM_F_ACK);
                    msg.put_str(NFTA_SET_TABLE, &table);
                    if by_handle {
                        msg.put_u64_be(NFTA_SET_HANDLE, handle);
                    } else {
                        msg.put_str(NFTA_SET_NAME, &set_name);
                    }
                    msg.end_msg(pos);
                })
            }
            CmdObj::Element => self.delete_elements(cmd),
            CmdObj::Flowtable => {
                let table = cmd.table.clone();
                let name = cmd.set_name.clone();
                let by_handle = cmd.has_handle;
                let handle = cmd.handle;
                self.send_batch(|msg| {
                    let pos = msg.begin_msg(NFT_MSG_DELFLOWTABLE, family, NLM_F_ACK);
                    msg.put_str(NFTA_FLOWTABLE_TABLE, &table);
                    if by_handle {
                        msg.put_u64_be(NFTA_FLOWTABLE_HANDLE, handle);
                    } else {
                        msg.put_str(NFTA_FLOWTABLE_NAME, &name);
                    }
                    msg.end_msg(pos);
                })
            }
            CmdObj::Counter | CmdObj::Quota | CmdObj::Limit
            | CmdObj::CtHelper | CmdObj::CtTimeout | CmdObj::CtExpect
            | CmdObj::Synproxy | CmdObj::Secmark | CmdObj::Tunnel => {
                // obj_spec.kind may be 0 if the caller said just
                // `delete counter t foo` without a type block; fill it
                // in from the CmdObj so the kernel can disambiguate.
                let mut cmd = cmd.clone();
                if cmd.obj_spec.kind == 0 {
                    cmd.obj_spec.kind = match cmd.obj {
                        CmdObj::Counter   => NFT_OBJECT_COUNTER,
                        CmdObj::Quota     => NFT_OBJECT_QUOTA,
                        CmdObj::Limit     => NFT_OBJECT_LIMIT,
                        CmdObj::CtHelper  => NFT_OBJECT_CT_HELPER,
                        CmdObj::CtTimeout => NFT_OBJECT_CT_TIMEOUT,
                        CmdObj::CtExpect  => NFT_OBJECT_CT_EXPECT,
                        CmdObj::Synproxy  => NFT_OBJECT_SYNPROXY,
                        CmdObj::Secmark   => NFT_OBJECT_SECMARK,
                        CmdObj::Tunnel    => NFT_OBJECT_TUNNEL,
                        _ => 0,
                    };
                }
                self.delete_object(&cmd)
            }
            _ => Err(io::Error::new(io::ErrorKind::Other, "unsupported delete target")),
        }
    }

    // ── List ────────────────────────────────────────────────────

    fn exec_list(&mut self, cmd: &Command) -> io::Result<()> {
        if self.json { return self.exec_list_json(cmd); }
        match cmd.obj {
            CmdObj::Ruleset => self.list_ruleset(cmd.family),
            CmdObj::Tables => self.list_tables(cmd.family),
            CmdObj::Table => self.list_table(cmd.family, &cmd.table),
            CmdObj::Chain => {
                println!("table {} {} {{", family_str(cmd.family), cmd.table);
                self.list_chain_with_rules(cmd.family, &cmd.table, &cmd.chain)?;
                println!("}}");
                Ok(())
            }
            CmdObj::Chains => self.list_chains(cmd.family),
            CmdObj::Rules => {
                if !cmd.table.is_empty() {
                    // list rules [family] table [chain]
                    self.list_table(cmd.family, &cmd.table)
                } else {
                    self.list_ruleset(cmd.family)
                }
            }
            CmdObj::Sets => self.list_sets(cmd.family),
            CmdObj::Maps => self.list_sets(cmd.family),
            CmdObj::Set | CmdObj::Map => {
                self.list_named_set(cmd.family, &cmd.table, &cmd.set_name)
            }
            CmdObj::Counter | CmdObj::Quota | CmdObj::Limit
            | CmdObj::CtHelper | CmdObj::CtTimeout | CmdObj::CtExpect
            | CmdObj::Synproxy | CmdObj::Secmark | CmdObj::Tunnel => {
                self.list_named_object(cmd.family, &cmd.table, &cmd.set_name)
            }
            CmdObj::Counters | CmdObj::Quotas | CmdObj::Limits => {
                let kind = match cmd.obj {
                    CmdObj::Counters => NFT_OBJECT_COUNTER,
                    CmdObj::Quotas   => NFT_OBJECT_QUOTA,
                    CmdObj::Limits   => NFT_OBJECT_LIMIT,
                    _ => 0,
                };
                self.list_objects(cmd.family, kind)
            }
            CmdObj::Objects => self.list_objects(cmd.family, 0),
            CmdObj::Flowtable => {
                self.list_named_flowtable(cmd.family, &cmd.table, &cmd.set_name)
            }
            CmdObj::Flowtables => {
                self.list_flowtables(cmd.family, &cmd.table)
            }
            _ => Err(io::Error::new(io::ErrorKind::Other, "unsupported list target")),
        }
    }

    fn list_named_set(&mut self, family: u8, table: &str, name: &str) -> io::Result<()> {
        let mut found: Vec<(u8, Vec<(u16, Vec<u8>)>)> = Vec::new();
        let tf = table.to_string();
        let nf = name.to_string();
        self.dump(NFT_MSG_GETSET, family, |_, _| {}, |mt, fam, data| {
            if mt == NFT_MSG_NEWSET {
                let attrs = parse_attrs(data);
                let t = attrs.iter().find(|(t, _)| *t == NFTA_SET_TABLE)
                    .map(|(_, v)| attr_str(v)).unwrap_or("");
                let n = attrs.iter().find(|(t, _)| *t == NFTA_SET_NAME)
                    .map(|(_, v)| attr_str(v)).unwrap_or("");
                let flags = attrs.iter().find(|(t, _)| *t == NFTA_SET_FLAGS)
                    .map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
                // Anonymous sets aren't user-addressable — `nft list
                // set t __set0` exits non-zero upstream even though
                // the object is visible to GETSET.
                if t == tf && n == nf && (flags & 0x1) == 0 {
                    found.push((fam, attrs.into_iter().map(|(t,v)| (t,v.to_vec())).collect()));
                }
            }
        })?;
        if found.is_empty() {
            return Err(io::Error::new(io::ErrorKind::NotFound, format!("no such set {}/{}", table, name)));
        }
        println!("table {} {} {{", family_str(family), table);
        for (fam, attrs) in &found {
            // Dump the set's elements so the body shows `elements =
            // {...}` in text output (terse mode still suppresses via
            // self.terse). print_set_with_elements handles both
            // plain and interval sets with the right framing.
            let sn = attrs.iter().find(|(t, _)| *t == NFTA_SET_NAME)
                .map(|(_, v)| attr_str(v).to_string()).unwrap_or_default();
            let tbl = table.to_string();
            let mut elems: Vec<Vec<(u16, Vec<u8>)>> = Vec::new();
            self.dump(NFT_MSG_GETSETELEM, *fam, |msg, pos| {
                msg.put_str(NFTA_SET_ELEM_LIST_TABLE, &tbl);
                msg.put_str(NFTA_SET_ELEM_LIST_SET, &sn);
                msg.end_msg(pos);
            }, |mt, _, data| {
                if mt == NFT_MSG_NEWSETELEM {
                    let a = parse_attrs(data);
                    if let Some((_, list)) = a.iter().find(|(t, _)| *t == NFTA_SET_ELEM_LIST_ELEMENTS) {
                        for (_, e) in parse_attrs(list) {
                            elems.push(parse_attrs(e).into_iter().map(|(t,v)| (t,v.to_vec())).collect());
                        }
                    }
                }
            })?;
            output::print_set_with_elements(*fam, attrs, &elems, self.terse);
        }
        println!("}}");
        Ok(())
    }

    /// `nft reset {counter|quota|...}` — uses NFT_MSG_GETOBJ_RESET so
    /// the kernel atomically returns the pre-reset snapshot AND zeros
    /// the object's stateful counters/consumed value. For non-object
    /// targets we fall through to plain list (rule reset isn't wired
    /// up yet).
    fn exec_reset(&mut self, cmd: &Command) -> io::Result<()> {
        match cmd.obj {
            CmdObj::Counter | CmdObj::Quota | CmdObj::Limit
            | CmdObj::CtHelper | CmdObj::CtTimeout | CmdObj::CtExpect
            | CmdObj::Synproxy | CmdObj::Secmark | CmdObj::Tunnel => {
                self.reset_named_object(cmd.family, &cmd.table, &cmd.set_name)
            }
            CmdObj::Counters | CmdObj::Quotas | CmdObj::Limits => {
                let kind = match cmd.obj {
                    CmdObj::Counters => NFT_OBJECT_COUNTER,
                    CmdObj::Quotas   => NFT_OBJECT_QUOTA,
                    CmdObj::Limits   => NFT_OBJECT_LIMIT,
                    _ => 0,
                };
                self.reset_objects(cmd.family, kind)
            }
            CmdObj::Rule => {
                self.reset_single_rule(cmd.family, &cmd.table, &cmd.chain, cmd.handle)
            }
            CmdObj::Rules => {
                self.reset_rules_scope(cmd.family, &cmd.table, &cmd.chain)
            }
            _ => self.exec_list(cmd),
        }
    }

    fn reset_named_object(&mut self, family: u8, table: &str, name: &str) -> io::Result<()> {
        let mut found: Vec<Vec<(u16, Vec<u8>)>> = Vec::new();
        let tf = table.to_string();
        let nf = name.to_string();
        self.dump(NFT_MSG_GETOBJ_RESET, family, |_, _| {}, |mt, _, data| {
            if mt == NFT_MSG_NEWOBJ {
                let attrs = parse_attrs(data);
                let t = attrs.iter().find(|(t, _)| *t == NFTA_OBJ_TABLE)
                    .map(|(_, v)| attr_str(v)).unwrap_or("");
                let n = attrs.iter().find(|(t, _)| *t == NFTA_OBJ_NAME)
                    .map(|(_, v)| attr_str(v)).unwrap_or("");
                if t == tf && n == nf { found.push(attrs.into_iter().map(|(t,v)| (t,v.to_vec())).collect()); }
            }
        })?;
        if found.is_empty() {
            return Err(io::Error::new(io::ErrorKind::NotFound,
                format!("no such object {}/{}", table, name)));
        }
        let sh = self.show_handles;
        println!("table {} {} {{", family_str(family), table);
        for attrs in &found {
            output::print_object_with_handle(attrs, sh);
        }
        println!("}}");
        Ok(())
    }

    fn reset_objects(&mut self, family: u8, kind: u32) -> io::Result<()> {
        let mut by_table: Vec<(u8, String, Vec<Vec<(u16, Vec<u8>)>>)> = Vec::new();
        let mut tables: Vec<(u8, String)> = Vec::new();
        self.dump(NFT_MSG_GETTABLE, family, |_, _| {}, |mt, fam, data| {
            if mt == NFT_MSG_NEWTABLE {
                let a = parse_attrs(data);
                let n = a.iter().find(|(t, _)| *t == NFTA_TABLE_NAME)
                    .map(|(_, v)| attr_str(v).to_string()).unwrap_or_default();
                tables.push((fam, n));
            }
        })?;
        for (fam, tname) in &tables {
            by_table.push((*fam, tname.clone(), Vec::new()));
        }
        self.dump(NFT_MSG_GETOBJ_RESET, family, |_, _| {}, |mt, _, data| {
            if mt == NFT_MSG_NEWOBJ {
                let attrs = parse_attrs(data);
                let t = attrs.iter().find(|(t, _)| *t == NFTA_OBJ_TABLE)
                    .map(|(_, v)| attr_str(v)).unwrap_or("");
                let k = attrs.iter().find(|(t, _)| *t == NFTA_OBJ_TYPE)
                    .map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
                if kind != 0 && k != kind { return; }
                if let Some(slot) = by_table.iter_mut().find(|(_, n, _)| n == &t) {
                    slot.2.push(attrs.into_iter().map(|(t,v)| (t,v.to_vec())).collect());
                }
            }
        })?;
        let sh = self.show_handles;
        for (fam, tname, objs) in &by_table {
            if objs.is_empty() { continue; }
            println!("table {} {} {{", family_str(*fam), tname);
            for a in objs {
                output::print_object_with_handle(a, sh);
            }
            println!("}}");
        }
        Ok(())
    }

    // ── Rule Reset ────────────────────────────────────────────────

    /// `nft reset rule TABLE CHAIN handle N` — issue NFT_MSG_GETRULE_RESET
    /// with table+chain+handle so the kernel resets only the targeted rule
    /// and returns its pre-reset snapshot. Print it inside a compact
    /// `table F T { chain C { ... } }` wrapper.
    fn reset_single_rule(&mut self, family: u8, table: &str, chain: &str, handle: u64) -> io::Result<()> {
        let tbl = table.to_string();
        let chn = chain.to_string();
        let mut found: Vec<Vec<(u16, Vec<u8>)>> = Vec::new();
        self.dump(NFT_MSG_GETRULE_RESET, family, |msg, pos| {
            msg.put_str(NFTA_RULE_TABLE, &tbl);
            msg.put_str(NFTA_RULE_CHAIN, &chn);
            msg.put_u64_be(NFTA_RULE_HANDLE, handle);
            msg.end_msg(pos);
        }, |mt, _, data| {
            if mt == NFT_MSG_NEWRULE { found.push(parse_attrs(data).into_iter().map(|(t,v)| (t,v.to_vec())).collect()); }
        })?;

        // Find the chain attrs so the header shows type/hook/priority.
        let mut chain_attrs: Option<(u8, Vec<(u16, Vec<u8>)>)> = None;
        let tbl2 = table.to_string();
        let chn2 = chain.to_string();
        self.dump(NFT_MSG_GETCHAIN, family, |_, _| {}, |mt, fam, data| {
            if mt == NFT_MSG_NEWCHAIN {
                let a = parse_attrs(data);
                let t = a.iter().find(|(t, _)| *t == NFTA_CHAIN_TABLE)
                    .map(|(_, v)| attr_str(v)).unwrap_or("");
                let c = a.iter().find(|(t, _)| *t == NFTA_CHAIN_NAME)
                    .map(|(_, v)| attr_str(v)).unwrap_or("");
                if t == tbl2 && c == chn2 { chain_attrs = Some((fam, a.into_iter().map(|(t,v)| (t,v.to_vec())).collect())); }
            }
        })?;

        let (efam, cattrs) = chain_attrs.unwrap_or_else(|| (family, Vec::new()));
        let anon_reg = self.collect_anon_sets(family, table)?;
        let sh = self.show_handles;
        let sl = self.stateless;
        println!("table {} {} {{", family_str(efam), table);
        output::print_chain_header(efam, &cattrs, sh);
        for attrs in &found {
            output::print_rule_with_sets(attrs, sh, sl, &anon_reg);
        }
        output::print_chain_footer();
        println!("}}");
        Ok(())
    }

    /// `nft reset rules [chain T C | table T | FAMILY | (all)]` — issue
    /// NFT_MSG_GETRULE_RESET at the appropriate scope, then render the
    /// result in nft list format (pre-reset counter values, full table
    /// structure for table/family/all scopes).
    fn reset_rules_scope(&mut self, family: u8, table: &str, chain: &str) -> io::Result<()> {
        if !table.is_empty() && !chain.is_empty() {
            // Chain scope: single chain within one table.
            self.reset_rules_chain(family, table, chain)
        } else if !table.is_empty() {
            // Table scope: all chains in one table.
            self.reset_rules_table(family, table)
        } else {
            // Family or all scope.
            self.reset_rules_family(family)
        }
    }

    /// Chain scope: `reset rules chain TABLE CHAIN`
    fn reset_rules_chain(&mut self, family: u8, table: &str, chain: &str) -> io::Result<()> {
        // Get chain attrs (for the header line).
        let tbl_f = table.to_string();
        let chn_f = chain.to_string();
        let mut chain_attrs: Option<(u8, Vec<(u16, Vec<u8>)>)> = None;
        self.dump(NFT_MSG_GETCHAIN, family, |_, _| {}, |mt, fam, data| {
            if mt == NFT_MSG_NEWCHAIN {
                let a = parse_attrs(data);
                let t = a.iter().find(|(t, _)| *t == NFTA_CHAIN_TABLE)
                    .map(|(_, v)| attr_str(v)).unwrap_or("");
                let c = a.iter().find(|(t, _)| *t == NFTA_CHAIN_NAME)
                    .map(|(_, v)| attr_str(v)).unwrap_or("");
                if t == tbl_f && c == chn_f { chain_attrs = Some((fam, a.into_iter().map(|(t,v)| (t,v.to_vec())).collect())); }
            }
        })?;

        // The kernel's GETRULE_RESET rejects NFPROTO_UNSPEC, so use the
        // actual family the GETCHAIN dump found this chain in. Fall back
        // to the input parameter only if the chain wasn't found (the
        // user will see an empty result then).
        let (efam, cattrs) = chain_attrs.unwrap_or_else(|| (family, Vec::new()));

        // Collect pre-reset rules for this chain.
        let tbl2 = table.to_string();
        let chn2 = chain.to_string();
        let mut rules: Vec<Vec<(u16, Vec<u8>)>> = Vec::new();
        self.dump(NFT_MSG_GETRULE_RESET, efam, |msg, pos| {
            msg.put_str(NFTA_RULE_TABLE, &tbl2);
            msg.put_str(NFTA_RULE_CHAIN, &chn2);
            msg.end_msg(pos);
        }, |mt, _, data| {
            if mt == NFT_MSG_NEWRULE { rules.push(parse_attrs(data).into_iter().map(|(t,v)| (t,v.to_vec())).collect()); }
        })?;
        let anon_reg = self.collect_anon_sets(family, table)?;
        let sh = self.show_handles;
        let sl = self.stateless;
        println!("table {} {} {{", family_str(efam), table);
        output::print_chain_header(efam, &cattrs, sh);
        for attrs in &rules {
            output::print_rule_with_sets(attrs, sh, sl, &anon_reg);
        }
        output::print_chain_footer();
        println!("}}");
        Ok(())
    }

    /// Table scope: `reset rules table TABLE` — renders the full table
    /// (sets, objects, flowtables, chains) but rule counters come from
    /// NFT_MSG_GETRULE_RESET (pre-reset snapshot).
    fn reset_rules_table(&mut self, family: u8, table: &str) -> io::Result<()> {
        let table_name = table.to_string();

        // Pipeline GETTABLE + GETCHAIN + GETSET + GETOBJ + GETFLOWTABLE
        // + GETRULE_RESET in one multi_dump pass.
        let t1 = table_name.clone();
        let reqs: Vec<(u16, u8, Box<dyn FnOnce(&mut MsgBuilder, usize)>)> = vec![
            (NFT_MSG_GETTABLE,       family, Box::new(|_, _| {})),
            (NFT_MSG_GETCHAIN,       family, Box::new(|_, _| {})),
            (NFT_MSG_GETSET,         family, Box::new(|_, _| {})),
            (NFT_MSG_GETOBJ,         family, Box::new(|_, _| {})),
            (NFT_MSG_GETFLOWTABLE,   family, Box::new(|_, _| {})),
            (NFT_MSG_GETRULE_RESET,  family, Box::new(move |msg, pos| {
                msg.put_str(NFTA_RULE_TABLE, &t1);
                msg.end_msg(pos);
            })),
        ];
        let mut batched = self.multi_dump(reqs)?;

        // Slot 0: table flags/comment
        let mut table_flags: u32 = 0;
        let mut table_comment: Option<String> = None;
        for (mt, _fam, data) in batched[0].drain(..) {
            if mt == NFT_MSG_NEWTABLE {
                let a = parse_attrs(&data);
                let n = a.iter().find(|(t, _)| *t == NFTA_TABLE_NAME)
                    .map(|(_, v)| attr_str(v)).unwrap_or("");
                if n == table_name {
                    if let Some((_, v)) = a.iter().find(|(t, _)| *t == NFTA_TABLE_FLAGS) {
                        table_flags = attr_u32_be(v);
                    }
                    if let Some((_, ud)) = a.iter().find(|(t, _)| *t == NFTA_TABLE_USERDATA) {
                        let mut ci = 0usize;
                        while ci + 2 <= ud.len() {
                            let ty = ud[ci]; let ln = ud[ci + 1] as usize; ci += 2;
                            if ci + ln > ud.len() { break; }
                            if ty == 0 {
                                let trimmed: Vec<u8> = ud[ci..ci + ln].iter().take_while(|&&b| b != 0).copied().collect();
                                if let Ok(txt) = std::str::from_utf8(&trimmed) {
                                    if !txt.is_empty() { table_comment = Some(txt.to_string()); }
                                }
                                break;
                            }
                            ci += ln;
                        }
                    }
                }
            }
        }

        // Slot 1: chains
        let mut chains: Vec<(u8, Vec<(u16, Vec<u8>)>)> = Vec::new();
        let mut bound_chain_names: std::collections::HashSet<String> =
            std::collections::HashSet::new();
        for (mt, fam, data) in batched[1].drain(..) {
            if mt == NFT_MSG_NEWCHAIN {
                let attrs = parse_attrs(&data);
                let t = attrs.iter().find(|(t, _)| *t == NFTA_CHAIN_TABLE)
                    .map(|(_, v)| attr_str(v)).unwrap_or("");
                if t != table_name { continue; }
                let cflags = attrs.iter().find(|(t, _)| *t == NFTA_CHAIN_FLAGS)
                    .map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
                if cflags & NFT_CHAIN_BINDING != 0 {
                    if let Some((_, n)) = attrs.iter().find(|(t, _)| *t == NFTA_CHAIN_NAME) {
                        bound_chain_names.insert(attr_str(n).to_string());
                    }
                    continue;
                }
                chains.push((fam, attrs.into_iter().map(|(t,v)| (t,v.to_vec())).collect()));
            }
        }

        // Slot 2: named sets (no anon sets — they're handled separately)
        let mut sets: Vec<(u8, Vec<(u16, Vec<u8>)>)> = Vec::new();
        for (mt, fam, data) in batched[2].drain(..) {
            if mt == NFT_MSG_NEWSET {
                let attrs = parse_attrs(&data);
                let t = attrs.iter().find(|(t, _)| *t == NFTA_SET_TABLE)
                    .map(|(_, v)| attr_str(v)).unwrap_or("");
                let flags = attrs.iter().find(|(t, _)| *t == NFTA_SET_FLAGS)
                    .map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
                if t == table_name && (flags & 0x1) == 0 {
                    sets.push((fam, attrs.into_iter().map(|(t,v)| (t,v.to_vec())).collect()));
                }
            }
        }

        // Slot 3: named objects
        let mut objs: Vec<Vec<(u16, Vec<u8>)>> = Vec::new();
        for (mt, _fam, data) in batched[3].drain(..) {
            if mt == NFT_MSG_NEWOBJ {
                let attrs = parse_attrs(&data);
                let t = attrs.iter().find(|(t, _)| *t == NFTA_OBJ_TABLE)
                    .map(|(_, v)| attr_str(v)).unwrap_or("");
                if t == table_name { objs.push(attrs.into_iter().map(|(t,v)| (t,v.to_vec())).collect()); }
            }
        }

        // Slot 4: flowtables
        let mut flowtables: Vec<(u8, Vec<(u16, Vec<u8>)>)> = Vec::new();
        for (mt, ffam, data) in batched[4].drain(..) {
            if mt == NFT_MSG_NEWFLOWTABLE {
                let attrs = parse_attrs(&data);
                let t = attrs.iter().find(|(t, _)| *t == NFTA_FLOWTABLE_TABLE)
                    .map(|(_, v)| attr_str(v)).unwrap_or("");
                if t == table_name { flowtables.push((ffam, attrs.into_iter().map(|(t,v)| (t,v.to_vec())).collect())); }
            }
        }

        // Slot 5: pre-reset rules grouped by chain
        let mut rules_by_chain: std::collections::HashMap<String, Vec<Vec<(u16, Vec<u8>)>>> =
            std::collections::HashMap::new();
        for (mt, _fam, data) in batched[5].drain(..) {
            if mt == NFT_MSG_NEWRULE {
                let attrs = parse_attrs(&data);
                let cname = attrs.iter().find(|(t, _)| *t == NFTA_RULE_CHAIN)
                    .map(|(_, v)| attr_str(v).to_string()).unwrap_or_default();
                rules_by_chain.entry(cname).or_default().push(attrs.into_iter().map(|(t,v)| (t,v.to_vec())).collect());
            }
        }

        // Anon set registry for inline `@__setN` expansion.
        let mut anon_reg = self.collect_anon_sets(family, table)?;
        for bname in &bound_chain_names {
            if let Some(brules) = rules_by_chain.remove(bname) {
                anon_reg.bound_chains.insert(bname.clone(), brules);
            }
        }

        // Render.
        println!("table {} {} {{", family_str(family), table);
        let sh = self.show_handles;
        let sl = self.stateless;
        let mut emitted_anything = false;
        if let Some(ref c) = table_comment { println!("\tcomment \"{}\"", c); emitted_anything = true; }
        if table_flags & NFT_TABLE_F_DORMANT != 0 { println!("\tflags dormant"); emitted_anything = true; }
        if emitted_anything && (!objs.is_empty() || !sets.is_empty() || !flowtables.is_empty() || !chains.is_empty()) { println!(); }

        for (i, attrs) in objs.iter().enumerate() {
            if i > 0 { println!(); }
            output::print_object_with_handle(attrs, sh);
        }
        if !objs.is_empty() && (!sets.is_empty() || !flowtables.is_empty() || !chains.is_empty()) { println!(); }

        for (i, (fam, attrs)) in sets.iter().enumerate() {
            if i > 0 { println!(); }
            let set_name = attrs.iter().find(|(t, _)| *t == NFTA_SET_NAME)
                .map(|(_, v)| attr_str(v).to_string()).unwrap_or_default();
            let tbl = table.to_string();
            let sn  = set_name.clone();
            let mut elems: Vec<Vec<(u16, Vec<u8>)>> = Vec::new();
            self.dump(NFT_MSG_GETSETELEM, *fam, |msg, pos| {
                msg.put_str(NFTA_SET_ELEM_LIST_TABLE, &tbl);
                msg.put_str(NFTA_SET_ELEM_LIST_SET,   &sn);
                msg.end_msg(pos);
            }, |mt, _, data| {
                if mt == NFT_MSG_NEWSETELEM {
                    let a = parse_attrs(data);
                    if let Some((_, list)) = a.iter().find(|(t, _)| *t == NFTA_SET_ELEM_LIST_ELEMENTS) {
                        for (_, e) in parse_attrs(list) { elems.push(parse_attrs(e).into_iter().map(|(t,v)| (t,v.to_vec())).collect()); }
                    }
                }
            })?;
            let flags = attrs.iter().find(|(t, _)| *t == NFTA_SET_FLAGS)
                .map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
            if flags & NFT_SET_INTERVAL == 0 {
                elems.sort_by(|a, b| {
                    let ka = a.iter().find(|(t, _)| *t == NFTA_SET_ELEM_KEY)
                        .and_then(|(_, v)| parse_attrs(v).into_iter()
                            .find(|(t, _)| *t == NFTA_DATA_VALUE).map(|(_, d)| d.to_vec()))
                        .unwrap_or_default();
                    let kb = b.iter().find(|(t, _)| *t == NFTA_SET_ELEM_KEY)
                        .and_then(|(_, v)| parse_attrs(v).into_iter()
                            .find(|(t, _)| *t == NFTA_DATA_VALUE).map(|(_, d)| d.to_vec()))
                        .unwrap_or_default();
                    ka.cmp(&kb)
                });
            }
            output::print_set_with_elements(*fam, attrs, &elems, self.terse);
        }
        if !sets.is_empty() && (!flowtables.is_empty() || !chains.is_empty()) { println!(); }

        for (i, (ffam, fattrs)) in flowtables.iter().enumerate() {
            if i > 0 { println!(); }
            output::print_flowtable_h(*ffam, fattrs, sh);
        }
        if !flowtables.is_empty() && !chains.is_empty() { println!(); }

        let reg_ref = &anon_reg;
        for (i, (fam, chain_attrs)) in chains.iter().enumerate() {
            if i > 0 { println!(); }
            output::print_chain_header(*fam, chain_attrs, sh);
            let cname = chain_attrs.iter().find(|(t, _)| *t == NFTA_CHAIN_NAME)
                .map(|(_, v)| attr_str(v)).unwrap_or("");
            if let Some(rules) = rules_by_chain.get(cname) {
                for attrs in rules {
                    output::print_rule_with_sets(attrs, sh, sl, reg_ref);
                }
            }
            output::print_chain_footer();
        }

        println!("}}");
        Ok(())
    }

    /// Family/all scope: `reset rules [FAMILY]` — same as list_ruleset but
    /// rules come from NFT_MSG_GETRULE_RESET (pre-reset snapshot). Only
    /// tables that have any rules in the GETRULE_RESET response are
    /// rendered (but the full table structure — sets, objects, chains — is
    /// always shown for those tables). Tables with no rules are also shown
    /// to match upstream behaviour (their chains simply have no rules listed).
    fn reset_rules_family(&mut self, family: u8) -> io::Result<()> {
        // Enumerate tables.
        let mut tables: Vec<(u8, String, u32, Option<String>)> = Vec::new();
        self.dump(NFT_MSG_GETTABLE, family, |_, _| {}, |mt, fam, data| {
            if mt == NFT_MSG_NEWTABLE {
                let a = parse_attrs(data);
                let name = a.iter().find(|(t, _)| *t == NFTA_TABLE_NAME)
                    .map(|(_, v)| attr_str(v).to_string()).unwrap_or_default();
                let flags = a.iter().find(|(t, _)| *t == NFTA_TABLE_FLAGS)
                    .map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
                let comment = a.iter().find(|(t, _)| *t == NFTA_TABLE_USERDATA)
                    .and_then(|(_, ud)| {
                        let mut ci = 0usize;
                        while ci + 2 <= ud.len() {
                            let ty = ud[ci]; let ln = ud[ci + 1] as usize; ci += 2;
                            if ci + ln > ud.len() { break; }
                            if ty == 0 {
                                let trimmed: Vec<u8> = ud[ci..ci + ln].iter().take_while(|&&b| b != 0).copied().collect();
                                return std::str::from_utf8(&trimmed).ok()
                                    .filter(|t| !t.is_empty()).map(String::from);
                            }
                            ci += ln;
                        }
                        None
                    });
                tables.push((fam, name, flags, comment));
            }
        })?;
        if tables.is_empty() { return Ok(()); }

        // GETRULE_RESET requires NFTA_RULE_TABLE — an unfiltered dump
        // returns EINVAL — so issue one request per table and merge.
        let mut reset_rules: std::collections::HashMap<(u8, String, String), Vec<Vec<(u16, Vec<u8>)>>> =
            std::collections::HashMap::new();
        for (fam, tname, _, _) in &tables {
            let tn = tname.clone();
            self.dump(NFT_MSG_GETRULE_RESET, *fam, |msg, pos| {
                msg.put_str(NFTA_RULE_TABLE, &tn);
                msg.end_msg(pos);
            }, |mt, rfam, data| {
                if mt == NFT_MSG_NEWRULE {
                    let attrs = parse_attrs(data);
                    let tbl = attrs.iter().find(|(t, _)| *t == NFTA_RULE_TABLE)
                        .map(|(_, v)| attr_str(v).to_string()).unwrap_or_default();
                    let chn = attrs.iter().find(|(t, _)| *t == NFTA_RULE_CHAIN)
                        .map(|(_, v)| attr_str(v).to_string()).unwrap_or_default();
                    reset_rules.entry((rfam, tbl, chn)).or_default().push(attrs.into_iter().map(|(t,v)| (t,v.to_vec())).collect());
                }
            })?;
        }

        // For each table, pipeline GETCHAIN + GETSET + GETOBJ + GETFLOWTABLE.
        let n_tables = tables.len();
        let mut reqs: Vec<(u16, u8, Box<dyn FnOnce(&mut MsgBuilder, usize)>)> =
            Vec::with_capacity(4 * n_tables);
        for (fam, _, _, _) in &tables {
            let fam = *fam;
            reqs.push((NFT_MSG_GETCHAIN,     fam, Box::new(|_, _| {})));
            reqs.push((NFT_MSG_GETSET,       fam, Box::new(|_, _| {})));
            reqs.push((NFT_MSG_GETOBJ,       fam, Box::new(|_, _| {})));
            reqs.push((NFT_MSG_GETFLOWTABLE, fam, Box::new(|_, _| {})));
        }
        let mut batched = self.multi_dump(reqs)?;
        // Slots per table: [4i]=GETCHAIN, [4i+1]=GETSET, [4i+2]=GETOBJ, [4i+3]=GETFLOWTABLE

        let sh = self.show_handles;
        let sl = self.stateless;

        for (i, (fam, table_name, table_flags, table_comment)) in tables.iter().enumerate() {
            let fam = *fam;
            let base = i * 4;

            // Chains
            let mut chains: Vec<(u8, Vec<(u16, Vec<u8>)>)> = Vec::new();
            let mut bound_chain_names: std::collections::HashSet<String> =
                std::collections::HashSet::new();
            for (mt, cfam, data) in batched[base].drain(..) {
                if mt == NFT_MSG_NEWCHAIN {
                    let attrs = parse_attrs(&data);
                    let t = attrs.iter().find(|(t, _)| *t == NFTA_CHAIN_TABLE)
                        .map(|(_, v)| attr_str(v)).unwrap_or("");
                    if &t != table_name { continue; }
                    let cflags = attrs.iter().find(|(t, _)| *t == NFTA_CHAIN_FLAGS)
                        .map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
                    if cflags & NFT_CHAIN_BINDING != 0 {
                        if let Some((_, n)) = attrs.iter().find(|(t, _)| *t == NFTA_CHAIN_NAME) {
                            bound_chain_names.insert(attr_str(n).to_string());
                        }
                        continue;
                    }
                    chains.push((cfam, attrs.into_iter().map(|(t,v)| (t,v.to_vec())).collect()));
                }
            }

            // Named sets
            let mut sets: Vec<(u8, Vec<(u16, Vec<u8>)>)> = Vec::new();
            for (mt, sfam, data) in batched[base + 1].drain(..) {
                if mt == NFT_MSG_NEWSET {
                    let attrs = parse_attrs(&data);
                    let t = attrs.iter().find(|(t, _)| *t == NFTA_SET_TABLE)
                        .map(|(_, v)| attr_str(v)).unwrap_or("");
                    let flags = attrs.iter().find(|(t, _)| *t == NFTA_SET_FLAGS)
                        .map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
                    if &t == table_name && (flags & 0x1) == 0 {
                        sets.push((sfam, attrs.into_iter().map(|(t,v)| (t,v.to_vec())).collect()));
                    }
                }
            }

            // Objects
            let mut objs: Vec<Vec<(u16, Vec<u8>)>> = Vec::new();
            for (mt, _ofam, data) in batched[base + 2].drain(..) {
                if mt == NFT_MSG_NEWOBJ {
                    let attrs = parse_attrs(&data);
                    let t = attrs.iter().find(|(t, _)| *t == NFTA_OBJ_TABLE)
                        .map(|(_, v)| attr_str(v)).unwrap_or("");
                    if &t == table_name { objs.push(attrs.into_iter().map(|(t,v)| (t,v.to_vec())).collect()); }
                }
            }

            // Flowtables
            let mut flowtables: Vec<(u8, Vec<(u16, Vec<u8>)>)> = Vec::new();
            for (mt, ffam, data) in batched[base + 3].drain(..) {
                if mt == NFT_MSG_NEWFLOWTABLE {
                    let attrs = parse_attrs(&data);
                    let t = attrs.iter().find(|(t, _)| *t == NFTA_FLOWTABLE_TABLE)
                        .map(|(_, v)| attr_str(v)).unwrap_or("");
                    if &t == table_name { flowtables.push((ffam, attrs.into_iter().map(|(t,v)| (t,v.to_vec())).collect())); }
                }
            }

            // Extract pre-reset rules for this table's chains.
            let mut rules_by_chain: std::collections::HashMap<String, Vec<Vec<(u16, Vec<u8>)>>> =
                std::collections::HashMap::new();
            for chn in chains.iter().map(|(_, a)| {
                a.iter().find(|(t, _)| *t == NFTA_CHAIN_NAME)
                    .map(|(_, v)| attr_str(v).to_string()).unwrap_or_default()
            }).chain(bound_chain_names.iter().cloned()) {
                if let Some(rules) = reset_rules.remove(&(fam, table_name.clone(), chn.clone())) {
                    rules_by_chain.insert(chn, rules);
                }
            }

            // Anon set registry.
            let mut anon_reg = self.collect_anon_sets(fam, table_name)?;
            for bname in &bound_chain_names {
                if let Some(brules) = rules_by_chain.remove(bname) {
                    anon_reg.bound_chains.insert(bname.clone(), brules);
                }
            }

            // Render table.
            println!("table {} {} {{", family_str(fam), table_name);
            let mut emitted_anything = false;
            if let Some(ref c) = table_comment { println!("\tcomment \"{}\"", c); emitted_anything = true; }
            if table_flags & NFT_TABLE_F_DORMANT != 0 { println!("\tflags dormant"); emitted_anything = true; }
            if emitted_anything && (!objs.is_empty() || !sets.is_empty() || !flowtables.is_empty() || !chains.is_empty()) { println!(); }

            for (j, attrs) in objs.iter().enumerate() {
                if j > 0 { println!(); }
                output::print_object_with_handle(attrs, sh);
            }
            if !objs.is_empty() && (!sets.is_empty() || !flowtables.is_empty() || !chains.is_empty()) { println!(); }

            for (j, (sfam, attrs)) in sets.iter().enumerate() {
                if j > 0 { println!(); }
                let set_name = attrs.iter().find(|(t, _)| *t == NFTA_SET_NAME)
                    .map(|(_, v)| attr_str(v).to_string()).unwrap_or_default();
                let tn = table_name.clone();
                let sn = set_name.clone();
                let mut elems: Vec<Vec<(u16, Vec<u8>)>> = Vec::new();
                self.dump(NFT_MSG_GETSETELEM, *sfam, |msg, pos| {
                    msg.put_str(NFTA_SET_ELEM_LIST_TABLE, &tn);
                    msg.put_str(NFTA_SET_ELEM_LIST_SET,   &sn);
                    msg.end_msg(pos);
                }, |mt, _, data| {
                    if mt == NFT_MSG_NEWSETELEM {
                        let a = parse_attrs(data);
                        if let Some((_, list)) = a.iter().find(|(t, _)| *t == NFTA_SET_ELEM_LIST_ELEMENTS) {
                            for (_, e) in parse_attrs(list) { elems.push(parse_attrs(e).into_iter().map(|(t,v)| (t,v.to_vec())).collect()); }
                        }
                    }
                })?;
                let flags = attrs.iter().find(|(t, _)| *t == NFTA_SET_FLAGS)
                    .map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
                if flags & NFT_SET_INTERVAL == 0 {
                    elems.sort_by(|a, b| {
                        let ka = a.iter().find(|(t, _)| *t == NFTA_SET_ELEM_KEY)
                            .and_then(|(_, v)| parse_attrs(v).into_iter()
                                .find(|(t, _)| *t == NFTA_DATA_VALUE).map(|(_, d)| d.to_vec()))
                            .unwrap_or_default();
                        let kb = b.iter().find(|(t, _)| *t == NFTA_SET_ELEM_KEY)
                            .and_then(|(_, v)| parse_attrs(v).into_iter()
                                .find(|(t, _)| *t == NFTA_DATA_VALUE).map(|(_, d)| d.to_vec()))
                            .unwrap_or_default();
                        ka.cmp(&kb)
                    });
                }
                output::print_set_with_elements(*sfam, attrs, &elems, self.terse);
            }
            if !sets.is_empty() && (!flowtables.is_empty() || !chains.is_empty()) { println!(); }

            for (j, (ffam, fattrs)) in flowtables.iter().enumerate() {
                if j > 0 { println!(); }
                output::print_flowtable_h(*ffam, fattrs, sh);
            }
            if !flowtables.is_empty() && !chains.is_empty() { println!(); }

            let reg_ref = &anon_reg;
            for (j, (cfam, chain_attrs)) in chains.iter().enumerate() {
                if j > 0 { println!(); }
                output::print_chain_header(*cfam, chain_attrs, sh);
                let cname = chain_attrs.iter().find(|(t, _)| *t == NFTA_CHAIN_NAME)
                    .map(|(_, v)| attr_str(v)).unwrap_or("");
                if let Some(rules) = rules_by_chain.get(cname) {
                    for attrs in rules {
                        output::print_rule_with_sets(attrs, sh, sl, reg_ref);
                    }
                }
                output::print_chain_footer();
            }

            println!("}}");
        }
        Ok(())
    }

    fn list_named_object(&mut self, family: u8, table: &str, name: &str) -> io::Result<()> {
        let mut found: Vec<Vec<(u16, Vec<u8>)>> = Vec::new();
        let tf = table.to_string();
        let nf = name.to_string();
        self.dump(NFT_MSG_GETOBJ, family, |_, _| {}, |mt, _, data| {
            if mt == NFT_MSG_NEWOBJ {
                let attrs = parse_attrs(data);
                let t = attrs.iter().find(|(t, _)| *t == NFTA_OBJ_TABLE)
                    .map(|(_, v)| attr_str(v)).unwrap_or("");
                let n = attrs.iter().find(|(t, _)| *t == NFTA_OBJ_NAME)
                    .map(|(_, v)| attr_str(v)).unwrap_or("");
                if t == tf && n == nf { found.push(attrs.into_iter().map(|(t,v)| (t,v.to_vec())).collect()); }
            }
        })?;
        if found.is_empty() {
            return Err(io::Error::new(io::ErrorKind::NotFound, format!("no such object {}/{}", table, name)));
        }
        let sh = self.show_handles;
        println!("table {} {} {{", family_str(family), table);
        for attrs in &found {
            output::print_object_with_handle(attrs, sh);
        }
        println!("}}");
        Ok(())
    }

    fn list_named_flowtable(&mut self, family: u8, table: &str, name: &str) -> io::Result<()> {
        let mut found: Vec<(u8, Vec<(u16, Vec<u8>)>)> = Vec::new();
        let tf = table.to_string();
        let nf = name.to_string();
        self.dump(NFT_MSG_GETFLOWTABLE, family, |_, _| {}, |mt, fam, data| {
            if mt == NFT_MSG_NEWFLOWTABLE {
                let attrs = parse_attrs(data);
                let t = attrs.iter().find(|(t, _)| *t == NFTA_FLOWTABLE_TABLE)
                    .map(|(_, v)| attr_str(v)).unwrap_or("");
                let n = attrs.iter().find(|(t, _)| *t == NFTA_FLOWTABLE_NAME)
                    .map(|(_, v)| attr_str(v)).unwrap_or("");
                if t == tf && n == nf { found.push((fam, attrs.into_iter().map(|(t,v)| (t,v.to_vec())).collect())); }
            }
        })?;
        if found.is_empty() {
            return Err(io::Error::new(io::ErrorKind::NotFound,
                format!("no such flowtable {}/{}", table, name)));
        }
        let sh = self.show_handles;
        println!("table {} {} {{", family_str(family), table);
        for (fam, attrs) in &found {
            output::print_flowtable_h(*fam, attrs, sh);
        }
        println!("}}");
        Ok(())
    }

    fn list_flowtables(&mut self, family: u8, filter_table: &str) -> io::Result<()> {
        // Collect all flowtables, group by (family, table).
        let mut all: Vec<(u8, String, Vec<(u16, Vec<u8>)>)> = Vec::new();
        self.dump(NFT_MSG_GETFLOWTABLE, family, |_, _| {}, |mt, fam, data| {
            if mt == NFT_MSG_NEWFLOWTABLE {
                let attrs = parse_attrs(data);
                let tname = attrs.iter().find(|(t, _)| *t == NFTA_FLOWTABLE_TABLE)
                    .map(|(_, v)| attr_str(v).to_string()).unwrap_or_default();
                if filter_table.is_empty() || tname == filter_table {
                    all.push((fam, tname, attrs.into_iter().map(|(t,v)| (t,v.to_vec())).collect()));
                }
            }
        })?;

        // Group by (family, table) in table-order.
        let mut tables: Vec<(u8, String)> = Vec::new();
        for (fam, tname, _) in &all {
            if !tables.iter().any(|(f, n)| f == fam && n == tname) {
                tables.push((*fam, tname.clone()));
            }
        }
        for (fam, tname) in &tables {
            println!("table {} {} {{", family_str(*fam), tname);
            let sh = self.show_handles;
            for (ffam, stable, fattrs) in &all {
                if ffam == fam && stable == tname {
                    output::print_flowtable_h(*ffam, fattrs, sh);
                }
            }
            println!("}}");
        }
        Ok(())
    }

    fn list_objects(&mut self, family: u8, kind: u32) -> io::Result<()> {
        let mut by_table: Vec<(u8, String, Vec<Vec<(u16, Vec<u8>)>>)> = Vec::new();
        let mut tables: Vec<(u8, String)> = Vec::new();
        self.dump(NFT_MSG_GETTABLE, family, |_, _| {}, |mt, fam, data| {
            if mt == NFT_MSG_NEWTABLE {
                let a = parse_attrs(data);
                let n = a.iter().find(|(t, _)| *t == NFTA_TABLE_NAME)
                    .map(|(_, v)| attr_str(v).to_string()).unwrap_or_default();
                tables.push((fam, n));
            }
        })?;
        for (fam, tname) in &tables {
            by_table.push((*fam, tname.clone(), Vec::new()));
        }
        self.dump(NFT_MSG_GETOBJ, family, |_, _| {}, |mt, _, data| {
            if mt == NFT_MSG_NEWOBJ {
                let attrs = parse_attrs(data);
                let t = attrs.iter().find(|(t, _)| *t == NFTA_OBJ_TABLE)
                    .map(|(_, v)| attr_str(v)).unwrap_or("");
                let k = attrs.iter().find(|(t, _)| *t == NFTA_OBJ_TYPE)
                    .map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
                if kind != 0 && k != kind { return; }
                if let Some(slot) = by_table.iter_mut().find(|(_, n, _)| n == &t) {
                    slot.2.push(attrs.into_iter().map(|(t,v)| (t,v.to_vec())).collect());
                }
            }
        })?;
        let sh = self.show_handles;
        for (fam, tname, objs) in &by_table {
            if objs.is_empty() { continue; }
            println!("table {} {} {{", family_str(*fam), tname);
            for a in objs {
                output::print_object_with_handle(a, sh);
            }
            println!("}}");
        }
        Ok(())
    }

    fn exec_list_json(&mut self, cmd: &Command) -> io::Result<()> {
        let mut j = output::JsonOut::begin();
        let sh = self.show_handles; let sl = self.stateless;
        match cmd.obj {
            CmdObj::Ruleset | CmdObj::Tables => {
                // Dump all tables first.
                let mut tables: Vec<(u8, Vec<(u16, Vec<u8>)>)> = Vec::new();
                self.dump(NFT_MSG_GETTABLE, cmd.family, |_, _| {}, |mt, fam, data| {
                    if mt == NFT_MSG_NEWTABLE { tables.push((fam, parse_attrs(data).into_iter().map(|(t,v)| (t,v.to_vec())).collect())); }
                })?;

                if !matches!(cmd.obj, CmdObj::Ruleset) {
                    // `list tables` — just the tables themselves.
                    for (fam, tattrs) in &tables { j.table(*fam, tattrs); }
                } else {
                    // `list ruleset` (JSON) — pipeline GETCHAIN + GETSET +
                    // GETRULE for all tables in one multi_dump pass, then
                    // emit in libnftables order (table, chains, sets, rules).
                    // Saves (3 * N_tables - 1) sequential RTTs vs the old
                    // per-table per-chain loop.
                    let n_tables = tables.len();
                    let mut reqs: Vec<(u16, u8, Box<dyn FnOnce(&mut MsgBuilder, usize)>)> =
                        Vec::with_capacity(3 * n_tables);
                    for (fam, tattrs) in &tables {
                        let fam = *fam;
                        let tname = tattrs.iter().find(|(t, _)| *t == NFTA_TABLE_NAME)
                            .map(|(_, v)| attr_str(v).to_string()).unwrap_or_default();
                        let t1 = tname.clone();
                        // GETCHAIN — unfiltered; group client-side.
                        reqs.push((NFT_MSG_GETCHAIN, fam, Box::new(|_, _| {})));
                        // GETSET   — unfiltered; group client-side.
                        reqs.push((NFT_MSG_GETSET,   fam, Box::new(|_, _| {})));
                        // GETRULE  — scoped to table to keep responses compact.
                        reqs.push((NFT_MSG_GETRULE,  fam, Box::new(move |msg, pos| {
                            msg.put_str(NFTA_RULE_TABLE, &t1);
                            msg.end_msg(pos);
                        })));
                    }
                    let mut batched = self.multi_dump(reqs)?;
                    // Slot layout per table i: [3i]=GETCHAIN [3i+1]=GETSET [3i+2]=GETRULE

                    for (i, (fam, tattrs)) in tables.iter().enumerate() {
                        let fam = *fam;
                        let tname = tattrs.iter().find(|(t, _)| *t == NFTA_TABLE_NAME)
                            .map(|(_, v)| attr_str(v).to_string()).unwrap_or_default();
                        j.table(fam, tattrs);

                        let base = i * 3;

                        // Chains (slot base+0).
                        let mut chains: Vec<Vec<(u16, Vec<u8>)>> = Vec::new();
                        for (mt, _, data) in batched[base].drain(..) {
                            if mt == NFT_MSG_NEWCHAIN {
                                let a = parse_attrs(&data);
                                let t = a.iter().find(|(t, _)| *t == NFTA_CHAIN_TABLE)
                                    .map(|(_, v)| attr_str(v)).unwrap_or("");
                                if t == tname { chains.push(a.into_iter().map(|(t,v)| (t,v.to_vec())).collect()); }
                            }
                        }
                        for cattrs in &chains { j.chain(fam, &tname, cattrs); }

                        // Named stateful objects (counters / quotas / limits)
                        // of this table — emitted before sets/maps, matching
                        // upstream nft's JSON output order.
                        let tn_obj = tname.clone();
                        let mut objects: Vec<Vec<(u16, Vec<u8>)>> = Vec::new();
                        self.dump(NFT_MSG_GETOBJ, fam, |_, _| {}, |mt, _, data| {
                            if mt != NFT_MSG_NEWOBJ { return; }
                            let a = parse_attrs(data);
                            let t = a.iter().find(|(t, _)| *t == NFTA_OBJ_TABLE)
                                .map(|(_, v)| attr_str(v)).unwrap_or("");
                            if t == tn_obj { objects.push(a.into_iter().map(|(t,v)| (t,v.to_vec())).collect()); }
                        })?;
                        for oattrs in &objects {
                            j.object(fam, &tname, oattrs);
                        }

                        // Named sets / maps (slot base+1).
                        let mut sets: Vec<Vec<(u16, Vec<u8>)>> = Vec::new();
                        for (mt, _, data) in batched[base + 1].drain(..) {
                            if mt == NFT_MSG_NEWSET {
                                let a = parse_attrs(&data);
                                let t = a.iter().find(|(t, _)| *t == NFTA_SET_TABLE)
                                    .map(|(_, v)| attr_str(v)).unwrap_or("");
                                let flags = a.iter().find(|(t, _)| *t == NFTA_SET_FLAGS)
                                    .map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
                                if t == tname && (flags & 0x1) == 0 { sets.push(a.into_iter().map(|(t,v)| (t,v.to_vec())).collect()); }
                            }
                        }
                        for sattrs in &sets {
                            let sname = sattrs.iter().find(|(t, _)| *t == NFTA_SET_NAME)
                                .map(|(_, v)| attr_str(v)).unwrap_or("");
                            let pairs = if self.terse {
                                Vec::new()
                            } else {
                                self.set_element_pairs(fam, &tname, &sname)?
                            };
                            j.set_pairs(fam, &tname, sattrs, &pairs);
                        }

                        // Flowtables — libnftables emits them after chains
                        // and named objects but before rules. Pull the
                        // flowtable list of this table in a single dump.
                        let tn_flow = tname.clone();
                        let mut flowtables: Vec<Vec<(u16, Vec<u8>)>> = Vec::new();
                        self.dump(NFT_MSG_GETFLOWTABLE, fam, |_, _| {}, |mt, _, data| {
                            if mt != NFT_MSG_NEWFLOWTABLE { return; }
                            let a = parse_attrs(data);
                            let t = a.iter().find(|(t, _)| *t == NFTA_FLOWTABLE_TABLE)
                                .map(|(_, v)| attr_str(v)).unwrap_or("");
                            if t == tn_flow { flowtables.push(a.into_iter().map(|(t,v)| (t,v.to_vec())).collect()); }
                        })?;
                        for fattrs in &flowtables {
                            j.flowtable(fam, &tname, fattrs);
                        }

                        // Anon-set registry for rule JSON.
                        let anon_reg = self.collect_anon_sets(fam, &tname)?;

                        // Rules grouped by chain (slot base+2).
                        let mut rules_by_chain: std::collections::HashMap<
                            String, Vec<Vec<(u16, Vec<u8>)>>> =
                            std::collections::HashMap::new();
                        for (mt, _, data) in batched[base + 2].drain(..) {
                            if mt == NFT_MSG_NEWRULE {
                                let a = parse_attrs(&data);
                                let cname = a.iter().find(|(t, _)| *t == NFTA_RULE_CHAIN)
                                    .map(|(_, v)| attr_str(v).to_string()).unwrap_or_default();
                                rules_by_chain.entry(cname).or_default().push(a.into_iter().map(|(t,v)| (t,v.to_vec())).collect());
                            }
                        }

                        for cattrs in &chains {
                            let cname = cattrs.iter().find(|(t, _)| *t == NFTA_CHAIN_NAME)
                                .map(|(_, v)| attr_str(v)).unwrap_or("");
                            if let Some(rules) = rules_by_chain.get(cname) {
                                for rattrs in rules {
                                    j.rule_with_sets(fam, &tname, cname, rattrs, sh, sl, &anon_reg);
                                }
                            }
                        }
                    }
                }
            }
            CmdObj::Table => {
                let name = cmd.table.clone();
                let mut tables: Vec<(u8, Vec<(u16, Vec<u8>)>)> = Vec::new();
                let nf = name.clone();
                self.dump(NFT_MSG_GETTABLE, cmd.family, |_, _| {}, |mt, fam, data| {
                    if mt == NFT_MSG_NEWTABLE {
                        let a = parse_attrs(data);
                        let n = a.iter().find(|(t, _)| *t == NFTA_TABLE_NAME)
                            .map(|(_, v)| attr_str(v)).unwrap_or("");
                        if n == nf { tables.push((fam, a.into_iter().map(|(t,v)| (t,v.to_vec())).collect())); }
                    }
                })?;
                for (fam, tattrs) in &tables {
                    j.table(*fam, tattrs);
                    let tn = name.clone();
                    let mut chains: Vec<Vec<(u16, Vec<u8>)>> = Vec::new();
                    self.dump(NFT_MSG_GETCHAIN, *fam, |_, _| {}, |mt, _, data| {
                        if mt == NFT_MSG_NEWCHAIN {
                            let a = parse_attrs(data);
                            let t = a.iter().find(|(t, _)| *t == NFTA_CHAIN_TABLE)
                                .map(|(_, v)| attr_str(v)).unwrap_or("");
                            if t == tn { chains.push(a.into_iter().map(|(t,v)| (t,v.to_vec())).collect()); }
                        }
                    })?;
                    // Collect anon sets of this table so rule JSON can
                    // inline `{"set": [...]}` / vmap `[[k, verdict], ...]`.
                    let anon_reg = self.collect_anon_sets(*fam, &name)?;
                    for cattrs in &chains {
                        j.chain(*fam, &name, cattrs);
                        let cname = cattrs.iter().find(|(t, _)| *t == NFTA_CHAIN_NAME)
                            .map(|(_, v)| attr_str(v).to_string()).unwrap_or_default();
                        let tn2 = name.clone();
                        let cn2 = cname.clone();
                        let mut rules: Vec<Vec<(u16, Vec<u8>)>> = Vec::new();
                        self.dump(NFT_MSG_GETRULE, *fam, |msg, pos| {
                            msg.put_str(NFTA_RULE_TABLE, &tn2);
                            msg.put_str(NFTA_RULE_CHAIN, &cn2);
                            msg.end_msg(pos);
                        }, |mt, _, data| {
                            if mt == NFT_MSG_NEWRULE { rules.push(parse_attrs(data).into_iter().map(|(t,v)| (t,v.to_vec())).collect()); }
                        })?;
                        for rattrs in &rules {
                            j.rule_with_sets(*fam, &name, &cname, rattrs, sh, sl, &anon_reg);
                        }
                    }
                }
            }
            CmdObj::Set | CmdObj::Map => {
                // `-j list set|map FAMILY TABLE NAME` — dump just the
                // named set/map plus the enclosing table envelope to
                // match upstream's output.
                let target_table = cmd.table.clone();
                let target_name = cmd.set_name.clone();
                let mut set_attrs: Option<(u8, Vec<(u16, Vec<u8>)>)> = None;
                self.dump(NFT_MSG_GETSET, cmd.family, |_, _| {}, |mt, fam, data| {
                    if mt != NFT_MSG_NEWSET { return; }
                    let a = parse_attrs(data);
                    let t = a.iter().find(|(t, _)| *t == NFTA_SET_TABLE)
                        .map(|(_, v)| attr_str(v)).unwrap_or("");
                    let n = a.iter().find(|(t, _)| *t == NFTA_SET_NAME)
                        .map(|(_, v)| attr_str(v)).unwrap_or("");
                    if t == target_table && n == target_name {
                        set_attrs = Some((fam, a.into_iter().map(|(t,v)| (t,v.to_vec())).collect()));
                    }
                })?;
                if let Some((fam, sattrs)) = set_attrs {
                    // Emit enclosing table envelope first.
                    let mut tables: Vec<(u8, Vec<(u16, Vec<u8>)>)> = Vec::new();
                    let tn = target_table.clone();
                    self.dump(NFT_MSG_GETTABLE, fam, |_, _| {}, |mt, f2, data| {
                        if mt != NFT_MSG_NEWTABLE { return; }
                        let a = parse_attrs(data);
                        let n = a.iter().find(|(t, _)| *t == NFTA_TABLE_NAME)
                            .map(|(_, v)| attr_str(v)).unwrap_or("");
                        if n == tn { tables.push((f2, a.into_iter().map(|(t,v)| (t,v.to_vec())).collect())); }
                    })?;
                    for (f, t) in &tables { j.table(*f, t); }
                    let pairs = if self.terse {
                        Vec::new()
                    } else {
                        self.set_element_pairs(fam, &target_table, &target_name)?
                    };
                    j.set_pairs(fam, &target_table, &sattrs, &pairs);
                }
            }
            _ => {} // other object types: just emit envelope
        }
        j.end();
        Ok(())
    }

    fn list_tables(&mut self, family: u8) -> io::Result<()> {
        self.dump(NFT_MSG_GETTABLE, family, |_, _| {}, |msg_type, fam, data| {
            if msg_type == NFT_MSG_NEWTABLE {
                let attrs: Vec<(u16, Vec<u8>)> = parse_attrs(data).into_iter().map(|(t,v)| (t,v.to_vec())).collect();
                output::print_table_line(fam, &attrs);
            }
        })
    }

    fn list_chains(&mut self, family: u8) -> io::Result<()> {
        self.dump(NFT_MSG_GETCHAIN, family, |_, _| {}, |msg_type, fam, data| {
            if msg_type == NFT_MSG_NEWCHAIN {
                let attrs = parse_attrs(data);
                let table = attrs.iter().find(|(t, _)| *t == NFTA_CHAIN_TABLE).map(|(_, v)| attr_str(v)).unwrap_or("?");
                let name = attrs.iter().find(|(t, _)| *t == NFTA_CHAIN_NAME).map(|(_, v)| attr_str(v)).unwrap_or("?");
                println!("table {} {} chain {}", family_str(fam), table, name);
            }
        })
    }

    fn list_table(&mut self, family: u8, table: &str) -> io::Result<()> {
        println!("table {} {} {{", family_str(family), table);
        let sh = self.show_handles;

        // Pipeline GETTABLE + GETCHAIN + GETSET + GETOBJ in a single
        // send/recv pass — saves 3 sequential RTTs (~60 ms each on arfur).
        // Slot 0 = GETTABLE, 1 = GETCHAIN, 2 = GETSET, 3 = GETOBJ,
        // 4 = GETFLOWTABLE.
        let reqs: Vec<(u16, u8, Box<dyn FnOnce(&mut MsgBuilder, usize)>)> = vec![
            (NFT_MSG_GETTABLE,     family, Box::new(|_, _| {})),
            (NFT_MSG_GETCHAIN,     family, Box::new(|_, _| {})),
            (NFT_MSG_GETSET,       family, Box::new(|_, _| {})),
            (NFT_MSG_GETOBJ,       family, Box::new(|_, _| {})),
            (NFT_MSG_GETFLOWTABLE, family, Box::new(|_, _| {})),
        ];
        let mut batched = self.multi_dump(reqs)?;

        // Process GETTABLE results (slot 0)
        let table_name = table.to_string();
        let mut table_flags: u32 = 0;
        let mut table_comment: Option<String> = None;
        for (msg_type, _fam, data) in batched[0].drain(..) {
            if msg_type == NFT_MSG_NEWTABLE {
                let a = parse_attrs(&data);
                let n = a.iter().find(|(t, _)| *t == NFTA_TABLE_NAME)
                    .map(|(_, v)| attr_str(v)).unwrap_or("");
                if n == table_name {
                    if let Some((_, v)) = a.iter().find(|(t, _)| *t == NFTA_TABLE_FLAGS) {
                        table_flags = attr_u32_be(v);
                    }
                    if let Some((_, ud)) = a.iter().find(|(t, _)| *t == NFTA_TABLE_USERDATA) {
                        let mut ci = 0usize;
                        while ci + 2 <= ud.len() {
                            let ty = ud[ci]; let ln = ud[ci + 1] as usize; ci += 2;
                            if ci + ln > ud.len() { break; }
                            if ty == 0 {
                                let trimmed: Vec<u8> = ud[ci..ci + ln].iter().take_while(|&&b| b != 0).copied().collect();
                                if let Ok(txt) = std::str::from_utf8(&trimmed) {
                                    if !txt.is_empty() { table_comment = Some(txt.to_string()); }
                                }
                                break;
                            }
                            ci += ln;
                        }
                    }
                }
            }
        }
        let mut emitted_anything = false;
        if let Some(ref c) = table_comment {
            println!("\tcomment \"{}\"", c);
            emitted_anything = true;
        }
        if table_flags & NFT_TABLE_F_DORMANT != 0 {
            println!("\tflags dormant");
            emitted_anything = true;
        }

        // Process GETCHAIN results (slot 1)
        let mut chains: Vec<(u8, Vec<(u16, Vec<u8>)>)> = Vec::new();
        for (msg_type, fam, data) in batched[1].drain(..) {
            if msg_type == NFT_MSG_NEWCHAIN {
                let attrs = parse_attrs(&data);
                let t = attrs.iter().find(|(t, _)| *t == NFTA_CHAIN_TABLE)
                    .map(|(_, v)| attr_str(v)).unwrap_or("");
                if t == table_name { chains.push((fam, attrs.into_iter().map(|(t,v)| (t,v.to_vec())).collect())); }
            }
        }

        // Process GETSET results (slot 2) — named sets only (anonymous
        // sets are collected separately by collect_anon_sets later).
        let mut sets: Vec<(u8, Vec<(u16, Vec<u8>)>)> = Vec::new();
        for (msg_type, fam, data) in batched[2].drain(..) {
            if msg_type == NFT_MSG_NEWSET {
                let attrs = parse_attrs(&data);
                let t = attrs.iter().find(|(t, _)| *t == NFTA_SET_TABLE)
                    .map(|(_, v)| attr_str(v)).unwrap_or("");
                let flags = attrs.iter().find(|(t, _)| *t == NFTA_SET_FLAGS)
                    .map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
                // Skip anonymous (kernel-internal) sets in list output.
                if t == table_name && (flags & 0x1) == 0 {
                    sets.push((fam, attrs.into_iter().map(|(t,v)| (t,v.to_vec())).collect()));
                }
            }
        }

        // Process GETOBJ results (slot 3)
        let mut objs: Vec<Vec<(u16, Vec<u8>)>> = Vec::new();
        for (msg_type, _fam, data) in batched[3].drain(..) {
            if msg_type == NFT_MSG_NEWOBJ {
                let attrs = parse_attrs(&data);
                let t = attrs.iter().find(|(t, _)| *t == NFTA_OBJ_TABLE)
                    .map(|(_, v)| attr_str(v)).unwrap_or("");
                if t == table_name { objs.push(attrs.into_iter().map(|(t,v)| (t,v.to_vec())).collect()); }
            }
        }

        // Process GETFLOWTABLE results (slot 4) — flowtables live in
        // the same table namespace, indexed by NFTA_FLOWTABLE_TABLE.
        let mut flowtables: Vec<(u8, Vec<(u16, Vec<u8>)>)> = Vec::new();
        for (msg_type, ffam, data) in batched[4].drain(..) {
            if msg_type == NFT_MSG_NEWFLOWTABLE {
                let attrs = parse_attrs(&data);
                let t = attrs.iter().find(|(t, _)| *t == NFTA_FLOWTABLE_TABLE)
                    .map(|(_, v)| attr_str(v)).unwrap_or("");
                if t == table_name { flowtables.push((ffam, attrs.into_iter().map(|(t,v)| (t,v.to_vec())).collect())); }
            }
        }

        if emitted_anything && (!objs.is_empty() || !sets.is_empty() || !flowtables.is_empty() || !chains.is_empty()) { println!(); }

        // Objects (counter, quota, limit, etc.) come before sets/maps
        // in upstream nft's output.
        for (i, attrs) in objs.iter().enumerate() {
            if i > 0 { println!(); }
            output::print_object_with_handle(attrs, sh);
        }

        if !objs.is_empty() && (!sets.is_empty() || !flowtables.is_empty() || !chains.is_empty()) { println!(); }

        for (i, (fam, attrs)) in sets.iter().enumerate() {
            if i > 0 { println!(); }
            let set_name = attrs.iter().find(|(t, _)| *t == NFTA_SET_NAME)
                .map(|(_, v)| attr_str(v).to_string()).unwrap_or_default();
            let tbl = table.to_string();
            let sn  = set_name.clone();
            let mut elems: Vec<Vec<(u16, Vec<u8>)>> = Vec::new();
            self.dump(NFT_MSG_GETSETELEM, *fam, |msg, pos| {
                msg.put_str(NFTA_SET_ELEM_LIST_TABLE, &tbl);
                msg.put_str(NFTA_SET_ELEM_LIST_SET,   &sn);
                msg.end_msg(pos);
            }, |mt, _, data| {
                if mt == NFT_MSG_NEWSETELEM {
                    let a = parse_attrs(data);
                    if let Some((_, list)) = a.iter().find(|(t, _)| *t == NFTA_SET_ELEM_LIST_ELEMENTS) {
                        for (_, e) in parse_attrs(list) {
                            elems.push(parse_attrs(e).into_iter().map(|(t,v)| (t,v.to_vec())).collect());
                        }
                    }
                }
            })?;
            // Sort elements by key bytes ascending so hash-set dumps
            // (otherwise returned in kernel-bucket order) display in
            // a stable order that matches upstream's listings.
            let flags = attrs.iter().find(|(t, _)| *t == NFTA_SET_FLAGS)
                .map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
            if flags & NFT_SET_INTERVAL == 0 {
                elems.sort_by(|a, b| {
                    let ka = a.iter().find(|(t, _)| *t == NFTA_SET_ELEM_KEY)
                        .and_then(|(_, v)| parse_attrs(v).into_iter()
                            .find(|(t, _)| *t == NFTA_DATA_VALUE)
                            .map(|(_, d)| d.to_vec()))
                        .unwrap_or_default();
                    let kb = b.iter().find(|(t, _)| *t == NFTA_SET_ELEM_KEY)
                        .and_then(|(_, v)| parse_attrs(v).into_iter()
                            .find(|(t, _)| *t == NFTA_DATA_VALUE)
                            .map(|(_, d)| d.to_vec()))
                        .unwrap_or_default();
                    ka.cmp(&kb)
                });
            }
            output::print_set_with_elements(*fam, attrs, &elems, self.terse);
        }

        if !sets.is_empty() && (!flowtables.is_empty() || !chains.is_empty()) { println!(); }

        // Flowtables go between named objects and chains in `nft list`
        // output, separated by blank lines. Each flowtable carries a
        // hook line and a devices line; the renderer formats both.
        for (i, (ffam, fattrs)) in flowtables.iter().enumerate() {
            if i > 0 { println!(); }
            output::print_flowtable_h(*ffam, fattrs, sh);
        }

        if !flowtables.is_empty() && !chains.is_empty() { println!(); }

        // Collect anonymous sets + their elements into a registry so
        // the rule printer can inline `{ a, b, c }` where upstream
        // does, instead of showing `@__set0`.
        let anon_reg = self.collect_anon_sets(family, table)?;

        // Fetch ALL rules for this table in one GETRULE dump (scoped to
        // the table, no chain filter) — saves N_chains − 1 RTTs.  The
        // kernel returns rules in chain order so we group them here.
        let tbl = table.to_string();
        let mut rules_by_chain: std::collections::HashMap<String, Vec<Vec<(u16, Vec<u8>)>>> =
            std::collections::HashMap::new();
        self.dump(NFT_MSG_GETRULE, family, |msg, pos| {
            msg.put_str(NFTA_RULE_TABLE, &tbl);
            msg.end_msg(pos);
        }, |msg_type, _, data| {
            if msg_type == NFT_MSG_NEWRULE {
                let attrs = parse_attrs(data);
                let chain = attrs.iter().find(|(t, _)| *t == NFTA_RULE_CHAIN)
                    .map(|(_, v)| attr_str(v).to_string())
                    .unwrap_or_default();
                rules_by_chain.entry(chain).or_default().push(attrs.into_iter().map(|(t,v)| (t,v.to_vec())).collect());
            }
        })?;

        let sh = self.show_handles;
        let sl = self.stateless;
        let reg_ref = &anon_reg;
        for (i, (fam, chain_attrs)) in chains.iter().enumerate() {
            if i > 0 { println!(); }
            output::print_chain_header(*fam, chain_attrs, self.show_handles);

            let chain_name = chain_attrs.iter().find(|(t, _)| *t == NFTA_CHAIN_NAME)
                .map(|(_, v)| attr_str(v)).unwrap_or("");
            if let Some(rules) = rules_by_chain.get(chain_name) {
                for attrs in rules {
                    output::print_rule_with_sets(attrs, sh, sl, reg_ref);
                }
            }

            output::print_chain_footer();
        }

        println!("}}");
        Ok(())
    }

    fn list_chain_with_rules(&mut self, family: u8, table: &str, chain: &str) -> io::Result<()> {
        // Collect the specific chain
        let mut found_attrs: Option<(u8, Vec<(u16, Vec<u8>)>)> = None;
        let table_f = table.to_string();
        let chain_f = chain.to_string();
        self.dump(NFT_MSG_GETCHAIN, family, |_, _| {}, |msg_type, fam, data| {
            if msg_type == NFT_MSG_NEWCHAIN {
                let attrs = parse_attrs(data);
                let t = attrs.iter().find(|(t, _)| *t == NFTA_CHAIN_TABLE).map(|(_, v)| attr_str(v)).unwrap_or("");
                let c = attrs.iter().find(|(t, _)| *t == NFTA_CHAIN_NAME).map(|(_, v)| attr_str(v)).unwrap_or("");
                if t == table_f && c == chain_f { found_attrs = Some((fam, attrs.into_iter().map(|(t,v)| (t,v.to_vec())).collect())); }
            }
        })?;

        if let Some((fam, attrs)) = found_attrs {
            output::print_chain_header(fam, &attrs, self.show_handles);

            let sh = self.show_handles;
            let sl = self.stateless;
            let tbl = table.to_string();
            let chn = chain.to_string();
            self.dump(NFT_MSG_GETRULE, family, |msg, pos| {
                msg.put_str(NFTA_RULE_TABLE, &tbl);
                msg.put_str(NFTA_RULE_CHAIN, &chn);
                msg.end_msg(pos);
            }, |msg_type, _, data| {
                if msg_type == NFT_MSG_NEWRULE {
                    let attrs: Vec<(u16, Vec<u8>)> = parse_attrs(data).into_iter().map(|(t,v)| (t,v.to_vec())).collect();
                    output::print_rule(&attrs, sh, sl);
                }
            })?;

            output::print_chain_footer();
        }
        Ok(())
    }

    fn list_ruleset(&mut self, family: u8) -> io::Result<()> {
        // Enumerate all tables first (single RTT).
        let mut tables: Vec<(u8, String, u32, Option<String>)> = Vec::new();
        self.dump(NFT_MSG_GETTABLE, family, |_, _| {}, |msg_type, fam, data| {
            if msg_type == NFT_MSG_NEWTABLE {
                let attrs = parse_attrs(data);
                let name = attrs.iter().find(|(t, _)| *t == NFTA_TABLE_NAME)
                    .map(|(_, v)| attr_str(v).to_string()).unwrap_or_default();
                let flags = attrs.iter().find(|(t, _)| *t == NFTA_TABLE_FLAGS)
                    .map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
                let comment = attrs.iter().find(|(t, _)| *t == NFTA_TABLE_USERDATA)
                    .and_then(|(_, ud)| {
                        let mut ci = 0usize;
                        while ci + 2 <= ud.len() {
                            let ty = ud[ci]; let ln = ud[ci + 1] as usize; ci += 2;
                            if ci + ln > ud.len() { break; }
                            if ty == 0 {
                                let trimmed: Vec<u8> = ud[ci..ci + ln].iter().take_while(|&&b| b != 0).copied().collect();
                                return std::str::from_utf8(&trimmed).ok()
                                    .filter(|t| !t.is_empty()).map(String::from);
                            }
                            ci += ln;
                        }
                        None
                    });
                tables.push((fam, name, flags, comment));
            }
        })?;
        if tables.is_empty() { return Ok(()); }

        // Pipeline GETCHAIN + GETSET + GETOBJ + GETFLOWTABLE + GETRULE
        // for every table in a single multi_dump pass (5 * N_tables
        // slots). This saves (5 * N_tables - 1) sequential RTTs vs
        // calling list_table in a loop, at the cost of one client-side
        // group-by on the results.
        let n_tables = tables.len();
        let mut reqs: Vec<(u16, u8, Box<dyn FnOnce(&mut MsgBuilder, usize)>)> =
            Vec::with_capacity(5 * n_tables);
        for (fam, tbl, _, _) in &tables {
            let fam = *fam;
            let t1 = tbl.clone();
            // GETCHAIN — unfiltered dump, we group by table client-side.
            reqs.push((NFT_MSG_GETCHAIN, fam, Box::new(|_, _| {})));
            // GETSET   — unfiltered dump.
            reqs.push((NFT_MSG_GETSET,   fam, Box::new(|_, _| {})));
            // GETOBJ   — unfiltered dump.
            reqs.push((NFT_MSG_GETOBJ,   fam, Box::new(|_, _| {})));
            // GETFLOWTABLE — unfiltered dump.
            reqs.push((NFT_MSG_GETFLOWTABLE, fam, Box::new(|_, _| {})));
            // GETRULE  — scoped to table to avoid cross-table noise.
            reqs.push((NFT_MSG_GETRULE, fam, Box::new(move |msg, pos| {
                msg.put_str(NFTA_RULE_TABLE, &t1);
                msg.end_msg(pos);
            })));
        }
        let mut batched = self.multi_dump(reqs)?;
        // batched is indexed as: table i → slots [5i, 5i+1, 5i+2, 5i+3, 5i+4]
        // = [GETCHAIN, GETSET, GETOBJ, GETFLOWTABLE, GETRULE]

        let sh = self.show_handles;
        let sl = self.stateless;

        for (i, (fam, table_name, table_flags, table_comment)) in tables.iter().enumerate() {
            let fam = *fam;
            let base = i * 5;

            // -- GETCHAIN slot (base+0) --
            let mut chains: Vec<(u8, Vec<(u16, Vec<u8>)>)> = Vec::new();
            for (msg_type, cfam, data) in batched[base].drain(..) {
                if msg_type == NFT_MSG_NEWCHAIN {
                    let attrs = parse_attrs(&data);
                    let t = attrs.iter().find(|(t, _)| *t == NFTA_CHAIN_TABLE)
                        .map(|(_, v)| attr_str(v)).unwrap_or("");
                    if &t == table_name { chains.push((cfam, attrs.into_iter().map(|(t,v)| (t,v.to_vec())).collect())); }
                }
            }

            // -- GETSET slot (base+1): named sets only --
            let mut sets: Vec<(u8, Vec<(u16, Vec<u8>)>)> = Vec::new();
            for (msg_type, sfam, data) in batched[base + 1].drain(..) {
                if msg_type == NFT_MSG_NEWSET {
                    let attrs = parse_attrs(&data);
                    let t = attrs.iter().find(|(t, _)| *t == NFTA_SET_TABLE)
                        .map(|(_, v)| attr_str(v)).unwrap_or("");
                    let flags = attrs.iter().find(|(t, _)| *t == NFTA_SET_FLAGS)
                        .map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
                    if &t == table_name && (flags & 0x1) == 0 {
                        sets.push((sfam, attrs.into_iter().map(|(t,v)| (t,v.to_vec())).collect()));
                    }
                }
            }

            // -- GETOBJ slot (base+2) --
            let mut objs: Vec<Vec<(u16, Vec<u8>)>> = Vec::new();
            for (msg_type, _ofam, data) in batched[base + 2].drain(..) {
                if msg_type == NFT_MSG_NEWOBJ {
                    let attrs = parse_attrs(&data);
                    let t = attrs.iter().find(|(t, _)| *t == NFTA_OBJ_TABLE)
                        .map(|(_, v)| attr_str(v)).unwrap_or("");
                    if &t == table_name { objs.push(attrs.into_iter().map(|(t,v)| (t,v.to_vec())).collect()); }
                }
            }

            // -- GETFLOWTABLE slot (base+3) --
            let mut flowtables: Vec<(u8, Vec<(u16, Vec<u8>)>)> = Vec::new();
            for (msg_type, ffam, data) in batched[base + 3].drain(..) {
                if msg_type == NFT_MSG_NEWFLOWTABLE {
                    let attrs = parse_attrs(&data);
                    let t = attrs.iter().find(|(t, _)| *t == NFTA_FLOWTABLE_TABLE)
                        .map(|(_, v)| attr_str(v)).unwrap_or("");
                    if &t == table_name { flowtables.push((ffam, attrs.into_iter().map(|(t,v)| (t,v.to_vec())).collect())); }
                }
            }

            // -- GETRULE slot (base+4): group by chain --
            let mut rules_by_chain: std::collections::HashMap<String, Vec<Vec<(u16, Vec<u8>)>>> =
                std::collections::HashMap::new();
            for (msg_type, _rfam, data) in batched[base + 4].drain(..) {
                if msg_type == NFT_MSG_NEWRULE {
                    let attrs = parse_attrs(&data);
                    let chain = attrs.iter().find(|(t, _)| *t == NFTA_RULE_CHAIN)
                        .map(|(_, v)| attr_str(v).to_string()).unwrap_or_default();
                    rules_by_chain.entry(chain).or_default().push(attrs.into_iter().map(|(t,v)| (t,v.to_vec())).collect());
                }
            }

            // Emit table header.  No blank line between tables: the
            // closing `}` of the previous table provides separation, which
            // matches `nft list ruleset` and the golden-file baseline.
            println!("table {} {} {{", family_str(fam), table_name);

            let mut emitted_anything = false;
            if let Some(ref c) = table_comment {
                println!("\tcomment \"{}\"", c);
                emitted_anything = true;
            }
            if table_flags & NFT_TABLE_F_DORMANT != 0 {
                println!("\tflags dormant");
                emitted_anything = true;
            }
            if emitted_anything && (!objs.is_empty() || !sets.is_empty() || !flowtables.is_empty() || !chains.is_empty()) {
                println!();
            }

            // Objects (counter, quota, limit, etc.) come before sets/maps
            // in upstream nft's output.
            for (oi, attrs) in objs.iter().enumerate() {
                if oi > 0 { println!(); }
                output::print_object_with_handle(attrs, sh);
            }

            if !objs.is_empty() && (!sets.is_empty() || !flowtables.is_empty() || !chains.is_empty()) { println!(); }

            // Named sets (with element dumps — separate RTT per set, unavoidable).
            for (si, (sfam, attrs)) in sets.iter().enumerate() {
                if si > 0 { println!(); }
                let set_name = attrs.iter().find(|(t, _)| *t == NFTA_SET_NAME)
                    .map(|(_, v)| attr_str(v).to_string()).unwrap_or_default();
                let tbl = table_name.clone();
                let sn  = set_name.clone();
                let mut elems: Vec<Vec<(u16, Vec<u8>)>> = Vec::new();
                self.dump(NFT_MSG_GETSETELEM, *sfam, |msg, pos| {
                    msg.put_str(NFTA_SET_ELEM_LIST_TABLE, &tbl);
                    msg.put_str(NFTA_SET_ELEM_LIST_SET,   &sn);
                    msg.end_msg(pos);
                }, |mt, _, data| {
                    if mt == NFT_MSG_NEWSETELEM {
                        let a = parse_attrs(data);
                        if let Some((_, list)) = a.iter().find(|(t, _)| *t == NFTA_SET_ELEM_LIST_ELEMENTS) {
                            for (_, e) in parse_attrs(list) { elems.push(parse_attrs(e).into_iter().map(|(t,v)| (t,v.to_vec())).collect()); }
                        }
                    }
                })?;
                let flags = attrs.iter().find(|(t, _)| *t == NFTA_SET_FLAGS)
                    .map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
                if flags & NFT_SET_INTERVAL == 0 {
                    elems.sort_by(|a, b| {
                        let ka = a.iter().find(|(t, _)| *t == NFTA_SET_ELEM_KEY)
                            .and_then(|(_, v)| parse_attrs(v).into_iter()
                                .find(|(t, _)| *t == NFTA_DATA_VALUE).map(|(_, d)| d.to_vec()))
                            .unwrap_or_default();
                        let kb = b.iter().find(|(t, _)| *t == NFTA_SET_ELEM_KEY)
                            .and_then(|(_, v)| parse_attrs(v).into_iter()
                                .find(|(t, _)| *t == NFTA_DATA_VALUE).map(|(_, d)| d.to_vec()))
                            .unwrap_or_default();
                        ka.cmp(&kb)
                    });
                }
                output::print_set_with_elements(*sfam, attrs, &elems, self.terse);
            }

            if !sets.is_empty() && (!flowtables.is_empty() || !chains.is_empty()) { println!(); }

            for (fi, (ffam, fattrs)) in flowtables.iter().enumerate() {
                if fi > 0 { println!(); }
                output::print_flowtable_h(*ffam, fattrs, sh);
            }

            if !flowtables.is_empty() && !chains.is_empty() { println!(); }

            // Collect anon-set registry for rule printing.
            let anon_reg = self.collect_anon_sets(fam, table_name)?;
            let reg_ref = &anon_reg;

            for (ci, (cfam, chain_attrs)) in chains.iter().enumerate() {
                if ci > 0 { println!(); }
                output::print_chain_header(*cfam, chain_attrs, sh);
                let chain_name = chain_attrs.iter().find(|(t, _)| *t == NFTA_CHAIN_NAME)
                    .map(|(_, v)| attr_str(v)).unwrap_or("");
                if let Some(rules) = rules_by_chain.get(chain_name) {
                    for attrs in rules {
                        output::print_rule_with_sets(attrs, sh, sl, reg_ref);
                    }
                }
                output::print_chain_footer();
            }

            println!("}}");
        }
        Ok(())
    }

    // ── Flush ───────────────────────────────────────────────────

    fn exec_flush(&mut self, cmd: &Command) -> io::Result<()> {
        match cmd.obj {
            CmdObj::Ruleset => self.flush_ruleset(cmd.family),
            CmdObj::Table => self.flush_table(cmd.family, &cmd.table),
            CmdObj::Chain => self.flush_chain(cmd.family, &cmd.table, &cmd.chain),
            CmdObj::Set | CmdObj::Map => {
                // Anonymous sets aren't user-addressable.
                if cmd.set_name.starts_with("__set") || cmd.set_name.starts_with("__map") {
                    return Err(io::Error::new(io::ErrorKind::Other,
                        format!("Error: No such file or directory; did you mean \"list set {} {}\" instead?", cmd.table, cmd.set_name)));
                }
                // `flush set|map TABLE NAME` — drop every element
                // from the set/map but keep the set itself. Encoded
                // as NFT_MSG_DELSETELEM with just table+set name and
                // no element list (kernel interprets that as "all").
                let table = cmd.table.clone();
                let name = cmd.set_name.clone();
                let fam = cmd.family;
                self.send_batch(|msg| {
                    let pos = msg.begin_msg(NFT_MSG_DELSETELEM, fam, NLM_F_ACK);
                    msg.put_str(NFTA_SET_ELEM_LIST_TABLE, &table);
                    msg.put_str(NFTA_SET_ELEM_LIST_SET,   &name);
                    msg.end_msg(pos);
                })
            }
            _ => Err(io::Error::new(io::ErrorKind::Other, "unsupported flush target")),
        }
    }

    fn flush_table(&mut self, family: u8, table: &str) -> io::Result<()> {
        let tbl = table.to_string();
        self.send_batch(|msg| {
            let pos = msg.begin_msg(NFT_MSG_DELRULE, family, NLM_F_ACK);
            msg.put_str(NFTA_RULE_TABLE, &tbl);
            msg.end_msg(pos);
        })
    }

    fn flush_chain(&mut self, family: u8, table: &str, chain: &str) -> io::Result<()> {
        let tbl = table.to_string();
        let chn = chain.to_string();
        self.send_batch(|msg| {
            let pos = msg.begin_msg(NFT_MSG_DELRULE, family, NLM_F_ACK);
            msg.put_str(NFTA_RULE_TABLE, &tbl);
            msg.put_str(NFTA_RULE_CHAIN, &chn);
            msg.end_msg(pos);
        })
    }

    fn flush_ruleset(&mut self, _family: u8) -> io::Result<()> {
        // Inside an atomic batch GETTABLE won't see tables we
        // just added. Libnftables solves this by emitting one
        // DELTABLE with family NFPROTO_UNSPEC and no name
        // attribute; the kernel interprets that as "wipe every
        // table in every family" and it batches correctly.
        self.send_batch(|msg| {
            let pos = msg.begin_msg(NFT_MSG_DELTABLE, NFPROTO_UNSPEC, NLM_F_ACK);
            msg.end_msg(pos);
        })
    }

    // ── Rename / Replace ────────────────────────────────────────

    fn exec_rename(&mut self, cmd: &Command) -> io::Result<()> {
        if !matches!(cmd.obj, CmdObj::Chain) {
            return Err(io::Error::new(io::ErrorKind::Other, "rename only supported for chains"));
        }
        // Look up the chain handle
        let family = cmd.family;
        let table_f = cmd.table.clone();
        let chain_f = cmd.chain.clone();
        let mut chain_handle: Option<u64> = None;
        self.dump(NFT_MSG_GETCHAIN, family, |_, _| {}, |msg_type, _fam, data| {
            if msg_type == NFT_MSG_NEWCHAIN {
                let attrs = parse_attrs(data);
                let t = attrs.iter().find(|(t, _)| *t == NFTA_CHAIN_TABLE).map(|(_, v)| attr_str(v)).unwrap_or("");
                let c = attrs.iter().find(|(t, _)| *t == NFTA_CHAIN_NAME).map(|(_, v)| attr_str(v)).unwrap_or("");
                if t == table_f && c == chain_f {
                    chain_handle = attrs.iter().find(|(t, _)| *t == NFTA_CHAIN_HANDLE).map(|(_, v)| attr_u64_be(v));
                }
            }
        })?;
        let handle = chain_handle.ok_or_else(|| io::Error::new(io::ErrorKind::NotFound, format!("chain '{}' not found", cmd.chain)))?;

        let table = cmd.table.clone();
        let new_name = cmd.new_name.clone();
        self.send_batch(|msg| {
            let pos = msg.begin_msg(NFT_MSG_NEWCHAIN, family, NLM_F_ACK);
            msg.put_str(NFTA_CHAIN_TABLE, &table);
            msg.put_u64_be(NFTA_CHAIN_HANDLE, handle);
            msg.put_str(NFTA_CHAIN_NAME, &new_name);
            msg.end_msg(pos);
        })
    }

    fn exec_replace(&mut self, cmd: &Command) -> io::Result<()> {
        if !cmd.has_handle {
            return Err(io::Error::new(io::ErrorKind::Other, "replace requires handle"));
        }
        // Atomic replace uses a single NEWRULE message with NLM_F_REPLACE
        // and carries the target rule's existing handle in NFTA_RULE_HANDLE
        // (not NFTA_RULE_POSITION, which is used as an anchor for insert).
        // Delete-then-add would not be atomic and would move the rule to
        // the end of the chain.
        let family = cmd.family;
        let table = cmd.table.clone();
        let chain = cmd.chain.clone();
        let handle = cmd.handle;
        // Lower any anon-set literals (`replace rule handle N ... { a, b }`)
        // into NEWSET+NEWSETELEM preambles ahead of the replace.
        let has_anon = cmd.exprs.iter().any(|e| matches!(e,
            Expr::AnonSet { .. } | Expr::AnonVmap { .. }));
        if has_anon {
            let _ = self.bump_anon_counter_past_existing(family, &table);
        }
        let (exprs, anon_plans) = self.lower_anon_sets(&cmd.exprs);
        let comment = if cmd.has_comment { Some(cmd.comment.clone()) } else { None };
        let table_ref = table.clone();
        self.send_batch(|msg| {
            Self::emit_anon_sets(msg, family, &table_ref, &anon_plans);
            let pos = msg.begin_msg(NFT_MSG_NEWRULE, family,
                NLM_F_REPLACE | NLM_F_ACK);
            msg.put_str(NFTA_RULE_TABLE, &table);
            msg.put_str(NFTA_RULE_CHAIN, &chain);
            msg.put_u64_be(NFTA_RULE_HANDLE, handle);
            if let Some(ref c) = comment {
                let cb = c.as_bytes();
                let mut tlv = Vec::with_capacity(cb.len() + 3);
                tlv.push(0u8);
                tlv.push((cb.len() + 1) as u8);
                tlv.extend_from_slice(cb);
                tlv.push(0u8);
                msg.put_bytes(NFTA_RULE_USERDATA, &tlv);
            }
            let exprs_nest = msg.begin_nested(NFTA_RULE_EXPRESSIONS);
            for expr in &exprs { compile_expr(msg, expr); }
            msg.end_nested(exprs_nest);
            msg.end_msg(pos);
        })
    }

    // ── Sets ────────────────────────────────────────────────────

    fn add_set(&mut self, cmd: &Command) -> io::Result<()> {
        let family = cmd.family;
        let table = cmd.table.clone();
        let set_name = cmd.set_name.clone();
        let spec = cmd.set_spec.clone();
        let comment = if cmd.has_comment { Some(cmd.comment.clone()) } else { None };
        {
            self.pending_sets.insert(
                (family, table.clone(), set_name.clone()),
                SetInfo {
                    interval: spec.flags & NFT_SET_INTERVAL != 0,
                    key_len: spec.key_len,
                    key_type: spec.key_type,
                    data_len: spec.data_len,
                    data_type: spec.data_type,
                },
            );
        }
        let excl = matches!(cmd.op, CmdOp::Create);
        self.send_batch(move |msg| {
            let mut flags_nlm = NLM_F_CREATE | NLM_F_ACK;
            if excl { flags_nlm |= NLM_F_EXCL; }
            let pos = msg.begin_msg(NFT_MSG_NEWSET, family, flags_nlm);
            msg.put_str(NFTA_SET_TABLE, &table);
            msg.put_str(NFTA_SET_NAME, &set_name);
            msg.put_u32_be(NFTA_SET_KEY_TYPE, spec.key_type);
            msg.put_u32_be(NFTA_SET_KEY_LEN, spec.key_len);
            let mut flags = spec.flags;
            // Object-reference maps (type KEY : counter/quota/...) use
            // NFT_SET_OBJECT only, NOT NFT_SET_MAP — the kernel treats them
            // differently. Regular verdict/data maps use NFT_SET_MAP.
            if spec.is_obj_map {
                flags |= NFT_SET_OBJECT;
            } else if spec.is_map {
                flags |= NFT_SET_MAP;
            }
            if flags != 0 {
                msg.put_u32_be(NFTA_SET_FLAGS, flags);
            }
            if spec.is_obj_map {
                // Object-reference maps use NFTA_SET_OBJ_TYPE instead of
                // NFTA_SET_DATA_TYPE; the kernel infers data width from the
                // object kind, so DATA_LEN is not sent.
                msg.put_u32_be(NFTA_SET_OBJ_TYPE, spec.obj_type);
            } else if spec.is_map && spec.data_type_name == "verdict" {
                // Verdict maps use the special NFT_DATA_VERDICT sentinel
                // (not a real type index) and zero-length data.
                msg.put_u32_be(NFTA_SET_DATA_TYPE, 0xffffff00);
                msg.put_u32_be(NFTA_SET_DATA_LEN, 0);
            } else if spec.is_map && spec.data_type > 0 {
                msg.put_u32_be(NFTA_SET_DATA_TYPE, spec.data_type);
                msg.put_u32_be(NFTA_SET_DATA_LEN, spec.data_len);
            }
            // Emit NFTA_SET_DESC → NFTA_SET_DESC_SIZE only when the user
            // explicitly wrote `size N` in the set declaration.  nft wire
            // analysis confirms this is the sole trigger: plain sets, interval
            // sets, verdict maps, and anonymous sets never carry SET_DESC in
            // nft's sendmsg output unless `size` was spelled out.
            if spec.size > 0 {
                let desc = msg.begin_nested(NFTA_SET_DESC);
                msg.put_u32_be(NFTA_SET_DESC_SIZE, spec.size);
                msg.end_nested(desc);
            }
            // Default per-element timeout — emitted as u64 NBO
            // milliseconds. nft list reads it back as `timeout 1m`.
            if spec.has_timeout && spec.timeout_ms > 0 {
                msg.put_u64_be(NFTA_SET_TIMEOUT, spec.timeout_ms);
            }
            // Set comment stored as NFTA_SET_USERDATA with the same TLV
            // encoding chain/rule comments use:
            //   [u8 type=0][u8 len = string_len + 1][bytes][NUL]
            // NFTNL_UDATA_SET_COMMENT = 0.
            if let Some(ref c) = comment {
                let cb = c.as_bytes();
                let mut tlv = Vec::with_capacity(cb.len() + 3);
                tlv.push(0u8);                   // type: SET_COMMENT
                tlv.push((cb.len() + 1) as u8);  // length: string + NUL
                tlv.extend_from_slice(cb);
                tlv.push(0u8);                   // NUL terminator
                msg.put_bytes(NFTA_SET_USERDATA, &tlv);
            }
            msg.put_u32_be(NFTA_SET_ID, 1);
            msg.end_msg(pos);
        })
    }

    fn list_sets(&mut self, family: u8) -> io::Result<()> {
        // `list sets` groups output by containing table, to mirror
        // what real nft does — `table ip nat { set ssh { ... } }`.
        // Collect all sets, group by (family, table), then emit.
        let mut all: Vec<(u8, String, Vec<(u16, Vec<u8>)>)> = Vec::new();
        self.dump(NFT_MSG_GETSET, family, |_, _| {}, |msg_type, fam, data| {
            if msg_type == NFT_MSG_NEWSET {
                let attrs = parse_attrs(data);
                let tname = attrs.iter().find(|(t, _)| *t == NFTA_SET_TABLE)
                    .map(|(_, v)| attr_str(v).to_string()).unwrap_or_default();
                all.push((fam, tname, attrs.into_iter().map(|(t,v)| (t,v.to_vec())).collect()));
            }
        })?;

        // Also enumerate tables so we can emit empty tables too when
        // they exist but have no sets. Upstream does this.
        let mut tables: Vec<(u8, String)> = Vec::new();
        self.dump(NFT_MSG_GETTABLE, family, |_, _| {}, |mt, fam, data| {
            if mt == NFT_MSG_NEWTABLE {
                let a = parse_attrs(data);
                let n = a.iter().find(|(t, _)| *t == NFTA_TABLE_NAME)
                    .map(|(_, v)| attr_str(v).to_string()).unwrap_or_default();
                tables.push((fam, n));
            }
        })?;

        for (fam, tname) in &tables {
            println!("table {} {} {{", family_str(*fam), tname);
            for (sfam, stable, sattrs) in &all {
                if *sfam == *fam && stable == tname {
                    output::print_set_header(*sfam, sattrs);
                }
            }
            println!("}}");
        }
        Ok(())
    }

    // ── Named stateful objects (counter / quota / limit) ──────
    //
    // Kernel UAPI: NFT_MSG_NEWOBJ carries NFTA_OBJ_TABLE / NAME /
    // TYPE, plus a nested NFTA_OBJ_DATA whose attribute namespace is
    // type-specific (shared with the in-rule expressions where
    // applicable — counter uses the same NFTA_COUNTER_* constants).

    fn add_object(&mut self, cmd: &Command) -> io::Result<()> {
        let family = cmd.family;
        let table = cmd.table.clone();
        let name = cmd.set_name.clone();
        let spec = cmd.obj_spec.clone();
        let obj_comment = if cmd.has_comment { Some(cmd.comment.clone()) } else { None };
        self.send_batch(|msg| {
            let pos = msg.begin_msg(NFT_MSG_NEWOBJ, family, NLM_F_CREATE | NLM_F_ACK);
            msg.put_str(NFTA_OBJ_TABLE, &table);
            msg.put_str(NFTA_OBJ_NAME, &name);
            msg.put_u32_be(NFTA_OBJ_TYPE, spec.kind);
            let data = msg.begin_nested(NFTA_OBJ_DATA);
            match spec.kind {
                NFT_OBJECT_COUNTER => {
                    msg.put_u64_be(NFTA_COUNTER_PACKETS, spec.packets);
                    msg.put_u64_be(NFTA_COUNTER_BYTES, spec.bytes);
                }
                NFT_OBJECT_QUOTA => {
                    msg.put_u64_be(NFTA_QUOTA_BYTES, spec.bytes);
                    if spec.quota_consumed > 0 {
                        msg.put_u64_be(NFTA_QUOTA_CONSUMED, spec.quota_consumed);
                    }
                    msg.put_u32_be(NFTA_QUOTA_FLAGS, spec.quota_flags);
                }
                NFT_OBJECT_LIMIT => {
                    msg.put_u64_be(NFTA_LIMIT_RATE, spec.limit_rate);
                    msg.put_u64_be(NFTA_LIMIT_UNIT, if spec.limit_unit == 0 { 1 } else { spec.limit_unit });
                    msg.put_u32_be(NFTA_LIMIT_BURST, spec.limit_burst);
                    msg.put_u32_be(NFTA_LIMIT_TYPE, spec.limit_type);
                    msg.put_u32_be(NFTA_LIMIT_FLAGS, spec.limit_flags);
                }
                NFT_OBJECT_CT_HELPER => {
                    // NFTA_CT_HELPER_NAME holds the kernel helper module
                    // name (`"ftp"`, `"sip"`, ...), not the user-facing
                    // object name — that one travels outside this nest
                    // as NFTA_OBJ_NAME. NFTA_CT_HELPER_L4PROTO is a u8
                    // (kernel reads a single byte). NFTA_CT_HELPER_L3PROTO
                    // is u16 in network byte order; only emitted when
                    // the source asked for a specific family — the
                    // kernel otherwise defaults to the table family.
                    msg.put_str(NFTA_CT_HELPER_NAME, &spec.helper_type);
                    if spec.has_helper_l3proto {
                        msg.put_u16_be(NFTA_CT_HELPER_L3PROTO, spec.helper_l3proto);
                    }
                    msg.put_u8(NFTA_CT_HELPER_L4PROTO, spec.helper_l4proto);
                }
                NFT_OBJECT_CT_TIMEOUT => {
                    // L4PROTO is u8. L3PROTO (u16 NBO) is only sent
                    // when explicitly specified via the `l3proto`
                    // keyword; upstream nft omits it, relying on
                    // nfgen_family in the netlink header instead.
                    // DATA is a nested attribute set where each child's
                    // type ID is the conntrack state index and the value
                    // is a u32 NBO timeout in seconds.
                    msg.put_u8(NFTA_CT_TIMEOUT_L4PROTO, spec.ct_timeout_l4proto as u8);
                    if spec.has_ct_timeout_l3proto {
                        msg.put_u16_be(NFTA_CT_TIMEOUT_L3PROTO, spec.ct_timeout_l3proto);
                    }
                    if !spec.ct_timeout_policy.is_empty() {
                        let tdata = msg.begin_nested(NFTA_CT_TIMEOUT_DATA);
                        let l4 = spec.ct_timeout_l4proto;
                        for (state, secs) in &spec.ct_timeout_policy {
                            let id = timeout_state_id(l4, state);
                            if id > 0 {
                                msg.put_u32_be(id, *secs);
                            }
                        }
                        msg.end_nested(tdata);
                    }
                }
                NFT_OBJECT_CT_EXPECT => {
                    // All attributes go directly inside NFTA_OBJ_DATA.
                    msg.put_u16_be(NFTA_CT_EXPECT_L3PROTO, spec.ct_expect_l3proto);
                    msg.put_u8(NFTA_CT_EXPECT_PROTOCOL, spec.ct_expect_protocol);
                    if spec.ct_expect_dport != 0 {
                        msg.put_u16_be(NFTA_CT_EXPECT_DPORT, spec.ct_expect_dport);
                    }
                    msg.put_u32(NFTA_CT_EXPECT_TIMEOUT, spec.ct_expect_timeout);
                    msg.put_u8(NFTA_CT_EXPECT_SIZE, spec.ct_expect_size);
                }
                NFT_OBJECT_SYNPROXY => {
                    msg.put_u16_be(NFTA_SYNPROXY_MSS, spec.synproxy_mss);
                    msg.put_u8(NFTA_SYNPROXY_WSCALE, spec.synproxy_wscale);
                    msg.put_u32_be(NFTA_SYNPROXY_FLAGS, spec.synproxy_flags);
                }
                NFT_OBJECT_SECMARK => {
                    msg.put_str(NFTA_SECMARK_CTX, &spec.secmark_ctx);
                }
                NFT_OBJECT_TUNNEL => {
                    msg.put_u32_be(NFTA_TUNNEL_KEY_ID, spec.tunnel_id);
                    if spec.tunnel_is_v6 {
                        let ip6 = msg.begin_nested(NFTA_TUNNEL_KEY_IP6);
                        msg.put_bytes(NFTA_TUNNEL_KEY_IP6_SRC, &spec.tunnel_src_v6);
                        msg.put_bytes(NFTA_TUNNEL_KEY_IP6_DST, &spec.tunnel_dst_v6);
                        msg.end_nested(ip6);
                    } else {
                        let ip4 = msg.begin_nested(NFTA_TUNNEL_KEY_IP);
                        msg.put_bytes(NFTA_TUNNEL_KEY_IP_SRC, &spec.tunnel_src_v4);
                        msg.put_bytes(NFTA_TUNNEL_KEY_IP_DST, &spec.tunnel_dst_v4);
                        msg.end_nested(ip4);
                    }
                    msg.put_u16_be(NFTA_TUNNEL_KEY_SPORT, spec.tunnel_sport);
                    msg.put_u16_be(NFTA_TUNNEL_KEY_DPORT, spec.tunnel_dport);
                    msg.put_u32_be(NFTA_TUNNEL_KEY_FLAGS, spec.tunnel_flags);
                    msg.put_u8(NFTA_TUNNEL_KEY_TOS, spec.tunnel_tos);
                    msg.put_u8(NFTA_TUNNEL_KEY_TTL, spec.tunnel_ttl);
                    match &spec.tunnel_opts {
                        TunnelOpts::Geneve { tlvs } if !tlvs.is_empty() => {
                            let opts = msg.begin_nested(NFTA_TUNNEL_KEY_OPTS);
                            for tlv in tlvs {
                                let gn = msg.begin_nested(NFTA_TUNNEL_KEY_OPTS_GENEVE);
                                msg.put_u16_be(NFTA_TUNNEL_KEY_GENEVE_CLASS, tlv.class);
                                msg.put_u8(NFTA_TUNNEL_KEY_GENEVE_TYPE, tlv.opt_type);
                                msg.put_bytes(NFTA_TUNNEL_KEY_GENEVE_DATA, &tlv.data);
                                msg.end_nested(gn);
                            }
                            msg.end_nested(opts);
                        }
                        TunnelOpts::Vxlan { gbp } => {
                            let opts = msg.begin_nested(NFTA_TUNNEL_KEY_OPTS);
                            let vx = msg.begin_nested(NFTA_TUNNEL_KEY_OPTS_VXLAN);
                            msg.put_u32_be(NFTA_TUNNEL_KEY_VXLAN_GBP, *gbp);
                            msg.end_nested(vx);
                            msg.end_nested(opts);
                        }
                        TunnelOpts::ErspanV1 { index } => {
                            let opts = msg.begin_nested(NFTA_TUNNEL_KEY_OPTS);
                            let es = msg.begin_nested(NFTA_TUNNEL_KEY_OPTS_ERSPAN);
                            msg.put_u32_be(NFTA_TUNNEL_KEY_ERSPAN_VERSION, 1);
                            msg.put_u32_be(NFTA_TUNNEL_KEY_ERSPAN_V1_INDEX, *index);
                            msg.end_nested(es);
                            msg.end_nested(opts);
                        }
                        TunnelOpts::ErspanV2 { hwid, dir } => {
                            let opts = msg.begin_nested(NFTA_TUNNEL_KEY_OPTS);
                            let es = msg.begin_nested(NFTA_TUNNEL_KEY_OPTS_ERSPAN);
                            msg.put_u32_be(NFTA_TUNNEL_KEY_ERSPAN_VERSION, 2);
                            msg.put_u8(NFTA_TUNNEL_KEY_ERSPAN_V2_HWID, *hwid);
                            msg.put_u8(NFTA_TUNNEL_KEY_ERSPAN_V2_DIR, *dir);
                            msg.end_nested(es);
                            msg.end_nested(opts);
                        }
                        _ => {}
                    }
                }
                _ => {}
            }
            msg.end_nested(data);
            // Object comment: NFTA_OBJ_USERDATA, same TLV as chain/rule.
            if let Some(ref c) = obj_comment {
                let cb = c.as_bytes();
                let mut tlv = Vec::with_capacity(cb.len() + 3);
                tlv.push(0u8);                   // type: COMMENT
                tlv.push((cb.len() + 1) as u8);  // length: string + NUL
                tlv.extend_from_slice(cb);
                tlv.push(0u8);                   // NUL terminator
                msg.put_bytes(NFTA_OBJ_USERDATA, &tlv);
            }
            msg.end_msg(pos);
        })
    }

    /// Encode a flowtable declaration as NFT_MSG_NEWFLOWTABLE. The
    /// flowtable lives directly inside the table — not under
    /// NFTA_OBJ_DATA — and carries its own attribute set: TABLE, NAME,
    /// HOOK (nested NUM/PRIORITY/DEVS), and optional FLAGS.
    fn add_flowtable(&mut self, cmd: &Command) -> io::Result<()> {
        let family = cmd.family;
        let table = cmd.table.clone();
        let name = cmd.set_name.clone();
        let spec = cmd.flow_spec.clone();
        let mut nlm_flags = NLM_F_CREATE | NLM_F_ACK;
        if matches!(cmd.op, CmdOp::Create) { nlm_flags |= NLM_F_EXCL; }
        if self.echo { nlm_flags |= NLM_F_ECHO; }
        self.send_batch(|msg| {
            let pos = msg.begin_msg(NFT_MSG_NEWFLOWTABLE, family, nlm_flags);
            msg.put_str(NFTA_FLOWTABLE_TABLE, &table);
            msg.put_str(NFTA_FLOWTABLE_NAME, &name);

            // Hook nest: NUM (always 0 = NF_NETDEV_INGRESS for flowtables
            // — the only hook the kernel supports), PRIORITY (s32 NBO),
            // and a DEVS sub-nest of NFTA_DEVICE_NAME strings.
            let hook_nest = msg.begin_nested(NFTA_FLOWTABLE_HOOK);
            let hooknum = match spec.hook.as_str() {
                "ingress" => 0u32,
                _ => 0,
            };
            msg.put_u32_be(NFTA_FLOWTABLE_HOOK_NUM, hooknum);
            // Default priority is 0 (`filter`); kernel rejects the message
            // if the attribute is missing, so always emit it.
            let prio = if spec.has_priority { spec.priority } else { 0 };
            msg.put_u32_be(NFTA_FLOWTABLE_HOOK_PRIORITY, prio as u32);
            if !spec.devices.is_empty() {
                let devs_nest = msg.begin_nested(NFTA_FLOWTABLE_HOOK_DEVS);
                for dev in &spec.devices {
                    msg.put_str(NFTA_DEVICE_NAME, dev);
                }
                msg.end_nested(devs_nest);
            }
            msg.end_nested(hook_nest);

            if spec.flags != 0 {
                msg.put_u32_be(NFTA_FLOWTABLE_FLAGS, spec.flags);
            }
            msg.end_msg(pos);
        })
    }

    fn delete_object(&mut self, cmd: &Command) -> io::Result<()> {
        let family = cmd.family;
        let table = cmd.table.clone();
        let name = cmd.set_name.clone();
        let kind = cmd.obj_spec.kind;
        let by_handle = cmd.has_handle;
        let handle = cmd.handle;
        self.send_batch(|msg| {
            let pos = msg.begin_msg(NFT_MSG_DELOBJ, family, NLM_F_ACK);
            msg.put_str(NFTA_OBJ_TABLE, &table);
            if by_handle {
                msg.put_u64_be(NFTA_OBJ_HANDLE, handle);
            } else {
                msg.put_str(NFTA_OBJ_NAME, &name);
            }
            msg.put_u32_be(NFTA_OBJ_TYPE, kind);
            msg.end_msg(pos);
        })
    }

    // ── Elements ───────────────────────────────────────────────

    fn add_elements(&mut self, cmd: &Command) -> io::Result<()> {
        let family = cmd.family;
        let table = cmd.table.clone();
        let set_name = cmd.set_name.clone();

        // Probe the target set for interval flag, key/data lengths
        // and types. The parser may have encoded elements at the
        // wrong width (e.g. port as u32 instead of u16 in a concat
        // key, or queue data value as u32 BE instead of u16 NE).
        let si = self.probe_set_info(family, &table, &set_name)?;
        let interval_flag = si.interval;
        let set_key_len = si.key_len;

        // Interval-set backends (rbtree/pipapo) return EEXIST when an
        // identical element is re-added even without NLM_F_EXCL —
        // that breaks `-f` round-trips where the save file already
        // contains every live element. Pre-dump what's there and
        // drop duplicates from this add. Non-interval sets tolerate
        // re-adds natively, so the filter is skipped for them.
        // `create element` (vs plain `add`) wants the EEXIST to
        // surface, so skip the dedupe in that case.
        let is_create = matches!(cmd.op, CmdOp::Create);
        let existing: Vec<Vec<u8>> = if interval_flag && !is_create {
            self.set_element_keys(family, &table, &set_name).unwrap_or_default()
        } else { Vec::new() };

        // Re-encode concat keys when the parser lacked concat_widths
        // (standalone `add element` commands).  Table-block and inline
        // elements already have correct per-slot encoding from the
        // parser's own concat_widths; re-encoding those would corrupt
        // the key by treating an already-narrowed MSB value as u32.
        let kt = si.key_type;
        let need_concat_fixup = cmd.set_spec.concat_widths.is_empty()
            && unpack_dtype_widths(kt).len() > 1;
        let fix_key = |k: &[u8]| -> Vec<u8> {
            let c = if need_concat_fixup { reencode_concat_key(k, kt) } else { k.to_vec() };
            resize_key(&c, set_key_len)
        };
        // When inside an atomic batch, a duplicate `add element` for an
        // object-reference map (type KEY : counter/quota/…) causes the
        // kernel to increment the stateful object's refcount twice even
        // though only one element row is stored.  A subsequent
        // `delete element` then decrements it once, leaving the counter
        // busy when `delete counter` fires — EBUSY — even inside a
        // single batch.  Detect this by tracking which element keys have
        // already been buffered for this (family, table, set) in the
        // current transaction and skip re-adds of the same key.
        // `create element` is excluded because the EEXIST must surface.
        let batch_pending_key = (family, table.clone(), set_name.clone());
        let skip_in_batch_dupes = self.batch.is_some() && !is_create;
        // Build a per-input-index mask of which elements pass all filters
        // so that both `elements` and `kept` (parallel structures) apply
        // the same dedup logic and stay index-aligned.
        let keep_mask: Vec<bool> = cmd.elements.iter()
            .map(|(k, _)| {
                let ek = fix_key(k);
                if existing.iter().any(|e| *e == ek) { return false; }
                if skip_in_batch_dupes {
                    if let Some(seen) = self.pending_elem_keys.get(&batch_pending_key) {
                        if seen.contains(&ek) { return false; }
                    }
                }
                true
            }).collect();
        let elements: Vec<(Vec<u8>, Option<Vec<u8>>)> = cmd.elements.iter()
            .zip(keep_mask.iter())
            .filter(|(_, &keep)| keep)
            .map(|((k, e), _)| {
                let rk = fix_key(k);
                let re = e.as_ref().map(|v| fix_key(v));
                if re.is_none() && interval_flag {
                    (rk.clone(), Some(rk))
                } else {
                    (rk, re)
                }
            }).collect();

        if elements.is_empty() { return Ok(()); }

        // Parallel data list for data-valued maps (ipv4->ipv4 etc.) —
        // built first because it's our disambiguator: an entry in
        // element_verdicts paired with Some data means the parser saw
        // a data value (and pushed a (0, "") sentinel to keep the
        // verdict list index-aligned). An entry paired with None data
        // is an actual verdict.
        let datas: Vec<Option<Vec<u8>>> = if cmd.element_datas.is_empty() {
            vec![None; cmd.elements.len()]
        } else {
            cmd.elements.iter().enumerate().map(|(i, _)| {
                cmd.element_datas.get(i).cloned().flatten()
            }).collect()
        };
        // Verdict list. Earlier we filtered out `(0, "")` to dodge the
        // data-map sentinel, but that also erased real `drop` verdicts
        // (NF_DROP == 0) — `add element vt { 1.1.1.1 : drop }` then
        // landed without DATA and the kernel rejected the apply with
        // EINVAL. Use the data column to distinguish: if data is Some
        // at this index, the verdict slot holds the (0, "") sentinel
        // and we ignore it; otherwise the verdict tuple is real.
        let verdicts: Vec<Option<(i32, String)>> = if cmd.element_verdicts.is_empty() {
            vec![None; cmd.elements.len()]
        } else {
            cmd.elements.iter().enumerate().map(|(i, _)| {
                if datas.get(i).cloned().flatten().is_some() {
                    None
                } else {
                    cmd.element_verdicts.get(i).cloned()
                }
            }).collect()
        };
        // Per-element timeouts parallel to cmd.elements; 0 means "no
        // override". Padded so a partial element_timeouts list (only
        // some keys had `timeout`) lines up by index.
        let timeouts: Vec<u64> = if cmd.element_timeouts.is_empty() {
            vec![0; cmd.elements.len()]
        } else {
            cmd.elements.iter().enumerate().map(|(i, _)| {
                cmd.element_timeouts.get(i).copied().unwrap_or(0)
            }).collect()
        };
        // Per-element comments parallel to cmd.elements; None means no comment.
        let comments: Vec<Option<String>> = if cmd.element_comments.is_empty() {
            vec![None; cmd.elements.len()]
        } else {
            cmd.elements.iter().enumerate().map(|(i, _)| {
                cmd.element_comments.get(i).cloned().flatten()
            }).collect()
        };
        // Per-element object references parallel to cmd.elements; None means
        // no objref (use DATA instead). Used for `type foo : counter` maps.
        let objrefs: Vec<Option<String>> = if cmd.element_objrefs.is_empty() {
            vec![None; cmd.elements.len()]
        } else {
            cmd.elements.iter().enumerate().map(|(i, _)| {
                cmd.element_objrefs.get(i).cloned().flatten()
            }).collect()
        };
        // Drop verdicts/datas/timeouts/comments/objrefs for elements
        // that were filtered out by keep_mask (existing dedup or
        // in-batch duplicate dedup).  The mask keeps both `elements`
        // and `kept` index-aligned so kept.get(i) in the send loop
        // always corresponds to elements[i].
        let kept: Vec<(Option<(i32, String)>, Option<Vec<u8>>, u64, Option<String>, Option<String>)> =
            verdicts.iter()
            .zip(datas.iter().zip(timeouts.iter().zip(comments.iter().zip(objrefs.iter()))))
            .zip(keep_mask.iter())
            .filter(|(_, &keep)| keep)
            .map(|((v, (d, (t, (c, r)))), _)| (v.clone(), d.clone(), *t, c.clone(), r.clone()))
            .collect();

        let excl = matches!(cmd.op, CmdOp::Create);
        // Record the element keys we are about to buffer so that a
        // later duplicate `add element` in the same batch can detect
        // and skip them.  Only meaningful in batch mode; for non-batch
        // (interactive / per-command) calls this map is always empty.
        if skip_in_batch_dupes {
            let seen = self.pending_elem_keys
                .entry(batch_pending_key)
                .or_default();
            for (k, _) in &elements {
                seen.insert(k.clone());
            }
        }
        self.send_batch(move |msg| {
            let mut flags_nlm = NLM_F_CREATE | NLM_F_ACK;
            if excl { flags_nlm |= NLM_F_EXCL; }
            // The nested NFTA_SET_ELEM_LIST_ELEMENTS attribute uses a u16
            // nla_len, so it caps at 65535 bytes. A single NEWSETELEM
            // message holding ~4090+ ipv4 elements overflows that limit
            // and the kernel rejects the malformed encoding (surfaced as
            // recvmsg ENOENT). Real nft splits the run across multiple
            // NEWSETELEM messages inside the same BATCH_BEGIN…BATCH_END
            // transaction so the kernel still applies them atomically.
            // 60000 is a safe ceiling that leaves headroom for the
            // outer message framing the kernel adds on top.
            const SPLIT_THRESHOLD: usize = 60000;
            let mut pos = msg.begin_msg(NFT_MSG_NEWSETELEM, family, flags_nlm);
            msg.put_str(NFTA_SET_ELEM_LIST_TABLE, &table);
            msg.put_str(NFTA_SET_ELEM_LIST_SET, &set_name);
            let mut elems_nest = msg.begin_nested(NFTA_SET_ELEM_LIST_ELEMENTS);
            for (i, (key, range_end)) in elements.iter().enumerate() {
                // Roll over to a fresh NEWSETELEM message when the
                // current one is approaching the u16 nla_len ceiling.
                // Done before emitting this element so we never split
                // mid-element. Only roll if we have at least one
                // element already encoded in this message.
                if msg.buf.len() - pos > SPLIT_THRESHOLD && msg.buf.len() > elems_nest + 4 {
                    msg.end_nested(elems_nest);
                    msg.end_msg(pos);
                    pos = msg.begin_msg(NFT_MSG_NEWSETELEM, family, flags_nlm);
                    msg.put_str(NFTA_SET_ELEM_LIST_TABLE, &table);
                    msg.put_str(NFTA_SET_ELEM_LIST_SET, &set_name);
                    elems_nest = msg.begin_nested(NFTA_SET_ELEM_LIST_ELEMENTS);
                }
                let elem = msg.begin_nested(NFTA_LIST_ELEM);
                msg.put_data_value(NFTA_SET_ELEM_KEY, key);
                let (maybe_verdict, maybe_data, etimeout, ecmt, maybe_objref) = kept.get(i)
                    .cloned().unwrap_or((None, None, 0, None, None));
                if let Some(objref_name) = maybe_objref {
                    // Object-reference map element: send the stateful
                    // object name as NFTA_SET_ELEM_OBJREF (attr 9).
                    msg.put_str(NFTA_SET_ELEM_OBJREF, &objref_name);
                } else if let Some((code, chain)) = maybe_verdict {
                    let d = msg.begin_nested(NFTA_SET_ELEM_DATA);
                    let vd = msg.begin_nested(NFTA_DATA_VERDICT);
                    msg.put_u32_be(NFTA_VERDICT_CODE, code as u32);
                    if !chain.is_empty() {
                        msg.put_str(NFTA_VERDICT_CHAIN, &chain);
                    }
                    msg.end_nested(vd);
                    msg.end_nested(d);
                } else if let Some(bytes) = maybe_data {
                    // NFTA_SET_ELEM_DATA nests NFTA_DATA_VALUE for
                    // non-verdict mapping values (ipv4/integer/ifname).
                    // The parser always encodes integers as u32 BE;
                    // narrow to the set's declared data_len and fix
                    // byte order for host-endian types (queue, mark).
                    let db = if si.data_len > 0 {
                        reencode_data_value(&bytes, si.data_len, si.data_type)
                    } else {
                        bytes
                    };
                    msg.put_data_value(NFTA_SET_ELEM_DATA, &db);
                }
                if etimeout > 0 {
                    // Per-element timeout override — kernel only accepts
                    // it on sets that carry NFT_SET_TIMEOUT, which we
                    // don't re-validate here; the kernel rejects with
                    // EINVAL otherwise and the user sees the upstream
                    // error message verbatim.
                    msg.put_u64_be(NFTA_SET_ELEM_TIMEOUT, etimeout);
                }
                // Per-element comment stored as NFTA_SET_ELEM_USERDATA
                // with the same TLV encoding used for rule / chain / set
                // comments: [u8 type=0][u8 len][bytes][NUL].
                if let Some(ref c) = ecmt {
                    let cb = c.as_bytes();
                    let mut tlv = Vec::with_capacity(cb.len() + 3);
                    tlv.push(0u8);                   // type: ELEM_COMMENT
                    tlv.push((cb.len() + 1) as u8);  // length: string + NUL
                    tlv.extend_from_slice(cb);
                    tlv.push(0u8);                   // NUL terminator
                    msg.put_bytes(NFTA_SET_ELEM_USERDATA, &tlv);
                }
                msg.end_nested(elem);
                if let Some(end) = range_end {
                    let mut end_plus = end.clone();
                    for byte in end_plus.iter_mut().rev() {
                        if *byte == 0xff { *byte = 0; } else { *byte += 1; break; }
                    }
                    let elem2 = msg.begin_nested(NFTA_LIST_ELEM);
                    msg.put_data_value(NFTA_SET_ELEM_KEY, &end_plus);
                    msg.put_u32_be(NFTA_SET_ELEM_FLAGS, NFT_SET_ELEM_INTERVAL_END);
                    msg.end_nested(elem2);
                }
            }
            msg.end_nested(elems_nest);
            msg.end_msg(pos);
        })
    }

    // Dump every element of (family, table, set) and return the raw
    // NFTA_DATA_VALUE bytes of each NFTA_SET_ELEM_KEY. Elements marked
    // with NFT_SET_ELEM_INTERVAL_END are skipped — they're the
    // kernel's end-sentinel for interval sets, not a user-visible
    // member. Used by list_json to fill the `"elem": [...]` array.
    // Walk every set in this table and build the output::AnonSetRegistry
    // a rule printer needs to inline `@__setN` lookups. We include named
    // sets too so `ip saddr @named` can also resolve — but anon sets are
    // the ones that actually need the inline rewrite; named sets stay as
    // `@name` (the rule printer checks the `__set` prefix before inlining).
    fn collect_anon_sets(&mut self, family: u8, table: &str) -> io::Result<output::AnonSetRegistry> {
        let tbl = table.to_string();
        let mut sets: Vec<Vec<(u16, Vec<u8>)>> = Vec::new();
        self.dump(NFT_MSG_GETSET, family, |_, _| {}, |mt, _, data| {
            if mt != NFT_MSG_NEWSET { return; }
            let a = parse_attrs(data);
            let t = a.iter().find(|(t, _)| *t == NFTA_SET_TABLE)
                .map(|(_, v)| attr_str(v)).unwrap_or("");
            // Filter to anon sets only. Named sets render as `@name`
            // in the rule printer regardless of element contents, so
            // dumping their elements here is pure waste — and on a
            // 200-prefix named interval set it's 5x of total list time.
            // Anon sets get kernel-assigned names with the `__setN` /
            // `__mapN` prefix, so a name-prefix check is enough.
            let name = a.iter().find(|(t, _)| *t == NFTA_SET_NAME)
                .map(|(_, v)| attr_str(v).to_string()).unwrap_or_default();
            let is_anon = name.starts_with("__set") || name.starts_with("__map");
            if t == tbl && is_anon { sets.push(a.into_iter().map(|(t,v)| (t,v.to_vec())).collect()); }
        })?;

        let mut reg = output::AnonSetRegistry::default();
        for attrs in &sets {
            let name = attrs.iter().find(|(t, _)| *t == NFTA_SET_NAME)
                .map(|(_, v)| attr_str(v).to_string()).unwrap_or_default();
            let key_type = attrs.iter().find(|(t, _)| *t == NFTA_SET_KEY_TYPE)
                .map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
            let key_len = attrs.iter().find(|(t, _)| *t == NFTA_SET_KEY_LEN)
                .map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
            let flags = attrs.iter().find(|(t, _)| *t == NFTA_SET_FLAGS)
                .map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
            let is_interval = flags & NFT_SET_INTERVAL != 0;
            let is_map = flags & NFT_SET_MAP != 0;

            let tn = tbl.clone();
            let sn = name.clone();
            let mut raw: Vec<(Vec<u8>, bool, Option<(i32, String)>)> = Vec::new();
            self.dump(NFT_MSG_GETSETELEM, family, |msg, pos| {
                msg.put_str(NFTA_SET_ELEM_LIST_TABLE, &tn);
                msg.put_str(NFTA_SET_ELEM_LIST_SET, &sn);
                msg.end_msg(pos);
            }, |mt, _, data| {
                if mt != NFT_MSG_NEWSETELEM { return; }
                let a = parse_attrs(data);
                if let Some((_, list)) = a.iter().find(|(t, _)| *t == NFTA_SET_ELEM_LIST_ELEMENTS) {
                    for (_, eb) in parse_attrs(list) {
                        let ea = parse_attrs(&eb);
                        let eflags = ea.iter().find(|(t, _)| *t == NFTA_SET_ELEM_FLAGS)
                            .map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
                        // For vmaps the element's NFTA_SET_ELEM_DATA wraps a
                        // NFTA_DATA_VERDICT with CODE (and optionally CHAIN).
                        let vdict = ea.iter().find(|(t, _)| *t == NFTA_SET_ELEM_DATA)
                            .and_then(|(_, d)| {
                                let inner = parse_attrs(d);
                                inner.iter().find(|(t, _)| *t == NFTA_DATA_VERDICT)
                                    .map(|(_, vd)| {
                                        let v = parse_attrs(vd);
                                        let code = v.iter().find(|(t, _)| *t == NFTA_VERDICT_CODE)
                                            .map(|(_, x)| attr_u32_be(x) as i32).unwrap_or(0);
                                        let chain = v.iter().find(|(t, _)| *t == NFTA_VERDICT_CHAIN)
                                            .map(|(_, x)| attr_str(x).to_string()).unwrap_or_default();
                                        (code, chain)
                                    })
                            });
                        if let Some((_, k)) = ea.iter().find(|(t, _)| *t == NFTA_SET_ELEM_KEY) {
                            let inner = parse_attrs(k);
                            if let Some((_, d)) = inner.iter().find(|(t, _)| *t == NFTA_DATA_VALUE) {
                                let is_end = eflags & NFT_SET_ELEM_INTERVAL_END != 0;
                                raw.push((d.to_vec(), is_end, vdict));
                            }
                        }
                    }
                }
            })?;

            // For interval sets the kernel stores [start, end+1|INTERVAL_END].
            // Dump order varies by backend (rbtree vs pipapo) — sort
            // ascending by byte value first, then walk to pair each
            // start with the following end sentinel.
            let mut elements: Vec<(Vec<u8>, Option<Vec<u8>>)> = Vec::new();
            let mut verdicts: Vec<(i32, String)> = Vec::new();
            if is_interval {
                // End sentinel sorts before start at the same value
                // so touching intervals pair up correctly.
                raw.sort_by(|a, b| a.0.cmp(&b.0).then(b.1.cmp(&a.1)));
                let mut i = 0;
                while i < raw.len() {
                    let (start, end_flag, _) = &raw[i];
                    if *end_flag { i += 1; continue; }
                    let mut end: Option<Vec<u8>> = None;
                    if i + 1 < raw.len() && raw[i + 1].1 {
                        let mut v = raw[i + 1].0.clone();
                        // Subtract one (upper bound was stored +1).
                        for byte in v.iter_mut().rev() {
                            if *byte == 0 { *byte = 0xff; } else { *byte -= 1; break; }
                        }
                        if v != *start { end = Some(v); }
                        i += 2;
                    } else {
                        i += 1;
                    }
                    elements.push((start.clone(), end));
                }
            } else {
                // Kernel dumps hash-set elements in bucket order, so
                // the ordering is pseudo-random. Upstream sorts by
                // value ascending for display — match that or the
                // text/JSON diffs permute arbitrarily. Vmaps sort
                // by key too and drag each element's verdict along.
                let mut items: Vec<(Vec<u8>, Option<(i32, String)>)> = raw.iter()
                    .filter(|(_, f, _)| !*f)
                    .map(|(k, _, v)| (k.clone(), v.clone()))
                    .collect();
                items.sort_by(|a, b| a.0.cmp(&b.0));
                for (k, v) in items {
                    elements.push((k, None));
                    if is_map {
                        verdicts.push(v.unwrap_or((0, String::new())));
                    }
                }
            }
            reg.sets.insert(name, output::AnonSetInfo {
                key_type, key_len, is_interval, elements,
                is_map, verdicts,
            });
        }
        Ok(reg)
    }

    /// Like set_element_keys, but for interval sets pairs each start
    /// with its trailing INTERVAL_END sentinel so callers can render
    /// CIDR/ranges. Returns (start, Option<end-inclusive>).
    fn set_element_pairs(&mut self, family: u8, table: &str, name: &str)
        -> io::Result<Vec<(Vec<u8>, Option<Vec<u8>>, Option<Vec<u8>>, Option<(i32, String)>, u64, u64)>>
    {
        let tbl = table.to_string();
        let sn  = name.to_string();
        // Find the set to know whether it's interval-flagged or a data map.
        let mut set_flags: u32 = 0;
        self.dump(NFT_MSG_GETSET, family, |_, _| {}, |mt, _, data| {
            if mt != NFT_MSG_NEWSET { return; }
            let a = parse_attrs(data);
            let t = a.iter().find(|(t, _)| *t == NFTA_SET_TABLE)
                .map(|(_, v)| attr_str(v)).unwrap_or("");
            let n = a.iter().find(|(t, _)| *t == NFTA_SET_NAME)
                .map(|(_, v)| attr_str(v)).unwrap_or("");
            if t == tbl && n == sn {
                set_flags = a.iter().find(|(t, _)| *t == NFTA_SET_FLAGS)
                    .map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
            }
        })?;
        let is_interval = set_flags & NFT_SET_INTERVAL != 0;
        let is_map      = set_flags & NFT_SET_MAP != 0;

        let tbl2 = tbl.clone();
        let sn2  = sn.clone();
        // (key_bytes, is_end, data_value_or_None, verdict_or_None,
        //  per-elem timeout ms, per-elem expiration ms). The last two
        // come from NFTA_SET_ELEM_TIMEOUT / NFTA_SET_ELEM_EXPIRATION
        // and are 0 when absent.
        let mut raw: Vec<(Vec<u8>, bool, Option<Vec<u8>>, Option<(i32, String)>, u64, u64)> = Vec::new();
        self.dump(NFT_MSG_GETSETELEM, family, |msg, pos| {
            msg.put_str(NFTA_SET_ELEM_LIST_TABLE, &tbl2);
            msg.put_str(NFTA_SET_ELEM_LIST_SET, &sn2);
            msg.end_msg(pos);
        }, |mt, _, data| {
            if mt != NFT_MSG_NEWSETELEM { return; }
            let a = parse_attrs(data);
            if let Some((_, list)) = a.iter().find(|(t, _)| *t == NFTA_SET_ELEM_LIST_ELEMENTS) {
                for (_, eb) in parse_attrs(list) {
                    let ea = parse_attrs(&eb);
                    let eflags = ea.iter().find(|(t, _)| *t == NFTA_SET_ELEM_FLAGS)
                        .map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
                    // Fetch map data: data-valued maps carry NFTA_DATA_VALUE,
                    // verdict maps carry NFTA_DATA_VERDICT (CODE + optional CHAIN).
                    let (dval, dvrd): (Option<Vec<u8>>, Option<(i32, String)>) = ea.iter()
                        .find(|(t, _)| *t == NFTA_SET_ELEM_DATA)
                        .map(|(_, d)| {
                            let inner = parse_attrs(d);
                            let val = inner.iter().find(|(t, _)| *t == NFTA_DATA_VALUE)
                                .map(|(_, v)| v.to_vec());
                            let vrd = inner.iter().find(|(t, _)| *t == NFTA_DATA_VERDICT)
                                .map(|(_, v)| {
                                    let vattrs = parse_attrs(v);
                                    let code = vattrs.iter().find(|(t, _)| *t == NFTA_VERDICT_CODE)
                                        .map(|(_, b)| attr_i32_be(b)).unwrap_or(0);
                                    let chain = vattrs.iter().find(|(t, _)| *t == NFTA_VERDICT_CHAIN)
                                        .map(|(_, b)| attr_str(b).to_string()).unwrap_or_default();
                                    (code, chain)
                                });
                            (val, vrd)
                        }).unwrap_or((None, None));
                    let etimeout = ea.iter().find(|(t, _)| *t == NFTA_SET_ELEM_TIMEOUT)
                        .map(|(_, v)| attr_u64_be(v)).unwrap_or(0);
                    let eexpires = ea.iter().find(|(t, _)| *t == NFTA_SET_ELEM_EXPIRATION)
                        .map(|(_, v)| attr_u64_be(v)).unwrap_or(0);
                    if let Some((_, k)) = ea.iter().find(|(t, _)| *t == NFTA_SET_ELEM_KEY) {
                        let inner = parse_attrs(k);
                        if let Some((_, d)) = inner.iter().find(|(t, _)| *t == NFTA_DATA_VALUE) {
                            raw.push((d.to_vec(),
                                eflags & NFT_SET_ELEM_INTERVAL_END != 0,
                                dval, dvrd, etimeout, eexpires));
                        }
                    }
                }
            }
        })?;

        let mut out: Vec<(Vec<u8>, Option<Vec<u8>>, Option<Vec<u8>>, Option<(i32, String)>, u64, u64)> = Vec::new();
        if is_interval {
            raw.sort_by(|a, b| a.0.cmp(&b.0));
            let mut i = 0;
            while i < raw.len() {
                let (start, end_flag, _, _, _, _) = &raw[i];
                if *end_flag { i += 1; continue; }
                let mut end: Option<Vec<u8>> = None;
                if i + 1 < raw.len() && raw[i + 1].1 {
                    let mut v = raw[i + 1].0.clone();
                    for byte in v.iter_mut().rev() {
                        if *byte == 0 { *byte = 0xff; } else { *byte -= 1; break; }
                    }
                    if v != *start { end = Some(v); }
                    i += 2;
                } else { i += 1; }
                out.push((start.clone(), end, None, None, 0, 0));
            }
        } else if is_map {
            // Non-interval map: third field carries data bytes (data-valued
            // map), fourth carries verdict code+chain (verdict map).
            let mut items: Vec<(Vec<u8>, Option<Vec<u8>>, Option<(i32, String)>, u64, u64)> = raw.into_iter()
                .filter_map(|(k, f, d, vd, t, e)| if !f { Some((k, d, vd, t, e)) } else { None })
                .collect();
            items.sort_by(|a, b| a.0.cmp(&b.0));
            for (k, d, vd, t, e) in items { out.push((k, None, d, vd, t, e)); }
        } else {
            let mut items: Vec<(Vec<u8>, u64, u64)> = raw.into_iter()
                .filter_map(|(k, f, _, _, t, e)| if !f { Some((k, t, e)) } else { None })
                .collect();
            items.sort_by(|a, b| a.0.cmp(&b.0));
            for (k, t, e) in items { out.push((k, None, None, None, t, e)); }
        }
        Ok(out)
    }

    fn set_element_keys(&mut self, family: u8, table: &str, name: &str) -> io::Result<Vec<Vec<u8>>> {
        let tbl = table.to_string();
        let set = name.to_string();
        let mut out: Vec<Vec<u8>> = Vec::new();
        self.dump(NFT_MSG_GETSETELEM, family, |msg, pos| {
            msg.put_str(NFTA_SET_ELEM_LIST_TABLE, &tbl);
            msg.put_str(NFTA_SET_ELEM_LIST_SET, &set);
            msg.end_msg(pos);
        }, |mt, _, data| {
            if mt != NFT_MSG_NEWSETELEM { return; }
            let a = parse_attrs(data);
            if let Some((_, v)) = a.iter().find(|(t, _)| *t == NFTA_SET_ELEM_LIST_ELEMENTS) {
                for (_, eb) in parse_attrs(v) {
                    let ea = parse_attrs(&eb);
                    let flags = ea.iter().find(|(t, _)| *t == NFTA_SET_ELEM_FLAGS)
                        .map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
                    if flags & NFT_SET_ELEM_INTERVAL_END != 0 { continue; }
                    if let Some((_, k)) = ea.iter().find(|(t, _)| *t == NFTA_SET_ELEM_KEY) {
                        let inner = parse_attrs(k);
                        if let Some((_, d)) = inner.iter().find(|(t, _)| *t == NFTA_DATA_VALUE) {
                            out.push(d.to_vec());
                        }
                    }
                }
            }
        })?;
        // Kernel dump order varies by backend (pipapo reverses).
        // Sort by raw bytes ascending for stable JSON output.
        out.sort();
        Ok(out)
    }

    /// Query the kernel (or the in-batch pending map) for full set
    /// metadata.  Returns `SetInfo` with interval flag, key/data
    /// lengths and types so add/delete_elements can re-encode keys
    /// and data values correctly.
    fn probe_set_info(&mut self, family: u8, table: &str, name: &str) -> io::Result<SetInfo> {
        // Check in-batch pending sets first (kernel dump won't see them).
        let key = (family, table.to_string(), name.to_string());
        if let Some(&si) = self.pending_sets.get(&key) {
            return Ok(si);
        }
        let table_s = table.to_string();
        let name_s = name.to_string();
        let mut info = SetInfo {
            interval: false, key_len: 4, key_type: 0,
            data_len: 0, data_type: 0,
        };
        self.dump(NFT_MSG_GETSET, family, |_, _| {}, |mt, _, data| {
            if mt != NFT_MSG_NEWSET { return; }
            let a = parse_attrs(data);
            let t = a.iter().find(|(t, _)| *t == NFTA_SET_TABLE)
                .map(|(_, v)| attr_str(v)).unwrap_or("");
            let n = a.iter().find(|(t, _)| *t == NFTA_SET_NAME)
                .map(|(_, v)| attr_str(v)).unwrap_or("");
            if t == table_s && n == name_s {
                let flags = a.iter().find(|(t, _)| *t == NFTA_SET_FLAGS)
                    .map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
                info.interval = flags & NFT_SET_INTERVAL != 0;
                if let Some((_, v)) = a.iter().find(|(t, _)| *t == NFTA_SET_KEY_LEN) {
                    info.key_len = attr_u32_be(v);
                }
                if let Some((_, v)) = a.iter().find(|(t, _)| *t == NFTA_SET_KEY_TYPE) {
                    info.key_type = attr_u32_be(v);
                }
                if let Some((_, v)) = a.iter().find(|(t, _)| *t == NFTA_SET_DATA_LEN) {
                    info.data_len = attr_u32_be(v);
                }
                if let Some((_, v)) = a.iter().find(|(t, _)| *t == NFTA_SET_DATA_TYPE) {
                    info.data_type = attr_u32_be(v);
                }
            }
        })?;
        Ok(info)
    }

    fn delete_elements(&mut self, cmd: &Command) -> io::Result<()> {
        let family = cmd.family;
        let table = cmd.table.clone();
        let set_name = cmd.set_name.clone();
        // Resize and re-encode element keys to match the set's actual
        // key layout — same concat-slot and width fixes as add_elements.
        let si = self.probe_set_info(family, &table, &set_name)?;
        let kt = si.key_type;
        let kl = si.key_len;
        let need_concat_fixup = cmd.set_spec.concat_widths.is_empty()
            && unpack_dtype_widths(kt).len() > 1;
        let elements: Vec<(Vec<u8>, Option<Vec<u8>>)> = cmd.elements.iter()
            .map(|(k, e)| {
                let c = if need_concat_fixup { reencode_concat_key(k, kt) } else { k.to_vec() };
                let rk = resize_key(&c, kl);
                let re = e.as_ref().map(|v| {
                    let c2 = if need_concat_fixup { reencode_concat_key(v, kt) } else { v.to_vec() };
                    resize_key(&c2, kl)
                });
                (rk, re)
            }).collect();
        self.send_batch(|msg| {
            // Same u16 nla_len ceiling on NFTA_SET_ELEM_LIST_ELEMENTS as
            // the add path — split DELSETELEM across multiple messages
            // inside the batch when needed.
            const SPLIT_THRESHOLD: usize = 60000;
            let mut pos = msg.begin_msg(NFT_MSG_DELSETELEM, family, NLM_F_ACK);
            msg.put_str(NFTA_SET_ELEM_LIST_TABLE, &table);
            msg.put_str(NFTA_SET_ELEM_LIST_SET, &set_name);
            let mut elems_nest = msg.begin_nested(NFTA_SET_ELEM_LIST_ELEMENTS);
            for (key, _range_end) in &elements {
                if msg.buf.len() - pos > SPLIT_THRESHOLD && msg.buf.len() > elems_nest + 4 {
                    msg.end_nested(elems_nest);
                    msg.end_msg(pos);
                    pos = msg.begin_msg(NFT_MSG_DELSETELEM, family, NLM_F_ACK);
                    msg.put_str(NFTA_SET_ELEM_LIST_TABLE, &table);
                    msg.put_str(NFTA_SET_ELEM_LIST_SET, &set_name);
                    elems_nest = msg.begin_nested(NFTA_SET_ELEM_LIST_ELEMENTS);
                }
                let elem = msg.begin_nested(NFTA_LIST_ELEM);
                msg.put_data_value(NFTA_SET_ELEM_KEY, key);
                msg.end_nested(elem);
            }
            msg.end_nested(elems_nest);
            msg.end_msg(pos);
        })
    }
}

// ── Expression compiler ─────────────────────────────────────────

fn compile_expr(msg: &mut MsgBuilder, expr: &Expr) {
    match expr {
        Expr::Payload { base, offset, len, protocol: _ } => {
            let elem = msg.begin_nested(NFTA_LIST_ELEM);
            msg.put_str(NFTA_EXPR_NAME, "payload");
            let data = msg.begin_nested(NFTA_EXPR_DATA);
            msg.put_u32_be(NFTA_PAYLOAD_DREG, NFT_REG32_00);
            msg.put_u32_be(NFTA_PAYLOAD_BASE, *base);
            msg.put_u32_be(NFTA_PAYLOAD_OFFSET, *offset);
            msg.put_u32_be(NFTA_PAYLOAD_LEN, *len);
            msg.end_nested(data);
            msg.end_nested(elem);
        }
        Expr::Meta { key, width } => {
            let elem = msg.begin_nested(NFTA_LIST_ELEM);
            msg.put_str(NFTA_EXPR_NAME, "meta");
            let data = msg.begin_nested(NFTA_EXPR_DATA);
            msg.put_u32_be(NFTA_META_KEY, *key);
            msg.put_u32_be(NFTA_META_DREG, reg_for_width(*width));
            msg.end_nested(data);
            msg.end_nested(elem);
        }
        Expr::Ct { key, dir, width } => {
            let elem = msg.begin_nested(NFTA_LIST_ELEM);
            msg.put_str(NFTA_EXPR_NAME, "ct");
            let data = msg.begin_nested(NFTA_EXPR_DATA);
            msg.put_u32_be(NFTA_CT_KEY, *key);
            msg.put_u32_be(NFTA_CT_DREG, reg_for_width(*width));
            if *dir >= 0 { msg.put_bytes(NFTA_CT_DIR, &[*dir as u8]); }
            msg.end_nested(data);
            msg.end_nested(elem);
        }
        Expr::Cmp { op, data: cmp_data } => {
            let elem = msg.begin_nested(NFTA_LIST_ELEM);
            msg.put_str(NFTA_EXPR_NAME, "cmp");
            let data = msg.begin_nested(NFTA_EXPR_DATA);
            msg.put_u32_be(NFTA_CMP_SREG, reg_for_width(cmp_data.len()));
            msg.put_u32_be(NFTA_CMP_OP, *op);
            msg.put_data_value(NFTA_CMP_DATA, cmp_data);
            msg.end_nested(data);
            msg.end_nested(elem);
        }
        Expr::Lookup { set_name, inverted, width } => {
            let elem = msg.begin_nested(NFTA_LIST_ELEM);
            msg.put_str(NFTA_EXPR_NAME, "lookup");
            let data = msg.begin_nested(NFTA_EXPR_DATA);
            msg.put_str(NFTA_LOOKUP_SET, set_name);
            msg.put_u32_be(NFTA_LOOKUP_SREG, reg_for_width(*width));
            if *inverted {
                msg.put_u32_be(NFTA_LOOKUP_FLAGS, NFT_LOOKUP_F_INV);
            }
            msg.end_nested(data);
            msg.end_nested(elem);
        }
        Expr::Vmap { set_name, width, set_id } => {
            let elem = msg.begin_nested(NFTA_LIST_ELEM);
            msg.put_str(NFTA_EXPR_NAME, "lookup");
            let data = msg.begin_nested(NFTA_EXPR_DATA);
            // Wire order mirrors upstream nft: SREG, DREG, SET, SET_ID.
            msg.put_u32_be(NFTA_LOOKUP_SREG, reg_for_width(*width));
            // For verdict-map lookups the dreg is NFT_REG_VERDICT (0).
            // Kernel's nft_parse_register_store special-cases that
            // register to accept NFT_DATA_VERDICT-typed sets.
            msg.put_u32_be(NFTA_LOOKUP_DREG, NFT_REG_VERDICT);
            msg.put_str(NFTA_LOOKUP_SET, set_name);
            // SET_ID is required for anon sets so the kernel can tie
            // this rule to the NEWSET we emitted earlier in the same
            // batch; for named maps we omit it and the kernel resolves
            // by name.
            if let Some(id) = set_id {
                msg.put_u32_be(NFTA_LOOKUP_SET_ID, *id);
            }
            msg.end_nested(data);
            msg.end_nested(elem);
        }
        // AnonVmap is always rewritten to Vmap by lower_anon_sets
        // (in add_rule) before reaching compile_expr. Reaching this
        // arm is a bug.
        Expr::AnonVmap { .. } => {}
        Expr::ObjRef { kind, name } => {
            // `objref` expression binds a rule to a named stateful
            // object. The IMM_TYPE attribute carries the object kind
            // (NFT_OBJECT_COUNTER / _QUOTA / _LIMIT) so the kernel can
            // look the name up in the right table of objects.
            let elem = msg.begin_nested(NFTA_LIST_ELEM);
            msg.put_str(NFTA_EXPR_NAME, "objref");
            let data = msg.begin_nested(NFTA_EXPR_DATA);
            msg.put_u32_be(NFTA_OBJREF_IMM_TYPE, *kind);
            msg.put_str(NFTA_OBJREF_IMM_NAME, name);
            msg.end_nested(data);
            msg.end_nested(elem);
        }
        Expr::Bitwise { mask, xor } => {
            let elem = msg.begin_nested(NFTA_LIST_ELEM);
            msg.put_str(NFTA_EXPR_NAME, "bitwise");
            let data = msg.begin_nested(NFTA_EXPR_DATA);
            let reg = reg_for_width(mask.len());
            msg.put_u32_be(NFTA_BITWISE_SREG, reg);
            msg.put_u32_be(NFTA_BITWISE_DREG, reg);
            msg.put_u32_be(NFTA_BITWISE_LEN, mask.len() as u32);
            msg.put_data_value(NFTA_BITWISE_MASK, mask);
            msg.put_data_value(NFTA_BITWISE_XOR, xor);
            msg.end_nested(data);
            msg.end_nested(elem);
        }
        Expr::Verdict { code, chain } => {
            let elem = msg.begin_nested(NFTA_LIST_ELEM);
            msg.put_str(NFTA_EXPR_NAME, "immediate");
            let data = msg.begin_nested(NFTA_EXPR_DATA);
            msg.put_u32_be(NFTA_IMM_DREG, NFT_REG_VERDICT);
            let imm_data = msg.begin_nested(NFTA_IMM_DATA);
            let verdict = msg.begin_nested(NFTA_DATA_VERDICT);
            msg.put_u32_be(NFTA_VERDICT_CODE, *code as u32);
            if !chain.is_empty() { msg.put_str(NFTA_VERDICT_CHAIN, chain); }
            msg.end_nested(verdict);
            msg.end_nested(imm_data);
            msg.end_nested(data);
            msg.end_nested(elem);
        }
        Expr::VerdictBinding { code, chain, chain_id } => {
            let elem = msg.begin_nested(NFTA_LIST_ELEM);
            msg.put_str(NFTA_EXPR_NAME, "immediate");
            let data = msg.begin_nested(NFTA_EXPR_DATA);
            msg.put_u32_be(NFTA_IMM_DREG, NFT_REG_VERDICT);
            let imm_data = msg.begin_nested(NFTA_IMM_DATA);
            let verdict = msg.begin_nested(NFTA_DATA_VERDICT);
            msg.put_u32_be(NFTA_VERDICT_CODE, *code as u32);
            if !chain.is_empty() { msg.put_str(NFTA_VERDICT_CHAIN, chain); }
            msg.put_u32_be(NFTA_VERDICT_CHAIN_ID, *chain_id);
            msg.end_nested(verdict);
            msg.end_nested(imm_data);
            msg.end_nested(data);
            msg.end_nested(elem);
        }
        Expr::Counter => {
            let elem = msg.begin_nested(NFTA_LIST_ELEM);
            msg.put_str(NFTA_EXPR_NAME, "counter");
            let data = msg.begin_nested(NFTA_EXPR_DATA);
            msg.end_nested(data);
            msg.end_nested(elem);
        }
        Expr::Log { prefix } => {
            let elem = msg.begin_nested(NFTA_LIST_ELEM);
            msg.put_str(NFTA_EXPR_NAME, "log");
            let data = msg.begin_nested(NFTA_EXPR_DATA);
            if !prefix.is_empty() { msg.put_str(NFTA_LOG_PREFIX, prefix); }
            msg.end_nested(data);
            msg.end_nested(elem);
        }
        Expr::Limit { rate, unit, burst, flags } => {
            let elem = msg.begin_nested(NFTA_LIST_ELEM);
            msg.put_str(NFTA_EXPR_NAME, "limit");
            let data = msg.begin_nested(NFTA_EXPR_DATA);
            msg.put_u64_be(NFTA_LIMIT_RATE, *rate);
            msg.put_u64_be(NFTA_LIMIT_UNIT, *unit);
            msg.put_u32_be(NFTA_LIMIT_BURST, *burst);
            if *flags != 0 { msg.put_u32_be(NFTA_LIMIT_FLAGS, *flags); }
            msg.end_nested(data);
            msg.end_nested(elem);
        }
        Expr::Nat { nat_type, family, addr, port, has_addr, has_port,
                    addr_max, has_addr_max, flags } => {
            // Load address(es) and port into registers if present.
            // For an `a-b` range we push addr into NFT_REG32_01 and
            // addr_max into NFT_REG32_02; the nat expression then
            // points NFTA_NAT_REG_ADDR_{MIN,MAX} at the two regs.
            if *has_addr && !addr.is_empty() {
                let elem = msg.begin_nested(NFTA_LIST_ELEM);
                msg.put_str(NFTA_EXPR_NAME, "immediate");
                let data = msg.begin_nested(NFTA_EXPR_DATA);
                msg.put_u32_be(NFTA_IMM_DREG, NFT_REG32_01);
                msg.put_data_value(NFTA_IMM_DATA, addr);
                msg.end_nested(data);
                msg.end_nested(elem);
            }
            if *has_addr_max && !addr_max.is_empty() {
                let elem = msg.begin_nested(NFTA_LIST_ELEM);
                msg.put_str(NFTA_EXPR_NAME, "immediate");
                let data = msg.begin_nested(NFTA_EXPR_DATA);
                msg.put_u32_be(NFTA_IMM_DREG, NFT_REG32_01 + 1);
                msg.put_data_value(NFTA_IMM_DATA, addr_max);
                msg.end_nested(data);
                msg.end_nested(elem);
            }
            if *has_port {
                // Port lives in REG32_02 for single-addr forms, REG32_03
                // when an address range already consumed REG32_02.
                let port_reg = NFT_REG32_01 + 1 + if *has_addr_max { 1 } else { 0 };
                let port_bytes = port.to_be_bytes();
                let elem = msg.begin_nested(NFTA_LIST_ELEM);
                msg.put_str(NFTA_EXPR_NAME, "immediate");
                let data = msg.begin_nested(NFTA_EXPR_DATA);
                msg.put_u32_be(NFTA_IMM_DREG, port_reg);
                msg.put_data_value(NFTA_IMM_DATA, &port_bytes);
                msg.end_nested(data);
                msg.end_nested(elem);
            }

            let elem = msg.begin_nested(NFTA_LIST_ELEM);
            msg.put_str(NFTA_EXPR_NAME, "nat");
            let data = msg.begin_nested(NFTA_EXPR_DATA);
            msg.put_u32_be(NFTA_NAT_TYPE, *nat_type);
            msg.put_u32_be(NFTA_NAT_FAMILY, *family as u32);
            if *has_addr {
                msg.put_u32_be(NFTA_NAT_REG_ADDR_MIN, NFT_REG32_01);
                if *has_addr_max {
                    msg.put_u32_be(NFTA_NAT_REG_ADDR_MAX, NFT_REG32_01 + 1);
                } else {
                    msg.put_u32_be(NFTA_NAT_REG_ADDR_MAX, NFT_REG32_01);
                }
            }
            if *has_port {
                let port_reg = NFT_REG32_01 + 1 + if *has_addr_max { 1 } else { 0 };
                msg.put_u32_be(NFTA_NAT_REG_PROTO_MIN, port_reg);
                msg.put_u32_be(NFTA_NAT_REG_PROTO_MAX, port_reg);
            }
            if *flags != 0 {
                msg.put_u32_be(NFTA_NAT_FLAGS, *flags);
            }
            msg.end_nested(data);
            msg.end_nested(elem);
        }
        Expr::Masquerade { flags } => {
            let elem = msg.begin_nested(NFTA_LIST_ELEM);
            msg.put_str(NFTA_EXPR_NAME, "masq");
            let data = msg.begin_nested(NFTA_EXPR_DATA);
            if *flags != 0 {
                msg.put_u32_be(NFTA_MASQ_FLAGS, *flags);
            }
            msg.end_nested(data);
            msg.end_nested(elem);
        }
        Expr::Notrack => {
            let elem = msg.begin_nested(NFTA_LIST_ELEM);
            msg.put_str(NFTA_EXPR_NAME, "notrack");
            let data = msg.begin_nested(NFTA_EXPR_DATA);
            msg.end_nested(data);
            msg.end_nested(elem);
        }
        Expr::Reject => {
            let elem = msg.begin_nested(NFTA_LIST_ELEM);
            msg.put_str(NFTA_EXPR_NAME, "reject");
            let data = msg.begin_nested(NFTA_EXPR_DATA);
            msg.end_nested(data);
            msg.end_nested(elem);
        }
        Expr::RejectWith { reject_type, code, has_code } => {
            // pf `block return-rst` / `block return-icmp` lowering.
            // Wire shape: NFTA_REJECT_TYPE (always) + NFTA_REJECT_ICMP_CODE
            // (only for ICMP_UNREACH / ICMPX_UNREACH variants — TCP_RST
            // ignores the code field and upstream nft omits it).
            let elem = msg.begin_nested(NFTA_LIST_ELEM);
            msg.put_str(NFTA_EXPR_NAME, "reject");
            let data = msg.begin_nested(NFTA_EXPR_DATA);
            msg.put_u32_be(NFTA_REJECT_TYPE, *reject_type);
            if *has_code {
                // NFTA_REJECT_ICMP_CODE is u8 on the wire (NLA payload
                // is one byte, padded to 4). Reuse put_u8_attr if it
                // exists; otherwise emit via put_data_value with a
                // 1-byte vec.
                msg.put_u8(NFTA_REJECT_ICMP_CODE, *code);
            }
            msg.end_nested(data);
            msg.end_nested(elem);
        }
        Expr::Range { sreg, op, from, to } => {
            // pf `hours { LO-HI }` lowers to:
            //   meta load TIME_HOUR -> reg 1
            //   byteorder hton(reg 1, 4, 4)
            //   range eq reg 1 LO_NBO HI_NBO
            // Upstream wraps FROM/TO in NESTED data attributes (same
            // layout as NFTA_CMP_DATA) so the kernel's nft_data_init
            // path can parse them; we mirror that.
            let elem = msg.begin_nested(NFTA_LIST_ELEM);
            msg.put_str(NFTA_EXPR_NAME, "range");
            let data = msg.begin_nested(NFTA_EXPR_DATA);
            msg.put_u32_be(NFTA_RANGE_SREG, *sreg);
            msg.put_u32_be(NFTA_RANGE_OP, *op);
            msg.put_data_value(NFTA_RANGE_FROM_DATA, from);
            msg.put_data_value(NFTA_RANGE_TO_DATA, to);
            msg.end_nested(data);
            msg.end_nested(elem);
        }
        Expr::Fib { flags, result, dreg } => {
            // pf `antispoof for <iface>` lowers to fib with
            // flags = NFTA_FIB_F_SADDR | NFTA_FIB_F_IIF, result = OIF.
            // Kernel runs the routing-table query and stores the chosen
            // output interface index into DREG. The next cmp checks
            // for index 0 (no route — "missing").
            let elem = msg.begin_nested(NFTA_LIST_ELEM);
            msg.put_str(NFTA_EXPR_NAME, "fib");
            let data = msg.begin_nested(NFTA_EXPR_DATA);
            msg.put_u32_be(NFTA_FIB_DREG, *dreg);
            msg.put_u32_be(NFTA_FIB_RESULT, *result);
            msg.put_u32_be(NFTA_FIB_FLAGS, *flags);
            msg.end_nested(data);
            msg.end_nested(elem);
        }
        // AnonSet is always lowered to Expr::Lookup in add_rule
        // before compile_expr sees the expression stream. Reaching
        // this arm means an expression list bypassed the rewrite,
        // which is a bug; emit nothing rather than crash.
        Expr::AnonSet { .. } => {}
        Expr::Socket { key, width, level } => {
            // `socket KEY` loads a per-packet socket attribute into
            // the destination register so the next cmp can match it.
            // Wire layout matches enum nft_socket_attributes: KEY=1,
            // DREG=2, LEVEL=3. Upstream emits all three even when
            // LEVEL is meaningless (LEVEL=0 for transparent / mark /
            // wildcard) so `nft monitor`'s decoder recognises the
            // load and renders the right symbolic name back. Drop
            // LEVEL only for non-cgroupv2 keys would re-introduce
            // the "appears as just `accept`" monitor regression.
            let elem = msg.begin_nested(NFTA_LIST_ELEM);
            msg.put_str(NFTA_EXPR_NAME, "socket");
            let data = msg.begin_nested(NFTA_EXPR_DATA);
            msg.put_u32_be(NFTA_SOCKET_KEY, *key);
            msg.put_u32_be(NFTA_SOCKET_DREG, reg_for_width(*width));
            msg.put_u32_be(NFTA_SOCKET_LEVEL, level.unwrap_or(0));
            msg.end_nested(data);
            msg.end_nested(elem);
        }
        Expr::Rt { key, width } => {
            // `rt KEY` loads a routing-derived value (egress classid,
            // ipv4/ipv6 nexthop, tcpmss) into the destination register.
            // Wire order is KEY, DREG — same shape as `meta` / `socket`.
            let elem = msg.begin_nested(NFTA_LIST_ELEM);
            msg.put_str(NFTA_EXPR_NAME, "rt");
            let data = msg.begin_nested(NFTA_EXPR_DATA);
            msg.put_u32_be(NFTA_RT_KEY, *key);
            msg.put_u32_be(NFTA_RT_DREG, reg_for_width(*width));
            msg.end_nested(data);
            msg.end_nested(elem);
        }
        Expr::FlowOffload { name } => {
            // `flow add @ft` — encoded as the `flow_offload` expression
            // with a single NFTA_FLOW_TABLE_NAME string. The kernel
            // matches it against an existing flowtable in the same
            // table and pushes the conntrack entry into it once
            // established.
            let elem = msg.begin_nested(NFTA_LIST_ELEM);
            msg.put_str(NFTA_EXPR_NAME, "flow_offload");
            let data = msg.begin_nested(NFTA_EXPR_DATA);
            msg.put_str(NFTA_FLOW_TABLE_NAME, name);
            msg.end_nested(data);
            msg.end_nested(elem);
        }
        Expr::Dynset { set_name, op, key_width: _, timeout_ms, set_id } => {
            // The preceding expression already loaded the key into
            // the same register the dynset reads. Wire order mirrors
            // upstream nft: SET_NAME, SET_ID, OP, SREG_KEY, TIMEOUT.
            // SET_ID is required when the set was created in the same
            // batch (table-block / -f mode) so the kernel can resolve
            // the set from the pending transaction list; for sets that
            // are already committed it is harmless to include.
            let elem = msg.begin_nested(NFTA_LIST_ELEM);
            msg.put_str(NFTA_EXPR_NAME, "dynset");
            let data = msg.begin_nested(NFTA_EXPR_DATA);
            msg.put_str(NFTA_DYNSET_SET_NAME, set_name);
            if let Some(id) = set_id {
                msg.put_u32_be(NFTA_DYNSET_SET_ID, *id);
            }
            msg.put_u32_be(NFTA_DYNSET_OP, *op);
            // Upstream nft always uses NFT_REG_1 for dynset SREG_KEY
            // regardless of key width; the kernel normalises the
            // 16-byte register to the physical 32-bit slot internally.
            msg.put_u32_be(NFTA_DYNSET_SREG_KEY, NFT_REG_1);
            if *timeout_ms > 0 {
                msg.put_u64_be(NFTA_DYNSET_TIMEOUT, *timeout_ms);
            }
            msg.end_nested(data);
            msg.end_nested(elem);
        }
        Expr::DynsetMeter { set_name, key_width: _, rate, unit, burst, limit_type, limit_flags } => {
            // Anonymous-meter dynset: `meter NAME { ip saddr limit
            // rate R/UNIT [burst B] }`. Same wire shape as a plain
            // dynset OP_ADD with the addition of NFTA_DYNSET_EXPR
            // carrying a single nested NFTA_LIST_ELEM whose name is
            // "limit" and whose data block is the usual NFTA_LIMIT_*.
            // Upstream nft always sets OP=ADD, no per-elem timeout,
            // and emits the limit attributes in the order RATE → UNIT
            // → BURST → TYPE → FLAGS — we mirror that to keep the
            // bracketed listing byte-stable.
            let elem = msg.begin_nested(NFTA_LIST_ELEM);
            msg.put_str(NFTA_EXPR_NAME, "dynset");
            let data = msg.begin_nested(NFTA_EXPR_DATA);
            msg.put_str(NFTA_DYNSET_SET_NAME, set_name);
            msg.put_u32_be(NFTA_DYNSET_OP, NFT_DYNSET_OP_ADD);
            msg.put_u32_be(NFTA_DYNSET_SREG_KEY, NFT_REG_1);
            let inner = msg.begin_nested(NFTA_DYNSET_EXPR);
            msg.put_str(NFTA_EXPR_NAME, "limit");
            let inner_data = msg.begin_nested(NFTA_EXPR_DATA);
            msg.put_u64_be(NFTA_LIMIT_RATE, *rate);
            msg.put_u64_be(NFTA_LIMIT_UNIT, *unit);
            msg.put_u32_be(NFTA_LIMIT_BURST, *burst);
            msg.put_u32_be(NFTA_LIMIT_TYPE, *limit_type);
            msg.put_u32_be(NFTA_LIMIT_FLAGS, *limit_flags);
            msg.end_nested(inner_data);
            msg.end_nested(inner);
            msg.end_nested(data);
            msg.end_nested(elem);
        }
        Expr::Connlimit { count, inv } => {
            // `ct count [over] N` — flag bit 0 (NFT_CONNLIMIT_F_INV)
            // toggles the kernel's threshold comparison from "<=" to
            // ">". COUNT is always emitted; FLAGS only when set, to
            // keep the wire bytes byte-identical with upstream's
            // emission for the no-`over` form.
            let elem = msg.begin_nested(NFTA_LIST_ELEM);
            msg.put_str(NFTA_EXPR_NAME, "connlimit");
            let data = msg.begin_nested(NFTA_EXPR_DATA);
            msg.put_u32_be(NFTA_CONNLIMIT_COUNT, *count);
            let flags = if *inv { NFT_CONNLIMIT_F_INV } else { 0 };
            if flags != 0 { msg.put_u32_be(NFTA_CONNLIMIT_FLAGS, flags); }
            msg.end_nested(data);
            msg.end_nested(elem);
        }
        Expr::HashKeyPayload { base, offset, len, dreg } => {
            // Same wire format as Expr::Payload but DREG is the
            // explicit register the parser chose. For a single-key
            // jhash that is always NFT_REG_2 (matches upstream
            // monitor-diff). For a concat key the parser advances
            // dreg by one 4-byte register slot per sub-field, so
            // `tcp dport . tcp sport` lands the loads in NFT_REG_2
            // and NFT_REG_3 respectively.
            let elem = msg.begin_nested(NFTA_LIST_ELEM);
            msg.put_str(NFTA_EXPR_NAME, "payload");
            let data = msg.begin_nested(NFTA_EXPR_DATA);
            msg.put_u32_be(NFTA_PAYLOAD_DREG, *dreg);
            msg.put_u32_be(NFTA_PAYLOAD_BASE, *base);
            msg.put_u32_be(NFTA_PAYLOAD_OFFSET, *offset);
            msg.put_u32_be(NFTA_PAYLOAD_LEN, *len);
            msg.end_nested(data);
            msg.end_nested(elem);
        }
        Expr::Numgen { ng_type, modulus, offset } => {
            // Wire layout (strace-captured against /usr/sbin/nft):
            //   NFTA_EXPR_NAME = "numgen\0", padded to 8 bytes.
            //   NFTA_EXPR_DATA = nested {
            //       NG_DREG    = NFT_REG_1 (NBO),
            //       NG_MODULUS = M (NBO),
            //       NG_TYPE    = INC|RANDOM (NBO),
            //       NG_OFFSET  = N (NBO),  // emitted even when 0
            //   }
            // OFFSET is unconditionally present; the kernel doesn't
            // care, but byte-diff tests do.
            let elem = msg.begin_nested(NFTA_LIST_ELEM);
            msg.put_str(NFTA_EXPR_NAME, "numgen");
            let data = msg.begin_nested(NFTA_EXPR_DATA);
            msg.put_u32_be(NFTA_NG_DREG, NFT_REG_1);
            msg.put_u32_be(NFTA_NG_MODULUS, *modulus);
            msg.put_u32_be(NFTA_NG_TYPE, *ng_type);
            msg.put_u32_be(NFTA_NG_OFFSET, *offset);
            msg.end_nested(data);
            msg.end_nested(elem);
        }
        Expr::Hash { sreg, len, modulus, seed, has_seed, offset, hash_type } => {
            // Wire layout (strace-captured). Two cases:
            //
            // jhash:   NFTA_EXPR_NAME = "hash\0\0\0\0", then
            //          { SREG, DREG, LEN, MODULUS, [SEED,]
            //            OFFSET, TYPE=JENKINS } — note SEED only
            //          shows up when the user wrote `seed N`;
            //          upstream omits it for the no-seed case.
            //
            // symhash: NFTA_EXPR_NAME = "hash\0\0\0\0", then
            //          { DREG, MODULUS, OFFSET, TYPE=SYM } —
            //          no SREG, no LEN. The kernel hashes the
            //          whole packet symmetrically.
            //
            // OFFSET and TYPE are always last and always present.
            let elem = msg.begin_nested(NFTA_LIST_ELEM);
            msg.put_str(NFTA_EXPR_NAME, "hash");
            let data = msg.begin_nested(NFTA_EXPR_DATA);
            if let Some(s) = sreg {
                msg.put_u32_be(NFTA_HASH_SREG, *s);
            }
            msg.put_u32_be(NFTA_HASH_DREG, NFT_REG_1);
            if sreg.is_some() {
                msg.put_u32_be(NFTA_HASH_LEN, *len);
            }
            msg.put_u32_be(NFTA_HASH_MODULUS, *modulus);
            if *has_seed {
                msg.put_u32_be(NFTA_HASH_SEED, *seed);
            }
            msg.put_u32_be(NFTA_HASH_OFFSET, *offset);
            msg.put_u32_be(NFTA_HASH_TYPE, *hash_type);
            msg.end_nested(data);
            msg.end_nested(elem);
        }
        Expr::Queue { num, total, flags, has_sreg, sreg_qnum } => {
            // Wire layout (strace-captured against /usr/sbin/nft for
            // `add rule ip t c queue num 5 bypass`):
            //   NFTA_EXPR_NAME = "queue\0\0\0", padded to 8 bytes
            //   NFTA_EXPR_DATA = nested {
            //       NFTA_QUEUE_NUM   = u16 NBO,    // queue 5  -> 0x0005
            //       NFTA_QUEUE_TOTAL = u16 NBO,    // total=1  -> 0x0001
            //       NFTA_QUEUE_FLAGS = u16 NBO,    // bypass=1 -> 0x0001
            //   }
            // For the dynamic form (queue ... to symhash/jhash/map),
            // NUM and TOTAL are omitted and SREG_QNUM (NLA_U32 NBO)
            // points at the producer's destination register.
            //
            // u16 attributes use put_u16_be (4-byte attr header + 2
            // bytes payload + 2 bytes pad) just like NFTA_QUOTA's
            // wider siblings; NFTA_QUEUE_FLAGS is omitted when zero
            // so a flagless `queue num 5` doesn't carry the attr.
            let elem = msg.begin_nested(NFTA_LIST_ELEM);
            msg.put_str(NFTA_EXPR_NAME, "queue");
            let data = msg.begin_nested(NFTA_EXPR_DATA);
            if *has_sreg {
                msg.put_u32_be(NFTA_QUEUE_SREG_QNUM, *sreg_qnum);
            } else {
                msg.put_u16_be(NFTA_QUEUE_NUM, *num);
                msg.put_u16_be(NFTA_QUEUE_TOTAL, *total);
            }
            if *flags != 0 {
                msg.put_u16_be(NFTA_QUEUE_FLAGS, *flags);
            }
            msg.end_nested(data);
            msg.end_nested(elem);
        }
        Expr::MapLookup { set_name, key_width, dreg } => {
            // Data-side map lookup: identical wire shape to a vmap
            // lookup but with DREG=NFT_REG_1 instead of
            // NFT_REG_VERDICT (the kernel routes the matched-data
            // bytes there for the next expression to consume).
            // Used by `queue ... to <fields...> map @qmap`, where
            // the map's data side is `queue` (a u16 fitting in
            // NFT_REG_1).
            let elem = msg.begin_nested(NFTA_LIST_ELEM);
            msg.put_str(NFTA_EXPR_NAME, "lookup");
            let data = msg.begin_nested(NFTA_EXPR_DATA);
            msg.put_u32_be(NFTA_LOOKUP_SREG, reg_for_width(*key_width));
            msg.put_u32_be(NFTA_LOOKUP_DREG, *dreg);
            msg.put_str(NFTA_LOOKUP_SET, set_name);
            msg.end_nested(data);
            msg.end_nested(elem);
        }
        Expr::MetaSet { key } => {
            // `meta KEY set <expr>` — the producing numgen / hash
            // already wrote its result into NFT_REG_1; we now
            // store that register back into the meta key. Wire
            // layout matches enum nft_meta_attributes:
            //   NFTA_META_KEY = key,
            //   NFTA_META_SREG = NFT_REG_1.
            // The DREG variant is omitted on purpose — the kernel
            // dispatches on which of DREG/SREG is present.
            let elem = msg.begin_nested(NFTA_LIST_ELEM);
            msg.put_str(NFTA_EXPR_NAME, "meta");
            let data = msg.begin_nested(NFTA_EXPR_DATA);
            msg.put_u32_be(NFTA_META_KEY, *key);
            msg.put_u32_be(NFTA_META_SREG, NFT_REG_1);
            msg.end_nested(data);
            msg.end_nested(elem);
        }
        Expr::Dup { addr, dev } => {
            // Wire: immediate(REG_1=addr), [immediate(REG_2=dev)],
            // dup{SREG_ADDR=REG_1, [SREG_DEV=REG_2]}.
            if !addr.is_empty() {
                let elem = msg.begin_nested(NFTA_LIST_ELEM);
                msg.put_str(NFTA_EXPR_NAME, "immediate");
                let data = msg.begin_nested(NFTA_EXPR_DATA);
                msg.put_u32_be(NFTA_IMM_DREG, NFT_REG_1);
                msg.put_data_value(NFTA_IMM_DATA, addr);
                msg.end_nested(data);
                msg.end_nested(elem);
            }
            if let Some(idx) = dev {
                let idx_bytes: [u8; 4] = (*idx).to_ne_bytes();
                let elem = msg.begin_nested(NFTA_LIST_ELEM);
                msg.put_str(NFTA_EXPR_NAME, "immediate");
                let data = msg.begin_nested(NFTA_EXPR_DATA);
                msg.put_u32_be(NFTA_IMM_DREG, NFT_REG_2);
                msg.put_data_value(NFTA_IMM_DATA, &idx_bytes);
                msg.end_nested(data);
                msg.end_nested(elem);
            }
            let elem = msg.begin_nested(NFTA_LIST_ELEM);
            msg.put_str(NFTA_EXPR_NAME, "dup");
            let data = msg.begin_nested(NFTA_EXPR_DATA);
            if !addr.is_empty() {
                msg.put_u32_be(NFTA_DUP_SREG_ADDR, NFT_REG_1);
            }
            if dev.is_some() {
                msg.put_u32_be(NFTA_DUP_SREG_DEV, NFT_REG_2);
            }
            msg.end_nested(data);
            msg.end_nested(elem);
        }
        Expr::Fwd { dev } => {
            let idx_bytes: [u8; 4] = (*dev).to_ne_bytes();
            let elem = msg.begin_nested(NFTA_LIST_ELEM);
            msg.put_str(NFTA_EXPR_NAME, "immediate");
            let data = msg.begin_nested(NFTA_EXPR_DATA);
            msg.put_u32_be(NFTA_IMM_DREG, NFT_REG_1);
            msg.put_data_value(NFTA_IMM_DATA, &idx_bytes);
            msg.end_nested(data);
            msg.end_nested(elem);

            let elem = msg.begin_nested(NFTA_LIST_ELEM);
            msg.put_str(NFTA_EXPR_NAME, "fwd");
            let data = msg.begin_nested(NFTA_EXPR_DATA);
            msg.put_u32_be(NFTA_FWD_SREG_DEV, NFT_REG_1);
            msg.end_nested(data);
            msg.end_nested(elem);
        }
        Expr::Tproxy { family, addr, port, has_addr, has_port } => {
            // Each immediate that precedes the tproxy expr loads one
            // operand into a register; the tproxy expr then names the
            // registers via REG_ADDR / REG_PORT. Upstream nft picks
            // sequential 16-byte registers (reg 1, then reg 2) and
            // omits the half the user didn't supply — see
            // netlink_gen_tproxy_stmt in nftables.git src/.
            let mut next_reg = NFT_REG_1;
            let mut addr_reg: Option<u32> = None;
            let mut port_reg: Option<u32> = None;

            if *has_addr && !addr.is_empty() {
                let elem = msg.begin_nested(NFTA_LIST_ELEM);
                msg.put_str(NFTA_EXPR_NAME, "immediate");
                let data = msg.begin_nested(NFTA_EXPR_DATA);
                msg.put_u32_be(NFTA_IMM_DREG, next_reg);
                msg.put_data_value(NFTA_IMM_DATA, addr);
                msg.end_nested(data);
                msg.end_nested(elem);
                addr_reg = Some(next_reg);
                next_reg += 1;
            }

            if *has_port {
                let port_bytes = port.to_be_bytes();
                let elem = msg.begin_nested(NFTA_LIST_ELEM);
                msg.put_str(NFTA_EXPR_NAME, "immediate");
                let data = msg.begin_nested(NFTA_EXPR_DATA);
                msg.put_u32_be(NFTA_IMM_DREG, next_reg);
                msg.put_data_value(NFTA_IMM_DATA, &port_bytes);
                msg.end_nested(data);
                msg.end_nested(elem);
                port_reg = Some(next_reg);
            }

            let elem = msg.begin_nested(NFTA_LIST_ELEM);
            msg.put_str(NFTA_EXPR_NAME, "tproxy");
            let data = msg.begin_nested(NFTA_EXPR_DATA);
            // Always emit FAMILY — the kernel looks it up
            // unconditionally; NFPROTO_UNSPEC=0 is the sentinel for
            // "match any L3" inside an inet chain.
            msg.put_u32_be(NFTA_TPROXY_FAMILY, *family);
            if let Some(r) = addr_reg {
                msg.put_u32_be(NFTA_TPROXY_REG_ADDR, r);
            }
            if let Some(r) = port_reg {
                msg.put_u32_be(NFTA_TPROXY_REG_PORT, r);
            }
            msg.end_nested(data);
            msg.end_nested(elem);
        }
        Expr::Synproxy { mss, wscale, flags } => {
            let elem = msg.begin_nested(NFTA_LIST_ELEM);
            msg.put_str(NFTA_EXPR_NAME, "synproxy");
            let data = msg.begin_nested(NFTA_EXPR_DATA);
            msg.put_u16_be(NFTA_SYNPROXY_MSS, *mss);
            msg.put_u8(NFTA_SYNPROXY_WSCALE, *wscale);
            msg.put_u32_be(NFTA_SYNPROXY_FLAGS, *flags);
            msg.end_nested(data);
            msg.end_nested(elem);
        }
        Expr::PayloadLoadReg { dreg, base, offset, len } => {
            let elem = msg.begin_nested(NFTA_LIST_ELEM);
            msg.put_str(NFTA_EXPR_NAME, "payload");
            let data = msg.begin_nested(NFTA_EXPR_DATA);
            msg.put_u32_be(NFTA_PAYLOAD_DREG, *dreg);
            msg.put_u32_be(NFTA_PAYLOAD_BASE, *base);
            msg.put_u32_be(NFTA_PAYLOAD_OFFSET, *offset);
            msg.put_u32_be(NFTA_PAYLOAD_LEN, *len);
            msg.end_nested(data);
            msg.end_nested(elem);
        }
        Expr::BitwiseReg { reg, mask, xor } => {
            // Wire layout (--debug=mnl on /sbin/nft 1.1.6):
            //   SREG (1), DREG (2), OP (6) = NFT_BITWISE_BOOL (0),
            //   LEN (3), MASK (4) nested NFTA_DATA_VALUE, XOR (5)
            //   nested NFTA_DATA_VALUE.
            // Note SREG, DREG come BEFORE OP, but OP comes BEFORE LEN
            // — the slot ordering is what nft picks, not numeric.
            // (My first pass put LEN immediately after DREG and skipped
            // OP entirely; the kernel accepted that, but the byte-diff
            // harness against upstream caught the layout drift.)
            const NFTA_BITWISE_OP: u16 = 6;
            const NFT_BITWISE_BOOL: u32 = 0;
            let elem = msg.begin_nested(NFTA_LIST_ELEM);
            msg.put_str(NFTA_EXPR_NAME, "bitwise");
            let data = msg.begin_nested(NFTA_EXPR_DATA);
            msg.put_u32_be(NFTA_BITWISE_SREG, *reg);
            msg.put_u32_be(NFTA_BITWISE_DREG, *reg);
            msg.put_u32_be(NFTA_BITWISE_OP, NFT_BITWISE_BOOL);
            msg.put_u32_be(NFTA_BITWISE_LEN, mask.len() as u32);
            msg.put_data_value(NFTA_BITWISE_MASK, mask);
            msg.put_data_value(NFTA_BITWISE_XOR, xor);
            msg.end_nested(data);
            msg.end_nested(elem);
        }
        Expr::Immediate { dreg, data: imm_data } => {
            // Free-standing `immediate reg X = <bytes>`. The pf-scrub
            // lowering uses this to seed PayloadSet / ExthdrSet inputs;
            // every other immediate-emitting path (NAT / DUP / FWD)
            // builds the expression inline so they don't share this arm.
            let elem = msg.begin_nested(NFTA_LIST_ELEM);
            msg.put_str(NFTA_EXPR_NAME, "immediate");
            let data = msg.begin_nested(NFTA_EXPR_DATA);
            msg.put_u32_be(NFTA_IMM_DREG, *dreg);
            msg.put_data_value(NFTA_IMM_DATA, imm_data);
            msg.end_nested(data);
            msg.end_nested(elem);
        }
        Expr::PayloadSet { base, offset, len, sreg, csum_type, csum_offset, csum_flags } => {
            // Wire layout (--debug=mnl against /sbin/nft 1.1.6):
            //   SREG (slot 5), BASE (2), OFFSET (3), LEN (4),
            //   CSUM_TYPE (6), CSUM_OFFSET (7).
            // Upstream omits CSUM_FLAGS (slot 8) when zero, so we do
            // too — emitting it would inflate NFTA_EXPR_DATA by 8 bytes
            // and break the byte-diff harness.
            // Critical: CSUM_TYPE must be NFT_PAYLOAD_CSUM_INET (1) and
            // CSUM_OFFSET must point at byte 10 (the IP header checksum
            // field) for any rewrite of bytes 0..20 of the IPv4 header,
            // otherwise the kernel forwards corrupt packets.
            let elem = msg.begin_nested(NFTA_LIST_ELEM);
            msg.put_str(NFTA_EXPR_NAME, "payload");
            let data = msg.begin_nested(NFTA_EXPR_DATA);
            msg.put_u32_be(NFTA_PAYLOAD_SREG, *sreg);
            msg.put_u32_be(NFTA_PAYLOAD_BASE, *base);
            msg.put_u32_be(NFTA_PAYLOAD_OFFSET, *offset);
            msg.put_u32_be(NFTA_PAYLOAD_LEN, *len);
            msg.put_u32_be(NFTA_PAYLOAD_CSUM_TYPE, *csum_type);
            msg.put_u32_be(NFTA_PAYLOAD_CSUM_OFFSET, *csum_offset);
            if *csum_flags != 0 {
                msg.put_u32_be(NFTA_PAYLOAD_CSUM_FLAGS, *csum_flags);
            }
            msg.end_nested(data);
            msg.end_nested(elem);
        }
        Expr::ExthdrSet { op, kind, offset, len, sreg } => {
            // Wire layout (--debug=netlink): exthdr write tcpopt reg N
            // => Lb @ <kind> + <offset>. The write side picks SREG
            // (slot 7) instead of the read-side DREG (slot 1); TYPE is
            // the option kind (2 = MSS), OFFSET is the offset *inside*
            // the option payload (2 for MSS — past the 1-byte kind and
            // 1-byte length), LEN is the byte width, OP=TCPOPT (1).
            let elem = msg.begin_nested(NFTA_LIST_ELEM);
            msg.put_str(NFTA_EXPR_NAME, "exthdr");
            let data = msg.begin_nested(NFTA_EXPR_DATA);
            msg.put_u32_be(NFTA_EXTHDR_SREG, *sreg);
            msg.put_bytes(NFTA_EXTHDR_TYPE, &[*kind]);
            msg.put_u32_be(NFTA_EXTHDR_OFFSET, *offset);
            msg.put_u32_be(NFTA_EXTHDR_LEN, *len);
            msg.put_u32_be(NFTA_EXTHDR_OP, *op);
            msg.end_nested(data);
            msg.end_nested(elem);
        }
        Expr::Byteorder { sreg, dreg, op, len, size } => {
            let elem = msg.begin_nested(NFTA_LIST_ELEM);
            msg.put_str(NFTA_EXPR_NAME, "byteorder");
            let data = msg.begin_nested(NFTA_EXPR_DATA);
            msg.put_u32_be(NFTA_BYTEORDER_SREG, *sreg);
            msg.put_u32_be(NFTA_BYTEORDER_DREG, *dreg);
            msg.put_u32_be(NFTA_BYTEORDER_OP, *op);
            msg.put_u32_be(NFTA_BYTEORDER_LEN, *len);
            msg.put_u32_be(NFTA_BYTEORDER_SIZE, *size);
            msg.end_nested(data);
            msg.end_nested(elem);
        }
        // Valid-but-unimplemented nft expressions: recognised during
        // parsing to keep the rule non-empty; produce no netlink output.
        Expr::Unimplemented => {}
    }
}

// ── Integration tests (require root + Linux kernel with nf_tables) ──
// Run with: cargo test -- --ignored
// Each test uses a unique table name to avoid conflicts when running in parallel.

#[cfg(test)]
mod tests {
    use super::*;
    use std::sync::atomic::{AtomicU32, Ordering};

    static TABLE_ID: AtomicU32 = AtomicU32::new(1);

    fn run(ctx: &mut NftCtx, input: &str) -> io::Result<()> {
        let cmds = crate::parser::parse(input).map_err(|e| io::Error::new(io::ErrorKind::Other, e))?;
        for cmd in &cmds { ctx.exec(cmd)?; }
        Ok(())
    }

    /// Create a context and a unique table name for this test.
    fn setup() -> (NftCtx, String) {
        let ctx = NftCtx::new().expect("failed to open netlink socket (need root?)");
        let id = TABLE_ID.fetch_add(1, Ordering::SeqCst);
        let table = format!("t{}", id);
        (ctx, table)
    }

    fn cleanup(ctx: &mut NftCtx, table: &str) {
        run(ctx, &format!("delete table inet {}", table)).ok();
    }

    // ── Table operations ────────────────────────────────────────

    #[test]
    #[ignore] // requires root + nf_tables kernel
    fn test_add_table() {
        let (mut ctx, t) = setup();
        run(&mut ctx, &format!("add table inet {}", t)).unwrap();
        cleanup(&mut ctx, &t);
    }

    #[test]
    #[ignore]
    fn test_add_table_all_families() {
        let (mut ctx, t) = setup();
        run(&mut ctx, &format!("add table ip {}", t)).unwrap();
        run(&mut ctx, &format!("add table ip6 {}v6", t)).unwrap();
        run(&mut ctx, &format!("add table inet {}inet", t)).unwrap();
        run(&mut ctx, &format!("add table bridge {}br", t)).unwrap();
        run(&mut ctx, &format!("delete table ip {}", t)).ok();
        run(&mut ctx, &format!("delete table ip6 {}v6", t)).ok();
        run(&mut ctx, &format!("delete table inet {}inet", t)).ok();
        run(&mut ctx, &format!("delete table bridge {}br", t)).ok();
    }

    #[test]
    #[ignore]
    fn test_delete_table() {
        let (mut ctx, t) = setup();
        run(&mut ctx, &format!("add table inet {}", t)).unwrap();
        run(&mut ctx, &format!("delete table inet {}", t)).unwrap();
    }

    #[test]
    #[ignore]
    fn test_flush_table() {
        let (mut ctx, t) = setup();
        run(&mut ctx, &format!("add table inet {}", t)).unwrap();
        run(&mut ctx, &format!("add chain inet {} c1", t)).unwrap();
        run(&mut ctx, &format!("flush table inet {}", t)).unwrap();
        cleanup(&mut ctx, &t);
    }

    // ── Chain operations ────────────────────────────────────────

    #[test]
    #[ignore]
    fn test_add_base_chain() {
        let (mut ctx, t) = setup();
        run(&mut ctx, &format!("add table inet {}", t)).unwrap();
        run(&mut ctx, &format!(
            r#"add chain inet {} input {{ type filter hook input priority filter; policy accept; }}"#, t
        )).unwrap();
        cleanup(&mut ctx, &t);
    }

    #[test]
    #[ignore]
    fn test_add_regular_chain() {
        let (mut ctx, t) = setup();
        run(&mut ctx, &format!("add table inet {}", t)).unwrap();
        run(&mut ctx, &format!("add chain inet {} mychain", t)).unwrap();
        cleanup(&mut ctx, &t);
    }

    #[test]
    #[ignore]
    fn test_rename_chain() {
        let (mut ctx, t) = setup();
        run(&mut ctx, &format!("add table inet {}", t)).unwrap();
        run(&mut ctx, &format!("add chain inet {} old", t)).unwrap();
        run(&mut ctx, &format!("rename chain inet {} old new", t)).unwrap();
        cleanup(&mut ctx, &t);
    }

    #[test]
    #[ignore]
    fn test_delete_chain() {
        let (mut ctx, t) = setup();
        run(&mut ctx, &format!("add table inet {}", t)).unwrap();
        run(&mut ctx, &format!("add chain inet {} mychain", t)).unwrap();
        run(&mut ctx, &format!("delete chain inet {} mychain", t)).unwrap();
        cleanup(&mut ctx, &t);
    }

    #[test]
    #[ignore]
    fn test_flush_chain() {
        let (mut ctx, t) = setup();
        run(&mut ctx, &format!("add table inet {}", t)).unwrap();
        run(&mut ctx, &format!(
            r#"add chain inet {} input {{ type filter hook input priority filter; policy accept; }}"#, t
        )).unwrap();
        run(&mut ctx, &format!("add rule inet {} input accept", t)).unwrap();
        run(&mut ctx, &format!("flush chain inet {} input", t)).unwrap();
        cleanup(&mut ctx, &t);
    }

    // ── Rule expressions ────────────────────────────────────────

    #[test]
    #[ignore]
    fn test_rule_tcp_dport() {
        let (mut ctx, t) = setup();
        run(&mut ctx, &format!("add table inet {}", t)).unwrap();
        run(&mut ctx, &format!(
            r#"add chain inet {} input {{ type filter hook input priority filter; policy accept; }}"#, t
        )).unwrap();
        run(&mut ctx, &format!("add rule inet {} input tcp dport 22 accept", t)).unwrap();
        cleanup(&mut ctx, &t);
    }

    #[test]
    #[ignore]
    fn test_rule_ct_state() {
        let (mut ctx, t) = setup();
        run(&mut ctx, &format!("add table inet {}", t)).unwrap();
        run(&mut ctx, &format!(
            r#"add chain inet {} input {{ type filter hook input priority filter; policy accept; }}"#, t
        )).unwrap();
        run(&mut ctx, &format!("add rule inet {} input ct state established,related accept", t)).unwrap();
        run(&mut ctx, &format!("add rule inet {} input ct state new accept", t)).unwrap();
        cleanup(&mut ctx, &t);
    }

    #[test]
    #[ignore]
    fn test_rule_cidr() {
        let (mut ctx, t) = setup();
        run(&mut ctx, &format!("add table inet {}", t)).unwrap();
        run(&mut ctx, &format!(
            r#"add chain inet {} input {{ type filter hook input priority filter; policy accept; }}"#, t
        )).unwrap();
        run(&mut ctx, &format!("add rule inet {} input ip saddr 10.0.0.0/8 drop", t)).unwrap();
        run(&mut ctx, &format!("add rule inet {} input ip saddr 192.168.1.0/24 accept", t)).unwrap();
        cleanup(&mut ctx, &t);
    }

    #[test]
    #[ignore]
    fn test_rule_counter() {
        let (mut ctx, t) = setup();
        run(&mut ctx, &format!("add table inet {}", t)).unwrap();
        run(&mut ctx, &format!(
            r#"add chain inet {} input {{ type filter hook input priority filter; policy accept; }}"#, t
        )).unwrap();
        run(&mut ctx, &format!("add rule inet {} input counter drop", t)).unwrap();
        cleanup(&mut ctx, &t);
    }

    #[test]
    #[ignore]
    fn test_rule_log() {
        let (mut ctx, t) = setup();
        run(&mut ctx, &format!("add table inet {}", t)).unwrap();
        run(&mut ctx, &format!(
            r#"add chain inet {} input {{ type filter hook input priority filter; policy accept; }}"#, t
        )).unwrap();
        run(&mut ctx, &format!(r#"add rule inet {} input log prefix "test: " accept"#, t)).unwrap();
        cleanup(&mut ctx, &t);
    }

    #[test]
    #[ignore]
    fn test_insert_rule() {
        let (mut ctx, t) = setup();
        run(&mut ctx, &format!("add table inet {}", t)).unwrap();
        run(&mut ctx, &format!(
            r#"add chain inet {} input {{ type filter hook input priority filter; policy accept; }}"#, t
        )).unwrap();
        run(&mut ctx, &format!("add rule inet {} input tcp dport 80 accept", t)).unwrap();
        run(&mut ctx, &format!("insert rule inet {} input tcp dport 443 accept", t)).unwrap();
        cleanup(&mut ctx, &t);
    }

    // ── Set operations ──────────────────────────────────────────

    #[test]
    #[ignore]
    fn test_add_set() {
        let (mut ctx, t) = setup();
        run(&mut ctx, &format!("add table inet {}", t)).unwrap();
        run(&mut ctx, &format!(r#"add set inet {} blocklist {{ type ipv4_addr; }}"#, t)).unwrap();
        cleanup(&mut ctx, &t);
    }

    #[test]
    #[ignore]
    fn test_add_delete_elements() {
        let (mut ctx, t) = setup();
        run(&mut ctx, &format!("add table inet {}", t)).unwrap();
        run(&mut ctx, &format!(r#"add set inet {} blocklist {{ type ipv4_addr; }}"#, t)).unwrap();
        run(&mut ctx, &format!(r#"add element inet {} blocklist {{ 192.168.1.1, 10.0.0.1 }}"#, t)).unwrap();
        run(&mut ctx, &format!(r#"delete element inet {} blocklist {{ 10.0.0.1 }}"#, t)).unwrap();
        cleanup(&mut ctx, &t);
    }

    #[test]
    #[ignore]
    fn test_delete_set() {
        let (mut ctx, t) = setup();
        run(&mut ctx, &format!("add table inet {}", t)).unwrap();
        run(&mut ctx, &format!(r#"add set inet {} blocklist {{ type ipv4_addr; }}"#, t)).unwrap();
        run(&mut ctx, &format!("delete set inet {} blocklist", t)).unwrap();
        cleanup(&mut ctx, &t);
    }

    // ── List operations ─────────────────────────────────────────

    #[test]
    #[ignore]
    fn test_list_ruleset() {
        let (mut ctx, t) = setup();
        run(&mut ctx, &format!("add table inet {}", t)).unwrap();
        run(&mut ctx, &format!(
            r#"add chain inet {} input {{ type filter hook input priority filter; policy accept; }}"#, t
        )).unwrap();
        run(&mut ctx, "list ruleset").unwrap();
        cleanup(&mut ctx, &t);
    }

    #[test]
    #[ignore]
    fn test_list_table() {
        let (mut ctx, t) = setup();
        run(&mut ctx, &format!("add table inet {}", t)).unwrap();
        run(&mut ctx, &format!("list table inet {}", t)).unwrap();
        cleanup(&mut ctx, &t);
    }

    #[test]
    #[ignore]
    fn test_list_tables() {
        let (mut ctx, t) = setup();
        run(&mut ctx, &format!("add table inet {}", t)).unwrap();
        run(&mut ctx, "list tables").unwrap();
        cleanup(&mut ctx, &t);
    }

    #[test]
    #[ignore]
    fn test_list_chains() {
        let (mut ctx, t) = setup();
        run(&mut ctx, &format!("add table inet {}", t)).unwrap();
        run(&mut ctx, &format!(
            r#"add chain inet {} input {{ type filter hook input priority filter; policy accept; }}"#, t
        )).unwrap();
        run(&mut ctx, "list chains").unwrap();
        cleanup(&mut ctx, &t);
    }

    #[test]
    #[ignore]
    fn test_list_with_handles() {
        let (mut ctx, t) = setup();
        ctx.show_handles = true;
        run(&mut ctx, &format!("add table inet {}", t)).unwrap();
        run(&mut ctx, &format!(
            r#"add chain inet {} input {{ type filter hook input priority filter; policy accept; }}"#, t
        )).unwrap();
        run(&mut ctx, &format!("add rule inet {} input accept", t)).unwrap();
        run(&mut ctx, "list ruleset").unwrap();
        cleanup(&mut ctx, &t);
    }

    // ── Flush operations ────────────────────────────────────────

    #[test]
    #[ignore]
    fn test_flush_ruleset() {
        // This test uses flush ruleset which affects all tables, so it
        // creates and flushes its own isolated table instead.
        let (mut ctx, t) = setup();
        run(&mut ctx, &format!("add table inet {}", t)).unwrap();
        run(&mut ctx, &format!(
            r#"add chain inet {} c1 {{ type filter hook input priority filter; policy accept; }}"#, t
        )).unwrap();
        run(&mut ctx, &format!("add rule inet {} c1 accept", t)).unwrap();
        run(&mut ctx, &format!("flush table inet {}", t)).unwrap();
        cleanup(&mut ctx, &t);
    }

    // ── Full workflow ───────────────────────────────────────────

    #[test]
    #[ignore]
    fn test_full_firewall_setup() {
        let (mut ctx, t) = setup();
        run(&mut ctx, &format!("add table inet {}", t)).unwrap();
        run(&mut ctx, &format!(
            r#"add chain inet {} input {{ type filter hook input priority filter; policy accept; }}"#, t
        )).unwrap();
        run(&mut ctx, &format!(r#"add set inet {} blocklist {{ type ipv4_addr; }}"#, t)).unwrap();
        run(&mut ctx, &format!(r#"add element inet {} blocklist {{ 192.168.1.1 }}"#, t)).unwrap();
        run(&mut ctx, &format!("add rule inet {} input ct state established,related accept", t)).unwrap();
        run(&mut ctx, &format!("add rule inet {} input tcp dport 22 accept", t)).unwrap();
        run(&mut ctx, &format!("add rule inet {} input tcp dport 80 accept", t)).unwrap();
        run(&mut ctx, &format!("add rule inet {} input tcp dport 443 accept", t)).unwrap();
        run(&mut ctx, &format!("add rule inet {} input ip saddr 10.0.0.0/8 drop", t)).unwrap();
        run(&mut ctx, &format!("add rule inet {} input counter drop", t)).unwrap();
        run(&mut ctx, "list ruleset").unwrap();
        cleanup(&mut ctx, &t);
    }
}
