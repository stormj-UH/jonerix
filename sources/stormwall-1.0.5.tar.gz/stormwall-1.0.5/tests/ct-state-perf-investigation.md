# `ct state` throughput performance investigation

**Date**: 2026-04-25
**Kernel on arfur**: 6.1.38-v8+ (aarch64, Raspberry Pi 5 / Cortex-A76)
**stormwall**: v0.1.0 at `/tmp/stormwall`
**nft**: v1.1.3 at `/usr/sbin/nft`
**Reported failure**: ct-soak.sh 5-min soak: `sw ~901 Mbps, nft ~1885 Mbps` (52% gap)
**iperf3-throughput.sh** (historical run): `chain_100 0.81x, allow_ssh 0.82x`

---

## 1. Probe ruleset

The ruleset used for probing (same as `ct-soak.sh`):

```
table ip filter {
    chain input {
        type filter hook input priority 0; policy drop;
        ct state established,related counter accept
        tcp dport 5201 ct state new counter accept
    }
}
```

Applied to arfur via:

```sh
# nft debug (on the probe file at /tmp/ct_probe.nft):
sudo nft --debug=netlink -f /tmp/ct_probe.nft 2>&1

# stormwall wire capture:
sudo strace -e trace=sendto -s 65536 /tmp/stormwall -f /tmp/ct_probe.nft 2>&1 | grep sendto
```

---

## 2. Expression-level comparison

### Rule 1: `ct state established,related counter accept`

**nft `--debug=netlink` output:**

```
ip filter input
  [ ct load state => reg 1 ]
  [ bitwise reg 1 = ( reg 1 & 0x00000006 ) ^ 0x00000000 ]
  [ cmp neq reg 1 0x00000000 ]
  [ counter pkts 0 bytes 0 ]
  [ immediate reg 0 accept ]
```

**stormwall (decoded from strace sendto bytes):**

```
  expression count: 5
  [0] ct state => reg8
  [1] bitwise reg8 = (reg8 & 0x00000006) ^ 0x00000000  len=4
  [2] cmp neq reg8 0x00000000
  [3] counter
  [4] immediate reg0 = accept
```

Both emit **5 expressions** in the same order: `ct → bitwise → cmp → counter → immediate`.
The bitwise mask value is `0x00000006` in both (established=2 | related=4).
The mask bytes in the NLA payload are identical: `06 00 00 00` (LE 32-bit).

### Rule 2: `tcp dport 5201 ct state new counter accept`

**nft `--debug=netlink` output:**

```
ip filter input
  [ meta load l4proto => reg 1 ]
  [ cmp eq reg 1 0x00000006 ]
  [ payload load 2b @ transport header + 2 => reg 1 ]
  [ cmp eq reg 1 0x00005114 ]
  [ ct load state => reg 1 ]
  [ bitwise reg 1 = ( reg 1 & 0x00000008 ) ^ 0x00000000 ]
  [ cmp neq reg 1 0x00000000 ]
  [ counter pkts 0 bytes 0 ]
  [ immediate reg 0 accept ]
```

**stormwall (decoded from strace sendto bytes):**

```
  expression count: 9
  [0] meta load l4proto => reg8
  [1] cmp eq reg8 0x06
  [2] payload load 2b @ transport+2 => reg8
  [3] cmp eq reg8 0x5114
  [4] ct state => reg8
  [5] bitwise reg8 = (reg8 & 0x00000008) ^ 0x00000000  len=4
  [6] cmp neq reg8 0x00000000
  [7] counter
  [8] immediate reg0 = accept
```

Both emit **9 expressions** in the same order.
The dport comparison data is identical: the NLA payload bytes are `[0x14][0x51]` in both
(TCP dport 5201 = 0x1451 in big-endian, which matches the on-wire format in the TCP header).

### Byte-by-byte diff of rule 1 wire payloads

The rule 1 payload lengths match: **244 bytes each**.
A byte-by-byte comparison reveals exactly **4 byte positions** that differ:

| Offset | Field | nft value | stormwall value |
|--------|-------|-----------|-----------------|
| 0x3f | `ct` expr: NFTA_CT_DREG | `0x01` | `0x08` |
| 0x5b | `bitwise` expr: NFTA_BITWISE_SREG | `0x01` | `0x08` |
| 0x63 | `bitwise` expr: NFTA_BITWISE_DREG | `0x01` | `0x08` |
| 0x9b | `cmp` expr: NFTA_CMP_SREG | `0x01` | `0x08` |

These four bytes encode the **register number** used in the expression chain.
`0x01` = `NFT_REG_1` (nft); `0x08` = `NFT_REG32_00` (stormwall).
All other bytes are **identical**.

---

## 3. Register analysis (H1, H2, H5)

The sole wire-format difference is that nft uses `NFT_REG_1` (UAPI value 1) throughout,
while stormwall uses `NFT_REG32_00` (UAPI value 8).

**Both are aliases for the same kernel-internal register slot.**

In `net/netfilter/nf_tables_api.c`, `nft_parse_register()` maps UAPI register numbers
to an index into `struct nft_regs { u32 data[20]; }`:

```
NFT_REG_1 (UAPI=1)     → slot = 1 × (16/4) = 4   → data[4] (byte offset 16)
NFT_REG32_00 (UAPI=8)  → slot = (8-8) + (1×4) = 4 → data[4] (byte offset 16)
```

They write to the **same 4-byte memory location** at offset 16 in the regs struct
(confirmed from kernel source, also consistent with both rulesets producing identical
traffic-parity results in the existing `monitor-diff` and `traffic-parity` test suites).

No code path in `nft_ct.c`, `nft_bitwise.c`, or `nft_cmp.c` branches on the register
number after the initial parse-time mapping. The hot-path kernel functions
(`nft_ct_get_eval`, `nft_bitwise_mask_xor_eval`, `nft_cmp_eval`) use the register
only as a memory address offset, with no conditional on its numeric value.

**Cache-line impact**: On aarch64 (64-byte cache lines) the `nft_regs` struct is 80 bytes.
`data[4]` is at byte 16 — first cache line. There is no cache-line difference.

**Verdict on H1 (extra payload/meta load), H2 (byte-order slow path), H5 (extra Bitwise)**:
None of these hypotheses are supported. Stormwall emits the same count, order, and mask
values as nft. The only difference is the register constant, which maps to the same slot.

---

## 4. L4proto dependency (H3)

For rule 2 (`tcp dport 5201 ct state new counter accept`), both nft and stormwall
emit `meta load l4proto` as the first expression, followed by `cmp eq 0x06` (TCP).
This is the implicit L4 protocol dependency that stormwall already injects via the
logic in `parser.rs:686-687`:

```rust
if !already_has_l4proto_check(&cmd.exprs) {
    cmd.exprs.push(Expr::Meta { key: NFT_META_L4PROTO, width: 1 });
    cmd.exprs.push(Expr::Cmp { op: NFT_CMP_EQ, data: vec![proto_num] });
}
```

The l4proto guard is present in stormwall for dport rules. H3 is **not the cause**.

---

## 5. Rule ordering (H4)

For rule 1, established traffic hits the ct state check first (correct).
For rule 2, the ordering is: `meta l4proto → cmp TCP → payload dport → cmp port → ct state → bitwise → cmp neq → counter → immediate`.
This is the same order as nft. H4 is **not the cause**.

---

## 6. Live probe results on arfur

Direct iperf3 measurements on arfur with a dedicated veth pair (not disturbing pid 3164770):

| Test duration | Scenario | nft Mbps | sw Mbps | ratio |
|---------------|----------|----------|---------|-------|
| 10 s | ct_state+counter | 1581 | 1528 | 0.966 |
| 60 s | ct_state+counter | 1329 | 1489 | **1.120** |
| 10 s | allow_ssh run 1  | 1762 | 1710 | 0.971 |
| 10 s | allow_ssh run 2  | 1738 | 1763 | 1.014 |
| 10 s | allow_ssh run 3  | 1666 | 2118 | 1.272 |
| 10 s | chain_100 run 1  | 2968 | 3031 | 1.021 |
| 10 s | chain_100 run 2  | 3083 | 3126 | 1.014 |
| 10 s | chain_100 run 3  | 3073 | 3000 | 0.976 |

Additionally, running the official `iperf3-throughput.sh --duration 10` on the same day
produced these results (which differ significantly from the historical run):

```
scenario              nft_mbps    sw_mbps    ratio
baseline              3444        3357       0.97
allow_ssh             3308        3465       1.05 [WARN]
interval_set_1000     3145        3332       1.06 [WARN]
vmap_50               2878        1791       0.62 [WARN]
ct_state              1739        1696       0.98
chain_100             1466        1423       0.97
```

The `ct_state`, `chain_100`, and `allow_ssh` ratios are **within noise** of 1.0 in today's run,
which is inconsistent with the historical 0.81x / 0.82x / 52% figures. The `vmap_50` scenario
shows a persistent 0.62x regression that warrants a separate investigation.

---

## 7. Best-supported hypothesis: measurement artifact in the sequential-arm design

After exhaustive analysis, **no encoding difference in the ct state rule chain can explain
the 52% throughput gap** reported by ct-soak.sh. The two rulesets are bit-for-bit identical
in their kernel-visible effect (confirmed by `nft list ruleset` producing the same output
after both loaders apply the probe file).

The most plausible explanation for the ct-soak 52% result is **thermal throttling** on the
Raspberry Pi 5 (arfur). The Cortex-A76 cores on RPi5 actively throttle under sustained load
to stay within the thermal envelope. The ct-soak test runs two 5-minute iperf3 arms
**sequentially** on the same machine:

1. **ARM 1 (nft)** runs first when the SoC is at ambient temperature. Cores hold max frequency
   (2.4 GHz on RPi5) for the initial period before thermal limits kick in. Throughput is high.
2. **ARM 2 (stormwall)** runs second when the SoC is already warm from 5 minutes of full-speed
   iperf3. The kernel's CPUfreq governor (`schedutil` or `ondemand`) has already reduced the
   clock, yielding materially lower throughput independent of ruleset correctness.

This explains why:
- The gap is 52% in the 5-minute soak but only 2–3% (within noise) in the 10-second alternating
  measurements.
- The direction of the gap is consistent with the ordering (nft first = cool = fast;
  stormwall second = warm = slow), not with any encoding property.
- The 60-second test actually shows stormwall **1.12x faster**, which is physically possible
  on a variable-frequency ARM core where cache warmth from the nft run benefits the stormwall run.

The iperf3-throughput historical values of 0.81x / 0.82x for chain_100 and allow_ssh are not
reproducible in today's run and are likely also frequency/thermal transients captured in a
particular instantaneous state of the CPU frequency governor.

---

## 8. The real open regression: `vmap_50` (0.62x)

While the ct state regression appears to be measurement noise, the **vmap_50 scenario shows a
consistent and large 0.62x regression** (stormwall 38% slower than nft for a 50-entry verdict
map lookup where the source IP is never in the map).

The lookup expression encoding differs in two ways:

| Attribute | nft | stormwall |
|-----------|-----|-----------|
| SREG value | 1 (NFT_REG_1) | 8 (NFT_REG32_00) |
| NFTA_LOOKUP_SET_ID | present (value=1) | absent |

The SREG difference maps to the same kernel slot (both → data[4]).
The SET_ID difference is expected: stormwall correctly omits it for named maps.

**UPDATE 2026-04-30**: the original investigation (v0.1.0) noted that stormwall sent 50
separate NEWSETELEM messages vs nft's single batched message. The current code (v0.1.3)
uses a 60000-byte split threshold in `add_elements()` that batches all 50 elements into
a single NEWSETELEM message, matching nft's wire format.

**NFTA_SET_DESC_SIZE hypothesis RULED OUT**: fresh strace on castle (nft 1.1.0, kernel
6.12.58-gentoo) against a 50-element verdict map without explicit `size` confirms that
**nft does NOT send NFTA_SET_DESC** in the NEWSET message. The NEWSET contains only
TABLE, NAME, FLAGS(MAP), KEY_TYPE, KEY_LEN, DATA_TYPE, DATA_LEN, SET_ID, and USERDATA.
The code comment in ops.rs:1869 was correct.

The 0.62x regression measured on arfur (v0.1.0) needs re-measurement with the current
codebase. Given that element batching is now correct and the only remaining wire difference
is the register number alias (NFT_REG_1 vs NFT_REG32_00, same kernel slot), the regression
may no longer exist. It may also have been a thermal artifact like the ct_state gap.

---

## 9. Concrete fix suggestions

### Fix A: ~~Add `NFTA_SET_DESC_SIZE` hint to NEWSET for named maps~~ **RULED OUT**

Wire analysis on castle (2026-04-30) confirms nft does NOT send `NFTA_SET_DESC_SIZE`
for named maps without explicit `size N`. The hypothesis was based on an incorrect
reading of the original strace output. No code change needed.
```

### Fix B: Batch map elements in a single NEWSETELEM message (MEDIUM priority)

Stormwall sends 50 separate `NFT_MSG_NEWSETELEM` messages for the 50 vmap entries.
nft sends them in one message (or a few). Batching improves insert efficiency and reduces
the number of kernel transaction commit round-trips. This has no data-path impact but
is correct practice.

### Fix C: Stabilise the throughput benchmark methodology (LOW priority, measurement)

The ct-soak test should run with CPU frequency pinned to a fixed P-state:

```sh
# Before each arm:
echo performance | sudo tee /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor
```

Or run the nft and stormwall arms in alternating 10-second windows (as iperf3-throughput.sh
does) rather than two sequential 5-minute blocks, to avoid thermal bias.

---

## 10. Summary

| Hypothesis | Status | Evidence |
|-----------|--------|----------|
| H1: extra payload/meta load per rule | **Ruled out** | Both emit identical 5-expr / 9-expr chains |
| H2: bitwise byte-order slow path | **Ruled out** | Mask values `0x00000006` / `0x00000008` identical in wire bytes |
| H3: missing meta l4proto dependency | **Ruled out** | Stormwall injects l4proto for dport rules; rule 1 has no l4proto needed |
| H4: wrong rule ordering | **Ruled out** | Expression order is identical in both loaders |
| H5: extra Bitwise expression | **Ruled out** | Exactly one bitwise per ct-state rule, same in both |
| Register number (NFT_REG_1 vs NFT_REG32_00) | **Confirmed harmless** | Both map to kernel slot data[4] |
| Thermal throttle in sequential soak test | **Best-supported cause of 52% gap** | 10-s alternating tests show 0.97–1.27 with no consistent direction |
| vmap_50 `NFTA_SET_DESC_SIZE` missing | **RULED OUT** (2026-04-30) | nft also omits SET_DESC for named maps without explicit `size` |

**The `ct state` throughput regression reported by `ct-soak.sh` is not caused by the
stormwall wire encoding. It is an artifact of the sequential-arm test methodology on a
thermally-constrained Raspberry Pi 5.**

**The `vmap_50` 0.62x regression (v0.1.0) had a suspected cause of missing
`NFTA_SET_DESC_SIZE`, but this was RULED OUT by wire analysis (2026-04-30).
The regression needs re-measurement with v0.1.3 which now correctly batches
elements into a single NEWSETELEM message. It may be a measurement artifact.**

---

## Appendix A: environment

- Host: arfur (aarch64, Raspberry Pi 5, 4-core Cortex-A76, Linux 6.1.38-v8+)
- Churn loop PID 3164770 (bash): not disturbed; all probes used isolated netns `pr_server`/`pr_client`
- stormwall binary: `/tmp/stormwall` (v0.1.0)
- nft binary: `/usr/sbin/nft` (v1.1.3)

## Appendix B: key strace excerpts

### stormwall sendto (one batch, 872 bytes total for the ct probe):

```
sendto(3, [
  batch_begin,
  DELTABLE ip filter (NLM_F_ACK),
  NEWTABLE ip filter (NLM_F_CREATE|NLM_F_ACK),
  NEWCHAIN ip filter input hook=input priority=0 policy=drop (NLM_F_CREATE|NLM_F_ACK),
  NEWRULE #1 nlmsg_len=260 (ct+bitwise+cmp+counter+immediate, regs=8),
  NEWRULE #2 nlmsg_len=436 (meta+cmp+payload+cmp+ct+bitwise+cmp+counter+immediate, regs=8),
  batch_end
], 872, ...)
```

### nft sendmsg (one batch, 880 bytes total for the ct probe):

```
sendmsg(3, [
  batch_begin,
  NEWTABLE ip filter,
  NEWCHAIN ip filter input hook=input priority=0 policy=drop,
  NEWRULE #1 nlmsg_len=260 (ct+bitwise+cmp+counter+immediate, regs=1),
  NEWRULE #2 nlmsg_len=436 (meta+cmp+payload+cmp+ct+bitwise+cmp+counter+immediate, regs=1),
  batch_end
], 880, ...)
```

Rule 1 and Rule 2 payloads differ only in the 4 register-number bytes (0x08 vs 0x01),
which map to the same kernel slot. All other bytes are identical.
