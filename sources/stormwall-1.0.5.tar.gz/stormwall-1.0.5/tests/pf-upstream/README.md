# pf-upstream — reference-only

These files are vendored verbatim from the OpenBSD source tree as a grammar
reference for stormwall's hand-written pf parser. They are NOT compiled into
stormwall, NOT linked into any cargo build path, and MUST NOT be edited.

## Files

- `parse.y` — pfctl grammar (BSD-2-Clause)
  source: https://github.com/openbsd/src/blob/master/sbin/pfctl/parse.y
- `pfvar.h` — pf kernel UAPI (BSD-2-Clause)
  source: https://github.com/openbsd/src/blob/master/sys/net/pfvar.h

## Last sync

Upstream commit: `04e2410ca848bb4089e04aa1decfee122bb47b16`
Sync date: 2026-04-29 (UTC)

## License

Both files retain their original BSD-2-Clause / ISC headers as shipped by
upstream. Any redistribution of stormwall that bundles this directory must
preserve those headers.
