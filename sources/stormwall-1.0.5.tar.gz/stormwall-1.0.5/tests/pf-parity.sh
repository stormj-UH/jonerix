#!/bin/sh
# tests/pf-parity.sh — pf <-> nft byte-equivalence harness.
#
# For each tests/pf-corpus/*.pf file we:
#   1. Run `stormwall --pf --dump-exprs -f $pf` and capture the
#      bracketed expression listing.
#   2. Compare it to the upstream `nft --debug=netlink` output frozen
#      under tests/pf-corpus/strace/${name}.strace (the parser-stage
#      lines starting with "  [ ").
#
# Why bracketed format and not raw netlink bytes? The nlmsg/nfgenmsg
# headers carry transient values (seq numbers, port IDs) that diverge
# between every run; the bracketed form is the parser-stage abstract
# rule the kernel will execute, identical between any two emitters
# that use the same expression encoding. We separately verify the
# attribute-byte layout matches by inspection of NLDUMP captures
# (notes in commit message).
#
# Pi-side monitor-diff verification: SKIPPED. jonerix-tormenta was
# offline at PR time (ssh timeout, ping 100% loss). TODO: when the Pi
# is back, run `nft monitor` against the kernel-applied output of
# stormwall vs upstream nft and confirm the trace decodes match.
#
# Feature #9 (cheap-wins) Pi-side end-to-end apply was verified by hand
# during PR landing — all four sub-features (`antispoof for em0`,
# `set skip on lo`, `pass ... hours { 9-17 }`, `block return-rst proto
# tcp port 65000`) apply with rc=0 on jonerix-tormenta against a
# uniquely-named `ip pf` table, then `delete table ip pf` cleans up.
# Note: a `block return-rst proto tcp port 22` rule WILL kick the
# admin's own SSH connection — use a dummy port (65000+) for live
# verification.
#
# POSIX-only: /bin/sh = mksh, no bashisms.

set -eu

CORPUS="$(dirname "$0")/pf-corpus"
STORMWALL="${STORMWALL:-./target/debug/stormwall}"
WORK="${WORK:-/tmp/pf-parity-$$}"
mkdir -p "$WORK"

PASS=0
FAIL=0
SKIP=0

# Map pf-corpus file -> strace reference. The mapping uses sub-feature
# basenames, so 01a_scrub_no_df.pf checks 01_scrub_no_df.strace.
ref_for() {
    base=$1
    case "$base" in
        01_scrub)               printf '01_scrub_combined.strace\n';;
        01a_scrub_no_df)        printf '01_scrub_no_df.strace\n';;
        01b_scrub_random_id)    printf '01_scrub_random_id.strace\n';;
        01c_scrub_min_ttl)      printf '01_scrub_min_ttl.strace\n';;
        01d_scrub_max_mss)      printf '01_scrub_max_mss.strace\n';;
        02_srctrack)            printf '02_srctrack_combined.strace\n';;
        02a_max_src_conn)       printf '02_srctrack_max_src_conn.strace\n';;
        02b_max_src_conn_rate)  printf '02_srctrack_max_src_conn_rate.strace\n';;
        02c_max_src_states)     printf '02_srctrack_max_src_states.strace\n';;
        02d_overload)           printf '02_srctrack_overload.strace\n';;
        09a_antispoof)          printf '09a_antispoof.strace\n';;
        09b_set_skip)           printf '09b_set_skip.strace\n';;
        09c_time_based)         printf '09c_time_based.strace\n';;
        09d_block_return)       printf '09d_block_return.strace\n';;
        15_log_basic)           printf '15_log_basic.strace\n';;
        16_routing_actions)     printf '16_routing_actions.strace\n';;
        17_nat_to)              printf '17_nat_to.strace\n';;
        18_tables)              printf '18_tables.strace\n';;
        19_anchors)             printf '19_anchors.strace\n';;
        20_state_flags)         printf '20_state_flags.strace\n';;
        21_queue)               printf '21_queue.strace\n';;
        *) return 1;;
    esac
}

# Pull just the bracketed expression lines from a file.
grep_exprs() {
    grep -E '^  \[ ' "$1" || true
}

run_case() {
    pf_file=$1
    name=$(basename "$pf_file" .pf)

    if ! ref_name=$(ref_for "$name"); then
        printf 'SKIP %s — no reference strace mapped\n' "$name"
        SKIP=$(( SKIP + 1 )); return
    fi
    ref_path="$CORPUS/strace/$ref_name"
    if [ ! -f "$ref_path" ]; then
        printf 'SKIP %s — reference %s missing\n' "$name" "$ref_path"
        SKIP=$(( SKIP + 1 )); return
    fi

    sw_out="$WORK/${name}.sw"
    if ! "$STORMWALL" --pf --dump-exprs -f "$pf_file" >"$sw_out" 2>"$WORK/${name}.err"; then
        printf 'FAIL %s — stormwall exited non-zero:\n' "$name"
        cat "$WORK/${name}.err"
        FAIL=$(( FAIL + 1 )); return
    fi

    sw_lines="$WORK/${name}.sw.exprs"
    ref_lines="$WORK/${name}.ref.exprs"
    grep_exprs "$sw_out" > "$sw_lines"
    grep_exprs "$ref_path" > "$ref_lines"

    if cmp -s "$sw_lines" "$ref_lines"; then
        printf 'PASS %s\n' "$name"
        PASS=$(( PASS + 1 ))
    else
        printf 'FAIL %s — expression listings differ\n' "$name"
        printf '  stormwall:\n'; sed 's/^/    /' "$sw_lines"
        printf '  expected :\n'; sed 's/^/    /' "$ref_lines"
        FAIL=$(( FAIL + 1 ))
    fi
}

for f in "$CORPUS"/*.pf; do
    [ -e "$f" ] || continue
    run_case "$f"
done

printf '\nTotals: PASS=%d FAIL=%d SKIP=%d\n' "$PASS" "$FAIL" "$SKIP"

# Exit non-zero only on FAIL. SKIPs are expected when sub-features ship
# without monitor-diff coverage (see Pi-skip note above).
[ "$FAIL" -eq 0 ] || exit 1
exit 0
