#!/usr/bin/env bash
# tests/all-corpora.sh — run every test corpus in this repo and report a
# single PASS/FAIL summary.
#
# Used by performance-optimisation worktrees to verify zero regressions
# after each change.  Runs in ~5 minutes; abort on first hard failure.
#
# Usage:
#   bash tests/all-corpora.sh           # full run
#   bash tests/all-corpora.sh --fast    # skip the bash 5.3 suite (saves ~3 min)

set -u

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
cd "$REPO_ROOT"

FAST=
if [ "${1:-}" = "--fast" ]; then FAST=1; fi

# A passing line in a runner is one of these patterns.
# We grep the runner's tail for the summary line and parse it.

results=()
fail_count=0

run_corpus() {
    local name="$1"
    local cmd="$2"
    local expect_pat="$3"      # regex — if matches summary line → pass
    local actual
    actual=$(eval "$cmd" 2>&1 | tail -3 | tr '\n' ' ' | tr -s ' ')
    if printf '%s' "$actual" | grep -Eq -- "$expect_pat"; then
        results+=("PASS  $name")
    else
        results+=("FAIL  $name : $actual")
        fail_count=$((fail_count + 1))
    fi
}

# bash 5.3 upstream — slowest, optional
if [ -z "$FAST" ]; then
    run_corpus "bash 5.3 suite (82/82)" \
        "bash scripts/run-tests-local.sh" \
        "82 passed, 0 failed"
fi

run_corpus "realworld scripts (38/38)" \
    "bash tests/realworld/run.sh" \
    "38 passed, 0 failed"

run_corpus "popular shell scripts (14/14)" \
    "bash tests/realworld/popular/run.sh" \
    "14/14 byte-identical"

run_corpus "configure --help (5/5)" \
    "bash tests/realworld/configure/run.sh" \
    "5 passed, 0 failed"

run_corpus "POSIX vs dash (15/15)" \
    "bash tests/dash/run.sh" \
    "POSIX conformance: 100%"

run_corpus "init.d (60/60)" \
    "bash tests/initd/run.sh" \
    "60 passed, 0 failed"

run_corpus "shellcheck snippets (173/173)" \
    "bash tests/shellcheck/run.sh" \
    "173 / 173"

run_corpus "binsh (17/17)" \
    "bash tests/binsh/run.sh" \
    "17/17"

run_corpus "bashisms (45/45)" \
    "bash tests/bashisms/run.sh" \
    "45/45"

run_corpus "mksh (40/40)" \
    "bash tests/mksh/run.sh" \
    "POSIX/ksh conformance: 100%"

run_corpus "busybox (30/30)" \
    "bash tests/busybox/run.sh" \
    "Conformance: 100%"

run_corpus "nixos (10/10)" \
    "bash tests/nixos/run.sh" \
    "10 passed, 0 failed"

run_corpus "docker (8/8)" \
    "bash tests/docker/run.sh" \
    "8 passed"

run_corpus "completion (10/10)" \
    "bash tests/completion/run.sh" \
    "10/10"

run_corpus "ci/actions (18/18)" \
    "bash tests/ci/run.sh" \
    "18 passed, 0 failed"

run_corpus "shfmt parser (parity)" \
    "bash tests/shfmt/run.sh" \
    "parity:.* 100"

run_corpus "fuzz (100 byte-identical)" \
    "FUZZ_SEED=42 bash tests/fuzz/diff_fuzz.sh 50" \
    "50 passed, 0 diverged"

# brash-specific regression suite — covers behaviour that is not
# byte-identical-vs-bash but is still required (process-tree shape after
# `cmd &`, BRASH_TEST_MODE startup-file precedence, internal compgen
# wordlist + function paths, .brashrc/.bashrc fallback rules).
run_corpus "regression (brash-specific)" \
    "bash tests/regression/run.sh" \
    "[1-9][0-9]* passed, 0 failed"

echo
echo "===================================================="
for r in "${results[@]}"; do
    echo "  $r"
done
echo "===================================================="

if [ "$fail_count" -eq 0 ]; then
    echo "ALL CORPORA PASS (${#results[@]} suites)"
    exit 0
else
    echo "FAILED: $fail_count of ${#results[@]} suites"
    exit 1
fi
