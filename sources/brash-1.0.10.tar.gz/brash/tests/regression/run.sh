#!/bin/sh
# tests/regression/run.sh — brash-specific regression suite.
#
# Each *.test script in this directory is a self-contained test that
# exercises a behaviour the upstream Bash 5.3 test suite cannot cover
# (process-tree shape, brash-vs-bash startup-file precedence, brash
# builtin internals).  Tests are POSIX-sh shell scripts; each one
# `set -e`'s and exits 0 on success, non-zero on failure.
#
# Usage:
#   tests/regression/run.sh                    # run all
#   tests/regression/run.sh 01_bg_wrapper      # run one
#   BRASH=/path/to/brash tests/regression/run.sh
#
# The regression set EXPLICITLY does not run under bash — these tests
# are about brash-internal behaviour, not differential output, so the
# corpora harness in all-corpora.sh treats this directory differently
# from the byte-identical-vs-bash suites.

set -u

SCRIPT_DIR=$(cd "$(dirname "$0")" && pwd)
REPO_ROOT=$(cd "$SCRIPT_DIR/../.." && pwd)
BRASH="${BRASH:-$REPO_ROOT/target/release/brash}"

if [ ! -x "$BRASH" ]; then
    printf 'ERROR: brash not found at %s — run `cargo build --release` first\n' "$BRASH" >&2
    exit 2
fi

export BRASH

pattern="${1:-*}"
pass=0
fail=0
failed_names=

for test_script in "$SCRIPT_DIR"/${pattern}*.test; do
    [ -f "$test_script" ] || continue
    name=$(basename "$test_script" .test)
    out=$(sh "$test_script" 2>&1)
    rc=$?
    if [ "$rc" -eq 0 ]; then
        pass=$((pass + 1))
        printf 'PASS  %s\n' "$name"
    else
        fail=$((fail + 1))
        failed_names="$failed_names $name"
        printf 'FAIL  %s\n' "$name"
        printf '%s\n' "$out" | sed 's/^/        /'
    fi
done

# Avoid double-counting when the same test matches both globs above.
# (POSIX sh has no associative arrays; rely on a sentinel file pass.)
total=$((pass + fail))
echo
echo "=== regression: $pass passed, $fail failed (of $total) ==="
[ "$fail" -eq 0 ]
