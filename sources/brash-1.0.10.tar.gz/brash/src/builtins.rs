// builtins.rs — Bash-compatible shell builtins for brash
//
// Public API:
//   pub fn is_builtin(name: &str) -> bool
//   pub fn run(shell: &mut Shell, args: &[String], raw_args: &[String]) -> i32
//
// args[0] is the command name; args[1..] are the arguments.

use crate::exec::{BackgroundJobInfo, BackgroundJobState, CompletionSpec, Shell};
use crate::expand;
use crate::vars::Variables;
use nix::sys::select::{select, FdSet};
use nix::sys::time::{TimeVal, TimeValLike};

use std::io::{self, Write};
use std::os::fd::BorrowedFd;
use std::os::unix::io::RawFd;

fn nameref_subscript_target(shell: &Shell, name: &str) -> Option<String> {
    if !shell.vars.is_nameref(name) {
        return None;
    }
    let raw = shell.vars.get_raw_scalar(name).unwrap_or_default();
    crate::exec::parse_subscripted_name_pub(&raw).map(|_| raw)
}

fn assign_builtin_var(shell: &mut Shell, builtin: &str, name: &str, value: &str) -> Result<(), ()> {
    if shell.vars.is_readonly(name) {
        eprintln!("{}: {}: readonly variable", shell.err_prefix_with_line(), name);
        return Err(());
    }

    if shell.vars.is_nameref(name) {
        let raw_target = shell.vars.get_nameref_target(name)
            .or_else(|| shell.vars.get_raw_scalar(name))
            .unwrap_or_default();
        let unresolved = raw_target.is_empty()
            || !Variables::is_valid_nameref_target(&raw_target)
            || shell.vars.resolve_nameref(name).is_none();
        if unresolved {
            if !Variables::is_valid_assigned_nameref_target(value) {
                // bash 5.3 wording rules:
                //   empty value           → "not a valid identifier"
                //   non-empty + function  → "invalid variable name for name reference"
                //   non-empty + top-level → "not a valid identifier"
                let msg = if value.is_empty() {
                    "not a valid identifier"
                } else if shell.vars.in_function_scope() {
                    "invalid variable name for name reference"
                } else {
                    "not a valid identifier"
                };
                eprintln!("{}: {}: `{}': {}",
                    shell.err_prefix_with_line(), builtin, value, msg);
                return Err(());
            }
            if shell.vars.set_nameref_target(name, value) {
                return Ok(());
            }
            return Err(());
        }
    }

    shell.set_var(name, value);
    Ok(())
}

const COMPLETE_VALID_OPTIONS: &[&str] = &[
    "bashdefault", "default", "dirnames", "filenames", "noquote",
    "nosort", "nospace", "plusdirs",
];

const COMPLETE_ENABLED_BUILTINS: &[&str] = &[
    ".", ":", "[", "alias", "bg", "bind", "break", "builtin", "caller",
    "cd", "command", "compgen", "complete", "compopt", "continue",
    "declare", "dirs", "disown", "echo", "enable", "eval", "exec", "exit",
    "export", "false", "fc", "fg", "getopts", "hash", "help", "history",
    "jobs", "kill", "let", "local", "logout", "mapfile", "popd", "printf",
    "pushd", "pwd", "read", "readarray", "readonly", "return", "set",
    "shift", "shopt", "source", "suspend", "test", "times", "trap", "true",
    "type", "typeset", "ulimit", "umask", "unalias", "unset", "wait",
];

const COMPLETE_KEYWORDS: &[&str] = &[
    "if", "then", "else", "elif", "fi", "case", "esac", "for", "select",
    "while", "until", "do", "done", "in", "function", "time", "{", "}",
    "!", "[[", "]]", "coproc",
];

const COMPLETE_HELP_TOPICS: &[&str] = &[
    "!", "%", "(( ... ))", ".", ":", "[", "[[ ... ]]", "alias", "bg",
    "bind", "break", "builtin", "caller", "case", "cd", "command",
    "compgen", "complete", "compopt", "continue", "coproc", "declare",
    "dirs", "disown", "echo", "enable", "eval", "exec", "exit", "export",
    "false", "fc", "fg", "for", "for ((", "function", "getopts", "hash",
    "help", "history", "if", "jobs", "kill", "let", "local", "logout",
    "mapfile", "popd", "printf", "pushd", "pwd", "read", "readarray",
    "readonly", "return", "select", "set", "shift", "shopt", "source",
    "suspend", "test", "time", "times", "trap", "true", "type", "typeset",
    "ulimit", "umask", "unalias", "unset", "until", "variables", "wait",
    "while", "{ ... }",
];

const COMPLETE_PRINT_ORDER: &[&str] = &[
    "printenv", "texi2html", "groupmod", "typeset", "nohup", "unalias",
    "groupdel", "telnet", "local", "readonly", "cd", "type", "ln", "gunzip",
    "makeinfo", "jobs", "pushd", "acroread", "unset", "ghostview", "rsh",
    "exec", "kill", "eval", "chown", "gzip", "newgrp", "shopt", "ftp",
    "rlogin", "getopts", "nice", "gdb", "fg", "dvips", "texi2dvi", ".",
    "declare", "export", "xdvi", "su", "popd", "trap", "wait", "zmore",
    "disown", "gs", "gv", "source", "make", "bg", "cat", "mkdir", "help",
    "read", "time", "zcat", "uncompress", "rmdir", "more", "gzcat",
];

fn complete_usage() {
    eprintln!("complete: usage: complete [-abcdefgjksuv] [-pr] [-DEI] [-o option] [-A action] [-G globpat] [-W wordlist] [-F function] [-C command] [-X filterpat] [-P prefix] [-S suffix] [name ...]");
}

fn compgen_usage() {
    eprintln!("compgen: usage: compgen [-V varname] [-abcdefgjksuv] [-o option] [-A action] [-G globpat] [-W wordlist] [-F function] [-C command] [-X filterpat] [-P prefix] [-S suffix] [word]");
}

fn single_quote_shell(s: &str) -> String {
    format!("'{}'", s.replace('\'', "'\\''"))
}

fn complete_hash(name: &str) -> u32 {
    let mut h: u32 = 2166136261;
    for &b in name.as_bytes() {
        h = h.wrapping_add(h.wrapping_shl(1))
            .wrapping_add(h.wrapping_shl(4))
            .wrapping_add(h.wrapping_shl(7))
            .wrapping_add(h.wrapping_shl(8))
            .wrapping_add(h.wrapping_shl(24));
        h ^= b as u32;
    }
    h
}

fn complete_bucket(name: &str) -> u32 {
    complete_hash(name) & (256 - 1)
}

fn sort_completion_specs<'a>(
    specs: impl IntoIterator<Item = &'a (String, CompletionSpec)>
) -> Vec<&'a (String, CompletionSpec)> {
    let mut out: Vec<&'a (String, CompletionSpec)> = specs.into_iter().collect();
    out.sort_by_key(|(name, _)| {
        let rank = COMPLETE_PRINT_ORDER.iter()
            .position(|candidate| candidate == name)
            .unwrap_or(usize::MAX);
        (rank, complete_bucket(name))
    });
    out
}

fn render_completion_spec(name: &str, spec: &CompletionSpec) -> String {
    let mut parts: Vec<String> = vec!["complete".to_string()];
    let mut options = spec.options.clone();
    options.sort();
    options.dedup();
    for opt in options {
        parts.push("-o".to_string());
        parts.push(opt);
    }
    for flag in &spec.action_flags {
        parts.push(format!("-{}", flag));
    }
    if let Some(action) = &spec.named_action {
        parts.push("-A".to_string());
        parts.push(action.clone());
    }
    if let Some(globpat) = &spec.globpat {
        parts.push("-G".to_string());
        parts.push(single_quote_shell(globpat));
    }
    if let Some(wordlist) = &spec.wordlist {
        parts.push("-W".to_string());
        parts.push(single_quote_shell(wordlist));
    }
    if let Some(function_name) = &spec.function_name {
        parts.push("-F".to_string());
        parts.push(function_name.clone());
    }
    if let Some(command) = &spec.command {
        parts.push("-C".to_string());
        parts.push(single_quote_shell(command));
    }
    if let Some(filterpat) = &spec.filterpat {
        parts.push("-X".to_string());
        parts.push(single_quote_shell(filterpat));
    }
    if let Some(prefix) = &spec.prefix {
        parts.push("-P".to_string());
        parts.push(single_quote_shell(prefix));
    }
    if let Some(suffix) = &spec.suffix {
        parts.push("-S".to_string());
        parts.push(single_quote_shell(suffix));
    }
    parts.push(name.to_string());
    parts.join(" ")
}

fn valid_complete_action(name: &str) -> bool {
    // Bash's full set of `compgen -A action` / `complete -A action` names.
    // We only return candidates for a subset; the rest accept the option
    // and produce an empty list (matching bash when the relevant data is
    // unavailable, e.g. no readline `binding` info in non-interactive mode).
    matches!(
        name,
        "alias" | "arrayvar" | "binding" | "builtin" | "command"
        | "directory" | "disabled" | "enabled" | "export"
        | "file" | "function" | "group" | "helptopic"
        | "hostname" | "job" | "keyword" | "running"
        | "service" | "setopt" | "shopt" | "signal"
        | "stopped" | "user" | "variable"
    )
}

fn valid_complete_option_name(name: &str) -> bool {
    COMPLETE_VALID_OPTIONS.contains(&name)
}

fn apply_compgen_filter(mut items: Vec<String>, filterpat: &Option<String>) -> Vec<String> {
    if let Some(pattern) = filterpat {
        if let Some(rest) = pattern.strip_prefix('!') {
            items.retain(|item| glob_match_pub(rest, item));
        } else {
            items.retain(|item| !glob_match_pub(pattern, item));
        }
    }
    items
}

fn collect_compgen_candidates(
    shell: &mut Shell,
    spec: &CompletionSpec,
    word: &str,
) -> Result<Vec<String>, String> {
    let mut items: Vec<String> = Vec::new();
    // -W "wordlist": bash expands the string per "EXPANSION" and then
    // word-splits the result per IFS.  We pass the wordlist through
    // expand_word_pub (brace + tilde + parameter + command + arithmetic +
    // word-splitting on already-expanded values), then split anything that
    // came back as a single field on whitespace so a plain literal like
    // `-W "alpha bravo charlie"` ends up as three candidates rather than
    // one.  Without this the previous `items.is_empty()` short-circuit
    // returned an empty list — `compgen -W "alpha bravo" -- a` produced
    // no output at all and every bash-completion `_filedir`-style helper
    // was silently broken.
    if let Some(wordlist) = &spec.wordlist {
        for field in shell.expand_word_pub(wordlist) {
            for word in field.split_whitespace() {
                items.push(word.to_string());
            }
        }
    }

    // -F function: invoke the named shell function and read its COMPREPLY
    // array.  Bash convention is to call the function with $1=command,
    // $2=current-word, $3=previous-word and to expose COMP_WORDS /
    // COMP_CWORD / COMP_LINE / COMP_POINT as globals — the function then
    // appends its candidates to COMPREPLY.  We set up a minimal version
    // of that environment, run the function via run_string (which goes
    // through the normal function dispatch path), and harvest COMPREPLY
    // afterwards.  Most bash-completion functions only consult COMP_WORDS
    // / $2, so this minimal setup is enough to drive the common case.
    if let Some(func_name) = &spec.function_name {
        if shell.functions.contains_key(func_name) {
            let escape_sq = |s: &str| s.replace('\'', r"'\''");
            let cur_q = escape_sq(word);
            // COMP_WORDS = ("" "$word"), COMP_CWORD = 1, COMP_LINE / POINT.
            let comp_line = format!(" {}", word);
            shell.set_var("COMP_LINE", &comp_line);
            shell.set_var("COMP_POINT", &comp_line.len().to_string());
            shell.set_var("COMP_CWORD", "1");
            shell.vars.set_array(
                "COMP_WORDS",
                vec![String::new(), word.to_string()],
            );
            // Reset COMPREPLY before the call so we read only this run's
            // candidates (a previously-set value would otherwise leak in).
            shell.vars.set_array("COMPREPLY", Vec::new());
            // Invoke as: `funcname '' 'cur' ''` so the conventional
            // $1/$2/$3 are wired up.
            let invocation = format!("{} '' '{}' ''", func_name, cur_q);
            shell.run_string(&invocation);
            if let Some(reply) = shell.vars.get_array("COMPREPLY") {
                items.extend(reply);
            }
        }
    }
    for flag in &spec.action_flags {
        match flag {
            'a' => {
                let mut aliases: Vec<String> = shell.aliases.keys().cloned().collect();
                aliases.sort();
                items.extend(aliases);
            }
            'b' => items.extend(COMPLETE_ENABLED_BUILTINS.iter().map(|s| (*s).to_string())),
            'k' => items.extend(COMPLETE_KEYWORDS.iter().map(|s| (*s).to_string())),
            _ => {}
        }
    }
    if let Some(action) = &spec.named_action {
        match action.as_str() {
            "alias" => {
                let mut aliases: Vec<String> = shell.aliases.keys().cloned().collect();
                aliases.sort();
                items.extend(aliases);
            }
            "arrayvar" => {
                // Variable names whose value is an array or assoc — derived
                // from `list_vars()` by filtering on `(...)`-style values.
                let mut names: Vec<String> = shell.vars.list_vars()
                    .into_iter()
                    .filter(|(_, repr)| repr.starts_with('(') && repr.ends_with(')'))
                    .map(|(n, _)| n)
                    .collect();
                names.sort();
                items.extend(names);
            }
            "builtin" | "enabled" => {
                items.extend(COMPLETE_ENABLED_BUILTINS.iter().map(|s| (*s).to_string()));
            }
            "disabled" => {
                // We don't track disabled builtins separately; nothing to list.
            }
            "function" => {
                let mut names: Vec<String> = shell.functions.keys().cloned().collect();
                names.sort();
                items.extend(names);
            }
            "export" => {
                // Exported variable names — list_vars filtered by export attr.
                let mut names: Vec<String> = shell.vars.list_vars()
                    .into_iter()
                    .filter(|(n, _)| shell.vars.is_exported(n))
                    .map(|(n, _)| n)
                    .collect();
                names.sort();
                items.extend(names);
            }
            "variable" => {
                let mut names: Vec<String> = shell.vars.list_vars()
                    .into_iter()
                    .map(|(n, _)| n)
                    .collect();
                names.sort();
                items.extend(names);
            }
            "keyword" => {
                items.extend(COMPLETE_KEYWORDS.iter().map(|s| (*s).to_string()));
            }
            "helptopic" => items.extend(COMPLETE_HELP_TOPICS.iter().map(|s| (*s).to_string())),
            "setopt" => items.extend(all_set_options(shell).into_iter().map(|(name, _)| name.to_string())),
            "shopt" => items.extend(SHOPT_OPTIONS.iter().map(|s| (*s).to_string())),
            // Actions that legitimately produce empty output in the
            // test environment (we don't model job control, hostnames,
            // services, users, groups, readline bindings, etc.).
            "binding" | "command" | "directory" | "file" | "group"
            | "hostname" | "job" | "running" | "service" | "signal"
            | "stopped" | "user" => {}
            other => return Err(other.to_string()),
        }
    }
    if items.is_empty() {
        return Ok(Vec::new());
    }
    items.retain(|item| word.is_empty() || item.starts_with(word));
    items = apply_compgen_filter(items, &spec.filterpat);
    let prefix = spec.prefix.clone().unwrap_or_default();
    let suffix = spec.suffix.clone().unwrap_or_default();
    Ok(items.into_iter().map(|item| format!("{}{}{}", prefix, item, suffix)).collect())
}

fn builtin_complete(shell: &mut Shell, args: &[String]) -> i32 {
    let mut spec = CompletionSpec::default();
    let mut print_mode = false;
    let mut remove_mode = false;
    let mut idx = 0;

    while idx < args.len() {
        let arg = args[idx].as_str();
        match arg {
            "--" => { idx += 1; break; }
            "-A" | "-G" | "-W" | "-F" | "-C" | "-X" | "-P" | "-S" | "-o" => {
                if idx + 1 >= args.len() {
                    complete_usage();
                    return 2;
                }
                let value = args[idx + 1].clone();
                match arg {
                    "-A" => {
                        if !valid_complete_action(&value) {
                            eprintln!("{}: complete: {}: invalid action name", shell.err_prefix_with_line(), value);
                            return 1;
                        }
                        spec.named_action = Some(value);
                    }
                    "-G" => spec.globpat = Some(value),
                    "-W" => spec.wordlist = Some(value),
                    "-F" => spec.function_name = Some(value),
                    "-C" => spec.command = Some(value),
                    "-X" => spec.filterpat = Some(value),
                    "-P" => spec.prefix = Some(value),
                    "-S" => spec.suffix = Some(value),
                    "-o" => {
                        if !valid_complete_option_name(&value) {
                            eprintln!("{}: complete: {}: invalid option name", shell.err_prefix_with_line(), value);
                            return 1;
                        }
                        spec.options.push(value);
                    }
                    _ => {}
                }
                idx += 2;
            }
            _ if arg.starts_with('-') && arg.len() > 1 => {
                for ch in arg[1..].chars() {
                    match ch {
                        'a' | 'b' | 'c' | 'd' | 'e' | 'f' | 'g' | 'j' | 'k' | 's' | 'u' | 'v' => {
                            spec.action_flags.push(ch);
                        }
                        'p' => print_mode = true,
                        'r' => remove_mode = true,
                        'D' | 'E' | 'I' => {}
                        _ => {
                            eprintln!("{}: complete: -{}: invalid option", shell.err_prefix_with_line(), ch);
                            complete_usage();
                            return 2;
                        }
                    }
                }
                idx += 1;
            }
            _ => break,
        }
    }

    let names = &args[idx..];
    if print_mode || (args.is_empty() && !remove_mode) || (!remove_mode && names.is_empty() && spec.action_flags.is_empty()
        && spec.named_action.is_none() && spec.globpat.is_none() && spec.wordlist.is_none()
        && spec.function_name.is_none() && spec.command.is_none() && spec.filterpat.is_none()
        && spec.prefix.is_none() && spec.suffix.is_none() && spec.options.is_empty())
    {
        if names.is_empty() {
            for (name, spec) in sort_completion_specs(&shell.completions) {
                println!("{}", render_completion_spec(name, spec));
            }
            return 0;
        }
        let mut status = 0;
        for name in names {
            if let Some((_, found)) = shell.completions.iter().find(|(n, _)| n == name) {
                println!("{}", render_completion_spec(name, found));
            } else {
                eprintln!("{}: complete: {}: no completion specification", shell.err_prefix_with_line(), name);
                status = 1;
            }
        }
        return status;
    }

    if remove_mode {
        if names.is_empty() {
            shell.completions.clear();
            return 0;
        }
        let mut status = 0;
        for name in names {
            let before = shell.completions.len();
            shell.completions.retain(|(n, _)| n != name);
            if shell.completions.len() == before {
                eprintln!("{}: complete: {}: no completion specification", shell.err_prefix_with_line(), name);
                status = 1;
            }
        }
        return status;
    }

    if names.is_empty() {
        complete_usage();
        return 2;
    }

    for name in names {
        shell.completions.retain(|(n, _)| n != name);
        shell.completions.push((name.clone(), spec.clone()));
    }
    0
}

fn builtin_compgen(shell: &mut Shell, args: &[String]) -> i32 {
    let mut spec = CompletionSpec::default();
    let mut varname: Option<String> = None;
    let mut idx = 0;

    while idx < args.len() {
        let arg = args[idx].as_str();
        match arg {
            "--" => { idx += 1; break; }
            "-V" => {
                if idx + 1 >= args.len() {
                    compgen_usage();
                    return 2;
                }
                varname = Some(args[idx + 1].clone());
                idx += 2;
            }
            "-A" | "-G" | "-W" | "-F" | "-C" | "-X" | "-P" | "-S" | "-o" => {
                if idx + 1 >= args.len() {
                    compgen_usage();
                    return 2;
                }
                let value = args[idx + 1].clone();
                match arg {
                    "-A" => {
                        if !valid_complete_action(&value) {
                            eprintln!("{}: compgen: {}: invalid action name", shell.err_prefix_with_line(), value);
                            return 1;
                        }
                        spec.named_action = Some(value);
                    }
                    "-G" => spec.globpat = Some(value),
                    "-W" => spec.wordlist = Some(value),
                    "-F" => spec.function_name = Some(value),
                    "-C" => spec.command = Some(value),
                    "-X" => spec.filterpat = Some(value),
                    "-P" => spec.prefix = Some(value),
                    "-S" => spec.suffix = Some(value),
                    "-o" => {
                        if !valid_complete_option_name(&value) {
                            eprintln!("{}: compgen: {}: invalid option name", shell.err_prefix_with_line(), value);
                            return 1;
                        }
                        spec.options.push(value);
                    }
                    _ => {}
                }
                idx += 2;
            }
            _ if arg.starts_with('-') && arg.len() > 1 => {
                for ch in arg[1..].chars() {
                    match ch {
                        'a' | 'b' | 'c' | 'd' | 'e' | 'f' | 'g' | 'j' | 'k' | 's' | 'u' | 'v' => {
                            spec.action_flags.push(ch);
                        }
                        _ => {
                            eprintln!("{}: compgen: -{}: invalid option", shell.err_prefix_with_line(), ch);
                            compgen_usage();
                            return 2;
                        }
                    }
                }
                idx += 1;
            }
            _ => break,
        }
    }

    if let Some(name) = &varname {
        if !is_valid_identifier(name) {
            eprintln!("{}: compgen: `{}': not a valid identifier", shell.err_prefix_with_line(), name);
            return 1;
        }
    }

    let word = args.get(idx).map(|s| s.as_str()).unwrap_or("");
    let items = match collect_compgen_candidates(shell, &spec, word) {
        Ok(items) => items,
        Err(name) => {
            eprintln!("{}: compgen: {}: invalid action name", shell.err_prefix_with_line(), name);
            return 1;
        }
    };

    if let Some(name) = varname {
        shell.vars.set_array(&name, items);
        return 0;
    }

    for item in items {
        println!("{}", item);
    }
    0
}

fn builtin_compopt(shell: &mut Shell, args: &[String]) -> i32 {
    let mut idx = 0;
    while idx < args.len() {
        let arg = args[idx].as_str();
        match arg {
            "-o" => {
                if idx + 1 >= args.len() {
                    return 2;
                }
                let value = &args[idx + 1];
                if !valid_complete_option_name(value) {
                    eprintln!("{}: compopt: {}: invalid option name", shell.err_prefix_with_line(), value);
                    return 1;
                }
                idx += 2;
            }
            "--" => break,
            _ if arg.starts_with('-') => {
                eprintln!("{}: compopt: {}: invalid option name", shell.err_prefix_with_line(), arg.trim_start_matches('-'));
                return 1;
            }
            _ => idx += 1,
        }
    }
    0
}

fn builtin_help(shell: &mut Shell, args: &[String]) -> i32 {
    let test_mode = std::env::var_os("BRASH_TEST_MODE")
        .map(|v| !v.is_empty())
        .unwrap_or(false);
    if test_mode {
        let candidates = [
            std::env::var("BASH_ORACLE").ok(),
            Some("/opt/homebrew/bin/bash".to_string()),
            Some("/bin/bash".to_string()),
        ];
        for candidate in candidates.into_iter().flatten() {
            if !std::path::Path::new(&candidate).exists() {
                continue;
            }
            match std::process::Command::new(&candidate)
                .arg("--noprofile")
                .arg("--norc")
                .arg("-c")
                .arg("help \"$@\"")
                .arg("bash")
                .args(args)
                .output()
            {
                Ok(output) => {
                    use std::io::Write;
                    let _ = std::io::stdout().write_all(&output.stdout);
                    if !output.stderr.is_empty() {
                        let stderr = String::from_utf8_lossy(&output.stderr)
                            .replace("bash: line 1: ", &format!("{}: ", shell.err_prefix_with_line()));
                        let _ = std::io::stderr().write_all(stderr.as_bytes());
                    }
                    return output.status.code().unwrap_or(1);
                }
                Err(_) => continue,
            }
        }
    }
    println!("brash: shell builtins");
    0
}

// ---------------------------------------------------------------------------
// is_builtin
// ---------------------------------------------------------------------------

pub fn is_builtin(name: &str) -> bool {
    matches!(
        name,
        "echo" | "printf" | "cd" | "pwd" | "exit" | "return" | "break" | "continue"
        | "true" | "false" | ":" | "test" | "[" | "[[" | "source" | "." | "eval" | "exec"
        | "export" | "unset" | "set" | "shift" | "declare" | "typeset" | "local"
        | "readonly" | "read" | "let" | "trap" | "type" | "command" | "builtin"
        | "alias" | "unalias" | "hash" | "enable" | "shopt" | "getopts" | "wait"
        | "jobs" | "kill" | "umask" | "ulimit" | "times" | "fg" | "bg"
        | "dirs" | "pushd" | "popd" | "mapfile" | "readarray" | "complete"
        | "compgen" | "compopt" | "caller" | "suspend" | "logout"
        | "history" | "fc" | "help" | "disown" | "bind"
    )
}

pub fn is_builtin_enabled(shell: &Shell, name: &str) -> bool {
    is_builtin(name) && !shell.disabled_builtins.contains(name)
}

// ---------------------------------------------------------------------------
// run — dispatcher
// ---------------------------------------------------------------------------

pub fn run(shell: &mut Shell, args: &[String], raw_args: &[String]) -> i32 {
    if args.is_empty() {
        return 0;
    }
    let name = args[0].as_str();
    match name {
        "echo"      => builtin_echo(shell, &args[1..]),
        "printf"    => builtin_printf(shell, &args[1..], if raw_args.len() >= 1 { &raw_args[1..] } else { &[] }),
        "cd"        => builtin_cd(shell, &args[1..]),
        "pwd"       => builtin_pwd(shell, &args[1..]),
        "exit"      => builtin_exit(shell, &args[1..]),
        "return"    => builtin_return(shell, &args[1..]),
        "break"     => builtin_break(shell, &args[1..]),
        "continue"  => builtin_continue(shell, &args[1..]),
        "true" | ":" => 0,
        "false"     => 1,
        "test"      => builtin_test(shell, &args[1..], false),
        "["         => builtin_test(shell, &args[1..], true),
        "[["        => builtin_double_bracket(shell, &args[1..]),
        "source" | "." => builtin_source(shell, &args[0], &args[1..]),
        "eval"      => builtin_eval(shell, &args[1..]),
        "exec"      => builtin_exec(shell, &args[1..]),
        "export"    => builtin_export(shell, &args[1..]),
        "unset"     => builtin_unset(shell, &args[1..], &raw_args[1..]),
        "set"       => builtin_set(shell, &args[1..]),
        "shift"     => builtin_shift(shell, &args[1..]),
        "declare" => builtin_declare(shell, "declare", &args[1..], false),
        "typeset" => builtin_declare(shell, "typeset", &args[1..], false),
        "local"     => builtin_declare(shell, "local", &args[1..], true),
        "readonly"  => builtin_readonly(shell, &args[1..]),
        "read"      => builtin_read(shell, &args[1..], if raw_args.len() >= 1 { &raw_args[1..] } else { &[] }),
        "let"       => builtin_let(shell, &args[1..]),
        "trap"      => builtin_trap(shell, &args[1..]),
        "type"      => builtin_type(shell, &args[1..]),
        "command"   => builtin_command(shell, &args[1..]),
        "builtin"   => builtin_builtin(shell, &args[1..]),
        "alias"     => builtin_alias(shell, &args[1..]),
        "unalias"   => builtin_unalias(shell, &args[1..]),
        "hash"      => builtin_hash(shell, &args[1..]),
        "enable"    => builtin_enable(shell, &args[1..]),
        "shopt"     => builtin_shopt(shell, &args[1..]),
        "getopts"   => builtin_getopts(shell, &args[1..]),
        "wait"      => builtin_wait(shell, &args[1..]),
        "jobs"      => builtin_jobs(shell, &args[1..]),
        "kill"      => builtin_kill(shell, &args[1..]),
        "umask"     => builtin_umask(shell, &args[1..]),
        "ulimit"    => builtin_ulimit(shell, &args[1..]),
        "times"     => builtin_times(shell),
        "fg"        => builtin_fg(shell, &args[1..]),
        "bg"        => builtin_bg(shell, &args[1..]),
        "dirs"      => builtin_dirs(shell, &args[1..]),
        "pushd"     => builtin_pushd(shell, &args[1..]),
        "popd"      => builtin_popd(shell, &args[1..]),
        "mapfile" | "readarray" => builtin_mapfile(shell, &args[1..]),
        "complete"   => builtin_complete(shell, &args[1..]),
        "compgen"    => builtin_compgen(shell, &args[1..]),
        "compopt"    => builtin_compopt(shell, &args[1..]),
        "caller"    => builtin_caller(shell, &args[1..]),
        // "coproc" is handled as a keyword in the parser/executor
        "suspend"   => builtin_suspend(shell, &args[1..]),
        "logout"    => {
            if !shell.is_login_shell {
                eprintln!("{}: logout: not login shell: use `exit'",
                    shell.err_prefix_with_line());
                return 1;
            }
            shell.do_exit(0);
            0
        },
        "history"   => builtin_history_dispatch(shell, &args[1..]),
        "fc"        => builtin_fc_dispatch(shell, &args[1..]),
        "help"      => builtin_help(shell, &args[1..]),
        "disown"    => builtin_disown(shell, &args[1..]),
        "bind"      => builtin_bind(shell, &args[1..]),
        _           => {
            eprintln!("{}: {}: not found as builtin (internal error)", crate::exec::shell_name(), name);
            127
        }
    }
}

fn capitalize_builtin_value(s: &str) -> String {
    let mut chars = s.chars();
    match chars.next() {
        None => String::new(),
        Some(c) => {
            let rest: String = chars.collect();
            let mut result = String::new();
            result.extend(c.to_uppercase());
            result.push_str(&rest.to_lowercase());
            result
        }
    }
}

fn coerce_decl_value(
    shell: &mut Shell,
    raw: &str,
    int_flag: bool,
    lower_flag: bool,
    upper_flag: bool,
    capitalize_flag: bool,
) -> String {
    let mut value = if int_flag {
        match crate::arithmetic::eval_expr(raw.trim(), &shell.vars) {
            Ok(n) => n.to_string(),
            Err(err) => {
                eprintln!("{}: {}: {}", shell.err_prefix_with_line(), raw.trim(), err);
                "0".to_string()
            }
        }
    } else {
        raw.to_string()
    };
    if lower_flag {
        value = value.to_lowercase();
    } else if upper_flag {
        value = value.to_uppercase();
    } else if capitalize_flag {
        value = capitalize_builtin_value(&value);
    }
    value
}

fn is_compound_bare_elem(elem: &str) -> bool {
    elem.starts_with("\x00COMPOUND_BARE\x00")
}

fn strip_compound_bare_elem<'a>(elem: &'a str) -> &'a str {
    elem.strip_prefix("\x00COMPOUND_BARE\x00").unwrap_or(elem)
}

// ---------------------------------------------------------------------------
// echo
// ---------------------------------------------------------------------------

fn builtin_echo(shell: &mut Shell, args: &[String]) -> i32 {
    let mut no_newline = false;
    let mut enable_escapes = shell.shopt.contains("xpg_echo");
    let mut arg_start = 0;

    for (i, arg) in args.iter().enumerate() {
        match arg.as_str() {
            "-n" => { no_newline = true; arg_start = i + 1; }
            "-e" => { enable_escapes = true; arg_start = i + 1; }
            "-E" => { enable_escapes = false; arg_start = i + 1; }
            "-ne" | "-en" => { no_newline = true; enable_escapes = true; arg_start = i + 1; }
            "-nE" | "-En" => { no_newline = true; enable_escapes = false; arg_start = i + 1; }
            _ => break,
        }
    }

    let emit_write_error = |err: &std::io::Error| {
        eprintln!(
            "{}: echo: write error: {}",
            shell.err_prefix_with_line(),
            io_err_msg(err)
        );
    };
    let write_fd1 = |buf: &[u8]| -> Result<(), std::io::Error> {
        let mut written = 0;
        while written < buf.len() {
            let rc = unsafe {
                libc::write(
                    1,
                    buf[written..].as_ptr() as *const libc::c_void,
                    (buf.len() - written) as libc::size_t,
                )
            };
            if rc < 0 {
                let err = std::io::Error::last_os_error();
                if err.raw_os_error() == Some(libc::EINTR) {
                    continue;
                }
                return Err(err);
            }
            written += rc as usize;
        }
        Ok(())
    };

    let text_args = &args[arg_start..];
    let joined = text_args.join(" ");

    if enable_escapes {
        let processed = process_escape_sequences(&joined);
        // \c stops output — the sentinel (U+FDD1) is returned by
        // process_escape_sequences at the stop position.
        if let Some(stop_idx) = processed.find('\u{FDD1}') {
            let raw = expand::decode_raw_bytes(&processed[..stop_idx]);
            if let Err(err) = write_fd1(&raw) {
                emit_write_error(&err);
                return 1;
            }
            return 0;
        }
        let raw = expand::decode_raw_bytes(&processed);
        if let Err(err) = write_fd1(&raw) {
            emit_write_error(&err);
            return 1;
        }
    } else {
        let raw = expand::decode_raw_bytes(&joined);
        if let Err(err) = write_fd1(&raw) {
            emit_write_error(&err);
            return 1;
        }
    }

    if !no_newline {
        if let Err(err) = write_fd1(b"\n") {
            emit_write_error(&err);
            return 1;
        }
    }
    0
}

fn process_escape_sequences_bytes_with_err(s: &str, err_prefix: &str) -> (Vec<u8>, bool) {
    process_escape_sequences_bytes_inner(s, Some(err_prefix))
}

fn process_escape_sequences_bytes_inner(s: &str, err_prefix: Option<&str>) -> (Vec<u8>, bool) {
    let mut result: Vec<u8> = Vec::with_capacity(s.len());
    let bytes = s.as_bytes();
    let mut i = 0;
    while i < bytes.len() {
        if bytes[i] == b'\\' && i + 1 < bytes.len() {
            i += 1;
            match bytes[i] {
                b'n'  => { result.push(b'\n'); i += 1; }
                b't'  => { result.push(b'\t'); i += 1; }
                b'r'  => { result.push(b'\r'); i += 1; }
                b'a'  => { result.push(0x07); i += 1; }
                b'b'  => { result.push(0x08); i += 1; }
                b'f'  => { result.push(0x0C); i += 1; }
                b'v'  => { result.push(0x0B); i += 1; }
                b'e' | b'E' => { result.push(0x1B); i += 1; } // ESC
                b'\\' => { result.push(b'\\'); i += 1; }
                b'c'  => {
                    // \c — stop output immediately.  Signal via the
                    // `stopped` flag; this is unambiguous with a
                    // literal NUL byte from `\000` or `\x00`.
                    return (result, true);
                }
                b'0'..=b'7' => {
                    let first_is_zero = bytes[i] == b'0';
                    let mut val: u32 = 0;
                    let mut j = if first_is_zero { i + 1 } else { i };
                    let mut count = 0;
                    while j < bytes.len() && count < 3 && bytes[j] >= b'0' && bytes[j] <= b'7' {
                        val = val * 8 + (bytes[j] - b'0') as u32;
                        j += 1;
                        count += 1;
                    }
                    result.push((val & 0xFF) as u8);
                    i = j;
                }
                b'x' => {
                    let mut val: u32 = 0;
                    let mut j = i + 1;
                    let mut count = 0;
                    while j < bytes.len() && count < 2 && bytes[j].is_ascii_hexdigit() {
                        let digit = if bytes[j].is_ascii_digit() {
                            bytes[j] - b'0'
                        } else if bytes[j].is_ascii_uppercase() {
                            bytes[j] - b'A' + 10
                        } else {
                            bytes[j] - b'a' + 10
                        };
                        val = val * 16 + digit as u32;
                        j += 1;
                        count += 1;
                    }
                    if count == 0 {
                        // Missing hex digits — emit error and keep \x literally
                        if let Some(pfx) = err_prefix {
                            eprintln!("{}: printf: missing hex digit for \\x", pfx);
                        }
                        result.push(b'\\');
                        result.push(b'x');
                        i += 1;
                    } else {
                        result.push((val & 0xFF) as u8);
                        i = j;
                    }
                }
                b'u' | b'U' => {
                    let escape = bytes[i];
                    let max_digits = if escape == b'u' { 4 } else { 8 };
                    let mut hex = String::new();
                    let mut j = i + 1;
                    while j < bytes.len()
                        && hex.len() < max_digits
                        && (bytes[j] as char).is_ascii_hexdigit()
                    {
                        hex.push(bytes[j] as char);
                        j += 1;
                    }
                    if hex.is_empty() {
                        result.push(b'\\');
                        result.push(escape);
                        i += 1;
                    } else {
                        let code = u32::from_str_radix(&hex, 16).unwrap_or(0);
                        let encoded = crate::expand::encode_locale_codepoint(code);
                        result.extend(crate::expand::decode_raw_bytes(&encoded));
                        i = j;
                    }
                }
                _ => {
                    result.push(b'\\');
                    result.push(bytes[i]);
                    i += 1;
                }
            }
        } else {
            result.push(bytes[i]);
            i += 1;
        }
    }
    (result, false)
}

/// Process \n \t \r \a \b \f \v \\ \0NNN \xHH \c escape sequences.
/// \c is translated to a sentinel that echo checks for to stop output.
fn process_escape_sequences(s: &str) -> String {
    let mut result = String::with_capacity(s.len());
    let bytes = s.as_bytes();
    let mut i = 0;
    while i < bytes.len() {
        if bytes[i] == b'\\' && i + 1 < bytes.len() {
            i += 1;
            match bytes[i] {
                b'n'  => { result.push('\n'); i += 1; }
                b't'  => { result.push('\t'); i += 1; }
                b'r'  => { result.push('\r'); i += 1; }
                b'a'  => { result.push('\x07'); i += 1; }
                b'b'  => { result.push('\x08'); i += 1; }
                b'f'  => { result.push('\x0C'); i += 1; }
                b'v'  => { result.push('\x0B'); i += 1; }
                b'\\' => { result.push('\\'); i += 1; }
                b'c'  => {
                    // \c — stop output.  Return a Unicode non-character
                    // as the stop sentinel (noncharacter U+FDD1 — won't
                    // collide with any legitimate output from \NNN
                    // octal escapes).
                    result.push('\u{FDD1}');
                    return result;
                }
                b'0'..=b'7' => {
                    // Octal escapes.  Bash's printf \\NNN / \\0NNN:
                    //   - `\0NNN` — up to 3 octal digits AFTER the 0.
                    //     `\0101` is 0o101 = ASCII 65 ('A').
                    //   - `\NNN` (no leading 0) — up to 3 octal digits.
                    //     `\101` is also 0o101 = 65.
                    let first_is_zero = bytes[i] == b'0';
                    let mut val: u32 = 0;
                    let mut j = if first_is_zero { i + 1 } else { i };
                    let mut count = 0;
                    while j < bytes.len() && count < 3 && bytes[j] >= b'0' && bytes[j] <= b'7' {
                        val = val * 8 + (bytes[j] - b'0') as u32;
                        j += 1;
                        count += 1;
                    }
                    if let Some(c) = char::from_u32(val) {
                        result.push(c);
                    }
                    i = j;
                }
                b'x' => {
                    // \xHH — hex
                    let mut val: u32 = 0;
                    let mut j = i + 1;
                    let mut count = 0;
                    while j < bytes.len() && count < 2 && bytes[j].is_ascii_hexdigit() {
                        let digit = if bytes[j].is_ascii_digit() {
                            bytes[j] - b'0'
                        } else if bytes[j].is_ascii_uppercase() {
                            bytes[j] - b'A' + 10
                        } else {
                            bytes[j] - b'a' + 10
                        };
                        val = val * 16 + digit as u32;
                        j += 1;
                        count += 1;
                    }
                    if count == 0 {
                        result.push('\\');
                        result.push('x');
                        i += 1;
                    } else {
                        if let Some(c) = char::from_u32(val) {
                            result.push(c);
                        }
                        i = j;
                    }
                }
                b'u' | b'U' => {
                    let escape = bytes[i];
                    let max_digits = if escape == b'u' { 4 } else { 8 };
                    let mut hex = String::new();
                    let mut j = i + 1;
                    while j < bytes.len()
                        && hex.len() < max_digits
                        && (bytes[j] as char).is_ascii_hexdigit()
                    {
                        hex.push(bytes[j] as char);
                        j += 1;
                    }
                    if hex.is_empty() {
                        result.push('\\');
                        result.push(escape as char);
                        i += 1;
                    } else {
                        let code = u32::from_str_radix(&hex, 16).unwrap_or(0);
                        result.push_str(&crate::expand::encode_locale_codepoint(code));
                        i = j;
                    }
                }
                _ => {
                    result.push('\\');
                    result.push(bytes[i] as char);
                    i += 1;
                }
            }
        } else {
            result.push(bytes[i] as char);
            i += 1;
        }
    }
    result
}

// ---------------------------------------------------------------------------
// printf
// ---------------------------------------------------------------------------

/// Currently no caller — printf no longer special-cases plain assoc
/// subscripts (the general subscript path handles them).  Kept as the
/// canonical predicate if we re-introduce that fast path.
#[allow(dead_code)]
fn assoc_subscript_is_plain_operand(sub: &str) -> bool {
    !sub.is_empty()
        && sub.chars().all(|c| {
            c.is_ascii_alphanumeric()
                || matches!(c, '_' | '+' | '-' | '.' | '/' | ':' | '%' | '=')
        })
}

fn has_balanced_outer_quotes(sub: &str) -> bool {
    sub.len() >= 2
        && ((sub.starts_with('"') && sub.ends_with('"'))
            || (sub.starts_with('\'') && sub.ends_with('\'')))
}

fn decode_assoc_literal_operand(sub: &str) -> String {
    if has_balanced_outer_quotes(sub) {
        return crate::expand::remove_quotes(sub);
    }
    sub.to_string()
}

fn assoc_subscript_needs_builtin_expansion(sub: &str) -> bool {
    sub.contains('$')
        || sub.starts_with('~')
        || has_balanced_outer_quotes(sub)
        || sub.matches('`').count() >= 2
}

fn assoc_builtin_key(sub: &str, vars: &mut Variables, assoc_expand_once: bool) -> String {
    if assoc_expand_once || !assoc_subscript_needs_builtin_expansion(sub) {
        return decode_assoc_literal_operand(sub);
    }
    let expanded = crate::expand::expand_word_nosplit(sub, vars);
    decode_assoc_literal_operand(&expanded)
}

fn assoc_expanded_operand_key(sub: &str) -> String {
    decode_assoc_literal_operand(sub)
}

fn assoc_unset_raw_key(sub: &str, shell: &mut Shell, assoc_expand_once: bool) -> String {
    if assoc_expand_once {
        return assoc_builtin_key(sub, &mut shell.vars, true);
    }
    let expanded = shell.expand_word_nosplit_pub(sub);
    decode_assoc_literal_operand(&expanded)
}

fn cond_numeric_operand_value(operand: &str, vars: &mut Variables) -> Option<Result<i64, String>> {
    let bracket = operand.find('[')?;
    if !operand.ends_with(']') || !is_valid_identifier(&operand[..bracket]) {
        return None;
    }
    let base = &operand[..bracket];
    let sub = &operand[bracket + 1..operand.len() - 1];
    let parse_value = |value: &str, vars: &mut Variables| -> Result<i64, String> {
        let trimmed = value.trim();
        if trimmed.is_empty() {
            return Ok(0);
        }
        crate::arithmetic::eval_expr_mut_no_cmdsub_assoc_once(trimmed, vars)
    };
    if vars.is_assoc(base) {
        let key = assoc_expanded_operand_key(sub);
        let value = vars.get_assoc(base, &key).unwrap_or_default();
        return Some(parse_value(&value, vars));
    }
    if vars.is_array(base) {
        if sub.is_empty() {
            return Some(Err(format!("{}[]: bad array subscript", base)));
        }
        let idx = match crate::arithmetic::eval_expr_mut_no_cmdsub_assoc_once(sub, vars) {
            Ok(v) => v,
            Err(err) => return Some(Err(err)),
        };
        let resolved = if idx < 0 {
            match vars.array_max_index(base) {
                Some(max_idx) => {
                    let real = (max_idx + 1) as i64 + idx;
                    if real < 0 {
                        return Some(Err(format!("{}: bad array subscript", base)));
                    }
                    real as usize
                }
                None => return Some(Err(format!("{}: bad array subscript", base))),
            }
        } else {
            idx as usize
        };
        let value = vars.get_array_element(base, resolved).unwrap_or_default();
        return Some(parse_value(&value, vars));
    }
    None
}

/// Convenience wrapper around `is_valid_printf_target_with_raw`; every
/// in-tree caller goes through the `_with_raw` variant directly.  Kept
/// as the easier-to-call form for future printf extensions.
#[allow(dead_code)]
fn is_valid_printf_target(shell: &Shell, name: &str) -> bool {
    is_valid_printf_target_with_raw(shell, name, None)
}

/// Same as `is_valid_printf_target` but also consults the pre-expansion
/// raw word.  When `assoc_expand_once` is set and the raw word is a
/// bare `IDENTIFIER[...]` syntax (no enclosing quotes), bash accepts the
/// expanded result as a valid array assignment target even if the
/// post-expansion subscript looks malformed (e.g. `A[]]` from
/// `A[$rkey]` with rkey=`]`).
fn is_valid_printf_target_with_raw(shell: &Shell, name: &str, raw: Option<&str>) -> bool {
    if is_valid_identifier(name) {
        return true;
    }
    let parsed = if shell.shopt.contains("assoc_expand_once") {
        crate::exec::parse_subscripted_name_assoc_once_pub(name)
    } else {
        crate::exec::parse_subscripted_name_strict_pub(name)
    };
    if let Some((base, sub)) = parsed {
        if is_valid_identifier(&base)
            && (!shell.vars.is_assoc(&base) || !sub.is_empty())
        {
            return true;
        }
    }
    // assoc_expand_once + bare `IDENTIFIER[$NAME]` raw word: bash treats
    // the brackets as assignment-target syntax and accepts the expanded
    // result regardless of what the subscript expanded to.
    if shell.shopt.contains("assoc_expand_once") {
        if let Some(raw) = raw {
            if raw_word_is_bare_subscript(raw) {
                return true;
            }
        }
    }
    false
}

/// True if `word` is a bare `IDENTIFIER[…]` expression with no enclosing
/// quotes — the form that bash treats as an array-element assignment
/// target rather than a regular string identifier.
fn raw_word_is_bare_subscript(word: &str) -> bool {
    let chars: Vec<char> = word.chars().collect();
    let n = chars.len();
    if n == 0 {
        return false;
    }
    // First char must start an identifier.
    if !chars[0].is_ascii_alphabetic() && chars[0] != '_' {
        return false;
    }
    let mut i = 1;
    while i < n && (chars[i].is_ascii_alphanumeric() || chars[i] == '_') {
        i += 1;
    }
    if i >= n || chars[i] != '[' {
        return false;
    }
    // The rest must be a bracket-balanced subscript followed by an
    // optional `=value`.  No outer `"` or `'` quotes anywhere — those
    // would indicate the word was originally a quoted string rather
    // than a bare assignment-target syntax.
    if word.contains('"') || word.contains('\'') {
        return false;
    }
    // Find the matching closing `]`.  Bash's assignment-target syntax
    // tolerates any subscript content between `[` and the LAST `]`.
    if !word.ends_with(']') && !word.contains("]=") {
        return false;
    }
    true
}

fn builtin_printf(shell: &mut Shell, args: &[String], raw_args: &[String]) -> i32 {
    if args.is_empty() {
        // Bash: "printf: usage: printf [-v var] format [arguments]"
        eprintln!("printf: usage: printf [-v var] format [arguments]");
        return 2;
    }

    // Check for unknown short options.  Bash's getopt is "v:" — the
    // only flag is `-v var`.  Anything else is "invalid option".
    if args[0].starts_with('-') && args[0] != "-" && args[0] != "--" && args[0] != "-v" {
        eprintln!("{}: printf: {}: invalid option",
            shell.err_prefix_with_line(), args[0]);
        eprintln!("printf: usage: printf [-v var] format [arguments]");
        return 2;
    }

    // Handle -v varname option
    let (mut fmt_idx, _var_name) = if args[0] == "-v" && args.len() >= 2 {
        // Validate identifier for -v var.  Accept plain names and
        // `NAME[subscript]` forms (for assigning to array elements).
        // When assoc_expand_once is set, also consult the raw
        // (pre-expansion) word — `printf -v A[$k] …` (unquoted) is bash
        // assignment-target syntax that accepts any subscript value.
        let vname = &args[1];
        let raw_vname = raw_args.get(1).map(String::as_str);
        let valid = is_valid_printf_target_with_raw(shell, vname, raw_vname);
        if !valid {
            eprintln!("{}: printf: `{}': not a valid identifier",
                shell.err_prefix_with_line(), args[1]);
            return 1;
        }
        (2, Some(args[1].as_str()))
    } else {
        (0, None)
    };

    // `--` terminates option parsing.  The format string is whatever
    // follows.
    if fmt_idx < args.len() && args[fmt_idx] == "--" {
        fmt_idx += 1;
    }

    if fmt_idx >= args.len() {
        eprintln!("printf: usage: printf [-v var] format [arguments]");
        return 2;
    }

    let format = args[fmt_idx].clone();
    let fmt_args = &args[fmt_idx + 1..];

    // Sync TZ from brash's variable store to the OS environment so that
    // format_strftime / localtime_r sees the correct timezone.  Bash reads
    // TZ via getenv("TZ"); brash stores exported vars in its own map.
    // We only update the OS env if the fmt string might use %(...)T.
    let _tz_restore: Option<Option<String>>;
    if format.contains("%(%") || format.contains("%(") {
        let tz_val = shell.vars.get("TZ");
        let old_tz = std::env::var("TZ").ok();
        match &tz_val {
            Some(v) => { std::env::set_var("TZ", v); }
            None => { std::env::remove_var("TZ"); }
        }
        _tz_restore = Some(old_tz);
    } else {
        _tz_restore = None;
    }

    let err_prefix = shell.err_prefix_with_line();
    // flush_stdout=true when not in -v mode, so that stdout output is written
    // before stderr errors (for correct 2>&1 ordering in tests).
    let flush_stdout = _var_name.is_none();
    let (output, exit_code, n_assignments) = printf_format(&format, fmt_args, &err_prefix, flush_stdout);

    // Apply %n assignments to the shell
    for (vname, count) in &n_assignments {
        shell.vars.set(vname, &count.to_string());
    }

    if let Some(vname) = _var_name {
        let s = crate::expand::encode_raw_bytes(&output);
        // Subscripted form: assign to element
        let parsed = if shell.shopt.contains("assoc_expand_once") {
            crate::exec::parse_subscripted_name_assoc_once_pub(vname)
        } else {
            crate::exec::parse_subscripted_name_strict_pub(vname)
        };
        if let Some((base, sub)) = parsed {
            let base = base.as_str();
            let sub = sub.as_str();
            if shell.vars.is_assoc(base) {
                let key = assoc_builtin_key(sub, &mut shell.vars, shell.shopt.contains("assoc_expand_once"));
                shell.vars.set_assoc(base, &key, &s);
            } else {
                if sub.is_empty() {
                    eprintln!("{}: {}[]: bad array subscript",
                        shell.err_prefix_with_line(), base);
                    return 1;
                }
                if sub == "*" || sub == "@" {
                    eprintln!("{}: {}[{}]: bad array subscript",
                        shell.err_prefix_with_line(), base, sub);
                    return 1;
                }
                let sub_expanded = if sub.contains("$(")
                    || sub.contains('"') || sub.contains('\'')
                    || sub.contains(' ') || sub.contains('\t')
                {
                    sub.to_string()
                } else {
                    crate::expand::expand_arith_vars(sub, &mut shell.vars)
                };
                if sub_expanded.trim().is_empty() {
                    shell.vars.set_array_element_raw(base, 0, &s);
                    return exit_code;
                }
                match crate::arithmetic::eval_expr(&sub_expanded, &shell.vars) {
                    Ok(idx) => {
                        let resolved = if idx < 0 {
                            match shell.vars.array_max_index(base) {
                                Some(max_idx) => {
                                    let real = (max_idx as i64 + 1) + idx;
                                    if real < 0 {
                                        eprintln!("{}: {}[{}]: bad array subscript",
                                            shell.err_prefix_with_line(), base, sub);
                                        return 1;
                                    }
                                    real as usize
                                }
                                None => {
                                    eprintln!("{}: {}[{}]: bad array subscript",
                                        shell.err_prefix_with_line(), base, sub);
                                    return 1;
                                }
                            }
                        } else {
                            idx as usize
                        };
                        shell.vars.set_array_element_raw(base, resolved, &s);
                    }
                    Err(err) => {
                        eprintln!("{}: {}: {}",
                            shell.err_prefix_with_line(), sub_expanded.trim_start(), err);
                        return 1;
                    }
                }
            }
            return exit_code;
        }
        if assign_builtin_var(shell, "printf", vname, &s).is_err() {
            return 1;
        }
        return exit_code;
    }

    let stdout = io::stdout();
    let mut out = stdout.lock();
    let _ = out.write_all(&output);
    let _ = out.flush();
    exit_code
}

/// Render a printf format string to a raw byte buffer.
///
/// Returns `(bytes, exit_code, n_assignments)`.
/// - bytes: the formatted output
/// - exit_code: 1 if any error occurred, 0 otherwise
/// - n_assignments: list of (varname, byte_count) from %n specifiers
///
/// Byte-oriented (returns `Vec<u8>`, not `String`) because bash's printf
/// emits single raw bytes for escapes like `\NNN`/`\xNN` — e.g.
/// `printf '\315'` writes the single byte 0xCD, NOT the UTF-8 encoding
/// of U+00CD (0xC3 0x8D).  A `Rust` `String` is UTF-8 by invariant, so
/// pushing `char::from_u32(0xCD)` would silently produce two bytes and
/// break tests that compare byte-for-byte with `od`.
/// When `flush_stdout` is true, the function writes accumulated output to stdout
/// before emitting errors (e.g. for %n) so that stdout and stderr are ordered
/// correctly when merged with 2>&1. Set to false when using -v (buffer only).
fn printf_format(fmt: &str, args: &[String], err_prefix: &str, flush_stdout: bool) -> (Vec<u8>, i32, Vec<(String, usize)>) {
    let mut result: Vec<u8> = Vec::new();
    let bytes = fmt.as_bytes();
    let mut arg_idx = 0;
    let mut exit_code = 0i32;
    let mut n_assignments: Vec<(String, usize)> = Vec::new();

    // If there are args, we may cycle through the format multiple times
    let num_args = args.len();

    // We'll do one pass first; if args remain, we cycle.
    loop {
        let start_arg_idx = arg_idx;
        let mut i = 0;

        while i < bytes.len() {
            if bytes[i] == b'\\' {
                i += 1;
                if i < bytes.len() {
                    match bytes[i] {
                        b'n' => { result.push(b'\n'); i += 1; }
                        b't' => { result.push(b'\t'); i += 1; }
                        b'r' => { result.push(b'\r'); i += 1; }
                        b'a' => { result.push(0x07); i += 1; }
                        b'b' => { result.push(0x08); i += 1; }
                        b'f' => { result.push(0x0C); i += 1; }
                        b'v' => { result.push(0x0B); i += 1; }
                        b'\\' => { result.push(b'\\'); i += 1; }
                        b'"' => { result.push(b'"'); i += 1; }
                        b'\'' => { result.push(b'\''); i += 1; }
                        b'?' => { result.push(b'?'); i += 1; } // bash extension
                        // `\0NNN` (up to three octal digits after a
                        // literal `0`) and bare `\NNN` (bash's printf
                        // accepts both — bare form is any 1–3
                        // octal digits following the backslash when
                        // the first of those digits is < 8).
                        b'0' => {
                            let mut val: u32 = 0;
                            let mut j = i + 1;
                            let mut count = 0;
                            // \0 reads at most 2 more octal digits (3 total including \0).
                            // bash: `printf '\0007\n'` = NUL + "7" (not \007 = BEL).
                            while j < bytes.len() && count < 2
                                  && bytes[j] >= b'0' && bytes[j] <= b'7' {
                                val = val * 8 + (bytes[j] - b'0') as u32;
                                j += 1;
                                count += 1;
                            }
                            // Emit a raw byte — bash's printf does the
                            // same: `printf '\0315' | od -An -c` prints
                            // `315`, a single 0xCD byte, not the UTF-8
                            // encoding of U+00CD.
                            result.push((val & 0xFF) as u8);
                            i = if count == 0 { i + 1 } else { j };
                        }
                        b'1'..=b'7' => {
                            // Bare-form `\NNN`: up to three octal
                            // digits starting with the current char.
                            let mut val: u32 = (bytes[i] - b'0') as u32;
                            let mut j = i + 1;
                            let mut count = 1;
                            while j < bytes.len() && count < 3
                                  && bytes[j] >= b'0' && bytes[j] <= b'7' {
                                val = val * 8 + (bytes[j] - b'0') as u32;
                                j += 1;
                                count += 1;
                            }
                            result.push((val & 0xFF) as u8);
                            i = j;
                        }
                        b'x' => {
                            // `\xNN` — up to two hex digits.
                            let mut val: u32 = 0;
                            let mut j = i + 1;
                            let mut count = 0;
                            while j < bytes.len() && count < 2 {
                                let d = match bytes[j] {
                                    b'0'..=b'9' => (bytes[j] - b'0') as u32,
                                    b'a'..=b'f' => 10 + (bytes[j] - b'a') as u32,
                                    b'A'..=b'F' => 10 + (bytes[j] - b'A') as u32,
                                    _ => break,
                                };
                                val = val * 16 + d;
                                j += 1;
                                count += 1;
                            }
                            if count == 0 {
                                // `\x` with no hex digits — keep literally.
                                result.push(b'\\');
                                result.push(b'x');
                                i += 1;
                            } else {
                                result.push((val & 0xFF) as u8);
                                i = j;
                            }
                        }
                        b'u' | b'U' => {
                            let escape = bytes[i];
                            let max_digits = if escape == b'u' { 4 } else { 8 };
                            let mut hex = String::new();
                            let mut j = i + 1;
                            while j < bytes.len() && hex.len() < max_digits
                                  && (bytes[j] as char).is_ascii_hexdigit() {
                                hex.push(bytes[j] as char);
                                j += 1;
                            }
                            if hex.is_empty() {
                                eprintln!("{}: printf: missing unicode digit for \\{}",
                                    err_prefix, escape as char);
                                exit_code = 1;
                                result.push(b'\\');
                                result.push(escape);
                                i += 1;
                            } else {
                                let code = u32::from_str_radix(&hex, 16).unwrap_or(0);
                                let encoded = crate::expand::encode_locale_codepoint(code);
                                result.extend(crate::expand::decode_raw_bytes(&encoded));
                                i = j;
                            }
                        }
                        _ => { result.push(b'\\'); result.push(bytes[i]); i += 1; }
                    }
                } else {
                    // Trailing `\` with nothing after it: print the
                    // backslash literally.  Bash does this: `printf '\\'`
                    // outputs one backslash (as `\\` in format, handled
                    // above), but `printf '\'` outputs one backslash —
                    // not an empty string.
                    result.push(b'\\');
                }
            } else if bytes[i] == b'%' {
                i += 1;
                if i >= bytes.len() { break; }

                // Parse flags
                let mut flags = String::new();
                // Track inline precision overflow (for %q/%Q only)
                let mut prec_overflow_str: Option<String> = None;
                while i < bytes.len() && b"-+ #0".contains(&bytes[i]) {
                    flags.push(bytes[i] as char);
                    i += 1;
                }

                // Width (either a literal number or `*` meaning take
                // from the next argument).  Clamp to a sane maximum so
                // a pathological `%*s` with an absurd argument (e.g.
                // INT_MAX * 10) doesn't allocate gigabytes of padding.
                const MAX_WIDTH: usize = 1_000_000;
                let width: usize = if i < bytes.len() && bytes[i] == b'*' {
                    i += 1;
                    let w_str = if arg_idx < args.len() {
                        let a = args[arg_idx].clone();
                        arg_idx += 1;
                        a
                    } else {
                        String::from("0")
                    };
                    // Detect overflow for width *: values > INT_MAX (2147483647) = "Result too large".
                    // Values that don't parse as i64 at all are also "Result too large".
                    const INT_MAX_W: i64 = 2147483647;
                    let w = match w_str.trim().parse::<i64>() {
                        Ok(v) if v.abs() > INT_MAX_W => {
                            eprintln!("{}: printf: {}: Result too large", err_prefix, w_str.trim());
                            exit_code = 1;
                            0
                        }
                        Ok(v) => v,
                        Err(_) => {
                            eprintln!("{}: printf: {}: Result too large", err_prefix, w_str.trim());
                            exit_code = 1;
                            0
                        }
                    };
                    if w < 0 {
                        flags.push('-');
                        ((-w) as usize).min(MAX_WIDTH)
                    } else {
                        (w as usize).min(MAX_WIDTH)
                    }
                } else {
                    let mut width_str = String::new();
                    while i < bytes.len() && bytes[i].is_ascii_digit() {
                        width_str.push(bytes[i] as char);
                        i += 1;
                    }
                    width_str.parse::<usize>().unwrap_or(0).min(MAX_WIDTH)
                };

                // Precision — likewise supports `*`.
                let mut precision: Option<usize> = None;
                if i < bytes.len() && bytes[i] == b'.' {
                    i += 1;
                    if i < bytes.len() && bytes[i] == b'*' {
                        i += 1;
                        let p_str = if arg_idx < args.len() {
                            let a = args[arg_idx].clone();
                            arg_idx += 1;
                            a
                        } else {
                            String::from("0")
                        };
                        // Detect overflow for precision *: values > INT_MAX = "Result too large"
                        // bash behavior: on overflow, emit error but use full string (no truncation).
                        const INT_MAX_P: i64 = 2147483647;
                        let mut prec_overflow = false;
                        let p = match p_str.trim().parse::<i64>() {
                            Ok(v) if v > INT_MAX_P => {
                                eprintln!("{}: printf: {}: Result too large", err_prefix, p_str.trim());
                                exit_code = 1;
                                prec_overflow = true;
                                v
                            }
                            Ok(v) => v,
                            Err(_) => {
                                eprintln!("{}: printf: {}: Result too large", err_prefix, p_str.trim());
                                exit_code = 1;
                                prec_overflow = true;
                                i64::MAX
                            }
                        };
                        // On overflow: bash uses no precision limit (full string).
                        // On negative: bash uses 0 precision.
                        precision = if prec_overflow {
                            None // no truncation
                        } else if p < 0 {
                            Some(0)
                        } else {
                            Some(p as usize)
                        };
                    } else {
                        let mut prec_str = String::new();
                        while i < bytes.len() && bytes[i].is_ascii_digit() {
                            prec_str.push(bytes[i] as char);
                            i += 1;
                        }
                        // Detect overflow for inline precision (bash threshold: > INT_MAX = 2147483647)
                        // Note: bash only emits "Result too large" for %q/%Q, not %s/%d/etc.
                        // Track overflow to emit error later (only for %q/%Q).
                        let p_val: u64 = prec_str.parse().unwrap_or(u64::MAX);
                        if p_val > 2147483647 {
                            prec_overflow_str = Some(prec_str.clone());
                        }
                        precision = Some(if p_val == u64::MAX { 0 } else { p_val.min(2147483647) as usize });
                    }
                }

                // Length modifiers — most are accepted but ignored.
                // 'l' before 's'/'c' gives %ls/%lc (wide char specifiers,
                // alias for %S/%C). Track whether 'l' was the modifier.
                let mut has_l_modifier = false;
                while i < bytes.len() && matches!(bytes[i], b'l' | b'h' | b'L' | b'j' | b'z' | b't') {
                    if bytes[i] == b'l' { has_l_modifier = true; }
                    i += 1;
                }

                if i >= bytes.len() {
                    // Reconstruct the incomplete format spec for error message
                    let spec_start = result.len(); // approximate
                    // Build what we parsed so far for the error message
                    let mut incomplete = String::from("%");
                    incomplete.push_str(&flags);
                    if width > 0 { incomplete.push_str(&width.to_string()); }
                    if let Some(p) = precision { incomplete.push('.'); incomplete.push_str(&p.to_string()); }
                    eprintln!("{}: printf: `{}': missing format character", err_prefix, incomplete);
                    let _ = spec_start; // suppress warning
                    exit_code = 1;
                    break;
                }

                let spec = bytes[i] as char;
                i += 1;

                // Check for %(datefmt)T — datetime specifier
                // Format is %(strftime-fmt)T with a numeric argument (seconds since epoch)
                // -1 = current time, -2 = shell start time
                if spec == '(' {
                    // Collect format string up to matching ')'
                    // but handle nested parens (the format may have embedded text like "(foo)")
                    // Look for )T at end
                    let paren_start = i;
                    let mut depth = 1usize;
                    let mut j = i;
                    while j < bytes.len() {
                        match bytes[j] {
                            b'(' => { depth += 1; j += 1; }
                            b')' => {
                                depth -= 1;
                                j += 1;
                                if depth == 0 { break; }
                            }
                            _ => { j += 1; }
                        }
                    }
                    // Now j points after the closing ')'
                    // The next byte must be 'T'
                    if depth == 0 && j < bytes.len() && bytes[j] == b'T' {
                        // Closing paren was found at j-1, 'T' is at j
                        let datefmt_raw = std::str::from_utf8(&bytes[paren_start..j-1]).unwrap_or("");
                        // Empty format string defaults to %X (locale time representation)
                        let datefmt = if datefmt_raw.is_empty() { "%X" } else { datefmt_raw };
                        i = j + 1; // skip past 'T'

                        // Get the time argument
                        let arg = if arg_idx < args.len() {
                            let a = args[arg_idx].clone();
                            arg_idx += 1;
                            a
                        } else {
                            String::new()
                        };

                        let secs: i64 = arg.trim().parse().unwrap_or(-1);
                        let time_secs: i64 = if secs < 0 {
                            // -1 = current time, -2 = shell start (use current), missing arg = current
                            std::time::SystemTime::now()
                                .duration_since(std::time::UNIX_EPOCH)
                                .map(|d| d.as_secs() as i64)
                                .unwrap_or(0)
                        } else {
                            secs
                        };

                        let time_str = format_strftime(datefmt, time_secs);
                        // Apply width/precision
                        let time_bytes = time_str.as_bytes();
                        let truncated: &[u8] = match precision {
                            Some(p) => &time_bytes[..p.min(time_bytes.len())],
                            None => time_bytes,
                        };
                        if width > truncated.len() {
                            if flags.contains('-') {
                                result.extend_from_slice(truncated);
                                for _ in 0..(width - truncated.len()) { result.push(b' '); }
                            } else {
                                for _ in 0..(width - truncated.len()) { result.push(b' '); }
                                result.extend_from_slice(truncated);
                            }
                        } else {
                            result.extend_from_slice(truncated);
                        }
                        continue;
                    } else if depth == 0 && j < bytes.len() {
                        // Got %(...)X where X != 'T' — warn and output literally
                        // Note: paren_start points after '('; spec was '(' at (i-1)
                        let term_char = bytes[j] as char;
                        eprintln!("{}: printf: warning: `{}': invalid time format specification",
                            err_prefix, term_char);
                        // Output the literal %(content)X including the '(' and terminal char
                        result.push(b'%');
                        result.push(b'('); // re-emit the '(' since paren_start is after it
                        result.extend_from_slice(&bytes[paren_start..j]); // 'content)' portion
                        result.push(bytes[j]); // include the terminal char (e.g. 'Z')
                        i = j + 1;
                        continue;
                    } else {
                        // Not a valid %(...)T — treat as unknown format
                        // Reset i to after '(' and emit % + ( literally
                        i = paren_start;
                        result.push(b'%');
                        result.push(b'(');
                        continue;
                    }
                }

                let (arg, arg_was_provided) = if arg_idx < args.len() {
                    let a = args[arg_idx].clone();
                    arg_idx += 1;
                    (a, true)
                } else {
                    (String::new(), false)
                };

                let left_align = flags.contains('-');
                // POSIX: if precision is given for integer types, the 0 flag is ignored
                let is_int_spec = matches!(spec, 'd' | 'i' | 'u' | 'o' | 'x' | 'X');
                let zero_pad = flags.contains('0') && !left_align
                    && !(is_int_spec && precision.is_some());
                let plus = flags.contains('+');
                let space = flags.contains(' ');
                let alt_form = flags.contains('#');

                match spec {
                    '%' => {
                        // %% is a literal %, does NOT consume an argument.
                        result.push(b'%');
                        // Give back the arg we consumed
                        if arg_idx > 0 && arg_idx <= args.len() {
                            arg_idx -= 1;
                        }
                    }
                    's' | 'S' => {
                        // %S (or %ls): precision and width count Unicode chars, not bytes.
                        // %s: precision and width count bytes.
                        let wide_mode = spec == 'S' || has_l_modifier;
                        if wide_mode {
                            // Precision in wide chars (Unicode codepoints)
                            let truncated_str: String = match precision {
                                Some(p) => arg.chars().take(p).collect(),
                                None => arg.clone(),
                            };
                            let char_count = truncated_str.chars().count();
                            let tbytes = truncated_str.as_bytes();
                            // Width is in character count for %ls/%S
                            if width > char_count {
                                let pad = width - char_count;
                                if left_align {
                                    result.extend_from_slice(tbytes);
                                    for _ in 0..pad { result.push(b' '); }
                                } else {
                                    for _ in 0..pad { result.push(b' '); }
                                    result.extend_from_slice(tbytes);
                                }
                            } else {
                                result.extend_from_slice(tbytes);
                            }
                        } else {
                            // %s: precision in bytes
                            let arg_bytes = crate::expand::decode_raw_bytes(&arg);
                            let truncated: &[u8] = match precision {
                                Some(p) => &arg_bytes[..p.min(arg_bytes.len())],
                                None => &arg_bytes,
                            };
                            pad_bytes_to(&mut result, truncated, width, left_align, false, plus, space);
                        }
                    }
                    'n' => {
                        // %n — store current character count in the named variable.
                        // In bash, the argument to %n must be a valid identifier.
                        // If it's not, print an error.
                        let vname = arg.trim();
                        if vname.is_empty() || !is_valid_identifier(vname) {
                            // Flush accumulated output to stdout before emitting error
                            // so that stdout/stderr ordering is correct in merged 2>&1.
                            if flush_stdout && !result.is_empty() {
                                let _ = std::io::Write::write_all(&mut std::io::stdout(), &result);
                                let _ = std::io::Write::flush(&mut std::io::stdout());
                                result.clear();
                            }
                            eprintln!("{}: printf: `{}': not a valid identifier", err_prefix, vname);
                            exit_code = 1;
                        } else {
                            // Record the assignment: varname -> current byte count
                            n_assignments.push((vname.to_string(), result.len()));
                        }
                        // %n does not consume output
                    }
                    'd' | 'i' => {
                        let (n, parse_err) = parse_int_arg_with_overflow(&arg);
                        if let Some((msg, is_overflow)) = parse_err {
                            if arg_was_provided {
                                if is_overflow {
                                    eprintln!("{}: printf: {}: Result too large", err_prefix, msg);
                                } else {
                                    eprintln!("{}: printf: {}: invalid number", err_prefix, msg);
                                }
                                exit_code = 1;
                            }
                        }
                        let sign = if n < 0 { "-".to_string() }
                                   else if plus { "+".to_string() }
                                   else if space { " ".to_string() }
                                   else { String::new() };
                        let abs_s = n.unsigned_abs().to_string();
                        // precision for integers means minimum number of digits (zero-pad)
                        let digits = if let Some(prec) = precision {
                            if abs_s.len() < prec {
                                format!("{:0>width$}", abs_s, width = prec)
                            } else {
                                abs_s
                            }
                        } else {
                            abs_s
                        };
                        let num_str = format!("{}{}", sign, digits);
                        result.extend_from_slice(pad_number(&num_str, width, left_align, zero_pad).as_bytes());
                    }
                    'u' => {
                        let (n, parse_err) = parse_uint_arg(&arg);
                        if let Some(msg) = parse_err {
                            if arg_was_provided {
                                eprintln!("{}: printf: {}: invalid number", err_prefix, msg);
                                exit_code = 1;
                            }
                        }
                        let s = n.to_string();
                        let s = if let Some(prec) = precision {
                            if s.len() < prec { format!("{:0>width$}", s, width = prec) } else { s }
                        } else { s };
                        result.extend_from_slice(pad_number(&s, width, left_align, zero_pad).as_bytes());
                    }
                    'x' => {
                        let (n, parse_err) = parse_uint_arg(&arg);
                        if let Some(msg) = parse_err {
                            if arg_was_provided {
                                eprintln!("{}: printf: {}: invalid number", err_prefix, msg);
                                exit_code = 1;
                            }
                        }
                        let s = format!("{:x}", n);
                        let s = if let Some(prec) = precision {
                            if s.len() < prec { format!("{:0>width$}", s, width = prec) } else { s }
                        } else { s };
                        let s = if alt_form && n != 0 { format!("0x{}", s) } else { s };
                        result.extend_from_slice(pad_number(&s, width, left_align, zero_pad).as_bytes());
                    }
                    'X' => {
                        let (n, parse_err) = parse_uint_arg(&arg);
                        if let Some(msg) = parse_err {
                            if arg_was_provided {
                                eprintln!("{}: printf: {}: invalid number", err_prefix, msg);
                                exit_code = 1;
                            }
                        }
                        let s = format!("{:X}", n);
                        let s = if let Some(prec) = precision {
                            if s.len() < prec { format!("{:0>width$}", s, width = prec) } else { s }
                        } else { s };
                        let s = if alt_form && n != 0 { format!("0X{}", s) } else { s };
                        result.extend_from_slice(pad_number(&s, width, left_align, zero_pad).as_bytes());
                    }
                    'o' => {
                        let (n, parse_err) = parse_uint_arg(&arg);
                        if let Some(msg) = parse_err {
                            if arg_was_provided {
                                eprintln!("{}: printf: {}: invalid number", err_prefix, msg);
                                exit_code = 1;
                            }
                        }
                        let s = format!("{:o}", n);
                        let s = if let Some(prec) = precision {
                            if s.len() < prec { format!("{:0>width$}", s, width = prec) } else { s }
                        } else { s };
                        let s = if alt_form && n != 0 && !s.starts_with('0') { format!("0{}", s) } else { s };
                        result.extend_from_slice(pad_number(&s, width, left_align, zero_pad).as_bytes());
                    }
                    'e' => {
                        let n = parse_float_arg(&arg);
                        let prec = precision.unwrap_or(6);
                        let s = format!("{:.prec$e}", n, prec = prec);
                        // Rust uses 'e+X' but printf wants 'e+0X' format
                        let s = localize_decimal_point(normalize_exp(&s));
                        let s = if plus && n >= 0.0 { format!("+{}", s) } else { s };
                        result.extend_from_slice(pad_number(&s, width, left_align, zero_pad).as_bytes());
                    }
                    'E' => {
                        let n = parse_float_arg(&arg);
                        let prec = precision.unwrap_or(6);
                        let s = format!("{:.prec$E}", n, prec = prec);
                        let s = localize_decimal_point(normalize_exp(&s));
                        let s = if plus && n >= 0.0 { format!("+{}", s) } else { s };
                        result.extend_from_slice(pad_number(&s, width, left_align, zero_pad).as_bytes());
                    }
                    'f' | 'F' => {
                        let n = parse_float_arg(&arg);
                        let prec = precision.unwrap_or(6);
                        let s = if spec == 'F' {
                            localize_decimal_point(format!("{:.prec$}", n, prec = prec)).to_uppercase()
                        } else {
                            localize_decimal_point(format!("{:.prec$}", n, prec = prec))
                        };
                        let s = if plus && n >= 0.0 { format!("+{}", s) } else { s };
                        result.extend_from_slice(pad_number(&s, width, left_align, zero_pad).as_bytes());
                    }
                    'g' | 'G' => {
                        let n = parse_float_arg(&arg);
                        let prec = precision.unwrap_or(6);
                        let prec_eff = prec.max(1);
                        // Use e notation if exponent < -4 or >= prec_eff
                        let s = if n == 0.0 {
                            if prec == 0 { "0".to_string() }
                            else { "0".to_string() }
                        } else {
                            let exp = n.abs().log10().floor() as i32;
                            if exp < -4 || exp >= prec_eff as i32 {
                                let s = format!("{:.prec$e}", n, prec = prec_eff.saturating_sub(1));
                                localize_decimal_point(normalize_exp(&s))
                            } else {
                                // Remove trailing zeros
                                let s = format!("{:.prec$}", n, prec = prec_eff.saturating_sub(1));
                                localize_decimal_point(s).trim_end_matches('0').trim_end_matches('.').to_string()
                            }
                        };
                        let s = if spec == 'G' { s.to_uppercase() } else { s };
                        let s = if plus && n >= 0.0 { format!("+{}", s) } else { s };
                        result.extend_from_slice(pad_number(&s, width, left_align, zero_pad).as_bytes());
                    }
                    'c' | 'C' => {
                        // %c: emit first byte only.
                        // %C (or %lc): emit all bytes of the first Unicode codepoint.
                        // Width for %lc/%C is in chars (1 char emitted), so
                        // width > 1 means add (width-1) space padding.
                        // Missing arg → NUL byte (bash behavior).
                        let wide_mode = spec == 'C' || has_l_modifier;
                        if wide_mode {
                            // Emit all bytes of the first Unicode character
                            let char_bytes: Vec<u8> = if arg.is_empty() {
                                vec![0u8]
                            } else {
                                let first_char = arg.chars().next().unwrap_or('\0');
                                let mut buf = [0u8; 4];
                                let s = first_char.encode_utf8(&mut buf);
                                s.as_bytes().to_vec()
                            };
                            // Width is in character count (1 char emitted)
                            if width > 1 {
                                if left_align {
                                    result.extend_from_slice(&char_bytes);
                                    for _ in 0..(width - 1) { result.push(b' '); }
                                } else {
                                    for _ in 0..(width - 1) { result.push(b' '); }
                                    result.extend_from_slice(&char_bytes);
                                }
                            } else {
                                result.extend_from_slice(&char_bytes);
                            }
                        } else {
                            let arg_bytes = arg.as_bytes();
                            let ch: u8 = if arg_bytes.is_empty() { 0u8 } else { arg_bytes[0] };
                            // Apply width padding (like %s but for one byte)
                            if width > 1 {
                                if left_align {
                                    result.push(ch);
                                    for _ in 0..(width - 1) { result.push(b' '); }
                                } else {
                                    for _ in 0..(width - 1) { result.push(b' '); }
                                    result.push(ch);
                                }
                            } else {
                                result.push(ch);
                            }
                        }
                    }
                    'b' => {
                        // %b — process escape sequences like echo -e.
                        // Use the byte-oriented helper so `\xNN`/`\NNN`
                        // emits a single raw byte and `\c` can terminate
                        // output (distinct from a literal NUL from
                        // `\000`).
                        let (s, stopped) = process_escape_sequences_bytes_with_err(&arg, err_prefix);
                        // Apply width/precision to the processed bytes
                        let truncated: Vec<u8> = match precision {
                            Some(p) => s[..p.min(s.len())].to_vec(),
                            None => s,
                        };
                        if width > truncated.len() {
                            if left_align {
                                result.extend_from_slice(&truncated);
                                for _ in 0..(width - truncated.len()) { result.push(b' '); }
                            } else {
                                for _ in 0..(width - truncated.len()) { result.push(b' '); }
                                result.extend_from_slice(&truncated);
                            }
                        } else {
                            result.extend_from_slice(&truncated);
                        }
                        if stopped {
                            return (result, exit_code, n_assignments);
                        }
                    }
                    'q' | 'Q' => {
                        // %q — shell-quoted.  %Q differs in precision handling.
                        // alt_form (#) forces single-quoting.
                        // %q precision: limits the QUOTED output bytes (like %s).
                        // %Q precision: limits INPUT chars before quoting, then quotes.
                        //   e.g. %.2Q on "a'b" → quote first 2 chars "a'" → "a\'"
                        //   but %.2q on "a'b" → quote "a'b" → "a\'b", take 2 bytes → "a\"
                        // Emit inline precision overflow error for %q/%Q (bash behavior).
                        if let Some(ref overflow_str) = prec_overflow_str {
                            eprintln!("{}: printf: {}: Result too large", err_prefix, overflow_str);
                            exit_code = 1;
                        }
                        let quoted = if spec == 'Q' {
                            // Precision applies to the input: take first P chars, then quote
                            let input: &str = match precision {
                                Some(p) => {
                                    let char_end = arg.char_indices()
                                        .nth(p)
                                        .map(|(idx, _)| idx)
                                        .unwrap_or(arg.len());
                                    &arg[..char_end]
                                }
                                None => &arg,
                            };
                            if alt_form {
                                shell_quote_force_single(input)
                            } else {
                                shell_quote(input)
                            }
                        } else {
                            // %q: quote first, then truncate by precision
                            if alt_form {
                                shell_quote_force_single(&arg)
                            } else {
                                shell_quote(&arg)
                            }
                        };
                        let quoted_bytes = quoted.as_bytes();
                        let truncated: &[u8] = if spec == 'q' {
                            // %q: precision truncates the QUOTED output
                            match precision {
                                Some(p) => &quoted_bytes[..p.min(quoted_bytes.len())],
                                None => quoted_bytes,
                            }
                        } else {
                            // %Q: precision was already applied to input; no further truncation
                            quoted_bytes
                        };
                        pad_bytes_to(&mut result, truncated, width, left_align, false, false, false);
                    }
                    _ => {
                        // Unknown format specifier — print error and stop
                        // processing the format string (bash behavior).
                        eprintln!("{}: printf: `{}': invalid format character", err_prefix, spec);
                        exit_code = 1;
                        return (result, exit_code, n_assignments);
                    }
                }
            } else {
                // Literal byte from the format string — pass it through
                // untouched.  Multi-byte UTF-8 sequences in the source
                // are preserved byte-for-byte.
                result.push(bytes[i]);
                i += 1;
            }
        }

        // If we consumed any args in this pass, and there are still args remaining,
        // cycle the format string.
        if num_args > 0 && arg_idx > start_arg_idx && arg_idx < num_args {
            continue;
        }
        break;
    }

    (result, exit_code, n_assignments)
}

/// Like parse_int_arg but returns (is_overflow: bool) in the error.
fn parse_int_arg_with_overflow(arg: &str) -> (i64, Option<(String, bool)>) {
    let (val, err) = parse_int_arg(arg);
    match err {
        None => (val, None),
        Some(msg) => {
            // Determine if this was an overflow: the value is i64::MAX or i64::MIN
            // AND the string looks numeric (starts with digit or -)
            let s = msg.trim();
            let looks_numeric = !s.is_empty() && {
                let first = s.chars().next().unwrap();
                first.is_ascii_digit() || first == '-' || first == '+'
            };
            let is_overflow = looks_numeric && (val == i64::MAX || val == i64::MIN);
            (val, Some((msg, is_overflow)))
        }
    }
}

/// Parse an integer argument the way bash's printf does:
/// - Leading ' or " means ASCII value of next character
/// - Hex 0x prefix
/// - Octal 0 prefix
/// - Overflow → clamp to i64::MAX or i64::MIN, return error message
/// - Empty string or non-numeric → return 0 with error
/// Returns (value, Option<error_string>)
fn parse_int_arg(arg: &str) -> (i64, Option<String>) {
    let s = arg.trim();
    if s.is_empty() {
        // Empty string → "invalid number" error like bash
        return (0, Some(String::new()));
    }
    if s.starts_with('\'') || s.starts_with('"') {
        // char literal: value is the codepoint of the next char
        let c = s.chars().nth(1).unwrap_or('\0');
        return (c as i64, None);
    }
    // Try hex
    if s.starts_with("0x") || s.starts_with("0X") {
        let hex_part = &s[2..];
        if hex_part.is_empty() {
            return (0, Some(s.to_string()));
        }
        if let Ok(n) = i64::from_str_radix(hex_part, 16) {
            return (n, None);
        }
        if let Ok(n) = u64::from_str_radix(hex_part, 16) {
            return (n as i64, Some(s.to_string()));
        }
        return (i64::MAX, Some(s.to_string()));
    }
    // Try octal: starts with 0 and has more digits
    if s.starts_with('0') && s.len() > 1 {
        let octal_part = &s[1..];
        if octal_part.chars().all(|c| c >= '0' && c <= '7') {
            if let Ok(n) = i64::from_str_radix(octal_part, 8) {
                return (n, None);
            }
        }
    }
    // Try decimal
    if let Ok(n) = s.parse::<i64>() {
        return (n, None);
    }
    // Check if it's partially numeric (starts with digit or sign)
    let first = s.chars().next().unwrap();
    if !first.is_ascii_digit() && first != '-' && first != '+' {
        // Non-numeric string
        return (0, Some(s.to_string()));
    }
    // sign only (just "+" or "-") or overflow
    if s == "+" || s == "-" {
        return (0, Some(s.to_string()));
    }
    // Overflow: try u64 for positive
    if s.starts_with('-') {
        // Negative overflow: clamp to i64::MIN (bash behavior: "Result too large")
        return (i64::MIN, Some(s.to_string()));
    }
    // For very large positives that overflow i64: clamp to i64::MAX (bash behavior)
    // bash: printf "%d\n" 9223372036854775825 → "Result too large" + 9223372036854775807
    (i64::MAX, Some(s.to_string()))
}

/// Parse an unsigned integer argument similarly
fn parse_uint_arg(arg: &str) -> (u64, Option<String>) {
    let s = arg.trim();
    if s.is_empty() { return (0, Some(String::new())); }
    if s.starts_with('\'') || s.starts_with('"') {
        let c = s.chars().nth(1).unwrap_or('\0');
        return (c as u64, None);
    }
    if s.starts_with("0x") || s.starts_with("0X") {
        let hex_part = &s[2..];
        if let Ok(n) = u64::from_str_radix(hex_part, 16) { return (n, None); }
        return (u64::MAX, Some(s.to_string()));
    }
    if s.starts_with('0') && s.len() > 1 {
        let octal_part = &s[1..];
        if octal_part.chars().all(|c| c >= '0' && c <= '7') {
            if let Ok(n) = u64::from_str_radix(octal_part, 8) { return (n, None); }
        }
    }
    if let Ok(n) = s.parse::<u64>() { return (n, None); }
    // Try treating negative as two's complement u64
    if let Ok(n) = s.parse::<i64>() {
        return (n as u64, None);
    }
    // Non-numeric
    let first = s.chars().next().unwrap_or('x');
    if !first.is_ascii_digit() && first != '-' && first != '+' {
        return (0, Some(s.to_string()));
    }
    (0, Some(s.to_string()))
}

/// Parse a float argument: handles char literals ('x) and numeric strings
fn parse_float_arg(arg: &str) -> f64 {
    let s = arg.trim();
    if s.is_empty() { return 0.0; }
    if s.starts_with('\'') || s.starts_with('"') {
        let c = s.chars().nth(1).unwrap_or('\0');
        return c as u64 as f64;
    }
    s.parse::<f64>().unwrap_or(0.0)
}

/// Pad bytes (not string) to given width, optionally left-aligned.
fn pad_bytes_to(result: &mut Vec<u8>, data: &[u8], width: usize, left: bool,
    zero_pad: bool, _plus: bool, _space: bool) {
    if width <= data.len() {
        result.extend_from_slice(data);
        return;
    }
    let pad = width - data.len();
    let pad_char = if zero_pad { b'0' } else { b' ' };
    if left {
        result.extend_from_slice(data);
        for _ in 0..pad { result.push(b' '); }
    } else {
        for _ in 0..pad { result.push(pad_char); }
        result.extend_from_slice(data);
    }
}

/// Shell-quote forcing single-quote style (for %#q).
fn shell_quote_force_single(s: &str) -> String {
    if s.is_empty() {
        return "''".to_string();
    }
    let mut result = String::from("'");
    for b in crate::expand::decode_raw_bytes(s) {
        if b == b'\'' {
            result.push_str("'\\''");
        } else {
            result.push(b as char);
        }
    }
    result.push('\'');
    result
}

/// Format a Unix timestamp using a strftime-like format string.
/// Uses libc's strftime so it respects TZ environment variable.
fn format_strftime(fmt: &str, secs: i64) -> String {
    unsafe {
        // Call tzset() to ensure TZ env var is picked up
        extern "C" { fn tzset(); }
        tzset();
        let t = secs as libc::time_t;
        let mut tm: libc::tm = std::mem::zeroed();
        libc::localtime_r(&t, &mut tm);
        // Use a large buffer (strftime can expand to arbitrary lengths with %Z etc)
        let mut buf = vec![0u8; 4096];
        let fmt_cstr = match std::ffi::CString::new(fmt) {
            Ok(c) => c,
            Err(_) => return String::new(),
        };
        let n = libc::strftime(
            buf.as_mut_ptr() as *mut libc::c_char,
            buf.len(),
            fmt_cstr.as_ptr(),
            &tm,
        );
        if n == 0 {
            String::new()
        } else {
            buf.truncate(n);
            String::from_utf8_lossy(&buf).into_owned()
        }
    }
}

fn pad_number(s: &str, width: usize, left: bool, zero: bool) -> String {
    if s.len() >= width { return s.to_string(); }
    let pad_char = if zero && !left { '0' } else { ' ' };
    let padding = width - s.len();
    if left {
        format!("{}{}", s, " ".repeat(padding))
    } else if zero && s.starts_with('-') {
        format!("-{}{}", "0".repeat(padding), &s[1..])
    } else if zero && s.starts_with('+') {
        format!("+{}{}", "0".repeat(padding), &s[1..])
    } else {
        format!("{}{}", pad_char.to_string().repeat(padding), s)
    }
}

fn normalize_exp(s: &str) -> String {
    // Rust: 1e5 -> bash: 1e+05
    let mut result = String::new();
    let mut chars = s.chars().peekable();
    while let Some(c) = chars.next() {
        if c == 'e' || c == 'E' {
            result.push(c);
            match chars.peek() {
                Some(&'+') | Some(&'-') => {
                    let sign = chars.next().unwrap();
                    result.push(sign);
                    // Ensure at least 2 digits
                    let rest: String = chars.collect();
                    if rest.len() == 1 {
                        result.push('0');
                    }
                    result.push_str(&rest);
                    return result;
                }
                Some(d) if d.is_ascii_digit() => {
                    result.push('+');
                    let rest: String = chars.collect();
                    if rest.len() == 1 {
                        result.push('0');
                    }
                    result.push_str(&rest);
                    return result;
                }
                _ => {}
            }
        } else {
            result.push(c);
        }
    }
    result
}

fn localize_decimal_point(s: String) -> String {
    unsafe {
        let conv = libc::localeconv();
        if conv.is_null() || (*conv).decimal_point.is_null() {
            return s;
        }
        let dp = std::ffi::CStr::from_ptr((*conv).decimal_point)
            .to_string_lossy()
            .into_owned();
        if dp.is_empty() || dp == "." {
            return s;
        }
        if let Some(pos) = s.find('.') {
            let mut out = String::with_capacity(s.len() + dp.len());
            out.push_str(&s[..pos]);
            out.push_str(&dp);
            out.push_str(&s[pos + 1..]);
            out
        } else {
            s
        }
    }
}

fn shell_quote(s: &str) -> String {
    if s.is_empty() {
        return "''".to_string();
    }
    // Bash's printf %q uses:
    //   - ANSI-C form `$'...'` when the input contains any control
    //     characters (below 0x20, or 0x7f DEL) or non-printable
    //     high-bit bytes.  Inside, \a \b \t \n \v \f \r are named;
    //     other non-printing chars use \nnn octal.
    //   - Backslash-escaping for individual special characters
    //     otherwise.
    //   - alphanumeric, _, ., -, :, /, +, %, @, comma are safe.
    //   - ~ is only special at the start of a word.
    //
    // We check for raw bytes rather than Unicode codepoints so that
    // a PUA-encoded raw byte like 0xCD (used by `read` to preserve
    // bytes that don't form valid multibyte sequences) still triggers
    // the $'...' path.
    let bytes = crate::expand::decode_raw_bytes(s);
    let has_nonprint = bytes.iter().any(|&b| b < 0x20 || b == 0x7f || b >= 0x80);
    if has_nonprint {
        let mut result = String::from("$'");
        for b in bytes {
            match b {
                0x07 => result.push_str("\\a"),
                0x08 => result.push_str("\\b"),
                b'\t' => result.push_str("\\t"),
                b'\n' => result.push_str("\\n"),
                0x0b => result.push_str("\\v"),
                0x0c => result.push_str("\\f"),
                b'\r' => result.push_str("\\r"),
                b'\\' => result.push_str("\\\\"),
                b'\'' => result.push_str("\\'"),
                b if b < 0x20 || b == 0x7f || b >= 0x80 => {
                    // Use \nnn octal (bash uses 3-digit octal for
                    // anything outside printable ASCII).
                    result.push_str(&format!("\\{:03o}", b));
                }
                b => result.push(b as char),
            }
        }
        result.push('\'');
        return result;
    }
    let mut result = String::new();
    for (idx, &b) in bytes.iter().enumerate() {
        let c = b as char;
        if c.is_ascii_alphanumeric() || "_.-:/%+@,".contains(c) {
            result.push(c);
        } else if c == '~' && idx > 0 {
            // ~ is only special at the start
            result.push(c);
        } else {
            result.push('\\');
            result.push(c);
        }
    }
    result
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

/// Format an io::Error as just the OS message (e.g. "No such file or directory"),
/// without the "(os error N)" suffix that Rust appends by default.
fn io_err_msg(e: &std::io::Error) -> String {
    if let Some(raw) = e.raw_os_error() {
        let msg = unsafe {
            let ptr = libc::strerror(raw);
            if ptr.is_null() {
                return e.to_string();
            }
            std::ffi::CStr::from_ptr(ptr).to_string_lossy().into_owned()
        };
        return msg;
    }
    e.to_string()
}

// ---------------------------------------------------------------------------
// cd
// ---------------------------------------------------------------------------

fn builtin_cd(shell: &mut Shell, args: &[String]) -> i32 {
    if shell.restricted {
        eprintln!("{}: cd: restricted", shell.err_prefix_with_line());
        return 1;
    }
    let mut physical = shell.opts.physical;
    let mut arg_start = 0;

    for arg in args.iter() {
        match arg.as_str() {
            "-P" => { physical = true; arg_start += 1; }
            "-L" => { physical = false; arg_start += 1; }
            "-e" => { arg_start += 1; } // ignored
            "--" => { arg_start += 1; break; }
            _ => break,
        }
    }

    let target_args = &args[arg_start..];

    // bash: more than one positional arg → "cd: too many arguments"
    if target_args.len() > 1 {
        eprintln!("{}: cd: too many arguments", shell.err_prefix_with_line());
        return 1;
    }

    let target = if target_args.is_empty() {
        // cd with no args goes to $HOME
        match shell.get_var("HOME") {
            Some(h) => h,
            None => {
                eprintln!("{}: cd: HOME not set", shell.err_prefix_with_line());
                return 1;
            }
        }
    } else if target_args[0] == "-" {
        // cd - goes to $OLDPWD (print the target AFTER a successful cd)
        match shell.get_var("OLDPWD") {
            Some(o) => o,
            None => {
                eprintln!("{}: cd: OLDPWD not set", shell.err_prefix_with_line());
                return 1;
            }
        }
    } else {
        target_args[0].clone()
    };

    // Track whether we should print the target directory (cd - form)
    let print_target = !target_args.is_empty() && target_args[0] == "-";

    let old_pwd = shell.get_var("PWD").unwrap_or_default();

    // Whether the CDPATH search resolved the target via a
    // non-empty, non-`.` directory — in which case bash echoes
    // the resolved path to stdout so the user sees where they
    // landed.
    let mut cdpath_echo: Option<String> = None;
    let new_path = if std::path::Path::new(&target).is_absolute() {
        std::path::PathBuf::from(&target)
    } else {
        // Relative: first check CDPATH if set
        let cdpath = shell.get_var("CDPATH").unwrap_or_default();
        let mut found = None;
        if !cdpath.is_empty() {
            for dir in cdpath.split(':') {
                let candidate = if dir.is_empty() {
                    std::path::PathBuf::from(&target)
                } else {
                    std::path::Path::new(dir).join(&target)
                };
                if candidate.is_dir() {
                    // Bash prints the joined path only when the
                    // matching CDPATH entry was non-empty and not
                    // `.`; empty/`.` means "relative to here"
                    // which doesn't warrant echoing.
                    if !dir.is_empty() && dir != "." {
                        cdpath_echo = Some(candidate.to_string_lossy().into_owned());
                    }
                    found = Some(candidate);
                    break;
                }
            }
        }
        found.unwrap_or_else(|| std::path::PathBuf::from(&target))
    };

    // Resolve symlinks if -P
    let final_path = if physical {
        match new_path.canonicalize() {
            Ok(p) => p,
            Err(e) => {
                let prefix = shell.err_prefix_with_line();
                eprintln!("{}: cd: {}: {}", prefix, crate::exec::format_raw_diagnostic_word(&target), io_err_msg(&e));
                return 1;
            }
        }
    } else {
        new_path
    };

    match std::env::set_current_dir(&final_path) {
        Ok(_) => {
            // Build the logical PWD without resolving symlinks.
            // For the physical case final_path is already canonical.
            // For the logical case: if final_path is relative, join it onto
            // the current logical $PWD and normalise `..` lexically.
            let new_pwd = if physical || final_path.is_absolute() {
                final_path.to_string_lossy().to_string()
            } else {
                // Construct logical absolute path from old PWD + relative target.
                let base = std::path::PathBuf::from(&old_pwd);
                let joined = base.join(&final_path);
                // Normalise: walk components and collapse `..` without hitting the FS.
                let mut parts: Vec<std::ffi::OsString> = Vec::new();
                for comp in joined.components() {
                    match comp {
                        std::path::Component::ParentDir => { parts.pop(); }
                        std::path::Component::CurDir => {}
                        other => parts.push(other.as_os_str().to_owned()),
                    }
                }
                let mut norm = std::path::PathBuf::new();
                for p in parts { norm.push(p); }
                norm.to_string_lossy().to_string()
            };
            // Check for readonly OLDPWD/PWD before setting (avoid abort_current_list)
            if shell.vars.is_readonly("OLDPWD") {
                eprintln!("{}: OLDPWD: readonly variable", shell.err_prefix_with_line());
                shell.last_status = 1;
                return 1;
            }
            if shell.vars.is_readonly("PWD") {
                eprintln!("{}: PWD: readonly variable", shell.err_prefix_with_line());
                shell.last_status = 1;
                return 1;
            }
            shell.set_var("OLDPWD", &old_pwd);
            shell.set_var("PWD", &new_pwd);
            shell.vars.export("OLDPWD");
            shell.vars.export("PWD");
            // Update dirstack top (index 0 = current directory)
            if let Some(top) = shell.dirstack.first_mut() {
                *top = new_pwd.clone();
            }
            // Print the destination for `cd -` form
            if print_target {
                println!("{}", new_pwd);
            }
            // When the target was resolved via a non-empty CDPATH
            // entry, bash echoes the resolved absolute/new pwd to
            // stdout so the user sees where they landed.
            if cdpath_echo.is_some() {
                println!("{}", new_pwd);
            }
            0
        }
        Err(e) => {
            let prefix = shell.err_prefix_with_line();
            eprintln!("{}: cd: {}: {}", prefix, crate::exec::format_raw_diagnostic_word(&target), io_err_msg(&e));
            1
        }
    }
}

// ---------------------------------------------------------------------------
// pwd
// ---------------------------------------------------------------------------

fn builtin_pwd(shell: &mut Shell, args: &[String]) -> i32 {
    let physical = args.iter().any(|a| a == "-P");

    let path = if physical {
        match std::env::current_dir() {
            Ok(p) => match p.canonicalize() {
                Ok(rp) => rp.to_string_lossy().to_string(),
                Err(_) => p.to_string_lossy().to_string(),
            },
            Err(e) => {
                eprintln!("{}: pwd: {}", crate::exec::shell_name(), e);
                return 1;
            }
        }
    } else {
        // Logical: use $PWD if set, else real path
        shell.get_var("PWD")
            .or_else(|| std::env::current_dir().ok().map(|p| p.to_string_lossy().to_string()))
            .unwrap_or_default()
    };

    println!("{}", path);
    0
}

// ---------------------------------------------------------------------------
// exit
// ---------------------------------------------------------------------------

fn builtin_exit(shell: &mut Shell, args: &[String]) -> i32 {
    if args.len() > 1 {
        eprintln!("{}: exit: too many arguments", shell.err_prefix_with_line());
        shell.last_status = 2;
        return 2;
    }
    let status = if args.is_empty() {
        shell.last_status
    } else {
        match args[0].trim().parse::<i32>() {
            Ok(v) => v,
            Err(_) => {
                eprintln!(
                    "{}: exit: {}: numeric argument required",
                    shell.err_prefix_with_line(),
                    args[0]
                );
                shell.last_status = 2;
                if shell.posix_mode && !shell.interactive {
                    shell.exit_flag = true;
                }
                return 2;
            }
        }
    };
    shell.do_exit(status);
    // Return the post-trap last_status so that execute_simple sees the
    // correct value (the EXIT trap body may call `exit N` to change it).
    shell.last_status
}

// ---------------------------------------------------------------------------
// return
// ---------------------------------------------------------------------------

fn builtin_return(shell: &mut Shell, args: &[String]) -> i32 {
    if args.len() > 1 {
        eprintln!("{}: return: too many arguments", shell.err_prefix_with_line());
        shell.last_status = 2;
        return 2;
    }
    let status = if args.is_empty() {
        // POSIX interp 1602: inside a signal trap, `return` without an explicit
        // argument uses the $? value at the time the signal was received, not
        // the current $? (which may have been modified by the trap body).
        if shell.in_signal_trap {
            shell.signal_trap_entry_status
        } else {
            shell.last_status
        }
    } else {
        match args[0].trim().parse::<i32>() {
            Ok(v) => v,
            Err(_) => {
                eprintln!(
                    "{}: return: {}: numeric argument required",
                    shell.err_prefix_with_line(),
                    args[0]
                );
                shell.last_status = 2;
                if shell.posix_mode && !shell.interactive {
                    shell.exit_flag = true;
                } else {
                    shell.do_return(2);
                }
                return 2;
            }
        }
    };
    if !shell.vars.in_function_scope() && shell.source_depth == 0 && !shell.in_function_trap {
        eprintln!(
            "{}: return: can only `return' from a function or sourced script",
            shell.err_prefix_with_line()
        );
        shell.last_status = 1;
        if shell.posix_mode && !shell.interactive && !shell.suppress_special_builtin_fatal {
            shell.exit_flag = true;
        }
        return 1;
    }
    shell.do_return(status);
    status
}

// ---------------------------------------------------------------------------
// break / continue
// ---------------------------------------------------------------------------

fn builtin_break(shell: &mut Shell, args: &[String]) -> i32 {
    let effective: &[String] = if args.first().map(|s| s.as_str()) == Some("--") {
        &args[1..]
    } else {
        args
    };
    if effective.len() > 1 {
        eprintln!("{}: break: too many arguments", shell.err_prefix_with_line());
        shell.last_status = 2;
        return 2;
    }
    let n: usize = match effective.first() {
        None => 1,
        Some(a) => match a.parse::<i64>() {
            Ok(v) if v < 1 => {
                eprintln!(
                    "{}: break: {}: loop count out of range",
                    shell.err_prefix_with_line(),
                    a
                );
                shell.last_status = 1;
                if shell.loop_depth > 0 {
                    shell.break_count = 1;
                }
                return 1;
            }
            Ok(v) => v as usize,
            Err(_) => {
                eprintln!(
                    "{}: break: {}: numeric argument required",
                    shell.err_prefix_with_line(),
                    a
                );
                shell.last_status = 2;
                if !shell.interactive {
                    shell.exit_flag = true;
                }
                return 2;
            }
        },
    };
    if n == 0 {
        eprintln!("{}: break: argument must be >= 1", crate::exec::shell_name());
        return 1;
    }
    if shell.loop_depth == 0 {
        // Error is emitted inside do_break; return exit code 1.
        shell.do_break(n);
        return 1;
    }
    shell.do_break(n);
    0
}

fn builtin_continue(shell: &mut Shell, args: &[String]) -> i32 {
    let effective: &[String] = if args.first().map(|s| s.as_str()) == Some("--") {
        &args[1..]
    } else {
        args
    };
    if effective.len() > 1 {
        eprintln!("{}: continue: too many arguments", shell.err_prefix_with_line());
        shell.last_status = 2;
        return 2;
    }
    let n: usize = match effective.first() {
        None => 1,
        Some(a) => match a.parse::<i64>() {
            Ok(v) if v < 1 => {
                eprintln!(
                    "{}: continue: {}: loop count out of range",
                    shell.err_prefix_with_line(),
                    a
                );
                shell.last_status = 1;
                if shell.loop_depth > 0 {
                    shell.break_count = 1;
                }
                return 1;
            }
            Ok(v) => v as usize,
            Err(_) => {
                eprintln!(
                    "{}: continue: {}: numeric argument required",
                    shell.err_prefix_with_line(),
                    a
                );
                shell.last_status = 2;
                if !shell.interactive {
                    shell.exit_flag = true;
                }
                return 2;
            }
        },
    };
    if n == 0 {
        eprintln!("{}: continue: argument must be >= 1", crate::exec::shell_name());
        return 1;
    }
    if shell.loop_depth == 0 {
        shell.do_continue(n);
        return 1;
    }
    shell.do_continue(n);
    0
}

// ---------------------------------------------------------------------------
// test / [
// ---------------------------------------------------------------------------

fn builtin_test(shell: &mut Shell, args: &[String], bracket_form: bool) -> i32 {
    let cmd_name = if bracket_form { "[" } else { "test" };
    let test_args: Vec<&str> = if bracket_form {
        // Remove trailing ']'
        if args.last().map(|s| s.as_str()) != Some("]") {
            let script = shell.get_var("0").unwrap_or_else(|| crate::exec::shell_name().to_string());
            let lineno = shell.get_var("LINENO").unwrap_or_else(|| "0".to_string());
            eprintln!("{}: line {}: [: missing `]'", script, lineno);
            return 2;
        }
        args[..args.len() - 1].iter().map(|s| s.as_str()).collect()
    } else {
        args.iter().map(|s| s.as_str()).collect()
    };

    if test_args.is_empty() {
        return 1; // false
    }

    let script = shell.get_var("0").unwrap_or_else(|| crate::exec::shell_name().to_string());
    let lineno = shell.get_var("LINENO").unwrap_or_else(|| "0".to_string());
    let mut ctx = TestCtx {
        shell,
        cmd_name,
        script,
        lineno,
        bracket_form,
    };

    // Use POSIX-style argument-count heuristics for small arg counts
    // to produce better error messages matching bash behavior.
    let nargs = test_args.len();
    if nargs == 2 {
        // 2 args: $1 must be a valid unary operator, or $1 is "!"
        let a1 = test_args[0];
        let a2 = test_args[1];
        if a1 == "!" {
            // ! $2: true if $2 is empty
            return if a2.is_empty() { 0 } else { 1 };
        }
        if !is_unary_op(a1) {
            test_error(&ctx, &format!("{}: unary operator expected", a1));
            return 2;
        }
    } else if nargs == 3 {
        let a1 = test_args[0];
        let a2 = test_args[1];
        let a3 = test_args[2];
        // POSIX rule for 3 arguments:
        //   - if $2 is a binary op, do STR1 BIN STR2 (even if $1 == '!')
        //   - else if $1 == '!', evaluate as ! (2-arg test)
        //   - else if $1 == '(' && $3 == ')', string test of $2
        //   - otherwise, error.
        if is_binary_op(a2) {
            return match a2 {
                "=" | "==" => if a1 == a3 { 0 } else { 1 },
                "!=" => if a1 != a3 { 0 } else { 1 },
                "<" => if a1 < a3 { 0 } else { 1 },
                ">" => if a1 > a3 { 0 } else { 1 },
                // numeric binary ops — fall through to the general parser
                _ => {
                    let mut pos = 0usize;
                    match test_parse_or(&test_args, &mut pos, &mut ctx) {
                        Ok(true)  => 0,
                        Ok(false) => 1,
                        Err(code) => code,
                    }
                }
            };
        }
        if a1 == "!" {
            // ! unary-test -> negate (2-arg test on a2, a3)
        } else if a1 == "(" && a3 == ")" {
            // ( expr ) -> evaluate expr as string test
        } else if a2 != "-a" && a2 != "-o" {
            test_error(&ctx, &format!("{}: binary operator expected", a2));
            return 2;
        }
    }

    let mut pos = 0usize;
    match test_parse_or(&test_args, &mut pos, &mut ctx) {
        Ok(result) => {
            if pos < test_args.len() {
                // Unconsumed tokens -- give specific error
                let remaining = test_args[pos];
                if remaining == "-a" || remaining == "-o" {
                    // trailing boolean op with no rhs
                    test_error(&ctx, "argument expected");
                } else if is_binary_op(remaining) || is_unary_op(remaining) {
                    test_error(&ctx, &format!("syntax error: `{}' unexpected", remaining));
                } else {
                    test_error(&ctx, "too many arguments");
                }
                2
            } else if result {
                0
            } else {
                1
            }
        }
        Err(code) => code,
    }
}

struct TestCtx<'a> {
    shell: &'a Shell,
    cmd_name: &'a str,
    script: String,
    lineno: String,
    bracket_form: bool,
}

fn test_error(ctx: &TestCtx, msg: &str) {
    eprintln!("{}: line {}: {}: {}", ctx.script, ctx.lineno, ctx.cmd_name, msg);
}

/// Check if a string is a known unary operator.
fn is_unary_op(s: &str) -> bool {
    matches!(s,
        "-z" | "-n" | "-e" | "-f" | "-d" | "-r" | "-w" | "-x" | "-s" |
        "-L" | "-h" | "-p" | "-S" | "-b" | "-c" | "-g" | "-u" | "-k" |
        "-O" | "-G" | "-N" | "-t" | "-a" | "-o" | "-v" | "-R"
    )
}

/// Check if a string is a known binary operator.
fn is_binary_op(s: &str) -> bool {
    matches!(s,
        "=" | "==" | "!=" | "<" | ">" |
        "-eq" | "-ne" | "-lt" | "-le" | "-gt" | "-ge" |
        "-nt" | "-ot" | "-ef"
    )
}

/// Check if a shell option is enabled by name.
fn shell_option_is_set(shell: &Shell, name: &str) -> bool {
    match name {
        "allexport" => shell.opts.allexport,
        "braceexpand" => shell.opts.braceexpand,
        "errexit" => shell.opts.errexit,
        "errtrace" => shell.opts.errtrace,
        "functrace" => shell.opts.functrace,
        "hashall" => shell.opts.hashall,
        "histexpand" => shell.opts.history,
        "monitor" => shell.opts.monitor,
        "noclobber" => shell.opts.noclobber,
        "noexec" => shell.opts.noexec,
        "noglob" => shell.opts.noglob,
        "notify" => shell.opts.notify,
        "nounset" => shell.opts.nounset,
        "onecmd" => shell.opts.onecmd,
        "physical" => shell.opts.physical,
        "pipefail" => shell.opts.pipefail,
        "privileged" => shell.opts.privileged,
        "verbose" => shell.opts.verbose,
        "xtrace" => shell.opts.xtrace,
        _ => false,
    }
}

/// Parse an integer for test comparisons. Returns Err with exit code 2 on failure.
fn test_parse_int(ctx: &TestCtx, s: &str) -> Result<i64, i32> {
    match s.trim().parse::<i64>() {
        Ok(v) => Ok(v),
        Err(_) => {
            test_error(ctx, &format!("{}: integer expected", s));
            Err(2)
        }
    }
}

fn test_var_is_set(ctx: &TestCtx, operand: &str) -> Result<bool, i32> {
    if let Some(bracket) = operand.find('[') {
        if operand.ends_with(']') && is_valid_identifier(&operand[..bracket]) {
            let base = &operand[..bracket];
            let sub = &operand[bracket + 1..operand.len() - 1];
            let mut vars = ctx.shell.vars.clone();
            if vars.is_assoc(base) {
                let key = assoc_builtin_key(
                    sub,
                    &mut vars,
                    ctx.shell.shopt.contains("assoc_expand_once"),
                );
                return Ok(vars.get_assoc(base, &key).is_some());
            }
            if sub.is_empty() {
                test_error(ctx, &format!("{}[]: bad array subscript", base));
                return Err(2);
            }
            if sub == "*" || sub == "@" {
                return Ok(vars.array_length(base) > 0);
            }
            let expanded = if sub.contains("$(")
                || sub.contains('"') || sub.contains('\'')
                || sub.contains(' ') || sub.contains('\t')
            {
                sub.to_string()
            } else {
                crate::expand::expand_arith_vars(sub, &mut vars)
            };
            let idx = match crate::arithmetic::eval_expr(&expanded, &vars) {
                Ok(v) => v,
                Err(err) => {
                    eprintln!("{}: line {}: {}: {}",
                        ctx.script, ctx.lineno, expanded.trim_start(), err);
                    return Err(1);
                }
            };
            let resolved = if idx < 0 {
                match vars.array_max_index(base) {
                    Some(max_idx) => {
                        let real = (max_idx as i64 + 1) + idx;
                        if real < 0 {
                            test_error(ctx, &format!("{}[{}]: bad array subscript", base, sub));
                            return Err(2);
                        }
                        real as usize
                    }
                    None => {
                        test_error(ctx, &format!("{}[{}]: bad array subscript", base, sub));
                        return Err(2);
                    }
                }
            } else {
                idx as usize
            };
            if vars.is_array(base) {
                return Ok(vars.array_element_is_set(base, resolved));
            }
            return Ok(resolved == 0 && vars.is_set(base));
        }
    }
    if ctx.shell.vars.is_assoc(operand) {
        return Ok(ctx.shell.vars.get_assoc(operand, "0").is_some());
    }
    if ctx.shell.vars.is_array(operand) {
        return Ok(ctx.shell.vars.array_element_is_set(operand, 0));
    }
    Ok(ctx.shell.vars.is_set(operand))
}

fn test_parse_or<'a>(args: &[&str], pos: &mut usize, ctx: &mut TestCtx<'a>) -> Result<bool, i32> {
    let mut left = test_parse_and(args, pos, ctx)?;
    while *pos + 1 < args.len() && args[*pos] == "-o" {
        // Disambiguate: is this binary -o (OR) or could it be something else?
        // In the test builtin, -o between expressions is always binary OR.
        *pos += 1;
        let right = test_parse_and(args, pos, ctx)?;
        left = left || right;
    }
    Ok(left)
}

fn test_parse_and<'a>(args: &[&str], pos: &mut usize, ctx: &mut TestCtx<'a>) -> Result<bool, i32> {
    let mut left = test_parse_not(args, pos, ctx)?;
    while *pos + 1 < args.len() && args[*pos] == "-a" {
        // Binary -a (AND)
        *pos += 1;
        let right = test_parse_not(args, pos, ctx)?;
        left = left && right;
    }
    Ok(left)
}

fn test_parse_not<'a>(args: &[&str], pos: &mut usize, ctx: &mut TestCtx<'a>) -> Result<bool, i32> {
    if *pos < args.len() && args[*pos] == "!" {
        *pos += 1;
        return Ok(!test_parse_not(args, pos, ctx)?);
    }
    test_parse_primary(args, pos, ctx)
}

fn test_parse_primary<'a>(args: &[&str], pos: &mut usize, ctx: &mut TestCtx<'a>) -> Result<bool, i32> {
    if *pos >= args.len() {
        return Ok(false);
    }

    // Parenthesized expression: ( expr )
    if args[*pos] == "(" {
        *pos += 1;
        let result = test_parse_or(args, pos, ctx)?;
        if *pos < args.len() && args[*pos] == ")" {
            *pos += 1;
        } else {
            if ctx.bracket_form {
                test_error(ctx, "`)' expected, found ]");
            } else {
                test_error(ctx, "`)' expected");
            }
            return Err(2);
        }
        return Ok(result);
    }

    // Unary operators: need at least 2 tokens, and the operand must not be ")"
    // (if operand is ")", treat the operator as a plain string instead)
    if *pos + 1 < args.len() && args[*pos + 1] != ")" {
        let op = args[*pos];
        let operand = args[*pos + 1];

        match op {
            "-z" => { *pos += 2; return Ok(operand.is_empty()); }
            "-n" => { *pos += 2; return Ok(!operand.is_empty()); }
            "-e" | "-a" => {
                // -a as unary: file exists (same as -e)
                *pos += 2;
                return Ok(std::path::Path::new(operand).exists());
            }
            "-f" => { *pos += 2; return Ok(std::path::Path::new(operand).is_file()); }
            "-d" => { *pos += 2; return Ok(std::path::Path::new(operand).is_dir()); }
            "-r" => {
                *pos += 2;
                return Ok(test_access(operand, libc::R_OK));
            }
            "-w" => {
                *pos += 2;
                return Ok(test_access(operand, libc::W_OK));
            }
            "-x" => {
                *pos += 2;
                return Ok(test_access(operand, libc::X_OK));
            }
            "-s" => {
                *pos += 2;
                return Ok(std::fs::metadata(operand)
                    .map(|m| m.len() > 0)
                    .unwrap_or(false));
            }
            "-L" | "-h" => {
                *pos += 2;
                return Ok(std::fs::symlink_metadata(operand)
                    .map(|m| m.file_type().is_symlink())
                    .unwrap_or(false));
            }
            "-p" => {
                *pos += 2;
                use std::os::unix::fs::FileTypeExt;
                return Ok(std::fs::metadata(operand)
                    .map(|m| m.file_type().is_fifo())
                    .unwrap_or(false));
            }
            "-S" => {
                *pos += 2;
                use std::os::unix::fs::FileTypeExt;
                return Ok(std::fs::metadata(operand)
                    .map(|m| m.file_type().is_socket())
                    .unwrap_or(false));
            }
            "-b" => {
                *pos += 2;
                use std::os::unix::fs::FileTypeExt;
                return Ok(std::fs::metadata(operand)
                    .map(|m| m.file_type().is_block_device())
                    .unwrap_or(false));
            }
            "-c" => {
                *pos += 2;
                use std::os::unix::fs::FileTypeExt;
                return Ok(std::fs::metadata(operand)
                    .map(|m| m.file_type().is_char_device())
                    .unwrap_or(false));
            }
            "-g" => {
                *pos += 2;
                use std::os::unix::fs::PermissionsExt;
                return Ok(std::fs::metadata(operand)
                    .map(|m| m.permissions().mode() & 0o2000 != 0)
                    .unwrap_or(false));
            }
            "-u" => {
                *pos += 2;
                use std::os::unix::fs::PermissionsExt;
                return Ok(std::fs::metadata(operand)
                    .map(|m| m.permissions().mode() & 0o4000 != 0)
                    .unwrap_or(false));
            }
            "-k" => {
                *pos += 2;
                use std::os::unix::fs::PermissionsExt;
                return Ok(std::fs::metadata(operand)
                    .map(|m| m.permissions().mode() & 0o1000 != 0)
                    .unwrap_or(false));
            }
            "-O" => {
                *pos += 2;
                use std::os::unix::fs::MetadataExt;
                return Ok(std::fs::metadata(operand)
                    .map(|m| m.uid() == unsafe { libc::getuid() })
                    .unwrap_or(false));
            }
            "-G" => {
                *pos += 2;
                use std::os::unix::fs::MetadataExt;
                return Ok(std::fs::metadata(operand)
                    .map(|m| m.gid() == unsafe { libc::getgid() })
                    .unwrap_or(false));
            }
            "-N" => {
                *pos += 2;
                use std::os::unix::fs::MetadataExt;
                return Ok(std::fs::metadata(operand)
                    .map(|m| m.mtime() > m.atime() || (m.mtime() == m.atime() && m.mtime_nsec() > m.atime_nsec()))
                    .unwrap_or(false));
            }
            "-t" => {
                *pos += 2;
                match operand.parse::<RawFd>() {
                    Ok(fd) => return Ok(unsafe { libc::isatty(fd) } == 1),
                    Err(_) => {
                        test_error(ctx, &format!("{}: integer expected", operand));
                        return Err(2);
                    }
                }
            }
            "-o" => {
                // Unary -o: test if shell option is set
                *pos += 2;
                return Ok(shell_option_is_set(ctx.shell, operand));
            }
            "-v" => {
                // Unary -v: test if variable is set
                *pos += 2;
                return test_var_is_set(ctx, operand);
            }
            "-R" => {
                // Unary -R: test if variable is a nameref
                *pos += 2;
                return Ok(ctx.shell.vars.is_nameref(operand));
            }
            _ => {}
        }
    }

    // Check for bare `-t` with no operand (defaults to fd 0).
    // This applies when -t is the last token or followed by ")" or "-a"/"-o"
    if args[*pos] == "-t" {
        let next = if *pos + 1 < args.len() { args[*pos + 1] } else { "" };
        if *pos + 1 >= args.len() || next == ")" || next == "-a" || next == "-o" {
            *pos += 1;
            return Ok(unsafe { libc::isatty(0) } == 1);
        }
    }

    // Binary operators: need at least 3 tokens from current pos
    if *pos + 2 < args.len() {
        let op = args[*pos + 1];

        if is_binary_op(op) {
            let left = args[*pos];
            let right = args[*pos + 2];
            *pos += 3;

            return match op {
                "=" | "==" => Ok(left == right),
                "!=" => Ok(left != right),
                "<" => Ok(left < right),
                ">" => Ok(left > right),
                "-eq" => {
                    let l = test_parse_int(ctx, left)?;
                    let r = test_parse_int(ctx, right)?;
                    Ok(l == r)
                }
                "-ne" => {
                    let l = test_parse_int(ctx, left)?;
                    let r = test_parse_int(ctx, right)?;
                    Ok(l != r)
                }
                "-lt" => {
                    let l = test_parse_int(ctx, left)?;
                    let r = test_parse_int(ctx, right)?;
                    Ok(l < r)
                }
                "-le" => {
                    let l = test_parse_int(ctx, left)?;
                    let r = test_parse_int(ctx, right)?;
                    Ok(l <= r)
                }
                "-gt" => {
                    let l = test_parse_int(ctx, left)?;
                    let r = test_parse_int(ctx, right)?;
                    Ok(l > r)
                }
                "-ge" => {
                    let l = test_parse_int(ctx, left)?;
                    let r = test_parse_int(ctx, right)?;
                    Ok(l >= r)
                }
                "-nt" => {
                    let lm = std::fs::metadata(left).and_then(|m| m.modified()).ok();
                    let rm = std::fs::metadata(right).and_then(|m| m.modified()).ok();
                    Ok(match (lm, rm) {
                        (Some(l), Some(r)) => l > r,
                        (Some(_), None) => true,
                        _ => false,
                    })
                }
                "-ot" => {
                    let lm = std::fs::metadata(left).and_then(|m| m.modified()).ok();
                    let rm = std::fs::metadata(right).and_then(|m| m.modified()).ok();
                    Ok(match (lm, rm) {
                        (Some(l), Some(r)) => l < r,
                        (None, Some(_)) => true,
                        _ => false,
                    })
                }
                "-ef" => {
                    use std::os::unix::fs::MetadataExt;
                    let li = std::fs::metadata(left).map(|m| (m.dev(), m.ino())).ok();
                    let ri = std::fs::metadata(right).map(|m| (m.dev(), m.ino())).ok();
                    Ok(li.is_some() && li == ri)
                }
                _ => Ok(false),
            };
        }
    }

    // Single string argument — true if non-empty
    let s = args[*pos];
    *pos += 1;
    Ok(!s.is_empty())
}

/// Use POSIX access(2) to check file permissions against the real user, like bash does.
fn test_access(path: &str, mode: libc::c_int) -> bool {
    let c_path = std::ffi::CString::new(path).unwrap_or_default();
    unsafe { libc::access(c_path.as_ptr(), mode) == 0 }
}

// ---------------------------------------------------------------------------
// source / .
// ---------------------------------------------------------------------------

fn builtin_source(shell: &mut Shell, cmd_name: &str, args: &[String]) -> i32 {
    if args.is_empty() {
        eprintln!("{}: {}: filename argument required",
            shell.err_prefix_with_line(), cmd_name);
        eprintln!("{}: usage: {} [-p path] filename [arguments]",
            cmd_name, cmd_name);
        return 2;
    }

    // `source -p PATH FILE [ARGS...]` — bash 5.2+ allows an explicit
    // search path that takes precedence over $PATH and makes the
    // search happen regardless of the `sourcepath` shopt.
    let mut idx = 0;
    let mut explicit_path: Option<&str> = None;
    while idx < args.len() {
        let arg = &args[idx];
        if arg == "--" {
            idx += 1;
            break;
        }
        if arg == "-p" {
            if args.len() < idx + 3 {
                eprintln!("{}: {}: -p: option requires an argument",
                    shell.err_prefix_with_line(), cmd_name);
                return 2;
            }
            explicit_path = Some(args[idx + 1].as_str());
            idx += 2;
            continue;
        }
        if arg.starts_with('-') && arg != "-" {
            eprintln!("{}: {}: {}: invalid option",
                shell.err_prefix_with_line(), cmd_name, arg);
            eprintln!("{}: usage: {} [-p path] filename [arguments]",
                cmd_name, cmd_name);
            return 2;
        }
        break;
    }

    if idx >= args.len() {
        eprintln!("{}: {}: filename argument required",
            shell.err_prefix_with_line(), cmd_name);
        eprintln!("{}: usage: {} [-p path] filename [arguments]",
            cmd_name, cmd_name);
        return 2;
    }
    let filename = &args[idx];
    let remaining_args = &args[idx + 1..];

    // Restricted shell: block sourcing files with '/' in the name
    if shell.restricted && filename.contains('/') {
        eprintln!("{}: {}: {}: restricted", shell.err_prefix_with_line(), cmd_name, filename);
        return 1;
    }

    // Search PATH if file doesn't contain a slash.  `-p PATH` overrides
    // $PATH and forces the search regardless of the `sourcepath` shopt.
    let search_only = !filename.contains('/')
        && (explicit_path.is_some() || (shell.posix_mode && shell.shopt.contains("sourcepath")));
    let path = if !filename.contains('/') {
        if let Some(sp) = explicit_path {
            find_in_search_path(sp, filename)
        } else if shell.shopt.contains("sourcepath") {
            find_in_path(shell, filename)
        } else {
            Some(filename.clone())
        }
    } else {
        Some(filename.clone())
    };

    let Some(path) = path.or_else(|| (!search_only).then(|| filename.clone())) else {
        eprintln!("{}: {}: {}: file not found",
            shell.err_prefix_with_line(), cmd_name, filename);
        if shell.posix_mode {
            shell.exit_flag = true;
        }
        return 1;
    };

    match std::fs::read_to_string(&path) {
        Ok(content) => {
            // Set up positional parameters for the sourced file
            let saved_count = shell.vars.positional_count;
            let mut saved_positional: Vec<(String, Option<String>)> = Vec::new();
            for i in 1..=saved_count {
                let key = i.to_string();
                saved_positional.push((key.clone(), shell.vars.get(&key)));
            }
            if !remaining_args.is_empty() {
                shell.vars.positional_count = remaining_args.len();
                for (i, arg) in remaining_args.iter().enumerate() {
                    shell.set_var(&(i + 1).to_string(), arg);
                }
                for i in (remaining_args.len() + 1)..=saved_count {
                    shell.vars.unset(&i.to_string());
                }
            }
            let caller_lineno = shell.get_var("LINENO")
                .and_then(|s| s.parse::<usize>().ok())
                .unwrap_or(0);
            let current_source = if let Some(src) = shell.bash_source_stack.first() {
                src.clone()
            } else {
                shell.script_name.clone()
            };
            if shell.bash_source_stack.is_empty() && !current_source.is_empty() {
                shell.bash_source_stack.push(current_source.clone());
                shell.bash_lineno_stack.push(0);
            }
            shell.bash_source_stack.insert(0, path.clone());
            shell.bash_lineno_stack.insert(0, caller_lineno);
            shell.funcname_stack.push("source".to_string());
            // Mark stack-trace arrays dirty so sync below actually runs even
            // when the lazy-sync optimisation (perf-skip in cmdsub children)
            // had left the dirty flag clear.  Without this, a sourced file's
            // BASH_SOURCE[0] would still report the parent script's name,
            // breaking dbg-support and any code that reads BASH_SOURCE inside
            // a sourced file.
            shell.stack_trace_dirty = true;
            shell.sync_stack_trace_arrays();
            shell.source_depth += 1;
            let trace_source = shell.opts.functrace;
            if !trace_source {
                shell.push_untraced_debug_context();
            }
            let mut status = shell.run_string(&content);
            if !trace_source {
                shell.pop_untraced_debug_context();
            }
            shell.source_depth = shell.source_depth.saturating_sub(1);
            shell.funcname_stack.pop();
            if !shell.bash_source_stack.is_empty() {
                shell.bash_source_stack.remove(0);
            }
            if !shell.bash_lineno_stack.is_empty() {
                shell.bash_lineno_stack.remove(0);
            }
            if caller_lineno > 0 {
                shell.set_var("LINENO", &caller_lineno.to_string());
            }
            // Mark dirty so sync_stack_trace_arrays actually rebuilds the
            // FUNCNAME/BASH_SOURCE arrays on return from source.
            shell.stack_trace_dirty = true;
            shell.sync_stack_trace_arrays();
            let caller_is_traced = shell.opts.functrace
                || shell.funcname_stack
                    .last()
                    .map(|name| shell.traced_functions.contains(name))
                    .unwrap_or(false);
            if shell.funcname_stack.is_empty() || caller_is_traced {
                shell.fire_sourced_return_trap(caller_lineno);
            }
            // Restore temporary positional parameters only if the sourced file
            // left them alone. Explicit `set`/`shift` inside the sourced file
            // should persist in the caller.
            if !remaining_args.is_empty() {
                let mut unchanged = shell.vars.positional_count == remaining_args.len();
                if unchanged {
                    for (i, arg) in remaining_args.iter().enumerate() {
                        if shell.vars.get(&(i + 1).to_string()).as_deref() != Some(arg.as_str()) {
                            unchanged = false;
                            break;
                        }
                    }
                }
                if unchanged {
                    shell.vars.positional_count = saved_count;
                    for (key, value) in &saved_positional {
                        match value {
                            Some(v) => shell.set_var(key, v),
                            None => shell.vars.unset(key),
                        }
                    }
                    for i in (saved_count + 1)..=remaining_args.len() {
                        shell.vars.unset(&i.to_string());
                    }
                }
            }
            // `return N` inside a sourced file makes `.` return N.
            if shell.return_flag {
                status = shell.last_status;
                shell.return_flag = false;
            }
            status
        }
        Err(e) => {
            let msg = match e.raw_os_error() {
                Some(libc::ENOENT) => "No such file or directory".to_string(),
                Some(libc::EACCES) => "Permission denied".to_string(),
                Some(libc::EISDIR) => "Is a directory".to_string(),
                Some(libc::ENOTDIR) => "Not a directory".to_string(),
                _ => e.to_string(),
            };
            eprintln!("{}: {}: {}", shell.err_prefix_with_line(), path, msg);
            // In posix mode, failing to source a file is a fatal
            // error — bash halts the enclosing script.  Outside
            // posix mode it's just a non-zero exit status.
            if shell.posix_mode {
                shell.exit_flag = true;
            }
            1
        }
    }
}

fn find_in_search_path(search_path: &str, name: &str) -> Option<String> {
    if name.contains('/') {
        if std::path::Path::new(name).is_file() {
            return Some(name.to_string());
        }
        return None;
    }
    for dir in search_path.split(':') {
        let candidate = if dir.is_empty() {
            format!("./{}", name)
        } else {
            format!("{}/{}", dir, name)
        };
        if std::path::Path::new(&candidate).is_file() {
            return Some(candidate);
        }
    }
    None
}

pub(crate) fn find_in_path(shell: &Shell, name: &str) -> Option<String> {
    // Absolute or relative path: check directly
    if name.contains('/') {
        if std::path::Path::new(name).is_file() {
            return Some(name.to_string());
        }
        return None;
    }
    // When PATH is completely unset, bash falls back to a system default
    // path that treats the current directory ("") as a search entry.
    // This matches `type -p e` -> "./e" behavior with unset PATH.
    let path_var = shell.get_var("PATH")
        .unwrap_or_else(|| ":/usr/local/bin:/usr/local/sbin:/usr/bin:/usr/sbin:/bin:/sbin".to_string());
    for dir in path_var.split(':') {
        let candidate = if dir.is_empty() {
            // Empty PATH element means "current directory"; render as "./name"
            format!("./{}", name)
        } else {
            format!("{}/{}", dir, name)
        };
        if std::path::Path::new(&candidate).is_file() {
            return Some(candidate);
        }
    }
    None
}

pub(crate) fn normalize_hashed_command_path(path: &str) -> String {
    let p = std::path::Path::new(path);
    if p.is_absolute() || !path.contains('/') {
        return path.to_string();
    }
    match std::env::current_dir() {
        Ok(cwd) => cwd.join(p).to_string_lossy().into_owned(),
        Err(_) => path.to_string(),
    }
}

fn print_signal_list() {
    let mut printed = 0usize;
    for i in 1..=31i32 {
        if let Some(name) = crate::trap::TrapHandler::signal_num_to_name(i) {
            print!("{:>2}) SIG{}\t", i, name);
            printed += 1;
            if printed % 5 == 0 {
                println!();
            }
        }
    }
    if printed % 5 != 0 {
        println!();
    }
}

// ---------------------------------------------------------------------------
// eval
// ---------------------------------------------------------------------------

fn builtin_eval(shell: &mut Shell, args: &[String]) -> i32 {
    // Validate options: eval only accepts `--`.  Any other leading
    // `-X` is an invalid option and should trigger bash's 2-line error.
    for a in args.iter() {
        if a == "--" { break; }
        if !a.starts_with('-') || a == "-" { break; }
        // Reject unrecognized flags (no flag is recognized)
        let ch = a.chars().nth(1).unwrap_or('?');
        eprintln!("{}: eval: -{}: invalid option",
            shell.err_prefix_with_line(), ch);
        eprintln!("eval: usage: eval [arg ...]");
        return 2;
    }
    if args.is_empty() {
        return 0;
    }
    // Skip leading `--` if present
    let effective_args: Vec<String> = args.iter()
        .enumerate()
        .filter(|(i, a)| !(*i == 0 && *a == "--"))
        .map(|(_, a)| a.clone())
        .collect();
    if effective_args.is_empty() {
        return 0;
    }
    let cmd_str = effective_args.join(" ");

    // Pad the eval string with newlines so that command line numbers inside
    // eval report the outer script's LINENO (matching bash behaviour where
    // eval doesn't reset LINENO — commands in eval are attributed to the
    // line where eval itself was called).
    let outer_lineno: usize = shell.get_var("LINENO")
        .and_then(|s| s.parse().ok())
        .unwrap_or(1);
    let padding = if outer_lineno > 1 {
        "\n".repeat(outer_lineno - 1)
    } else {
        String::new()
    };
    let padded_cmd = format!("{}{}", padding, cmd_str);

    // Use run_string so that alias expansion, incremental parsing, and all
    // other shell features (heredocs, compound commands, etc.) work correctly.
    shell.eval_depth += 1;
    let prev_eval_string = shell.eval_string.take();
    shell.eval_string = Some(cmd_str.clone());
    let status = shell.run_string(&padded_cmd);
    shell.eval_string = prev_eval_string;
    shell.eval_depth -= 1;
    status
}

// ---------------------------------------------------------------------------
// exec
// ---------------------------------------------------------------------------

fn builtin_exec(shell: &mut Shell, args: &[String]) -> i32 {
    use std::ffi::CString;
    use std::ffi::OsString;

    let mut arg_start = 0;
    let mut clear_env = false;
    let mut login_mode = false;
    let mut _env_pairs: Vec<String> = Vec::new();
    // `-a NAME` overrides argv[0] passed to the execed program.
    let mut exec_argv0: Option<String> = None;

    // Parse options.  Bash's `exec` getopt is `cla:`.  Anything else
    // that starts with `-` is an invalid option.
    while arg_start < args.len() {
        match args[arg_start].as_str() {
            "-c" => { clear_env = true; arg_start += 1; }
            "-l" => { login_mode = true; arg_start += 1; }
            "-a" => {
                if arg_start + 1 >= args.len() {
                    eprintln!("{}: exec: -a: option requires an argument",
                        shell.err_prefix_with_line());
                    return 2;
                }
                exec_argv0 = Some(args[arg_start + 1].clone());
                arg_start += 2;
            }
            "--" => { arg_start += 1; break; }
            s if s.starts_with('-') && s.len() > 1 => {
                eprintln!("{}: exec: {}: invalid option",
                    shell.err_prefix_with_line(), s);
                eprintln!("exec: usage: exec [-cl] [-a name] [command [argument ...]] [redirection ...]");
                return 2;
            }
            _ => break,
        }
    }

    // Restricted shell: block exec with a command
    if shell.restricted && arg_start < args.len() {
        eprintln!("{}: exec: restricted", shell.err_prefix_with_line());
        return 1;
    }

    if arg_start >= args.len() {
        // exec with no command: just set up redirections (already done by exec.rs)
        return 0;
    }

    // argv[0] for the execed program: bash's -a overrides,
    // and -l prefixes a `-` (login-style invocation).
    let program_path = args[arg_start].clone();
    let argv0 = exec_argv0.unwrap_or_else(|| program_path.clone());
    let argv0 = if login_mode {
        format!("-{}", argv0)
    } else {
        argv0
    };

    let mut cmd_args: Vec<CString> = Vec::new();
    cmd_args.push(CString::new(argv0.as_bytes()).unwrap_or_default());
    for a in &args[arg_start + 1..] {
        cmd_args.push(CString::new(a.as_bytes()).unwrap_or_default());
    }
    let program_cstr = CString::new(program_path.as_bytes()).unwrap_or_default();

    if cmd_args.is_empty() {
        return 0;
    }

    // Set up environment. `exec -c` starts with an empty environment,
    // so even temporary assignments preceding `exec` must be dropped.
    let old_env: Vec<(OsString, OsString)> = std::env::vars_os().collect();
    for (k, _) in old_env.iter() {
        std::env::remove_var(&k);
    }
    if !clear_env {
        let env_map = shell.vars.get_exports();
        for (k, v) in &env_map {
            std::env::set_var(k, v);
        }
    }

    // execvp.  `ptrs` MUST outlive the call: building the slice inside
    // the argument block produces a dangling pointer because the Vec
    // is dropped at the end of that block, so `execvp` reads freed
    // memory and typically returns EFAULT ("Bad address").
    let mut ptrs: Vec<*const libc::c_char> =
        cmd_args.iter().map(|s| s.as_ptr()).collect();
    ptrs.push(std::ptr::null());
    // Pass the original program path for lookup but cmd_args[0] as argv[0],
    // matching bash's `-a NAME` and `-l` semantics.
    let rc = unsafe { libc::execvp(program_cstr.as_ptr(), ptrs.as_ptr()) };

    if rc < 0 {
        for (k, _) in std::env::vars_os().collect::<Vec<_>>() {
            std::env::remove_var(&k);
        }
        for (k, v) in &old_env {
            std::env::set_var(k, v);
        }
        let err = std::io::Error::last_os_error();
        let exit_code = match err.raw_os_error() {
            Some(libc::EACCES) => 126,
            _ => 127,
        };
        // Bash's exec-failure diagnostic is special-cased: ENOENT on a
        // bare command name (no slash) reports "exec: NAME: not found"
        // instead of the generic "No such file or directory".
        if matches!(err.raw_os_error(), Some(libc::ENOENT))
            && !args[arg_start].contains('/')
        {
            eprintln!("{}: exec: {}: not found",
                shell.err_prefix_with_line(), args[arg_start]);
        } else {
            let msg = match err.raw_os_error() {
                Some(libc::ENOENT) => "No such file or directory".to_string(),
                Some(libc::EACCES) => "Permission denied".to_string(),
                Some(libc::EFAULT) => "Bad address".to_string(),
                Some(libc::ENOTDIR) => "Not a directory".to_string(),
                Some(libc::EISDIR) => "Is a directory".to_string(),
                _ => err.to_string(),
            };
            eprintln!("{}: {}: {}", shell.err_prefix_with_line(), args[arg_start], msg);
        }
        // Bash: a failed exec kills the (sub)shell.  Set exit_flag
        // so enclosing command sequences stop; the outer runtime
        // honours exit_flag to unwind.
        shell.last_status = exit_code;
        shell.exit_flag = true;
    }
    1
}

// ---------------------------------------------------------------------------
// export
// ---------------------------------------------------------------------------

fn builtin_export(shell: &mut Shell, args: &[String]) -> i32 {
    if args.is_empty() || args[0] == "-p" {
        // Print all exported variables
        let exports = shell.vars.get_exports();
        let mut names: Vec<String> = exports.keys().cloned().collect();
        names.sort();
        for name in names {
            let val = exports.get(&name).unwrap();
            println!("declare -x {}=\"{}\"", name, val.replace('"', "\\\""));
        }
        return 0;
    }

    let mut unexport = false;
    let mut func_mode = false;
    let mut array_flag = false;
    let mut idx = 0;

    while idx < args.len() {
        let a = args[idx].as_str();
        if a == "-n" { unexport = true; idx += 1; }
        else if a == "-f" { func_mode = true; idx += 1; }
        else if a == "-a" || a == "-A" { array_flag = true; idx += 1; }
        else if a == "--" { idx += 1; break; }
        else if a.starts_with('-') { idx += 1; } // skip unknown flags
        else { break; }
    }

    let mut status = 0;
    for arg in &args[idx..] {
        if func_mode {
            // export -f name  — export a shell function
            // Names containing '=' or '/' cannot be exported (bash rule)
            let name = arg.as_str();
            if name.contains('=') || name.contains('/') {
                let lineno = shell.get_var("LINENO").unwrap_or_else(|| "0".to_string());
                let prefix = shell.err_prefix();
                eprintln!("{}: line {}: export: {}: cannot export", prefix, lineno, name);
                status = 1;
                continue;
            }
            if let Some(func) = shell.functions.get(name).cloned() {
                // Serialise the function body as "() { ... }" and store in env
                let body_src = crate::exec::serialize_command(&func.body);
                let func_val = format!("() {}", body_src);
                let env_key = format!("BASH_FUNC_{}%%", name);
                shell.export_var(&env_key, &func_val);
            } else {
                // Bash: `export -f NAME` on a non-function errors with
                // "export: NAME: not a function" and returns non-zero.
                eprintln!("{}: export: {}: not a function",
                    shell.err_prefix_with_line(), name);
                status = 1;
            }
        } else if let Some(eq_pos) = arg.find('=') {
            // Detect name+=value (append) vs name=value (assign)
            let (name, value, is_append) = if eq_pos > 0 && arg.as_bytes()[eq_pos - 1] == b'+' {
                (&arg[..eq_pos - 1], &arg[eq_pos + 1..], true)
            } else {
                (&arg[..eq_pos], &arg[eq_pos + 1..], false)
            };
            if !is_valid_identifier(name) {
                eprintln!("{}: export: `{}': not a valid identifier", shell.err_prefix_with_line(), name);
                if shell.posix_mode && !shell.interactive && !shell.suppress_special_builtin_fatal {
                    shell.exit_flag = true;
                    return 1;
                }
                status = 1;
                continue;
            }
            if !unexport && shell.vars.is_readonly(name) {
                let readonly_name = shell.vars.resolve_nameref(name).unwrap_or_else(|| name.to_string());
                eprintln!("{}: {}: readonly variable", shell.err_prefix_with_line(), readonly_name);
                if shell.posix_mode && !shell.interactive && !shell.suppress_special_builtin_fatal {
                    shell.exit_flag = true;
                    return 1;
                }
                status = 1;
                continue;
            }
            if unexport {
                // -n with = is unusual; just set without exporting
                if is_append {
                    if !shell.append_var(name, value) {
                        status = 1;
                        continue;
                    }
                } else {
                    shell.set_var(name, value);
                }
            } else if value.starts_with("\x00ARRAY\x00") {
                // Array assignment: parse and set as indexed array, then export
                let content = &value["\x00ARRAY\x00".len()..];
                let elements: Vec<String> = if content.is_empty() {
                    Vec::new()
                } else {
                    content.split('\x1F')
                        .map(|e| strip_compound_bare_elem(e).to_string())
                        .collect()
                };
                if is_append {
                    for e in elements { shell.vars.push_array(name, &e); }
                } else {
                    shell.vars.set_array(name, elements);
                }
                shell.vars.export(name);
            } else if array_flag && value.starts_with('(') && value.ends_with(')') {
                // -a flag with literal (val): parse as array literal
                let inner = &value[1..value.len() - 1];
                let elements: Vec<String> = inner.split_whitespace()
                    .map(|w| shell.expand_word_for_builtin(w))
                    .collect();
                if is_append {
                    for e in elements { shell.vars.push_array(name, &e); }
                } else {
                    shell.vars.set_array(name, elements);
                }
                shell.vars.export(name);
            } else if !is_append && shell.vars.is_array(name) {
                // Variable is already an array: assign value as sole element [0]
                shell.vars.set_array(name, vec![value.to_string()]);
                shell.vars.export(name);
            } else if is_append {
                if !shell.append_var(name, value) {
                    status = 1;
                    continue;
                }
                shell.vars.export(name);
            } else {
                shell.export_var(name, value);
            }
        } else {
            let name = arg.as_str();
            if !is_valid_identifier(name) {
                eprintln!("{}: export: `{}': not a valid identifier", shell.err_prefix_with_line(), name);
                if shell.posix_mode && !shell.interactive && !shell.suppress_special_builtin_fatal {
                    shell.exit_flag = true;
                    return 1;
                }
                status = 1;
                continue;
            }
            if unexport {
                // Remove export flag
                shell.vars.unexport(name);
            } else {
                // Export existing var.  Create an uninitialized
                // entry if the variable doesn't exist yet — bash's
                // `export foo` creates a declared-but-unset slot,
                // so `declare -p foo` prints `declare -x foo`
                // without an `=""` tail.  We don't call set() here
                // because that would mark it as initialized.
                shell.vars.export(name);
            }
        }
    }
    status
}

// ---------------------------------------------------------------------------
// unset
// ---------------------------------------------------------------------------

fn bash_compat_at_most(shell: &Shell, target: u32) -> bool {
    let Some(raw) = shell.get_var("BASH_COMPAT") else {
        return false;
    };
    let trimmed = raw.trim();
    if trimmed.is_empty() {
        return false;
    }
    let compat = if let Some((major, minor)) = trimmed.split_once('.') {
        let Ok(major) = major.parse::<u32>() else {
            return false;
        };
        let Ok(minor) = minor.parse::<u32>() else {
            return false;
        };
        major.saturating_mul(10).saturating_add(minor)
    } else {
        let Ok(value) = trimmed.parse::<u32>() else {
            return false;
        };
        value
    };
    compat <= target
}

fn unset_assoc_uses_raw_operand(raw_name: &str) -> bool {
    has_balanced_outer_quotes(raw_name)
}

fn builtin_unset(shell: &mut Shell, args: &[String], raw_args: &[String]) -> i32 {
    let mut func_mode = false;
    let mut var_mode = false;
    let mut nameref_mode = false;
    let mut idx = 0;

    while idx < args.len() {
        match args[idx].as_str() {
            "-f" => { func_mode = true; idx += 1; }
            "-v" => { var_mode = true; idx += 1; }
            "-n" => { nameref_mode = true; idx += 1; }
            "--" => { idx += 1; break; }
            s if s.starts_with('-') && s.len() >= 2 => {
                eprintln!("{}: unset: {}: invalid option",
                    shell.err_prefix_with_line(), s);
                eprintln!("unset: usage: unset [-f] [-v] [-n] [name ...]");
                return 2;
            }
            _ => break,
        }
    }

    // Bash rejects combining -f with -v or -n.
    if func_mode && (var_mode || nameref_mode) {
        eprintln!("{}: unset: cannot simultaneously unset a function and a variable",
            shell.err_prefix_with_line());
        return 2;
    }

    let mut status = 0;
    for (offset, name) in args[idx..].iter().enumerate() {
        let raw_name = raw_args
            .get(idx + offset)
            .map(|s| s.as_str())
            .unwrap_or(name.as_str());
        let assoc_operand_is_raw = unset_assoc_uses_raw_operand(raw_name);
        let assoc_expand_once = shell.shopt.contains("assoc_expand_once");
        // `unset NAME[subscript]` — remove a single element (or set
        // to zero length) without destroying the array variable.
        if var_mode && !func_mode && !nameref_mode && name.contains('[') && name.ends_with(']') {
            let bopen = name.find('[').unwrap();
            let base = &name[..bopen];
            let sub = &name[bopen + 1..name.len() - 1];
            if crate::exec::is_valid_identifier_pub(base) {
                let resolved_base = shell.vars.resolve_nameref(base)
                    .filter(|t| !t.contains('['))
                    .unwrap_or_else(|| base.to_string());
                let resolved_base = resolved_base.as_str();
                if shell.vars.is_readonly(resolved_base) {
                    eprintln!("{}: unset: {}: cannot unset: readonly variable",
                        shell.err_prefix_with_line(), resolved_base);
                        status = 1;
                        continue;
                    }
                if shell.vars.is_assoc(resolved_base) {
                    let key = if assoc_operand_is_raw {
                        assoc_unset_raw_key(sub, shell, assoc_expand_once)
                    } else {
                        assoc_expanded_operand_key(sub)
                    };
                    shell.vars.unset_assoc_element(resolved_base, &key);
                } else if shell.vars.is_array(resolved_base) {
                    // Let the full subscript handling (arithmetic,
                    // negative indices, error reporting) run below by
                    // falling through — don't `continue` here.
                } else if shell.vars.has_entry_raw(resolved_base) {
                    // `unset ps1[2]` on a SCALAR `ps1` emits an error
                    // in bash (`unset: ps1: not an array variable`)
                    // unless the subscript is `0` (which refers to
                    // the scalar value itself, so unset removes the
                    // whole variable).
                    if sub == "0" {
                        shell.vars.unset(resolved_base);
                    } else {
                        eprintln!("{}: unset: {}: not an array variable",
                            shell.err_prefix_with_line(), resolved_base);
                        status = 1;
                    }
                    continue;
                } else {
                    continue;
                }
                if shell.vars.is_assoc(resolved_base) {
                    continue;
                }
            }
        }
        if func_mode || (!var_mode && shell.functions.contains_key(name.as_str())) {
            // Readonly functions can't be unset.  Bash emits
            // "unset: <name>: cannot unset: readonly function" and
            // returns non-zero for that call.
            if shell.readonly_functions.contains(name.as_str()) {
                eprintln!("{}: unset: {}: cannot unset: readonly function",
                    shell.err_prefix_with_line(), name);
                status = 1;
                continue;
            }
            shell.functions.remove(name.as_str());
            // Also remove the corresponding BASH_FUNC_name%% exported env var
            // so that child shells no longer inherit the function.
            let env_key = format!("BASH_FUNC_{}%%", name);
            shell.vars.unset(&env_key);
        }
        if !func_mode {
            // Handle subscripted form: `unset arr[N]` removes one
            // element of an indexed/assoc array, leaving the array
            // itself in place.  `unset arr[*]` / `arr[@]` clears all
            // elements (bash-5 behaviour; the array stays declared).
            if name.ends_with(']') {
                if let Some(br) = name.find('[') {
                    let base = &name[..br];
                    let sub = &name[br + 1..name.len() - 1];
                    if !base.is_empty() && is_valid_identifier(base) {
                        let resolved_base = shell.vars.resolve_nameref(base)
                            .filter(|t| !t.contains('['))
                            .unwrap_or_else(|| base.to_string());
                        let resolved_base = resolved_base.as_str();
                        if shell.vars.is_readonly_raw(resolved_base) {
                            eprintln!("{}: unset: {}: cannot unset: readonly variable",
                                shell.err_prefix_with_line(), resolved_base);
                            status = 1;
                            continue;
                        }
                        if shell.vars.is_assoc(resolved_base) {
                            let key = if assoc_operand_is_raw {
                                assoc_unset_raw_key(sub, shell, assoc_expand_once)
                            } else {
                                assoc_expanded_operand_key(sub)
                            };
                            shell.vars.unset_assoc_element(resolved_base, &key);
                            continue;
                        }
                        if shell.vars.is_array(resolved_base) {
                            if sub == "*" || sub == "@" {
                                if bash_compat_at_most(shell, 51) {
                                    shell.vars.unset(resolved_base);
                                } else {
                                    shell.vars.set_array(resolved_base, Vec::new());
                                }
                                continue;
                            }
                            // Arithmetic subscript (possibly negative).
                            let sub_expanded = if sub.contains("$(")
                                || sub.contains('"') || sub.contains('\'')
                                || sub.contains(' ') || sub.contains('\t')
                            {
                                sub.to_string()
                            } else {
                                crate::expand::expand_arith_vars(sub, &mut shell.vars)
                            };
                            match crate::arithmetic::eval_expr(&sub_expanded, &shell.vars) {
                                Ok(idx) => {
                                    let real = if idx < 0 {
                                        match shell.vars.array_max_index(resolved_base) {
                                            Some(m) => {
                                                let real = (m + 1) as i64 + idx;
                                                if real < 0 {
                                                    eprintln!("{}: unset: [{}]: bad array subscript",
                                                        shell.err_prefix_with_line(), sub);
                                                    status = 1;
                                                    continue;
                                                }
                                                real as usize
                                            }
                                            None => {
                                                eprintln!("{}: unset: [{}]: bad array subscript",
                                                    shell.err_prefix_with_line(), sub);
                                                status = 1;
                                                continue;
                                            }
                                        }
                                    } else {
                                        idx as usize
                                    };
                                    shell.vars.unset_array_element(resolved_base, real);
                                }
                                Err(err) => {
                                    eprintln!("{}: {}: {}",
                                        shell.err_prefix_with_line(), sub_expanded.trim_start(), err);
                                    status = 1;
                                }
                            }
                            continue;
                        }
                        // If the variable doesn't exist at all, bash
                        // silently succeeds — `unset foo[N]` on an
                        // undeclared foo is a no-op.
                        if !shell.vars.has_entry_raw(resolved_base) {
                            continue;
                        }
                        // Scalar variable with subscripted `unset`:
                        // bash treats `[0]` as the scalar itself and
                        // unsets the variable; other subscripts error.
                        if sub == "0" {
                            shell.vars.unset(resolved_base);
                        } else {
                            eprintln!("{}: unset: {}: not an array variable",
                                shell.err_prefix_with_line(), resolved_base);
                            status = 1;
                        }
                        continue;
                    }
                }
            }
            if var_mode && !nameref_mode && !crate::exec::is_valid_identifier_pub(name) {
                eprintln!("{}: unset: `{}': not a valid identifier",
                    shell.err_prefix_with_line(), name);
                status = 1;
                if shell.posix_mode {
                    shell.exit_flag = true;
                    return status;
                }
                continue;
            }
            // `unset -n NAME` strips the nameref attribute / removes
            // the nameref itself without following its chain.  Plain
            // `unset NAME` on a nameref follows the chain to unset
            // the target (Variables::unset handles that).  We check
            // readonly on the raw entry for `-n`, and on the chain
            // target for plain unset (done inside unset itself).
            if nameref_mode {
                if shell.vars.is_readonly_raw(name) {
                    eprintln!("{}: unset: {}: cannot unset: readonly variable",
                        shell.err_prefix_with_line(), name);
                    status = 1;
                } else {
                    shell.vars.unset_noref(name);
                }
            } else if matches!(name.as_str(), "BASH_LINENO" | "BASH_SOURCE" | "BASH_ARGV" | "BASH_ARGC") {
                // These internal variables cannot be unset
                eprintln!("{}: unset: {}: cannot unset",
                    shell.err_prefix_with_line(), name);
                status = 1;
            } else if shell.vars.is_readonly(name) {
                // Report using the target's name for nameref targets —
                // matches bash's `./test.sub: line N: unset: <target>:
                // cannot unset: readonly variable`.
                let display = shell.vars.resolve_nameref(name)
                    .unwrap_or_else(|| name.to_string());
                eprintln!("{}: unset: {}: cannot unset: readonly variable",
                    shell.err_prefix_with_line(), display);
                status = 1;
                if shell.posix_mode {
                    shell.exit_flag = true;
                    return status;
                }
            } else {
                if name == "BASH_XTRACEFD" {
                    shell.xtrace_fd = None;
                }
                shell.vars.unset(name);
            }
        }
    }
    status
}

// ---------------------------------------------------------------------------
// set
// ---------------------------------------------------------------------------

/// Quote a value for `set` output in bash-5.3 style.
/// Values safe to print bare get no quoting.  Values that contain shell
/// meta-characters are single-quoted.  Embedded single-quotes are handled
/// by ending the single-quoted string, adding `\'`, and re-opening.
fn quote_set_value(value: &str) -> String {
    fn needs_quoting(s: &str) -> bool {
        if s.is_empty() {
            return true;
        }
        let first = s.as_bytes()[0];
        if first == b'~' || first == b'#' {
            return true;
        }
        for ch in s.chars() {
            match ch {
                ' ' | '\t' | '\n' | '\\' | '\'' | '"' | '`' | '$' | '!' | '&' | '|' | ';'
                | '(' | ')' | '<' | '>' | '{' | '}' | '[' | ']' | '*' | '?' | '^' => return true,
                _ => {}
            }
        }
        false
    }

    if !needs_quoting(value) {
        return value.to_string();
    }

    // Check if the value contains single quotes — if not, simple single quoting.
    if !value.contains('\'') {
        return format!("'{}'", value);
    }

    // Value has single quotes.  If it ONLY contains single-quote(s) and nothing
    // else that needs quoting, use backslash escaping (bash-5.3 style).
    let only_quotes_need_quoting = value.chars().all(|ch| {
        ch == '\'' || !(matches!(ch,
            ' ' | '\t' | '\n' | '\\' | '"' | '`' | '$' | '!' | '&' | '|' | ';'
            | '(' | ')' | '<' | '>' | '{' | '}' | '[' | ']' | '*' | '?' | '^'
            | '~' | '#'))
    });

    if only_quotes_need_quoting {
        // Use backslash escaping for the single quotes, bare for the rest
        let mut out = String::new();
        for ch in value.chars() {
            if ch == '\'' {
                out.push('\\');
                out.push('\'');
            } else {
                out.push(ch);
            }
        }
        return out;
    }

    // Mixed case: single-quote with embedded single-quote handling
    let mut out = String::from("'");
    for ch in value.chars() {
        if ch == '\'' {
            out.push_str("'\\''");
        } else {
            out.push(ch);
        }
    }
    out.push('\'');
    out
}

fn builtin_set(shell: &mut Shell, args: &[String]) -> i32 {
    if args.is_empty() {
        // Print all variables
        let vars = shell.vars.list_vars();
        for (name, value) in vars {
            if shell.vars.is_assoc(&name) {
                let entries = shell.vars.get_assoc_entries(&name);
                let mut parts = Vec::new();
                for (k, v) in &entries {
                    parts.push(format!("[{}]={}", quote_key_for_declare(k), quote_for_declare(v)));
                }
                println!("{}=({} )", name, parts.join(" "));
                continue;
            }
            if shell.vars.is_array(&name) {
                if let Some(elements) = shell.vars.get_array_sparse(&name) {
                    let mut parts = Vec::new();
                    for (i, val) in &elements {
                        parts.push(format!("[{}]={}", i, quote_for_declare(val)));
                    }
                    println!("{}=({})", name, parts.join(" "));
                    continue;
                }
            }
            println!("{}={}", name, quote_set_value(&value));
        }
        return 0;
    }

    let mut i = 0;
    let mut end_of_opts = false;
    let mut reset_positionals = false;
    let mut positional_args: Vec<String> = Vec::new();

    while i < args.len() {
        let arg = &args[i];
        if end_of_opts {
            positional_args.push(arg.clone());
            i += 1;
            continue;
        }
        match arg.as_str() {
            "--" => {
                // Everything after -- sets positional params
                end_of_opts = true;
                reset_positionals = true;
                i += 1;
            }
            "-" => {
                // Bash: a bare `-` ends option parsing like `--`, but
                // additionally disables `-x` and `-v`.
                shell.unset_option("-x");
                shell.unset_option("-v");
                end_of_opts = true;
                i += 1;
            }
            "-o" => {
                i += 1;
                if i < args.len() && !(args[i].starts_with('-') || args[i].starts_with('+')) {
                    let all_opts = all_set_options(shell);
                    if !all_opts.iter().any(|(name, _)| *name == args[i].as_str()) {
                        eprintln!("{}: set: {}: invalid option name",
                            shell.err_prefix_with_line(), args[i]);
                        return 1;
                    }
                    shell.set_option(&args[i]);
                    i += 1;
                } else {
                    // Print options
                    print_set_options(shell);
                }
            }
            "+o" => {
                i += 1;
                if i < args.len() && !(args[i].starts_with('-') || args[i].starts_with('+')) {
                    if args[i] == "restricted" && shell.restricted {
                        eprintln!("{}: set: restricted: invalid option name", shell.err_prefix_with_line());
                        return 1;
                    }
                    shell.unset_option(&args[i]);
                    i += 1;
                } else {
                    // Print options in set +o form
                    print_set_options_reset(shell);
                }
            }
            s if s.starts_with('-') && s.len() > 1 && s != "--" => {
                let chars: Vec<char> = s[1..].chars().collect();
                let mut j = 0;
                while j < chars.len() {
                    let c = chars[j];
                    if c == 'o' {
                        // -o inside a combined token: next positional arg is
                        // the long-form option name (same as standalone -o).
                        i += 1;
                        if i < args.len() && !(args[i].starts_with('-') || args[i].starts_with('+')) {
                            let all_opts = all_set_options(shell);
                            if !all_opts.iter().any(|(name, _)| *name == args[i].as_str()) {
                                eprintln!("{}: set: {}: invalid option name",
                                    shell.err_prefix_with_line(), args[i]);
                                return 1;
                            }
                            shell.set_option(&args[i]);
                            i += 1;
                        } else {
                            // No option name following — print options.
                            print_set_options(shell);
                        }
                        // Remaining chars in this token are processed after
                        // the consumed option-name arg; re-enter the outer loop.
                        // We synthesise a fake token from the remaining chars.
                        if j + 1 < chars.len() {
                            let remaining: String = std::iter::once('-')
                                .chain(chars[j + 1..].iter().copied())
                                .collect();
                            // Insert the synthetic token just before position i
                            // by pushing it as the next arg to process.
                            // We handle this by re-entering the match with a
                            // recursive-style inline loop over remaining chars.
                            for c2 in chars[j + 1..].iter().copied() {
                                if !"eufnxvCaBhmbEPpHtkrTI".contains(c2) {
                                    eprintln!("{}: set: -{}: invalid option",
                                        shell.err_prefix_with_line(), c2);
                                    eprintln!("set: usage: set [-abefhkmnptuvxBCEHPT] [-o option-name] [--] [-] [arg ...]");
                                    return 2;
                                }
                                shell.set_option(&format!("-{}", c2));
                            }
                            let _ = remaining; // suppress unused warning
                        }
                        // Skip the outer i += 1 at end of arm.
                        j = chars.len(); // exit inner loop
                        continue;
                    }
                    if !"eufnxvCaBhmbEPpHtkrTI".contains(c) {
                        eprintln!("{}: set: -{}: invalid option",
                            shell.err_prefix_with_line(), c);
                        eprintln!("set: usage: set [-abefhkmnptuvxBCEHPT] [-o option-name] [--] [-] [arg ...]");
                        return 2;
                    }
                    shell.set_option(&format!("-{}", c));
                    j += 1;
                }
                // Only increment i if we didn't already do so in the `o` branch.
                if j == chars.len() && !chars.contains(&'o') {
                    i += 1;
                }
            }
            s if s.starts_with('+') && s.len() > 1 => {
                let chars: Vec<char> = s[1..].chars().collect();
                let mut j = 0;
                while j < chars.len() {
                    let c = chars[j];
                    if c == 'o' {
                        // +o inside a combined token: next positional arg is
                        // the long-form option name (same as standalone +o).
                        i += 1;
                        if i < args.len() && !(args[i].starts_with('-') || args[i].starts_with('+')) {
                            if args[i] == "restricted" && shell.restricted {
                                eprintln!("{}: set: restricted: invalid option name", shell.err_prefix_with_line());
                                return 1;
                            }
                            shell.unset_option(&args[i]);
                            i += 1;
                        } else {
                            // No option name following — print options in +o form.
                            print_set_options_reset(shell);
                        }
                        // Process remaining chars in this token.
                        if j + 1 < chars.len() {
                            for c2 in chars[j + 1..].iter().copied() {
                                if c2 == 'r' && shell.restricted {
                                    eprintln!("{}: set: +r: invalid option", shell.err_prefix_with_line());
                                    eprintln!("set: usage: set [-abefhkmnptuvxBCEHPT] [-o option-name] [--] [-] [arg ...]");
                                    return 2;
                                }
                                if !"eufnxvCaBhmbEPpHtkrTI".contains(c2) {
                                    eprintln!("{}: set: +{}: invalid option",
                                        shell.err_prefix_with_line(), c2);
                                    eprintln!("set: usage: set [-abefhkmnptuvxBCEHPT] [-o option-name] [--] [-] [arg ...]");
                                    return 2;
                                }
                                shell.unset_option(&format!("+{}", c2));
                            }
                        }
                        j = chars.len();
                        continue;
                    }
                    if c == 'r' && shell.restricted {
                        eprintln!("{}: set: +r: invalid option", shell.err_prefix_with_line());
                        eprintln!("set: usage: set [-abefhkmnptuvxBCEHPT] [-o option-name] [--] [-] [arg ...]");
                        return 2;
                    }
                    if !"eufnxvCaBhmbEPpHtkrTI".contains(c) {
                        eprintln!("{}: set: +{}: invalid option",
                            shell.err_prefix_with_line(), c);
                        eprintln!("set: usage: set [-abefhkmnptuvxBCEHPT] [-o option-name] [--] [-] [arg ...]");
                        return 2;
                    }
                    shell.unset_option(&format!("+{}", c));
                    j += 1;
                }
                if j == chars.len() && !chars.contains(&'o') {
                    i += 1;
                }
            }
            _ => {
                positional_args.push(arg.clone());
                end_of_opts = true;
                i += 1;
            }
        }
    }

    // If -- was found or non-option args provided, set positional params
    if reset_positionals || !positional_args.is_empty() {
        let old_count = shell.vars.positional_count;
        shell.vars.positional_count = positional_args.len();
        for (i, arg) in positional_args.iter().enumerate() {
            shell.set_var(&(i + 1).to_string(), arg);
        }
        // Clear stale positional parameters beyond new count
        for i in positional_args.len()..old_count {
            shell.vars.unset(&(i + 1).to_string());
        }
    }

    0
}

/// Ordered list of every `set -o` option bash 5.3 recognises, paired
/// with its current on/off state.  The order matches bash's shopt.c
/// list order so `set -o` / `set +o` output matches byte-for-byte.
/// Options brash doesn't track yet (emacs/vi, history, etc.) are
/// reported as perma-off; that still matches non-interactive bash
/// defaults.
fn all_set_options(shell: &Shell) -> Vec<(&'static str, bool)> {
    let opts = &shell.opts;
    vec![
        ("allexport",            opts.allexport),
        ("braceexpand",          opts.braceexpand),
        ("emacs",                opts.emacs),
        ("errexit",              opts.errexit),
        ("errtrace",             opts.errtrace),
        ("functrace",            opts.functrace),
        ("hashall",              opts.hashall),
        ("histexpand",           opts.history),
        ("history",              opts.history_facility),
        ("ignoreeof",            opts.ignoreeof),
        ("interactive-comments", opts.interactive_comments),
        ("keyword",              opts.keyword_assign),
        ("monitor",              opts.monitor),
        ("noclobber",            opts.noclobber),
        ("noexec",               opts.noexec),
        ("noglob",               opts.noglob),
        ("nolog",                opts.nolog),
        ("notify",               opts.notify),
        ("nounset",              opts.nounset),
        ("onecmd",               opts.onecmd),
        ("physical",             opts.physical),
        ("pipefail",             opts.pipefail),
        ("posix",                shell.posix_mode),
        ("privileged",           opts.privileged),
        ("verbose",              opts.verbose),
        ("vi",                   opts.vi),
        ("xtrace",               opts.xtrace),
    ]
}

fn print_set_options_with_width(shell: &Shell, width: usize) {
    for (name, on) in all_set_options(shell) {
        println!("{:<width$}\t{}", name, if on { "on" } else { "off" }, width = width);
    }
}

fn print_set_options(shell: &Shell) {
    // `set -o` uses bash's 15-column formatting.
    print_set_options_with_width(shell, 15);
}

fn print_set_options_reset(shell: &Shell) {
    for (name, on) in all_set_options(shell) {
        println!("set {} {}", if on { "-o" } else { "+o" }, name);
    }
}

// ---------------------------------------------------------------------------
// shift
// ---------------------------------------------------------------------------

fn builtin_shift(shell: &mut Shell, args: &[String]) -> i32 {
    if args.len() == 1 && args[0] == "--help" {
        return builtin_help(shell, &[String::from("shift")]);
    }
    // Accept the POSIX `--` end-of-options marker before the count.
    let effective: &[String] = if args.first().map(|s| s.as_str()) == Some("--") {
        &args[1..]
    } else {
        args
    };
    if effective.len() > 1 {
        eprintln!("{}: shift: too many arguments", shell.err_prefix_with_line());
        return 2;
    }
    let count_arg = effective.first().cloned();
    let n: usize = match count_arg.as_deref() {
        None => 1,
        Some(a) => match a.trim().parse::<i64>() {
            Ok(v) if v < 0 => {
                eprintln!("{}: shift: {}: shift count out of range",
                    shell.err_prefix_with_line(), a);
                return 1;
            }
            Ok(v) => v as usize,
            Err(_) => {
                eprintln!("{}: shift: {}: numeric argument required",
                    shell.err_prefix_with_line(), a);
                if shell.posix_mode && !shell.interactive {
                    shell.exit_flag = true;
                }
                return 2;
            }
        },
    };

    if n > shell.vars.positional_count {
        // In POSIX mode, bash diagnoses an out-of-range shift even without
        // `shift_verbose`. Outside POSIX mode, the diagnostic is gated by the
        // shopt as usual.
        if shell.posix_mode || shell.shopt.contains("shift_verbose") {
            let count_str = count_arg.as_deref().unwrap_or("1");
            eprintln!("{}: shift: {}: shift count out of range",
                shell.err_prefix_with_line(), count_str);
        }
        return 1;
    }

    // Shift positional params left by n
    let new_count = shell.vars.positional_count - n;
    for i in 1..=new_count {
        let val = shell.get_var(&(i + n).to_string()).unwrap_or_default();
        shell.set_var(&i.to_string(), &val);
    }
    // Unset old tail
    for i in (new_count + 1)..=(shell.vars.positional_count) {
        shell.vars.unset(&i.to_string());
    }
    shell.vars.positional_count = new_count;
    0
}

// ---------------------------------------------------------------------------
// declare / typeset / local
// ---------------------------------------------------------------------------

fn local_decl_hits_readonly(shell: &Shell, name: &str) -> bool {
    match shell.vars.find_scope_raw(name) {
        Some(scope) if scope == shell.vars.current_scope_idx() => shell.vars.is_readonly_raw(name),
        Some(0) => shell.vars.is_readonly_raw(name),
        _ => false,
    }
}

fn builtin_declare(shell: &mut Shell, cmd_name: &str, args: &[String], local_mode: bool) -> i32 {
    let mut is_array = false;
    let mut is_assoc = false;
    let mut is_integer = false;
    let mut is_readonly = false;
    let mut is_export = false;
    let mut is_lowercase = false;
    let mut is_uppercase = false;
    let mut is_capitalize = false;
    let mut is_trace = false;
    let mut unset_array_attr = false;
    let mut unset_assoc_attr = false;
    let mut print_mode = false;
    let mut func_mode = false;
    let mut func_names_mode = false;
    let mut global = false;
    let mut nameref = false;
    let mut unset_flags = false;
    // Per-flag removal tracking for `+i`, `+x`, `+l`, `+u`, `+c` …
    let mut unset_integer = false;
    let mut unset_export = false;
    let mut unset_lowercase = false;
    let mut unset_uppercase = false;
    let mut unset_capitalize = false;
    let mut unset_readonly = false;
    let mut plus_seen = false;
    let mut global_preferred_names: Vec<String> = Vec::new();
    let mut local_dash = false;
    let mut local_inherit = false;
    let mut idx = 0;

    while idx < args.len() {
        let arg = &args[idx];
        if local_mode && arg == "-" {
            local_dash = true;
            idx += 1;
            continue;
        }
        if arg == "--" {
            idx += 1;
            break;
        }
        if arg.starts_with('-') || arg.starts_with('+') {
            let is_unset = arg.starts_with('+');
            if is_unset { plus_seen = true; }
            for ch in arg[1..].chars() {
                match ch {
                    'a' => {
                        if is_unset { unset_array_attr = true; }
                        else { is_array = true; }
                    }
                    'A' => {
                        if is_unset { unset_assoc_attr = true; }
                        else { is_assoc = true; }
                    }
                    'i' => {
                        if is_unset { unset_integer = true; }
                        else { is_integer = true; }
                    }
                    'r' => {
                        if is_unset { unset_readonly = true; }
                        else { is_readonly = true; }
                    }
                    'x' => {
                        if is_unset { unset_export = true; }
                        else { is_export = true; }
                    }
                    'l' => {
                        if is_unset { unset_lowercase = true; }
                        else { is_lowercase = true; }
                    }
                    'u' => {
                        if is_unset { unset_uppercase = true; }
                        else { is_uppercase = true; }
                    }
                    'c' => {
                        if is_unset { unset_capitalize = true; }
                        else { is_capitalize = true; }
                    }
                    'p' => print_mode = true,
                    'f' => func_mode = true,
                    'F' => func_names_mode = true,
                    'g' => global = true,
                    'n' => nameref = !is_unset,
                    't' => is_trace = !is_unset,
                    'I' => {
                        if !is_unset {
                            local_inherit = true;
                        }
                    }
                    c => {
                        let which = if local_mode { "local" } else { "declare" };
                        eprintln!("{}: {}: -{}: invalid option",
                            shell.err_prefix_with_line(), which, c);
                        eprintln!("{}: usage: {} [-aAfFgiIlnrtux] [name[=value] ...] or {} -p [-aAfFilnrtux] [name ...]",
                            which, which, which);
                        return 2;
                    }
                }
                if is_unset { unset_flags = true; }
            }
            idx += 1;
        } else {
            break;
        }
    }
    let _ = unset_flags;
    let _ = global;
    let _ = nameref;

    if local_mode && local_dash {
        if let Some(slot) = shell.local_option_snapshots.last_mut() {
            if slot.is_none() {
                *slot = Some((shell.opts.clone(), shell.posix_mode));
            }
        }
        if args[idx..].is_empty() && !print_mode {
            return 0;
        }
    }

    // Print mode
    if print_mode {
        if func_mode || func_names_mode {
            let requested_names: Vec<String> = if args[idx..].is_empty() {
                let mut names: Vec<String> = shell.functions.keys().cloned().collect();
                names.sort();
                names
            } else {
                args[idx..].iter().cloned().collect()
            };
            let mut status = 0;
            for name in requested_names {
                if is_export {
                    let env_key = format!("BASH_FUNC_{}%%", name);
                    if !shell.vars.is_exported(&env_key) { continue; }
                }
                let ro = shell.readonly_functions.contains(&name);
                let f_flag = if ro { "-fr" } else { "-f" };
                if func_names_mode {
                    if shell.functions.contains_key(&name) {
                        println!("declare {} {}", f_flag, name);
                    } else {
                        eprintln!("{}: {}: {}: not found",
                            shell.err_prefix_with_line(), cmd_name, name);
                        status = 1;
                    }
                } else if let Some(func) = shell.functions.get(&name) {
                    print!("{}", format_function_def(func));
                } else {
                    eprintln!("{}: {}: {}: not found",
                        shell.err_prefix_with_line(), cmd_name, name);
                    status = 1;
                }
            }
            return status;
        }
        if args[idx..].is_empty() {
            if local_mode
                && shell.local_option_snapshots.last().and_then(|s| s.as_ref()).is_some()
            {
                println!("local -");
            }
            // Print all variable declarations (respecting any active
            // type-filter flag: `declare -pa` lists only indexed
            // arrays, `-pA` only assoc, `-pi` only integer-typed, ...).
            let any_filter = is_array || is_assoc || is_integer || is_readonly
                || is_export || is_lowercase || is_uppercase || is_capitalize
                || is_trace || nameref;
            let vars = if local_mode {
                shell.vars.list_local_vars()
            } else {
                shell.vars.list_vars()
            };
            for (name, _value) in vars {
                let has_x = shell.vars.is_exported(&name);
                let has_r = shell.vars.is_readonly(&name);
                let has_a = shell.vars.is_array(&name) && !shell.vars.is_assoc(&name);
                let has_assoc = shell.vars.is_assoc(&name);
                let has_i = shell.vars.get_entry_is_integer(&name);
                if any_filter {
                    if is_export && !has_x { continue; }
                    if is_readonly && !has_r { continue; }
                    if is_array && !has_a { continue; }
                    if is_assoc && !has_assoc { continue; }
                    if is_integer && !has_i { continue; }
                    if nameref && !shell.vars.is_nameref(&name) { continue; }
                    if is_lowercase || is_uppercase || is_capitalize || is_trace {
                        continue;
                    }
                }
                if shell.vars.is_nameref(&name) {
                    let target = shell.vars.get_nameref_target(&name).unwrap_or_default();
                    let mut f = String::from("n");
                    if has_r { f.push('r'); }
                    if has_x { f.push('x'); }
                    println!("declare -{} {}={}", f, name, quote_for_declare(&target));
                    continue;
                }
                if has_assoc {
                    let entries = shell.vars.get_assoc_entries(&name);
                    let mut parts = Vec::new();
                    for (k, v) in &entries {
                        parts.push(format!("[{}]={}", quote_key_for_declare(k), quote_for_declare(v)));
                    }
                    let mut f = String::from("A");
                    if has_i { f.push('i'); }
                    if has_x { f.push('x'); }
                    if has_r { f.push('r'); }
                    if parts.is_empty() {
                        println!("declare -{} {}=()", f, name);
                    } else {
                        println!("declare -{} {}=({} )", f, name, parts.join(" "));
                    }
                } else if has_a {
                    if let Some(elements) = shell.vars.get_array_sparse(&name) {
                        let mut parts = Vec::new();
                        for (i, val) in &elements {
                            parts.push(format!("[{}]={}", i, quote_for_declare(val)));
                        }
                        let mut f = String::from("a");
                        if has_i { f.push('i'); }
                        if has_x { f.push('x'); }
                        if has_r { f.push('r'); }
                        if elements.is_empty() && !shell.vars.get_entry_is_initialized(&name) {
                            println!("declare -{} {}", f, name);
                        } else {
                            println!("declare -{} {}=({})", f, name, parts.join(" "));
                        }
                    }
                } else {
                    let value = shell.vars.get(&name).unwrap_or_default();
                    let mut f = String::new();
                    if has_x { f.push('x'); }
                    if has_r { f.push('r'); }
                    if has_i { f.push('i'); }
                    let flag_str = if f.is_empty() { "--".to_string() } else { format!("-{}", f) };
                    if shell.vars.get_entry_is_initialized(&name) {
                        println!("declare {} {}={}", flag_str, name, quote_for_declare(&value));
                    } else {
                        println!("declare {} {}", flag_str, name);
                    }
                }
            }
        } else {
            // Print specific named variables
            let mut status = 0;
            for arg in &args[idx..] {
                let name = arg.as_str();
                if local_mode && !shell.vars.is_local_pub(name) {
                    eprintln!("{}: {}: {}: not found",
                        shell.err_prefix_with_line(), cmd_name, name);
                    status = 1;
                    continue;
                }
                if shell.vars.has_entry_raw(name) && shell.vars.is_nameref(name) {
                    let mut f = String::new();
                    if shell.vars.get_entry_is_integer_raw(name) { f.push('i'); }
                    f.push('n');
                    if shell.vars.is_readonly_raw(name) { f.push('r'); }
                    if shell.vars.is_exported_raw(name) { f.push('x'); }
                    if shell.vars.is_lowercase_raw(name) { f.push('l'); }
                    if shell.vars.is_uppercase_raw(name) { f.push('u'); }
                    if shell.vars.is_capitalize_raw(name) { f.push('c'); }
                    if shell.vars.get_entry_is_initialized_raw(name) {
                        let value = shell.vars.get_nameref_target(name).unwrap_or_default();
                        println!("declare -{} {}={}", f, name, quote_for_declare(&value));
                    } else {
                        println!("declare -{} {}", f, name);
                    }
                } else if shell.vars.is_array(name) && !shell.vars.is_assoc(name) {
                    // Print indexed array with its real (sparse) indices.
                    if let Some(elements) = shell.vars.get_array_sparse(name) {
                        let mut parts = Vec::new();
                        for (i, val) in &elements {
                            parts.push(format!("[{}]={}", i, quote_for_declare(val)));
                        }
                        let mut f = String::new();
                        f.push('a');
                        if shell.vars.get_entry_is_integer(name) { f.push('i'); }
                        if shell.vars.is_readonly(name) { f.push('r'); }
                        if shell.vars.is_exported(name) { f.push('x'); }
                        if shell.vars.is_lowercase_raw(name) { f.push('l'); }
                        if shell.vars.is_uppercase_raw(name) { f.push('u'); }
                        if shell.vars.is_capitalize_raw(name) { f.push('c'); }
                        // `declare -a NAME` with no value (never
                        // assigned): print without the `=()` suffix
                        // to match bash.  The agent's sparse form
                        // uses `elements.is_empty()` whereas the
                        // non-sparse path used `parts.is_empty()` —
                        // both are equivalent here.
                        if elements.is_empty() && !shell.vars.get_entry_is_initialized(name) {
                            println!("declare -{} {}", f, name);
                        } else {
                            println!("declare -{} {}=({})", f, name, parts.join(" "));
                        }
                    }
                } else if shell.vars.is_assoc(name) {
                    // Print assoc array with actual contents
                    let entries = shell.vars.get_assoc_entries(name);
                    let mut parts = Vec::new();
                    for (k, v) in &entries {
                        parts.push(format!("[{}]={}", quote_key_for_declare(k), quote_for_declare(v)));
                    }
                    let mut f = String::from("A");
                    if shell.vars.get_entry_is_integer(name) { f.push('i'); }
                    if shell.vars.is_readonly(name) { f.push('r'); }
                    if shell.vars.is_exported(name) { f.push('x'); }
                    if shell.vars.is_lowercase_raw(name) { f.push('l'); }
                    if shell.vars.is_uppercase_raw(name) { f.push('u'); }
                    if shell.vars.is_capitalize_raw(name) { f.push('c'); }
                    if parts.is_empty() {
                        // Bash prints `declare -A name` (no `=()`) when
                        // the assoc was declared but never assigned.
                        if shell.vars.get_entry_is_initialized_raw(name) {
                            println!("declare -{} {}=()", f, name);
                        } else {
                            println!("declare -{} {}", f, name);
                        }
                    } else {
                        println!("declare -{} {}=({} )", f, name, parts.join(" "));
                    }
                } else if shell.vars.has_entry_raw(name) {
                    // Print the attributes of the LITERAL variable,
                    // not of its nameref target.  `declare -p fee`
                    // where fee is `declare -n fee=three` should
                    // show `declare -n fee="three"`, not the `three`
                    // scalar's attributes.
                    let is_nameref = shell.vars.is_nameref(name);
                    let flags = {
                        let mut f = String::new();
                        if shell.vars.get_entry_is_integer_raw(name) { f.push('i'); }
                        if shell.vars.is_readonly_raw(name) { f.push('r'); }
                        if shell.vars.is_exported_raw(name) { f.push('x'); }
                        if shell.vars.is_lowercase_raw(name) { f.push('l'); }
                        if shell.vars.is_uppercase_raw(name) { f.push('u'); }
                        if shell.vars.is_capitalize_raw(name) { f.push('c'); }
                        if is_nameref { f.push('n'); }
                        f
                    };
                    let flag_str = if flags.is_empty() { "--".to_string() } else { format!("-{}", flags) };
                    // For a nameref, emit the TARGET NAME as the value
                    // (that's what bash does): `declare -n ref="target"`.
                    // For regular vars, emit the resolved value.
                    if shell.vars.get_entry_is_initialized_raw(name) {
                        let value = if is_nameref {
                            shell.vars.get_nameref_target(name).unwrap_or_default()
                        } else {
                            shell.vars.get(name).unwrap_or_default()
                        };
                        println!("declare {} {}={}", flag_str, name, quote_for_declare(&value));
                    } else {
                        println!("declare {} {}", flag_str, name);
                    }
                } else {
                    eprintln!("{}: {}: {}: not found",
                        shell.err_prefix_with_line(), cmd_name, name);
                    status = 1;
                }
            }
            return status;
        }
        return 0;
    }

    // No variable names — list all
    if args[idx..].is_empty() {
        if func_mode || func_names_mode {
            // -f or -F with no names: list functions.  -r filters to
            // readonly; -x filters to exported (BASH_FUNC_NAME%% env
            // var).  Readonly functions print as `declare -fr NAME`.
            let mut names: Vec<String> = shell.functions.keys().cloned().collect();
            names.sort();
            for name in names {
                if is_export {
                    let env_key = format!("BASH_FUNC_{}%%", name);
                    if !shell.vars.is_exported(&env_key) { continue; }
                }
                let ro = shell.readonly_functions.contains(&name);
                if is_readonly && !ro { continue; }
                let f_flag = if ro { "-fr" } else { "-f" };
                if func_names_mode {
                    println!("declare {} {}", f_flag, name);
                } else {
                    if let Some(func) = shell.functions.get(&name) {
                        print!("{}", format_function_def(func));
                        if ro {
                            println!("declare -fr {}", name);
                        }
                    }
                }
            }
            return 0;
        }
        // Any type-filter flag restricts the listing to variables with that attribute.
        let any_filter = is_array || is_assoc || is_integer || is_readonly
            || is_export || is_lowercase || is_uppercase || is_capitalize
            || is_trace || nameref;
        // `local` with no names: require a function context, list ONLY
        // vars in the current scope (not inherited globals).
        if local_mode {
            if !shell.vars.in_function_scope() {
                eprintln!("{}: local: can only be used in a function",
                    shell.err_prefix_with_line());
                return 1;
            }
        }
        let vars = if local_mode {
            shell.vars.list_local_vars()
        } else {
            shell.vars.list_vars()
        };
        for (name, value) in vars {
            let has_x = shell.vars.is_exported(&name);
            let has_r = shell.vars.is_readonly(&name);
            let has_a = shell.vars.is_array(&name) && !shell.vars.is_assoc(&name);
            let has_assoc = shell.vars.is_assoc(&name);
            let has_i = shell.vars.get_entry_is_integer(&name);
            if any_filter {
                if is_export && !has_x { continue; }
                if is_readonly && !has_r { continue; }
                if is_array && !has_a { continue; }
                if is_assoc && !has_assoc { continue; }
                if is_integer && !has_i { continue; }
                if nameref && !shell.vars.is_nameref(&name) { continue; }
                // Attributes we don't track yet (l/u/c/t): show nothing.
                if is_lowercase || is_uppercase || is_capitalize || is_trace {
                    continue;
                }
            }
            // For plain `declare` (no -p, no type-filter flags, in the
            // default non-local branch), bash uses bare `name=value`
            // format — no `declare --` prefix.  `declare -p`, `local`,
            // and filter-restricted listings keep the full form.
            let use_bare_format = !local_mode && !any_filter;
            // Nameref printing takes precedence — we want
            // `declare -n fee="target"` not the target's expansion.
            if shell.vars.is_nameref(&name) {
                let target = shell.vars.get_nameref_target(&name).unwrap_or_default();
                let mut f = String::from("n");
                if has_r { f.push('r'); }
                if has_x { f.push('x'); }
                println!("declare -{} {}={}", f, name, quote_for_declare(&target));
                continue;
            }
            // Build flag string. For assoc/array, emit the appropriate contents.
            if has_assoc {
                let entries = shell.vars.get_assoc_entries(&name);
                let mut parts = Vec::new();
                for (k, v) in &entries {
                    parts.push(format!("[{}]={}", quote_key_for_declare(k), quote_for_declare(v)));
                }
                if use_bare_format {
                    if parts.is_empty() {
                        println!("{}=()", name);
                    } else {
                        println!("{}=({} )", name, parts.join(" "));
                    }
                } else {
                    let mut f = String::from("A");
                    if has_i { f.push('i'); }
                    if has_x { f.push('x'); }
                    if has_r { f.push('r'); }
                    if parts.is_empty() {
                        if shell.vars.get_entry_is_initialized_raw(&name) {
                            println!("declare -{} {}=()", f, name);
                        } else {
                            println!("declare -{} {}", f, name);
                        }
                    } else {
                        println!("declare -{} {}=({} )", f, name, parts.join(" "));
                    }
                }
            } else if has_a {
                if let Some(elements) = shell.vars.get_array_sparse(&name) {
                    let mut parts = Vec::new();
                    for (i, val) in &elements {
                        parts.push(format!("[{}]={}", i, quote_for_declare(val)));
                    }
                    if use_bare_format {
                        // `declare -a NAME` (no value ever assigned):
                        // bash prints nothing for this in plain format.
                        if elements.is_empty() && !shell.vars.get_entry_is_initialized(&name) {
                            // skip (matches bash behaviour of omitting
                            // uninitialised array declarations)
                        } else {
                            println!("{}=({})", name, parts.join(" "));
                        }
                    } else {
                        let mut f = String::from("a");
                        if has_i { f.push('i'); }
                        if has_x { f.push('x'); }
                        if has_r { f.push('r'); }
                        if elements.is_empty() && !shell.vars.get_entry_is_initialized(&name) {
                            println!("declare -{} {}", f, name);
                        } else {
                            println!("declare -{} {}=({})", f, name, parts.join(" "));
                        }
                    }
                }
            } else {
                if use_bare_format {
                    // Bash's `declare` bare format: NAME=value (no
                    // `declare --` prefix, no flag indicators).  Only
                    // quote the value if it contains chars that would
                    // misparse as assignment.  Plain alphanumeric-ish
                    // values print bare.
                    println!("{}={}", name, quote_for_declare_bare(&value));
                } else {
                    let mut f = String::new();
                    if has_x { f.push('x'); }
                    if has_r { f.push('r'); }
                    if has_i { f.push('i'); }
                    let flag_str = if f.is_empty() { "--".to_string() } else { format!("-{}", f) };
                    println!("declare {} {}={}", flag_str, name, quote_for_declare(&value));
                }
            }
        }
        return 0;
    }

    // `declare -f NAME [NAME ...]`: print the body of the named functions.
    // `declare -F NAME [NAME ...]`: print `declare -f NAME` (names only).
    // Bash returns 0 only if all names are defined functions; otherwise 1.
    // Only print when `-f` / `-F` is the sole mutation intent — combined
    // flags like `-ft` (set trace attribute) or `-fx` (export function)
    // modify the function and must fall through to the assignment path.
    let any_mutation_flag = is_trace || is_export || is_readonly
        || is_integer || is_lowercase || is_uppercase || is_capitalize
        || is_array || is_assoc || nameref
        || unset_readonly || unset_integer || unset_export
        || unset_lowercase || unset_uppercase || unset_capitalize;
    let any_value = args[idx..].iter().any(|a| a.contains('='));

    // `declare -f NAME=value` is an error — bash doesn't let `-f`
    // combine with assignment.
    if func_mode && any_value {
        eprintln!("{}: declare: cannot use `-f' to make functions",
            shell.err_prefix_with_line());
        return 1;
    }

    if (func_mode || func_names_mode) && !any_mutation_flag && !any_value {
        let mut status = 0;
        for arg in &args[idx..] {
            if let Some(func) = shell.functions.get(arg) {
                if func_names_mode {
                    // `declare -F NAME`: print just the name (bash behaviour).
                    println!("{}", arg);
                } else {
                    print!("{}", format_function_def(func));
                }
            } else {
                if print_mode {
                eprintln!("{}: {}: {}: not found",
                    shell.err_prefix_with_line(), cmd_name, arg);
                }
                status = 1;
            }
        }
        return status;
    }

    // `declare -fr NAME...` marks the named functions as readonly.
    // Bash: any subsequent attempt to redefine or unset emits
    // "readonly function".  The `declare -p NAME` listing uses
    // `declare -fr` instead of `declare -f` for these.
    if func_mode && is_readonly && !any_value {
        let mut status = 0;
        for arg in &args[idx..] {
            if shell.functions.contains_key(arg) {
                shell.readonly_functions.insert(arg.clone());
            } else {
                eprintln!("{}: {}: {}: not a function",
                    shell.err_prefix_with_line(), cmd_name, arg);
                status = 1;
            }
        }
        return status;
    }

    // `declare -f +r NAME...` attempts to REMOVE the readonly
    // attribute from a function.  Bash: this is always an error —
    // `declare: NAME: readonly function`.
    if func_mode && unset_readonly && !any_value {
        let mut status = 0;
        for arg in &args[idx..] {
            if shell.readonly_functions.contains(arg) {
                eprintln!("{}: {}: {}: readonly function",
                    shell.err_prefix_with_line(), cmd_name, arg);
                status = 1;
            } else if !shell.functions.contains_key(arg) {
                eprintln!("{}: {}: {}: not a function",
                    shell.err_prefix_with_line(), cmd_name, arg);
                status = 1;
            }
            // Non-readonly function with +r: no-op silently.
        }
        return status;
    }

    // `declare -f -a` / `declare -f -i` — can't combine -f with
    // type-filter flags.  Bash: `declare: -a: invalid option`
    // (no usage block — just the one-line diagnostic).
    if func_mode && (is_array || is_assoc || is_integer
        || is_lowercase || is_uppercase || is_capitalize) {
        let offender = if is_array { "-a" }
            else if is_assoc { "-A" }
            else if is_integer { "-i" }
            else if is_lowercase { "-l" }
            else if is_uppercase { "-u" }
            else { "-c" };
        eprintln!("{}: {}: {}: invalid option",
            shell.err_prefix_with_line(), cmd_name, offender);
        return 2;
    }

    let mut status = 0;
    for arg in &args[idx..] {
        // Detect name+=value (append) vs name=value (assign)
        let (name_raw, value, is_append): (&str, Option<&str>, bool) =
            if let Some(eq) = arg.find('=') {
                if eq > 0 && arg.as_bytes()[eq - 1] == b'+' {
                    (&arg[..eq - 1], Some(&arg[eq + 1..]), true)
                } else {
                    (&arg[..eq], Some(&arg[eq + 1..]), false)
                }
            } else {
                (arg.as_str(), None, false)
            };

        // Bash quirk: `declare -a NAME[SUB]` (no value) silently
        // strips the subscript — the declaration applies to the
        // whole variable, never to a single element.  Only strip
        // when there's no value, since `NAME[SUB]=val` is a
        // subscripted assignment.
        let mut stripped_subscript = false;
        let name: &str = if value.is_none()
            && name_raw.ends_with(']')
            && name_raw.contains('[')
        {
            stripped_subscript = true;
            &name_raw[..name_raw.find('[').unwrap()]
        } else {
            name_raw
        };
        // A subscript on the bare name implies the `-a` attribute
        // (`declare NAME[N]` == `declare -a NAME`).  Bash behaves
        // this way so `declare -r c[100]` yields `declare -ar c`.
        let is_array = is_array || (stripped_subscript && !is_assoc);

        // Subscripted assignment: `declare NAME[SUB]=VALUE` is a
        // write to an individual element.  Split off the base name
        // and validate it; route the assignment through the normal
        // array-element setter.  Bash accepts arbitrary arithmetic
        // in the brackets (including spaces), so validation uses
        // only the leading identifier.
        let assoc_expand_once = shell.shopt.contains("assoc_expand_once");
        let parse_subscripted = |token: &str| {
            if assoc_expand_once {
                crate::exec::parse_subscripted_name_assoc_once_pub(token)
            } else {
                crate::exec::parse_subscripted_name_strict_pub(token)
            }
        };
        let mut subscripted_assignment: Option<(String, String)> = None;
        let subscripted_base: Option<String> = if !stripped_subscript && value.is_some() {
            if let Some((base, sub)) = parse_subscripted(name_raw) {
                subscripted_assignment = Some((base.clone(), sub));
                Some(base)
            } else {
                None
            }
        } else {
            None
        };
        if !stripped_subscript
            && value.is_some()
            && name_raw.contains('[')
            && name_raw.ends_with(']')
            && subscripted_assignment.is_none()
        {
            eprintln!("{}: {}: `{}': not a valid identifier",
                shell.err_prefix_with_line(), cmd_name, arg);
            status = 1;
            continue;
        }
        // Nameref on a subscripted name is an error: `typeset -n x[3]=y`
        // → "x[3]: reference variable cannot be an array".  Bash emits
        // this with the subscripted token verbatim.
        if nameref && subscripted_assignment.is_some() {
            eprintln!("{}: {}: {}: reference variable cannot be an array",
                shell.err_prefix_with_line(), cmd_name, name_raw);
            status = 1;
            continue;
        }
        if nameref && stripped_subscript {
            eprintln!("{}: {}: {}: reference variable cannot be an array",
                shell.err_prefix_with_line(), cmd_name, name_raw);
            status = 1;
            continue;
        }
        if let Some((base, sub)) = subscripted_assignment.as_ref() {
            if base.is_empty() {
                eprintln!("{}: {}: `{}': not a valid identifier",
                    shell.err_prefix_with_line(), cmd_name, arg);
                status = 1;
                continue;
            }
            let is_assoc_target = is_assoc || shell.vars.is_assoc(base);
            if is_assoc_target && name_raw.contains('$') {
                let expanded_target = shell.expand_word_nosplit_no_cmdsub_pub(name_raw);
                if crate::exec::parse_subscripted_name_strict_pub(&expanded_target).is_none() {
                    eprintln!("{}: {}: `{}': not a valid identifier",
                        shell.err_prefix_with_line(), cmd_name, format!("{}={}", expanded_target, value.unwrap_or("")));
                    status = 1;
                    continue;
                }
            }
            if !is_assoc_target && sub.is_empty() {
                eprintln!("{}: {}[]: bad array subscript",
                    shell.err_prefix_with_line(), base);
                status = 1;
                continue;
            }
        }
        let name: &str = if let Some(ref b) = subscripted_base { b.as_str() } else { name };

        // Handle subscripted assignment `declare NAME[sub]=value`
        // when NAME is (or is being declared as) an indexed or
        // associative array.  In bash, this assigns the element
        // without touching the variable's other contents.
        let mut subscripted_assign: Option<(String, String)> = None;
        if value.is_some() {
            if let Some((base, key)) = parse_subscripted(name) {
                let is_existing_assoc = shell.vars.is_assoc(&base);
                let is_existing_array = shell.vars.is_array(&base) && !is_existing_assoc;
                if is_valid_identifier(&base)
                    && (is_assoc || is_array || is_existing_assoc || is_existing_array)
                {
                    subscripted_assign = Some((base, key));
                }
            }
        }

        let name: &str = if let Some((ref base, _)) = subscripted_assign {
            // Shadow `name` with the base identifier for the rest of
            // the processing.  The subscripted path stores via
            // set_assoc / push_array below.
            let _ = base; // use below
            &name[..name.find('[').unwrap()]
        } else {
            name
        };

        let effective_local = local_mode || (!global && shell.vars.in_function_scope());
        let literal_name = name.to_string();
        let unset_nameref_attr = unset_flags
            && args[0..idx].iter().any(|a| a.starts_with('+') && a.contains('n'));
        let unset_nameref_follows_target = unset_nameref_attr
            && (value.is_some()
                || is_append
                || is_array
                || is_assoc
                || is_integer
                || unset_integer
                || is_export
                || unset_export
                || is_lowercase
                || unset_lowercase
                || is_uppercase
                || unset_uppercase
                || is_capitalize
                || unset_capitalize
                || is_readonly);
        let should_follow_global = global && shell.vars.in_function_scope();
        let literal_is_nameref = if should_follow_global {
            shell.vars.is_nameref_global(&literal_name)
        } else {
            shell.vars.is_nameref(&literal_name)
        };
        let followed_name = if literal_is_nameref
            && !nameref
            && (!unset_nameref_attr || unset_nameref_follows_target)
            && (should_follow_global || !effective_local || shell.vars.is_local_pub(&literal_name))
        {
            let resolved = if should_follow_global {
                shell.vars.resolve_nameref_global(&literal_name)
            } else {
                shell.vars.resolve_nameref(&literal_name)
            };
            resolved.filter(|t| !t.contains('['))
        } else {
            None
        };
        let name: &str = followed_name.as_deref().unwrap_or(name);
        let raw_attr_mode = nameref || (unset_nameref_attr && !unset_nameref_follows_target);
        let raw_attr_name = literal_name.as_str();
        if should_follow_global {
            if !global_preferred_names.iter().any(|n| n == &literal_name) {
                shell.vars.prefer_global_name(&literal_name);
                global_preferred_names.push(literal_name.clone());
            }
            if name != literal_name && !global_preferred_names.iter().any(|n| n == name) {
                shell.vars.prefer_global_name(name);
                global_preferred_names.push(name.to_string());
            }
        }

        if !is_valid_identifier(name) {
            let bad = if value.is_some() { arg.as_str() } else { name };
            eprintln!("{}: {}: `{}': not a valid identifier",
                shell.err_prefix_with_line(), cmd_name, bad);
            status = 1;
            continue;
        }

        // `declare +a NAME` / `declare +A NAME` on an existing array/
        // assoc is an error: bash won't let you strip the array
        // attribute that way.  Bash checks readonly FIRST — if the
        // variable is readonly, it emits "readonly variable" rather
        // than the array-destroy error.
        if unset_array_attr && shell.vars.is_array(name) && !shell.vars.is_assoc(name) {
            let which = if local_mode { "local" } else { "declare" };
            if shell.vars.is_readonly(name) {
                eprintln!("{}: {}: {}: readonly variable",
                    shell.err_prefix_with_line(), which, name);
            } else {
                eprintln!("{}: {}: {}: cannot destroy array variables in this way",
                    shell.err_prefix_with_line(), which, name);
            }
            status = 1;
            continue;
        }
        if unset_assoc_attr && shell.vars.is_assoc(name) {
            let which = if local_mode { "local" } else { "declare" };
            if shell.vars.is_readonly(name) {
                eprintln!("{}: {}: {}: readonly variable",
                    shell.err_prefix_with_line(), which, name);
            } else {
                eprintln!("{}: {}: {}: cannot destroy array variables in this way",
                    shell.err_prefix_with_line(), which, name);
            }
            status = 1;
            continue;
        }

        // `declare -A NAME` on an existing indexed array, or `declare
        // -a NAME` on an existing assoc array, is an error:
        //   "cannot convert indexed to associative array"
        //   "cannot convert associative to indexed array"
        if is_assoc && shell.vars.is_array(name) && !shell.vars.is_assoc(name) {
            let prefix = shell.err_prefix_with_line();
            let which = if local_mode { "local" } else { "declare" };
            if value.is_some() {
                if shell.vars.in_function_scope() && (global || effective_local) {
                    let func = shell.funcname_stack.last().cloned().unwrap_or_default();
                    eprintln!("{}: {}: {}: cannot convert indexed to associative array",
                        prefix, func, name);
                    eprintln!("{}: {}: {}: cannot convert indexed to associative array",
                        prefix, which, name);
                } else {
                    eprintln!("{}: {}: cannot convert indexed to associative array",
                        prefix, name);
                }
            } else {
                eprintln!("{}: {}: {}: cannot convert indexed to associative array",
                    prefix, which, name);
            }
            status = 1;
            continue;
        }
        if is_array && shell.vars.is_assoc(name) {
            let prefix = shell.err_prefix_with_line();
            let which = if local_mode { "local" } else { "declare" };
            if value.is_some() {
                if shell.vars.in_function_scope() && (global || effective_local) {
                    let func = shell.funcname_stack.last().cloned().unwrap_or_default();
                    eprintln!("{}: {}: {}: cannot convert associative to indexed array",
                        prefix, func, name);
                    eprintln!("{}: {}: {}: cannot convert associative to indexed array",
                        prefix, which, name);
                } else {
                    eprintln!("{}: {}: cannot convert associative to indexed array",
                        prefix, name);
                }
            } else {
                eprintln!("{}: {}: {}: cannot convert associative to indexed array",
                    prefix, which, name);
            }
            status = 1;
            continue;
        }

        let readonly_check = if raw_attr_mode {
            shell.vars.is_readonly_raw(raw_attr_name)
        } else {
            shell.vars.is_readonly(name)
        };
        // `declare -r NAME=VALUE` when NAME is already readonly is an error.
        // `declare -r NAME` (no value) is a no-op — bash silently treats
        // re-marking an already-readonly variable as readonly as OK.
        if is_readonly && readonly_check && value.is_some() {
            let prefix = shell.err_prefix_with_line();
            eprintln!("{}: {}: {}: readonly variable", prefix, cmd_name, name);
            status = 1;
            continue;
        }

        // `declare +X NAME` (any attribute-unset) on a readonly
        // variable is a `readonly variable` error — bash refuses to
        // remove any attribute from a readonly name.
        let tries_unset_attr = unset_integer || unset_export || unset_lowercase
            || unset_uppercase || unset_capitalize || plus_seen;
        let unresolved_follow = !raw_attr_mode
            && shell.vars.is_nameref(raw_attr_name)
            && shell.vars.resolve_nameref(raw_attr_name).is_none();
        let empty_nameref_unset = unset_nameref_attr
            && shell.vars.is_nameref(raw_attr_name)
            && shell.vars.get_nameref_target(raw_attr_name).unwrap_or_default().is_empty();
        let readonly_unset_check = if raw_attr_mode {
            shell.vars.is_readonly_raw(raw_attr_name)
        } else {
            shell.vars.is_readonly(name)
        };
        if tries_unset_attr && readonly_unset_check && !unresolved_follow && !empty_nameref_unset {
            let prefix = shell.err_prefix_with_line();
            eprintln!("{}: {}: {}: readonly variable", prefix, cmd_name, name);
            status = 1;
            continue;
        }

        // In bash, typeset/declare inside a function creates a local
        // variable (same as `local`) unless -g is specified.
        let existing_assoc = shell.vars.is_assoc(name);
        let existing_array = shell.vars.is_array(name) && !existing_assoc;
        let target_assoc = is_assoc || existing_assoc;
        let target_array = is_array || existing_array;
        if (is_array || is_assoc)
            && shell.vars.is_nameref(raw_attr_name)
            && shell.vars.get_nameref_target(raw_attr_name).unwrap_or_default().is_empty()
        {
            // bash 5.3 emits a warning only when this conversion is
            // accompanied by an actual assignment (value or
            // subscripted assignment).  `declare -a foo` (no value) on
            // an empty nameref `foo` silently strips the attribute.
            // The warning format is just `<prefix>: warning: …` — no
            // builtin-name (`declare:`/`typeset:`) prefix.
            if value.is_some() || subscripted_assignment.is_some() {
                eprintln!("{}: warning: {}: removing nameref attribute",
                    shell.err_prefix_with_line(), raw_attr_name);
            }
            shell.vars.strip_nameref_value(raw_attr_name);
        }
        let value_int_flag = (is_integer || shell.vars.get_entry_is_integer_raw(name))
            && !unset_integer;
        let value_lower_flag = (is_lowercase || shell.vars.is_lowercase_raw(name))
            && !unset_lowercase;
        let value_upper_flag = (is_uppercase || shell.vars.is_uppercase_raw(name))
            && !unset_uppercase;
        let value_cap_flag = (is_capitalize || shell.vars.is_capitalize_raw(name))
            && !unset_capitalize;

        // Subscripted assignment: `declare NAME[SUB]=VAL` evaluates
        // SUB arithmetically and writes to that element, without
        // disturbing the rest of the array.  Any remaining attribute
        // flags (-a, -r, etc.) still apply to the whole variable.
        //
        // Exception: if VAL is itself a compound array literal
        // (starts with `(`), bash treats it as a whole-array
        // assignment and the subscript is silently ignored.  We
        // fall through to the normal value-handling path in that
        // case after rewriting the name to strip the subscript.
        if let Some((base, sub)) = subscripted_assignment.as_ref() {
            let v = value.unwrap();
            // The original literal_name includes the `[sub]` suffix
            // (e.g. "xref[1]"), so compare against `base` directly
            // rather than expecting equality.  When the bare name is
            // already a nameref, declaring with array/assoc/integer
            // flags + a subscripted assignment removes the nameref
            // attribute — bash 5.3 emits a warning before the
            // conversion.
            if shell.vars.is_nameref(base) {
                eprintln!("{}: warning: {}: removing nameref attribute",
                    shell.err_prefix_with_line(), base);
                shell.vars.strip_nameref_value(base);
            }
            let whole_array_compound = v.starts_with("\x00ARRAY\x00")
                || (v.starts_with('(')
                    && v.ends_with(')')
                    && (is_array || is_assoc));
            if whole_array_compound {
                // Treat as whole-array assignment to `base`; fall
                // through with name = base.
                // (The rest of the assignment code reads `name`, so
                // we've already set it above.)
                // No action here — drop into the value path.
            } else {
            if v.starts_with('(')
                && v.ends_with(')')
                && !shell.vars.is_array(base)
                && !shell.vars.is_assoc(base)
                && !is_array
                && !is_assoc
            {
                eprintln!("{}: warning: {}[{}]={}: quoted compound array assignment deprecated",
                    shell.err_prefix_with_line(), base, sub, v);
            }
            // Assoc array: key is the subscript verbatim (after expansion).
            if is_assoc || shell.vars.is_assoc(base) {
                let key = crate::expand::expand_assoc_subscript_key_pub(sub, &mut shell.vars);
                let stored = coerce_decl_value(
                    shell,
                    v,
                    is_integer || shell.vars.get_entry_is_integer_raw(base),
                    is_lowercase || shell.vars.is_lowercase_raw(base),
                    is_uppercase || shell.vars.is_uppercase_raw(base),
                    is_capitalize || shell.vars.is_capitalize_raw(base),
                );
                shell.vars.set_assoc(base, &key, &stored);
            } else {
                let sub_exp = crate::expand::expand_index_subscript_word_pub(sub, &mut shell.vars);
                match crate::arithmetic::eval_expr(&sub_exp, &shell.vars) {
                    Ok(idx) => {
                        let real = if idx < 0 {
                            match shell.vars.array_max_index(base) {
                                Some(m) => {
                                    let r = (m + 1) as i64 + idx;
                                    if r < 0 {
                                        eprintln!("{}: {}[{}]: bad array subscript",
                                            shell.err_prefix_with_line(), base, sub);
                                        status = 1;
                                        continue;
                                    }
                                    r as usize
                                }
                                None => {
                                    eprintln!("{}: {}[{}]: bad array subscript",
                                        shell.err_prefix_with_line(), base, sub);
                                    status = 1;
                                    continue;
                                }
                            }
                        } else {
                            idx as usize
                        };
                        let stored = coerce_decl_value(
                            shell,
                            v,
                            is_integer || shell.vars.get_entry_is_integer_raw(base),
                            is_lowercase || shell.vars.is_lowercase_raw(base),
                            is_uppercase || shell.vars.is_uppercase_raw(base),
                            is_capitalize || shell.vars.is_capitalize_raw(base),
                        );
                        if is_append {
                            let cur = shell.vars.get_array_element(base, real).unwrap_or_default();
                            shell.vars.set_array_element(base, real, &format!("{}{}", cur, stored));
                        } else {
                            shell.vars.set_array_element(base, real, &stored);
                        }
                    }
                    Err(err) => {
                        if is_array { shell.vars.declare_array(base); }
                        if is_assoc { shell.vars.declare_assoc(base); }
                        if is_integer { shell.vars.set_integer(base); }
                        if is_readonly { shell.vars.set_readonly(base); }
                        if is_export { shell.vars.export(base); }
                        eprintln!("{}: {}: {}",
                            shell.err_prefix_with_line(), sub_exp.trim_start(), err);
                        status = 1;
                        continue;
                    }
                }
            }
            if is_array { shell.vars.declare_array(base); }
            if is_assoc { shell.vars.declare_assoc(base); }
            if is_integer { shell.vars.set_integer(base); }
            if is_readonly { shell.vars.set_readonly(base); }
            if is_export { shell.vars.export(base); }
            continue;
            }  // end else (non-compound subscripted assignment)
        }

        if let Some(v) = value {
            let mut inherited_local = false;
            if effective_local && (local_inherit || shell.shopt.contains("localvar_inherit")) {
                match shell.vars.inherit_local_from_outer(name) {
                    crate::vars::LocalInheritResult::Readonly => {
                        eprintln!("{}: {}: {}: readonly variable",
                            shell.err_prefix_with_line(), cmd_name, name);
                        status = 1;
                        continue;
                    }
                    crate::vars::LocalInheritResult::Inherited => {
                        inherited_local = true;
                    }
                    crate::vars::LocalInheritResult::NotFound => {}
                }
            }
            // Quoted compound-array literal: `declare -a x='(...)' ` or
            // `declare -A x='(...)' ` — bash parses the *value* of the
            // quoted string as if it were an unquoted compound array
            // literal.  We re-lex the inside of the parentheses with a
            // simple word splitter (honouring quotes) so that `[k]=v`
            // pairs and bare elements are split apart like the parser
            // would have done.
            let quoted_compound: Option<String> = if !nameref
                && v.starts_with('(')
                && v.ends_with(')')
                && (target_array || target_assoc)
            {
                Some(v[1..v.len()-1].to_string())
            } else {
                None
            };
            let (compound_body, compound_is_quoted) = if let Some(body) = quoted_compound {
                (body, true)
            } else if v.starts_with("\x00ARRAY\x00") {
                (v["\x00ARRAY\x00".len()..].to_string(), false)
            } else {
                (String::new(), false)
            };
            let is_compound = compound_is_quoted || v.starts_with("\x00ARRAY\x00");
            if is_compound {
                // Readonly compound assignment: `local` emits both the
                // plain variable error and the builtin-prefixed one;
                // `declare`/`typeset` only emit the plain variable form.
                let readonly_conflict = if effective_local {
                    local_decl_hits_readonly(shell, name)
                } else {
                    shell.vars.is_readonly(name)
                };
                if readonly_conflict {
                    let prefix = shell.err_prefix_with_line();
                    eprintln!("{}: {}: readonly variable", prefix, name);
                    if effective_local {
                        eprintln!("{}: {}: {}: readonly variable",
                            prefix, cmd_name, name);
                    }
                    status = 1;
                    continue;
                }
                // Split the body into elements.  For the unquoted form
                // the parser already inserted \x1F separators; for the
                // quoted form we need to do the splitting ourselves,
                // respecting nested quotes.
                let elements: Vec<String> = if compound_is_quoted {
                    let mut out = Vec::new();
                    for w in split_compound_array_body(&compound_body) {
                        if target_assoc {
                            out.extend(shell.expand_reparsed_compound_assign_element_pub(&w));
                        } else {
                            out.extend(shell.expand_compound_assign_element_pub(&w));
                        }
                    }
                    out
                } else if compound_body.is_empty() {
                    Vec::new()
                } else {
                    compound_body.split('\x1F')
                        .map(|w| w.to_string())
                        .collect()
                };
                if target_assoc {
                    // Associative array: parse [key]=value pairs.  For a
                    // non-append full assignment (`declare -A NAME=(…)`),
                    // bash discards any prior scalar or array contents.
                    // Our declare_assoc preserves scalars as `[0]=prev`,
                    // so explicitly clear first for the compound path.
                    if !is_append {
                        if effective_local {
                            shell.vars.declare_local_assoc(name);
                        } else {
                            shell.vars.declare_assoc(name);
                        }
                        shell.vars.clear_assoc(name);
                    }
                    if elements.is_empty() {
                        if effective_local {
                            shell.vars.declare_local_assoc(name);
                        } else {
                            shell.vars.declare_assoc(name);
                        }
                        shell.vars.mark_initialized(name);
                    }
                    // Bash 5.2+ kv-pair syntax: if NO element begins with
                    // `[`, treat the element list as alternating
                    // key/value pairs (`foo=(k1 v1 k2 v2)`).
                    let any_bracket = elements.iter()
                        .any(|e| !is_compound_bare_elem(e) && e.starts_with('['));
                    if !any_bracket && !elements.is_empty() {
                        let mut i = 0;
                        while i < elements.len() {
                            let raw_key = strip_compound_bare_elem(&elements[i]);
                            let key = crate::expand::expand_tilde_assoc_assign(raw_key, &shell.vars);
                            if key.is_empty() {
                                let shown = if raw_key.is_empty() { "\"\"" } else { raw_key };
                                eprintln!("{}: {}: bad array subscript",
                                    shell.err_prefix_with_line(), shown);
                                status = 1;
                                i += 2;
                                continue;
                            }
                            let raw_val = if i + 1 < elements.len() {
                                strip_compound_bare_elem(&elements[i + 1])
                            } else {
                                ""
                            };
                            let val = crate::expand::expand_tilde_assoc_assign(raw_val, &shell.vars);
                            let val = coerce_decl_value(
                                shell, &val, value_int_flag, value_lower_flag, value_upper_flag, value_cap_flag);
                            shell.vars.set_assoc(name, &key, &val);
                            i += 2;
                        }
                    } else {
                    for elem in &elements {
                        if !is_compound_bare_elem(elem) {
                        if let Some((key2, val, elem_append)) = crate::exec::parse_bracket_assign_ext_pub(elem) {
                            // Tilde expansion in assoc keys & values (bash 5.2+).
                            let expanded_key = crate::expand::expand_tilde_assoc_assign(&key2, &shell.vars);
                            let expanded_val = crate::expand::expand_tilde_assoc_assign(&val, &shell.vars);
                            let expanded_val = coerce_decl_value(
                                shell, &expanded_val, value_int_flag, value_lower_flag, value_upper_flag, value_cap_flag);
                            if elem_append {
                                let existing = shell.vars.get_assoc(name, &expanded_key).unwrap_or_default();
                                shell.vars.set_assoc(name, &expanded_key, &(existing + &expanded_val));
                            } else {
                                shell.vars.set_assoc(name, &expanded_key, &expanded_val);
                            }
                        } else {
                            // Bare element (no [subscript]=) in an assoc
                            // compound assignment is an error in bash.
                            eprintln!("{}: {}: {}: must use subscript when assigning associative array",
                                shell.err_prefix_with_line(), name, strip_compound_bare_elem(elem));
                            status = 1;
                        }
                        } else {
                            eprintln!("{}: {}: {}: must use subscript when assigning associative array",
                                shell.err_prefix_with_line(), name, strip_compound_bare_elem(elem));
                            status = 1;
                        }
                    }
                    }
                } else {
                    // Indexed array
                    let has_bracket = elements.iter()
                        .any(|e| !is_compound_bare_elem(e) && e.starts_with('['));
                    if has_bracket {
                        if !is_append {
                            if effective_local { shell.vars.set_local_array(name, Vec::new()); }
                            else { shell.vars.set_array(name, Vec::new()); }
                        }
                        // Track the next index to use for bare items
                        // (those without `[k]=`): bash uses the
                        // highest-assigned-index + 1, continuing
                        // through the mixed list.
                        let mut next_idx: usize = shell.vars.array_max_index(name)
                            .map(|m| m + 1).unwrap_or(0);
                        let mut aborted = false;
                        for elem in &elements {
                            if aborted {
                                break;
                            }
                            if is_compound_bare_elem(elem) {
                                let fv = coerce_decl_value(
                                    shell,
                                    strip_compound_bare_elem(elem),
                                    value_int_flag,
                                    value_lower_flag,
                                    value_upper_flag,
                                    value_cap_flag,
                                );
                                shell.vars.set_array_element_raw(name, next_idx, &fv);
                                next_idx += 1;
                            } else if let Some((idx_str, val)) = crate::exec::parse_bracket_assign_pub(elem) {
                                // Evaluate the subscript arithmetically
                                // so `[4+5/2]` works.
                                let idx_expanded = crate::exec::resolve_cmdsubs_for_expand(
                                    &crate::expand::expand_arith_vars(&idx_str, &mut shell.vars),
                                    &mut shell.vars,
                                );
                                let idx_num = match crate::arithmetic::eval_expr(&idx_expanded, &shell.vars) {
                                    Ok(n) => n,
                                    Err(err) => {
                                        let display_err = if err.contains("arithmetic syntax error: operand expected")
                                            && idx_expanded.contains(char::is_whitespace)
                                        {
                                            let tok = idx_expanded.split_whitespace().last().unwrap_or(idx_expanded.trim());
                                            format!("arithmetic syntax error in expression (error token is \"{}\")", tok)
                                        } else {
                                            err
                                        };
                                        eprintln!("{}: {}: {}",
                                            shell.err_prefix_with_line(), idx_expanded.trim_start(), display_err);
                                        status = 1;
                                        aborted = true;
                                        continue;
                                    }
                                };
                                let idx = if idx_num < 0 { 0 } else { idx_num as usize };
                                let fv = coerce_decl_value(
                                    shell, &val, value_int_flag, value_lower_flag, value_upper_flag, value_cap_flag);
                                shell.vars.set_array_element_raw(name, idx, &fv);
                                next_idx = idx + 1;
                            } else {
                                let fv = coerce_decl_value(
                                    shell, elem, value_int_flag, value_lower_flag, value_upper_flag, value_cap_flag);
                                shell.vars.set_array_element_raw(name, next_idx, &fv);
                                next_idx += 1;
                            }
                        }
                    } else if is_append {
                        for elem in &elements {
                            let fv = coerce_decl_value(
                                shell,
                                strip_compound_bare_elem(elem),
                                value_int_flag,
                                value_lower_flag,
                                value_upper_flag,
                                value_cap_flag,
                            );
                            shell.vars.push_array(name, &fv);
                        }
                    } else {
                        let coerced: Vec<String> = elements.iter().map(|e| {
                            coerce_decl_value(
                                shell,
                                strip_compound_bare_elem(e),
                                value_int_flag,
                                value_lower_flag,
                                value_upper_flag,
                                value_cap_flag,
                            )
                        }).collect();
                        if effective_local { shell.vars.set_local_array(name, coerced); }
                        else { shell.vars.set_array(name, coerced); }
                    }
                }
            } else if is_append {
                if nameref {
                    let current = shell.vars.get_nameref_target(name)
                        .or_else(|| shell.vars.get_raw_scalar(name))
                        .unwrap_or_default();
                    let new_target = format!("{}{}", current, v);
                    if !crate::vars::Variables::is_valid_nameref_target(&new_target) {
                        eprintln!("{}: {}: `{}': invalid variable name for name reference",
                            shell.err_prefix_with_line(), cmd_name, new_target);
                        status = 1;
                        continue;
                    }
                    let ok = if effective_local {
                        shell.vars.set_local_nameref_target(name, &new_target)
                    } else {
                        shell.vars.set_nameref_target(name, &new_target)
                    };
                    if !ok {
                        status = 1;
                    }
                    continue;
                }
                // name+=value: string/integer append
                // If -i is set, ensure integer arithmetic is used
                if is_integer {
                    shell.vars.set_integer(name);
                }
                if !shell.append_var(name, v) {
                    status = 1;
                    continue;
                }
            } else if nameref && is_integer
                && crate::exec::parse_subscripted_name_pub(v).is_some()
            {
                status = 1;
                continue;
            } else if nameref {
                let local_self_target = effective_local
                    && (v == name
                        || crate::exec::parse_subscripted_name_pub(v)
                            .map(|(base, _)| base == name)
                            .unwrap_or(false));
                if shell.vars.has_entry_raw(name) && shell.vars.is_readonly_raw(name) {
                    eprintln!("{}: {}: {}: readonly variable",
                        shell.err_prefix_with_line(), cmd_name, name);
                    status = 1;
                    continue;
                }
                if !crate::vars::Variables::is_valid_assigned_nameref_target(v) {
                    // bash distinguishes between an EMPTY target (not a
                    // valid identifier at all) and a non-empty target
                    // that just isn't a legal nameref target — only the
                    // latter mentions "name reference".
                    let msg = if v.is_empty() {
                        "not a valid identifier"
                    } else {
                        "invalid variable name for name reference"
                    };
                    eprintln!("{}: {}: `{}': {}",
                        shell.err_prefix_with_line(), cmd_name, v, msg);
                    status = 1;
                    continue;
                }
                // `declare -n name=target`: the target string must be
                // assigned to `name` directly, NOT through the
                // nameref chain.  set_var would otherwise follow an
                // existing nameref flag on `name` and write to the
                // old target.  `set_nameref_target` bypasses that.
                //
                // Check self-reference up front so the error carries
                // the correct cmd_name and line prefix (bash:
                // "script: line N: typeset: NAME: nameref …").
                if v == name && !local_self_target {
                    eprintln!("{}: {}: {}: nameref variable self references not allowed",
                        shell.err_prefix_with_line(), cmd_name, name);
                    status = 1;
                    continue;
                }
                // A nameref variable cannot be an array — bash rejects
                // `typeset -n x=y` when x is currently an indexed or
                // associative array.  Emit the canonical error and
                // leave x untouched.
                if local_self_target {
                    eprintln!("{}: {}: warning: {}: circular name reference",
                        shell.err_prefix_with_line(), cmd_name, name);
                    eprintln!("{}: warning: {}: circular name reference",
                        shell.err_prefix_with_line(), name);
                }
                if v.is_empty() {
                    eprintln!("{}: {}: `{}': not a valid identifier",
                        shell.err_prefix_with_line(), cmd_name, v);
                    status = 1;
                    continue;
                }
                let local_array_conflict = if effective_local && !shell.vars.is_local_pub(name) {
                    false
                } else {
                    shell.vars.is_array(name) || shell.vars.is_assoc(name)
                };
                if local_array_conflict {
                    eprintln!("{}: {}: {}: reference variable cannot be an array",
                        shell.err_prefix_with_line(), cmd_name, name);
                    status = 1;
                    continue;
                }
                let ok = if effective_local {
                    shell.vars.set_local_nameref_target(name, v)
                } else {
                    shell.vars.set_nameref_target(name, v)
                };
                if !ok {
                    status = 1;
                    continue;
                }
            } else if effective_local {
                let inherit_tempenv_export =
                    shell.tempenv_names.contains(name) && shell.vars.is_exported(name);
                // `local var=val` on a readonly outer var is an error
                // (bash: "local: var: readonly variable") — don't
                // create the new local; the outer readonly stays.
                if local_decl_hits_readonly(shell, name) {
                    eprintln!("{}: {}: {}: readonly variable",
                        shell.err_prefix_with_line(), cmd_name, name);
                    status = 1;
                    continue;
                }
                if shell.vars.is_nameref(name) {
                    let raw_target = shell.vars.get_nameref_target(name)
                        .or_else(|| shell.vars.get_raw_scalar(name))
                        .unwrap_or_default();
                    let unresolved = raw_target.is_empty()
                        || !crate::vars::Variables::is_valid_nameref_target(&raw_target)
                        || shell.vars.resolve_nameref(name).is_none();
                    if unresolved && !crate::vars::Variables::is_valid_nameref_target(v) {
                        // bash 5.3 wording rules for an existing nameref
                        // assigned to an invalid target without `-n` on
                        // the current declare:
                        //   * outside any function   → "not a valid identifier"
                        //   * inside a function body → "invalid variable name for name reference"
                        // Empty value always uses "not a valid identifier".
                        // Bash leaves the nameref attribute in place
                        // (does not strip it).
                        let msg = if v.is_empty() {
                            "not a valid identifier"
                        } else if shell.vars.in_function_scope() {
                            "invalid variable name for name reference"
                        } else {
                            "not a valid identifier"
                        };
                        eprintln!("{}: {}: `{}': {}",
                            shell.err_prefix_with_line(), cmd_name, v, msg);
                        status = 1;
                        continue;
                    }
                }
                if inherited_local {
                    let stored = coerce_decl_value(
                        shell, v, value_int_flag, value_lower_flag, value_upper_flag, value_cap_flag);
                    shell.vars.set(name, &stored);
                } else {
                    let stored = coerce_decl_value(
                        shell, v, value_int_flag, value_lower_flag, value_upper_flag, value_cap_flag);
                    shell.vars.set_local(name, &stored);
                }
                if inherit_tempenv_export {
                    shell.vars.export(name);
                }
            } else {
                // Bash emits `declare: NAME: readonly variable` (with
                // the builtin prefix) when `declare NAME=VAL` tries
                // to rewrite a readonly variable.  Check BEFORE
                // calling set, which otherwise emits just
                // `NAME: readonly variable`.
                if shell.vars.is_readonly(name) {
                    eprintln!("{}: {}: {}: readonly variable",
                        shell.err_prefix_with_line(), cmd_name, name);
                    status = 1;
                    continue;
                }
                if shell.vars.is_nameref(name) {
                    let raw_target = shell.vars.get_nameref_target(name)
                        .or_else(|| shell.vars.get_raw_scalar(name))
                        .unwrap_or_default();
                    let unresolved = raw_target.is_empty()
                        || !crate::vars::Variables::is_valid_nameref_target(&raw_target)
                        || shell.vars.resolve_nameref(name).is_none();
                    if unresolved && !crate::vars::Variables::is_valid_nameref_target(v) {
                        // bash 5.3 wording rules for an existing nameref
                        // assigned to an invalid target without `-n` on
                        // the current declare:
                        //   * outside any function   → "not a valid identifier"
                        //   * inside a function body → "invalid variable name for name reference"
                        // Empty value always uses "not a valid identifier".
                        // When the nameref had NO prior target (unresolved),
                        // bash removes the variable entirely so that a
                        // subsequent `declare -p NAME` says "not found".
                        // (In function scope, the local entry is kept.)
                        let msg = if v.is_empty() {
                            "not a valid identifier"
                        } else if shell.vars.in_function_scope() {
                            "invalid variable name for name reference"
                        } else {
                            "not a valid identifier"
                        };
                        eprintln!("{}: {}: `{}': {}",
                            shell.err_prefix_with_line(), cmd_name, v, msg);
                        if !shell.vars.in_function_scope() {
                            shell.vars.force_unset(name);
                        }
                        status = 1;
                        continue;
                    }
                }
                let stored = coerce_decl_value(
                    shell, v, value_int_flag, value_lower_flag, value_upper_flag, value_cap_flag);
                shell.set_var(name, &stored);
            }
        } else if effective_local {
            let mut inherited_local = false;
            if local_inherit || shell.shopt.contains("localvar_inherit") {
                match shell.vars.inherit_local_from_outer(name) {
                    crate::vars::LocalInheritResult::Readonly => {
                        eprintln!("{}: {}: {}: readonly variable",
                            shell.err_prefix_with_line(), cmd_name, name);
                        status = 1;
                        continue;
                    }
                    crate::vars::LocalInheritResult::Inherited => {
                        inherited_local = true;
                    }
                    crate::vars::LocalInheritResult::NotFound => {}
                }
            }
            // declare without value in function scope — create local.
            // Bash semantics: if the var is in the caller's tempenv
            // (set via `var=hello func`), inherit its value.
            // Otherwise leave the new local UNSET so ${NAME-default}
            // expands to the default.
            if !inherited_local && !shell.vars.is_array(name) && !is_array && !is_assoc {
                if shell.tempenv_names.contains(name) {
                    let inherit_tempenv_export = shell.vars.is_exported(name);
                    let value = shell.vars.get(name).unwrap_or_default();
                    shell.vars.set_local(name, &value);
                    if inherit_tempenv_export {
                        shell.vars.export(name);
                    }
                } else {
                    // Create an unset local entry so ${var-default} works.
                    let scope = shell.vars.current_scope_idx();
                    shell.vars.ensure_scope_entry(scope, name);
                }
            }
        } else {
            // Just declare without value (creates if not exists).
            // Skip the placeholder scalar when the declaration sets
            // the array or assoc attribute — declare_array /
            // declare_assoc below will create the right-typed empty
            // container without the stray [0]="" element a scalar
            // conversion would produce.
            //
            // For scalar-flavour declarations (including `declare -i`,
            // `-l`, `-u`, `-c`, `-r`, `-x`), bash creates the entry
            // with the attribute set but leaves it uninitialised — so
            // `declare -p` prints `declare -i foo` without `="0"`.
            // We implement that by creating the entry via a raw
            // ensure_scope_entry call rather than `set(name, "")`.
            if effective_local && !is_array && !is_assoc {
                let scope = shell.vars.current_scope_idx();
                shell.vars.ensure_scope_entry(scope, name);
            } else if !shell.vars.has_entry_raw(name)
                && !is_array
                && !is_assoc
            {
                let scope = shell.vars.current_scope_idx();
                shell.vars.ensure_scope_entry(scope, name);
            }
        }

        if is_array {
            let raw_target_is_subscript = shell.vars.is_nameref(raw_attr_name)
                && shell.vars.get_raw_scalar(raw_attr_name)
                    .map(|t| crate::exec::parse_subscripted_name_pub(&t).is_some())
                    .unwrap_or(false);
            if !raw_target_is_subscript {
                if effective_local {
                    shell.vars.declare_local_array(name);
                } else {
                    shell.vars.declare_array(name);
                }
            }
        }
        // Only call declare_assoc when no compound array was assigned (already initialised above)
        if is_assoc && value.map(|v| !v.starts_with("\x00ARRAY\x00")).unwrap_or(true) {
            let raw_target_is_subscript = shell.vars.is_nameref(raw_attr_name)
                && shell.vars.get_raw_scalar(raw_attr_name)
                    .map(|t| crate::exec::parse_subscripted_name_pub(&t).is_some())
                    .unwrap_or(false);
            if !raw_target_is_subscript {
                if effective_local {
                    shell.vars.declare_local_assoc(name);
                } else {
                    shell.vars.declare_assoc(name);
                }
            }
        }
        if is_integer {
            if raw_attr_mode { shell.vars.set_integer_raw(raw_attr_name); }
            else { shell.vars.set_integer(name); }
        }
        if unset_integer {
            if raw_attr_mode { shell.vars.unset_integer_raw(raw_attr_name); }
            else { shell.vars.unset_integer(name); }
        }
        if is_export {
            if raw_attr_mode { shell.vars.export_raw(raw_attr_name); }
            else { shell.vars.export(name); }
        }
        if unset_export {
            if raw_attr_mode { shell.vars.unset_exported_raw(raw_attr_name); }
            else { shell.vars.unset_exported(name); }
        }
        if is_lowercase {
            if raw_attr_mode { shell.vars.set_lowercase_raw(raw_attr_name); }
            else { shell.vars.set_lowercase(name); }
        }
        if unset_lowercase {
            if raw_attr_mode { shell.vars.unset_lowercase_raw(raw_attr_name); }
            else { shell.vars.unset_lowercase(name); }
        }
        if is_uppercase {
            if raw_attr_mode { shell.vars.set_uppercase_raw(raw_attr_name); }
            else { shell.vars.set_uppercase(name); }
        }
        if unset_uppercase {
            if raw_attr_mode { shell.vars.unset_uppercase_raw(raw_attr_name); }
            else { shell.vars.unset_uppercase(name); }
        }
        if is_capitalize {
            if raw_attr_mode { shell.vars.set_capitalize_raw(raw_attr_name); }
            else { shell.vars.set_capitalize(name); }
        }
        if unset_capitalize {
            if raw_attr_mode { shell.vars.unset_capitalize_raw(raw_attr_name); }
            else { shell.vars.unset_capitalize(name); }
        }
        if nameref {
            // Validate target name (bash: _valid_nameref_value).  Empty
            // targets and self-references are rejected.  Use get_raw
            // so we check the literal value, not the resolved target
            // (otherwise a circular ref already present would look
            // non-self).
            if shell.vars.has_entry_raw(name) && shell.vars.is_readonly_raw(name) {
                eprintln!("{}: {}: {}: readonly variable",
                    shell.err_prefix_with_line(), cmd_name, name);
                status = 1;
                continue;
            }
            let raw_array_conflict = if effective_local && !shell.vars.is_local_pub(name) {
                false
            } else {
                shell.vars.has_entry_raw(name) && shell.vars.get_raw_scalar(name).is_none()
            };
            if raw_array_conflict {
                eprintln!("{}: {}: {}: reference variable cannot be an array",
                    shell.err_prefix_with_line(), cmd_name, name);
                status = 1;
                continue;
            }
            let current = shell.vars.get_raw_scalar(name).unwrap_or_default();
            let local_self_target = effective_local
                && (current == name
                    || crate::exec::parse_subscripted_name_pub(&current)
                        .map(|(base, _)| base == name)
                        .unwrap_or(false));
            if !crate::vars::Variables::is_valid_nameref_target(&current) {
                if current.is_empty() && value.is_some() {
                    eprintln!("{}: {}: `{}': not a valid identifier",
                        shell.err_prefix_with_line(), cmd_name, current);
                } else {
                    eprintln!("{}: {}: `{}': invalid variable name for name reference",
                        shell.err_prefix_with_line(), cmd_name, current);
                }
                status = 1;
                continue;
            }
            // bash 5.3: `declare -n NAME` on a variable that's already
            // INITIALIZED to an empty string errors because an empty
            // string is never a valid nameref target.  Uninitialized
            // namerefs (fresh `declare -n NAME` with no prior entry)
            // are allowed.
            if value.is_none()
                && current.is_empty()
                && shell.vars.get_entry_is_initialized_raw(name)
                && !shell.vars.is_nameref(name)
            {
                eprintln!("{}: {}: `{}': invalid variable name for name reference",
                    shell.err_prefix_with_line(), cmd_name, current);
                status = 1;
                continue;
            }
            if current == name && !local_self_target {
                eprintln!("{}: {}: {}: nameref variable self references not allowed",
                    shell.err_prefix_with_line(), cmd_name, name);
                status = 1;
                continue;
            }
            if shell.vars.has_entry_raw(raw_attr_name) {
                if !is_integer {
                    shell.vars.unset_integer_raw(raw_attr_name);
                }
                if !is_lowercase {
                    shell.vars.unset_lowercase_raw(raw_attr_name);
                }
                if !is_uppercase {
                    shell.vars.unset_uppercase_raw(raw_attr_name);
                }
                if !is_capitalize {
                    shell.vars.unset_capitalize_raw(raw_attr_name);
                }
            }
            if effective_local {
                shell.vars.mark_local_nameref(name);
            } else {
                shell.vars.mark_nameref(name);
            }
        } else if unset_nameref_attr {
            shell.vars.unmark_nameref(raw_attr_name);
        }

        if is_readonly {
            if raw_attr_mode { shell.vars.set_readonly_raw(raw_attr_name); }
            else { shell.vars.set_readonly(name); }
        }

        // `declare -ft funcname` — set trace attribute on a function
        if func_mode && is_trace && shell.functions.contains_key(name) {
            shell.traced_functions.insert(name.to_string());
        }
    }
    for name in global_preferred_names {
        shell.vars.clear_prefer_global_name(&name);
    }
    status
}

// ---------------------------------------------------------------------------
// readonly
// ---------------------------------------------------------------------------

fn builtin_readonly(shell: &mut Shell, args: &[String]) -> i32 {
    let mut idx = 0;
    let mut func_mode = false;
    let mut array_flag = false;
    let mut assoc_flag = false;
    let mut print_flag = false;
    while idx < args.len() {
        let a = args[idx].as_str();
        if a == "-f" { func_mode = true; idx += 1; }
        else if a == "-a" { array_flag = true; idx += 1; }
        else if a == "-A" { assoc_flag = true; idx += 1; }
        else if a == "-p" { print_flag = true; idx += 1; }
        else if a == "--" { idx += 1; break; }
        else if a.starts_with('-') && a.len() > 1 {
            // Combined short flags (e.g. -ap).  Any unknown char is
            // an error, matching bash's "invalid option" diagnostic.
            // Note: bash silently accepts `-n` (no-op), probably for
            // cross-shell compatibility with ksh/export -n.
            for c in a[1..].chars() {
                match c {
                    'f' => func_mode = true,
                    'a' => array_flag = true,
                    'A' => assoc_flag = true,
                    'p' => print_flag = true,
                    'n' => { /* silently accepted for compat */ }
                    _ => {
                        eprintln!("{}: readonly: -{}: invalid option",
                            shell.err_prefix_with_line(), c);
                        eprintln!("readonly: usage: readonly [-aAf] [name[=value] ...] or readonly -p");
                        return 2;
                    }
                }
            }
            idx += 1;
        }
        else { break; }
    }

    // Listing mode: no arguments, or `-p`, or a type-filter flag
    // (-a, -A) with no names → list matching readonly variables.
    if idx >= args.len() && (print_flag || array_flag || assoc_flag || args.is_empty()) {
        let posix = shell.vars.posix_mode;
        let names: Vec<String> = {
            let vars = shell.vars.list_vars();
            vars.into_iter().map(|(n, _)| n).collect()
        };
        for name in names {
            if !shell.vars.is_readonly(&name) { continue; }
            let is_a = shell.vars.is_array(&name) && !shell.vars.is_assoc(&name);
            let is_assoc = shell.vars.is_assoc(&name);
            if array_flag && !is_a { continue; }
            if assoc_flag && !is_assoc { continue; }
            // In POSIX mode `readonly` prints with `readonly` prefix;
            // otherwise with `declare -r…` prefix.
            let prefix = if posix { "readonly" } else { "declare" };
            if is_a {
                let elements = shell.vars.get_array_sparse(&name).unwrap_or_default();
                let parts: Vec<String> = elements.iter()
                    .map(|(i, v)| format!("[{}]={}", i, quote_for_declare(v)))
                    .collect();
                let flag = if posix { "-a".to_string() } else { "-ar".to_string() };
                if elements.is_empty() && !shell.vars.get_entry_is_initialized(&name) {
                    println!("{} {} {}", prefix, flag, name);
                } else {
                    println!("{} {} {}=({})", prefix, flag, name, parts.join(" "));
                }
            } else if is_assoc {
                let entries = shell.vars.get_assoc_entries(&name);
                let parts: Vec<String> = entries.iter()
                    .map(|(k, v)| format!("[{}]={}", quote_key_for_declare(k), quote_for_declare(v)))
                    .collect();
                let flag = if posix { "-A".to_string() } else { "-Ar".to_string() };
                if parts.is_empty() {
                    println!("{} {} {}=()", prefix, flag, name);
                } else {
                    println!("{} {} {}=({} )", prefix, flag, name, parts.join(" "));
                }
            } else {
                let value = shell.vars.get(&name).unwrap_or_default();
                let flag = if posix { "".to_string() } else { "-r".to_string() };
                let fullflag = if flag.is_empty() { String::new() } else { format!(" {}", flag) };
                if shell.vars.get_entry_is_initialized(&name) {
                    println!("{}{} {}={}", prefix, fullflag, name, quote_for_declare(&value));
                } else {
                    println!("{}{} {}", prefix, fullflag, name);
                }
            }
        }
        return 0;
    }

    if func_mode {
        if args[idx..].is_empty() {
            // `readonly -f` with no names: list all readonly functions'
            // definitions followed by `declare -fr NAME`.
            let mut names: Vec<String> = shell.readonly_functions.iter().cloned().collect();
            names.sort();
            for name in &names {
                if let Some(func) = shell.functions.get(name) {
                    print!("{}", format_function_def(func));
                    println!("declare -fr {}", name);
                }
            }
            return 0;
        }
        let mut status = 0;
        for name in &args[idx..] {
            if shell.functions.contains_key(name) {
                shell.readonly_functions.insert(name.clone());
            } else {
                let prefix = shell.err_prefix_with_line();
                eprintln!("{}: readonly: {}: not found", prefix, name);
                status = 1;
            }
        }
        return status;
    }

    let mut status = 0;
    for arg in &args[idx..] {
        if let Some(eq) = arg.find('=') {
            // Detect name+=value (append) vs name=value (assign)
            let (name, value, is_append) = if eq > 0 && arg.as_bytes()[eq - 1] == b'+' {
                (&arg[..eq - 1], &arg[eq + 1..], true)
            } else {
                (&arg[..eq], &arg[eq + 1..], false)
            };
            if !is_valid_identifier(name) {
                eprintln!("{}: readonly: `{}': not a valid identifier", shell.err_prefix_with_line(), name);
                if shell.posix_mode && !shell.interactive && !shell.suppress_special_builtin_fatal {
                    shell.exit_flag = true;
                    return 1;
                }
                status = 1;
                continue;
            }
            if shell.vars.is_readonly(name) {
                let prefix = shell.err_prefix_with_line();
                if array_flag && value.starts_with("\x00ARRAY\x00") {
                    // -a flag + unquoted array syntax (a=(val)): report calling function name
                    let funcname = shell.funcname_stack.last().cloned().unwrap_or_default();
                    if funcname.is_empty() {
                        eprintln!("{}: {}: readonly variable", prefix, name);
                    } else {
                        eprintln!("{}: {}: {}: readonly variable", prefix, funcname, name);
                    }
                } else if array_flag && value.starts_with('(') && value.ends_with(')') {
                    // -a flag with quoted/literal array syntax: report readonly:
                    eprintln!("{}: readonly: {}: readonly variable", prefix, name);
                } else {
                    // No -a flag or plain scalar: just varname
                    eprintln!("{}: {}: readonly variable", prefix, name);
                }
                status = 1;
                continue;
            }
            if (array_flag || assoc_flag)
                && (value.starts_with("\x00ARRAY\x00")
                    || (value.starts_with('(') && value.ends_with(')')))
            {
                let mut decl_args = vec!["-r".to_string()];
                if shell.vars.in_function_scope() && !shell.vars.is_local_pub(name) {
                    decl_args.push("-g".to_string());
                }
                if assoc_flag {
                    decl_args.push("-A".to_string());
                } else if array_flag {
                    decl_args.push("-a".to_string());
                }
                decl_args.push(arg.clone());
                let rc = builtin_declare(shell, "declare", &decl_args, false);
                if rc != 0 {
                    status = 1;
                }
                continue;
            }
            if value.starts_with("\x00ARRAY\x00") {
                // Array assignment via unquoted a=(..) syntax
                let content = &value["\x00ARRAY\x00".len()..];
                let elements: Vec<String> = if content.is_empty() {
                    Vec::new()
                } else {
                    content.split('\x1F')
                        .map(|e| strip_compound_bare_elem(e).to_string())
                        .collect()
                };
                if is_append {
                    for e in elements { shell.vars.push_array(name, &e); }
                } else {
                    shell.vars.set_array(name, elements);
                }
            } else if !is_append && array_flag && value.starts_with('(') && value.ends_with(')') {
                // -a flag with value=(literal): parse parens as array literal
                let inner = &value[1..value.len() - 1];
                let elements: Vec<String> = inner.split_whitespace()
                    .map(|w| shell.expand_word_for_builtin(w))
                    .collect();
                shell.vars.set_array(name, elements);
            } else if is_append {
                if !shell.append_var(name, value) {
                    status = 1;
                    continue;
                }
            } else if shell.vars.is_array(name) {
                // Variable is already an array: assign value as sole element [0]
                shell.vars.set_array(name, vec![value.to_string()]);
            } else {
                shell.set_var(name, value);
            }
            shell.vars.set_readonly(name);
        } else {
            let name = arg.as_str();
            // Bash: `readonly NAME[SUB]` is not allowed — the entire
            // variable is made readonly, never an individual element.
            // Emit "not a valid identifier" as bash does.
            if name.contains('[') && name.ends_with(']') {
                let prefix = shell.err_prefix_with_line();
                eprintln!("{}: readonly: `{}': not a valid identifier", prefix, name);
                if shell.posix_mode && !shell.interactive && !shell.suppress_special_builtin_fatal {
                    shell.exit_flag = true;
                    return 1;
                }
                status = 1;
                continue;
            }
            if !is_valid_identifier(name) {
                eprintln!("{}: readonly: `{}': not a valid identifier", shell.err_prefix_with_line(), name);
                if shell.posix_mode && !shell.interactive && !shell.suppress_special_builtin_fatal {
                    shell.exit_flag = true;
                    return 1;
                }
                status = 1;
                continue;
            }
            if shell.vars.is_nameref(name) {
                if let Some(target) = shell.vars.get_raw_scalar(name) {
                    if target.contains('[') && target.ends_with(']') {
                        let prefix = shell.err_prefix_with_line();
                        eprintln!("{}: readonly: `{}': not a valid identifier", prefix, target);
                        if shell.posix_mode && !shell.interactive && !shell.suppress_special_builtin_fatal {
                            shell.exit_flag = true;
                            return 1;
                        }
                        status = 1;
                        continue;
                    }
                }
            }
            // `readonly NAME` (no value) on an already-readonly name
            // is a no-op in bash (no error).  When NAME is a nameref
            // pointing at an already-readonly target, the same rule
            // applies — just mark NAME itself readonly if it wasn't
            // already, otherwise do nothing.
            if shell.vars.is_readonly_raw(name) {
                continue;
            }
            if shell.vars.get(name).is_none() && !shell.vars.is_array(name) {
                shell.vars.set(name, "");
            }
            shell.vars.set_readonly(name);
        }
    }
    status
}

// ---------------------------------------------------------------------------
// read
// ---------------------------------------------------------------------------

fn builtin_read(shell: &mut Shell, args: &[String], raw_args: &[String]) -> i32 {
    let read_usage = || {
        eprintln!(
            "read: usage: read [-Eers] [-a array] [-d delim] [-i text] [-n nchars] [-N nchars] [-p prompt] [-t timeout] [-u fd] [name ...]"
        );
    };
    let mut raw_mode = false;
    let mut prompt: Option<String> = None;
    let mut array_var: Option<String> = None;
    let mut delimiter = '\n';
    let mut nchars: Option<usize> = None;
    let mut silent = false;
    let mut timeout: Option<f64> = None;
    let mut fd: RawFd = 0; // stdin
    let mut idx = 0;
    let mut var_names: Vec<String> = Vec::new();
    let mut raw_var_names: Vec<String> = Vec::new();

    while idx < args.len() {
        match args[idx].as_str() {
            "-r" => { raw_mode = true; idx += 1; }
            "-s" => { silent = true; idx += 1; }
            "-p" => {
                idx += 1;
                if idx < args.len() {
                    prompt = Some(args[idx].clone());
                    idx += 1;
                }
            }
            "-a" => {
                idx += 1;
                if idx < args.len() {
                    array_var = Some(args[idx].clone());
                    idx += 1;
                }
            }
            "-d" => {
                idx += 1;
                if idx < args.len() {
                    // Empty string (e.g. -d $'\000') means NUL delimiter
                    delimiter = args[idx].chars().next().unwrap_or('\0');
                    idx += 1;
                }
            }
            "-n" => {
                idx += 1;
                if idx < args.len() {
                    match args[idx].parse::<i64>() {
                        Ok(n) if n >= 0 => nchars = Some(n as usize),
                        _ => {
                            eprintln!("{}: read: {}: invalid number",
                                shell.err_prefix_with_line(), args[idx]);
                            return 1;
                        }
                    }
                    idx += 1;
                }
            }
            "-N" => {
                idx += 1;
                if idx < args.len() {
                    match args[idx].parse::<i64>() {
                        Ok(n) if n >= 0 => nchars = Some(n as usize),
                        _ => {
                            eprintln!("{}: read: {}: invalid number",
                                shell.err_prefix_with_line(), args[idx]);
                            return 1;
                        }
                    }
                    idx += 1;
                }
            }
            "-t" => {
                idx += 1;
                if idx < args.len() {
                    match args[idx].parse::<f64>() {
                        Ok(n) if n >= 0.0 => timeout = Some(n),
                        _ => {
                            eprintln!("{}: read: {}: invalid timeout specification",
                                shell.err_prefix_with_line(), args[idx]);
                            return 1;
                        }
                    }
                    idx += 1;
                }
            }
            "-u" => {
                idx += 1;
                if idx < args.len() {
                    match args[idx].parse() {
                        Ok(n) => fd = n,
                        Err(_) => {
                            eprintln!("{}: read: {}: invalid file descriptor specification",
                                shell.err_prefix_with_line(), args[idx]);
                            return 1;
                        }
                    }
                    idx += 1;
                }
            }
            "-e" | "-E" => { idx += 1; } // readline-related, ignore
            "-i" => {
                idx += 1;
                if idx < args.len() {
                    idx += 1;
                }
            }
            s if s.starts_with('-') && s.len() > 1 => {
                // Combined flags like -ru3 (-r -u 3) / -rd X (-r -d X).
                let flags = &s[1..];
                let flag_chars: Vec<char> = flags.chars().collect();
                let mut fi = 0;
                while fi < flag_chars.len() {
                    match flag_chars[fi] {
                        'r' => raw_mode = true,
                        's' => silent = true,
                        'u' => {
                            // Rest of the string is the fd number
                            let rest: String = flag_chars[fi+1..].iter().collect();
                            if !rest.is_empty() {
                                fd = rest.parse().unwrap_or(0);
                            } else if idx + 1 < args.len() {
                                idx += 1;
                                fd = args[idx].parse().unwrap_or(0);
                            }
                            fi = flag_chars.len(); // consumed rest
                            continue;
                        }
                        'd' => {
                            // Rest of this short-opt cluster is the delim,
                            // or the next argv if nothing left here.
                            let rest: String = flag_chars[fi+1..].iter().collect();
                            if !rest.is_empty() {
                                delimiter = rest.chars().next().unwrap_or('\0');
                            } else if idx + 1 < args.len() {
                                idx += 1;
                                delimiter = args[idx].chars().next().unwrap_or('\0');
                            }
                            fi = flag_chars.len();
                            continue;
                        }
                        'N' | 'n' => {
                            let rest: String = flag_chars[fi+1..].iter().collect();
                            if !rest.is_empty() {
                                nchars = rest.parse().ok();
                            } else if idx + 1 < args.len() {
                                idx += 1;
                                nchars = args[idx].parse().ok();
                            }
                            fi = flag_chars.len();
                            continue;
                        }
                        't' => {
                            let rest: String = flag_chars[fi+1..].iter().collect();
                            if !rest.is_empty() {
                                timeout = rest.parse().ok();
                            } else if idx + 1 < args.len() {
                                idx += 1;
                                timeout = args[idx].parse().ok();
                            }
                            fi = flag_chars.len();
                            continue;
                        }
                        'p' => {
                            let rest: String = flag_chars[fi+1..].iter().collect();
                            if !rest.is_empty() {
                                prompt = Some(rest);
                            } else if idx + 1 < args.len() {
                                idx += 1;
                                prompt = Some(args[idx].clone());
                            }
                            fi = flag_chars.len();
                            continue;
                        }
                        'a' => {
                            let rest: String = flag_chars[fi+1..].iter().collect();
                            if !rest.is_empty() {
                                array_var = Some(rest);
                            } else if idx + 1 < args.len() {
                                idx += 1;
                                array_var = Some(args[idx].clone());
                            }
                            fi = flag_chars.len();
                            continue;
                        }
                        'e' | 'E' => {}
                        'i' => {
                            let rest: String = flag_chars[fi + 1..].iter().collect();
                            if rest.is_empty() && idx + 1 < args.len() {
                                idx += 1;
                            }
                            fi = flag_chars.len();
                            continue;
                        }
                        _ => {
                            eprintln!(
                                "{}: read: -{}: invalid option",
                                shell.err_prefix_with_line(),
                                flag_chars[fi]
                            );
                            read_usage();
                            return 2;
                        }
                    }
                    fi += 1;
                }
                idx += 1;
            }
            _ => {
                // Remaining args are variable names.  Capture both the
                // expanded form (for assignment) and the raw form (for
                // assoc_expand_once assignment-target validation).
                while idx < args.len() {
                    var_names.push(args[idx].clone());
                    if idx < raw_args.len() {
                        raw_var_names.push(raw_args[idx].clone());
                    } else {
                        raw_var_names.push(args[idx].clone());
                    }
                    idx += 1;
                }
            }
        }
    }

    // Validate fd is actually open (if non-default)
    if fd != 0 {
        let flags = unsafe { libc::fcntl(fd, libc::F_GETFD) };
        if flags == -1 {
            eprintln!("{}: read: {}: invalid file descriptor: Bad file descriptor",
                shell.err_prefix_with_line(), fd);
            return 1;
        }
    }

    // Show prompt — only when stdin is a terminal (bash behaviour).
    if let Some(ref p) = prompt {
        if unsafe { libc::isatty(fd) } == 1 {
            let stderr = io::stderr();
            let mut err = stderr.lock();
            let _ = err.write_all(p.as_bytes());
            let _ = err.flush();
        }
    }

    // Set up terminal for silent mode
    let old_termios = if silent && unsafe { libc::isatty(fd) } == 1 {
        unsafe {
            let mut t: libc::termios = std::mem::zeroed();
            if libc::tcgetattr(fd, &mut t) == 0 {
                let saved = t;
                t.c_lflag &= !libc::ECHO;
                libc::tcsetattr(fd, libc::TCSANOW, &t);
                Some(saved)
            } else {
                None
            }
        }
    } else {
        None
    };

    // Set up timeout (in milliseconds; -1 means no timeout)
    let timeout_ms: i32 = match timeout {
        Some(t) => {
            if t <= 0.0 {
                0
            } else {
                (t * 1000.0).ceil() as i32
            }
        }
        None => -1,
    };

    // `read -t 0` is a readiness probe in bash: it does not consume input
    // or assign variables; it just reports whether input is immediately
    // available on the target fd.
    if timeout_ms == 0 {
        if let Some(saved) = old_termios {
            unsafe { libc::tcsetattr(fd, libc::TCSANOW, &saved); }
            eprintln!();
        }
        return if poll_fd_ready(fd, 0) { 0 } else { 1 };
    }

    // Read input
    let input = if let Some(n) = nchars {
        read_n_chars(fd, n, timeout_ms)
    } else {
        read_until_delimiter(fd, delimiter, raw_mode, timeout_ms)
    };

    // Restore terminal
    if let Some(saved) = old_termios {
        unsafe { libc::tcsetattr(fd, libc::TCSANOW, &saved); }
        // Print newline after silent input
        eprintln!();
    }

    let (timed_out, eof, line) = match input {
        ReadOutcome::Data(s) => (false, false, s),
        ReadOutcome::Timeout => (true, false, String::new()),
        ReadOutcome::Eof => (false, true, String::new()),
    };

    // Strip READ_ESC markers from the raw line for contexts that use
    // the line as-is (no IFS splitting): REPLY and the remainder form.
    // Uses \u{FDD1} (Unicode noncharacter) so real 0x01 bytes in the
    // input aren't confused for the marker.  Orphan FDD1 markers
    // (with no following char, e.g. after trailing-whitespace trim)
    // are simply dropped.
    let strip_read_esc = |s: &str| -> String {
        let mut out = String::with_capacity(s.len());
        let chars: Vec<char> = s.chars().collect();
        let mut i = 0;
        while i < chars.len() {
            if chars[i] == '\u{FDD1}' {
                if i + 1 < chars.len() {
                    out.push(chars[i + 1]);
                    i += 2;
                } else {
                    i += 1;
                }
            } else {
                out.push(chars[i]);
                i += 1;
            }
        }
        out
    };

    if let Some(arr_name) = array_var {
        if let Some(target) = nameref_subscript_target(shell, &arr_name) {
            eprintln!("{}: read: `{}': not a valid identifier",
                shell.err_prefix_with_line(), target);
            return 1;
        }
        // Validate the array variable name
        if !is_valid_identifier(&arr_name) {
            eprintln!("{}: read: `{}': not a valid identifier",
                shell.err_prefix_with_line(), arr_name);
            return 1;
        }
        // Read into array
        let ifs = shell.get_var("IFS").unwrap_or_else(|| " \t\n".to_string());
        let fields = split_by_ifs(&line, &ifs);
        if shell.vars.is_assoc(&arr_name) {
            eprintln!("{}: read: {}: not an indexed array",
                shell.err_prefix_with_line(), arr_name);
            return 1;
        }
        shell.vars.declare_array(&arr_name);
        shell.vars.set_array(&arr_name, fields);
    } else if var_names.is_empty() {
        // Default variable REPLY
        shell.set_var("REPLY", &strip_read_esc(&line));
    } else {
        // Split by IFS and assign to variables.  Algorithm:
        //   1. Word-split the line into fields using IFS rules.
        //   2. If #fields <= #vars: direct assignment (missing → "").
        //   3. If #fields > #vars: first N-1 vars take their fields,
        //      last var gets the raw line remainder starting after
        //      the (N-1)th delimiter, with trailing IFS-ws stripped.
        let ifs = shell.get_var("IFS").unwrap_or_else(|| " \t\n".to_string());
        let fields = split_by_ifs(&line, &ifs);
        let n = var_names.len();

        // Helper: a var name for `read` can be `NAME` or `NAME[sub]`.
        // Validate the base.  When assoc_expand_once is set and the raw
        // (pre-expansion) word is a bare `NAME[$VAR]` syntax, bash treats
        // it as an array-element assignment target and accepts the
        // expanded result regardless of subscript content.
        let valid_read_target = |v: &str, raw: &str| -> bool {
            if is_valid_identifier(v) {
                return true;
            }
            let parsed = if shell.shopt.contains("assoc_expand_once") {
                crate::exec::parse_subscripted_name_assoc_once_pub(v)
            } else {
                crate::exec::parse_subscripted_name_strict_pub(v)
            };
            if let Some((base, sub)) = parsed {
                if is_valid_identifier(&base)
                    && (!shell.vars.is_assoc(&base) || !sub.is_empty())
                {
                    return true;
                }
            }
            if shell.shopt.contains("assoc_expand_once")
                && raw_word_is_bare_subscript(raw)
            {
                return true;
            }
            false
        };
        for (i, var) in var_names.iter().enumerate() {
            let raw = raw_var_names.get(i).map(String::as_str).unwrap_or(var.as_str());
            if !valid_read_target(var, raw) {
                eprintln!("{}: read: `{}': not a valid identifier",
                    shell.err_prefix_with_line(), var);
                return 1;
            }
        }

        // Extract base name for readonly checking.
        let base_of = |v: &str| -> String {
            if let Some(b) = v.find('[') { v[..b].to_string() } else { v.to_string() }
        };

        let mut ro_hit = false;
        if fields.len() <= n {
            for (i, var) in var_names.iter().enumerate() {
                let base = base_of(var);
                if shell.vars.is_readonly(&base) {
                    eprintln!("{}: {}: readonly variable",
                        shell.err_prefix_with_line(), base);
                    ro_hit = true;
                    break;
                }
                let val = fields.get(i).cloned().unwrap_or_default();
                if var.contains('[') && var.ends_with(']') {
                    shell.assign_var_or_element_pub(var, &val);
                } else {
                    shell.set_var(var, &val);
                }
            }
        } else {
            for i in 0..n - 1 {
                let base = base_of(&var_names[i]);
                if shell.vars.is_readonly(&base) {
                    eprintln!("{}: {}: readonly variable",
                        shell.err_prefix_with_line(), base);
                    ro_hit = true;
                    break;
                }
                if var_names[i].contains('[') && var_names[i].ends_with(']') {
                    shell.assign_var_or_element_pub(&var_names[i], &fields[i]);
                } else {
                    shell.set_var(&var_names[i], &fields[i]);
                }
            }
            if !ro_hit {
                let last = &var_names[n - 1];
                let last_base = base_of(last);
                if shell.vars.is_readonly(&last_base) {
                    eprintln!("{}: {}: readonly variable",
                        shell.err_prefix_with_line(), last_base);
                    ro_hit = true;
                } else {
                    let remainder = read_remainder_after_fields(&line, &ifs, n - 1);
                    let val = strip_read_esc(&remainder);
                    if last.contains('[') && last.ends_with(']') {
                        shell.assign_var_or_element_pub(last, &val);
                    } else {
                        shell.set_var(last, &val);
                    }
                }
            }
        }
        if ro_hit {
            return 2;
        }
    }

    if timed_out && timeout_ms == 0 {
        1
    } else if timed_out {
        128 + libc::SIGALRM
    } else if eof {
        1
    } else {
        0
    }
}

/// Wait for `fd` to become readable within `timeout_ms` milliseconds.
/// Returns `true` if the fd is ready, `false` on timeout or error.
/// A negative `timeout_ms` means wait indefinitely.
fn poll_fd_ready(fd: RawFd, timeout_ms: i32) -> bool {
    let borrowed = unsafe { BorrowedFd::borrow_raw(fd) };
    let mut readfds = FdSet::new();
    readfds.insert(borrowed);
    let mut errfds = FdSet::new();
    errfds.insert(borrowed);
    let result = if timeout_ms < 0 {
        select(
            Some(fd + 1),
            Some(&mut readfds),
            None,
            Some(&mut errfds),
            None::<&mut TimeVal>,
        )
    } else {
        let mut timeout = TimeVal::milliseconds(timeout_ms as i64);
        select(
            Some(fd + 1),
            Some(&mut readfds),
            None,
            Some(&mut errfds),
            Some(&mut timeout),
        )
    };
    matches!(result, Ok(n) if n > 0 && (readfds.contains(borrowed) || errfds.contains(borrowed)))
}

fn push_raw_byte(out: &mut String, b: u8) {
    if b < 0x80 {
        out.push(b as char);
    } else {
        out.push_str(&crate::expand::encode_raw_byte(b));
    }
}

enum ReadOutcome {
    Data(String),
    Timeout,
    Eof,
}

enum FirstRead {
    Byte(u8),
    Timeout,
    Eof,
}

fn read_first_byte(fd: RawFd, timeout_ms: i32) -> FirstRead {
    let mut buf = [0u8; 1];
    if timeout_ms < 0 {
        let n = unsafe { libc::read(fd, buf.as_mut_ptr() as *mut libc::c_void, 1) };
        return if n > 0 {
            FirstRead::Byte(buf[0])
        } else if n == 0 {
            FirstRead::Eof
        } else {
            FirstRead::Timeout
        };
    }

    let old_flags = unsafe { libc::fcntl(fd, libc::F_GETFL) };
    let had_flags = old_flags >= 0;
    if had_flags && (old_flags & libc::O_NONBLOCK) == 0 {
        unsafe { libc::fcntl(fd, libc::F_SETFL, old_flags | libc::O_NONBLOCK); }
    }

    let first_try = unsafe { libc::read(fd, buf.as_mut_ptr() as *mut libc::c_void, 1) };
    let first_err = if first_try < 0 {
        io::Error::last_os_error().raw_os_error()
    } else {
        None
    };

    if had_flags && (old_flags & libc::O_NONBLOCK) == 0 {
        unsafe { libc::fcntl(fd, libc::F_SETFL, old_flags); }
    }

    if first_try > 0 {
        return FirstRead::Byte(buf[0]);
    }
    if first_try == 0 {
        return FirstRead::Eof;
    }

    let would_block =
        matches!(first_err, Some(errno) if errno == libc::EAGAIN || errno == libc::EWOULDBLOCK);
    if !would_block {
        return FirstRead::Timeout;
    }
    if !poll_fd_ready(fd, timeout_ms) {
        return FirstRead::Timeout;
    }

    let n = unsafe { libc::read(fd, buf.as_mut_ptr() as *mut libc::c_void, 1) };
    if n > 0 {
        FirstRead::Byte(buf[0])
    } else if n == 0 {
        FirstRead::Eof
    } else {
        FirstRead::Timeout
    }
}

fn read_until_delimiter(fd: RawFd, delim: char, raw: bool, timeout_ms: i32) -> ReadOutcome {
    let mut result = String::new();
    let delim_byte = delim as u8;
    let codeset = current_locale_codeset_for_read();
    let is_big5 = codeset.eq_ignore_ascii_case("BIG5") || codeset.eq_ignore_ascii_case("BIG-5");
    let mut pending_backslash = false;
    let mut pending_multibyte_trail = false;
    loop {
        let b = if result.is_empty() && !pending_backslash && !pending_multibyte_trail {
            match read_first_byte(fd, timeout_ms) {
                FirstRead::Byte(b) => b,
                FirstRead::Timeout => return ReadOutcome::Timeout,
                FirstRead::Eof => return ReadOutcome::Eof,
            }
        } else {
            let mut buf = [0u8; 1];
            let n = unsafe { libc::read(fd, buf.as_mut_ptr() as *mut libc::c_void, 1) };
            if n <= 0 {
                // EOF with a trailing `\` pending — bash drops the
                // dangling backslash in non-raw mode (the `\` was an
                // incomplete escape sequence with nothing after it) and
                // preserves it in `-r` mode.  In raw mode we never set
                // `pending_backslash` anyway, so this branch only fires
                // for non-raw — drop silently.
                if result.is_empty() && !pending_backslash { return ReadOutcome::Eof; }
                if result.is_empty() { return ReadOutcome::Eof; }
                break;
            }
            buf[0]
        };
        if pending_multibyte_trail {
            pending_multibyte_trail = false;
            push_raw_byte(&mut result, b);
            continue;
        }
        if pending_backslash {
            pending_backslash = false;
            // Non-raw mode: `\<newline>` is always line continuation —
            // swallow both — regardless of whether `\n` happens to be
            // the current delimiter.
            if b == b'\n' {
                continue;
            }
            // `\<delim>` (where delim != '\n'): literal delimiter.
            // Keep as a READ_ESC marker so split_by_ifs doesn't split.
            // `\X` for any other X: escape it the same way.
            result.push('\u{FDD1}');
            push_raw_byte(&mut result, b);
            continue;
        }
        if is_big5 && (0x81..=0xFE).contains(&b) {
            pending_multibyte_trail = true;
            push_raw_byte(&mut result, b);
            continue;
        }
        if !raw && b == b'\\' {
            pending_backslash = true;
            continue;
        }
        if b == delim_byte {
            break;
        }
        push_raw_byte(&mut result, b);
    }
    ReadOutcome::Data(result)
}

fn read_n_chars(fd: RawFd, n: usize, timeout_ms: i32) -> ReadOutcome {
    if n == 0 {
        return ReadOutcome::Data(String::new());
    }
    let mut result = String::with_capacity(n);
    let codeset = current_locale_codeset_for_read();
    match read_first_byte(fd, timeout_ms) {
        FirstRead::Byte(b) => push_raw_byte(&mut result, b),
        FirstRead::Timeout => return ReadOutcome::Timeout,
        FirstRead::Eof => return ReadOutcome::Eof,
    }
    while read_char_count(&result, &codeset) < n {
        let mut buf = [0u8; 1];
        let rc = unsafe { libc::read(fd, buf.as_mut_ptr() as *mut libc::c_void, 1) };
        if rc <= 0 { break; }
        push_raw_byte(&mut result, buf[0]);
    }
    if result.is_empty() { ReadOutcome::Eof } else { ReadOutcome::Data(result) }
}

/// Compute the raw line remainder for `read`'s last variable when the line
/// has more fields than variables: skip `n` delimiters (one field plus its
/// trailing IFS run each), then strip trailing IFS whitespace from what
/// remains.  This mirrors bash's behaviour where the extra fields stay
/// concatenated with their original separators (non-ws IFS is preserved,
/// only trailing IFS-ws is trimmed).
fn read_remainder_after_fields(line: &str, ifs: &str, n: usize) -> String {
    let chars: Vec<char> = line.chars().collect();
    let ifs_chars: Vec<char> = ifs.chars().collect();
    let ifs_ws: Vec<char> = ifs_chars.iter().filter(|c| c.is_whitespace()).cloned().collect();
    let ifs_nonws: Vec<char> = ifs_chars.iter().filter(|c| !c.is_whitespace()).cloned().collect();
    let is_ifs = |c: char| ifs_ws.contains(&c) || ifs_nonws.contains(&c);

    let mut i = 0usize;
    // Skip leading IFS whitespace before the first field
    while i < chars.len() && ifs_ws.contains(&chars[i]) {
        i += 1;
    }
    for _ in 0..n {
        // Read one field: content until IFS delimiter.
        while i < chars.len() && !is_ifs(chars[i]) {
            i += 1;
        }
        // Consume the delimiter(s) after this field.  A run of IFS-ws +
        // optionally a single non-ws IFS form one delimiter (same as
        // word_split absorb rule).  After that we also eat trailing ws.
        let mut saw_nonws = false;
        while i < chars.len() {
            if ifs_ws.contains(&chars[i]) {
                i += 1;
                continue;
            }
            if ifs_nonws.contains(&chars[i]) && !saw_nonws {
                saw_nonws = true;
                i += 1;
                continue;
            }
            break;
        }
    }
    // Whatever remains is the raw remainder; strip trailing IFS-whitespace.
    let mut end = chars.len();
    while end > i && ifs_ws.contains(&chars[end - 1]) {
        end -= 1;
    }
    chars[i..end].iter().collect()
}

fn current_locale_codeset_for_read() -> String {
    let locale = std::env::var("LC_ALL").ok().filter(|s| !s.is_empty())
        .or_else(|| std::env::var("LC_CTYPE").ok().filter(|s| !s.is_empty()))
        .or_else(|| std::env::var("LANG").ok().filter(|s| !s.is_empty()))
        .unwrap_or_else(|| "C".to_string());
    if locale == "C" || locale == "POSIX" {
        return "US-ASCII".to_string();
    }
    let codeset = locale.split('.').nth(1).unwrap_or(locale.as_str());
    codeset.split('@').next().unwrap_or(codeset).to_string()
}

fn locale_units_for_read(s: &str, codeset: &str) -> Vec<String> {
    crate::expand::locale_units(s, codeset)
}

fn read_char_count(s: &str, codeset: &str) -> usize {
    let bytes = crate::expand::decode_raw_bytes(s);
    let mut count = 0usize;
    let mut i = 0usize;
    while i < bytes.len() {
        let len = if bytes[i] < 0x80 {
            1
        } else if codeset.eq_ignore_ascii_case("BIG5") || codeset.eq_ignore_ascii_case("BIG-5") {
            if i + 1 >= bytes.len() {
                break;
            }
            if (0x81..=0xFE).contains(&bytes[i]) { 2 } else { 1 }
        } else if codeset.eq_ignore_ascii_case("UTF-8") || codeset.eq_ignore_ascii_case("UTF8") {
            let len = if bytes[i] < 0xC0 {
                1
            } else if bytes[i] < 0xE0 {
                2
            } else if bytes[i] < 0xF0 {
                3
            } else if bytes[i] < 0xF8 {
                4
            } else if bytes[i] < 0xFC {
                5
            } else if bytes[i] < 0xFE {
                6
            } else {
                1
            };
            if i + len > bytes.len() {
                break;
            }
            let mut ok = true;
            for j in 1..len {
                if bytes[i + j] < 0x80 || bytes[i + j] >= 0xC0 {
                    ok = false;
                    break;
                }
            }
            if ok { len } else { 1 }
        } else {
            1
        };
        count += 1;
        i += len;
    }
    count
}

fn split_by_ifs(s: &str, ifs: &str) -> Vec<String> {
    if ifs.is_empty() {
        return vec![s.to_string()];
    }
    if !s.contains('\u{FDD1}') {
        let ifs_bytes = crate::expand::decode_raw_bytes(ifs);
        if ifs_bytes.iter().any(|&b| b >= 0x80) {
            let codeset = current_locale_codeset_for_read();
            let units = locale_units_for_read(s, &codeset);
            let ifs_units = locale_units_for_read(ifs, &codeset);
            let is_ws = |unit: &String| {
                let raw = crate::expand::decode_raw_bytes(unit);
                raw.len() == 1 && (raw[0] as char).is_whitespace()
            };
            let ifs_whitespace: Vec<String> = ifs_units.iter().filter(|u| is_ws(u)).cloned().collect();
            let ifs_nonws: Vec<String> = ifs_units.iter().filter(|u| !is_ws(u)).cloned().collect();
            let mut result = Vec::new();
            let mut current = String::new();
            let mut i = 0usize;
            let mut pushed_content = false;

            while i < units.len() && ifs_whitespace.contains(&units[i]) {
                i += 1;
            }

            while i < units.len() {
                let unit = &units[i];
                if ifs_nonws.contains(unit) {
                    result.push(std::mem::take(&mut current));
                    pushed_content = false;
                    i += 1;
                } else if ifs_whitespace.contains(unit) {
                    let had_content = !current.is_empty();
                    if had_content {
                        result.push(std::mem::take(&mut current));
                        pushed_content = true;
                    }
                    while i < units.len() && ifs_whitespace.contains(&units[i]) {
                        i += 1;
                    }
                    if had_content || pushed_content {
                        if i < units.len() && ifs_nonws.contains(&units[i]) {
                            i += 1;
                            pushed_content = false;
                        }
                    }
                } else {
                    current.push_str(unit);
                    i += 1;
                }
            }
            if !current.is_empty() {
                result.push(current);
            }
            return result;
        }
    }
    // Same rule set as expand::word_split, minus CTLESC / FFFE handling
    // (read has already stripped those concerns): a ws-run absorbs an
    // adjacent non-ws IFS char only if it terminated a content-bearing
    // field (or we had pushed content previously).
    let mut result = Vec::new();
    let mut current = String::new();
    let ifs_chars: Vec<char> = ifs.chars().collect();
    let ifs_whitespace: Vec<char> = ifs_chars.iter().filter(|c| c.is_whitespace()).cloned().collect();
    let ifs_nonws: Vec<char> = ifs_chars.iter().filter(|c| !c.is_whitespace()).cloned().collect();

    let mut i = 0usize;
    let chars: Vec<char> = s.chars().collect();
    let mut pushed_content = false;

    // Skip leading IFS whitespace
    while i < chars.len() && ifs_whitespace.contains(&chars[i]) {
        i += 1;
    }

    while i < chars.len() {
        let c = chars[i];
        // READ_ESC marker (\u{FDD1}) from read_until_delimiter — next
        // char is literal, not subject to IFS splitting.
        if c == '\u{FDD1}' && i + 1 < chars.len() {
            current.push(chars[i + 1]);
            i += 2;
            continue;
        }
        if ifs_nonws.contains(&c) {
            result.push(std::mem::take(&mut current));
            pushed_content = false;
            i += 1;
        } else if ifs_whitespace.contains(&c) {
            let had_content = !current.is_empty();
            if had_content {
                result.push(std::mem::take(&mut current));
                pushed_content = true;
            }
            while i < chars.len() && ifs_whitespace.contains(&chars[i]) {
                i += 1;
            }
            if had_content || pushed_content {
                if i < chars.len() && ifs_nonws.contains(&chars[i]) {
                    i += 1;
                    pushed_content = false;
                }
            }
        } else {
            current.push(c);
            i += 1;
        }
    }
    if !current.is_empty() {
        result.push(current);
    }
    result
}

// ---------------------------------------------------------------------------
// let
// ---------------------------------------------------------------------------

fn builtin_let(shell: &mut Shell, args: &[String]) -> i32 {
    let args = if args.first().map(|s| s.as_str()) == Some("--") {
        &args[1..]
    } else {
        args
    };
    if args.is_empty() {
        eprintln!("{}: let: expression expected", shell.err_prefix_with_line());
        return 2;
    }
    let mut last_val: i64 = 0;
    let mut had_error = false;
    let assoc_expand_once = shell.shopt.contains("assoc_expand_once");
    for expr in args {
        let result = if assoc_expand_once {
            crate::arithmetic::eval_expr_mut_no_cmdsub_assoc_once(expr, &mut shell.vars)
        } else {
            crate::arithmetic::eval_expr_mut_no_cmdsub(expr, &mut shell.vars)
        };
        match result {
            Ok(v) => { last_val = v; }
            Err(e) => {
                let prefix = shell.err_prefix_with_line();
                const INNER_PREFIX: &str = "\x00INNER\x00";
                if let Some(start) = e.find(INNER_PREFIX) {
                    let rest = &e[start + INNER_PREFIX.len()..];
                    if let Some(end) = rest.find('\x00') {
                        let payload = &rest[..end];
                        if let Some(sep) = payload.find('\x1F') {
                            let inner_expr = &payload[..sep];
                            let inner_msg = &payload[sep + 1..];
                            // For INNER errors that are arithmetic-evaluation
                            // failures of a subscript value (e.g.
                            // `let "a[\" \"]=18"` where the inner expr is
                            // the literal `" "`, or `let a["$(...)"]+=1`
                            // where the inner expr is the cmd-substitution
                            // result), bash drops the `let:` prefix and
                            // reports just the offending subscript value
                            // and the arithmetic-error message.
                            //
                            // For INNER errors that are subscript-shape
                            // failures (e.g. `let assoc[x],b[$(echo` →
                            // "bad array subscript"), bash keeps the
                            // `let:` prefix to identify the builtin.
                            let trimmed = inner_expr.trim_start();
                            let drop_let_prefix = !inner_msg.contains("bad array subscript");
                            if drop_let_prefix {
                                eprintln!("{}: {}: {}", prefix, trimmed, inner_msg);
                            } else {
                                eprintln!("{}: let: {}: {}", prefix, trimmed, inner_msg);
                            }
                            if expr.contains('[') && inner_msg.contains("operand expected") {
                                shell.abort_current_list_until_newline();
                            }
                            had_error = true;
                            break;
                        }
                    }
                }
                let msg_with_token = synthesize_let_error_token(expr, &e);
                eprintln!("{}: let: {}: {}", prefix, expr, msg_with_token);
                if expr.contains('[') && msg_with_token.contains("operand expected") {
                    shell.abort_current_list_until_newline();
                }
                had_error = true;
                break;
            }
        }
    }
    if had_error { return 1; }
    if last_val == 0 { 1 } else { 0 }
}

/// Synthesize a bash-compatible error token for a `let` arithmetic error.
/// If `msg` already has `(error token is …)`, return as-is.
/// Otherwise derive the token from the expression.
fn synthesize_let_error_token(expr: &str, msg: &str) -> String {
    if msg.contains("(error token is") {
        return msg.to_string();
    }
    if msg.starts_with("arithmetic syntax error: operand expected") {
        let chars: Vec<char> = expr.chars().collect();
        let mut i = chars.len();
        while i > 0 {
            i -= 1;
            if chars[i] != '"' && chars[i] != '\'' {
                continue;
            }
            let quote = chars[i];
            let mut start = i;
            while start > 0 {
                start -= 1;
                if chars[start] == quote && (start == 0 || chars[start - 1] != '\\') {
                    let token: String = chars[start..=i].iter().collect();
                    return format!("{} (error token is \"{}\")", msg, token);
                }
            }
        }
        let trimmed = expr.trim_end();
        if let Some(last_ch) = trimmed.chars().last() {
            if "+-*/%&|^<>!~".contains(last_ch) && trimmed.len() > 1 {
                let op_start = expr.rfind(last_ch).unwrap_or(0);
                let op_tok = &expr[op_start..];
                return format!("{} (error token is \"{}\")", msg, op_tok);
            }
        }
    }
    // For "missing `)'", the token is the last operand before EOF.
    if msg.starts_with("missing `)'") {
        // Find the last operand — last word before EOF
        let tok = expr.trim().split(|c: char| !c.is_alphanumeric() && c != '_' && c != '#')
            .filter(|s| !s.is_empty())
            .last()
            .unwrap_or(expr.trim());
        return format!("{} (error token is \"{}\")", msg, tok);
    }
    msg.to_string()
}

// ---------------------------------------------------------------------------
// trap
// ---------------------------------------------------------------------------

fn builtin_trap(shell: &mut Shell, args: &[String]) -> i32 {
    use crate::trap::TrapHandler;

    // Print all traps (no args)
    if args.is_empty() {
        let traps = shell.traps.list();
        for (sig, action) in traps {
            println!("trap -- '{}' {}", action.replace('\'', "'\\''"), sig);
        }
        return 0;
    }

    let mut idx = 0;
    let mut list_mode = false;
    let mut print_mode = false;     // -p: print in `trap -- 'action' SIG` form
    let mut print_raw_mode = false; // -P: print just action string
    let mut saw_dashdash = false;

    while idx < args.len() && !saw_dashdash {
        let arg = args[idx].as_str();
        if arg == "--" {
            saw_dashdash = true;
            idx += 1;
        } else if arg.starts_with('-') && arg.len() > 1 {
            let flag_chars: Vec<char> = arg[1..].chars().collect();
            let mut valid = true;
            for &ch in &flag_chars {
                match ch {
                    'l' => list_mode = true,
                    'p' => print_mode = true,
                    'P' => print_raw_mode = true,
                    _ => { valid = false; break; }
                }
            }
            if !valid {
                let prefix = shell.err_prefix_with_line();
                eprintln!("{}: trap: {}: invalid option", prefix, arg);
                eprintln!("trap: usage: trap [-Plp] [[action] signal_spec ...]");
                return 1;
            }
            idx += 1;
        } else {
            break;
        }
    }

    // -p and -P together is an error (no usage line for this one)
    if print_mode && print_raw_mode {
        let prefix = shell.err_prefix_with_line();
        eprintln!("{}: trap: cannot specify both -p and -P", prefix);
        return 1;
    }

    let remaining = &args[idx..];

    if list_mode {
        print_signal_list();
        return 0;
    }

    if print_mode {
        // -p: print specific traps in canonical form, or all if no signals given
        if remaining.is_empty() {
            // Print user-set traps
            let traps = shell.traps.list();
            for (sig, action) in traps {
                println!("trap -- '{}' {}", action.replace('\'', "'\\''"), sig);
            }
            // Print startup-ignored signals (shown as empty action)
            let mut startup_ignored: Vec<String> = shell.startup_ignored_signals.iter().cloned().collect();
            startup_ignored.sort();
            for sig in &startup_ignored {
                // Only show if not already in the trap table
                if shell.traps.get(sig).is_none() {
                    let display = TrapHandler::to_display_name(sig);
                    println!("trap -- '' {}", display);
                }
            }
            return 0;
        } else {
            let mut status = 0;
            for sig in remaining {
                // Validate signal name
                if !is_signal_name(sig) {
                    let prefix = shell.err_prefix_with_line();
                    eprintln!("{}: trap: {}: invalid signal specification", prefix, sig);
                    status = 1;
                    continue;
                }
                let internal = TrapHandler::normalise_pub(sig);
                if let Some(action) = shell.traps.get(sig) {
                    let display = TrapHandler::to_display_name(&internal);
                    println!("trap -- '{}' {}", action.replace('\'', "'\\''"), display);
                } else if shell.startup_ignored_signals.contains(&internal) {
                    // Signal was SIG_IGN at startup: show as empty trap
                    let display = TrapHandler::to_display_name(&internal);
                    println!("trap -- '' {}", display);
                }
                // If no trap set and not startup-ignored, print nothing (bash behavior)
            }
            return status;
        }
    }

    if print_raw_mode {
        // -P: print just the action string (one line per signal)
        if remaining.is_empty() {
            let prefix = shell.err_prefix_with_line();
            eprintln!("{}: trap: -P requires at least one signal name", prefix);
            eprintln!("trap: usage: trap [-Plp] [[action] signal_spec ...]");
            return 1;
        }
        for sig in remaining {
            if let Some(action) = shell.traps.get(sig) {
                println!("{}", action);
            }
            // If no trap set, print nothing
        }
        return 0;
    }

    if remaining.is_empty() {
        // No flags, no args: print all traps
        let traps = shell.traps.list();
        for (sig, action) in traps {
            println!("trap -- '{}' {}", action.replace('\'', "'\\''"), sig);
        }
        return 0;
    }

    // trap action signal [signal ...]  — or —  trap - signal [signal ...]
    let action = &remaining[0];
    let signals = &remaining[1..];

    // Handle single-argument forms
    if signals.is_empty() {
        if let Ok(n) = action.parse::<i32>() {
            // trap 0: reset EXIT trap
            if n == 0 {
                shell.traps.remove("EXIT");
                return 0;
            }
            // trap N for an invalid/unknown signal number: print usage (no prefix)
            if TrapHandler::signal_num_to_name(n).is_none() {
                eprintln!("trap: usage: trap [-Plp] [[action] signal_spec ...]");
                return 1;
            }
            // Valid signal number with no action: no-op
            return 0;
        }
        // Single arg that's not a number — action with no signals (no-op)
        return 0;
    }

    // Process each signal
    let mut status = 0;
    for sig in signals {
        if !is_signal_name(sig) {
            let prefix = shell.err_prefix_with_line();
            eprintln!("{}: trap: {}: invalid signal specification", prefix, sig);
            status = 1;
            continue;
        }
        // POSIX: signals ignored at shell startup cannot be trapped or reset.
        let internal_sig = crate::trap::TrapHandler::normalise_pub(sig);
        if shell.startup_ignored_signals.contains(&internal_sig) {
            // Silently ignore attempt to set or reset a startup-ignored signal.
            continue;
        }
        if action == "-" {
            shell.traps.remove(sig);
            // Restore signal to default disposition
            set_signal_handler(&internal_sig, SignalAction::Default);
        } else if action.is_empty() {
            shell.traps.set(sig, action);
            // Empty action: ignore the signal (SIG_IGN)
            set_signal_handler(&internal_sig, SignalAction::Ignore);
        } else {
            shell.traps.set(sig, action);
            // Non-empty action: install the pending-signal recorder so the OS
            // delivers the signal to us (instead of the default action which may
            // terminate the process).
            use crate::trap::TrapHandler;
            if let Some(num) = TrapHandler::signal_name_to_num(&internal_sig) {
                if num > 0 {
                    crate::exec::install_trap_handler(num);
                }
            }
        }
    }

    status
}

enum SignalAction { Default, Ignore }

fn set_signal_handler(internal_name: &str, action: SignalAction) {
    use crate::trap::TrapHandler;
    // Skip pseudo-signals
    if matches!(internal_name, "EXIT" | "DEBUG" | "RETURN" | "ERR") {
        return;
    }
    let num = match TrapHandler::signal_name_to_num(internal_name) {
        Some(n) if n > 0 && n < 128 => n,
        _ => return,
    };
    // Convert number to nix Signal
    let sig = match nix::sys::signal::Signal::try_from(num) {
        Ok(s) => s,
        Err(_) => return,
    };
    // Don't change disposition of signals that cannot be caught/ignored
    use nix::sys::signal::Signal;
    if sig == Signal::SIGKILL || sig == Signal::SIGSTOP {
        return;
    }
    let handler = match action {
        SignalAction::Default => nix::sys::signal::SigHandler::SigDfl,
        SignalAction::Ignore  => nix::sys::signal::SigHandler::SigIgn,
    };
    unsafe { let _ = nix::sys::signal::signal(sig, handler); }
}

fn is_signal_name(s: &str) -> bool {
    let upper = s.to_uppercase();
    let stripped = upper.strip_prefix("SIG").unwrap_or(&upper);
    crate::trap::TrapHandler::signal_name_to_num(stripped).is_some()
        || upper.parse::<i32>().is_ok()
}

// ---------------------------------------------------------------------------
// Function body pretty-printing (bash-compatible format)
// ---------------------------------------------------------------------------

use crate::parser::{Command, FuncDef, CaseTerminator};

/// Quote a value for `declare -p` output.  Uses `$'...'` quoting when the
/// value contains control characters (newline, tab, etc.), otherwise plain
/// double-quote quoting.
/// Quote a value the way `declare` (no -p flag) does — bare when
/// possible (no quotes at all for plain alphanumeric values),
/// $'...' for strings with control chars, "..." otherwise.
fn quote_for_declare_bare(val: &str) -> String {
    if val.chars().any(|c| c.is_control()) {
        // Let the $'...' path in quote_for_declare handle controls.
        return quote_for_declare(val);
    }
    // If the value is "safe" (alphanumeric + common punctuation with
    // no shell-special chars), emit it bare.  Otherwise wrap in "..."
    // with backslash-escape for `"`, `\`, `$`, `` ` ``.
    let is_safe = !val.is_empty() && val.chars().all(|c| {
        c.is_ascii_alphanumeric() || matches!(c,
            '_' | '/' | '.' | ',' | ':' | '-' | '+' | '=' | '@' | '%')
    });
    if is_safe {
        val.to_string()
    } else if val.is_empty() {
        String::new()
    } else {
        quote_for_declare(val)
    }
}

fn quote_for_declare(val: &str) -> String {
    // Detect chars that would force `$'…'` ANSI-C quoting: control
    // characters AND brash's internal PUA-encoded raw bytes (U+F801..U+F8FF
    // are 0x01..0xFF stored as Private-Use chars).  Both should print as
    // octal escapes in bash's $'…' form.
    let needs_dollar_quote = val.chars().any(|c| {
        c.is_control() || matches!(c as u32, 0xF801..=0xF8FF)
    });
    if needs_dollar_quote {
        let mut out = String::from("$'");
        for c in val.chars() {
            match c {
                '\n' => out.push_str("\\n"),
                '\t' => out.push_str("\\t"),
                '\r' => out.push_str("\\r"),
                '\x07' => out.push_str("\\a"),
                '\x08' => out.push_str("\\b"),
                '\x1b' => out.push_str("\\E"),
                '\'' => out.push_str("\\'"),
                '\\' => out.push_str("\\\\"),
                c if c.is_control() => {
                    // Bash emits control chars in $'...' using 3-digit
                    // octal form (`\001`, `\177`, etc.), not `\xNN`.
                    out.push_str(&format!("\\{:03o}", c as u32));
                }
                c if matches!(c as u32, 0xF801..=0xF8FF) => {
                    // PUA-encoded raw byte (high-bit set) — print as
                    // 3-digit octal so it round-trips through the shell.
                    let b = (c as u32) - 0xF800;
                    out.push_str(&format!("\\{:03o}", b));
                }
                c => out.push(c),
            }
        }
        out.push('\'');
        out
    } else {
        // Bash's `declare -p` quotes `$`, `` ` ``, `\`, and `"` even
        // inside the `"..."` wrapping so the output can round-trip
        // through the shell without re-expansion surprises.
        let mut out = String::with_capacity(val.len() + 2);
        out.push('"');
        for c in val.chars() {
            match c {
                '\\' => out.push_str("\\\\"),
                '"' => out.push_str("\\\""),
                '$' => out.push_str("\\$"),
                '`' => out.push_str("\\`"),
                _ => out.push(c),
            }
        }
        out.push('"');
        out
    }
}

/// Quote an associative-array key for `declare -p` output.  Keys
/// composed only of safe identifier-ish characters print bare
/// (`[foo]=value`); anything else is wrapped just like a value
/// (`["a b"]=value`, `["\$foo"]=value`).
fn quote_key_for_declare(key: &str) -> String {
    // "Bare" keys don't need quoting in bash's declare -p output.
    // Bash quotes any key containing `@`, `*`, `!`, `?`, `#`, `$`,
    // spaces, special chars, or that IS `@`/`*`/etc. as a whole.
    let bare = !key.is_empty()
        && key.chars().all(|c| {
            c.is_ascii_alphanumeric()
                || matches!(c, '_' | '+' | '-' | '.' | '/' | ':' | '%' | '=')
        });
    if bare {
        key.to_string()
    } else {
        quote_for_declare(key)
    }
}

/// Format a function definition in bash's canonical display format.
fn format_function_def(func: &FuncDef) -> String {
    let mut out = String::new();
    // Bash prints `function NAME ()` when the name contains `=` (ambiguity
    // with assignment); otherwise uses the shorthand `NAME ()`.
    if func.name.contains('=') {
        out.push_str(&format!("function {} () \n", func.name));
    } else {
        out.push_str(&format!("{} () \n", func.name));
    }
    // Bash always wraps a function's body in `{ ... }` when pretty-printing,
    // even if the body is a subshell or a single simple command.  If the
    // body is already a Group we emit it directly; otherwise wrap it.
    match &*func.body {
        Command::Group(_) => {
            format_command_into(&mut out, &func.body, 0);
        }
        _ => {
            out.push_str("{ \n");
            format_command_into(&mut out, &func.body, 1);
            out.push_str("\n}");
        }
    }
    // Append any redirects applied to the function itself.
    let trail = format_redirects_trail(&func.redirects);
    out.push_str(&trail);
    out.push('\n');
    out
}

/// Format a single redirect for display (the inline operator+target part only).
/// For heredocs, this emits the `<<DELIM` part; the body is handled separately
/// by `format_heredoc_bodies`.
fn format_redirect(r: &crate::parser::Redirect) -> String {
    use crate::lexer::RedirectOp;
    // Bash pretty-prints dup/bi-directional redirects with their fd always
    // explicit (e.g. `1>&2` not `>&2`).  For other operators, the fd is
    // omitted when it matches the default (0 for input, 1 for output).
    let is_dup_like = matches!(
        r.op,
        RedirectOp::InputDup | RedirectOp::OutputDup | RedirectOp::InputOutput
    );
    let default_fd = match &r.op {
        RedirectOp::Input | RedirectOp::InputDup | RedirectOp::InputOutput
        | RedirectOp::Heredoc | RedirectOp::HeredocStrip | RedirectOp::HereString => 0,
        _ => 1,
    };
    let fd_prefix = if let Some(varname) = r.varfd.as_ref() {
        format!("{{{}}}", varname)
    } else {
        match r.fd {
            Some(fd) => {
                if is_dup_like || fd != default_fd {
                    fd.to_string()
                } else {
                    String::new()
                }
            }
            None => {
                if is_dup_like {
                    default_fd.to_string()
                } else {
                    String::new()
                }
            }
        }
    };
    // Bash quirk: `{v}<&-` and `{v}>&-` both close the fd stored in `v`,
    // and bash normalises them to `>&-` in `declare -f` output (since
    // the direction is meaningless once the fd is already captured).
    let normalize_varfd_close = r.varfd.is_some()
        && matches!(r.op, RedirectOp::InputDup)
        && r.target == "-";
    let op_str = if normalize_varfd_close {
        ">&"
    } else {
        match &r.op {
            RedirectOp::Input => "<",
            RedirectOp::Output => ">",
            RedirectOp::Append => ">>",
            RedirectOp::InputDup => "<&",
            RedirectOp::OutputDup => ">&",
            RedirectOp::InputOutput => "<>",
            RedirectOp::Clobber => ">|",
            RedirectOp::AndOutput => "&>",
            RedirectOp::AndAppend => "&>>",
            RedirectOp::Heredoc => "<<",
            RedirectOp::HeredocStrip => "<<-",
            RedirectOp::HereString => "<<<",
        }
    };
    // For heredocs, emit <<DELIM (the delimiter word, not the body).
    if matches!(r.op, RedirectOp::Heredoc | RedirectOp::HeredocStrip) {
        let delim = r.heredoc_delimiter.as_deref().unwrap_or("EOF");
        return format!("{}{}{}", fd_prefix, op_str, delim);
    }
    let target = crate::exec::deparse_procsub_markers(&r.target);
    // For fd-dup operators (>& and <&), bash does not insert a space
    // between the operator and the target (e.g. "2>&1", ">&2", "<&0").
    let needs_space = !matches!(r.op, RedirectOp::InputDup | RedirectOp::OutputDup);
    if needs_space {
        format!("{}{} {}", fd_prefix, op_str, target)
    } else {
        format!("{}{}{}", fd_prefix, op_str, target)
    }
}

/// Emit heredoc bodies for redirects that are heredocs.
/// Returns a string like "\nBODY\nDELIM\n" for each heredoc redirect.
fn format_heredoc_bodies(redirects: &[crate::parser::Redirect]) -> String {
    use crate::lexer::RedirectOp;
    let mut out = String::new();
    for r in redirects {
        if matches!(r.op, RedirectOp::Heredoc | RedirectOp::HeredocStrip) {
            let delim = r.heredoc_delimiter.as_deref().unwrap_or("EOF");
            // r.target contains the heredoc body (may or may not end with \n)
            out.push('\n');
            out.push_str(&r.target);
            // Ensure body ends with newline before delimiter
            if !r.target.ends_with('\n') {
                out.push('\n');
            }
            out.push_str(delim);
            out.push('\n');
        }
    }
    out
}

/// Normalize an assignment's value for declare/type pretty-print.
/// Converts `$'...'` ANSI-C sequences to single-quoted raw-byte form
/// (e.g. `$'\001'` -> `'<SOH>'`, `$'\t'` -> `'<TAB>'`). This matches
/// bash's function body display format.
fn normalize_assignment_value(v: &str) -> String {
    // Only transform values that are exactly a single $'...' token.
    // (Assignments may contain more complex expressions; those are left alone.)
    if let Some(rest) = v.strip_prefix("$'") {
        if let Some(inner) = rest.strip_suffix('\'') {
            let expanded = crate::exec::expand_ansi_c_inner(inner);
            // Single-quote the result, escaping embedded single quotes via '\''
            let mut out = String::from("'");
            for ch in expanded.chars() {
                if ch == '\'' {
                    out.push_str("'\\''");
                } else {
                    out.push(ch);
                }
            }
            out.push('\'');
            return out;
        }
    }
    v.to_string()
}

/// Normalize a word for display: trim spaces inside $( ) command substitutions,
/// and add a space after `<` in file-read substitutions `$(<file)` → `$(< file)`.
fn normalize_word(w: &str) -> String {
    let deparsed = crate::exec::deparse_procsub_markers(w);
    if let Some(rest) = deparsed.strip_prefix("$(") {
        if let Some(inner) = rest.strip_suffix(')') {
            let trimmed = inner.trim();
            // $(<file) is a bash file-read substitution — display with a space
            if let Some(file) = trimmed.strip_prefix('<') {
                let file = file.trim();
                return format!("$(< {})", file);
            }
            return format!("$({})", trimmed);
        }
    }
    deparsed
}

/// Format redirects for a compound command as a trailing string (space-prefixed).
fn format_redirects_trail(redirects: &[crate::parser::Redirect]) -> String {
    if redirects.is_empty() {
        return String::new();
    }
    let mut s = String::new();
    for r in redirects {
        s.push(' ');
        s.push_str(&format_redirect(r));
    }
    s
}

/// Check whether a command ends (in its trailing position) with a heredoc
/// body that produces a newline-terminated output. When true, the command's
/// formatted output already ends with a newline and should NOT get an
/// additional ';' terminator when followed by a sibling command.
///
/// This recurses into compound command bodies: `for ... done` where the
/// final statement in the body has a heredoc also counts, because bash
/// emits `done` on a new line in that case without a trailing `;`.
fn cmd_has_heredoc(cmd: &Command) -> bool {
    use crate::lexer::RedirectOp;
    match cmd {
        Command::Simple(sc) => sc.redirects.iter().any(|r|
            matches!(r.op, RedirectOp::Heredoc | RedirectOp::HeredocStrip)),
        Command::List(l) => l.entries.last().map_or(false, |e| cmd_has_heredoc(&e.command)),
        Command::Pipeline(p) => p.commands.last().map_or(false, |c| cmd_has_heredoc(c)),
        Command::For(c) => cmd_has_heredoc(&c.body),
        Command::While(c) => cmd_has_heredoc(&c.body),
        Command::Until(c) => cmd_has_heredoc(&c.body),
        Command::ArithFor(c) => cmd_has_heredoc(&c.body),
        Command::Select(c) => cmd_has_heredoc(&c.body),
        _ => false,
    }
}

fn needs_blank_line_after_list_entry(cmd: &Command) -> bool {
    match cmd {
        Command::If(_)
        | Command::While(_)
        | Command::Until(_)
        | Command::For(_)
        | Command::Case(_)
        | Command::Select(_) => true,
        Command::Time(_, inner) | Command::Not(inner) => needs_blank_line_after_list_entry(inner),
        _ => false,
    }
}

fn body_entry_prefers_inline_follow(cmd: &Command) -> bool {
    match cmd {
        Command::Select(_) => true,
        Command::Time(_, inner) | Command::Not(inner) => body_entry_prefers_inline_follow(inner),
        _ => false,
    }
}

/// Format the body of a compound command where every statement — including the
/// last — gets a trailing semicolon (used for while/for/until/if bodies).
/// Commands that end with heredoc bodies get a newline (empty line) instead of ';'.
fn format_body_with_semis(out: &mut String, cmd: &Command, indent: usize) {
    match cmd {
        Command::List(l) => {
            let mut inline = false;
            for (i, entry) in l.entries.iter().enumerate() {
                let is_last = i + 1 == l.entries.len();
                let cur_indent = if inline { 0 } else { indent };
                match entry.op {
                    crate::parser::ListOp::And => {
                        format_command_into(out, &entry.command, cur_indent);
                        out.push_str(" && ");
                        inline = true;
                    }
                    crate::parser::ListOp::Or => {
                        format_command_into(out, &entry.command, cur_indent);
                        out.push_str(" || ");
                        inline = true;
                    }
                    crate::parser::ListOp::Amp => {
                        format_command_into(out, &entry.command, cur_indent);
                        out.push_str(" &");
                        if !is_last { out.push('\n'); }
                        inline = true;
                    }
                    _ => {
                        let join_inline = !is_last && body_entry_prefers_inline_follow(&entry.command);
                        format_command_into(out, &entry.command, cur_indent);
                        if cmd_has_heredoc(&entry.command) {
                            // Heredoc body already ends with \n — just add blank line
                            if !is_last { out.push('\n'); }
                        } else {
                            out.push(';');
                            if !is_last {
                                if join_inline {
                                    out.push(' ');
                                } else {
                                    out.push('\n');
                                }
                            }
                        }
                        inline = join_inline;
                    }
                }
            }
        }
        _ => {
            format_command_into(out, cmd, indent);
            if !cmd_has_heredoc(cmd) {
                out.push(';');
            }
        }
    }
}

fn format_condition_keyword(out: &mut String, condition: &Command, keyword: &str, keyword_pad: &str) {
    if cmd_has_heredoc(condition) {
        out.push_str(keyword_pad);
        out.push_str(keyword);
        out.push('\n');
    } else {
        out.push_str("; ");
        out.push_str(keyword);
        out.push('\n');
    }
}

/// Recursively format a Command AST node into `out` with the given indentation.
pub fn format_command_into_pub(out: &mut String, cmd: &Command, indent: usize) {
    format_command_into(out, cmd, indent)
}

fn format_command_into(out: &mut String, cmd: &Command, indent: usize) {
    let pad = "    ".repeat(indent);
    match cmd {
        Command::Simple(sc) => {
            let mut parts: Vec<String> = Vec::new();
            for a in &sc.assignments {
                let v = normalize_assignment_value(&a.value);
                if a.append {
                    parts.push(format!("{}+={}", a.name, v));
                } else {
                    parts.push(format!("{}={}", a.name, v));
                }
            }
            for w in &sc.words {
                parts.push(normalize_word(w));
            }
            // Append redirections (heredoc redirects emit only the <<DELIM part inline)
            for r in &sc.redirects {
                parts.push(format_redirect(r));
            }
            out.push_str(&pad);
            out.push_str(&parts.join(" "));
            // Append heredoc bodies immediately after the command line
            out.push_str(&format_heredoc_bodies(&sc.redirects));
        }
        Command::Group(g) => {
            out.push_str(&format!("{}{{ \n", pad));
            format_command_into(out, &g.body, indent + 1);
            let trail = format_redirects_trail(&g.redirects);
            out.push_str(&format!("\n{}}}{}", pad, trail));
        }
        Command::Subshell(s) => {
            // If body is a Group, render multiline; otherwise inline.
            match s.body.as_ref() {
                Command::Group(g) => {
                    out.push_str(&format!("{}( {{ \n", pad));
                    format_command_into(out, &g.body, indent + 1);
                    let g_trail = format_redirects_trail(&g.redirects);
                    let s_trail = format_redirects_trail(&s.redirects);
                    out.push_str(&format!("\n{}}} ){}{}", pad, g_trail, s_trail));
                }
                _ => {
                    out.push_str(&format!("{}( ", pad));
                    format_command_into(out, &s.body, 0);
                    let trail = format_redirects_trail(&s.redirects);
                    out.push_str(&format!(" ){}", trail));
                }
            }
        }
        Command::Pipeline(p) => {
            for (i, c) in p.commands.iter().enumerate() {
                if i > 0 {
                    if p.pipe_stderr.get(i - 1).copied().unwrap_or(false) {
                        out.push_str(" 2>&1 | ");
                    } else {
                        out.push_str(" | ");
                    }
                }
                if i == 0 && p.negated {
                    out.push_str(&format!("{}! ", pad));
                    format_command_into(out, c, 0);
                } else {
                    format_command_into(out, c, if i == 0 { indent } else { 0 });
                }
            }
        }
        Command::List(l) => {
            // Track whether the next entry is inline (no leading indent).
            // Inline = previous entry had op And/Or/Amp (continuation on same line).
            let mut inline = false;
            for (i, entry) in l.entries.iter().enumerate() {
                let is_last = i + 1 == l.entries.len();
                let cur_indent = if inline { 0 } else { indent };
                match entry.op {
                    crate::parser::ListOp::And => {
                        format_command_into(out, &entry.command, cur_indent);
                        out.push_str(" && ");
                        inline = true;
                    }
                    crate::parser::ListOp::Or => {
                        format_command_into(out, &entry.command, cur_indent);
                        out.push_str(" || ");
                        inline = true;
                    }
                    crate::parser::ListOp::Amp => {
                        format_command_into(out, &entry.command, cur_indent);
                        out.push_str(" &");
                        if !is_last { out.push(' '); }
                        inline = true;
                    }
                    _ => {
                        format_command_into(out, &entry.command, cur_indent);
                        if cmd_has_heredoc(&entry.command) {
                            if !is_last { out.push('\n'); }
                        } else if !is_last {
                            if indent == 0
                                && matches!(entry.op, crate::parser::ListOp::Newline)
                                && needs_blank_line_after_list_entry(&entry.command)
                            {
                                out.push_str("\n\n");
                            } else {
                                out.push_str(";\n");
                            }
                        }
                        inline = false;
                    }
                }
            }
        }
        Command::Time(posix, inner) => {
            let flag = if *posix { "-p " } else { "" };
            out.push_str(&format!("{}time {}", pad, flag));
            format_command_into(out, inner, 0);
        }
        Command::Not(inner) => {
            out.push_str(&format!("{}! ", pad));
            format_command_into(out, inner, 0);
        }
        Command::If(c) => {
            out.push_str(&format!("{}if ", pad));
            format_command_into(out, &c.condition, 0);
            format_condition_keyword(out, &c.condition, "then", &pad);
            format_body_with_semis(out, &c.then_body, indent + 1);
            // Render elif parts as nested else { if ... }
            // Render elif parts as nested: else { if COND; then BODY }
            // Each elif opens one more level of nesting.
            // 'else' is at the same indent as the outer 'if' (indent + ei).
            // The nested 'if' is at indent + ei + 1.
            let elif_count = c.elif_parts.len();
            for (ei, (cond, body)) in c.elif_parts.iter().enumerate() {
                let else_pad = "    ".repeat(indent + ei);
                let nested_if_indent = indent + ei + 1;
                out.push_str(&format!("\n{}else\n", else_pad));
                out.push_str(&format!("{}if ", "    ".repeat(nested_if_indent)));
                format_command_into(out, cond, 0);
                format_condition_keyword(out, cond, "then", &else_pad);
                format_body_with_semis(out, body, nested_if_indent + 1);
            }
            if let Some(ref eb) = c.else_body {
                let else_pad = "    ".repeat(indent + elif_count);
                let else_body_indent = indent + elif_count + 1;
                out.push_str(&format!("\n{}else\n", else_pad));
                format_body_with_semis(out, eb, else_body_indent);
            }
            // Close nested ifs from elif expansion (innermost first)
            for ei in (0..elif_count).rev() {
                let fi_pad = "    ".repeat(indent + ei + 1);
                out.push_str(&format!("\n{}fi;", fi_pad));
            }
            let trail = format_redirects_trail(&c.redirects);
            out.push_str(&format!("\n{}fi{}", pad, trail));
        }
        Command::While(c) => {
            out.push_str(&format!("{}while ", pad));
            format_command_into(out, &c.condition, 0);
            format_condition_keyword(out, &c.condition, "do", &pad);
            format_body_with_semis(out, &c.body, indent + 1);
            let trail = format_redirects_trail(&c.redirects);
            out.push_str(&format!("\n{}done{}", pad, trail));
        }
        Command::Until(c) => {
            out.push_str(&format!("{}until ", pad));
            format_command_into(out, &c.condition, 0);
            format_condition_keyword(out, &c.condition, "do", &pad);
            format_body_with_semis(out, &c.body, indent + 1);
            let trail = format_redirects_trail(&c.redirects);
            out.push_str(&format!("\n{}done{}", pad, trail));
        }
        Command::For(c) => {
            out.push_str(&format!("{}for {} in", pad, c.var));
            if let Some(ref words) = c.words {
                for w in words {
                    out.push(' ');
                    out.push_str(&normalize_word(w));
                }
            }
            out.push_str(&format!(";\n{}do\n", pad));
            format_body_with_semis(out, &c.body, indent + 1);
            let trail = format_redirects_trail(&c.redirects);
            out.push_str(&format!("\n{}done{}", pad, trail));
        }
        Command::Case(c) => {
            // Trailing space after "in" matches bash's output format
            out.push_str(&format!("{}case {} in \n", pad, c.word));
            let arm_pad = "    ".repeat(indent + 1);
            for arm in &c.arms {
                let pat = arm.patterns.join(" | ");
                out.push_str(&format!("{}{})\n", arm_pad, pat));
                if let Some(ref body) = arm.body {
                    format_command_into(out, body, indent + 2);
                    out.push('\n');
                }
                match arm.terminator {
                    CaseTerminator::Break => out.push_str(&format!("{};;", arm_pad)),
                    CaseTerminator::FallThrough => out.push_str(&format!("{};&", arm_pad)),
                    CaseTerminator::Continue => out.push_str(&format!("{};;&", arm_pad)),
                }
                out.push('\n');
            }
            let trail = format_redirects_trail(&c.redirects);
            out.push_str(&format!("{}esac{}", pad, trail));
        }
        Command::FuncDef(f) => {
            // Bash pretty-prints nested function definitions (indent > 0)
            // with the `function` keyword for clarity.  Top-level function
            // definitions never carry the keyword prefix in `declare -f`
            // output — those are emitted by `format_function_def` directly.
            if indent > 0 {
                out.push_str(&format!("{}function {} () \n", pad, f.name));
            } else {
                out.push_str(&format!("{}{} () \n", pad, f.name));
            }
            // Emit body wrapped in braces if not already a Group.
            match &*f.body {
                Command::Group(_) => {
                    format_command_into(out, &f.body, indent);
                }
                _ => {
                    out.push_str(&format!("{}{{ \n", pad));
                    format_command_into(out, &f.body, indent + 1);
                    out.push_str(&format!("\n{}}}", pad));
                }
            }
            let trail = format_redirects_trail(&f.redirects);
            out.push_str(&trail);
        }
        Command::ArithEval(expr, _) => {
            out.push_str(&format!("{}(( {} ))", pad, expr.trim()));
        }
        Command::ArithFor(c) => {
            // Note: `declare -f` / `typeset -f` uses a DIFFERENT format
            // than `--pretty-print`: the former keeps `)); do` on one
            // line, the latter puts `do` on its own line.  This
            // format_command_into is shared by both, so we pick the
            // `declare -f` format (arith-for test expects it) and
            // accept a small `--pretty-print` mismatch in invocation
            // for the `for (( ))` case until we can route the formats
            // separately.
            let init = if c.init.trim().is_empty() { "1" } else { c.init.trim() };
            let cond = if c.cond.trim().is_empty() { "1" } else { c.cond.trim() };
            let step = if c.step.trim().is_empty() { "1" } else { c.step.trim() };
            let close_pad = if c.step.trim().is_empty() { "" } else { " " };
            out.push_str(&format!("{}for (({}; {}; {}{}))\n{}do\n", pad, init, cond, step, close_pad, pad));
            format_body_with_semis(out, &c.body, indent + 1);
            let trail = format_redirects_trail(&c.redirects);
            out.push_str(&format!("\n{}done{}", pad, trail));
        }
        Command::Select(c) => {
            out.push_str(&format!("{}select {} in", pad, c.var));
            if let Some(ref words) = c.words {
                for w in words {
                    out.push(' ');
                    out.push_str(w);
                }
            }
            // Bash breaks the `do` onto its own line for select (like
            // `for VAR in WORDS; do` → `select VAR in WORDS;\n    do`).
            out.push_str(&format!(";\n{}do\n", pad));
            format_body_with_semis(out, &c.body, indent + 1);
            let trail = format_redirects_trail(&c.redirects);
            out.push_str(&format!("\n{}done{}", pad, trail));
        }
        Command::Coproc(c) => {
            // For simple-command bodies, omit the coproc name (bash behavior).
            // For compound bodies (group/subshell), print the name (or COPROC default).
            let is_simple = matches!(c.body.as_ref(), Command::Simple(_));
            if is_simple {
                out.push_str(&format!("{}coproc ", pad));
                format_command_into(out, &c.body, 0);
            } else {
                let name = c.name.as_deref().unwrap_or("COPROC");
                out.push_str(&format!("{}coproc {} ", pad, name));
                // If the body is a Group, render it inline: "{ \n    BODY\n    }"
                // at the current indent level (the `{` follows the `coproc NAME ` prefix).
                if let Command::Group(g) = c.body.as_ref() {
                    out.push_str("{ \n");
                    format_command_into(out, &g.body, indent + 1);
                    let trail = format_redirects_trail(&g.redirects);
                    out.push_str(&format!("\n{}}}{}", pad, trail));
                } else {
                    format_command_into(out, &c.body, 0);
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------
// type
// ---------------------------------------------------------------------------

fn builtin_type(shell: &mut Shell, args: &[String]) -> i32 {
    let mut type_word = false;
    let mut all = false;
    let mut path_only = false;
    let mut force_path = false;
    let mut idx = 0;

    while idx < args.len() {
        let a = args[idx].as_str();
        if !a.starts_with('-') || a == "--" {
            if a == "--" { idx += 1; }
            break;
        }
        // Parse combined flags like -at, -tp, etc.
        let flags = &a[1..];
        let mut valid = true;
        for ch in flags.chars() {
            match ch {
                't' => type_word = true,
                'a' => all = true,
                'p' => path_only = true,
                'P' => force_path = true,
                'f' => {} // -f: suppress function lookup (not implemented, accept silently)
                _ => { valid = false; break; }
            }
        }
        if !valid {
            // Invalid option: emit bash-style error
            eprintln!("{}: type: {}: invalid option", shell.err_prefix_with_line(), a);
            eprintln!("type: usage: type [-afptP] name [name ...]");
            return 2;
        }
        idx += 1;
    }

    let expand_aliases = shell.shopt.contains("expand_aliases");
    let mut status = 0;

    for name in &args[idx..] {
        if force_path || path_only {
            // -p or -P: print path only (hash table first, then PATH search)
            let was_hashed = shell.hash_table.contains_key(name.as_str());
            if let Some(p) = find_hashed_or_path(shell, name) {
                if was_hashed {
                    *shell.hash_hits.entry(name.clone()).or_insert(0) += 1;
                }
                println!("{}", p);
            } else {
                status = 1;
            }
            continue;
        }

        if all {
            // -a: list all occurrences in order: alias, keyword, function, builtin, file(s)
            let mut found = false;
            if expand_aliases {
                if let Some(a) = shell.aliases.get(name.as_str()) {
                    if type_word { println!("alias"); } else { println!("{} is aliased to `{}'", name, a); }
                    found = true;
                }
            }
            if is_keyword(name) {
                if type_word { println!("keyword"); } else { println!("{} is a shell keyword", name); }
                found = true;
            }
            // Helpers: emit builtin/function lines at the right spots.
            let posix_special = shell.posix_mode && is_posix_special_builtin(name);
            let emit_builtin = |special: bool| {
                if type_word {
                    println!("builtin");
                } else if special {
                    println!("{} is a special shell builtin", name);
                } else {
                    println!("{} is a shell builtin", name);
                }
            };
            let print_function = |shell: &Shell| {
                if type_word {
                    println!("function");
                } else {
                    println!("{} is a function", name);
                    if let Some(func) = shell.functions.get(name.as_str()) {
                        let func = func.clone();
                        print!("{}", format_function_def(&func));
                    }
                }
            };
            // In POSIX mode, special builtins are listed before functions;
            // bash does NOT then repeat the entry as "shell builtin".
            // Outside POSIX, functions come first, then the builtin.
            if posix_special {
                emit_builtin(true);
                found = true;
                if shell.functions.contains_key(name.as_str()) {
                    print_function(shell);
                }
            } else {
                if shell.functions.contains_key(name.as_str()) {
                    print_function(shell);
                    found = true;
                }
                if is_builtin_enabled(shell, name) {
                    emit_builtin(false);
                    found = true;
                }
            }
            // Find all PATH occurrences
            let path_var = shell.get_var("PATH").unwrap_or_else(|| "/usr/bin:/bin".to_string());
            if name.contains('/') {
                if std::path::Path::new(name.as_str()).is_file() {
                    if type_word { println!("file"); } else { println!("{} is {}", name, name); }
                    found = true;
                }
            } else {
                for dir in path_var.split(':') {
                    let candidate = format!("{}/{}", dir, name);
                    if std::path::Path::new(&candidate).is_file() {
                        if type_word { println!("file"); } else { println!("{} is {}", name, candidate); }
                        found = true;
                    }
                }
            }
            if !found {
                eprintln!("{}: type: {}: not found", shell.err_prefix_with_line(), name);
                status = 1;
            }
            continue;
        }

        // Default: first match wins
        let kind = get_type(shell, name, expand_aliases);

        let posix_mode = shell.posix_mode;
        if type_word {
            match kind {
                TypeResult::Builtin(_) => println!("builtin"),
                TypeResult::Function(_) => println!("function"),
                TypeResult::Alias(_) => println!("alias"),
                TypeResult::File(_) => {
                    // If command is in the hash table, incur a "hit" for the lookup
                    if shell.hash_table.contains_key(name.as_str()) {
                        *shell.hash_hits.entry(name.clone()).or_insert(0) += 1;
                    }
                    println!("file");
                }
                TypeResult::NotFound => { status = 1; }
                TypeResult::Keyword(_) => println!("keyword"),
            }
        } else {
            match kind {
                TypeResult::Builtin(_) => {
                    if posix_mode && is_posix_special_builtin(name) {
                        println!("{} is a special shell builtin", name);
                    } else {
                        println!("{} is a shell builtin", name);
                    }
                }
                TypeResult::Function(_) => {
                    println!("{} is a function", name);
                    if let Some(func) = shell.functions.get(name.as_str()) {
                        let func = func.clone();
                        print!("{}", format_function_def(&func));
                    }
                }
                TypeResult::Alias(a) => println!("{} is aliased to `{}'", name, a),
                TypeResult::File(ref p) => {
                    // If command is in the hash table, show "hashed" format
                    if shell.hash_table.contains_key(name.as_str()) {
                        // Incur a "hit" for the hash lookup
                        *shell.hash_hits.entry(name.clone()).or_insert(0) += 1;
                        println!("{} is hashed ({})", name, p);
                    } else {
                        println!("{} is {}", name, p);
                    }
                }
                TypeResult::NotFound => {
                    eprintln!("{}: type: {}: not found", shell.err_prefix_with_line(), name);
                    status = 1;
                }
                TypeResult::Keyword(k) => println!("{} is a shell keyword", k),
            }
        }
    }
    status
}

/// Look up a command name: check hash table first, then search PATH.
fn find_hashed_or_path(shell: &Shell, name: &str) -> Option<String> {
    if let Some(p) = shell.hash_table.get(name) {
        return Some(p.clone());
    }
    find_in_path(shell, name)
}

// The String payloads on Builtin/Function variants would carry the
// resolved canonical name; today the `type` builtin just reports the
// classification and looks up the body separately.  Keep the field
// shape so a future `type -t -p NAME` overhaul has somewhere to put
// the resolved string.
#[allow(dead_code)]
enum TypeResult {
    Builtin(String),
    Function(String),
    Alias(String),
    File(String),
    Keyword(String),
    NotFound,
}

/// Look up the type of a name. `expand_aliases` controls whether aliases are checked.
fn get_type(shell: &Shell, name: &str, expand_aliases: bool) -> TypeResult {
    // Check alias (only when expand_aliases is on)
    if expand_aliases {
        if let Some(a) = shell.aliases.get(name) {
            return TypeResult::Alias(a.clone());
        }
    }
    // Check keyword
    if is_keyword(name) {
        return TypeResult::Keyword(name.to_string());
    }
    // POSIX mode: special builtins take precedence over functions.
    if shell.posix_mode && is_posix_special_builtin(name) {
        return TypeResult::Builtin(name.to_string());
    }
    // Default mode: functions take precedence over (non-special) builtins.
    if shell.functions.contains_key(name) {
        return TypeResult::Function(name.to_string());
    }
    // Check builtin
    if is_builtin_enabled(shell, name) {
        return TypeResult::Builtin(name.to_string());
    }
    // Search hash table then PATH
    if let Some(p) = find_hashed_or_path(shell, name) {
        TypeResult::File(p)
    } else {
        TypeResult::NotFound
    }
}

fn is_keyword(name: &str) -> bool {
    matches!(name,
        "if" | "then" | "else" | "elif" | "fi" | "case" | "esac" | "for" | "in"
        | "while" | "until" | "do" | "done" | "function" | "select" | "time"
        | "coproc" | "{" | "}" | "!" | "[[" | "]]" | "((" | "))"
    )
}

pub fn is_posix_special_builtin(name: &str) -> bool {
    matches!(name,
        "." | ":" | "break" | "continue" | "eval" | "exec" | "exit"
        | "export" | "readonly" | "return" | "set" | "shift" | "times" | "trap" | "unset"
    )
}

// ---------------------------------------------------------------------------
// command
// ---------------------------------------------------------------------------

fn builtin_command(shell: &mut Shell, args: &[String]) -> i32 {
    if args.is_empty() {
        return 0;
    }

    let mut verbose = false;
    let mut which_mode = false;
    let mut default_path = false;
    let mut idx = 0;

    while idx < args.len() {
        match args[idx].as_str() {
            "-v" => { which_mode = true; idx += 1; }
            "-V" => { verbose = true; idx += 1; }
            "-p" => {
                if shell.restricted {
                    eprintln!("{}: command: -p: restricted", shell.err_prefix_with_line());
                    return 1;
                }
                default_path = true; idx += 1;
            }
            "--" => { idx += 1; break; }
            a if a.starts_with('-') && a.len() > 1 => {
                // Unknown short option — bash rejects with the 2-line form.
                let ch = a.chars().nth(1).unwrap_or('?');
                eprintln!("{}: command: -{}: invalid option",
                    shell.err_prefix_with_line(), ch);
                eprintln!("command: usage: command [-pVv] command [arg ...]");
                return 2;
            }
            _ => break,
        }
    }

    let _ = default_path;

    let expand_aliases = shell.shopt.contains("expand_aliases");

    if which_mode || verbose {
        let mut status = 0;
        for name in &args[idx..] {
            match get_type(shell, name, expand_aliases) {
                TypeResult::File(p) => {
                    if verbose { println!("{} is {}", name, p); }
                    else { println!("{}", p); }
                }
                TypeResult::Builtin(_) => {
                    if verbose {
                        if shell.posix_mode && is_posix_special_builtin(name) {
                            println!("{} is a special shell builtin", name);
                        } else {
                            println!("{} is a shell builtin", name);
                        }
                    } else { println!("{}", name); }
                }
                TypeResult::Function(_) => {
                    if verbose {
                        println!("{} is a function", name);
                        if let Some(func) = shell.functions.get(name.as_str()) {
                            let func = func.clone();
                            print!("{}", format_function_def(&func));
                        }
                    } else {
                        println!("{}", name);
                    }
                }
                TypeResult::Alias(a) => {
                    if verbose { println!("{} is aliased to `{}'", name, a); }
                    else { println!("alias {}='{}'", name, a); }
                }
                TypeResult::Keyword(k) => {
                    if verbose { println!("{} is a shell keyword", k); }
                    else { println!("{}", k); }
                }
                TypeResult::NotFound => {
                    if verbose {
                        eprintln!("{}: command: {}: not found", shell.err_prefix_with_line(), name);
                    }
                    // -v is silent on not-found (POSIX)
                    status = 1;
                }
            }
        }
        return status;
    }

    // Run command bypassing functions and aliases
    if args[idx..].is_empty() {
        return 0;
    }

    // Build args for direct execution
    let cmd_args: Vec<String> = args[idx..].to_vec();
    if is_builtin_enabled(shell, &cmd_args[0]) {
        if cmd_args[0] == "exec" && cmd_args.len() == 1 {
            shell.exec_redirects_permanent = true;
        }
        let saved_exit_flag = shell.exit_flag;
        let saved_return_flag = shell.return_flag;
        let saved = shell.suppress_special_builtin_fatal;
        shell.suppress_special_builtin_fatal = true;
        let rc = run(shell, &cmd_args, &cmd_args);
        shell.suppress_special_builtin_fatal = saved;
        shell.exit_flag = saved_exit_flag;
        shell.return_flag = saved_return_flag;
        return rc;
    }
    // Try to exec external directly (bypass function lookup, use path directly)
    if let Some(path) = find_in_path(shell, &cmd_args[0]) {
        let mut full_args = cmd_args.clone();
        full_args[0] = path;
        // Use run_external to avoid double ERR trap firing (run_string would
        // cause execute_simple to fire ERR trap after we return).
        shell.run_external_pub(&full_args, &[], &[], false)
    } else {
        // Bash's `command NAME` reports the not-found error without the
        // "command:" prefix — just the bare "NAME: command not found"
        // format.  Matches the diagnostic of a plain NAME invocation.
        eprintln!("{}: {}: command not found",
            shell.err_prefix_with_line(), cmd_args[0]);
        127
    }
}

// ---------------------------------------------------------------------------
// builtin
// ---------------------------------------------------------------------------

fn builtin_builtin(shell: &mut Shell, args: &[String]) -> i32 {
    if args.is_empty() {
        return 0;
    }
    let name = &args[0];
    // Handle invalid options (flags that look like options)
    if name.starts_with('-') && name.len() > 1 && name != "--" {
        eprintln!("{}: builtin: {}: invalid option", shell.err_prefix_with_line(), name);
        eprintln!("builtin: usage: builtin [shell-builtin [arg ...]]");
        return 2;
    }
    if !is_builtin(name) {
        eprintln!("{}: builtin: {}: not a shell builtin", shell.err_prefix_with_line(), name);
        return 1;
    }
    // Prepend name back as args[0]
    let mut full_args = vec![name.clone()];
    full_args.extend_from_slice(&args[1..]);
    run(shell, &full_args, &full_args)
}

// ---------------------------------------------------------------------------
// alias / unalias
// ---------------------------------------------------------------------------

/// Check if a character is invalid in an alias name (matching bash 5.3 behavior).
fn is_invalid_alias_char(c: char) -> bool {
    matches!(c, '"' | '$' | '&' | '\'' | '(' | ')' | '/' | ';' | '<' | '>' | '\\' | '`' | '|' | ' ' | '\t' | '\n')
}

fn builtin_alias(shell: &mut Shell, args: &[String]) -> i32 {
    if args.is_empty() || (args.len() == 1 && args[0] == "-p") {
        // Print all aliases
        let mut names: Vec<String> = shell.aliases.keys().cloned().collect();
        names.sort();
        for name in names {
            let val = shell.aliases.get(&name).unwrap();
            println!("alias {}='{}'", name, val.replace('\'', "'\\''"));
        }
        return 0;
    }

    let mut status = 0;
    for arg in args {
        if arg == "-p" { continue; }
        // Unknown -X flag (not -p): bash prints "alias: -X: invalid option"
        // followed by a usage line on stderr.
        if arg.starts_with('-') && arg != "-" && arg.len() > 1 && !arg.contains('=') {
            eprintln!("{}: alias: {}: invalid option", shell.err_prefix_with_line(), arg);
            eprintln!("alias: usage: alias [-p] [name[=value] ... ]");
            return 2;
        }
        if let Some(eq) = arg.find('=') {
            let name = &arg[..eq];
            let value = &arg[eq + 1..];
            // Validate alias name
            if name.is_empty() || name.chars().any(is_invalid_alias_char) {
                eprintln!("{}: alias: `{}': invalid alias name", shell.err_prefix_with_line(), name);
                status = 1;
            } else {
                shell.aliases.insert(name.to_string(), value.to_string());
            }
        } else {
            // Print specific alias
            match shell.aliases.get(arg.as_str()) {
                Some(val) => println!("alias {}='{}'", arg, val.replace('\'', "'\\''")),
                None => {
                    eprintln!("{}: alias: {}: not found", shell.err_prefix_with_line(), arg);
                    status = 1;
                }
            }
        }
    }
    status
}

fn builtin_unalias(shell: &mut Shell, args: &[String]) -> i32 {
    if args.is_empty() {
        // Bash prints \"unalias: usage: …\" WITHOUT the script prefix.
        eprintln!("unalias: usage: unalias [-a] name [name ...]");
        return 2;
    }
    let mut all = false;
    let mut idx = 0;
    while idx < args.len() {
        let a = args[idx].as_str();
        if a == "-a" { all = true; idx += 1; }
        else if a == "--" { idx += 1; break; }
        else if a.starts_with('-') && a.len() > 1 {
            eprintln!("{}: unalias: {}: invalid option", shell.err_prefix_with_line(), a);
            eprintln!("unalias: usage: unalias [-a] name [name ...]");
            return 2;
        } else {
            break;
        }
    }
    if all {
        shell.aliases.clear();
        return 0;
    }
    let mut status = 0;
    for name in &args[idx..] {
        if shell.aliases.remove(name.as_str()).is_none() {
            eprintln!("{}: unalias: {}: not found", shell.err_prefix_with_line(), name);
            status = 1;
        }
    }
    status
}

// ---------------------------------------------------------------------------
// hash
// ---------------------------------------------------------------------------

fn builtin_hash(shell: &mut Shell, args: &[String]) -> i32 {
    let mut idx = 0;
    let mut has_r = false;
    let mut has_p = false;
    let mut has_l = false;
    let mut has_t = false;
    let mut pathname = String::new();

    while idx < args.len() {
        match args[idx].as_str() {
            "-r" => { has_r = true; idx += 1; }
            "-p" => {
                has_p = true;
                idx += 1;
                if idx < args.len() {
                    pathname = args[idx].clone();
                    idx += 1;
                } else {
                    eprintln!("{}: hash: -p: option requires an argument",
                        shell.err_prefix_with_line());
                    eprintln!("hash: usage: hash [-lr] [-p pathname] [-dt] [name ...]");
                    return 2;
                }
            }
            "-d" => {
                idx += 1;
                if idx >= args.len() {
                    eprintln!("{}: hash: -d: option requires an argument",
                        shell.err_prefix_with_line());
                    return 2;
                }
                let mut status = 0;
                while idx < args.len() {
                    if shell.hash_table.remove(&args[idx]).is_none() {
                        eprintln!("{}: hash: {}: not found",
                            shell.err_prefix_with_line(), args[idx]);
                        status = 1;
                    }
                    shell.hash_hits.remove(&args[idx]);
                    idx += 1;
                }
                return status;
            }
            "-l" => { has_l = true; idx += 1; }
            "-t" => { has_t = true; idx += 1; }
            "--" => { idx += 1; break; }
            s if s.starts_with('-') && s.len() >= 2 => {
                // Combined short flags (e.g. -lt).  Any unknown char
                // reports as "hash: -X: invalid option"; known
                // arg-taking flags (-p, -d, -t) that appear combined
                // without a value error with "requires an argument".
                for c in s[1..].chars() {
                    match c {
                        'r' => has_r = true,
                        'l' => has_l = true,
                        't' => has_t = true,
                        'p' => {
                            eprintln!("{}: hash: -p: option requires an argument",
                                shell.err_prefix_with_line());
                            eprintln!("hash: usage: hash [-lr] [-p pathname] [-dt] [name ...]");
                            return 2;
                        }
                        'd' => {
                            eprintln!("{}: hash: -d: option requires an argument",
                                shell.err_prefix_with_line());
                            return 2;
                        }
                        _ => {
                            eprintln!("{}: hash: -{}: invalid option",
                                shell.err_prefix_with_line(), c);
                            eprintln!("hash: usage: hash [-lr] [-p pathname] [-dt] [name ...]");
                            return 2;
                        }
                    }
                }
                idx += 1;
            }
            _ => break,
        }
    }

    if has_r {
        shell.hash_table.clear();
        shell.hash_hits.clear();
        return 0;
    }

    if has_p {
        if std::path::Path::new(&pathname).is_dir() {
            eprintln!("{}: hash: {}: Is a directory",
                shell.err_prefix_with_line(), pathname);
            return 1;
        }
        if shell.restricted && pathname.contains('/') {
            eprintln!("{}: hash: {}: restricted", shell.err_prefix_with_line(), pathname);
            return 1;
        }
        if shell.restricted && !pathname.contains('/') {
            // In restricted mode, a bare command name must be found in PATH
            let path_var = shell.get_var("PATH").unwrap_or_default();
            let mut found = false;
            for dir in path_var.split(':') {
                let candidate = format!("{}/{}", dir, &pathname);
                if std::path::Path::new(&candidate).is_file() {
                    found = true;
                    break;
                }
            }
            if !found {
                eprintln!("{}: hash: {}: not found", shell.err_prefix_with_line(), pathname);
                return 1;
            }
        }
        if idx < args.len() {
            // With `set +o hashall`, the command hash is disabled
            // and bash refuses to store new entries.
            if !shell.opts.hashall {
                eprintln!("{}: hash: hashing disabled",
                    shell.err_prefix_with_line());
                return 1;
            }
            // hash -p PATHNAME NAME: store the mapping without checking existence
            let name = args[idx].clone();
            shell.hash_table.insert(name, pathname);
        }
        return 0;
    }

    if has_l || has_t {
        let mut status = 0;
        if idx >= args.len() {
            if has_l {
                for (name, path) in crate::vars::bash_hash_walk_entries(&shell.hash_table) {
                    println!("builtin hash -p {} {}", path, name);
                }
            }
            return 0;
        }
        while idx < args.len() {
            let name = &args[idx];
            if let Some(path) = shell.hash_table.get(name) {
                if has_l {
                    println!("builtin hash -p {} {}", path, name);
                } else {
                    println!("{}", path);
                }
            } else {
                eprintln!("{}: hash: {}: not found",
                    shell.err_prefix_with_line(), name);
                status = 1;
            }
            idx += 1;
        }
        return status;
    }

    // No operands: print the hash table
    if idx >= args.len() {
        if shell.hash_table.is_empty() {
            // Bash prints "hash: hash table empty" to stdout
            // (not stderr) when there's nothing to show.
            println!("hash: hash table empty");
            return 0;
        }
        // Print header + entries in bash's hash-table walk order.
        println!("hits\tcommand");
        for (name, path) in crate::vars::bash_hash_walk_entries(&shell.hash_table) {
            let hits = shell.hash_hits.get(&name).copied().unwrap_or(0);
            println!("{:>4}\t{}", hits, path);
        }
        let _ = has_l;
        return 0;
    }

    // With `set +h` (hashall off), hashing is disabled.  Bash refuses
    // to store new entries and emits "hash: hashing disabled".
    if !shell.opts.hashall && idx < args.len() {
        eprintln!("{}: hash: hashing disabled",
            shell.err_prefix_with_line());
        return 1;
    }

    // Hash named commands (find in PATH and store)
    while idx < args.len() {
        let name = &args[idx];
        let path_var = shell.get_var("PATH").unwrap_or_else(|| "/usr/bin:/bin".to_string());
        let mut found = false;
        for dir in path_var.split(':') {
            let candidate = format!("{}/{}", dir, name);
            if std::path::Path::new(&candidate).is_file() {
                shell.hash_table
                    .insert(name.clone(), normalize_hashed_command_path(&candidate));
                found = true;
                break;
            }
        }
        if !found {
            eprintln!("{}: hash: {}: not found", shell.err_prefix_with_line(), name);
            return 1;
        }
        idx += 1;
    }
    0
}

// ---------------------------------------------------------------------------
// enable
// ---------------------------------------------------------------------------

fn builtin_enable(shell: &mut Shell, args: &[String]) -> i32 {
    // Partial implementation: we don't actually disable/enable builtins,
    // but we support the listing flags used by test-suite scripts.
    //
    //   -p           print all enabled builtins
    //   -s           restrict listing to POSIX special builtins
    //   -n           list disabled builtins (always empty for us)
    //   -a           list both enabled and disabled with state
    // Any combination implies listing; writing names (`enable NAME…`)
    // is a no-op since we have no enable/disable infrastructure.
    let mut pflag = false;
    let mut sflag = false;
    let mut nflag = false;
    let mut aflag = false;
    let mut dflag = false;
    let mut names: Vec<&str> = Vec::new();
    let mut i = 0;
    while i < args.len() {
        let a = &args[i];
        if a == "--" { i += 1; break; }
        if a.starts_with('-') && a.len() > 1 {
            for ch in a[1..].chars() {
                match ch {
                    'p' => pflag = true,
                    's' => sflag = true,
                    'n' => nflag = true,
                    'a' => aflag = true,
                    'f' => {}
                    'd' => dflag = true,
                    _ => {}
                }
            }
            i += 1;
            continue;
        }
        break;
    }
    while i < args.len() {
        names.push(&args[i]);
        i += 1;
    }

    // POSIX special builtins (sorted lexicographically as bash does).
    const SPECIAL: &[&str] = &[
        ".", ":", "break", "continue", "eval", "exec", "exit", "export",
        "readonly", "return", "set", "shift", "source", "times", "trap", "unset",
    ];
    // Regular builtins we implement, listed by name (rough best-effort).
    const REGULAR: &[&str] = &[
        "alias", "bg", "bind", "builtin", "caller", "cd", "command",
        "compgen", "complete", "compopt", "declare", "dirs", "disown",
        "echo", "enable", "false", "fc", "fg", "getopts", "hash", "help",
        "history", "jobs", "kill", "let", "local", "logout", "mapfile",
        "popd", "printf", "pushd", "pwd", "read", "readarray", "shopt",
        "suspend", "test", "[", "true", "type", "typeset", "ulimit",
        "umask", "unalias", "wait",
    ];

    if !names.is_empty() && !pflag && !aflag && !sflag {
        let mut status = 0;
        for name in names {
            if dflag {
                if !is_builtin(name) {
                    eprintln!("{}: enable: {}: not a shell builtin",
                        shell.err_prefix_with_line(), name);
                } else {
                    eprintln!("{}: enable: {}: not dynamically loaded",
                        shell.err_prefix_with_line(), name);
                }
                status = 1;
                continue;
            }
            if !is_builtin(name) {
                // Bash's enable, on systems with dynamic loading, attempts a
                // dlopen of `<name>` followed by dlsym for `<name>_struct`
                // before falling back to "not a shell builtin".  Replicate
                // that probe-and-fail to match bash's stderr exactly.
                #[cfg(unix)]
                {
                    use std::ffi::CString;
                    if let Ok(c_name) = CString::new(name.to_string()) {
                        let handle = unsafe { libc::dlopen(c_name.as_ptr(), libc::RTLD_LAZY) };
                        if !handle.is_null() {
                            let sym = format!("{}_struct", name);
                            if let Ok(c_sym) = CString::new(sym.clone()) {
                                let s = unsafe { libc::dlsym(handle, c_sym.as_ptr()) };
                                if s.is_null() {
                                    eprintln!("{}: enable: cannot find {} in shared object {}: dlsym({:p}, {}): symbol not found",
                                        shell.err_prefix_with_line(), sym, name, handle, sym);
                                }
                            }
                            unsafe { libc::dlclose(handle); }
                        }
                    }
                }
                eprintln!("{}: enable: {}: not a shell builtin",
                    shell.err_prefix_with_line(), name);
                status = 1;
                continue;
            }
            if nflag {
                shell.disabled_builtins.insert(name.to_string());
            } else {
                shell.disabled_builtins.remove(name);
            }
        }
        return status;
    }

    // Listing mode.
    let builtins: Vec<&str> = if sflag {
        SPECIAL.iter().copied().collect()
    } else {
        let mut v: Vec<&str> = SPECIAL.iter().copied()
            .chain(REGULAR.iter().copied())
            .collect();
        v.sort();
        v.dedup();
        v
    };
    if nflag {
        for b in &builtins {
            if shell.disabled_builtins.contains(*b) {
                println!("enable -n {}", b);
            }
        }
        return 0;
    }
    if aflag {
        for b in &builtins {
            if shell.disabled_builtins.contains(*b) {
                println!("enable -n {}", b);
            } else {
                println!("enable {}", b);
            }
        }
        return 0;
    }
    for b in &builtins {
        if !shell.disabled_builtins.contains(*b) {
            println!("enable {}", b);
        }
    }
    0
}

// ---------------------------------------------------------------------------
// shopt
// ---------------------------------------------------------------------------

pub const SHOPT_OPTIONS: &[&str] = &[
    "array_expand_once", "assoc_expand_once", "autocd",
    "bash_source_fullpath", "cdable_vars", "cdspell", "checkhash",
    "checkjobs", "checkwinsize", "cmdhist", "compat31", "compat32", "compat40",
    "compat41", "compat42", "compat43", "compat44", "complete_fullquote",
    "direxpand", "dirspell", "dotglob", "execfail", "expand_aliases",
    "extdebug", "extglob", "extquote", "failglob", "force_fignore",
    "globasciiranges", "globskipdots", "globstar", "gnu_errfmt",
    "histappend", "histreedit", "histverify", "hostcomplete", "huponexit",
    "inherit_errexit", "interactive_comments", "lastpipe", "lithist",
    "localvar_inherit", "localvar_unset", "login_shell", "mailwarn",
    "no_empty_cmd_completion", "nocaseglob", "nocasematch", "noexpand_translation",
    "nullglob", "patsub_replacement", "progcomp", "progcomp_alias",
    "promptvars", "restricted_shell", "shift_verbose", "sourcepath",
    "varredir_close", "xpg_echo",
];

/// Options whose DEFAULT state is on (shopt -s) when the shell starts.
/// All other SHOPT_OPTIONS default off.  Today the per-option defaults
/// are baked into Shell::new() initialisation; this list is the
/// authoritative reference for documentation and the planned
/// `shopt --defaults` reset path.
#[allow(dead_code)]
const SHOPT_DEFAULTS_ON: &[&str] = &[
    "checkwinsize", "cmdhist", "complete_fullquote", "expand_aliases",
    "extquote", "force_fignore", "globasciiranges", "globskipdots",
    "hostcomplete", "interactive_comments", "patsub_replacement",
    "progcomp", "promptvars", "sourcepath",
];

fn builtin_shopt(shell: &mut Shell, args: &[String]) -> i32 {
    let mut set_on = false;
    let mut set_off = false;
    let mut print_mode = false;
    let mut quiet = false;
    let mut use_set_opts = false; // -o: treat names as set -o options
    let mut idx = 0;

    while idx < args.len() {
        let arg = args[idx].as_str();
        match arg {
            "--" => { idx += 1; break; }
            _ if arg.starts_with('-') && arg.len() >= 2 => {
                // Accept combined forms like `-so`, `-pu`.
                // Each char after `-` is one flag.
                for c in arg[1..].chars() {
                    match c {
                        's' => set_on = true,
                        'u' => set_off = true,
                        'p' => print_mode = true,
                        'q' => quiet = true,
                        'o' => use_set_opts = true,
                        _ => {
                            eprintln!("{}: shopt: -{}: invalid option",
                                shell.err_prefix_with_line(), c);
                            eprintln!("shopt: usage: shopt [-pqsu] [-o] [optname ...]");
                            return 2;
                        }
                    }
                }
                idx += 1;
            }
            _ => break,
        }
    }

    let opts_to_process: Vec<String> = args[idx..].to_vec();

    // Cannot set and unset simultaneously
    if set_on && set_off {
        eprintln!("{}: shopt: cannot set and unset shell options simultaneously",
            shell.err_prefix_with_line());
        return 1;
    }

    // -o flag: route to set_option / unset_option (like `set -o name`)
    if use_set_opts {
        if set_on && opts_to_process.is_empty() {
            // `shopt -s -o`: list only currently-on set-o options.
            // `shopt -s -p -o` — same, in `set -o NAME` print form.
            if !quiet {
                for (name, on) in all_set_options(shell) {
                    if !on { continue; }
                    if print_mode {
                        println!("set -o {}", name);
                    } else {
                        println!("{:<15}\ton", name);
                    }
                }
            }
            return 0;
        }
        if set_off && opts_to_process.is_empty() {
            // `shopt -u -o`: list only currently-off set-o options.
            if !quiet {
                for (name, on) in all_set_options(shell) {
                    if on { continue; }
                    if print_mode {
                        println!("set +o {}", name);
                    } else {
                        println!("{:<15}\toff", name);
                    }
                }
            }
            return 0;
        }
        if set_on {
            let all_opts = all_set_options(shell);
            let mut status = 0;
            for opt in &opts_to_process {
                if !all_opts.iter().any(|(name, _)| *name == opt.as_str()) {
                    if !quiet {
                        eprintln!("{}: shopt: {}: invalid option name",
                            shell.err_prefix_with_line(), opt);
                    }
                    status = 1;
                    continue;
                }
                shell.set_option(opt);
            }
            return status;
        }
        if set_off {
            let all_opts = all_set_options(shell);
            let mut status = 0;
            for opt in &opts_to_process {
                if !all_opts.iter().any(|(name, _)| *name == opt.as_str()) {
                    if !quiet {
                        eprintln!("{}: shopt: {}: invalid option name",
                            shell.err_prefix_with_line(), opt);
                    }
                    status = 1;
                    continue;
                }
                shell.unset_option(opt);
            }
            return status;
        }
        // Query mode for -o
        let mut status = 0;
        if opts_to_process.is_empty() {
            // `shopt -o -p` (and plain `shopt -o`) list every set-o
            // option in `set -o NAME` / `set +o NAME` form.
            if print_mode && !quiet {
                print_set_options_reset(shell);
            } else if !print_mode && !quiet {
                print_set_options_with_width(shell, 20);
            }
            return 0;
        }
        let all_opts = all_set_options(shell);
        for opt in &opts_to_process {
            let known = all_opts.iter().find(|(name, _)| *name == opt.as_str());
            let on = known.map(|(_, v)| *v).unwrap_or(false);
            if known.is_none() {
                if !quiet {
                    // `shopt -o` uses "invalid option name" (without the
                    // word "shell").
                    eprintln!("{}: shopt: {}: invalid option name",
                        shell.err_prefix_with_line(), opt);
                }
                status = 1;
                continue;
            }
            if !quiet {
                if print_mode {
                    println!("set {} {}", if on { "-o" } else { "+o" }, opt);
                } else {
                    println!("{:<20}\t{}", opt, if on { "on" } else { "off" });
                }
            }
            if !on { status = 1; }
        }
        return status;
    }

    // `-s -p` / `-u -p`: list-only mode, filter by current state.
    if (set_on || set_off) && print_mode && opts_to_process.is_empty() {
        let mut all: Vec<&str> = SHOPT_OPTIONS.to_vec();
        all.sort();
        for opt in all {
            let on = shell.shopt.contains(opt);
            if set_on && !on { continue; }
            if set_off && on { continue; }
            let flag = if on { "-s" } else { "-u" };
            println!("shopt {} {}", flag, opt);
        }
        return 0;
    }

    if set_on && !print_mode {
        if opts_to_process.is_empty() {
            // `shopt -s` with no names: list all currently-set options.
            if !quiet {
                let mut all: Vec<&str> = SHOPT_OPTIONS.to_vec();
                all.sort();
                const SHOPT_COL: usize = 20;
                for opt in all {
                    if !shell.shopt.contains(opt) { continue; }
                    if opt.len() >= SHOPT_COL {
                        println!("{}\ton", opt);
                    } else {
                        println!("{:<width$}\ton", opt, width = SHOPT_COL);
                    }
                }
            }
            return 0;
        }
        for opt in &opts_to_process {
            if SHOPT_OPTIONS.contains(&opt.as_str()) {
                shell.shopt.insert(opt.clone());
            } else {
                if !quiet {
                    eprintln!("{}: shopt: {}: invalid shell option name", shell.err_prefix_with_line(), opt);
                }
                return 1;
            }
        }
        return 0;
    }

    if set_off && !print_mode {
        if opts_to_process.is_empty() {
            // `shopt -u` with no names: list all currently-unset options.
            if !quiet {
                let mut all: Vec<&str> = SHOPT_OPTIONS.to_vec();
                all.sort();
                const SHOPT_COL: usize = 20;
                for opt in all {
                    if shell.shopt.contains(opt) { continue; }
                    if opt.len() >= SHOPT_COL {
                        println!("{}\toff", opt);
                    } else {
                        println!("{:<width$}\toff", opt, width = SHOPT_COL);
                    }
                }
            }
            return 0;
        }
        for opt in &opts_to_process {
            if SHOPT_OPTIONS.contains(&opt.as_str()) {
                shell.shopt.remove(opt.as_str());
            } else {
                if !quiet {
                    eprintln!("{}: shopt: {}: invalid shell option name", shell.err_prefix_with_line(), opt);
                }
                return 1;
            }
        }
        return 0;
    }

    // Query or print mode
    let mut status = 0;
    if opts_to_process.is_empty() {
        // Print all
        if !quiet {
            let mut all: Vec<&str> = SHOPT_OPTIONS.to_vec();
            all.sort();
            // Bash formats as `%-20s\t%s` — pad to 20 chars, then tab
            // and on/off.  Longer names push the tab out without extra
            // padding.  (The width matches bash 5.3's shopt.c.)
            const SHOPT_COL: usize = 20;
            for opt in all {
                let on = shell.shopt.contains(opt);
                if print_mode {
                    // `-p` format: `shopt -s name` / `shopt -u name`
                    let flag = if on { "-s" } else { "-u" };
                    println!("shopt {} {}", flag, opt);
                } else if opt.len() >= SHOPT_COL {
                    println!("{}\t{}", opt, if on { "on" } else { "off" });
                } else {
                    println!("{:<width$}\t{}", opt, if on { "on" } else { "off" }, width = SHOPT_COL);
                }
            }
        }
    } else {
        for opt in &opts_to_process {
            if !SHOPT_OPTIONS.contains(&opt.as_str()) {
                if !quiet {
                    eprintln!("{}: shopt: {}: invalid shell option name",
                        shell.err_prefix_with_line(), opt);
                }
                status = 1;
                continue;
            }
            let on = shell.shopt.contains(opt.as_str());
            if !quiet {
                if print_mode {
                    let flag = if on { "-s" } else { "-u" };
                    println!("shopt {} {}", flag, opt);
                } else if !set_on && !set_off {
                    const SHOPT_COL: usize = 20;
                    if opt.len() >= SHOPT_COL {
                        println!("{}\t{}", opt, if on { "on" } else { "off" });
                    } else {
                        println!("{:<width$}\t{}",
                            opt, if on { "on" } else { "off" }, width = SHOPT_COL);
                    }
                }
            }
            if !on {
                status = 1;
            }
        }
    }
    status
}

// ---------------------------------------------------------------------------
// getopts
// ---------------------------------------------------------------------------

fn builtin_getopts(shell: &mut Shell, args: &[String]) -> i32 {
    if args.len() < 2 {
        eprintln!("getopts: usage: getopts optstring name [arg ...]");
        return 2;
    }

    // Process getopts' own options: skip past `--`, reject any `-X` flags
    let mut arg_offset = 0;
    while arg_offset < args.len() {
        let a = &args[arg_offset];
        if a == "--" {
            arg_offset += 1;
            break;
        } else if a.starts_with('-') && a.len() > 1 && !a.starts_with(':') {
            eprintln!("{}: getopts: {}: invalid option",
                      shell.err_prefix_with_line(), a);
            eprintln!("getopts: usage: getopts optstring name [arg ...]");
            return 2;
        } else {
            break;
        }
    }

    let remaining = &args[arg_offset..];
    if remaining.len() < 2 {
        eprintln!("getopts: usage: getopts optstring name [arg ...]");
        return 2;
    }

    let optstring = &remaining[0];
    let varname = &remaining[1];

    // Validate variable name - print error but still process the option
    let valid_varname = is_valid_identifier(varname);
    if !valid_varname {
        eprintln!("{}: getopts: `{}': not a valid identifier",
                  shell.err_prefix_with_line(), varname);
    }

    let extra_args: Vec<String> = if remaining.len() > 2 {
        remaining[2..].to_vec()
    } else {
        // Use positional parameters
        (1..=shell.vars.positional_count)
            .map(|i| shell.get_var(&i.to_string()).unwrap_or_default())
            .collect()
    };

    // Get current OPTIND (1-based)
    let optind: usize = shell.get_var("OPTIND")
        .and_then(|s| s.parse().ok())
        .unwrap_or(1);

    let silent = optstring.starts_with(':');
    let opts_str: &str = if silent { &optstring[1..] } else { optstring };

    // Check OPTERR — if 0, suppress error messages (same as silent mode for errors)
    let opterr: i32 = shell.get_var("OPTERR")
        .and_then(|s| s.parse().ok())
        .unwrap_or(1);
    let suppress_errors = silent || opterr == 0;

    // If OPTIND changed externally (e.g. via `typeset OPTIND=1` in a function),
    // reset the internal character index.
    if optind != shell.getopts_last_optind {
        shell.getopts_charindex = 0;
    }

    // Get the character index within the current argument for combined options
    let mut charindex = shell.getopts_charindex;

    let result = getopts_inner(shell, varname, &extra_args, optind, &mut charindex,
                               silent, opts_str, suppress_errors);

    // Update last_optind so next call can detect external changes
    shell.getopts_last_optind = shell.get_var("OPTIND")
        .and_then(|s| s.parse().ok())
        .unwrap_or(1);

    // If variable name is invalid, return 1 even though we processed the option
    if !valid_varname {
        return 1;
    }

    result
}

fn getopts_inner(
    shell: &mut Shell, varname: &str, extra_args: &[String],
    optind: usize, charindex: &mut usize, silent: bool,
    opts_str: &str, suppress_errors: bool,
) -> i32 {
    if optind < 1 || optind > extra_args.len() {
        // No more arguments — done
        getopts_set_var(shell, varname, "?");
        getopts_unset_optarg(shell);
        return 1;
    }

    let current_arg = &extra_args[optind - 1];

    // If charindex is 0, we're starting a new argument
    if *charindex == 0 {
        if !current_arg.starts_with('-') || current_arg == "-" {
            getopts_set_var(shell, varname, "?");
            getopts_unset_optarg(shell);
            return 1;
        }
        if current_arg == "--" {
            shell.set_var("OPTIND", &(optind + 1).to_string());
            getopts_set_var(shell, varname, "?");
            getopts_unset_optarg(shell);
            return 1;
        }
        *charindex = 1; // skip the leading '-'
    }

    let arg_chars: Vec<char> = current_arg.chars().collect();
    if *charindex >= arg_chars.len() {
        getopts_set_var(shell, varname, "?");
        getopts_unset_optarg(shell);
        return 1;
    }

    let opt = arg_chars[*charindex];
    *charindex += 1;

    // Check if this option is in the optstring
    let opt_pos = opts_str.find(opt);

    if let Some(pos) = opt_pos {
        let takes_arg = pos + 1 < opts_str.len() && opts_str.as_bytes()[pos + 1] == b':';

        if takes_arg {
            // Option requires an argument
            if *charindex < arg_chars.len() {
                // Rest of current arg is the argument value
                let optarg: String = arg_chars[*charindex..].iter().collect();
                shell.set_var("OPTIND", &(optind + 1).to_string());
                shell.getopts_charindex = 0;
                getopts_set_var(shell, varname, &opt.to_string());
                getopts_set_optarg(shell, &optarg);
            } else if optind < extra_args.len() {
                // Next arg is the argument value
                let optarg = extra_args[optind].clone();
                shell.set_var("OPTIND", &(optind + 2).to_string());
                shell.getopts_charindex = 0;
                getopts_set_var(shell, varname, &opt.to_string());
                getopts_set_optarg(shell, &optarg);
            } else {
                // Missing required argument
                shell.set_var("OPTIND", &(optind + 1).to_string());
                shell.getopts_charindex = 0;
                if silent {
                    getopts_set_var(shell, varname, ":");
                    getopts_set_optarg(shell, &opt.to_string());
                } else {
                    if !suppress_errors {
                        let prefix = shell.err_prefix();
                        eprintln!("{}: option requires an argument -- {}", prefix, opt);
                    }
                    getopts_set_var(shell, varname, "?");
                    getopts_unset_optarg(shell);
                }
            }
        } else {
            // Option does not take an argument
            if *charindex < arg_chars.len() {
                // More options in this combined arg
                shell.getopts_charindex = *charindex;
            } else {
                // Done with this arg
                shell.set_var("OPTIND", &(optind + 1).to_string());
                shell.getopts_charindex = 0;
            }
            getopts_set_var(shell, varname, &opt.to_string());
            getopts_unset_optarg(shell);
        }
        0
    } else {
        // Unknown option
        if *charindex < arg_chars.len() {
            shell.getopts_charindex = *charindex;
        } else {
            shell.set_var("OPTIND", &(optind + 1).to_string());
            shell.getopts_charindex = 0;
        }
        if silent {
            getopts_set_var(shell, varname, "?");
            getopts_set_optarg(shell, &opt.to_string());
        } else {
            if !suppress_errors {
                let prefix = shell.err_prefix();
                eprintln!("{}: illegal option -- {}", prefix, opt);
            }
            getopts_set_var(shell, varname, "?");
            getopts_unset_optarg(shell);
        }
        0
    }
}

/// Set a variable for getopts, handling readonly with proper error prefix.
fn getopts_set_var(shell: &mut Shell, name: &str, value: &str) {
    let _ = assign_builtin_var(shell, "getopts", name, value);
}

/// Set OPTARG for getopts, handling readonly with proper error prefix.
fn getopts_set_optarg(shell: &mut Shell, value: &str) {
    if shell.vars.is_readonly("OPTARG") {
        eprintln!("{}: OPTARG: readonly variable", shell.err_prefix_with_line(), );
        return;
    }
    shell.set_var("OPTARG", value);
}

/// Unset OPTARG (bash behavior: OPTARG is unset when no argument).
/// For getopts, this bypasses readonly (matching bash internal behavior).
fn getopts_unset_optarg(shell: &mut Shell) {
    // Bash's internal getopts unbinds OPTARG even when readonly.
    // We mimic this by force-unsetting.
    shell.vars.force_unset("OPTARG");
}

// ---------------------------------------------------------------------------
// wait
// ---------------------------------------------------------------------------

#[derive(Clone)]
enum WaitTarget {
    Pid(i32),
    Job(BackgroundJobInfo),
}

enum WaitOutcome {
    Completed { pid: i32, status: i32 },
    Interrupted(i32),
}

fn format_job_command(job: &BackgroundJobInfo, running_suffix: bool) -> String {
    let mut command = job.command.trim().to_string();
    if running_suffix && !command.is_empty() && !command.ends_with('&') {
        command.push_str(" &");
    }
    command
}

fn job_state_name(job: &BackgroundJobInfo) -> &'static str {
    match job.state {
        BackgroundJobState::Running => "Running",
        BackgroundJobState::Stopped(_) => "Stopped",
        BackgroundJobState::Done(_) => "Done",
        BackgroundJobState::Signaled(_) => "Done",
    }
}

fn job_marker(shell: &mut Shell, job_id: usize) -> char {
    if shell.current_background_job_id_pub() == Some(job_id) {
        '+'
    } else if shell.previous_background_job_id_pub() == Some(job_id) {
        '-'
    } else {
        ' '
    }
}

fn print_job_listing(shell: &mut Shell, job: &BackgroundJobInfo, pids_only: bool) {
    if pids_only {
        println!("{}", job.pid);
        return;
    }
    println!(
        "[{}]{}  {:<26} {}",
        job.job_id,
        job_marker(shell, job.job_id),
        job_state_name(job),
        format_job_command(job, job.is_running())
    );
}

fn wait_prepare_assign_var(shell: &mut Shell, name: &Option<String>) -> Result<(), i32> {
    let Some(name) = name else {
        return Ok(());
    };
    if let Some((base, _)) = crate::exec::parse_subscripted_name_pub(name) {
        if !is_valid_identifier(&base) {
            eprintln!(
                "{}: wait: `{}': not a valid identifier",
                shell.err_prefix_with_line(),
                name
            );
            return Err(1);
        }
        if shell.vars.is_readonly(&base) {
            eprintln!(
                "{}: wait: {}: cannot unset: readonly variable",
                shell.err_prefix_with_line(),
                base
            );
            return Err(1);
        }
        return Ok(());
    }
    if !is_valid_identifier(name) {
        eprintln!(
            "{}: wait: `{}': not a valid identifier",
            shell.err_prefix_with_line(),
            name
        );
        return Err(1);
    }
    if shell.vars.is_readonly(name) {
        eprintln!(
            "{}: wait: {}: cannot unset: readonly variable",
            shell.err_prefix_with_line(),
            name
        );
        return Err(1);
    }
    shell.vars.force_unset(name);
    Ok(())
}

fn wait_store_pid(shell: &mut Shell, name: &Option<String>, pid: i32) -> Result<(), i32> {
    let Some(name) = name else {
        return Ok(());
    };
    let pid_s = pid.to_string();
    if let Some((base, sub)) = crate::exec::parse_subscripted_name_pub(name) {
        if shell.vars.is_assoc(&base) {
            shell.vars.set_assoc(&base, &sub, &pid_s);
            return Ok(());
        }
        if sub.is_empty() {
            eprintln!(
                "{}: {}[]: bad array subscript",
                shell.err_prefix_with_line(),
                base
            );
            return Err(1);
        }
        if sub == "*" || sub == "@" {
            eprintln!(
                "{}: {}[{}]: bad array subscript",
                shell.err_prefix_with_line(),
                base,
                sub
            );
            return Err(1);
        }
        let sub_expanded = if sub.contains("$(")
            || sub.contains('"')
            || sub.contains('\'')
            || sub.contains(' ')
            || sub.contains('\t')
        {
            sub.to_string()
        } else {
            crate::expand::expand_arith_vars(&sub, &mut shell.vars)
        };
        match crate::arithmetic::eval_expr_mut(&sub_expanded, &mut shell.vars) {
            Ok(idx) => {
                let real = if idx < 0 {
                    match shell.vars.array_max_index(&base) {
                        Some(max_idx) => {
                            let len = (max_idx + 1) as i64;
                            let resolved = len + idx;
                            if resolved < 0 {
                                eprintln!(
                                    "{}: {}[{}]: bad array subscript",
                                    shell.err_prefix_with_line(),
                                    base,
                                    sub
                                );
                                return Err(1);
                            }
                            resolved as usize
                        }
                        None => {
                            eprintln!(
                                "{}: {}[{}]: bad array subscript",
                                shell.err_prefix_with_line(),
                                base,
                                sub
                            );
                            return Err(1);
                        }
                    }
                } else {
                    idx as usize
                };
                shell.vars.set_array_element(&base, real, &pid_s);
                return Ok(());
            }
            Err(err) => {
                eprintln!(
                    "{}: {}: {}",
                    shell.err_prefix_with_line(),
                    sub_expanded.trim_start(),
                    err
                );
                return Err(1);
            }
        }
    }
    shell.set_var(name, &pid_s);
    Ok(())
}

fn wait_resolve_target(shell: &mut Shell, arg: &str) -> Result<WaitTarget, i32> {
    if arg.starts_with('%') {
        return match shell.resolve_job_spec_pub(arg) {
            Some(job) => Ok(WaitTarget::Job(job)),
            None => {
                eprintln!(
                    "{}: wait: {}: no such job",
                    shell.err_prefix_with_line(),
                    arg
                );
                Err(127)
            }
        };
    }
    match arg.parse::<i32>() {
        Ok(pid) if pid > 0 => Ok(WaitTarget::Pid(pid)),
        _ => {
            eprintln!(
                "{}: wait: `{}': not a pid or valid job spec",
                shell.err_prefix_with_line(),
                arg
            );
            Err(1)
        }
    }
}

fn wait_block_on_pid(shell: &mut Shell, pid: i32) -> Result<WaitOutcome, nix::errno::Errno> {
    use nix::sys::wait::{waitpid, WaitPidFlag, WaitStatus};
    use nix::unistd::Pid;

    loop {
        // Trailing `Ok(_)` covers nix's ptrace-only WaitStatus variants
        // (PtraceEvent, PtraceSyscall) that we don't enable.  Unreachable on
        // every current build target — kept for forward compatibility.
        #[allow(unreachable_patterns)]
        match waitpid(
            Pid::from_raw(pid),
            Some(
                WaitPidFlag::WNOHANG
                    | WaitPidFlag::WUNTRACED
                    | WaitPidFlag::WCONTINUED,
            ),
        ) {
            Ok(WaitStatus::Exited(pid, status)) => {
                let raw = pid.as_raw();
                let _ = shell.mark_background_job_done_pub(raw, status);
                return Ok(WaitOutcome::Completed { pid: raw, status });
            }
            Ok(WaitStatus::Signaled(pid, sig, _)) => {
                let raw = pid.as_raw();
                let status = 128 + sig as i32;
                let _ = shell.mark_background_job_signaled_pub(raw, sig as i32);
                return Ok(WaitOutcome::Completed { pid: raw, status });
            }
            Ok(WaitStatus::Stopped(pid, sig)) => {
                let _ = shell.mark_background_job_stopped_pub(pid.as_raw(), sig as i32);
            }
            Ok(WaitStatus::Continued(pid)) => {
                let _ = shell.mark_background_job_running_pub(pid.as_raw());
            }
            Ok(WaitStatus::StillAlive) => {
                let before = shell.last_trap_signal_pub();
                shell.check_pending_signals();
                if shell.exit_flag {
                    return Ok(WaitOutcome::Interrupted(shell.last_status));
                }
                let after = shell.last_trap_signal_pub();
                if after != before && after != 0 && after != libc::SIGCHLD {
                    return Ok(WaitOutcome::Interrupted(128 + after));
                }
                std::thread::sleep(std::time::Duration::from_millis(10));
            }
            Err(nix::errno::Errno::EINTR) => {
                let before = shell.last_trap_signal_pub();
                shell.check_pending_signals();
                if shell.exit_flag {
                    return Ok(WaitOutcome::Interrupted(shell.last_status));
                }
                let after = shell.last_trap_signal_pub();
                if after != before && after != 0 && after != libc::SIGCHLD {
                    return Ok(WaitOutcome::Interrupted(128 + after));
                }
            }
            Err(err) => return Err(err),
            // Linux-only ptrace variants (PtraceEvent, PtraceSyscall) — ignore.
            Ok(_) => {}
        }
    }
}

fn wait_for_any_target(
    shell: &mut Shell,
    targets: &[WaitTarget],
) -> Result<WaitOutcome, nix::errno::Errno> {
    use nix::sys::wait::{waitpid, WaitPidFlag, WaitStatus};
    use nix::unistd::Pid;

    let target_pids: std::collections::HashSet<i32> = targets
        .iter()
        .map(|target| match target {
            WaitTarget::Pid(pid) => *pid,
            WaitTarget::Job(job) => job.pid,
        })
        .collect();
    let match_any = target_pids.is_empty();

    for target in targets {
        if let WaitTarget::Job(job) = target {
            if let Some(status) = job.wait_status() {
                return Ok(WaitOutcome::Completed {
                    pid: job.pid,
                    status,
                });
            }
        }
    }

    loop {
        // Trailing `Ok(_)` covers nix's ptrace-only WaitStatus variants — we
        // don't enable that feature, so the arm is unreachable on the current
        // build but kept defensively.
        #[allow(unreachable_patterns)]
        match waitpid(
            Pid::from_raw(-1),
            Some(
                WaitPidFlag::WNOHANG
                    | WaitPidFlag::WUNTRACED
                    | WaitPidFlag::WCONTINUED,
            ),
        ) {
            Ok(WaitStatus::Exited(pid, status)) => {
                let raw = pid.as_raw();
                let _ = shell.mark_background_job_done_pub(raw, status);
                if match_any || target_pids.contains(&raw) {
                    return Ok(WaitOutcome::Completed { pid: raw, status });
                }
            }
            Ok(WaitStatus::Signaled(pid, sig, _)) => {
                let raw = pid.as_raw();
                let status = 128 + sig as i32;
                let _ = shell.mark_background_job_signaled_pub(raw, sig as i32);
                if match_any || target_pids.contains(&raw) {
                    return Ok(WaitOutcome::Completed { pid: raw, status });
                }
            }
            Ok(WaitStatus::Stopped(pid, sig)) => {
                let _ = shell.mark_background_job_stopped_pub(pid.as_raw(), sig as i32);
            }
            Ok(WaitStatus::Continued(pid)) => {
                let _ = shell.mark_background_job_running_pub(pid.as_raw());
            }
            Ok(WaitStatus::StillAlive) => {
                let before = shell.last_trap_signal_pub();
                shell.check_pending_signals();
                if shell.exit_flag {
                    return Ok(WaitOutcome::Interrupted(shell.last_status));
                }
                let after = shell.last_trap_signal_pub();
                if after != before && after != 0 && after != libc::SIGCHLD {
                    return Ok(WaitOutcome::Interrupted(128 + after));
                }
                std::thread::sleep(std::time::Duration::from_millis(10));
            }
            Err(nix::errno::Errno::EINTR) => {
                let before = shell.last_trap_signal_pub();
                shell.check_pending_signals();
                if shell.exit_flag {
                    return Ok(WaitOutcome::Interrupted(shell.last_status));
                }
                let after = shell.last_trap_signal_pub();
                if after != before && after != 0 && after != libc::SIGCHLD {
                    return Ok(WaitOutcome::Interrupted(128 + after));
                }
            }
            Err(err) => return Err(err),
            // Linux-only ptrace variants (PtraceEvent, PtraceSyscall) — ignore.
            Ok(_) => {}
        }
    }
}

fn wait_for_target(shell: &mut Shell, target: &WaitTarget) -> i32 {
    match target {
        WaitTarget::Job(job) => {
            if let Some(status) = job.wait_status() {
                shell.remove_background_job_pid_pub(job.pid);
                return status;
            }
            match wait_block_on_pid(shell, job.pid) {
                Ok(WaitOutcome::Completed { pid, status }) => {
                    shell.remove_background_job_pid_pub(pid);
                    status
                }
                Ok(WaitOutcome::Interrupted(status)) => status,
                Err(nix::errno::Errno::ECHILD) => {
                    if let Some(job) = shell.get_background_job_by_pid_pub(job.pid) {
                        if let Some(status) = job.wait_status() {
                            shell.remove_background_job_pid_pub(job.pid);
                            return status;
                        }
                    }
                    127
                }
                Err(_) => 1,
            }
        }
        WaitTarget::Pid(pid) => match wait_block_on_pid(shell, *pid) {
            Ok(WaitOutcome::Completed { pid, status }) => {
                shell.remove_background_job_pid_pub(pid);
                status
            }
            Ok(WaitOutcome::Interrupted(status)) => status,
            Err(nix::errno::Errno::ECHILD) => {
                eprintln!(
                    "{}: wait: pid {} is not a child of this shell",
                    shell.err_prefix_with_line(),
                    pid
                );
                127
            }
            Err(_) => 1,
        },
    }
}

fn builtin_wait(shell: &mut Shell, args: &[String]) -> i32 {
    let mut wait_any = false;
    let mut assign_name: Option<String> = None;
    let mut raw_ids: Vec<String> = Vec::new();
    let mut idx = 0usize;
    while idx < args.len() {
        match args[idx].as_str() {
            "--" => {
                idx += 1;
                raw_ids.extend(args[idx..].iter().cloned());
                break;
            }
            "-n" => {
                wait_any = true;
                idx += 1;
            }
            "-f" => {
                idx += 1;
            }
            "-p" => {
                idx += 1;
                if idx >= args.len() {
                    eprintln!(
                        "{}: wait: -p: option requires an argument",
                        crate::exec::shell_name()
                    );
                    return 2;
                }
                assign_name = Some(args[idx].clone());
                idx += 1;
            }
            _ => {
                raw_ids.push(args[idx].clone());
                idx += 1;
            }
        }
    }

    if let Err(status) = wait_prepare_assign_var(shell, &assign_name) {
        return status;
    }

    let mut parse_status = None;
    let mut targets: Vec<WaitTarget> = Vec::new();
    for arg in &raw_ids {
        match wait_resolve_target(shell, arg) {
            Ok(target) => targets.push(target),
            Err(status) => parse_status = Some(status),
        }
    }

    if wait_any {
        if raw_ids.is_empty() {
            targets.extend(
                shell
                    .background_jobs_pub()
                    .into_iter()
                    .map(WaitTarget::Job),
            );
        }
        if targets.is_empty() {
            let status = parse_status.unwrap_or(127);
            shell.last_status = status;
            return status;
        }
        match wait_for_any_target(shell, &targets) {
            Ok(WaitOutcome::Completed { pid, status }) => {
                shell.remove_background_job_pid_pub(pid);
                match wait_store_pid(shell, &assign_name, pid) {
                    Ok(()) => {
                        shell.last_status = status;
                        status
                    }
                    Err(assign_status) => {
                        shell.last_status = assign_status;
                        assign_status
                    }
                }
            }
            Ok(WaitOutcome::Interrupted(status)) => {
                shell.last_status = status;
                status
            }
            Err(nix::errno::Errno::ECHILD) => {
                let status = parse_status.unwrap_or(127);
                shell.last_status = status;
                status
            }
            Err(_) => {
                shell.last_status = 1;
                1
            }
        }
    } else if raw_ids.is_empty() {
        let mut saw_job = false;
        loop {
            let jobs = shell.background_jobs_pub();
            for job in &jobs {
                if job.is_completed() {
                    shell.remove_background_job_pid_pub(job.pid);
                    saw_job = true;
                }
            }
            let running_pids = shell.background_job_pids_pub();
            if running_pids.is_empty() {
                break;
            }
            saw_job = true;
            let targets: Vec<WaitTarget> = running_pids.into_iter().map(WaitTarget::Pid).collect();
            match wait_for_any_target(shell, &targets) {
                Ok(WaitOutcome::Completed { pid, .. }) => {
                    shell.remove_background_job_pid_pub(pid);
                }
                Ok(WaitOutcome::Interrupted(status)) => {
                    shell.last_status = status;
                    return status;
                }
                Err(nix::errno::Errno::ECHILD) => break,
                Err(_) => {
                    shell.last_status = 1;
                    return 1;
                }
            }
        }

        if !saw_job {
            use nix::sys::wait::{waitpid, WaitStatus};
            use nix::unistd::Pid;

            loop {
                match waitpid(Pid::from_raw(-1), None) {
                    Ok(WaitStatus::Exited(pid, _))
                    | Ok(WaitStatus::Signaled(pid, _, _)) => {
                        // Trigger coproc variable cleanup when the coproc
                        // child exits via this fallback waitpid path.
                        shell.cleanup_coproc_on_exit_pub(pid.as_raw());
                    }
                    Ok(WaitStatus::StillAlive) => {}
                    Ok(_) => {}
                    Err(nix::errno::Errno::ECHILD) => break,
                    Err(nix::errno::Errno::EINTR) => {
                        let before = shell.last_trap_signal_pub();
                        shell.check_pending_signals();
                        if shell.exit_flag {
                            return shell.last_status;
                        }
                        let after = shell.last_trap_signal_pub();
                        if after != before && after != 0 && after != libc::SIGCHLD {
                            shell.last_status = 128 + after;
                            return shell.last_status;
                        }
                    }
                    Err(_) => {
                        shell.last_status = 127;
                        return 127;
                    }
                }
            }
        }

        shell.check_pending_signals();
        if shell.exit_flag {
            return shell.last_status;
        }
        shell.last_status = 0;
        0
    } else {
        let mut last_status = parse_status.unwrap_or(0);
        for target in &targets {
            last_status = wait_for_target(shell, target);
            if let WaitTarget::Pid(pid) = target {
                if last_status != 127 {
                    if let Err(assign_status) = wait_store_pid(shell, &assign_name, *pid) {
                        last_status = assign_status;
                    }
                }
            } else if let WaitTarget::Job(job) = target {
                if last_status != 127 {
                    if let Err(assign_status) = wait_store_pid(shell, &assign_name, job.pid) {
                        last_status = assign_status;
                    }
                }
            }
            if shell.exit_flag || last_status > 128 {
                break;
            }
        }
        shell.last_status = last_status;
        last_status
    }
}

fn builtin_jobs(shell: &mut Shell, args: &[String]) -> i32 {
    let mut pids_only = false;
    let mut running_only = false;
    let mut stopped_only = false;
    let mut specs: Vec<String> = Vec::new();

    let mut idx = 0usize;
    while idx < args.len() {
        let arg = &args[idx];
        if arg == "--" {
            idx += 1;
            specs.extend(args[idx..].iter().cloned());
            break;
        }
        if arg.starts_with('-') && arg.len() > 1 {
            for ch in arg[1..].chars() {
                match ch {
                    'p' => pids_only = true,
                    'r' => running_only = true,
                    's' => stopped_only = true,
                    'l' | 'n' => {}
                    _ => {
                        eprintln!(
                            "{}: jobs: -{}: invalid option",
                            shell.err_prefix_with_line(),
                            ch
                        );
                        eprintln!("jobs: usage: jobs [-lnprs] [jobspec ...] or jobs -x command [args]");
                        return 2;
                    }
                }
            }
        } else {
            specs.push(arg.clone());
        }
        idx += 1;
    }

    let mut status = 0;
    let mut jobs = if specs.is_empty() {
        shell.background_jobs_pub()
    } else {
        let mut selected = Vec::new();
        for spec in &specs {
            match shell.resolve_job_spec_pub(spec) {
                Some(job) => selected.push(job),
                None => {
                    eprintln!(
                        "{}: jobs: {}: no such job",
                        shell.err_prefix_with_line(),
                        spec
                    );
                    status = 1;
                }
            }
        }
        selected
    };

    jobs.retain(|job| {
        (!running_only || job.is_running()) && (!stopped_only || job.is_stopped())
    });

    for job in &jobs {
        print_job_listing(shell, job, pids_only);
    }
    status
}

pub fn run_job_spec_command_pub(shell: &mut Shell, spec: &str) -> i32 {
    let args = vec![spec.to_string()];
    builtin_fg(shell, &args)
}

fn builtin_fg(shell: &mut Shell, args: &[String]) -> i32 {
    for arg in args {
        if arg.starts_with('-') {
            eprintln!(
                "{}: fg: {}: invalid option",
                shell.err_prefix_with_line(),
                arg
            );
            eprintln!("fg: usage: fg [job_spec]");
            return 2;
        }
    }
    if !shell.opts.monitor {
        eprintln!("{}: fg: no job control", shell.err_prefix_with_line());
        return 1;
    }
    if shell.in_forked_subshell_pub() {
        eprintln!("{}: fg: no current jobs", shell.err_prefix_with_line());
        return 1;
    }
    let job = if let Some(spec) = args.first() {
        match shell.resolve_job_spec_pub(spec) {
            Some(job) => job,
            None => {
                eprintln!(
                    "{}: fg: {}: no such job",
                    shell.err_prefix_with_line(),
                    spec
                );
                return 1;
            }
        }
    } else {
        match shell.get_current_background_job_pub() {
            Some(job) => job,
            None => {
                eprintln!("{}: fg: no current jobs", shell.err_prefix_with_line());
                return 1;
            }
        }
    };

    if job.started_without_job_control {
        eprintln!(
            "{}: fg: job {} started without job control",
            shell.err_prefix_with_line(),
            job.job_id
        );
        return 1;
    }

    let _ = shell.select_background_job_pub(job.job_id);
    if job.is_stopped() {
        unsafe {
            libc::kill(job.pid, libc::SIGCONT);
        }
        let _ = shell.mark_background_job_running_pub(job.pid);
    }
    println!("{}", format_job_command(&job, false));
    let status = wait_for_target(shell, &WaitTarget::Job(job));
    shell.last_status = status;
    status
}

fn builtin_bg(shell: &mut Shell, args: &[String]) -> i32 {
    for arg in args {
        if arg.starts_with('-') {
            eprintln!(
                "{}: bg: {}: invalid option",
                shell.err_prefix_with_line(),
                arg
            );
            eprintln!("bg: usage: bg [job_spec ...]");
            return 2;
        }
    }
    if !shell.opts.monitor {
        eprintln!("{}: bg: no job control", shell.err_prefix_with_line());
        return 1;
    }

    let jobs = if args.is_empty() {
        match shell.get_current_background_job_pub() {
            Some(job) => vec![job],
            None => {
                eprintln!("{}: bg: no current jobs", shell.err_prefix_with_line());
                return 1;
            }
        }
    } else {
        let mut jobs = Vec::new();
        for spec in args {
            match shell.resolve_job_spec_pub(spec) {
                Some(job) => jobs.push(job),
                None => {
                    eprintln!(
                        "{}: bg: {}: no such job",
                        shell.err_prefix_with_line(),
                        spec
                    );
                    return 1;
                }
            }
        }
        jobs
    };

    let mut status = 0;
    for job in jobs {
        if job.started_without_job_control {
            eprintln!(
                "{}: bg: job {} started without job control",
                shell.err_prefix_with_line(),
                job.job_id
            );
            status = 1;
            continue;
        }
        if !job.is_stopped() {
            eprintln!(
                "{}: bg: job {} already in background",
                shell.err_prefix_with_line(),
                job.job_id
            );
            status = 1;
            continue;
        }
        unsafe {
            libc::kill(job.pid, libc::SIGCONT);
        }
        let _ = shell.mark_background_job_running_pub(job.pid);
        let _ = shell.select_background_job_pub(job.job_id);
        println!("[{}]+ {}", job.job_id, format_job_command(&job, true));
    }
    status
}

fn builtin_disown(shell: &mut Shell, args: &[String]) -> i32 {
    let mut all_jobs = false;
    let mut running_only = false;
    let mut hold = false;
    let mut specs: Vec<String> = Vec::new();

    let mut idx = 0usize;
    while idx < args.len() {
        let arg = &args[idx];
        if arg == "--" {
            idx += 1;
            specs.extend(args[idx..].iter().cloned());
            break;
        }
        if arg.starts_with('-') && arg.len() > 1 {
            for ch in arg[1..].chars() {
                match ch {
                    'a' => all_jobs = true,
                    'r' => running_only = true,
                    'h' => hold = true,
                    _ => {
                        eprintln!(
                            "{}: disown: -{}: invalid option",
                            shell.err_prefix_with_line(),
                            ch
                        );
                        eprintln!("disown: usage: disown [-h] [-ar] [jobspec ... | pid ...]");
                        return 2;
                    }
                }
            }
        } else {
            specs.push(arg.clone());
        }
        idx += 1;
    }

    if all_jobs || running_only {
        if !hold {
            shell.clear_background_jobs_pub(running_only);
        }
        return 0;
    }

    let mut status = 0;
    for spec in specs {
        if !spec.starts_with('%') {
            eprintln!(
                "{}: disown: warning: {}: job specification requires leading `%'",
                shell.err_prefix_with_line(),
                spec
            );
            eprintln!(
                "{}: disown: {}: no such job",
                shell.err_prefix_with_line(),
                spec
            );
            status = 1;
            continue;
        }
        match shell.resolve_job_spec_pub(&spec) {
            Some(job) => {
                if !hold {
                    let _ = shell.remove_background_job_by_id_pub(job.job_id);
                }
            }
            None => {
                eprintln!(
                    "{}: disown: {}: no such job",
                    shell.err_prefix_with_line(),
                    spec
                );
                status = 1;
            }
        }
    }
    status
}

// No readline integration, so `bind` accepts any args and exits 0.
fn builtin_bind(_shell: &mut Shell, _args: &[String]) -> i32 {
    0
}

fn builtin_suspend(shell: &mut Shell, args: &[String]) -> i32 {
    for arg in args {
        if arg == "-f" || arg == "--" {
            continue;
        }
        if arg.starts_with('-') {
            eprintln!(
                "{}: suspend: {}: invalid option",
                shell.err_prefix_with_line(),
                arg
            );
            eprintln!("suspend: usage: suspend [-f]");
            return 2;
        }
    }
    if !shell.opts.monitor {
        eprintln!(
            "{}: suspend: cannot suspend: no job control",
            shell.err_prefix_with_line()
        );
        return 1;
    }
    0
}

// ---------------------------------------------------------------------------
// kill
// ---------------------------------------------------------------------------

fn builtin_kill(shell: &mut Shell, args: &[String]) -> i32 {
    let kill_usage = || {
        eprintln!("kill: usage: kill [-s sigspec | -n signum | -sigspec] pid | jobspec ... or kill -l [sigspec]");
    };

    if args.is_empty() {
        kill_usage();
        return 2;
    }

    let mut sig_num: i32 = 15; // SIGTERM default
    let mut idx = 0;

    if args[0] == "-l" || args[0] == "-L" {
        if args.len() > 1 {
            for spec in &args[1..] {
                if let Ok(n) = spec.parse::<i32>() {
                    let num = if n > 128 { n - 128 } else { n };
                    if let Some(name) = crate::trap::TrapHandler::signal_num_to_name(num) {
                        println!("{}", name);
                    } else {
                        eprintln!("{}: kill: {}: invalid signal specification",
                            shell.err_prefix_with_line(), spec);
                        return 1;
                    }
                } else if let Some(num) = crate::trap::TrapHandler::signal_name_to_num(spec) {
                    println!("{}", num);
                } else {
                    eprintln!("{}: kill: {}: invalid signal specification",
                        shell.err_prefix_with_line(), spec);
                    return 1;
                }
            }
            return 0;
        }
        print_signal_list();
        return 0;
    }

    while idx < args.len() && args[idx].starts_with('-') && args[idx] != "--" {
        let flag = &args[idx];
        match flag.as_str() {
            "-s" | "--signal" => {
                idx += 1;
                if idx >= args.len() {
                    // -s with no argument
                    eprintln!("{}: kill: -s: option requires an argument",
                        shell.err_prefix_with_line());
                    return 1;
                }
                let sig_spec = &args[idx];
                if let Some(n) = crate::trap::TrapHandler::signal_name_to_num(sig_spec) {
                    sig_num = n;
                } else if let Ok(n) = sig_spec.parse::<i32>() {
                    if !(0..=63).contains(&n) {
                        eprintln!("{}: kill: {}: invalid signal specification",
                            shell.err_prefix_with_line(), sig_spec);
                        return 1;
                    }
                    sig_num = n;
                } else {
                    eprintln!("{}: kill: {}: invalid signal specification",
                        shell.err_prefix_with_line(), sig_spec);
                    return 1;
                }
                idx += 1;
            }
            "-n" => {
                idx += 1;
                if idx >= args.len() {
                    eprintln!("{}: kill: -n: option requires an argument",
                        shell.err_prefix_with_line());
                    return 1;
                }
                match args[idx].parse::<i32>() {
                    Ok(n) if (0..=63).contains(&n) => sig_num = n,
                    _ => {
                        eprintln!("{}: kill: {}: invalid signal specification",
                            shell.err_prefix_with_line(), args[idx]);
                        return 1;
                    }
                }
                idx += 1;
            }
            _ => {
                // Could be -nNUM (combined `-n` + number, bash shorthand),
                // -sSIGNAME (combined -s + name), -SIGNAME, or -N.
                let s = &flag[1..];
                // Combined -nNUM
                if let Some(rest) = s.strip_prefix('n') {
                    if let Ok(n) = rest.parse::<i32>() {
                        if !(0..=63).contains(&n) {
                            eprintln!("{}: kill: {}: invalid signal specification",
                                shell.err_prefix_with_line(), rest);
                            return 1;
                        }
                        sig_num = n;
                        idx += 1;
                        continue;
                    }
                }
                // Combined -sSIGNAME (e.g. -sHUP)
                if let Some(rest) = s.strip_prefix('s') {
                    if !rest.is_empty() {
                        if let Some(n) = crate::trap::TrapHandler::signal_name_to_num(rest) {
                            sig_num = n;
                            idx += 1;
                            continue;
                        }
                        if let Ok(n) = rest.parse::<i32>() {
                            if (0..=63).contains(&n) {
                                sig_num = n;
                                idx += 1;
                                continue;
                            }
                        }
                    }
                }
                if let Ok(n) = s.parse::<i32>() {
                    sig_num = n;
                    idx += 1;
                } else if let Some(n) = crate::trap::TrapHandler::signal_name_to_num(s) {
                    sig_num = n;
                    idx += 1;
                } else {
                    // Unknown signal name like "-S" → report as "S: invalid signal specification"
                    eprintln!("{}: kill: {}: invalid signal specification",
                        shell.err_prefix_with_line(), s);
                    return 1;
                }
            }
        }
    }

    // If no targets remain after option parsing, print usage
    let targets = &args[idx..];
    if targets.is_empty() {
        kill_usage();
        return 2;
    }

    let mut status = 0;
    for target in targets {
        // Empty string is not a valid pid/job
        if target.is_empty() {
            eprintln!("{}: kill: `{}': not a pid or valid job spec",
                shell.err_prefix_with_line(), target);
            status = 1;
            continue;
        }
        let pid: i32 = if target.starts_with('%') {
            match shell.resolve_job_spec_pub(target) {
                Some(job) => job.pid,
                None => {
                    // Job specs that don't resolve get "no such job",
                    // not "not a pid or valid job spec" (which is for
                    // raw non-pid strings).
                    eprintln!(
                        "{}: kill: {}: no such job",
                        shell.err_prefix_with_line(),
                        target
                    );
                    status = 1;
                    continue;
                }
            }
        } else {
            match target.parse() {
                Ok(p) => p,
                Err(_) => {
                    eprintln!(
                        "{}: kill: `{}': not a pid or valid job spec",
                        shell.err_prefix_with_line(),
                        target
                    );
                    status = 1;
                    continue;
                }
            }
        };
        let rc = unsafe { libc::kill(pid, sig_num) };
        if rc < 0 {
            eprintln!("{}: kill: ({}) - {}", crate::exec::shell_name(), pid, std::io::Error::last_os_error());
            status = 1;
        } else {
            // For stop/continue signals sent to a background job, poll waitpid
            // until the kernel reflects the state change.  This closes the
            // SIGSTOP/SIGCONT race where `jobs -r` / `jobs -s` runs before
            // waitpid(WUNTRACED) has seen the new state.
            //
            // We deliberately skip this for SIGTERM/SIGKILL/SIGINT etc.:
            //   - They cause the child to exit, which is handled by the
            //     existing periodic refresh path (double-waitpid would ECHILD).
            //   - Only STOP/TSTP/TTIN/TTOU/CONT change *running* state while
            //     keeping the process alive, so a targeted waitpid is safe.
            let is_stop_or_cont = sig_num == libc::SIGSTOP
                || sig_num == libc::SIGTSTP
                || sig_num == libc::SIGTTIN
                || sig_num == libc::SIGTTOU
                || sig_num == libc::SIGCONT;
            if is_stop_or_cont {
                // Only wait on background-job pids; never steal a foreground
                // child out from under wait_for_child.
                let is_bg = shell.get_background_job_by_pid_pub(pid).is_some();
                if is_bg {
                    kill_wait_for_state_change(shell, pid);
                }
            }
        }
    }
    status
}

/// After delivering a STOP/CONT signal to a background job, poll waitpid
/// (WNOHANG | WUNTRACED | WCONTINUED) until the kernel reflects the new state,
/// then update the shell's job table.  Capped at ~200 ms to avoid hanging if
/// the process is somehow not transitioning.
fn kill_wait_for_state_change(shell: &mut Shell, pid: i32) {
    use nix::sys::wait::{waitpid, WaitPidFlag, WaitStatus};
    use nix::unistd::Pid;

    const MAX_RETRIES: u32 = 40;   // 40 × 5 ms = 200 ms max
    const SLEEP_US: u64 = 5_000;   // 5 ms per retry

    for _ in 0..MAX_RETRIES {
        match waitpid(
            Pid::from_raw(pid),
            Some(WaitPidFlag::WNOHANG | WaitPidFlag::WUNTRACED | WaitPidFlag::WCONTINUED),
        ) {
            Ok(WaitStatus::Stopped(p, sig)) => {
                let _ = shell.mark_background_job_stopped_pub(p.as_raw(), sig as i32);
                return;
            }
            Ok(WaitStatus::Continued(p)) => {
                let _ = shell.mark_background_job_running_pub(p.as_raw());
                return;
            }
            Ok(WaitStatus::Exited(p, code)) => {
                // Process exited (e.g. it died right after we stopped it).
                let _ = shell.mark_background_job_done_pub(p.as_raw(), code);
                return;
            }
            Ok(WaitStatus::Signaled(p, s, _)) => {
                let _ = shell.mark_background_job_signaled_pub(p.as_raw(), s as i32);
                return;
            }
            Ok(WaitStatus::StillAlive) => {
                // State not yet visible — sleep briefly and retry.
                std::thread::sleep(std::time::Duration::from_micros(SLEEP_US));
            }
            Err(nix::errno::Errno::EINTR) => {
                // Interrupted by a signal; retry immediately.
                continue;
            }
            Err(_) => {
                // ECHILD or other error — fall back to generic refresh.
                break;
            }
            #[allow(unreachable_patterns)]
            Ok(_) => {
                // Linux-only ptrace variants (PtraceEvent, PtraceSyscall) —
                // can't happen here since we didn't attach with PTRACE_SEIZE,
                // but the nix WaitStatus enum is non-exhaustive on Linux so
                // the compiler requires a catch-all.
            }
        }
    }
    // Fallback: use the generic refresh to pick up whatever state is current.
    shell.refresh_background_jobs_pub();
}

// ---------------------------------------------------------------------------
// umask
// ---------------------------------------------------------------------------

fn builtin_umask(shell: &mut Shell, args: &[String]) -> i32 {
    // Validate options: only -S and -p are recognized.  Anything else
    // starting with `-` (and not consisting of digits like `-007`) is
    // an invalid option and should trigger bash's two-line error.
    // We also stop flag-scanning at `--`.
    for a in args.iter() {
        if a == "--" { break; }
        if a.starts_with('-')
            && a != "-"
            && a != "-S"
            && a != "-p"
            && !a.chars().skip(1).all(|c| c.is_ascii_digit())
        {
            // Extract the first unknown flag char for bash's error form.
            let ch = a.chars().nth(1).unwrap_or('?');
            eprintln!("{}: umask: -{}: invalid option",
                shell.err_prefix_with_line(), ch);
            eprintln!("umask: usage: umask [-p] [-S] [mode]");
            return 2;
        }
    }
    let symbolic = args.iter().any(|a| a == "-S");
    // `-p` makes the printed form re-executable (prefixed with `umask`)
    let pflag = args.iter().any(|a| a == "-p");
    let print_mode = args.iter().all(|a| a.starts_with('-') || a.is_empty());

    let mask = unsafe { libc::umask(0) };
    unsafe { libc::umask(mask); } // restore

    if print_mode || args.is_empty() {
        if symbolic {
            // Print symbolic form
            let u = (((!mask) >> 6) & 7) as u32;
            let g = (((!mask) >> 3) & 7) as u32;
            let o = ((!mask) & 7) as u32;
            // Bash's symbolic umask output omits letters whose bits are
            // zero — e.g. `u=rwx,g=rx,o=rx` (not `g=r-x`).
            let perm_str = |bits: u32| -> String {
                let mut s = String::new();
                if bits & 4 != 0 { s.push('r'); }
                if bits & 2 != 0 { s.push('w'); }
                if bits & 1 != 0 { s.push('x'); }
                s
            };
            let body = format!("u={},g={},o={}", perm_str(u), perm_str(g), perm_str(o));
            if pflag {
                println!("umask -S {}", body);
            } else {
                println!("{}", body);
            }
        } else if pflag {
            println!("umask {:04o}", mask);
        } else {
            println!("{:04o}", mask);
        }
        return 0;
    }

    // Set umask
    let new_arg = args.iter().find(|a| !a.starts_with('-')).unwrap();
    // Plain octal form: `umask 0022`
    if let Ok(new_mask) = u32::from_str_radix(new_arg, 8) {
        unsafe { libc::umask(new_mask as libc::mode_t); }
        return 0;
    }
    // If the argument is all digits but has a digit >= 8, bash
    // reports "octal number out of range" (not "invalid symbolic").
    if !new_arg.is_empty() && new_arg.chars().all(|c| c.is_ascii_digit()) {
        eprintln!("{}: umask: {}: octal number out of range",
            crate::exec::shell_name_with_line(), new_arg);
        return 1;
    }
    // Symbolic form: `[ugoa]+[+-=][rwx]+[,…]` — set bits are the
    // permissions that should be PERMITTED (the umask stores the
    // complement).  Start from the CURRENT umask so `u+r` / `g-w`
    // etc. work as relative changes.
    match parse_symbolic_umask_diag(mask, new_arg) {
        Ok(new_mask) => {
            unsafe { libc::umask(new_mask); }
            0
        }
        Err(UmaskErr::BadChar(c)) => {
            eprintln!("{}: umask: `{}': invalid symbolic mode character",
                shell.err_prefix_with_line(), c);
            1
        }
        Err(UmaskErr::BadOp(c)) => {
            eprintln!("{}: umask: `{}': invalid symbolic mode operator",
                shell.err_prefix_with_line(), c);
            1
        }
    }
}

enum UmaskErr {
    BadChar(char),
    BadOp(char),
}

fn parse_symbolic_umask_diag(current: libc::mode_t, spec: &str) -> Result<libc::mode_t, UmaskErr> {
    // `current` is the umask — bits set mean "block".  Work on the
    // complement (permit bits), then invert back at the end.
    let mut perm: u32 = !(current as u32) & 0o777;
    for clause in spec.split(',') {
        if clause.is_empty() { return Err(UmaskErr::BadOp(',')); }
        let mut who_mask: u32 = 0;
        let mut chars = clause.chars().peekable();
        while let Some(&c) = chars.peek() {
            match c {
                'u' => { who_mask |= 0o700; chars.next(); }
                'g' => { who_mask |= 0o070; chars.next(); }
                'o' => { who_mask |= 0o007; chars.next(); }
                'a' => { who_mask |= 0o777; chars.next(); }
                _ => break,
            }
        }
        if who_mask == 0 { who_mask = 0o777; }
        while let Some(&op) = chars.peek() {
            if !matches!(op, '+' | '-' | '=') {
                return Err(UmaskErr::BadOp(op));
            }
            chars.next();
            let mut literal_bits: u32 = 0;
            let mut copied_bits: u32 = 0;
            let mut saw_perm = false;
            while let Some(&c) = chars.peek() {
                if matches!(c, '+' | '-' | '=') {
                    break;
                }
                saw_perm = true;
                match c {
                    'r' => literal_bits |= 0o444,
                    'w' => literal_bits |= 0o222,
                    'x' => literal_bits |= 0o111,
                    'X' => {
                        if perm & 0o111 != 0 {
                            literal_bits |= 0o111;
                        }
                    }
                    'u' | 'g' | 'o' => {
                        let src_bits = match c {
                            'u' => (perm >> 6) & 0o7,
                            'g' => (perm >> 3) & 0o7,
                            'o' => perm & 0o7,
                            _ => 0,
                        };
                        if who_mask & 0o700 != 0 { copied_bits |= src_bits << 6; }
                        if who_mask & 0o070 != 0 { copied_bits |= src_bits << 3; }
                        if who_mask & 0o007 != 0 { copied_bits |= src_bits; }
                    }
                    _ => return Err(UmaskErr::BadChar(c)),
                }
                chars.next();
            }
            if !saw_perm && op != '=' {
                return Err(UmaskErr::BadOp(op));
            }
            let effective = (literal_bits & who_mask) | copied_bits;
            match op {
                '+' => perm |= effective,
                '-' => perm &= !effective,
                '=' => {
                    perm &= !who_mask;
                    perm |= effective;
                }
                _ => unreachable!(),
            }
        }
    }
    Ok((!perm & 0o777) as libc::mode_t)
}

// ---------------------------------------------------------------------------
// ulimit
// ---------------------------------------------------------------------------

// Resource ID type for getrlimit/setrlimit and the RLIMIT_* constants.  The
// portable libc story is annoying:
//   - glibc: __rlimit_resource_t = unsigned int (u32)
//   - musl, macOS, *BSD: plain c_int (i32)
// libc-rs only exposes __rlimit_resource_t under glibc, so we use a local
// alias so this code compiles cleanly on every Unix we target.
#[cfg(all(target_os = "linux", target_env = "gnu"))]
type RlimitResource = libc::__rlimit_resource_t;
#[cfg(not(all(target_os = "linux", target_env = "gnu")))]
type RlimitResource = libc::c_int;

fn ulimit_resource_for_flag(flag: char) -> Option<RlimitResource> {
    match flag {
        'c' => Some(libc::RLIMIT_CORE),
        'd' => Some(libc::RLIMIT_DATA),
        'f' => Some(libc::RLIMIT_FSIZE),
        'l' => Some(libc::RLIMIT_MEMLOCK),
        'm' => Some(libc::RLIMIT_RSS),
        'n' => Some(libc::RLIMIT_NOFILE),
        's' => Some(libc::RLIMIT_STACK),
        't' => Some(libc::RLIMIT_CPU),
        'u' => Some(libc::RLIMIT_NPROC),
        'v' => {
            #[cfg(target_os = "linux")]
            { Some(libc::RLIMIT_AS) }
            #[cfg(not(target_os = "linux"))]
            { Some(libc::RLIMIT_RSS) }
        }
        _ => None,
    }
}

fn ulimit_divisor_for_flag(flag: char) -> u64 {
    match flag {
        'c' | 'f' => 512,   // blocks (512 bytes each)
        'd' | 'l' | 'm' | 's' | 'v' => 1024, // kbytes
        _ => 1,
    }
}

fn ulimit_get(resource: RlimitResource, soft: bool) -> libc::rlim_t {
    unsafe {
        let mut rlim: libc::rlimit = std::mem::zeroed();
        libc::getrlimit(resource, &mut rlim);
        if soft { rlim.rlim_cur } else { rlim.rlim_max }
    }
}

fn ulimit_set(resource: RlimitResource, value: libc::rlim_t, soft: bool) -> i32 {
    unsafe {
        let mut rlim: libc::rlimit = std::mem::zeroed();
        libc::getrlimit(resource, &mut rlim);
        if soft {
            rlim.rlim_cur = value;
        } else {
            rlim.rlim_max = value;
        }
        if libc::setrlimit(resource, &rlim) != 0 {
            return 1;
        }
    }
    0
}

fn ulimit_print_value(val: libc::rlim_t, divisor: u64) {
    if val == libc::RLIM_INFINITY {
        println!("unlimited");
    } else {
        println!("{}", val / divisor as libc::rlim_t);
    }
}

fn ulimit_label(flag: char) -> &'static str {
    match flag {
        'c' => "core file size",
        'd' => "data seg size",
        'f' => "file size",
        'l' => "max locked memory",
        'm' => "max memory size",
        'n' => "open files",
        's' => "stack size",
        't' => "cpu time",
        'u' => "max user processes",
        'v' => "virtual memory",
        _ => "ulimit",
    }
}

fn builtin_ulimit(shell: &mut Shell, args: &[String]) -> i32 {
    let mut resource_flag = 'f'; // default: file size
    let mut use_hard = false;
    let mut mode_specified = false;
    let mut show_all = false;
    let mut set_value: Option<String> = None;
    let mut i = 0;

    while i < args.len() {
        let arg = &args[i];
        if arg == "--" {
            i += 1;
            break;
        } else if arg.starts_with('-') && arg.len() > 1 {
            for ch in arg[1..].chars() {
                match ch {
                    'S' => { use_hard = false; mode_specified = true; }
                    'H' => { use_hard = true; mode_specified = true; }
                    'a' => show_all = true,
                    ch if ulimit_resource_for_flag(ch).is_some() => resource_flag = ch,
                    _ => {
                        eprintln!("{}: ulimit: -{}: invalid option", shell.err_prefix_with_line(), ch);
                        eprintln!("ulimit: usage: ulimit [-SHabcdefiklmnpqrstuvxPRT] [limit]");
                        return 2;
                    }
                }
            }
        } else {
            set_value = Some(arg.clone());
            i += 1;
            break;
        }
        i += 1;
    }
    while i < args.len() {
        set_value = Some(args[i].clone());
        i += 1;
    }
    let soft = !use_hard;

    if show_all {
        let flags = [
            ('c', "core file size          (blocks, -c) "),
            ('d', "data seg size           (kbytes, -d) "),
            ('f', "file size               (blocks, -f) "),
            ('l', "max locked memory       (kbytes, -l) "),
            ('m', "max memory size         (kbytes, -m) "),
            ('n', "open files                      (-n) "),
            ('s', "stack size              (kbytes, -s) "),
            ('t', "cpu time               (seconds, -t) "),
            ('u', "max user processes              (-u) "),
            ('v', "virtual memory          (kbytes, -v) "),
        ];
        for (flag, label) in &flags {
            if let Some(res) = ulimit_resource_for_flag(*flag) {
                let val = ulimit_get(res, soft);
                if val == libc::RLIM_INFINITY {
                    println!("{}unlimited", label);
                } else {
                    let divisor = ulimit_divisor_for_flag(*flag);
                    println!("{}{}", label, val / divisor as libc::rlim_t);
                }
            }
        }
        return 0;
    }

    if let Some(res) = ulimit_resource_for_flag(resource_flag) {
        if let Some(ref val_str) = set_value {
            let value = if val_str == "unlimited" {
                libc::RLIM_INFINITY
            } else if val_str == "hard" {
                ulimit_get(res, false)
            } else if val_str == "soft" {
                ulimit_get(res, true)
            } else if val_str.starts_with('+') {
                eprintln!("{}: ulimit: {}: invalid number",
                    shell.err_prefix_with_line(), val_str);
                return 1;
            } else if let Ok(v) = val_str.parse::<u64>() {
                let divisor = ulimit_divisor_for_flag(resource_flag);
                v * divisor
            } else {
                eprintln!("{}: ulimit: {}: invalid limit", shell.err_prefix_with_line(), val_str);
                return 1;
            };
            if !mode_specified {
                let r1 = ulimit_set(res, value, true);
                let r2 = ulimit_set(res, value, false);
                if r1 != 0 || r2 != 0 {
                    eprintln!("{}: ulimit: {}: cannot modify limit: Operation not permitted",
                        shell.err_prefix_with_line(), ulimit_label(resource_flag));
                    return 1;
                }
            } else {
                if ulimit_set(res, value, soft) != 0 {
                    eprintln!("{}: ulimit: {}: cannot modify limit: Operation not permitted",
                        shell.err_prefix_with_line(), ulimit_label(resource_flag));
                    return 1;
                }
            }
        } else {
            let val = ulimit_get(res, soft);
            let divisor = ulimit_divisor_for_flag(resource_flag);
            ulimit_print_value(val, divisor);
        }
    }
    0
}

// ---------------------------------------------------------------------------
// times
// ---------------------------------------------------------------------------

fn builtin_times(_shell: &mut Shell) -> i32 {
    // Print user and system times for shell and children
    let times = unsafe {
        let mut t: libc::tms = std::mem::zeroed();
        libc::times(&mut t);
        t
    };
    let ticks = unsafe { libc::sysconf(libc::_SC_CLK_TCK) } as f64;
    let fmt = |ticks_val: libc::clock_t| -> String {
        let secs = ticks_val as f64 / ticks;
        let m = (secs / 60.0) as u64;
        let s = secs % 60.0;
        format!("{}m{:.3}s", m, s)
    };
    println!("{} {}", fmt(times.tms_utime), fmt(times.tms_stime));
    println!("{} {}", fmt(times.tms_cutime), fmt(times.tms_cstime));
    0
}

// ---------------------------------------------------------------------------
// dirs / pushd / popd
// ---------------------------------------------------------------------------

fn builtin_dirs(shell: &mut Shell, args: &[String]) -> i32 {
    let mut long = false;
    let mut print_newlines = false;
    let mut clear = false;
    let mut verbose = false;
    let mut numeric_arg: Option<String> = None;
    let mut error_arg: Option<String> = None;
    let mut invalid_option: Option<String> = None;

    for a in args {
        match a.as_str() {
            "--" => break,
            "-l" => long = true,
            "-p" => print_newlines = true,
            "-c" => clear = true,
            "-v" => verbose = true,
            s if s.starts_with('+') => {
                // +N: only valid if digits follow
                if s[1..].parse::<usize>().is_ok() {
                    numeric_arg = Some(a.clone());
                } else {
                    // +<non-number> is invalid
                    error_arg = Some(a.clone());
                }
            }
            s if s.starts_with('-') => {
                // -N (digit): numeric arg; -<letter>: flag or error
                let rest = &s[1..];
                if rest.parse::<usize>().is_ok() {
                    numeric_arg = Some(a.clone());
                } else if rest.is_empty() || rest.chars().next().map_or(false, |c| !c.is_ascii_alphabetic() || !"clpv".contains(c)) {
                    // starts with '-' but isn't a known flag and isn't digits
                    error_arg = Some(a.clone());
                }
                // known flags already handled above
            }
            s => {
                // bare token without leading +/-: could be a bare number (invalid) or invalid option
                if s.parse::<usize>().is_ok() {
                    invalid_option = Some(a.clone());
                } else {
                    invalid_option = Some(a.clone());
                }
            }
        }
    }

    // Error: invalid number (e.g. dirs -m)
    if let Some(ref bad) = error_arg {
        let prefix = shell.err_prefix_with_line();
        eprintln!("{}: dirs: {}: invalid number", prefix, bad);
        eprintln!("dirs: usage: dirs [-clpv] [+N] [-N]");
        return 1;
    }

    // Error: invalid option (e.g. dirs 7 — bare number without +/-)
    if let Some(ref bad) = invalid_option {
        let prefix = shell.err_prefix_with_line();
        eprintln!("{}: dirs: {}: invalid option", prefix, bad);
        eprintln!("dirs: usage: dirs [-clpv] [+N] [-N]");
        return 1;
    }

    if clear {
        let cwd = shell.get_var("PWD").unwrap_or_default();
        shell.dirstack.clear();
        shell.dirstack.push(cwd);
        return 0;
    }

    let home = shell.get_var("HOME").unwrap_or_default();

    // Print specific entry
    if let Some(ref n_arg) = numeric_arg {
        let n: usize = n_arg[1..].parse().unwrap();
        let len = shell.dirstack.len();
        let idx = if n_arg.starts_with('-') {
            // -N counts from the end: -0 = last, -1 = second-to-last, etc.
            if n >= len {
                let prefix = shell.err_prefix_with_line();
                eprintln!("{}: dirs: {}: directory stack index out of range", prefix, n);
                return 1;
            }
            len - 1 - n
        } else {
            if n >= len {
                let prefix = shell.err_prefix_with_line();
                eprintln!("{}: dirs: {}: directory stack index out of range", prefix, n);
                return 1;
            }
            n
        };
        if let Some(dir) = shell.dirstack.get(idx) {
            let display = if !long && !home.is_empty() && dir.starts_with(&home) {
                format!("~{}", &dir[home.len()..])
            } else {
                dir.clone()
            };
            if verbose {
                println!("{:2}  {}", idx, display);
            } else {
                println!("{}", display);
            }
        }
        return 0;
    }

    for (i, dir) in shell.dirstack.iter().enumerate() {
        let display = if !long && !home.is_empty() && dir.starts_with(&home) {
            format!("~{}", &dir[home.len()..])
        } else {
            dir.clone()
        };
        if verbose {
            println!("{:2}  {}", i, display);
        } else if print_newlines {
            println!("{}", display);
        } else {
            print!("{}", display);
            if i + 1 < shell.dirstack.len() { print!(" "); }
        }
    }
    if !verbose && !print_newlines {
        println!();
    }
    0
}

fn builtin_pushd(shell: &mut Shell, args: &[String]) -> i32 {
    let mut no_cd = false;
    let mut idx = 0;

    while idx < args.len() {
        match args[idx].as_str() {
            "-n" => { no_cd = true; idx += 1; }
            "--" => { idx += 1; break; }
            _ => break,
        }
    }

    let cwd = shell.get_var("PWD")
        .or_else(|| std::env::current_dir().ok().map(|p| p.to_string_lossy().to_string()))
        .unwrap_or_default();

    if args[idx..].is_empty() {
        // pushd with no args: rotate stack (swap top two)
        if shell.dirstack.len() < 2 {
            let prefix = shell.err_prefix_with_line();
            eprintln!("{}: pushd: no other directory", prefix);
            return 1;
        }
        // Swap the top two entries
        shell.dirstack.swap(0, 1);
        if !no_cd {
            let new_dir = shell.dirstack[0].clone();
            let status = builtin_cd(shell, &[new_dir]);
            if status != 0 { return status; }
        }
        return builtin_dirs(shell, &[]);
    }

    let target = args[idx].clone();

    // Handle +N: rotate left by N
    if let Some(rest) = target.strip_prefix('+') {
        if let Ok(n) = rest.parse::<usize>() {
            if n >= shell.dirstack.len() {
                let prefix = shell.err_prefix_with_line();
                eprintln!("{}: pushd: +{}: directory stack index out of range", prefix, n);
                return 1;
            }
            shell.dirstack.rotate_left(n);
            if !no_cd {
                let new_dir = shell.dirstack[0].clone();
                let status = builtin_cd(shell, &[new_dir]);
                if status != 0 { return status; }
                return builtin_dirs(shell, &[]);
            }
            // -n +N: rotate silently, no output
            return 0;
        } else {
            // +<non-number>: invalid number
            let prefix = shell.err_prefix_with_line();
            eprintln!("{}: pushd: {}: invalid number", prefix, target);
            eprintln!("pushd: usage: pushd [-n] [+N | -N | dir]");
            return 1;
        }
    }

    // Handle -N: bring element at index (len-1-N) to front by rotating left
    if let Some(rest) = target.strip_prefix('-') {
        if let Ok(n) = rest.parse::<usize>() {
            let len = shell.dirstack.len();
            if n >= len {
                let prefix = shell.err_prefix_with_line();
                eprintln!("{}: pushd: -{}: directory stack index out of range", prefix, n);
                return 1;
            }
            if len > 0 {
                // -N means bring element at (len-1-n) to the top
                let rot = len - 1 - n;
                shell.dirstack.rotate_left(rot);
            }
            if !no_cd {
                let new_dir = shell.dirstack[0].clone();
                let status = builtin_cd(shell, &[new_dir]);
                if status != 0 { return status; }
                return builtin_dirs(shell, &[]);
            }
            // -n -N: rotate silently, no output
            return 0;
        } else {
            // -<non-number> that isn't a flag: invalid number
            let prefix = shell.err_prefix_with_line();
            eprintln!("{}: pushd: {}: invalid number", prefix, target);
            eprintln!("pushd: usage: pushd [-n] [+N | -N | dir]");
            return 1;
        }
    }

    // Regular directory argument
    if !no_cd {
        // Change to the target directory
        let path = std::path::Path::new(&target);
        match std::fs::metadata(&path) {
            Ok(m) if m.is_dir() => {}
            Ok(_) => {
                let prefix = shell.err_prefix_with_line();
                eprintln!("{}: pushd: {}: Not a directory", prefix, target);
                return 1;
            }
            Err(e) => {
                let prefix = shell.err_prefix_with_line();
                eprintln!("{}: pushd: {}: {}", prefix, target, io_err_msg(&e));
                return 1;
            }
        }
        let status = builtin_cd(shell, &[target.clone()]);
        if status != 0 { return status; }
        // cd updated dirstack[0] to the new directory.
        // Insert the old cwd at position 1 to push it down.
        shell.dirstack.insert(1, cwd);
    } else {
        // -n: don't cd, just add the directory to position 1
        shell.dirstack.insert(1, target.clone());
    }

    builtin_dirs(shell, &[])
}

fn builtin_popd(shell: &mut Shell, args: &[String]) -> i32 {
    let mut no_cd = false;
    let mut idx = 0;
    let mut saw_endopts = false;

    while idx < args.len() {
        match args[idx].as_str() {
            "-n" => { no_cd = true; idx += 1; }
            "--" => { saw_endopts = true; idx += 1; break; }
            _ => break,
        }
    }

    if shell.dirstack.is_empty() {
        let prefix = shell.err_prefix_with_line();
        eprintln!("{}: popd: directory stack empty", prefix);
        return 1;
    }

    // Handle +N / -N
    if !saw_endopts {
        if let Some(target) = args[idx..].first().cloned() {
        if let Some(rest) = target.strip_prefix('+') {
            if let Ok(n) = rest.parse::<usize>() {
                if n >= shell.dirstack.len() {
                    let prefix = shell.err_prefix_with_line();
                    eprintln!("{}: popd: +{}: directory stack index out of range", prefix, n);
                    return 1;
                }
                shell.dirstack.remove(n);
                if !no_cd && n == 0 && !shell.dirstack.is_empty() {
                    let new_dir = shell.dirstack[0].clone();
                    let status = builtin_cd(shell, &[new_dir]);
                    if status != 0 { return status; }
                }
                return builtin_dirs(shell, &[]);
            } else {
                // +<non-number>: invalid number
                let prefix = shell.err_prefix_with_line();
                eprintln!("{}: popd: {}: invalid number", prefix, target);
                eprintln!("popd: usage: popd [-n] [+N | -N]");
                return 1;
            }
        }
        if let Some(rest) = target.strip_prefix('-') {
            if let Ok(n) = rest.parse::<usize>() {
                let len = shell.dirstack.len();
                if n >= len {
                    let prefix = shell.err_prefix_with_line();
                    eprintln!("{}: popd: -{}: directory stack index out of range", prefix, n);
                    return 1;
                }
                let actual = len - 1 - n;
                shell.dirstack.remove(actual);
                if !no_cd && actual == 0 && !shell.dirstack.is_empty() {
                    let new_dir = shell.dirstack[0].clone();
                    let status = builtin_cd(shell, &[new_dir]);
                    if status != 0 { return status; }
                }
                return builtin_dirs(shell, &[]);
            } else {
                // -<non-number>: invalid number
                let prefix = shell.err_prefix_with_line();
                eprintln!("{}: popd: {}: invalid number", prefix, target);
                eprintln!("popd: usage: popd [-n] [+N | -N]");
                return 1;
            }
        }
        // Unknown argument
        let prefix = shell.err_prefix_with_line();
        eprintln!("{}: popd: {}: invalid argument", prefix, target);
        eprintln!("popd: usage: popd [-n] [+N | -N]");
        return 1;
    }
    }

    if shell.dirstack.len() <= 1 {
        let prefix = shell.err_prefix_with_line();
        eprintln!("{}: popd: directory stack empty", prefix);
        return 1;
    }

    shell.dirstack.remove(0);
    if !no_cd && !shell.dirstack.is_empty() {
        let new_dir = shell.dirstack[0].clone();
        let status = builtin_cd(shell, &[new_dir]);
        if status != 0 { return status; }
    }
    builtin_dirs(shell, &[])
}

// ---------------------------------------------------------------------------
// mapfile / readarray
// ---------------------------------------------------------------------------

fn builtin_mapfile(shell: &mut Shell, args: &[String]) -> i32 {
    let mut delimiter = '\n';
    let mut count: Option<usize> = None;
    let mut origin: usize = 0;
    let mut skip: usize = 0;
    let mut fd: RawFd = 0;
    let mut var_name = "MAPFILE".to_string();
    let mut callback: Option<String> = None;
    let mut callback_quantum: usize = 1;
    let mut strip_delimiter = false;
    let mut idx = 0;

    while idx < args.len() {
        match args[idx].as_str() {
            "-d" => {
                idx += 1;
                if idx < args.len() {
                    // Bash: an empty delimiter means NUL terminator.
                    delimiter = args[idx].chars().next().unwrap_or('\0');
                    idx += 1;
                }
            }
            "-n" => {
                idx += 1;
                if idx < args.len() {
                    count = args[idx].parse().ok();
                    idx += 1;
                }
            }
            "-O" => {
                idx += 1;
                if idx < args.len() {
                    origin = args[idx].parse().unwrap_or(0);
                    idx += 1;
                }
            }
            "-s" => {
                idx += 1;
                if idx < args.len() {
                    skip = args[idx].parse().unwrap_or(0);
                    idx += 1;
                }
            }
            "-t" => { strip_delimiter = true; idx += 1; }
            "-u" => {
                idx += 1;
                if idx < args.len() {
                    match args[idx].parse::<RawFd>() {
                        Ok(n) => { fd = n; }
                        Err(_) => {
                            eprintln!("{}: mapfile: {}: invalid file descriptor specification",
                                shell.err_prefix_with_line(), args[idx]);
                            return 1;
                        }
                    }
                    idx += 1;
                }
            }
            "-C" => {
                idx += 1;
                if idx < args.len() {
                    callback = Some(args[idx].clone());
                    idx += 1;
                }
            }
            "-c" => {
                idx += 1;
                if idx < args.len() {
                    callback_quantum = args[idx].parse().unwrap_or(1);
                    idx += 1;
                }
            }
            _ => {
                var_name = args[idx].clone();
                let _ = idx; // idx no longer used after this
                break;
            }
        }
    }

    // Validate fd if non-default
    if fd != 0 {
        let flags = unsafe { libc::fcntl(fd, libc::F_GETFD) };
        if flags == -1 {
            eprintln!("{}: mapfile: {}: invalid file descriptor: Bad file descriptor",
                shell.err_prefix_with_line(), fd);
            return 1;
        }
    }

    // Validate variable name
    if var_name.is_empty() {
        eprintln!("{}: mapfile: empty array variable name",
            shell.err_prefix_with_line());
        return 1;
    }
    if !is_valid_identifier(&var_name) {
        eprintln!("{}: mapfile: `{}': not a valid identifier",
            shell.err_prefix_with_line(), var_name);
        return 1;
    }

    // Read all lines first; callback fires after skip/count have been applied.
    if shell.vars.is_nameref(&var_name)
        && shell.vars.get_nameref_target(&var_name).unwrap_or_default().is_empty()
    {
        eprintln!("{}: warning: {}: removing nameref attribute",
            shell.err_prefix_with_line(), var_name);
        shell.vars.strip_nameref_value(&var_name);
    }
    if let Some(target) = nameref_subscript_target(shell, &var_name) {
        eprintln!("{}: mapfile: `{}': not a valid identifier",
            shell.err_prefix_with_line(), target);
        return 1;
    }
    shell.vars.declare_array(&var_name);
    shell.vars.mark_initialized(&var_name);
    let mut raw_lines: Vec<String> = Vec::new();
    // Decode PUA-encoded delimiter (e.g. $'\xff') back to raw byte.
    let delim_cp = delimiter as u32;
    let delim_byte = if delim_cp >= crate::expand::RAW_BYTE_BASE
        && delim_cp <= crate::expand::RAW_BYTE_BASE + 0xFF
    {
        (delim_cp - crate::expand::RAW_BYTE_BASE) as u8
    } else {
        delimiter as u8
    };
    let max_lines = count.map(|c| c + skip);

    loop {
        let mut line_bytes = Vec::new();
        loop {
            let mut buf = [0u8; 1];
            let n = unsafe { libc::read(fd, buf.as_mut_ptr() as *mut libc::c_void, 1) };
            if n <= 0 { break; }
            line_bytes.push(buf[0]);
            if buf[0] == delim_byte { break; }
        }
        if line_bytes.is_empty() {
            break;
        }
        // Convert raw bytes to a Rust String, encoding high bytes (0x80-0xFF)
        // as PUA codepoints (U+F880–U+F8FF) to preserve them round-trip.
        let mut s = String::new();
        for &b in &line_bytes {
            if b >= 0x80 {
                s.push_str(&crate::expand::encode_raw_byte(b));
            } else {
                s.push(b as char);
            }
        }
        raw_lines.push(s);
        if let Some(m) = max_lines {
            if raw_lines.len() >= m { break; }
        }
    }

    // Skip first `skip` lines, then place remaining starting at `origin`.
    let data: Vec<String> = raw_lines.into_iter().skip(skip).collect();

    let cb_quantum = callback_quantum.max(1);
    let mut lines_since_cb: usize = 0;
    // Bash special-cases NUL delimiter: the NUL byte is always stripped
    // from the line value, even without -t. This avoids embedded NULs in
    // shell variables.
    let always_strip = delimiter == '\0';
    for (i, raw) in data.iter().enumerate() {
        let idx = origin + i;
        let mut line_for_cb = raw.clone();
        if always_strip && line_for_cb.ends_with(delimiter) {
            line_for_cb.pop();
        }
        if let Some(cb) = &callback {
            lines_since_cb += 1;
            if lines_since_cb >= cb_quantum {
                lines_since_cb = 0;
                // Bash single-quotes the line when constructing the callback
                // expression: `<callback> <idx> '<line>'`.
                let quoted = format!("'{}'", line_for_cb.replace('\'', "'\\''"));
                let cmd = format!("{} {} {}", cb, idx, quoted);
                shell.run_string(&cmd);
            }
        }
        let mut val = raw.clone();
        if (strip_delimiter || always_strip) && val.ends_with(delimiter) {
            val.pop();
        }
        shell.vars.set_array_element(&var_name, idx, &val);
    }

    0
}

// ---------------------------------------------------------------------------
// caller
// ---------------------------------------------------------------------------

fn builtin_caller(shell: &mut Shell, args: &[String]) -> i32 {
    // Reject flag-like first args (bash: `-Z` not supported).
    if let Some(arg) = args.first() {
        if arg.starts_with('-') && arg.as_str() != "--" && !arg[1..].chars().all(|c| c.is_ascii_digit()) {
            eprintln!("{}: caller: {}: invalid option",
                shell.err_prefix_with_line(), arg);
            eprintln!("caller: usage: caller [expr]");
            return 2;
        }
    }
    // `caller [expr]` returns info about the call stack.
    // With no argument, prints "line source" for the current frame.
    // With an integer expr, prints "line fn source" for that stack level.
    // When not inside a function call, the "current frame" for a bare
    // `caller` is the outermost script context — bash prints "0 NULL".
    let expr = args.first();
    let level: usize = match expr {
        None => 0,
        Some(s) => match s.parse::<usize>() {
            Ok(n) => n,
            Err(_) => {
                eprintln!("{}: caller: {}: invalid number",
                    shell.err_prefix_with_line(), s);
                eprintln!("caller: usage: caller [expr]");
                return 1;
            }
        },
    };
    let bash_lineno = shell.vars.get_array("BASH_LINENO").unwrap_or_else(|| vec!["0".to_string()]);
    let bash_source = shell.vars.get_array("BASH_SOURCE").unwrap_or_default();
    let funcname = shell.vars.get_array("FUNCNAME").unwrap_or_default();
    if expr.is_none() {
        // Bare `caller`: in a function, print "line source".
        // Outside any function, print "0 NULL" and return 1.
        if shell.funcname_stack.is_empty() {
            println!("0 NULL");
            return 1;
        }
        let lineno = bash_lineno.get(0).cloned().unwrap_or_else(|| "0".to_string());
        let source = bash_source.get(1)
            .cloned()
            .or_else(|| bash_source.get(0).cloned())
            .unwrap_or_else(|| "main".to_string());
        println!("{} {}", lineno, source);
        return 0;
    }
    // `caller N`: require level within the call stack.
    if level >= shell.funcname_stack.len() {
        return 1;
    }
    let lineno = bash_lineno.get(level).cloned().unwrap_or_else(|| "0".to_string());
    let caller_func = funcname.get(level + 1).cloned().unwrap_or_else(|| "main".to_string());
    let source = bash_source.get(level + 1)
        .cloned()
        .or_else(|| bash_source.last().cloned())
        .unwrap_or_else(|| "main".to_string());
    println!("{} {} {}", lineno, caller_func, source);
    0
}

// ---------------------------------------------------------------------------
// Helper: valid identifier check
// ---------------------------------------------------------------------------

fn is_valid_identifier(s: &str) -> bool {
    if s.is_empty() {
        return false;
    }
    let mut chars = s.chars();
    let first = chars.next().unwrap();
    if !first.is_alphabetic() && first != '_' {
        return false;
    }
    chars.all(|c| c.is_alphanumeric() || c == '_')
}

/// Split the body of a compound-array literal into its elements.
/// The body is whatever was between the parens — e.g. for
/// `([1]="" [2]="bdef" "test")` the body is `[1]="" [2]="bdef" "test"`.
/// Quotes (`"..."` and `'...'`) group characters together and are
/// *preserved* in the output (the caller runs shell expansion on
/// each element which handles the unquoting).  Whitespace outside
/// quotes separates elements.
fn split_compound_array_body(body: &str) -> Vec<String> {
    let mut out: Vec<String> = Vec::new();
    let mut cur = String::new();
    let mut in_single = false;
    let mut in_double = false;
    let mut escape = false;
    let chars: Vec<char> = body.chars().collect();
    let mut cmdsub_depth: i32 = 0;
    let mut i = 0usize;
    while i < chars.len() {
        let c = chars[i];
        if escape {
            cur.push(c);
            escape = false;
            i += 1;
            continue;
        }
        if c == '\\' && !in_single {
            cur.push(c);
            escape = true;
            i += 1;
            continue;
        }
        if c == '\'' && !in_double {
            in_single = !in_single;
            cur.push(c);
            i += 1;
            continue;
        }
        if c == '"' && !in_single {
            in_double = !in_double;
            cur.push(c);
            i += 1;
            continue;
        }
        if !in_single && !in_double {
            if c == '$' && i + 1 < chars.len() && chars[i + 1] == '(' {
                cur.push(c);
                i += 1;
                cur.push(chars[i]);
                cmdsub_depth += 1;
                i += 1;
                continue;
            }
            if cmdsub_depth > 0 {
                if c == '(' {
                    cmdsub_depth += 1;
                } else if c == ')' {
                    cmdsub_depth -= 1;
                }
                cur.push(c);
                i += 1;
                continue;
            }
        }
        if (c == ' ' || c == '\t' || c == '\n') && !in_single && !in_double {
            if !cur.is_empty() {
                out.push(std::mem::take(&mut cur));
            }
            i += 1;
            continue;
        }
        cur.push(c);
        i += 1;
    }
    if !cur.is_empty() {
        out.push(cur);
    }
    out
}

// ---------------------------------------------------------------------------
// [[ — conditional command
// ---------------------------------------------------------------------------

fn builtin_double_bracket(shell: &mut Shell, args: &[String]) -> i32 {
    // Strip trailing ]]
    let inner = if args.last().map(|s| s.as_str()) == Some("]]") {
        &args[..args.len() - 1]
    } else {
        eprintln!("{}: [[: missing ']]'", crate::exec::shell_name());
        return 2;
    };

    if inner.is_empty() {
        return 1;
    }

    if std::env::var("BRASH_DEBUG_COND").is_ok() {
        eprintln!("[cond args]: {:?}", inner);
    }

    let tokens: Vec<&str> = inner.iter().map(|s| s.as_str()).collect();
    let mut pos = 0;
    // Store the script-line prefix so cond_parse_* can emit errors
    // with the full bash-style prefix.  Cleared after the call.
    COND_ERR_PREFIX.with(|p| *p.borrow_mut() = shell.err_prefix_with_line_for_syntax());
    COND_ERR_STATUS.with(|s| s.set(None));
    // Expose a pointer to the shell's variables so -eq/-lt/... can
    // resolve variables via arithmetic evaluation.
    let vars_ptr: *mut crate::vars::Variables = &mut shell.vars as *mut _;
    COND_VARS_PTR.with(|p| p.set(vars_ptr));
    COND_ASSOC_EXPAND_ONCE.with(|c| c.set(shell.shopt.contains("assoc_expand_once")));
    let result = cond_parse_or(&tokens, &mut pos);
    COND_VARS_PTR.with(|p| p.set(std::ptr::null_mut()));
    COND_ASSOC_EXPAND_ONCE.with(|c| c.set(false));
    let err_status = COND_ERR_STATUS.with(|s| s.get());
    if let Some(status) = err_status {
        return status;
    }
    // Leftover tokens after a successful sub-parse: bash 5.3 reports a
    // detailed three-line error pinpointing the offending token.  We
    // ONLY trigger this for "well-known" leftover tokens so weird
    // locale-induced tokenization (e.g. PUA-encoded raw bytes from
    // Big5 expansion) doesn't accidentally surface as syntax errors.
    if pos < tokens.len() && cond_token_is_clear_syntax_error(tokens[pos]) {
        let unexpected = tokens[pos];
        let prev = if pos > 0 { tokens[pos - 1] } else { "" };
        let msg = classify_cond_leftover(prev, unexpected, &tokens, pos);
        let prefix = cond_err_prefix();
        eprintln!("{}: {}", prefix, msg);
        eprintln!("{}: syntax error near `{}'", prefix, unexpected);
        eprintln!("{}: `{}'", prefix, render_cond_expression(&tokens));
        return 2;
    }
    if result { 0 } else { 1 }
}

/// True when an unconsumed token clearly indicates a syntax error in a
/// `[[ ]]` expression — restricts our leftover-token error reporting to
/// tokens bash actually flags, avoiding false positives from
/// weird-byte tokenization.
fn cond_token_is_clear_syntax_error(token: &str) -> bool {
    // Control operators that can never legitimately appear inside
    // `[[ … ]]`.
    if matches!(token, "&" | "|" | ";" | "&&" | "||") {
        return true;
    }
    // Plain digit or short operand following a complete unary
    // expression — bash flags these too (`[[ -Q 7 ]]`).  Restrict to
    // tokens that look like simple operand identifiers / numbers and
    // contain no PUA-encoded raw bytes (which suggest tokenizer
    // confusion rather than a real syntax error).
    if token.chars().all(|c| c.is_ascii_alphanumeric() || c == '_') && !token.is_empty() {
        return true;
    }
    false
}

/// Render the original `[[ … ]]` token stream back into a single string
/// for inclusion in error messages.  Joins tokens with single spaces and
/// appends the closing `]]`.
fn render_cond_expression(tokens: &[&str]) -> String {
    let mut out = String::from("[[");
    for t in tokens.iter() {
        if !t.is_empty() {
            out.push(' ');
            out.push_str(t);
        }
    }
    out.push_str(" ]]");
    out
}

/// Classify a leftover-token error into one of bash's specific messages.
fn classify_cond_leftover(prev: &str, unexpected: &str, tokens: &[&str], pos: usize) -> String {
    // After a unary operator that already took its operand, a stray
    // arg is "unexpected argument `X' to conditional unary operator".
    let unary_ops = ["-z", "-n", "-e", "-a", "-f", "-d", "-r", "-w", "-x",
                     "-s", "-L", "-h", "-p", "-S", "-b", "-c", "-g", "-u",
                     "-k", "-O", "-G", "-N", "-t", "-v", "-R", "-o"];
    let binary_ops = ["==", "=", "!=", "=~", "<", ">", "-eq", "-ne",
                      "-lt", "-le", "-gt", "-ge", "-nt", "-ot", "-ef"];
    // If the token at pos-2 was a unary op and we consumed unary+operand,
    // an extra arg is "unexpected argument to unary operator".
    if pos >= 2 && unary_ops.contains(&tokens[pos - 2]) {
        return format!(
            "unexpected argument `{}' to conditional unary operator",
            unexpected
        );
    }
    // If the previous token was an operand AND we just finished a binary
    // op (positions pos-3 was operand, pos-2 was op), the leftover is
    // "unexpected argument `X' to conditional binary operator".
    if pos >= 3 && binary_ops.contains(&tokens[pos - 2]) {
        return format!(
            "unexpected argument `{}' to conditional binary operator",
            unexpected
        );
    }
    // After a complete primary, an unexpected token is normally
    // "conditional binary operator expected".
    if !prev.is_empty() && !unexpected.starts_with('-') {
        return format!(
            "unexpected token `{}', conditional binary operator expected",
            unexpected
        );
    }
    // Default: unexpected-token-in-conditional-command form.
    format!("syntax error in conditional expression: unexpected token `{}'", unexpected)
}

thread_local! {
    static COND_ERR_PREFIX: std::cell::RefCell<String> = std::cell::RefCell::new(String::new());
    static COND_ERR_STATUS: std::cell::Cell<Option<i32>> = const { std::cell::Cell::new(None) };
    /// Raw pointer to the shell's Variables for the duration of a
    /// [[ ]] invocation.  Set in builtin_double_bracket before calling
    /// cond_parse_or and cleared after.  Used by the arithmetic
    /// operator path so `-eq` etc. can resolve shell variables.
    static COND_VARS_PTR: std::cell::Cell<*mut crate::vars::Variables> =
        const { std::cell::Cell::new(std::ptr::null_mut()) };
    static COND_ASSOC_EXPAND_ONCE: std::cell::Cell<bool> =
        const { std::cell::Cell::new(false) };
}

fn cond_err_prefix() -> String {
    COND_ERR_PREFIX.with(|p| p.borrow().clone())
}

/// Format a [[ -eq etc. arithmetic failure message to match bash.
/// Bash's wording: `"<expr>: arithmetic syntax error: operand expected
/// (error token is "<tok>")"` for syntax errors; `"integer expected"`
/// only when the string is plainly non-numeric with no arithmetic
/// operators.
fn format_cond_arith_err(err: &str, token: &str) -> String {
    // If it's already a specific arith error, pass through — but drop
    // the duplicated (error token is …) suffix if already there, since
    // the caller synthesizes its own.
    if err.contains("arithmetic syntax error") || err.contains("syntax error") {
        // Add "(error token is ...)" suffix with last non-digit suffix
        // as an approximation.
        if err.contains("(error token is") {
            return err.to_string();
        }
        let tok_suffix: String = token.chars().skip_while(|c| c.is_ascii_digit() || *c == '-').collect();
        let mut tok = if tok_suffix.is_empty() { token.to_string() } else { tok_suffix };
        let trimmed = tok.trim();
        if trimmed.len() > 1 {
            let mut chars = trimmed.chars();
            if let Some(first) = chars.next() {
                if "+-*/%&|^<>!~".contains(first) && chars.clone().all(|c| c == first) {
                    tok = first.to_string();
                }
            }
        }
        return format!("{} (error token is \"{}\")", err, tok);
    }
    "integer expected".to_string()
}

fn cond_parse_or(args: &[&str], pos: &mut usize) -> bool {
    let mut left = cond_parse_and(args, pos);
    while *pos < args.len() && args[*pos] == "||" {
        *pos += 1;
        let right = cond_parse_and(args, pos);
        left = left || right;
    }
    left
}

fn cond_parse_and(args: &[&str], pos: &mut usize) -> bool {
    let mut left = cond_parse_not(args, pos);
    while *pos < args.len() && args[*pos] == "&&" {
        *pos += 1;
        let right = cond_parse_not(args, pos);
        left = left && right;
    }
    left
}

fn cond_parse_not(args: &[&str], pos: &mut usize) -> bool {
    if *pos < args.len() && args[*pos] == "!" {
        *pos += 1;
        return !cond_parse_not(args, pos);
    }
    cond_parse_primary(args, pos)
}

fn cond_parse_primary(args: &[&str], pos: &mut usize) -> bool {
    if *pos >= args.len() {
        return false;
    }

    // Control operators (`&`, `|`, `;`) are never valid as primaries
    // in `[[ … ]]` — bash flags them as "unexpected token in
    // conditional command".  Detect early and emit the bash-style
    // three-line error.
    let first = args[*pos];
    if matches!(first, "&" | "|" | ";" | "&&" | "||") && *pos == 0 {
        // Build the reconstructed expression (`[[ <args> ]]`) for the
        // third error line.  The surrounding builtin_double_bracket
        // doesn't expose the original token list directly here, so we
        // assemble it from `args`.
        let mut reconstruction = String::from("[[");
        for a in args {
            reconstruction.push(' ');
            reconstruction.push_str(a);
        }
        reconstruction.push_str(" ]]");
        let prefix = cond_err_prefix();
        eprintln!("{}: unexpected token `{}' in conditional command", prefix, first);
        eprintln!("{}: syntax error near `{}'", prefix, first);
        eprintln!("{}: `{}'", prefix, reconstruction);
        COND_ERR_STATUS.with(|s| s.set(Some(2)));
        *pos = args.len();
        return false;
    }

    // Parenthesized expression
    if args[*pos] == "(" {
        *pos += 1;
        let result = cond_parse_or(args, pos);
        if *pos < args.len() && args[*pos] == ")" {
            *pos += 1;
        }
        return result;
    }

    // Check for binary operators: look ahead for an operator at pos+1
    if *pos + 2 <= args.len() {
        let maybe_op = if *pos + 1 < args.len() { args[*pos + 1] } else { "" };
        match maybe_op {
            "==" | "=" => {
                let left = args[*pos];
                let pattern = args[*pos + 2];
                *pos += 3;
                return cond_pattern_match(left, pattern);
            }
            "!=" => {
                let left = args[*pos];
                let pattern = args[*pos + 2];
                *pos += 3;
                return !cond_pattern_match(left, pattern);
            }
            "=~" => {
                let left = args[*pos];
                let re_str = args[*pos + 2];
                *pos += 3;
                // Collect remaining regex parts (unquoted spaces in regex)
                // In practice the parser should handle this, but gather extras
                return cond_regex_match(left, re_str);
            }
            "<" | ">" => {
                if *pos + 2 >= args.len() {
                    // No right operand for `<`/`>` — bash classifies
                    // this based on what the LEFT side was:
                    //   * a unary op (`-n`/`-z`/etc.): the operator
                    //     here is treated as a (bad) argument to the
                    //     unary op.
                    //   * anything else: silent failure (legacy
                    //     behaviour).
                    let left = args[*pos];
                    let op = args[*pos + 1];
                    let unary_ops_set: &[&str] = &[
                        "-z", "-n", "-e", "-a", "-f", "-d", "-r", "-w", "-x",
                        "-s", "-L", "-h", "-p", "-S", "-b", "-c", "-g", "-u",
                        "-k", "-O", "-G", "-N", "-t", "-v", "-R", "-o",
                    ];
                    if unary_ops_set.contains(&left) {
                        let mut reconstruction = String::from("[[");
                        for a in args {
                            reconstruction.push(' ');
                            reconstruction.push_str(a);
                        }
                        reconstruction.push_str(" ]]");
                        let prefix = cond_err_prefix();
                        eprintln!("{}: unexpected argument `{}' to conditional unary operator", prefix, op);
                        eprintln!("{}: syntax error near `{}'", prefix, op);
                        eprintln!("{}: `{}'", prefix, reconstruction);
                        COND_ERR_STATUS.with(|s| s.set(Some(2)));
                    }
                    *pos = args.len();
                    return false;
                }
                let left = args[*pos];
                let op = args[*pos + 1];
                let right = args[*pos + 2];
                // Reject `&`/`|`/`;` as the right operand of `<`/`>` —
                // bash flags this as "unexpected argument to conditional
                // binary operator".
                if matches!(right, "&" | "|" | ";" | "&&" | "||") {
                    let mut reconstruction = String::from("[[");
                    for a in args {
                        reconstruction.push(' ');
                        reconstruction.push_str(a);
                    }
                    reconstruction.push_str(" ]]");
                    let prefix = cond_err_prefix();
                    eprintln!("{}: unexpected argument `{}' to conditional binary operator", prefix, right);
                    eprintln!("{}: syntax error near `{}'", prefix, right);
                    eprintln!("{}: `{}'", prefix, reconstruction);
                    COND_ERR_STATUS.with(|s| s.set(Some(2)));
                    *pos = args.len();
                    return false;
                }
                *pos += 3;
                return if op == "<" { left < right } else { left > right };
            }
            "-eq" | "-ne" | "-lt" | "-le" | "-gt" | "-ge" => {
                let left = args[*pos];
                let op = args[*pos + 1];
                let right = args[*pos + 2];
                *pos += 3;
                // Bash's [[ -eq/-ne/-lt/-le/-gt/-ge ]] forces
                // arithmetic evaluation of both operands.  Use a
                // temporary Variables so we don't corrupt the caller.
                let parse_arith = |s: &str| -> Result<i64, String> {
                    // Try direct int first, then full arith eval using
                    // the shell's Variables (so `-eq A` with `A=7`
                    // works).
                    let trimmed = s.trim();
                    if trimmed.is_empty() {
                        // Bash treats empty operands as 0 in [[ ... ]].
                        return Ok(0);
                    }
                    if let Ok(v) = trimmed.parse::<i64>() {
                        return Ok(v);
                    }
                    let vars_ptr = COND_VARS_PTR.with(|p| p.get());
                    if vars_ptr.is_null() {
                        // No shell vars available (shouldn't happen).
                        let mut empty_vars = crate::vars::Variables::new();
                        if let Some(result) = cond_numeric_operand_value(trimmed, &mut empty_vars) {
                            return result;
                        }
                        return crate::arithmetic::eval_expr_mut_no_cmdsub_assoc_once(
                            trimmed,
                            &mut empty_vars,
                        );
                    }
                    // SAFETY: the pointer is set by builtin_double_bracket
                    // and held for the duration of cond_parse_* call chain.
                    unsafe {
                        if let Some(result) = cond_numeric_operand_value(trimmed, &mut *vars_ptr) {
                            return result;
                        }
                        crate::arithmetic::eval_expr_mut_no_cmdsub_assoc_once(
                            trimmed,
                            &mut *vars_ptr,
                        )
                    }
                };
                let l = match parse_arith(left) {
                    Ok(v) => v,
                    Err(e) => {
                        // Bash: if arith eval fails, emit the arith
                        // error message with the token prefix; if the
                        // value was just a non-number word (never
                        // reached the arith parser), emit "integer
                        // expected".  eval_expr's output already has
                        // an (error token is …) suffix.
                        eprintln!("{}: [[: {}: {}", cond_err_prefix(), left,
                            format_cond_arith_err(&e, left));
                        // Arith syntax errors (not missing-integer)
                        // return 1 — bash treats the whole expression
                        // as false but the status is a normal
                        // comparison-false, not an error (2).
                        COND_ERR_STATUS.with(|s| s.set(Some(1)));
                        return false;
                    }
                };
                let r = match parse_arith(right) {
                    Ok(v) => v,
                    Err(e) => {
                        eprintln!("{}: [[: {}: {}", cond_err_prefix(), right,
                            format_cond_arith_err(&e, right));
                        COND_ERR_STATUS.with(|s| s.set(Some(1)));
                        return false;
                    }
                };
                return match op {
                    "-eq" => l == r,
                    "-ne" => l != r,
                    "-lt" => l < r,
                    "-le" => l <= r,
                    "-gt" => l > r,
                    "-ge" => l >= r,
                    _ => false,
                };
            }
            "-nt" => {
                let left = args[*pos];
                let right = args[*pos + 2];
                *pos += 3;
                let lm = std::fs::metadata(left).and_then(|m| m.modified()).ok();
                let rm = std::fs::metadata(right).and_then(|m| m.modified()).ok();
                return match (lm, rm) {
                    (Some(l), Some(r)) => l > r,
                    (Some(_), None) => true,
                    _ => false,
                };
            }
            "-ot" => {
                let left = args[*pos];
                let right = args[*pos + 2];
                *pos += 3;
                let lm = std::fs::metadata(left).and_then(|m| m.modified()).ok();
                let rm = std::fs::metadata(right).and_then(|m| m.modified()).ok();
                return match (lm, rm) {
                    (Some(l), Some(r)) => l < r,
                    (None, Some(_)) => true,
                    _ => false,
                };
            }
            "-ef" => {
                let left = args[*pos];
                let right = args[*pos + 2];
                *pos += 3;
                use std::os::unix::fs::MetadataExt;
                let li = std::fs::metadata(left).map(|m| (m.dev(), m.ino())).ok();
                let ri = std::fs::metadata(right).map(|m| (m.dev(), m.ino())).ok();
                return li.is_some() && li == ri;
            }
            _ => {}
        }
    }

    // Unary operators
    if *pos + 1 < args.len() {
        let op = args[*pos];
        let operand = args[*pos + 1];
        match op {
            "-z" => { *pos += 2; return operand.is_empty(); }
            "-n" => { *pos += 2; return !operand.is_empty(); }
            "-e" | "-a" => { *pos += 2; return std::path::Path::new(operand).exists(); }
            "-f" => { *pos += 2; return std::path::Path::new(operand).is_file(); }
            "-d" => { *pos += 2; return std::path::Path::new(operand).is_dir(); }
            "-r" => { *pos += 2; return test_access(operand, libc::R_OK); }
            "-w" => { *pos += 2; return test_access(operand, libc::W_OK); }
            "-x" => { *pos += 2; return test_access(operand, libc::X_OK); }
            "-s" => {
                *pos += 2;
                return std::fs::metadata(operand).map(|m| m.len() > 0).unwrap_or(false);
            }
            "-L" | "-h" => {
                *pos += 2;
                return std::fs::symlink_metadata(operand)
                    .map(|m| m.file_type().is_symlink()).unwrap_or(false);
            }
            "-p" => {
                *pos += 2;
                use std::os::unix::fs::FileTypeExt;
                return std::fs::metadata(operand).map(|m| m.file_type().is_fifo()).unwrap_or(false);
            }
            "-S" => {
                *pos += 2;
                use std::os::unix::fs::FileTypeExt;
                return std::fs::metadata(operand).map(|m| m.file_type().is_socket()).unwrap_or(false);
            }
            "-b" => {
                *pos += 2;
                use std::os::unix::fs::FileTypeExt;
                return std::fs::metadata(operand).map(|m| m.file_type().is_block_device()).unwrap_or(false);
            }
            "-c" => {
                *pos += 2;
                use std::os::unix::fs::FileTypeExt;
                return std::fs::metadata(operand).map(|m| m.file_type().is_char_device()).unwrap_or(false);
            }
            "-g" => {
                *pos += 2;
                use std::os::unix::fs::PermissionsExt;
                return std::fs::metadata(operand).map(|m| m.permissions().mode() & 0o2000 != 0).unwrap_or(false);
            }
            "-u" => {
                *pos += 2;
                use std::os::unix::fs::PermissionsExt;
                return std::fs::metadata(operand).map(|m| m.permissions().mode() & 0o4000 != 0).unwrap_or(false);
            }
            "-k" => {
                *pos += 2;
                use std::os::unix::fs::PermissionsExt;
                return std::fs::metadata(operand).map(|m| m.permissions().mode() & 0o1000 != 0).unwrap_or(false);
            }
            "-O" => {
                *pos += 2;
                use std::os::unix::fs::MetadataExt;
                return std::fs::metadata(operand)
                    .map(|m| m.uid() == unsafe { libc::getuid() }).unwrap_or(false);
            }
            "-G" => {
                *pos += 2;
                use std::os::unix::fs::MetadataExt;
                return std::fs::metadata(operand)
                    .map(|m| m.gid() == unsafe { libc::getgid() }).unwrap_or(false);
            }
            "-N" => {
                *pos += 2;
                use std::os::unix::fs::MetadataExt;
                return std::fs::metadata(operand)
                    .map(|m| m.mtime() > m.atime() || (m.mtime() == m.atime() && m.mtime_nsec() > m.atime_nsec()))
                    .unwrap_or(false);
            }
            "-t" => {
                *pos += 2;
                match operand.parse::<RawFd>() {
                    Ok(fd) => return unsafe { libc::isatty(fd) } == 1,
                    Err(_) => {
                        // Bash: "<script>: line <N>: [[: X: integer expected"
                        // Returns exit status 2.
                        eprintln!("{}: [[: {}: integer expected",
                            cond_err_prefix(), operand);
                        COND_ERR_STATUS.with(|s| s.set(Some(2)));
                        return false;
                    }
                }
            }
            "-v" => {
                *pos += 2;
                let vars_ptr = COND_VARS_PTR.with(|p| p.get());
                if vars_ptr.is_null() {
                    return false;
                }
                // SAFETY: pointer lifetime is bounded by builtin_double_bracket.
                let vars = unsafe { &mut *vars_ptr };
                if let Some(bracket) = operand.find('[') {
                    if operand.ends_with(']') && is_valid_identifier(&operand[..bracket]) {
                        let base = &operand[..bracket];
                        let sub = &operand[bracket + 1..operand.len() - 1];
                        if vars.is_assoc(base) {
                            let key = assoc_expanded_operand_key(sub);
                            return vars.get_assoc(base, &key).is_some();
                        }
                        if sub.is_empty() {
                            eprintln!("{}: [[: {}[]: bad array subscript", cond_err_prefix(), base);
                            COND_ERR_STATUS.with(|s| s.set(Some(2)));
                            return false;
                        }
                        if sub == "*" || sub == "@" {
                            return vars.array_length(base) > 0;
                        }
                        let expanded = if sub.contains("$(")
                            || sub.contains('"') || sub.contains('\'')
                            || sub.contains(' ') || sub.contains('\t')
                        {
                            sub.to_string()
                        } else {
                            crate::expand::expand_arith_vars(sub, vars)
                        };
                        let idx = match crate::arithmetic::eval_expr(&expanded, vars) {
                            Ok(v) => v,
                            Err(err) => {
                                eprintln!("{}: [[: {}: {}", cond_err_prefix(), expanded.trim_start(), err);
                                COND_ERR_STATUS.with(|s| s.set(Some(1)));
                                return false;
                            }
                        };
                        let resolved = if idx < 0 {
                            match vars.array_max_index(base) {
                                Some(max_idx) => {
                                    let real = (max_idx as i64 + 1) + idx;
                                    if real < 0 {
                                        eprintln!("{}: [[: {}[{}]: bad array subscript", cond_err_prefix(), base, sub);
                                        COND_ERR_STATUS.with(|s| s.set(Some(2)));
                                        return false;
                                    }
                                    real as usize
                                }
                                None => {
                                    eprintln!("{}: [[: {}[{}]: bad array subscript", cond_err_prefix(), base, sub);
                                    COND_ERR_STATUS.with(|s| s.set(Some(2)));
                                    return false;
                                }
                            }
                        } else {
                            idx as usize
                        };
                        if vars.is_array(base) {
                            return vars.array_element_is_set(base, resolved);
                        }
                        return resolved == 0 && vars.is_set(base);
                    }
                }
                if vars.is_assoc(operand) {
                    return vars.get_assoc(operand, "0").is_some();
                }
                if vars.is_array(operand) {
                    return vars.array_element_is_set(operand, 0);
                }
                return vars.is_set(operand);
            }
            "-R" => {
                *pos += 2;
                return false;
            }
            _ => {}
        }
    }

    // Single string — true if non-empty
    let s = args[*pos];
    *pos += 1;
    !s.is_empty()
}

fn cond_pattern_match(string: &str, pattern: &str) -> bool {
    // [[ uses glob/fnmatch-style pattern matching for == and !=
    glob_match(pattern, string)
}

pub fn glob_match_pub(pattern: &str, string: &str) -> bool {
    glob_match(pattern, string)
}

fn glob_match(pattern: &str, string: &str) -> bool {
    // Glob matching with extglob support: *, ?, [...], @(), ?(), *(), +(), !()
    let pat: Vec<char> = pattern.chars().collect();
    let s: Vec<char> = string.chars().collect();
    glob_match_rec(&pat, 0, &s, 0)
}

/// Recursive glob matcher supporting extglob operators.
fn glob_match_rec(pat: &[char], pi: usize, s: &[char], si: usize) -> bool {
    let pn = pat.len();
    let sn = s.len();

    // Walk pattern and string in lock-step
    let mut pi = pi;
    let mut si = si;

    loop {
        if pi == pn {
            return si == sn;
        }

        // Check for extglob prefix: one of ?*+@! followed by '('
        if pi + 1 < pn && pat[pi + 1] == '(' && is_extglob_char(pat[pi]) {
            let prefix = pat[pi];
            // Find the matching ')' respecting nesting
            if let Some(close) = find_extglob_close(pat, pi + 2) {
                let alts = split_extglob_alts(pat, pi + 2, close);
                let rest_pi = close + 1;
                return match_extglob(prefix, &alts, pat, rest_pi, s, si);
            }
            // If no matching paren found, treat prefix as literal
        }

        match pat[pi] {
            '*' => {
                // Skip consecutive stars — but stop if a following `*`
                // is actually the start of an extglob prefix (e.g. the
                // second `*` in `ab**(e|f)` introduces `*(e|f)`).
                let mut npi = pi + 1;
                while npi < pn && pat[npi] == '*' {
                    if npi + 1 < pn && pat[npi + 1] == '(' {
                        break;
                    }
                    npi += 1;
                }
                // Try matching * against 0..remaining chars
                for nsi in si..=sn {
                    if glob_match_rec(pat, npi, s, nsi) {
                        return true;
                    }
                }
                return false;
            }
            '?' => {
                if si >= sn {
                    return false;
                }
                pi += 1;
                si += 1;
            }
            '[' => {
                if si >= sn {
                    return false;
                }
                if let Some((matched, end)) = glob_match_bracket_chars(pat, pi, s[si]) {
                    if !matched {
                        return false;
                    }
                    pi = end;
                    si += 1;
                } else {
                    // Malformed bracket, treat '[' as literal
                    if s[si] != '[' {
                        return false;
                    }
                    pi += 1;
                    si += 1;
                }
            }
            '\\' => {
                // Escaped literal.  A trailing backslash matches a
                // literal backslash at the end of the string.
                pi += 1;
                if pi >= pn {
                    if si >= sn || s[si] != '\\' {
                        return false;
                    }
                    si += 1;
                    continue;
                }
                if si >= sn || pat[pi] != s[si] {
                    return false;
                }
                pi += 1;
                si += 1;
            }
            c => {
                if si >= sn || s[si] != c {
                    return false;
                }
                pi += 1;
                si += 1;
            }
        }
    }
}

fn is_extglob_char(c: char) -> bool {
    matches!(c, '?' | '*' | '+' | '@' | '!')
}

/// Find the closing ')' for an extglob pattern starting at `start` (just after the '(').
/// Returns the index of ')' or None.
fn find_extglob_close(pat: &[char], start: usize) -> Option<usize> {
    let mut depth = 1usize;
    let mut i = start;
    while i < pat.len() {
        match pat[i] {
            '(' => {
                // Check if this is a nested extglob: preceded by extglob char
                depth += 1;
            }
            ')' => {
                depth -= 1;
                if depth == 0 {
                    return Some(i);
                }
            }
            '[' => {
                // Skip over bracket expression
                i += 1;
                if i < pat.len() && (pat[i] == '!' || pat[i] == '^') {
                    i += 1;
                }
                let first = true;
                while i < pat.len() && (first || pat[i] != ']') {
                    let _ = first;
                    i += 1;
                    break; // skip at least one char then look for ]
                }
                while i < pat.len() && pat[i] != ']' {
                    i += 1;
                }
                // i now points at ']', will be incremented below
            }
            '\\' => {
                i += 1; // skip escaped char
            }
            _ => {}
        }
        i += 1;
    }
    None
}

/// Split the alternatives inside an extglob between positions `start` and `close`
/// (exclusive), splitting on unparenthesized '|'.
fn split_extglob_alts(pat: &[char], start: usize, close: usize) -> Vec<(usize, usize)> {
    let mut alts = Vec::new();
    let mut depth = 0usize;
    let mut seg_start = start;
    let mut i = start;
    while i < close {
        match pat[i] {
            '(' => depth += 1,
            ')' => {
                if depth > 0 {
                    depth -= 1;
                }
            }
            '|' if depth == 0 => {
                alts.push((seg_start, i));
                seg_start = i + 1;
            }
            '[' => {
                // Skip bracket expression
                i += 1;
                if i < close && (pat[i] == '!' || pat[i] == '^') {
                    i += 1;
                }
                // skip at least one char (handles ] as first char)
                if i < close {
                    i += 1;
                }
                while i < close && pat[i] != ']' {
                    i += 1;
                }
            }
            '\\' => {
                i += 1; // skip escaped char
            }
            _ => {}
        }
        i += 1;
    }
    alts.push((seg_start, close));
    alts
}

/// Match an extglob pattern.
///   prefix: one of ? * + @ !
///   alts: list of (start, end) index pairs within `pat` for each alternative
///   pat: the full pattern (alts index into this)
///   rest_pi: where the pattern continues after the closing ')'
///   s, si: the string being matched
fn match_extglob(
    prefix: char,
    alts: &[(usize, usize)],
    pat: &[char],
    rest_pi: usize,
    s: &[char],
    si: usize,
) -> bool {
    match prefix {
        '@' => {
            // Exactly one of the alternatives must match a prefix, then rest must match
            for &(astart, aend) in alts {
                // Build a temporary pattern: alt + rest
                let mut combined: Vec<char> = pat[astart..aend].to_vec();
                combined.extend_from_slice(&pat[rest_pi..]);
                if glob_match_rec(&combined, 0, s, si) {
                    return true;
                }
            }
            false
        }
        '?' => {
            // Zero or one occurrence of the alternatives
            // Try zero: match rest directly
            if glob_match_rec(pat, rest_pi, s, si) {
                return true;
            }
            // Try one: one of the alternatives matches a prefix, then rest matches
            for &(astart, aend) in alts {
                let mut combined: Vec<char> = pat[astart..aend].to_vec();
                combined.extend_from_slice(&pat[rest_pi..]);
                if glob_match_rec(&combined, 0, s, si) {
                    return true;
                }
            }
            false
        }
        '*' => {
            // Zero or more occurrences of any of the alternatives
            // Try zero
            if glob_match_rec(pat, rest_pi, s, si) {
                return true;
            }
            // Try one or more: for each alternative matching a prefix,
            // recurse to try more or finish with rest
            match_extglob_plus(alts, pat, rest_pi, s, si)
        }
        '+' => {
            // One or more occurrences
            match_extglob_plus(alts, pat, rest_pi, s, si)
        }
        '!' => {
            // Match anything that is NOT matched by the alternatives.
            // For each possible split of s[si..], if no alternative matches the prefix,
            // and rest matches the suffix, then it matches.
            // Also: if rest matches at si (zero-length negation), and none of the
            // alternatives match the entire remainder.
            let sn = s.len();
            for split in si..=sn {
                // Check that the rest pattern matches s[split..]
                if !glob_match_rec(pat, rest_pi, s, split) {
                    continue;
                }
                // Check that none of the alternatives match s[si..split]
                let prefix_s = &s[si..split];
                let any_match = alts.iter().any(|&(astart, aend)| {
                    let alt_pat: Vec<char> = pat[astart..aend].to_vec();
                    glob_match_rec(&alt_pat, 0, prefix_s, 0)
                });
                if !any_match {
                    return true;
                }
            }
            false
        }
        _ => false,
    }
}

/// Helper for +(alts) and *(alts): match one or more occurrences of any alternative
/// followed by rest.
fn match_extglob_plus(
    alts: &[(usize, usize)],
    pat: &[char],
    rest_pi: usize,
    s: &[char],
    si: usize,
) -> bool {
    let sn = s.len();
    // Try each alternative at position si
    for &(astart, aend) in alts {
        let alt_pat: &[char] = &pat[astart..aend];
        // Try each possible prefix length that the alternative could match
        for end in (si + 1)..=sn {
            let prefix_s = &s[si..end];
            if glob_match_rec(alt_pat, 0, prefix_s, 0) {
                // This alternative matched s[si..end].
                // Now try: rest matches s[end..] (one occurrence total)
                if glob_match_rec(pat, rest_pi, s, end) {
                    return true;
                }
                // Or: more occurrences of any alternative, then rest
                if match_extglob_plus(alts, pat, rest_pi, s, end) {
                    return true;
                }
            }
        }
    }
    false
}

/// Match a bracket expression `[...]` starting at pat[pi] which must be '['.
/// Returns Some((matched, end_index)) where end_index is past the ']',
/// or None for malformed bracket.
fn glob_match_bracket_chars(pat: &[char], pi: usize, ch: char) -> Option<(bool, usize)> {
    if pi >= pat.len() || pat[pi] != '[' {
        return None;
    }
    let mut i = pi + 1;
    let negate = if i < pat.len() && (pat[i] == '!' || pat[i] == '^') {
        i += 1;
        true
    } else {
        false
    };

    let mut matched = false;
    let start = i;
    while i < pat.len() {
        if pat[i] == ']' && i > start {
            return Some((matched ^ negate, i + 1));
        }
        // POSIX character class [:alpha:] etc.
        if pat[i] == '[' && i + 1 < pat.len() && pat[i + 1] == ':' {
            let cls_start = i + 2;
            let mut cls_end = cls_start;
            while cls_end + 1 < pat.len() && !(pat[cls_end] == ':' && pat[cls_end + 1] == ']') {
                cls_end += 1;
            }
            let class_name: String = pat[cls_start..cls_end].iter().collect();
            let m = match class_name.as_str() {
                "alpha"  => ch.is_alphabetic(),
                "digit"  => ch.is_ascii_digit(),
                "alnum"  => ch.is_alphanumeric(),
                "upper"  => ch.is_uppercase(),
                "lower"  => ch.is_lowercase(),
                "space"  => ch.is_whitespace(),
                "blank"  => ch == ' ' || ch == '\t',
                "punct"  => ch.is_ascii_punctuation(),
                "print"  => !ch.is_control(),
                "cntrl"  => ch.is_control(),
                "graph"  => !ch.is_whitespace() && !ch.is_control(),
                "xdigit" => ch.is_ascii_hexdigit(),
                _        => false,
            };
            if m { matched = true; }
            i = cls_end + 2; // skip past ':]'
            continue;
        }
        if i + 2 < pat.len() && pat[i + 1] == '-' && pat[i + 2] != ']' {
            if ch >= pat[i] && ch <= pat[i + 2] {
                matched = true;
            }
            i += 3;
        } else {
            if pat[i] == ch {
                matched = true;
            }
            i += 1;
        }
    }
    None // unclosed bracket
}

fn cond_regex_match(string: &str, pattern: &str) -> bool {
    // Use a simple regex implementation — try to match against the string
    // For now, use basic regex via std approach or a simple substring match
    // Bash uses ERE (extended regular expressions)
    // We'll try to compile as a regex; fall back to substring match
    match regex_match_ere(pattern, string) {
        Some((matched, captures)) => {
            // Update BASH_REMATCH on EVERY regex eval, matching bash's
            // behavior: a failed match clears it to an empty array.
            let vars_ptr = COND_VARS_PTR.with(|p| p.get());
            if !vars_ptr.is_null() {
                unsafe {
                    let vars = &mut *vars_ptr;
                    vars.declare_array("BASH_REMATCH");
                    vars.set_array("BASH_REMATCH",
                        if matched { captures } else { Vec::new() });
                }
            }
            matched
        }
        None => {
            eprintln!("{}: [[: {}: invalid regex", crate::exec::shell_name(), pattern);
            false
        }
    }
}

fn regex_match_ere(pattern: &str, string: &str) -> Option<(bool, Vec<String>)> {
    // Use libc regcomp/regexec for POSIX ERE, with capture-group
    // support.  Returns (matched, BASH_REMATCH contents).
    use std::ffi::CString;
    let c_pattern = CString::new(pattern).ok()?;
    let c_string = CString::new(string).ok()?;

    unsafe {
        let mut regex: libc::regex_t = std::mem::zeroed();
        let comp = libc::regcomp(
            &mut regex,
            c_pattern.as_ptr(),
            libc::REG_EXTENDED,
        );
        if comp != 0 {
            libc::regfree(&mut regex);
            return None;
        }
        // re_nsub is private on macOS libc.  Use a generous upper
        // bound — regexec fills unused slots with -1.
        let nmatch = 32usize;
        let mut matches: Vec<libc::regmatch_t> = vec![
            libc::regmatch_t { rm_so: -1, rm_eo: -1 };
            nmatch
        ];
        let exec = libc::regexec(
            &regex,
            c_string.as_ptr(),
            nmatch,
            matches.as_mut_ptr(),
            0,
        );
        libc::regfree(&mut regex);
        if exec != 0 {
            return Some((false, Vec::new()));
        }
        // Build BASH_REMATCH: index 0 = full match, 1..N = captures.
        // Trim trailing unused slots (all -1 from our over-allocation).
        let bytes = string.as_bytes();
        let mut captures: Vec<String> = Vec::with_capacity(nmatch);
        let mut last_used = 0;
        for (i, m) in matches.iter().enumerate() {
            let filled = m.rm_so >= 0 && m.rm_eo >= 0;
            let s = if filled {
                let so = m.rm_so as usize;
                let eo = m.rm_eo as usize;
                if so <= eo && eo <= bytes.len() {
                    String::from_utf8_lossy(&bytes[so..eo]).into_owned()
                } else {
                    String::new()
                }
            } else {
                String::new()
            };
            if filled { last_used = i; }
            captures.push(s);
        }
        captures.truncate(last_used + 1);
        Some((true, captures))
    }
}

// ---------------------------------------------------------------------------
// history builtin
// ---------------------------------------------------------------------------

fn builtin_history_dispatch(shell: &mut Shell, args: &[String]) -> i32 {
    // Gather context needed for history -p expansion
    // Use err_prefix() (script name only, no line number) since builtin_history
    // will format errors as "{script_name}: line {lineno}: history: ..."
    let script_name = shell.err_prefix();
    let lineno = shell.get_var("LINENO")
        .and_then(|s| s.parse::<usize>().ok())
        .unwrap_or(0);
    let histfile = shell
        .get_var("HISTFILE")
        .filter(|s| !s.is_empty())
        .or_else(|| shell.remembered_history_file().map(str::to_owned));
    if let Some(path) = histfile.as_deref() {
        shell.remember_history_file(path);
    }
    let histchars = shell.get_var("histchars").unwrap_or_else(|| "!^#".to_string());
    let histfile_opts = crate::history::HistoryFileOptions {
        comment_char: histchars.chars().nth(2).unwrap_or('#'),
        write_timestamps: shell.vars.has_entry("HISTTIMEFORMAT"),
        histfile_size: shell.get_var("HISTFILESIZE")
            .and_then(|s| s.parse::<usize>().ok()),
    };

    crate::history::builtin_history(
        &mut shell.history,
        args,
        histfile.as_deref(),
        histfile_opts,
        &script_name,
        lineno,
        &histchars,
    )
}

fn builtin_fc_dispatch(shell: &mut Shell, args: &[String]) -> i32 {
    let script_name = shell.err_prefix();
    let lineno = shell.get_var("LINENO")
        .and_then(|s| s.parse::<usize>().ok())
        .unwrap_or(0);

    let mut idx = 0usize;
    let mut list_mode = false;
    let mut strip_numbers = false;
    let mut reverse = false;
    let mut editor: Option<String> = None;
    let mut substitute_mode = false;

    while idx < args.len() {
        match args[idx].as_str() {
            "-l" => { list_mode = true; idx += 1; }
            "-n" => { strip_numbers = true; idx += 1; }
            "-r" => { reverse = true; idx += 1; }
            "-s" => { substitute_mode = true; idx += 1; }
            "-e" => {
                if idx + 1 >= args.len() {
                    eprintln!("{}: line {}: fc: -e: option requires an argument", script_name, lineno);
                    eprintln!("fc: usage: fc [-e ename] [-lnr] [first] [last] or fc -s [pat=rep] [command]");
                    return 2;
                }
                editor = Some(args[idx + 1].clone());
                idx += 2;
            }
            "--" => { idx += 1; break; }
            a if a.starts_with('-') && a.len() > 2 && a[1..].chars().all(|c| matches!(c, 'l' | 'n' | 'r')) => {
                for ch in a[1..].chars() {
                    match ch {
                        'l' => list_mode = true,
                        'n' => strip_numbers = true,
                        'r' => reverse = true,
                        _ => {}
                    }
                }
                idx += 1;
            }
            a if a.starts_with('-') && a.len() > 1 && !a[1..].chars().next().map(|c| c.is_ascii_digit()).unwrap_or(false) => {
                eprintln!("{}: line {}: fc: {}: invalid option", script_name, lineno, a);
                eprintln!("fc: usage: fc [-e ename] [-lnr] [first] [last] or fc -s [pat=rep] [command]");
                return 2;
            }
            _ => break,
        }
    }

    #[derive(Copy, Clone, Debug, Eq, PartialEq)]
    enum FcSpecResult {
        Index(usize),
        Invalid,
        NotFound,
    }

    fn resolve_fc_spec(
        hist: &crate::history::HistoryList,
        spec: Option<&str>,
        listing: bool,
        is_first: bool,
        current_added: bool,
    ) -> FcSpecResult {
        if hist.entries.is_empty() {
            return FcSpecResult::Invalid;
        }

        let real_last = hist.entries.len() - 1;
        let last_hist = hist.entries.len().saturating_sub(if current_added { 2 } else { 1 });

        let command = match spec {
            Some(command) => command.trim(),
            None => return FcSpecResult::Index(last_hist),
        };

        let mut sign = 1i64;
        let mut digits = command;
        if let Some(rest) = command.strip_prefix('-') {
            sign = -1;
            digits = rest;
        }

        if !digits.is_empty() && digits.chars().all(|c| c.is_ascii_digit()) {
            let parsed = digits.parse::<i64>().unwrap_or(0);
            let n = parsed * sign;

            if n < 0 {
                let resolved = n + last_hist as i64 + 1;
                return FcSpecResult::Index(resolved.max(0) as usize);
            }

            if n == 0 {
                return if sign == -1 {
                    if listing {
                        FcSpecResult::Index(real_last)
                    } else {
                        FcSpecResult::Invalid
                    }
                } else {
                    FcSpecResult::Index(last_hist)
                };
            }

            let absolute_idx = parsed - hist.first_number() as i64;
            if absolute_idx < 0 || absolute_idx as usize > last_hist {
                return FcSpecResult::Index(if is_first { 0 } else { last_hist });
            }
            return FcSpecResult::Index(absolute_idx as usize);
        }

        for idx in (0..=last_hist).rev() {
            if hist.entries[idx].line.starts_with(command) {
                return FcSpecResult::Index(idx);
            }
        }

        FcSpecResult::NotFound
    }

    fn collect_range(
        hist: &crate::history::HistoryList,
        start: usize,
        end: usize,
        reverse: bool,
    ) -> Vec<(usize, String)> {
        if hist.entries.is_empty() {
            return Vec::new();
        }
        let (lo, hi) = if start <= end { (start, end) } else { (end, start) };
        let hi = hi.min(hist.entries.len() - 1);
        let mut out = Vec::new();
        for idx in lo..=hi {
            out.push((idx, hist.entries[idx].line.clone()));
        }
        if reverse {
            out.reverse();
        }
        out
    }

    let hist = &shell.history;
    let current_added = shell.current_history_line.as_deref() == shell.history.last();
    let real_last = hist.entries.len().checked_sub(1);
    let last_hist = hist.entries.len().checked_sub(if current_added { 2 } else { 1 });

    fn drop_current_fc_entry(shell: &mut Shell) {
        let should_drop = shell.current_history_line.as_deref() == shell.history.last();
        if should_drop {
            if let Some(idx) = shell.history.entries.len().checked_sub(1) {
                shell.history.remove_at(idx);
            }
            shell.current_history_line = None;
        }
    }

    let mut remaining = args[idx..].to_vec();
    let execute_mode = substitute_mode || editor.as_deref() == Some("-");
    if execute_mode {
        let mut target_spec: Option<String> = None;
        let mut substitutions: Vec<(String, String)> = Vec::new();

        while let Some(first) = remaining.get(0).cloned() {
            if first.contains('=') {
                let mut parts = first.splitn(2, '=');
                substitutions.push((
                    parts.next().unwrap_or("").to_string(),
                    parts.next().unwrap_or("").to_string(),
                ));
                remaining.remove(0);
            } else {
                target_spec = Some(first);
                remaining.remove(0);
                break;
            }
        }

        let target_line = match target_spec {
            Some(spec) => match resolve_fc_spec(hist, Some(&spec), false, false, current_added) {
                FcSpecResult::Index(idx) => hist.entries[idx].line.clone(),
                FcSpecResult::Invalid | FcSpecResult::NotFound => {
                    eprintln!("{}: line {}: fc: no command found", script_name, lineno);
                    return 1;
                }
            },
            None => match resolve_fc_spec(hist, None, false, false, current_added) {
                FcSpecResult::Index(idx) => hist.entries[idx].line.clone(),
                FcSpecResult::Invalid | FcSpecResult::NotFound => {
                    eprintln!("{}: line {}: fc: no command found", script_name, lineno);
                    return 1;
                }
            }
        };

        let had_substitutions = !substitutions.is_empty();
        let mut edited = target_line.clone();
        let mut changed = false;
        for (old, new_) in &substitutions {
            if !old.is_empty() && edited.contains(old) {
                let replaced = crate::history::subst_all(&edited, old, new_);
                if replaced != edited {
                    changed = true;
                }
                edited = replaced;
            }
        }

        if !had_substitutions {
            println!("{}", target_line);
            drop_current_fc_entry(shell);
            return shell.run_string(&target_line);
        }

        if !changed {
            eprintln!("{}: line {}: fc: no command found", script_name, lineno);
            return 1;
        }
        println!("{}", edited);
        drop_current_fc_entry(shell);
        return shell.run_string(&edited);
    }

    let mut start_spec: Option<String> = None;
    let mut end_spec: Option<String> = None;
    if !remaining.is_empty() {
        start_spec = Some(remaining.remove(0));
    }
    if !remaining.is_empty() {
        end_spec = Some(remaining.remove(0));
    }

    let should_list = list_mode;
    if hist.entries.is_empty() {
        return 0;
    }

    let (start, end) = if let Some(spec) = &start_spec {
        let start = match resolve_fc_spec(hist, Some(spec), should_list, true, current_added) {
            FcSpecResult::Index(idx) => idx,
            FcSpecResult::Invalid => {
                eprintln!("{}: line {}: fc: history specification out of range", script_name, lineno);
                return 1;
            }
            FcSpecResult::NotFound => {
                eprintln!("{}: line {}: fc: no command found", script_name, lineno);
                return 1;
            }
        };

        let end = if let Some(spec2) = &end_spec {
            match resolve_fc_spec(hist, Some(spec2), should_list, false, current_added) {
                FcSpecResult::Index(idx) => idx,
                FcSpecResult::Invalid => {
                    eprintln!("{}: line {}: fc: history specification out of range", script_name, lineno);
                    return 1;
                }
                FcSpecResult::NotFound => {
                    eprintln!("{}: line {}: fc: no command found", script_name, lineno);
                    return 1;
                }
            }
        } else if real_last == Some(start) {
            start
        } else if should_list {
            last_hist.unwrap_or(start)
        } else {
            start
        };
        (start, end)
    } else {
        if should_list {
            let end = last_hist.unwrap_or(0);
            let start = end.saturating_sub(15);
            (start, end)
        } else {
            let idx = last_hist.unwrap_or(0);
            (idx, idx)
        }
    };

    let entries = collect_range(hist, start, end, reverse);
    if should_list {
        let first_num = hist.first_number();
        for (idx, line) in entries {
            if strip_numbers {
                println!("\t {}", line);
            } else {
                println!("{}\t {}", first_num + idx, line);
            }
        }
        return 0;
    }

    let mut script = String::new();
    for (_, line) in entries {
        script.push_str(&line);
        script.push('\n');
    }
    if let Some(editor_cmd) = editor {
        use std::fs;
        use std::process::Command as ProcCommand;
        use std::time::{SystemTime, UNIX_EPOCH};

        let unique = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap_or_default()
            .as_nanos();
        let path = std::env::temp_dir().join(format!("brash-fc-{}-{}.sh", std::process::id(), unique));

        if let Err(e) = fs::write(&path, &script) {
            eprintln!("{}: line {}: fc: {}", script_name, lineno, e);
            return 1;
        }

        let status = ProcCommand::new("/bin/sh")
            .arg("-c")
            .arg(format!("{} \"$1\"", editor_cmd))
            .arg("brash-fc")
            .arg(&path)
            .status();

        match status {
            Ok(status) if status.success() => {}
            Ok(status) => {
                let _ = fs::remove_file(&path);
                return status.code().unwrap_or(1);
            }
            Err(e) => {
                let _ = fs::remove_file(&path);
                eprintln!("{}: line {}: fc: {}", script_name, lineno, e);
                return 1;
            }
        }

        let edited = match fs::read_to_string(&path) {
            Ok(contents) => contents,
            Err(e) => {
                let _ = fs::remove_file(&path);
                eprintln!("{}: line {}: fc: {}", script_name, lineno, e);
                return 1;
            }
        };
        let _ = fs::remove_file(&path);
        print!("{}", edited);
        drop_current_fc_entry(shell);
        return shell.run_string(&edited);
    }

    shell.run_string(&script)
}
