/// Shell lexer/tokenizer for brash (Bash-compatible shell).
///
/// Converts raw shell input into a flat `Vec<Token>`.  Here-document bodies
/// are read eagerly after the newline that terminates the line containing the
/// `<<` operator.
///
/// Design notes
/// ============
/// * The lexer works on a `Vec<char>` cursor.
/// * Continuation lines (`\\\n`) inside non-here-doc input are transparently
///   skipped during whitespace handling and inside word reading.
/// * `$(…)` / `$((…))` / process-substitutions are emitted as dedicated token
///   variants so the parser can distinguish them.
/// * Reserved words are emitted as their own token variants.
/// * `;;`, `;&`, `;;&` are emitted as `CaseSemi`, `CaseSemiAmp`,
///   `CaseSemiSemiAmp` respectively.

// std::collections::{HashMap, HashSet} are not used at the top level any more —
// the lexer's hot maps live in ahash.  Anywhere that still wants the std types
// uses fully-qualified paths so the unused-import warning stays clean.

// ---------------------------------------------------------------------------
// Public types
// ---------------------------------------------------------------------------

#[derive(Debug, Clone, PartialEq)]
pub enum Token {
    // ----- word-like tokens -----
    /// An unquoted (or mixed-quoting) word, including bare variable
    /// references like `$foo`, tilde prefixes, glob patterns, etc.
    Word(String),
    /// A single-quoted string – the inner text (no surrounding quotes).
    SingleQuoted(String),
    /// A double-quoted string – the inner text (quotes stripped, escapes kept
    /// verbatim so the expander can re-process them).
    DoubleQuoted(String),
    /// `$'...'` ANSI-C quoted string – inner text with backslash sequences.
    DollarSingleQuoted(String),
    /// `${...}` parameter expansion – the full text including `${` and `}`.
    BraceGroup(String),
    /// `>(cmd)` or `<(cmd)` process substitution – full text.
    ProcessSub(String),
    /// `$(cmd)` command substitution – inner command text.
    CommandSub(String),
    /// `$((expr))` arithmetic substitution – inner expression text.
    ArithSub(String),
    /// `@(…)`, `*(…)`, etc. extended glob – full text.
    ExtGlob(String),
    /// Tilde prefix like `~`, `~user` – the full prefix.
    Tilde(String),
    /// An `NAME=value` or `NAME+=value` assignment word.
    AssignWord(String, String, String), // name, op ("=" or "+="), value
    /// A concatenation of multiple word-piece tokens – used when quoting
    /// boundaries split a logical word into parts.
    Concat(Vec<String>),

    // ----- reserved words -----
    If,
    Then,
    Elif,
    Else,
    Fi,
    While,
    Until,
    For,
    Do,
    Done,
    Case,
    Esac,
    In,
    Select,
    Function,
    Coproc,
    Time,
    Bang, // !

    // ----- operators -----
    Pipe,          // |
    PipeAmp,       // |&   (pipe-and: also redirects stderr through the pipe)
    AndAnd,        // &&
    OrOr,          // ||
    Semi,          // ;
    CaseSemi,      // ;;
    CaseSemiAmp,   // ;&
    CaseSemiSemiAmp, // ;;&
    Amp,           // &
    Newline,       // \n
    /// A backslash-newline line continuation. Advances parser line numbers
    /// but does not act as a command separator.
    LineCont,
    /// A newline that came from inside an alias expansion body.
    /// Acts as a command separator but does NOT advance the parser's LINENO.
    AliasNewline,
    LParen,        // (
    RParen,        // )
    LBrace,        // {
    RBrace,        // }

    // ----- bracket / arithmetic commands -----
    DoubleLBracket,  // [[
    DoubleRBracket,  // ]]
    /// `(( expr ))` as a standalone command – inner expression text.
    ArithCmd(String),

    // ----- redirections -----
    Redirect(RedirectInfo),
    HereDoc(HereDocInfo),

    Eof,
}

#[derive(Debug, Clone, PartialEq)]
pub struct RedirectInfo {
    pub fd: Option<i32>,
    pub op: RedirectOp,
    pub target: String,
    /// Bash-4 `{varname}< file` form: the kernel picks a free FD >= 10
    /// and its number is stored in the shell variable `varname`.  When
    /// set, `fd` is ignored.
    pub varfd: Option<String>,
}

#[derive(Debug, Clone, PartialEq)]
pub enum RedirectOp {
    Input,       // <
    Output,      // >
    Append,      // >>
    InputDup,    // <&
    OutputDup,   // >&
    InputOutput, // <>
    Clobber,     // >|
    AndOutput,   // &>
    AndAppend,   // &>>
    Heredoc,     // <<
    HeredocStrip,// <<-
    HereString,  // <<<
}

#[derive(Debug, Clone, PartialEq)]
pub struct HereDocInfo {
    pub fd: Option<i32>,
    pub op: RedirectOp, // always RedirectOp::Input; present for parser symmetry
    pub delimiter: String,
    pub strip_tabs: bool,
    pub quoted: bool,   // true if delimiter was quoted → no expansion in body
    pub content: String,
    /// Bash `{name}<<DELIM` named-FD form.  When Some(name), the
    /// heredoc is attached to a fresh FD stored in the named variable.
    pub varfd: Option<String>,
}

/// Warning about a here-document delimited by end-of-file.
#[derive(Debug, Clone)]
pub enum HeredocWarningKind {
    DelimitedByEof,
    CmdSubUnterminated { count: usize },
}

#[derive(Debug, Clone)]
pub struct HeredocWarning {
    /// Line where the `<<` appeared (1-based).
    pub heredoc_start_line: usize,
    /// Line where end-of-file terminated the heredoc (1-based).
    pub eof_line: usize,
    /// The expected delimiter word.
    pub wanted: String,
    /// If true, this is a "command substitution:" prefixed warning.
    pub comsub: bool,
    /// Line to use for deciding when to emit this warning during execution.
    /// For warnings inside `$(…)`, this is the line of the `$(`; for
    /// top-level heredocs, this equals `heredoc_start_line`.
    pub trigger_line: usize,
    pub kind: HeredocWarningKind,
}

/// An error about unmatched `$(` at end-of-file.
#[derive(Debug, Clone)]
pub struct ComsubEofError {
    /// Line where the end-of-file was reached (1-based).
    pub eof_line: usize,
}

/// Result of tokenisation: tokens plus any warnings.
pub struct TokenizeResult {
    pub tokens: Vec<Token>,
    pub heredoc_warnings: Vec<HeredocWarning>,
    pub comsub_eof_errors: Vec<ComsubEofError>,
    /// Set when more than 16 here-documents appear in a single command.
    /// Value is the (1-based) line number where the limit was exceeded.
    pub heredoc_max_exceeded_line: Option<usize>,
    /// Set when `${ ` (dollar-brace-space) is encountered, which bash 5.3+ treats as
    /// a group command. Value is the (1-based) line number where it was seen.
    pub dollar_brace_space_line: Option<usize>,
    /// Set when a `${…}` brace expansion reaches EOF without finding the closing `}`.
    /// Value is the (1-based) line number where the unclosed `${` was opened.
    pub unclosed_brace_line: Option<usize>,
    /// Set when an unexpected control operator (e.g. `&`, `|`, `;`) was
    /// found inside an array literal `(…)`.  The parser turns this into
    /// a bash-style "syntax error near unexpected token" diagnostic.
    pub array_literal_bad_token: Option<(String, usize)>,
}

// ---------------------------------------------------------------------------
// Entry point
// ---------------------------------------------------------------------------

/// Tokenise `input` into a `Vec<Token>`.
pub fn tokenize(input: &str) -> Vec<Token> {
    let mut lexer = Lexer::new(input);
    lexer.run();
    lexer.tokens
}

/// Tokenise `input` into tokens plus heredoc warnings.
#[cfg_attr(not(test), allow(dead_code))]
pub fn tokenize_with_warnings(input: &str) -> TokenizeResult {
    tokenize_with_warnings_at(input, 0)
}

/// Tokenise `input` into tokens plus heredoc warnings, with line numbers
/// offset by `start_line` (0 = no offset).
pub fn tokenize_with_warnings_at(input: &str, start_line: usize) -> TokenizeResult {
    let mut lexer = Lexer::new(input);
    lexer.start_line = start_line;
    lexer.run();
    TokenizeResult {
        tokens: lexer.tokens,
        heredoc_warnings: lexer.heredoc_warnings,
        comsub_eof_errors: lexer.comsub_eof_errors,
        heredoc_max_exceeded_line: lexer.heredoc_max_exceeded_line,
        dollar_brace_space_line: lexer.dollar_brace_space_line,
        unclosed_brace_line: lexer.unclosed_brace_line,
        array_literal_bad_token: lexer.array_literal_bad_token.clone(),
    }
}

/// Tokenise `input` with alias expansion enabled.
#[cfg_attr(not(test), allow(dead_code))]
pub fn tokenize_with_aliases(input: &str, aliases: &ahash::AHashMap<String, String>) -> TokenizeResult {
    tokenize_with_aliases_at(input, aliases, 0)
}

/// Tokenise `input` with alias expansion enabled, reporting line numbers
/// starting from `start_line` (0 = no offset, matching legacy behaviour).
pub fn tokenize_with_aliases_at(input: &str, aliases: &ahash::AHashMap<String, String>, start_line: usize) -> TokenizeResult {
    let mut lexer = Lexer::new(input);
    lexer.aliases = Some(aliases.clone());
    lexer.start_line = start_line;
    lexer.run();
    TokenizeResult {
        tokens: lexer.tokens,
        heredoc_warnings: lexer.heredoc_warnings,
        comsub_eof_errors: lexer.comsub_eof_errors,
        heredoc_max_exceeded_line: lexer.heredoc_max_exceeded_line,
        dollar_brace_space_line: lexer.dollar_brace_space_line,
        unclosed_brace_line: lexer.unclosed_brace_line,
        array_literal_bad_token: lexer.array_literal_bad_token.clone(),
    }
}

// ---------------------------------------------------------------------------
// Reserved-word lookup table
// ---------------------------------------------------------------------------

fn reserved_word(s: &str) -> Option<Token> {
    match s {
        "if"       => Some(Token::If),
        "then"     => Some(Token::Then),
        "elif"     => Some(Token::Elif),
        "else"     => Some(Token::Else),
        "fi"       => Some(Token::Fi),
        "while"    => Some(Token::While),
        "until"    => Some(Token::Until),
        "for"      => Some(Token::For),
        "do"       => Some(Token::Do),
        "done"     => Some(Token::Done),
        "case"     => Some(Token::Case),
        "esac"     => Some(Token::Esac),
        "in"       => Some(Token::In),
        "select"   => Some(Token::Select),
        "function" => Some(Token::Function),
        "coproc"   => Some(Token::Coproc),
        "time"     => Some(Token::Time),
        "!"        => Some(Token::Bang),
        "{"        => Some(Token::LBrace),
        "}"        => Some(Token::RBrace),
        _          => None,
    }
}

// ---------------------------------------------------------------------------
// Lexer state
// ---------------------------------------------------------------------------

struct Lexer<'a> {
    #[allow(dead_code)]
    src: &'a str,
    chars: Vec<char>,
    pos: usize,
    tokens: Vec<Token>,
    pending_heredocs: Vec<HereDocInfo>,
    /// True when inside a `[[ ... ]]` conditional command.
    in_double_bracket: bool,
    /// Line offset: added to all 1-based line numbers computed by `line_number_at`.
    /// Used by segmented execution to avoid prepending newlines to the input;
    /// the tokenizer just adds this offset to make error messages report correct
    /// source lines.
    start_line: usize,
    /// Warnings about here-documents terminated by end-of-file.
    heredoc_warnings: Vec<HeredocWarning>,
    /// Errors about unmatched `$(` at end-of-file.
    comsub_eof_errors: Vec<ComsubEofError>,
    /// Line where the here-document count limit was exceeded (1-based), if any.
    heredoc_max_exceeded_line: Option<usize>,
    /// Line where a `${ ` (dollar-brace-space) group command was encountered (1-based), if any.
    /// Bash 5.3+ treats `${ ` as a group command requiring a matching `}`.
    dollar_brace_space_line: Option<usize>,
    /// Line where a `${…}` brace expansion was opened but never closed (EOF with depth > 0).
    unclosed_brace_line: Option<usize>,
    /// Recorded when `read_array_literal` encountered an unexpected
    /// control operator (e.g. `&`, `|`, `;`); holds (token_text, 1-
    /// based line number).  The parser/runtime reads this to emit a
    /// bash-style "syntax error near unexpected token" diagnostic.
    pub array_literal_bad_token: Option<(String, usize)>,
    /// Nesting depth of enclosing `"..."` contexts — when > 0 we are
    /// reading a double-quoted string (possibly through a nested
    /// `${…}` body).  The `read_brace_expansion_inner` uses this so
    /// that `'` inside `"${…'…}"` is treated as a literal character
    /// instead of opening a single-quoted string (bash POSIX rule).
    dquote_nest_depth: usize,
    /// Alias table for lexer-level alias expansion (if enabled).
    aliases: Option<ahash::AHashMap<String, String>>,
    /// Aliases currently being expanded (prevents circular expansion).
    expanding_aliases: ahash::AHashSet<String>,
    /// When true, the next word should be checked for alias expansion
    /// (set when the previous alias expansion ended with a space/tab).
    alias_expand_next: bool,
    /// True when inside a case pattern context (between `in`/`;;` and `)`).
    /// Alias expansion is suppressed in this context.
    in_case_pattern: bool,
    /// Nesting depth of case statements (to correctly track in_case_pattern).
    case_depth: usize,
    /// Counter of pending `in` keywords expected after CASE/FOR/SELECT.
    /// Incremented when CASE/FOR/SELECT is emitted, decremented when an
    /// IN token is emitted. Bash uses this to loosen the `in` recognition
    /// rule, allowing `case x\nin\nx) … esac`.
    expecting_in_count: usize,
    /// The reserved word (Case/For/Select) that the most recent
    /// `expecting_in_count` increment came from. Used to decide whether
    /// to enter CASEPAT (for Case) or not (for For/Select) when the
    /// matching `in` is emitted in the loose rule.
    expecting_in_command: Option<Token>,
    /// Stack of (end_pos, alias_name, trailing_space) marking where each alias
    /// expansion ends. When `self.pos` reaches or passes `end_pos`, the alias
    /// is unmarked from `expanding_aliases`. If `trailing_space` is true,
    /// `alias_expand_next` is activated for the word after the boundary.
    alias_expansion_ends: Vec<(usize, String, bool)>,
}

impl<'a> Lexer<'a> {
    fn new(src: &'a str) -> Self {
        Lexer {
            src,
            chars: src.chars().collect(),
            pos: 0,
            tokens: Vec::new(),
            pending_heredocs: Vec::new(),
            in_double_bracket: false,
            start_line: 0,
            heredoc_warnings: Vec::new(),
            comsub_eof_errors: Vec::new(),
            heredoc_max_exceeded_line: None,
            dollar_brace_space_line: None,
            unclosed_brace_line: None,
            array_literal_bad_token: None,
            dquote_nest_depth: 0,
            aliases: None,
            expanding_aliases: ahash::AHashSet::new(),
            alias_expand_next: false,
            in_case_pattern: false,
            case_depth: 0,
            expecting_in_count: 0,
            expecting_in_command: None,
            alias_expansion_ends: Vec::new(),
        }
    }

    /// Compute the 1-based line number for a character position.
    fn line_number_at(&self, pos: usize) -> usize {
        self.chars[..pos.min(self.chars.len())].iter().filter(|&&c| c == '\n').count() + 1 + self.start_line
    }

    /// Returns true when the next token would be in command position (i.e.
    /// could be the start of a simple command / compound command).  `[[` is
    /// only recognised as a reserved word in command position.
    fn is_command_position(&self) -> bool {
        match self.last_non_linecont_token() {
            // Very start of input
            None => true,
            Some(t) => matches!(
                t,
                Token::Newline
                | Token::AliasNewline
                | Token::Semi
                | Token::CaseSemi
                | Token::CaseSemiAmp
                | Token::CaseSemiSemiAmp
                | Token::Pipe
                | Token::PipeAmp
                | Token::OrOr
                | Token::AndAnd
                | Token::Amp
                | Token::LParen
                | Token::LBrace
                | Token::Bang
                | Token::If
                | Token::Then
                | Token::Elif
                | Token::Else
                | Token::While
                | Token::Until
                | Token::Do
                | Token::Time
                | Token::Coproc
                // Redirections and assignments before a command word don't
                // consume the command position – alias expansion should
                // still be attempted on the next word.
                | Token::Redirect(_)
                | Token::HereDoc(_)
                | Token::AssignWord(_, _, _)
            ),
        }
    }

    /// Returns true when the next word should be checked for alias expansion.
    /// This is like `is_command_position` but excludes positions where the
    /// next word is a case pattern or similar non-command context.
    fn is_alias_position(&self) -> bool {
        // Inside case patterns: suppress alias expansion.
        if self.in_case_pattern {
            return false;
        }
        match self.last_non_linecont_token() {
            None => true,
            Some(t) => matches!(
                t,
                Token::Newline
                | Token::AliasNewline
                | Token::Semi
                | Token::Pipe
                | Token::PipeAmp
                | Token::OrOr
                | Token::AndAnd
                | Token::Amp
                | Token::LParen
                | Token::LBrace
                | Token::Bang
                | Token::If
                | Token::Then
                | Token::Elif
                | Token::Else
                | Token::While
                | Token::Until
                | Token::Do
                | Token::Time
                | Token::Coproc
                | Token::Redirect(_)
                | Token::HereDoc(_)
                | Token::AssignWord(_, _, _)
            ),
        }
    }

    fn last_non_linecont_token(&self) -> Option<&Token> {
        self.tokens.iter().rev().find(|t| !matches!(t, Token::LineCont))
    }

    // -----------------------------------------------------------------------
    // Character helpers
    // -----------------------------------------------------------------------

    #[inline]
    fn peek(&self) -> Option<char> {
        self.chars.get(self.pos).copied()
    }

    #[inline]
    fn peek_at(&self, offset: usize) -> Option<char> {
        self.chars.get(self.pos + offset).copied()
    }

    /// Returns true iff `word` starts at the current position AND is followed
    /// by a word-terminating character (whitespace, metachar, EOF, etc.).
    /// Used to detect reserved words like `case` / `esac` / `in` during
    /// command-substitution scanning.
    fn starts_with_word(&self, word: &str) -> bool {
        let n = word.len();
        if self.pos + n > self.chars.len() {
            return false;
        }
        for (i, ch) in word.chars().enumerate() {
            if self.chars[self.pos + i] != ch {
                return false;
            }
        }
        // Check the character after the word: must be whitespace/metachar/EOF
        match self.chars.get(self.pos + n).copied() {
            None => true,
            Some(c) => matches!(c,
                ' ' | '\t' | '\n' | ';' | '&' | '|' | '(' | ')' | '<' | '>' | '`'),
        }
    }

    /// Check if the word at `self.pos` is an alias whose expansion would affect
    /// comsub boundary scanning:  either the value contains `(` / `)`, or the
    /// value begins with a case-related keyword (`case`, `esac`, `in`).
    fn alias_affects_comsub_depth_at_pos(&self) -> bool {
        let aliases = match &self.aliases {
            Some(a) => a,
            None => return false,
        };
        // Read the word at self.pos
        let start = self.pos;
        let mut end = start;
        while end < self.chars.len() {
            let c = self.chars[end];
            if c.is_alphanumeric() || c == '_' || c == '-' { end += 1; } else { break; }
        }
        if end == start { return false; }
        // Must be a whole word
        match self.chars.get(end).copied() {
            None => {}
            Some(c) if matches!(c, ' ' | '\t' | '\n' | ';' | '&' | '|' | '(' | ')' | '<' | '>' | '`') => {}
            _ => return false,
        }
        let word: String = self.chars[start..end].iter().collect();
        let expansion = match aliases.get(&word) {
            None => return false,
            Some(e) => e,
        };
        // Check if expansion contains `(` or `)` which affect paren depth,
        // contains `{` or `}` which affect brace-group depth in the child,
        // OR begins with a case-related keyword.
        if expansion.contains('(') || expansion.contains(')')
            || expansion.contains('{') || expansion.contains('}')
        {
            return true;
        }
        let exp = expansion.trim_start();
        for kw in &["case", "esac", "in"] {
            let n = kw.len();
            if exp.starts_with(kw) {
                match exp[n..].chars().next() {
                    None => return true,
                    Some(c) if matches!(c, ' ' | '\t' | '\n' | ';' | '&' | '|' | '(' | ')' | '<' | '>' | '`') => return true,
                    _ => {}
                }
            }
        }
        false
    }

    /// Read the current word at `self.pos` (without consuming it) and check
    /// whether it is an alias whose expansion begins with `target` as a word.
    /// This is used inside `read_nested_parens_content` to detect aliases for
    /// `case` / `esac` / `in` so that paren-depth tracking works correctly
    /// even when the user defines aliases like `alias switch=case`.
    #[allow(dead_code)] // kept for paren-depth alias detection — not yet wired into nested-paren reads
    fn word_is_alias_for(&self, target: &str) -> bool {
        let aliases = match &self.aliases {
            Some(a) => a,
            None => return false,
        };
        // Read the identifier at self.pos (alphanumeric/underscore/dash chars)
        let start = self.pos;
        let mut end = start;
        while end < self.chars.len() {
            let c = self.chars[end];
            if c.is_alphanumeric() || c == '_' || c == '-' {
                end += 1;
            } else {
                break;
            }
        }
        if end == start {
            return false;
        }
        // Make sure it's a whole word (followed by metachar/whitespace/EOF)
        match self.chars.get(end).copied() {
            None => {}
            Some(c) if matches!(c, ' ' | '\t' | '\n' | ';' | '&' | '|' | '(' | ')' | '<' | '>' | '`') => {}
            _ => return false,
        }
        let word: String = self.chars[start..end].iter().collect();
        match aliases.get(&word) {
            None => false,
            Some(expansion) => {
                // The alias expansion must begin with `target` as a word.
                let exp = expansion.trim_start();
                let n = target.len();
                if exp.len() < n {
                    return false;
                }
                let exp_chars: Vec<char> = exp.chars().collect();
                if exp_chars[..n].iter().zip(target.chars()).any(|(a, b)| *a != b) {
                    return false;
                }
                match exp_chars.get(n).copied() {
                    None => true,
                    Some(c) => matches!(c, ' ' | '\t' | '\n' | ';' | '&' | '|' | '(' | ')' | '<' | '>' | '`'),
                }
            }
        }
    }

    #[inline]
    fn consume_if(&mut self, expected: char) -> bool {
        if self.peek() == Some(expected) {
            self.pos += 1;
            true
        } else {
            false
        }
    }

    // -----------------------------------------------------------------------
    // Whitespace / continuation
    // -----------------------------------------------------------------------

    fn skip_whitespace(&mut self) {
        loop {
            match self.peek() {
                Some(' ') | Some('\t') => { self.pos += 1; }
                Some('\\') if self.peek_at(1) == Some('\n') => {
                    self.pos += 2;
                    self.tokens.push(Token::LineCont);
                }
                _ => break,
            }
        }
    }

    // -----------------------------------------------------------------------
    // Alias expansion helpers
    // -----------------------------------------------------------------------

    /// Peek at the next bare word starting at the current position without
    /// advancing `self.pos`. Returns `None` if not positioned at a word char.
    fn peek_bare_word(&self) -> Option<String> {
        let mut i = self.pos;
        if i >= self.chars.len() {
            return None;
        }
        let ch = self.chars[i];
        // Must start with a word character (not an operator or quote)
        if ch.is_whitespace() || matches!(ch, '|' | '&' | ';' | '(' | ')' | '<' | '>' | '\n') {
            return None;
        }
        let mut word = String::new();
        while i < self.chars.len() {
            let c = self.chars[i];
            if c.is_whitespace() || matches!(c, '|' | '&' | ';' | '(' | ')' | '<' | '>' | '\n'
                | '\'' | '"' | '`' | '$' | '{' | '}' | '#') {
                break;
            }
            // Backslash-newline is transparent
            if c == '\\' && i + 1 < self.chars.len() && self.chars[i + 1] == '\n' {
                i += 2;
                continue;
            }
            word.push(c);
            i += 1;
        }
        if word.is_empty() { None } else { Some(word) }
    }

    /// Check whether the peeked word at `self.pos` is "standalone" — i.e.,
    /// the word boundary is followed by a metacharacter, whitespace, EOF,
    /// or a quote/operator (not more alphanumerics that would make it a
    /// different word).
    fn is_standalone_word(&self, word: &str) -> bool {
        let end = self.pos + word.len();
        if end >= self.chars.len() {
            return true;
        }
        let next_ch = self.chars[end];
        // The word must be followed by a shell metacharacter/delimiter
        next_ch.is_whitespace() || matches!(next_ch,
            '|' | '&' | ';' | '(' | ')' | '<' | '>' | '\n'
            | '\'' | '"' | '`' | '$' | '#' | '{' | '}')
    }

    /// Try to expand an alias at the current position. Returns true if
    /// expansion occurred (the chars Vec was modified), false otherwise.
    fn try_alias_expand(&mut self) -> bool {
        let aliases = match &self.aliases {
            Some(a) => a.clone(),
            None => return false,
        };
        let word = match self.peek_bare_word() {
            Some(w) => w,
            None => return false,
        };
        // The word must be standalone (not joined with more text)
        if !self.is_standalone_word(&word) {
            return false;
        }
        // Prevent circular expansion
        if self.expanding_aliases.contains(&word) {
            return false;
        }
        let alias_text = match aliases.get(&word) {
            Some(t) => t.clone(),
            None => return false,
        };
        // Perform the expansion: replace the word in self.chars with alias text
        let word_end = self.pos + word.len();
        let alias_chars: Vec<char> = alias_text.chars().collect();
        let alias_len = alias_chars.len();
        let trailing_space = alias_chars.last().map(|&c| c == ' ' || c == '\t').unwrap_or(false);

        // If the alias text ends with a digit and the remaining text starts
        // with `<` or `>`, the digit+redirect would be misparsed as an fd
        // redirect (e.g. `echo 0>&2` → fd 0 redirect instead of `echo 0 >&2`).
        // Insert a space at the boundary to prevent this.
        let next_after_word = self.chars.get(word_end).copied();
        let last_alias_char = alias_chars.last().copied();
        let need_boundary_space = !trailing_space
            && last_alias_char.map_or(false, |c| c.is_ascii_digit())
            && next_after_word.map_or(false, |c| c == '<' || c == '>');
        let extra = if need_boundary_space { 1usize } else { 0 };

        // Adjust existing expansion end markers for the splice
        let delta = (alias_len + extra) as isize - word.len() as isize;
        for (end_pos, _, _) in &mut self.alias_expansion_ends {
            if *end_pos > self.pos {
                *end_pos = (*end_pos as isize + delta) as usize;
            }
        }

        let mut new_chars = Vec::with_capacity(self.chars.len() - word.len() + alias_len + extra);
        new_chars.extend_from_slice(&self.chars[..self.pos]);
        new_chars.extend_from_slice(&alias_chars);
        if need_boundary_space {
            new_chars.push(' ');
        }
        new_chars.extend_from_slice(&self.chars[word_end..]);
        self.chars = new_chars;

        // Mark as expanding to prevent circular recursion
        self.expanding_aliases.insert(word.clone());

        // Record the end of this expansion and whether it has trailing space.
        // Include the boundary space in the expansion region if we added one.
        let expansion_end = self.pos + alias_len + extra;
        self.alias_expansion_ends.push((expansion_end, word, trailing_space));

        true
    }

    /// Returns true if `self.pos` is currently inside an alias expansion body.
    fn inside_alias_expansion(&self) -> bool {
        self.alias_expansion_ends.iter().any(|(end_pos, _, _)| self.pos < *end_pos)
    }

    /// Try to alias-expand the word AFTER a redirect operator at the current
    /// position. This handles cases like alias c='< ' where the trailing
    /// space should cause the redirect target to be alias-expanded.
    fn try_alias_expand_past_redirect(&mut self) -> bool {
        let aliases = match &self.aliases {
            Some(a) => a.clone(),
            None => return false,
        };

        // Skip the redirect operator character(s)
        let mut scan = self.pos;
        if scan >= self.chars.len() { return false; }

        // Skip < or > and any following <, >, &
        scan += 1;
        while scan < self.chars.len() && matches!(self.chars[scan], '<' | '>' | '&') {
            scan += 1;
        }

        // Skip whitespace
        while scan < self.chars.len() && (self.chars[scan] == ' ' || self.chars[scan] == '\t') {
            scan += 1;
        }

        // Peek the word at this position
        if scan >= self.chars.len() { return false; }
        let ch = self.chars[scan];
        if ch.is_whitespace() || matches!(ch, '|' | '&' | ';' | '(' | ')' | '<' | '>' | '\n') {
            return false;
        }

        let mut word = String::new();
        let mut wi = scan;
        while wi < self.chars.len() {
            let c = self.chars[wi];
            if c.is_whitespace() || matches!(c, '|' | '&' | ';' | '(' | ')' | '<' | '>' | '\n'
                | '\'' | '"' | '`' | '$' | '{' | '}' | '#') {
                break;
            }
            if c == '\\' && wi + 1 < self.chars.len() && self.chars[wi + 1] == '\n' {
                wi += 2;
                continue;
            }
            word.push(c);
            wi += 1;
        }

        if word.is_empty() { return false; }

        // Check standalone
        if wi < self.chars.len() {
            let next_ch = self.chars[wi];
            if !(next_ch.is_whitespace() || matches!(next_ch,
                '|' | '&' | ';' | '(' | ')' | '<' | '>' | '\n'
                | '\'' | '"' | '`' | '$' | '#' | '{' | '}')) {
                return false;
            }
        }

        // Check circular
        if self.expanding_aliases.contains(&word) { return false; }

        let alias_text = match aliases.get(&word) {
            Some(t) => t.clone(),
            None => return false,
        };

        // Perform the expansion at position `scan`
        let word_end = scan + word.len();
        let alias_chars: Vec<char> = alias_text.chars().collect();
        let alias_len = alias_chars.len();
        let trailing_space = alias_chars.last().map(|&c| c == ' ' || c == '\t').unwrap_or(false);

        // Adjust existing boundaries
        let delta = alias_len as isize - word.len() as isize;
        for (end_pos, _, _) in &mut self.alias_expansion_ends {
            if *end_pos > scan {
                *end_pos = (*end_pos as isize + delta) as usize;
            }
        }

        // Splice
        let mut new_chars = Vec::with_capacity(self.chars.len() - word.len() + alias_len);
        new_chars.extend_from_slice(&self.chars[..scan]);
        new_chars.extend_from_slice(&alias_chars);
        new_chars.extend_from_slice(&self.chars[word_end..]);
        self.chars = new_chars;

        // Track expansion
        self.expanding_aliases.insert(word.clone());
        let expansion_end = scan + alias_len;
        self.alias_expansion_ends.push((expansion_end, word, trailing_space));

        // Don't clear alias_expand_next here - let the boundary mechanism handle it.
        // But do clear it since this expansion consumed the "next word".
        self.alias_expand_next = false;

        true
    }

    /// Check and process alias expansion boundaries. When the lexer position
    /// reaches or passes the end of an alias expansion, unmark the alias
    /// and set alias_expand_next if the expansion had trailing space.
    fn check_alias_boundaries(&mut self) {
        let mut i = 0;
        while i < self.alias_expansion_ends.len() {
            let (end_pos, _, _) = &self.alias_expansion_ends[i];
            if self.pos >= *end_pos {
                let (_, name, had_trailing_space) = self.alias_expansion_ends.remove(i);
                self.expanding_aliases.remove(&name);
                if had_trailing_space {
                    self.alias_expand_next = true;
                }
            } else {
                i += 1;
            }
        }
    }

    // -----------------------------------------------------------------------
    // Main loop
    // -----------------------------------------------------------------------

    fn run(&mut self) {
        loop {
            self.skip_whitespace();

            // Alias expansion: check before matching the next character.
            if self.aliases.is_some() {
                // Process expansion boundaries: unmark completed expansions
                // and activate trailing-space flags.
                self.check_alias_boundaries();

                let alias_pos = self.is_alias_position();
                // Also try expansion when inside an active expansion boundary
                // (re-scanning replacement text for more aliases).
                let inside_expansion = self.alias_expansion_ends.iter().any(|(end, _, _)| self.pos < *end);
                let in_alias_pos = alias_pos || self.alias_expand_next || inside_expansion;
                if in_alias_pos {
                    if self.try_alias_expand() {
                        // Expansion succeeded. Clear alias_expand_next since
                        // the "next word" was consumed. The new expansion's
                        // trailing-space will fire via the boundary mechanism.
                        self.alias_expand_next = false;
                        continue;
                    }
                    // If alias_expand_next or inside an expansion, and we're
                    // at a redirect operator, try to expand the word past it.
                    if self.alias_expand_next || inside_expansion {
                        if let Some(ch) = self.peek() {
                            if ch == '<' || ch == '>' {
                                if self.try_alias_expand_past_redirect() {
                                    self.alias_expand_next = false;
                                    continue;
                                }
                            }
                        }
                    }
                }
                // Clear alias_expand_next when we're past all expansion
                // boundaries and not in alias position.
                if self.alias_expand_next && !alias_pos && !inside_expansion {
                    self.alias_expand_next = false;
                }
            }

            match self.peek() {
                None => {
                    self.pending_heredocs.clear();
                    self.tokens.push(Token::Eof);
                    return;
                }
                Some('#') => {
                    // Comment – skip to end of line
                    while matches!(self.peek(), Some(c) if c != '\n') {
                        self.pos += 1;
                    }
                }
                Some('\n') => {
                    self.pos += 1;
                    if self.inside_alias_expansion() {
                        self.tokens.push(Token::AliasNewline);
                    } else {
                        self.tokens.push(Token::Newline);
                    }
                    if !self.pending_heredocs.is_empty() {
                        self.consume_heredoc_bodies();
                    }
                }
                // |  ||  |&
                Some('|') => {
                    self.pos += 1;
                    if self.consume_if('|') {
                        self.tokens.push(Token::OrOr);
                    } else if self.consume_if('&') {
                        self.tokens.push(Token::PipeAmp);
                    } else {
                        self.tokens.push(Token::Pipe);
                    }
                }
                // &  &&  &>  &>>
                Some('&') => {
                    self.pos += 1;
                    if self.consume_if('&') {
                        self.tokens.push(Token::AndAnd);
                    } else if self.peek() == Some('>') {
                        self.pos += 1;
                        let op = if self.peek() == Some('>') {
                            self.pos += 1;
                            RedirectOp::AndAppend
                        } else {
                            RedirectOp::AndOutput
                        };
                        self.skip_whitespace();
                        let target = self.read_word_raw();
                        self.tokens.push(Token::Redirect(RedirectInfo { fd: None, op, target, varfd: None }));
                    } else {
                        self.tokens.push(Token::Amp);
                    }
                }
                // ;  ;;  ;&  ;;&
                Some(';') => {
                    self.pos += 1;
                    if self.peek() == Some(';') {
                        self.pos += 1;
                        if self.peek() == Some('&') {
                            self.pos += 1;
                            if self.case_depth > 0 { self.in_case_pattern = true; }
                            self.tokens.push(Token::CaseSemiSemiAmp);
                        } else {
                            if self.case_depth > 0 { self.in_case_pattern = true; }
                            self.tokens.push(Token::CaseSemi);
                        }
                    } else if self.peek() == Some('&') {
                        self.pos += 1;
                        if self.case_depth > 0 { self.in_case_pattern = true; }
                        self.tokens.push(Token::CaseSemiAmp);
                    } else {
                        self.tokens.push(Token::Semi);
                    }
                }
                // (  ((…))
                Some('(') => {
                    // Check for (( arith command ))
                    if self.peek_at(1) == Some('(') {
                        let save_pos = self.pos;
                        self.pos += 2; // consume both `(`
                        let (expr, found_close) = self.read_arith_cmd_body();
                        if found_close {
                            self.tokens.push(Token::ArithCmd(expr));
                        } else {
                            // Didn't find matching )) — treat as two LParens
                            self.pos = save_pos + 1;
                            self.tokens.push(Token::LParen);
                        }
                    } else {
                        self.pos += 1;
                        self.tokens.push(Token::LParen);
                    }
                }
                Some(')') => {
                    self.pos += 1;
                    if self.in_case_pattern {
                        self.in_case_pattern = false;
                    }
                    self.tokens.push(Token::RParen);
                }
                // { is a reserved word only when standalone (followed by
                // whitespace/newline/EOF/;).  Otherwise it starts a brace
                // expansion like {a,b,c} and must go through word reading.
                Some('{') if matches!(self.peek_at(1), None | Some(' ') | Some('\t') | Some('\n') | Some(';') | Some('|') | Some('&') | Some(')') | Some('#')) => {
                    self.pos += 1;
                    self.tokens.push(Token::LBrace);
                }
                // Bash `{varname}</file` / `{varname}>/file` etc. — named
                // file descriptor allocation.  Only matches if the
                // contents `{<name>}` are a valid identifier and the
                // `}` is immediately followed by `<` or `>`.
                Some('{') if self.try_match_varfd_redirect() => {
                    // handled inside try_match_varfd_redirect
                }
                // } is always a reserved word delimiter
                Some('}') => { self.pos += 1; self.tokens.push(Token::RBrace); }
                // [[  ]] – `[[` is only a reserved word when followed by
                // whitespace (like any shell reserved word).  Inside bracket
                // expressions `[[:alpha:]]`, `[[.a.]]`, etc. it is NOT a
                // reserved word.  Similarly, `]]` only closes `[[ … ]]`.
                Some('[') if self.peek_at(1) == Some('[')
                    && matches!(self.peek_at(2), None | Some(' ') | Some('\t') | Some('\n')) =>
                {
                    self.pos += 2;
                    self.in_double_bracket = true;
                    self.tokens.push(Token::DoubleLBracket);
                }
                Some(']') if self.peek_at(1) == Some(']') && self.in_double_bracket => {
                    self.pos += 2;
                    self.in_double_bracket = false;
                    self.tokens.push(Token::DoubleRBracket);
                }
                // < redirections
                Some('<') => {
                    // Inside `[[ … ]]`, a bare `<` is the
                    // string-comparison operator, NOT an input
                    // redirect.  Emit it as a plain word so the
                    // double-bracket parser sees the operand on the
                    // other side as a separate token.
                    if self.in_double_bracket && !matches!(self.peek_at(1), Some('<')|Some('('))
                    {
                        self.pos += 1;
                        self.tokens.push(Token::Word("<".to_string()));
                    } else {
                        self.lex_less(None);
                    }
                }
                // > redirections
                Some('>') => {
                    if self.in_double_bracket && !matches!(self.peek_at(1), Some('>')|Some('(')|Some('&')) {
                        self.pos += 1;
                        self.tokens.push(Token::Word(">".to_string()));
                    } else {
                        self.lex_greater(None);
                    }
                }
                // > (cmd)  process substitution – note: >( already handled in
                // lex_greater, but we check it there.
                // Digit – may be fd number before a redirection
                Some(c) if c.is_ascii_digit() => {
                    self.lex_digit_or_word();
                }
                // Process substitution >( and <( when at start of a token
                // These are handled by read_word_token via the '<'/'>' check;
                // but we can also hit them here if we somehow land on '<' or '>'
                // – those are already handled above. For >( / <( the '<' and '>'
                // paths in lex_less / lex_greater handle them.
                _ => {
                    self.read_word_token();
                }
            }
            // After certain reserved words, the next word has a special role
            // (variable name, function name) and should NOT be alias-expanded.
            if let Some(last) = self.last_non_linecont_token() {
                if matches!(last, Token::For | Token::Select | Token::Function | Token::Case) {
                    self.alias_expand_next = false;
                }
            }
        }
    }

    fn insert_outer_suffix_text(&mut self, suffix: &str) {
        if suffix.is_empty() {
            return;
        }

        let inserted = suffix.chars().count();
        self.chars.splice(self.pos..self.pos, suffix.chars());
        for (end, _, _) in &mut self.alias_expansion_ends {
            if *end >= self.pos {
                *end += inserted;
            }
        }
    }

    // -----------------------------------------------------------------------
    // Redirection: < variants
    // -----------------------------------------------------------------------

    /// If the current position looks like `{name}<` or `{name}>`, parse
    /// it as a bash named-fd redirect and return true.  Otherwise do
    /// nothing and return false (so the caller can fall through to the
    /// normal `{` handler).
    fn try_match_varfd_redirect(&mut self) -> bool {
        // We expect self.peek() == '{'
        let save = self.pos;
        self.pos += 1; // consume '{'
        // Parse identifier: [_a-zA-Z][_a-zA-Z0-9]*
        let name_start = self.pos;
        match self.peek() {
            Some(c) if c == '_' || c.is_ascii_alphabetic() => {
                self.pos += 1;
                while let Some(c) = self.peek() {
                    if c == '_' || c.is_ascii_alphanumeric() {
                        self.pos += 1;
                    } else {
                        break;
                    }
                }
            }
            _ => {
                self.pos = save;
                return false;
            }
        }
        // Optional array subscript `[…]` so `{fd[0]}` is recognised as
        // a varfd redirect.  Body of the subscript is collected verbatim
        // up to the matching `]`.
        if self.peek() == Some('[') {
            self.pos += 1;
            let mut depth = 1i32;
            while depth > 0 {
                match self.peek() {
                    None | Some('\n') => {
                        self.pos = save;
                        return false;
                    }
                    Some('[') => { depth += 1; self.pos += 1; }
                    Some(']') => {
                        depth -= 1;
                        self.pos += 1;
                        if depth == 0 { break; }
                    }
                    Some(_) => self.pos += 1,
                }
            }
        }
        let name: String = self.chars[name_start..self.pos].iter().collect();
        if self.peek() != Some('}') {
            self.pos = save;
            return false;
        }
        self.pos += 1; // consume '}'
        match self.peek() {
            Some('<') => {
                self.lex_less_varfd(None, Some(name));
                true
            }
            Some('>') => {
                self.lex_greater_varfd(None, Some(name));
                true
            }
            _ => {
                self.pos = save;
                false
            }
        }
    }

    fn lex_less(&mut self, fd: Option<i32>) {
        self.lex_less_varfd(fd, None);
    }
    fn lex_less_varfd(&mut self, fd: Option<i32>, varfd: Option<String>) {
        self.pos += 1; // consume '<'
        match self.peek() {
            Some('(') => {
                // <(cmd) process substitution
                self.pos += 1;
                let inner = self.read_nested_parens_content();
                self.tokens.push(Token::ProcessSub(format!("<({})", inner)));
            }
            Some('<') => {
                self.pos += 1;
                if self.peek() == Some('<') {
                    // <<< here-string
                    self.pos += 1;
                    self.skip_whitespace();
                    let target = self.read_word_raw();
                    self.tokens.push(Token::Redirect(RedirectInfo {
                        fd,
                        op: RedirectOp::HereString,
                        target,
                        varfd: varfd.clone(),
                    }));
                } else {
                    // << or <<- here-doc
                    let strip_tabs = self.consume_if('-');
                    self.skip_whitespace();
                    let (mut delim, quoted) = self.read_heredoc_delimiter();
                    // For <<-, leading tabs are stripped from both body lines
                    // and the delimiter line; normalise the stored delim to
                    // its stripped form so body-line matching is trivial.
                    if strip_tabs {
                        delim = delim.trim_start_matches('\t').to_string();
                    }
                    let info = HereDocInfo {
                        fd,
                        op: RedirectOp::Input,
                        delimiter: delim,
                        strip_tabs,
                        quoted,
                        content: String::new(),
                        varfd: varfd.clone(),
                    };
                    // Bash limits here-documents to 16 per command.
                    if self.pending_heredocs.len() >= 16 && self.heredoc_max_exceeded_line.is_none() {
                        // Compute the current line number from tokens
                        let lineno = self.tokens.iter().filter(|t| matches!(t, Token::Newline | Token::AliasNewline)).count() + 1;
                        self.heredoc_max_exceeded_line = Some(lineno);
                    } else {
                        self.pending_heredocs.push(info.clone());
                        self.tokens.push(Token::HereDoc(info));
                    }
                }
            }
            Some('&') => {
                self.pos += 1;
                self.skip_whitespace();
                let target = self.read_word_raw();
                self.tokens.push(Token::Redirect(RedirectInfo {
                    fd, op: RedirectOp::InputDup, target, varfd: varfd.clone(),
                }));
            }
            Some('>') => {
                self.pos += 1;
                self.skip_whitespace();
                let target = self.read_word_raw();
                self.tokens.push(Token::Redirect(RedirectInfo {
                    fd, op: RedirectOp::InputOutput, target, varfd: varfd.clone(),
                }));
            }
            _ => {
                self.skip_whitespace();
                // Process substitution as redirect target: N< <(cmd) or N< >(cmd)
                if (self.peek() == Some('<') || self.peek() == Some('>'))
                    && self.peek_at(1) == Some('(')
                {
                    let dir_ch = self.peek().unwrap();
                    self.pos += 2; // consume <( or >(
                    let inner = self.read_nested_parens_content();
                    // Use PUA-marked form so the execution-time resolver
                    // distinguishes this from a literal `<(cmd)` filename.
                    let marker = if dir_ch == '<' { '\u{E010}' } else { '\u{E011}' };
                    let procsub = format!("{}{}\u{E012}", marker, inner);
                    self.tokens.push(Token::Redirect(RedirectInfo {
                        fd, op: RedirectOp::Input, target: procsub, varfd: varfd.clone(),
                    }));
                } else {
                    let target = self.read_word_raw();
                    self.tokens.push(Token::Redirect(RedirectInfo {
                        fd, op: RedirectOp::Input, target, varfd: varfd.clone(),
                    }));
                }
            }
        }
    }

    // -----------------------------------------------------------------------
    // Redirection: > variants
    // -----------------------------------------------------------------------

    fn lex_greater(&mut self, fd: Option<i32>) {
        self.lex_greater_varfd(fd, None);
    }
    fn lex_greater_varfd(&mut self, fd: Option<i32>, varfd: Option<String>) {
        self.pos += 1; // consume '>'
        match self.peek() {
            Some('(') => {
                // >(cmd) process substitution
                self.pos += 1;
                let inner = self.read_nested_parens_content();
                self.tokens.push(Token::ProcessSub(format!(">({})", inner)));
            }
            Some('>') => {
                self.pos += 1;
                self.skip_whitespace();
                let target = self.read_word_raw();
                self.tokens.push(Token::Redirect(RedirectInfo {
                    fd, op: RedirectOp::Append, target, varfd: varfd.clone(),
                }));
            }
            Some('&') => {
                self.pos += 1;
                self.skip_whitespace();
                let target = self.read_word_raw();
                self.tokens.push(Token::Redirect(RedirectInfo {
                    fd, op: RedirectOp::OutputDup, target, varfd: varfd.clone(),
                }));
            }
            Some('|') => {
                self.pos += 1;
                self.skip_whitespace();
                let target = self.read_word_raw();
                self.tokens.push(Token::Redirect(RedirectInfo {
                    fd, op: RedirectOp::Clobber, target, varfd: varfd.clone(),
                }));
            }
            _ => {
                self.skip_whitespace();
                // Process substitution as redirect target: N> <(cmd) or N> >(cmd)
                if (self.peek() == Some('<') || self.peek() == Some('>'))
                    && self.peek_at(1) == Some('(')
                {
                    let dir_ch = self.peek().unwrap();
                    self.pos += 2; // consume <( or >(
                    let inner = self.read_nested_parens_content();
                    let procsub = format!("{}({})", dir_ch, inner);
                    self.tokens.push(Token::Redirect(RedirectInfo {
                        fd, op: RedirectOp::Output, target: procsub, varfd: varfd.clone(),
                    }));
                } else {
                    let target = self.read_word_raw();
                    self.tokens.push(Token::Redirect(RedirectInfo {
                        fd, op: RedirectOp::Output, target, varfd: varfd.clone(),
                    }));
                }
            }
        }
    }

    // -----------------------------------------------------------------------
    // Digit-or-word: 2> 2>&1 etc., or plain word starting with digits
    // -----------------------------------------------------------------------

    fn lex_digit_or_word(&mut self) {
        let start = self.pos;
        while matches!(self.peek(), Some(c) if c.is_ascii_digit()) {
            self.pos += 1;
        }
        let digit_str: String = self.chars[start..self.pos].iter().collect();

        match self.peek() {
            Some('<') => {
                if let Ok(fd) = digit_str.parse::<i32>() {
                    self.lex_less(Some(fd));
                } else {
                    self.pos = start;
                    self.read_word_token();
                }
            }
            Some('>') => {
                if let Ok(fd) = digit_str.parse::<i32>() {
                    self.lex_greater(Some(fd));
                } else {
                    self.pos = start;
                    self.read_word_token();
                }
            }
            _ => {
                // Digits are part of a plain word; back up and do normal word read.
                self.pos = start;
                self.read_word_token();
            }
        }
    }

    // -----------------------------------------------------------------------
    // Word token (top-level dispatcher)
    // -----------------------------------------------------------------------

    /// Read a complete word token and push it (or the appropriate specialised
    /// token) into `self.tokens`.
    /// Determine whether a `<(` or `>(` at position `self.pos` is best
    /// interpreted as a process substitution (becoming part of a word) or
    /// as a redirection.  We scan past the matching `)` and look at the
    /// first non-whitespace character that follows.  If it could continue
    /// a word (alphanumeric, `=`, `.`, etc.) or start the `()` of a
    /// function-definition shorthand, we treat it as a process sub.
    fn looks_like_word_start_procsub(&self) -> bool {
        // Scan ahead to find the matching `)`.  Track brace/paren depth.
        let n = self.chars.len();
        let mut i = self.pos + 2; // skip `<(` or `>(`
        let mut depth = 1i32;
        while i < n && depth > 0 {
            match self.chars[i] {
                '(' => depth += 1,
                ')' => depth -= 1,
                _ => {}
            }
            i += 1;
        }
        // i now points just after the matching `)`
        if depth != 0 { return false; }
        // Skip whitespace and look at next non-blank char.
        while i < n && matches!(self.chars[i], ' ' | '\t') { i += 1; }
        match self.chars.get(i) {
            Some('(') => true, // function-def shorthand like `<(:) ()`
            Some('\n') | None | Some('|') | Some('&') | Some(';')
                | Some('<') | Some('>') => false, // end of command
            _ => false, // default: treat as redirection
        }
    }

    fn read_word_token(&mut self) {
        // Collect all pieces of this word.
        let mut pieces: Vec<WordPiece> = Vec::new();
        // Track open `[` count inside this word.  When we're inside
        // `[[ … ]]` and the word contains a bracket expression like
        // `[[:alpha:]]`, `]]` inside the bracket expression must NOT
        // terminate the outer `[[`.  We track literal `[` characters
        // consumed into this word and only treat `]]` as a terminator
        // when they're all closed.
        let mut word_bracket_depth: i32 = 0;

        loop {
            match self.peek() {
                None | Some('\n') => break,
                Some(' ') | Some('\t') => break,
                Some('\\') if self.peek_at(1) == Some('\n') => {
                    // Continuation – transparent
                    self.pos += 2;
                }
                // Operator characters end a word
                Some('|') | Some('&') | Some(';') | Some('(') | Some(')') => break,
                // < and > end a word UNLESS they start a process substitution.
                // Process substitutions can appear at word start too (e.g.
                // `<(:) ()` as a function name) — but only if the char after
                // `)` suggests it's a word, not a redirect target.
                Some('<') if !pieces.is_empty() && self.peek_at(1) == Some('(') => {
                    self.pos += 2; // consume <(
                    let inner = self.read_nested_parens_content();
                    pieces.push(WordPiece::ProcessSub(format!("<({})", inner)));
                }
                Some('>') if !pieces.is_empty() && self.peek_at(1) == Some('(') => {
                    self.pos += 2; // consume >(
                    let inner = self.read_nested_parens_content();
                    pieces.push(WordPiece::ProcessSub(format!(">({})", inner)));
                }
                // `<(...)` / `>(...)` at word start, followed by more word
                // characters — treat as process substitution.  This handles
                // things like `<(:) ()` where the process substitution IS
                // the (invalid) word to be used as a function name.
                Some('<') if pieces.is_empty() && self.peek_at(1) == Some('(') &&
                    self.looks_like_word_start_procsub() => {
                    self.pos += 2;
                    let inner = self.read_nested_parens_content();
                    pieces.push(WordPiece::ProcessSub(format!("<({})", inner)));
                }
                Some('>') if pieces.is_empty() && self.peek_at(1) == Some('(') &&
                    self.looks_like_word_start_procsub() => {
                    self.pos += 2;
                    let inner = self.read_nested_parens_content();
                    pieces.push(WordPiece::ProcessSub(format!(">({})", inner)));
                }
                Some('<') | Some('>') => break,
                // { and } inside a word are literal characters (brace expansion
                // like {a,b,c} is handled by the expander, not the lexer).
                // } also terminates a word if we haven't accumulated anything yet
                // (so the outer loop can see it as RBrace).
                Some('}') if pieces.is_empty() => break,
                Some('[') if self.peek_at(1) == Some('[')
                    && matches!(self.peek_at(2), None | Some(' ') | Some('\t') | Some('\n')) => break,
                Some(']') if self.peek_at(1) == Some(']')
                    && self.in_double_bracket
                    && word_bracket_depth == 0 => break,
                // Extended globs: @( *( +( ?( !(
                Some(c) if is_extglob_prefix(c) && self.peek_at(1) == Some('(') => {
                    let prefix = c;
                    self.pos += 2; // consume prefix and '('
                    let inner = self.read_nested_parens_content();
                    pieces.push(WordPiece::ExtGlob(format!("{}({})", prefix, inner)));
                }
                Some('\'') => {
                    let inner = self.read_single_quoted_inner();
                    pieces.push(WordPiece::SingleQuoted(inner));
                }
                Some('"') => {
                    let inner = self.read_double_quoted_inner();
                    pieces.push(WordPiece::DoubleQuoted(inner));
                }
                Some('`') => {
                    let inner = self.read_backtick_inner();
                    pieces.push(WordPiece::CommandSub(format!("`{}`", inner)));
                }
                Some('$') => {
                    let piece = self.read_dollar_piece();
                    pieces.push(piece);
                }
                Some('~') if pieces.is_empty() => {
                    // Tilde prefix: collect until '/', ':', or word terminator
                    let tilde = self.read_tilde_prefix();
                    pieces.push(WordPiece::Tilde(tilde));
                }
                Some('~') => {
                    // Mid-word tilde is a literal character
                    pieces.push(WordPiece::Bare("~".to_string()));
                    self.pos += 1;
                }
                Some('\\') => {
                    self.pos += 1; // consume backslash
                    match self.peek() {
                        None => { pieces.push(WordPiece::Bare("\\".to_string())); }
                        Some('\n') => { self.pos += 1; } // continuation
                        Some(c) => {
                            let mut s = String::from('\\');
                            s.push(c);
                            self.pos += 1;
                            pieces.push(WordPiece::Bare(s));
                        }
                    }
                }
                Some(c) => {
                    // Accumulate bare characters
                    let mut s = String::new();
                    loop {
                        match self.peek() {
                            None | Some('\n') | Some(' ') | Some('\t')
                            | Some('|') | Some('&') | Some(';') | Some('(')
                            | Some(')') | Some('<') | Some('>') | Some('\\')
                            | Some('\'') | Some('"') | Some('`') | Some('$')
                            | Some('~') => break,
                            Some('[') if self.peek_at(1) == Some('[')
                                && matches!(self.peek_at(2), None | Some(' ') | Some('\t') | Some('\n')) => break,
                            Some(']') if self.peek_at(1) == Some(']')
                                && self.in_double_bracket
                                && word_bracket_depth == 0 => break,
                            Some(c2) if is_extglob_prefix(c2) && self.peek_at(1) == Some('(') => break,
                            Some('[') if pieces.is_empty() && !s.is_empty()
                                && s.chars().all(|c| c.is_alphanumeric() || c == '_')
                                && s.chars().next().map_or(false, |c| c.is_alphabetic() || c == '_')
                                && word_bracket_depth == 0 => {
                                // Assignment subscript context:
                                // NAME[...]=value  or  NAME[...]+=value
                                // Spaces inside the `[...]` are literal
                                // parts of the key (bash allows assoc
                                // keys like `fluff[hello world]=foo`).
                                // Quotes inside the subscript are
                                // recognised so that `]` in a quoted
                                // region doesn't close the subscript —
                                // matching bash's `skipsubst` behaviour.
                                s.push('[');
                                self.pos += 1;
                                let mut depth = 1i32;
                                while depth > 0 {
                                    match self.peek() {
                                        None | Some('\n') => break,
                                        Some('\\') => {
                                            // Backslash-escape: preserve
                                            // the backslash and the next
                                            // char verbatim (so `\]`
                                            // doesn't close the subscript).
                                            s.push('\\');
                                            self.pos += 1;
                                            if let Some(c) = self.peek() {
                                                s.push(c);
                                                self.pos += 1;
                                            }
                                        }
                                        Some('\'') => {
                                            // Single-quoted: consume the
                                            // whole quoted region as
                                            // literal (no interpretation).
                                            let inner = self.read_single_quoted_inner();
                                            s.push('\'');
                                            s.push_str(&inner);
                                            s.push('\'');
                                        }
                                        Some('"') => {
                                            // Double-quoted: read with
                                            // dquote semantics so a `]`
                                            // inside the quotes doesn't
                                            // end the subscript.
                                            let inner = self.read_double_quoted_inner();
                                            s.push('"');
                                            s.push_str(&inner);
                                            s.push('"');
                                        }
                                        Some('`') => {
                                            let inner = self.read_backtick_inner();
                                            s.push('`');
                                            s.push_str(&inner);
                                            s.push('`');
                                        }
                                        Some('$') => {
                                            let piece = self.read_dollar_piece();
                                            s.push_str(&piece_to_string(piece));
                                        }
                                        Some('[') => { depth += 1; s.push('['); self.pos += 1; }
                                        Some(']') => {
                                            depth -= 1;
                                            s.push(']');
                                            self.pos += 1;
                                            if depth == 0 { break; }
                                        }
                                        Some(c3) => { s.push(c3); self.pos += 1; }
                                    }
                                }
                            }
                            Some(c2) => {
                                if c2 == '[' { word_bracket_depth += 1; }
                                if c2 == ']' && word_bracket_depth > 0 { word_bracket_depth -= 1; }
                                s.push(c2);
                                self.pos += 1;
                            }
                        }
                    }
                    if !s.is_empty() {
                        pieces.push(WordPiece::Bare(s));
                    }
                    let _ = c;
                }
            }
        }

        if pieces.is_empty() {
            return;
        }

        self.emit_word_pieces(pieces);
    }

    fn emit_word_pieces(&mut self, pieces: Vec<WordPiece>) {
        // Check for assignment pattern: first piece is Bare ending with = or +=
        if let Some(WordPiece::Bare(ref first)) = pieces.first() {
            if let Some(assign_info) = detect_assignment_prefix(first) {
                // It's an assignment: name, op, and the rest of pieces form the value
                let (name, op, bare_rest) = assign_info;

                // Check for array assignment: name=( ... )
                if bare_rest.is_empty() && pieces.len() == 1 && self.peek() == Some('(') {
                    let bad_before = self.array_literal_bad_token.is_some();
                    self.pos += 1; // consume '('
                    let inner = self.read_array_literal();
                    // If the array body was malformed (unexpected `&`, `|`,
                    // `;` inside the parens), don't emit an AssignWord —
                    // the run_string driver prints the syntax error and
                    // we don't want to shadow the `false`-valued `$?` it
                    // sets with a successful empty-array assignment.
                    if !bad_before && self.array_literal_bad_token.is_some() {
                        // Insert a stand-in "false" token so `$?` becomes
                        // 1 for the failed assignment, matching bash.
                        self.tokens.push(Token::Word("false".to_string()));
                        self.tokens.push(Token::Newline);
                        return;
                    }
                    let suffix = self.read_compound_assign_suffix_raw();
                    if !suffix.is_empty() {
                        let value = format!("({}){}", inner.replace('\x1F', " "), suffix);
                        self.tokens.push(Token::AssignWord(name, op, value));
                        return;
                    }
                    // Encode as special value with \x00ARRAY\x00 marker
                    let value = format!("\x00ARRAY\x00{}", inner);
                    self.tokens.push(Token::AssignWord(name, op, value));
                    return;
                }

                let mut value_parts: Vec<String> = Vec::new();
                if !bare_rest.is_empty() {
                    value_parts.push(bare_rest);
                }
                for p in pieces.into_iter().skip(1) {
                    value_parts.push(piece_to_string(p));
                }
                let value = value_parts.join("");
                self.tokens.push(Token::AssignWord(name, op, value));
                return;
            }

            // Multi-piece assignment: NAME[quoted_subscript]=value
            // e.g. BASH_ALIASES['\$']=xx → Bare("BASH_ALIASES["), SingleQuoted("\\$"), Bare("]=xx")
            // The first Bare ends with '[' and a later Bare contains ']='.
            if pieces.len() >= 2 && first.ends_with('[') {
                // Join all pieces into a single string and try assignment detection.
                let joined: String = pieces.iter().map(|p| piece_to_string_raw(p)).collect();
                if let Some((name, op, rest)) = detect_assignment_prefix(&joined) {
                    // Reconstruct the value preserving quoting of pieces after the '='.
                    // The name includes the subscript (e.g. "BASH_ALIASES[\$]").
                    self.tokens.push(Token::AssignWord(name, op, rest));
                    return;
                }
            }
        }

        if pieces.len() == 1 {
            match pieces.into_iter().next().unwrap() {
                WordPiece::Bare(s) => {
                    // Check for reserved words, assignments, etc.
                    self.emit_bare_word(s);
                }
                WordPiece::SingleQuoted(inner) => {
                    self.tokens.push(Token::SingleQuoted(inner));
                }
                WordPiece::DoubleQuoted(inner) => {
                    self.tokens.push(Token::DoubleQuoted(inner));
                }
                WordPiece::DollarSingleQuoted(inner) => {
                    self.tokens.push(Token::DollarSingleQuoted(inner));
                }
                WordPiece::BraceGroup(s) => {
                    self.tokens.push(Token::BraceGroup(s));
                }
                WordPiece::CommandSub(s) => {
                    self.tokens.push(Token::CommandSub(s));
                }
                WordPiece::ArithSub(s) => {
                    self.tokens.push(Token::ArithSub(s));
                }
                WordPiece::ProcessSub(s) => {
                    self.tokens.push(Token::ProcessSub(s));
                }
                WordPiece::ExtGlob(s) => {
                    self.tokens.push(Token::ExtGlob(s));
                }
                WordPiece::Tilde(s) => {
                    self.tokens.push(Token::Tilde(s));
                }
            }
        } else {
            // Multiple pieces → Concat.  Flatten each piece to its string
            // representation so the expander deals with one string per
            // word-element.
            let mut parts: Vec<String> = Vec::new();
            for p in pieces {
                parts.push(piece_to_string(p));
            }
            self.tokens.push(Token::Concat(parts));
        }
    }

    fn emit_bare_word(&mut self, s: String) {
        // 1. Reserved words (only recognised as whole unquoted words)
        //
        // Special case: the word immediately following CASE/FOR/SELECT
        // is the loop/case expression and must never be a reserved word.
        // This handles `case esac in …`, `for do in …`, etc.
        if matches!(
            self.last_non_linecont_token(),
            Some(Token::Case) | Some(Token::For) | Some(Token::Select)
        ) {
            self.tokens.push(Token::Word(s));
            return;
        }
        if let Some(rw) = reserved_word(&s) {
            // Track case statement nesting for alias expansion suppression.
            //
            // Bash's case-pattern tokenization rule (PST_CASEPAT):
            // Inside a case pattern position (after `in`, `;;`, `;&`, `;;&`,
            // before `)`), reserved-word recognition is suppressed.
            // The ONLY reserved word still recognized is `esac`, and only
            // when the preceding token is NOT `(` or `|` — because
            // `(esac)` and `|esac)` are valid pattern alternatives.
            if self.in_case_pattern {
                match &rw {
                    Token::Esac => {
                        let last_is_paren_or_pipe = matches!(
                            self.last_non_linecont_token(),
                            Some(Token::LParen) | Some(Token::Pipe)
                        );
                        if last_is_paren_or_pipe {
                            // emit as WORD (pattern alternative)
                            self.tokens.push(Token::Word(s));
                            return;
                        }
                        // esac closes the case
                        if self.case_depth > 0 {
                            self.case_depth -= 1;
                        }
                        self.in_case_pattern = false;
                        self.tokens.push(rw);
                        return;
                    }
                    _ => {
                        // All other reserved words become WORD in
                        // pattern position (in, case, if, while, for,
                        // do, done, etc.)
                        self.tokens.push(Token::Word(s));
                        return;
                    }
                }
            }
            match &rw {
                Token::Case => {
                    self.case_depth += 1;
                    self.expecting_in_count += 1;
                    self.expecting_in_command = Some(Token::Case);
                    self.tokens.push(rw);
                    return;
                }
                Token::For | Token::Select => {
                    self.expecting_in_count += 1;
                    self.expecting_in_command = Some(rw.clone());
                    self.tokens.push(rw);
                    return;
                }
                Token::In if self.case_depth > 0 || self.expecting_in_count > 0 => {
                    // Bash rule (from decomp in _read_token):
                    //
                    //   Strict (when expecting_in_token == 0):
                    //     `in` is IN only when last=WORD and
                    //     prev-prev=CASE/FOR/SELECT.
                    //   Loose (when expecting_in_token != 0):
                    //     last=WORD or NEWLINE, current="in" → IN.
                    //
                    // Only CASE enters pattern-list mode (PST_CASEPAT);
                    // FOR/SELECT use `in` too but their following words
                    // are plain words, not patterns.
                    let n = self.tokens.len();
                    let is_word_tok = |t: &Token| matches!(t,
                        Token::Word(_) | Token::Concat(_) | Token::Tilde(_)
                        | Token::SingleQuoted(_) | Token::DoubleQuoted(_)
                        | Token::DollarSingleQuoted(_) | Token::BraceGroup(_)
                        | Token::CommandSub(_) | Token::ProcessSub(_)
                        | Token::ArithSub(_) | Token::ExtGlob(_)
                    );
                    let last_is_word_or_nl = n >= 1 && (
                        is_word_tok(&self.tokens[n - 1])
                        || matches!(&self.tokens[n - 1], Token::Newline | Token::Semi)
                    );
                    let prev_is_word = n >= 1 && is_word_tok(&self.tokens[n - 1]);
                    let prev_prev_is_head = n >= 2 && matches!(
                        &self.tokens[n - 2],
                        Token::Case | Token::For | Token::Select
                    );
                    let accept = if self.expecting_in_count > 0 {
                        // Loose rule when we're actively awaiting an IN
                        last_is_word_or_nl
                    } else {
                        // Strict rule (fallback — unlikely reached)
                        prev_is_word && prev_prev_is_head
                    };
                    if accept {
                        // Determine whether this IN enters CASEPAT
                        let is_case_in = matches!(
                            self.expecting_in_command,
                            Some(Token::Case)
                        ) || (prev_is_word
                              && n >= 2
                              && matches!(&self.tokens[n - 2], Token::Case));
                        if self.expecting_in_count > 0 {
                            self.expecting_in_count -= 1;
                        }
                        self.expecting_in_command = None;
                        if is_case_in {
                            self.in_case_pattern = true;
                        }
                        self.tokens.push(rw);
                        return;
                    }
                    // Not in the right position — emit as WORD.
                    self.tokens.push(Token::Word(s));
                    return;
                }
                Token::In if self.is_command_position() => {
                    self.tokens.push(rw);
                    return;
                }
                Token::Esac => {
                    // `esac` is always a keyword in case context (here
                    // we're outside a pattern position — e.g. after a
                    // `)` command list or newline).
                    if self.case_depth > 0 {
                        self.case_depth -= 1;
                    }
                    self.in_case_pattern = false;
                    self.tokens.push(rw);
                    return;
                }
                _ => {
                    self.tokens.push(rw);
                    return;
                }
            }
        }
        // 2. Assignment: NAME=value or NAME+=value
        if let Some((name, op, val)) = parse_assignment(&s) {
            self.tokens.push(Token::AssignWord(name, op, val));
            return;
        }
        // 3. Tilde-only word
        if s == "~" || (s.starts_with('~') && !s.contains('/') && s.len() > 1) {
            self.tokens.push(Token::Tilde(s));
            return;
        }
        // 4. Plain word
        self.tokens.push(Token::Word(s));
    }

    // -----------------------------------------------------------------------
    // read_word_raw – used for redirect targets (returns a plain String)
    // -----------------------------------------------------------------------

    fn read_word_raw(&mut self) -> String {
        let start = self.pos;
        // Collect until whitespace or operator
        let mut s = String::new();
        loop {
            match self.peek() {
                None | Some('\n') | Some(' ') | Some('\t') => break,
                Some('\\') if self.peek_at(1) == Some('\n') => {
                    self.pos += 2;
                }
                Some('\\') => {
                    self.pos += 1;
                    if let Some(c) = self.peek() {
                        s.push(c);
                        self.pos += 1;
                    } else {
                        // Trailing backslash with no following char: bash
                        // preserves it as a literal `\`.
                        s.push('\\');
                    }
                }
                Some('\'') => {
                    let inner = self.read_single_quoted_inner();
                    s.push('\'');
                    s.push_str(&inner);
                    s.push('\'');
                }
                Some('"') => {
                    let inner = self.read_double_quoted_inner();
                    s.push('"');
                    s.push_str(&inner);
                    s.push('"');
                }
                Some('`') => {
                    let inner = self.read_backtick_inner();
                    s.push('`');
                    s.push_str(&inner);
                    s.push('`');
                }
                Some('$') => {
                    let piece = self.read_dollar_piece();
                    s.push_str(&piece.to_string_raw());
                }
                Some(c) if ";&|<>(){}".contains(c) => break,
                Some(c) => {
                    s.push(c);
                    self.pos += 1;
                }
            }
        }
        let _ = start;
        s
    }

    // -----------------------------------------------------------------------
    // Single-quoted  '...'  – returns inner text
    // -----------------------------------------------------------------------

    fn read_single_quoted_inner(&mut self) -> String {
        self.pos += 1; // consume opening '
        let mut s = String::new();
        loop {
            match self.peek() {
                None => break,
                Some('\'') => { self.pos += 1; break; }
                Some(c) => { s.push(c); self.pos += 1; }
            }
        }
        s
    }

    // -----------------------------------------------------------------------
    // Double-quoted  "..."  – returns inner text (escapes kept verbatim)
    // -----------------------------------------------------------------------

    fn read_double_quoted_inner(&mut self) -> String {
        self.pos += 1; // consume opening "
        self.dquote_nest_depth += 1;
        let mut s = String::new();
        loop {
            match self.peek() {
                None => break,
                Some('"') => { self.pos += 1; self.dquote_nest_depth -= 1; break; }
                Some('\\') => {
                    // Keep backslash sequences verbatim; expander handles them.
                    self.pos += 1;
                    match self.peek() {
                        None => { s.push('\\'); }
                        Some('\n') => {
                            // continuation inside double-quotes: strip both
                            self.pos += 1;
                        }
                        Some(c) => {
                            s.push('\\');
                            s.push(c);
                            self.pos += 1;
                        }
                    }
                }
                Some('`') => {
                    let inner = self.read_backtick_inner_ctx(true);
                    s.push('`');
                    s.push_str(&inner);
                    s.push('`');
                }
                Some('$') => {
                    // Inside a double-quoted string, $" does NOT start a locale
                    // string — the " would close the outer double-quote.  Push $
                    // literally and let the outer loop process the ".
                    if self.peek_at(1) == Some('"') {
                        s.push('$');
                        self.pos += 1;
                    } else {
                        let piece = self.read_dollar_piece();
                        s.push_str(&piece.to_string_raw());
                    }
                }
                Some(c) => { s.push(c); self.pos += 1; }
            }
        }
        s
    }

    // -----------------------------------------------------------------------
    // Backtick `...`
    // -----------------------------------------------------------------------

    fn read_backtick_inner(&mut self) -> String {
        self.read_backtick_inner_ctx(false)
    }

    /// Read `...\`` content.  When `in_dquote` is true (the backtick is
    /// embedded inside `"..."`), the backslash-escape rules are
    /// extended: `\"` becomes literal `"` and `\$`, `\\`, `` \` ``,
    /// `\newline` are processed.  Otherwise the lexer keeps all
    /// backslash sequences verbatim and the shell's child process does
    /// the stripping.
    fn read_backtick_inner_ctx(&mut self, in_dquote: bool) -> String {
        self.pos += 1; // consume opening `
        let mut s = String::new();
        loop {
            match self.peek() {
                None => break,
                Some('`') => { self.pos += 1; break; }
                Some('\\') => {
                    // The expander's `collect_backtick` does a single
                    // halving pass for `\$`, `` \` ``, `\\` — preserve
                    // those sequences verbatim here so we don't double-
                    // halve.
                    //
                    // In dquote context bash also halves `\"` and
                    // `\<newline>` at this level (the dquote escape
                    // rules): we strip `\` from `\"` (otherwise the
                    // subshell would see the literal `\` and not see
                    // the `"` as closing an inner dquote), and drop
                    // `\<newline>` as a line continuation.  Outside
                    // dquote none of that applies and we keep `\x`
                    // for the expander.
                    self.pos += 1;
                    match self.peek() {
                        None => { s.push('\\'); }
                        Some(c) => {
                            if in_dquote && c == '\n' {
                                // Line continuation inside "...`...`...":
                                // the dquote context drops `\<newline>`.
                                self.pos += 1;
                            } else if in_dquote && c == '"' {
                                // In dquote context, `\"` halves to `"`.
                                s.push('"');
                                self.pos += 1;
                            } else {
                                s.push('\\');
                                s.push(c);
                                self.pos += 1;
                            }
                        }
                    }
                }
                Some(c) => { s.push(c); self.pos += 1; }
            }
        }
        s
    }

    // -----------------------------------------------------------------------
    // Dollar expansions
    // -----------------------------------------------------------------------

    fn read_dollar_piece(&mut self) -> WordPiece {
        self.pos += 1; // consume '$'
        match self.peek() {
            Some('(') => {
                self.pos += 1;
                if self.peek() == Some('(') {
                    let double_open = self.pos; // pos of second `(`
                    self.pos += 1;
                    let (expr, closed_doubled) = self.read_until_double_close_paren();
                    if closed_doubled {
                        WordPiece::ArithSub(expr)
                    } else {
                        // Re-parse as `$( (…) )` command substitution.
                        // Rewind to the second `(` and let
                        // `read_nested_parens_content` consume from there.
                        // A space is inserted after `$(` so that
                        // downstream expanders don't re-interpret the
                        // literal as arithmetic again.
                        self.pos = double_open;
                        // Command substitution body is parsed in a
                        // FRESH quote context — the enclosing `"..."`
                        // does not propagate into `$(...)` at the
                        // syntax level.  Save and reset
                        // `dquote_nest_depth` so brace parsing inside
                        // the body applies the correct rules.
                        let saved_dq = self.dquote_nest_depth;
                        self.dquote_nest_depth = 0;
                        let inner = self.read_nested_parens_content();
                        self.dquote_nest_depth = saved_dq;
                        WordPiece::CommandSub(format!("$( {})", inner))
                    }
                } else {
                    let saved_dq = self.dquote_nest_depth;
                    self.dquote_nest_depth = 0;
                    let inner = self.read_nested_parens_content();
                    self.dquote_nest_depth = saved_dq;
                    WordPiece::CommandSub(format!("$({})", inner))
                }
            }
            Some('{') => {
                self.pos += 1;
                // Bash 5.2+ treats `${ ` (dollar-brace followed by whitespace) as a
                // no-fork command substitution (valfork) that runs in the current
                // shell. Keep the original `${ ... }` spelling so the expansion
                // layer can distinguish it from ordinary `$(...)`.
                if matches!(self.peek(), Some(' ') | Some('\t') | Some('\n')) {
                    let dbs_pos = self.pos;
                    let inner = self.read_brace_cmd_sub_inner();
                    // Bash requires a `;` or newline before the closing `}`.
                    // Valid terminators: `;`, `\n`, `}` (nested function body),
                    // or `)` when the body is a pure subshell — i.e. the trimmed
                    // body starts with `(` like `${ (shift) }`.
                    // A trailing `)` from a command substitution (e.g. `${ $() }`)
                    // is NOT valid; bash treats it as malformed and emits the
                    // "unexpected EOF while looking for matching `}'" error.
                    let trimmed = inner.trim_end_matches(|c: char| c == ' ' || c == '\t');
                    let ends_with_subshell_paren = trimmed.ends_with(')')
                        && trimmed.trim_start().starts_with('(');
                    if !trimmed.is_empty()
                        && !trimmed.ends_with(';')
                        && !trimmed.ends_with('\n')
                        && !trimmed.ends_with('}')
                        && !ends_with_subshell_paren
                    {
                        if self.dollar_brace_space_line.is_none() {
                            self.dollar_brace_space_line =
                                Some(self.line_number_at(dbs_pos));
                        }
                    }
                    return WordPiece::BraceGroup(format!("${{{}}}", inner));
                }
                let inner = self.read_brace_expansion_inner();
                WordPiece::BraceGroup(format!("${{{}}}", inner))
            }
            Some('\'') => {
                let inner = self.read_ansi_c_quoted_inner();
                WordPiece::DollarSingleQuoted(inner)
            }
            Some('"') => {
                // $"..." locale string – treat like double-quoted
                // (locale translation is a no-op for now)
                let inner = self.read_double_quoted_inner();
                WordPiece::DoubleQuoted(format!("\"{}\"", inner))
            }
            Some('[') => {
                // $[expr] is the deprecated arithmetic expansion form
                // (same as $((expr))).  Collect up to the matching `]`.
                self.pos += 1;
                let expr = self.read_bracket_arith_inner();
                WordPiece::ArithSub(expr)
            }
            Some(c) if is_special_param(c) || c.is_alphabetic() || c == '_' => {
                let name = self.read_param_name();
                WordPiece::Bare(format!("${}", name))
            }
            Some(c) if c.is_ascii_digit() => {
                let c2 = c;
                self.pos += 1;
                WordPiece::Bare(format!("${}", c2))
            }
            _ => WordPiece::Bare("$".to_string()),
        }
    }

    /// Read inside `$[...]` keeping track of nested `[` and `]`.
    fn read_bracket_arith_inner(&mut self) -> String {
        let mut depth = 1usize;
        let mut s = String::new();
        loop {
            match self.peek() {
                None => break,
                Some('[') => { depth += 1; s.push('['); self.pos += 1; }
                Some(']') => {
                    depth -= 1;
                    if depth == 0 { self.pos += 1; break; }
                    s.push(']'); self.pos += 1;
                }
                Some('\\') => {
                    s.push('\\'); self.pos += 1;
                    if let Some(c) = self.peek() { s.push(c); self.pos += 1; }
                }
                Some(c) => { s.push(c); self.pos += 1; }
            }
        }
        s
    }

    fn read_param_name(&mut self) -> String {
        // Check for single special chars first
        if let Some(c) = self.peek() {
            if is_special_param(c) {
                self.pos += 1;
                return c.to_string();
            }
        }
        let mut name = String::new();
        while matches!(self.peek(), Some(c) if c.is_alphanumeric() || c == '_') {
            name.push(self.peek().unwrap());
            self.pos += 1;
        }
        name
    }

    /// Read inside `${...}` keeping track of nested `{` and `}`.
    fn read_brace_expansion_inner(&mut self) -> String {
        let open_pos = self.pos; // position right after the `{`
        let mut depth = 1usize;
        let mut s = String::new();
        loop {
            match self.peek() {
                None => break,
                Some('{') => {
                    // Bare `{` inside a `${…}` body is literal text, not a
                    // depth increment — only `${…}` opens a new nested
                    // parameter expansion (handled by the `$` arm below).
                    s.push('{');
                    self.pos += 1;
                }
                Some('}') => {
                    depth -= 1;
                    if depth == 0 { self.pos += 1; break; }
                    s.push('}'); self.pos += 1;
                }
                Some('\\') => {
                    s.push('\\'); self.pos += 1;
                    if let Some(c) = self.peek() { s.push(c); self.pos += 1; }
                }
                Some('\'') => {
                    // Posix rule: when the `${…}` sits inside a
                    // `"..."` AND posix mode is active, `'` is
                    // literal (not a quote opener) and the first
                    // unescaped `}` terminates.  We detect this via
                    // the lexer's `dquote_nest_depth` state plus the
                    // thread-local POSIX_MODE cell (updated from
                    // `run_string_inner` before tokenization).
                    let posix_dquote_rule = self.dquote_nest_depth > 0
                        && crate::exec::POSIX_MODE.with(|p| p.get());
                    if posix_dquote_rule {
                        s.push('\'');
                        self.pos += 1;
                        continue;
                    }
                    // Non-posix: if the single quote would consume
                    // past the matching `}` (no closing `'` before
                    // brace end), treat it as literal.  Non-posix
                    // bash errors here; we pick the forgiving
                    // interpretation (posix-like leniency on a
                    // per-`'` basis) for test-suite compatibility
                    // with the mksh-style inputs that rely on it.
                    if !self.sq_closes_before_brace_end(depth) {
                        s.push('\'');
                        self.pos += 1;
                        continue;
                    }
                    let inner = self.read_single_quoted_inner();
                    s.push('\''); s.push_str(&inner); s.push('\'');
                }
                Some('"') => {
                    let inner = self.read_double_quoted_inner();
                    s.push('"'); s.push_str(&inner); s.push('"');
                }
                Some('`') => {
                    // Backtick command substitution inside `${…}`:
                    // the `}` inside the backtick body is literal and
                    // must not close our brace.  `read_backtick_inner`
                    // already does this in its own state machine.
                    let inner = self.read_backtick_inner();
                    s.push('`');
                    s.push_str(&inner);
                    s.push('`');
                }
                Some('$') => {
                    s.push('$');
                    self.pos += 1;
                    match self.peek() {
                        Some('{') => {
                            // Nested `${…}` — track its brace depth so its
                            // closing `}` doesn't prematurely close us.
                            s.push('{');
                            self.pos += 1;
                            depth += 1;
                        }
                        Some('(') => {
                            // Nested `$(…)` command substitution or
                            // `$((…))` arithmetic.  Consume the whole
                            // thing so any `{`/`}` inside doesn't affect
                            // our outer brace depth.
                            s.push('(');
                            self.pos += 1;
                            if self.peek() == Some('(') {
                                s.push('(');
                                self.pos += 1;
                                // Read up to matching `))`.
                                let (inner, _closed) = self.read_until_double_close_paren();
                                s.push_str(&inner);
                                s.push_str("))");
                            } else {
                                let inner = self.read_nested_parens_content();
                                s.push_str(&inner);
                                s.push(')');
                            }
                        }
                        Some('\'') => {
                            // $'...' ANSI-C quoted string: collect verbatim so
                            // that \' inside is not mistaken for end of string.
                            s.push('\'');
                            self.pos += 1;
                            loop {
                                match self.peek() {
                                    None | Some('\'') => {
                                        if self.peek().is_some() {
                                            s.push('\'');
                                            self.pos += 1;
                                        }
                                        break;
                                    }
                                    Some('\\') => {
                                        s.push('\\');
                                        self.pos += 1;
                                        if let Some(c) = self.peek() {
                                            s.push(c);
                                            self.pos += 1;
                                        }
                                    }
                                    Some(c) => { s.push(c); self.pos += 1; }
                                }
                            }
                        }
                        _ => {
                            // $var, bare $, etc. — caller handles.
                        }
                    }
                }
                Some(c) => { s.push(c); self.pos += 1; }
            }
        }
        // If we exited the loop with depth still > 0, EOF was reached without
        // finding the closing `}`.  Record the line number of the opening `${`
        // so exec.rs can emit "unexpected EOF while looking for matching `}'" —
        // but only if we haven't already recorded one (the first unclosed brace
        // is the one bash reports).
        if depth > 0 && self.unclosed_brace_line.is_none() {
            // open_pos is just after the `{`; the `$` was one char before.
            let dollar_pos = open_pos.saturating_sub(2); // pos of `$`
            self.unclosed_brace_line = Some(self.line_number_at(dollar_pos));
        }
        s
    }

    /// Look ahead (without consuming) to decide whether a `'` at
    /// `self.pos` inside a `${…}` body has a matching closing quote
    /// "close enough" to be plausibly intended as a quoted region.
    /// We stop the scan at a literal newline (a clear
    /// command-separator) so that a stray unterminated `'` in one
    /// `${…}` doesn't accidentally pair up with a `'` in a later
    /// statement.
    ///
    /// Returns true when a closing `'` appears before the next `\n`;
    /// false when the quote is unterminated within the current line.
    /// `${IFS+'bar}` (no closing quote before `\n`) → false → `'`
    /// treated as literal (posix-mode behaviour).
    /// `${IFS+'}'z}` (closing `'` on the same line, past the inner
    /// `}`) → true → full quote honoured, inner `}` quoted.
    fn sq_closes_before_brace_end(&self, _depth: usize) -> bool {
        // Scan forward from the character AFTER the opening `'`.  Return true
        // if we find a closing `'` before EOF.  We no longer stop at `\n`
        // because bash allows single-quoted regions inside `${…}` to span
        // multiple input lines (e.g. `"${x##'}"` on one line followed by
        // `recho "${x:-'}'}"` on the next — the first `'` opens a SQ region
        // that closes at the `'` on the second line, making both lines part of
        // one logical command).
        let mut i = self.pos + 1;
        while i < self.chars.len() {
            let c = self.chars[i];
            if c == '\'' {
                return true;
            }
            if c == '\\' && i + 1 < self.chars.len() {
                i += 2;
                continue;
            }
            i += 1;
        }
        false
    }

    /// Read the body of a `${ ... }` command substitution (bash 5.2+ valfork).
    /// Called after consuming `${` and verifying the next char is whitespace.
    /// Reads shell command text until the matching `}` at depth 0.
    /// Handles nested `{`/`}` and quoted strings to correctly find the closing `}`.
    /// Returns the inner content (without the surrounding `{` and `}`).
    fn read_brace_cmd_sub_inner(&mut self) -> String {
        let mut depth = 1usize;
        let mut s = String::new();
        loop {
            match self.peek() {
                None => break,
                Some('{') => { depth += 1; s.push('{'); self.pos += 1; }
                Some('}') => {
                    depth -= 1;
                    if depth == 0 { self.pos += 1; break; }
                    s.push('}'); self.pos += 1;
                }
                Some('\\') => {
                    s.push('\\'); self.pos += 1;
                    if let Some(c) = self.peek() { s.push(c); self.pos += 1; }
                }
                Some('\'') => {
                    let inner = self.read_single_quoted_inner();
                    s.push('\''); s.push_str(&inner); s.push('\'');
                }
                Some('"') => {
                    let inner = self.read_double_quoted_inner();
                    s.push('"'); s.push_str(&inner); s.push('"');
                }
                Some(c) => { s.push(c); self.pos += 1; }
            }
        }
        s
    }

    /// Read array literal content after `=(` — reads space-separated words
    /// until `)`.  Returns them space-separated.
    fn read_array_literal(&mut self) -> String {
        let mut elements: Vec<String> = Vec::new();
        loop {
            // Skip whitespace and newlines
            while matches!(self.peek(), Some(' ') | Some('\t') | Some('\n')) {
                self.pos += 1;
            }
            match self.peek() {
                None => break,
                Some(')') => { self.pos += 1; break; }
                Some('#') => {
                    // Comment
                    while matches!(self.peek(), Some(c) if c != '\n') {
                        self.pos += 1;
                    }
                }
                Some('&') | Some('|') | Some(';') | Some('<') | Some('>') => {
                    // Shell control operators are invalid inside an array
                    // literal.  Mark the token so the parser can emit a
                    // syntax error that matches bash.
                    // Note: `!` is NOT listed here — it's a valid extglob
                    // prefix (e.g. `arr=(!(...))`) or literal character,
                    // not a control operator.
                    let tok = match self.peek().unwrap() {
                        '<' => {
                            if self.chars.get(self.pos + 1) == Some(&'>') {
                                "<>".to_string()
                            } else {
                                "<".to_string()
                            }
                        }
                        '>' => ">".to_string(),
                        c => c.to_string(),
                    };
                    // Record the line for error reporting.
                    if self.array_literal_bad_token.is_none() {
                        self.array_literal_bad_token = Some((
                            tok,
                            self.line_number_at(self.pos),
                        ));
                    }
                    // Consume until closing `)` to keep the lexer stream
                    // in a recoverable state (the parser will reject).
                    let mut depth = 1;
                    while depth > 0 {
                        match self.peek() {
                            None => break,
                            Some('(') => { depth += 1; self.pos += 1; }
                            Some(')') => { depth -= 1; self.pos += 1; }
                            Some(_) => { self.pos += 1; }
                        }
                    }
                    break;
                }
                _ => {
                    // Read a word (can be quoted, have expansions, etc.)
                    // Bash array literal elements treat `[...]` as a bracket
                    // subscript — spaces inside are part of the key, not
                    // element delimiters (e.g. `[foo bar]=val`).
                    let mut word = String::new();
                    let word_start = self.pos;
                    // Track `[...]` subscript depth so spaces inside a key
                    // don't split the element.
                    let mut bracket_depth: i32 = 0;
                    // Track extglob `!(...)` / `@(...)` etc. nesting so their
                    // closing `)` isn't mistaken for the array's closing `)`.
                    let mut extglob_depth: i32 = 0;
                    loop {
                        match self.peek() {
                            None => break,
                            Some(')') if extglob_depth > 0 => {
                                extglob_depth -= 1;
                                word.push(')');
                                self.pos += 1;
                            }
                            Some(')') => break,
                            Some(' ') | Some('\t') | Some('\n') if bracket_depth == 0 => break,
                            Some('\'') => {
                                let inner = self.read_single_quoted_inner();
                                word.push('\'');
                                word.push_str(&inner);
                                word.push('\'');
                            }
                            Some('"') => {
                                let inner = self.read_double_quoted_inner();
                                word.push('"');
                                word.push_str(&inner);
                                word.push('"');
                            }
                            Some('\\') => {
                                word.push('\\');
                                self.pos += 1;
                                if let Some(c) = self.peek() {
                                    word.push(c);
                                    self.pos += 1;
                                }
                            }
                            Some('$') => {
                                let piece = self.read_dollar_piece();
                                word.push_str(&piece_to_string(piece));
                            }
                            Some('[') if word.is_empty() => {
                                // Leading `[` begins a subscript.  Only
                                // the first unquoted `[` at the start of
                                // the word opens a tracked bracket range;
                                // nested `[` inside the subscript are
                                // still counted so `[a[b]c]=v` works.
                                bracket_depth += 1;
                                word.push('[');
                                self.pos += 1;
                            }
                            Some('[') if bracket_depth > 0 => {
                                bracket_depth += 1;
                                word.push('[');
                                self.pos += 1;
                            }
                            Some(']') if bracket_depth > 0 => {
                                bracket_depth -= 1;
                                word.push(']');
                                self.pos += 1;
                            }
                            Some(c) if is_extglob_prefix(c) && self.chars.get(self.pos + 1) == Some(&'(') => {
                                // Extglob prefix: ?(  *(  +(  @(  !(
                                extglob_depth += 1;
                                word.push(c);
                                self.pos += 1;
                                word.push('(');
                                self.pos += 1;
                            }
                            Some('(') if extglob_depth > 0 => {
                                // Nested `(` inside extglob (e.g. for
                                // alternation `!(a|b(c))`)
                                extglob_depth += 1;
                                word.push('(');
                                self.pos += 1;
                            }
                            Some(c) => {
                                word.push(c);
                                self.pos += 1;
                            }
                        }
                    }
                    if !word.is_empty() {
                        if let Some(tok) = Self::invalid_compound_array_value_token(&word) {
                            if self.array_literal_bad_token.is_none() {
                                self.array_literal_bad_token = Some((tok, self.line_number_at(word_start)));
                            }
                            let mut depth = 1;
                            while depth > 0 {
                                match self.peek() {
                                    None => break,
                                    Some('(') => { depth += 1; self.pos += 1; }
                                    Some(')') => { depth -= 1; self.pos += 1; }
                                    Some(_) => { self.pos += 1; }
                                }
                            }
                            break;
                        }
                        elements.push(word);
                    }
                }
            }
        }
        // Use \x1F (ASCII unit separator) as element delimiter to avoid
        // confusing elements that contain spaces (e.g. $' ' ANSI-C quoting).
        elements.join("\x1F")
    }

    fn invalid_compound_array_value_token(word: &str) -> Option<String> {
        let bytes = word.as_bytes();
        if !bytes.starts_with(b"[") {
            return None;
        }
        let mut depth = 1i32;
        let mut in_sq = false;
        let mut in_dq = false;
        let mut i = 1usize;
        while i < bytes.len() {
            let b = bytes[i];
            if in_sq {
                if b == b'\'' {
                    in_sq = false;
                }
                i += 1;
                continue;
            }
            if in_dq {
                if b == b'\\' && i + 1 < bytes.len() {
                    i += 2;
                    continue;
                }
                if b == b'"' {
                    in_dq = false;
                }
                i += 1;
                continue;
            }
            match b {
                b'\\' => {
                    i += if i + 1 < bytes.len() { 2 } else { 1 };
                    continue;
                }
                b'\'' => {
                    in_sq = true;
                    i += 1;
                    continue;
                }
                b'"' => {
                    in_dq = true;
                    i += 1;
                    continue;
                }
                b'[' => depth += 1,
                b']' => {
                    depth -= 1;
                    if depth == 0 {
                        let val_start = if i + 2 < bytes.len() && bytes[i + 1] == b'+' && bytes[i + 2] == b'=' {
                            i + 3
                        } else if i + 1 < bytes.len() && bytes[i + 1] == b'=' {
                            i + 2
                        } else {
                            return None;
                        };
                        let val = &word[val_start..];
                        if val.starts_with("<>") {
                            return Some("<>".to_string());
                        }
                        if let Some(ch) = val.chars().next() {
                            if matches!(ch, '<' | '>' | '!' | '&' | '|' | ';') {
                                return Some(ch.to_string());
                            }
                        }
                        return None;
                    }
                }
                _ => {}
            }
            i += 1;
        }
        None
    }

    /// Read `$(...)` inner content – already consumed `$(`.  Caller gets back
    /// the content *without* the surrounding `$(` and `)`.
    fn read_nested_parens_content(&mut self) -> String {
        let start_pos = self.pos;
        // Line of the `$(` — used as trigger_line for heredoc warnings
        // generated inside this command substitution.  `start_pos` is right
        // after `$(`, so back up by 2 to get the `$` position.
        let comsub_line = self.line_number_at(start_pos.saturating_sub(2));
        let mut depth = 1usize;
        let mut s = String::new();
        #[derive(Clone)]
        struct PendingCmdSubHeredoc {
            delim: String,
            strip_tabs: bool,
            pos: usize,
        }
        struct DeferredCmdSubClose {
            line: usize,
            suffix: String,
            count: usize,
            had_newline_after_close: bool,
        }
        let mut pending_heredocs: Vec<PendingCmdSubHeredoc> = Vec::new();
        let mut deferred_close: Option<DeferredCmdSubClose> = None;
        let mut deferred_eof_warnings: Vec<HeredocWarning> = Vec::new();
        // Case-construct tracking: each `case WORD in` pushes a state onto
        // this stack. Inside a case body, `)` is a pattern terminator (not
        // a comsub terminator), so we shouldn't decrement our paren depth.
        // Stack entries track the current CaseScan state for nested cases.
        #[derive(Copy, Clone, PartialEq, Debug)]
        enum CaseScan {
            WaitIn,   // saw `case WORD`, waiting for `in`
            Pattern,  // after `in` or after `;;` — next `)` is pattern end
            Body,     // after pattern `)` — inside case arm body
        }
        let mut case_stack: Vec<CaseScan> = Vec::new();
        let mut at_word_start = true;
        'scan: loop {
            // If we have a pending heredoc and just hit a newline, consume the body.
            if self.pos > 0 && self.chars[self.pos - 1] == '\n' && !pending_heredocs.is_empty() {
                let pending = std::mem::take(&mut pending_heredocs);
                let pending_len = pending.len();
                let mut hit_eof = false;

                for (idx, pending_doc) in pending.into_iter().enumerate() {
                    let delim = pending_doc.delim;
                    let strip_tabs = pending_doc.strip_tabs;
                    let heredoc_pos = pending_doc.pos;
                    let is_last = idx + 1 == pending_len;
                    let mut found_delim = false;

                    // We're right after the newline that follows the << line.
                    // Read heredoc body lines, adding them to s, without tracking paren depth.
                    loop {
                        let line_start = self.pos;
                        let mut line = String::new();
                        loop {
                            match self.peek() {
                                None => break,
                                Some('\n') => { line.push('\n'); self.pos += 1; break; }
                                Some(c) => { line.push(c); self.pos += 1; }
                            }
                        }
                        let check = if strip_tabs {
                            line.trim_start_matches('\t').to_string()
                        } else {
                            line.clone()
                        };
                        let trimmed = check.trim_end_matches('\n');
                        if trimmed == delim {
                            // Exact delimiter match - heredoc body ends normally.
                            if deferred_close.is_some() && is_last {
                                s.push_str(trimmed);
                                if line.ends_with('\n') && self.pos > 0 {
                                    self.pos -= 1;
                                }
                            } else {
                                s.push_str(&line);
                            }
                            found_delim = true;
                            break;
                        }
                        // Bash compat: if we're inside $(…) and the line starts with
                        // the delimiter text followed by ')' (the command sub closer),
                        // terminate the heredoc and push back the rest of the line so
                        // the ')' can close the command substitution.
                        if trimmed.starts_with(&delim) {
                            let after_delim = &trimmed[delim.len()..];
                            let after_trimmed = after_delim.trim_start();
                            if after_trimmed.starts_with(')') {
                                // Rewind: don't consume this line; position back to
                                // where the ')' is so the outer loop sees it.
                                self.pos = line_start + delim.len();
                                // Skip whitespace before ')'
                                while self.pos < self.chars.len() && matches!(self.chars[self.pos], ' ' | '\t') {
                                    self.pos += 1;
                                }
                                // Emit a warning: heredoc terminated by end-of-file
                                let eof_line = self.line_number_at(self.pos);
                                let hd_line = self.line_number_at(heredoc_pos);
                                self.heredoc_warnings.push(HeredocWarning {
                                    heredoc_start_line: hd_line,
                                    eof_line,
                                    wanted: delim.clone(),
                                    comsub: false,
                                    trigger_line: comsub_line,
                                    kind: HeredocWarningKind::DelimitedByEof,
                                });
                                // Preserve just the delimiter text here. The
                                // expansion-time command-substitution scanner has
                                // its own `EOF)` handling, and synthesizing an
                                // extra newline here skews later parser line
                                // accounting away from the source file.
                                s.push_str(&delim);
                                break;
                            }
                        }
                        s.push_str(&line);
                        if self.pos >= self.chars.len() {
                            // EOF while reading heredoc body inside $(...)
                            let eof_line = if self.pos > 0 {
                                self.line_number_at(self.pos - 1)
                            } else {
                                self.line_number_at(self.pos)
                            };
                            let hd_line = self.line_number_at(heredoc_pos);
                            let warning = HeredocWarning {
                                heredoc_start_line: hd_line,
                                eof_line,
                                wanted: delim.clone(),
                                comsub: false,
                                trigger_line: comsub_line,
                                kind: HeredocWarningKind::DelimitedByEof,
                            };
                            if deferred_close.is_some() {
                                deferred_eof_warnings.push(warning);
                            } else {
                                self.heredoc_warnings.push(warning);
                            }
                            hit_eof = true;
                            break;
                        }
                    }

                    if !found_delim && hit_eof {
                        break;
                    }
                }

                if let Some(close) = deferred_close.take() {
                    self.heredoc_warnings.push(HeredocWarning {
                        heredoc_start_line: comsub_line,
                        eof_line: close.line,
                        wanted: String::new(),
                        comsub: true,
                        trigger_line: comsub_line,
                        kind: HeredocWarningKind::CmdSubUnterminated { count: close.count },
                    });
                    self.heredoc_warnings.append(&mut deferred_eof_warnings);
                    self.insert_outer_suffix_text(&close.suffix);
                    depth = 0;
                    break 'scan;
                }
                if hit_eof {
                    break; // EOF
                }
                continue;
            }

            // At a potential word boundary, peek ahead for reserved words
            // that affect case-construct tracking (case/in/esac/;;), and
            // for `#` which starts a line-comment (bracket chars inside
            // the comment must not affect our paren depth).
            if at_word_start {
                if self.peek() == Some('#') {
                    // Consume `#...\n` as a comment; do NOT track parens.
                    while let Some(c) = self.peek() {
                        s.push(c); self.pos += 1;
                        if c == '\n' { break; }
                    }
                    at_word_start = true;
                    continue;
                }
                // When alias expansion is active, selectively expand aliases whose
                // value would affect comsub boundary detection:
                //   - contains `(` or `)` (paren depth tracking)
                //   - begins with a case-related keyword (case/esac/in)
                // We intentionally do NOT expand aliases whose values are purely
                // commands/arguments (like `let='let --'`) because expanding those
                // would change the semantics of the child execution unnecessarily.
                if self.alias_affects_comsub_depth_at_pos() {
                    // Attempt alias expansion at word start.  If successful,
                    // self.chars is spliced in place and self.pos still points
                    // to the start of the expansion — the outer loop re-processes
                    // the expanded chars normally (depth tracking, case detection).
                    self.try_alias_expand();
                    // Stay at_word_start=true: don't flip to false here.
                    // The outer loop will process the newly spliced chars.
                    // (No `continue` — fall through to the regular word detection.)
                }
                // Check for "case " or "case\t" or "case\n"
                if self.starts_with_word("case") {
                    case_stack.push(CaseScan::WaitIn);
                } else if self.starts_with_word("esac") {
                    // Bash case-pattern rule: inside a Pattern alternative,
                    // `esac` is only the closer when the previous non-
                    // whitespace character is NOT `(` or `|`, and the
                    // next non-whitespace character is not `|`.  For
                    // `foo|esac)` and `esac|foo)`, the `esac` is part of
                    // a pattern alternative, not the case closer.
                    let esac_is_closer = match case_stack.last() {
                        Some(CaseScan::Pattern) => {
                            let prev = s.trim_end_matches(|c: char| c == ' ' || c == '\t' || c == '\n')
                                .chars().last();
                            let next = self.chars[self.pos + 4..]
                                .iter()
                                .copied()
                                .find(|c| !matches!(c, ' ' | '\t' | '\n'));
                            !matches!(prev, Some('(') | Some('|'))
                                && !matches!(next, Some('|'))
                        }
                        _ => true,
                    };
                    if esac_is_closer {
                        case_stack.pop();
                    }
                } else if !case_stack.is_empty() {
                    if self.starts_with_word("in") && matches!(case_stack.last(), Some(CaseScan::WaitIn)) {
                        *case_stack.last_mut().unwrap() = CaseScan::Pattern;
                        // Consume "in" so we advance past it
                        s.push_str("in");
                        self.pos += 2;
                        at_word_start = false;
                        continue;
                    }
                }
                at_word_start = false;
            }

            match self.peek() {
                None => break,
                Some('(') => {
                    depth += 1;
                    // An explicit `(` in pattern position opens a paren-group
                    // pattern `(p1|p2)`; keep it in Pattern state.
                    s.push('('); self.pos += 1;
                }
                Some(')') => {
                    if !pending_heredocs.is_empty() && depth == 1 {
                        let line = self.line_number_at(self.pos);
                        let count = pending_heredocs.len();
                        self.pos += 1;
                        let suffix_start = self.pos;
                        while self.pos < self.chars.len() && self.chars[self.pos] != '\n' {
                            self.pos += 1;
                        }
                        let suffix: String = self.chars[suffix_start..self.pos].iter().collect();
                        let had_newline_after_close = self.peek() == Some('\n');
                        if had_newline_after_close {
                            s.push('\n');
                            self.pos += 1;
                        }
                        deferred_close = Some(DeferredCmdSubClose {
                            line,
                            suffix,
                            count,
                            had_newline_after_close,
                        });
                        continue;
                    }
                    // If the innermost case is in Pattern state, this `)`
                    // is a case-pattern terminator, not a comsub terminator.
                    if matches!(case_stack.last(), Some(CaseScan::Pattern)) {
                        // Only consume as pattern-end when depth==1 (no
                        // matching `(` inside pattern).  A balanced `(...)`
                        // inside a pattern group decrements depth normally.
                        if depth == 1 {
                            *case_stack.last_mut().unwrap() = CaseScan::Body;
                            s.push(')'); self.pos += 1;
                            continue;
                        }
                    }
                    depth -= 1;
                    if depth == 0 { self.pos += 1; break; }
                    s.push(')'); self.pos += 1;
                }
                Some(';') if self.peek_at(1) == Some(';')
                    && matches!(case_stack.last(), Some(CaseScan::Body)) =>
                {
                    // `;;` inside case body — consume and transition back to Pattern
                    s.push(';'); s.push(';'); self.pos += 2;
                    // Handle `;;&` (fall-through continue) — stays in Body→Pattern transition
                    if self.peek() == Some('&') {
                        s.push('&'); self.pos += 1;
                    }
                    *case_stack.last_mut().unwrap() = CaseScan::Pattern;
                    // Treat next non-whitespace as a new word start
                    while matches!(self.peek(), Some(' ') | Some('\t') | Some('\n')) {
                        s.push(self.peek().unwrap()); self.pos += 1;
                    }
                    at_word_start = true;
                    continue;
                }
                Some(';') if self.peek_at(1) == Some('&')
                    && matches!(case_stack.last(), Some(CaseScan::Body)) =>
                {
                    // `;&` fall-through terminator — stays in Body, no reset needed,
                    // but the next pattern follows after whitespace.
                    s.push(';'); s.push('&'); self.pos += 2;
                    *case_stack.last_mut().unwrap() = CaseScan::Pattern;
                    while matches!(self.peek(), Some(' ') | Some('\t') | Some('\n')) {
                        s.push(self.peek().unwrap()); self.pos += 1;
                    }
                    at_word_start = true;
                    continue;
                }
                Some('\\') => {
                    s.push('\\'); self.pos += 1;
                    if let Some(c) = self.peek() { s.push(c); self.pos += 1; }
                }
                Some('\'') => {
                    let inner = self.read_single_quoted_inner();
                    s.push('\''); s.push_str(&inner); s.push('\'');
                }
                Some('"') => {
                    let inner = self.read_double_quoted_inner();
                    s.push('"'); s.push_str(&inner); s.push('"');
                }
                Some('`') => {
                    let inner = self.read_backtick_inner();
                    s.push('`'); s.push_str(&inner); s.push('`');
                }
                Some('$') => {
                    let p = self.read_dollar_piece();
                    s.push_str(&p.to_string_raw());
                }
                Some('<') if self.peek_at(1) == Some('<') && self.peek_at(2) == Some('<') => {
                    // Here-string operator <<<  — just pass through as literal text
                    s.push('<'); self.pos += 1;
                    s.push('<'); self.pos += 1;
                    s.push('<'); self.pos += 1;
                }
                Some('<') if self.peek_at(1) == Some('<') => {
                    // Possible heredoc operator <<  or <<-
                    let heredoc_pos = self.pos;
                    s.push('<'); self.pos += 1;
                    s.push('<'); self.pos += 1;
                    let strip_tabs = if self.peek() == Some('-') {
                        s.push('-'); self.pos += 1;
                        true
                    } else {
                        false
                    };
                    // Skip whitespace
                    while matches!(self.peek(), Some(' ') | Some('\t')) {
                        s.push(self.peek().unwrap()); self.pos += 1;
                    }
                    // Read the delimiter
                    let delim = self.read_heredoc_delim_inline(&mut s);
                    if !delim.is_empty() {
                        // Continue scanning the rest of this line normally.
                        // The heredoc body starts after the next newline.
                        // Store the pending heredoc info.
                        pending_heredocs.push(PendingCmdSubHeredoc {
                            delim,
                            strip_tabs,
                            pos: heredoc_pos,
                        });
                    }
                }
                Some('\n') => {
                    s.push('\n'); self.pos += 1;
                    at_word_start = true;
                    // If there's a pending heredoc, it will be consumed at the top of the loop.
                }
                Some(c) if c == ' ' || c == '\t' => {
                    s.push(c); self.pos += 1;
                    at_word_start = true;
                }
                Some(';') | Some('|') | Some('&') => {
                    // Generic separator — passes through; next significant
                    // char starts a new word.
                    s.push(self.peek().unwrap()); self.pos += 1;
                    at_word_start = true;
                }
                Some(c) => { s.push(c); self.pos += 1; }
            }
        }
        // If we reached EOF without finding the closing `)`, record an error.
        if let Some(close) = deferred_close.take() {
            self.heredoc_warnings.push(HeredocWarning {
                heredoc_start_line: comsub_line,
                eof_line: close.line,
                wanted: String::new(),
                comsub: true,
                trigger_line: comsub_line,
                kind: HeredocWarningKind::CmdSubUnterminated { count: close.count },
            });
            for pending_doc in pending_heredocs.drain(..) {
                let hd_line = self.line_number_at(pending_doc.pos);
                self.heredoc_warnings.push(HeredocWarning {
                    heredoc_start_line: hd_line,
                    eof_line: close.line,
                    wanted: pending_doc.delim,
                    comsub: false,
                    trigger_line: comsub_line,
                    kind: HeredocWarningKind::DelimitedByEof,
                });
            }
            self.heredoc_warnings.append(&mut deferred_eof_warnings);
            self.insert_outer_suffix_text(&close.suffix);
            if !close.had_newline_after_close {
                s.clear();
                s.push(':');
            }
            depth = 0;
        }
        if depth > 0 {
            let eof_line = self.line_number_at(self.pos);
            self.comsub_eof_errors.push(ComsubEofError {
                eof_line,
            });
        }
        s
    }

    /// Read a heredoc delimiter inline, appending the raw delimiter text to `s`.
    /// Returns the parsed delimiter string (without quoting).
    fn read_heredoc_delim_inline(&mut self, s: &mut String) -> String {
        let mut delim = String::new();
        match self.peek() {
            Some('\'') => {
                s.push('\''); self.pos += 1;
                while !matches!(self.peek(), None | Some('\'')) {
                    let c = self.peek().unwrap();
                    delim.push(c); s.push(c); self.pos += 1;
                }
                if self.peek() == Some('\'') { s.push('\''); self.pos += 1; }
            }
            Some('"') => {
                s.push('"'); self.pos += 1;
                while !matches!(self.peek(), None | Some('"')) {
                    let c = self.peek().unwrap();
                    if c == '\\' {
                        s.push(c); self.pos += 1;
                        if self.peek() == Some('\n') {
                            s.push('\n');
                            self.pos += 1;
                            continue;
                        }
                        if let Some(c2) = self.peek() { delim.push(c2); s.push(c2); self.pos += 1; }
                    } else {
                        delim.push(c); s.push(c); self.pos += 1;
                    }
                }
                if self.peek() == Some('"') { s.push('"'); self.pos += 1; }
            }
            Some('\\') => {
                s.push('\\'); self.pos += 1;
                // The stop condition is \n or whitespace or end, but we must
                // handle \<NL> as a line-continuation (skip both, keep reading).
                loop {
                    match self.peek() {
                        None | Some(' ') | Some('\t') => break,
                        Some('\n') => break,
                        Some('\\') => {
                            // Check for line continuation \<NL>
                            if self.chars.get(self.pos + 1).copied() == Some('\n') {
                                // Line continuation: push both to s (verbatim text), skip
                                s.push('\\'); self.pos += 1;
                                s.push('\n'); self.pos += 1;
                                // Continue reading delimiter chars on next line
                                continue;
                            }
                            // Regular backslash-escape inside delimiter word
                            s.push('\\'); self.pos += 1;
                            if let Some(c2) = self.peek() { delim.push(c2); s.push(c2); self.pos += 1; }
                        }
                        Some(c) => {
                            delim.push(c); s.push(c); self.pos += 1;
                        }
                    }
                }
            }
            _ => {
                while matches!(self.peek(), Some(c) if !c.is_whitespace()
                        && c != ';' && c != '&' && c != '|' && c != '<' && c != '>'
                        && c != ')' && c != '(') {
                    let c = self.peek().unwrap();
                    delim.push(c); s.push(c); self.pos += 1;
                }
            }
        }
        delim
    }

    /// Read `$((...))`  inner expression.  Caller has already consumed `$((`.
    /// Read arithmetic command body after `((`. Returns (expr, true) if `))` found,
    /// or (expr, false) if EOF/newline reached without finding `))`.
    /// Scan a command substitution `$(...)` body for use inside an arithmetic
    /// expression context.  Unlike `read_nested_parens_content`, this function
    /// tracks `case`/`esac` depth so that `)` in a case-pattern position is
    /// not mistaken for the closing `)` of the `$()`.
    ///
    /// Caller has already consumed `$(`.  Returns the content (without the
    /// surrounding `$(` and `)`), positioning `self.pos` after the closing `)`.
    // The macro flush_word! mutates case_depth on every invocation, but the
    // final flush_word! at the end of the loop fires after we've already
    // returned from any case/esac match — so its update is never observed.
    // The mid-function increments/decrements ARE read on line ~3265, so the
    // counter is genuinely live; only the trailing assignment is dead.
    #[allow(unused_assignments)]
    fn read_comsub_in_arith(&mut self) -> String {
        let mut depth = 1i32;   // paren depth (1 = inside the $())
        let mut case_depth = 0i32; // how many case..esac layers we're in
        let mut s = String::new();
        // Buffer to detect reserved words (case, esac, in).
        let mut word_buf = String::new();
        macro_rules! flush_word {
            () => {
                if !word_buf.is_empty() {
                    match word_buf.as_str() {
                        "case" => { case_depth += 1; }
                        "esac" => { if case_depth > 0 { case_depth -= 1; } }
                        _ => {}
                    }
                    s.push_str(&word_buf);
                    word_buf.clear();
                }
            };
        }
        loop {
            match self.peek() {
                None => break,
                Some('\'') => {
                    flush_word!();
                    s.push('\'');
                    self.pos += 1;
                    loop {
                        match self.peek() {
                            None | Some('\n') => break,
                            Some('\'') => { s.push('\''); self.pos += 1; break; }
                            Some('\\') => {
                                s.push('\\'); self.pos += 1;
                                if let Some(c) = self.peek() { s.push(c); self.pos += 1; }
                            }
                            Some(c) => { s.push(c); self.pos += 1; }
                        }
                    }
                }
                Some('"') => {
                    flush_word!();
                    s.push('"');
                    self.pos += 1;
                    loop {
                        match self.peek() {
                            None | Some('\n') => break,
                            Some('"') => { s.push('"'); self.pos += 1; break; }
                            Some('\\') => {
                                s.push('\\'); self.pos += 1;
                                if let Some(c) = self.peek() { s.push(c); self.pos += 1; }
                            }
                            Some(c) => { s.push(c); self.pos += 1; }
                        }
                    }
                }
                Some('\\') => {
                    flush_word!();
                    s.push('\\');
                    self.pos += 1;
                    if let Some(c) = self.peek() { s.push(c); self.pos += 1; }
                }
                Some('$') => {
                    flush_word!();
                    s.push('$');
                    self.pos += 1;
                    match self.peek() {
                        Some('(') => {
                            self.pos += 1;
                            let inner = self.read_comsub_in_arith();
                            s.push('(');
                            s.push_str(&inner);
                            s.push(')');
                        }
                        Some('{') => {
                            self.pos += 1;
                            let inner = self.read_brace_expansion_inner();
                            s.push('{');
                            s.push_str(&inner);
                            s.push('}');
                        }
                        _ => {}
                    }
                }
                Some('(') => {
                    flush_word!();
                    depth += 1;
                    s.push('(');
                    self.pos += 1;
                }
                Some(')') => {
                    flush_word!();
                    if case_depth > 0 {
                        // Inside a case statement: ) is a pattern terminator
                        s.push(')');
                        self.pos += 1;
                    } else {
                        depth -= 1;
                        if depth == 0 {
                            self.pos += 1; // consume the closing )
                            break;
                        }
                        s.push(')');
                        self.pos += 1;
                    }
                }
                Some('\n') => {
                    flush_word!();
                    s.push('\n');
                    self.pos += 1;
                }
                Some(c) if c.is_alphanumeric() || c == '_' => {
                    // Accumulate word chars to detect reserved words
                    word_buf.push(c);
                    self.pos += 1;
                }
                Some(c) => {
                    flush_word!();
                    s.push(c);
                    self.pos += 1;
                }
            }
        }
        flush_word!();
        s
    }

    fn read_arith_cmd_body(&mut self) -> (String, bool) {
        let mut depth = 0i32;  // extra paren depth beyond the initial ((
        let mut s = String::new();
        loop {
            match self.peek() {
                None | Some('\n') => return (s, false), // didn't find ))
                Some('$') => {
                    s.push('$');
                    self.pos += 1;
                    match self.peek() {
                        Some('(') => {
                            // $( ... ) command substitution — use the case-aware
                            // reader so ) inside case patterns doesn't prematurely
                            // close the (( )) arith-for header.
                            self.pos += 1; // consume '('
                            let inner = self.read_comsub_in_arith();
                            s.push('(');
                            s.push_str(&inner);
                            s.push(')');
                        }
                        Some('{') => {
                            // ${ ... } brace expansion — read until matching }
                            // so ) inside (e.g. case patterns) doesn't close ((.
                            self.pos += 1; // consume '{'
                            let inner = self.read_brace_expansion_inner();
                            s.push('{');
                            s.push_str(&inner);
                            s.push('}');
                        }
                        _ => {}
                    }
                }
                Some('(') => { depth += 1; s.push('('); self.pos += 1; }
                Some(')') => {
                    if depth == 0 && self.peek_at(1) == Some(')') {
                        self.pos += 2; // consume ))
                        return (s, true);
                    } else if depth > 0 {
                        depth -= 1; s.push(')'); self.pos += 1;
                    } else {
                        // Unmatched ) at depth 0 — not arithmetic
                        return (s, false);
                    }
                }
                Some('\'') => {
                    // Single-quoted string: read until closing '
                    s.push('\'');
                    self.pos += 1;
                    loop {
                        match self.peek() {
                            None | Some('\n') => break,
                            Some('\'') => { s.push('\''); self.pos += 1; break; }
                            Some('\\') => {
                                s.push('\\'); self.pos += 1;
                                if let Some(c) = self.peek() { s.push(c); self.pos += 1; }
                            }
                            Some(c) => { s.push(c); self.pos += 1; }
                        }
                    }
                }
                Some('"') => {
                    // Double-quoted string: read until closing "
                    s.push('"');
                    self.pos += 1;
                    loop {
                        match self.peek() {
                            None | Some('\n') => break,
                            Some('"') => { s.push('"'); self.pos += 1; break; }
                            Some('\\') => {
                                s.push('\\'); self.pos += 1;
                                if let Some(c) = self.peek() { s.push(c); self.pos += 1; }
                            }
                            Some(c) => { s.push(c); self.pos += 1; }
                        }
                    }
                }
                Some('\\') => {
                    s.push('\\'); self.pos += 1;
                    if let Some(c) = self.peek() { s.push(c); self.pos += 1; }
                }
                Some(c) => { s.push(c); self.pos += 1; }
            }
        }
    }

    fn read_compound_assign_suffix_raw(&mut self) -> String {
        let mut out = String::new();
        let mut in_sq = false;
        let mut in_dq = false;
        loop {
            let Some(c) = self.peek() else { break; };
            if in_sq {
                out.push(c);
                self.pos += 1;
                if c == '\'' {
                    in_sq = false;
                }
                continue;
            }
            if in_dq {
                out.push(c);
                self.pos += 1;
                if c == '\\' {
                    if let Some(nc) = self.peek() {
                        out.push(nc);
                        self.pos += 1;
                    }
                    continue;
                }
                if c == '"' {
                    in_dq = false;
                }
                continue;
            }
            match c {
                '\n' | ' ' | '\t' | '|' | '&' | ';' | '(' | ')' | '<' | '>' => break,
                '\'' => {
                    in_sq = true;
                    out.push(c);
                    self.pos += 1;
                }
                '"' => {
                    in_dq = true;
                    out.push(c);
                    self.pos += 1;
                }
                '\\' => {
                    out.push(c);
                    self.pos += 1;
                    if let Some(nc) = self.peek() {
                        out.push(nc);
                        self.pos += 1;
                    }
                }
                _ => {
                    out.push(c);
                    self.pos += 1;
                }
            }
        }
        out
    }

    /// Read the body of a `$((…))` arithmetic expansion.  Returns
    /// `(body, closed_doubled)` where `closed_doubled` is true if we
    /// terminated on a well-formed `))` (arith form) and false if the
    /// inner `)` count made that impossible — the caller should then
    /// re-parse as a `$( (…) )` command substitution.
    fn read_until_double_close_paren(&mut self) -> (String, bool) {
        let mut depth = 2usize;
        let mut s = String::new();
        let mut closed_doubled = false;
        loop {
            match self.peek() {
                None => break,
                Some('(') => { depth += 1; s.push('('); self.pos += 1; }
                Some(')') => {
                    if depth == 2 && self.peek_at(1) == Some(')') {
                        self.pos += 2;
                        closed_doubled = true;
                        break;
                    } else if depth == 1 {
                        // We've consumed more `)` than `(` — this can
                        // only be `$( (…) )` command substitution, not
                        // arithmetic.  Stop with the remaining input
                        // (including this `)`) intact for the caller.
                        break;
                    } else {
                        depth -= 1; s.push(')'); self.pos += 1;
                    }
                }
                Some('\\') => {
                    s.push('\\'); self.pos += 1;
                    if let Some(c) = self.peek() { s.push(c); self.pos += 1; }
                }
                Some(c) => { s.push(c); self.pos += 1; }
            }
        }
        (s, closed_doubled)
    }

    // -----------------------------------------------------------------------
    // $'...' ANSI-C quoting – returns inner text
    // -----------------------------------------------------------------------

    fn read_ansi_c_quoted_inner(&mut self) -> String {
        self.pos += 1; // consume '\''
        let mut s = String::new();
        loop {
            match self.peek() {
                None | Some('\'') => {
                    if self.peek().is_some() { self.pos += 1; }
                    break;
                }
                Some('\\') => {
                    self.pos += 1;
                    s.push('\\');
                    if let Some(c) = self.peek() { s.push(c); self.pos += 1; }
                }
                Some(c) => { s.push(c); self.pos += 1; }
            }
        }
        s
    }

    // -----------------------------------------------------------------------
    // Tilde prefix
    // -----------------------------------------------------------------------

    fn read_tilde_prefix(&mut self) -> String {
        self.pos += 1; // consume '~'
        let mut s = String::from('~');
        // Read optional username: letters, digits, '_', '-', '.'
        while matches!(self.peek(), Some(c) if c.is_alphanumeric() || c == '_' || c == '-' || c == '.') {
            s.push(self.peek().unwrap());
            self.pos += 1;
        }
        s
    }

    // -----------------------------------------------------------------------
    // Here-document delimiter
    // -----------------------------------------------------------------------

    fn read_heredoc_delimiter(&mut self) -> (String, bool) {
        let mut delim = String::new();
        let mut quoted = false;

        match self.peek() {
            Some('\'') => {
                quoted = true;
                self.pos += 1;
                while !matches!(self.peek(), None | Some('\'')) {
                    delim.push(self.peek().unwrap()); self.pos += 1;
                }
                if self.peek() == Some('\'') { self.pos += 1; }
            }
            Some('"') => {
                quoted = true;
                self.pos += 1;
                while !matches!(self.peek(), None | Some('"')) {
                    if self.peek() == Some('\\') {
                        self.pos += 1;
                        if let Some(c) = self.peek() { delim.push(c); self.pos += 1; }
                    } else {
                        delim.push(self.peek().unwrap()); self.pos += 1;
                    }
                }
                if self.peek() == Some('"') { self.pos += 1; }
            }
            Some('\\') => {
                // Backslash-quoting the delimiter makes the body literal.
                // `\<NL>` is a line continuation even here — skip both and
                // keep scanning on the next physical line.
                if self.chars.get(self.pos + 1).copied() == Some('\n') {
                    self.pos += 2;
                    // Re-enter this function at current position: fall through
                    // to the default branch (unquoted).
                    while matches!(self.peek(), Some(c) if !c.is_whitespace()
                            && c != ';' && c != '&' && c != '|' && c != '<' && c != '>') {
                        if self.peek() == Some('\\') && self.chars.get(self.pos + 1).copied() == Some('\n') {
                            self.pos += 2;
                            continue;
                        }
                        delim.push(self.peek().unwrap()); self.pos += 1;
                    }
                    return (delim, false);
                }
                quoted = true;
                self.pos += 1;
                while !matches!(self.peek(), None | Some('\n') | Some(' ') | Some('\t')) {
                    // `\<NL>` in a backslash-quoted delim is still a line
                    // continuation; eat both chars and continue.
                    if self.peek() == Some('\\') && self.chars.get(self.pos + 1).copied() == Some('\n') {
                        self.pos += 2;
                        continue;
                    }
                    if self.peek() == Some('\\') {
                        self.pos += 1;
                        if let Some(c) = self.peek() { delim.push(c); self.pos += 1; }
                    } else {
                        delim.push(self.peek().unwrap()); self.pos += 1;
                    }
                }
            }
            _ => {
                while matches!(self.peek(), Some(c) if !c.is_whitespace()
                        && c != ';' && c != '&' && c != '|' && c != '<' && c != '>') {
                    // Backslash-newline is a line continuation: skip both chars
                    // without adding either to the delimiter.
                    if self.peek() == Some('\\') && self.chars.get(self.pos + 1).copied() == Some('\n') {
                        self.pos += 2;
                        continue;
                    }
                    delim.push(self.peek().unwrap()); self.pos += 1;
                }
            }
        }
        (delim, quoted)
    }

    // -----------------------------------------------------------------------
    // Here-document body consumption
    // -----------------------------------------------------------------------

    fn consume_heredoc_bodies(&mut self) {
        let pending = std::mem::take(&mut self.pending_heredocs);

        // Find the token indices of the HereDoc tokens we just pushed, in order.
        let mut hdoc_indices: Vec<usize> = Vec::new();
        for i in (0..self.tokens.len()).rev() {
            if let Token::HereDoc(_) = &self.tokens[i] {
                hdoc_indices.push(i);
                if hdoc_indices.len() == pending.len() { break; }
            }
        }
        hdoc_indices.reverse();

        let mut total_newlines = 0usize;
        for (info, tok_idx) in pending.into_iter().zip(hdoc_indices.into_iter()) {
            let body_start = self.pos;
            let content = self.read_heredoc_body(&info.delimiter, info.strip_tabs, info.quoted);
            // Count physical source newlines consumed while reading the
            // heredoc, not logical newlines in the stored body. Unquoted
            // heredocs can fold `\\<NL>` pairs, which would otherwise skew
            // parser line tracking.
            total_newlines += self.chars[body_start..self.pos]
                .iter()
                .filter(|&&c| c == '\n')
                .count();
            if let Token::HereDoc(ref mut hd) = self.tokens[tok_idx] {
                hd.content = content;
            }
        }
        // Push Newline tokens for lines consumed by heredoc bodies so the
        // parser's line counter stays in sync with the source file.
        for _ in 0..total_newlines {
            self.tokens.push(Token::Newline);
        }
    }

    fn read_heredoc_body(&mut self, delimiter: &str, strip_tabs: bool, quoted: bool) -> String {
        let start_pos = self.pos;
        let mut body = String::new();
        let mut found_delimiter = false;
        loop {
            // Read one logical line. For unquoted heredocs, `\<NL>` is a line
            // continuation: the backslash and newline are removed and reading
            // continues on the next physical line.
            let mut line = String::new();
            let mut hit_eof = false;
            loop {
                match self.peek() {
                    None => { hit_eof = true; break; }
                    Some('\n') => { line.push('\n'); self.pos += 1; break; }
                    Some('\\') if !quoted
                        && self.chars.get(self.pos + 1).copied() == Some('\n') => {
                        // Skip the backslash-newline pair; continue building
                        // the same logical line.
                        self.pos += 2;
                    }
                    Some(c) => { line.push(c); self.pos += 1; }
                }
            }
            // Check if this line (after optional tab stripping) is the delimiter
            let check = if strip_tabs {
                line.trim_start_matches('\t').to_string()
            } else {
                line.clone()
            };
            let trimmed = check.trim_end_matches('\n');
            if trimmed == delimiter {
                found_delimiter = true;
                break;
            }
            if strip_tabs {
                body.push_str(line.trim_start_matches('\t'));
            } else {
                body.push_str(&line);
            }
            if hit_eof || self.pos >= self.chars.len() { break; }
        }
        if !found_delimiter {
            // Heredoc was terminated by end-of-file; record a warning.
            // We need the line of the << operator. Approximate: count newlines
            // in body to get current line, and the << was some lines before.
            // Use the position of the last consumed character (not one-past-end)
            // so we report the line of the last content line, matching bash.
            let eof_line = if self.pos > 0 {
                self.line_number_at(self.pos - 1)
            } else {
                self.line_number_at(self.pos)
            };
            // The start_pos is just after the newline that triggered body reading,
            // so the << was on the line before that.
            let heredoc_line = self.line_number_at(start_pos) - 1;
            let hsl = if heredoc_line == 0 { 1 } else { heredoc_line };
            self.heredoc_warnings.push(HeredocWarning {
                heredoc_start_line: hsl,
                eof_line,
                wanted: delimiter.to_string(),
                comsub: false,
                trigger_line: hsl,
                kind: HeredocWarningKind::DelimitedByEof,
            });
        }
        body
    }
}

// ---------------------------------------------------------------------------
// WordPiece – internal helper to collect the parts of a compound word
// ---------------------------------------------------------------------------

enum WordPiece {
    Bare(String),
    SingleQuoted(String),
    DoubleQuoted(String),
    DollarSingleQuoted(String),
    BraceGroup(String),
    CommandSub(String),
    ArithSub(String),
    ProcessSub(String),
    ExtGlob(String),
    Tilde(String),
}

impl WordPiece {
    /// Produce the canonical string representation of this piece (for use
    /// inside Concat payloads).
    fn to_string_raw(&self) -> String {
        match self {
            WordPiece::Bare(s) => s.clone(),
            WordPiece::SingleQuoted(s) => format!("'{}'", s),
            WordPiece::DoubleQuoted(s) => {
                // Already has surrounding quotes encoded in the string if it came
                // from $"…"; otherwise wrap it.
                if s.starts_with("$\"") { s.clone() } else { format!("\"{}\"", s) }
            }
            WordPiece::DollarSingleQuoted(s) => format!("$'{}'", s),
            WordPiece::BraceGroup(s) => s.clone(),
            WordPiece::CommandSub(s) => s.clone(),
            WordPiece::ArithSub(s) => format!("$(({}))", s),
            WordPiece::ProcessSub(s) => s.clone(),
            WordPiece::ExtGlob(s) => s.clone(),
            WordPiece::Tilde(s) => s.clone(),
        }
    }
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

#[inline]
fn is_extglob_prefix(c: char) -> bool {
    matches!(c, '@' | '*' | '+' | '?' | '!')
}

#[inline]
fn is_special_param(c: char) -> bool {
    "@*#?!-$0".contains(c)
}

fn piece_to_string(p: WordPiece) -> String {
    match p {
        WordPiece::Bare(s) => s,
        WordPiece::SingleQuoted(s) => format!("'{}'", s),
        WordPiece::DoubleQuoted(s) => format!("\"{}\"", s),
        WordPiece::DollarSingleQuoted(s) => format!("$'{}'", s),
        WordPiece::BraceGroup(s) => s,
        WordPiece::CommandSub(s) => s,
        WordPiece::ArithSub(s) => format!("$(({}))", s),
        // Process substitutions get a PUA marker so the execution-time
        // resolver distinguishes real procsubs from literal `<(...)`
        // produced by backslash-escapes or variable expansion.
        WordPiece::ProcessSub(s) => {
            // s looks like `<(cmd)` or `>(cmd)` — prefix with U+E010/E011
            // and suffix with U+E012 to make a unique framing.
            if let Some(rest) = s.strip_prefix("<(") {
                format!("\u{E010}{}\u{E012}", rest.trim_end_matches(')'))
            } else if let Some(rest) = s.strip_prefix(">(") {
                format!("\u{E011}{}\u{E012}", rest.trim_end_matches(')'))
            } else {
                s
            }
        }
        WordPiece::ExtGlob(s) => s,
        WordPiece::Tilde(s) => s,
    }
}

/// Like piece_to_string but takes a reference.
fn piece_to_string_raw(p: &WordPiece) -> String {
    match p {
        WordPiece::Bare(s) => s.clone(),
        WordPiece::SingleQuoted(s) => format!("'{}'", s),
        WordPiece::DoubleQuoted(s) => format!("\"{}\"", s),
        WordPiece::DollarSingleQuoted(s) => format!("$'{}'", s),
        WordPiece::BraceGroup(s) => s.clone(),
        WordPiece::CommandSub(s) => s.clone(),
        WordPiece::ArithSub(s) => format!("$(({}))", s),
        WordPiece::ProcessSub(s) => {
            if let Some(rest) = s.strip_prefix("<(") {
                format!("\u{E010}{}\u{E012}", rest.trim_end_matches(')'))
            } else if let Some(rest) = s.strip_prefix(">(") {
                format!("\u{E011}{}\u{E012}", rest.trim_end_matches(')'))
            } else {
                s.clone()
            }
        }
        WordPiece::ExtGlob(s) => s.clone(),
        WordPiece::Tilde(s) => s.clone(),
    }
}

/// Check if a bare word starts with NAME= or NAME+= pattern.
/// Returns (name, op, rest_of_bare) if it matches.
fn skip_assignment_parens(bytes: &[u8], mut i: usize) -> usize {
    let mut depth = 1i32;
    while i < bytes.len() {
        match bytes[i] {
            b'\\' => {
                i += if i + 1 < bytes.len() { 2 } else { 1 };
            }
            b'\'' => {
                i += 1;
                while i < bytes.len() {
                    if bytes[i] == b'\'' {
                        i += 1;
                        break;
                    }
                    i += 1;
                }
            }
            b'"' => {
                i += 1;
                while i < bytes.len() {
                    if bytes[i] == b'\\' && i + 1 < bytes.len() {
                        i += 2;
                        continue;
                    }
                    if bytes[i] == b'"' {
                        i += 1;
                        break;
                    }
                    i += 1;
                }
            }
            b'$' if i + 1 < bytes.len() && bytes[i + 1] == b'(' => {
                i = skip_assignment_parens(bytes, i + 2);
            }
            b'(' => {
                depth += 1;
                i += 1;
            }
            b')' => {
                depth -= 1;
                i += 1;
                if depth == 0 {
                    break;
                }
            }
            _ => i += 1,
        }
    }
    i
}

fn skip_assignment_braces(bytes: &[u8], mut i: usize) -> usize {
    let mut depth = 1i32;
    while i < bytes.len() {
        match bytes[i] {
            b'\\' => {
                i += if i + 1 < bytes.len() { 2 } else { 1 };
            }
            b'\'' => {
                i += 1;
                while i < bytes.len() {
                    if bytes[i] == b'\'' {
                        i += 1;
                        break;
                    }
                    i += 1;
                }
            }
            b'"' => {
                i += 1;
                while i < bytes.len() {
                    if bytes[i] == b'\\' && i + 1 < bytes.len() {
                        i += 2;
                        continue;
                    }
                    if bytes[i] == b'"' {
                        i += 1;
                        break;
                    }
                    i += 1;
                }
            }
            b'$' if i + 1 < bytes.len() && bytes[i + 1] == b'{' => {
                i = skip_assignment_braces(bytes, i + 2);
            }
            b'$' if i + 1 < bytes.len() && bytes[i + 1] == b'(' => {
                i = skip_assignment_parens(bytes, i + 2);
            }
            b'{' => {
                depth += 1;
                i += 1;
            }
            b'}' => {
                depth -= 1;
                i += 1;
                if depth == 0 {
                    break;
                }
            }
            _ => i += 1,
        }
    }
    i
}

fn detect_assignment_prefix(s: &str) -> Option<(String, String, String)> {
    let bytes = s.as_bytes();
    let mut in_bracket = false;
    let mut in_dq = false;
    let mut in_sq = false;
    let mut bracket_depth = 0i32;
    let mut i = 0;
    while i < bytes.len() {
        let b = bytes[i];
        if in_sq {
            if b == b'\'' { in_sq = false; }
            i += 1;
            continue;
        }
        if in_dq {
            if b == b'\\' && i + 1 < bytes.len() {
                i += 2;
                continue;
            }
            if b == b'"' { in_dq = false; }
            i += 1;
            continue;
        }
        if b == b'=' && !in_bracket {
            if i == 0 { return None; }
            let (op_str, name_part) = if i >= 1 && bytes[i - 1] == b'+' {
                ("+=", &s[..i - 1])
            } else {
                ("=", &s[..i])
            };
            if !is_valid_assign_name(name_part) {
                return None;
            }
            let rest = s[i + 1..].to_string();
            return Some((name_part.to_string(), op_str.to_string(), rest));
        }
        match b {
            b'[' => {
                in_bracket = true;
                bracket_depth += 1;
            }
            b']' if in_bracket => {
                bracket_depth -= 1;
                if bracket_depth <= 0 {
                    in_bracket = false;
                    bracket_depth = 0;
                }
            }
            b'\\' if i + 1 < bytes.len() => {
                i += 2;
                continue;
            }
            b'"' if in_bracket => {
                in_dq = true;
                i += 1;
                continue;
            }
            b'\'' if in_bracket => {
                in_sq = true;
                i += 1;
                continue;
            }
            b'$' if in_bracket && i + 1 < bytes.len() && bytes[i + 1] == b'(' => {
                i = skip_assignment_parens(bytes, i + 2);
                continue;
            }
            b'$' if in_bracket && i + 1 < bytes.len() && bytes[i + 1] == b'{' => {
                i = skip_assignment_braces(bytes, i + 2);
                continue;
            }
            _ => {}
        }
        if !in_bracket {
            let c = b as char;
            if i == 0 {
                if !c.is_alphabetic() && c != '_' { return None; }
            } else if !c.is_alphanumeric() && c != '_' && c != '+' && c != '[' && c != ']' {
                return None;
            }
        }
        i += 1;
    }
    None
}

/// Check if `name` is a valid assignment LHS: NAME or NAME[subscript].
fn is_valid_assign_name(name: &str) -> bool {
    // Split on first '[' to check base name
    let (base, rest) = if let Some(idx) = name.find('[') {
        (&name[..idx], &name[idx..])
    } else {
        (name, "")
    };
    if base.is_empty() { return false; }
    let base_chars: Vec<char> = base.chars().collect();
    if !base_chars[0].is_alphabetic() && base_chars[0] != '_' { return false; }
    if base_chars.iter().skip(1).any(|&c| !c.is_alphanumeric() && c != '_') { return false; }
    // If there's a subscript, it must end with ]
    if !rest.is_empty() {
        if !rest.ends_with(']') { return false; }
    }
    true
}

/// Try to parse `s` as an assignment word (`NAME=val` or `NAME+=val`).
/// Also handles `NAME[subscript]=val`.
/// Returns `(name, op, value)` or `None`.
fn parse_assignment(s: &str) -> Option<(String, String, String)> {
    let bytes = s.as_bytes();
    let mut in_bracket = false;
    let mut in_sq = false;
    let mut in_dq = false;
    let mut bracket_depth = 0i32;
    let mut i = 0usize;
    while i < bytes.len() {
        let b = bytes[i];
        if in_sq {
            if b == b'\'' { in_sq = false; }
            i += 1;
            continue;
        }
        if in_dq {
            if b == b'\\' && i + 1 < bytes.len() {
                i += 2;
                continue;
            }
            if b == b'"' { in_dq = false; }
            i += 1;
            continue;
        }
        match b {
            b'[' => {
                in_bracket = true;
                bracket_depth += 1;
            }
            b']' if in_bracket => {
                bracket_depth -= 1;
                if bracket_depth <= 0 {
                    in_bracket = false;
                    bracket_depth = 0;
                }
            }
            b'"' if in_bracket => {
                in_dq = true;
                i += 1;
                continue;
            }
            b'\'' if in_bracket => {
                in_sq = true;
                i += 1;
                continue;
            }
            b'$' if in_bracket && i + 1 < bytes.len() && bytes[i + 1] == b'(' => {
                i = skip_assignment_parens(bytes, i + 2);
                continue;
            }
            b'$' if in_bracket && i + 1 < bytes.len() && bytes[i + 1] == b'{' => {
                i = skip_assignment_braces(bytes, i + 2);
                continue;
            }
            _ => {}
        }
        if b == b'=' && !in_bracket {
            if i == 0 { return None; }
            let (op_str, name_part) = if i >= 1 && bytes[i - 1] == b'+' {
                ("+=", &s[..i - 1])
            } else {
                ("=", &s[..i])
            };
            if !is_valid_assign_name(name_part) {
                return None;
            }
            let value = s[i + 1..].to_string();
            return Some((name_part.to_string(), op_str.to_string(), value));
        }
        i += 1;
    }
    None
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use super::*;

    fn get_words(tokens: &[Token]) -> Vec<String> {
        tokens.iter().filter_map(|t| match t {
            Token::Word(s) => Some(s.clone()),
            _ => None,
        }).collect()
    }

    #[test]
    fn test_simple_command() {
        let tokens = tokenize("echo hello world");
        assert_eq!(tokens[0], Token::Word("echo".into()));
        assert_eq!(tokens[1], Token::Word("hello".into()));
        assert_eq!(tokens[2], Token::Word("world".into()));
        assert_eq!(tokens[3], Token::Eof);
    }

    #[test]
    fn test_pipe() {
        let tokens = tokenize("ls | grep foo");
        assert!(tokens.contains(&Token::Pipe));
    }

    #[test]
    fn test_pipe_amp() {
        let tokens = tokenize("cmd1 |& cmd2");
        assert!(tokens.contains(&Token::PipeAmp));
    }

    #[test]
    fn test_or_and() {
        let tokens = tokenize("a || b && c");
        assert!(tokens.contains(&Token::OrOr));
        assert!(tokens.contains(&Token::AndAnd));
    }

    #[test]
    fn test_semicolons() {
        let tokens = tokenize("a ; b ;; c");
        assert!(tokens.contains(&Token::Semi));
        assert!(tokens.contains(&Token::CaseSemi));
    }

    #[test]
    fn test_case_terminators() {
        let tokens = tokenize("a ;& b ;;& c");
        assert!(tokens.contains(&Token::CaseSemiAmp));
        assert!(tokens.contains(&Token::CaseSemiSemiAmp));
    }

    #[test]
    fn test_redirect_output() {
        let tokens = tokenize("echo hi > /tmp/out");
        let r = tokens.iter().find_map(|t| if let Token::Redirect(r) = t { Some(r) } else { None }).unwrap();
        assert_eq!(r.op, RedirectOp::Output);
        assert_eq!(r.target, "/tmp/out");
        assert_eq!(r.fd, None);
    }

    #[test]
    fn test_redirect_append() {
        let tokens = tokenize("echo hi >> /tmp/out");
        let r = tokens.iter().find_map(|t| if let Token::Redirect(r) = t { Some(r) } else { None }).unwrap();
        assert_eq!(r.op, RedirectOp::Append);
    }

    #[test]
    fn test_redirect_fd() {
        let tokens = tokenize("cmd 2>/dev/null");
        let r = tokens.iter().find_map(|t| if let Token::Redirect(r) = t { Some(r) } else { None }).unwrap();
        assert_eq!(r.fd, Some(2));
        assert_eq!(r.op, RedirectOp::Output);
    }

    #[test]
    fn test_redirect_stderr_stdout() {
        let tokens = tokenize("cmd 2>&1");
        let r = tokens.iter().find_map(|t| if let Token::Redirect(r) = t { Some(r) } else { None }).unwrap();
        assert_eq!(r.fd, Some(2));
        assert_eq!(r.op, RedirectOp::OutputDup);
        assert_eq!(r.target, "1");
    }

    #[test]
    fn test_redirect_input() {
        let tokens = tokenize("cmd < input.txt");
        let r = tokens.iter().find_map(|t| if let Token::Redirect(r) = t { Some(r) } else { None }).unwrap();
        assert_eq!(r.op, RedirectOp::Input);
        assert_eq!(r.target, "input.txt");
    }

    #[test]
    fn test_redirect_and_output() {
        let tokens = tokenize("cmd &> /dev/null");
        let r = tokens.iter().find_map(|t| if let Token::Redirect(r) = t { Some(r) } else { None }).unwrap();
        assert_eq!(r.op, RedirectOp::AndOutput);
    }

    #[test]
    fn test_redirect_and_append() {
        let tokens = tokenize("cmd &>> /dev/null");
        let r = tokens.iter().find_map(|t| if let Token::Redirect(r) = t { Some(r) } else { None }).unwrap();
        assert_eq!(r.op, RedirectOp::AndAppend);
    }

    #[test]
    fn test_redirect_clobber() {
        let tokens = tokenize("cmd >| /tmp/file");
        let r = tokens.iter().find_map(|t| if let Token::Redirect(r) = t { Some(r) } else { None }).unwrap();
        assert_eq!(r.op, RedirectOp::Clobber);
    }

    #[test]
    fn test_redirect_input_output() {
        let tokens = tokenize("cmd <> /tmp/file");
        let r = tokens.iter().find_map(|t| if let Token::Redirect(r) = t { Some(r) } else { None }).unwrap();
        assert_eq!(r.op, RedirectOp::InputOutput);
    }

    #[test]
    fn test_single_quoted() {
        let tokens = tokenize("echo 'hello world'");
        assert!(tokens.contains(&Token::SingleQuoted("hello world".into())));
    }

    #[test]
    fn test_double_quoted() {
        let tokens = tokenize(r#"echo "hello $NAME""#);
        if let Some(Token::DoubleQuoted(s)) = tokens.iter().find(|t| matches!(t, Token::DoubleQuoted(_))) {
            assert_eq!(s, "hello $NAME");
        } else {
            panic!("expected DoubleQuoted token");
        }
    }

    #[test]
    fn test_comment() {
        let tokens = tokenize("echo hi # this is a comment\necho bye");
        let words = get_words(&tokens);
        assert!(words.contains(&"bye".to_string()));
        assert!(!words.iter().any(|w| w.starts_with('#')));
    }

    #[test]
    fn test_newline_token() {
        let tokens = tokenize("a\nb");
        assert!(tokens.contains(&Token::Newline));
    }

    #[test]
    fn test_continuation_line() {
        let tokens = tokenize("echo \\\nhello");
        assert_eq!(get_words(&tokens), vec!["echo", "hello"]);
        assert!(!tokens.contains(&Token::Newline));
    }

    #[test]
    fn test_heredoc_basic() {
        let input = "cat <<EOF\nhello world\nEOF\n";
        let tokens = tokenize(input);
        let hd = tokens.iter().find_map(|t| if let Token::HereDoc(h) = t { Some(h) } else { None }).unwrap();
        assert_eq!(hd.delimiter, "EOF");
        assert_eq!(hd.content, "hello world\n");
        assert!(!hd.strip_tabs);
        assert!(!hd.quoted);
    }

    #[test]
    fn test_heredoc_strip_tabs() {
        let input = "cat <<-EOF\n\thello\n\tworld\nEOF\n";
        let tokens = tokenize(input);
        let hd = tokens.iter().find_map(|t| if let Token::HereDoc(h) = t { Some(h) } else { None }).unwrap();
        assert!(hd.strip_tabs);
        assert_eq!(hd.content, "hello\nworld\n");
    }

    #[test]
    fn test_heredoc_quoted_delimiter() {
        let input = "cat <<'EOF'\n$not_expanded\nEOF\n";
        let tokens = tokenize(input);
        let hd = tokens.iter().find_map(|t| if let Token::HereDoc(h) = t { Some(h) } else { None }).unwrap();
        assert!(hd.quoted);
        assert_eq!(hd.content, "$not_expanded\n");
    }

    #[test]
    fn test_multiple_heredocs() {
        let input = "paste <<EOF1 <<EOF2\nline_a\nEOF1\nline_b\nEOF2\n";
        let tokens = tokenize(input);
        let hds: Vec<&HereDocInfo> = tokens.iter()
            .filter_map(|t| if let Token::HereDoc(h) = t { Some(h) } else { None })
            .collect();
        assert_eq!(hds.len(), 2);
        assert_eq!(hds[0].content, "line_a\n");
        assert_eq!(hds[1].content, "line_b\n");
    }

    #[test]
    fn test_command_substitution() {
        let tokens = tokenize("echo $(date)");
        assert!(tokens.iter().any(|t| matches!(t, Token::CommandSub(s) if s == "$(date)")));
    }

    #[test]
    fn test_arithmetic_sub() {
        let tokens = tokenize("echo $((1 + 2))");
        assert!(tokens.iter().any(|t| matches!(t, Token::ArithSub(s) if s == "1 + 2")));
    }

    #[test]
    fn test_arith_cmd() {
        let tokens = tokenize("(( x + 1 ))");
        assert!(tokens.iter().any(|t| matches!(t, Token::ArithCmd(s) if s.contains("x"))));
    }

    #[test]
    fn test_backtick() {
        let tokens = tokenize("echo `date`");
        assert!(tokens.iter().any(|t| matches!(t, Token::CommandSub(s) if s.contains("date"))));
    }

    #[test]
    fn test_ansi_c_quoting() {
        let tokens = tokenize(r"echo $'\n\t'");
        assert!(tokens.iter().any(|t| matches!(t, Token::DollarSingleQuoted(_))));
    }

    #[test]
    fn test_brace_expansion() {
        let tokens = tokenize("echo ${HOME:-/root}");
        assert!(tokens.iter().any(|t| matches!(t, Token::BraceGroup(s) if s.contains("HOME"))));
    }

    #[test]
    fn test_process_sub() {
        let tokens = tokenize("diff <(ls a) <(ls b)");
        let psubs: Vec<_> = tokens.iter()
            .filter(|t| matches!(t, Token::ProcessSub(_)))
            .collect();
        assert_eq!(psubs.len(), 2);
    }

    #[test]
    fn test_bang() {
        let tokens = tokenize("! false");
        assert!(tokens.contains(&Token::Bang));
    }

    #[test]
    fn test_braces() {
        let tokens = tokenize("{ echo hi; }");
        assert!(tokens.contains(&Token::LBrace));
        assert!(tokens.contains(&Token::RBrace));
    }

    #[test]
    fn test_double_bracket() {
        let tokens = tokenize("[[ x == y ]]");
        assert!(tokens.contains(&Token::DoubleLBracket));
        assert!(tokens.contains(&Token::DoubleRBracket));
    }

    #[test]
    fn test_reserved_words() {
        let tokens = tokenize("if true; then echo yes; fi");
        assert!(tokens.contains(&Token::If));
        assert!(tokens.contains(&Token::Then));
        assert!(tokens.contains(&Token::Fi));
    }

    #[test]
    fn test_assignment_word() {
        let tokens = tokenize("FOO=bar");
        assert!(tokens.iter().any(|t| matches!(t, Token::AssignWord(n, op, v) if n == "FOO" && op == "=" && v == "bar")));
    }

    #[test]
    fn test_append_assignment() {
        let tokens = tokenize("PATH+=/usr/local/bin");
        assert!(tokens.iter().any(|t| matches!(t, Token::AssignWord(n, op, _) if n == "PATH" && op == "+=")));
    }

    #[test]
    fn test_tilde() {
        let tokens = tokenize("cd ~");
        assert!(tokens.iter().any(|t| matches!(t, Token::Tilde(s) if s == "~")));
    }

    #[test]
    fn test_tilde_user() {
        let tokens = tokenize("ls ~root/bin");
        // ~root should be emitted as a Tilde or Concat starting with tilde
        assert!(tokens.iter().any(|t| {
            matches!(t, Token::Tilde(s) if s == "~root")
            || matches!(t, Token::Concat(parts) if parts.first().map(|p| p.starts_with('~')).unwrap_or(false))
        }));
    }

    #[test]
    fn test_herestring() {
        let tokens = tokenize("cat <<<hello");
        let r = tokens.iter().find_map(|t| if let Token::Redirect(r) = t { Some(r) } else { None }).unwrap();
        assert_eq!(r.op, RedirectOp::Input);
        assert!(r.target.starts_with("<<<"));
    }

    #[test]
    fn test_nested_command_sub() {
        let tokens = tokenize("echo $(echo $(date))");
        assert!(tokens.iter().any(|t| matches!(t, Token::CommandSub(s) if s.contains("$(date)"))));
    }

    #[test]
    fn test_extglob() {
        let tokens = tokenize("echo @(*.txt|*.md)");
        assert!(tokens.iter().any(|t| matches!(t, Token::ExtGlob(_))));
    }

    #[test]
    fn test_concat_word() {
        // "prefix$VAR" forms a Concat of Bare + dollar expansion
        let tokens = tokenize(r#"echo "foo"bar"#);
        // Should produce a concat or two separate adjacent tokens
        // Either way no crash
        assert!(!tokens.is_empty());
    }

    #[test]
    fn test_cmdsub_heredoc_closes_after_body_when_paren_on_operator_line() {
        let input = "echo $(cat << EOF)\nfoo\nbar\nEOF\nafter\n";
        let result = tokenize_with_warnings(input);
        assert!(result.comsub_eof_errors.is_empty());
        assert!(result.tokens.iter().any(|t| {
            matches!(t, Token::CommandSub(s) if s == "$(cat << EOF\nfoo\nbar\nEOF)")
        }));
        assert!(result.tokens.iter().any(|t| matches!(t, Token::Word(s) if s == "after")));
        assert!(result.heredoc_warnings.iter().any(|w| {
            matches!(w.kind, HeredocWarningKind::CmdSubUnterminated { count: 1 }) && w.eof_line == 1
        }));
    }

    #[test]
    fn test_cmdsub_heredoc_operator_line_close_keeps_outer_suffix() {
        let input = "echo $(cat <<EOF) X\nbody\nEOF\n";
        let result = tokenize_with_warnings(input);
        assert!(result.comsub_eof_errors.is_empty());
        assert!(result.tokens.iter().any(|t| {
            matches!(t, Token::CommandSub(s) if s == "$(cat <<EOF\nbody\nEOF)")
        }));
        assert!(result.tokens.iter().any(|t| matches!(t, Token::Word(s) if s == "X")));
        assert!(result.heredoc_warnings.iter().any(|w| {
            matches!(w.kind, HeredocWarningKind::CmdSubUnterminated { count: 1 }) && w.eof_line == 1
        }));
    }

    #[test]
    fn test_cmdsub_heredoc_operator_line_close_keeps_same_word_suffix() {
        let input = "echo A$(cat <<EOF)B C\nx\nEOF\n";
        let result = tokenize_with_warnings(input);
        assert!(result.comsub_eof_errors.is_empty());
        assert!(result.tokens.iter().any(|t| {
            matches!(
                t,
                Token::Concat(parts)
                    if parts == &vec![
                        "A".to_string(),
                        "$(cat <<EOF\nx\nEOF)".to_string(),
                        "B".to_string(),
                    ]
            )
        }));
        assert!(result.tokens.iter().any(|t| matches!(t, Token::Word(s) if s == "C")));
        assert!(result.heredoc_warnings.iter().any(|w| {
            matches!(w.kind, HeredocWarningKind::CmdSubUnterminated { count: 1 }) && w.eof_line == 1
        }));
    }

    #[test]
    fn test_cmdsub_heredoc_operator_line_close_keeps_assignment_suffix() {
        let input = "v=A$(cat <<EOF)B\nx\nEOF\n";
        let result = tokenize_with_warnings(input);
        assert!(result.comsub_eof_errors.is_empty());
        assert!(result.tokens.iter().any(|t| {
            matches!(
                t,
                Token::AssignWord(name, op, value)
                    if name == "v"
                        && op == "="
                        && value == "A$(cat <<EOF\nx\nEOF)B"
            )
        }));
        assert!(result.heredoc_warnings.iter().any(|w| {
            matches!(w.kind, HeredocWarningKind::CmdSubUnterminated { count: 1 }) && w.eof_line == 1
        }));
    }

    #[test]
    fn test_cmdsub_heredoc_operator_line_close_missing_delimiter_is_not_unmatched() {
        let input = "echo $(cat <<EOF)";
        let result = tokenize_with_warnings(input);
        assert!(result.comsub_eof_errors.is_empty());
        assert!(result.heredoc_warnings.iter().any(|w| {
            matches!(w.kind, HeredocWarningKind::CmdSubUnterminated { count: 1 }) && w.eof_line == 1
        }));
        assert!(result.heredoc_warnings.iter().any(|w| {
            matches!(w.kind, HeredocWarningKind::DelimitedByEof)
                && w.heredoc_start_line == 1
                && w.wanted == "EOF"
        }));
    }

    #[test]
    fn test_cmdsub_heredoc_operator_line_close_counts_pending_heredocs() {
        let input = "echo $(cat <<A <<B)\nA\nB\n";
        let result = tokenize_with_warnings(input);
        assert!(result.comsub_eof_errors.is_empty());
        assert!(result.heredoc_warnings.iter().any(|w| {
            matches!(w.kind, HeredocWarningKind::CmdSubUnterminated { count: 2 }) && w.eof_line == 1
        }));
    }
}
