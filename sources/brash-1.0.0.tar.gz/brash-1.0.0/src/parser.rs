use crate::lexer::Token;

// ---------------------------------------------------------------------------
// AST types
// ---------------------------------------------------------------------------

#[derive(Debug, Clone)]
pub enum Command {
    Simple(SimpleCommand),
    Pipeline(Pipeline),
    List(List),
    If(IfCmd),
    While(WhileCmd),
    Until(UntilCmd),
    For(ForCmd),
    Case(CaseCmd),
    FuncDef(FuncDef),
    Group(GroupCmd),
    Subshell(SubshellCmd),
    Coproc(CoprocCmd),
    Select(SelectCmd),
    ArithFor(ArithForCmd),
    /// (( expr )) — arithmetic evaluation command
    ArithEval(String, usize), // (expr, lineno)
    Time(bool, Box<Command>), // (posix_flag, inner)
    Not(Box<Command>),
}

#[derive(Debug, Clone)]
pub struct SimpleCommand {
    pub assignments: Vec<Assignment>,
    pub words: Vec<String>,
    pub redirects: Vec<Redirect>,
    pub lineno: usize,
}

#[derive(Debug, Clone)]
pub struct Assignment {
    pub name: String,
    pub value: String,
    pub append: bool,
    pub export: bool,
}

#[derive(Debug, Clone)]
pub struct Redirect {
    pub fd: Option<i32>,
    pub op: crate::lexer::RedirectOp,
    pub target: String,
    /// True for heredocs with a quoted delimiter — body should NOT be expanded.
    pub heredoc_quoted: bool,
    /// For heredoc redirects, the original delimiter word (e.g. "EOF", "END").
    /// None for non-heredoc redirects.
    pub heredoc_delimiter: Option<String>,
    /// Bash `{name}< file` form: allocate a new FD and store it in the
    /// named shell variable.  When `Some(name)`, `fd` is ignored and
    /// the kernel-chosen FD value is assigned to `name`.
    pub varfd: Option<String>,
    /// Source-line number of the redirect operator.  Bash reports
    /// redirect-time errors using this line (e.g. `done > file`
    /// failures are attributed to the `done` line, not the `for`).
    /// Zero means "unknown" — fall back to the surrounding command's
    /// LINENO.
    pub lineno: usize,
}

#[derive(Debug, Clone)]
pub struct Pipeline {
    pub commands: Vec<Command>,
    pub negated: bool,
    /// Per-segment pipe types: `pipe_stderr[i]` is true when the pipe between
    /// command `i` and command `i+1` is `|&` (redirect stderr as well).
    /// Length is always `commands.len() - 1`.
    pub pipe_stderr: Vec<bool>,
}

#[derive(Debug, Clone)]
pub struct List {
    pub entries: Vec<ListEntry>,
}

#[derive(Debug, Clone)]
pub struct ListEntry {
    pub command: Command,
    pub op: ListOp,
}

#[derive(Debug, Clone)]
pub enum ListOp {
    Semi,
    Amp,
    And,
    Or,
    Newline,
    Last,
}

#[derive(Debug, Clone)]
pub struct IfCmd {
    pub condition: Box<Command>,
    pub then_body: Box<Command>,
    pub elif_parts: Vec<(Command, Command)>,
    pub else_body: Option<Box<Command>>,
    pub redirects: Vec<Redirect>,
    pub lineno: usize,
}

#[derive(Debug, Clone)]
pub struct WhileCmd {
    pub condition: Box<Command>,
    pub body: Box<Command>,
    pub redirects: Vec<Redirect>,
    pub lineno: usize,
}

#[derive(Debug, Clone)]
pub struct UntilCmd {
    pub condition: Box<Command>,
    pub body: Box<Command>,
    pub redirects: Vec<Redirect>,
    pub lineno: usize,
}

#[derive(Debug, Clone)]
pub struct ForCmd {
    pub var: String,
    pub words: Option<Vec<String>>,
    pub body: Box<Command>,
    pub redirects: Vec<Redirect>,
    pub lineno: usize,
}

#[derive(Debug, Clone)]
pub struct CaseCmd {
    pub word: String,
    pub arms: Vec<CaseArm>,
    pub redirects: Vec<Redirect>,
    pub lineno: usize,
}

#[derive(Debug, Clone)]
pub struct CaseArm {
    pub patterns: Vec<String>,
    pub body: Option<Box<Command>>,
    pub terminator: CaseTerminator,
    pub lineno: usize,
}

#[derive(Debug, Clone)]
pub enum CaseTerminator {
    Break,
    FallThrough,
    Continue,
}

#[derive(Debug, Clone)]
pub struct FuncDef {
    pub name: String,
    pub body: Box<Command>,
    pub redirects: Vec<Redirect>,
    pub start_lineno: usize,
    pub lineno: usize,
}

#[derive(Debug, Clone)]
pub struct GroupCmd {
    pub body: Box<Command>,
    pub redirects: Vec<Redirect>,
    pub lineno: usize,
}

#[derive(Debug, Clone)]
pub struct SubshellCmd {
    pub body: Box<Command>,
    pub redirects: Vec<Redirect>,
    /// Line number of the closing `)`. Used to attribute subshell-level
    /// fatal errors (e.g. POSIX-mode `break`-as-function) to that line.
    pub end_lineno: usize,
}

#[derive(Debug, Clone)]
pub struct CoprocCmd {
    pub name: Option<String>,
    pub body: Box<Command>,
    pub lineno: usize,
}

#[derive(Debug, Clone)]
pub struct SelectCmd {
    pub var: String,
    pub words: Option<Vec<String>>,
    pub body: Box<Command>,
    pub redirects: Vec<Redirect>,
    pub lineno: usize,
}

#[derive(Debug, Clone)]
pub struct ArithForCmd {
    pub init: String,
    pub cond: String,
    pub step: String,
    pub body: Box<Command>,
    pub redirects: Vec<Redirect>,
    pub lineno: usize,
}

// ---------------------------------------------------------------------------
// Public entry point
// ---------------------------------------------------------------------------

/// Parse a flat token stream produced by the lexer into an AST.
/// Parse error with line number context.
pub struct ParseError {
    pub message: String,
    pub lineno: usize,
}

impl std::fmt::Display for ParseError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "{}", self.message)
    }
}

pub fn parse(tokens: Vec<Token>) -> Result<Command, ParseError> {
    let mut p = Parser::new(tokens);
    let cmd = p.parse_complete_command().map_err(|msg| ParseError { message: msg, lineno: p.lineno })?;
    // Check for leftover tokens that weren't consumed (syntax error)
    p.skip_newlines();
    if !p.at_eof() {
        let tok = p.peek().clone();
        return Err(ParseError {
            message: format!("syntax error near unexpected token `{}'", token_display(&tok)),
            lineno: p.lineno,
        });
    }
    Ok(cmd)
}

/// Display a token in bash-compatible format for error messages
fn token_display(tok: &Token) -> String {
    match tok {
        Token::RParen => ")".into(),
        Token::LParen => "(".into(),
        Token::LBrace => "{".into(),
        Token::RBrace => "}".into(),
        Token::Semi => ";".into(),
        Token::Amp => "&".into(),
        Token::Pipe => "|".into(),
        Token::AndAnd => "&&".into(),
        Token::OrOr => "||".into(),
        Token::Do => "do".into(),
        Token::Done => "done".into(),
        Token::Then => "then".into(),
        Token::Fi => "fi".into(),
        Token::Esac => "esac".into(),
        Token::Elif => "elif".into(),
        Token::Else => "else".into(),
        Token::In => "in".into(),
        Token::For => "for".into(),
        Token::While => "while".into(),
        Token::Until => "until".into(),
        Token::Case => "case".into(),
        Token::If => "if".into(),
        Token::Select => "select".into(),
        Token::Function => "function".into(),
        Token::Word(w) => w.clone(),
        Token::Newline | Token::AliasNewline => "newline".into(),
        Token::LineCont => "line continuation".into(),
        Token::CaseSemi => ";;".into(),
        Token::CaseSemiAmp => ";&".into(),
        Token::CaseSemiSemiAmp => ";;&".into(),
        _ => format!("{:?}", tok),
    }
}

// ---------------------------------------------------------------------------
// Parser state
// ---------------------------------------------------------------------------

struct Parser {
    tokens: Vec<Token>,
    pos: usize,
    lineno: usize,
}

// ---------------------------------------------------------------------------
// Token helpers (free functions)
// ---------------------------------------------------------------------------

/// Returns Some(word-string) if `tok` is usable as a plain shell word.
/// Reserved words are allowed here (they are words when not in command position).
fn token_as_word(tok: &Token) -> Option<String> {
    match tok {
        Token::Word(s) => Some(s.clone()),
        Token::SingleQuoted(s) => Some(format!("'{}'", s)),
        Token::DoubleQuoted(s) => Some(format!("\"{}\"", s)),
        Token::DollarSingleQuoted(s) => Some(format!("$'{}'", s)),
        Token::BraceGroup(s) => Some(s.clone()),
        Token::ProcessSub(s) => {
            // Mark procsubs with PUA markers so the execution-time resolver
            // can distinguish them from literal `<(` / `>(` that came from
            // backslash-escapes or variable expansions.
            if let Some(rest) = s.strip_prefix("<(") {
                Some(format!("\u{E010}{}\u{E012}", rest.trim_end_matches(')')))
            } else if let Some(rest) = s.strip_prefix(">(") {
                Some(format!("\u{E011}{}\u{E012}", rest.trim_end_matches(')')))
            } else {
                Some(s.clone())
            }
        }
        Token::CommandSub(s) => Some(s.clone()),
        Token::ArithSub(s) => Some(format!("$(({}))", s)),
        Token::ExtGlob(s) => Some(s.clone()),
        Token::Tilde(s) => Some(s.clone()),
        Token::AssignWord(name, op, val) => Some(format!("{}{}{}", name, op, val)),
        Token::Concat(parts) => Some(parts.join("")),
        // Reserved words are words when not in command-first position
        Token::If => Some("if".into()),
        Token::Then => Some("then".into()),
        Token::Elif => Some("elif".into()),
        Token::Else => Some("else".into()),
        Token::Fi => Some("fi".into()),
        Token::While => Some("while".into()),
        Token::Until => Some("until".into()),
        Token::For => Some("for".into()),
        Token::Do => Some("do".into()),
        Token::Done => Some("done".into()),
        Token::Case => Some("case".into()),
        Token::Esac => Some("esac".into()),
        Token::In => Some("in".into()),
        Token::Select => Some("select".into()),
        Token::Function => Some("function".into()),
        Token::Coproc => Some("coproc".into()),
        Token::Time => Some("time".into()),
        Token::Bang => Some("!".into()),
        Token::LBrace => Some("{".into()),
        Token::RBrace => Some("}".into()),
        _ => None,
    }
}

fn decode_compound_assign_word(name: &str, op: &str, val: &str) -> String {
    if let Some(body) = val.strip_prefix("\x00ARRAY\x00") {
        format!("{}{}({})", name, op, body.replace('\x1F', " "))
    } else {
        format!("{}{}{}", name, op, val)
    }
}

fn compound_assign_arg_mode(words: &[String]) -> &'static str {
    match words.first().map(|s| s.as_str()) {
        Some("declare") | Some("typeset") | Some("local")
        | Some("readonly") | Some("export") => "encoded",
        Some("eval") | Some("let") => "raw",
        _ => "forbid",
    }
}

/// True if tok ends or separates list entries.
fn is_separator(tok: &Token) -> bool {
    matches!(
        tok,
        Token::Newline | Token::AliasNewline | Token::Semi | Token::Amp | Token::AndAnd | Token::OrOr | Token::Eof
    )
}

/// True if tok is a redirection (Redirect or HereDoc).
fn is_redirect(tok: &Token) -> bool {
    matches!(tok, Token::Redirect(_) | Token::HereDoc(_))
}

// ---------------------------------------------------------------------------
// Parser implementation
// ---------------------------------------------------------------------------

impl Parser {
    fn new(tokens: Vec<Token>) -> Self {
        Parser { tokens, pos: 0, lineno: 1 }
    }

    fn unexpected_eof_from(&self, opener: &str, line: usize) -> String {
        // Bash's wording for an unexpected EOF inside an unclosed compound
        // command (`if`, `while`, `for`, `case`, `(`, `{` …):
        //   syntax error: unexpected end of file from `KEYWORD' command on line N
        //
        // Inside a `$(...)` / `\`...\`` command substitution exec.rs rewrites
        // this to "syntax error near unexpected token `)'" before printing,
        // matching bash's one-pass behaviour where the enclosing `)` is the
        // unexpected token.
        format!(
            "syntax error: unexpected end of file from `{}' command on line {}",
            opener, line
        )
    }

    // -----------------------------------------------------------------------
    // Low-level token access
    // -----------------------------------------------------------------------

    fn peek(&self) -> &Token {
        self.tokens.get(self.pos).unwrap_or(&Token::Eof)
    }

    fn peek_offset(&self, offset: usize) -> &Token {
        self.tokens.get(self.pos + offset).unwrap_or(&Token::Eof)
    }

    fn advance(&mut self) -> Token {
        let t = self.tokens.get(self.pos).cloned().unwrap_or(Token::Eof);
        if self.pos < self.tokens.len() {
            match &t {
                Token::Newline | Token::LineCont => self.lineno += 1,
                // Count embedded newlines inside quoted strings and
                // command/arith/process substitutions so that LINENO
                // stays accurate past multi-line tokens like
                // `x="\\<newline>"` or `$(<newline>cmd<newline>)`.
                Token::SingleQuoted(s)
                | Token::DoubleQuoted(s)
                | Token::DollarSingleQuoted(s)
                | Token::CommandSub(s)
                | Token::ArithSub(s)
                | Token::ProcessSub(s)
                | Token::BraceGroup(s)
                | Token::ExtGlob(s) => {
                    self.lineno += s.chars().filter(|&c| c == '\n').count();
                }
                Token::Concat(parts) => {
                    for p in parts {
                        self.lineno += p.chars().filter(|&c| c == '\n').count();
                    }
                }
                Token::AssignWord(_, _, value) => {
                    self.lineno += value.chars().filter(|&c| c == '\n').count();
                }
                _ => {}
            }
            self.pos += 1;
        }
        t
    }

    fn at_eof(&self) -> bool {
        matches!(self.peek(), Token::Eof)
    }

    fn skip_newlines(&mut self) {
        while matches!(self.peek(), Token::Newline | Token::AliasNewline | Token::LineCont) {
            self.advance();
        }
    }

    /// Skip backslash-newline line continuations only.  Unlike `skip_newlines`,
    /// this does NOT consume real newlines — it is for places where the parser
    /// needs to look past a `\<NL>` sequence (which is whitespace in bash) but
    /// must still treat a hard newline as a list/command separator.
    fn skip_line_conts(&mut self) {
        while matches!(self.peek(), Token::LineCont) {
            self.advance();
        }
    }

    fn skip_newlines_and_semis(&mut self) {
        while matches!(self.peek(), Token::Newline | Token::AliasNewline | Token::LineCont | Token::Semi) {
            self.advance();
        }
    }

    /// Expect and consume one specific token variant (by discriminant).
    fn expect(&mut self, expected: &Token) -> Result<(), String> {
        let tok = self.peek().clone();
        if std::mem::discriminant(&tok) == std::mem::discriminant(expected) {
            self.advance();
            Ok(())
        } else {
            Err(format!("syntax error near unexpected token `{}'", token_display(&tok)))
        }
    }

    /// Expect and consume a `(` token.
    fn expect_lparen(&mut self) -> Result<(), String> {
        if matches!(self.peek(), Token::LParen) {
            self.advance();
            Ok(())
        } else {
            Err(format!("syntax error near unexpected token `{}'", token_display(&self.peek())))
        }
    }

    /// Expect and consume a `)` token.
    fn expect_rparen(&mut self) -> Result<(), String> {
        if matches!(self.peek(), Token::RParen) {
            self.advance();
            Ok(())
        } else {
            Err("unexpected EOF while looking for matching `)'".into())
        }
    }

    // -----------------------------------------------------------------------
    // Top-level parse
    // -----------------------------------------------------------------------

    fn parse_complete_command(&mut self) -> Result<Command, String> {
        self.skip_newlines();
        if self.at_eof() {
            return Ok(Command::Simple(SimpleCommand {
                assignments: vec![],
                words: vec![],
                redirects: vec![],
                lineno: self.lineno,
            }));
        }
        let list = self.parse_list()?;
        self.skip_newlines();
        Ok(list)
    }

    // -----------------------------------------------------------------------
    // List: pipeline ((;|&|&&||||newline) pipeline)*
    // -----------------------------------------------------------------------

    fn parse_list(&mut self) -> Result<Command, String> {
        let mut entries: Vec<ListEntry> = vec![];

        loop {
            self.skip_newlines();
            if self.at_eof() || self.is_list_terminator() {
                break;
            }

            let cmd = self.parse_pipeline()?;

            // `\<NL>` after a pipeline is bash whitespace — transparent.
            // It only shows up here when the pipeline ended on a compound
            // command (subshell, group, case, etc.); simple-command parsing
            // already eats LineCont internally.
            self.skip_line_conts();

            let op = match self.peek() {
                Token::Semi => {
                    self.advance();
                    ListOp::Semi
                }
                Token::Amp => {
                    self.advance();
                    ListOp::Amp
                }
                Token::AndAnd => {
                    self.advance();
                    ListOp::And
                }
                Token::OrOr => {
                    self.advance();
                    ListOp::Or
                }
                Token::Newline | Token::AliasNewline => {
                    self.advance();
                    ListOp::Newline
                }
                Token::Eof => ListOp::Last,
                _ => {
                    // Compound-command terminator or unknown – treat as last entry.
                    entries.push(ListEntry { command: cmd, op: ListOp::Last });
                    break;
                }
            };

            let done = matches!(op, ListOp::Last);
            entries.push(ListEntry { command: cmd, op });
            if done {
                break;
            }
        }

        if entries.is_empty() {
            // When a structural terminator (reserved word like do, done, fi,
            // etc.) appears where a command was expected, produce a
            // bash-compatible "syntax error near unexpected token" message.
            if self.is_list_terminator() {
                return Err(format!("syntax error near unexpected token `{}'", token_display(&self.peek())));
            }
            return Err("empty command list".into());
        }

        // Unwrap trivial single-entry list.
        if entries.len() == 1 {
            return Ok(entries.remove(0).command);
        }

        Ok(Command::List(List { entries }))
    }

    /// True when the current token is a structural terminator from an outer
    /// compound command (e.g. `fi`, `done`, `esac`, `}`, `)`).
    fn is_list_terminator(&self) -> bool {
        matches!(
            self.peek(),
            Token::Fi
                | Token::Done
                | Token::Esac
                | Token::CaseSemi
                | Token::CaseSemiAmp
                | Token::CaseSemiSemiAmp
                | Token::RBrace
                | Token::Then
                | Token::Elif
                | Token::Else
                | Token::Do
                | Token::RParen
        )
    }

    // -----------------------------------------------------------------------
    // Pipeline: [time [-p]] [!] command (| or |& command)*
    // -----------------------------------------------------------------------

    fn parse_pipeline(&mut self) -> Result<Command, String> {
        // `time` prefix
        if matches!(self.peek(), Token::Time) {
            self.advance();
            // optional `-p` flag
            let posix = if let Token::Word(ref w) = self.peek().clone() {
                if w == "-p" {
                    self.advance();
                    true
                } else {
                    false
                }
            } else {
                false
            };
            // optional `--` (end of options for time)
            if let Token::Word(ref w) = self.peek().clone() {
                if w == "--" {
                    self.advance();
                }
            }
            let inner = self.parse_pipeline()?;
            return Ok(Command::Time(posix, Box::new(inner)));
        }

        // `!` negation
        let negated = if matches!(self.peek(), Token::Bang) {
            self.advance();
            true
        } else {
            false
        };

        // After `!`, if the next token is a newline/separator/EOF/list-terminator,
        // this is a bare `!` that negates an implicit empty command (exit status
        // 0 -> 1).  We must NOT skip newlines here, or we'd accidentally swallow
        // the command on the next line.
        if negated && (matches!(self.peek(), Token::Newline | Token::AliasNewline | Token::LineCont | Token::Semi | Token::Eof)
                       || self.is_list_terminator())
        {
            let empty = Command::Simple(SimpleCommand {
                assignments: vec![],
                words: vec![],
                redirects: vec![],
                lineno: self.lineno,
            });
            return Ok(Command::Pipeline(Pipeline {
                commands: vec![empty],
                negated: true,
                pipe_stderr: vec![],
            }));
        }

        // After `!`, if the next token is `time` or another `!`, handle it
        // by recursively calling parse_pipeline so that nested `! time`,
        // `! !`, `! ! !`, etc. are parsed correctly.
        if negated && matches!(self.peek(), Token::Time | Token::Bang) {
            let inner = self.parse_pipeline()?;
            return Ok(Command::Pipeline(Pipeline {
                commands: vec![inner],
                negated: true,
                pipe_stderr: vec![],
            }));
        }

        let first = self.parse_command()?;

        let mut cmds = vec![first];
        let mut pipe_stderr_vec: Vec<bool> = Vec::new();

        loop {
            // `\<NL>` between a command and the next `|`/`|&` is whitespace.
            // Compound commands return here without consuming trailing LineCont,
            // unlike simple commands which eat it inside parse_simple_command.
            self.skip_line_conts();
            match self.peek() {
                Token::Pipe => {
                    pipe_stderr_vec.push(false);
                    self.advance();
                    self.skip_newlines();
                    cmds.push(self.parse_command()?);
                }
                Token::PipeAmp => {
                    pipe_stderr_vec.push(true);
                    self.advance();
                    self.skip_newlines();
                    cmds.push(self.parse_command()?);
                }
                _ => break,
            }
        }

        if cmds.len() == 1 && !negated {
            return Ok(cmds.remove(0));
        }

        Ok(Command::Pipeline(Pipeline {
            commands: cmds,
            negated,
            pipe_stderr: pipe_stderr_vec,
        }))
    }

    // -----------------------------------------------------------------------
    // Command dispatch
    // -----------------------------------------------------------------------

    fn parse_command(&mut self) -> Result<Command, String> {
        self.skip_newlines();

        match self.peek().clone() {
            Token::If => self.parse_if(),
            Token::While => self.parse_while(),
            Token::Until => self.parse_until(),
            Token::For => self.parse_for(),
            Token::Case => self.parse_case(),
            Token::Select => self.parse_select(),
            Token::Coproc => self.parse_coproc(),
            Token::Function => self.parse_funcdef_keyword(),
            Token::LBrace => self.parse_group(),
            Token::In
            | Token::Then
            | Token::Elif
            | Token::Else
            | Token::Fi
            | Token::Do
            | Token::Done
            | Token::Esac => Err(format!(
                "syntax error near unexpected token `{}'",
                token_display(&self.peek())
            )),
            Token::LParen => {
                // The lexer already emits Token::ArithCmd for `((expr))` (no
                // space).  Two separate LParen tokens (with whitespace between
                // them) represent nested subshells, e.g. `( (cmd) )`.
                self.parse_subshell()
            }
            Token::DoubleLBracket => self.parse_double_bracket(),
            Token::ArithCmd(s) => {
                let s = s.clone();
                let ln = self.lineno;
                self.advance();
                Ok(Command::ArithEval(s, ln))
            }
            // Bare word: may be a `name ()` function definition
            Token::Word(_)
                | Token::Concat(_)
                | Token::SingleQuoted(_)
                | Token::DoubleQuoted(_)
                | Token::ProcessSub(_) => {
                if self.is_funcdef_shorthand() {
                    self.parse_funcdef_shorthand()
                } else {
                    self.parse_simple_command()
                }
            }
            _ => self.parse_simple_command(),
        }
    }

    // -----------------------------------------------------------------------
    // `(( expr ))` arithmetic command
    // -----------------------------------------------------------------------

    fn parse_arith_cmd(&mut self) -> Result<Command, String> {
        self.expect_lparen()?; // first (
        self.expect_lparen()?; // second (
        let expr = self.collect_until_double_rparen()?;
        let redirects = self.parse_redirects()?;
        Ok(Command::Simple(SimpleCommand {
            assignments: vec![],
            words: vec![format!("(({}))", expr)],
            redirects,
            lineno: self.lineno,
        }))
    }

    /// Collect tokens until `))` (matching nested parens), return inner text.
    fn collect_until_double_rparen(&mut self) -> Result<String, String> {
        let mut parts: Vec<String> = vec![];
        let mut depth = 0i32; // extra nesting inside the expr
        loop {
            match self.peek().clone() {
                Token::Eof => return Err("unterminated (( )) expression".into()),
                Token::RParen => {
                    if matches!(self.peek_offset(1), Token::RParen) && depth == 0 {
                        self.advance(); // first )
                        self.advance(); // second )
                        break;
                    } else if depth > 0 {
                        depth -= 1;
                        parts.push(")".into());
                        self.advance();
                    } else {
                        // Single ) at depth 0 closes the expression (shouldn't
                        // normally happen in well-formed input, but handle it).
                        self.advance();
                        break;
                    }
                }
                Token::LParen => {
                    depth += 1;
                    parts.push("(".into());
                    self.advance();
                }
                tok => {
                    if let Some(w) = token_as_word(&tok) {
                        parts.push(w);
                    } else {
                        // Operators and punctuation: render them as-is
                        let s = token_punct_str(&tok);
                        parts.push(s);
                    }
                    self.advance();
                }
            }
        }
        Ok(parts.join(" "))
    }

    // -----------------------------------------------------------------------
    // `[[ … ]]` extended test command (treated as a single word)
    // -----------------------------------------------------------------------

    fn parse_double_bracket(&mut self) -> Result<Command, String> {
        let start_line = self.lineno;
        self.advance(); // consume [[
        let mut parts: Vec<String> = vec!["[[".into()];
        // Track unmatched `(` depth so EOF errors can mention `expected `)'`
        // when the user left a paren unclosed (`[[ ( -n xx`).
        let mut paren_depth: usize = 0;
        loop {
            match self.peek().clone() {
                Token::Eof => {
                    // bash 5.3 emits a TWO-line error message for an EOF
                    // inside a `[[ … ]]` construct.  Use a special marker
                    // `\x00DBRACKET_EOF\x00<start_line>\x00<first_msg>` that
                    // the c-mode printer detects and unpacks into two
                    // properly-prefixed lines.
                    //
                    // BUT: when the [[ body ends with a control-operator
                    // token (`&`, `<`, `>`, …) that bash flags as a
                    // semantic error in the cond expression, emit the
                    // three-line bash form instead — bash classifies the
                    // error based on what came before the control op.
                    let unary_ops_set: &[&str] = &[
                        "-z", "-n", "-e", "-a", "-f", "-d", "-r", "-w", "-x",
                        "-s", "-L", "-h", "-p", "-S", "-b", "-c", "-g", "-u",
                        "-k", "-O", "-G", "-N", "-t", "-v", "-R", "-o",
                    ];
                    let last = parts.last().map(|s| s.as_str()).unwrap_or("");
                    let prev = if parts.len() >= 2 {
                        parts[parts.len() - 2].as_str()
                    } else {
                        ""
                    };
                    let is_control_op = matches!(last, "&" | "|" | ";" | "<" | ">" | "&&" | "||");
                    if is_control_op {
                        // Reconstruct the original `[[ … ` text (no `]]`)
                        // for the third error line.
                        let mut reconstruction = String::from("[[");
                        for p in &parts[1..] {
                            reconstruction.push(' ');
                            reconstruction.push_str(p);
                        }
                        let msg = if unary_ops_set.contains(&prev) {
                            format!(
                                "unexpected argument `{}' to conditional unary operator",
                                last
                            )
                        } else if prev.is_empty() || prev == "[[" {
                            // Just `[[ &`: bash says "unexpected token in conditional command".
                            format!("unexpected token `{}' in conditional command", last)
                        } else {
                            format!(
                                "syntax error in conditional expression: unexpected token `{}'",
                                last
                            )
                        };
                        return Err(format!(
                            "\x00DBRACKET_TOK\x00{}\x00{}\x00{}",
                            reconstruction, last, msg
                        ));
                    }
                    if paren_depth > 0 {
                        return Err(format!(
                            "\x00DBRACKET_EOF\x00{}\x00unexpected token `EOF', expected `)'",
                            start_line
                        ));
                    }
                    return Err(format!(
                        "\x00DBRACKET_EOF\x00{}\x00unexpected EOF while looking for `]]'",
                        start_line
                    ));
                }
                Token::DoubleRBracket => {
                    self.advance();
                    parts.push("]]".into());
                    break;
                }
                Token::LParen => {
                    paren_depth += 1;
                    parts.push("(".into());
                    self.advance();
                    continue;
                }
                Token::RParen => {
                    if paren_depth > 0 { paren_depth -= 1; }
                    parts.push(")".into());
                    self.advance();
                    continue;
                }
                tok => {
                    let word_str = if let Some(w) = token_as_word(&tok) {
                        w
                    } else {
                        token_punct_str(&tok)
                    };
                    // A bare `]` (instead of `]]`) inside `[[ … ]]` is a
                    // bash syntax error.  Emit a marker `\x00DBRACKET_TOK\x00
                    // <reconstruction>\x00<offending>\x00<msg>` that the
                    // c-mode printer unpacks into bash's three-line form:
                    //   <prefix>: <msg>
                    //   <prefix>: syntax error near `<offending>'
                    //   <prefix>: `<reconstruction>'
                    //
                    // Special case: if any earlier token was a control
                    // operator (`&`/`|`/`;`/etc.), bash blames THAT
                    // token instead of the lone `]`.
                    if word_str == "]" {
                        let mut reconstruction = String::from("[[");
                        for p in &parts[1..] {
                            reconstruction.push(' ');
                            reconstruction.push_str(p);
                        }
                        reconstruction.push_str(" ]");
                        let earlier_ctl = parts[1..].iter().find(|p| {
                            matches!(p.as_str(), "&" | "|" | ";" | "&&" | "||")
                        });
                        if let Some(ctl) = earlier_ctl {
                            return Err(format!(
                                "\x00DBRACKET_TOK\x00{}\x00{}\x00syntax error in conditional expression: unexpected token `{}'",
                                reconstruction, ctl, ctl
                            ));
                        }
                        return Err(format!(
                            "\x00DBRACKET_TOK\x00{}\x00]\x00syntax error in conditional expression: unexpected token `]'",
                            reconstruction
                        ));
                    }
                    // Bash rule: after `=~`, the remainder until `]]`
                    // is all one pattern (even if it contains parens,
                    // whitespace, etc.).  Join subsequent tokens into
                    // one word with no separator.
                    let is_regex_op = word_str == "=~";
                    self.advance();
                    parts.push(word_str);
                    if is_regex_op {
                        // Collect the regex operand until ]].  Tokens
                        // are concatenated with a single space between
                        // adjacent word-like tokens so regex patterns
                        // like `(one two)` preserve their internal
                        // whitespace.  Adjacent punctuation (e.g. `(`
                        // followed by a word) is kept contiguous.
                        let mut regex = String::new();
                        let mut last_was_word = false;
                        loop {
                            match self.peek().clone() {
                                Token::Eof => return Err("unterminated [[ ]] expression".into()),
                                Token::DoubleRBracket => {
                                    self.advance();
                                    parts.push(regex);
                                    parts.push("]]".into());
                                    let redirects = self.parse_redirects()?;
                                    return Ok(Command::Simple(SimpleCommand {
                                        assignments: vec![],
                                        words: parts,
                                        redirects,
                                        lineno: self.lineno,
                                    }));
                                }
                                tok2 => {
                                    let (w2, is_word) = if let Some(w) = token_as_word(&tok2) {
                                        (w, true)
                                    } else {
                                        (token_punct_str(&tok2), false)
                                    };
                                    if last_was_word && is_word && !regex.is_empty() {
                                        regex.push(' ');
                                    }
                                    last_was_word = is_word;
                                    regex.push_str(&w2);
                                    self.advance();
                                }
                            }
                        }
                    }
                }
            }
        }
        let redirects = self.parse_redirects()?;
        Ok(Command::Simple(SimpleCommand {
            assignments: vec![],
            words: parts,
            redirects,
            lineno: self.lineno,
        }))
    }

    // -----------------------------------------------------------------------
    // Function definition shorthand:  name () compound_command [redirects]
    // -----------------------------------------------------------------------

    /// True if current token could start a function definition shorthand:
    /// a name token followed by `()`.  We accept Word, Concat, AssignWord,
    /// SingleQuoted, DoubleQuoted, and ProcessSub — bash rejects most of
    /// these at the identifier-validation stage with a clear error message,
    /// but we need to parse past them to emit that error instead of a
    /// generic syntax error.
    fn is_funcdef_shorthand(&self) -> bool {
        let name_ok = matches!(
            self.peek(),
            Token::Word(_)
                | Token::Concat(_)
                | Token::SingleQuoted(_)
                | Token::DoubleQuoted(_)
                | Token::ProcessSub(_)
        );
        name_ok
            && matches!(self.peek_offset(1), Token::LParen)
            && matches!(self.peek_offset(2), Token::RParen)
    }

    fn parse_funcdef_shorthand(&mut self) -> Result<Command, String> {
        let start_lineno = self.lineno;
        let name = match self.advance() {
            Token::Word(n) => n,
            Token::Concat(parts) => parts.join(""),
            // Preserve surrounding quotes so the runtime error message
            // matches bash's "`'a b c'': not a valid identifier" format.
            Token::SingleQuoted(s) => format!("'{}'", s),
            Token::DoubleQuoted(s) => format!("\"{}\"", s),
            Token::ProcessSub(s) => s,
            other => return Err(format!("expected function name, got {:?}", other)),
        };
        self.expect_lparen()?;
        self.expect_rparen()?;
        self.skip_newlines();
        let body = self.parse_compound_command_body()?;
        let redirects = self.parse_redirects()?;
        // Capture the line of the closing brace — bash reports this line in
        // "not a valid identifier" errors for invalid-identifier names.
        let lineno = self.lineno;
        Ok(Command::FuncDef(FuncDef {
            name,
            body: Box::new(body),
            redirects,
            start_lineno,
            lineno,
        }))
    }

    /// `function name [()] compound_command [redirects]`
    fn parse_funcdef_keyword(&mut self) -> Result<Command, String> {
        let start_lineno = self.lineno;
        self.advance(); // consume `function`
        // Bash accepts ANY word (even non-identifier) as a function name
        // when introduced by the `function` keyword: `function 11111`,
        // `function a=2`, `function sys$read`, etc.  Reconstruct a string
        // representation from whatever token the lexer produced.
        let name = match self.advance() {
            Token::Word(n) => n,
            Token::AssignWord(n, op, v) => format!("{}{}{}", n, op, v),
            Token::Concat(parts) => parts.join(""),
            other => return Err(format!("expected function name after `function`, got {:?}", other)),
        };
        // optional `()`
        if matches!(self.peek(), Token::LParen) {
            self.advance();
            if matches!(self.peek(), Token::RParen) {
                self.advance();
            } else {
                return Err(format!("expected `)` in function definition, got {:?}", self.peek()));
            }
        }
        self.skip_newlines();
        let body = self.parse_compound_command_body()?;
        let redirects = self.parse_redirects()?;
        let lineno = self.lineno;
        Ok(Command::FuncDef(FuncDef {
            name,
            body: Box::new(body),
            redirects,
            start_lineno,
            lineno,
        }))
    }

    /// Parse a compound command that forms the body of a function definition.
    fn parse_compound_command_body(&mut self) -> Result<Command, String> {
        match self.peek().clone() {
            Token::LBrace => self.parse_group(),
            Token::LParen => {
                // Two separate LParen tokens = nested subshells, not arithmetic.
                // The lexer emits Token::ArithCmd for true `((expr))`.
                self.parse_subshell()
            }
            Token::If => self.parse_if(),
            Token::While => self.parse_while(),
            Token::Until => self.parse_until(),
            Token::For => self.parse_for(),
            Token::Case => self.parse_case(),
            Token::Select => self.parse_select(),
            Token::DoubleLBracket => self.parse_double_bracket(),
            Token::ArithCmd(s) => {
                let s = s.clone();
                let ln = self.lineno;
                self.advance();
                Ok(Command::ArithEval(s, ln))
            }
            other => Err(format!("expected compound command body, got {:?}", other)),
        }
    }

    // -----------------------------------------------------------------------
    // Group  { list; }
    // -----------------------------------------------------------------------

    fn parse_group(&mut self) -> Result<Command, String> {
        let brace_open_line = self.lineno;
        self.expect(&Token::LBrace)?;
        self.skip_newlines_and_semis();
        let body = self.parse_list()?;
        self.skip_newlines_and_semis();
        if matches!(self.peek(), Token::Eof) {
            self.lineno = brace_open_line;
            return Err(format!(
                "syntax error: unexpected end of file from `{{' command on line {}",
                brace_open_line
            ));
        }
        self.expect(&Token::RBrace)?;
        let redirects = self.parse_redirects()?;
        Ok(Command::Group(GroupCmd {
            body: Box::new(body),
            redirects,
            lineno: brace_open_line,
        }))
    }

    // -----------------------------------------------------------------------
    // Subshell  ( list )
    // -----------------------------------------------------------------------

    fn parse_subshell(&mut self) -> Result<Command, String> {
        let subshell_open_line = self.lineno;
        self.expect_lparen()?;
        self.skip_newlines();
        if matches!(self.peek(), Token::Eof) {
            self.lineno = subshell_open_line;
            return Err(format!(
                "syntax error: unexpected end of file from `(' command on line {}",
                subshell_open_line
            ));
        }
        let body = match self.parse_list() {
            Ok(body) => body,
            Err(msg) if msg == "empty command list" && matches!(self.peek(), Token::Eof) => {
                self.lineno = subshell_open_line;
                return Err(format!(
                    "syntax error: unexpected end of file from `(' command on line {}",
                    subshell_open_line
                ));
            }
            Err(msg) => return Err(msg),
        };
        self.skip_newlines();
        if matches!(self.peek(), Token::Eof) {
            self.lineno = subshell_open_line;
            return Err(format!(
                "syntax error: unexpected end of file from `(' command on line {}",
                subshell_open_line
            ));
        }
        let end_lineno = self.lineno;
        self.expect_rparen()?;
        let redirects = self.parse_redirects()?;
        Ok(Command::Subshell(SubshellCmd {
            body: Box::new(body),
            redirects,
            end_lineno,
        }))
    }

    // -----------------------------------------------------------------------
    // if / then / elif / else / fi
    // -----------------------------------------------------------------------

    fn parse_if(&mut self) -> Result<Command, String> {
        let lineno = self.lineno;
        self.expect(&Token::If)?;
        self.skip_newlines();
        let condition = self.parse_list()?;
        self.skip_newlines_and_semis();
        self.expect(&Token::Then)?;
        self.skip_newlines();
        let then_body = self.parse_list()?;
        self.skip_newlines_and_semis();

        let mut elif_parts: Vec<(Command, Command)> = vec![];
        let mut else_body: Option<Box<Command>> = None;

        loop {
            match self.peek().clone() {
                Token::Elif => {
                    self.advance();
                    self.skip_newlines();
                    let cond = self.parse_list()?;
                    self.skip_newlines_and_semis();
                    self.expect(&Token::Then)?;
                    self.skip_newlines();
                    let body = self.parse_list()?;
                    self.skip_newlines_and_semis();
                    elif_parts.push((cond, body));
                }
                Token::Else => {
                    self.advance();
                    self.skip_newlines();
                    let eb = self.parse_list()?;
                    self.skip_newlines_and_semis();
                    else_body = Some(Box::new(eb));
                    break;
                }
                _ => break,
            }
        }

        if matches!(self.peek(), Token::Eof) {
            return Err(self.unexpected_eof_from("if", lineno));
        }
        self.expect(&Token::Fi)?;
        let redirects = self.parse_redirects()?;

        Ok(Command::If(IfCmd {
            condition: Box::new(condition),
            then_body: Box::new(then_body),
            elif_parts,
            else_body,
            redirects,
            lineno,
        }))
    }

    // -----------------------------------------------------------------------
    // while / until
    // -----------------------------------------------------------------------

    fn parse_while(&mut self) -> Result<Command, String> {
        let lineno = self.lineno;
        self.expect(&Token::While)?;
        self.skip_newlines();
        let condition = self.parse_list()?;
        self.skip_newlines_and_semis();
        let body = self.parse_loop_body("while", lineno)?;
        let redirects = self.parse_redirects()?;
        Ok(Command::While(WhileCmd {
            condition: Box::new(condition),
            body: Box::new(body),
            redirects,
            lineno,
        }))
    }

    fn parse_until(&mut self) -> Result<Command, String> {
        let lineno = self.lineno;
        self.expect(&Token::Until)?;
        self.skip_newlines();
        let condition = self.parse_list()?;
        self.skip_newlines_and_semis();
        let body = self.parse_loop_body("until", lineno)?;
        let redirects = self.parse_redirects()?;
        Ok(Command::Until(UntilCmd {
            condition: Box::new(condition),
            body: Box::new(body),
            redirects,
            lineno,
        }))
    }

    /// Parse a loop body in either `do ... done` or `{ ... }` form.
    fn parse_loop_body(&mut self, opener: &str, open_line: usize) -> Result<Command, String> {
        if matches!(self.peek(), Token::LBrace) {
            self.advance(); // consume `{`
            self.skip_newlines();
            let body = match self.parse_list() {
                Ok(b) => b,
                Err(msg) if msg == "empty command list" && matches!(self.peek(), Token::Eof) => {
                    // Empty body terminated by Eof — bash treats this
                    // as the unexpected `)` token (in cmdsub context
                    // exec.rs will rewrite "Eof" to ")" before display).
                    return Err("syntax error near unexpected token `Eof'".to_string());
                }
                Err(msg) => return Err(msg),
            };
            self.skip_newlines_and_semis();
            self.expect(&Token::RBrace)?;
            Ok(body)
        } else {
            self.expect(&Token::Do)?;
            self.skip_newlines();
            let body = match self.parse_list() {
                Ok(b) => b,
                Err(msg) if msg == "empty command list" && matches!(self.peek(), Token::Eof) => {
                    // `for/while/until/select … do <Eof>` — empty body
                    // hitting Eof.  In cmdsub context this is an
                    // unclosed `do` reaching the cmdsub's `)`; bash
                    // emits "syntax error near unexpected token `)`".
                    return Err("syntax error near unexpected token `Eof'".to_string());
                }
                Err(msg) => return Err(msg),
            };
            self.skip_newlines_and_semis();
            if matches!(self.peek(), Token::Eof) {
                return Err(self.unexpected_eof_from(opener, open_line));
            }
            self.expect(&Token::Done)?;
            Ok(body)
        }
    }

    // -----------------------------------------------------------------------
    // for  /  for (( ))
    // -----------------------------------------------------------------------

    fn parse_for(&mut self) -> Result<Command, String> {
        let for_lineno = self.lineno;
        self.expect(&Token::For)?;
        self.skip_newlines();

        // for (( init; cond; step )) do … done
        if matches!(self.peek(), Token::LParen) && matches!(self.peek_offset(1), Token::LParen) {
            return self.parse_arith_for(for_lineno);
        }

        // The lexer may have consumed (( expr )) as ArithCmd already
        if let Token::ArithCmd(expr) = self.peek().clone() {
            self.advance();
            return self.parse_arith_for_from_expr(&expr, for_lineno);
        }

        // Standard: for var [in words…]; do list; done
        let tok = self.advance();
        let var = match token_as_word(&tok) {
            Some(w) => w,
            None => {
                return Err(format!("syntax error near unexpected token `{}'", token_display(&tok)));
            }
        };

        self.skip_newlines();

        let words = if matches!(self.peek(), Token::In) {
            self.advance(); // consume `in`
            let mut ws: Vec<String> = vec![];
            loop {
                match self.peek().clone() {
                    Token::LineCont => {
                        self.advance();
                    }
                    Token::Newline | Token::AliasNewline | Token::Semi | Token::Do | Token::Eof => break,
                    tok => match token_as_word(&tok) {
                        Some(w) => {
                            ws.push(w);
                            self.advance();
                        }
                        None => break,
                    },
                }
            }
            Some(ws)
        } else {
            // No `in` clause → iterate over "$@"
            None
        };

        self.skip_newlines_and_semis();
        // Bash accepts both `do … done` and `{ … }` for the body.
        let body = if matches!(self.peek(), Token::LBrace) {
            self.advance(); // consume `{`
            self.skip_newlines();
            let b = self.parse_list()?;
            self.skip_newlines_and_semis();
            self.expect(&Token::RBrace)?;
            b
        } else {
            self.expect(&Token::Do)?;
            self.skip_newlines();
            let b = match self.parse_list() {
                Ok(b) => b,
                Err(msg) if msg == "empty command list" && matches!(self.peek(), Token::Eof) => {
                    // `for … do <Eof>` (e.g. `: $(for z in 1 2 3; do )`)
                    // — empty body hitting Eof.  In cmdsub context exec.rs
                    // rewrites Eof to `)` for display.
                    return Err("syntax error near unexpected token `Eof'".to_string());
                }
                Err(msg) => return Err(msg),
            };
            self.skip_newlines_and_semis();
            if matches!(self.peek(), Token::Eof) {
                return Err(self.unexpected_eof_from("for", for_lineno));
            }
            self.expect(&Token::Done)?;
            b
        };
        let redirects = self.parse_redirects()?;

        Ok(Command::For(ForCmd {
            var,
            words,
            body: Box::new(body),
            redirects,
            lineno: for_lineno,
        }))
    }

    fn parse_arith_for(&mut self, lineno: usize) -> Result<Command, String> {
        self.expect_lparen()?; // first  (
        self.expect_lparen()?; // second (
        let init = self.collect_arith_until_semi()?;
        let cond = self.collect_arith_until_semi()?;
        let step = self.collect_arith_until_dparen()?;
        self.skip_newlines_and_semis();
        // Accept either do...done or { ... }
        let use_braces = matches!(self.peek(), Token::LBrace);
        if use_braces {
            self.advance(); // consume {
        } else {
            self.expect(&Token::Do)?;
        }
        self.skip_newlines();
        let body = self.parse_list()?;
        self.skip_newlines_and_semis();
        if use_braces {
            self.expect(&Token::RBrace)?;
        } else {
            self.expect(&Token::Done)?;
        }
        let redirects = self.parse_redirects()?;
        Ok(Command::ArithFor(ArithForCmd {
            init,
            cond,
            step,
            body: Box::new(body),
            redirects,
            lineno,
        }))
    }

    /// Parse arithmetic for-loop when the lexer already consumed (( expr )) as ArithCmd.
    /// The expr contains "init; cond; step".
    fn parse_arith_for_from_expr(&mut self, expr: &str, lineno: usize) -> Result<Command, String> {
        let [init, cond, step] = split_arith_for_clauses(expr).map_err(|msg| {
            if msg == "syntax error: arithmetic expression required" {
                format!(
                    "syntax error: arithmetic expression required\nsyntax error: `(( {} ))'",
                    expr.trim()
                )
            } else if msg == "syntax error near unexpected token `;'" {
                format!(
                    "syntax error: `;' unexpected\nsyntax error: `(( {} ))'",
                    expr.trim()
                )
            } else {
                msg
            }
        })?;

        self.skip_newlines_and_semis();
        // Accept either do...done or { ... }
        let use_braces = matches!(self.peek(), Token::LBrace);
        if use_braces {
            self.advance(); // consume {
        } else {
            self.expect(&Token::Do)?;
        }
        self.skip_newlines();
        let body = self.parse_list()?;
        self.skip_newlines_and_semis();
        if use_braces {
            self.expect(&Token::RBrace)?;
        } else {
            self.expect(&Token::Done)?;
        }
        let redirects = self.parse_redirects()?;
        Ok(Command::ArithFor(ArithForCmd {
            init,
            cond,
            step,
            body: Box::new(body),
            redirects,
            lineno,
        }))
    }

    /// Collect tokens into a string until an unparenthesised `;` (consumed).
    fn collect_arith_until_semi(&mut self) -> Result<String, String> {
        let mut parts: Vec<String> = vec![];
        let mut depth = 0i32;
        loop {
            match self.peek().clone() {
                Token::Eof => return Err("unterminated arithmetic for expression".into()),
                Token::Semi if depth == 0 => {
                    self.advance();
                    break;
                }
                Token::LParen => {
                    depth += 1;
                    parts.push("(".into());
                    self.advance();
                }
                Token::RParen if depth > 0 => {
                    depth -= 1;
                    parts.push(")".into());
                    self.advance();
                }
                // In arithmetic context, quotes are stripped (bash semantics).
                Token::DoubleQuoted(s) => {
                    parts.push(s.clone());
                    self.advance();
                }
                Token::SingleQuoted(s) => {
                    parts.push(s.clone());
                    self.advance();
                }
                tok => {
                    if let Some(w) = token_as_word(&tok) {
                        parts.push(w);
                    } else {
                        parts.push(token_punct_str(&tok));
                    }
                    self.advance();
                }
            }
        }
        Ok(parts.join(" "))
    }

    /// Collect tokens into a string until an unparenthesised `))` (consumed).
    fn collect_arith_until_dparen(&mut self) -> Result<String, String> {
        let mut parts: Vec<String> = vec![];
        let mut depth = 0i32;
        loop {
            match self.peek().clone() {
                Token::Eof => return Err("unterminated arithmetic for expression".into()),
                Token::RParen => {
                    if depth == 0 && matches!(self.peek_offset(1), Token::RParen) {
                        self.advance(); // first )
                        self.advance(); // second )
                        break;
                    } else if depth > 0 {
                        depth -= 1;
                        parts.push(")".into());
                        self.advance();
                    } else {
                        // Single ) at depth 0 – shouldn't normally occur.
                        self.advance();
                        break;
                    }
                }
                Token::LParen => {
                    depth += 1;
                    parts.push("(".into());
                    self.advance();
                }
                // In arithmetic context, quotes are stripped (bash semantics).
                Token::DoubleQuoted(s) => {
                    parts.push(s.clone());
                    self.advance();
                }
                Token::SingleQuoted(s) => {
                    parts.push(s.clone());
                    self.advance();
                }
                tok => {
                    if let Some(w) = token_as_word(&tok) {
                        parts.push(w);
                    } else {
                        parts.push(token_punct_str(&tok));
                    }
                    self.advance();
                }
            }
        }
        Ok(parts.join(" "))
    }

    // -----------------------------------------------------------------------
    // case / in / ;; / ;& / ;;& / esac
    // -----------------------------------------------------------------------

    fn parse_case(&mut self) -> Result<Command, String> {
        let case_lineno = self.lineno;
        self.expect(&Token::Case)?;
        self.skip_newlines();

        // The word after `case`
        let word = {
            let tok = self.advance();
            token_as_word(&tok)
                .ok_or_else(|| format!("expected word after `case`, got {:?}", tok))?
        };

        self.skip_newlines();
        self.expect(&Token::In)?;
        self.skip_newlines();

        let mut arms: Vec<CaseArm> = vec![];
        loop {
            self.skip_newlines();
            if matches!(self.peek(), Token::Esac | Token::Eof) {
                break;
            }
            arms.push(self.parse_case_arm()?);
        }

        if matches!(self.peek(), Token::Eof) {
            return Err(self.unexpected_eof_from("case", case_lineno));
        }
        self.expect(&Token::Esac)?;
        let redirects = self.parse_redirects()?;

        Ok(Command::Case(CaseCmd {
            word,
            arms,
            redirects,
            lineno: case_lineno,
        }))
    }

    fn parse_case_arm(&mut self) -> Result<CaseArm, String> {
        let arm_lineno = self.lineno;
        // Optional leading `(`
        if matches!(self.peek(), Token::LParen) {
            self.advance();
        }

        // One or more patterns separated by `|`.  A `\<NL>` may appear between
        // patterns or around the `|` separator — it is transparent whitespace.
        let mut patterns: Vec<String> = vec![];
        loop {
            self.skip_line_conts();
            let tok = self.advance();
            let pat = token_as_word(&tok)
                .ok_or_else(|| format!("expected pattern in case arm, got {:?}", tok))?;
            patterns.push(pat);
            self.skip_line_conts();
            if matches!(self.peek(), Token::Pipe) {
                self.advance();
            } else {
                break;
            }
        }

        if matches!(self.peek(), Token::RParen) {
            self.advance();
        } else {
            return Err(format!(
                "expected `)` after case pattern, got {:?}",
                self.peek()
            ));
        }

        self.skip_newlines();

        // Body is optional (e.g., `pat) ;;`)
        let body = if matches!(
            self.peek(),
            Token::CaseSemi | Token::CaseSemiAmp | Token::CaseSemiSemiAmp | Token::Esac
        ) {
            None
        } else {
            Some(Box::new(self.parse_list()?))
        };

        self.skip_newlines();

        let terminator = match self.peek() {
            Token::CaseSemi => {
                self.advance();
                CaseTerminator::Break
            }
            Token::CaseSemiAmp => {
                self.advance();
                CaseTerminator::FallThrough
            }
            Token::CaseSemiSemiAmp => {
                self.advance();
                CaseTerminator::Continue
            }
            Token::Esac => CaseTerminator::Break, // no explicit ;; before esac
            _ => CaseTerminator::Break,
        };

        self.skip_newlines();

        Ok(CaseArm {
            patterns,
            body,
            terminator,
            lineno: arm_lineno,
        })
    }

    // -----------------------------------------------------------------------
    // select  select var [in words]; do list; done
    // -----------------------------------------------------------------------

    fn parse_select(&mut self) -> Result<Command, String> {
        let select_lineno = self.lineno;
        self.expect(&Token::Select)?;
        self.skip_newlines();

        // Accept any word-like token; identifier validity is checked
        // at execution time so the error message matches bash's format.
        let tok = self.advance();
        let var = match token_as_word(&tok) {
            Some(w) => w,
            None => return Err(format!("syntax error near unexpected token `{}'", token_display(&tok))),
        };

        self.skip_newlines();

        let words = if matches!(self.peek(), Token::In) {
            self.advance();
            let mut ws: Vec<String> = vec![];
            loop {
                match self.peek().clone() {
                    Token::LineCont => {
                        self.advance();
                    }
                    Token::Newline | Token::AliasNewline | Token::Semi | Token::Do | Token::Eof => break,
                    tok => match token_as_word(&tok) {
                        Some(w) => {
                            ws.push(w);
                            self.advance();
                        }
                        None => break,
                    },
                }
            }
            Some(ws)
        } else {
            None
        };

        self.skip_newlines_and_semis();
        let body = self.parse_loop_body("select", select_lineno)?;
        let redirects = self.parse_redirects()?;

        Ok(Command::Select(SelectCmd {
            var,
            words,
            body: Box::new(body),
            redirects,
            lineno: select_lineno,
        }))
    }

    // -----------------------------------------------------------------------
    // coproc  coproc [NAME] command
    // -----------------------------------------------------------------------

    fn parse_coproc(&mut self) -> Result<Command, String> {
        let coproc_lineno = self.lineno;
        self.expect(&Token::Coproc)?;
        self.skip_newlines();

        // Optional name: a plain word that is followed by another command starter
        // (i.e. it is NOT the command itself).
        let name = if let Token::Word(ref w) = self.peek().clone() {
            let w = w.clone();
            // A word is only the coproc NAME if it is followed by a compound
            // command keyword.  `coproc cmd arg ...` is a simple command with
            // name defaulting to COPROC, NOT name=cmd body=arg.
            let next = self.peek_offset(1);
            let next_is_compound = matches!(
                next,
                Token::LBrace
                    | Token::LParen
                    | Token::If
                    | Token::While
                    | Token::Until
                    | Token::For
                    | Token::Case
                    | Token::Select
            );
            // Parse the optional name loosely and let execution-time
            // validation decide whether it is a legal variable name.
            // Bash accepts `coproc @ { ... }` syntactically and reports
            // the invalid identifier at runtime instead of here.
            if next_is_compound {
                self.advance();
                Some(w)
            } else {
                None
            }
        } else {
            None
        };

        let body = self.parse_command()?;
        Ok(Command::Coproc(CoprocCmd {
            name,
            body: Box::new(body),
            lineno: coproc_lineno,
        }))
    }

    // -----------------------------------------------------------------------
    // Simple command:  [assignments…] [word…] [redirect…]  (interleaved)
    // -----------------------------------------------------------------------

    fn parse_simple_command(&mut self) -> Result<Command, String> {
        let cmd_lineno = self.lineno;
        let mut assignments: Vec<Assignment> = vec![];
        let mut words: Vec<String> = vec![];
        let mut redirects: Vec<Redirect> = vec![];

        loop {
            if matches!(self.peek(), Token::LineCont) {
                self.advance();
                continue;
            }
            // Redirects may appear anywhere in a simple command.
            if is_redirect(self.peek()) {
                redirects.push(self.parse_one_redirect()?);
                continue;
            }

            match self.peek().clone() {
                // Assignments only valid before any non-assignment word.
                Token::AssignWord(name, op, val) if words.is_empty() => {
                    self.advance();
                    let append = op == "+=";
                    assignments.push(Assignment {
                        name,
                        value: val,
                        append,
                        export: false,
                    });
                }
                Token::AssignWord(name, op, val) => {
                    if val.starts_with("\x00ARRAY\x00") {
                        match compound_assign_arg_mode(&words) {
                            "encoded" => {
                                words.push(format!("{}{}{}", name, op, val));
                                self.advance();
                            }
                            "raw" => {
                                words.push(decode_compound_assign_word(&name, &op, &val));
                                self.advance();
                            }
                            _ => {
                                return Err("syntax error near unexpected token `('".to_string());
                            }
                        }
                    } else {
                        words.push(format!("{}{}{}", name, op, val));
                        self.advance();
                    }
                }
                tok => {
                    // Stop on separators, pipe, or compound-command terminators.
                    if is_separator(&tok)
                        || matches!(tok, Token::Pipe | Token::PipeAmp)
                    {
                        break;
                    }
                    // List terminators only stop us when we haven't started
                    // collecting words — in argument position, reserved words
                    // like `done`, `fi`, `esac` are just regular strings.
                    if words.is_empty() && assignments.is_empty() && self.is_list_terminator() {
                        break;
                    }
                    match token_as_word(&tok) {
                        Some(w) => {
                            words.push(w);
                            self.advance();
                        }
                        None => break, // Unknown token – stop.
                    }
                }
            }
        }

        // Collect any trailing redirects.
        while is_redirect(self.peek()) {
            redirects.push(self.parse_one_redirect()?);
        }

        Ok(Command::Simple(SimpleCommand {
            assignments,
            words,
            redirects,
            lineno: cmd_lineno,
        }))
    }

    // -----------------------------------------------------------------------
    // Redirections
    // -----------------------------------------------------------------------

    fn parse_redirects(&mut self) -> Result<Vec<Redirect>, String> {
        let mut result = vec![];
        while is_redirect(self.peek()) {
            result.push(self.parse_one_redirect()?);
        }
        Ok(result)
    }

    fn parse_one_redirect(&mut self) -> Result<Redirect, String> {
        let lineno = self.lineno;
        match self.advance() {
            Token::Redirect(info) => Ok(Redirect {
                fd: info.fd,
                op: info.op,
                target: info.target,
                heredoc_quoted: false,
                heredoc_delimiter: None,
                varfd: info.varfd,
                lineno,
            }),
            Token::HereDoc(info) => Ok(Redirect {
                fd: info.fd,
                op: if info.strip_tabs {
                    crate::lexer::RedirectOp::HeredocStrip
                } else {
                    crate::lexer::RedirectOp::Heredoc
                },
                heredoc_quoted: info.quoted,
                // The lexer pre-fills the heredoc content in HereDocInfo::content.
                target: info.content,
                heredoc_delimiter: Some(info.delimiter),
                varfd: info.varfd,
                lineno,
            }),
            other => Err(format!("expected redirect token, got {:?}", other)),
        }
    }
}

// ---------------------------------------------------------------------------
// Helper: render a punctuation/operator token as a string (for arith exprs
// and [[ ]] where we reconstruct source text).
// ---------------------------------------------------------------------------

/// In arithmetic contexts, bash strips surrounding double or single quotes
/// from an expression (e.g. `"i < 3"` becomes `i < 3`).
/// The input `s` should already have leading whitespace stripped; this
/// function preserves trailing whitespace (bash shows it in error messages).
fn arith_strip_quotes(s: &str) -> String {
    // Only strip leading+trailing whitespace temporarily to check for quotes.
    let trimmed = s.trim();
    if trimmed.len() >= 2 {
        if (trimmed.starts_with('"') && trimmed.ends_with('"'))
            || (trimmed.starts_with('\'') && trimmed.ends_with('\''))
        {
            return trimmed[1..trimmed.len() - 1].to_string();
        }
    }
    // Return original (with trailing space preserved for error display).
    s.to_string()
}

fn split_arith_for_clauses(expr: &str) -> Result<[String; 3], String> {
    let chars: Vec<char> = expr.chars().collect();
    let mut clauses: Vec<String> = Vec::new();
    let mut cur = String::new();
    let mut paren_depth = 0i32;
    let mut bracket_depth = 0i32;
    let mut brace_depth = 0i32;
    let mut i = 0usize;

    while i < chars.len() {
        let ch = chars[i];
        if ch == '\\' {
            cur.push(ch);
            if i + 1 < chars.len() {
                cur.push(chars[i + 1]);
                i += 2;
            } else {
                i += 1;
            }
            continue;
        }
        if ch == '\'' || ch == '"' {
            let quote = ch;
            cur.push(ch);
            i += 1;
            while i < chars.len() {
                cur.push(chars[i]);
                if chars[i] == '\\' && quote == '"' && i + 1 < chars.len() {
                    cur.push(chars[i + 1]);
                    i += 2;
                    continue;
                }
                if chars[i] == quote {
                    i += 1;
                    break;
                }
                i += 1;
            }
            continue;
        }
        if ch == '`' {
            cur.push(ch);
            i += 1;
            while i < chars.len() {
                cur.push(chars[i]);
                if chars[i] == '\\' && i + 1 < chars.len() {
                    cur.push(chars[i + 1]);
                    i += 2;
                    continue;
                }
                if chars[i] == '`' {
                    i += 1;
                    break;
                }
                i += 1;
            }
            continue;
        }
        if ch == '$' && i + 1 < chars.len() {
            if chars[i + 1] == '{' {
                let start = i;
                let mut depth = 1usize;
                i += 2;
                while i < chars.len() && depth > 0 {
                    if chars[i] == '\\' {
                        i += 2;
                        continue;
                    }
                    if chars[i] == '\'' || chars[i] == '"' || chars[i] == '`' {
                        let quote = chars[i];
                        i += 1;
                        while i < chars.len() {
                            if chars[i] == '\\' && quote != '\'' && i + 1 < chars.len() {
                                i += 2;
                                continue;
                            }
                            if chars[i] == quote {
                                i += 1;
                                break;
                            }
                            i += 1;
                        }
                        continue;
                    }
                    if chars[i] == '$' && i + 1 < chars.len() && chars[i + 1] == '{' {
                        depth += 1;
                        i += 2;
                        continue;
                    }
                    if chars[i] == '}' {
                        depth -= 1;
                        i += 1;
                        continue;
                    }
                    i += 1;
                }
                cur.push_str(&chars[start..i.min(chars.len())].iter().collect::<String>());
                continue;
            }
            if chars[i + 1] == '(' {
                let start = i;
                let mut depth = 1i32;
                i += 2;
                while i < chars.len() && depth > 0 {
                    if chars[i] == '\\' {
                        i += 2;
                        continue;
                    }
                    if chars[i] == '\'' || chars[i] == '"' || chars[i] == '`' {
                        let quote = chars[i];
                        i += 1;
                        while i < chars.len() {
                            if chars[i] == '\\' && quote != '\'' && i + 1 < chars.len() {
                                i += 2;
                                continue;
                            }
                            if chars[i] == quote {
                                i += 1;
                                break;
                            }
                            i += 1;
                        }
                        continue;
                    }
                    if chars[i] == '$' && i + 1 < chars.len() && chars[i + 1] == '(' {
                        depth += 1;
                        i += 2;
                        continue;
                    }
                    if chars[i] == '(' {
                        depth += 1;
                        i += 1;
                        continue;
                    }
                    if chars[i] == ')' {
                        depth -= 1;
                        i += 1;
                        continue;
                    }
                    i += 1;
                }
                cur.push_str(&chars[start..i.min(chars.len())].iter().collect::<String>());
                continue;
            }
        }
        match ch {
            '(' => paren_depth += 1,
            ')' if paren_depth > 0 => paren_depth -= 1,
            '[' => bracket_depth += 1,
            ']' if bracket_depth > 0 => bracket_depth -= 1,
            '{' => brace_depth += 1,
            '}' if brace_depth > 0 => brace_depth -= 1,
            ';' if paren_depth == 0 && bracket_depth == 0 && brace_depth == 0 => {
                if clauses.len() == 2 {
                    return Err("syntax error near unexpected token `;'".to_string());
                }
                clauses.push(arith_strip_quotes(cur.trim_start()));
                cur.clear();
                i += 1;
                continue;
            }
            _ => {}
        }
        cur.push(ch);
        i += 1;
    }

    clauses.push(arith_strip_quotes(cur.trim_start()));
    if clauses.len() != 3 {
        return Err("syntax error: arithmetic expression required".to_string());
    }
    Ok([
        clauses.remove(0),
        clauses.remove(0),
        clauses.remove(0),
    ])
}

fn token_punct_str(tok: &Token) -> String {
    use crate::lexer::RedirectOp;
    match tok {
        Token::Semi => ";".into(),
        Token::Amp => "&".into(),
        Token::AndAnd => "&&".into(),
        Token::OrOr => "||".into(),
        Token::Pipe => "|".into(),
        Token::PipeAmp => "|&".into(),
        Token::Bang => "!".into(),
        Token::LParen => "(".into(),
        Token::RParen => ")".into(),
        Token::LBrace => "{".into(),
        Token::RBrace => "}".into(),
        Token::Newline | Token::AliasNewline | Token::LineCont => " ".into(),
        Token::Redirect(info) => {
            // Reconstruct a reasonable text form — used when a
            // Redirect token appears inside `[[ ... ]]`, e.g.
            // `[[ $b > 7 ]]` where `>` is actually a string-compare
            // operator (bash reads it literally inside the brackets).
            let op = match info.op {
                RedirectOp::Input => "<",
                RedirectOp::Output => ">",
                RedirectOp::Append => ">>",
                RedirectOp::InputOutput => "<>",
                RedirectOp::InputDup => "<&",
                RedirectOp::OutputDup => ">&",
                RedirectOp::Clobber => ">|",
                RedirectOp::AndOutput => "&>",
                RedirectOp::AndAppend => "&>>",
                RedirectOp::HereString => "<<<",
                RedirectOp::Heredoc | RedirectOp::HeredocStrip => "<<",
            };
            // We treat `[[ A > B ]]` as two separate words "A", ">",
            // "B", so emit just the operator; the body side will be a
            // subsequent Word token in most cases.  If the Redirect
            // carries a target, append it so callers that pass the
            // whole thing through word-like expansion still see it.
            let target = &info.target;
            if target.is_empty() {
                op.to_string()
            } else {
                format!("{} {}", op, target)
            }
        }
        other => format!("{:?}", other),
    }
}

#[cfg(test)]
mod tests {
    use super::parse;
    use crate::lexer::tokenize_with_warnings;

    #[test]
    fn parse_error_lineno_for_unclosed_subshell_uses_opener_line() {
        let input = "echo one\n(cat\n";
        let result = tokenize_with_warnings(input);
        let err = parse(result.tokens).unwrap_err();
        assert_eq!(err.lineno, 2);
        assert_eq!(
            err.message,
            "syntax error: unexpected end of file from `(' command on line 2"
        );
    }

    #[test]
    fn parse_error_lineno_after_cmdsub_heredoc_matches_source() {
        let input = "text=$(cat <<EOF2\nhere is the text\nEOF2)\necho = \"$text\" =\n(cat\n";
        let result = tokenize_with_warnings(input);
        assert!(result.comsub_eof_errors.is_empty());
        let err = parse(result.tokens).unwrap_err();
        assert_eq!(err.lineno, 5);
        assert_eq!(
            err.message,
            "syntax error: unexpected end of file from `(' command on line 5"
        );
    }

    #[test]
    fn parse_error_lineno_counts_physical_heredoc_lines() {
        let input = "cat <<END\nhello\\\nEND\nEND\n(cat\n";
        let result = tokenize_with_warnings(input);
        let err = parse(result.tokens).unwrap_err();
        assert_eq!(err.lineno, 5);
        assert_eq!(
            err.message,
            "syntax error: unexpected end of file from `(' command on line 5"
        );
    }
}
