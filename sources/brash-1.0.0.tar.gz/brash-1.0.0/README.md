# brash

`brash` is a Bash-compatible shell written in Rust.

The goal is straightforward: run real Bash scripts and interactive sessions with behavior close enough to GNU Bash 5.3 that the upstream Bash test suite is useful as the compatibility target.

This is not a wrapper around an existing shell parser or executor. The lexer, parser, expansion engine, variable model, and executor all live in this repo.

## Current shape

The current tree already covers a large chunk of the shell surface:

- interactive and non-interactive execution (`-c`, `-s`, script files, login shell mode)
- Bash-style quoting, here-documents, command substitution, arithmetic expansion, and process substitution
- pipelines, lists, compound commands, functions, redirections, subshells, and job-control plumbing
- shell variables with scopes, arrays, associative arrays, attributes, and exported function import
- a broad builtin set including `printf`, `test`, `read`, `declare`, `export`, `trap`, `set`, `shopt`, `mapfile`, and `compgen`
- traps, history support, and Bash-style prompt expansion

It is still under active compatibility work. The target is Bash 5.3 behavior, not a POSIX-only subset.

## Repo layout

- `src/lexer.rs` - tokenization, quoting, here-doc collection, command/arithmetic substitution, process substitution
- `src/parser.rs` - recursive-descent parser for pipelines, lists, compounds, and function definitions
- `src/expand.rs` - brace, tilde, parameter, command, arithmetic, word-splitting, and pathname expansion
- `src/exec.rs` - command execution, pipelines, redirections, subshells, signals, and shell runtime state
- `src/builtins.rs` - builtin command implementations and shell options
- `src/vars.rs` - scoped variables, arrays, associative arrays, and attributes
- `src/arithmetic.rs` - arithmetic parser/evaluator
- `src/trap.rs` - trap and signal handling
- `src/history.rs` - interactive history support
- `scripts/install-alpine-runtime.sh` - fetch a minimal Alpine runtime with GNU Bash and test dependencies
- `scripts/run-bash-tests.sh` - build upstream Bash and run its official test suite against `brash`
- `scripts/run-bash-tests-docker.sh` - Docker-oriented wrapper for the same suite
- `recipe.toml` - jonerix packaging recipe

## Build

```sh
cargo build --release
./target/release/brash --version
```

You can also use the `Makefile` targets:

```sh
make build
make source-tarball
make jpkg
```

`make install` installs `brash` and creates `bash` and `rash` symlinks that point at the same binary.

## Running

Examples:

```sh
./target/release/brash -c 'printf "%s\n" "$BASH_VERSION"'

./target/release/brash script.sh arg1 arg2

./target/release/brash -s one "two three" <<'EOF'
printf '%s/%s\n' "$1" "$2"
EOF
```

## Testing

Rust unit tests:

```sh
cargo test
```

Upstream Bash test suite:

```sh
./scripts/install-alpine-runtime.sh
./scripts/run-bash-tests.sh
```

Or in Docker:

```sh
./scripts/run-bash-tests-docker.sh
```

The bash-suite helpers are executable scripts with their own shebangs. Run them directly rather than forcing them through `sh`.

## Status

`brash` is well beyond the "toy shell" stage, but it is not done. The compatibility target is explicit and the remaining work is normal Bash edge-case cleanup, not basic shell bring-up.

On the current tree, `cargo test` still reports two failing unit tests:

- `arithmetic::tests::test_bitwise`
- `lexer::tests::test_herestring`

`TODO.md` tracks the next major goal at a high level: keep pushing toward broader Bash test-suite coverage.

## License

MIT. See [LICENSE](LICENSE).
