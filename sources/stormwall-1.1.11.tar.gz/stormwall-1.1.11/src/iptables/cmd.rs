// (c) 2026 Jon-Erik G. Storm, Inc., a California Corporation,
// doing business as LAVA GOAT SOFTWARE.  MIT license.
//
// IptCmd: parsed representation of one `iptables`-style invocation.
//
// We keep the surface deliberately flat: a single struct that holds
// every option an iptables command can carry. The parser fills in
// what was given, the lowerer translates that into one or more nft
// commands. This mirrors the way iptables(8) is documented as a flat
// flag set in the manpage and the way real iptables internally does
// `do_command4 -> command_match` — one giant struct, lots of optional
// fields, dispatch in the lowerer.
//
// Clean room: types and field names follow the iptables(8) manpage
// (e.g. `--src`, `--sport`) and the kernel's xt_match/xt_target ABI
// names that are public API. No source code from xtables-addons or
// iptables itself was consulted.

use std::fmt;

/// The top-level operation: append, insert, delete, etc.
///
/// One `IptCmd` carries exactly one operation. Multi-rule invocations
/// (e.g. `iptables -F` flushing every chain) decompose into a sequence
/// of `IptCmd`s before lowering — keeping the per-command shape simple.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum IptOp {
    /// `-A <chain>` — append rule to end of chain.
    Append,
    /// `-I <chain> [<n>]` — insert rule at 1-based position N (default 1).
    Insert(u32),
    /// `-D <chain> <n>` — delete by 1-based rule number.
    DeleteNum(u32),
    /// `-D <chain> <rule-spec>` — delete first rule matching the spec.
    DeleteMatch,
    /// `-R <chain> <n>` — replace 1-based rule N with the new spec.
    Replace(u32),
    /// `-L [<chain>]` — list rules. `chain` is empty when no chain given.
    List,
    /// `-S [<chain>]` — print rules in restore format.
    Save,
    /// `-F [<chain>]` — flush. `chain` empty means flush every chain in the table.
    Flush,
    /// `-X [<chain>]` — delete user-defined chain. Empty means every empty user chain.
    DeleteChain,
    /// `-N <chain>` — create a new user-defined chain.
    NewChain,
    /// `-Z [<chain>]` — zero packet/byte counters.
    Zero,
    /// `-C <chain>` — check if rule matching the spec exists.
    Check,
    /// `-P <chain> <target>` — set policy on a built-in chain.
    Policy,
    /// `-E old-chain new-chain` — rename a user chain. The new name
    /// rides on the IptCmd via `policy_target` (reuse the auxiliary
    /// string slot rather than introducing a new field).
    Rename,
}

/// The five built-in iptables tables. Each maps 1:1 to an nft table
/// of the same name in family `ip` (iptables) or `ip6` (ip6tables).
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum IptTable {
    Filter,
    Nat,
    Mangle,
    Raw,
    Security,
}

impl IptTable {
    pub fn from_str_opt(s: &str) -> Option<Self> {
        Some(match s {
            "filter"   => IptTable::Filter,
            "nat"      => IptTable::Nat,
            "mangle"   => IptTable::Mangle,
            "raw"      => IptTable::Raw,
            "security" => IptTable::Security,
            _ => return None,
        })
    }
    pub fn name(self) -> &'static str {
        match self {
            IptTable::Filter   => "filter",
            IptTable::Nat      => "nat",
            IptTable::Mangle   => "mangle",
            IptTable::Raw      => "raw",
            IptTable::Security => "security",
        }
    }
}

impl fmt::Display for IptTable {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{}", self.name())
    }
}

impl Default for IptTable {
    fn default() -> Self { IptTable::Filter }
}

/// L3 family. `Ip` for `iptables`, `Ip6` for `ip6tables`. Affects
/// table family in the lowering and a few payload offsets (the
/// per-protocol header parser).
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Family {
    Ip,
    Ip6,
}

impl Family {
    pub fn nft_family(self) -> &'static str {
        match self { Family::Ip => "ip", Family::Ip6 => "ip6" }
    }
}

/// A network address with optional prefix length. Used for `-s` /
/// `-d` and SNAT/DNAT/`--to-source` etc. We carry the original string
/// alongside the parsed bytes so the renderer (iptables-save output,
/// `-L` output) can reproduce the user's input verbatim — iptables
/// itself behaves that way and the framework round-trip tests rely on
/// it.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct AddrSpec {
    pub raw: String,
    pub family: Family,
    /// Negated with leading `!`.
    pub neg: bool,
}

/// Parsed `--sport` / `--dport` value: a single port or a range.
/// iptables accepts `start:end`, omitted-start (`:end` = 0..end),
/// omitted-end (`start:` = start..65535) and bare `port`.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct PortRange { pub start: u16, pub end: u16 }

impl PortRange {
    pub fn single(p: u16) -> Self { PortRange { start: p, end: p } }
}

/// A multiport list — `-m multiport --dports 22,80,443,1000:2000`.
/// Each entry is either a single port or a range.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct MultiportList {
    pub items: Vec<PortRange>,
    pub neg: bool,
}

/// Conntrack state set: NEW, ESTABLISHED, RELATED, INVALID,
/// UNTRACKED, DNAT, SNAT. We store as a vector of strings to round-
/// trip exactly; the lowerer maps them to nft `ct state` keywords.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct StateSet {
    pub names: Vec<String>,
    pub neg: bool,
}

/// `-m limit --limit RATE --limit-burst N`.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct LimitOpt {
    pub rate: u64,        // numerator
    pub unit: String,     // "second", "minute", "hour", "day"
    pub burst: u32,
}

/// `-j TARGET [args...]` — terminal action.
///
/// We split the well-known iptables targets into named variants so the
/// lowerer can produce the exact nft form. Anything else (including
/// jumps to user chains) lands in `Jump(name)` — the lowerer treats
/// it as `jump <name>` if the chain exists, otherwise emits an error.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum Target {
    Accept,
    Drop,
    Return,
    /// Jump to a user chain or another built-in. Stores the raw name.
    Jump(String),
    /// REJECT, optionally with `--reject-with <type>`. Type strings
    /// pass through to the lowerer untouched (e.g. "icmp-port-unreachable").
    Reject(Option<String>),
    /// LOG, with optional `--log-prefix <s>` / `--log-level <n>` and
    /// the four boolean modifiers `--log-tcp-sequence`,
    /// `--log-tcp-options`, `--log-ip-options`, `--log-uid`. The
    /// boolean flags lower to nft `log flags tcp sequence,options`,
    /// `log flags ip options`, and (for uid) `comment "log-uid"` —
    /// nft has no first-class log-uid token, so we record the user
    /// intent via comment and pass otherwise through.
    Log {
        prefix: Option<String>,
        level: Option<u8>,
        tcp_sequence: bool,
        tcp_options: bool,
        ip_options: bool,
        log_uid: bool,
    },
    /// MASQUERADE [--to-ports START[-END]] [--random] [--random-fully].
    Masquerade { to_ports: Option<PortRange>, random: bool, random_fully: bool },
    /// SNAT --to-source ADDR[-ADDR][:PORT[-PORT]] [--random] [--random-fully] [--persistent].
    Snat { to_source: String, random: bool, random_fully: bool, persistent: bool },
    /// DNAT --to-destination ADDR[-ADDR][:PORT[-PORT]] [--random] [--random-fully] [--persistent].
    Dnat { to_destination: String, random: bool, random_fully: bool, persistent: bool },
    /// REDIRECT --to-ports START[-END] [--random].
    Redirect { to_ports: Option<PortRange>, random: bool },
    /// MARK --set-mark VALUE[/MASK] / --set-xmark / --or-mark / --and-mark / --xor-mark.
    Mark { kind: MarkKind, value: u32, mask: Option<u32> },
    /// CONNMARK --set-mark / --save-mark / --restore-mark / --and-mark / --or-mark / --xor-mark.
    Connmark(ConnmarkOp),
    /// TPROXY --on-port <p> [--on-ip <a>] [--tproxy-mark v[/m]].
    Tproxy { on_port: Option<u16>, on_ip: Option<String>, mark: Option<(u32, Option<u32>)> },
    /// NFLOG [--nflog-prefix s] [--nflog-group n].
    Nflog { prefix: Option<String>, group: Option<u32> },
    /// TRACE.
    Trace,
    /// NOTRACK — prevents conntrack from creating a state entry. nft
    /// equivalent is the bare `notrack` statement (raw-table prerouting/
    /// output is the canonical use site, mirroring iptables practice).
    Notrack,
    /// NFQUEUE — punt the packet to a userspace queue. nft equivalent
    /// is `queue num <n> [bypass] [fanout]`. `--queue-balance` is
    /// converted to a `num <lo>-<hi>` form; bypass and fanout flags
    /// pass through.
    Nfqueue { num: u32, balance_hi: Option<u32>, bypass: bool, fanout: bool },
    /// TCPMSS — clamp or set the TCP Maximum Segment Size option.
    /// `--clamp-mss-to-pmtu` lowers to `tcp option maxseg size set rt
    /// mtu`; `--set-mss N` lowers to `tcp option maxseg size set N`.
    Tcpmss(TcpmssOp),
    /// CT — conntrack helpers / zones / explicit notrack hook. iptables
    /// CT is a raw-table target whose closest nft equivalent is the
    /// `ct helper set "<name>"` / `ct zone set <n>` / bare `notrack`
    /// statement, depending on which sub-flag was used.
    Ct {
        notrack: bool,
        helper: Option<String>,
        zone: Option<u32>,
    },
    /// TOS — set the 8-bit Type-of-Service byte. iptables `--set-tos`
    /// writes the full byte; nft splits this into `ip dscp` (top 6
    /// bits) and ECN (bottom 2). The lowering picks the closest nft
    /// form per sub-op (Set → ip dscp set; And/Or/Xor → comment marker).
    Tos(TosOp),
    /// DSCP — set the 6-bit DiffServ Code Point. nft `ip dscp set N`.
    /// Class names (BE/EF/AFxx/CSx) are pre-resolved to numeric at
    /// parse time.
    Dscp(DscpOp),
    /// TTL — IPv4 only. nft `ip ttl set N` / `... + 1` / `... - 1`.
    Ttl(TtlOp),
    /// HL — IPv6 hop-limit, semantically equivalent to TTL.
    /// nft `ip6 hoplimit set N` / `... + 1` / `... - 1`.
    Hl(TtlOp),
    /// CLASSIFY — set the qdisc classid for traffic shaping.
    /// nft `meta priority set MAJ:MIN`. Real iptables takes hex
    /// MAJOR:MINOR; we preserve that semantic.
    Classify { major: u16, minor: u16 },
    /// CHECKSUM — recompute the L4 checksum for outbound packets.
    /// iptables `--checksum-fill` is a no-op for stormwall: nft has no
    /// first-class checksum-set statement (the kernel auto-fixes
    /// mismatched checksums on output via the network stack), so we
    /// install a comment marker for round-trip preservation.
    Checksum,
    /// NETMAP — rewrite source or destination network with a 1:1 mask
    /// preservation. Lowers to `dnat to <prefix>` for prerouting/output
    /// chains and `snat to <prefix>` for postrouting; the lowerer
    /// inspects `cmd.chain` to pick.
    Netmap { to_prefix: String },
    /// SET — add/del an entry to/from a named set (legacy ipset name
    /// or modern nft set). `--add-set NAME src` lowers to
    /// `add @NAME { ip saddr }`, `--del-set` to `delete @NAME { ... }`.
    Set { name: String, dirs: Vec<String>, op: SetOp, exist: bool, timeout: Option<u32> },
}

/// TOS target operations. iptables exposes set/and/or/xor; nft only
/// has `ip dscp set` so we approximate.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum TosOp {
    SetTos(u8),
    And(u8),
    Or(u8),
    Xor(u8),
}

/// DSCP target operations. Both `--set-dscp N` and `--set-dscp-class
/// CLASS` resolve to the same numeric u8 at parse time so the lowerer
/// only handles two cases.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum DscpOp {
    SetDscp(u8),
    SetClass(u8),
}

/// TTL / HL target operations. iptables exposes set/dec/inc; nft has
/// `ip ttl set N` / `ip ttl set ip ttl - N` / `ip ttl set ip ttl + N`.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum TtlOp {
    Set(u8),
    Dec(u8),
    Inc(u8),
}

/// `-j SET` operation kind.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum SetOp { Add, Del }

/// TCPMSS target operation — `--set-mss <N>` vs `--clamp-mss-to-pmtu`.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum TcpmssOp {
    SetMss(u16),
    ClampToPmtu,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum MarkKind { Set, Xset, And, Or, Xor }

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum ConnmarkOp {
    SetMark { value: u32, mask: Option<u32> },
    SaveMark { nfmask: Option<u32>, ctmask: Option<u32> },
    RestoreMark { nfmask: Option<u32>, ctmask: Option<u32> },
    And(u32),
    Or(u32),
    Xor(u32),
}

/// A parsed `-m <module> [args...]` clause that we don't have a first-
/// class home for. Used for `-m comment --comment ...` (consumed but
/// ignored at the netlink layer) and for stub modules that warn rather
/// than fail.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum MatchModule {
    /// Already-folded into `RuleSpec` fields; kept as a marker so
    /// renderers can re-emit `-m state`/`-m conntrack` etc.
    Stateful(String),
    /// `-m comment --comment "<s>"`.
    Comment(String),
    /// `-m addrtype --src-type LOCAL` / `--dst-type LOCAL` (etc.).
    Addrtype { src: Option<String>, dst: Option<String> },
    /// `-m mark --mark VALUE[/MASK]`.
    Mark { value: u32, mask: Option<u32>, neg: bool },
    /// `-m physdev --physdev-in IF` / `--physdev-out IF` / `--physdev-is-bridged`.
    Physdev { iin: Option<String>, oout: Option<String>, is_bridged: bool },
    /// `-m owner --uid-owner UID` / `--gid-owner GID`.
    Owner { uid: Option<u32>, gid: Option<u32> },
    /// `-m set --match-set NAME src/dst[,src/dst...]`.
    Set { name: String, dirs: Vec<String>, neg: bool },
    /// `-m mac --mac-source AA:BB:...`.
    Mac { source: String, neg: bool },
    /// `-m string --string S --algo bm|kmp` — punted; lowerer warns.
    String { s: String, algo: String },
    /// `-m iprange --src-range LO-HI` / `--dst-range LO-HI`. Either
    /// or both ranges may be set in a single `-m iprange` clause.
    Iprange { src: Option<(String, String)>, dst: Option<(String, String)>, neg: bool },
    /// `-m length --length N[:M]`. Single value matches exact byte
    /// length; range matches an inclusive interval. Negation supported.
    Length { lo: u32, hi: u32, neg: bool },
    /// `-m pkttype --pkt-type unicast|broadcast|multicast`. Negation
    /// supported. The lowerer emits `meta pkttype <kind>`.
    Pkttype { kind: String, neg: bool },
    /// `-m connmark --mark VALUE[/MASK]`. Distinct from `-m mark`
    /// (which matches `meta mark`); this matches `ct mark`.
    Connmark { value: u32, mask: Option<u32>, neg: bool },
    /// `-m tcpmss --mss N[:M]`. Matches the value of the TCP MSS
    /// option in the segment header. Lowers to
    /// `tcp option maxseg size <N>` (single) or
    /// `tcp option maxseg size <LO>-<HI>` (range).
    TcpmssMatch { lo: u16, hi: u16, neg: bool },
    /// `-m tos --tos VALUE[/MASK]`. Matches the 8-bit TOS byte. Most
    /// real-world rules only use the top 6 bits (DSCP); we lower to
    /// `ip dscp` after stripping ECN.
    Tos { value: u8, mask: Option<u8>, neg: bool },
    /// `-m dscp --dscp N` or `--dscp-class CLASS`. nft `ip dscp <N>`.
    Dscp { value: u8, neg: bool },
    /// `-m ttl --ttl-eq N` / `--ttl-gt N` / `--ttl-lt N`. IPv4 only.
    /// Lowers to `ip ttl == N` / `ip ttl > N` / `ip ttl < N`.
    Ttl { op: TtlMatchOp, value: u8, neg: bool },
    /// `-m hl --hl-eq N` / `--hl-gt N` / `--hl-lt N`. IPv6 only.
    /// Lowers to `ip6 hoplimit == N` etc.
    Hl { op: TtlMatchOp, value: u8, neg: bool },
    /// `-m statistic --mode random --probability F` or
    /// `-m statistic --mode nth --every N [--packet P]`.
    Statistic(StatisticOp),
    /// `-m connlimit --connlimit-above N [--connlimit-mask M]
    /// [--connlimit-saddr|--connlimit-daddr]`.
    Connlimit {
        above: bool,
        n: u32,
        mask: Option<u8>,
        on_dest: bool,
    },
    /// `-m helper --helper "ftp"`. Lowers to nft `ct helper "ftp"`.
    /// Distinct from `-j CT --helper X` (which writes a helper).
    Helper { name: String, neg: bool },
    /// `-m time --timestart hh:mm[:ss] --timestop hh:mm[:ss]
    /// [--weekdays day,day...]`. Lowers to nft `meta hour …` plus
    /// optional `meta day { … }`.
    Time {
        start: Option<String>,
        stop: Option<String>,
        weekdays: Vec<String>,
        contiguous: bool,
        kerneltz: bool,
    },
    /// `-m rpfilter [--loose] [--validmark] [--accept-local] [--invert]`.
    /// Lowers to nft's `fib saddr . iif oif != 0` (the canonical
    /// reverse-path-filter equivalent); the auxiliary flags pass
    /// through as comments for round-trip fidelity.
    Rpfilter { loose: bool, validmark: bool, accept_local: bool, invert: bool },
    /// `-m recent --set | --rcheck | --update | --remove [--name X]
    /// [--seconds N] [--hitcount N] [--rsource | --rdest]`. Lowers to
    /// nft set operations on a named set with timeouts:
    ///   --set    → `update @NAME { ip saddr timeout Ns }`
    ///   --rcheck → `ip saddr @NAME`
    ///   --update → `update @NAME { ip saddr timeout Ns }` (refreshes ttl)
    ///   --remove → `delete @NAME { ip saddr }`
    /// The named set itself must exist on the host (we don't auto-
    /// create — typically the user defines it once in their persistent
    /// nft.conf). `--rdest` switches the key to ip daddr.
    Recent {
        op: RecentOp,
        name: String,
        seconds: Option<u32>,
        hitcount: Option<u32>,
        on_dest: bool,
        neg: bool,
    },
    /// `-m connbytes --connbytes N[:M] --connbytes-dir <dir>
    ///                --connbytes-mode <mode>`. Lowers to nft
    /// `ct {bytes,pkts,avgpkt} <op> N`. iptables defaults: dir=both,
    /// mode=packets.
    Connbytes {
        lo: u64,
        hi: Option<u64>,
        dir: ConnbytesDir,
        mode: ConnbytesMode,
        neg: bool,
    },
    /// `-m hashlimit` — rate-limit per-source/destination hash bucket.
    ///
    /// Core flags (`upto`/`above`, `burst`, `name`) lower directly to an
    /// inline nft `limit rate … burst … packets` clause (or the negated
    /// `over` form). The remaining flags (`mode`, `srcmask`/`dstmask`,
    /// `htable-*`, `rate-match`/`rate-interval`) have no first-class nft
    /// equivalents in a per-rule inline context and are preserved as a
    /// comment marker so iptables-save round-trips them verbatim.
    Hashlimit {
        /// `--hashlimit-upto N[/UNIT]` — allow up to this rate (cap).
        upto: Option<(u64, String)>,
        /// `--hashlimit-above N[/UNIT]` — match above this rate (floor).
        above: Option<(u64, String)>,
        /// `--hashlimit-burst N` — burst allowance.
        burst: Option<u32>,
        /// `--hashlimit-name NAME` — named bucket (flows into comment).
        name: Option<String>,
        /// `--hashlimit-mode MODE,...` — hash fields (comment marker).
        mode: Option<String>,
        /// `--hashlimit-srcmask N` — CIDR prefix (comment marker).
        srcmask: Option<u8>,
        /// `--hashlimit-dstmask N` — CIDR prefix (comment marker).
        dstmask: Option<u8>,
        /// `--hashlimit-htable-size N` (comment marker).
        htable_size: Option<u32>,
        /// `--hashlimit-htable-max N` (comment marker).
        htable_max: Option<u32>,
        /// `--hashlimit-htable-expire MS` (comment marker).
        htable_expire: Option<u32>,
        /// `--hashlimit-htable-gcinterval MS` (comment marker).
        htable_gcinterval: Option<u32>,
        /// `--hashlimit-rate-match` (comment marker).
        rate_match: bool,
        /// `--hashlimit-rate-interval N` (comment marker).
        rate_interval: Option<u32>,
    },
    /// `-m policy` — match against the IPsec policy on the packet.
    ///
    /// The primary knob (`--pol ipsec` vs `--pol none`) lowers to nft's
    /// `meta secpath exists` / `meta secpath missing`. Finer-grained
    /// fields (`--reqid`, `--spi`, `--proto`, `--mode`, `--tunnel-src`,
    /// `--tunnel-dst`) live inside the xfrm policy structure and have no
    /// direct nft match selector in this position; they are preserved as
    /// comment markers for round-trip fidelity.
    Policy {
        /// `--dir in|out`
        dir: Option<String>,
        /// `--pol ipsec|none`
        pol: Option<String>,
        /// `--strict` — chain must match exactly (comment marker).
        strict: bool,
        /// `--reqid N` (comment marker).
        reqid: Option<u32>,
        /// `--spi N` (comment marker).
        spi: Option<u32>,
        /// `--proto ah|esp|ipcomp` (comment marker).
        proto: Option<String>,
        /// `--mode tunnel|transport` (comment marker).
        mode: Option<String>,
        /// `--tunnel-src ADDR[/MASK]` (comment marker).
        tunnel_src: Option<String>,
        /// `--tunnel-dst ADDR[/MASK]` (comment marker).
        tunnel_dst: Option<String>,
        /// `--next` (comment marker — chains additional --strict blocks).
        next: bool,
    },
    /// `-m ah --ahspi N`. IPv4: only `--ahspi`; IPv6: also `--ahlen N`
    /// and the boolean `--ahres`. `--ahlen` and `--ahres` have no direct
    /// nft equivalent and are emitted as comment markers.
    Ah { spi: u32, len: Option<u32>, res: bool, neg: bool },
    /// `-m esp --espspi N`. nft `esp spi N`.
    Esp { spi: u32, neg: bool },
    /// `-m frag` (IPv6). nft: `frag id N`, `frag length N`,
    /// `frag more-fragments 0/1`, etc. `--fragres` and `--fraglast` have
    /// no direct nft keyword and are emitted as comment markers.
    Frag {
        id:    Option<u32>,
        len:   Option<u32>,
        first: bool,
        more:  bool,
        last:  bool,
        res:   bool,
        neg:   bool,
    },
    /// `-m hbh` (IPv6 Hop-By-Hop options). `--hbh-len N` lowers to
    /// `hbh hdrlength N`; `--hbh-opts T:V[,T:V...]` has no nft equivalent
    /// and is recorded in `opts` for round-trip only, emitted as a comment.
    Hbh { len: Option<u32>, opts: Vec<String> },
    /// `-m mh --mh-type TYPE` (IPv6 Mobility Header). TYPE is a symbolic
    /// name (binding-update, binding-ack, …) or a number. nft `mh type N`.
    Mh { mh_type: String },
    /// `-m rt` (IPv6 Routing Header). `--rt-type T` → `rt type T`;
    /// `--rt-segsleft N` → `rt segs-left N`; `--rt-len N` → `rt hdrlength N`.
    /// `--rt-0-res`, `--rt-0-addrs`, and `--rt-0-not-strict` have no direct
    /// nft equivalent and are stored for round-trip / comment emission.
    Rt {
        rt_type:    Option<u32>,
        segs_left:  Option<u32>,
        len:        Option<u32>,
        rt0_res:    bool,
        rt0_addrs:  Vec<String>,
        rt0_strict: bool,
    },
    /// `-m dst` (IPv6 Destination options). `--dst-len N` → `dst hdrlength N`;
    /// `--dst-opts T:V[,T:V...]` has no nft equivalent and is stored for
    /// round-trip only, emitted as a comment.
    Dst { len: Option<u32>, opts: Vec<String> },
    /// `-m ipv6header [--soft] --header H,H,...` Matches which IPv6
    /// extension headers are present. Lowers to `ip6 nexthdr { h1, h2, … }`
    /// using a set of canonical nexthdr names. `--soft` (match if *any* of
    /// the listed headers are present) has no first-class nft equivalent and
    /// is emitted as a comment marker.
    Ipv6Header { headers: Vec<String>, soft: bool },
    /// Unsupported / not-yet-implemented module. The lowerer rejects
    /// these by default; verbose mode lists them explicitly.
    Unsupported(String),
}

/// `-m recent` operation kind. Maps to a different nft statement per
/// case; the parser captures which sub-flag the user supplied.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum RecentOp { Set, Rcheck, Update, Remove }

/// `-m connbytes --connbytes-dir`.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ConnbytesDir { Original, Reply, Both }

/// `-m connbytes --connbytes-mode`.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ConnbytesMode { Packets, Bytes, Avgpkt }

/// Comparator for `-m ttl` / `-m hl`.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum TtlMatchOp { Eq, Gt, Lt }

/// `-m statistic` mode + parameters. `Random` stores the probability
/// as parts-per-billion to keep StatisticOp `Eq`-friendly (f64 is not
/// Eq because of NaN). The 1e9 scale matches the nft lowering's
/// `numgen random mod 1_000_000_000 < threshold` form, so the parser
/// converts iptables's `--probability F` to ppb at parse time.
/// `Nth` lowers via `numgen inc mod N == P`.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum StatisticOp {
    Random { probability_ppb: u32 },
    Nth    { every: u32, packet: u32 },
}

/// One iptables rule spec: a bag of optional matches + a target.
///
/// All `Option`s are populated only when the corresponding flag was
/// given on the command line. The lowerer reads each in turn and
/// builds an nft `add rule` with the equivalent match clauses.
///
/// Negation (`!`) is tracked per-field. iptables grammar puts `!`
/// before the flag (e.g. `! -s 1.2.3.4`); we capture that by storing
/// `(value, negated)` for fields that support negation.
#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct RuleSpec {
    /// `-p tcp` etc. Lowercased, kept as the user wrote it.
    pub protocol: Option<String>,
    pub protocol_neg: bool,
    /// `-s ADDR[/CIDR]`.
    pub src: Option<AddrSpec>,
    /// `-d ADDR[/CIDR]`.
    pub dst: Option<AddrSpec>,
    /// `-i IFACE`.
    pub iif: Option<String>,
    pub iif_neg: bool,
    /// `-o IFACE`.
    pub oif: Option<String>,
    pub oif_neg: bool,
    /// `-f` — fragments-only.
    pub fragment: bool,
    /// `--sport`/`--dport` (after `-p tcp` or `-p udp`).
    pub sport: Option<PortRange>,
    pub sport_neg: bool,
    pub dport: Option<PortRange>,
    pub dport_neg: bool,
    /// `--icmp-type` / `--icmpv6-type`.
    pub icmp_type: Option<String>,
    pub icmp_type_neg: bool,
    /// TCP flags from `-m tcp --tcp-flags MASK COMP` or the legacy `--tcp-flags`.
    /// `(mask, comp)` — both comma-separated lists like "SYN,ACK".
    pub tcp_flags: Option<(String, String)>,
    pub tcp_flags_neg: bool,
    /// `-m tcp --syn` shorthand: equivalent to `--tcp-flags FIN,SYN,RST,ACK SYN`.
    pub tcp_syn: bool,
    /// Folded conntrack state set (from `-m state` or `-m conntrack`).
    pub state: Option<StateSet>,
    /// `-m multiport --sports`.
    pub multiport_sports: Option<MultiportList>,
    /// `-m multiport --dports`.
    pub multiport_dports: Option<MultiportList>,
    /// `-m limit --limit ...`.
    pub limit: Option<LimitOpt>,
    /// All other `-m ...` modules in source order. The lowerer iterates
    /// and emits the right nft clause for each.
    pub modules: Vec<MatchModule>,
    /// `-j TARGET` — terminal action. `None` is a valid (non-terminal)
    /// rule under iptables: matches accumulate into the chain's policy
    /// path, no jump. Real iptables accepts this and so do we.
    pub target: Option<Target>,
    /// `--goto NAME` — like jump but with a different return semantic
    /// (no implicit return at end of target chain). nft equivalent:
    /// `goto <name>`.
    pub goto: Option<String>,
    /// User-supplied comment via `-m comment --comment "<s>"`. Stored
    /// once even if multiple `-m comment` clauses appear; the lowerer
    /// emits an nft `comment "..."` clause from this field directly.
    pub comment: Option<String>,
}

/// One full iptables invocation.
#[derive(Debug, Clone)]
pub struct IptCmd {
    pub family: Family,
    pub table: IptTable,
    pub op: IptOp,
    /// Chain name. Empty for table-level operations like `-S` / `-F`
    /// without a chain argument.
    pub chain: String,
    /// For `-P <chain> <target>`: the target name (ACCEPT|DROP).
    pub policy_target: Option<String>,
    /// Rule spec for ops that carry one (-A/-I/-D-by-match/-R/-C).
    pub spec: RuleSpec,
    /// Display flags from `-L`: numeric (`-n`), verbose (`-v`),
    /// line-numbers (`--line-numbers`), exact counts (`-x`).
    pub list_numeric: bool,
    pub list_verbose: bool,
    pub list_linenums: bool,
    pub list_exact: bool,
    /// `-w` / `-W`: lock-wait knobs. Accepted for compat; ignored.
    /// Set so the renderer can re-emit them on save when carrying a
    /// fully-faithful round-trip is desired.
    pub wait: Option<u32>,
    pub wait_interval_us: Option<u32>,
}

impl IptCmd {
    pub fn new(family: Family) -> Self {
        IptCmd {
            family,
            table: IptTable::default(),
            op: IptOp::List,
            chain: String::new(),
            policy_target: None,
            spec: RuleSpec::default(),
            list_numeric: false,
            list_verbose: false,
            list_linenums: false,
            list_exact: false,
            wait: None,
            wait_interval_us: None,
        }
    }
}

/// The standard set of built-in chains per table. Matches xtables_chain_lookup
/// from the public iptables sources but the layout is dictated by
/// netfilter's hook API (`netfilter_ipv4.h`) which is the public ABI.
pub const FILTER_BUILTINS:   &[&str] = &["INPUT", "OUTPUT", "FORWARD"];
pub const NAT_BUILTINS:      &[&str] = &["PREROUTING", "INPUT", "OUTPUT", "POSTROUTING"];
pub const MANGLE_BUILTINS:   &[&str] = &["PREROUTING", "INPUT", "FORWARD", "OUTPUT", "POSTROUTING"];
pub const RAW_BUILTINS:      &[&str] = &["PREROUTING", "OUTPUT"];
pub const SECURITY_BUILTINS: &[&str] = &["INPUT", "OUTPUT", "FORWARD"];

pub fn builtins_for(table: IptTable) -> &'static [&'static str] {
    match table {
        IptTable::Filter   => FILTER_BUILTINS,
        IptTable::Nat      => NAT_BUILTINS,
        IptTable::Mangle   => MANGLE_BUILTINS,
        IptTable::Raw      => RAW_BUILTINS,
        IptTable::Security => SECURITY_BUILTINS,
    }
}

/// Iptables built-in chain → (nft hook, nft priority constant) for the
/// matching netfilter hook. Priorities follow the kernel's
/// `linux/netfilter_ipv4.h` `NF_IP_PRI_*` (which iptables itself wires
/// up via xtables_init_ipv4). We pick the same numeric values nft uses
/// (filter=0, raw=-300, mangle=-150, dstnat=-100, srcnat=100, security=50).
pub fn hook_for_chain(table: IptTable, chain: &str) -> Option<(&'static str, &'static str)> {
    let chain_upper: &str = chain;
    Some(match (table, chain_upper) {
        (IptTable::Filter,   "INPUT")        => ("input",       "filter"),
        (IptTable::Filter,   "OUTPUT")       => ("output",      "filter"),
        (IptTable::Filter,   "FORWARD")      => ("forward",     "filter"),

        (IptTable::Nat,      "PREROUTING")   => ("prerouting",  "dstnat"),
        (IptTable::Nat,      "INPUT")        => ("input",       "100"),
        (IptTable::Nat,      "OUTPUT")       => ("output",      "-100"),
        (IptTable::Nat,      "POSTROUTING")  => ("postrouting", "srcnat"),

        (IptTable::Mangle,   "PREROUTING")   => ("prerouting",  "mangle"),
        (IptTable::Mangle,   "INPUT")        => ("input",       "mangle"),
        (IptTable::Mangle,   "FORWARD")      => ("forward",     "mangle"),
        (IptTable::Mangle,   "OUTPUT")       => ("output",      "mangle"),
        (IptTable::Mangle,   "POSTROUTING")  => ("postrouting", "mangle"),

        (IptTable::Raw,      "PREROUTING")   => ("prerouting",  "raw"),
        (IptTable::Raw,      "OUTPUT")       => ("output",      "raw"),

        (IptTable::Security, "INPUT")        => ("input",       "security"),
        (IptTable::Security, "OUTPUT")       => ("output",      "security"),
        (IptTable::Security, "FORWARD")      => ("forward",     "security"),
        _ => return None,
    })
}

/// Returns true iff `chain` is a built-in for `table` (case-sensitive,
/// matching iptables behaviour: "INPUT" is built-in, "input" isn't).
pub fn is_builtin(table: IptTable, chain: &str) -> bool {
    builtins_for(table).iter().any(|b| *b == chain)
}
