// (c) 2026 Jon-Erik G. Storm, Inc., a California Corporation,
// doing business as LAVA GOAT SOFTWARE.  MIT license.
//
// argv → IptCmd. Hand-written recursive-descent over a flat argv
// vector, modelled on iptables(8). The flag set is documented in
// `man iptables`, `man iptables-extensions`, and the table of match
// modules in <https://netfilter.org/projects/iptables/>. We did not
// look at iptables source — every parse choice falls out of the
// observable CLI behaviour and the manpage prose.
//
// Two grammar quirks worth calling out:
//
// 1. `! -s 1.2.3.4` puts the negation BEFORE the flag, but `-s !
//    1.2.3.4` (legacy form) puts it after. Real iptables 1.6+ deprecates
//    the legacy form but still accepts it; we accept both.
// 2. `--dport 22` is only valid AFTER `-p tcp` or `-p udp` (or
//    inside `-m tcp` / `-m udp`). The match-module clause acts as a
//    "switch" that enables more flags. We don't enforce that strictly —
//    we just consume `--dport` whenever we see it. This matches
//    real iptables which, for example, accepts `iptables -A INPUT -p
//    tcp -m tcp --dport 22` and `iptables -A INPUT -p tcp --dport 22`
//    interchangeably.

use super::cmd::*;

pub struct Parsed {
    pub cmd: IptCmd,
}

#[derive(Debug)]
pub struct ParseError(pub String);

impl std::fmt::Display for ParseError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "{}", self.0)
    }
}

impl std::error::Error for ParseError {}

type Res<T> = Result<T, ParseError>;

fn err(s: impl Into<String>) -> ParseError { ParseError(s.into()) }

/// Family inferred from the binary basename (after stripping `-save` /
/// `-restore`). `iptables`, `iptables-save`, `iptables-restore` →
/// `Family::Ip`. `ip6tables*` → `Family::Ip6`. Anything else is
/// rejected here so the dispatcher can produce a clean error.
pub fn family_from_argv0(argv0: &str) -> Res<Family> {
    let base = std::path::Path::new(argv0)
        .file_name()
        .map(|s| s.to_string_lossy().into_owned())
        .unwrap_or_else(|| argv0.to_string());
    // Strip suffixes for save/restore variants: we just need the family.
    let core = base
        .strip_suffix("-save")
        .or_else(|| base.strip_suffix("-restore"))
        .unwrap_or(&base);
    match core {
        "iptables"          => Ok(Family::Ip),
        "ip6tables"         => Ok(Family::Ip6),
        // Compatibility aliases. Some distros symlink the legacy
        // names (`iptables-legacy`, `iptables-nft`) at the same path;
        // accept both since we are the only backend here.
        "iptables-legacy"   => Ok(Family::Ip),
        "iptables-nft"      => Ok(Family::Ip),
        "ip6tables-legacy"  => Ok(Family::Ip6),
        "ip6tables-nft"     => Ok(Family::Ip6),
        other => Err(err(format!("unknown iptables binary: {}", other))),
    }
}

/// Returns true if `argv0`'s basename is one of the *-save variants.
pub fn is_save_variant(argv0: &str) -> bool {
    let base = std::path::Path::new(argv0)
        .file_name()
        .map(|s| s.to_string_lossy().into_owned())
        .unwrap_or_else(|| argv0.to_string());
    base.ends_with("-save")
}

/// Returns true if `argv0`'s basename is one of the *-restore variants.
pub fn is_restore_variant(argv0: &str) -> bool {
    let base = std::path::Path::new(argv0)
        .file_name()
        .map(|s| s.to_string_lossy().into_owned())
        .unwrap_or_else(|| argv0.to_string());
    base.ends_with("-restore")
}

/// Parse a single iptables invocation.
///
/// `argv` should NOT include argv[0] — pass `&args[1..]`. The family
/// (ip / ip6) is determined separately by the dispatcher from argv[0].
pub fn parse(family: Family, argv: &[String]) -> Res<Parsed> {
    let mut p = Parser::new(family, argv);
    p.parse()?;
    Ok(Parsed { cmd: p.into_cmd() })
}

struct Parser<'a> {
    argv: &'a [String],
    i: usize,
    cmd: IptCmd,
    /// Toggled by a leading `!` token; consumed by the next flag and
    /// reset. iptables documents the modern form (`! -s 1.2.3.4`)
    /// here; legacy `-s ! 1.2.3.4` is handled per-flag below.
    pending_neg: bool,
    /// Track which match modules have been "enabled" by a `-m`
    /// invocation. We don't enforce strict ordering (iptables itself is
    /// sloppy) but we use this to disambiguate `--mark` (the mark
    /// match) from MARK target args.
    in_module: Option<String>,
    /// Set when `-j ` was just seen and the next token is the target
    /// name. After that, `--reject-with`, `--to-source`, `--set-mark`
    /// etc. attach to the target rather than to a match.
    have_target: bool,
}

impl<'a> Parser<'a> {
    fn new(family: Family, argv: &'a [String]) -> Self {
        Parser {
            argv,
            i: 0,
            cmd: IptCmd::new(family),
            pending_neg: false,
            in_module: None,
            have_target: false,
        }
    }

    fn into_cmd(self) -> IptCmd { self.cmd }

    fn peek(&self) -> Option<&'a str> { self.argv.get(self.i).map(|s| s.as_str()) }

    fn next_str(&mut self) -> Res<&'a str> {
        let s = self.argv.get(self.i)
            .ok_or_else(|| err("missing argument"))?;
        self.i += 1;
        Ok(s.as_str())
    }

    fn take_value(&mut self, flag: &str) -> Res<String> {
        match self.argv.get(self.i) {
            Some(s) => {
                self.i += 1;
                // Legacy `-s ! 1.2.3.4`: a literal "!" between flag and
                // value flips the negation.
                if s == "!" {
                    self.pending_neg = !self.pending_neg;
                    self.take_value(flag)
                } else {
                    Ok(s.clone())
                }
            }
            None => Err(err(format!("{} requires a value", flag))),
        }
    }

    /// Take both the value and its negation flag in one shot. Handles
    /// the modern `! -s 1.2.3.4` form (`!` before the flag, captured
    /// in `pending_neg` by the outer parser loop) and the legacy
    /// `-s ! 1.2.3.4` form (`!` between the flag and its value, set
    /// inside `take_value`). A standalone `take_neg()` BEFORE
    /// `take_value()` would miss the legacy form because the flip
    /// inside `take_value` happens after the read.
    fn take_value_neg(&mut self, flag: &str) -> Res<(String, bool)> {
        let v = self.take_value(flag)?;
        let neg = self.pending_neg;
        self.pending_neg = false;
        Ok((v, neg))
    }

    fn take_neg(&mut self) -> bool {
        let n = self.pending_neg;
        self.pending_neg = false;
        n
    }

    fn parse(&mut self) -> Res<()> {
        // First pass: pick up table override (`-t TABLE`) and global
        // flags. iptables accepts `-t` anywhere on the command line, so
        // we just walk through.
        let mut have_op = false;
        while self.i < self.argv.len() {
            let tok = self.argv[self.i].clone();
            match tok.as_str() {
                "!" => { self.pending_neg = !self.pending_neg; self.i += 1; }
                "-t" | "--table" => {
                    self.i += 1;
                    let v = self.take_value("-t")?;
                    self.cmd.table = IptTable::from_str_opt(&v)
                        .ok_or_else(|| err(format!("unknown table: {}", v)))?;
                }
                // Operations. Each consumes its mandatory chain arg
                // (and, where applicable, a numeric position).
                "-A" | "--append" => {
                    self.i += 1;
                    self.cmd.op = IptOp::Append;
                    self.cmd.chain = self.take_value("-A")?;
                    have_op = true;
                }
                "-I" | "--insert" => {
                    self.i += 1;
                    self.cmd.chain = self.take_value("-I")?;
                    // Optional position argument. If the next token
                    // parses as a positive integer, it's the position.
                    let pos = match self.peek() {
                        Some(s) if s.chars().all(|c| c.is_ascii_digit()) => {
                            let n: u32 = s.parse().unwrap_or(1);
                            self.i += 1;
                            n
                        }
                        _ => 1,
                    };
                    self.cmd.op = IptOp::Insert(pos);
                    have_op = true;
                }
                "-D" | "--delete" => {
                    self.i += 1;
                    self.cmd.chain = self.take_value("-D")?;
                    // Either a 1-based rule number, or the rule-spec
                    // begins immediately. Heuristic: if the next token
                    // is an unsigned integer AND no further flags
                    // follow, treat as rule number; otherwise as match.
                    if let Some(s) = self.peek() {
                        if s.chars().all(|c| c.is_ascii_digit())
                            && !s.is_empty()
                            && (self.argv.get(self.i + 1).is_none()
                                || self.argv.get(self.i + 1).map(|v| v.starts_with('-') || v == "!").unwrap_or(false))
                        {
                            // Bare numeric — but only treat as N when
                            // there are no more rule-spec tokens AFTER
                            // the number. If a flag follows, fall
                            // through into rule-spec parsing.
                            let only_num = self.argv.get(self.i + 1).is_none();
                            if only_num {
                                let n: u32 = s.parse().unwrap_or(1);
                                self.i += 1;
                                self.cmd.op = IptOp::DeleteNum(n);
                                have_op = true;
                                continue;
                            }
                        }
                    }
                    self.cmd.op = IptOp::DeleteMatch;
                    have_op = true;
                }
                "-R" | "--replace" => {
                    self.i += 1;
                    self.cmd.chain = self.take_value("-R")?;
                    let n: u32 = self.take_value("-R")?.parse()
                        .map_err(|_| err("-R requires a numeric position"))?;
                    self.cmd.op = IptOp::Replace(n);
                    have_op = true;
                }
                "-L" | "--list" => {
                    self.i += 1;
                    self.cmd.op = IptOp::List;
                    if let Some(s) = self.peek() {
                        if !s.starts_with('-') && s != "!" {
                            self.cmd.chain = self.next_str()?.to_string();
                        }
                    }
                    have_op = true;
                }
                "-S" | "--list-rules" => {
                    self.i += 1;
                    self.cmd.op = IptOp::Save;
                    if let Some(s) = self.peek() {
                        if !s.starts_with('-') && s != "!" {
                            self.cmd.chain = self.next_str()?.to_string();
                        }
                    }
                    have_op = true;
                }
                "-F" | "--flush" => {
                    self.i += 1;
                    self.cmd.op = IptOp::Flush;
                    if let Some(s) = self.peek() {
                        if !s.starts_with('-') && s != "!" {
                            self.cmd.chain = self.next_str()?.to_string();
                        }
                    }
                    have_op = true;
                }
                "-X" | "--delete-chain" => {
                    self.i += 1;
                    self.cmd.op = IptOp::DeleteChain;
                    if let Some(s) = self.peek() {
                        if !s.starts_with('-') && s != "!" {
                            self.cmd.chain = self.next_str()?.to_string();
                        }
                    }
                    have_op = true;
                }
                "-N" | "--new-chain" => {
                    self.i += 1;
                    self.cmd.op = IptOp::NewChain;
                    self.cmd.chain = self.take_value("-N")?;
                    have_op = true;
                }
                "-Z" | "--zero" => {
                    self.i += 1;
                    self.cmd.op = IptOp::Zero;
                    if let Some(s) = self.peek() {
                        if !s.starts_with('-') && s != "!" {
                            self.cmd.chain = self.next_str()?.to_string();
                        }
                    }
                    have_op = true;
                }
                "-C" | "--check" => {
                    self.i += 1;
                    self.cmd.op = IptOp::Check;
                    self.cmd.chain = self.take_value("-C")?;
                    have_op = true;
                }
                "-P" | "--policy" => {
                    self.i += 1;
                    self.cmd.op = IptOp::Policy;
                    self.cmd.chain = self.take_value("-P")?;
                    self.cmd.policy_target = Some(self.take_value("-P")?);
                    have_op = true;
                }
                "-E" | "--rename-chain" => {
                    self.i += 1;
                    self.cmd.op = IptOp::Rename;
                    self.cmd.chain = self.take_value("-E")?;
                    // Reuse policy_target as the auxiliary string slot
                    // for the new chain name.
                    self.cmd.policy_target = Some(self.take_value("-E")?);
                    have_op = true;
                }
                // -c / --set-counters PKTS BYTES: initialise counters on
                // a new rule. Real iptables stores them on the rule for
                // restore round-trip; we accept and ignore (no nft
                // equivalent in our forward-only path). Two values follow.
                "-c" | "--set-counters" => {
                    self.i += 1;
                    let _pkts = self.take_value("-c")?;
                    let _bytes = self.take_value("-c")?;
                }
                // Display / wait flags — modify behaviour without changing op.
                "-n" | "--numeric"      => { self.i += 1; self.cmd.list_numeric = true; }
                "-v" | "--verbose"      => { self.i += 1; self.cmd.list_verbose = true; }
                "-x" | "--exact"        => { self.i += 1; self.cmd.list_exact = true; }
                "--line-numbers"        => { self.i += 1; self.cmd.list_linenums = true; }
                "-w" | "--wait"         => {
                    self.i += 1;
                    // -w takes an optional integer. Probe.
                    if let Some(s) = self.peek() {
                        if s.chars().all(|c| c.is_ascii_digit()) {
                            self.cmd.wait = Some(s.parse().unwrap_or(0));
                            self.i += 1;
                            continue;
                        }
                    }
                    self.cmd.wait = Some(0);
                }
                "-W" | "--wait-interval" => {
                    self.i += 1;
                    self.cmd.wait_interval_us = Some(self.take_value("-W")?.parse().unwrap_or(0));
                }
                // Compat / ignored.
                "--ipv4" | "-4" => { self.i += 1; }
                "--ipv6" | "-6" => { self.i += 1; }
                "-h" | "--help" => { return Err(err("__help__")); }
                "-V" | "--version" => { return Err(err("__version__")); }
                "-m" | "--match" => {
                    self.i += 1;
                    let name = self.take_value("-m")?;
                    self.in_module = Some(name.clone());
                    // Some modules carry implicit consumption (e.g.
                    // `-m comment` always followed by `--comment`).
                    // Most modules have a marker effect only — they
                    // enable additional flags that follow.
                    // Append a placeholder Stateful entry for renderers
                    // that want to re-emit `-m <name>` literally.
                    self.cmd.spec.modules.push(MatchModule::Stateful(name.clone()));
                    // Modules with a meaningful default-no-flags form:
                    // `-m rpfilter` alone means "match packets that
                    // pass the reverse-path-filter check" (the most
                    // common form in real-world rules — admins use
                    // it as a drop-in spoof filter). Pre-seed an
                    // Rpfilter variant so the lower path emits the
                    // base `fib saddr . iif oif != 0` even when no
                    // sub-flag follows.
                    if name == "rpfilter" {
                        self.cmd.spec.modules.push(MatchModule::Rpfilter {
                            loose: false, validmark: false,
                            accept_local: false, invert: false,
                        });
                    }
                    // Pre-seed a Policy stub so sub-flags like --dir /
                    // --pol can find and merge into it via merge_policy.
                    if name == "policy" {
                        self.cmd.spec.modules.push(MatchModule::Policy {
                            dir: None, pol: None, strict: false,
                            reqid: None, spi: None, proto: None, mode: None,
                            tunnel_src: None, tunnel_dst: None, next: false,
                        });
                    }
                    // Pre-seed a Hashlimit stub so sub-flags can accumulate.
                    if name == "hashlimit" {
                        self.cmd.spec.modules.push(MatchModule::Hashlimit {
                            upto: None, above: None, burst: None, name: None,
                            mode: None, srcmask: None, dstmask: None,
                            htable_size: None, htable_max: None,
                            htable_expire: None, htable_gcinterval: None,
                            rate_match: false, rate_interval: None,
                        });
                    }
                }
                "-j" | "--jump" => {
                    self.i += 1;
                    let name = self.take_value("-j")?;
                    self.have_target = true;
                    self.cmd.spec.target = Some(parse_target_name(&name));
                }
                "--goto" | "-g" => {
                    self.i += 1;
                    self.cmd.spec.goto = Some(self.take_value("--goto")?);
                }
                // Match-side flags. Each calls into a helper below.
                _ => self.parse_match_flag(&tok)?,
            }
        }
        if !have_op {
            return Err(err("no operation specified (use -A/-I/-D/-L/-S/-F/-X/-N/-Z/-C/-P)"));
        }
        Ok(())
    }

    fn parse_match_flag(&mut self, tok: &str) -> Res<()> {
        match tok {
            "-p" | "--protocol" => {
                self.i += 1;
                let (v, neg) = self.take_value_neg("-p")?;
                self.cmd.spec.protocol = Some(v.to_lowercase());
                self.cmd.spec.protocol_neg = neg;
                Ok(())
            }
            "-s" | "--source" | "--src" => {
                self.i += 1;
                let (v, neg) = self.take_value_neg("-s")?;
                self.cmd.spec.src = Some(AddrSpec { raw: v, family: self.cmd.family, neg });
                Ok(())
            }
            "-d" | "--destination" | "--dst" => {
                self.i += 1;
                let (v, neg) = self.take_value_neg("-d")?;
                self.cmd.spec.dst = Some(AddrSpec { raw: v, family: self.cmd.family, neg });
                Ok(())
            }
            "-i" | "--in-interface" => {
                self.i += 1;
                let (v, neg) = self.take_value_neg("-i")?;
                self.cmd.spec.iif = Some(v);
                self.cmd.spec.iif_neg = neg;
                Ok(())
            }
            "-o" | "--out-interface" => {
                self.i += 1;
                let (v, neg) = self.take_value_neg("-o")?;
                self.cmd.spec.oif = Some(v);
                self.cmd.spec.oif_neg = neg;
                Ok(())
            }
            "-f" | "--fragment" => { self.i += 1; self.cmd.spec.fragment = true; Ok(()) }
            "--sport" | "--source-port" | "--source-ports" => {
                self.i += 1;
                let (v, neg) = self.take_value_neg("--sport")?;
                if matches!(self.in_module.as_deref(), Some("multiport")) && v.contains(',') {
                    self.cmd.spec.multiport_sports = Some(parse_multiport(&v, neg)?);
                } else {
                    self.cmd.spec.sport = Some(parse_port_range(&v)?);
                    self.cmd.spec.sport_neg = neg;
                }
                Ok(())
            }
            "--dport" | "--destination-port" | "--destination-ports" => {
                self.i += 1;
                let (v, neg) = self.take_value_neg("--dport")?;
                if matches!(self.in_module.as_deref(), Some("multiport")) && v.contains(',') {
                    self.cmd.spec.multiport_dports = Some(parse_multiport(&v, neg)?);
                } else {
                    self.cmd.spec.dport = Some(parse_port_range(&v)?);
                    self.cmd.spec.dport_neg = neg;
                }
                Ok(())
            }
            "--dports" => {
                self.i += 1;
                let (v, neg) = self.take_value_neg("--dports")?;
                self.cmd.spec.multiport_dports = Some(parse_multiport(&v, neg)?);
                Ok(())
            }
            "--sports" => {
                self.i += 1;
                let (v, neg) = self.take_value_neg("--sports")?;
                self.cmd.spec.multiport_sports = Some(parse_multiport(&v, neg)?);
                Ok(())
            }
            "--icmp-type" | "--icmpv6-type" => {
                self.i += 1;
                let (v, neg) = self.take_value_neg("--icmp-type")?;
                self.cmd.spec.icmp_type = Some(v);
                self.cmd.spec.icmp_type_neg = neg;
                Ok(())
            }
            "--syn" => { self.i += 1; self.cmd.spec.tcp_syn = true; Ok(()) }
            "--tcp-flags" => {
                self.i += 1;
                // Two values follow: mask and comp. Either can carry a
                // legacy `!`. Use take_value_neg on the FIRST so any
                // pre-flag `!` (modern) or pre-mask `!` (legacy) is
                // captured; comp is plain take_value.
                let (mask, neg) = self.take_value_neg("--tcp-flags")?;
                let comp = self.take_value("--tcp-flags")?;
                self.cmd.spec.tcp_flags = Some((mask, comp));
                self.cmd.spec.tcp_flags_neg = neg;
                Ok(())
            }
            "--state" | "--ctstate" => {
                self.i += 1;
                let (v, neg) = self.take_value_neg("--state")?;
                let names = v.split(',').map(|s| s.trim().to_string()).collect();
                self.cmd.spec.state = Some(StateSet { names, neg });
                Ok(())
            }
            "--limit" => {
                self.i += 1;
                let v = self.take_value("--limit")?;
                let (rate, unit) = match v.find('/') {
                    Some(i) => (v[..i].parse::<u64>().unwrap_or(0), v[i+1..].to_string()),
                    None    => (v.parse::<u64>().unwrap_or(0), "second".to_string()),
                };
                let burst = if matches!(self.peek(), Some("--limit-burst")) {
                    self.i += 1;
                    self.take_value("--limit-burst")?.parse().unwrap_or(5)
                } else { 5 };
                self.cmd.spec.limit = Some(LimitOpt { rate, unit, burst });
                Ok(())
            }
            "--limit-burst" => {
                // Standalone (no preceding --limit). Apply to existing
                // limit if any; otherwise build a default 1/second limit.
                self.i += 1;
                let burst: u32 = self.take_value("--limit-burst")?.parse().unwrap_or(5);
                if let Some(ref mut l) = self.cmd.spec.limit {
                    l.burst = burst;
                } else {
                    self.cmd.spec.limit = Some(LimitOpt {
                        rate: 1, unit: "second".to_string(), burst,
                    });
                }
                Ok(())
            }
            "--comment" => {
                self.i += 1;
                let s = self.take_value("--comment")?;
                self.cmd.spec.comment = Some(s.clone());
                self.cmd.spec.modules.push(MatchModule::Comment(s));
                Ok(())
            }
            "--src-type" => {
                self.i += 1;
                let v = self.take_value("--src-type")?;
                self.cmd.spec.modules.push(MatchModule::Addrtype { src: Some(v), dst: None });
                Ok(())
            }
            "--dst-type" => {
                self.i += 1;
                let v = self.take_value("--dst-type")?;
                self.cmd.spec.modules.push(MatchModule::Addrtype { src: None, dst: Some(v) });
                Ok(())
            }
            "--mark" => {
                self.i += 1;
                let (v, neg) = self.take_value_neg("--mark")?;
                let (val, mask) = parse_mark_mask(&v)?;
                if self.have_target {
                    // Belongs to MARK target — reroute.
                    if let Some(Target::Jump(name)) = self.cmd.spec.target.clone() {
                        if name.eq_ignore_ascii_case("MARK") {
                            self.cmd.spec.target = Some(Target::Mark { kind: MarkKind::Set, value: val, mask });
                            return Ok(());
                        }
                    }
                }
                // -m connmark --mark: matches ct mark, not meta mark.
                // Disambiguate by `in_module`: when the most recent
                // -m clause was `connmark`, --mark is a connmark match.
                if matches!(self.in_module.as_deref(), Some("connmark")) {
                    self.cmd.spec.modules.push(MatchModule::Connmark { value: val, mask, neg });
                } else {
                    self.cmd.spec.modules.push(MatchModule::Mark { value: val, mask, neg });
                }
                Ok(())
            }
            "--set-mark" => {
                self.i += 1;
                let v = self.take_value("--set-mark")?;
                let (val, mask) = parse_mark_mask(&v)?;
                self.have_target = true;
                self.cmd.spec.target = Some(promote_mark_target(&self.cmd.spec.target, MarkKind::Set, val, mask));
                Ok(())
            }
            "--set-xmark" => {
                self.i += 1;
                let v = self.take_value("--set-xmark")?;
                let (val, mask) = parse_mark_mask(&v)?;
                self.have_target = true;
                self.cmd.spec.target = Some(promote_mark_target(&self.cmd.spec.target, MarkKind::Xset, val, mask));
                Ok(())
            }
            "--and-mark" => {
                self.i += 1;
                let v = self.take_value("--and-mark")?;
                let (val, mask) = parse_mark_mask(&v)?;
                self.have_target = true;
                self.cmd.spec.target = Some(promote_mark_target(&self.cmd.spec.target, MarkKind::And, val, mask));
                Ok(())
            }
            "--or-mark" => {
                self.i += 1;
                let v = self.take_value("--or-mark")?;
                let (val, mask) = parse_mark_mask(&v)?;
                self.have_target = true;
                self.cmd.spec.target = Some(promote_mark_target(&self.cmd.spec.target, MarkKind::Or, val, mask));
                Ok(())
            }
            "--xor-mark" => {
                self.i += 1;
                let v = self.take_value("--xor-mark")?;
                let (val, mask) = parse_mark_mask(&v)?;
                self.have_target = true;
                self.cmd.spec.target = Some(promote_mark_target(&self.cmd.spec.target, MarkKind::Xor, val, mask));
                Ok(())
            }
            "--save-mark" => {
                self.i += 1;
                self.have_target = true;
                self.cmd.spec.target = Some(Target::Connmark(ConnmarkOp::SaveMark { nfmask: None, ctmask: None }));
                Ok(())
            }
            "--restore-mark" => {
                self.i += 1;
                self.have_target = true;
                self.cmd.spec.target = Some(Target::Connmark(ConnmarkOp::RestoreMark { nfmask: None, ctmask: None }));
                Ok(())
            }
            "--nfmask" | "--ctmask" => {
                // Mask sub-options for `-j CONNMARK --save-mark` /
                // `--restore-mark`. iptables accepts decimal or 0xHEX
                // (parse_mark_mask handles both, ignoring the optional
                // /mask suffix that doesn't apply here). Tailscale's
                // healthcheck relies on these — without them parsed,
                // `tailscale up` reports "enabling connmark rules ...
                // unknown flag: --nfmask".
                let flag = self.argv[self.i].clone();
                self.i += 1;
                let v = self.take_value(&flag)?;
                let (value, _) = parse_mark_mask(&v)?;
                match self.cmd.spec.target.as_mut() {
                    Some(Target::Connmark(ConnmarkOp::SaveMark { nfmask, ctmask })) |
                    Some(Target::Connmark(ConnmarkOp::RestoreMark { nfmask, ctmask })) => {
                        if flag == "--nfmask" { *nfmask = Some(value); }
                        else                   { *ctmask = Some(value); }
                    }
                    _ => return Err(err(format!(
                        "{} requires CONNMARK --save-mark or --restore-mark target", flag))),
                }
                Ok(())
            }
            "--reject-with" => {
                self.i += 1;
                let v = self.take_value("--reject-with")?;
                self.cmd.spec.target = Some(Target::Reject(Some(v)));
                Ok(())
            }
            "--log-prefix" => {
                self.i += 1;
                let v = self.take_value("--log-prefix")?;
                merge_log(&mut self.cmd.spec.target, |l| l.prefix = Some(v));
                Ok(())
            }
            "--log-level" => {
                self.i += 1;
                let v = self.take_value("--log-level")?;
                let lvl: u8 = v.parse().unwrap_or(0);
                merge_log(&mut self.cmd.spec.target, |l| l.level = Some(lvl));
                Ok(())
            }
            "--log-tcp-sequence" => {
                self.i += 1;
                merge_log(&mut self.cmd.spec.target, |l| l.tcp_sequence = true);
                Ok(())
            }
            "--log-tcp-options" => {
                self.i += 1;
                merge_log(&mut self.cmd.spec.target, |l| l.tcp_options = true);
                Ok(())
            }
            "--log-ip-options" => {
                self.i += 1;
                merge_log(&mut self.cmd.spec.target, |l| l.ip_options = true);
                Ok(())
            }
            "--log-uid" => {
                self.i += 1;
                merge_log(&mut self.cmd.spec.target, |l| l.log_uid = true);
                Ok(())
            }
            // NFQUEUE target flags. NFQUEUE puts the packet into a
            // userspace queue identified by a numeric id; the optional
            // balance form `--queue-balance LO:HI` declares a CPU-fanout
            // range, which nft expresses as `queue num LO-HI`.
            "--queue-num" => {
                self.i += 1;
                let v = self.take_value("--queue-num")?;
                let num: u32 = v.parse().unwrap_or(0);
                let cur = self.cmd.spec.target.clone();
                let (balance_hi, bypass, fanout) = match cur {
                    Some(Target::Nfqueue { balance_hi, bypass, fanout, .. })
                        => (balance_hi, bypass, fanout),
                    _ => (None, false, false),
                };
                self.cmd.spec.target = Some(Target::Nfqueue { num, balance_hi, bypass, fanout });
                Ok(())
            }
            "--queue-balance" => {
                self.i += 1;
                let v = self.take_value("--queue-balance")?;
                let (lo, hi) = match v.find(':') {
                    Some(i) => (
                        v[..i].parse::<u32>().unwrap_or(0),
                        v[i+1..].parse::<u32>().unwrap_or(0),
                    ),
                    None => (v.parse::<u32>().unwrap_or(0), 0),
                };
                let cur = self.cmd.spec.target.clone();
                let (bypass, fanout) = match cur {
                    Some(Target::Nfqueue { bypass, fanout, .. }) => (bypass, fanout),
                    _ => (false, false),
                };
                self.cmd.spec.target = Some(Target::Nfqueue { num: lo, balance_hi: Some(hi), bypass, fanout });
                Ok(())
            }
            "--queue-bypass" => {
                self.i += 1;
                let cur = self.cmd.spec.target.clone();
                let (num, balance_hi, fanout) = match cur {
                    Some(Target::Nfqueue { num, balance_hi, fanout, .. })
                        => (num, balance_hi, fanout),
                    _ => (0, None, false),
                };
                self.cmd.spec.target = Some(Target::Nfqueue { num, balance_hi, bypass: true, fanout });
                Ok(())
            }
            "--queue-cpu-fanout" => {
                self.i += 1;
                let cur = self.cmd.spec.target.clone();
                let (num, balance_hi, bypass) = match cur {
                    Some(Target::Nfqueue { num, balance_hi, bypass, .. })
                        => (num, balance_hi, bypass),
                    _ => (0, None, false),
                };
                self.cmd.spec.target = Some(Target::Nfqueue { num, balance_hi, bypass, fanout: true });
                Ok(())
            }
            // TCPMSS target flags.
            "--set-mss" => {
                self.i += 1;
                let v = self.take_value("--set-mss")?;
                let mss: u16 = v.parse().unwrap_or(0);
                self.cmd.spec.target = Some(Target::Tcpmss(TcpmssOp::SetMss(mss)));
                Ok(())
            }
            "--clamp-mss-to-pmtu" => {
                self.i += 1;
                self.cmd.spec.target = Some(Target::Tcpmss(TcpmssOp::ClampToPmtu));
                Ok(())
            }
            // CT target flags.
            "--notrack" => {
                self.i += 1;
                let cur = self.cmd.spec.target.clone();
                let (helper, zone) = match cur {
                    Some(Target::Ct { helper, zone, .. }) => (helper, zone),
                    _ => (None, None),
                };
                self.cmd.spec.target = Some(Target::Ct { notrack: true, helper, zone });
                Ok(())
            }
            "--helper" => {
                // Disambiguate `-m helper --helper "ftp"` (match) from
                // `-j CT --helper ftp` (target). When the most recent
                // -m clause was `helper`, this is a match-side flag;
                // otherwise it routes to the CT target.
                if matches!(self.in_module.as_deref(), Some("helper")) {
                    self.i += 1;
                    let (v, neg) = self.take_value_neg("--helper")?;
                    let name = if v.starts_with('"') && v.ends_with('"') && v.len() >= 2 {
                        v[1..v.len()-1].to_string()
                    } else { v };
                    self.cmd.spec.modules.push(MatchModule::Helper { name, neg });
                    Ok(())
                } else {
                    self.i += 1;
                    let v = self.take_value("--helper")?;
                    let cur = self.cmd.spec.target.clone();
                    let (notrack, zone) = match cur {
                        Some(Target::Ct { notrack, zone, .. }) => (notrack, zone),
                        _ => (false, None),
                    };
                    self.cmd.spec.target = Some(Target::Ct { notrack, helper: Some(v), zone });
                    Ok(())
                }
            }
            "--zone" => {
                self.i += 1;
                let v = self.take_value("--zone")?;
                let zone: u32 = v.parse().unwrap_or(0);
                let cur = self.cmd.spec.target.clone();
                let (notrack, helper) = match cur {
                    Some(Target::Ct { notrack, helper, .. }) => (notrack, helper),
                    _ => (false, None),
                };
                self.cmd.spec.target = Some(Target::Ct { notrack, helper, zone: Some(zone) });
                Ok(())
            }
            // -m iprange: --src-range / --dst-range. Either or both may
            // appear within a single -m iprange clause; the parser
            // merges them into the same Iprange MatchModule.
            "--src-range" => {
                self.i += 1;
                let (v, neg) = self.take_value_neg("--src-range")?;
                let (lo, hi) = parse_addr_range(&v)?;
                merge_iprange(&mut self.cmd.spec.modules, |r| {
                    r.src = Some((lo, hi));
                    if neg { r.neg = true; }
                });
                Ok(())
            }
            "--dst-range" => {
                self.i += 1;
                let (v, neg) = self.take_value_neg("--dst-range")?;
                let (lo, hi) = parse_addr_range(&v)?;
                merge_iprange(&mut self.cmd.spec.modules, |r| {
                    r.dst = Some((lo, hi));
                    if neg { r.neg = true; }
                });
                Ok(())
            }
            // -m length: --length N or --length N:M.
            "--length" => {
                self.i += 1;
                let (v, neg) = self.take_value_neg("--length")?;
                let (lo, hi) = match v.find(':') {
                    Some(i) => (
                        v[..i].parse::<u32>().map_err(|_| err(format!("bad length: {}", v)))?,
                        v[i+1..].parse::<u32>().map_err(|_| err(format!("bad length: {}", v)))?,
                    ),
                    None => {
                        let n: u32 = v.parse().map_err(|_| err(format!("bad length: {}", v)))?;
                        (n, n)
                    }
                };
                self.cmd.spec.modules.push(MatchModule::Length { lo, hi, neg });
                Ok(())
            }
            // -m pkttype: --pkt-type host|broadcast|multicast.
            "--pkt-type" => {
                self.i += 1;
                let (v, neg) = self.take_value_neg("--pkt-type")?;
                self.cmd.spec.modules.push(MatchModule::Pkttype { kind: v, neg });
                Ok(())
            }
            // -m tcpmss: --mss N or N:M.
            "--mss" => {
                self.i += 1;
                let (v, neg) = self.take_value_neg("--mss")?;
                let (lo, hi) = match v.find(':') {
                    Some(i) => (
                        v[..i].parse::<u16>().unwrap_or(0),
                        v[i+1..].parse::<u16>().unwrap_or(0),
                    ),
                    None => {
                        let n: u16 = v.parse().unwrap_or(0);
                        (n, n)
                    }
                };
                self.cmd.spec.modules.push(MatchModule::TcpmssMatch { lo, hi, neg });
                Ok(())
            }
            // -m tos --tos N[/M]  OR  -j TOS --set-tos N (when have_target).
            "--tos" => {
                self.i += 1;
                let (v, neg) = self.take_value_neg("--tos")?;
                let (value, mask) = parse_tos_value(&v)?;
                if self.have_target {
                    self.cmd.spec.target = Some(Target::Tos(TosOp::SetTos(value)));
                } else {
                    self.cmd.spec.modules.push(MatchModule::Tos { value, mask, neg });
                }
                Ok(())
            }
            "--set-tos" => {
                self.i += 1;
                let v = self.take_value("--set-tos")?;
                let (value, _mask) = parse_tos_value(&v)?;
                self.cmd.spec.target = Some(Target::Tos(TosOp::SetTos(value)));
                Ok(())
            }
            "--and-tos" => {
                self.i += 1;
                let v = self.take_value("--and-tos")?;
                self.cmd.spec.target = Some(Target::Tos(TosOp::And(parse_u8_flexible(&v))));
                Ok(())
            }
            "--or-tos" => {
                self.i += 1;
                let v = self.take_value("--or-tos")?;
                self.cmd.spec.target = Some(Target::Tos(TosOp::Or(parse_u8_flexible(&v))));
                Ok(())
            }
            "--xor-tos" => {
                self.i += 1;
                let v = self.take_value("--xor-tos")?;
                self.cmd.spec.target = Some(Target::Tos(TosOp::Xor(parse_u8_flexible(&v))));
                Ok(())
            }
            // -m dscp / -j DSCP.
            "--dscp" => {
                self.i += 1;
                let (v, neg) = self.take_value_neg("--dscp")?;
                let n = parse_u8_flexible(&v);
                self.cmd.spec.modules.push(MatchModule::Dscp { value: n, neg });
                Ok(())
            }
            "--dscp-class" => {
                self.i += 1;
                let (v, neg) = self.take_value_neg("--dscp-class")?;
                let n = parse_dscp_class(&v).unwrap_or(0);
                self.cmd.spec.modules.push(MatchModule::Dscp { value: n, neg });
                Ok(())
            }
            "--set-dscp" => {
                self.i += 1;
                let v = self.take_value("--set-dscp")?;
                let n = parse_u8_flexible(&v);
                self.cmd.spec.target = Some(Target::Dscp(DscpOp::SetDscp(n)));
                Ok(())
            }
            "--set-dscp-class" => {
                self.i += 1;
                let v = self.take_value("--set-dscp-class")?;
                let n = parse_dscp_class(&v).unwrap_or(0);
                self.cmd.spec.target = Some(Target::Dscp(DscpOp::SetClass(n)));
                Ok(())
            }
            // -m ttl: TtlMatchOp (eq/gt/lt). All three iptables forms
            // are in the same family. -m hl is the IPv6 sibling.
            "--ttl-eq" => {
                self.i += 1;
                let (v, neg) = self.take_value_neg("--ttl-eq")?;
                self.cmd.spec.modules.push(MatchModule::Ttl { op: TtlMatchOp::Eq, value: parse_u8_flexible(&v), neg });
                Ok(())
            }
            "--ttl-gt" => {
                self.i += 1;
                let (v, neg) = self.take_value_neg("--ttl-gt")?;
                self.cmd.spec.modules.push(MatchModule::Ttl { op: TtlMatchOp::Gt, value: parse_u8_flexible(&v), neg });
                Ok(())
            }
            "--ttl-lt" => {
                self.i += 1;
                let (v, neg) = self.take_value_neg("--ttl-lt")?;
                self.cmd.spec.modules.push(MatchModule::Ttl { op: TtlMatchOp::Lt, value: parse_u8_flexible(&v), neg });
                Ok(())
            }
            "--hl-eq" => {
                self.i += 1;
                let (v, neg) = self.take_value_neg("--hl-eq")?;
                self.cmd.spec.modules.push(MatchModule::Hl { op: TtlMatchOp::Eq, value: parse_u8_flexible(&v), neg });
                Ok(())
            }
            "--hl-gt" => {
                self.i += 1;
                let (v, neg) = self.take_value_neg("--hl-gt")?;
                self.cmd.spec.modules.push(MatchModule::Hl { op: TtlMatchOp::Gt, value: parse_u8_flexible(&v), neg });
                Ok(())
            }
            "--hl-lt" => {
                self.i += 1;
                let (v, neg) = self.take_value_neg("--hl-lt")?;
                self.cmd.spec.modules.push(MatchModule::Hl { op: TtlMatchOp::Lt, value: parse_u8_flexible(&v), neg });
                Ok(())
            }
            // -j TTL / -j HL.
            "--ttl-set" => {
                self.i += 1;
                let v = self.take_value("--ttl-set")?;
                self.cmd.spec.target = Some(Target::Ttl(TtlOp::Set(parse_u8_flexible(&v))));
                Ok(())
            }
            "--ttl-dec" => {
                self.i += 1;
                let v = self.take_value("--ttl-dec")?;
                self.cmd.spec.target = Some(Target::Ttl(TtlOp::Dec(parse_u8_flexible(&v))));
                Ok(())
            }
            "--ttl-inc" => {
                self.i += 1;
                let v = self.take_value("--ttl-inc")?;
                self.cmd.spec.target = Some(Target::Ttl(TtlOp::Inc(parse_u8_flexible(&v))));
                Ok(())
            }
            "--hl-set" => {
                self.i += 1;
                let v = self.take_value("--hl-set")?;
                self.cmd.spec.target = Some(Target::Hl(TtlOp::Set(parse_u8_flexible(&v))));
                Ok(())
            }
            "--hl-dec" => {
                self.i += 1;
                let v = self.take_value("--hl-dec")?;
                self.cmd.spec.target = Some(Target::Hl(TtlOp::Dec(parse_u8_flexible(&v))));
                Ok(())
            }
            "--hl-inc" => {
                self.i += 1;
                let v = self.take_value("--hl-inc")?;
                self.cmd.spec.target = Some(Target::Hl(TtlOp::Inc(parse_u8_flexible(&v))));
                Ok(())
            }
            // -m statistic --mode random|nth, or -m policy --mode tunnel|transport.
            "--mode" => {
                self.i += 1;
                let v = self.take_value("--mode")?;
                // Route to policy when in_module is "policy" or a Policy
                // module has already been started by --pol/--dir/etc.
                if matches!(self.in_module.as_deref(), Some("policy"))
                    || self.cmd.spec.modules.iter().any(|m| matches!(m, MatchModule::Policy { .. }))
                {
                    merge_policy(&mut self.cmd.spec.modules, |p| p.mode = Some(v));
                    return Ok(());
                }
                let stat = match v.as_str() {
                    "random" => StatisticOp::Random { probability_ppb: 0 },
                    "nth"    => StatisticOp::Nth { every: 0, packet: 0 },
                    _ => return Err(err(format!("statistic --mode '{}' not supported", v))),
                };
                self.cmd.spec.modules.push(MatchModule::Statistic(stat));
                Ok(())
            }
            "--probability" => {
                self.i += 1;
                let (v, _neg) = self.take_value_neg("--probability")?;
                let p: f64 = v.parse().unwrap_or(0.0);
                // Convert F ∈ [0.0, 1.0] to parts-per-billion (lossless
                // for the precisions iptables actually accepts; matches
                // the nft lowering's modulus).
                let ppb = (p.clamp(0.0, 1.0) * 1_000_000_000.0) as u32;
                if let Some(MatchModule::Statistic(StatisticOp::Random { probability_ppb }))
                    = self.cmd.spec.modules.iter_mut().rev()
                        .find(|m| matches!(m, MatchModule::Statistic(StatisticOp::Random { .. })))
                {
                    *probability_ppb = ppb;
                }
                Ok(())
            }
            "--every" => {
                self.i += 1;
                let (v, _neg) = self.take_value_neg("--every")?;
                let n: u32 = v.parse().unwrap_or(0);
                if let Some(MatchModule::Statistic(StatisticOp::Nth { every, .. }))
                    = self.cmd.spec.modules.iter_mut().rev()
                        .find(|m| matches!(m, MatchModule::Statistic(StatisticOp::Nth { .. })))
                {
                    *every = n;
                }
                Ok(())
            }
            "--packet" => {
                self.i += 1;
                let v = self.take_value("--packet")?;
                let p: u32 = v.parse().unwrap_or(0);
                if let Some(MatchModule::Statistic(StatisticOp::Nth { packet, .. }))
                    = self.cmd.spec.modules.iter_mut().rev()
                        .find(|m| matches!(m, MatchModule::Statistic(StatisticOp::Nth { .. })))
                {
                    *packet = p;
                }
                Ok(())
            }
            // -m connlimit
            "--connlimit-above" => {
                self.i += 1;
                let v = self.take_value("--connlimit-above")?;
                let n: u32 = v.parse().unwrap_or(0);
                merge_connlimit(&mut self.cmd.spec.modules, |c| { c.above = true; c.n = n; });
                Ok(())
            }
            "--connlimit-upto" => {
                self.i += 1;
                let v = self.take_value("--connlimit-upto")?;
                let n: u32 = v.parse().unwrap_or(0);
                merge_connlimit(&mut self.cmd.spec.modules, |c| { c.above = false; c.n = n; });
                Ok(())
            }
            "--connlimit-mask" => {
                self.i += 1;
                let v = self.take_value("--connlimit-mask")?;
                let n: u8 = v.parse().unwrap_or(0);
                merge_connlimit(&mut self.cmd.spec.modules, |c| c.mask = Some(n));
                Ok(())
            }
            "--connlimit-saddr" => {
                self.i += 1;
                merge_connlimit(&mut self.cmd.spec.modules, |c| c.on_dest = false);
                Ok(())
            }
            "--connlimit-daddr" => {
                self.i += 1;
                merge_connlimit(&mut self.cmd.spec.modules, |c| c.on_dest = true);
                Ok(())
            }
            // -m helper handler is unified at the existing `--helper`
            // arm above (search for --helper in the file). It now
            // checks `in_module` to disambiguate the match from
            // -j CT --helper.
            // -m time
            "--timestart" => {
                self.i += 1;
                let v = self.take_value("--timestart")?;
                merge_time(&mut self.cmd.spec.modules, |t| t.start = Some(v));
                Ok(())
            }
            "--timestop" => {
                self.i += 1;
                let v = self.take_value("--timestop")?;
                merge_time(&mut self.cmd.spec.modules, |t| t.stop = Some(v));
                Ok(())
            }
            "--weekdays" => {
                self.i += 1;
                let (v, _neg) = self.take_value_neg("--weekdays")?;
                let days: Vec<String> = v.split(',')
                    .map(|d| weekday_to_full(d.trim()).to_string())
                    .collect();
                merge_time(&mut self.cmd.spec.modules, |t| t.weekdays = days);
                Ok(())
            }
            "--monthdays" => {
                // No first-class nft equivalent; consumed for compat.
                self.i += 1;
                let _ = self.take_value("--monthdays")?;
                Ok(())
            }
            "--datestart" | "--datestop" => {
                self.i += 1;
                let _ = self.take_value("--datestart")?;
                // Date-window not lowered; iptables-save would preserve
                // via comment if desired.
                Ok(())
            }
            "--contiguous" => {
                self.i += 1;
                merge_time(&mut self.cmd.spec.modules, |t| t.contiguous = true);
                Ok(())
            }
            "--kerneltz" => {
                self.i += 1;
                merge_time(&mut self.cmd.spec.modules, |t| t.kerneltz = true);
                Ok(())
            }
            // -m rpfilter
            "--loose" => {
                self.i += 1;
                merge_rpfilter(&mut self.cmd.spec.modules, |r| r.loose = true);
                Ok(())
            }
            "--validmark" => {
                self.i += 1;
                merge_rpfilter(&mut self.cmd.spec.modules, |r| r.validmark = true);
                Ok(())
            }
            "--accept-local" => {
                self.i += 1;
                merge_rpfilter(&mut self.cmd.spec.modules, |r| r.accept_local = true);
                Ok(())
            }
            "--invert" => {
                self.i += 1;
                merge_rpfilter(&mut self.cmd.spec.modules, |r| r.invert = true);
                Ok(())
            }
            // -m recent
            "--set" => {
                self.i += 1;
                merge_recent(&mut self.cmd.spec.modules, |r| r.op = RecentOp::Set);
                Ok(())
            }
            "--rcheck" => {
                self.i += 1;
                merge_recent(&mut self.cmd.spec.modules, |r| r.op = RecentOp::Rcheck);
                Ok(())
            }
            "--update" => {
                self.i += 1;
                merge_recent(&mut self.cmd.spec.modules, |r| r.op = RecentOp::Update);
                Ok(())
            }
            "--remove" => {
                self.i += 1;
                merge_recent(&mut self.cmd.spec.modules, |r| r.op = RecentOp::Remove);
                Ok(())
            }
            "--name" => {
                self.i += 1;
                let v = self.take_value("--name")?;
                merge_recent(&mut self.cmd.spec.modules, |r| r.name = v);
                Ok(())
            }
            "--seconds" => {
                self.i += 1;
                let v = self.take_value("--seconds")?;
                let n: u32 = v.parse().unwrap_or(0);
                merge_recent(&mut self.cmd.spec.modules, |r| r.seconds = Some(n));
                Ok(())
            }
            "--hitcount" => {
                self.i += 1;
                let v = self.take_value("--hitcount")?;
                let n: u32 = v.parse().unwrap_or(0);
                merge_recent(&mut self.cmd.spec.modules, |r| r.hitcount = Some(n));
                Ok(())
            }
            "--rsource" => {
                self.i += 1;
                merge_recent(&mut self.cmd.spec.modules, |r| r.on_dest = false);
                Ok(())
            }
            "--rdest" => {
                self.i += 1;
                merge_recent(&mut self.cmd.spec.modules, |r| r.on_dest = true);
                Ok(())
            }
            "--mask" => {
                // recent --mask CIDR-prefix. Consumed for compat; the
                // nft set-based equivalent would require extra
                // plumbing to express the per-prefix grouping.
                self.i += 1;
                let _ = self.take_value("--mask")?;
                Ok(())
            }
            "--reap" | "--rttl" => {
                // recent --reap (auto-expire) and --rttl (require ttl
                // match). Both flag-only; consumed for compat.
                self.i += 1;
                Ok(())
            }
            // -m connbytes
            "--connbytes" => {
                self.i += 1;
                let (v, neg) = self.take_value_neg("--connbytes")?;
                let (lo, hi) = match v.find(':') {
                    Some(i) => (
                        v[..i].parse::<u64>().unwrap_or(0),
                        Some(v[i+1..].parse::<u64>().unwrap_or(u64::MAX)),
                    ),
                    None => (v.parse::<u64>().unwrap_or(0), None),
                };
                merge_connbytes(&mut self.cmd.spec.modules, |c| {
                    c.lo = lo; c.hi = hi; c.neg = neg;
                });
                Ok(())
            }
            "--connbytes-dir" => {
                self.i += 1;
                let v = self.take_value("--connbytes-dir")?;
                let dir = match v.as_str() {
                    "original" => ConnbytesDir::Original,
                    "reply"    => ConnbytesDir::Reply,
                    _          => ConnbytesDir::Both,
                };
                merge_connbytes(&mut self.cmd.spec.modules, |c| c.dir = dir);
                Ok(())
            }
            "--connbytes-mode" => {
                self.i += 1;
                let v = self.take_value("--connbytes-mode")?;
                let mode = match v.as_str() {
                    "packets" => ConnbytesMode::Packets,
                    "bytes"   => ConnbytesMode::Bytes,
                    "avgpkt"  => ConnbytesMode::Avgpkt,
                    _         => ConnbytesMode::Packets,
                };
                merge_connbytes(&mut self.cmd.spec.modules, |c| c.mode = mode);
                Ok(())
            }
            // -j CLASSIFY
            "--set-class" => {
                self.i += 1;
                let v = self.take_value("--set-class")?;
                let (maj, min) = match v.find(':') {
                    Some(i) => (
                        u16::from_str_radix(&v[..i], 16).unwrap_or(0),
                        u16::from_str_radix(&v[i+1..], 16).unwrap_or(0),
                    ),
                    None => (u16::from_str_radix(&v, 16).unwrap_or(0), 0),
                };
                self.cmd.spec.target = Some(Target::Classify { major: maj, minor: min });
                Ok(())
            }
            // -j CHECKSUM
            "--checksum-fill" => {
                self.i += 1;
                self.cmd.spec.target = Some(Target::Checksum);
                Ok(())
            }
            // -j NETMAP
            "--to" => {
                self.i += 1;
                let v = self.take_value("--to")?;
                self.cmd.spec.target = Some(Target::Netmap { to_prefix: v });
                Ok(())
            }
            // -j SET
            "--add-set" => {
                self.i += 1;
                let name = self.take_value("--add-set")?;
                let dirs_raw = self.take_value("--add-set")?;
                let dirs: Vec<String> = dirs_raw.split(',').map(|s| s.trim().to_string()).collect();
                self.cmd.spec.target = Some(Target::Set { name, dirs, op: SetOp::Add, exist: false, timeout: None });
                Ok(())
            }
            "--del-set" => {
                self.i += 1;
                let name = self.take_value("--del-set")?;
                let dirs_raw = self.take_value("--del-set")?;
                let dirs: Vec<String> = dirs_raw.split(',').map(|s| s.trim().to_string()).collect();
                self.cmd.spec.target = Some(Target::Set { name, dirs, op: SetOp::Del, exist: false, timeout: None });
                Ok(())
            }
            "--exist" => {
                self.i += 1;
                if let Some(Target::Set { exist, .. }) = self.cmd.spec.target.as_mut() {
                    *exist = true;
                }
                Ok(())
            }
            "--timeout" => {
                self.i += 1;
                let v = self.take_value("--timeout")?;
                let t: u32 = v.parse().unwrap_or(0);
                if let Some(Target::Set { timeout, .. }) = self.cmd.spec.target.as_mut() {
                    *timeout = Some(t);
                }
                Ok(())
            }
            "--to-source" => {
                self.i += 1;
                let v = self.take_value("--to-source")?;
                self.cmd.spec.target = Some(Target::Snat {
                    to_source: v, random: false, random_fully: false, persistent: false,
                });
                Ok(())
            }
            "--to-destination" => {
                self.i += 1;
                let v = self.take_value("--to-destination")?;
                self.cmd.spec.target = Some(Target::Dnat {
                    to_destination: v, random: false, random_fully: false, persistent: false,
                });
                Ok(())
            }
            "--to-ports" => {
                self.i += 1;
                let v = self.take_value("--to-ports")?;
                let r = parse_port_range(&v)?;
                // Could be MASQUERADE --to-ports or REDIRECT --to-ports.
                match self.cmd.spec.target.clone() {
                    Some(Target::Masquerade { random, random_fully, .. }) =>
                        self.cmd.spec.target = Some(Target::Masquerade {
                            to_ports: Some(r), random, random_fully,
                        }),
                    Some(Target::Redirect { random, .. }) =>
                        self.cmd.spec.target = Some(Target::Redirect { to_ports: Some(r), random }),
                    _ => self.cmd.spec.target = Some(Target::Redirect { to_ports: Some(r), random: false }),
                }
                Ok(())
            }
            "--random" => {
                self.i += 1;
                match self.cmd.spec.target.clone() {
                    Some(Target::Masquerade { to_ports, random_fully, .. }) => {
                        self.cmd.spec.target = Some(Target::Masquerade {
                            to_ports, random: true, random_fully,
                        });
                    }
                    Some(Target::Snat { to_source, random_fully, persistent, .. }) =>
                        self.cmd.spec.target = Some(Target::Snat {
                            to_source, random: true, random_fully, persistent,
                        }),
                    Some(Target::Dnat { to_destination, random_fully, persistent, .. }) =>
                        self.cmd.spec.target = Some(Target::Dnat {
                            to_destination, random: true, random_fully, persistent,
                        }),
                    Some(Target::Redirect { to_ports, .. }) =>
                        self.cmd.spec.target = Some(Target::Redirect { to_ports, random: true }),
                    _ => {} // Ignore on other targets.
                }
                Ok(())
            }
            "--random-fully" => {
                self.i += 1;
                match self.cmd.spec.target.clone() {
                    Some(Target::Masquerade { to_ports, random, .. }) =>
                        self.cmd.spec.target = Some(Target::Masquerade {
                            to_ports, random, random_fully: true,
                        }),
                    Some(Target::Snat { to_source, random, persistent, .. }) =>
                        self.cmd.spec.target = Some(Target::Snat {
                            to_source, random, random_fully: true, persistent,
                        }),
                    Some(Target::Dnat { to_destination, random, persistent, .. }) =>
                        self.cmd.spec.target = Some(Target::Dnat {
                            to_destination, random, random_fully: true, persistent,
                        }),
                    _ => {}
                }
                Ok(())
            }
            "--persistent" => {
                self.i += 1;
                match self.cmd.spec.target.clone() {
                    Some(Target::Snat { to_source, random, random_fully, .. }) =>
                        self.cmd.spec.target = Some(Target::Snat {
                            to_source, random, random_fully, persistent: true,
                        }),
                    Some(Target::Dnat { to_destination, random, random_fully, .. }) =>
                        self.cmd.spec.target = Some(Target::Dnat {
                            to_destination, random, random_fully, persistent: true,
                        }),
                    _ => {}
                }
                Ok(())
            }
            // -m physdev family.
            "--physdev-in" => {
                self.i += 1;
                let v = self.take_value("--physdev-in")?;
                self.merge_physdev(|p| p.iin = Some(v));
                Ok(())
            }
            "--physdev-out" => {
                self.i += 1;
                let v = self.take_value("--physdev-out")?;
                self.merge_physdev(|p| p.oout = Some(v));
                Ok(())
            }
            "--physdev-is-bridged" => {
                self.i += 1;
                self.merge_physdev(|p| p.is_bridged = true);
                Ok(())
            }
            "--uid-owner" => {
                self.i += 1;
                let v = self.take_value("--uid-owner")?.parse().unwrap_or(0);
                self.merge_owner(|o| o.uid = Some(v));
                Ok(())
            }
            "--gid-owner" => {
                self.i += 1;
                let v = self.take_value("--gid-owner")?.parse().unwrap_or(0);
                self.merge_owner(|o| o.gid = Some(v));
                Ok(())
            }
            "--match-set" => {
                self.i += 1;
                let (name, neg) = self.take_value_neg("--match-set")?;
                let dirs_raw = self.take_value("--match-set")?;
                let dirs = dirs_raw.split(',').map(|s| s.trim().to_string()).collect();
                self.cmd.spec.modules.push(MatchModule::Set { name, dirs, neg });
                Ok(())
            }
            "--mac-source" => {
                self.i += 1;
                let (s, neg) = self.take_value_neg("--mac-source")?;
                self.cmd.spec.modules.push(MatchModule::Mac { source: s, neg });
                Ok(())
            }
            "--string" => {
                self.i += 1;
                let s = self.take_value("--string")?;
                let algo = if matches!(self.peek(), Some("--algo")) {
                    self.i += 1; self.take_value("--algo")?
                } else { "bm".to_string() };
                self.cmd.spec.modules.push(MatchModule::String { s, algo });
                Ok(())
            }
            // NFLOG fields.
            "--nflog-prefix" => {
                self.i += 1;
                let v = self.take_value("--nflog-prefix")?;
                merge_nflog(&mut self.cmd.spec.target, |t| t.prefix = Some(v));
                Ok(())
            }
            "--nflog-group" => {
                self.i += 1;
                let v = self.take_value("--nflog-group")?.parse().unwrap_or(0);
                merge_nflog(&mut self.cmd.spec.target, |t| t.group = Some(v));
                Ok(())
            }
            // -m hashlimit flags.
            "--hashlimit-upto" => {
                self.i += 1;
                let v = self.take_value("--hashlimit-upto")?;
                let (rate, unit) = parse_rate_spec(&v);
                merge_hashlimit(&mut self.cmd.spec.modules, |h| h.upto = Some((rate, unit)));
                Ok(())
            }
            "--hashlimit-above" => {
                self.i += 1;
                let v = self.take_value("--hashlimit-above")?;
                let (rate, unit) = parse_rate_spec(&v);
                merge_hashlimit(&mut self.cmd.spec.modules, |h| h.above = Some((rate, unit)));
                Ok(())
            }
            "--hashlimit-burst" => {
                self.i += 1;
                let v = self.take_value("--hashlimit-burst")?;
                let n: u32 = v.parse().unwrap_or(5);
                merge_hashlimit(&mut self.cmd.spec.modules, |h| h.burst = Some(n));
                Ok(())
            }
            "--hashlimit-name" => {
                self.i += 1;
                let v = self.take_value("--hashlimit-name")?;
                merge_hashlimit(&mut self.cmd.spec.modules, |h| h.name = Some(v));
                Ok(())
            }
            "--hashlimit-mode" => {
                self.i += 1;
                let v = self.take_value("--hashlimit-mode")?;
                merge_hashlimit(&mut self.cmd.spec.modules, |h| h.mode = Some(v));
                Ok(())
            }
            "--hashlimit-srcmask" => {
                self.i += 1;
                let v = self.take_value("--hashlimit-srcmask")?;
                let n: u8 = v.parse().unwrap_or(32);
                merge_hashlimit(&mut self.cmd.spec.modules, |h| h.srcmask = Some(n));
                Ok(())
            }
            "--hashlimit-dstmask" => {
                self.i += 1;
                let v = self.take_value("--hashlimit-dstmask")?;
                let n: u8 = v.parse().unwrap_or(32);
                merge_hashlimit(&mut self.cmd.spec.modules, |h| h.dstmask = Some(n));
                Ok(())
            }
            "--hashlimit-htable-size" => {
                self.i += 1;
                let v = self.take_value("--hashlimit-htable-size")?;
                let n: u32 = v.parse().unwrap_or(0);
                merge_hashlimit(&mut self.cmd.spec.modules, |h| h.htable_size = Some(n));
                Ok(())
            }
            "--hashlimit-htable-max" => {
                self.i += 1;
                let v = self.take_value("--hashlimit-htable-max")?;
                let n: u32 = v.parse().unwrap_or(0);
                merge_hashlimit(&mut self.cmd.spec.modules, |h| h.htable_max = Some(n));
                Ok(())
            }
            "--hashlimit-htable-expire" => {
                self.i += 1;
                let v = self.take_value("--hashlimit-htable-expire")?;
                let n: u32 = v.parse().unwrap_or(0);
                merge_hashlimit(&mut self.cmd.spec.modules, |h| h.htable_expire = Some(n));
                Ok(())
            }
            "--hashlimit-htable-gcinterval" => {
                self.i += 1;
                let v = self.take_value("--hashlimit-htable-gcinterval")?;
                let n: u32 = v.parse().unwrap_or(0);
                merge_hashlimit(&mut self.cmd.spec.modules, |h| h.htable_gcinterval = Some(n));
                Ok(())
            }
            "--hashlimit-rate-match" => {
                self.i += 1;
                merge_hashlimit(&mut self.cmd.spec.modules, |h| h.rate_match = true);
                Ok(())
            }
            "--hashlimit-rate-interval" => {
                self.i += 1;
                let v = self.take_value("--hashlimit-rate-interval")?;
                let n: u32 = v.parse().unwrap_or(0);
                merge_hashlimit(&mut self.cmd.spec.modules, |h| h.rate_interval = Some(n));
                Ok(())
            }
            // -m policy flags.
            "--dir" => {
                // Disambiguate: -m policy --dir vs -m statistic --mode
                // Both occur in the same flat namespace; we route to
                // policy when in_module is "policy" (or any non-statistic
                // context that already has a Policy module started).
                if matches!(self.in_module.as_deref(), Some("policy"))
                    || self.cmd.spec.modules.iter().any(|m| matches!(m, MatchModule::Policy { .. }))
                {
                    self.i += 1;
                    let v = self.take_value("--dir")?;
                    merge_policy(&mut self.cmd.spec.modules, |p| p.dir = Some(v));
                    Ok(())
                } else {
                    // Could also be statistic context; fall through as unknown.
                    Err(err("--dir requires -m policy context"))
                }
            }
            "--pol" => {
                self.i += 1;
                let v = self.take_value("--pol")?;
                merge_policy(&mut self.cmd.spec.modules, |p| p.pol = Some(v));
                Ok(())
            }
            "--strict" => {
                self.i += 1;
                merge_policy(&mut self.cmd.spec.modules, |p| p.strict = true);
                Ok(())
            }
            "--reqid" => {
                self.i += 1;
                let v = self.take_value("--reqid")?;
                let n: u32 = v.parse().unwrap_or(0);
                merge_policy(&mut self.cmd.spec.modules, |p| p.reqid = Some(n));
                Ok(())
            }
            "--spi" => {
                self.i += 1;
                let v = self.take_value("--spi")?;
                let n: u32 = v.parse().unwrap_or(0);
                merge_policy(&mut self.cmd.spec.modules, |p| p.spi = Some(n));
                Ok(())
            }
            // --proto: policy module only (distinct from -p / --protocol).
            "--proto" => {
                self.i += 1;
                let v = self.take_value("--proto")?;
                merge_policy(&mut self.cmd.spec.modules, |p| p.proto = Some(v));
                Ok(())
            }
            "--tunnel-src" => {
                self.i += 1;
                let v = self.take_value("--tunnel-src")?;
                merge_policy(&mut self.cmd.spec.modules, |p| p.tunnel_src = Some(v));
                Ok(())
            }
            "--tunnel-dst" => {
                self.i += 1;
                let v = self.take_value("--tunnel-dst")?;
                merge_policy(&mut self.cmd.spec.modules, |p| p.tunnel_dst = Some(v));
                Ok(())
            }
            "--next" => {
                self.i += 1;
                merge_policy(&mut self.cmd.spec.modules, |p| p.next = true);
                Ok(())
            }
            // TPROXY fields.
            "--on-port" => {
                self.i += 1;
                let v: u16 = self.take_value("--on-port")?.parse().unwrap_or(0);
                merge_tproxy(&mut self.cmd.spec.target, |t| t.on_port = Some(v));
                Ok(())
            }
            "--on-ip" => {
                self.i += 1;
                let v = self.take_value("--on-ip")?;
                merge_tproxy(&mut self.cmd.spec.target, |t| t.on_ip = Some(v));
                Ok(())
            }
            "--tproxy-mark" => {
                self.i += 1;
                let v = self.take_value("--tproxy-mark")?;
                let (val, mask) = parse_mark_mask(&v)?;
                merge_tproxy(&mut self.cmd.spec.target, |t| t.mark = Some((val, mask)));
                Ok(())
            }
            // -m ah: --ahspi, --ahlen, --ahres
            "--ahspi" => {
                self.i += 1;
                let (v, neg) = self.take_value_neg("--ahspi")?;
                let spi: u32 = v.parse().unwrap_or(0);
                merge_ah(&mut self.cmd.spec.modules, |a| { a.spi = spi; if neg { a.neg = true; } });
                Ok(())
            }
            "--ahlen" => {
                self.i += 1;
                let v = self.take_value("--ahlen")?;
                let n: u32 = v.parse().unwrap_or(0);
                merge_ah(&mut self.cmd.spec.modules, |a| a.len = Some(n));
                Ok(())
            }
            "--ahres" => {
                self.i += 1;
                merge_ah(&mut self.cmd.spec.modules, |a| a.res = true);
                Ok(())
            }
            // -m esp: --espspi
            "--espspi" => {
                self.i += 1;
                let (v, neg) = self.take_value_neg("--espspi")?;
                let spi: u32 = v.parse().unwrap_or(0);
                self.cmd.spec.modules.push(MatchModule::Esp { spi, neg });
                Ok(())
            }
            // -m frag: --fragid, --fraglen, --fragres, --fragfirst, --fragmore, --fraglast
            "--fragid" => {
                self.i += 1;
                let (v, neg) = self.take_value_neg("--fragid")?;
                let id: u32 = v.parse().unwrap_or(0);
                merge_frag(&mut self.cmd.spec.modules, |fr| { fr.id = Some(id); if neg { fr.neg = true; } });
                Ok(())
            }
            "--fraglen" => {
                self.i += 1;
                let v = self.take_value("--fraglen")?;
                let n: u32 = v.parse().unwrap_or(0);
                merge_frag(&mut self.cmd.spec.modules, |fr| fr.len = Some(n));
                Ok(())
            }
            "--fragres" => {
                self.i += 1;
                merge_frag(&mut self.cmd.spec.modules, |fr| fr.res = true);
                Ok(())
            }
            "--fragfirst" => {
                self.i += 1;
                merge_frag(&mut self.cmd.spec.modules, |fr| fr.first = true);
                Ok(())
            }
            "--fragmore" => {
                self.i += 1;
                merge_frag(&mut self.cmd.spec.modules, |fr| fr.more = true);
                Ok(())
            }
            "--fraglast" => {
                self.i += 1;
                merge_frag(&mut self.cmd.spec.modules, |fr| fr.last = true);
                Ok(())
            }
            // -m hbh: --hbh-len, --hbh-opts
            "--hbh-len" => {
                self.i += 1;
                let v = self.take_value("--hbh-len")?;
                let n: u32 = v.parse().unwrap_or(0);
                merge_hbh(&mut self.cmd.spec.modules, |h| h.len = Some(n));
                Ok(())
            }
            "--hbh-opts" => {
                self.i += 1;
                let v = self.take_value("--hbh-opts")?;
                let opts: Vec<String> = v.split(',').map(|s| s.trim().to_string()).collect();
                merge_hbh(&mut self.cmd.spec.modules, |h| h.opts = opts);
                Ok(())
            }
            // -m mh: --mh-type
            "--mh-type" => {
                self.i += 1;
                let v = self.take_value("--mh-type")?;
                self.cmd.spec.modules.push(MatchModule::Mh { mh_type: v });
                Ok(())
            }
            // -m rt: --rt-type, --rt-segsleft, --rt-len, --rt-0-res, --rt-0-addrs, --rt-0-not-strict
            "--rt-type" => {
                self.i += 1;
                let v = self.take_value("--rt-type")?;
                let n: u32 = v.parse().unwrap_or(0);
                merge_rt(&mut self.cmd.spec.modules, |r| r.rt_type = Some(n));
                Ok(())
            }
            "--rt-segsleft" => {
                self.i += 1;
                let v = self.take_value("--rt-segsleft")?;
                let n: u32 = v.parse().unwrap_or(0);
                merge_rt(&mut self.cmd.spec.modules, |r| r.segs_left = Some(n));
                Ok(())
            }
            "--rt-len" => {
                self.i += 1;
                let v = self.take_value("--rt-len")?;
                let n: u32 = v.parse().unwrap_or(0);
                merge_rt(&mut self.cmd.spec.modules, |r| r.len = Some(n));
                Ok(())
            }
            "--rt-0-res" => {
                self.i += 1;
                merge_rt(&mut self.cmd.spec.modules, |r| r.rt0_res = true);
                Ok(())
            }
            "--rt-0-addrs" => {
                self.i += 1;
                let v = self.take_value("--rt-0-addrs")?;
                let addrs: Vec<String> = v.split(',').map(|s| s.trim().to_string()).collect();
                merge_rt(&mut self.cmd.spec.modules, |r| r.rt0_addrs = addrs);
                Ok(())
            }
            "--rt-0-not-strict" => {
                self.i += 1;
                merge_rt(&mut self.cmd.spec.modules, |r| r.rt0_strict = false);
                Ok(())
            }
            // -m dst: --dst-len, --dst-opts
            "--dst-len" => {
                self.i += 1;
                let v = self.take_value("--dst-len")?;
                let n: u32 = v.parse().unwrap_or(0);
                merge_dst(&mut self.cmd.spec.modules, |d| d.len = Some(n));
                Ok(())
            }
            "--dst-opts" => {
                self.i += 1;
                let v = self.take_value("--dst-opts")?;
                let opts: Vec<String> = v.split(',').map(|s| s.trim().to_string()).collect();
                merge_dst(&mut self.cmd.spec.modules, |d| d.opts = opts);
                Ok(())
            }
            // -m ipv6header: --soft, --header
            "--soft" => {
                self.i += 1;
                merge_ipv6header(&mut self.cmd.spec.modules, |h| h.soft = true);
                Ok(())
            }
            "--header" => {
                self.i += 1;
                let v = self.take_value("--header")?;
                let headers: Vec<String> = v.split(',').map(|s| s.trim().to_string()).collect();
                merge_ipv6header(&mut self.cmd.spec.modules, |h| h.headers = headers);
                Ok(())
            }
            other => {
                // Unrecognised. iptables treats unknown long options as
                // hard errors; we mirror that. Stop with a clean message.
                Err(err(format!("unknown flag: {}", other)))
            }
        }
    }

    fn merge_physdev<F: FnOnce(&mut PhysdevAcc)>(&mut self, f: F) {
        // Walk modules backwards looking for an existing Physdev to
        // update; otherwise push a fresh one.
        for m in self.cmd.spec.modules.iter_mut().rev() {
            if let MatchModule::Physdev { iin, oout, is_bridged } = m {
                let mut acc = PhysdevAcc {
                    iin: iin.clone(), oout: oout.clone(), is_bridged: *is_bridged
                };
                f(&mut acc);
                *iin = acc.iin;
                *oout = acc.oout;
                *is_bridged = acc.is_bridged;
                return;
            }
        }
        let mut acc = PhysdevAcc::default();
        f(&mut acc);
        self.cmd.spec.modules.push(MatchModule::Physdev {
            iin: acc.iin, oout: acc.oout, is_bridged: acc.is_bridged,
        });
    }

    fn merge_owner<F: FnOnce(&mut OwnerAcc)>(&mut self, f: F) {
        for m in self.cmd.spec.modules.iter_mut().rev() {
            if let MatchModule::Owner { uid, gid } = m {
                let mut acc = OwnerAcc { uid: *uid, gid: *gid };
                f(&mut acc);
                *uid = acc.uid;
                *gid = acc.gid;
                return;
            }
        }
        let mut acc = OwnerAcc::default();
        f(&mut acc);
        self.cmd.spec.modules.push(MatchModule::Owner { uid: acc.uid, gid: acc.gid });
    }
}

#[derive(Default)]
struct PhysdevAcc { iin: Option<String>, oout: Option<String>, is_bridged: bool }

#[derive(Default)]
struct OwnerAcc { uid: Option<u32>, gid: Option<u32> }

/// Map a target name to the right `Target` variant. Names with extra
/// arguments (REJECT, MARK, MASQUERADE, SNAT, DNAT, ...) get filled in
/// later when their `--*` flags appear; default to the no-arg form.
fn parse_target_name(name: &str) -> Target {
    match name {
        "ACCEPT"     => Target::Accept,
        "DROP"       => Target::Drop,
        "RETURN"     => Target::Return,
        "REJECT"     => Target::Reject(None),
        "LOG"        => Target::Log {
            prefix: None, level: None,
            tcp_sequence: false, tcp_options: false,
            ip_options: false, log_uid: false,
        },
        "MASQUERADE" => Target::Masquerade { to_ports: None, random: false, random_fully: false },
        "SNAT"       => Target::Snat { to_source: String::new(), random: false, random_fully: false, persistent: false },
        "DNAT"       => Target::Dnat { to_destination: String::new(), random: false, random_fully: false, persistent: false },
        "REDIRECT"   => Target::Redirect { to_ports: None, random: false },
        "MARK"       => Target::Mark { kind: MarkKind::Set, value: 0, mask: None },
        "CONNMARK"   => Target::Connmark(ConnmarkOp::SetMark { value: 0, mask: None }),
        "TPROXY"     => Target::Tproxy { on_port: None, on_ip: None, mark: None },
        "NFLOG"      => Target::Nflog { prefix: None, group: None },
        "TRACE"      => Target::Trace,
        "NOTRACK"    => Target::Notrack,
        "NFQUEUE"    => Target::Nfqueue { num: 0, balance_hi: None, bypass: false, fanout: false },
        "TCPMSS"     => Target::Tcpmss(TcpmssOp::ClampToPmtu),
        "CT"         => Target::Ct { notrack: false, helper: None, zone: None },
        "TOS"        => Target::Tos(TosOp::SetTos(0)),
        "DSCP"       => Target::Dscp(DscpOp::SetDscp(0)),
        "TTL"        => Target::Ttl(TtlOp::Set(0)),
        "HL"         => Target::Hl(TtlOp::Set(0)),
        "CLASSIFY"   => Target::Classify { major: 0, minor: 0 },
        "CHECKSUM"   => Target::Checksum,
        "NETMAP"     => Target::Netmap { to_prefix: String::new() },
        "SET"        => Target::Set { name: String::new(), dirs: Vec::new(), op: SetOp::Add, exist: false, timeout: None },
        // Anything else: treat as a chain jump. Real iptables resolves
        // this against the table's user-chain set; we punt that to the
        // lowerer so the message matches iptables' error text exactly.
        _ => Target::Jump(name.to_string()),
    }
}

fn promote_mark_target(cur: &Option<Target>, kind: MarkKind, val: u32, mask: Option<u32>) -> Target {
    match cur {
        Some(Target::Connmark(_)) => Target::Connmark(match kind {
            MarkKind::Set | MarkKind::Xset => ConnmarkOp::SetMark { value: val, mask },
            MarkKind::And => ConnmarkOp::And(val),
            MarkKind::Or  => ConnmarkOp::Or(val),
            MarkKind::Xor => ConnmarkOp::Xor(val),
        }),
        _ => Target::Mark { kind, value: val, mask },
    }
}

fn merge_log<F: FnOnce(&mut LogAcc)>(target: &mut Option<Target>, f: F) {
    match target {
        Some(Target::Log { prefix, level, tcp_sequence, tcp_options, ip_options, log_uid }) => {
            let mut acc = LogAcc {
                prefix: prefix.clone(), level: *level,
                tcp_sequence: *tcp_sequence, tcp_options: *tcp_options,
                ip_options: *ip_options, log_uid: *log_uid,
            };
            f(&mut acc);
            *prefix = acc.prefix;
            *level = acc.level;
            *tcp_sequence = acc.tcp_sequence;
            *tcp_options = acc.tcp_options;
            *ip_options = acc.ip_options;
            *log_uid = acc.log_uid;
        }
        _ => {
            let mut acc = LogAcc::default();
            f(&mut acc);
            *target = Some(Target::Log {
                prefix: acc.prefix, level: acc.level,
                tcp_sequence: acc.tcp_sequence, tcp_options: acc.tcp_options,
                ip_options: acc.ip_options, log_uid: acc.log_uid,
            });
        }
    }
}

#[derive(Default)]
struct LogAcc {
    prefix: Option<String>,
    level: Option<u8>,
    tcp_sequence: bool,
    tcp_options: bool,
    ip_options: bool,
    log_uid: bool,
}

fn merge_nflog<F: FnOnce(&mut NflogAcc)>(target: &mut Option<Target>, f: F) {
    match target {
        Some(Target::Nflog { prefix, group }) => {
            let mut acc = NflogAcc { prefix: prefix.clone(), group: *group };
            f(&mut acc);
            *prefix = acc.prefix;
            *group = acc.group;
        }
        _ => {
            let mut acc = NflogAcc::default();
            f(&mut acc);
            *target = Some(Target::Nflog { prefix: acc.prefix, group: acc.group });
        }
    }
}

#[derive(Default)]
struct NflogAcc { prefix: Option<String>, group: Option<u32> }

fn merge_tproxy<F: FnOnce(&mut TproxyAcc)>(target: &mut Option<Target>, f: F) {
    match target {
        Some(Target::Tproxy { on_port, on_ip, mark }) => {
            let mut acc = TproxyAcc { on_port: *on_port, on_ip: on_ip.clone(), mark: mark.clone() };
            f(&mut acc);
            *on_port = acc.on_port;
            *on_ip = acc.on_ip;
            *mark = acc.mark;
        }
        _ => {
            let mut acc = TproxyAcc::default();
            f(&mut acc);
            *target = Some(Target::Tproxy { on_port: acc.on_port, on_ip: acc.on_ip, mark: acc.mark });
        }
    }
}

#[derive(Default)]
struct TproxyAcc { on_port: Option<u16>, on_ip: Option<String>, mark: Option<(u32, Option<u32>)> }

/// Parse `value[/mask]` for mark-style flags. Both are u32 written in
/// hex (`0x100`), decimal, or octal (with `0` prefix). We honour the
/// `0x` prefix for hex and otherwise decimal; the kernel does the same.
pub fn parse_mark_mask(v: &str) -> Res<(u32, Option<u32>)> {
    let parse = |s: &str| -> Res<u32> {
        if let Some(rest) = s.strip_prefix("0x") {
            u32::from_str_radix(rest, 16).map_err(|_| err(format!("bad mark value: {}", s)))
        } else if let Some(rest) = s.strip_prefix("0X") {
            u32::from_str_radix(rest, 16).map_err(|_| err(format!("bad mark value: {}", s)))
        } else {
            s.parse::<u32>().map_err(|_| err(format!("bad mark value: {}", s)))
        }
    };
    if let Some(i) = v.find('/') {
        Ok((parse(&v[..i])?, Some(parse(&v[i+1..])?)))
    } else {
        Ok((parse(v)?, None))
    }
}

/// Parse a `start[:end]` port range. iptables also accepts `:end`
/// (start defaults to 0) and `start:` (end defaults to 65535).
pub fn parse_port_range(v: &str) -> Res<PortRange> {
    if let Some(i) = v.find(':') {
        let lo = if i == 0 { 0 } else { v[..i].parse::<u16>().map_err(|_| err(format!("bad port: {}", v)))? };
        let hi = if i + 1 == v.len() { 65535 } else { v[i+1..].parse::<u16>().map_err(|_| err(format!("bad port: {}", v)))? };
        Ok(PortRange { start: lo, end: hi })
    } else if let Some(i) = v.find('-') {
        // SNAT/DNAT-style port range uses '-' instead of ':'.
        let lo: u16 = v[..i].parse().map_err(|_| err(format!("bad port: {}", v)))?;
        let hi: u16 = v[i+1..].parse().map_err(|_| err(format!("bad port: {}", v)))?;
        Ok(PortRange { start: lo, end: hi })
    } else {
        let p: u16 = v.parse().map_err(|_| err(format!("bad port: {}", v)))?;
        Ok(PortRange { start: p, end: p })
    }
}

/// Parse `--dports 22,80,443,1000:2000` into a list of port ranges.
pub fn parse_multiport(v: &str, neg: bool) -> Res<MultiportList> {
    let mut items = Vec::new();
    for part in v.split(',') {
        let p = part.trim();
        if p.is_empty() { continue; }
        items.push(parse_port_range(p)?);
    }
    Ok(MultiportList { items, neg })
}

/// Parse `start-end` as an address range (no validation of family —
/// we pass the raw strings through; the lowerer emits them as
/// `ip saddr LO-HI` and the kernel's nft module enforces format).
pub fn parse_addr_range(v: &str) -> Res<(String, String)> {
    let dash = v.find('-')
        .ok_or_else(|| err(format!("expected LOW-HIGH range, got '{}'", v)))?;
    let lo = v[..dash].trim().to_string();
    let hi = v[dash+1..].trim().to_string();
    if lo.is_empty() || hi.is_empty() {
        return Err(err(format!("malformed range '{}'", v)));
    }
    Ok((lo, hi))
}

/// Find an existing -m iprange MatchModule in the modules list (so a
/// -m iprange clause that mentions both --src-range and --dst-range
/// folds into a single Iprange variant rather than two), or push a
/// fresh empty one. The closure mutates the variant in place.
fn merge_iprange<F: FnOnce(&mut IprangeAcc)>(modules: &mut Vec<MatchModule>, f: F) {
    if let Some(m) = modules.iter_mut().rev().find(|m| matches!(m, MatchModule::Iprange { .. })) {
        if let MatchModule::Iprange { src, dst, neg } = m {
            let mut acc = IprangeAcc { src: src.clone(), dst: dst.clone(), neg: *neg };
            f(&mut acc);
            *src = acc.src;
            *dst = acc.dst;
            *neg = acc.neg;
            return;
        }
    }
    let mut acc = IprangeAcc::default();
    f(&mut acc);
    modules.push(MatchModule::Iprange { src: acc.src, dst: acc.dst, neg: acc.neg });
}

#[derive(Default)]
struct IprangeAcc {
    src: Option<(String, String)>,
    dst: Option<(String, String)>,
    neg: bool,
}

/// Parse a TOS value: numeric (decimal/hex) with optional /MASK, or a
/// DiffServ symbolic name (Minimize-Delay, Maximize-Throughput, etc.).
/// Symbolic names map to the iptables-extensions table.
pub fn parse_tos_value(v: &str) -> Res<(u8, Option<u8>)> {
    let (val_s, mask_s) = match v.find('/') {
        Some(i) => (&v[..i], Some(&v[i+1..])),
        None    => (v, None),
    };
    let value = if let Some(n) = val_s.strip_prefix("0x").or_else(|| val_s.strip_prefix("0X")) {
        u8::from_str_radix(n, 16).map_err(|_| err(format!("bad TOS '{}'", v)))?
    } else if let Ok(n) = val_s.parse::<u8>() {
        n
    } else {
        match val_s.to_uppercase().as_str() {
            "BE" | "CS0" => 0,
            "MINIMIZE-DELAY" => 16,
            "MAXIMIZE-THROUGHPUT" => 8,
            "MAXIMIZE-RELIABILITY" => 4,
            "MINIMIZE-COST" => 2,
            "NORMAL-SERVICE" => 0,
            "EF" => 46,
            "AF11" => 10, "AF12" => 12, "AF13" => 14,
            "AF21" => 18, "AF22" => 20, "AF23" => 22,
            "AF31" => 26, "AF32" => 28, "AF33" => 30,
            "AF41" => 34, "AF42" => 36, "AF43" => 38,
            "CS1" => 8,  "CS2" => 16, "CS3" => 24,
            "CS4" => 32, "CS5" => 40, "CS6" => 48, "CS7" => 56,
            _ => return Err(err(format!("unknown TOS/DSCP class '{}'", val_s))),
        }
    };
    let mask = mask_s.map(|m| {
        if let Some(n) = m.strip_prefix("0x").or_else(|| m.strip_prefix("0X")) {
            u8::from_str_radix(n, 16).unwrap_or(0xff)
        } else {
            m.parse::<u8>().unwrap_or(0xff)
        }
    });
    Ok((value, mask))
}

/// Resolve a DiffServ class name (BE / EF / AFxx / CSx) to a numeric
/// 6-bit DSCP code point.
pub fn parse_dscp_class(s: &str) -> Option<u8> {
    Some(match s.to_uppercase().as_str() {
        "BE" | "CS0" => 0,
        "EF" => 46,
        "AF11" => 10, "AF12" => 12, "AF13" => 14,
        "AF21" => 18, "AF22" => 20, "AF23" => 22,
        "AF31" => 26, "AF32" => 28, "AF33" => 30,
        "AF41" => 34, "AF42" => 36, "AF43" => 38,
        "CS1" => 8,  "CS2" => 16, "CS3" => 24,
        "CS4" => 32, "CS5" => 40, "CS6" => 48, "CS7" => 56,
        _ => return None,
    })
}

/// Parse a numeric u8 in dec / hex (0xNN) / oct (0oNN).
pub fn parse_u8_flexible(s: &str) -> u8 {
    if let Some(h) = s.strip_prefix("0x").or_else(|| s.strip_prefix("0X")) {
        u8::from_str_radix(h, 16).unwrap_or(0)
    } else if let Some(o) = s.strip_prefix("0o").or_else(|| s.strip_prefix("0O")) {
        u8::from_str_radix(o, 8).unwrap_or(0)
    } else {
        s.parse::<u8>().unwrap_or(0)
    }
}

/// Normalise a weekday token to its full lowercase name. Accepts ISO
/// weekday numbers (1 = Monday … 7 = Sunday) and three-letter
/// abbreviations.
pub fn weekday_to_full(s: &str) -> &'static str {
    match s.to_lowercase().as_str() {
        "1" | "mon" | "monday"    => "monday",
        "2" | "tue" | "tuesday"   => "tuesday",
        "3" | "wed" | "wednesday" => "wednesday",
        "4" | "thu" | "thursday"  => "thursday",
        "5" | "fri" | "friday"    => "friday",
        "6" | "sat" | "saturday"  => "saturday",
        "7" | "sun" | "sunday"    => "sunday",
        _ => "monday",
    }
}

#[derive(Default)]
struct ConnlimitAcc { above: bool, n: u32, mask: Option<u8>, on_dest: bool }
fn merge_connlimit<F: FnOnce(&mut ConnlimitAcc)>(modules: &mut Vec<MatchModule>, f: F) {
    if let Some(m) = modules.iter_mut().rev()
        .find(|m| matches!(m, MatchModule::Connlimit { .. }))
    {
        if let MatchModule::Connlimit { above, n, mask, on_dest } = m {
            let mut acc = ConnlimitAcc { above: *above, n: *n, mask: *mask, on_dest: *on_dest };
            f(&mut acc);
            *above = acc.above;
            *n = acc.n;
            *mask = acc.mask;
            *on_dest = acc.on_dest;
            return;
        }
    }
    let mut acc = ConnlimitAcc::default();
    f(&mut acc);
    modules.push(MatchModule::Connlimit { above: acc.above, n: acc.n, mask: acc.mask, on_dest: acc.on_dest });
}

#[derive(Default)]
struct TimeAcc {
    start: Option<String>,
    stop: Option<String>,
    weekdays: Vec<String>,
    contiguous: bool,
    kerneltz: bool,
}
fn merge_time<F: FnOnce(&mut TimeAcc)>(modules: &mut Vec<MatchModule>, f: F) {
    if let Some(m) = modules.iter_mut().rev()
        .find(|m| matches!(m, MatchModule::Time { .. }))
    {
        if let MatchModule::Time { start, stop, weekdays, contiguous, kerneltz } = m {
            let mut acc = TimeAcc {
                start: start.clone(), stop: stop.clone(),
                weekdays: weekdays.clone(),
                contiguous: *contiguous, kerneltz: *kerneltz,
            };
            f(&mut acc);
            *start = acc.start;
            *stop = acc.stop;
            *weekdays = acc.weekdays;
            *contiguous = acc.contiguous;
            *kerneltz = acc.kerneltz;
            return;
        }
    }
    let mut acc = TimeAcc::default();
    f(&mut acc);
    modules.push(MatchModule::Time {
        start: acc.start, stop: acc.stop, weekdays: acc.weekdays,
        contiguous: acc.contiguous, kerneltz: acc.kerneltz,
    });
}

#[derive(Default)]
struct RecentAcc {
    op: RecentOp,
    name: String,
    seconds: Option<u32>,
    hitcount: Option<u32>,
    on_dest: bool,
    neg: bool,
}
impl Default for RecentOp {
    fn default() -> Self { RecentOp::Set }
}

fn merge_recent<F: FnOnce(&mut RecentAcc)>(modules: &mut Vec<MatchModule>, f: F) {
    if let Some(m) = modules.iter_mut().rev()
        .find(|m| matches!(m, MatchModule::Recent { .. }))
    {
        if let MatchModule::Recent { op, name, seconds, hitcount, on_dest, neg } = m {
            let mut acc = RecentAcc {
                op: *op, name: name.clone(),
                seconds: *seconds, hitcount: *hitcount,
                on_dest: *on_dest, neg: *neg,
            };
            f(&mut acc);
            *op = acc.op;
            *name = acc.name;
            *seconds = acc.seconds;
            *hitcount = acc.hitcount;
            *on_dest = acc.on_dest;
            *neg = acc.neg;
            return;
        }
    }
    let mut acc = RecentAcc::default();
    f(&mut acc);
    modules.push(MatchModule::Recent {
        op: acc.op, name: if acc.name.is_empty() { "DEFAULT".into() } else { acc.name },
        seconds: acc.seconds, hitcount: acc.hitcount,
        on_dest: acc.on_dest, neg: acc.neg,
    });
}

#[derive(Default)]
struct ConnbytesAcc {
    lo: u64,
    hi: Option<u64>,
    dir: ConnbytesDir,
    mode: ConnbytesMode,
    neg: bool,
}
impl Default for ConnbytesDir { fn default() -> Self { ConnbytesDir::Both } }
impl Default for ConnbytesMode { fn default() -> Self { ConnbytesMode::Packets } }

fn merge_connbytes<F: FnOnce(&mut ConnbytesAcc)>(modules: &mut Vec<MatchModule>, f: F) {
    if let Some(m) = modules.iter_mut().rev()
        .find(|m| matches!(m, MatchModule::Connbytes { .. }))
    {
        if let MatchModule::Connbytes { lo, hi, dir, mode, neg } = m {
            let mut acc = ConnbytesAcc {
                lo: *lo, hi: *hi, dir: *dir, mode: *mode, neg: *neg,
            };
            f(&mut acc);
            *lo = acc.lo;
            *hi = acc.hi;
            *dir = acc.dir;
            *mode = acc.mode;
            *neg = acc.neg;
            return;
        }
    }
    let mut acc = ConnbytesAcc::default();
    f(&mut acc);
    modules.push(MatchModule::Connbytes {
        lo: acc.lo, hi: acc.hi, dir: acc.dir, mode: acc.mode, neg: acc.neg,
    });
}

#[derive(Default)]
struct HashlimitAcc {
    upto: Option<(u64, String)>,
    above: Option<(u64, String)>,
    burst: Option<u32>,
    name: Option<String>,
    mode: Option<String>,
    srcmask: Option<u8>,
    dstmask: Option<u8>,
    htable_size: Option<u32>,
    htable_max: Option<u32>,
    htable_expire: Option<u32>,
    htable_gcinterval: Option<u32>,
    rate_match: bool,
    rate_interval: Option<u32>,
}

fn merge_hashlimit<F: FnOnce(&mut HashlimitAcc)>(modules: &mut Vec<MatchModule>, f: F) {
    if let Some(m) = modules.iter_mut().rev()
        .find(|m| matches!(m, MatchModule::Hashlimit { .. }))
    {
        if let MatchModule::Hashlimit {
            upto, above, burst, name, mode, srcmask, dstmask,
            htable_size, htable_max, htable_expire, htable_gcinterval,
            rate_match, rate_interval,
        } = m {
            let mut acc = HashlimitAcc {
                upto: upto.clone(), above: above.clone(), burst: *burst,
                name: name.clone(), mode: mode.clone(),
                srcmask: *srcmask, dstmask: *dstmask,
                htable_size: *htable_size, htable_max: *htable_max,
                htable_expire: *htable_expire, htable_gcinterval: *htable_gcinterval,
                rate_match: *rate_match, rate_interval: *rate_interval,
            };
            f(&mut acc);
            *upto = acc.upto; *above = acc.above; *burst = acc.burst;
            *name = acc.name; *mode = acc.mode;
            *srcmask = acc.srcmask; *dstmask = acc.dstmask;
            *htable_size = acc.htable_size; *htable_max = acc.htable_max;
            *htable_expire = acc.htable_expire; *htable_gcinterval = acc.htable_gcinterval;
            *rate_match = acc.rate_match; *rate_interval = acc.rate_interval;
            return;
        }
    }
    let mut acc = HashlimitAcc::default();
    f(&mut acc);
    modules.push(MatchModule::Hashlimit {
        upto: acc.upto, above: acc.above, burst: acc.burst,
        name: acc.name, mode: acc.mode,
        srcmask: acc.srcmask, dstmask: acc.dstmask,
        htable_size: acc.htable_size, htable_max: acc.htable_max,
        htable_expire: acc.htable_expire, htable_gcinterval: acc.htable_gcinterval,
        rate_match: acc.rate_match, rate_interval: acc.rate_interval,
    });
}

#[derive(Default)]
struct PolicyAcc {
    dir: Option<String>,
    pol: Option<String>,
    strict: bool,
    reqid: Option<u32>,
    spi: Option<u32>,
    proto: Option<String>,
    mode: Option<String>,
    tunnel_src: Option<String>,
    tunnel_dst: Option<String>,
    next: bool,
}

fn merge_policy<F: FnOnce(&mut PolicyAcc)>(modules: &mut Vec<MatchModule>, f: F) {
    if let Some(m) = modules.iter_mut().rev()
        .find(|m| matches!(m, MatchModule::Policy { .. }))
    {
        if let MatchModule::Policy {
            dir, pol, strict, reqid, spi, proto, mode,
            tunnel_src, tunnel_dst, next,
        } = m {
            let mut acc = PolicyAcc {
                dir: dir.clone(), pol: pol.clone(), strict: *strict,
                reqid: *reqid, spi: *spi, proto: proto.clone(), mode: mode.clone(),
                tunnel_src: tunnel_src.clone(), tunnel_dst: tunnel_dst.clone(),
                next: *next,
            };
            f(&mut acc);
            *dir = acc.dir; *pol = acc.pol; *strict = acc.strict;
            *reqid = acc.reqid; *spi = acc.spi; *proto = acc.proto;
            *mode = acc.mode; *tunnel_src = acc.tunnel_src;
            *tunnel_dst = acc.tunnel_dst; *next = acc.next;
            return;
        }
    }
    let mut acc = PolicyAcc::default();
    f(&mut acc);
    modules.push(MatchModule::Policy {
        dir: acc.dir, pol: acc.pol, strict: acc.strict,
        reqid: acc.reqid, spi: acc.spi, proto: acc.proto, mode: acc.mode,
        tunnel_src: acc.tunnel_src, tunnel_dst: acc.tunnel_dst, next: acc.next,
    });
}

/// Parse a rate spec like `100/second`, `5/minute`, or bare `10`
/// (defaults to `/second`). Returns `(rate, unit)`.
fn parse_rate_spec(v: &str) -> (u64, String) {
    match v.find('/') {
        Some(i) => {
            let rate = v[..i].parse::<u64>().unwrap_or(0);
            let unit = normalize_unit_str(&v[i+1..]).to_string();
            (rate, unit)
        }
        None => (v.parse::<u64>().unwrap_or(0), "second".to_string()),
    }
}

/// Normalise a unit string to one of `second / minute / hour / day`
/// (matching iptables -m limit canonical forms).
fn normalize_unit_str(s: &str) -> &'static str {
    match s.to_lowercase().as_str() {
        "sec" | "second" | "s"   => "second",
        "min" | "minute" | "m"   => "minute",
        "hour" | "h"             => "hour",
        "day" | "d"              => "day",
        _                        => "second",
    }
}

#[derive(Default)]
struct RpfilterAcc { loose: bool, validmark: bool, accept_local: bool, invert: bool }
fn merge_rpfilter<F: FnOnce(&mut RpfilterAcc)>(modules: &mut Vec<MatchModule>, f: F) {
    if let Some(m) = modules.iter_mut().rev()
        .find(|m| matches!(m, MatchModule::Rpfilter { .. }))
    {
        if let MatchModule::Rpfilter { loose, validmark, accept_local, invert } = m {
            let mut acc = RpfilterAcc {
                loose: *loose, validmark: *validmark,
                accept_local: *accept_local, invert: *invert,
            };
            f(&mut acc);
            *loose = acc.loose;
            *validmark = acc.validmark;
            *accept_local = acc.accept_local;
            *invert = acc.invert;
            return;
        }
    }
    let mut acc = RpfilterAcc::default();
    f(&mut acc);
    modules.push(MatchModule::Rpfilter {
        loose: acc.loose, validmark: acc.validmark,
        accept_local: acc.accept_local, invert: acc.invert,
    });
}


#[derive(Default)]
struct AhAcc { spi: u32, len: Option<u32>, res: bool, neg: bool }
fn merge_ah<F: FnOnce(&mut AhAcc)>(modules: &mut Vec<MatchModule>, f: F) {
    if let Some(m) = modules.iter_mut().rev()
        .find(|m| matches!(m, MatchModule::Ah { .. }))
    {
        if let MatchModule::Ah { spi, len, res, neg } = m {
            let mut acc = AhAcc { spi: *spi, len: *len, res: *res, neg: *neg };
            f(&mut acc);
            *spi = acc.spi; *len = acc.len; *res = acc.res; *neg = acc.neg;
            return;
        }
    }
    let mut acc = AhAcc::default();
    f(&mut acc);
    modules.push(MatchModule::Ah { spi: acc.spi, len: acc.len, res: acc.res, neg: acc.neg });
}

#[derive(Default)]
struct FragAcc { id: Option<u32>, len: Option<u32>, first: bool, more: bool, last: bool, res: bool, neg: bool }
fn merge_frag<F: FnOnce(&mut FragAcc)>(modules: &mut Vec<MatchModule>, f: F) {
    if let Some(m) = modules.iter_mut().rev()
        .find(|m| matches!(m, MatchModule::Frag { .. }))
    {
        if let MatchModule::Frag { id, len, first, more, last, res, neg } = m {
            let mut acc = FragAcc {
                id: *id, len: *len, first: *first, more: *more, last: *last, res: *res, neg: *neg,
            };
            f(&mut acc);
            *id = acc.id; *len = acc.len; *first = acc.first;
            *more = acc.more; *last = acc.last; *res = acc.res; *neg = acc.neg;
            return;
        }
    }
    let mut acc = FragAcc::default();
    f(&mut acc);
    modules.push(MatchModule::Frag {
        id: acc.id, len: acc.len, first: acc.first,
        more: acc.more, last: acc.last, res: acc.res, neg: acc.neg,
    });
}

#[derive(Default)]
struct HbhAcc { len: Option<u32>, opts: Vec<String> }
fn merge_hbh<F: FnOnce(&mut HbhAcc)>(modules: &mut Vec<MatchModule>, f: F) {
    if let Some(m) = modules.iter_mut().rev()
        .find(|m| matches!(m, MatchModule::Hbh { .. }))
    {
        if let MatchModule::Hbh { len, opts } = m {
            let mut acc = HbhAcc { len: *len, opts: opts.clone() };
            f(&mut acc);
            *len = acc.len; *opts = acc.opts;
            return;
        }
    }
    let mut acc = HbhAcc::default();
    f(&mut acc);
    modules.push(MatchModule::Hbh { len: acc.len, opts: acc.opts });
}

#[derive(Default)]
struct RtAcc {
    rt_type: Option<u32>, segs_left: Option<u32>, len: Option<u32>,
    rt0_res: bool, rt0_addrs: Vec<String>, rt0_strict: bool,
}
fn merge_rt<F: FnOnce(&mut RtAcc)>(modules: &mut Vec<MatchModule>, f: F) {
    if let Some(m) = modules.iter_mut().rev()
        .find(|m| matches!(m, MatchModule::Rt { .. }))
    {
        if let MatchModule::Rt { rt_type, segs_left, len, rt0_res, rt0_addrs, rt0_strict } = m {
            let mut acc = RtAcc {
                rt_type: *rt_type, segs_left: *segs_left, len: *len,
                rt0_res: *rt0_res, rt0_addrs: rt0_addrs.clone(), rt0_strict: *rt0_strict,
            };
            f(&mut acc);
            *rt_type = acc.rt_type; *segs_left = acc.segs_left; *len = acc.len;
            *rt0_res = acc.rt0_res; *rt0_addrs = acc.rt0_addrs; *rt0_strict = acc.rt0_strict;
            return;
        }
    }
    let mut acc = RtAcc { rt0_strict: true, ..RtAcc::default() };
    f(&mut acc);
    modules.push(MatchModule::Rt {
        rt_type: acc.rt_type, segs_left: acc.segs_left, len: acc.len,
        rt0_res: acc.rt0_res, rt0_addrs: acc.rt0_addrs, rt0_strict: acc.rt0_strict,
    });
}

#[derive(Default)]
struct DstAcc { len: Option<u32>, opts: Vec<String> }
fn merge_dst<F: FnOnce(&mut DstAcc)>(modules: &mut Vec<MatchModule>, f: F) {
    if let Some(m) = modules.iter_mut().rev()
        .find(|m| matches!(m, MatchModule::Dst { .. }))
    {
        if let MatchModule::Dst { len, opts } = m {
            let mut acc = DstAcc { len: *len, opts: opts.clone() };
            f(&mut acc);
            *len = acc.len; *opts = acc.opts;
            return;
        }
    }
    let mut acc = DstAcc::default();
    f(&mut acc);
    modules.push(MatchModule::Dst { len: acc.len, opts: acc.opts });
}

#[derive(Default)]
struct Ipv6HeaderAcc { headers: Vec<String>, soft: bool }
fn merge_ipv6header<F: FnOnce(&mut Ipv6HeaderAcc)>(modules: &mut Vec<MatchModule>, f: F) {
    if let Some(m) = modules.iter_mut().rev()
        .find(|m| matches!(m, MatchModule::Ipv6Header { .. }))
    {
        if let MatchModule::Ipv6Header { headers, soft } = m {
            let mut acc = Ipv6HeaderAcc { headers: headers.clone(), soft: *soft };
            f(&mut acc);
            *headers = acc.headers; *soft = acc.soft;
            return;
        }
    }
    let mut acc = Ipv6HeaderAcc::default();
    f(&mut acc);
    modules.push(MatchModule::Ipv6Header { headers: acc.headers, soft: acc.soft });
}

#[cfg(test)]
mod tests {
    use super::*;

    fn parse_argv(family: Family, args: &[&str]) -> IptCmd {
        let argv: Vec<String> = args.iter().map(|s| s.to_string()).collect();
        parse(family, &argv).unwrap().cmd
    }

    #[test]
    fn family_strips_save_suffix() {
        assert!(matches!(family_from_argv0("iptables-save"), Ok(Family::Ip)));
        assert!(matches!(family_from_argv0("ip6tables-restore"), Ok(Family::Ip6)));
        assert!(matches!(family_from_argv0("/usr/sbin/ip6tables"), Ok(Family::Ip6)));
    }

    #[test]
    fn append_basic() {
        let c = parse_argv(Family::Ip, &["-A", "INPUT", "-j", "ACCEPT"]);
        assert!(matches!(c.op, IptOp::Append));
        assert_eq!(c.chain, "INPUT");
        assert_eq!(c.spec.target, Some(Target::Accept));
    }

    #[test]
    fn append_with_dport() {
        let c = parse_argv(Family::Ip, &["-A", "INPUT", "-p", "tcp", "--dport", "22", "-j", "ACCEPT"]);
        assert_eq!(c.spec.protocol.as_deref(), Some("tcp"));
        assert_eq!(c.spec.dport, Some(PortRange::single(22)));
    }

    #[test]
    fn negation_modern() {
        let c = parse_argv(Family::Ip, &["-A", "FORWARD", "!", "-i", "eth0", "-j", "ACCEPT"]);
        assert_eq!(c.spec.iif.as_deref(), Some("eth0"));
        assert!(c.spec.iif_neg);
    }

    #[test]
    fn negation_legacy() {
        let c = parse_argv(Family::Ip, &["-A", "FORWARD", "-s", "!", "10.0.0.0/8", "-j", "DROP"]);
        assert!(c.spec.src.unwrap().neg);
    }

    #[test]
    fn nat_masquerade() {
        let c = parse_argv(Family::Ip, &[
            "-t", "nat", "-A", "POSTROUTING", "-s", "172.17.0.0/16", "!", "-o", "docker0", "-j", "MASQUERADE"
        ]);
        assert_eq!(c.table, IptTable::Nat);
        assert!(c.spec.oif_neg);
        assert_eq!(c.spec.oif.as_deref(), Some("docker0"));
        assert!(matches!(c.spec.target, Some(Target::Masquerade { .. })));
    }

    #[test]
    fn dnat_to_destination() {
        let c = parse_argv(Family::Ip, &[
            "-t", "nat", "-A", "PREROUTING", "-p", "tcp", "--dport", "8080",
            "-j", "DNAT", "--to-destination", "172.17.0.2:80"
        ]);
        match c.spec.target.unwrap() {
            Target::Dnat { to_destination, .. } => assert_eq!(to_destination, "172.17.0.2:80"),
            _ => panic!("expected DNAT"),
        }
    }

    #[test]
    fn conntrack_state() {
        let c = parse_argv(Family::Ip, &[
            "-A", "FORWARD", "-m", "conntrack", "--ctstate", "RELATED,ESTABLISHED", "-j", "ACCEPT"
        ]);
        let st = c.spec.state.unwrap();
        assert_eq!(st.names, vec!["RELATED", "ESTABLISHED"]);
    }

    #[test]
    fn comment_consumed() {
        let c = parse_argv(Family::Ip, &[
            "-A", "INPUT", "-m", "comment", "--comment", "hello world", "-j", "ACCEPT"
        ]);
        assert_eq!(c.spec.comment.as_deref(), Some("hello world"));
    }

    #[test]
    fn new_chain_op() {
        let c = parse_argv(Family::Ip, &["-N", "DOCKER"]);
        assert!(matches!(c.op, IptOp::NewChain));
        assert_eq!(c.chain, "DOCKER");
    }

    #[test]
    fn policy_set() {
        let c = parse_argv(Family::Ip, &["-P", "FORWARD", "DROP"]);
        assert!(matches!(c.op, IptOp::Policy));
        assert_eq!(c.policy_target.as_deref(), Some("DROP"));
    }

    #[test]
    fn delete_by_num() {
        let c = parse_argv(Family::Ip, &["-D", "INPUT", "3"]);
        assert!(matches!(c.op, IptOp::DeleteNum(3)));
    }

    #[test]
    fn delete_by_match() {
        let c = parse_argv(Family::Ip, &["-D", "INPUT", "-p", "tcp", "--dport", "22", "-j", "ACCEPT"]);
        assert!(matches!(c.op, IptOp::DeleteMatch));
    }

    #[test]
    fn multiport_dports() {
        let c = parse_argv(Family::Ip, &[
            "-A", "INPUT", "-p", "tcp", "-m", "multiport", "--dports", "22,80,443", "-j", "ACCEPT"
        ]);
        let mp = c.spec.multiport_dports.unwrap();
        assert_eq!(mp.items.len(), 3);
        assert_eq!(mp.items[0], PortRange::single(22));
    }

    #[test]
    fn addrtype_dst_local() {
        let c = parse_argv(Family::Ip, &[
            "-t", "nat", "-A", "PREROUTING", "-m", "addrtype", "--dst-type", "LOCAL", "-j", "ACCEPT"
        ]);
        let mut found = false;
        for m in &c.spec.modules {
            if let MatchModule::Addrtype { dst: Some(d), .. } = m {
                if d == "LOCAL" { found = true; }
            }
        }
        assert!(found);
    }

    #[test]
    fn list_with_chain() {
        let c = parse_argv(Family::Ip, &["-L", "FORWARD", "-n", "-v", "--line-numbers"]);
        assert!(matches!(c.op, IptOp::List));
        assert_eq!(c.chain, "FORWARD");
        assert!(c.list_numeric);
        assert!(c.list_verbose);
        assert!(c.list_linenums);
    }

    #[test]
    fn reject_with_type() {
        let c = parse_argv(Family::Ip, &[
            "-A", "INPUT", "-j", "REJECT", "--reject-with", "icmp-port-unreachable"
        ]);
        assert_eq!(c.spec.target, Some(Target::Reject(Some("icmp-port-unreachable".into()))));
    }

    #[test]
    fn limit_burst() {
        let c = parse_argv(Family::Ip, &[
            "-A", "INPUT", "-m", "limit", "--limit", "10/second", "--limit-burst", "5", "-j", "ACCEPT"
        ]);
        let l = c.spec.limit.unwrap();
        assert_eq!(l.rate, 10);
        assert_eq!(l.unit, "second");
        assert_eq!(l.burst, 5);
    }
}
