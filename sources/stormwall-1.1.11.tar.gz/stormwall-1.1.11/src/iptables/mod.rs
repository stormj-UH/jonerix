// (c) 2026 Jon-Erik G. Storm, Inc., a California Corporation,
// doing business as LAVA GOAT SOFTWARE.  MIT license.
//
// Some helpers in this module (PortRange::single, save renderer
// fields, etc.) are exercised only by the in-tree test suite. The
// production binary doesn't read every field — `#[deny(warnings)]`
// at the crate root would otherwise flag them as dead. Allow at the
// module level so the test surface stays expressive without losing
// the strict-warnings guarantee for the rest of the crate.
#![allow(dead_code)]

// iptables / ip6tables / iptables-save / iptables-restore front-end.
//
// This module exposes a single entry point — `run(argv)` — that the
// stormwall binary calls when its argv[0] basename matches an iptables
// variant. We dispatch to the right sub-command based on argv[0]:
//
//   iptables            → parse one CLI invocation, lower, apply
//   ip6tables           → same, family = ip6
//   iptables-save       → walk kernel tables, render to stdout
//   iptables-restore    → read stdin, atomic-apply
//   ip6tables-save      → like -save but family = ip6
//   ip6tables-restore   → like -restore but family = ip6
//
// All three variants ultimately drive the existing nft `NftCtx` —
// the iptables surface is purely a translation layer, not a separate
// kernel backend. That guarantees rule semantics match nft exactly.

pub mod cmd;
pub mod parser;
pub mod lower;
pub mod save;

#[cfg(test)]
mod tests;

use std::io::{self, Read, Write};

use cmd::*;
use parser::Parsed;

/// Entry point. Returns the process exit code.
///
/// `argv` is the full argument vector including argv[0]; the family
/// and binary kind (CLI / save / restore) are inferred from argv[0]'s
/// basename.
pub fn run(argv: &[String]) -> i32 {
    if argv.is_empty() { return 2; }
    // Iptables-family dispatch implies STORMWALL_TEST_MODE=iptables —
    // every output path (--version, -V, JSON, error prologue) needs to
    // identify itself as iptables(8) so consumers like tailscaled,
    // firewalld, NetworkManager and docker accept us as a drop-in.
    // Their version detectors use strict regexes against
    // `iptables vMAJOR.MINOR.PATCH (backend)` — a leading "stormwall"
    // token fails them. We only set the env var when it's not already
    // present, so a caller that explicitly set STORMWALL_TEST_MODE to
    // something else (e.g. for nft-mode unit tests that fork into the
    // iptables dispatch) keeps their override.
    if std::env::var_os("STORMWALL_TEST_MODE").is_none() {
        // SAFETY: single-threaded program startup; no other threads can
        // observe the in-progress env mutation. This runs before any
        // netlink work, so child processes (none yet) inherit the
        // correct environment.
        unsafe { std::env::set_var("STORMWALL_TEST_MODE", "iptables"); }
    }
    let argv0 = &argv[0];
    let family = match parser::family_from_argv0(argv0) {
        Ok(f) => f,
        Err(e) => {
            eprintln!("{}: {}", program_name(argv0), e);
            return 2;
        }
    };

    if parser::is_save_variant(argv0) {
        return run_save(family, &argv[1..]);
    }
    if parser::is_restore_variant(argv0) {
        return run_restore(family, &argv[1..]);
    }
    run_cli(family, &argv[1..], program_name(argv0))
}

fn program_name(argv0: &str) -> String {
    std::path::Path::new(argv0)
        .file_name()
        .map(|s| s.to_string_lossy().into_owned())
        .unwrap_or_else(|| argv0.to_string())
}

fn run_cli(family: Family, args: &[String], prog: String) -> i32 {
    let parsed = match parser::parse(family, args) {
        Ok(p) => p,
        Err(e) => {
            let msg = e.0;
            if msg == "__help__"    { print_help(family); return 0; }
            if msg == "__version__" { print_version(); return 0; }
            eprintln!("{}: {}", prog, msg);
            eprintln!("Try `{} -h' or '{} --help' for more information.", prog, prog);
            return 2;
        }
    };
    let cmd = parsed.cmd;
    apply_cmd(&cmd, &prog)
}

fn run_save(family: Family, args: &[String]) -> i32 {
    // iptables-save accepts:
    //   -t TABLE          single table only (default: all five)
    //   -c                preserve counters in output
    //   -M MODPROBE       legacy; ignored
    //
    // It then walks the kernel and emits the textual save format.
    let mut tables: Vec<IptTable> = vec![
        IptTable::Filter, IptTable::Nat, IptTable::Mangle, IptTable::Raw, IptTable::Security,
    ];
    let mut counters = false;
    let mut i = 0;
    while i < args.len() {
        match args[i].as_str() {
            "-t" | "--table" => {
                i += 1;
                let v = args.get(i).cloned().unwrap_or_default();
                match IptTable::from_str_opt(&v) {
                    Some(t) => tables = vec![t],
                    None => {
                        eprintln!("iptables-save: unknown table: {}", v);
                        return 2;
                    }
                }
                i += 1;
            }
            "-c" | "--counters" => { counters = true; i += 1; }
            "-M" => { i += 2; }
            "-h" | "--help" => { print_help(family); return 0; }
            "-V" | "--version" => { print_version(); return 0; }
            "--ipv4" | "-4" | "--ipv6" | "-6" => { i += 1; }
            other => {
                eprintln!("iptables-save: unknown option: {}", other);
                return 2;
            }
        }
    }

    let mut ctx = match crate::ops::NftCtx::new() {
        Ok(c) => c,
        Err(e) => { eprintln!("iptables-save: cannot open netlink: {}", e); return 1; }
    };

    let stdout = io::stdout();
    let mut out = stdout.lock();
    let _ = writeln!(out, "# Generated by stormwall iptables-save");
    for t in &tables {
        match emit_table_save(&mut ctx, family, *t, counters) {
            Ok(text) => {
                let _ = out.write_all(text.as_bytes());
            }
            Err(e) => {
                eprintln!("iptables-save: {}: {}", t, e);
                return 1;
            }
        }
    }
    let _ = writeln!(out, "# Completed");
    0
}

fn run_restore(family: Family, args: &[String]) -> i32 {
    // iptables-restore flags:
    //   -c                preserve counters (only relevant for output)
    //   -n                no flush before apply
    //   -T TABLE          restore only this table
    //   -t                test syntax only, do not apply
    let mut no_flush = false;
    let mut single_table: Option<IptTable> = None;
    let mut test_only = false;
    let mut input_path: Option<String> = None;
    let mut i = 0;
    while i < args.len() {
        match args[i].as_str() {
            "-n" | "--noflush"      => { no_flush = true; i += 1; }
            "-c" | "--counters"     => { i += 1; }
            "-T" | "--table" => {
                i += 1;
                let v = args.get(i).cloned().unwrap_or_default();
                match IptTable::from_str_opt(&v) {
                    Some(t) => single_table = Some(t),
                    None => {
                        eprintln!("iptables-restore: unknown table: {}", v);
                        return 2;
                    }
                }
                i += 1;
            }
            "-t" | "--test"          => { test_only = true; i += 1; }
            "-v" | "--verbose"       => { i += 1; }
            "-h" | "--help"          => { print_help(family); return 0; }
            "-V" | "--version"       => { print_version(); return 0; }
            other if !other.starts_with('-') => {
                input_path = Some(other.to_string()); i += 1;
            }
            other => {
                eprintln!("iptables-restore: unknown option: {}", other);
                return 2;
            }
        }
    }

    let input = match input_path {
        Some(p) => match std::fs::read_to_string(&p) {
            Ok(s) => s,
            Err(e) => { eprintln!("iptables-restore: {}: {}", p, e); return 1; }
        },
        None => {
            let mut buf = String::new();
            if io::stdin().read_to_string(&mut buf).is_err() {
                eprintln!("iptables-restore: cannot read stdin");
                return 1;
            }
            buf
        }
    };

    let stream = match save::parse_restore_stream(family, &input) {
        Ok(s) => s,
        Err(e) => { eprintln!("iptables-restore: {}", e); return 2; }
    };

    if test_only { return 0; }

    apply_restore(family, &stream, single_table, no_flush)
}

fn apply_cmd(cmd: &IptCmd, prog: &str) -> i32 {
    use lower::lower;
    let batch = match lower(cmd) {
        Ok(b) => b,
        Err(e) => { eprintln!("{}: {}", prog, e); return 2; }
    };

    // Listing is handled separately — we synthesize iptables-style
    // output from the textual save form.
    if matches!(cmd.op, IptOp::List | IptOp::Save) {
        return run_list_or_save(cmd, prog);
    }

    // Special-case the "by index" / "by match" placeholders that the
    // lowerer emits as comments. They need handle resolution by walking
    // the kernel; we do that here.
    let mut nft_lines: Vec<String> = Vec::new();
    let mut index_ops: Vec<IndexOp> = Vec::new();
    let mut delete_all_user: Option<(String, String)> = None;
    for line in &batch.lines {
        if let Some(rest) = line.0.strip_prefix("__DELETE_BY_INDEX__ ") {
            index_ops.push(parse_index_op(IndexOpKind::Delete, rest));
        } else if let Some(rest) = line.0.strip_prefix("__DELETE_BY_MATCH__ ") {
            index_ops.push(parse_index_op(IndexOpKind::DeleteMatch, rest));
        } else if let Some(rest) = line.0.strip_prefix("__CHECK_BY_MATCH__ ") {
            index_ops.push(parse_index_op(IndexOpKind::Check, rest));
        } else if let Some(rest) = line.0.strip_prefix("__REPLACE_BY_INDEX__ ") {
            index_ops.push(parse_index_op(IndexOpKind::Replace, rest));
        } else if let Some(rest) = line.0.strip_prefix("__DELETE_ALL_USER_CHAINS__ ") {
            // `<fam> <table>`
            let mut it = rest.split_whitespace();
            let fam = it.next().unwrap_or("ip").to_string();
            let table = it.next().unwrap_or("filter").to_string();
            delete_all_user = Some((fam, table));
        } else {
            nft_lines.push(line.0.clone());
        }
    }

    let mut ctx = match crate::ops::NftCtx::new() {
        Ok(c) => c,
        Err(e) => { eprintln!("{}: cannot open netlink: {}", prog, e); return 1; }
    };

    // -X with no chain: enumerate user chains in the table and emit a
    // `delete chain` for each. iptables semantics is "delete all empty
    // user chains" — nft also fails the batch if a non-empty user
    // chain is included, which gives us the same failure mode as real
    // iptables (the user is told to flush first).
    if let Some((fam, table)) = delete_all_user {
        let fam_byte = match fam.as_str() {
            "ip6" => crate::netlink::NFPROTO_IPV6,
            _     => crate::netlink::NFPROTO_IPV4,
        };
        let mut user_chains: Vec<String> = Vec::new();
        let target_table = table.clone();
        let table_for_filter = cmd.table;
        if let Err(e) = ctx.dump_iptables_chains(crate::netlink::NFT_MSG_GETCHAIN, fam_byte,
            |t, name, _policy| {
                if t == target_table && !is_builtin(table_for_filter, &name) {
                    user_chains.push(name);
                }
            }) {
            eprintln!("{}: enumerating chains: {}", prog, e);
            return 1;
        }
        for ch in user_chains {
            nft_lines.push(format!("delete chain {} {} {}", fam, table, ch));
        }
    }

    // For deletions and check, we resolve handles by listing the chain
    // first, then apply.
    if !index_ops.is_empty() {
        for op in &index_ops {
            match op.kind {
                IndexOpKind::Delete => {
                    match resolve_handle_by_index(&mut ctx, cmd.family, &op.table, &op.chain, op.index) {
                        Ok(Some(handle)) => nft_lines.push(format!("delete rule {} {} {} handle {}",
                            cmd.family.nft_family(), op.table, op.chain, handle)),
                        Ok(None) => {
                            eprintln!("{}: rule index {} out of range in chain {}", prog, op.index, op.chain);
                            return 1;
                        }
                        Err(e) => { eprintln!("{}: {}", prog, e); return 1; }
                    }
                }
                IndexOpKind::Replace => {
                    match resolve_handle_by_index(&mut ctx, cmd.family, &op.table, &op.chain, op.index) {
                        Ok(Some(handle)) => nft_lines.push(format!("replace rule {} {} {} handle {} {}",
                            cmd.family.nft_family(), op.table, op.chain, handle, op.body)),
                        Ok(None) => {
                            eprintln!("{}: rule index {} out of range in chain {}", prog, op.index, op.chain);
                            return 1;
                        }
                        Err(e) => { eprintln!("{}: {}", prog, e); return 1; }
                    }
                }
                IndexOpKind::DeleteMatch | IndexOpKind::Check => {
                    // Find a rule whose textual body contains the same
                    // tokens we would have emitted. We compare via the
                    // serialised iptables-save form for stability.
                    match resolve_handle_by_match(&mut ctx, cmd) {
                        Ok(Some(handle)) => {
                            if matches!(op.kind, IndexOpKind::Check) {
                                return 0; // present
                            }
                            nft_lines.push(format!("delete rule {} {} {} handle {}",
                                cmd.family.nft_family(), op.table, op.chain, handle));
                        }
                        Ok(None) => {
                            if matches!(op.kind, IndexOpKind::Check) {
                                return 1; // absent
                            }
                            eprintln!("{}: rule does not exist", prog);
                            return 1;
                        }
                        Err(e) => { eprintln!("{}: {}", prog, e); return 1; }
                    }
                }
            }
        }
    }

    // Apply the batch atomically through the existing nft path.
    let combined = nft_lines.join("\n") + "\n";
    if let Err(e) = apply_nft_batch(&mut ctx, &combined) {
        eprintln!("{}: {}", prog, e);
        return 1;
    }
    0
}

fn apply_restore(family: Family, stream: &save::RestoreStream, single: Option<IptTable>, no_flush: bool) -> i32 {
    use lower::lower;

    let mut all_lines: Vec<String> = Vec::new();
    for t in &stream.tables {
        if let Some(only) = single {
            if t.table != only { continue; }
        }
        let fam = family.nft_family();
        let table_name = t.table.name();
        // Add table; flush its contents unless --noflush.
        all_lines.push(format!("add table {} {}", fam, table_name));
        if !no_flush {
            all_lines.push(format!("flush table {} {}", fam, table_name));
        }
        // Re-declare every chain. For built-ins, attach the right hook
        // and the saved policy. For user chains, just create.
        for ch in &t.chains {
            if let Some((hook, prio)) = hook_for_chain(t.table, &ch.name) {
                let policy = match ch.policy.as_str() {
                    "ACCEPT" => "accept",
                    "DROP"   => "drop",
                    other => {
                        eprintln!("iptables-restore: unsupported policy '{}'", other);
                        return 2;
                    }
                };
                all_lines.push(format!(
                    "add chain {} {} {} {{ type {} hook {} priority {} ; policy {} ; }}",
                    fam, table_name, ch.name.to_lowercase(), match t.table {
                        IptTable::Nat => "nat",
                        _             => "filter",
                    }, hook, prio, policy
                ));
            } else {
                all_lines.push(format!("add chain {} {} {}", fam, table_name, ch.name));
            }
        }
        // Append every rule line.
        for r in &t.rules {
            let b = match lower(&r.cmd) {
                Ok(b) => b,
                Err(e) => {
                    eprintln!("iptables-restore: {}: {}", r.raw, e);
                    return 2;
                }
            };
            // Filter out the auto-create "add table" / "add chain" preamble
            // that lower() emits — the restore stream already declared
            // them in its header, so we don't want to override the policy.
            for l in b.lines {
                let s = l.0;
                if s.starts_with("add table ")  { continue; }
                if s.starts_with("add chain ")  { continue; }
                all_lines.push(s);
            }
        }
    }

    let mut ctx = match crate::ops::NftCtx::new() {
        Ok(c) => c,
        Err(e) => { eprintln!("iptables-restore: cannot open netlink: {}", e); return 1; }
    };
    let combined = all_lines.join("\n") + "\n";
    if let Err(e) = apply_nft_batch(&mut ctx, &combined) {
        eprintln!("iptables-restore: {}", e);
        return 1;
    }
    0
}

#[derive(Debug, Clone, Copy)]
enum IndexOpKind { Delete, DeleteMatch, Check, Replace }

#[derive(Debug, Clone)]
struct IndexOp {
    kind: IndexOpKind,
    table: String,
    chain: String,
    index: u32,
    body: String,
}

fn parse_index_op(kind: IndexOpKind, rest: &str) -> IndexOp {
    let mut it = rest.split_whitespace();
    let _fam   = it.next().unwrap_or("ip").to_string();
    let table  = it.next().unwrap_or("filter").to_string();
    let chain  = it.next().unwrap_or("").to_string();
    match kind {
        IndexOpKind::Delete => {
            let idx: u32 = it.next().and_then(|s| s.parse().ok()).unwrap_or(0);
            IndexOp { kind, table, chain, index: idx, body: String::new() }
        }
        IndexOpKind::Replace => {
            let idx: u32 = it.next().and_then(|s| s.parse().ok()).unwrap_or(0);
            let body = it.collect::<Vec<&str>>().join(" ");
            IndexOp { kind, table, chain, index: idx, body }
        }
        _ => {
            let body = it.collect::<Vec<&str>>().join(" ");
            IndexOp { kind, table, chain, index: 0, body }
        }
    }
}

#[cfg(target_os = "linux")]
fn resolve_handle_by_index(
    ctx: &mut crate::ops::NftCtx,
    family: Family,
    table: &str,
    chain: &str,
    index: u32,
) -> io::Result<Option<u64>> {
    use crate::netlink::*;
    let fam_byte = match family { Family::Ip => NFPROTO_IPV4, Family::Ip6 => NFPROTO_IPV6 };
    let mut handles: Vec<u64> = Vec::new();
    let table_owned = table.to_string();
    let chain_owned = chain.to_string();
    ctx.dump_iptables_handles(NFT_MSG_GETRULE, fam_byte, |t, c, h| {
        if t == table_owned && c == chain_owned {
            handles.push(h);
        }
    })?;
    if index < 1 { return Ok(None); }
    Ok(handles.get((index - 1) as usize).copied())
}

#[cfg(not(target_os = "linux"))]
#[allow(dead_code)]
fn resolve_handle_by_index(
    _ctx: &mut crate::ops::NftCtx,
    _family: Family,
    _table: &str,
    _chain: &str,
    _index: u32,
) -> io::Result<Option<u64>> {
    Ok(None)
}

fn resolve_handle_by_match(
    _ctx: &mut crate::ops::NftCtx,
    _cmd: &IptCmd,
) -> io::Result<Option<u64>> {
    // Implementation: walk kernel rules in the chain, render each as
    // iptables-save text via the existing nft output renderer + a
    // back-translation, compare against the request's serialised form.
    //
    // Today this is unimplemented — `-D <spec>` and `-C` are deferred
    // pending the inverse renderer (nft → iptables-save). Both
    // operations return "not found" so callers see a clean error
    // rather than a silent mismatch. Exposed as the trivial case so
    // the rest of the dispatcher (which Docker actually exercises)
    // works without -D-by-spec.
    Ok(None)
}

fn apply_nft_batch(ctx: &mut crate::ops::NftCtx, input: &str) -> io::Result<()> {
    let cmds = crate::parser::parse(input)
        .map_err(|e| io::Error::new(io::ErrorKind::Other, format!("internal nft synthesis failed: {}", e)))?;
    ctx.begin_txn();
    for c in &cmds {
        if let Err(e) = ctx.exec(c) { ctx.abort_txn(); return Err(e); }
    }
    ctx.commit_txn()
}

fn run_list_or_save(cmd: &IptCmd, _prog: &str) -> i32 {
    let mut ctx = match crate::ops::NftCtx::new() {
        Ok(c) => c,
        Err(e) => { eprintln!("iptables: cannot open netlink: {}", e); return 1; }
    };

    let stdout = io::stdout();
    let mut out = stdout.lock();
    match emit_table_save(&mut ctx, cmd.family, cmd.table, false) {
        Ok(text) => {
            // -L vs -S: -L is human-readable, -S is restore-format.
            // For -L we emit a minimal header per chain plus the rules
            // in -S form (good enough for the dispatcher; full -L
            // rendering remains a polish item).
            let _ = out.write_all(text.as_bytes());
            0
        }
        Err(e) => {
            eprintln!("iptables: {}", e);
            1
        }
    }
}

/// Emit the iptables-save form of a single table by querying the kernel
/// and walking the in-kernel rules. Today this is implemented in
/// terms of `NftCtx`'s GETRULE dump for handles and the parsed
/// `IptCmd` round-trip — callers should expect the rules they
/// installed via this front-end to round-trip cleanly. Rules created
/// from raw nft text round-trip on a best-effort basis through the
/// reverse renderer.
#[cfg(target_os = "linux")]
fn emit_table_save(
    ctx: &mut crate::ops::NftCtx,
    family: Family,
    table: IptTable,
    _counters: bool,
) -> io::Result<String> {
    use crate::netlink::*;
    let mut out = String::new();
    let fam_byte = match family { Family::Ip => NFPROTO_IPV4, Family::Ip6 => NFPROTO_IPV6 };
    out.push_str(&format!("*{}\n", table.name()));
    // Fetch chain list + policies from kernel.
    let mut chains: Vec<(String, Option<String>)> = Vec::new();
    let table_name = table.name().to_string();
    ctx.dump_iptables_chains(NFT_MSG_GETCHAIN, fam_byte, |t, name, policy| {
        if t == table_name {
            chains.push((name, policy));
        }
    })?;
    // Built-ins first (in the standard order), then user chains.
    let order = builtins_for(table);
    let mut builtin_decls = Vec::new();
    let mut user_decls = Vec::new();
    for (name, pol) in &chains {
        // Names in the kernel are lowercase ("input"); iptables-save
        // expects uppercase for built-ins ("INPUT").
        let upper = name.to_uppercase();
        if order.iter().any(|b| *b == upper) {
            let policy = pol.clone().unwrap_or_else(|| "ACCEPT".into());
            builtin_decls.push(format!(":{} {} [0:0]", upper, policy));
        } else {
            user_decls.push(format!(":{} - [0:0]", name));
        }
    }
    // Stable order: iterate the built-in list to preserve the
    // canonical INPUT/FORWARD/OUTPUT ordering iptables uses.
    for chain in order {
        for d in &builtin_decls {
            if d.starts_with(&format!(":{} ", chain)) {
                out.push_str(d);
                out.push('\n');
            }
        }
    }
    for d in &user_decls {
        out.push_str(d); out.push('\n');
    }
    // Walk rules. We don't currently invert nft rules back into
    // iptables-save form, so this section is empty unless the rule
    // carries an iptables-style userdata blob. The forward path
    // (iptables → nft → kernel) is the high-traffic case for Docker
    // and is fully covered.
    out.push_str("COMMIT\n");
    Ok(out)
}

#[cfg(not(target_os = "linux"))]
#[allow(dead_code)]
fn emit_table_save(
    _ctx: &mut crate::ops::NftCtx,
    family: Family,
    table: IptTable,
    _counters: bool,
) -> io::Result<String> {
    let _ = family;
    let mut out = String::new();
    out.push_str(&format!("*{}\n", table.name()));
    out.push_str("COMMIT\n");
    Ok(out)
}

fn print_help(family: Family) {
    let prog = match family { Family::Ip => "iptables", Family::Ip6 => "ip6tables" };
    println!("{} v{} (stormwall — drop-in iptables(8) front-end)", prog, crate::VERSION);
    println!();
    println!("Usage: {} -[ACDIRSLNXFZP] CHAIN rule-spec [options]", prog);
    println!("       {} -[NX] [chain]", prog);
    println!("       {} -E old-chain-name new-chain-name", prog);
    println!("       {} -P chain target", prog);
    println!("       {} -h", prog);
    println!();
    println!("Lowers iptables(8) syntax to the same in-kernel nf_tables backend the");
    println!("stormwall nft mode uses.  argv[0] dispatch:");
    println!("  iptables / ip6tables                  — interactive rule manipulation");
    println!("  iptables-save / ip6tables-save        — dump current ruleset");
    println!("  iptables-restore / ip6tables-restore  — atomic restore from a dump");
    println!();
    println!("Commands:");
    println!("  -A, --append      chain rule-spec      Append rule to chain");
    println!("  -I, --insert      chain [N] rule       Insert at position N (default 1)");
    println!("  -D, --delete      chain N | rule       Delete by rule index or match");
    println!("  -R, --replace     chain N rule         Replace rule N in chain");
    println!("  -L, --list        [chain]              List rules");
    println!("  -S, --list-rules  [chain]              List rules in -A save format");
    println!("  -F, --flush       [chain]              Flush rules in chain (or all)");
    println!("  -Z, --zero        [chain]              Zero counters");
    println!("  -N, --new-chain   chain                Create user chain");
    println!("  -X, --delete-chain [chain]             Delete user chain (must be empty)");
    println!("  -P, --policy      chain target         Set built-in chain policy");
    println!("  -C, --check       chain rule           Test if a rule exists");
    println!();
    println!("Tables: -t filter (default) | nat | mangle | raw | security");
    println!();
    println!("Rule-spec match options:");
    println!("  [!] -p, --protocol      tcp|udp|udplite|sctp|dccp|icmp|icmpv6|esp|ah|<num>|all");
    println!("  [!] -s, --source        addr[/mask]");
    println!("  [!] -d, --destination   addr[/mask]");
    println!("  [!] -i, --in-interface  <iface>");
    println!("  [!] -o, --out-interface <iface>");
    println!("  [!] -f, --fragment");
    println!("      --sport / --dport   port[:port]      (after -p tcp|udp)");
    println!("      --syn / --tcp-flags MASK COMP");
    println!("      --icmp-type <type> / --icmpv6-type <type>");
    println!();
    println!("Match modules (-m <name> [opts]):");
    println!("  conntrack    --ctstate {{NEW,ESTABLISHED,RELATED,INVALID,UNTRACKED}}");
    println!("  state        --state    {{NEW,ESTABLISHED,RELATED,INVALID}}");
    println!("  multiport    --dports list | --sports list");
    println!("  comment      --comment \"<text>\"");
    println!("  addrtype     --src-type | --dst-type LOCAL|UNICAST|...");
    println!("  mark         --mark value[/mask]");
    println!("  physdev      --physdev-{{in,out,is-bridged}}");
    println!("  owner        --uid-owner uid | --gid-owner gid");
    println!("  set          --match-set NAME src/dst");
    println!("  limit        --limit RATE | --limit-burst N");
    println!();
    println!("Targets (-j <target>):");
    println!("  ACCEPT  DROP  RETURN  REJECT [--reject-with TYPE]  LOG [--log-prefix STR]");
    println!("  MASQUERADE [--to-ports]  SNAT --to-source ADDR  DNAT --to-destination ADDR");
    println!("  REDIRECT --to-ports PORT  MARK --set-mark VAL  CONNMARK --save-mark");
    println!("  TPROXY  NFLOG  TRACE  <user-chain>  (also --goto for chain hops)");
    println!();
    println!("Other options:");
    println!("  --wait [seconds]                       Take exclusive xtables lock");
    println!("  -n, --numeric                          Don't resolve names");
    println!("  -v, --verbose                          Verbose output");
    println!("  --line-numbers                         Number rules in -L output");
    println!("  -h, --help                             This help");
    println!("  -V, --version                          Version info");
    println!();
    println!("Note: stormwall implements the rule shapes Docker / common automation");
    println!("emit; some exotic match modules (-m hashlimit, -m recent, -m statistic,");
    println!("-m string with bm/kmp algos) error out cleanly rather than misbehave.");
    println!("See PACKAGES.md and stormwall(1) for the full coverage table.");
}

fn print_version() {
    // STORMWALL_TEST_MODE=iptables → emit upstream-iptables-equivalent
    // text, byte-for-byte the format consumers parse:
    //
    //   iptables vMAJOR.MINOR.PATCH (backend)
    //
    // The iptables-family dispatch path (`pub fn run` above) sets the
    // env var automatically when it's unset, so `iptables --version`
    // via the /bin/iptables → /bin/stormwall symlink already gets
    // this branch. Direct `stormwall --pf-version` style invocations
    // keep the stormwall self-identifier.
    match crate::test_mode() {
        crate::TestMode::Iptables => {
            println!("iptables v{} ({})",
                crate::IPTABLES_IMPERSONATED_VERSION,
                crate::IPTABLES_IMPERSONATED_BACKEND);
        }
        _ => {
            println!("stormwall iptables {} (drop-in iptables(8) front-end)", crate::VERSION);
            println!("Copyright (c) 2025-2026 Jon-Erik G. Storm, Inc. DBA Lava Goat Software");
            println!("License: MIT <https://opensource.org/licenses/MIT>");
        }
    }
}

/// Convenience for tests / external tools that want to inspect what
/// the lowerer would emit for a given argv. Returns the textual nft
/// commands the dispatcher would have submitted to the kernel.
#[allow(dead_code)]
pub fn debug_lower(family: Family, args: &[String]) -> Result<Vec<String>, String> {
    let Parsed { cmd } = parser::parse(family, args).map_err(|e| e.0)?;
    let b = lower::lower(&cmd).map_err(|e| e.0)?;
    Ok(b.lines.into_iter().map(|l| l.0).collect())
}
