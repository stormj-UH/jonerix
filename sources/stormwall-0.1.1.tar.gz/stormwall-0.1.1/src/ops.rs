//! nftables operations - add/delete/list/flush via netlink. 100% safe Rust.

use crate::netlink::*;
use crate::output;
use crate::parser::*;
use std::cmp::Ordering;
use std::io;

#[derive(Clone)]
struct AnonSetPlan {
    name: String,
    set_id: u32,
    key_type: u32,
    key_len: u32,
    is_interval: bool,
    elements: Vec<(Vec<u8>, Option<Vec<u8>>)>,
    /// For anonymous verdict maps: one verdict per element
    /// (parallel to `elements`). Empty when this is a plain set.
    /// Each tuple is (code, chain_name) matching Expr::Verdict.
    verdicts: Vec<(i32, String)>,
    /// For anonymous data maps: one data value per element.
    data_values: Vec<Vec<u8>>,
    data_type: u32,
    data_len: u32,
}

#[derive(Clone, Copy)]
struct PendingSetInfo {
    set_id: u32,
    key_len: u32,
    key_type: u32,
}

#[derive(Clone)]
struct PreparedRule {
    chain: String,
    comment: Option<String>,
    exprs: Vec<Expr>,
    anon_plans: Vec<AnonSetPlan>,
    bound_chains: Vec<PreparedBoundChain>,
}

#[derive(Clone)]
struct PreparedBoundChain {
    name: String,
    rules: Vec<PreparedRule>,
}

pub struct NftCtx {
    sock: NlSocket,
    pub show_handles: bool,
    pub stateless: bool,
    pub numeric_prio: bool,
    pub numeric_proto: bool,
    pub json: bool,
    pub terse: bool,
    pub echo: bool,
    batch: Option<MsgBuilder>,
    // (family, table, set) entries whose add_set call is still
    // buffered in the current batch. add_elements uses this so it
    // treats a same-batch NEWSET as definitive (the kernel's
    // GETSET dump won't see it yet, so probe_set_is_interval would
    // otherwise lie).
    pending_interval_sets: std::collections::HashSet<(u8, String, String)>,
    pending_named_sets: std::collections::HashMap<(u8, String, String), PendingSetInfo>,
    pending_flush_ruleset: bool,
    // Monotonic `__setN` allocator for anonymous sets created by
    // `ip saddr { a, b }` literals. Also doubles as the NFTA_SET_ID
    // counter (starts at 1 so 0 means "unset"). Never reset so
    // parallel anon sets inside one batch get distinct names.
    anon_set_counter: u32,
}

impl NftCtx {
    const NETLINK_SEND_CHUNK: usize = 60 * 1024;
    const SET_UDATA_KEY_TYPEOF: u8 = 1;
    const SET_UDATA_DATA_TYPEOF: u8 = 2;
    const SET_UDATA_AUTO_MERGE: u8 = 3;

    pub fn new() -> io::Result<Self> {
        Ok(NftCtx {
            sock: NlSocket::open()?,
            show_handles: false,
            stateless: false,
            numeric_prio: false,
            numeric_proto: false,
            json: false,
            terse: false,
            echo: false,
            batch: None,
            pending_interval_sets: std::collections::HashSet::new(),
            pending_named_sets: std::collections::HashMap::new(),
            pending_flush_ruleset: false,
            anon_set_counter: 0,
        })
    }

    fn sync_anon_set_counter(&mut self, family: u8, table: &str) -> io::Result<()> {
        let table_name = table.to_string();
        let mut max_suffix = self.anon_set_counter;
        self.dump(
            NFT_MSG_GETSET,
            family,
            |_, _| {},
            |mt, _, data| {
                if mt != NFT_MSG_NEWSET {
                    return;
                }
                let attrs = parse_attrs(data);
                let set_table = attrs
                    .iter()
                    .find(|(t, _)| *t == NFTA_SET_TABLE)
                    .map(|(_, v)| attr_str(v).to_string())
                    .unwrap_or_default();
                if set_table != table_name {
                    return;
                }
                let set_name = attrs
                    .iter()
                    .find(|(t, _)| *t == NFTA_SET_NAME)
                    .map(|(_, v)| attr_str(v).to_string())
                    .unwrap_or_default();
                let suffix = set_name
                    .strip_prefix("__set")
                    .or_else(|| set_name.strip_prefix("__map"))
                    .and_then(|v| v.parse::<u32>().ok());
                if let Some(n) = suffix {
                    max_suffix = max_suffix.max(n.saturating_add(1));
                }
            },
        )?;
        self.anon_set_counter = max_suffix;
        Ok(())
    }

    fn prepare_rule(&mut self, family: u8, table: &str, cmd: &Command) -> io::Result<PreparedRule> {
        let (exprs, anon_plans) = self.lower_anon_sets(&cmd.exprs);
        let exprs =
            self.rewrite_concat_lookup_regs(self.resolve_pending_lookup_ids(family, table, exprs));
        let mut bound_chains: Vec<PreparedBoundChain> = Vec::new();
        for bound in &cmd.bound_chains {
            let mut rules: Vec<PreparedRule> = Vec::new();
            for rule in &bound.rules {
                rules.push(self.prepare_rule(family, table, rule)?);
            }
            bound_chains.push(PreparedBoundChain {
                name: bound.name.clone(),
                rules,
            });
        }
        Ok(PreparedRule {
            chain: cmd.chain.clone(),
            comment: if cmd.has_comment {
                Some(cmd.comment.clone())
            } else {
                None
            },
            exprs,
            anon_plans,
            bound_chains,
        })
    }

    fn emit_prepared_rule(
        msg: &mut MsgBuilder,
        family: u8,
        table: &str,
        chain: &str,
        flags: u16,
        handle: Option<u64>,
        comment: Option<&str>,
        anon_plans: &[AnonSetPlan],
        exprs: &[Expr],
    ) {
        Self::emit_anon_sets(msg, family, table, anon_plans);

        let pos = msg.begin_msg(NFT_MSG_NEWRULE, family, flags);
        msg.put_str(NFTA_RULE_TABLE, table);
        msg.put_str(NFTA_RULE_CHAIN, chain);
        if let Some(h) = handle {
            msg.put_u64_be(NFTA_RULE_POSITION, h);
        }
        if let Some(c) = comment {
            let cb = c.as_bytes();
            let mut tlv = Vec::with_capacity(cb.len() + 3);
            tlv.push(0u8);
            tlv.push((cb.len() + 1) as u8);
            tlv.extend_from_slice(cb);
            tlv.push(0u8);
            msg.put_bytes(NFTA_RULE_USERDATA, &tlv);
        }

        let exprs_nest = msg.begin_nested(NFTA_RULE_EXPRESSIONS);
        for expr in exprs {
            compile_expr(msg, expr);
        }
        msg.end_nested(exprs_nest);
        msg.end_msg(pos);
    }

    fn emit_bound_chains(
        msg: &mut MsgBuilder,
        family: u8,
        table: &str,
        echo: bool,
        bound_chains: &[PreparedBoundChain],
    ) {
        let mut chain_flags = NLM_F_CREATE | NLM_F_ACK;
        if echo {
            chain_flags |= NLM_F_ECHO;
        }
        let mut rule_flags = NLM_F_CREATE | NLM_F_ACK | NLM_F_APPEND;
        if echo {
            rule_flags |= NLM_F_ECHO;
        }

        for bound in bound_chains {
            let pos = msg.begin_msg(NFT_MSG_NEWCHAIN, family, chain_flags);
            msg.put_str(NFTA_CHAIN_TABLE, table);
            msg.put_str(NFTA_CHAIN_NAME, &bound.name);
            msg.put_u32_be(NFTA_CHAIN_FLAGS, NFT_CHAIN_BINDING);
            msg.end_msg(pos);

            for rule in &bound.rules {
                Self::emit_bound_chains(msg, family, table, echo, &rule.bound_chains);
                Self::emit_prepared_rule(
                    msg,
                    family,
                    table,
                    &bound.name,
                    rule_flags,
                    None,
                    rule.comment.as_deref(),
                    &rule.anon_plans,
                    &rule.exprs,
                );
            }
        }
    }

    fn interval_sort_key(key: &[u8], is_end: bool) -> (bool, &[u8], bool) {
        let wraps_max = is_end && key.iter().all(|b| *b == 0);
        (wraps_max, key, !is_end)
    }

    fn cmp_interval_items(a: &(Vec<u8>, bool), b: &(Vec<u8>, bool)) -> Ordering {
        Self::interval_sort_key(&a.0, a.1).cmp(&Self::interval_sort_key(&b.0, b.1))
    }

    fn interval_range_end(start: &[u8], end: &Option<Vec<u8>>) -> Vec<u8> {
        end.clone().unwrap_or_else(|| start.to_vec())
    }

    fn interval_ranges_touch_or_overlap(cur_end: &[u8], next_start: &[u8]) -> bool {
        if next_start <= cur_end {
            return true;
        }
        let mut succ = cur_end.to_vec();
        for byte in succ.iter_mut().rev() {
            if *byte == 0xff {
                *byte = 0;
            } else {
                *byte += 1;
                return next_start == succ;
            }
        }
        false
    }

    fn merge_interval_items<T: Clone + PartialEq>(
        mut items: Vec<(Vec<u8>, Vec<u8>, T)>,
    ) -> Vec<(Vec<u8>, Vec<u8>, T)> {
        items.sort_by(|a, b| a.0.cmp(&b.0).then(a.1.cmp(&b.1)));
        let mut merged: Vec<(Vec<u8>, Vec<u8>, T)> = Vec::new();
        for (start, end, tag) in items {
            if let Some((_, cur_end, cur_tag)) = merged.last_mut() {
                if *cur_tag == tag && Self::interval_ranges_touch_or_overlap(cur_end, &start) {
                    if end > *cur_end {
                        *cur_end = end;
                    }
                    continue;
                }
            }
            merged.push((start, end, tag));
        }
        merged
    }

    // Lower Expr::AnonSet entries into Expr::Lookup plus a list of
    // AnonSetPlan records (NEWSET + NEWSETELEM messages that must
    // precede the rule in the same netlink batch). Shared between
    // add_rule and exec_replace so both `add rule ... { a, b }` and
    // `replace rule handle N ... { a, b }` work.
    fn lower_anon_sets(&mut self, in_exprs: &[Expr]) -> (Vec<Expr>, Vec<AnonSetPlan>) {
        use crate::netlink as nl;
        let mut anon_plans: Vec<AnonSetPlan> = Vec::new();
        let mut exprs: Vec<Expr> = Vec::with_capacity(in_exprs.len());
        let mut last_ctx_type: Option<(u32, u32)> = None;
        for e in in_exprs {
            match e {
                Expr::Payload {
                    offset,
                    len,
                    base,
                    protocol,
                    ..
                } => {
                    last_ctx_type = Some(match (*base, *offset, *len, *protocol) {
                        (b, 12, 4, _) | (b, 16, 4, _) if b == nl::NFT_PAYLOAD_NETWORK_HEADER => {
                            (7, 4)
                        }
                        (b, 8, 16, _) | (b, 24, 16, _) if b == nl::NFT_PAYLOAD_NETWORK_HEADER => {
                            (8, 16)
                        }
                        (b, 0, 2, _) | (b, 2, 2, _) if b == nl::NFT_PAYLOAD_TRANSPORT_HEADER => {
                            (13, 2)
                        }
                        (b, 0, 1, 1) if b == nl::NFT_PAYLOAD_TRANSPORT_HEADER => (14, 1),
                        (b, 1, 1, 1) if b == nl::NFT_PAYLOAD_TRANSPORT_HEADER => (18, 1),
                        (b, 0, 1, 58) if b == nl::NFT_PAYLOAD_TRANSPORT_HEADER => (19, 1),
                        (b, 1, 1, 58) if b == nl::NFT_PAYLOAD_TRANSPORT_HEADER => (20, 1),
                        (_, _, 1, _) => (12, 1),
                        (_, _, w, _) => (4, w),
                    });
                }
                Expr::Meta { key, width, .. } => {
                    last_ctx_type = Some(match *key {
                        nl::NFT_META_MARK => (15, 4),
                        nl::NFT_META_IIFNAME | nl::NFT_META_OIFNAME => (16, 16),
                        nl::NFT_META_L4PROTO => (12, 1),
                        nl::NFT_META_NFPROTO => (2, 1),
                        nl::NFT_META_PROTOCOL => (10, 2),
                        nl::NFT_META_IIF | nl::NFT_META_OIF => (36, 4),
                        _ => (4, *width as u32),
                    });
                }
                Expr::Ct { key, width, .. } => {
                    last_ctx_type = Some(match *key {
                        nl::NFT_CT_STATE => (27, *width as u32),
                        nl::NFT_CT_DIRECTION => (28, *width as u32),
                        nl::NFT_CT_STATUS => (29, *width as u32),
                        _ => (4, *width as u32),
                    });
                }
                Expr::Rt { key, width, .. } => {
                    last_ctx_type = Some(match *key {
                        nl::NFT_RT_NEXTHOP4 => (7, 4),
                        nl::NFT_RT_NEXTHOP6 => (8, 16),
                        nl::NFT_RT_TCPMSS => (13, 2),
                        nl::NFT_RT_XFRM => (12, 1),
                        _ => (4, *width as u32),
                    });
                }
                Expr::Exthdr {
                    raw_type,
                    offset,
                    len,
                    op,
                    flags,
                    ..
                } => {
                    last_ctx_type = Some(match (*op, *raw_type, *offset, *len, *flags) {
                        (nl::NFT_EXTHDR_OP_IPV6, nl::IPPROTO_ROUTING, 2, 1, 0) => (12, 1),
                        (nl::NFT_EXTHDR_OP_TCPOPT, nl::TCPOPT_MAXSEG, 2, 2, 0) => (13, 2),
                        (_, _, _, 1, _) => (12, 1),
                        (_, _, _, w, _) => (4, w),
                    });
                }
                _ => {}
            }
            match e {
                Expr::AnonSet {
                    elements,
                    width,
                    inverted,
                    key_type,
                } => {
                    self.anon_set_counter = self.anon_set_counter.wrapping_add(1);
                    let n = self.anon_set_counter;
                    let name = format!("__set{}", n - 1);
                    let is_interval = elements.iter().any(|(_, end)| end.is_some());
                    let (key_type, key_len) = match key_type {
                        Some(t) => (*t, *width as u32),
                        None => last_ctx_type.take().unwrap_or_else(|| match *width {
                            4 => (7u32, 4u32),
                            16 => (8u32, 16u32),
                            2 => (13u32, 2u32),
                            1 => (12u32, 1u32),
                            w => (4u32, w as u32),
                        }),
                    };
                    let merged = if is_interval && !is_concat_type(key_type) {
                        Self::merge_interval_items(
                            elements
                                .iter()
                                .map(|(start, end)| {
                                    (start.clone(), Self::interval_range_end(start, end), ())
                                })
                                .collect(),
                        )
                        .into_iter()
                        .map(|(start, end, _)| {
                            let range_end = if start == end { None } else { Some(end) };
                            (start, range_end)
                        })
                        .collect()
                    } else {
                        elements.clone()
                    };
                    anon_plans.push(AnonSetPlan {
                        name: name.clone(),
                        set_id: n,
                        key_type,
                        key_len,
                        is_interval,
                        elements: merged,
                        verdicts: Vec::new(),
                        data_values: Vec::new(),
                        data_type: 0,
                        data_len: 0,
                    });
                    exprs.push(Expr::Lookup {
                        set_name: name,
                        inverted: *inverted,
                        width: *width,
                        set_id: Some(n),
                        key_type: Some(key_type),
                    });
                }
                Expr::AnonVmap {
                    pairs,
                    width,
                    key_type,
                } => {
                    self.anon_set_counter = self.anon_set_counter.wrapping_add(1);
                    let n = self.anon_set_counter;
                    let name = format!("__map{}", n - 1);
                    let (key_type, key_len) = match key_type {
                        Some(t) => (*t, *width as u32),
                        None => last_ctx_type.take().unwrap_or_else(|| match *width {
                            4 => (7u32, 4u32),
                            16 => (8u32, 16u32),
                            2 => (13u32, 2u32),
                            1 => (12u32, 1u32),
                            w => (4u32, w as u32),
                        }),
                    };
                    let is_interval = pairs.iter().any(|(_, end, _, _)| end.is_some());
                    let merged = if is_interval && !is_concat_type(key_type) {
                        Self::merge_interval_items(
                            pairs
                                .iter()
                                .map(|(start, end, code, chain)| {
                                    (
                                        start.clone(),
                                        Self::interval_range_end(start, end),
                                        (*code, chain.clone()),
                                    )
                                })
                                .collect(),
                        )
                    } else {
                        pairs
                            .iter()
                            .map(|(start, end, code, chain)| {
                                (
                                    start.clone(),
                                    Self::interval_range_end(start, end),
                                    (*code, chain.clone()),
                                )
                            })
                            .collect()
                    };
                    let elements: Vec<(Vec<u8>, Option<Vec<u8>>)> = merged
                        .iter()
                        .map(|(start, end, _)| {
                            (
                                start.clone(),
                                if *start == *end {
                                    None
                                } else {
                                    Some(end.clone())
                                },
                            )
                        })
                        .collect();
                    let verdicts: Vec<(i32, String)> = merged
                        .iter()
                        .map(|(_, _, verdict)| verdict.clone())
                        .collect();
                    anon_plans.push(AnonSetPlan {
                        name: name.clone(),
                        set_id: n,
                        key_type,
                        key_len,
                        is_interval,
                        elements,
                        verdicts,
                        data_values: Vec::new(),
                        data_type: 0xffffff00,
                        data_len: 0,
                    });
                    exprs.push(Expr::Vmap {
                        set_name: name,
                        width: *width,
                        set_id: Some(n),
                        key_type: Some(key_type),
                    });
                }
                Expr::AnonMap {
                    pairs,
                    width,
                    key_type,
                    data_type,
                    data_len,
                    dreg,
                } => {
                    self.anon_set_counter = self.anon_set_counter.wrapping_add(1);
                    let n = self.anon_set_counter;
                    let name = format!("__map{}", n - 1);
                    let (key_type, key_len) = match key_type {
                        Some(t) => (*t, *width as u32),
                        None => last_ctx_type.take().unwrap_or_else(|| match *width {
                            4 => (7u32, 4u32),
                            16 => (8u32, 16u32),
                            2 => (13u32, 2u32),
                            1 => (12u32, 1u32),
                            w => (4u32, w as u32),
                        }),
                    };
                    let is_interval = pairs.iter().any(|(_, end, _)| end.is_some());
                    let merged = if is_interval && !is_concat_type(key_type) {
                        Self::merge_interval_items(
                            pairs
                                .iter()
                                .map(|(start, end, value)| {
                                    (
                                        start.clone(),
                                        Self::interval_range_end(start, end),
                                        value.clone(),
                                    )
                                })
                                .collect(),
                        )
                    } else {
                        pairs
                            .iter()
                            .map(|(start, end, value)| {
                                (
                                    start.clone(),
                                    Self::interval_range_end(start, end),
                                    value.clone(),
                                )
                            })
                            .collect()
                    };
                    let elements: Vec<(Vec<u8>, Option<Vec<u8>>)> = merged
                        .iter()
                        .map(|(start, end, _)| {
                            (
                                start.clone(),
                                if *start == *end {
                                    None
                                } else {
                                    Some(end.clone())
                                },
                            )
                        })
                        .collect();
                    let data_values: Vec<Vec<u8>> =
                        merged.iter().map(|(_, _, value)| value.clone()).collect();
                    anon_plans.push(AnonSetPlan {
                        name: name.clone(),
                        set_id: n,
                        key_type,
                        key_len,
                        is_interval,
                        elements,
                        verdicts: Vec::new(),
                        data_values,
                        data_type: *data_type,
                        data_len: *data_len,
                    });
                    exprs.push(Expr::Map {
                        set_name: name,
                        width: *width,
                        set_id: Some(n),
                        key_type: Some(key_type),
                        dreg: *dreg,
                    });
                }
                _ => {
                    exprs.push(e.clone());
                }
            }
        }
        (exprs, anon_plans)
    }

    fn resolve_pending_lookup_ids(
        &self,
        family: u8,
        table: &str,
        in_exprs: Vec<Expr>,
    ) -> Vec<Expr> {
        in_exprs
            .into_iter()
            .map(|expr| match expr {
                Expr::Lookup {
                    set_name,
                    inverted,
                    width,
                    set_id,
                    key_type,
                } => {
                    let info = self
                        .pending_named_sets
                        .get(&(family, table.to_string(), set_name.clone()))
                        .copied();
                    Expr::Lookup {
                        set_name,
                        inverted,
                        width,
                        set_id: set_id.or(info.map(|x| x.set_id)),
                        key_type: key_type.or(info.map(|x| x.key_type)),
                    }
                }
                Expr::Vmap {
                    set_name,
                    width,
                    set_id,
                    key_type,
                } => {
                    let info = self
                        .pending_named_sets
                        .get(&(family, table.to_string(), set_name.clone()))
                        .copied();
                    Expr::Vmap {
                        set_name,
                        width,
                        set_id: set_id.or(info.map(|x| x.set_id)),
                        key_type: key_type.or(info.map(|x| x.key_type)),
                    }
                }
                Expr::Map {
                    set_name,
                    width,
                    set_id,
                    key_type,
                    dreg,
                } => {
                    let info = self
                        .pending_named_sets
                        .get(&(family, table.to_string(), set_name.clone()))
                        .copied();
                    Expr::Map {
                        set_name,
                        width,
                        set_id: set_id.or(info.map(|x| x.set_id)),
                        key_type: key_type.or(info.map(|x| x.key_type)),
                        dreg,
                    }
                }
                Expr::DynSet {
                    set_name,
                    op,
                    timeout_ms,
                    set_id,
                    key_type,
                    data_sreg,
                } => {
                    let info = self
                        .pending_named_sets
                        .get(&(family, table.to_string(), set_name.clone()))
                        .copied();
                    Expr::DynSet {
                        set_name,
                        op,
                        timeout_ms,
                        set_id: set_id.or(info.map(|x| x.set_id)),
                        key_type: key_type.or(info.map(|x| x.key_type)),
                        data_sreg,
                    }
                }
                other => other,
            })
            .collect()
    }

    fn concat_reg_for_word_offset(words: usize) -> u32 {
        if words % NFT_REG32_COUNT == 0 {
            NFT_REG_1 + (words / NFT_REG32_COUNT) as u32
        } else {
            NFT_REG32_00 + words as u32
        }
    }

    fn expr_field_len(expr: &Expr) -> Option<u32> {
        match expr {
            Expr::Payload { len, .. } => Some(*len),
            Expr::Meta { width, .. } => Some(*width as u32),
            Expr::Ct { width, .. } => Some(*width as u32),
            Expr::Fib { width, .. } => Some(*width as u32),
            Expr::Rt { width, .. } => Some(*width as u32),
            Expr::Exthdr { len, .. } => Some(*len),
            Expr::DataLoad { data, .. } => Some(data.len() as u32),
            _ => None,
        }
    }

    fn set_expr_dreg(expr: &mut Expr, dreg: u32) {
        match expr {
            Expr::Payload { dreg: slot, .. } if slot.is_none() => *slot = Some(dreg),
            Expr::Meta { dreg: slot, .. } if slot.is_none() => *slot = Some(dreg),
            Expr::Ct { dreg: slot, .. } if slot.is_none() => *slot = Some(dreg),
            Expr::Fib { dreg: slot, .. } if slot.is_none() => *slot = Some(dreg),
            Expr::Rt { dreg: slot, .. } if slot.is_none() => *slot = Some(dreg),
            Expr::Exthdr {
                dreg: slot, sreg, ..
            } if sreg.is_none() && slot.is_none() => *slot = Some(dreg),
            Expr::DataLoad { dreg: slot, .. } if slot.is_none() => *slot = Some(dreg),
            _ => {}
        }
    }

    fn rewrite_concat_lookup_regs(&self, exprs: Vec<Expr>) -> Vec<Expr> {
        let mut out = exprs;
        for idx in 0..out.len() {
            let key_type = match &out[idx] {
                Expr::Lookup { key_type, .. }
                | Expr::Vmap { key_type, .. }
                | Expr::Map { key_type, .. }
                | Expr::DynSet { key_type, .. } => *key_type,
                _ => None,
            };
            let Some(key_type) = key_type else {
                continue;
            };
            let field_lens = concat_field_lens_from_type(key_type);
            if field_lens.len() <= 1 {
                continue;
            }

            let mut load_idxs: Vec<usize> = Vec::new();
            for probe in (0..idx).rev() {
                if Self::expr_field_len(&out[probe]).is_some() {
                    load_idxs.push(probe);
                    if load_idxs.len() == field_lens.len() {
                        break;
                    }
                }
            }
            if load_idxs.len() != field_lens.len() {
                continue;
            }
            load_idxs.reverse();

            let mut word_offset = 0usize;
            for (load_idx, field_len) in load_idxs.into_iter().zip(field_lens.iter()) {
                let dreg = Self::concat_reg_for_word_offset(word_offset);
                Self::set_expr_dreg(&mut out[load_idx], dreg);
                word_offset += (padded_key_len(*field_len) / 4) as usize;
            }
        }
        out
    }

    // Emit the NEWSET + NEWSETELEM preambles for an anon-set plan
    // batch into the MsgBuilder (which is either the shared
    // batch buffer or a fresh one per `send_batch` invocation).
    fn emit_anon_sets(msg: &mut MsgBuilder, family: u8, table: &str, plans: &[AnonSetPlan]) {
        for plan in plans {
            let is_vmap = !plan.verdicts.is_empty();
            let is_data_map = !plan.data_values.is_empty();
            let pset = msg.begin_msg(NFT_MSG_NEWSET, family, NLM_F_CREATE | NLM_F_ACK);
            msg.put_str(NFTA_SET_TABLE, table);
            msg.put_str(NFTA_SET_NAME, &plan.name);
            msg.put_u32_be(NFTA_SET_KEY_TYPE, plan.key_type);
            msg.put_u32_be(NFTA_SET_KEY_LEN, plan.key_len);
            let mut flags_v = NFT_SET_ANONYMOUS | NFT_SET_CONSTANT;
            if plan.is_interval {
                flags_v |= NFT_SET_INTERVAL;
            }
            if is_vmap || is_data_map {
                flags_v |= NFT_SET_MAP;
            }
            if is_concat_type(plan.key_type) {
                flags_v |= NFT_SET_CONCAT;
            }
            msg.put_u32_be(NFTA_SET_FLAGS, flags_v);
            if is_concat_type(plan.key_type) {
                let desc = msg.begin_nested(NFTA_SET_DESC);
                let concat = msg.begin_nested(NFTA_SET_DESC_CONCAT);
                for field_len in concat_field_lens_from_type(plan.key_type) {
                    let elem = msg.begin_nested(NFTA_LIST_ELEM);
                    msg.put_u32_be(NFTA_SET_FIELD_LEN, field_len);
                    msg.end_nested(elem);
                }
                msg.end_nested(concat);
                msg.end_nested(desc);
            }
            if is_vmap {
                // NFT_DATA_VERDICT = 0xffffff00 (a mask, not a type index).
                // For verdict-valued sets the kernel sets dlen to the
                // verdict struct size itself, so we send DATA_LEN=0 —
                // matches upstream nft wire format verbatim.
                msg.put_u32_be(NFTA_SET_DATA_TYPE, 0xffffff00);
                msg.put_u32_be(NFTA_SET_DATA_LEN, 0);
            } else if is_data_map {
                msg.put_u32_be(NFTA_SET_DATA_TYPE, plan.data_type);
                msg.put_u32_be(NFTA_SET_DATA_LEN, plan.data_len);
            }
            msg.put_u32_be(NFTA_SET_ID, plan.set_id);
            msg.end_msg(pset);

            let pelem = msg.begin_msg(NFT_MSG_NEWSETELEM, family, NLM_F_CREATE | NLM_F_ACK);
            msg.put_str(NFTA_SET_ELEM_LIST_TABLE, table);
            msg.put_str(NFTA_SET_ELEM_LIST_SET, &plan.name);
            msg.put_u32_be(NFTA_SET_ELEM_LIST_SET_ID, plan.set_id);
            let elist = msg.begin_nested(NFTA_SET_ELEM_LIST_ELEMENTS);
            for (i, (key, range_end)) in plan.elements.iter().enumerate() {
                let effective_end: Option<Vec<u8>> = if range_end.is_some() {
                    range_end.clone()
                } else if plan.is_interval {
                    Some(key.clone())
                } else {
                    None
                };
                let ee = msg.begin_nested(NFTA_LIST_ELEM);
                msg.put_data_value(NFTA_SET_ELEM_KEY, key);
                if plan.is_interval && is_concat_type(plan.key_type) {
                    if let Some(end) = &effective_end {
                        msg.put_data_value(NFTA_SET_ELEM_KEY_END, end);
                    }
                }
                if is_vmap {
                    let (code, chain) = &plan.verdicts[i];
                    // DATA nested: NFTA_DATA_VERDICT nested with
                    // VERDICT_CODE and optional VERDICT_CHAIN.
                    let d = msg.begin_nested(NFTA_SET_ELEM_DATA);
                    let vd = msg.begin_nested(NFTA_DATA_VERDICT);
                    msg.put_u32_be(NFTA_VERDICT_CODE, *code as u32);
                    if !chain.is_empty() {
                        msg.put_str(NFTA_VERDICT_CHAIN, chain);
                    }
                    msg.end_nested(vd);
                    msg.end_nested(d);
                } else if is_data_map {
                    msg.put_data_value(NFTA_SET_ELEM_DATA, &plan.data_values[i]);
                }
                msg.end_nested(ee);
                if plan.is_interval && !is_concat_type(plan.key_type) {
                    if let Some(end) = effective_end {
                        let mut end_plus = end.clone();
                        for byte in end_plus.iter_mut().rev() {
                            if *byte == 0xff {
                                *byte = 0;
                            } else {
                                *byte += 1;
                                break;
                            }
                        }
                        let ee2 = msg.begin_nested(NFTA_LIST_ELEM);
                        msg.put_data_value(NFTA_SET_ELEM_KEY, &end_plus);
                        msg.put_u32_be(NFTA_SET_ELEM_FLAGS, NFT_SET_ELEM_INTERVAL_END);
                        msg.end_nested(ee2);
                    }
                }
            }
            msg.end_nested(elist);
            msg.end_msg(pelem);
        }
    }

    // ── Transactional batch mode ─────────────────────────────────
    // Buffer every NEW*/DEL* into one netlink batch so the whole
    // ruleset applies atomically. Any kernel ENOENT/EEXIST from
    // later messages rolls back earlier ones. Used for -f input.
    pub fn begin_txn(&mut self) {
        let mut m = MsgBuilder::new();
        m.batch_begin();
        self.batch = Some(m);
        self.pending_interval_sets.clear();
        self.pending_named_sets.clear();
        self.pending_flush_ruleset = false;
    }

    pub fn commit_txn(&mut self) -> io::Result<()> {
        if let Some(mut m) = self.batch.take() {
            self.pending_interval_sets.clear();
            self.pending_named_sets.clear();
            self.pending_flush_ruleset = false;
            m.batch_end();
            let buf = m.finish();
            self.send_netlink_stream(&buf)?;
            let deadline = std::time::Instant::now() + std::time::Duration::from_secs(30);
            // Capture NLM_F_ECHO'd messages so callers can print
            // the rule they just added (with kernel-assigned handle)
            // — `-e` / --echo semantics.
            let echo = self.echo;
            let mut echoed: Vec<(u16, u8, Vec<u8>)> = Vec::new();
            let portid = self.sock.portid;
            loop {
                if std::time::Instant::now() >= deadline {
                    break;
                }
                let mut resp = vec![0u8; 65536];
                let n = self.sock.recv_timeout(&mut resp, 2000)?;
                if n == 0 {
                    break;
                }
                // Walk the buffer: accumulate echoes, propagate errors.
                if echo {
                    let slice = &resp[..n];
                    let _ = process_response(slice, portid, |mt, fam, data| {
                        echoed.push((mt, fam, data.to_vec()));
                    })?;
                } else {
                    check_ack(&resp[..n])?;
                }
            }
            if echo {
                self.print_echoed(&echoed);
            }
        }
        Ok(())
    }

    fn send_netlink_stream(&self, buf: &[u8]) -> io::Result<()> {
        let mut start = 0usize;
        while start < buf.len() {
            let mut end = start;
            while end < buf.len() {
                if end + 4 > buf.len() {
                    return Err(io::Error::new(
                        io::ErrorKind::InvalidData,
                        "truncated netlink message",
                    ));
                }
                let nlmsg_len =
                    u32::from_ne_bytes([buf[end], buf[end + 1], buf[end + 2], buf[end + 3]])
                        as usize;
                let msg_len = ((nlmsg_len + 3) / 4) * 4;
                if nlmsg_len < 16 || end + msg_len > buf.len() {
                    return Err(io::Error::new(
                        io::ErrorKind::InvalidData,
                        "invalid netlink message length",
                    ));
                }
                if end > start && end + msg_len - start > Self::NETLINK_SEND_CHUNK {
                    break;
                }
                end += msg_len;
            }
            if end == start {
                return Err(io::Error::new(
                    io::ErrorKind::InvalidData,
                    "single netlink message exceeds send chunk",
                ));
            }
            self.sock.send(&buf[start..end])?;
            start = end;
        }
        Ok(())
    }

    fn print_echoed(&self, echoed: &[(u16, u8, Vec<u8>)]) {
        for (mt, fam, data) in echoed {
            let attrs = parse_attrs(data);
            match *mt {
                NFT_MSG_NEWRULE => {
                    let table = attrs
                        .iter()
                        .find(|(t, _)| *t == NFTA_RULE_TABLE)
                        .map(|(_, v)| attr_str(v).to_string())
                        .unwrap_or_default();
                    let chain = attrs
                        .iter()
                        .find(|(t, _)| *t == NFTA_RULE_CHAIN)
                        .map(|(_, v)| attr_str(v).to_string())
                        .unwrap_or_default();
                    let handle = attrs
                        .iter()
                        .find(|(t, _)| *t == NFTA_RULE_HANDLE)
                        .map(|(_, v)| attr_u64_be(v))
                        .unwrap_or(0);
                    println!(
                        "add rule {} {} {} # handle {}",
                        family_str(*fam),
                        table,
                        chain,
                        handle
                    );
                }
                NFT_MSG_NEWTABLE => {
                    let name = attrs
                        .iter()
                        .find(|(t, _)| *t == NFTA_TABLE_NAME)
                        .map(|(_, v)| attr_str(v).to_string())
                        .unwrap_or_default();
                    let handle = attrs
                        .iter()
                        .find(|(t, _)| *t == NFTA_TABLE_HANDLE)
                        .map(|(_, v)| attr_u64_be(v))
                        .unwrap_or(0);
                    println!(
                        "add table {} {} # handle {}",
                        family_str(*fam),
                        name,
                        handle
                    );
                }
                NFT_MSG_NEWCHAIN => {
                    let table = attrs
                        .iter()
                        .find(|(t, _)| *t == NFTA_CHAIN_TABLE)
                        .map(|(_, v)| attr_str(v).to_string())
                        .unwrap_or_default();
                    let name = attrs
                        .iter()
                        .find(|(t, _)| *t == NFTA_CHAIN_NAME)
                        .map(|(_, v)| attr_str(v).to_string())
                        .unwrap_or_default();
                    let handle = attrs
                        .iter()
                        .find(|(t, _)| *t == NFTA_CHAIN_HANDLE)
                        .map(|(_, v)| attr_u64_be(v))
                        .unwrap_or(0);
                    println!(
                        "add chain {} {} {} # handle {}",
                        family_str(*fam),
                        table,
                        name,
                        handle
                    );
                }
                _ => {}
            }
        }
    }

    pub fn abort_txn(&mut self) {
        self.batch = None;
        self.pending_interval_sets.clear();
        self.pending_named_sets.clear();
        self.pending_flush_ruleset = false;
    }

    pub fn exec(&mut self, cmd: &Command) -> io::Result<()> {
        match cmd.op {
            CmdOp::Add | CmdOp::Create => self.exec_add(cmd),
            CmdOp::Insert => self.exec_insert(cmd),
            CmdOp::Delete => self.exec_delete(cmd, false),
            CmdOp::Destroy => self.exec_delete(cmd, true),
            CmdOp::List => self.exec_list(cmd),
            CmdOp::Flush => self.exec_flush(cmd),
            CmdOp::Rename => self.exec_rename(cmd),
            CmdOp::Replace => self.exec_replace(cmd),
            CmdOp::Reset => self.exec_list(cmd), // simplified
        }
    }

    // ── Batch send helper ───────────────────────────────────────

    fn send_batch(&mut self, build: impl FnOnce(&mut MsgBuilder)) -> io::Result<()> {
        if let Some(ref mut m) = self.batch {
            build(m);
            return Ok(());
        }
        let mut msg = MsgBuilder::new();
        msg.batch_begin();
        build(&mut msg);
        msg.batch_end();
        let buf = msg.finish();
        self.sock.send(&buf)?;

        // Read all responses until timeout; kernel may send multiple messages
        loop {
            let mut resp = vec![0u8; 65536];
            let n = self.sock.recv_timeout(&mut resp, 2000)?;
            if n == 0 {
                break;
            }
            check_ack(&resp[..n])?;
        }
        Ok(())
    }

    // ── Dump helper ─────────────────────────────────────────────

    fn dump<F>(
        &mut self,
        msg_type: u16,
        family: u8,
        build_payload: impl FnOnce(&mut MsgBuilder, usize),
        mut handler: F,
    ) -> io::Result<()>
    where
        F: FnMut(u16, u8, &[u8]),
    {
        let mut msg = MsgBuilder::new();
        let pos = msg.begin_msg(msg_type, family, NLM_F_ACK | NLM_F_DUMP);
        build_payload(&mut msg, pos);
        msg.end_msg(pos);
        let buf = msg.finish();
        self.sock.send(&buf)?;

        loop {
            let mut resp = vec![0u8; 65536];
            let n = self.sock.recv(&mut resp)?;
            if n == 0 {
                break;
            }
            let done = process_response(&resp[..n], self.sock.portid, &mut handler)?;
            if done {
                break;
            }
        }
        Ok(())
    }

    fn get_one<F>(
        &mut self,
        msg_type: u16,
        family: u8,
        build_payload: impl FnOnce(&mut MsgBuilder, usize),
        mut handler: F,
    ) -> io::Result<()>
    where
        F: FnMut(u16, u8, &[u8]),
    {
        let mut msg = MsgBuilder::new();
        let pos = msg.begin_msg(msg_type, family, NLM_F_ACK);
        build_payload(&mut msg, pos);
        msg.end_msg(pos);
        let buf = msg.finish();
        self.sock.send(&buf)?;

        loop {
            let mut resp = vec![0u8; 65536];
            let n = self.sock.recv_timeout(&mut resp, 500)?;
            if n == 0 {
                break;
            }
            let done = process_response(&resp[..n], self.sock.portid, &mut handler)?;
            if done {
                break;
            }
        }
        Ok(())
    }

    fn get_table_attrs(
        &mut self,
        family: u8,
        table: &str,
    ) -> io::Result<Option<Vec<(u16, Vec<u8>)>>> {
        let tbl = table.to_string();
        let mut out = None;
        self.get_one(
            NFT_MSG_GETTABLE,
            family,
            |msg, _| {
                msg.put_str(NFTA_TABLE_NAME, &tbl);
            },
            |mt, _, data| {
                if mt == NFT_MSG_NEWTABLE {
                    out = Some(parse_attrs(data));
                }
            },
        )?;
        Ok(out)
    }

    fn get_set_attrs(
        &mut self,
        family: u8,
        table: &str,
        name: &str,
    ) -> io::Result<Option<Vec<(u16, Vec<u8>)>>> {
        let tbl = table.to_string();
        let set = name.to_string();
        let mut out = None;
        self.get_one(
            NFT_MSG_GETSET,
            family,
            |msg, _| {
                msg.put_str(NFTA_SET_TABLE, &tbl);
                msg.put_str(NFTA_SET_NAME, &set);
            },
            |mt, _, data| {
                if mt == NFT_MSG_NEWSET {
                    out = Some(parse_attrs(data));
                }
            },
        )?;
        Ok(out)
    }

    fn get_object_attrs(
        &mut self,
        family: u8,
        table: &str,
        name: &str,
        kind: u32,
    ) -> io::Result<Option<Vec<(u16, Vec<u8>)>>> {
        let tbl = table.to_string();
        let obj = name.to_string();
        let mut out = None;
        self.get_one(
            NFT_MSG_GETOBJ,
            family,
            |msg, _| {
                msg.put_str(NFTA_OBJ_TABLE, &tbl);
                msg.put_str(NFTA_OBJ_NAME, &obj);
                msg.put_u32_be(NFTA_OBJ_TYPE, kind);
            },
            |mt, _, data| {
                if mt == NFT_MSG_NEWOBJ {
                    out = Some(parse_attrs(data));
                }
            },
        )?;
        Ok(out)
    }

    fn get_flowtable_attrs(
        &mut self,
        family: u8,
        table: &str,
        name: &str,
    ) -> io::Result<Option<Vec<(u16, Vec<u8>)>>> {
        let tbl = table.to_string();
        let flow = name.to_string();
        let mut out = None;
        self.get_one(
            NFT_MSG_GETFLOWTABLE,
            family,
            |msg, _| {
                msg.put_str(NFTA_FLOWTABLE_TABLE, &tbl);
                msg.put_str(NFTA_FLOWTABLE_NAME, &flow);
            },
            |mt, _, data| {
                if mt == NFT_MSG_NEWFLOWTABLE {
                    out = Some(parse_attrs(data));
                }
            },
        )?;
        Ok(out)
    }

    // ── Add ─────────────────────────────────────────────────────

    fn exec_add(&mut self, cmd: &Command) -> io::Result<()> {
        match cmd.obj {
            CmdObj::Table => self.add_table(cmd),
            CmdObj::Chain => self.add_chain(cmd),
            CmdObj::Rule => self.add_rule(cmd, false),
            CmdObj::Set | CmdObj::Map => self.add_set(cmd),
            CmdObj::Flowtable => self.add_flowtable(cmd),
            CmdObj::Element => self.add_elements(cmd),
            CmdObj::Counter
            | CmdObj::Quota
            | CmdObj::Limit
            | CmdObj::CtTimeout
            | CmdObj::CtExpectation => self.add_object(cmd),
            _ => Err(io::Error::new(
                io::ErrorKind::Other,
                "unsupported add target",
            )),
        }
    }

    fn exec_insert(&mut self, cmd: &Command) -> io::Result<()> {
        if matches!(cmd.obj, CmdObj::Rule) {
            self.add_rule(cmd, true)
        } else {
            Err(io::Error::new(
                io::ErrorKind::Other,
                "insert only for rules",
            ))
        }
    }

    fn add_table(&mut self, cmd: &Command) -> io::Result<()> {
        let family = cmd.family;
        let name = cmd.table.clone();
        let flags = if cmd.table_spec.has_flags {
            Some(cmd.table_spec.flags)
        } else {
            None
        };
        // `create` (vs plain `add`) asks the kernel to fail with EEXIST
        // when the object is already present — the tests rely on this
        // for duplicate-detection assertions.
        let mut nlm_flags = NLM_F_CREATE | NLM_F_ACK;
        if matches!(cmd.op, CmdOp::Create) {
            nlm_flags |= NLM_F_EXCL;
        }
        if self.echo {
            nlm_flags |= NLM_F_ECHO;
        }
        self.send_batch(|msg| {
            let pos = msg.begin_msg(NFT_MSG_NEWTABLE, family, nlm_flags);
            msg.put_str(NFTA_TABLE_NAME, &name);
            if let Some(f) = flags {
                msg.put_u32_be(NFTA_TABLE_FLAGS, f);
            }
            msg.end_msg(pos);
        })
    }

    fn add_chain(&mut self, cmd: &Command) -> io::Result<()> {
        let family = cmd.family;
        let table = cmd.table.clone();
        let chain = cmd.chain.clone();
        let spec = cmd.chain_spec.clone();
        let mut nlm_flags = NLM_F_CREATE | NLM_F_ACK;
        if matches!(cmd.op, CmdOp::Create) {
            nlm_flags |= NLM_F_EXCL;
        }
        if self.echo {
            nlm_flags |= NLM_F_ECHO;
        }
        self.send_batch(|msg| {
            let pos = msg.begin_msg(NFT_MSG_NEWCHAIN, family, nlm_flags);
            msg.put_str(NFTA_CHAIN_TABLE, &table);
            msg.put_str(NFTA_CHAIN_NAME, &chain);

            if spec.is_base {
                msg.put_str(NFTA_CHAIN_TYPE, &spec.chain_type);

                let hook_nest = msg.begin_nested(NFTA_CHAIN_HOOK);
                // inet's ingress hook lives at number 5, not 0 (0 is
                // prerouting for inet but ingress for netdev). Keep
                // hook_from_str compatible with legacy callers by
                // picking the family-specific value here.
                let hooknum = if spec.hook == "ingress" && family == NFPROTO_INET {
                    Some(5)
                } else {
                    hook_from_str(&spec.hook)
                };
                if let Some(h) = hooknum {
                    msg.put_u32_be(NFTA_HOOK_HOOKNUM, h);
                }
                if spec.has_priority {
                    msg.put_u32_be(NFTA_HOOK_PRIORITY, spec.priority as u32);
                }
                if spec.has_device {
                    msg.put_str(NFTA_HOOK_DEV, &spec.device);
                }
                msg.end_nested(hook_nest);
            }
            if spec.has_policy {
                let policy = if spec.policy == "drop" {
                    NF_DROP as u32
                } else {
                    NF_ACCEPT as u32
                };
                msg.put_u32_be(NFTA_CHAIN_POLICY, policy);
            }
            msg.end_msg(pos);
        })
    }

    fn add_flowtable(&mut self, cmd: &Command) -> io::Result<()> {
        let family = cmd.family;
        let table = cmd.table.clone();
        let name = cmd.set_name.clone();
        let spec = cmd.flowtable_spec.clone();
        let mut nlm_flags = NLM_F_CREATE | NLM_F_ACK;
        if matches!(cmd.op, CmdOp::Create) {
            nlm_flags |= NLM_F_EXCL;
        }
        if self.echo {
            nlm_flags |= NLM_F_ECHO;
        }
        self.send_batch(|msg| {
            let pos = msg.begin_msg(NFT_MSG_NEWFLOWTABLE, family, nlm_flags);
            msg.put_str(NFTA_FLOWTABLE_TABLE, &table);
            msg.put_str(NFTA_FLOWTABLE_NAME, &name);

            let hook_nest = msg.begin_nested(NFTA_FLOWTABLE_HOOK);
            msg.put_u32_be(NFTA_FLOWTABLE_HOOK_NUM, NF_NETDEV_INGRESS);
            if spec.has_priority {
                msg.put_u32_be(NFTA_FLOWTABLE_HOOK_PRIORITY, spec.priority as u32);
            }
            if !spec.devices.is_empty() {
                let devs_nest = msg.begin_nested(NFTA_FLOWTABLE_HOOK_DEVS);
                for dev in &spec.devices {
                    if let Some(prefix) = dev.strip_suffix('*') {
                        msg.put_str(NFTA_DEVICE_PREFIX, prefix);
                    } else {
                        msg.put_str(NFTA_DEVICE_NAME, dev);
                    }
                }
                msg.end_nested(devs_nest);
            }
            msg.end_nested(hook_nest);
            if spec.flags != 0 {
                msg.put_u32_be(NFTA_FLOWTABLE_FLAGS, spec.flags);
            }
            msg.end_msg(pos);
        })
    }

    fn add_rule(&mut self, cmd: &Command, insert: bool) -> io::Result<()> {
        let family = cmd.family;
        let table = cmd.table.clone();
        let chain = cmd.chain.clone();

        self.sync_anon_set_counter(family, &table)?;
        let prepared = self.prepare_rule(family, &table, cmd)?;

        // Resolve `index N` → handle. nft(8) documents `index` as the
        // 0-based ordinal in the chain. We GETRULE-dump the chain,
        // pull handles in kernel order, and substitute.
        let handle = if cmd.has_rule_index && cmd.rule_index >= 0 {
            let idx = cmd.rule_index as usize;
            let t = table.clone();
            let c = chain.clone();
            let mut handles: Vec<u64> = Vec::new();
            self.dump(
                NFT_MSG_GETRULE,
                family,
                |msg, pos| {
                    msg.put_str(NFTA_RULE_TABLE, &t);
                    msg.put_str(NFTA_RULE_CHAIN, &c);
                    msg.end_msg(pos);
                },
                |mt, _, data| {
                    if mt == NFT_MSG_NEWRULE {
                        let a = parse_attrs(data);
                        if let Some((_, v)) = a.iter().find(|(t, _)| *t == NFTA_RULE_HANDLE) {
                            handles.push(attr_u64_be(v));
                        }
                    }
                },
            )?;
            match handles.get(idx).copied() {
                Some(h) => Some(h),
                None if !insert && idx == handles.len() => None,
                // `index N` where N is past the end: the user asked
                // to anchor onto a rule that doesn't exist. nft(8)
                // rejects this (ERANGE); we mirror that.
                None => {
                    return Err(io::Error::new(
                        io::ErrorKind::InvalidInput,
                        format!(
                            "index {} out of range ({} rules in chain)",
                            idx,
                            handles.len()
                        ),
                    ))
                }
            }
        } else if cmd.has_handle {
            Some(cmd.handle)
        } else {
            None
        };
        let mut flags = NLM_F_CREATE | NLM_F_ACK | if insert { 0 } else { NLM_F_APPEND };
        if self.echo {
            flags |= NLM_F_ECHO;
        }
        let echo = self.echo;

        let table_ref = table.clone();
        self.send_batch(|msg| {
            Self::emit_bound_chains(msg, family, &table_ref, echo, &prepared.bound_chains);
            Self::emit_prepared_rule(
                msg,
                family,
                &table,
                &chain,
                flags,
                handle,
                prepared.comment.as_deref(),
                &prepared.anon_plans,
                &prepared.exprs,
            );
        })
    }

    // ── Delete ──────────────────────────────────────────────────

    fn exec_delete(&mut self, cmd: &Command, destroy: bool) -> io::Result<()> {
        let family = cmd.family;
        match cmd.obj {
            CmdObj::Table => {
                let name = cmd.table.clone();
                let by_handle = cmd.has_handle;
                let handle = cmd.handle;
                // For delete-by-handle: kernel's lookup-by-handle is
                // global (no family check), and upstream nft filters
                // userspace-side. Pre-check the family match so
                // `delete table inet handle $ip_handle` becomes
                // ENOENT. Always run the dump — dumps go over the
                // socket directly and don't care about the pending
                // batch buffer; they see kernel-committed state.
                // destroy always falls through here too (silent
                // success if missing).
                if by_handle {
                    let mut match_found = false;
                    self.dump(
                        NFT_MSG_GETTABLE,
                        family,
                        |_, _| {},
                        |mt, _, data| {
                            if mt != NFT_MSG_NEWTABLE {
                                return;
                            }
                            let a = parse_attrs(data);
                            let h = a
                                .iter()
                                .find(|(t, _)| *t == NFTA_TABLE_HANDLE)
                                .map(|(_, v)| attr_u64_be(v))
                                .unwrap_or(0);
                            if h == handle {
                                match_found = true;
                            }
                        },
                    )?;
                    if !match_found {
                        if destroy {
                            return Ok(());
                        }
                        return Err(io::Error::from_raw_os_error(libc::ENOENT));
                    }
                } else if destroy {
                    let name_s = name.clone();
                    let mut exists = false;
                    self.dump(
                        NFT_MSG_GETTABLE,
                        family,
                        |_, _| {},
                        |mt, _, data| {
                            if mt != NFT_MSG_NEWTABLE {
                                return;
                            }
                            let a = parse_attrs(data);
                            let n = a
                                .iter()
                                .find(|(t, _)| *t == NFTA_TABLE_NAME)
                                .map(|(_, v)| attr_str(v).to_string())
                                .unwrap_or_default();
                            if n == name_s {
                                exists = true;
                            }
                        },
                    )?;
                    if !exists {
                        return Ok(());
                    }
                }
                self.send_batch(|msg| {
                    let pos = msg.begin_msg(NFT_MSG_DELTABLE, family, NLM_F_ACK);
                    if by_handle {
                        msg.put_u64_be(NFTA_TABLE_HANDLE, handle);
                    } else {
                        msg.put_str(NFTA_TABLE_NAME, &name);
                    }
                    msg.end_msg(pos);
                })
            }
            CmdObj::Chain => {
                let table = cmd.table.clone();
                let chain = cmd.chain.clone();
                let by_handle = cmd.has_handle;
                let handle = cmd.handle;
                // `destroy chain` must succeed even when the chain
                // doesn't exist. Some kernels reject
                // NFT_MSG_DESTROYCHAIN outright (observed EINVAL on
                // 6.1 arm64), so we pre-check existence via GETCHAIN
                // and either skip or fall through to DELCHAIN. DEL
                // is used as the wire opcode in both cases so the
                // batch-buffer commit still carries a valid message.
                if destroy {
                    let table_s = table.clone();
                    let chain_s = chain.clone();
                    let mut exists = false;
                    self.dump(
                        NFT_MSG_GETCHAIN,
                        family,
                        |_, _| {},
                        |mt, _, data| {
                            if mt != NFT_MSG_NEWCHAIN {
                                return;
                            }
                            let a = parse_attrs(data);
                            let t = a
                                .iter()
                                .find(|(t, _)| *t == NFTA_CHAIN_TABLE)
                                .map(|(_, v)| attr_str(v).to_string())
                                .unwrap_or_default();
                            if by_handle {
                                let h = a
                                    .iter()
                                    .find(|(t, _)| *t == NFTA_CHAIN_HANDLE)
                                    .map(|(_, v)| attr_u64_be(v))
                                    .unwrap_or(0);
                                if t == table_s && h == handle {
                                    exists = true;
                                }
                            } else {
                                let c = a
                                    .iter()
                                    .find(|(t, _)| *t == NFTA_CHAIN_NAME)
                                    .map(|(_, v)| attr_str(v).to_string())
                                    .unwrap_or_default();
                                if t == table_s && c == chain_s {
                                    exists = true;
                                }
                            }
                        },
                    )?;
                    if !exists {
                        return Ok(());
                    }
                }
                self.send_batch(|msg| {
                    let pos = msg.begin_msg(NFT_MSG_DELCHAIN, family, NLM_F_ACK);
                    msg.put_str(NFTA_CHAIN_TABLE, &table);
                    if by_handle {
                        msg.put_u64_be(NFTA_CHAIN_HANDLE, handle);
                    } else {
                        msg.put_str(NFTA_CHAIN_NAME, &chain);
                    }
                    msg.end_msg(pos);
                })
            }
            CmdObj::Rule => {
                let table = cmd.table.clone();
                let chain = cmd.chain.clone();
                let handle = cmd.handle;
                if destroy {
                    let table_s = table.clone();
                    let chain_s = chain.clone();
                    let mut exists = false;
                    self.dump(
                        NFT_MSG_GETRULE,
                        family,
                        |msg, pos| {
                            msg.put_str(NFTA_RULE_TABLE, &table_s);
                            msg.put_str(NFTA_RULE_CHAIN, &chain_s);
                            msg.end_msg(pos);
                        },
                        |mt, _, data| {
                            if mt != NFT_MSG_NEWRULE {
                                return;
                            }
                            let a = parse_attrs(data);
                            let h = a
                                .iter()
                                .find(|(t, _)| *t == NFTA_RULE_HANDLE)
                                .map(|(_, v)| attr_u64_be(v))
                                .unwrap_or(0);
                            if h == handle {
                                exists = true;
                            }
                        },
                    )?;
                    if !exists {
                        return Ok(());
                    }
                }
                self.send_batch(|msg| {
                    let pos = msg.begin_msg(NFT_MSG_DELRULE, family, NLM_F_ACK);
                    msg.put_str(NFTA_RULE_TABLE, &table);
                    msg.put_str(NFTA_RULE_CHAIN, &chain);
                    msg.put_u64_be(NFTA_RULE_HANDLE, handle);
                    msg.end_msg(pos);
                })
            }
            CmdObj::Set | CmdObj::Map => {
                let table = cmd.table.clone();
                let mut set_name = cmd.set_name.clone();
                let by_handle = cmd.has_handle;
                let handle = cmd.handle;
                let want_map = matches!(cmd.obj, CmdObj::Map);
                if by_handle || destroy {
                    let tn = table.clone();
                    let sn = set_name.clone();
                    let mut exists = false;
                    self.dump(
                        NFT_MSG_GETSET,
                        family,
                        |_, _| {},
                        |mt, _, data| {
                            if mt != NFT_MSG_NEWSET {
                                return;
                            }
                            let a = parse_attrs(data);
                            let t = a
                                .iter()
                                .find(|(t, _)| *t == NFTA_SET_TABLE)
                                .map(|(_, v)| attr_str(v).to_string())
                                .unwrap_or_default();
                            if t != tn {
                                return;
                            }
                            let flags = a
                                .iter()
                                .find(|(t, _)| *t == NFTA_SET_FLAGS)
                                .map(|(_, v)| attr_u32_be(v))
                                .unwrap_or(0);
                            let is_map = flags & NFT_SET_MAP != 0;
                            if is_map != want_map {
                                return;
                            }
                            if by_handle {
                                let h = a
                                    .iter()
                                    .find(|(t, _)| *t == NFTA_SET_HANDLE)
                                    .map(|(_, v)| attr_u64_be(v))
                                    .unwrap_or(0);
                                if h == handle {
                                    exists = true;
                                    set_name = a
                                        .iter()
                                        .find(|(t, _)| *t == NFTA_SET_NAME)
                                        .map(|(_, v)| attr_str(v).to_string())
                                        .unwrap_or_default();
                                }
                            } else {
                                let n = a
                                    .iter()
                                    .find(|(t, _)| *t == NFTA_SET_NAME)
                                    .map(|(_, v)| attr_str(v).to_string())
                                    .unwrap_or_default();
                                if n == sn {
                                    exists = true;
                                }
                            }
                        },
                    )?;
                    if !exists {
                        if destroy {
                            return Ok(());
                        }
                        return Err(io::Error::from_raw_os_error(libc::ENOENT));
                    }
                }
                self.send_batch(|msg| {
                    let pos = msg.begin_msg(NFT_MSG_DELSET, family, NLM_F_ACK);
                    msg.put_str(NFTA_SET_TABLE, &table);
                    if by_handle {
                        msg.put_u64_be(NFTA_SET_HANDLE, handle);
                    } else {
                        msg.put_str(NFTA_SET_NAME, &set_name);
                    }
                    msg.end_msg(pos);
                })
            }
            CmdObj::Element => self.delete_elements(cmd),
            CmdObj::Flowtable => {
                let table = cmd.table.clone();
                let name = cmd.set_name.clone();
                let by_handle = cmd.has_handle;
                let handle = cmd.handle;
                if by_handle || destroy {
                    let tf = table.clone();
                    let nf = name.clone();
                    let mut exists = false;
                    self.dump(
                        NFT_MSG_GETFLOWTABLE,
                        family,
                        |_, _| {},
                        |mt, _, data| {
                            if mt != NFT_MSG_NEWFLOWTABLE {
                                return;
                            }
                            let attrs = parse_attrs(data);
                            let t = attrs
                                .iter()
                                .find(|(t, _)| *t == NFTA_FLOWTABLE_TABLE)
                                .map(|(_, v)| attr_str(v).to_string())
                                .unwrap_or_default();
                            if t != tf {
                                return;
                            }
                            if by_handle {
                                let h = attrs
                                    .iter()
                                    .find(|(t, _)| *t == NFTA_FLOWTABLE_HANDLE)
                                    .map(|(_, v)| attr_u64_be(v))
                                    .unwrap_or(0);
                                if h == handle {
                                    exists = true;
                                }
                            } else {
                                let n = attrs
                                    .iter()
                                    .find(|(t, _)| *t == NFTA_FLOWTABLE_NAME)
                                    .map(|(_, v)| attr_str(v).to_string())
                                    .unwrap_or_default();
                                if n == nf {
                                    exists = true;
                                }
                            }
                        },
                    )?;
                    if !exists {
                        if destroy {
                            return Ok(());
                        }
                        return Err(io::Error::from_raw_os_error(libc::ENOENT));
                    }
                }
                self.send_batch(|msg| {
                    let pos = msg.begin_msg(NFT_MSG_DELFLOWTABLE, family, NLM_F_ACK);
                    msg.put_str(NFTA_FLOWTABLE_TABLE, &table);
                    if by_handle {
                        msg.put_u64_be(NFTA_FLOWTABLE_HANDLE, handle);
                    } else {
                        msg.put_str(NFTA_FLOWTABLE_NAME, &name);
                    }
                    msg.end_msg(pos);
                })
            }
            CmdObj::Counter
            | CmdObj::Quota
            | CmdObj::Limit
            | CmdObj::CtTimeout
            | CmdObj::CtExpectation => {
                // obj_spec.kind may be 0 if the caller said just
                // `delete counter t foo` without a type block; fill it
                // in from the CmdObj so the kernel can disambiguate.
                let mut cmd = cmd.clone();
                if cmd.obj_spec.kind == 0 {
                    cmd.obj_spec.kind = match cmd.obj {
                        CmdObj::Counter => NFT_OBJECT_COUNTER,
                        CmdObj::Quota => NFT_OBJECT_QUOTA,
                        CmdObj::Limit => NFT_OBJECT_LIMIT,
                        CmdObj::CtTimeout => NFT_OBJECT_CT_TIMEOUT,
                        CmdObj::CtExpectation => NFT_OBJECT_CT_EXPECT,
                        _ => 0,
                    };
                }
                if cmd.has_handle || destroy {
                    let table = cmd.table.clone();
                    let name = cmd.set_name.clone();
                    let kind = cmd.obj_spec.kind;
                    let mut exists = false;
                    self.dump(
                        NFT_MSG_GETOBJ,
                        family,
                        |_, _| {},
                        |mt, _, data| {
                            if mt != NFT_MSG_NEWOBJ {
                                return;
                            }
                            let attrs = parse_attrs(data);
                            let t = attrs
                                .iter()
                                .find(|(t, _)| *t == NFTA_OBJ_TABLE)
                                .map(|(_, v)| attr_str(v).to_string())
                                .unwrap_or_default();
                            let k = attrs
                                .iter()
                                .find(|(t, _)| *t == NFTA_OBJ_TYPE)
                                .map(|(_, v)| attr_u32_be(v))
                                .unwrap_or(0);
                            if t != table || k != kind {
                                return;
                            }
                            if cmd.has_handle {
                                let h = attrs
                                    .iter()
                                    .find(|(t, _)| *t == NFTA_OBJ_HANDLE)
                                    .map(|(_, v)| attr_u64_be(v))
                                    .unwrap_or(0);
                                if h == cmd.handle {
                                    exists = true;
                                }
                            } else {
                                let n = attrs
                                    .iter()
                                    .find(|(t, _)| *t == NFTA_OBJ_NAME)
                                    .map(|(_, v)| attr_str(v).to_string())
                                    .unwrap_or_default();
                                if n == name {
                                    exists = true;
                                }
                            }
                        },
                    )?;
                    if !exists {
                        if destroy {
                            return Ok(());
                        }
                        return Err(io::Error::from_raw_os_error(libc::ENOENT));
                    }
                }
                self.delete_object(&cmd)
            }
            _ => Err(io::Error::new(
                io::ErrorKind::Other,
                "unsupported delete target",
            )),
        }
    }

    // ── List ────────────────────────────────────────────────────

    fn exec_list(&mut self, cmd: &Command) -> io::Result<()> {
        if self.json {
            return self.exec_list_json(cmd);
        }
        match cmd.obj {
            CmdObj::Ruleset => self.list_ruleset(cmd.family),
            CmdObj::Tables => self.list_tables(cmd.family),
            CmdObj::Table => self.list_table(cmd.family, &cmd.table),
            CmdObj::Chain => {
                println!("table {} {} {{", family_str(cmd.family), cmd.table);
                self.list_chain_with_rules(cmd.family, &cmd.table, &cmd.chain)?;
                println!("}}");
                Ok(())
            }
            CmdObj::Chains => self.list_chains(cmd.family),
            CmdObj::Sets => self.list_sets(cmd.family),
            CmdObj::Flowtables => self.list_flowtables(cmd.family),
            CmdObj::Set | CmdObj::Map => self.list_named_set(cmd.family, &cmd.table, &cmd.set_name),
            CmdObj::Flowtable => self.list_named_flowtable(cmd.family, &cmd.table, &cmd.set_name),
            CmdObj::Counter
            | CmdObj::Quota
            | CmdObj::Limit
            | CmdObj::CtTimeout
            | CmdObj::CtExpectation => {
                self.list_named_object(cmd.family, &cmd.table, &cmd.set_name)
            }
            CmdObj::Counters | CmdObj::Quotas | CmdObj::Limits => {
                let kind = match cmd.obj {
                    CmdObj::Counters => NFT_OBJECT_COUNTER,
                    CmdObj::Quotas => NFT_OBJECT_QUOTA,
                    CmdObj::Limits => NFT_OBJECT_LIMIT,
                    _ => 0,
                };
                self.list_objects(cmd.family, kind)
            }
            _ => Err(io::Error::new(
                io::ErrorKind::Other,
                "unsupported list target",
            )),
        }
    }

    fn list_named_set(&mut self, family: u8, table: &str, name: &str) -> io::Result<()> {
        let mut found: Vec<(u8, Vec<(u16, Vec<u8>)>)> = Vec::new();
        let tf = table.to_string();
        let nf = name.to_string();
        self.dump(
            NFT_MSG_GETSET,
            family,
            |_, _| {},
            |mt, fam, data| {
                if mt == NFT_MSG_NEWSET {
                    let attrs = parse_attrs(data);
                    let t = attrs
                        .iter()
                        .find(|(t, _)| *t == NFTA_SET_TABLE)
                        .map(|(_, v)| attr_str(v).to_string())
                        .unwrap_or_default();
                    let n = attrs
                        .iter()
                        .find(|(t, _)| *t == NFTA_SET_NAME)
                        .map(|(_, v)| attr_str(v).to_string())
                        .unwrap_or_default();
                    let flags = attrs
                        .iter()
                        .find(|(t, _)| *t == NFTA_SET_FLAGS)
                        .map(|(_, v)| attr_u32_be(v))
                        .unwrap_or(0);
                    // Anonymous sets aren't user-addressable — `nft list
                    // set t __set0` exits non-zero upstream even though
                    // the object is visible to GETSET.
                    if t == tf && n == nf && (flags & 0x1) == 0 {
                        found.push((fam, attrs));
                    }
                }
            },
        )?;
        if found.is_empty() {
            return Err(io::Error::new(
                io::ErrorKind::NotFound,
                format!("no such set {}/{}", table, name),
            ));
        }
        println!("table {} {} {{", family_str(family), table);
        for (fam, attrs) in &found {
            // Dump the set's elements so the body shows `elements =
            // {...}` in text output (terse mode still suppresses via
            // self.terse). print_set_with_elements handles both
            // plain and interval sets with the right framing.
            let sn = attrs
                .iter()
                .find(|(t, _)| *t == NFTA_SET_NAME)
                .map(|(_, v)| attr_str(v).to_string())
                .unwrap_or_default();
            let tbl = table.to_string();
            let mut elems: Vec<Vec<(u16, Vec<u8>)>> = Vec::new();
            self.dump(
                NFT_MSG_GETSETELEM,
                *fam,
                |msg, pos| {
                    msg.put_str(NFTA_SET_ELEM_LIST_TABLE, &tbl);
                    msg.put_str(NFTA_SET_ELEM_LIST_SET, &sn);
                    msg.end_msg(pos);
                },
                |mt, _, data| {
                    if mt == NFT_MSG_NEWSETELEM {
                        let a = parse_attrs(data);
                        if let Some((_, list)) =
                            a.iter().find(|(t, _)| *t == NFTA_SET_ELEM_LIST_ELEMENTS)
                        {
                            for (_, e) in parse_attrs(list) {
                                elems.push(parse_attrs(&e));
                            }
                        }
                    }
                },
            )?;
            let attrs_for_print = if self.show_handles {
                self.get_set_attrs(*fam, table, name)?
                    .unwrap_or_else(|| attrs.clone())
            } else {
                attrs.clone()
            };
            output::print_set_with_elements(
                *fam,
                &attrs_for_print,
                &elems,
                self.show_handles,
                self.terse,
            );
        }
        println!("}}");
        Ok(())
    }

    fn list_named_object(&mut self, family: u8, table: &str, name: &str) -> io::Result<()> {
        let mut found: Vec<Vec<(u16, Vec<u8>)>> = Vec::new();
        let tf = table.to_string();
        let nf = name.to_string();
        self.dump(
            NFT_MSG_GETOBJ,
            family,
            |_, _| {},
            |mt, _, data| {
                if mt == NFT_MSG_NEWOBJ {
                    let attrs = parse_attrs(data);
                    let t = attrs
                        .iter()
                        .find(|(t, _)| *t == NFTA_OBJ_TABLE)
                        .map(|(_, v)| attr_str(v).to_string())
                        .unwrap_or_default();
                    let n = attrs
                        .iter()
                        .find(|(t, _)| *t == NFTA_OBJ_NAME)
                        .map(|(_, v)| attr_str(v).to_string())
                        .unwrap_or_default();
                    if t == tf && n == nf {
                        found.push(attrs);
                    }
                }
            },
        )?;
        if found.is_empty() {
            return Err(io::Error::new(
                io::ErrorKind::NotFound,
                format!("no such object {}/{}", table, name),
            ));
        }
        println!("table {} {} {{", family_str(family), table);
        for attrs in &found {
            let attrs_for_print = if self.show_handles {
                let kind = attrs
                    .iter()
                    .find(|(t, _)| *t == NFTA_OBJ_TYPE)
                    .map(|(_, v)| attr_u32_be(v))
                    .unwrap_or(0);
                self.get_object_attrs(family, table, name, kind)?
                    .unwrap_or_else(|| attrs.clone())
            } else {
                attrs.clone()
            };
            output::print_object(&attrs_for_print, self.show_handles);
        }
        println!("}}");
        Ok(())
    }

    fn list_named_flowtable(&mut self, family: u8, table: &str, name: &str) -> io::Result<()> {
        let mut found: Vec<Vec<(u16, Vec<u8>)>> = Vec::new();
        let tf = table.to_string();
        let nf = name.to_string();
        self.dump(
            NFT_MSG_GETFLOWTABLE,
            family,
            |_, _| {},
            |mt, _, data| {
                if mt == NFT_MSG_NEWFLOWTABLE {
                    let attrs = parse_attrs(data);
                    let t = attrs
                        .iter()
                        .find(|(t, _)| *t == NFTA_FLOWTABLE_TABLE)
                        .map(|(_, v)| attr_str(v).to_string())
                        .unwrap_or_default();
                    let n = attrs
                        .iter()
                        .find(|(t, _)| *t == NFTA_FLOWTABLE_NAME)
                        .map(|(_, v)| attr_str(v).to_string())
                        .unwrap_or_default();
                    if t == tf && n == nf {
                        found.push(attrs);
                    }
                }
            },
        )?;
        if found.is_empty() {
            return Err(io::Error::new(
                io::ErrorKind::NotFound,
                format!("no such flowtable {}/{}", table, name),
            ));
        }
        println!("table {} {} {{", family_str(family), table);
        for attrs in &found {
            let attrs_for_print = if self.show_handles {
                self.get_flowtable_attrs(family, table, name)?
                    .unwrap_or_else(|| attrs.clone())
            } else {
                attrs.clone()
            };
            output::print_flowtable(&attrs_for_print, self.show_handles);
        }
        println!("}}");
        Ok(())
    }

    fn list_objects(&mut self, family: u8, kind: u32) -> io::Result<()> {
        let mut by_table: Vec<(u8, String, Vec<Vec<(u16, Vec<u8>)>>)> = Vec::new();
        let mut tables: Vec<(u8, String)> = Vec::new();
        self.dump(
            NFT_MSG_GETTABLE,
            family,
            |_, _| {},
            |mt, fam, data| {
                if mt == NFT_MSG_NEWTABLE {
                    let a = parse_attrs(data);
                    let n = a
                        .iter()
                        .find(|(t, _)| *t == NFTA_TABLE_NAME)
                        .map(|(_, v)| attr_str(v).to_string())
                        .unwrap_or_default();
                    tables.push((fam, n));
                }
            },
        )?;
        for (fam, tname) in &tables {
            by_table.push((*fam, tname.clone(), Vec::new()));
        }
        self.dump(
            NFT_MSG_GETOBJ,
            family,
            |_, _| {},
            |mt, _, data| {
                if mt == NFT_MSG_NEWOBJ {
                    let attrs = parse_attrs(data);
                    let t = attrs
                        .iter()
                        .find(|(t, _)| *t == NFTA_OBJ_TABLE)
                        .map(|(_, v)| attr_str(v).to_string())
                        .unwrap_or_default();
                    let k = attrs
                        .iter()
                        .find(|(t, _)| *t == NFTA_OBJ_TYPE)
                        .map(|(_, v)| attr_u32_be(v))
                        .unwrap_or(0);
                    if k != kind {
                        return;
                    }
                    if let Some(slot) = by_table.iter_mut().find(|(_, n, _)| n == &t) {
                        slot.2.push(attrs);
                    }
                }
            },
        )?;
        for (fam, tname, objs) in &by_table {
            if objs.is_empty() {
                continue;
            }
            println!("table {} {} {{", family_str(*fam), tname);
            for a in objs {
                let attrs_for_print = if self.show_handles {
                    let name = a
                        .iter()
                        .find(|(t, _)| *t == NFTA_OBJ_NAME)
                        .map(|(_, v)| attr_str(v).to_string())
                        .unwrap_or_default();
                    self.get_object_attrs(*fam, tname, &name, kind)?
                        .unwrap_or_else(|| a.clone())
                } else {
                    a.clone()
                };
                output::print_object(&attrs_for_print, self.show_handles);
            }
            println!("}}");
        }
        Ok(())
    }

    fn exec_list_json(&mut self, cmd: &Command) -> io::Result<()> {
        let mut j = output::JsonOut::begin();
        let sh = self.show_handles;
        let sl = self.stateless;
        match cmd.obj {
            CmdObj::Ruleset | CmdObj::Tables => {
                // Dump all tables first.
                let mut tables: Vec<(u8, Vec<(u16, Vec<u8>)>)> = Vec::new();
                self.dump(
                    NFT_MSG_GETTABLE,
                    cmd.family,
                    |_, _| {},
                    |mt, fam, data| {
                        if mt == NFT_MSG_NEWTABLE {
                            tables.push((fam, parse_attrs(data)));
                        }
                    },
                )?;

                if !matches!(cmd.obj, CmdObj::Ruleset) {
                    // `list tables` — just the tables themselves.
                    for (fam, tattrs) in &tables {
                        j.table(*fam, tattrs);
                    }
                } else {
                    // `list ruleset` — libnftables interleaves per table:
                    //   metainfo, table1, chains of table1, rules of
                    //   chains of table1, table2, chains of table2, ...
                    // Matching that order exactly is what the test
                    // framework's diff requires.
                    for (fam, tattrs) in &tables {
                        let tname = tattrs
                            .iter()
                            .find(|(t, _)| *t == NFTA_TABLE_NAME)
                            .map(|(_, v)| attr_str(v).to_string())
                            .unwrap_or_default();
                        j.table(*fam, tattrs);

                        // Chains of this table.
                        let tn = tname.clone();
                        let mut chains: Vec<Vec<(u16, Vec<u8>)>> = Vec::new();
                        self.dump(
                            NFT_MSG_GETCHAIN,
                            *fam,
                            |_, _| {},
                            |mt, _, data| {
                                if mt == NFT_MSG_NEWCHAIN {
                                    let a = parse_attrs(data);
                                    let t = a
                                        .iter()
                                        .find(|(t, _)| *t == NFTA_CHAIN_TABLE)
                                        .map(|(_, v)| attr_str(v).to_string())
                                        .unwrap_or_default();
                                    if t == tn {
                                        chains.push(a);
                                    }
                                }
                            },
                        )?;

                        for cattrs in &chains {
                            j.chain(*fam, &tname, cattrs);
                        }

                        // Named sets / maps of this table.
                        let tn = tname.clone();
                        let mut sets: Vec<Vec<(u16, Vec<u8>)>> = Vec::new();
                        self.dump(
                            NFT_MSG_GETSET,
                            *fam,
                            |_, _| {},
                            |mt, _, data| {
                                if mt == NFT_MSG_NEWSET {
                                    let a = parse_attrs(data);
                                    let t = a
                                        .iter()
                                        .find(|(t, _)| *t == NFTA_SET_TABLE)
                                        .map(|(_, v)| attr_str(v).to_string())
                                        .unwrap_or_default();
                                    let flags = a
                                        .iter()
                                        .find(|(t, _)| *t == NFTA_SET_FLAGS)
                                        .map(|(_, v)| attr_u32_be(v))
                                        .unwrap_or(0);
                                    // Skip anonymous sets (NFT_SET_ANONYMOUS = 0x1).
                                    if t == tn && (flags & 0x1) == 0 {
                                        sets.push(a);
                                    }
                                }
                            },
                        )?;
                        for sattrs in &sets {
                            let sname = sattrs
                                .iter()
                                .find(|(t, _)| *t == NFTA_SET_NAME)
                                .map(|(_, v)| attr_str(v).to_string())
                                .unwrap_or_default();
                            // `-t` / `--terse` mode — upstream libnftables
                            // skips element enumeration to avoid large
                            // dumps for anti-DDoS sets, etc.
                            let pairs = if self.terse {
                                Vec::new()
                            } else {
                                self.set_element_pairs(*fam, &tname, &sname)?
                            };
                            j.set_pairs(*fam, &tname, sattrs, &pairs);
                        }

                        // Gather anon-set info so rule JSON can inline
                        // `{"set": [...]}` for `__setN` lookups.
                        let anon_reg = self.collect_anon_sets(*fam, &tname)?;

                        // Rules of those chains.
                        for cattrs in &chains {
                            let cname = cattrs
                                .iter()
                                .find(|(t, _)| *t == NFTA_CHAIN_NAME)
                                .map(|(_, v)| attr_str(v).to_string())
                                .unwrap_or_default();
                            let tn2 = tname.clone();
                            let cn2 = cname.clone();
                            let mut rules: Vec<Vec<(u16, Vec<u8>)>> = Vec::new();
                            self.dump(
                                NFT_MSG_GETRULE,
                                *fam,
                                |msg, pos| {
                                    msg.put_str(NFTA_RULE_TABLE, &tn2);
                                    msg.put_str(NFTA_RULE_CHAIN, &cn2);
                                    msg.end_msg(pos);
                                },
                                |mt, _, data| {
                                    if mt == NFT_MSG_NEWRULE {
                                        rules.push(parse_attrs(data));
                                    }
                                },
                            )?;
                            for rattrs in &rules {
                                j.rule_with_sets(*fam, &tname, &cname, rattrs, sh, sl, &anon_reg);
                            }
                        }
                    }
                }
            }
            CmdObj::Table => {
                let name = cmd.table.clone();
                let mut tables: Vec<(u8, Vec<(u16, Vec<u8>)>)> = Vec::new();
                let nf = name.clone();
                self.dump(
                    NFT_MSG_GETTABLE,
                    cmd.family,
                    |_, _| {},
                    |mt, fam, data| {
                        if mt == NFT_MSG_NEWTABLE {
                            let a = parse_attrs(data);
                            let n = a
                                .iter()
                                .find(|(t, _)| *t == NFTA_TABLE_NAME)
                                .map(|(_, v)| attr_str(v).to_string())
                                .unwrap_or_default();
                            if n == nf {
                                tables.push((fam, a));
                            }
                        }
                    },
                )?;
                for (fam, tattrs) in &tables {
                    j.table(*fam, tattrs);
                    let tn = name.clone();
                    let mut chains: Vec<Vec<(u16, Vec<u8>)>> = Vec::new();
                    self.dump(
                        NFT_MSG_GETCHAIN,
                        *fam,
                        |_, _| {},
                        |mt, _, data| {
                            if mt == NFT_MSG_NEWCHAIN {
                                let a = parse_attrs(data);
                                let t = a
                                    .iter()
                                    .find(|(t, _)| *t == NFTA_CHAIN_TABLE)
                                    .map(|(_, v)| attr_str(v).to_string())
                                    .unwrap_or_default();
                                if t == tn {
                                    chains.push(a);
                                }
                            }
                        },
                    )?;
                    // Collect anon sets of this table so rule JSON can
                    // inline `{"set": [...]}` / vmap `[[k, verdict], ...]`.
                    let anon_reg = self.collect_anon_sets(*fam, &name)?;
                    for cattrs in &chains {
                        j.chain(*fam, &name, cattrs);
                        let cname = cattrs
                            .iter()
                            .find(|(t, _)| *t == NFTA_CHAIN_NAME)
                            .map(|(_, v)| attr_str(v).to_string())
                            .unwrap_or_default();
                        let tn2 = name.clone();
                        let cn2 = cname.clone();
                        let mut rules: Vec<Vec<(u16, Vec<u8>)>> = Vec::new();
                        self.dump(
                            NFT_MSG_GETRULE,
                            *fam,
                            |msg, pos| {
                                msg.put_str(NFTA_RULE_TABLE, &tn2);
                                msg.put_str(NFTA_RULE_CHAIN, &cn2);
                                msg.end_msg(pos);
                            },
                            |mt, _, data| {
                                if mt == NFT_MSG_NEWRULE {
                                    rules.push(parse_attrs(data));
                                }
                            },
                        )?;
                        for rattrs in &rules {
                            j.rule_with_sets(*fam, &name, &cname, rattrs, sh, sl, &anon_reg);
                        }
                    }
                }
            }
            CmdObj::Set | CmdObj::Map => {
                // `-j list set|map FAMILY TABLE NAME` — dump just the
                // named set/map plus the enclosing table envelope to
                // match upstream's output.
                let target_table = cmd.table.clone();
                let target_name = cmd.set_name.clone();
                let mut set_attrs: Option<(u8, Vec<(u16, Vec<u8>)>)> = None;
                self.dump(
                    NFT_MSG_GETSET,
                    cmd.family,
                    |_, _| {},
                    |mt, fam, data| {
                        if mt != NFT_MSG_NEWSET {
                            return;
                        }
                        let a = parse_attrs(data);
                        let t = a
                            .iter()
                            .find(|(t, _)| *t == NFTA_SET_TABLE)
                            .map(|(_, v)| attr_str(v).to_string())
                            .unwrap_or_default();
                        let n = a
                            .iter()
                            .find(|(t, _)| *t == NFTA_SET_NAME)
                            .map(|(_, v)| attr_str(v).to_string())
                            .unwrap_or_default();
                        if t == target_table && n == target_name {
                            set_attrs = Some((fam, a));
                        }
                    },
                )?;
                if let Some((fam, sattrs)) = set_attrs {
                    // Emit enclosing table envelope first.
                    let mut tables: Vec<(u8, Vec<(u16, Vec<u8>)>)> = Vec::new();
                    let tn = target_table.clone();
                    self.dump(
                        NFT_MSG_GETTABLE,
                        fam,
                        |_, _| {},
                        |mt, f2, data| {
                            if mt != NFT_MSG_NEWTABLE {
                                return;
                            }
                            let a = parse_attrs(data);
                            let n = a
                                .iter()
                                .find(|(t, _)| *t == NFTA_TABLE_NAME)
                                .map(|(_, v)| attr_str(v).to_string())
                                .unwrap_or_default();
                            if n == tn {
                                tables.push((f2, a));
                            }
                        },
                    )?;
                    for (f, t) in &tables {
                        j.table(*f, t);
                    }
                    let pairs = if self.terse {
                        Vec::new()
                    } else {
                        self.set_element_pairs(fam, &target_table, &target_name)?
                    };
                    j.set_pairs(fam, &target_table, &sattrs, &pairs);
                }
            }
            _ => {} // other object types: just emit envelope
        }
        j.end();
        Ok(())
    }

    fn list_tables(&mut self, family: u8) -> io::Result<()> {
        self.dump(
            NFT_MSG_GETTABLE,
            family,
            |_, _| {},
            |msg_type, fam, data| {
                if msg_type == NFT_MSG_NEWTABLE {
                    let attrs = parse_attrs(data);
                    output::print_table_line(fam, &attrs);
                }
            },
        )
    }

    fn list_chains(&mut self, family: u8) -> io::Result<()> {
        self.dump(
            NFT_MSG_GETCHAIN,
            family,
            |_, _| {},
            |msg_type, fam, data| {
                if msg_type == NFT_MSG_NEWCHAIN {
                    let attrs = parse_attrs(data);
                    let table = attrs
                        .iter()
                        .find(|(t, _)| *t == NFTA_CHAIN_TABLE)
                        .map(|(_, v)| attr_str(v))
                        .unwrap_or("?");
                    let name = attrs
                        .iter()
                        .find(|(t, _)| *t == NFTA_CHAIN_NAME)
                        .map(|(_, v)| attr_str(v))
                        .unwrap_or("?");
                    println!("table {} {} chain {}", family_str(fam), table, name);
                }
            },
        )
    }

    fn list_table(&mut self, family: u8, table: &str) -> io::Result<()> {
        let table_attrs = self.get_table_attrs(family, table)?;
        let table_flags = table_attrs
            .as_ref()
            .and_then(|a| {
                a.iter()
                    .find(|(t, _)| *t == NFTA_TABLE_FLAGS)
                    .map(|(_, v)| attr_u32_be(v))
            })
            .unwrap_or(0);
        if let Some(attrs) = table_attrs.as_ref() {
            output::print_table_header(family, attrs, self.show_handles);
        } else {
            println!("table {} {} {{", family_str(family), table);
        }
        let mut emitted_anything = false;
        if table_flags & NFT_TABLE_F_DORMANT != 0 {
            println!("\tflags dormant");
            emitted_anything = true;
        }

        // Collect chains
        let mut chains: Vec<(u8, Vec<(u16, Vec<u8>)>)> = Vec::new();
        let table_filter = table.to_string();
        self.dump(
            NFT_MSG_GETCHAIN,
            family,
            |_, _| {},
            |msg_type, fam, data| {
                if msg_type == NFT_MSG_NEWCHAIN {
                    let attrs = parse_attrs(data);
                    let t = attrs
                        .iter()
                        .find(|(t, _)| *t == NFTA_CHAIN_TABLE)
                        .map(|(_, v)| attr_str(v).to_string())
                        .unwrap_or_default();
                    if t == table_filter {
                        chains.push((fam, attrs));
                    }
                }
            },
        )?;

        // Collect named stateful objects first, then sets/maps,
        // flowtables, and finally chains — matches upstream `nft list
        // ruleset` ordering.
        let table_filter2 = table.to_string();
        let mut objs: Vec<Vec<(u16, Vec<u8>)>> = Vec::new();
        self.dump(
            NFT_MSG_GETOBJ,
            family,
            |_, _| {},
            |msg_type, _fam, data| {
                if msg_type == NFT_MSG_NEWOBJ {
                    let attrs = parse_attrs(data);
                    let t = attrs
                        .iter()
                        .find(|(t, _)| *t == NFTA_OBJ_TABLE)
                        .map(|(_, v)| attr_str(v).to_string())
                        .unwrap_or_default();
                    if t == table_filter2 {
                        objs.push(attrs);
                    }
                }
            },
        )?;

        let table_filter2 = table.to_string();
        let mut sets: Vec<(u8, Vec<(u16, Vec<u8>)>)> = Vec::new();
        self.dump(
            NFT_MSG_GETSET,
            family,
            |_, _| {},
            |msg_type, fam, data| {
                if msg_type == NFT_MSG_NEWSET {
                    let attrs = parse_attrs(data);
                    let t = attrs
                        .iter()
                        .find(|(t, _)| *t == NFTA_SET_TABLE)
                        .map(|(_, v)| attr_str(v).to_string())
                        .unwrap_or_default();
                    let flags = attrs
                        .iter()
                        .find(|(t, _)| *t == NFTA_SET_FLAGS)
                        .map(|(_, v)| attr_u32_be(v))
                        .unwrap_or(0);
                    // Skip anonymous (kernel-internal) sets in list output.
                    if t == table_filter2 && (flags & 0x1) == 0 {
                        sets.push((fam, attrs));
                    }
                }
            },
        )?;

        let table_filter3 = table.to_string();
        let mut flowtables: Vec<Vec<(u16, Vec<u8>)>> = Vec::new();
        self.dump(
            NFT_MSG_GETFLOWTABLE,
            family,
            |_, _| {},
            |msg_type, _fam, data| {
                if msg_type == NFT_MSG_NEWFLOWTABLE {
                    let attrs = parse_attrs(data);
                    let t = attrs
                        .iter()
                        .find(|(t, _)| *t == NFTA_FLOWTABLE_TABLE)
                        .map(|(_, v)| attr_str(v).to_string())
                        .unwrap_or_default();
                    if t == table_filter3 {
                        flowtables.push(attrs);
                    }
                }
            },
        )?;

        let mut dynset_targets: std::collections::HashSet<String> =
            std::collections::HashSet::new();
        for (_, chain_attrs) in &chains {
            let chain_name = chain_attrs
                .iter()
                .find(|(t, _)| *t == NFTA_CHAIN_NAME)
                .map(|(_, v)| attr_str(v).to_string())
                .unwrap_or_default();
            let tbl = table.to_string();
            let chn = chain_name.clone();
            self.dump(
                NFT_MSG_GETRULE,
                family,
                |msg, pos| {
                    msg.put_str(NFTA_RULE_TABLE, &tbl);
                    msg.put_str(NFTA_RULE_CHAIN, &chn);
                    msg.end_msg(pos);
                },
                |msg_type, _, data| {
                    if msg_type != NFT_MSG_NEWRULE {
                        return;
                    }
                    let attrs = parse_attrs(data);
                    let Some((_, exprs)) = attrs.iter().find(|(t, _)| *t == NFTA_RULE_EXPRESSIONS)
                    else {
                        return;
                    };
                    for (_, eb) in parse_attrs(exprs) {
                        let ea = parse_attrs(&eb);
                        let name = ea
                            .iter()
                            .find(|(t, _)| *t == NFTA_EXPR_NAME)
                            .map(|(_, v)| attr_str(v));
                        if name != Some("dynset") {
                            continue;
                        }
                        let Some((_, d)) = ea.iter().find(|(t, _)| *t == NFTA_EXPR_DATA) else {
                            continue;
                        };
                        let da = parse_attrs(d);
                        if let Some((_, v)) = da.iter().find(|(t, _)| *t == NFTA_DYNSET_SET_NAME) {
                            dynset_targets.insert(attr_str(v).to_string());
                        }
                    }
                },
            )?;
        }

        if emitted_anything
            && (!objs.is_empty()
                || !sets.is_empty()
                || !flowtables.is_empty()
                || !chains.is_empty())
        {
            println!();
        }

        for (i, attrs) in objs.iter().enumerate() {
            if i > 0 {
                println!();
            }
            let attrs_for_print = if self.show_handles {
                let name = attrs
                    .iter()
                    .find(|(t, _)| *t == NFTA_OBJ_NAME)
                    .map(|(_, v)| attr_str(v).to_string())
                    .unwrap_or_default();
                let kind = attrs
                    .iter()
                    .find(|(t, _)| *t == NFTA_OBJ_TYPE)
                    .map(|(_, v)| attr_u32_be(v))
                    .unwrap_or(0);
                self.get_object_attrs(family, table, &name, kind)?
                    .unwrap_or_else(|| attrs.clone())
            } else {
                attrs.clone()
            };
            output::print_object(&attrs_for_print, self.show_handles);
        }

        if !objs.is_empty() && (!sets.is_empty() || !flowtables.is_empty() || !chains.is_empty()) {
            println!();
        }

        for (i, (fam, attrs)) in sets.iter().enumerate() {
            if i > 0 {
                println!();
            }
            let set_name = attrs
                .iter()
                .find(|(t, _)| *t == NFTA_SET_NAME)
                .map(|(_, v)| attr_str(v).to_string())
                .unwrap_or_default();
            let tbl = table.to_string();
            let sn = set_name.clone();
            let mut elems: Vec<Vec<(u16, Vec<u8>)>> = Vec::new();
            self.dump(
                NFT_MSG_GETSETELEM,
                *fam,
                |msg, pos| {
                    msg.put_str(NFTA_SET_ELEM_LIST_TABLE, &tbl);
                    msg.put_str(NFTA_SET_ELEM_LIST_SET, &sn);
                    msg.end_msg(pos);
                },
                |mt, _, data| {
                    if mt == NFT_MSG_NEWSETELEM {
                        let a = parse_attrs(data);
                        if let Some((_, list)) =
                            a.iter().find(|(t, _)| *t == NFTA_SET_ELEM_LIST_ELEMENTS)
                        {
                            for (_, e) in parse_attrs(list) {
                                elems.push(parse_attrs(&e));
                            }
                        }
                    }
                },
            )?;
            // Sort elements by key bytes ascending so hash-set dumps
            // (otherwise returned in kernel-bucket order) display in
            // a stable order that matches upstream's listings.
            let flags = attrs
                .iter()
                .find(|(t, _)| *t == NFTA_SET_FLAGS)
                .map(|(_, v)| attr_u32_be(v))
                .unwrap_or(0);
            if flags & NFT_SET_INTERVAL == 0 {
                elems.sort_by(|a, b| {
                    let ka = a
                        .iter()
                        .find(|(t, _)| *t == NFTA_SET_ELEM_KEY)
                        .and_then(|(_, v)| {
                            parse_attrs(v)
                                .into_iter()
                                .find(|(t, _)| *t == NFTA_DATA_VALUE)
                                .map(|(_, d)| d)
                        })
                        .unwrap_or_default();
                    let kb = b
                        .iter()
                        .find(|(t, _)| *t == NFTA_SET_ELEM_KEY)
                        .and_then(|(_, v)| {
                            parse_attrs(v)
                                .into_iter()
                                .find(|(t, _)| *t == NFTA_DATA_VALUE)
                                .map(|(_, d)| d)
                        })
                        .unwrap_or_default();
                    ka.cmp(&kb)
                });
            }
            let mut attrs_for_print = attrs.clone();
            if dynset_targets.contains(&set_name) {
                if let Some((_, v)) = attrs_for_print
                    .iter_mut()
                    .find(|(t, _)| *t == NFTA_SET_FLAGS)
                {
                    let flags = attr_u32_be(v) | NFT_SET_EVAL;
                    *v = flags.to_be_bytes().to_vec();
                } else {
                    attrs_for_print.push((NFTA_SET_FLAGS, NFT_SET_EVAL.to_be_bytes().to_vec()));
                }
            }
            if self.show_handles {
                if let Some(full_attrs) = self.get_set_attrs(*fam, table, &set_name)? {
                    attrs_for_print = full_attrs;
                    if dynset_targets.contains(&set_name) {
                        if let Some((_, v)) = attrs_for_print
                            .iter_mut()
                            .find(|(t, _)| *t == NFTA_SET_FLAGS)
                        {
                            let flags = attr_u32_be(v) | NFT_SET_EVAL;
                            *v = flags.to_be_bytes().to_vec();
                        } else {
                            attrs_for_print
                                .push((NFTA_SET_FLAGS, NFT_SET_EVAL.to_be_bytes().to_vec()));
                        }
                    }
                }
            }
            output::print_set_with_elements(
                *fam,
                &attrs_for_print,
                &elems,
                self.show_handles,
                self.terse,
            );
        }

        if !sets.is_empty() && (!flowtables.is_empty() || !chains.is_empty()) {
            println!();
        }

        for (i, attrs) in flowtables.iter().enumerate() {
            if i > 0 {
                println!();
            }
            let attrs_for_print = if self.show_handles {
                let name = attrs
                    .iter()
                    .find(|(t, _)| *t == NFTA_FLOWTABLE_NAME)
                    .map(|(_, v)| attr_str(v).to_string())
                    .unwrap_or_default();
                self.get_flowtable_attrs(family, table, &name)?
                    .unwrap_or_else(|| attrs.clone())
            } else {
                attrs.clone()
            };
            output::print_flowtable(&attrs_for_print, self.show_handles);
        }

        if !flowtables.is_empty() && !chains.is_empty() {
            println!();
        }

        // Collect anonymous sets + their elements into a registry so
        // the rule printer can inline `{ a, b, c }` where upstream
        // does, instead of showing `@__set0`.
        let anon_reg = self.collect_anon_sets(family, table)?;
        let mut bound_reg = output::BoundChainRegistry::default();
        for (_, chain_attrs) in &chains {
            let flags = chain_attrs
                .iter()
                .find(|(t, _)| *t == NFTA_CHAIN_FLAGS)
                .map(|(_, v)| attr_u32_be(v))
                .unwrap_or(0);
            if flags & NFT_CHAIN_BINDING == 0 {
                continue;
            }
            let chain_name = chain_attrs
                .iter()
                .find(|(t, _)| *t == NFTA_CHAIN_NAME)
                .map(|(_, v)| attr_str(v).to_string())
                .unwrap_or_default();
            let mut rules: Vec<Vec<(u16, Vec<u8>)>> = Vec::new();
            let tbl = table.to_string();
            let chn = chain_name.clone();
            self.dump(
                NFT_MSG_GETRULE,
                family,
                |msg, pos| {
                    msg.put_str(NFTA_RULE_TABLE, &tbl);
                    msg.put_str(NFTA_RULE_CHAIN, &chn);
                    msg.end_msg(pos);
                },
                |msg_type, _, data| {
                    if msg_type == NFT_MSG_NEWRULE {
                        rules.push(parse_attrs(data));
                    }
                },
            )?;
            bound_reg.chains.insert(chain_name, rules);
        }

        let mut visible_chain_idx = 0usize;
        for (fam, chain_attrs) in chains.iter() {
            let flags = chain_attrs
                .iter()
                .find(|(t, _)| *t == NFTA_CHAIN_FLAGS)
                .map(|(_, v)| attr_u32_be(v))
                .unwrap_or(0);
            if flags & NFT_CHAIN_BINDING != 0 {
                continue;
            }
            if visible_chain_idx > 0 {
                println!();
            }
            visible_chain_idx += 1;
            output::print_chain_header(*fam, chain_attrs, self.show_handles);

            let chain_name = chain_attrs
                .iter()
                .find(|(t, _)| *t == NFTA_CHAIN_NAME)
                .map(|(_, v)| attr_str(v).to_string())
                .unwrap_or_default();
            let sh = self.show_handles;
            let sl = self.stateless;
            let tbl = table.to_string();
            let reg_ref = &anon_reg;
            self.dump(
                NFT_MSG_GETRULE,
                family,
                |msg, pos| {
                    msg.put_str(NFTA_RULE_TABLE, &tbl);
                    msg.put_str(NFTA_RULE_CHAIN, &chain_name);
                    msg.end_msg(pos);
                },
                |msg_type, _, data| {
                    if msg_type == NFT_MSG_NEWRULE {
                        let attrs = parse_attrs(data);
                        output::print_rule_with_sets_bound(&attrs, sh, sl, reg_ref, &bound_reg);
                    }
                },
            )?;

            output::print_chain_footer();
        }

        println!("}}");
        Ok(())
    }

    fn list_chain_with_rules(&mut self, family: u8, table: &str, chain: &str) -> io::Result<()> {
        // Collect the specific chain
        let mut found_attrs: Option<(u8, Vec<(u16, Vec<u8>)>)> = None;
        let table_f = table.to_string();
        let chain_f = chain.to_string();
        self.dump(
            NFT_MSG_GETCHAIN,
            family,
            |_, _| {},
            |msg_type, fam, data| {
                if msg_type == NFT_MSG_NEWCHAIN {
                    let attrs = parse_attrs(data);
                    let t = attrs
                        .iter()
                        .find(|(t, _)| *t == NFTA_CHAIN_TABLE)
                        .map(|(_, v)| attr_str(v).to_string())
                        .unwrap_or_default();
                    let c = attrs
                        .iter()
                        .find(|(t, _)| *t == NFTA_CHAIN_NAME)
                        .map(|(_, v)| attr_str(v).to_string())
                        .unwrap_or_default();
                    if t == table_f && c == chain_f {
                        found_attrs = Some((fam, attrs));
                    }
                }
            },
        )?;

        if let Some((fam, attrs)) = found_attrs {
            output::print_chain_header(fam, &attrs, self.show_handles);

            let sh = self.show_handles;
            let sl = self.stateless;
            let tbl = table.to_string();
            let chn = chain.to_string();
            self.dump(
                NFT_MSG_GETRULE,
                family,
                |msg, pos| {
                    msg.put_str(NFTA_RULE_TABLE, &tbl);
                    msg.put_str(NFTA_RULE_CHAIN, &chn);
                    msg.end_msg(pos);
                },
                |msg_type, _, data| {
                    if msg_type == NFT_MSG_NEWRULE {
                        let attrs = parse_attrs(data);
                        output::print_rule(&attrs, sh, sl);
                    }
                },
            )?;

            output::print_chain_footer();
        }
        Ok(())
    }

    fn list_ruleset(&mut self, family: u8) -> io::Result<()> {
        // Collect tables
        let mut tables: Vec<(u8, String)> = Vec::new();
        self.dump(
            NFT_MSG_GETTABLE,
            family,
            |_, _| {},
            |msg_type, fam, data| {
                if msg_type == NFT_MSG_NEWTABLE {
                    let attrs = parse_attrs(data);
                    let name = attrs
                        .iter()
                        .find(|(t, _)| *t == NFTA_TABLE_NAME)
                        .map(|(_, v)| attr_str(v).to_string())
                        .unwrap_or_default();
                    tables.push((fam, name));
                }
            },
        )?;

        for (fam, name) in tables {
            self.list_table(fam, &name)?;
        }
        Ok(())
    }

    // ── Flush ───────────────────────────────────────────────────

    fn exec_flush(&mut self, cmd: &Command) -> io::Result<()> {
        match cmd.obj {
            CmdObj::Ruleset => self.flush_ruleset(cmd.family),
            CmdObj::Table => self.flush_table(cmd.family, &cmd.table),
            CmdObj::Chain => self.flush_chain(cmd.family, &cmd.table, &cmd.chain),
            CmdObj::Set | CmdObj::Map => {
                // `flush set|map TABLE NAME` — drop every element
                // from the set/map but keep the set itself. Encoded
                // as NFT_MSG_DELSETELEM with just table+set name and
                // no element list (kernel interprets that as "all").
                let table = cmd.table.clone();
                let name = cmd.set_name.clone();
                let fam = cmd.family;
                self.send_batch(|msg| {
                    let pos = msg.begin_msg(NFT_MSG_DELSETELEM, fam, NLM_F_ACK);
                    msg.put_str(NFTA_SET_ELEM_LIST_TABLE, &table);
                    msg.put_str(NFTA_SET_ELEM_LIST_SET, &name);
                    msg.end_msg(pos);
                })
            }
            _ => Err(io::Error::new(
                io::ErrorKind::Other,
                "unsupported flush target",
            )),
        }
    }

    fn flush_table(&mut self, family: u8, table: &str) -> io::Result<()> {
        let tbl = table.to_string();
        self.send_batch(|msg| {
            let pos = msg.begin_msg(NFT_MSG_DELRULE, family, NLM_F_ACK);
            msg.put_str(NFTA_RULE_TABLE, &tbl);
            msg.end_msg(pos);
        })
    }

    fn flush_chain(&mut self, family: u8, table: &str, chain: &str) -> io::Result<()> {
        let tbl = table.to_string();
        let chn = chain.to_string();
        self.send_batch(|msg| {
            let pos = msg.begin_msg(NFT_MSG_DELRULE, family, NLM_F_ACK);
            msg.put_str(NFTA_RULE_TABLE, &tbl);
            msg.put_str(NFTA_RULE_CHAIN, &chn);
            msg.end_msg(pos);
        })
    }

    fn flush_ruleset(&mut self, _family: u8) -> io::Result<()> {
        // Inside an atomic batch GETTABLE won't see tables we
        // just added. Libnftables solves this by emitting one
        // DELTABLE with family NFPROTO_UNSPEC and no name
        // attribute; the kernel interprets that as "wipe every
        // table in every family" and it batches correctly.
        if self.batch.is_some() {
            self.pending_flush_ruleset = true;
        }
        self.send_batch(|msg| {
            let pos = msg.begin_msg(NFT_MSG_DELTABLE, NFPROTO_UNSPEC, NLM_F_ACK);
            msg.end_msg(pos);
        })
    }

    // ── Rename / Replace ────────────────────────────────────────

    fn exec_rename(&mut self, cmd: &Command) -> io::Result<()> {
        if !matches!(cmd.obj, CmdObj::Chain) {
            return Err(io::Error::new(
                io::ErrorKind::Other,
                "rename only supported for chains",
            ));
        }
        // Look up the chain handle
        let family = cmd.family;
        let table_f = cmd.table.clone();
        let chain_f = cmd.chain.clone();
        let mut chain_handle: Option<u64> = None;
        self.dump(
            NFT_MSG_GETCHAIN,
            family,
            |_, _| {},
            |msg_type, _fam, data| {
                if msg_type == NFT_MSG_NEWCHAIN {
                    let attrs = parse_attrs(data);
                    let t = attrs
                        .iter()
                        .find(|(t, _)| *t == NFTA_CHAIN_TABLE)
                        .map(|(_, v)| attr_str(v).to_string())
                        .unwrap_or_default();
                    let c = attrs
                        .iter()
                        .find(|(t, _)| *t == NFTA_CHAIN_NAME)
                        .map(|(_, v)| attr_str(v).to_string())
                        .unwrap_or_default();
                    if t == table_f && c == chain_f {
                        chain_handle = attrs
                            .iter()
                            .find(|(t, _)| *t == NFTA_CHAIN_HANDLE)
                            .map(|(_, v)| attr_u64_be(v));
                    }
                }
            },
        )?;
        let handle = chain_handle.ok_or_else(|| {
            io::Error::new(
                io::ErrorKind::NotFound,
                format!("chain '{}' not found", cmd.chain),
            )
        })?;

        let table = cmd.table.clone();
        let new_name = cmd.new_name.clone();
        self.send_batch(|msg| {
            let pos = msg.begin_msg(NFT_MSG_NEWCHAIN, family, NLM_F_ACK);
            msg.put_str(NFTA_CHAIN_TABLE, &table);
            msg.put_u64_be(NFTA_CHAIN_HANDLE, handle);
            msg.put_str(NFTA_CHAIN_NAME, &new_name);
            msg.end_msg(pos);
        })
    }

    fn exec_replace(&mut self, cmd: &Command) -> io::Result<()> {
        if !cmd.has_handle {
            return Err(io::Error::new(
                io::ErrorKind::Other,
                "replace requires handle",
            ));
        }
        // Atomic replace uses a single NEWRULE message with NLM_F_REPLACE
        // and carries the target rule's existing handle in NFTA_RULE_HANDLE
        // (not NFTA_RULE_POSITION, which is used as an anchor for insert).
        // Delete-then-add would not be atomic and would move the rule to
        // the end of the chain.
        let family = cmd.family;
        let table = cmd.table.clone();
        let chain = cmd.chain.clone();
        let handle = cmd.handle;
        // Lower any anon-set literals (`replace rule handle N ... { a, b }`)
        // into NEWSET+NEWSETELEM preambles ahead of the replace.
        self.sync_anon_set_counter(family, &table)?;
        let (exprs, anon_plans) = self.lower_anon_sets(&cmd.exprs);
        let exprs =
            self.rewrite_concat_lookup_regs(self.resolve_pending_lookup_ids(family, &table, exprs));
        let comment = if cmd.has_comment {
            Some(cmd.comment.clone())
        } else {
            None
        };
        let table_ref = table.clone();
        self.send_batch(|msg| {
            Self::emit_anon_sets(msg, family, &table_ref, &anon_plans);
            let pos = msg.begin_msg(NFT_MSG_NEWRULE, family, NLM_F_REPLACE | NLM_F_ACK);
            msg.put_str(NFTA_RULE_TABLE, &table);
            msg.put_str(NFTA_RULE_CHAIN, &chain);
            msg.put_u64_be(NFTA_RULE_HANDLE, handle);
            if let Some(ref c) = comment {
                let cb = c.as_bytes();
                let mut tlv = Vec::with_capacity(cb.len() + 3);
                tlv.push(0u8);
                tlv.push((cb.len() + 1) as u8);
                tlv.extend_from_slice(cb);
                tlv.push(0u8);
                msg.put_bytes(NFTA_RULE_USERDATA, &tlv);
            }
            let exprs_nest = msg.begin_nested(NFTA_RULE_EXPRESSIONS);
            for expr in &exprs {
                compile_expr(msg, expr);
            }
            msg.end_nested(exprs_nest);
            msg.end_msg(pos);
        })
    }

    // ── Sets ────────────────────────────────────────────────────

    fn add_set(&mut self, cmd: &Command) -> io::Result<()> {
        let family = cmd.family;
        let table = cmd.table.clone();
        let set_name = cmd.set_name.clone();
        let spec = cmd.set_spec.clone();
        self.anon_set_counter = self.anon_set_counter.wrapping_add(1);
        let set_id = self.anon_set_counter;
        if spec.flags & NFT_SET_INTERVAL != 0 {
            self.pending_interval_sets
                .insert((family, table.clone(), set_name.clone()));
        }
        if self.batch.is_some() {
            self.pending_named_sets.insert(
                (family, table.clone(), set_name.clone()),
                PendingSetInfo {
                    set_id,
                    key_len: spec.key_len,
                    key_type: spec.key_type,
                },
            );
        }
        let excl = matches!(cmd.op, CmdOp::Create);
        self.send_batch(move |msg| {
            let mut flags_nlm = NLM_F_CREATE | NLM_F_ACK;
            if excl {
                flags_nlm |= NLM_F_EXCL;
            }
            let pos = msg.begin_msg(NFT_MSG_NEWSET, family, flags_nlm);
            msg.put_str(NFTA_SET_TABLE, &table);
            msg.put_str(NFTA_SET_NAME, &set_name);
            msg.put_u32_be(NFTA_SET_KEY_TYPE, spec.key_type);
            msg.put_u32_be(NFTA_SET_KEY_LEN, spec.key_len);
            let mut flags = spec.flags;
            if spec.is_map {
                flags |= NFT_SET_MAP;
            }
            if spec.key_field_types.len() > 1 {
                flags |= NFT_SET_CONCAT;
            }
            if flags != 0 {
                msg.put_u32_be(NFTA_SET_FLAGS, flags);
            }
            if spec.has_size || spec.key_field_types.len() > 1 {
                let desc = msg.begin_nested(NFTA_SET_DESC);
                if spec.has_size {
                    msg.put_u32_be(NFTA_SET_DESC_SIZE, spec.size);
                }
                if spec.key_field_types.len() > 1 {
                    let concat = msg.begin_nested(NFTA_SET_DESC_CONCAT);
                    for field_len in &spec.key_field_lens {
                        let elem = msg.begin_nested(NFTA_LIST_ELEM);
                        msg.put_u32_be(NFTA_SET_FIELD_LEN, *field_len as u32);
                        msg.end_nested(elem);
                    }
                    msg.end_nested(concat);
                }
                msg.end_nested(desc);
            }
            if spec.is_map && spec.data_type > 0 {
                msg.put_u32_be(NFTA_SET_DATA_TYPE, spec.data_type);
                msg.put_u32_be(NFTA_SET_DATA_LEN, spec.data_len);
            }
            let mut userdata: Vec<u8> = Vec::new();
            if spec.key_is_typeof {
                userdata.push(Self::SET_UDATA_KEY_TYPEOF);
                userdata.push(spec.key_type_name.len() as u8);
                userdata.extend_from_slice(spec.key_type_name.as_bytes());
            }
            if spec.data_is_typeof {
                userdata.push(Self::SET_UDATA_DATA_TYPEOF);
                userdata.push(spec.data_type_name.len() as u8);
                userdata.extend_from_slice(spec.data_type_name.as_bytes());
            }
            if spec.auto_merge {
                userdata.push(Self::SET_UDATA_AUTO_MERGE);
                userdata.push(1);
                userdata.push(1);
            }
            if !userdata.is_empty() {
                msg.put_bytes(NFTA_SET_USERDATA, &userdata);
            }
            msg.put_u32_be(NFTA_SET_ID, set_id);
            msg.end_msg(pos);
        })
    }

    fn list_sets(&mut self, family: u8) -> io::Result<()> {
        // `list sets` groups output by containing table, to mirror
        // what real nft does — `table ip nat { set ssh { ... } }`.
        // Collect all sets, group by (family, table), then emit.
        let mut all: Vec<(u8, String, Vec<(u16, Vec<u8>)>)> = Vec::new();
        self.dump(
            NFT_MSG_GETSET,
            family,
            |_, _| {},
            |msg_type, fam, data| {
                if msg_type == NFT_MSG_NEWSET {
                    let attrs = parse_attrs(data);
                    let tname = attrs
                        .iter()
                        .find(|(t, _)| *t == NFTA_SET_TABLE)
                        .map(|(_, v)| attr_str(v).to_string())
                        .unwrap_or_default();
                    all.push((fam, tname, attrs));
                }
            },
        )?;

        // Also enumerate tables so we can emit empty tables too when
        // they exist but have no sets. Upstream does this.
        let mut tables: Vec<(u8, String)> = Vec::new();
        self.dump(
            NFT_MSG_GETTABLE,
            family,
            |_, _| {},
            |mt, fam, data| {
                if mt == NFT_MSG_NEWTABLE {
                    let a = parse_attrs(data);
                    let n = a
                        .iter()
                        .find(|(t, _)| *t == NFTA_TABLE_NAME)
                        .map(|(_, v)| attr_str(v).to_string())
                        .unwrap_or_default();
                    tables.push((fam, n));
                }
            },
        )?;

        for (fam, tname) in &tables {
            println!("table {} {} {{", family_str(*fam), tname);
            for (sfam, stable, sattrs) in &all {
                if *sfam == *fam && stable == tname {
                    let attrs_for_print = if self.show_handles {
                        let name = sattrs
                            .iter()
                            .find(|(t, _)| *t == NFTA_SET_NAME)
                            .map(|(_, v)| attr_str(v).to_string())
                            .unwrap_or_default();
                        self.get_set_attrs(*sfam, tname, &name)?
                            .unwrap_or_else(|| sattrs.clone())
                    } else {
                        sattrs.clone()
                    };
                    output::print_set_header(*sfam, &attrs_for_print, self.show_handles);
                }
            }
            println!("}}");
        }
        Ok(())
    }

    fn list_flowtables(&mut self, family: u8) -> io::Result<()> {
        let mut all: Vec<(u8, String, Vec<(u16, Vec<u8>)>)> = Vec::new();
        self.dump(
            NFT_MSG_GETFLOWTABLE,
            family,
            |_, _| {},
            |msg_type, fam, data| {
                if msg_type == NFT_MSG_NEWFLOWTABLE {
                    let attrs = parse_attrs(data);
                    let tname = attrs
                        .iter()
                        .find(|(t, _)| *t == NFTA_FLOWTABLE_TABLE)
                        .map(|(_, v)| attr_str(v).to_string())
                        .unwrap_or_default();
                    all.push((fam, tname, attrs));
                }
            },
        )?;

        let mut tables: Vec<(u8, String)> = Vec::new();
        self.dump(
            NFT_MSG_GETTABLE,
            family,
            |_, _| {},
            |mt, fam, data| {
                if mt == NFT_MSG_NEWTABLE {
                    let a = parse_attrs(data);
                    let n = a
                        .iter()
                        .find(|(t, _)| *t == NFTA_TABLE_NAME)
                        .map(|(_, v)| attr_str(v).to_string())
                        .unwrap_or_default();
                    tables.push((fam, n));
                }
            },
        )?;

        for (fam, tname) in &tables {
            println!("table {} {} {{", family_str(*fam), tname);
            for (ffam, ftable, fattrs) in &all {
                if *ffam == *fam && ftable == tname {
                    let attrs_for_print = if self.show_handles {
                        let name = fattrs
                            .iter()
                            .find(|(t, _)| *t == NFTA_FLOWTABLE_NAME)
                            .map(|(_, v)| attr_str(v).to_string())
                            .unwrap_or_default();
                        self.get_flowtable_attrs(*ffam, tname, &name)?
                            .unwrap_or_else(|| fattrs.clone())
                    } else {
                        fattrs.clone()
                    };
                    output::print_flowtable(&attrs_for_print, self.show_handles);
                }
            }
            println!("}}");
        }
        Ok(())
    }

    // ── Named stateful objects (counter / quota / limit) ──────
    //
    // Kernel UAPI: NFT_MSG_NEWOBJ carries NFTA_OBJ_TABLE / NAME /
    // TYPE, plus a nested NFTA_OBJ_DATA whose attribute namespace is
    // type-specific (shared with the in-rule expressions where
    // applicable — counter uses the same NFTA_COUNTER_* constants).

    fn add_object(&mut self, cmd: &Command) -> io::Result<()> {
        let family = cmd.family;
        let table = cmd.table.clone();
        let name = cmd.set_name.clone();
        let spec = cmd.obj_spec.clone();
        if spec.kind == NFT_OBJECT_CT_TIMEOUT {
            if spec.ct_l4proto == 0 {
                return Err(io::Error::new(
                    io::ErrorKind::InvalidInput,
                    "ct timeout object requires protocol",
                ));
            }
            for (state, _) in &spec.ct_timeout_policy {
                if ct_timeout_state_attr(spec.ct_l4proto, state).is_none() {
                    return Err(io::Error::new(
                        io::ErrorKind::InvalidInput,
                        format!("unknown ct timeout state '{}'", state),
                    ));
                }
            }
        }
        self.send_batch(|msg| {
            let pos = msg.begin_msg(NFT_MSG_NEWOBJ, family, NLM_F_CREATE | NLM_F_ACK);
            msg.put_str(NFTA_OBJ_TABLE, &table);
            msg.put_str(NFTA_OBJ_NAME, &name);
            msg.put_u32_be(NFTA_OBJ_TYPE, spec.kind);
            let data = msg.begin_nested(NFTA_OBJ_DATA);
            match spec.kind {
                NFT_OBJECT_COUNTER => {
                    msg.put_u64_be(NFTA_COUNTER_PACKETS, spec.packets);
                    msg.put_u64_be(NFTA_COUNTER_BYTES, spec.bytes);
                }
                NFT_OBJECT_QUOTA => {
                    msg.put_u64_be(NFTA_QUOTA_BYTES, spec.bytes);
                    msg.put_u32_be(NFTA_QUOTA_FLAGS, spec.quota_flags);
                }
                NFT_OBJECT_LIMIT => {
                    msg.put_u64_be(NFTA_LIMIT_RATE, spec.limit_rate);
                    msg.put_u64_be(
                        NFTA_LIMIT_UNIT,
                        if spec.limit_unit == 0 {
                            1
                        } else {
                            spec.limit_unit
                        },
                    );
                    msg.put_u32_be(NFTA_LIMIT_BURST, spec.limit_burst);
                    msg.put_u32_be(NFTA_LIMIT_TYPE, spec.limit_type);
                    msg.put_u32_be(NFTA_LIMIT_FLAGS, spec.limit_flags);
                }
                NFT_OBJECT_CT_TIMEOUT => {
                    msg.put_u8(NFTA_CT_TIMEOUT_L4PROTO, spec.ct_l4proto);
                    if spec.ct_l3proto != 0 {
                        msg.put_u16_be(NFTA_CT_TIMEOUT_L3PROTO, spec.ct_l3proto);
                    }
                    let policy = msg.begin_nested(NFTA_CT_TIMEOUT_DATA);
                    for (state, secs) in &spec.ct_timeout_policy {
                        if let Some(attr) = ct_timeout_state_attr(spec.ct_l4proto, state) {
                            msg.put_u32_be(attr, *secs);
                        }
                    }
                    msg.end_nested(policy);
                }
                NFT_OBJECT_CT_EXPECT => {
                    if spec.ct_l3proto != 0 {
                        msg.put_u16_be(NFTA_CT_EXPECT_L3PROTO, spec.ct_l3proto);
                    }
                    msg.put_u8(NFTA_CT_EXPECT_L4PROTO, spec.ct_l4proto);
                    msg.put_u16_be(NFTA_CT_EXPECT_DPORT, spec.ct_expect_dport);
                    msg.put_u32(NFTA_CT_EXPECT_TIMEOUT, spec.ct_expect_timeout_ms);
                    msg.put_u8(NFTA_CT_EXPECT_SIZE, spec.ct_expect_size);
                }
                _ => {}
            }
            msg.end_nested(data);
            msg.end_msg(pos);
        })
    }

    fn delete_object(&mut self, cmd: &Command) -> io::Result<()> {
        let family = cmd.family;
        let table = cmd.table.clone();
        let name = cmd.set_name.clone();
        let kind = cmd.obj_spec.kind;
        let by_handle = cmd.has_handle;
        let handle = cmd.handle;
        self.send_batch(|msg| {
            let pos = msg.begin_msg(NFT_MSG_DELOBJ, family, NLM_F_ACK);
            msg.put_str(NFTA_OBJ_TABLE, &table);
            if by_handle {
                msg.put_u64_be(NFTA_OBJ_HANDLE, handle);
            } else {
                msg.put_str(NFTA_OBJ_NAME, &name);
            }
            msg.put_u32_be(NFTA_OBJ_TYPE, kind);
            msg.end_msg(pos);
        })
    }

    // ── Elements ───────────────────────────────────────────────

    fn add_elements(&mut self, cmd: &Command) -> io::Result<()> {
        let family = cmd.family;
        let table = cmd.table.clone();
        let set_name = cmd.set_name.clone();
        let pending_info = self
            .pending_named_sets
            .get(&(family, table.clone(), set_name.clone()))
            .copied();
        let key_len = pending_info.map(|info| info.key_len).unwrap_or_else(|| {
            self.probe_set_key_len(family, &table, &set_name)
                .unwrap_or(0)
        }) as usize;
        let normalized_elements: Vec<(Vec<u8>, Option<Vec<u8>>)> = cmd
            .elements
            .iter()
            .map(|(k, e)| {
                let key = normalize_elem_key(k, key_len);
                let end = e.as_ref().map(|x| normalize_elem_key(x, key_len));
                (key, end)
            })
            .collect();

        // Find out whether the target set is interval-flagged; if so, a
        // bare element `a` must be expanded to the range [a, a] so the
        // kernel's two-record INTERVAL_END encoding is correctly laid
        // down. Without this expansion, bare elements in an interval
        // set fail with EINVAL.
        // Check in-batch NEWSET first (kernel GETSET dump won't see
        // a set we just enqueued in the same transaction).
        let interval_flag =
            if self
                .pending_interval_sets
                .contains(&(family, table.clone(), set_name.clone()))
            {
                true
            } else {
                self.probe_set_is_interval(family, &table, &set_name)?
            };

        // Interval-set backends (rbtree/pipapo) return EEXIST when an
        // identical element is re-added even without NLM_F_EXCL —
        // that breaks `-f` round-trips where the save file already
        // contains every live element. Pre-dump what's there and
        // drop duplicates from this add. Non-interval sets tolerate
        // re-adds natively, so the filter is skipped for them.
        // `create element` (vs plain `add`) wants the EEXIST to
        // surface, so skip the dedupe in that case.
        let is_create = matches!(cmd.op, CmdOp::Create);
        let existing: Vec<Vec<u8>> = if self.pending_flush_ruleset {
            Vec::new()
        } else if interval_flag && !is_create {
            self.set_element_keys(family, &table, &set_name)
                .unwrap_or_default()
        } else {
            Vec::new()
        };

        let elements: Vec<(Vec<u8>, Option<Vec<u8>>)> = normalized_elements
            .iter()
            .filter(|(k, _)| !existing.iter().any(|e| e == k))
            .map(|(k, e)| {
                if e.is_none() && interval_flag {
                    (k.clone(), Some(k.clone()))
                } else {
                    (k.clone(), e.clone())
                }
            })
            .collect();

        if elements.is_empty() {
            return Ok(());
        }

        // Parallel verdict list (empty when target isn't a vmap).
        // Index-align with `elements` after the `existing` filter so
        // we emit the right verdict for each surviving key.
        let verdicts: Vec<Option<(i32, String)>> = if cmd.element_verdicts.is_empty() {
            vec![None; cmd.elements.len()]
        } else {
            cmd.elements
                .iter()
                .enumerate()
                .map(|(i, _)| {
                    // Data-valued maps use the placeholder `(0, "")` to
                    // keep `element_verdicts` aligned with `element_datas`.
                    // Preserve the real `drop` verdict (also code 0) when
                    // there's no parallel data payload.
                    let has_data = cmd.element_datas.get(i).and_then(|d| d.as_ref()).is_some();
                    match cmd.element_verdicts.get(i).cloned() {
                        Some((0, chain)) if chain.is_empty() && has_data => None,
                        Some(v) => Some(v),
                        None => None,
                    }
                })
                .collect()
        };
        // Parallel data list for data-valued maps (ipv4->ipv4 etc.).
        let datas: Vec<Option<Vec<u8>>> = if cmd.element_datas.is_empty() {
            vec![None; cmd.elements.len()]
        } else {
            cmd.elements
                .iter()
                .enumerate()
                .map(|(i, _)| cmd.element_datas.get(i).cloned().flatten())
                .collect()
        };
        let exprs: Vec<Vec<Expr>> = if cmd.element_exprs.is_empty() {
            vec![Vec::new(); cmd.elements.len()]
        } else {
            cmd.elements
                .iter()
                .enumerate()
                .map(|(i, _)| cmd.element_exprs.get(i).cloned().unwrap_or_default())
                .collect()
        };
        // Drop verdicts/datas whose key got filtered out above.
        let kept: Vec<(Option<(i32, String)>, Option<Vec<u8>>, Vec<Expr>)> = normalized_elements
            .iter()
            .zip(verdicts.iter().zip(datas.iter().zip(exprs.iter())))
            .filter(|((k, _), _)| !existing.iter().any(|e| e == k))
            .map(|(_, (v, (d, exprs)))| (v.clone(), d.clone(), exprs.clone()))
            .collect();

        let excl = matches!(cmd.op, CmdOp::Create);
        self.send_batch(move |msg| {
            let mut flags_nlm = NLM_F_CREATE | NLM_F_ACK;
            if excl {
                flags_nlm |= NLM_F_EXCL;
            }
            let pos = msg.begin_msg(NFT_MSG_NEWSETELEM, family, flags_nlm);
            msg.put_str(NFTA_SET_ELEM_LIST_TABLE, &table);
            msg.put_str(NFTA_SET_ELEM_LIST_SET, &set_name);
            if let Some(info) = pending_info {
                msg.put_u32_be(NFTA_SET_ELEM_LIST_SET_ID, info.set_id);
            }
            let elems_nest = msg.begin_nested(NFTA_SET_ELEM_LIST_ELEMENTS);
            for (i, (key, range_end)) in elements.iter().enumerate() {
                let elem = msg.begin_nested(NFTA_LIST_ELEM);
                msg.put_data_value(NFTA_SET_ELEM_KEY, key);
                let (maybe_verdict, maybe_data, exprs) =
                    kept.get(i).cloned().unwrap_or((None, None, Vec::new()));
                if let Some((code, chain)) = maybe_verdict {
                    let d = msg.begin_nested(NFTA_SET_ELEM_DATA);
                    let vd = msg.begin_nested(NFTA_DATA_VERDICT);
                    msg.put_u32_be(NFTA_VERDICT_CODE, code as u32);
                    if !chain.is_empty() {
                        msg.put_str(NFTA_VERDICT_CHAIN, &chain);
                    }
                    msg.end_nested(vd);
                    msg.end_nested(d);
                } else if let Some(bytes) = maybe_data {
                    // NFTA_SET_ELEM_DATA nests NFTA_DATA_VALUE for
                    // non-verdict mapping values (ipv4/integer/ifname).
                    msg.put_data_value(NFTA_SET_ELEM_DATA, &bytes);
                }
                match exprs.as_slice() {
                    [expr] => {
                        let attr = msg.begin_nested(NFTA_SET_ELEM_EXPR);
                        compile_set_elem_expr(msg, expr);
                        msg.end_nested(attr);
                    }
                    [] => {}
                    _ => {
                        let attr = msg.begin_nested(NFTA_SET_ELEM_EXPRESSIONS);
                        for expr in &exprs {
                            let list_elem = msg.begin_nested(NFTA_LIST_ELEM);
                            compile_set_elem_expr(msg, expr);
                            msg.end_nested(list_elem);
                        }
                        msg.end_nested(attr);
                    }
                }
                msg.end_nested(elem);
                if let Some(end) = range_end {
                    let mut end_plus = end.clone();
                    for byte in end_plus.iter_mut().rev() {
                        if *byte == 0xff {
                            *byte = 0;
                        } else {
                            *byte += 1;
                            break;
                        }
                    }
                    let elem2 = msg.begin_nested(NFTA_LIST_ELEM);
                    msg.put_data_value(NFTA_SET_ELEM_KEY, &end_plus);
                    msg.put_u32_be(NFTA_SET_ELEM_FLAGS, NFT_SET_ELEM_INTERVAL_END);
                    msg.end_nested(elem2);
                }
            }
            msg.end_nested(elems_nest);
            msg.end_msg(pos);
        })
    }

    // Dump every element of (family, table, set) and return the raw
    // NFTA_DATA_VALUE bytes of each NFTA_SET_ELEM_KEY. Elements marked
    // with NFT_SET_ELEM_INTERVAL_END are skipped — they're the
    // kernel's end-sentinel for interval sets, not a user-visible
    // member. Used by list_json to fill the `"elem": [...]` array.
    // Walk every set in this table and build the output::AnonSetRegistry
    // a rule printer needs to inline `@__setN` lookups. We include named
    // sets too so `ip saddr @named` can also resolve — but anon sets are
    // the ones that actually need the inline rewrite; named sets stay as
    // `@name` (the rule printer checks the `__set` prefix before inlining).
    fn collect_anon_sets(
        &mut self,
        family: u8,
        table: &str,
    ) -> io::Result<output::AnonSetRegistry> {
        let tbl = table.to_string();
        let mut sets: Vec<Vec<(u16, Vec<u8>)>> = Vec::new();
        self.dump(
            NFT_MSG_GETSET,
            family,
            |_, _| {},
            |mt, _, data| {
                if mt != NFT_MSG_NEWSET {
                    return;
                }
                let a = parse_attrs(data);
                let t = a
                    .iter()
                    .find(|(t, _)| *t == NFTA_SET_TABLE)
                    .map(|(_, v)| attr_str(v).to_string())
                    .unwrap_or_default();
                if t == tbl {
                    sets.push(a);
                }
            },
        )?;

        let mut reg = output::AnonSetRegistry::default();
        for attrs in &sets {
            let name = attrs
                .iter()
                .find(|(t, _)| *t == NFTA_SET_NAME)
                .map(|(_, v)| attr_str(v).to_string())
                .unwrap_or_default();
            let key_type = attrs
                .iter()
                .find(|(t, _)| *t == NFTA_SET_KEY_TYPE)
                .map(|(_, v)| attr_u32_be(v))
                .unwrap_or(0);
            let key_len = attrs
                .iter()
                .find(|(t, _)| *t == NFTA_SET_KEY_LEN)
                .map(|(_, v)| attr_u32_be(v))
                .unwrap_or(0);
            let data_type = attrs
                .iter()
                .find(|(t, _)| *t == NFTA_SET_DATA_TYPE)
                .map(|(_, v)| attr_u32_be(v))
                .unwrap_or(0);
            let data_len = attrs
                .iter()
                .find(|(t, _)| *t == NFTA_SET_DATA_LEN)
                .map(|(_, v)| attr_u32_be(v))
                .unwrap_or(0);
            let flags = attrs
                .iter()
                .find(|(t, _)| *t == NFTA_SET_FLAGS)
                .map(|(_, v)| attr_u32_be(v))
                .unwrap_or(0);
            let is_interval = flags & NFT_SET_INTERVAL != 0;
            let is_map = flags & NFT_SET_MAP != 0;

            let tn = tbl.clone();
            let sn = name.clone();
            let mut raw: Vec<(
                Vec<u8>,
                Option<Vec<u8>>,
                bool,
                Option<(i32, String)>,
                Option<Vec<u8>>,
            )> = Vec::new();
            self.dump(
                NFT_MSG_GETSETELEM,
                family,
                |msg, pos| {
                    msg.put_str(NFTA_SET_ELEM_LIST_TABLE, &tn);
                    msg.put_str(NFTA_SET_ELEM_LIST_SET, &sn);
                    msg.end_msg(pos);
                },
                |mt, _, data| {
                    if mt != NFT_MSG_NEWSETELEM {
                        return;
                    }
                    let a = parse_attrs(data);
                    if let Some((_, list)) =
                        a.iter().find(|(t, _)| *t == NFTA_SET_ELEM_LIST_ELEMENTS)
                    {
                        for (_, eb) in parse_attrs(list) {
                            let ea = parse_attrs(&eb);
                            let eflags = ea
                                .iter()
                                .find(|(t, _)| *t == NFTA_SET_ELEM_FLAGS)
                                .map(|(_, v)| attr_u32_be(v))
                                .unwrap_or(0);
                            // For vmaps the element's NFTA_SET_ELEM_DATA wraps a
                            // NFTA_DATA_VERDICT with CODE (and optionally CHAIN).
                            let vdict = ea.iter().find(|(t, _)| *t == NFTA_SET_ELEM_DATA).and_then(
                                |(_, d)| {
                                    let inner = parse_attrs(d);
                                    inner.iter().find(|(t, _)| *t == NFTA_DATA_VERDICT).map(
                                        |(_, vd)| {
                                            let v = parse_attrs(vd);
                                            let code = v
                                                .iter()
                                                .find(|(t, _)| *t == NFTA_VERDICT_CODE)
                                                .map(|(_, x)| attr_u32_be(x) as i32)
                                                .unwrap_or(0);
                                            let chain = v
                                                .iter()
                                                .find(|(t, _)| *t == NFTA_VERDICT_CHAIN)
                                                .map(|(_, x)| attr_str(x).to_string())
                                                .unwrap_or_default();
                                            (code, chain)
                                        },
                                    )
                                },
                            );
                            let data_value = ea
                                .iter()
                                .find(|(t, _)| *t == NFTA_SET_ELEM_DATA)
                                .and_then(|(_, d)| {
                                    let inner = parse_attrs(d);
                                    inner
                                        .iter()
                                        .find(|(t, _)| *t == NFTA_DATA_VALUE)
                                        .map(|(_, dv)| dv.clone())
                                });
                            if let Some((_, k)) = ea.iter().find(|(t, _)| *t == NFTA_SET_ELEM_KEY) {
                                let inner = parse_attrs(k);
                                if let Some((_, d)) =
                                    inner.iter().find(|(t, _)| *t == NFTA_DATA_VALUE)
                                {
                                    let key_end = ea
                                        .iter()
                                        .find(|(t, _)| *t == NFTA_SET_ELEM_KEY_END)
                                        .and_then(|(_, end_attr)| {
                                            let end_inner = parse_attrs(end_attr);
                                            end_inner
                                                .iter()
                                                .find(|(t, _)| *t == NFTA_DATA_VALUE)
                                                .map(|(_, end_data)| end_data.clone())
                                        });
                                    let is_end = eflags & NFT_SET_ELEM_INTERVAL_END != 0;
                                    raw.push((d.clone(), key_end, is_end, vdict, data_value));
                                }
                            }
                        }
                    }
                },
            )?;

            // For interval sets the kernel stores [start, end+1|INTERVAL_END].
            // Dump order varies by backend (rbtree vs pipapo) — sort
            // ascending by byte value first, then walk to pair each
            // start with the following end sentinel.
            let mut elements: Vec<(Vec<u8>, Option<Vec<u8>>)> = Vec::new();
            let mut verdicts: Vec<(i32, String)> = Vec::new();
            let mut data_values: Vec<Vec<u8>> = Vec::new();
            if is_interval {
                let has_key_end = raw.iter().any(|(_, key_end, _, _, _)| key_end.is_some());
                if has_key_end {
                    for (start, key_end, end_flag, vdict, data_value) in &raw {
                        if *end_flag {
                            continue;
                        }
                        let end = key_end.clone().filter(|end_key| end_key != start);
                        elements.push((start.clone(), end));
                        if is_map {
                            if let Some(value) = data_value.clone() {
                                data_values.push(value);
                            } else {
                                verdicts.push(vdict.clone().unwrap_or((0, String::new())));
                            }
                        }
                    }
                } else {
                    let mut sorted = raw.clone();
                    // End sentinel sorts before start at the same value
                    // so touching intervals pair up correctly.
                    sorted.sort_by(|a, b| {
                        Self::cmp_interval_items(&(a.0.clone(), a.2), &(b.0.clone(), b.2))
                    });
                    let mut i = 0;
                    while i < sorted.len() {
                        let (start, _, end_flag, vdict, data_value) = &sorted[i];
                        if *end_flag {
                            i += 1;
                            continue;
                        }
                        let mut end: Option<Vec<u8>> = None;
                        if i + 1 < sorted.len() && sorted[i + 1].2 {
                            let mut v = sorted[i + 1].0.clone();
                            // Subtract one (upper bound was stored +1).
                            for byte in v.iter_mut().rev() {
                                if *byte == 0 {
                                    *byte = 0xff;
                                } else {
                                    *byte -= 1;
                                    break;
                                }
                            }
                            if v != *start {
                                end = Some(v);
                            }
                            i += 2;
                        } else {
                            i += 1;
                        }
                        elements.push((start.clone(), end));
                        if is_map {
                            if let Some(value) = data_value.clone() {
                                data_values.push(value);
                            } else {
                                verdicts.push(vdict.clone().unwrap_or((0, String::new())));
                            }
                        }
                    }
                }
            } else {
                // Kernel dumps hash-set elements in bucket order, so
                // the ordering is pseudo-random. Upstream sorts by
                // value ascending for display — match that or the
                // text/JSON diffs permute arbitrarily. Vmaps sort
                // by key too and drag each element's verdict along.
                let mut items: Vec<(Vec<u8>, Option<(i32, String)>, Option<Vec<u8>>)> = raw
                    .iter()
                    .filter(|(_, _, f, _, _)| !*f)
                    .map(|(k, _, _, v, d)| (k.clone(), v.clone(), d.clone()))
                    .collect();
                items.sort_by(|a, b| a.0.cmp(&b.0));
                for (k, v, d) in items {
                    elements.push((k, None));
                    if is_map {
                        if let Some(value) = d {
                            data_values.push(value);
                        } else {
                            verdicts.push(v.unwrap_or((0, String::new())));
                        }
                    }
                }
            }
            reg.sets.insert(
                name,
                output::AnonSetInfo {
                    key_type,
                    key_len,
                    is_interval,
                    elements,
                    is_map,
                    verdicts,
                    data_type,
                    data_len,
                    data_values,
                },
            );
        }
        Ok(reg)
    }

    /// Like set_element_keys, but for interval sets pairs each start
    /// with its trailing INTERVAL_END sentinel so callers can render
    /// CIDR/ranges. Returns (start, Option<end-inclusive>).
    fn set_element_pairs(
        &mut self,
        family: u8,
        table: &str,
        name: &str,
    ) -> io::Result<Vec<(Vec<u8>, Option<Vec<u8>>)>> {
        let tbl = table.to_string();
        let sn = name.to_string();
        // Find the set to know whether it's interval-flagged.
        let mut set_flags: u32 = 0;
        self.dump(
            NFT_MSG_GETSET,
            family,
            |_, _| {},
            |mt, _, data| {
                if mt != NFT_MSG_NEWSET {
                    return;
                }
                let a = parse_attrs(data);
                let t = a
                    .iter()
                    .find(|(t, _)| *t == NFTA_SET_TABLE)
                    .map(|(_, v)| attr_str(v).to_string())
                    .unwrap_or_default();
                let n = a
                    .iter()
                    .find(|(t, _)| *t == NFTA_SET_NAME)
                    .map(|(_, v)| attr_str(v).to_string())
                    .unwrap_or_default();
                if t == tbl && n == sn {
                    set_flags = a
                        .iter()
                        .find(|(t, _)| *t == NFTA_SET_FLAGS)
                        .map(|(_, v)| attr_u32_be(v))
                        .unwrap_or(0);
                }
            },
        )?;
        let is_interval = set_flags & NFT_SET_INTERVAL != 0;

        let tbl2 = tbl.clone();
        let sn2 = sn.clone();
        let mut raw: Vec<(Vec<u8>, Option<Vec<u8>>, bool)> = Vec::new();
        self.dump(
            NFT_MSG_GETSETELEM,
            family,
            |msg, pos| {
                msg.put_str(NFTA_SET_ELEM_LIST_TABLE, &tbl2);
                msg.put_str(NFTA_SET_ELEM_LIST_SET, &sn2);
                msg.end_msg(pos);
            },
            |mt, _, data| {
                if mt != NFT_MSG_NEWSETELEM {
                    return;
                }
                let a = parse_attrs(data);
                if let Some((_, list)) = a.iter().find(|(t, _)| *t == NFTA_SET_ELEM_LIST_ELEMENTS) {
                    for (_, eb) in parse_attrs(list) {
                        let ea = parse_attrs(&eb);
                        let eflags = ea
                            .iter()
                            .find(|(t, _)| *t == NFTA_SET_ELEM_FLAGS)
                            .map(|(_, v)| attr_u32_be(v))
                            .unwrap_or(0);
                        if let Some((_, k)) = ea.iter().find(|(t, _)| *t == NFTA_SET_ELEM_KEY) {
                            let inner = parse_attrs(k);
                            if let Some((_, d)) = inner.iter().find(|(t, _)| *t == NFTA_DATA_VALUE)
                            {
                                let key_end = ea
                                    .iter()
                                    .find(|(t, _)| *t == NFTA_SET_ELEM_KEY_END)
                                    .and_then(|(_, end_attr)| {
                                        let end_inner = parse_attrs(end_attr);
                                        end_inner
                                            .iter()
                                            .find(|(t, _)| *t == NFTA_DATA_VALUE)
                                            .map(|(_, end_data)| end_data.clone())
                                    });
                                raw.push((
                                    d.clone(),
                                    key_end,
                                    eflags & NFT_SET_ELEM_INTERVAL_END != 0,
                                ));
                            }
                        }
                    }
                }
            },
        )?;

        let mut out: Vec<(Vec<u8>, Option<Vec<u8>>)> = Vec::new();
        if is_interval {
            let has_key_end = raw.iter().any(|(_, key_end, _)| key_end.is_some());
            if has_key_end {
                for (start, key_end, end_flag) in raw {
                    if end_flag {
                        continue;
                    }
                    let end = key_end.filter(|end_key| *end_key != start);
                    out.push((start, end));
                }
            } else {
                raw.sort_by(|a, b| {
                    Self::cmp_interval_items(&(a.0.clone(), a.2), &(b.0.clone(), b.2))
                });
                let mut i = 0;
                while i < raw.len() {
                    let (start, _, end_flag) = &raw[i];
                    if *end_flag {
                        i += 1;
                        continue;
                    }
                    let mut end: Option<Vec<u8>> = None;
                    if i + 1 < raw.len() && raw[i + 1].2 {
                        let mut v = raw[i + 1].0.clone();
                        for byte in v.iter_mut().rev() {
                            if *byte == 0 {
                                *byte = 0xff;
                            } else {
                                *byte -= 1;
                                break;
                            }
                        }
                        if v != *start {
                            end = Some(v);
                        }
                        i += 2;
                    } else {
                        i += 1;
                    }
                    out.push((start.clone(), end));
                }
            }
        } else {
            let mut items: Vec<Vec<u8>> = raw
                .into_iter()
                .filter_map(|(k, _, f)| if !f { Some(k) } else { None })
                .collect();
            items.sort();
            for k in items {
                out.push((k, None));
            }
        }
        Ok(out)
    }

    fn set_element_keys(
        &mut self,
        family: u8,
        table: &str,
        name: &str,
    ) -> io::Result<Vec<Vec<u8>>> {
        let tbl = table.to_string();
        let set = name.to_string();
        let mut out: Vec<Vec<u8>> = Vec::new();
        self.dump(
            NFT_MSG_GETSETELEM,
            family,
            |msg, pos| {
                msg.put_str(NFTA_SET_ELEM_LIST_TABLE, &tbl);
                msg.put_str(NFTA_SET_ELEM_LIST_SET, &set);
                msg.end_msg(pos);
            },
            |mt, _, data| {
                if mt != NFT_MSG_NEWSETELEM {
                    return;
                }
                let a = parse_attrs(data);
                if let Some((_, v)) = a.iter().find(|(t, _)| *t == NFTA_SET_ELEM_LIST_ELEMENTS) {
                    for (_, eb) in parse_attrs(v) {
                        let ea = parse_attrs(&eb);
                        let flags = ea
                            .iter()
                            .find(|(t, _)| *t == NFTA_SET_ELEM_FLAGS)
                            .map(|(_, v)| attr_u32_be(v))
                            .unwrap_or(0);
                        if flags & NFT_SET_ELEM_INTERVAL_END != 0 {
                            continue;
                        }
                        if let Some((_, k)) = ea.iter().find(|(t, _)| *t == NFTA_SET_ELEM_KEY) {
                            let inner = parse_attrs(k);
                            if let Some((_, d)) = inner.iter().find(|(t, _)| *t == NFTA_DATA_VALUE)
                            {
                                out.push(d.clone());
                            }
                        }
                    }
                }
            },
        )?;
        // Kernel dump order varies by backend (pipapo reverses).
        // Sort by raw bytes ascending for stable JSON output.
        out.sort();
        Ok(out)
    }

    fn probe_set_is_interval(&mut self, family: u8, table: &str, name: &str) -> io::Result<bool> {
        let table_s = table.to_string();
        let name_s = name.to_string();
        let mut interval = false;
        self.dump(
            NFT_MSG_GETSET,
            family,
            |_, _| {},
            |mt, _, data| {
                if mt != NFT_MSG_NEWSET {
                    return;
                }
                let a = parse_attrs(data);
                let t = a
                    .iter()
                    .find(|(t, _)| *t == NFTA_SET_TABLE)
                    .map(|(_, v)| attr_str(v).to_string())
                    .unwrap_or_default();
                let n = a
                    .iter()
                    .find(|(t, _)| *t == NFTA_SET_NAME)
                    .map(|(_, v)| attr_str(v).to_string())
                    .unwrap_or_default();
                if t == table_s && n == name_s {
                    let flags = a
                        .iter()
                        .find(|(t, _)| *t == NFTA_SET_FLAGS)
                        .map(|(_, v)| attr_u32_be(v))
                        .unwrap_or(0);
                    if flags & NFT_SET_INTERVAL != 0 {
                        interval = true;
                    }
                }
            },
        )?;
        Ok(interval)
    }

    fn probe_set_key_len(&mut self, family: u8, table: &str, name: &str) -> io::Result<u32> {
        let table_s = table.to_string();
        let name_s = name.to_string();
        let mut key_len = 0u32;
        self.dump(
            NFT_MSG_GETSET,
            family,
            |_, _| {},
            |mt, _, data| {
                if mt != NFT_MSG_NEWSET {
                    return;
                }
                let a = parse_attrs(data);
                let t = a
                    .iter()
                    .find(|(t, _)| *t == NFTA_SET_TABLE)
                    .map(|(_, v)| attr_str(v).to_string())
                    .unwrap_or_default();
                let n = a
                    .iter()
                    .find(|(t, _)| *t == NFTA_SET_NAME)
                    .map(|(_, v)| attr_str(v).to_string())
                    .unwrap_or_default();
                if t == table_s && n == name_s {
                    key_len = a
                        .iter()
                        .find(|(t, _)| *t == NFTA_SET_KEY_LEN)
                        .map(|(_, v)| attr_u32_be(v))
                        .unwrap_or(0);
                }
            },
        )?;
        Ok(key_len)
    }

    fn delete_elements(&mut self, cmd: &Command) -> io::Result<()> {
        let family = cmd.family;
        let table = cmd.table.clone();
        let set_name = cmd.set_name.clone();
        let pending_info = self
            .pending_named_sets
            .get(&(family, table.clone(), set_name.clone()))
            .copied();
        let key_len = pending_info.map(|info| info.key_len).unwrap_or_else(|| {
            self.probe_set_key_len(family, &table, &set_name)
                .unwrap_or(0)
        }) as usize;
        let elements: Vec<(Vec<u8>, Option<Vec<u8>>)> = cmd
            .elements
            .iter()
            .map(|(k, e)| {
                let key = normalize_elem_key(k, key_len);
                let end = e.as_ref().map(|x| normalize_elem_key(x, key_len));
                (key, end)
            })
            .collect();
        self.send_batch(|msg| {
            let pos = msg.begin_msg(NFT_MSG_DELSETELEM, family, NLM_F_ACK);
            msg.put_str(NFTA_SET_ELEM_LIST_TABLE, &table);
            msg.put_str(NFTA_SET_ELEM_LIST_SET, &set_name);
            if let Some(info) = pending_info {
                msg.put_u32_be(NFTA_SET_ELEM_LIST_SET_ID, info.set_id);
            }
            let elems_nest = msg.begin_nested(NFTA_SET_ELEM_LIST_ELEMENTS);
            for (key, _range_end) in &elements {
                let elem = msg.begin_nested(NFTA_LIST_ELEM);
                msg.put_data_value(NFTA_SET_ELEM_KEY, key);
                msg.end_nested(elem);
            }
            msg.end_nested(elems_nest);
            msg.end_msg(pos);
        })
    }
}

fn normalize_elem_key(key: &[u8], key_len: usize) -> Vec<u8> {
    if key_len == 0 || key.len() == key_len {
        return key.to_vec();
    }
    if key.len() > key_len {
        return key[key.len() - key_len..].to_vec();
    }
    let mut out = vec![0u8; key_len - key.len()];
    out.extend_from_slice(key);
    out
}

// ── Expression compiler ─────────────────────────────────────────

fn compile_set_elem_expr(msg: &mut MsgBuilder, expr: &Expr) {
    match expr {
        Expr::Counter { packets, bytes } => {
            msg.put_str(NFTA_EXPR_NAME, "counter");
            let data = msg.begin_nested(NFTA_EXPR_DATA);
            if *packets != 0 {
                msg.put_u64_be(NFTA_COUNTER_PACKETS, *packets);
            }
            if *bytes != 0 {
                msg.put_u64_be(NFTA_COUNTER_BYTES, *bytes);
            }
            msg.end_nested(data);
        }
        Expr::Limit { rate, unit, burst } => {
            msg.put_str(NFTA_EXPR_NAME, "limit");
            let data = msg.begin_nested(NFTA_EXPR_DATA);
            msg.put_u64_be(NFTA_LIMIT_RATE, *rate);
            msg.put_u64_be(NFTA_LIMIT_UNIT, *unit);
            msg.put_u32_be(NFTA_LIMIT_TYPE, NFT_LIMIT_PKTS);
            msg.put_u32_be(NFTA_LIMIT_FLAGS, 0);
            if *burst != 0 {
                msg.put_u32_be(NFTA_LIMIT_BURST, *burst);
            }
            msg.end_nested(data);
        }
        other => panic!("unsupported set element expression: {:?}", other),
    }
}

fn compile_expr(msg: &mut MsgBuilder, expr: &Expr) {
    match expr {
        Expr::Payload {
            base,
            offset,
            len,
            protocol: _,
            dreg,
        } => {
            let elem = msg.begin_nested(NFTA_LIST_ELEM);
            msg.put_str(NFTA_EXPR_NAME, "payload");
            let data = msg.begin_nested(NFTA_EXPR_DATA);
            msg.put_u32_be(NFTA_PAYLOAD_DREG, dreg.unwrap_or(NFT_REG32_00));
            msg.put_u32_be(NFTA_PAYLOAD_BASE, *base);
            msg.put_u32_be(NFTA_PAYLOAD_OFFSET, *offset);
            msg.put_u32_be(NFTA_PAYLOAD_LEN, *len);
            msg.end_nested(data);
            msg.end_nested(elem);
        }
        Expr::Meta { key, width, dreg } => {
            let elem = msg.begin_nested(NFTA_LIST_ELEM);
            msg.put_str(NFTA_EXPR_NAME, "meta");
            let data = msg.begin_nested(NFTA_EXPR_DATA);
            msg.put_u32_be(NFTA_META_KEY, *key);
            msg.put_u32_be(NFTA_META_DREG, dreg.unwrap_or(reg_for_width(*width)));
            msg.end_nested(data);
            msg.end_nested(elem);
        }
        Expr::Ct {
            key,
            dir,
            width,
            dreg,
        } => {
            let elem = msg.begin_nested(NFTA_LIST_ELEM);
            msg.put_str(NFTA_EXPR_NAME, "ct");
            let data = msg.begin_nested(NFTA_EXPR_DATA);
            msg.put_u32_be(NFTA_CT_KEY, *key);
            msg.put_u32_be(NFTA_CT_DREG, dreg.unwrap_or(reg_for_width(*width)));
            if *dir >= 0 {
                msg.put_bytes(NFTA_CT_DIR, &[*dir as u8]);
            }
            msg.end_nested(data);
            msg.end_nested(elem);
        }
        Expr::Fib {
            result,
            flags,
            width,
            dreg,
        } => {
            let elem = msg.begin_nested(NFTA_LIST_ELEM);
            msg.put_str(NFTA_EXPR_NAME, "fib");
            let data = msg.begin_nested(NFTA_EXPR_DATA);
            msg.put_u32_be(NFTA_FIB_DREG, dreg.unwrap_or(reg_for_width(*width)));
            msg.put_u32_be(NFTA_FIB_RESULT, *result);
            msg.put_u32_be(NFTA_FIB_FLAGS, *flags);
            msg.end_nested(data);
            msg.end_nested(elem);
        }
        Expr::Rt { key, width, dreg } => {
            let elem = msg.begin_nested(NFTA_LIST_ELEM);
            msg.put_str(NFTA_EXPR_NAME, "rt");
            let data = msg.begin_nested(NFTA_EXPR_DATA);
            msg.put_u32_be(NFTA_RT_DREG, dreg.unwrap_or(reg_for_width(*width)));
            msg.put_u32_be(NFTA_RT_KEY, *key);
            msg.end_nested(data);
            msg.end_nested(elem);
        }
        Expr::Exthdr {
            raw_type,
            offset,
            len,
            op,
            flags,
            dreg,
            sreg,
        } => {
            let elem = msg.begin_nested(NFTA_LIST_ELEM);
            msg.put_str(NFTA_EXPR_NAME, "exthdr");
            let data = msg.begin_nested(NFTA_EXPR_DATA);
            if let Some(sreg) = sreg {
                msg.put_u32_be(NFTA_EXTHDR_SREG, *sreg);
            } else {
                msg.put_u32_be(
                    NFTA_EXTHDR_DREG,
                    dreg.unwrap_or(reg_for_width(*len as usize)),
                );
            }
            msg.put_u8(NFTA_EXTHDR_TYPE, *raw_type);
            msg.put_u32_be(NFTA_EXTHDR_OFFSET, *offset);
            msg.put_u32_be(NFTA_EXTHDR_LEN, *len);
            msg.put_u32_be(NFTA_EXTHDR_OP, *op);
            if *flags != 0 {
                msg.put_u32_be(NFTA_EXTHDR_FLAGS, *flags);
            }
            msg.end_nested(data);
            msg.end_nested(elem);
        }
        Expr::Cmp { op, data: cmp_data } => {
            let elem = msg.begin_nested(NFTA_LIST_ELEM);
            msg.put_str(NFTA_EXPR_NAME, "cmp");
            let data = msg.begin_nested(NFTA_EXPR_DATA);
            msg.put_u32_be(NFTA_CMP_SREG, reg_for_width(cmp_data.len()));
            msg.put_u32_be(NFTA_CMP_OP, *op);
            msg.put_data_value(NFTA_CMP_DATA, cmp_data);
            msg.end_nested(data);
            msg.end_nested(elem);
        }
        Expr::Lookup {
            set_name,
            inverted,
            width,
            set_id,
            ..
        } => {
            let elem = msg.begin_nested(NFTA_LIST_ELEM);
            msg.put_str(NFTA_EXPR_NAME, "lookup");
            let data = msg.begin_nested(NFTA_EXPR_DATA);
            msg.put_str(NFTA_LOOKUP_SET, set_name);
            msg.put_u32_be(NFTA_LOOKUP_SREG, reg_for_width(*width));
            if *inverted {
                msg.put_u32_be(NFTA_LOOKUP_FLAGS, NFT_LOOKUP_F_INV);
            }
            if let Some(id) = set_id {
                msg.put_u32_be(NFTA_LOOKUP_SET_ID, *id);
            }
            msg.end_nested(data);
            msg.end_nested(elem);
        }
        Expr::Vmap {
            set_name,
            width,
            set_id,
            ..
        } => {
            let elem = msg.begin_nested(NFTA_LIST_ELEM);
            msg.put_str(NFTA_EXPR_NAME, "lookup");
            let data = msg.begin_nested(NFTA_EXPR_DATA);
            // Wire order mirrors upstream nft: SREG, DREG, SET, SET_ID.
            msg.put_u32_be(NFTA_LOOKUP_SREG, reg_for_width(*width));
            // For verdict-map lookups the dreg is NFT_REG_VERDICT (0).
            // Kernel's nft_parse_register_store special-cases that
            // register to accept NFT_DATA_VERDICT-typed sets.
            msg.put_u32_be(NFTA_LOOKUP_DREG, NFT_REG_VERDICT);
            msg.put_str(NFTA_LOOKUP_SET, set_name);
            // SET_ID is required for anon sets so the kernel can tie
            // this rule to the NEWSET we emitted earlier in the same
            // batch; for named maps we omit it and the kernel resolves
            // by name.
            if let Some(id) = set_id {
                msg.put_u32_be(NFTA_LOOKUP_SET_ID, *id);
            }
            msg.end_nested(data);
            msg.end_nested(elem);
        }
        Expr::DataLoad { data: imm, dreg } => {
            let elem = msg.begin_nested(NFTA_LIST_ELEM);
            msg.put_str(NFTA_EXPR_NAME, "immediate");
            let data = msg.begin_nested(NFTA_EXPR_DATA);
            msg.put_u32_be(NFTA_IMM_DREG, dreg.unwrap_or(reg_for_width(imm.len())));
            msg.put_data_value(NFTA_IMM_DATA, imm);
            msg.end_nested(data);
            msg.end_nested(elem);
        }
        Expr::FlowOffload { flowtable } => {
            let elem = msg.begin_nested(NFTA_LIST_ELEM);
            msg.put_str(NFTA_EXPR_NAME, "flow_offload");
            let data = msg.begin_nested(NFTA_EXPR_DATA);
            msg.put_str(NFTA_FLOW_TABLE_NAME, flowtable);
            msg.end_nested(data);
            msg.end_nested(elem);
        }
        Expr::DynSet {
            set_name,
            op,
            timeout_ms,
            set_id,
            key_type,
            data_sreg,
        } => {
            let elem = msg.begin_nested(NFTA_LIST_ELEM);
            msg.put_str(NFTA_EXPR_NAME, "dynset");
            let data = msg.begin_nested(NFTA_EXPR_DATA);
            let sreg = match key_type {
                Some(t) if is_concat_type(*t) => NFT_REG_1,
                Some(t) => reg_for_width(set_type_len(*t) as usize),
                None => NFT_REG32_00,
            };
            msg.put_str(NFTA_DYNSET_SET_NAME, set_name);
            if let Some(id) = set_id {
                msg.put_u32_be(NFTA_DYNSET_SET_ID, *id);
            }
            msg.put_u32_be(NFTA_DYNSET_OP, *op);
            msg.put_u32_be(NFTA_DYNSET_SREG_KEY, sreg);
            if let Some(sreg_data) = data_sreg {
                msg.put_u32_be(NFTA_DYNSET_SREG_DATA, *sreg_data);
            }
            if *timeout_ms > 0 {
                msg.put_u64_be(NFTA_DYNSET_TIMEOUT, *timeout_ms);
            }
            msg.end_nested(data);
            msg.end_nested(elem);
        }
        Expr::Numgen {
            mode,
            modulus,
            offset,
            dreg,
        } => {
            let elem = msg.begin_nested(NFTA_LIST_ELEM);
            msg.put_str(NFTA_EXPR_NAME, "numgen");
            let data = msg.begin_nested(NFTA_EXPR_DATA);
            msg.put_u32_be(NFTA_NG_DREG, *dreg);
            msg.put_u32_be(NFTA_NG_MODULUS, *modulus);
            msg.put_u32_be(NFTA_NG_TYPE, *mode);
            msg.put_u32_be(NFTA_NG_OFFSET, *offset);
            msg.end_nested(data);
            msg.end_nested(elem);
        }
        Expr::Byteorder {
            op,
            len,
            size,
            sreg,
            dreg,
        } => {
            let elem = msg.begin_nested(NFTA_LIST_ELEM);
            msg.put_str(NFTA_EXPR_NAME, "byteorder");
            let data = msg.begin_nested(NFTA_EXPR_DATA);
            msg.put_u32_be(NFTA_BYTEORDER_SREG, *sreg);
            msg.put_u32_be(NFTA_BYTEORDER_DREG, *dreg);
            msg.put_u32_be(NFTA_BYTEORDER_OP, *op);
            msg.put_u32_be(NFTA_BYTEORDER_LEN, *len);
            msg.put_u32_be(NFTA_BYTEORDER_SIZE, *size);
            msg.end_nested(data);
            msg.end_nested(elem);
        }
        Expr::Map {
            set_name,
            width,
            set_id,
            dreg,
            ..
        } => {
            let elem = msg.begin_nested(NFTA_LIST_ELEM);
            msg.put_str(NFTA_EXPR_NAME, "lookup");
            let data = msg.begin_nested(NFTA_EXPR_DATA);
            msg.put_u32_be(NFTA_LOOKUP_SREG, reg_for_width(*width));
            msg.put_u32_be(NFTA_LOOKUP_DREG, *dreg);
            msg.put_str(NFTA_LOOKUP_SET, set_name);
            if let Some(id) = set_id {
                msg.put_u32_be(NFTA_LOOKUP_SET_ID, *id);
            }
            msg.end_nested(data);
            msg.end_nested(elem);
        }
        Expr::PayloadSet {
            base,
            offset,
            len,
            sreg,
            csum_type,
            csum_offset,
            csum_flags,
        } => {
            let elem = msg.begin_nested(NFTA_LIST_ELEM);
            msg.put_str(NFTA_EXPR_NAME, "payload");
            let data = msg.begin_nested(NFTA_EXPR_DATA);
            msg.put_u32_be(NFTA_PAYLOAD_SREG, *sreg);
            msg.put_u32_be(NFTA_PAYLOAD_BASE, *base);
            msg.put_u32_be(NFTA_PAYLOAD_OFFSET, *offset);
            msg.put_u32_be(NFTA_PAYLOAD_LEN, *len);
            if *csum_type != 0 {
                msg.put_u32_be(NFTA_PAYLOAD_CSUM_TYPE, *csum_type);
            }
            if *csum_offset != 0 {
                msg.put_u32_be(NFTA_PAYLOAD_CSUM_OFFSET, *csum_offset);
            }
            if *csum_flags != 0 {
                msg.put_u32_be(NFTA_PAYLOAD_CSUM_FLAGS, *csum_flags);
            }
            msg.end_nested(data);
            msg.end_nested(elem);
        }
        Expr::Tproxy { family, addr, port } => {
            let addr_reg = match addr {
                Some(bytes) if bytes.len() > 4 => Some(NFT_REG_1),
                Some(_) => Some(NFT_REG32_00),
                None => None,
            };
            let port_reg = match (addr_reg, port.as_ref()) {
                (_, None) => None,
                (Some(NFT_REG32_00), Some(_)) => Some(NFT_REG32_01),
                _ => Some(NFT_REG32_00),
            };

            if let (Some(bytes), Some(reg)) = (addr.as_ref(), addr_reg) {
                let elem = msg.begin_nested(NFTA_LIST_ELEM);
                msg.put_str(NFTA_EXPR_NAME, "immediate");
                let data = msg.begin_nested(NFTA_EXPR_DATA);
                msg.put_u32_be(NFTA_IMM_DREG, reg);
                msg.put_data_value(NFTA_IMM_DATA, bytes);
                msg.end_nested(data);
                msg.end_nested(elem);
            }
            if let (Some(bytes), Some(reg)) = (port.as_ref(), port_reg) {
                let elem = msg.begin_nested(NFTA_LIST_ELEM);
                msg.put_str(NFTA_EXPR_NAME, "immediate");
                let data = msg.begin_nested(NFTA_EXPR_DATA);
                msg.put_u32_be(NFTA_IMM_DREG, reg);
                msg.put_data_value(NFTA_IMM_DATA, bytes);
                msg.end_nested(data);
                msg.end_nested(elem);
            }

            let elem = msg.begin_nested(NFTA_LIST_ELEM);
            msg.put_str(NFTA_EXPR_NAME, "tproxy");
            let data = msg.begin_nested(NFTA_EXPR_DATA);
            msg.put_u32_be(NFTA_TPROXY_FAMILY, *family as u32);
            if let Some(reg) = addr_reg {
                msg.put_u32_be(NFTA_TPROXY_REG_ADDR, reg);
            }
            if let Some(reg) = port_reg {
                msg.put_u32_be(NFTA_TPROXY_REG_PORT, reg);
            }
            msg.end_nested(data);
            msg.end_nested(elem);
        }
        // AnonVmap is always rewritten to Vmap by lower_anon_sets
        // (in add_rule) before reaching compile_expr. Reaching this
        // arm is a bug.
        Expr::AnonVmap { .. } => {}
        Expr::AnonMap { .. } => {}
        Expr::ObjRef { kind, name } => {
            // `objref` expression binds a rule to a named stateful
            // object. The IMM_TYPE attribute carries the object kind
            // (NFT_OBJECT_COUNTER / _QUOTA / _LIMIT) so the kernel can
            // look the name up in the right table of objects.
            let elem = msg.begin_nested(NFTA_LIST_ELEM);
            msg.put_str(NFTA_EXPR_NAME, "objref");
            let data = msg.begin_nested(NFTA_EXPR_DATA);
            msg.put_u32_be(NFTA_OBJREF_IMM_TYPE, *kind);
            msg.put_str(NFTA_OBJREF_IMM_NAME, name);
            msg.end_nested(data);
            msg.end_nested(elem);
        }
        Expr::Bitwise { mask, xor } => {
            let elem = msg.begin_nested(NFTA_LIST_ELEM);
            msg.put_str(NFTA_EXPR_NAME, "bitwise");
            let data = msg.begin_nested(NFTA_EXPR_DATA);
            let reg = reg_for_width(mask.len());
            msg.put_u32_be(NFTA_BITWISE_SREG, reg);
            msg.put_u32_be(NFTA_BITWISE_DREG, reg);
            msg.put_u32_be(NFTA_BITWISE_LEN, mask.len() as u32);
            msg.put_data_value(NFTA_BITWISE_MASK, mask);
            msg.put_data_value(NFTA_BITWISE_XOR, xor);
            msg.end_nested(data);
            msg.end_nested(elem);
        }
        Expr::Verdict { code, chain } => {
            let elem = msg.begin_nested(NFTA_LIST_ELEM);
            msg.put_str(NFTA_EXPR_NAME, "immediate");
            let data = msg.begin_nested(NFTA_EXPR_DATA);
            msg.put_u32_be(NFTA_IMM_DREG, NFT_REG_VERDICT);
            let imm_data = msg.begin_nested(NFTA_IMM_DATA);
            let verdict = msg.begin_nested(NFTA_DATA_VERDICT);
            msg.put_u32_be(NFTA_VERDICT_CODE, *code as u32);
            if !chain.is_empty() {
                msg.put_str(NFTA_VERDICT_CHAIN, chain);
            }
            msg.end_nested(verdict);
            msg.end_nested(imm_data);
            msg.end_nested(data);
            msg.end_nested(elem);
        }
        Expr::Counter { packets, bytes } => {
            let elem = msg.begin_nested(NFTA_LIST_ELEM);
            msg.put_str(NFTA_EXPR_NAME, "counter");
            let data = msg.begin_nested(NFTA_EXPR_DATA);
            if *packets != 0 {
                msg.put_u64_be(NFTA_COUNTER_PACKETS, *packets);
            }
            if *bytes != 0 {
                msg.put_u64_be(NFTA_COUNTER_BYTES, *bytes);
            }
            msg.end_nested(data);
            msg.end_nested(elem);
        }
        Expr::Log {
            prefix,
            level,
            flags,
        } => {
            let elem = msg.begin_nested(NFTA_LIST_ELEM);
            msg.put_str(NFTA_EXPR_NAME, "log");
            let data = msg.begin_nested(NFTA_EXPR_DATA);
            if !prefix.is_empty() {
                msg.put_str(NFTA_LOG_PREFIX, prefix);
            }
            if let Some(level) = level {
                msg.put_u32_be(NFTA_LOG_LEVEL, *level);
            }
            if *flags != 0 {
                msg.put_u32_be(NFTA_LOG_FLAGS, *flags);
            }
            msg.end_nested(data);
            msg.end_nested(elem);
        }
        Expr::Hash {
            hash_type,
            modulus,
            seed,
            offset,
            sreg,
            len,
            dreg,
        } => {
            let elem = msg.begin_nested(NFTA_LIST_ELEM);
            msg.put_str(NFTA_EXPR_NAME, "hash");
            let data = msg.begin_nested(NFTA_EXPR_DATA);
            if let Some(sreg) = sreg {
                msg.put_u32_be(NFTA_HASH_SREG, *sreg);
            }
            msg.put_u32_be(NFTA_HASH_DREG, *dreg);
            if *len > 0 {
                msg.put_u32_be(NFTA_HASH_LEN, *len);
            }
            msg.put_u32_be(NFTA_HASH_MODULUS, *modulus);
            if *seed != 0 || *hash_type == NFT_HASH_JENKINS {
                msg.put_u32_be(NFTA_HASH_SEED, *seed);
            }
            if *offset != 0 {
                msg.put_u32_be(NFTA_HASH_OFFSET, *offset);
            }
            msg.put_u32_be(NFTA_HASH_TYPE, *hash_type);
            msg.end_nested(data);
            msg.end_nested(elem);
        }
        Expr::Queue {
            num,
            total,
            flags,
            sreg_qnum,
        } => {
            let elem = msg.begin_nested(NFTA_LIST_ELEM);
            msg.put_str(NFTA_EXPR_NAME, "queue");
            let data = msg.begin_nested(NFTA_EXPR_DATA);
            if let Some(sreg_qnum) = sreg_qnum {
                msg.put_u32_be(NFTA_QUEUE_SREG_QNUM, *sreg_qnum);
            } else if let Some(num) = num {
                msg.put_u16_be(NFTA_QUEUE_NUM, *num);
                if let Some(total) = total {
                    msg.put_u16_be(NFTA_QUEUE_TOTAL, *total);
                }
            }
            if *flags != 0 {
                msg.put_u16_be(NFTA_QUEUE_FLAGS, *flags);
            }
            msg.end_nested(data);
            msg.end_nested(elem);
        }
        Expr::Limit { rate, unit, burst } => {
            let elem = msg.begin_nested(NFTA_LIST_ELEM);
            msg.put_str(NFTA_EXPR_NAME, "limit");
            let data = msg.begin_nested(NFTA_EXPR_DATA);
            msg.put_u64_be(NFTA_LIMIT_RATE, *rate);
            msg.put_u64_be(NFTA_LIMIT_UNIT, *unit);
            msg.put_u32_be(NFTA_LIMIT_TYPE, NFT_LIMIT_PKTS);
            msg.put_u32_be(NFTA_LIMIT_FLAGS, 0);
            if *burst != 0 {
                msg.put_u32_be(NFTA_LIMIT_BURST, *burst);
            }
            msg.end_nested(data);
            msg.end_nested(elem);
        }
        Expr::Nat {
            nat_type,
            family,
            addr,
            port,
            has_addr,
            has_port,
        } => {
            // Load address/port into registers if present
            if *has_addr && !addr.is_empty() {
                let elem = msg.begin_nested(NFTA_LIST_ELEM);
                msg.put_str(NFTA_EXPR_NAME, "immediate");
                let data = msg.begin_nested(NFTA_EXPR_DATA);
                msg.put_u32_be(NFTA_IMM_DREG, NFT_REG32_01);
                msg.put_data_value(NFTA_IMM_DATA, addr);
                msg.end_nested(data);
                msg.end_nested(elem);
            }
            if *has_port {
                let port_bytes = port.to_be_bytes();
                let elem = msg.begin_nested(NFTA_LIST_ELEM);
                msg.put_str(NFTA_EXPR_NAME, "immediate");
                let data = msg.begin_nested(NFTA_EXPR_DATA);
                msg.put_u32_be(NFTA_IMM_DREG, NFT_REG32_01 + 1);
                msg.put_data_value(NFTA_IMM_DATA, &port_bytes);
                msg.end_nested(data);
                msg.end_nested(elem);
            }

            let elem = msg.begin_nested(NFTA_LIST_ELEM);
            msg.put_str(NFTA_EXPR_NAME, "nat");
            let data = msg.begin_nested(NFTA_EXPR_DATA);
            msg.put_u32_be(NFTA_NAT_TYPE, *nat_type);
            msg.put_u32_be(NFTA_NAT_FAMILY, *family as u32);
            if *has_addr {
                msg.put_u32_be(NFTA_NAT_REG_ADDR_MIN, NFT_REG32_01);
                msg.put_u32_be(NFTA_NAT_REG_ADDR_MAX, NFT_REG32_01);
            }
            if *has_port {
                msg.put_u32_be(NFTA_NAT_REG_PROTO_MIN, NFT_REG32_01 + 1);
                msg.put_u32_be(NFTA_NAT_REG_PROTO_MAX, NFT_REG32_01 + 1);
            }
            msg.end_nested(data);
            msg.end_nested(elem);
        }
        Expr::Masquerade => {
            let elem = msg.begin_nested(NFTA_LIST_ELEM);
            msg.put_str(NFTA_EXPR_NAME, "masq");
            let data = msg.begin_nested(NFTA_EXPR_DATA);
            msg.end_nested(data);
            msg.end_nested(elem);
        }
        Expr::Notrack => {
            let elem = msg.begin_nested(NFTA_LIST_ELEM);
            msg.put_str(NFTA_EXPR_NAME, "notrack");
            let data = msg.begin_nested(NFTA_EXPR_DATA);
            msg.end_nested(data);
            msg.end_nested(elem);
        }
        Expr::Reject {
            rej_type,
            icmp_code,
        } => {
            let elem = msg.begin_nested(NFTA_LIST_ELEM);
            msg.put_str(NFTA_EXPR_NAME, "reject");
            let data = msg.begin_nested(NFTA_EXPR_DATA);
            msg.put_u32_be(NFTA_REJECT_TYPE, *rej_type);
            if let Some(code) = icmp_code {
                msg.put_bytes(NFTA_REJECT_ICMP_CODE, &[*code]);
            }
            msg.end_nested(data);
            msg.end_nested(elem);
        }
        // AnonSet is always lowered to Expr::Lookup in add_rule
        // before compile_expr sees the expression stream. Reaching
        // this arm means an expression list bypassed the rewrite,
        // which is a bug; emit nothing rather than crash.
        Expr::AnonSet { .. } => {}
    }
}

// ── Integration tests (require root + Linux kernel with nf_tables) ──
// Run with: cargo test -- --ignored
// Each test uses a unique table name to avoid conflicts when running in parallel.

#[cfg(test)]
mod tests {
    use super::*;
    use std::sync::atomic::{AtomicU32, Ordering};

    static TABLE_ID: AtomicU32 = AtomicU32::new(1);

    fn run(ctx: &mut NftCtx, input: &str) -> io::Result<()> {
        let cmds =
            crate::parser::parse(input).map_err(|e| io::Error::new(io::ErrorKind::Other, e))?;
        for cmd in &cmds {
            ctx.exec(cmd)?;
        }
        Ok(())
    }

    /// Create a context and a unique table name for this test.
    fn setup() -> (NftCtx, String) {
        let ctx = NftCtx::new().expect("failed to open netlink socket (need root?)");
        let id = TABLE_ID.fetch_add(1, Ordering::SeqCst);
        let table = format!("t{}", id);
        (ctx, table)
    }

    fn cleanup(ctx: &mut NftCtx, table: &str) {
        run(ctx, &format!("delete table inet {}", table)).ok();
    }

    // ── Table operations ────────────────────────────────────────

    #[test]
    #[ignore] // requires root + nf_tables kernel
    fn test_add_table() {
        let (mut ctx, t) = setup();
        run(&mut ctx, &format!("add table inet {}", t)).unwrap();
        cleanup(&mut ctx, &t);
    }

    #[test]
    #[ignore]
    fn test_add_table_all_families() {
        let (mut ctx, t) = setup();
        run(&mut ctx, &format!("add table ip {}", t)).unwrap();
        run(&mut ctx, &format!("add table ip6 {}v6", t)).unwrap();
        run(&mut ctx, &format!("add table inet {}inet", t)).unwrap();
        run(&mut ctx, &format!("add table bridge {}br", t)).unwrap();
        run(&mut ctx, &format!("delete table ip {}", t)).ok();
        run(&mut ctx, &format!("delete table ip6 {}v6", t)).ok();
        run(&mut ctx, &format!("delete table inet {}inet", t)).ok();
        run(&mut ctx, &format!("delete table bridge {}br", t)).ok();
    }

    #[test]
    #[ignore]
    fn test_delete_table() {
        let (mut ctx, t) = setup();
        run(&mut ctx, &format!("add table inet {}", t)).unwrap();
        run(&mut ctx, &format!("delete table inet {}", t)).unwrap();
    }

    #[test]
    #[ignore]
    fn test_flush_table() {
        let (mut ctx, t) = setup();
        run(&mut ctx, &format!("add table inet {}", t)).unwrap();
        run(&mut ctx, &format!("add chain inet {} c1", t)).unwrap();
        run(&mut ctx, &format!("flush table inet {}", t)).unwrap();
        cleanup(&mut ctx, &t);
    }

    // ── Chain operations ────────────────────────────────────────

    #[test]
    #[ignore]
    fn test_add_base_chain() {
        let (mut ctx, t) = setup();
        run(&mut ctx, &format!("add table inet {}", t)).unwrap();
        run(&mut ctx, &format!(
            r#"add chain inet {} input {{ type filter hook input priority filter; policy accept; }}"#, t
        )).unwrap();
        cleanup(&mut ctx, &t);
    }

    #[test]
    #[ignore]
    fn test_add_regular_chain() {
        let (mut ctx, t) = setup();
        run(&mut ctx, &format!("add table inet {}", t)).unwrap();
        run(&mut ctx, &format!("add chain inet {} mychain", t)).unwrap();
        cleanup(&mut ctx, &t);
    }

    #[test]
    #[ignore]
    fn test_rename_chain() {
        let (mut ctx, t) = setup();
        run(&mut ctx, &format!("add table inet {}", t)).unwrap();
        run(&mut ctx, &format!("add chain inet {} old", t)).unwrap();
        run(&mut ctx, &format!("rename chain inet {} old new", t)).unwrap();
        cleanup(&mut ctx, &t);
    }

    #[test]
    #[ignore]
    fn test_delete_chain() {
        let (mut ctx, t) = setup();
        run(&mut ctx, &format!("add table inet {}", t)).unwrap();
        run(&mut ctx, &format!("add chain inet {} mychain", t)).unwrap();
        run(&mut ctx, &format!("delete chain inet {} mychain", t)).unwrap();
        cleanup(&mut ctx, &t);
    }

    #[test]
    #[ignore]
    fn test_flush_chain() {
        let (mut ctx, t) = setup();
        run(&mut ctx, &format!("add table inet {}", t)).unwrap();
        run(&mut ctx, &format!(
            r#"add chain inet {} input {{ type filter hook input priority filter; policy accept; }}"#, t
        )).unwrap();
        run(&mut ctx, &format!("add rule inet {} input accept", t)).unwrap();
        run(&mut ctx, &format!("flush chain inet {} input", t)).unwrap();
        cleanup(&mut ctx, &t);
    }

    // ── Rule expressions ────────────────────────────────────────

    #[test]
    #[ignore]
    fn test_rule_tcp_dport() {
        let (mut ctx, t) = setup();
        run(&mut ctx, &format!("add table inet {}", t)).unwrap();
        run(&mut ctx, &format!(
            r#"add chain inet {} input {{ type filter hook input priority filter; policy accept; }}"#, t
        )).unwrap();
        run(
            &mut ctx,
            &format!("add rule inet {} input tcp dport 22 accept", t),
        )
        .unwrap();
        cleanup(&mut ctx, &t);
    }

    #[test]
    #[ignore]
    fn test_rule_ct_state() {
        let (mut ctx, t) = setup();
        run(&mut ctx, &format!("add table inet {}", t)).unwrap();
        run(&mut ctx, &format!(
            r#"add chain inet {} input {{ type filter hook input priority filter; policy accept; }}"#, t
        )).unwrap();
        run(
            &mut ctx,
            &format!(
                "add rule inet {} input ct state established,related accept",
                t
            ),
        )
        .unwrap();
        run(
            &mut ctx,
            &format!("add rule inet {} input ct state new accept", t),
        )
        .unwrap();
        cleanup(&mut ctx, &t);
    }

    #[test]
    #[ignore]
    fn test_rule_cidr() {
        let (mut ctx, t) = setup();
        run(&mut ctx, &format!("add table inet {}", t)).unwrap();
        run(&mut ctx, &format!(
            r#"add chain inet {} input {{ type filter hook input priority filter; policy accept; }}"#, t
        )).unwrap();
        run(
            &mut ctx,
            &format!("add rule inet {} input ip saddr 10.0.0.0/8 drop", t),
        )
        .unwrap();
        run(
            &mut ctx,
            &format!("add rule inet {} input ip saddr 192.168.1.0/24 accept", t),
        )
        .unwrap();
        cleanup(&mut ctx, &t);
    }

    #[test]
    #[ignore]
    fn test_rule_counter() {
        let (mut ctx, t) = setup();
        run(&mut ctx, &format!("add table inet {}", t)).unwrap();
        run(&mut ctx, &format!(
            r#"add chain inet {} input {{ type filter hook input priority filter; policy accept; }}"#, t
        )).unwrap();
        run(&mut ctx, &format!("add rule inet {} input counter drop", t)).unwrap();
        cleanup(&mut ctx, &t);
    }

    #[test]
    #[ignore]
    fn test_rule_log() {
        let (mut ctx, t) = setup();
        run(&mut ctx, &format!("add table inet {}", t)).unwrap();
        run(&mut ctx, &format!(
            r#"add chain inet {} input {{ type filter hook input priority filter; policy accept; }}"#, t
        )).unwrap();
        run(
            &mut ctx,
            &format!(r#"add rule inet {} input log prefix "test: " accept"#, t),
        )
        .unwrap();
        cleanup(&mut ctx, &t);
    }

    #[test]
    #[ignore]
    fn test_insert_rule() {
        let (mut ctx, t) = setup();
        run(&mut ctx, &format!("add table inet {}", t)).unwrap();
        run(&mut ctx, &format!(
            r#"add chain inet {} input {{ type filter hook input priority filter; policy accept; }}"#, t
        )).unwrap();
        run(
            &mut ctx,
            &format!("add rule inet {} input tcp dport 80 accept", t),
        )
        .unwrap();
        run(
            &mut ctx,
            &format!("insert rule inet {} input tcp dport 443 accept", t),
        )
        .unwrap();
        cleanup(&mut ctx, &t);
    }

    // ── Set operations ──────────────────────────────────────────

    #[test]
    #[ignore]
    fn test_add_set() {
        let (mut ctx, t) = setup();
        run(&mut ctx, &format!("add table inet {}", t)).unwrap();
        run(
            &mut ctx,
            &format!(r#"add set inet {} blocklist {{ type ipv4_addr; }}"#, t),
        )
        .unwrap();
        cleanup(&mut ctx, &t);
    }

    #[test]
    #[ignore]
    fn test_add_delete_elements() {
        let (mut ctx, t) = setup();
        run(&mut ctx, &format!("add table inet {}", t)).unwrap();
        run(
            &mut ctx,
            &format!(r#"add set inet {} blocklist {{ type ipv4_addr; }}"#, t),
        )
        .unwrap();
        run(
            &mut ctx,
            &format!(
                r#"add element inet {} blocklist {{ 192.168.1.1, 10.0.0.1 }}"#,
                t
            ),
        )
        .unwrap();
        run(
            &mut ctx,
            &format!(r#"delete element inet {} blocklist {{ 10.0.0.1 }}"#, t),
        )
        .unwrap();
        cleanup(&mut ctx, &t);
    }

    #[test]
    #[ignore]
    fn test_delete_set() {
        let (mut ctx, t) = setup();
        run(&mut ctx, &format!("add table inet {}", t)).unwrap();
        run(
            &mut ctx,
            &format!(r#"add set inet {} blocklist {{ type ipv4_addr; }}"#, t),
        )
        .unwrap();
        run(&mut ctx, &format!("delete set inet {} blocklist", t)).unwrap();
        cleanup(&mut ctx, &t);
    }

    // ── List operations ─────────────────────────────────────────

    #[test]
    #[ignore]
    fn test_list_ruleset() {
        let (mut ctx, t) = setup();
        run(&mut ctx, &format!("add table inet {}", t)).unwrap();
        run(&mut ctx, &format!(
            r#"add chain inet {} input {{ type filter hook input priority filter; policy accept; }}"#, t
        )).unwrap();
        run(&mut ctx, "list ruleset").unwrap();
        cleanup(&mut ctx, &t);
    }

    #[test]
    #[ignore]
    fn test_list_table() {
        let (mut ctx, t) = setup();
        run(&mut ctx, &format!("add table inet {}", t)).unwrap();
        run(&mut ctx, &format!("list table inet {}", t)).unwrap();
        cleanup(&mut ctx, &t);
    }

    #[test]
    #[ignore]
    fn test_list_tables() {
        let (mut ctx, t) = setup();
        run(&mut ctx, &format!("add table inet {}", t)).unwrap();
        run(&mut ctx, "list tables").unwrap();
        cleanup(&mut ctx, &t);
    }

    #[test]
    #[ignore]
    fn test_list_chains() {
        let (mut ctx, t) = setup();
        run(&mut ctx, &format!("add table inet {}", t)).unwrap();
        run(&mut ctx, &format!(
            r#"add chain inet {} input {{ type filter hook input priority filter; policy accept; }}"#, t
        )).unwrap();
        run(&mut ctx, "list chains").unwrap();
        cleanup(&mut ctx, &t);
    }

    #[test]
    #[ignore]
    fn test_list_with_handles() {
        let (mut ctx, t) = setup();
        ctx.show_handles = true;
        run(&mut ctx, &format!("add table inet {}", t)).unwrap();
        run(&mut ctx, &format!(
            r#"add chain inet {} input {{ type filter hook input priority filter; policy accept; }}"#, t
        )).unwrap();
        run(&mut ctx, &format!("add rule inet {} input accept", t)).unwrap();
        run(&mut ctx, "list ruleset").unwrap();
        cleanup(&mut ctx, &t);
    }

    // ── Flush operations ────────────────────────────────────────

    #[test]
    #[ignore]
    fn test_flush_ruleset() {
        // This test uses flush ruleset which affects all tables, so it
        // creates and flushes its own isolated table instead.
        let (mut ctx, t) = setup();
        run(&mut ctx, &format!("add table inet {}", t)).unwrap();
        run(&mut ctx, &format!(
            r#"add chain inet {} c1 {{ type filter hook input priority filter; policy accept; }}"#, t
        )).unwrap();
        run(&mut ctx, &format!("add rule inet {} c1 accept", t)).unwrap();
        run(&mut ctx, &format!("flush table inet {}", t)).unwrap();
        cleanup(&mut ctx, &t);
    }

    // ── Full workflow ───────────────────────────────────────────

    #[test]
    #[ignore]
    fn test_full_firewall_setup() {
        let (mut ctx, t) = setup();
        run(&mut ctx, &format!("add table inet {}", t)).unwrap();
        run(&mut ctx, &format!(
            r#"add chain inet {} input {{ type filter hook input priority filter; policy accept; }}"#, t
        )).unwrap();
        run(
            &mut ctx,
            &format!(r#"add set inet {} blocklist {{ type ipv4_addr; }}"#, t),
        )
        .unwrap();
        run(
            &mut ctx,
            &format!(r#"add element inet {} blocklist {{ 192.168.1.1 }}"#, t),
        )
        .unwrap();
        run(
            &mut ctx,
            &format!(
                "add rule inet {} input ct state established,related accept",
                t
            ),
        )
        .unwrap();
        run(
            &mut ctx,
            &format!("add rule inet {} input tcp dport 22 accept", t),
        )
        .unwrap();
        run(
            &mut ctx,
            &format!("add rule inet {} input tcp dport 80 accept", t),
        )
        .unwrap();
        run(
            &mut ctx,
            &format!("add rule inet {} input tcp dport 443 accept", t),
        )
        .unwrap();
        run(
            &mut ctx,
            &format!("add rule inet {} input ip saddr 10.0.0.0/8 drop", t),
        )
        .unwrap();
        run(&mut ctx, &format!("add rule inet {} input counter drop", t)).unwrap();
        run(&mut ctx, "list ruleset").unwrap();
        cleanup(&mut ctx, &t);
    }
}
