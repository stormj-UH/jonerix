//! nft command parser - tokenizer + command parser. 100% safe Rust.

use crate::netlink::*;
use std::sync::atomic::{AtomicU32, Ordering};

static BOUND_CHAIN_COUNTER: AtomicU32 = AtomicU32::new(0);

// ── Types ───────────────────────────────────────────────────────

#[derive(Debug, Clone)]
pub enum CmdOp {
    Add,
    Create,
    Delete,
    Destroy,
    List,
    Flush,
    Rename,
    Insert,
    Replace,
    Reset,
}
#[derive(Debug, Clone)]
pub enum CmdObj {
    Table,
    Chain,
    Rule,
    Set,
    Map,
    Element,
    Flowtable,
    Ruleset,
    Tables,
    Chains,
    Rules,
    Sets,
    Maps,
    Flowtables,
    // Named stateful objects.
    Counter,
    Quota,
    Limit,
    CtTimeout,
    CtExpectation,
    Counters,
    Quotas,
    Limits,
}

#[derive(Debug, Clone, Default)]
pub struct ChainSpec {
    pub is_base: bool,
    pub chain_type: String,
    pub hook: String,
    pub priority: i32,
    pub has_priority: bool,
    pub policy: String,
    pub has_policy: bool,
    pub device: String,
    pub has_device: bool,
}

#[derive(Debug, Clone, Default)]
pub struct TableSpec {
    pub flags: u32,
    pub has_flags: bool,
}

#[derive(Debug, Clone, Default)]
pub struct SetSpec {
    pub key_type_name: String,
    pub key_type: u32,
    pub key_len: u32,
    pub key_field_types: Vec<u32>,
    pub key_field_lens: Vec<u8>,
    pub key_is_typeof: bool,
    pub data_type_name: String,
    pub data_type: u32,
    pub data_len: u32,
    pub data_is_typeof: bool,
    pub flags: u32,
    pub has_flags: bool,
    pub size: u32,
    pub has_size: bool,
    pub auto_merge: bool,
    pub is_map: bool,
}

#[derive(Debug, Clone, Default)]
pub struct FlowtableSpec {
    pub hook: String,
    pub has_hook: bool,
    pub priority: i32,
    pub has_priority: bool,
    pub devices: Vec<String>,
    pub flags: u32,
}

/// Attributes for a named stateful object declaration:
///     add counter t cnt { packets 0 bytes 0 ; }
///     add quota t q   { over 500 mbytes ; }
///     add limit t l   { rate 10/second burst 5 packets ; }
/// The `kind` field is one of NFT_OBJECT_COUNTER / _QUOTA / _LIMIT.
#[derive(Debug, Clone, Default)]
pub struct ObjSpec {
    pub kind: u32,
    pub packets: u64,     // counter init + limit `rate <N>`
    pub bytes: u64,       // counter init + quota `<N> bytes`
    pub quota_flags: u32, // NFT_QUOTA_F_INV when `over` is used
    pub limit_rate: u64,
    pub limit_unit: u64, // seconds per period (1, 60, 3600, 86400)
    pub limit_burst: u32,
    pub limit_type: u32,  // NFT_LIMIT_PKTS (0) or NFT_LIMIT_PKT_BYTES (1)
    pub limit_flags: u32, // NFT_LIMIT_F_INV
    pub ct_l3proto: u16,
    pub ct_l4proto: u8,
    pub ct_timeout_policy: Vec<(String, u32)>,
    pub ct_expect_dport: u16,
    pub ct_expect_timeout_ms: u32,
    pub ct_expect_size: u8,
}

#[derive(Debug, Clone)]
pub enum Expr {
    Payload {
        base: u32,
        offset: u32,
        len: u32,
        protocol: u8,
        dreg: Option<u32>,
    },
    // `width` is the source value's byte width; used to pick the correct
    // destination register (NFT_REG_1 for 16-byte keys like iifname,
    // NFT_REG32_00 for 4-byte keys like mark). Default 4 for back-compat.
    Meta {
        key: u32,
        width: usize,
        dreg: Option<u32>,
    },
    Ct {
        key: u32,
        dir: i8,
        width: usize,
        dreg: Option<u32>,
    },
    Fib {
        result: u32,
        flags: u32,
        width: usize,
        dreg: Option<u32>,
    },
    Rt {
        key: u32,
        width: usize,
        dreg: Option<u32>,
    },
    Exthdr {
        raw_type: u8,
        offset: u32,
        len: u32,
        op: u32,
        flags: u32,
        dreg: Option<u32>,
        sreg: Option<u32>,
    },
    Cmp {
        op: u32,
        data: Vec<u8>,
    },
    Bitwise {
        mask: Vec<u8>,
        xor: Vec<u8>,
    },
    Verdict {
        code: i32,
        chain: String,
    },
    /// `ip saddr @blocked` / `tcp dport != @allowed` — look the value in
    /// the current register up in a named set. `inverted` is true for
    /// `!=` (NFT_LOOKUP_F_INV). `width` is the key width, used to pick
    /// the same register the preceding Meta/Payload stored into.
    Lookup {
        set_name: String,
        inverted: bool,
        width: usize,
        set_id: Option<u32>,
        key_type: Option<u32>,
    },
    /// Anonymous set literal: `ip saddr { 1.1.1.1, 2.2.2.2 }` or
    /// `tcp dport { 22, 80 }`. At rule-build time ops.rs allocates a
    /// `__setN` name, emits NEWSET+NEWSETELEM into the same batch, and
    /// replaces this variant with an Expr::Lookup that points at the
    /// freshly-created anon set. Element tuples use the same
    /// (key, optional-range-end) shape as Command::elements, so CIDR
    /// ranges and `a-b` literals lower naturally.
    AnonSet {
        elements: Vec<(Vec<u8>, Option<Vec<u8>>)>,
        width: usize,
        inverted: bool,
        key_type: Option<u32>,
    },
    /// `... vmap @set` — named verdict map lookup. `set_id` is `Some(n)`
    /// for anon vmaps so the lookup's NFTA_LOOKUP_SET_ID matches the
    /// NEWSET's NFTA_SET_ID in the same batch (required by the kernel
    /// for transactional-name resolution); `None` for named maps.
    Vmap {
        set_name: String,
        width: usize,
        set_id: Option<u32>,
        key_type: Option<u32>,
    },
    /// `... vmap { key : VERDICT, ... }` — anonymous verdict map literal.
    /// Each pair stores (key-start, optional-key-end, verdict-code,
    /// chain-name). The optional end is present for interval keys
    /// like `100-222 : accept`.
    AnonVmap {
        pairs: Vec<(Vec<u8>, Option<Vec<u8>>, i32, String)>,
        width: usize,
        key_type: Option<u32>,
    },
    DataLoad {
        data: Vec<u8>,
        dreg: Option<u32>,
    },
    DynSet {
        set_name: String,
        op: u32,
        timeout_ms: u64,
        set_id: Option<u32>,
        key_type: Option<u32>,
        data_sreg: Option<u32>,
    },
    /// Reference to a named stateful object from a rule:
    ///     counter name "cnt"        (kind = NFT_OBJECT_COUNTER)
    ///     quota name   "q"          (kind = NFT_OBJECT_QUOTA)
    ///     limit name   "l"          (kind = NFT_OBJECT_LIMIT)
    /// Encodes as the `objref` expression with IMM_TYPE + IMM_NAME.
    ObjRef {
        kind: u32,
        name: String,
    },
    Counter {
        packets: u64,
        bytes: u64,
    },
    Log {
        prefix: String,
        level: Option<u32>,
        flags: u32,
    },
    Numgen {
        mode: u32,
        modulus: u32,
        offset: u32,
        dreg: u32,
    },
    Byteorder {
        op: u32,
        len: u32,
        size: u32,
        sreg: u32,
        dreg: u32,
    },
    Map {
        set_name: String,
        width: usize,
        set_id: Option<u32>,
        key_type: Option<u32>,
        dreg: u32,
    },
    AnonMap {
        pairs: Vec<(Vec<u8>, Option<Vec<u8>>, Vec<u8>)>,
        width: usize,
        key_type: Option<u32>,
        data_type: u32,
        data_len: u32,
        dreg: u32,
    },
    PayloadSet {
        base: u32,
        offset: u32,
        len: u32,
        sreg: u32,
        csum_type: u32,
        csum_offset: u32,
        csum_flags: u32,
    },
    Hash {
        hash_type: u32,
        modulus: u32,
        seed: u32,
        offset: u32,
        sreg: Option<u32>,
        len: u32,
        dreg: u32,
    },
    Queue {
        num: Option<u16>,
        total: Option<u16>,
        flags: u16,
        sreg_qnum: Option<u32>,
    },
    FlowOffload {
        flowtable: String,
    },
    Tproxy {
        family: u8,
        addr: Option<Vec<u8>>,
        port: Option<Vec<u8>>,
    },
    Limit {
        rate: u64,
        unit: u64,
        burst: u32,
    },
    Nat {
        nat_type: u32,
        family: u8,
        addr: Vec<u8>,
        port: u16,
        has_addr: bool,
        has_port: bool,
    },
    Masquerade,
    Notrack,
    Reject {
        rej_type: u32,
        icmp_code: Option<u8>,
    },
}

#[derive(Debug, Clone)]
pub struct Command {
    pub op: CmdOp,
    pub obj: CmdObj,
    pub family: u8,
    pub table: String,
    pub chain: String,
    pub set_name: String,
    pub new_name: String,
    pub handle: u64,
    pub has_handle: bool,
    pub rule_index: i32, // 0-based position within chain for `index N`
    pub has_rule_index: bool,
    pub comment: String,
    pub has_comment: bool,
    pub chain_spec: ChainSpec,
    pub table_spec: TableSpec,
    pub set_spec: SetSpec,
    pub flowtable_spec: FlowtableSpec,
    pub obj_spec: ObjSpec,
    pub exprs: Vec<Expr>,
    // Each element is (key, optional-range-end). A range `a-b` in the
    // source serialises as (a, Some(b)); a bare key is (a, None). The
    // encoder emits two records per range (start without flag, end+1
    // with NFT_SET_ELEM_INTERVAL_END) so interval-flagged sets get the
    // kernel encoding the manpage documents.
    pub elements: Vec<(Vec<u8>, Option<Vec<u8>>)>,
    /// For verdict-map element blocks: per-element (code, chain) pairs
    /// parallel to `elements`. Empty when the set isn't a vmap. Chain
    /// is empty for accept/drop/return/continue verdicts.
    pub element_verdicts: Vec<(i32, String)>,
    /// For data-value maps (`type ipv4_addr : ipv4_addr` etc.):
    /// per-element data-value bytes parallel to `elements`. Each
    /// Option is None for a keyed-only element; Some(bytes) for
    /// a mapping entry. Empty vec when the set is plain (no values).
    pub element_datas: Vec<Option<Vec<u8>>>,
    /// Per-element stateful expressions (counter/limit) parallel to
    /// `elements`. Empty inner vec when the element carries no
    /// attached expressions.
    pub element_exprs: Vec<Vec<Expr>>,
    /// Inline anonymous chains lowered from `jump { ... }` / `goto { ... }`.
    pub bound_chains: Vec<BoundChain>,
}

#[derive(Debug, Clone)]
pub struct BoundChain {
    pub name: String,
    pub rules: Vec<Command>,
}

impl Default for Command {
    fn default() -> Self {
        Command {
            op: CmdOp::List,
            obj: CmdObj::Ruleset,
            family: NFPROTO_IPV4,
            table: String::new(),
            chain: String::new(),
            set_name: String::new(),
            new_name: String::new(),
            handle: 0,
            has_handle: false,
            rule_index: -1,
            has_rule_index: false,
            comment: String::new(),
            has_comment: false,
            chain_spec: ChainSpec::default(),
            table_spec: TableSpec::default(),
            set_spec: SetSpec::default(),
            flowtable_spec: FlowtableSpec::default(),
            obj_spec: ObjSpec::default(),
            exprs: Vec::new(),
            elements: Vec::new(),
            element_verdicts: Vec::new(),
            element_datas: Vec::new(),
            element_exprs: Vec::new(),
            bound_chains: Vec::new(),
        }
    }
}

// ── Tokenizer ───────────────────────────────────────────────────

fn tokenize(input: &str) -> Vec<String> {
    let mut tokens = Vec::new();
    let mut chars = input.chars().peekable();
    let mut brace_depth: i32 = 0;

    while let Some(&c) = chars.peek() {
        // Newline always acts as a statement terminator. This matches
        // nft(8) syntax inside chain bodies (rules separated by `;`
        // OR newline) and between top-level commands. List parsers
        // (set element enumerations etc.) skip stray `;` so emitting
        // one at every newline depth is safe.
        if c == '\n' {
            chars.next();
            if tokens.last().map_or(true, |t| t != ";") {
                tokens.push(";".into());
            }
            continue;
        }
        if c.is_whitespace() {
            chars.next();
            continue;
        }
        if c == '#' {
            while chars.peek().map_or(false, |&c| c != '\n') {
                chars.next();
            }
            continue;
        }

        // Single-char tokens
        if matches!(c, '{' | '}' | '(' | ')' | ';' | ',') {
            if c == '{' {
                brace_depth += 1;
            }
            if c == '}' {
                brace_depth = brace_depth.saturating_sub(1);
            }
            tokens.push(c.to_string());
            chars.next();
            continue;
        }

        // Operators
        if c == '!' {
            chars.next();
            if chars.peek() == Some(&'=') {
                chars.next();
                tokens.push("!=".into());
            } else {
                tokens.push("!".into());
            }
            continue;
        }
        if c == '=' {
            chars.next();
            if chars.peek() == Some(&'=') {
                chars.next();
                tokens.push("==".into());
            } else {
                tokens.push("=".into());
            }
            continue;
        }
        if c == '<' {
            chars.next();
            if chars.peek() == Some(&'=') {
                chars.next();
                tokens.push("<=".into());
            } else {
                tokens.push("<".into());
            }
            continue;
        }
        if c == '>' {
            chars.next();
            if chars.peek() == Some(&'=') {
                chars.next();
                tokens.push(">=".into());
            } else {
                tokens.push(">".into());
            }
            continue;
        }

        // Quoted string
        if c == '"' {
            chars.next();
            let mut s = String::new();
            while let Some(&ch) = chars.peek() {
                if ch == '"' {
                    chars.next();
                    break;
                }
                if ch == '\\' {
                    chars.next();
                    if let Some(&esc) = chars.peek() {
                        s.push(esc);
                        chars.next();
                    }
                } else {
                    s.push(ch);
                    chars.next();
                }
            }
            tokens.push(format!("\"{}\"", s));
            continue;
        }

        // Words, numbers, addresses
        let mut word = String::new();
        while let Some(&ch) = chars.peek() {
            if ch.is_whitespace()
                || matches!(
                    ch,
                    '{' | '}' | '(' | ')' | ';' | ',' | '!' | '=' | '<' | '>'
                )
            {
                break;
            }
            // Dash handling. Ranges like 10.0.0.20-10.0.0.25 or 1000-2000
            // need the dash to break the token; but hyphenated names like
            // "foo-bar" are identifiers and keep it. Rule: if the current
            // word is a numeric literal or IPv4 address (digits + dots
            // only) AND the next character is a digit, the dash is a
            // range separator.
            if ch == '-' && !word.is_empty() {
                // IPv4 range: left is digits-plus-dots, right starts digit.
                let is_ipv4_like = word.chars().all(|c| c.is_ascii_digit() || c == '.');
                // IPv6 range: left contains `:` and uses only hex+colon+dot
                // (allow embedded ipv4 for ::ffff:a.b.c.d), right starts
                // with a hex digit or `:` (for an abbreviation like `::1`).
                let is_ipv6_like = word.contains(':')
                    && word
                        .chars()
                        .all(|c| c.is_ascii_hexdigit() || c == ':' || c == '.');
                if is_ipv4_like || is_ipv6_like {
                    let next_c = chars.clone().skip(1).next().unwrap_or(' ');
                    let right_starts_addr = if is_ipv4_like {
                        next_c.is_ascii_digit()
                    } else {
                        next_c.is_ascii_hexdigit() || next_c == ':'
                    };
                    if right_starts_addr {
                        tokens.push(word.clone());
                        word.clear();
                        tokens.push("-".into());
                        chars.next();
                        continue;
                    }
                }
            }
            word.push(ch);
            chars.next();
        }
        if !word.is_empty() {
            tokens.push(word);
        }
    }
    tokens
}

// ── Parser ──────────────────────────────────────────────────────

struct Parser {
    tokens: Vec<String>,
    pos: usize,
    named_sets: std::collections::HashMap<(u8, String, String), SetSpec>,
    error: Option<String>,
}

impl Parser {
    fn new(tokens: Vec<String>) -> Self {
        Parser {
            tokens,
            pos: 0,
            named_sets: std::collections::HashMap::new(),
            error: None,
        }
    }
    fn peek(&self) -> &str {
        self.tokens.get(self.pos).map(|s| s.as_str()).unwrap_or("")
    }
    fn peek_offset(&self, n: usize) -> &str {
        self.tokens
            .get(self.pos + n)
            .map(|s| s.as_str())
            .unwrap_or("")
    }
    fn advance(&mut self) -> &str {
        let t = self.tokens.get(self.pos).map(|s| s.as_str()).unwrap_or("");
        self.pos += 1;
        t
    }
    fn at_end(&self) -> bool {
        self.pos >= self.tokens.len()
    }
    fn matches(&mut self, s: &str) -> bool {
        if self.peek() == s {
            self.advance();
            true
        } else {
            false
        }
    }

    fn is_family(s: &str) -> bool {
        matches!(s, "ip" | "ip6" | "inet" | "arp" | "bridge" | "netdev")
    }

    fn parse_family_default_ip(&mut self) -> u8 {
        if Self::is_family(self.peek()) {
            family_from_str(self.advance()).unwrap_or(NFPROTO_IPV4)
        } else {
            NFPROTO_IPV4
        }
    }

    fn parse_family_default_unspec(&mut self) -> u8 {
        if Self::is_family(self.peek()) {
            family_from_str(self.advance()).unwrap_or(NFPROTO_UNSPEC)
        } else {
            NFPROTO_UNSPEC
        }
    }

    fn next_bound_chain_name() -> String {
        let n = BOUND_CHAIN_COUNTER.fetch_add(1, Ordering::Relaxed);
        format!("__chain{}_{}", std::process::id(), n)
    }

    fn parse_name(&mut self) -> String {
        let t = self.advance();
        let name = if t.starts_with('"') && t.ends_with('"') {
            t[1..t.len() - 1].to_string()
        } else {
            t.to_string()
        };
        if name.len() > 255 && self.error.is_none() {
            self.error = Some(format!("identifier too long: '{}'", name));
        }
        name
    }

    fn parse_ipv4(s: &str) -> Option<[u8; 4]> {
        if !s.contains('.') {
            return None;
        }
        let parts: Vec<&str> = s.split('.').collect();
        if parts.len() != 4 {
            return None;
        }
        let mut out = [0u8; 4];
        for (idx, part) in parts.iter().enumerate() {
            if part.is_empty() || !part.bytes().all(|b| b.is_ascii_digit()) {
                return None;
            }
            out[idx] = part.parse::<u8>().ok()?;
        }
        Some(out)
    }

    /// Parse an IPv6 address literal into 16 bytes. Accepts the usual
    /// forms: full (`2001:db8:1:2:3:4:5:6`), abbreviated (`fe80::1`,
    /// `::1`, `::`), and IPv4-mapped (`::ffff:1.2.3.4`). Returns None
    /// for malformed input — callers fall back to other element
    /// parsing paths (string key etc.) on None.
    fn parse_ipv6(s: &str) -> Option<[u8; 16]> {
        s.parse::<std::net::Ipv6Addr>().ok().map(|a| a.octets())
    }

    fn ipv4_cidr_range(tok: &str) -> Option<(Vec<u8>, Vec<u8>)> {
        let slash = tok.find('/')?;
        let addr = Self::parse_ipv4(&tok[..slash])?;
        let prefix = tok[slash + 1..].parse::<u32>().ok()?.min(32);
        let base = u32::from_be_bytes(addr);
        let host_mask = match prefix {
            32 => 0,
            0 => u32::MAX,
            _ => (1u32 << (32 - prefix)) - 1,
        };
        let start = base & !host_mask;
        let end = start | host_mask;
        Some((start.to_be_bytes().to_vec(), end.to_be_bytes().to_vec()))
    }

    fn ipv6_cidr_range(tok: &str) -> Option<(Vec<u8>, Vec<u8>)> {
        let slash = tok.find('/')?;
        let addr = Self::parse_ipv6(&tok[..slash])?;
        let prefix = tok[slash + 1..].parse::<u32>().ok()?.min(128);
        let base = u128::from_be_bytes(addr);
        let host_mask = match prefix {
            128 => 0,
            0 => u128::MAX,
            _ => (1u128 << (128 - prefix)) - 1,
        };
        let start = base & !host_mask;
        let end = start | host_mask;
        Some((start.to_be_bytes().to_vec(), end.to_be_bytes().to_vec()))
    }

    fn parse_nat_port_token(tok: &str) -> Option<u16> {
        if tok.is_empty() || tok.contains('-') {
            return None;
        }
        let port = Self::parse_numeric_token(tok)?;
        u16::try_from(port).ok()
    }

    fn parse_nat_addr_token(tok: &str) -> Option<(u8, Vec<u8>, Option<u16>)> {
        if tok.contains('-') {
            return None;
        }

        if tok.starts_with('[') {
            let end = tok.find(']')?;
            let addr = Self::parse_ipv6(&tok[1..end])?.to_vec();
            let rest = &tok[end + 1..];
            if rest.is_empty() {
                return Some((NFPROTO_IPV6, addr, None));
            }
            let port = Self::parse_nat_port_token(rest.strip_prefix(':')?)?;
            return Some((NFPROTO_IPV6, addr, Some(port)));
        }

        if let Some(addr) = Self::parse_ipv6(tok) {
            return Some((NFPROTO_IPV6, addr.to_vec(), None));
        }
        if let Some(addr) = Self::parse_ipv4(tok) {
            return Some((NFPROTO_IPV4, addr.to_vec(), None));
        }

        let (addr_part, port_part) = tok.rsplit_once(':')?;
        let port = Self::parse_nat_port_token(port_part)?;
        let addr = Self::parse_ipv4(addr_part)?.to_vec();
        Some((NFPROTO_IPV4, addr, Some(port)))
    }

    fn tcp_flag_value(tok: &str) -> Option<u8> {
        match tok {
            "fin" => Some(0x01),
            "syn" => Some(0x02),
            "rst" => Some(0x04),
            "psh" => Some(0x08),
            "ack" => Some(0x10),
            "urg" => Some(0x20),
            "ece" => Some(0x40),
            "cwr" => Some(0x80),
            _ => None,
        }
    }

    fn tcp_flag_mask_token(tok: &str) -> Option<u8> {
        let stripped = tok.trim_start_matches('(').trim_end_matches(')');
        if stripped.contains('|') {
            let mut mask = 0u8;
            for part in stripped.split('|') {
                mask |= Self::tcp_flag_value(part)?;
            }
            Some(mask)
        } else {
            Self::tcp_flag_value(stripped)
        }
    }

    fn parse_tcp_flag_mask(&mut self) -> Option<u8> {
        let compact = self.peek().to_string();
        if compact != "(" {
            if let Some(mask) = Self::tcp_flag_mask_token(&compact) {
                self.advance();
                return Some(mask);
            }
        }

        let mut mask = 0u8;
        let mut saw_any = false;
        let paren = self.matches("(");
        loop {
            let tok = self.peek().to_string();
            let Some(flag_mask) = Self::tcp_flag_mask_token(&tok) else {
                break;
            };
            saw_any = true;
            mask |= flag_mask;
            self.advance();
            if self.peek() == "|" {
                self.advance();
                continue;
            }
            break;
        }
        if paren && !self.matches(")") {
            return None;
        }
        if saw_any {
            Some(mask)
        } else {
            None
        }
    }

    fn split_compact_type_decl(tok: &str) -> Option<(String, String)> {
        let (key, data) = tok.split_once(':')?;
        if key.is_empty() || data.is_empty() {
            return None;
        }
        let (kt, _) = crate::netlink::set_key_type(key);
        let (dt, _) = crate::netlink::set_key_type(data);
        if kt == 0 || dt == 0 {
            return None;
        }
        Some((key.to_string(), data.to_string()))
    }

    fn is_verdict_token(tok: &str) -> bool {
        matches!(
            tok,
            "accept" | "drop" | "return" | "continue" | "jump" | "goto"
        )
    }

    fn split_compact_pair(tok: &str) -> Option<(String, String)> {
        if !tok.contains(':') || Self::parse_ipv6(tok).is_some() {
            return None;
        }
        let strong = |s: &str| {
            Self::is_verdict_token(s)
                || Self::parse_ipv6(s).is_some()
                || Self::parse_ipv4(s).is_some()
                || s.parse::<u32>().is_ok()
                || (s.starts_with('"') && s.ends_with('"') && s.len() >= 2)
        };
        let simple = |s: &str| {
            !s.is_empty()
                && s.chars()
                    .all(|c| c.is_ascii_alphanumeric() || matches!(c, '_' | '-' | '.' | '$'))
        };
        for (idx, ch) in tok.char_indices().rev() {
            if ch != ':' {
                continue;
            }
            let left = &tok[..idx];
            let right = &tok[idx + 1..];
            if left.is_empty() || right.is_empty() {
                continue;
            }
            let left_strong = strong(left);
            let right_strong = strong(right);
            if (right_strong && (left_strong || simple(left)))
                || (left_strong && (right_strong || simple(right)))
            {
                return Some((left.to_string(), right.to_string()));
            }
        }
        None
    }

    fn split_trailing_range(tok: &str) -> Option<String> {
        let start = tok.strip_suffix('-')?;
        if start.is_empty() {
            return None;
        }
        Some(start.to_string())
    }

    fn parse_type_fields(&mut self, first_tok: String) -> Vec<String> {
        let mut fields = vec![first_tok];
        while self.peek() == "." {
            self.advance();
            if self.at_end() || matches!(self.peek(), ":" | ";" | "}") {
                break;
            }
            fields.push(self.advance().to_string());
        }
        fields
    }

    fn build_type_fields(fields: &[String]) -> (String, u32, u32, Vec<u32>, Vec<u8>) {
        let mut encoded = 0u32;
        let mut types: Vec<u32> = Vec::new();
        let mut lens: Vec<u8> = Vec::new();
        for field in fields {
            let (ty, len) = crate::netlink::set_key_type(field);
            if ty == 0 {
                continue;
            }
            encoded = if encoded == 0 {
                ty
            } else {
                crate::netlink::concat_type_add(encoded, ty)
            };
            types.push(ty);
            lens.push(len as u8);
        }
        let key_len = if lens.len() <= 1 {
            lens.first().copied().unwrap_or(0) as u32
        } else {
            lens.iter()
                .map(|len| crate::netlink::padded_key_len(*len as u32))
                .sum()
        };
        (fields.join(" . "), encoded, key_len, types, lens)
    }

    fn apply_set_key_fields(spec: &mut SetSpec, fields: Vec<String>) {
        let (name, ty, len, types, lens) = Self::build_type_fields(&fields);
        spec.key_type_name = name;
        spec.key_type = ty;
        spec.key_len = len;
        spec.key_field_types = types;
        spec.key_field_lens = lens;
        spec.key_is_typeof = false;
    }

    fn apply_set_data_fields(spec: &mut SetSpec, fields: Vec<String>) {
        let (name, ty, len, _, _) = Self::build_type_fields(&fields);
        spec.data_type_name = name;
        spec.data_type = ty;
        spec.data_len = len;
        spec.data_is_typeof = false;
    }

    fn apply_typeof_key_fields(spec: &mut SetSpec, fields: Vec<(String, u32, u8)>) {
        let mut encoded = 0u32;
        let mut names: Vec<String> = Vec::new();
        let mut types: Vec<u32> = Vec::new();
        let mut lens: Vec<u8> = Vec::new();
        for (name, ty, len) in fields {
            names.push(name);
            encoded = if encoded == 0 {
                ty
            } else {
                crate::netlink::concat_type_add(encoded, ty)
            };
            types.push(ty);
            lens.push(len);
        }
        spec.key_type_name = names.join(" . ");
        spec.key_type = encoded;
        spec.key_len = if lens.len() <= 1 {
            lens.first().copied().unwrap_or(0) as u32
        } else {
            lens.iter()
                .map(|len| crate::netlink::padded_key_len(*len as u32))
                .sum()
        };
        spec.key_field_types = types;
        spec.key_field_lens = lens;
        spec.key_is_typeof = true;
    }

    fn validate_named_set_spec(spec: &SetSpec) -> Result<(), String> {
        if spec.key_type == 0 {
            return Err("set definition does not specify key".into());
        }
        if spec.is_map && spec.data_type == 0 {
            return Err("map definition does not specify data".into());
        }
        if spec.auto_merge && spec.flags & NFT_SET_INTERVAL == 0 {
            return Err("auto-merge only works with interval sets".into());
        }
        Ok(())
    }

    fn parse_typeof_selector(&mut self) -> Option<(String, u32, u8)> {
        let tok = self.peek().to_string();
        match tok.as_str() {
            "ip" => {
                self.advance();
                let field = self.advance().to_string();
                match field.as_str() {
                    "saddr" => Some(("ip saddr".to_string(), 7, 4)),
                    "daddr" => Some(("ip daddr".to_string(), 7, 4)),
                    "protocol" => Some(("ip protocol".to_string(), 12, 1)),
                    _ => None,
                }
            }
            "ip6" => {
                self.advance();
                let field = self.advance().to_string();
                match field.as_str() {
                    "saddr" => Some(("ip6 saddr".to_string(), 8, 16)),
                    "daddr" => Some(("ip6 daddr".to_string(), 8, 16)),
                    "nexthdr" => Some(("ip6 nexthdr".to_string(), 12, 1)),
                    _ => None,
                }
            }
            "meta" => {
                self.advance();
                let field = self.advance().to_string();
                let Some((key, width)) = meta_key(&field) else {
                    return None;
                };
                let (ty, len) = Self::expr_key_type(&Expr::Meta {
                    key,
                    width,
                    dreg: None,
                })?;
                Some((format!("meta {}", field), ty, len as u8))
            }
            "tcp" | "udp" => {
                self.advance();
                if self.peek() == "option" {
                    self.advance();
                    let option = self.advance().to_string();
                    let field = self.advance().to_string();
                    return match (tok.as_str(), option.as_str(), field.as_str()) {
                        ("tcp", "maxseg", "size") => {
                            Some(("tcp option maxseg size".to_string(), 13, 2))
                        }
                        _ => None,
                    };
                }
                let field = self.advance().to_string();
                match field.as_str() {
                    "sport" | "dport" => Some((format!("{} {}", tok, field), 13, 2)),
                    _ => None,
                }
            }
            "rt" => {
                self.advance();
                match self.advance() {
                    "type" => Some(("rt type".to_string(), 12, 1)),
                    _ => None,
                }
            }
            "icmp" => {
                self.advance();
                let field = self.advance().to_string();
                match field.as_str() {
                    "type" => Some(("icmp type".to_string(), 14, 1)),
                    "code" => Some(("icmp code".to_string(), 18, 1)),
                    _ => None,
                }
            }
            "icmpv6" => {
                self.advance();
                let field = self.advance().to_string();
                match field.as_str() {
                    "type" => Some(("icmpv6 type".to_string(), 19, 1)),
                    "code" => Some(("icmpv6 code".to_string(), 20, 1)),
                    _ => None,
                }
            }
            _ => None,
        }
    }

    fn parse_typeof_selectors(&mut self) -> Option<Vec<(String, u32, u8)>> {
        let mut fields = Vec::new();
        fields.push(self.parse_typeof_selector()?);
        while self.peek() == "." {
            self.advance();
            fields.push(self.parse_typeof_selector()?);
        }
        Some(fields)
    }

    fn remember_named_set(&mut self, family: u8, table: &str, set_name: &str, spec: &SetSpec) {
        self.named_sets.insert(
            (family, table.to_string(), set_name.to_string()),
            spec.clone(),
        );
    }

    fn named_set_spec(&self, family: u8, table: &str, set_name: &str) -> Option<&SetSpec> {
        self.named_sets
            .get(&(family, table.to_string(), set_name.to_string()))
    }

    fn expr_key_type(expr: &Expr) -> Option<(u32, u32)> {
        match expr {
            Expr::Payload {
                base,
                offset,
                len,
                protocol,
                ..
            } => match (*base, *offset, *len, *protocol) {
                (b, 12, 4, _) | (b, 16, 4, _) if b == NFT_PAYLOAD_NETWORK_HEADER => Some((7, 4)),
                (b, 8, 16, _) | (b, 24, 16, _) if b == NFT_PAYLOAD_NETWORK_HEADER => Some((8, 16)),
                (b, 6, 1, _) | (b, 9, 1, _) if b == NFT_PAYLOAD_NETWORK_HEADER => Some((12, 1)),
                (b, 0, 2, p) | (b, 2, 2, p)
                    if b == NFT_PAYLOAD_TRANSPORT_HEADER && (p == 6 || p == 17 || p == 0) =>
                {
                    Some((13, 2))
                }
                (b, 0, 1, 1) if b == NFT_PAYLOAD_TRANSPORT_HEADER => Some((14, 1)),
                (b, 1, 1, 1) if b == NFT_PAYLOAD_TRANSPORT_HEADER => Some((18, 1)),
                (b, 0, 1, 58) if b == NFT_PAYLOAD_TRANSPORT_HEADER => Some((19, 1)),
                (b, 1, 1, 58) if b == NFT_PAYLOAD_TRANSPORT_HEADER => Some((20, 1)),
                (_, _, 1, _) => Some((12, 1)),
                (_, _, w, _) => Some((4, w)),
            },
            Expr::Meta { key, width, .. } => Some(match *key {
                NFT_META_MARK => (15, 4),
                NFT_META_IIFNAME | NFT_META_OIFNAME => (16, 16),
                NFT_META_L4PROTO => (12, 1),
                NFT_META_NFPROTO => (2, 1),
                NFT_META_PROTOCOL => (10, 2),
                NFT_META_IIF | NFT_META_OIF => (36, 4),
                _ => (4, *width as u32),
            }),
            Expr::Ct { key, width, .. } => Some(match *key {
                NFT_CT_STATE => (27, *width as u32),
                NFT_CT_DIRECTION => (28, *width as u32),
                NFT_CT_STATUS => (29, *width as u32),
                _ => (4, *width as u32),
            }),
            Expr::Fib { width, .. } => Some((25, *width as u32)),
            Expr::Rt { key, width, .. } => Some(match *key {
                NFT_RT_NEXTHOP4 => (7, 4),
                NFT_RT_NEXTHOP6 => (8, 16),
                NFT_RT_TCPMSS => (13, 2),
                NFT_RT_XFRM => (12, 1),
                NFT_RT_CLASSID => (4, 4),
                _ => (4, *width as u32),
            }),
            Expr::Exthdr {
                raw_type,
                offset,
                len,
                op,
                flags,
                ..
            } => Some(match (*op, *raw_type, *offset, *len, *flags) {
                (NFT_EXTHDR_OP_IPV6, IPPROTO_ROUTING, 2, 1, 0) => (12, 1),
                (NFT_EXTHDR_OP_TCPOPT, TCPOPT_MAXSEG, 2, 2, 0) => (13, 2),
                (_, _, _, 1, _) => (12, 1),
                (_, _, _, w, _) => (4, w),
            }),
            _ => None,
        }
    }

    fn parse_iface_index(tok: &str) -> Option<u32> {
        if let Some(n) = Self::parse_numeric_token(tok) {
            return Some(n as u32);
        }
        let raw = if tok.starts_with('"') && tok.ends_with('"') && tok.len() >= 2 {
            &tok[1..tok.len() - 1]
        } else {
            tok
        };
        let path = format!("/sys/class/net/{}/ifindex", raw);
        std::fs::read_to_string(&path)
            .ok()
            .and_then(|s| s.trim().parse::<u32>().ok())
            .or_else(|| if raw == "lo" { Some(1) } else { None })
    }

    fn parse_typed_value_token(tok: &str, ty: u32, len: u32) -> Option<Vec<u8>> {
        let parse_fixed_hex = |tok: &str, len: u32| -> Option<Vec<u8>> {
            let hex = tok.strip_prefix("0x")?;
            if hex.is_empty() || hex.len() % 2 != 0 || hex.len() > len as usize * 2 {
                return None;
            }
            let mut out = Vec::with_capacity(len as usize);
            let pad = len as usize - (hex.len() / 2);
            out.resize(pad, 0);
            let mut i = 0usize;
            while i < hex.len() {
                let byte = u8::from_str_radix(&hex[i..i + 2], 16).ok()?;
                out.push(byte);
                i += 2;
            }
            Some(out)
        };
        match ty {
            2 => nfproto_num(tok)
                .map(|n| vec![n])
                .or_else(|| tok.parse::<u8>().ok().map(|n| vec![n])),
            7 => Self::parse_ipv4(tok).map(|a| a.to_vec()),
            8 => Self::parse_ipv6(tok).map(|a| a.to_vec()),
            12 => proto_num(tok)
                .or_else(|| nfproto_num(tok))
                .map(|n| vec![n])
                .or_else(|| tok.parse::<u8>().ok().map(|n| vec![n])),
            13 => service_num(tok)
                .or_else(|| tok.parse::<u16>().ok())
                .map(|n| n.to_be_bytes().to_vec()),
            14 => icmp_type_num(tok)
                .or_else(|| tok.parse::<u8>().ok())
                .map(|n| vec![n]),
            19 => icmpv6_type_num(tok)
                .or_else(|| tok.parse::<u8>().ok())
                .map(|n| vec![n]),
            15 | 22 | 27 | 29 | 36 => {
                let n = if ty == 27 {
                    ct_state_val(tok)
                } else if ty == 36 {
                    Self::parse_iface_index(tok)?
                } else {
                    Self::parse_numeric_token(tok)? as u32
                };
                Some(if ty == 27 {
                    n.to_ne_bytes().to_vec()
                } else {
                    n.to_be_bytes().to_vec()
                })
            }
            25 => fib_addrtype_num(tok)
                .or_else(|| Self::parse_numeric_token(tok).map(|n| n as u32))
                .map(|n| n.to_be_bytes().to_vec()),
            16 => {
                let raw = if tok.starts_with('"') && tok.ends_with('"') && tok.len() >= 2 {
                    &tok[1..tok.len() - 1]
                } else {
                    tok
                };
                let mut out = raw.as_bytes().to_vec();
                out.push(0);
                while out.len() < len as usize {
                    out.push(0);
                }
                Some(out)
            }
            _ if len == 1 => tok.parse::<u8>().ok().map(|n| vec![n]),
            _ if len == 2 => tok.parse::<u16>().ok().map(|n| n.to_be_bytes().to_vec()),
            _ if len == 4 => {
                Self::parse_numeric_token(tok).map(|n| (n as u32).to_be_bytes().to_vec())
            }
            _ if len == 8 => Self::parse_numeric_token(tok).map(|n| n.to_be_bytes().to_vec()),
            _ => parse_fixed_hex(tok, len),
        }
    }

    fn parse_raw_payload_selector_token(tok: &str) -> Option<(u32, u32, u32)> {
        let raw = tok.strip_prefix('@')?;
        let mut parts = raw.split(',');
        let base = match parts.next()? {
            "ll" => NFT_PAYLOAD_LL_HEADER,
            "nh" => NFT_PAYLOAD_NETWORK_HEADER,
            "th" => NFT_PAYLOAD_TRANSPORT_HEADER,
            _ => return None,
        };
        let offset_bits = Self::parse_numeric_token(parts.next()?)? as u32;
        let len_bits = Self::parse_numeric_token(parts.next()?)? as u32;
        if parts.next().is_some()
            || len_bits == 0
            || offset_bits % 8 != 0
            || len_bits % 8 != 0
            || len_bits > 128
        {
            return None;
        }
        Some((base, offset_bits / 8, len_bits / 8))
    }

    fn raw_payload_base(tok: &str) -> Option<u32> {
        match tok {
            "@ll" => Some(NFT_PAYLOAD_LL_HEADER),
            "@nh" => Some(NFT_PAYLOAD_NETWORK_HEADER),
            "@th" => Some(NFT_PAYLOAD_TRANSPORT_HEADER),
            _ => None,
        }
    }

    fn parse_raw_payload_selector(&mut self) -> Option<(u32, u32, u32)> {
        let tok = self.peek().to_string();
        if let Some(parsed) = Self::parse_raw_payload_selector_token(&tok) {
            self.advance();
            return Some(parsed);
        }

        let Some(base) = Self::raw_payload_base(self.peek()) else {
            return None;
        };
        let offset_tok = self.peek_offset(2).to_string();
        let len_tok = self.peek_offset(4).to_string();
        let selector = format!("{},{},{}", self.peek(), offset_tok, len_tok);
        if self.peek_offset(1) != ","
            || self.peek_offset(3) != ","
            || offset_tok.is_empty()
            || len_tok.is_empty()
        {
            if self.error.is_none() {
                self.error = Some(format!("invalid raw payload selector '{}'", tok));
            }
            return None;
        }

        let Some(offset_bits) = Self::parse_numeric_token(&offset_tok).map(|n| n as u32) else {
            if self.error.is_none() {
                self.error = Some(format!("invalid raw payload selector '{}'", selector));
            }
            return None;
        };
        let Some(len_bits) = Self::parse_numeric_token(&len_tok).map(|n| n as u32) else {
            if self.error.is_none() {
                self.error = Some(format!("invalid raw payload selector '{}'", selector));
            }
            return None;
        };
        if len_bits == 0 || offset_bits % 8 != 0 || len_bits % 8 != 0 || len_bits > 128 {
            if self.error.is_none() {
                self.error = Some(format!("invalid raw payload selector '{}'", selector));
            }
            return None;
        }

        for _ in 0..5 {
            self.advance();
        }
        Some((base, offset_bits / 8, len_bits / 8))
    }

    fn parse_duration_ms(tok: &str) -> Option<u64> {
        if tok.chars().all(|c| c.is_ascii_digit()) {
            return Self::parse_numeric_token(tok).map(|v| v.saturating_mul(1000));
        }

        let mut total = 0u64;
        let mut pos = 0usize;
        let bytes = tok.as_bytes();
        while pos < bytes.len() {
            let start = pos;
            while pos < bytes.len() && bytes[pos].is_ascii_digit() {
                pos += 1;
            }
            if pos == start {
                return None;
            }
            let num = Self::parse_numeric_token(&tok[start..pos])?;
            let unit_ms = if tok[pos..].starts_with("ms") {
                pos += 2;
                1u64
            } else {
                let unit = *bytes.get(pos)? as char;
                pos += 1;
                match unit {
                    's' => 1000u64,
                    'm' => 60_000u64,
                    'h' => 3_600_000u64,
                    'd' => 86_400_000u64,
                    'w' => 604_800_000u64,
                    _ => return None,
                }
            };
            total = total.saturating_add(num.saturating_mul(unit_ms));
        }
        Some(total)
    }

    fn append_concat_field(buf: &mut Vec<u8>, field: &[u8], field_len: u8) {
        let start = buf.len();
        buf.extend_from_slice(field);
        let padded = crate::netlink::padded_key_len(field_len as u32) as usize;
        while padded != 0 && buf.len() - start < padded {
            buf.push(0);
        }
    }

    fn parse_concat_key(
        &mut self,
        first_tok: String,
        field_types: &[u32],
        field_lens: &[u8],
    ) -> Option<Vec<u8>> {
        let (start, end) = self.parse_concat_interval_key(first_tok, field_types, field_lens)?;
        if end.is_some() {
            return None;
        }
        Some(start)
    }

    fn parse_concat_interval_key(
        &mut self,
        first_tok: String,
        field_types: &[u32],
        field_lens: &[u8],
    ) -> Option<(Vec<u8>, Option<Vec<u8>>)> {
        if field_types.is_empty() || field_types.len() != field_lens.len() {
            return None;
        }
        let mut start_buf: Vec<u8> = Vec::new();
        let mut end_buf: Vec<u8> = Vec::new();
        let mut has_interval = false;
        let mut tok = first_tok;
        for idx in 0..field_types.len() {
            let ty = field_types[idx];
            let len = field_lens[idx] as u32;
            let (field_start, field_end) = match ty {
                7 => {
                    if let Some((start, end)) = Self::ipv4_cidr_range(&tok) {
                        let is_range = start != end;
                        (start, if is_range { Some(end) } else { None })
                    } else {
                        let start = Self::parse_typed_value_token(&tok, ty, len)?;
                        (start, None)
                    }
                }
                8 => {
                    if let Some((start, end)) = Self::ipv6_cidr_range(&tok) {
                        let is_range = start != end;
                        (start, if is_range { Some(end) } else { None })
                    } else {
                        let start = Self::parse_typed_value_token(&tok, ty, len)?;
                        (start, None)
                    }
                }
                _ => {
                    let start = Self::parse_typed_value_token(&tok, ty, len)?;
                    (start, None)
                }
            };
            let field_end = field_end.unwrap_or_else(|| field_start.clone());
            has_interval |= field_start != field_end;
            Self::append_concat_field(&mut start_buf, &field_start, field_lens[idx]);
            Self::append_concat_field(&mut end_buf, &field_end, field_lens[idx]);
            if idx + 1 == field_types.len() {
                break;
            }
            if self.peek() != "." {
                return None;
            }
            self.advance();
            tok = self.advance().to_string();
        }
        Some((start_buf, if has_interval { Some(end_buf) } else { None }))
    }

    fn parse_dynset_field(&mut self, cmd: &mut Command, ty: u32, len: u8) -> bool {
        if let Some((field_ty, _)) = self.parse_concat_selector(cmd) {
            return field_ty == ty;
        }
        let tok = self.peek().to_string();
        if let Some(bytes) = Self::parse_typed_value_token(&tok, ty, len as u32) {
            self.advance();
            cmd.exprs.push(Expr::DataLoad {
                data: bytes,
                dreg: None,
            });
            return true;
        }
        false
    }

    fn parse_dynset_stmt(&mut self, cmd: &mut Command, op: u32) -> bool {
        let set_tok = self.peek_offset(1).to_string();
        if !set_tok.starts_with('@') {
            return false;
        }
        let set_name = set_tok[1..].to_string();
        let spec = self
            .named_set_spec(cmd.family, &cmd.table, &set_name)
            .cloned();

        self.advance();
        self.advance();
        if !self.matches("{") {
            self.error = Some(format!("expected '{{' after @{}", set_name));
            return false;
        }

        let parsed_key_type = if let Some(spec) = spec.as_ref() {
            let field_types: Vec<u32> = if spec.key_field_types.is_empty() {
                vec![spec.key_type]
            } else {
                spec.key_field_types.clone()
            };
            let field_lens: Vec<u8> = if spec.key_field_lens.is_empty() {
                vec![spec.key_len as u8]
            } else {
                spec.key_field_lens.clone()
            };
            if field_types.is_empty() || field_types.len() != field_lens.len() {
                return false;
            }

            let mut word_offset = 0usize;
            for (idx, (ty, len)) in field_types
                .iter()
                .copied()
                .zip(field_lens.iter().copied())
                .enumerate()
            {
                if idx > 0 && !self.matches(".") {
                    self.error = Some(format!("invalid dynset key for @{}", set_name));
                    return false;
                }
                if !self.parse_dynset_field(cmd, ty, len) {
                    self.error = Some(format!("invalid dynset key for @{}", set_name));
                    return false;
                }
                if field_types.len() > 1 {
                    if !Self::set_last_expr_dreg(cmd, Self::concat_reg_for_word_offset(word_offset))
                    {
                        self.error = Some(format!("invalid dynset key for @{}", set_name));
                        return false;
                    }
                    word_offset += (crate::netlink::padded_key_len(len as u32) / 4) as usize;
                }
            }
            Some(spec.key_type)
        } else {
            let mut field_types: Vec<u32> = Vec::new();
            let mut word_offset = 0usize;
            loop {
                let Some((ty, len)) = self.parse_concat_selector(cmd) else {
                    self.error = Some(format!("invalid dynset key for @{}", set_name));
                    return false;
                };
                field_types.push(ty);
                if field_types.len() > 1 || self.peek() == "." {
                    if !Self::set_last_expr_dreg(cmd, Self::concat_reg_for_word_offset(word_offset))
                    {
                        self.error = Some(format!("invalid dynset key for @{}", set_name));
                        return false;
                    }
                    word_offset += (crate::netlink::padded_key_len(len) / 4) as usize;
                }
                if !self.matches(".") {
                    break;
                }
            }
            field_types
                .into_iter()
                .reduce(crate::netlink::concat_type_add)
        };

        let mut data_sreg = None;
        if let Some(spec) = spec.as_ref() {
            if spec.is_map {
                if !self.matches(":") {
                    self.error = Some(format!(
                        "expected ':' in dynset map update for @{}",
                        set_name
                    ));
                    return false;
                }
                if !self.parse_dynset_field(cmd, spec.data_type, spec.data_len as u8) {
                    self.error = Some(format!("invalid dynset map value for @{}", set_name));
                    return false;
                }
                let dreg = if is_concat_type(spec.data_type) {
                    NFT_REG_1
                } else {
                    reg_for_width(spec.data_len as usize)
                };
                if !Self::set_last_expr_dreg(cmd, dreg) {
                    self.error = Some(format!("invalid dynset map value for @{}", set_name));
                    return false;
                }
                data_sreg = Some(dreg);
            } else if self.peek().starts_with(':') || self.peek() == ":" {
                self.error = Some(format!(
                    "unexpected map value in set update for @{}",
                    set_name
                ));
                return false;
            }
        } else if self.matches(":") {
            let Some((data_ty, data_len)) = self.parse_concat_selector(cmd) else {
                self.error = Some(format!("invalid dynset map value for @{}", set_name));
                return false;
            };
            let dreg = if is_concat_type(data_ty) {
                NFT_REG_1
            } else {
                NFT_REG32_01
            };
            if !Self::set_last_expr_dreg(cmd, dreg) {
                self.error = Some(format!("invalid dynset map value for @{}", set_name));
                return false;
            }
            let _ = data_len;
            data_sreg = Some(dreg);
        }

        let mut timeout_ms = 0u64;
        if self.matches("timeout") {
            timeout_ms = Self::parse_duration_ms(self.advance()).unwrap_or(0);
        }
        if !self.matches("}") {
            self.error = Some(format!(
                "unexpected token '{}' in dynset update",
                self.peek()
            ));
            return false;
        }
        cmd.exprs.push(Expr::DynSet {
            set_name,
            op,
            timeout_ms,
            set_id: None,
            key_type: parsed_key_type,
            data_sreg,
        });
        true
    }

    fn set_last_expr_dreg(cmd: &mut Command, dreg: u32) -> bool {
        match cmd.exprs.last_mut() {
            Some(Expr::Payload { dreg: slot, .. }) => {
                *slot = Some(dreg);
                true
            }
            Some(Expr::Meta { dreg: slot, .. }) => {
                *slot = Some(dreg);
                true
            }
            Some(Expr::Ct { dreg: slot, .. }) => {
                *slot = Some(dreg);
                true
            }
            Some(Expr::Fib { dreg: slot, .. }) => {
                *slot = Some(dreg);
                true
            }
            Some(Expr::Rt { dreg: slot, .. }) => {
                *slot = Some(dreg);
                true
            }
            Some(Expr::Exthdr {
                dreg: slot, sreg, ..
            }) if sreg.is_none() => {
                *slot = Some(dreg);
                true
            }
            Some(Expr::DataLoad { dreg: slot, .. }) => {
                *slot = Some(dreg);
                true
            }
            _ => false,
        }
    }

    fn expr_is_proto_dependency(expr: &Expr) -> bool {
        matches!(expr,
            Expr::Meta { key, .. } if *key == NFT_META_L4PROTO
        ) || matches!(expr,
            Expr::Payload { base, offset, len, .. }
                if *base == NFT_PAYLOAD_NETWORK_HEADER && *len == 1 && matches!(*offset, 6 | 9)
        )
    }

    fn has_proto_dependency(exprs: &[Expr]) -> bool {
        exprs
            .windows(2)
            .any(|w| Self::expr_is_proto_dependency(&w[0]))
    }

    fn has_conflicting_proto_dependency(exprs: &[Expr], proto_num: u8) -> bool {
        exprs.windows(2).any(|w| {
            if !Self::expr_is_proto_dependency(&w[0]) {
                return false;
            }
            let Expr::Cmp { op, data } = &w[1] else {
                return false;
            };
            if data.len() != 1 {
                return false;
            }
            (*op == NFT_CMP_EQ && data[0] != proto_num)
                || (*op == NFT_CMP_NEQ && data[0] == proto_num)
        })
    }

    fn has_nfproto_dependency(exprs: &[Expr], nfproto: u8) -> bool {
        exprs.windows(2).any(|w| {
            matches!(&w[0], Expr::Meta { key, .. } if *key == NFT_META_NFPROTO)
                && matches!(&w[1], Expr::Cmp { op, data } if *op == NFT_CMP_EQ && data == &[nfproto])
        })
    }

    fn has_conflicting_nfproto_dependency(exprs: &[Expr], nfproto: u8) -> bool {
        exprs.windows(2).any(|w| {
            if !matches!(&w[0], Expr::Meta { key, .. } if *key == NFT_META_NFPROTO) {
                return false;
            }
            let Expr::Cmp { op, data } = &w[1] else {
                return false;
            };
            if data.len() != 1 {
                return false;
            }
            (*op == NFT_CMP_EQ && data[0] != nfproto) || (*op == NFT_CMP_NEQ && data[0] == nfproto)
        })
    }

    fn selector_reg(width: u32) -> u32 {
        if width > 4 {
            NFT_REG_1
        } else {
            NFT_REG32_00
        }
    }

    fn concat_reg_for_word_offset(words: usize) -> u32 {
        if words % NFT_REG32_COUNT == 0 {
            NFT_REG_1 + (words / NFT_REG32_COUNT) as u32
        } else {
            NFT_REG32_00 + words as u32
        }
    }

    fn parse_queue_flags(&mut self) -> u16 {
        let mut flags = 0u16;
        loop {
            match self.peek() {
                "bypass" => {
                    self.advance();
                    flags |= NFT_QUEUE_FLAG_BYPASS;
                }
                "fanout" => {
                    self.advance();
                    flags |= NFT_QUEUE_FLAG_CPU_FANOUT;
                }
                "," => {
                    self.advance();
                }
                _ => break,
            }
        }
        flags
    }

    fn parse_queue_range(&mut self) -> Option<(u16, Option<u16>)> {
        let start = Self::parse_numeric_token(self.peek())?;
        if start > u16::MAX as u64 {
            return None;
        }
        self.advance();
        if self.peek() == "-" {
            self.advance();
            let end = Self::parse_numeric_token(self.peek())?;
            if end > u16::MAX as u64 || end < start {
                return None;
            }
            self.advance();
            Some((start as u16, Some((end - start + 1) as u16)))
        } else {
            Some((start as u16, None))
        }
    }

    fn reorder_last_transport_matches_for_queue(cmd: &mut Command) {
        let mut pairs: Vec<(usize, usize, u32)> = Vec::new();
        let mut i = 0usize;
        while i + 1 < cmd.exprs.len() {
            if let Expr::Payload {
                base, offset, len, ..
            } = &cmd.exprs[i]
            {
                if *base == NFT_PAYLOAD_TRANSPORT_HEADER
                    && *len == 2
                    && matches!(cmd.exprs.get(i + 1), Some(Expr::Cmp { .. }))
                {
                    pairs.push((i, i + 1, *offset));
                    i += 2;
                    continue;
                }
            }
            i += 1;
        }
        if pairs.len() < 2 {
            return;
        }
        let (a0, a1, off_a) = pairs[pairs.len() - 2];
        let (b0, b1, off_b) = pairs[pairs.len() - 1];
        if off_a != 2 || off_b != 0 {
            return;
        }
        let first_payload = cmd.exprs[a0].clone();
        let first_cmp = cmd.exprs[a1].clone();
        let second_payload = cmd.exprs[b0].clone();
        let second_cmp = cmd.exprs[b1].clone();
        cmd.exprs.splice(
            a0..=b1,
            [second_payload, second_cmp, first_payload, first_cmp],
        );
    }

    fn payload_write_csum(base: u32, offset: u32, len: u32) -> (u32, u32, u32) {
        if base == NFT_PAYLOAD_NETWORK_HEADER && len == 4 && matches!(offset, 12 | 16) {
            (NFT_PAYLOAD_CSUM_INET, 10, NFT_PAYLOAD_L4CSUM_PSEUDOHDR)
        } else {
            (0, 0, 0)
        }
    }

    fn parse_inline_data_map(
        &mut self,
        key_type: u32,
        key_len: u32,
        data_type: u32,
        data_len: u32,
        dreg: u32,
    ) -> Option<Expr> {
        if !self.matches("{") {
            return None;
        }
        let mut pairs: Vec<(Vec<u8>, Option<Vec<u8>>, Vec<u8>)> = Vec::new();
        while !self.at_end() && self.peek() != "}" {
            if self.peek() == "," || self.peek() == ";" {
                self.advance();
                continue;
            }
            let raw_tok = self.advance().to_string();
            let compact_value = Self::split_compact_pair(&raw_tok);
            let tok = compact_value
                .as_ref()
                .map(|(key, _)| key.clone())
                .unwrap_or(raw_tok);
            let trailing_range = Self::split_trailing_range(&tok);
            let start_tok = trailing_range.as_deref().unwrap_or(&tok);
            let start = Self::parse_typed_value_token(start_tok, key_type, key_len)?;
            let end = if trailing_range.is_some() {
                let end_tok = self.advance().to_string();
                Some(Self::parse_typed_value_token(&end_tok, key_type, key_len)?)
            } else if self.peek() == "-" {
                self.advance();
                let end_tok = self.advance().to_string();
                Some(Self::parse_typed_value_token(&end_tok, key_type, key_len)?)
            } else {
                None
            };
            let value_tok = if let Some((_, value)) = compact_value {
                value
            } else {
                if !self.matches(":") {
                    return None;
                }
                self.advance().to_string()
            };
            let value = Self::parse_typed_value_token(&value_tok, data_type, data_len)?;
            pairs.push((start, end, value));
        }
        self.matches("}");
        Some(Expr::AnonMap {
            pairs,
            width: key_len as usize,
            key_type: Some(key_type),
            data_type,
            data_len,
            dreg,
        })
    }

    fn parse_set_stmt(&mut self, cmd: &mut Command, base: u32, offset: u32, len: u32) -> bool {
        if self.peek() != "set" {
            return false;
        }
        let Some((data_type, data_len)) = Self::expr_key_type(&Expr::Payload {
            base,
            offset,
            len,
            protocol: 0,
            dreg: None,
        }) else {
            return false;
        };
        self.advance();

        if !self.matches("numgen") {
            return false;
        }
        let mode = match self.advance() {
            "inc" => NFT_NG_INCREMENTAL,
            "random" => NFT_NG_RANDOM,
            _ => return false,
        };
        if !self.matches("mod") {
            return false;
        }
        let Some(modulus) = Self::parse_numeric_token(self.peek()) else {
            return false;
        };
        self.advance();
        let offset_val = if self.matches("offset") {
            let Some(n) = Self::parse_numeric_token(self.peek()) else {
                return false;
            };
            self.advance();
            n as u32
        } else {
            0
        };

        let dreg = NFT_REG32_00;
        cmd.exprs.push(Expr::Numgen {
            mode,
            modulus: modulus as u32,
            offset: offset_val,
            dreg,
        });
        cmd.exprs.push(Expr::Byteorder {
            op: NFT_BYTEORDER_HTON,
            len: 4,
            size: 4,
            sreg: dreg,
            dreg,
        });

        if self.matches("map") {
            let key_type = 4u32;
            let key_len = 4u32;
            if let Some(expr) =
                self.parse_inline_data_map(key_type, key_len, data_type, data_len, dreg)
            {
                cmd.exprs.push(expr);
            } else {
                return false;
            }
        } else {
            return false;
        }

        let (csum_type, csum_offset, csum_flags) = Self::payload_write_csum(base, offset, len);
        cmd.exprs.push(Expr::PayloadSet {
            base,
            offset,
            len,
            sreg: dreg,
            csum_type,
            csum_offset,
            csum_flags,
        });
        true
    }

    fn parse_exthdr_set_stmt(
        &mut self,
        cmd: &mut Command,
        raw_type: u8,
        offset: u32,
        len: u32,
        op: u32,
        flags: u32,
    ) -> bool {
        if self.peek() != "set" {
            return false;
        }
        let Some((data_type, data_len)) = Self::expr_key_type(&Expr::Exthdr {
            raw_type,
            offset,
            len,
            op,
            flags,
            dreg: None,
            sreg: None,
        }) else {
            return false;
        };
        self.advance();

        if self.matches("rt") {
            let (key, width) = match self.advance() {
                "classid" => (NFT_RT_CLASSID, 4usize),
                "mtu" => (NFT_RT_TCPMSS, 2),
                "ipsec" => (NFT_RT_XFRM, 1),
                _ => return false,
            };
            let dreg = Self::selector_reg(width as u32);
            cmd.exprs.push(Expr::Rt {
                key,
                width,
                dreg: Some(dreg),
            });
            if key == NFT_RT_TCPMSS {
                cmd.exprs.push(Expr::Byteorder {
                    op: NFT_BYTEORDER_HTON,
                    len: 2,
                    size: 2,
                    sreg: dreg,
                    dreg,
                });
            }
            cmd.exprs.push(Expr::Exthdr {
                raw_type,
                offset,
                len,
                op,
                flags,
                dreg: None,
                sreg: Some(dreg),
            });
            return true;
        }

        let data = if let Some(v) = Self::parse_typed_value_token(self.peek(), data_type, data_len)
        {
            v
        } else if let Some(v) = Self::parse_scalar_token(cmd, self.peek(), data_len as usize) {
            v
        } else {
            return false;
        };
        self.advance();
        let dreg = Self::selector_reg(data.len() as u32);
        cmd.exprs.push(Expr::DataLoad {
            data,
            dreg: Some(dreg),
        });
        cmd.exprs.push(Expr::Exthdr {
            raw_type,
            offset,
            len,
            op,
            flags,
            dreg: None,
            sreg: Some(dreg),
        });
        true
    }

    fn parse_queue_stmt(&mut self, cmd: &mut Command) -> bool {
        if self.peek() != "queue" {
            return false;
        }

        Self::reorder_last_transport_matches_for_queue(cmd);
        self.advance();

        let mut flags = 0u16;
        if self.matches("flags") {
            flags |= self.parse_queue_flags();
        }

        let mut num: Option<u16> = None;
        let mut total: Option<u16> = None;
        let mut sreg_qnum: Option<u32> = None;

        if self.matches("num") {
            let Some((start, range_total)) = self.parse_queue_range() else {
                return false;
            };
            num = Some(start);
            total = range_total;
            flags |= self.parse_queue_flags();
        } else if self.matches("to") {
            if self.matches("symhash") {
                if !self.matches("mod") {
                    return false;
                }
                let Some(modulus) = Self::parse_numeric_token(self.peek()) else {
                    return false;
                };
                self.advance();
                cmd.exprs.push(Expr::Hash {
                    hash_type: NFT_HASH_SYM,
                    modulus: modulus as u32,
                    seed: 0,
                    offset: 0,
                    sreg: None,
                    len: 0,
                    dreg: NFT_REG32_00,
                });
                sreg_qnum = Some(NFT_REG32_00);
            } else if self.matches("jhash") {
                let start_reg = NFT_REG32_01;
                let mut field_count = 0u32;
                let mut total_len = 0u32;
                loop {
                    let Some((_ty, len)) = self.parse_concat_selector(cmd) else {
                        return false;
                    };
                    if !Self::set_last_expr_dreg(cmd, start_reg + field_count) {
                        return false;
                    }
                    total_len += crate::netlink::padded_key_len(len);
                    field_count += 1;
                    if !self.matches(".") {
                        break;
                    }
                }
                if field_count == 0 || !self.matches("mod") {
                    return false;
                }
                let Some(modulus) = Self::parse_numeric_token(self.peek()) else {
                    return false;
                };
                self.advance();
                cmd.exprs.push(Expr::Hash {
                    hash_type: NFT_HASH_JENKINS,
                    modulus: modulus as u32,
                    seed: 0,
                    offset: 0,
                    sreg: Some(start_reg),
                    len: total_len,
                    dreg: NFT_REG32_00,
                });
                sreg_qnum = Some(NFT_REG32_00);
            } else {
                let save_pos = self.pos;
                let save_expr_len = cmd.exprs.len();
                let mut field_types: Vec<u32> = Vec::new();
                let mut field_lens: Vec<u8> = Vec::new();
                let mut word_offset = 0usize;
                while let Some((ty, len)) = self.parse_concat_selector(cmd) {
                    if !Self::set_last_expr_dreg(cmd, Self::concat_reg_for_word_offset(word_offset))
                    {
                        self.pos = save_pos;
                        cmd.exprs.truncate(save_expr_len);
                        return false;
                    }
                    field_types.push(ty);
                    field_lens.push(len as u8);
                    word_offset += (crate::netlink::padded_key_len(len) / 4) as usize;
                    if !self.matches(".") {
                        break;
                    }
                }
                if !field_types.is_empty() && self.matches("map") && self.peek().starts_with('@') {
                    let set_name = self.advance().trim_start_matches('@').to_string();
                    let key_type = field_types
                        .iter()
                        .copied()
                        .reduce(crate::netlink::concat_type_add);
                    let width: usize = field_lens
                        .iter()
                        .map(|len| crate::netlink::padded_key_len(*len as u32) as usize)
                        .sum();
                    cmd.exprs.push(Expr::Map {
                        set_name,
                        width,
                        set_id: None,
                        key_type,
                        dreg: NFT_REG32_00,
                    });
                    sreg_qnum = Some(NFT_REG32_00);
                } else {
                    self.pos = save_pos;
                    cmd.exprs.truncate(save_expr_len);
                    let Some((start, range_total)) = self.parse_queue_range() else {
                        return false;
                    };
                    num = Some(start);
                    total = range_total;
                }
            }
        } else {
            return false;
        }

        cmd.exprs.push(Expr::Queue {
            num,
            total,
            flags,
            sreg_qnum,
        });
        true
    }

    fn parse_flow_stmt(&mut self, cmd: &mut Command) -> bool {
        if self.peek() != "flow" {
            return false;
        }
        self.advance();
        if !self.matches("add") {
            self.error = Some(format!("unexpected token '{}' after flow", self.peek()));
            return false;
        }
        let name = self.advance().to_string();
        let Some(flowtable) = name.strip_prefix('@') else {
            self.error = Some("flow add requires @flowtable".into());
            return false;
        };
        if flowtable.is_empty() {
            self.error = Some("flow add requires @flowtable".into());
            return false;
        }
        cmd.exprs.push(Expr::FlowOffload {
            flowtable: flowtable.to_string(),
        });
        true
    }

    fn parse_tproxy_stmt(&mut self, cmd: &mut Command) -> bool {
        if self.peek() != "tproxy" {
            return false;
        }
        self.advance();

        let mut family = NFPROTO_UNSPEC;
        if self.matches("ip") {
            family = NFPROTO_IPV4;
        } else if self.matches("ip6") {
            family = NFPROTO_IPV6;
        }
        if !self.matches("to") {
            return false;
        }

        let mut addr: Option<Vec<u8>> = None;
        let mut port: Option<Vec<u8>> = None;

        let parse_port = |tok: &str| {
            service_num(tok)
                .or_else(|| tok.parse::<u16>().ok())
                .map(|n| n.to_be_bytes().to_vec())
        };

        if self.peek().starts_with(':') {
            let raw = self.advance().to_string();
            port = parse_port(raw.trim_start_matches(':'));
        } else if !self.at_end() {
            let raw = self.advance().to_string();
            let (addr_part, port_part) = if raw.starts_with('[') {
                if let Some((addr, port_tok)) = raw.split_once("]:") {
                    (addr.trim_start_matches('['), Some(port_tok))
                } else {
                    (raw.trim_start_matches('[').trim_end_matches(']'), None)
                }
            } else if let Some((addr, port_tok)) = raw.split_once(':') {
                if Self::parse_ipv4(addr).is_some() {
                    (addr, Some(port_tok))
                } else {
                    (raw.as_str(), None)
                }
            } else {
                (raw.as_str(), None)
            };
            if let Some(ip4) = Self::parse_ipv4(addr_part) {
                family = if family == NFPROTO_UNSPEC {
                    NFPROTO_IPV4
                } else {
                    family
                };
                addr = Some(ip4.to_vec());
            } else if let Some(ip6) = Self::parse_ipv6(addr_part) {
                family = if family == NFPROTO_UNSPEC {
                    NFPROTO_IPV6
                } else {
                    family
                };
                addr = Some(ip6.to_vec());
            } else {
                return false;
            }
            if let Some(port_tok) = port_part {
                port = parse_port(port_tok);
            } else if self.matches(":") {
                let port_tok = self.advance().to_string();
                port = parse_port(&port_tok);
            }
        }

        if addr.is_none() && port.is_none() {
            return false;
        }

        let _ = cmd;
        cmd.exprs.push(Expr::Tproxy { family, addr, port });
        true
    }

    fn parse_priority(&mut self, family: u8) -> Result<i32, String> {
        self.parse_priority_ctx(family, "", "")
    }

    /// Priority parsing with the chain type and hook available so
    /// we can reject nat-specific names (`dstnat`, `srcnat`, `out`)
    /// when the enclosing chain is a plain `filter` chain — what
    /// upstream nft does and what chains/0023..0029 check.
    fn parse_priority_ctx(
        &mut self,
        family: u8,
        chain_type: &str,
        hook: &str,
    ) -> Result<i32, String> {
        // A priority expression is one of:
        //   <int>                  e.g. 10, -10
        //   <name>                 e.g. filter, dstnat
        //   <name> <+|-> <int>     e.g. filter + 10
        //   "<name> <+|-> <int>"   quoted (coming from a variable)
        // Consume at most those four tokens and stop at the next
        // statement keyword so we don't swallow `policy ...`, `device
        // ...`, or the chain-block terminator.
        let mut prio_str = String::new();
        let stop = |t: &str| {
            matches!(
                t,
                "" | ";" | "}" | "policy" | "device" | "hook" | "type" | "flags" | "comment"
            )
        };
        // First token: number, name, or a quoted string that itself
        // contains the whole expression.
        if stop(self.peek()) {
            return Ok(0);
        }
        let first = self.advance().to_string();
        // Strip surrounding quotes the tokenizer preserved (for
        // `define for = "filter - 100"` style values).
        let first_unquoted = if first.starts_with('"') && first.ends_with('"') && first.len() >= 2 {
            first[1..first.len() - 1].to_string()
        } else {
            first.clone()
        };
        prio_str.push_str(&first_unquoted);
        // Optional `+ N` / `- N` tail.
        if matches!(self.peek(), "+" | "-") && !stop(self.peek_offset(1)) {
            let sign = self.advance().to_string();
            let num = self.advance().to_string();
            prio_str.push(' ');
            prio_str.push_str(&sign);
            prio_str.push(' ');
            prio_str.push_str(&num);
        } else if matches!(self.peek().as_bytes().first(), Some(b'+') | Some(b'-'))
            && self.peek()[1..].chars().all(|c| c.is_ascii_digit())
        {
            prio_str.push(' ');
            prio_str.push_str(self.advance());
        }
        // Extract the bare name (before any `+`/`-` offset) for
        // validating it against the chain context.
        let prio_name = prio_str.split_whitespace().next().unwrap_or("");
        let prio_val = crate::netlink::priority_from_str_opt(&prio_str, family)
            .ok_or_else(|| format!("unknown priority '{}'", prio_str.trim()))?;

        // Priority name validity depends on (family, chain_type, hook).
        // Upstream nft rejects mismatches at parse time — we mirror
        // the same table here.
        if !chain_type.is_empty() && !hook.is_empty() {
            let is_bridge = family == crate::netlink::NFPROTO_BRIDGE;
            let is_arp = family == crate::netlink::NFPROTO_ARP;
            let is_netdev = family == crate::netlink::NFPROTO_NETDEV;
            let hook_ok = |allowed: &[&str]| allowed.iter().any(|h| *h == hook);
            // arp and netdev only accept `filter` (and bare integers),
            // no named priorities beyond that.
            if (is_arp || is_netdev)
                && matches!(
                    prio_name,
                    "raw" | "mangle" | "dstnat" | "security" | "srcnat" | "out"
                )
            {
                return Err(format!(
                    "priority '{}' is not valid in {} family",
                    prio_name,
                    if is_arp { "arp" } else { "netdev" }
                ));
            }
            // `dstnat` binds the prerouting (or ip6 output) hook.
            if prio_name == "dstnat" {
                let allowed: &[&str] = if family == crate::netlink::NFPROTO_IPV6 {
                    &["prerouting", "output"]
                } else {
                    &["prerouting"]
                };
                if !hook_ok(allowed) {
                    return Err(format!(
                        "priority 'dstnat' is only valid in the prerouting hook"
                    ));
                }
            }
            // `srcnat` binds postrouting.
            if prio_name == "srcnat" && !hook_ok(&["postrouting"]) {
                return Err(format!(
                    "priority 'srcnat' is only valid in the postrouting hook"
                ));
            }
            // `out` is bridge-only and hook output only.
            if prio_name == "out" {
                if !is_bridge {
                    return Err(format!("priority 'out' is only valid in the bridge family"));
                }
                if !hook_ok(&["output"]) {
                    return Err(format!("priority 'out' is only valid in the output hook"));
                }
            }
        }

        Ok(prio_val)
    }

    fn parse_flowtable_priority(&mut self, family: u8) -> Result<i32, String> {
        let stop = |t: &str| matches!(t, "" | ";" | "}" | "devices" | "counter");
        if stop(self.peek()) {
            return Err("missing flowtable priority".into());
        }

        let first = self.advance().to_string();
        let first_unquoted = if first.starts_with('"') && first.ends_with('"') && first.len() >= 2 {
            first[1..first.len() - 1].to_string()
        } else {
            first.clone()
        };
        let mut prio_str = first_unquoted;
        if matches!(self.peek(), "+" | "-") && !stop(self.peek_offset(1)) {
            let sign = self.advance().to_string();
            let num = self.advance().to_string();
            prio_str.push(' ');
            prio_str.push_str(&sign);
            prio_str.push(' ');
            prio_str.push_str(&num);
        } else if matches!(self.peek().as_bytes().first(), Some(b'+') | Some(b'-'))
            && self.peek()[1..].chars().all(|c| c.is_ascii_digit())
        {
            prio_str.push(' ');
            prio_str.push_str(self.advance());
        }

        if prio_str.trim().parse::<i32>().is_ok() {
            return Ok(prio_str.trim().parse::<i32>().unwrap_or(0));
        }

        let prio_name = prio_str.split_whitespace().next().unwrap_or("");
        if prio_name != "filter" {
            return Err(format!("unknown priority '{}'", prio_str.trim()));
        }
        crate::netlink::priority_from_str_opt(&prio_str, family)
            .ok_or_else(|| format!("unknown priority '{}'", prio_str.trim()))
    }

    fn parse_flowtable_devices(&mut self) -> Result<Vec<String>, String> {
        let mut devices = Vec::new();
        if self.matches("{") {
            while !self.at_end() && self.peek() != "}" {
                while self.matches(",") {}
                if self.peek() == "}" {
                    break;
                }
                let dev = self.parse_name();
                if dev.is_empty() {
                    return Err("empty device name in flowtable".into());
                }
                devices.push(dev);
                while self.matches(",") {}
            }
            if !self.matches("}") {
                return Err("missing closing '}' in flowtable devices".into());
            }
        } else {
            let dev = self.parse_name();
            if dev.is_empty() {
                return Err("empty device name in flowtable".into());
            }
            devices.push(dev);
        }
        Ok(devices)
    }

    fn parse_flowtable_block(&mut self, cmd: &mut Command) -> Result<(), String> {
        if !self.matches("{") {
            return Ok(());
        }
        while !self.at_end() && self.peek() != "}" {
            while self.matches(";") {}
            if self.peek() == "}" {
                break;
            }
            if self.matches("hook") {
                let hook = self.parse_name();
                if hook != "ingress" {
                    return Err(format!("unknown hook '{}'", hook));
                }
                cmd.flowtable_spec.hook = hook;
                cmd.flowtable_spec.has_hook = true;
                if !self.matches("priority") {
                    return Err("missing flowtable priority".into());
                }
                cmd.flowtable_spec.priority = self.parse_flowtable_priority(cmd.family)?;
                cmd.flowtable_spec.has_priority = true;
                self.matches(";");
                continue;
            }
            if self.matches("devices") {
                self.matches("=");
                cmd.flowtable_spec.devices = self.parse_flowtable_devices()?;
                self.matches(";");
                continue;
            }
            if self.matches("counter") {
                cmd.flowtable_spec.flags |= NFT_FLOWTABLE_COUNTER;
                self.matches(";");
                continue;
            }
            return Err(format!(
                "unexpected token '{}' in flowtable block",
                self.peek()
            ));
        }
        if !self.matches("}") {
            return Err("missing closing '}' in flowtable block".into());
        }
        if !cmd.flowtable_spec.has_hook || !cmd.flowtable_spec.has_priority {
            return Err("missing flowtable hook or priority".into());
        }
        Ok(())
    }

    fn parse_cmp_op(&mut self) -> u32 {
        match self.peek() {
            "==" | "=" | "eq" => {
                self.advance();
                NFT_CMP_EQ
            }
            "!=" | "ne" => {
                self.advance();
                NFT_CMP_NEQ
            }
            _ => NFT_CMP_EQ,
        }
    }

    fn parse_value(&mut self, data_len: usize) -> Vec<u8> {
        let tok = self.advance().to_string();

        // CT state bitmask - return as native endian bytes
        if matches!(
            tok.as_str(),
            "new" | "established" | "related" | "untracked" | "invalid"
        ) {
            let mut state = ct_state_val(&tok);
            while self.peek() == "," {
                self.advance();
                state |= ct_state_val(self.advance());
            }
            // For bitmask comparisons, kernel needs: bitwise(reg & mask) + cmp(result != 0)
            // We return the bitmask value and let parse_cmp_and_value handle the special case
            return state.to_ne_bytes().to_vec();
        }

        // Protocol name as value
        if let Some(proto) = proto_num(&tok) {
            return vec![proto];
        }

        // IPv4 with optional /prefix
        if let Some(slash) = tok.find('/') {
            if let Some(addr) = Self::parse_ipv4(&tok[..slash]) {
                return addr.to_vec(); // CIDR handled by caller
            }
        }
        if let Some(addr) = Self::parse_ipv4(&tok) {
            return addr.to_vec();
        }

        // Number (port, mark, etc). Accept hex (0x..), octal (0o.. / 0..),
        // and decimal. meta mark / ct mark routinely use hex.
        let parsed = Self::parse_numeric_token(&tok);
        if parsed.is_none()
            && tok.len() > 1
            && tok.starts_with('0')
            && tok.bytes().all(|b| b.is_ascii_digit())
        {
            return Vec::new();
        }
        if let Some(n) = parsed {
            if data_len == 1 {
                return vec![n as u8];
            }
            if data_len == 2 {
                return (n as u16).to_be_bytes().to_vec();
            }
            if data_len == 8 {
                return (n as u64).to_be_bytes().to_vec();
            }
            return (n as u32).to_be_bytes().to_vec();
        }

        // String value (interface name). Strip the surrounding quotes the
        // tokenizer preserved for unambiguous lookahead; the kernel wants
        // the raw bytes, not `"lo"`.
        let raw = if tok.starts_with('"') && tok.ends_with('"') && tok.len() >= 2 {
            &tok[1..tok.len() - 1]
        } else {
            tok.as_str()
        };
        let mut v = raw.as_bytes().to_vec();
        v.push(0);
        while v.len() < data_len {
            v.push(0);
        }
        v
    }

    fn parse_scalar_token(cmd: &Command, tok: &str, data_len: usize) -> Option<Vec<u8>> {
        if data_len == 16 {
            if let Some(addr) = Self::parse_ipv6(tok) {
                return Some(addr.to_vec());
            }
        }
        if data_len == 2 {
            if let Some(Expr::Payload {
                base,
                offset,
                len,
                protocol,
                ..
            }) = cmd.exprs.last()
            {
                if *base == NFT_PAYLOAD_TRANSPORT_HEADER
                    && *len == 2
                    && (*offset == 0 || *offset == 2)
                    && (*protocol == 6 || *protocol == 17)
                {
                    if let Some(port) = service_num(tok) {
                        return Some(port.to_be_bytes().to_vec());
                    }
                }
            }
        }
        if data_len == 1 {
            match cmd.exprs.last() {
                Some(Expr::Meta { key, .. }) if *key == NFT_META_L4PROTO => {
                    if let Some(proto) = proto_num(tok) {
                        return Some(vec![proto]);
                    }
                }
                Some(Expr::Meta { key, .. }) if *key == NFT_META_NFPROTO => {
                    if let Some(proto) = nfproto_num(tok) {
                        return Some(vec![proto]);
                    }
                }
                Some(Expr::Payload {
                    base,
                    offset,
                    len,
                    protocol,
                    ..
                }) => {
                    if *base == NFT_PAYLOAD_TRANSPORT_HEADER && *len == 1 && *offset == 0 {
                        if *protocol == 58 {
                            if let Some(ty) = icmpv6_type_num(tok) {
                                return Some(vec![ty]);
                            }
                        } else if *protocol == 1 {
                            if let Some(ty) = icmp_type_num(tok) {
                                return Some(vec![ty]);
                            }
                        }
                    }
                }
                _ => {}
            }
        }
        None
    }

    fn parse_concat_selector(&mut self, cmd: &mut Command) -> Option<(u32, u32)> {
        if let Some((base, offset, len)) = self.parse_raw_payload_selector() {
            cmd.exprs.push(Expr::Payload {
                base,
                offset,
                len,
                protocol: 0,
                dreg: None,
            });
            return Some((4, len));
        }
        let tok = self.peek().to_string();
        if tok == "ip" {
            self.advance();
            let field = self.advance();
            let (offset, len) = match field {
                "saddr" => (12, 4),
                "daddr" => (16, 4),
                "protocol" => (9, 1),
                _ => return None,
            };
            cmd.exprs.push(Expr::Payload {
                base: NFT_PAYLOAD_NETWORK_HEADER,
                offset,
                len,
                protocol: 0,
                dreg: None,
            });
            return Some(Self::expr_key_type(cmd.exprs.last().unwrap()).unwrap());
        }
        if tok == "ip6" {
            self.advance();
            let field = self.advance();
            let (offset, len) = match field {
                "saddr" => (8, 16),
                "daddr" => (24, 16),
                "nexthdr" => (6, 1),
                _ => return None,
            };
            cmd.exprs.push(Expr::Payload {
                base: NFT_PAYLOAD_NETWORK_HEADER,
                offset,
                len,
                protocol: 0,
                dreg: None,
            });
            return Some(Self::expr_key_type(cmd.exprs.last().unwrap()).unwrap());
        }
        if tok == "meta" {
            self.advance();
            let key_str = self.advance().to_string();
            let Some((key, vlen)) = meta_key(&key_str) else {
                if self.error.is_none() {
                    self.error = Some(format!("unknown meta key '{}'", key_str));
                }
                return None;
            };
            cmd.exprs.push(Expr::Meta {
                key,
                width: vlen,
                dreg: None,
            });
            return Some(Self::expr_key_type(cmd.exprs.last().unwrap()).unwrap());
        }
        if tok == "iifname" || tok == "oifname" || tok == "iif" || tok == "oif" {
            self.advance();
            let (key, vlen) = meta_key(&tok).expect("known meta alias");
            cmd.exprs.push(Expr::Meta {
                key,
                width: vlen,
                dreg: None,
            });
            return Some(Self::expr_key_type(cmd.exprs.last().unwrap()).unwrap());
        }
        if tok == "tcp" || tok == "udp" || tok == "icmp" || tok == "icmpv6" {
            let proto_name = tok.clone();
            let proto_num: u8 = match proto_name.as_str() {
                "tcp" => 6,
                "udp" => 17,
                "icmp" => 1,
                "icmpv6" => 58,
                _ => return None,
            };
            self.advance();
            let field = self.advance();
            let (offset, len) = match (proto_name.as_str(), field) {
                ("tcp", "sport") | ("udp", "sport") => (0, 2),
                ("tcp", "dport") | ("udp", "dport") => (2, 2),
                ("icmp", "type") | ("icmpv6", "type") => (0, 1),
                ("icmp", "code") | ("icmpv6", "code") => (1, 1),
                _ => return None,
            };
            if Self::has_conflicting_proto_dependency(&cmd.exprs, proto_num) {
                if self.error.is_none() {
                    self.error = Some(format!(
                        "conflicting protocol dependency for {}",
                        proto_name
                    ));
                }
                return None;
            }
            let has_proto_match =
                Self::has_proto_dependency(&cmd.exprs) || cmd.family != NFPROTO_INET;
            if !has_proto_match {
                cmd.exprs.push(Expr::Meta {
                    key: NFT_META_L4PROTO,
                    width: 1,
                    dreg: None,
                });
                cmd.exprs.push(Expr::Cmp {
                    op: NFT_CMP_EQ,
                    data: vec![proto_num],
                });
            }
            cmd.exprs.push(Expr::Payload {
                base: NFT_PAYLOAD_TRANSPORT_HEADER,
                offset,
                len,
                protocol: proto_num,
                dreg: None,
            });
            return Some(Self::expr_key_type(cmd.exprs.last().unwrap()).unwrap());
        }
        None
    }

    fn parse_rule_exprs(&mut self, cmd: &mut Command) {
        while !self.at_end() && self.peek() != ";" {
            let tok = self.peek().to_string();

            // Comment
            if tok == "comment" {
                self.advance();
                if !self.at_end() {
                    cmd.comment = self.parse_name();
                    cmd.has_comment = true;
                }
                continue;
            }

            // ip saddr/daddr/protocol
            if tok == "ip" {
                self.advance();
                let field = self.advance();
                let (base, offset, len) = match field {
                    "saddr" => (NFT_PAYLOAD_NETWORK_HEADER, 12u32, 4u32),
                    "daddr" => (NFT_PAYLOAD_NETWORK_HEADER, 16, 4),
                    "protocol" => (NFT_PAYLOAD_NETWORK_HEADER, 9, 1),
                    _ => {
                        continue;
                    }
                };
                cmd.exprs.push(Expr::Payload {
                    base,
                    offset,
                    len,
                    protocol: 0,
                    dreg: None,
                });
                self.parse_cmp_and_value(cmd, len as usize);
                continue;
            }

            // ip6
            if tok == "ip6" {
                self.advance();
                let field = self.advance();
                let (offset, len) = match field {
                    "saddr" => (8u32, 16u32),
                    "daddr" => (24, 16),
                    "nexthdr" => (6, 1),
                    "hoplimit" => (7, 1),
                    _ => {
                        continue;
                    }
                };
                cmd.exprs.push(Expr::Payload {
                    base: NFT_PAYLOAD_NETWORK_HEADER,
                    offset,
                    len,
                    protocol: 0,
                    dreg: None,
                });
                self.parse_cmp_and_value(cmd, len as usize);
                continue;
            }

            if tok == "th" {
                self.advance();
                let field = self.advance();
                let (offset, len) = match field {
                    "sport" => (0u32, 2u32),
                    "dport" => (2, 2),
                    _ => {
                        continue;
                    }
                };
                cmd.exprs.push(Expr::Payload {
                    base: NFT_PAYLOAD_TRANSPORT_HEADER,
                    offset,
                    len,
                    protocol: 0,
                    dreg: None,
                });
                self.parse_cmp_and_value(cmd, len as usize);
                continue;
            }

            // tcp / udp / icmp: real nft injects an implicit
            // `meta l4proto ==` match so the kernel reads the
            // transport header only after it's confirmed the
            // packet is of the expected protocol. Without it
            // the listing decoder can't tell tcp sport apart
            // from udp sport (both are transport offset 0, len
            // 2) and defaults to `tcp` for every case.
            if tok == "tcp" || tok == "udp" || tok == "icmp" || tok == "icmpv6" {
                let proto_name = tok.clone();
                let proto_num: u8 = match proto_name.as_str() {
                    "tcp" => 6,
                    "udp" => 17,
                    "icmp" => 1,
                    "icmpv6" => 58,
                    _ => unreachable!(),
                };
                self.advance();
                if proto_name == "tcp" && self.peek() == "option" {
                    self.advance();
                    let option = self.advance().to_string();
                    let field = self.advance().to_string();
                    let (raw_type, offset, len, op, flags) = match (option.as_str(), field.as_str())
                    {
                        ("maxseg", "size") => {
                            (TCPOPT_MAXSEG, 2u32, 2u32, NFT_EXTHDR_OP_TCPOPT, 0u32)
                        }
                        _ => {
                            continue;
                        }
                    };
                    if Self::has_conflicting_proto_dependency(&cmd.exprs, proto_num) {
                        if self.error.is_none() {
                            self.error = Some(format!(
                                "conflicting protocol dependency for {}",
                                proto_name
                            ));
                        }
                        return;
                    }
                    let has_proto_match = Self::has_proto_dependency(&cmd.exprs);
                    if !has_proto_match {
                        cmd.exprs.push(Expr::Meta {
                            key: NFT_META_L4PROTO,
                            width: 1,
                            dreg: None,
                        });
                        cmd.exprs.push(Expr::Cmp {
                            op: NFT_CMP_EQ,
                            data: vec![proto_num],
                        });
                    }
                    cmd.exprs.push(Expr::Exthdr {
                        raw_type,
                        offset,
                        len,
                        op,
                        flags,
                        dreg: None,
                        sreg: None,
                    });
                    self.parse_cmp_and_value(cmd, len as usize);
                    continue;
                }
                let field = self.advance();
                let (offset, len) = match (proto_name.as_str(), field) {
                    ("tcp", "sport") => (0u32, 2u32),
                    ("tcp", "dport") => (2, 2),
                    ("tcp", "flags") => (13, 1),
                    ("udp", "sport") => (0, 2),
                    ("udp", "dport") => (2, 2),
                    ("udp", "length") => (4, 2),
                    ("icmp", "type") => (0, 1),
                    ("icmp", "code") => (1, 1),
                    ("icmpv6", "type") => (0, 1),
                    ("icmpv6", "code") => (1, 1),
                    _ => {
                        continue;
                    }
                };
                if Self::has_conflicting_proto_dependency(&cmd.exprs, proto_num) {
                    if self.error.is_none() {
                        self.error = Some(format!(
                            "conflicting protocol dependency for {}",
                            proto_name
                        ));
                    }
                    return;
                }
                // Only inject the dependency if we haven't already
                // seen an equivalent match earlier in this rule
                // (user-written `meta l4proto tcp` / `ip protocol tcp`).
                let has_proto_match = Self::has_proto_dependency(&cmd.exprs);
                if !has_proto_match {
                    cmd.exprs.push(Expr::Meta {
                        key: NFT_META_L4PROTO,
                        width: 1,
                        dreg: None,
                    });
                    cmd.exprs.push(Expr::Cmp {
                        op: NFT_CMP_EQ,
                        data: vec![proto_num],
                    });
                }
                cmd.exprs.push(Expr::Payload {
                    base: NFT_PAYLOAD_TRANSPORT_HEADER,
                    offset,
                    len,
                    protocol: proto_num,
                    dreg: None,
                });
                if proto_name == "tcp" && field == "flags" {
                    if self.matches("&") {
                        let Some(mask) = self.parse_tcp_flag_mask() else {
                            if self.error.is_none() {
                                self.error = Some("invalid tcp flags mask".into());
                            }
                            return;
                        };
                        let op = self.parse_cmp_op();
                        let Some(value) = self.parse_tcp_flag_mask() else {
                            if self.error.is_none() {
                                self.error = Some("invalid tcp flags value".into());
                            }
                            return;
                        };
                        cmd.exprs.push(Expr::Bitwise {
                            mask: vec![mask],
                            xor: vec![0],
                        });
                        cmd.exprs.push(Expr::Cmp {
                            op,
                            data: vec![value],
                        });
                    } else if let Some(value) = self.parse_tcp_flag_mask() {
                        let op = self.parse_cmp_op();
                        cmd.exprs.push(Expr::Cmp {
                            op,
                            data: vec![value],
                        });
                    } else {
                        self.parse_cmp_and_value(cmd, len as usize);
                    }
                    continue;
                }
                self.parse_cmp_and_value(cmd, len as usize);
                continue;
            }

            if tok == "rt" {
                self.advance();
                let next = self.advance().to_string();
                match next.as_str() {
                    "type" => {
                        if cmd.family == NFPROTO_INET {
                            if Self::has_conflicting_nfproto_dependency(&cmd.exprs, NFPROTO_IPV6) {
                                if self.error.is_none() {
                                    self.error =
                                        Some("conflicting family dependency for rt type".into());
                                }
                                return;
                            }
                            if !Self::has_nfproto_dependency(&cmd.exprs, NFPROTO_IPV6) {
                                cmd.exprs.push(Expr::Meta {
                                    key: NFT_META_NFPROTO,
                                    width: 1,
                                    dreg: None,
                                });
                                cmd.exprs.push(Expr::Cmp {
                                    op: NFT_CMP_EQ,
                                    data: vec![NFPROTO_IPV6],
                                });
                            }
                        }
                        cmd.exprs.push(Expr::Exthdr {
                            raw_type: IPPROTO_ROUTING,
                            offset: 2,
                            len: 1,
                            op: NFT_EXTHDR_OP_IPV6,
                            flags: 0,
                            dreg: None,
                            sreg: None,
                        });
                        self.parse_cmp_and_value(cmd, 1);
                    }
                    "ip" => {
                        if !self.matches("nexthop") {
                            continue;
                        }
                        if cmd.family == NFPROTO_INET {
                            if Self::has_conflicting_nfproto_dependency(&cmd.exprs, NFPROTO_IPV4) {
                                if self.error.is_none() {
                                    self.error = Some(
                                        "conflicting family dependency for rt ip nexthop".into(),
                                    );
                                }
                                return;
                            }
                            if !Self::has_nfproto_dependency(&cmd.exprs, NFPROTO_IPV4) {
                                cmd.exprs.push(Expr::Meta {
                                    key: NFT_META_NFPROTO,
                                    width: 1,
                                    dreg: None,
                                });
                                cmd.exprs.push(Expr::Cmp {
                                    op: NFT_CMP_EQ,
                                    data: vec![NFPROTO_IPV4],
                                });
                            }
                        }
                        cmd.exprs.push(Expr::Rt {
                            key: NFT_RT_NEXTHOP4,
                            width: 4,
                            dreg: None,
                        });
                        self.parse_cmp_and_value(cmd, 4);
                    }
                    "ip6" => {
                        if !self.matches("nexthop") {
                            continue;
                        }
                        if cmd.family == NFPROTO_INET {
                            if Self::has_conflicting_nfproto_dependency(&cmd.exprs, NFPROTO_IPV6) {
                                if self.error.is_none() {
                                    self.error = Some(
                                        "conflicting family dependency for rt ip6 nexthop".into(),
                                    );
                                }
                                return;
                            }
                            if !Self::has_nfproto_dependency(&cmd.exprs, NFPROTO_IPV6) {
                                cmd.exprs.push(Expr::Meta {
                                    key: NFT_META_NFPROTO,
                                    width: 1,
                                    dreg: None,
                                });
                                cmd.exprs.push(Expr::Cmp {
                                    op: NFT_CMP_EQ,
                                    data: vec![NFPROTO_IPV6],
                                });
                            }
                        }
                        cmd.exprs.push(Expr::Rt {
                            key: NFT_RT_NEXTHOP6,
                            width: 16,
                            dreg: None,
                        });
                        self.parse_cmp_and_value(cmd, 16);
                    }
                    "classid" => {
                        cmd.exprs.push(Expr::Rt {
                            key: NFT_RT_CLASSID,
                            width: 4,
                            dreg: None,
                        });
                        self.parse_cmp_and_value(cmd, 4);
                    }
                    "mtu" => {
                        cmd.exprs.push(Expr::Rt {
                            key: NFT_RT_TCPMSS,
                            width: 2,
                            dreg: None,
                        });
                        self.parse_cmp_and_value(cmd, 2);
                    }
                    "ipsec" => {
                        cmd.exprs.push(Expr::Rt {
                            key: NFT_RT_XFRM,
                            width: 1,
                            dreg: None,
                        });
                        self.parse_cmp_and_value(cmd, 1);
                    }
                    _ => {}
                }
                continue;
            }

            if tok.starts_with('@') {
                let Some((base, offset, len)) = self.parse_raw_payload_selector() else {
                    if self.error.is_none() {
                        self.error = Some(format!("invalid raw payload selector '{}'", tok));
                    }
                    return;
                };
                cmd.exprs.push(Expr::Payload {
                    base,
                    offset,
                    len,
                    protocol: 0,
                    dreg: None,
                });
                self.parse_cmp_and_value(cmd, len as usize);
                continue;
            }

            // ether
            if tok == "ether" {
                self.advance();
                let field = self.advance();
                let (offset, len) = match field {
                    "saddr" => (6u32, 6u32),
                    "daddr" => (0, 6),
                    "type" => (12, 2),
                    _ => {
                        continue;
                    }
                };
                cmd.exprs.push(Expr::Payload {
                    base: NFT_PAYLOAD_LL_HEADER,
                    offset,
                    len,
                    protocol: 0,
                    dreg: None,
                });
                self.parse_cmp_and_value(cmd, len as usize);
                continue;
            }

            // meta
            if tok == "meta" {
                self.advance();
                let key_str = self.advance().to_string();
                let Some((key, vlen)) = meta_key(&key_str) else {
                    if self.error.is_none() {
                        self.error = Some(format!("unknown meta key '{}'", key_str));
                    }
                    return;
                };
                cmd.exprs.push(Expr::Meta {
                    key,
                    width: vlen,
                    dreg: None,
                });
                if !self.at_end() && self.peek() != ";" {
                    if key == NFT_META_NFPROTO {
                        let save_pos = self.pos;
                        let op = self.parse_cmp_op();
                        if let Some(proto) = nfproto_num(self.peek()) {
                            self.advance();
                            cmd.exprs.push(Expr::Cmp {
                                op,
                                data: vec![proto],
                            });
                        } else if !is_statement_start(self.peek()) {
                            self.pos = save_pos;
                            self.parse_cmp_and_value(cmd, vlen);
                        }
                    } else if matches!(key, NFT_META_L4PROTO | NFT_META_PROTOCOL) {
                        let save_pos = self.pos;
                        let op = self.parse_cmp_op();
                        if let Some(proto) = proto_num(self.peek()) {
                            self.advance();
                            cmd.exprs.push(Expr::Cmp {
                                op,
                                data: vec![proto],
                            });
                        } else if !is_statement_start(self.peek()) {
                            self.pos = save_pos;
                            self.parse_cmp_and_value(cmd, vlen);
                        }
                    } else if !is_statement_start(self.peek()) {
                        self.parse_cmp_and_value(cmd, vlen);
                    }
                }
                continue;
            }

            // iifname/oifname without meta prefix
            if tok == "iifname" || tok == "oifname" {
                self.advance();
                let key = if tok == "iifname" {
                    NFT_META_IIFNAME
                } else {
                    NFT_META_OIFNAME
                };
                cmd.exprs.push(Expr::Meta {
                    key,
                    width: 16,
                    dreg: None,
                });
                self.parse_cmp_and_value(cmd, 16);
                continue;
            }
            if tok == "iif" || tok == "oif" {
                self.advance();
                let key = if tok == "iif" {
                    NFT_META_IIF
                } else {
                    NFT_META_OIF
                };
                cmd.exprs.push(Expr::Meta {
                    key,
                    width: 4,
                    dreg: None,
                });
                self.parse_cmp_and_value(cmd, 4);
                continue;
            }

            // ct
            if tok == "ct" {
                self.advance();
                if self.peek() == "timeout" || self.peek() == "expectation" {
                    let kind = if self.peek() == "timeout" {
                        NFT_OBJECT_CT_TIMEOUT
                    } else {
                        NFT_OBJECT_CT_EXPECT
                    };
                    self.advance();
                    if !self.matches("set") {
                        if self.error.is_none() {
                            self.error = Some(format!(
                                "expected 'set' after ct {}",
                                if kind == NFT_OBJECT_CT_TIMEOUT {
                                    "timeout"
                                } else {
                                    "expectation"
                                }
                            ));
                        }
                        return;
                    }
                    let name = self.parse_name();
                    cmd.exprs.push(Expr::ObjRef { kind, name });
                    continue;
                }
                let mut dir: i8 = -1;
                if self.peek() == "original" {
                    self.advance();
                    dir = 0;
                } else if self.peek() == "reply" {
                    self.advance();
                    dir = 1;
                }
                let key_str = self.advance().to_string();
                let Some((key, vlen)) = ct_key(&key_str) else {
                    if self.error.is_none() {
                        self.error = Some(format!("unknown ct key '{}'", key_str));
                    }
                    return;
                };
                cmd.exprs.push(Expr::Ct {
                    key,
                    dir,
                    width: vlen,
                    dreg: None,
                });

                if !self.at_end() && !is_statement_start(self.peek()) && self.peek() != ";" {
                    if key == NFT_CT_STATE
                        && (self.peek() == "vmap"
                            || self.peek() == "{"
                            || self.peek().starts_with('@'))
                    {
                        self.parse_cmp_and_value(cmd, vlen);
                    } else if key == NFT_CT_STATE {
                        // ct state uses bitmask matching:
                        //   `ct state X`   → bitwise + cmp(NEQ, 0)
                        //     — reg & mask != 0, i.e. any bit present
                        //   `ct state != X` → bitwise + cmp(EQ, 0)
                        //     — reg & mask == 0, i.e. no bit present
                        let op = self.parse_cmp_op();
                        let mask_bytes = self.parse_value(vlen);
                        let zeros = vec![0u8; mask_bytes.len()];
                        cmd.exprs.push(Expr::Bitwise {
                            mask: mask_bytes,
                            xor: zeros.clone(),
                        });
                        let cmp_op = if op == NFT_CMP_NEQ {
                            NFT_CMP_EQ
                        } else {
                            NFT_CMP_NEQ
                        };
                        cmd.exprs.push(Expr::Cmp {
                            op: cmp_op,
                            data: zeros,
                        });
                    } else {
                        self.parse_cmp_and_value(cmd, vlen);
                    }
                }
                continue;
            }

            // fib
            if tok == "fib" {
                self.advance();
                let mut fib_flags = 0u32;
                let mut fib_terms: Vec<String> = Vec::new();
                while matches!(
                    self.peek(),
                    "saddr" | "daddr" | "mark" | "iif" | "oif" | "oifname" | "type" | "check" | "."
                ) {
                    fib_terms.push(self.advance().to_string());
                }
                fib_terms.retain(|term| term != ".");
                if fib_terms.is_empty() {
                    if self.error.is_none() {
                        self.error = Some("missing fib result".into());
                    }
                    return;
                }

                let result_tok = fib_terms.pop().unwrap_or_default();
                for term in fib_terms {
                    match term.as_str() {
                        "saddr" => fib_flags |= NFTA_FIB_F_SADDR,
                        "daddr" => fib_flags |= NFTA_FIB_F_DADDR,
                        "mark" => fib_flags |= NFTA_FIB_F_MARK,
                        "iif" => fib_flags |= NFTA_FIB_F_IIF,
                        "oif" => fib_flags |= NFTA_FIB_F_OIF,
                        _ => {
                            if self.error.is_none() {
                                self.error = Some(format!("invalid fib flag '{}'", term));
                            }
                            return;
                        }
                    }
                }

                let (result, width) = match result_tok.as_str() {
                    "oif" => (NFT_FIB_RESULT_OIF, 4usize),
                    "oifname" => (NFT_FIB_RESULT_OIFNAME, 16usize),
                    "type" => (NFT_FIB_RESULT_ADDRTYPE, 4usize),
                    "check" => {
                        fib_flags |= NFTA_FIB_F_PRESENT;
                        (NFT_FIB_RESULT_OIF, 1usize)
                    }
                    _ => continue,
                };
                if result == NFT_FIB_RESULT_ADDRTYPE && fib_flags & NFTA_FIB_F_OIF != 0 {
                    return;
                }
                cmd.exprs.push(Expr::Fib {
                    result,
                    flags: fib_flags,
                    width,
                    dreg: None,
                });
                if result_tok == "check" {
                    if self.matches("missing") {
                        cmd.exprs.push(Expr::Cmp {
                            op: NFT_CMP_EQ,
                            data: vec![0],
                        });
                    } else if self.matches("exists") {
                        cmd.exprs.push(Expr::Cmp {
                            op: NFT_CMP_EQ,
                            data: vec![1],
                        });
                    }
                } else if !self.at_end() && !is_statement_start(self.peek()) && self.peek() != ";" {
                    self.parse_cmp_and_value(cmd, width);
                }
                continue;
            }

            if tok == "add" || tok == "update" {
                let op = if tok == "add" {
                    NFT_DYNSET_OP_ADD
                } else {
                    NFT_DYNSET_OP_UPDATE
                };
                if self.parse_dynset_stmt(cmd, op) {
                    continue;
                }
            }

            if tok == "queue" {
                if self.parse_queue_stmt(cmd) {
                    continue;
                }
            }

            if tok == "flow" {
                if self.parse_flow_stmt(cmd) {
                    continue;
                }
            }

            if tok == "tproxy" {
                if self.parse_tproxy_stmt(cmd) {
                    continue;
                }
            }

            if tok == "synproxy" && self.peek_offset(1) == "name" {
                let mut idx = self.pos + 2;
                while idx < self.tokens.len() {
                    let probe = self.tokens[idx].as_str();
                    if probe == ";" || probe == "}" {
                        break;
                    }
                    if probe.starts_with('"') && probe.ends_with('"') && probe.contains('*') {
                        self.error = Some(format!("invalid synproxy object map value '{}'", probe));
                        return;
                    }
                    idx += 1;
                }
            }

            // Verdicts
            if tok == "accept" {
                self.advance();
                cmd.exprs.push(Expr::Verdict {
                    code: NF_ACCEPT,
                    chain: String::new(),
                });
                continue;
            }
            if tok == "drop" {
                self.advance();
                cmd.exprs.push(Expr::Verdict {
                    code: NF_DROP,
                    chain: String::new(),
                });
                continue;
            }
            if tok == "return" {
                self.advance();
                cmd.exprs.push(Expr::Verdict {
                    code: NFT_RETURN,
                    chain: String::new(),
                });
                continue;
            }
            if tok == "jump" || tok == "goto" {
                let code = if tok == "jump" { NFT_JUMP } else { NFT_GOTO };
                self.advance();
                if self.peek() == "{" {
                    match self.parse_bound_chain_body(cmd) {
                        Ok(bound) => {
                            let name = bound.name.clone();
                            cmd.bound_chains.push(bound);
                            cmd.exprs.push(Expr::Verdict { code, chain: name });
                        }
                        Err(err) => {
                            if self.error.is_none() {
                                self.error = Some(err);
                            }
                            return;
                        }
                    }
                } else {
                    let c = self.parse_name();
                    cmd.exprs.push(Expr::Verdict { code, chain: c });
                }
                continue;
            }
            if tok == "continue" {
                self.advance();
                cmd.exprs.push(Expr::Verdict {
                    code: NFT_CONTINUE,
                    chain: String::new(),
                });
                continue;
            }

            // Counter
            if tok == "counter" {
                self.advance();
                // `counter name "x"` → reference a named counter object
                // (objref expression). Bare `counter` is the per-rule
                // anonymous counter.
                if self.peek() == "name" {
                    self.advance();
                    let n = self.parse_name();
                    cmd.exprs.push(Expr::ObjRef {
                        kind: NFT_OBJECT_COUNTER,
                        name: n,
                    });
                    if !self.at_end()
                        && self.peek() != ";"
                        && self.peek() != "}"
                        && !is_statement_start(self.peek())
                    {
                        if self.error.is_none() {
                            self.error = Some(format!(
                                "unexpected token '{}' after counter name",
                                self.peek()
                            ));
                        }
                        return;
                    }
                } else {
                    cmd.exprs.push(self.parse_counter_expr());
                }
                continue;
            }
            if tok == "quota" && self.peek_offset(1) == "name" {
                self.advance();
                self.advance();
                let n = self.parse_name();
                cmd.exprs.push(Expr::ObjRef {
                    kind: NFT_OBJECT_QUOTA,
                    name: n,
                });
                if !self.at_end()
                    && self.peek() != ";"
                    && self.peek() != "}"
                    && !is_statement_start(self.peek())
                {
                    if self.error.is_none() {
                        self.error = Some(format!(
                            "unexpected token '{}' after quota name",
                            self.peek()
                        ));
                    }
                    return;
                }
                continue;
            }
            if tok == "limit" && self.peek_offset(1) == "name" {
                self.advance();
                self.advance();
                let n = self.parse_name();
                cmd.exprs.push(Expr::ObjRef {
                    kind: NFT_OBJECT_LIMIT,
                    name: n,
                });
                if !self.at_end()
                    && self.peek() != ";"
                    && self.peek() != "}"
                    && !is_statement_start(self.peek())
                {
                    if self.error.is_none() {
                        self.error = Some(format!(
                            "unexpected token '{}' after limit name",
                            self.peek()
                        ));
                    }
                    return;
                }
                continue;
            }

            // Log
            if tok == "log" {
                self.advance();
                let mut prefix = String::new();
                let mut level = None;
                let mut flags = 0u32;
                loop {
                    match self.peek() {
                        "prefix" => {
                            self.advance();
                            prefix = self.parse_name();
                        }
                        "level" => {
                            self.advance();
                            level = log_level(self.advance());
                        }
                        "flags" => {
                            self.advance();
                            if self.peek() == "all" {
                                self.advance();
                                flags |= NF_LOG_MASK;
                                continue;
                            }
                            loop {
                                match (self.peek(), self.peek_offset(1)) {
                                    ("tcp", "sequence") => {
                                        self.advance();
                                        self.advance();
                                        flags |= NF_LOG_TCPSEQ;
                                    }
                                    ("tcp", "options") => {
                                        self.advance();
                                        self.advance();
                                        flags |= NF_LOG_TCPOPT;
                                    }
                                    ("ip", "options") => {
                                        self.advance();
                                        self.advance();
                                        flags |= NF_LOG_IPOPT;
                                    }
                                    ("skuid", _) => {
                                        self.advance();
                                        flags |= NF_LOG_UID;
                                    }
                                    ("ether", _) => {
                                        self.advance();
                                        flags |= NF_LOG_MACDECODE;
                                    }
                                    _ => break,
                                }
                                if self.peek() == "," {
                                    self.advance();
                                }
                            }
                        }
                        _ => break,
                    }
                }
                cmd.exprs.push(Expr::Log {
                    prefix,
                    level,
                    flags,
                });
                continue;
            }

            // Limit
            if tok == "limit" {
                self.advance();
                cmd.exprs.push(self.parse_limit_expr());
                continue;
            }

            // NAT
            if tok == "masquerade" {
                self.advance();
                cmd.exprs.push(Expr::Masquerade);
                continue;
            }
            if tok == "snat" || tok == "dnat" {
                let nat_type = if tok == "snat" {
                    NFT_NAT_SNAT
                } else {
                    NFT_NAT_DNAT
                };
                if !self.parse_nat_stmt(cmd, nat_type) {
                    return;
                }
                continue;
            }

            // Notrack / Reject
            if tok == "notrack" {
                self.advance();
                cmd.exprs.push(Expr::Notrack);
                continue;
            }
            if tok == "reject" {
                self.advance();
                let (mut rej_type, mut icmp_code) = match cmd.family {
                    NFPROTO_IPV4 => (NFT_REJECT_ICMP_UNREACH, Some(ICMP_PORT_UNREACH)),
                    NFPROTO_IPV6 => (NFT_REJECT_ICMP_UNREACH, Some(ICMP6_DST_UNREACH_NOPORT)),
                    _ => (
                        NFT_REJECT_ICMPX_UNREACH,
                        Some(NFT_REJECT_ICMPX_PORT_UNREACH),
                    ),
                };
                if self.matches("with") {
                    if self.matches("tcp") {
                        self.matches("reset");
                        rej_type = NFT_REJECT_TCP_RST;
                        icmp_code = None;
                    } else if self.matches("icmpx") {
                        self.matches("type");
                        if let Some(code) = reject_icmpx_code(self.peek())
                            .or_else(|| self.peek().parse::<u8>().ok())
                        {
                            self.advance();
                            rej_type = NFT_REJECT_ICMPX_UNREACH;
                            icmp_code = Some(code);
                        }
                    }
                }
                cmd.exprs.push(Expr::Reject {
                    rej_type,
                    icmp_code,
                });
                continue;
            }

            // Unknown - skip
            self.advance();
        }
    }

    fn parse_cmp_and_value(&mut self, cmd: &mut Command, data_len: usize) {
        if self.at_end() || self.peek() == ";" {
            return;
        }
        let known_scalar_type = cmd.exprs.last().and_then(Self::expr_key_type);

        if self.peek() == "set" {
            if let Some(Expr::Payload {
                base,
                offset,
                len,
                protocol,
                dreg,
            }) = cmd.exprs.last().cloned()
            {
                let save_pos = self.pos;
                let save_expr_len = cmd.exprs.len();
                cmd.exprs.pop();
                if self.parse_set_stmt(cmd, base, offset, len) {
                    return;
                }
                self.pos = save_pos;
                cmd.exprs.truncate(save_expr_len - 1);
                cmd.exprs.push(Expr::Payload {
                    base,
                    offset,
                    len,
                    protocol,
                    dreg,
                });
            }
            if let Some(Expr::Exthdr {
                raw_type,
                offset,
                len,
                op,
                flags,
                dreg,
                sreg,
            }) = cmd.exprs.last().cloned()
            {
                let save_pos = self.pos;
                let save_expr_len = cmd.exprs.len();
                cmd.exprs.pop();
                if self.parse_exthdr_set_stmt(cmd, raw_type, offset, len, op, flags) {
                    return;
                }
                self.pos = save_pos;
                cmd.exprs.truncate(save_expr_len - 1);
                cmd.exprs.push(Expr::Exthdr {
                    raw_type,
                    offset,
                    len,
                    op,
                    flags,
                    dreg,
                    sreg,
                });
            }
            if self.error.is_none() {
                self.error = Some("invalid set statement".into());
            }
            return;
        }

        if self.peek() == "." {
            let Some((first_ty, first_len)) = cmd.exprs.last().and_then(Self::expr_key_type) else {
                return;
            };
            let mut field_types = vec![first_ty];
            let mut field_lens = vec![first_len as u8];
            while self.peek() == "." {
                self.advance();
                let Some((ty, len)) = self.parse_concat_selector(cmd) else {
                    if self.error.is_none() {
                        self.error = Some(format!("invalid concat selector '{}'", self.peek()));
                    }
                    return;
                };
                field_types.push(ty);
                field_lens.push(len as u8);
            }
            let key_type = field_types
                .iter()
                .copied()
                .reduce(crate::netlink::concat_type_add);
            let width: usize = field_lens
                .iter()
                .map(|len| crate::netlink::padded_key_len(*len as u32) as usize)
                .sum();

            if self.peek() == "vmap" {
                self.advance();
                if self.peek().starts_with('@') {
                    let tok = self.advance().to_string();
                    let set_name = tok.trim_start_matches('@').to_string();
                    cmd.exprs.push(Expr::Vmap {
                        set_name,
                        width,
                        set_id: None,
                        key_type,
                    });
                    return;
                }
                if self.peek() == "{" {
                    self.advance();
                    let mut pairs: Vec<(Vec<u8>, Option<Vec<u8>>, i32, String)> = Vec::new();
                    while !self.at_end() && self.peek() != "}" {
                        if self.peek() == "," || self.peek() == ";" {
                            self.advance();
                            continue;
                        }
                        let first_tok = self.advance().to_string();
                        let Some((key_start, key_end)) = self.parse_concat_interval_key(
                            first_tok.clone(),
                            &field_types,
                            &field_lens,
                        ) else {
                            if self.error.is_none() {
                                self.error = Some(format!("invalid vmap key '{}'", first_tok));
                            }
                            return;
                        };
                        self.matches(":");
                        let verdict_tok = self.advance().to_string();
                        let Some((code, cn)) = self.parse_verdict(verdict_tok.clone()) else {
                            if self.error.is_none() {
                                self.error =
                                    Some(format!("invalid vmap verdict '{}'", verdict_tok));
                            }
                            return;
                        };
                        pairs.push((key_start, key_end, code, cn));
                    }
                    self.matches("}");
                    cmd.exprs.push(Expr::AnonVmap {
                        pairs,
                        width,
                        key_type,
                    });
                    return;
                }
                return;
            }

            let op = self.parse_cmp_op();
            if self.peek().starts_with('@') {
                let tok = self.advance().to_string();
                let set_name = tok.trim_start_matches('@').to_string();
                let inverted = op == NFT_CMP_NEQ;
                cmd.exprs.push(Expr::Lookup {
                    set_name,
                    inverted,
                    width,
                    set_id: None,
                    key_type,
                });
                return;
            }
            if self.peek() == "{" {
                self.advance();
                let inverted = op == NFT_CMP_NEQ;
                let mut elements: Vec<(Vec<u8>, Option<Vec<u8>>)> = Vec::new();
                while !self.at_end() && self.peek() != "}" {
                    if self.peek() == "," || self.peek() == ";" {
                        self.advance();
                        continue;
                    }
                    let first_tok = self.advance().to_string();
                    if let Some((key_start, key_end)) =
                        self.parse_concat_interval_key(first_tok, &field_types, &field_lens)
                    {
                        elements.push((key_start, key_end));
                    }
                }
                self.matches("}");
                cmd.exprs.push(Expr::AnonSet {
                    elements,
                    width,
                    inverted,
                    key_type,
                });
                return;
            }
            return;
        }

        // `ip saddr vmap @m` and `ip saddr vmap { 1.1.1.1 : jump c2 }`
        // lower to a lookup with a DREG for the verdict output. For
        // now we only support the named-set form; anon vmap literals
        // are a future expansion.
        if self.peek() == "vmap" {
            self.advance();
            if self.peek().starts_with('@') {
                let tok = self.advance().to_string();
                let set_name = tok.trim_start_matches('@').to_string();
                cmd.exprs.push(Expr::Vmap {
                    set_name,
                    width: data_len,
                    set_id: None,
                    key_type: None,
                });
                return;
            }
            // Anonymous vmap literal: collect `k : verdict` pairs.
            if self.peek() == "{" {
                self.advance();
                let mut pairs: Vec<(Vec<u8>, Option<Vec<u8>>, i32, String)> = Vec::new();
                let parse_key = |tok: &str| -> Option<Vec<u8>> {
                    if let Some((ty, len)) = known_scalar_type {
                        if let Some(v) = Self::parse_typed_value_token(tok, ty, len) {
                            return Some(v);
                        }
                    }
                    if data_len == 4 {
                        Self::parse_ipv4(tok)
                            .map(|a| a.to_vec())
                            .or_else(|| tok.parse::<u32>().ok().map(|n| n.to_be_bytes().to_vec()))
                    } else if data_len == 16 {
                        Self::parse_ipv6(tok).map(|a| a.to_vec())
                    } else if data_len == 2 {
                        tok.parse::<u16>().ok().map(|n| n.to_be_bytes().to_vec())
                    } else if data_len == 1 {
                        tok.parse::<u8>().ok().map(|n| vec![n])
                    } else {
                        None
                    }
                };
                while !self.at_end() && self.peek() != "}" {
                    if self.peek() == "," || self.peek() == ";" {
                        self.advance();
                        continue;
                    }
                    let raw_tok = self.advance().to_string();
                    let compact_pair = Self::split_compact_pair(&raw_tok);
                    let tok = compact_pair
                        .as_ref()
                        .map(|(key, _)| key.clone())
                        .unwrap_or(raw_tok);
                    let Some(key_start) = parse_key(&tok) else {
                        if self.error.is_none() {
                            self.error = Some(format!("invalid vmap key '{}'", tok));
                        }
                        return;
                    };
                    let key_end = if compact_pair.is_none() && self.peek() == "-" {
                        self.advance();
                        parse_key(self.advance())
                    } else {
                        None
                    };
                    let verdict_tok = if let Some((_, value)) = compact_pair {
                        value
                    } else {
                        self.matches(":");
                        self.advance().to_string()
                    };
                    let (code, cn) = match self.parse_verdict(verdict_tok.clone()) {
                        Some(v) => v,
                        None => {
                            if self.error.is_none() {
                                self.error =
                                    Some(format!("invalid vmap verdict '{}'", verdict_tok));
                            }
                            return;
                        }
                    };
                    pairs.push((key_start, key_end, code, cn));
                }
                self.matches("}");
                cmd.exprs.push(Expr::AnonVmap {
                    pairs,
                    width: data_len,
                    key_type: known_scalar_type.map(|(ty, _)| ty),
                });
                return;
            }
            return;
        }

        let op = self.parse_cmp_op();

        // Named-set reference: `ip saddr @blocked drop`. Emits a
        // lookup expression that matches against the set referenced
        // by the preceding Meta / Payload load. NFT_CMP_NEQ becomes
        // the inverted flag on the lookup.
        if self.peek().starts_with('@') {
            let tok = self.advance().to_string();
            let set_name = tok.trim_start_matches('@').to_string();
            let inverted = op == NFT_CMP_NEQ;
            cmd.exprs.push(Expr::Lookup {
                set_name,
                inverted,
                width: data_len,
                set_id: None,
                key_type: None,
            });
            return;
        }

        // Check for set literal { ... } — an anonymous set. Previously
        // this lowered to multiple Expr::Cmp entries which the kernel
        // ANDed together (so `ip saddr { 1.1.1.1, 2.2.2.2 }` matched
        // nothing). Now we emit a single Expr::AnonSet and let
        // add_rule allocate a __setN, NEWSET it, populate elements,
        // and rewrite this into an Expr::Lookup.
        if self.peek() == "{" {
            self.advance();
            let inverted = op == NFT_CMP_NEQ;
            let mut elements: Vec<(Vec<u8>, Option<Vec<u8>>)> = Vec::new();
            while !self.at_end() && self.peek() != "}" {
                if self.peek() == "," || self.peek() == ";" {
                    self.advance();
                    continue;
                }
                let tok = self.advance().to_string();

                // CIDR: expand `1.1.1.0/24` / `2001:db8::/32` to an
                // inclusive [start, end] interval so anonymous set
                // lowering can feed the interval-set element path.
                if data_len == 4 {
                    if let Some((start, end)) = Self::ipv4_cidr_range(&tok) {
                        elements.push((start, Some(end)));
                        continue;
                    }
                } else if data_len == 16 {
                    if let Some((start, end)) = Self::ipv6_cidr_range(&tok) {
                        elements.push((start, Some(end)));
                        continue;
                    }
                }

                // Bare value plus optional `-` range tail. For 4-byte
                // fields the value may be an IPv4 address (`1.1.1.1`)
                // or an integer literal (`123`, `0x7b`) depending on
                // context — `meta mark`, `ct mark`, etc. use integer
                // form. Try address first, fall back to integer.
                let parse_scalar = |tok: &str| -> Option<Vec<u8>> {
                    if let Some((ty, len)) = known_scalar_type {
                        if let Some(v) = Self::parse_typed_value_token(tok, ty, len) {
                            return Some(v);
                        }
                    }
                    if let Some(v) = Self::parse_scalar_token(cmd, tok, data_len) {
                        return Some(v);
                    }
                    if data_len == 4 {
                        if let Some(a) = Self::parse_ipv4(tok) {
                            return Some(a.to_vec());
                        }
                        let n: Option<u32> = if let Some(s) = tok.strip_prefix("0x") {
                            u32::from_str_radix(s, 16).ok()
                        } else {
                            tok.parse::<u32>().ok()
                        };
                        n.map(|n| n.to_be_bytes().to_vec())
                    } else if data_len == 16 {
                        Self::parse_ipv6(tok).map(|a| a.to_vec())
                    } else if data_len == 2 {
                        tok.parse::<u16>().ok().map(|n| n.to_be_bytes().to_vec())
                    } else if data_len == 1 {
                        if let Some(s) = tok.strip_prefix("0x") {
                            u8::from_str_radix(s, 16).ok().map(|n| vec![n])
                        } else {
                            tok.parse::<u8>().ok().map(|n| vec![n])
                        }
                    } else {
                        tok.parse::<u32>().ok().map(|n| n.to_be_bytes().to_vec())
                    }
                };
                let start: Option<Vec<u8>> = parse_scalar(&tok);

                if let Some(s) = start {
                    let end = if self.peek() == "-" {
                        self.advance();
                        let end_tok = self.advance().to_string();
                        parse_scalar(&end_tok)
                    } else {
                        None
                    };
                    elements.push((s, end));
                    continue;
                }

                if self.error.is_none() {
                    self.error = Some(format!("invalid set element '{}'", tok));
                }
                return;
            }
            self.matches("}");
            cmd.exprs.push(Expr::AnonSet {
                elements,
                width: data_len,
                inverted,
                key_type: known_scalar_type.map(|(ty, _)| ty),
            });
            return;
        }

        // Check for CIDR
        let tok = self.peek().to_string();
        if let Some(slash) = tok.find('/') {
            if let Some(addr_bytes) = Self::parse_ipv4(&tok[..slash]) {
                let prefix_len: u32 = tok[slash + 1..].parse().unwrap_or(32);
                self.advance();

                // Generate bitwise mask
                let mut mask = [0u8; 4];
                for i in 0..prefix_len.min(32) {
                    mask[(i / 8) as usize] |= 1 << (7 - (i % 8));
                }
                let xor = [0u8; 4];
                let masked: Vec<u8> = addr_bytes
                    .iter()
                    .zip(mask.iter())
                    .map(|(a, m)| a & m)
                    .collect();

                cmd.exprs.push(Expr::Bitwise {
                    mask: mask.to_vec(),
                    xor: xor.to_vec(),
                });
                cmd.exprs.push(Expr::Cmp { op, data: masked });
                return;
            }
            if let Some(addr_bytes) = Self::parse_ipv6(&tok[..slash]) {
                let prefix_len: u32 = tok[slash + 1..].parse().unwrap_or(128);
                self.advance();

                let mut mask = [0u8; 16];
                for i in 0..prefix_len.min(128) {
                    mask[(i / 8) as usize] |= 1 << (7 - (i % 8));
                }
                let xor = [0u8; 16];
                let masked: Vec<u8> = addr_bytes
                    .iter()
                    .zip(mask.iter())
                    .map(|(a, m)| a & m)
                    .collect();

                cmd.exprs.push(Expr::Bitwise {
                    mask: mask.to_vec(),
                    xor: xor.to_vec(),
                });
                cmd.exprs.push(Expr::Cmp { op, data: masked });
                return;
            }
        }

        let parse_direct_scalar = |tok: &str| -> Option<Vec<u8>> {
            if let Some((ty, len)) = known_scalar_type {
                if let Some(v) = Self::parse_typed_value_token(tok, ty, len) {
                    return Some(v);
                }
            }
            if let Some(v) = Self::parse_scalar_token(cmd, tok, data_len) {
                return Some(v);
            }
            if data_len == 4 {
                if let Some(a) = Self::parse_ipv4(tok) {
                    return Some(a.to_vec());
                }
                let n: Option<u32> = if let Some(s) = tok.strip_prefix("0x") {
                    u32::from_str_radix(s, 16).ok()
                } else {
                    tok.parse::<u32>().ok()
                };
                n.map(|n| n.to_be_bytes().to_vec())
            } else if data_len == 16 {
                Self::parse_ipv6(tok).map(|a| a.to_vec())
            } else if data_len == 2 {
                tok.parse::<u16>().ok().map(|n| n.to_be_bytes().to_vec())
            } else if data_len == 1 {
                if let Some(s) = tok.strip_prefix("0x") {
                    u8::from_str_radix(s, 16).ok().map(|n| vec![n])
                } else {
                    tok.parse::<u8>().ok().map(|n| vec![n])
                }
            } else {
                tok.parse::<u32>().ok().map(|n| n.to_be_bytes().to_vec())
            }
        };

        if self.peek_offset(1) == "-" {
            let start_tok = self.peek().to_string();
            if let Some(start) = parse_direct_scalar(&start_tok) {
                let end_tok = self.peek_offset(2).to_string();
                if let Some(end) = parse_direct_scalar(&end_tok) {
                    self.advance();
                    self.advance();
                    self.advance();
                    cmd.exprs.push(Expr::AnonSet {
                        elements: vec![(start, Some(end))],
                        width: data_len,
                        inverted: op == NFT_CMP_NEQ,
                        key_type: None,
                    });
                    return;
                }
            }
        }

        if let Some((ty, len)) = known_scalar_type {
            if self.peek_offset(1) == "-" && (op == NFT_CMP_EQ || op == NFT_CMP_NEQ) {
                if let Some(start) = Self::parse_typed_value_token(self.peek(), ty, len) {
                    if let Some(end) = Self::parse_typed_value_token(self.peek_offset(2), ty, len) {
                        self.advance();
                        self.advance();
                        self.advance();
                        cmd.exprs.push(Expr::AnonSet {
                            elements: vec![(start, Some(end))],
                            width: len as usize,
                            inverted: op == NFT_CMP_NEQ,
                            key_type: Some(ty),
                        });
                        return;
                    }
                }
            }
            if let Some(data) = Self::parse_typed_value_token(self.peek(), ty, len) {
                self.advance();
                cmd.exprs.push(Expr::Cmp { op, data });
                return;
            }
        }

        if let Some(data) = Self::parse_scalar_token(cmd, self.peek(), data_len) {
            self.advance();
            cmd.exprs.push(Expr::Cmp { op, data });
            return;
        }

        let data = self.parse_value(data_len);
        cmd.exprs.push(Expr::Cmp { op, data });
    }

    fn parse_chain_block(&mut self, cmd: &mut Command) -> Result<(), String> {
        if !self.matches("{") {
            return Err(format!("expected '{{' after chain '{}'", cmd.chain));
        }
        while !self.at_end() && self.peek() != "}" {
            if self.matches("type") {
                cmd.chain_spec.is_base = true;
                cmd.chain_spec.chain_type = self.parse_name();
                if self.matches("hook") {
                    cmd.chain_spec.hook = self.parse_name();
                }
                if self.matches("device") {
                    cmd.chain_spec.device = self.parse_name();
                    if cmd.chain_spec.device.is_empty() {
                        return Err("device name must not be empty".into());
                    }
                    cmd.chain_spec.has_device = true;
                }
                if self.matches("priority") {
                    let ct = cmd.chain_spec.chain_type.clone();
                    let hk = cmd.chain_spec.hook.clone();
                    cmd.chain_spec.priority = self.parse_priority_ctx(cmd.family, &ct, &hk)?;
                    cmd.chain_spec.has_priority = true;
                }
                self.matches(";");
            } else if self.matches("policy") {
                let pol = self.parse_name();
                if pol != "accept" && pol != "drop" {
                    return Err(format!("unknown policy '{}'", pol));
                }
                if !cmd.chain_spec.is_base {
                    return Err("chain policy is only valid for base chains".into());
                }
                cmd.chain_spec.policy = pol;
                cmd.chain_spec.has_policy = true;
                self.matches(";");
            } else if self.matches(";") {
            } else {
                self.advance();
            }
        }
        self.matches("}");
        Ok(())
    }

    fn parse_set_block(&mut self, cmd: &mut Command) {
        if !self.matches("{") {
            return;
        }
        while !self.at_end() && self.peek() != "}" {
            if self.matches("type") {
                let type_tok = self.advance().to_string();
                if let Some((key, data)) = Self::split_compact_type_decl(&type_tok) {
                    Self::apply_set_key_fields(&mut cmd.set_spec, vec![key]);
                    cmd.set_spec.is_map = true;
                    Self::apply_set_data_fields(&mut cmd.set_spec, vec![data]);
                } else {
                    let key_fields = self.parse_type_fields(type_tok);
                    Self::apply_set_key_fields(&mut cmd.set_spec, key_fields);
                    if self.peek() == ":" {
                        self.advance();
                        cmd.set_spec.is_map = true;
                        let data_tok = self.advance().to_string();
                        let data_fields = self.parse_type_fields(data_tok);
                        Self::apply_set_data_fields(&mut cmd.set_spec, data_fields);
                    }
                }
                self.matches(";");
            } else if self.matches("typeof") {
                let Some(fields) = self.parse_typeof_selectors() else {
                    if self.error.is_none() {
                        self.error = Some(format!("invalid typeof selector '{}'", self.peek()));
                    }
                    return;
                };
                Self::apply_typeof_key_fields(&mut cmd.set_spec, fields);
                if self.peek() == ":" {
                    self.advance();
                    cmd.set_spec.is_map = true;
                    if self.matches("queue") {
                        cmd.set_spec.data_type_name = "queue".to_string();
                        cmd.set_spec.data_type = 4;
                        cmd.set_spec.data_len = 2;
                        cmd.set_spec.data_is_typeof = true;
                    } else {
                        let data_tok = self.advance().to_string();
                        let data_fields = self.parse_type_fields(data_tok);
                        Self::apply_set_data_fields(&mut cmd.set_spec, data_fields);
                        cmd.set_spec.data_is_typeof = true;
                    }
                }
                self.matches(";");
            } else if self.matches("flags") {
                cmd.set_spec.has_flags = true;
                while !self.at_end() && self.peek() != ";" {
                    match self.peek() {
                        "constant" => {
                            cmd.set_spec.flags |= 0x2;
                            self.advance();
                        }
                        "interval" => {
                            cmd.set_spec.flags |= 0x4;
                            self.advance();
                        }
                        "timeout" => {
                            cmd.set_spec.flags |= NFT_SET_TIMEOUT;
                            self.advance();
                        }
                        "dynamic" => {
                            cmd.set_spec.flags |= NFT_SET_EVAL;
                            self.advance();
                        }
                        "," => {
                            self.advance();
                        }
                        _ => {
                            self.advance();
                        }
                    }
                }
                self.matches(";");
            } else if self.matches("size") {
                cmd.set_spec.has_size = true;
                cmd.set_spec.size = Self::parse_numeric_token(self.advance()).unwrap_or(0) as u32;
                self.matches(";");
            } else if self.matches("auto-merge") {
                cmd.set_spec.auto_merge = true;
                self.matches(";");
            } else if self.matches(";") {
            } else {
                self.advance();
            }
        }
        self.matches("}");
    }

    fn parse_counter_expr(&mut self) -> Expr {
        let mut packets = 0u64;
        let mut bytes = 0u64;
        loop {
            match self.peek() {
                "packets" => {
                    self.advance();
                    packets = Self::parse_numeric_token(self.advance()).unwrap_or(0);
                }
                "bytes" => {
                    self.advance();
                    bytes = Self::parse_numeric_token(self.advance()).unwrap_or(0);
                }
                _ => break,
            }
        }
        Expr::Counter { packets, bytes }
    }

    fn parse_limit_expr(&mut self) -> Expr {
        self.matches("rate");
        let tok = self.advance().to_string();
        let (rate, unit) = if let Some(slash) = tok.find('/') {
            (
                Self::parse_numeric_token(&tok[..slash]).unwrap_or(0),
                limit_unit(&tok[slash + 1..]),
            )
        } else {
            let rate = Self::parse_numeric_token(&tok).unwrap_or(0);
            let unit = if self.peek() == "/" {
                self.advance();
                limit_unit(self.advance())
            } else {
                1
            };
            (rate, unit)
        };
        let burst = if self.matches("burst") {
            self.advance().parse().unwrap_or(5)
        } else {
            5
        };
        self.matches("packets");
        Expr::Limit { rate, unit, burst }
    }

    fn parse_nat_stmt(&mut self, cmd: &mut Command, nat_type: u32) -> bool {
        let nat_name = if nat_type == NFT_NAT_SNAT {
            "snat"
        } else {
            "dnat"
        };
        self.advance();

        let mut family = cmd.family;
        let mut family_explicit = false;
        if matches!(self.peek(), "ip" | "ip6") {
            family = if self.peek() == "ip" {
                NFPROTO_IPV4
            } else {
                NFPROTO_IPV6
            };
            family_explicit = true;
            self.advance();
            if self.matches("prefix") {
                self.error = Some("nat prefix targets are not supported".into());
                return false;
            }
        }

        if !self.matches("to") {
            self.error = Some(format!("expected 'to' after {}", nat_name));
            return false;
        }

        let target = self.peek().to_string();
        if target.is_empty() {
            self.error = Some(format!("missing nat target after {}", nat_name));
            return false;
        }

        let mut addr = Vec::new();
        let mut has_addr = false;
        let mut port = 0u16;
        let mut has_port = false;

        if target == ":" {
            self.advance();
            let Some(parsed_port) = Self::parse_nat_port_token(self.advance()) else {
                self.error = Some(format!("invalid nat port after {}", nat_name));
                return false;
            };
            port = parsed_port;
            has_port = true;
        } else if let Some(rest) = target.strip_prefix(':') {
            let Some(parsed_port) = Self::parse_nat_port_token(rest) else {
                self.error = Some(format!("invalid nat port after {}", nat_name));
                return false;
            };
            self.advance();
            port = parsed_port;
            has_port = true;
        } else if let Some((parsed_family, parsed_addr, inline_port)) =
            Self::parse_nat_addr_token(&target)
        {
            if family_explicit && family != parsed_family {
                self.error = Some(format!("nat family does not match target '{}'", target));
                return false;
            }
            family = parsed_family;
            self.advance();
            addr = parsed_addr;
            has_addr = true;
            if let Some(parsed_port) = inline_port {
                port = parsed_port;
                has_port = true;
            } else if self.peek() == ":" {
                self.advance();
                let Some(parsed_port) = Self::parse_nat_port_token(self.advance()) else {
                    self.error = Some(format!("invalid nat port after {}", nat_name));
                    return false;
                };
                port = parsed_port;
                has_port = true;
            } else if let Some(rest) = self.peek().strip_prefix(':') {
                let Some(parsed_port) = Self::parse_nat_port_token(rest) else {
                    self.error = Some(format!("invalid nat port after {}", nat_name));
                    return false;
                };
                self.advance();
                port = parsed_port;
                has_port = true;
            }
        } else {
            self.error = Some(format!("unsupported nat target '{}'", target));
            return false;
        }

        while matches!(self.peek(), "persistent" | "random" | "fully-random") {
            self.advance();
        }
        if !self.at_end() && self.peek() != ";" && !is_statement_start(self.peek()) {
            self.error = Some(format!(
                "unexpected token '{}' after nat target",
                self.peek()
            ));
            return false;
        }

        cmd.exprs.push(Expr::Nat {
            nat_type,
            family,
            addr,
            port,
            has_addr,
            has_port,
        });
        true
    }

    fn push_set_element_key(cmd: &mut Command, start: Vec<u8>, end: Option<Vec<u8>>) {
        cmd.elements.push((start, end));
        cmd.element_exprs.push(Vec::new());
    }

    fn parse_element_value_if_present(
        &mut self,
        cmd: &mut Command,
        compact_value: Option<String>,
    ) -> Result<(), String> {
        if let Some(value) = compact_value {
            self.push_element_value(cmd, value)?;
        } else if self.peek() == ":" {
            self.parse_element_value(cmd)?;
        } else if cmd.set_spec.is_map {
            return Err("missing value for map element".into());
        }
        Ok(())
    }

    fn parse_set_element_statements(&mut self, exprs: &mut Vec<Expr>) -> Result<(), String> {
        loop {
            match self.peek() {
                "counter" => {
                    self.advance();
                    exprs.push(self.parse_counter_expr());
                }
                "limit" => {
                    self.advance();
                    exprs.push(self.parse_limit_expr());
                }
                "connlimit" | "quota" | "last" => {
                    return Err(format!(
                        "unsupported set element statement '{}'",
                        self.peek()
                    ));
                }
                _ => break,
            }
        }
        Ok(())
    }

    fn parse_element_block(&mut self, cmd: &mut Command) -> Result<(), String> {
        if !self.matches("{") {
            return Err("expected '{' to start element block".into());
        }
        while !self.at_end() && self.peek() != "}" {
            // Newlines tokenise to `;`; inside an element list they
            // are just whitespace, so skip along with `,`.
            if self.peek() == "," || self.peek() == ";" {
                self.advance();
                continue;
            }
            let raw_tok = self.advance().to_string();
            let compact_value = Self::split_compact_pair(&raw_tok);
            let tok = compact_value
                .as_ref()
                .map(|(key, _)| key.clone())
                .unwrap_or(raw_tok);

            if cmd.set_spec.key_field_types.len() > 1 {
                if let Some((key_start, key_end)) = self.parse_concat_interval_key(
                    tok.clone(),
                    &cmd.set_spec.key_field_types,
                    &cmd.set_spec.key_field_lens,
                ) {
                    Self::push_set_element_key(cmd, key_start, key_end);
                    let idx = cmd.element_exprs.len().saturating_sub(1);
                    self.parse_set_element_statements(&mut cmd.element_exprs[idx])?;
                    self.parse_element_value_if_present(
                        cmd,
                        compact_value.as_ref().map(|(_, value)| value.clone()),
                    )?;
                    continue;
                }
            }

            // CIDR first — an interval-set element written as
            // `1.1.1.0/24` expands to the range [1.1.1.0, 1.1.1.255]
            // so add_elements' INTERVAL_END expansion works. Not
            // special-cased for plain sets: a CIDR in a non-interval
            // set is a user error and the kernel will reject it.
            if let Some((start, end)) =
                Self::ipv4_cidr_range(&tok).or_else(|| Self::ipv6_cidr_range(&tok))
            {
                Self::push_set_element_key(cmd, start, Some(end));
                let idx = cmd.element_exprs.len().saturating_sub(1);
                self.parse_set_element_statements(&mut cmd.element_exprs[idx])?;
                self.parse_element_value_if_present(
                    cmd,
                    compact_value.as_ref().map(|(_, value)| value.clone()),
                )?;
                continue;
            }

            let known_scalar_type = if cmd.set_spec.key_field_types.len() <= 1 {
                Some((cmd.set_spec.key_type, cmd.set_spec.key_len))
            } else {
                None
            };
            // Try address / port first so we can peek for a following `-`
            // which indicates a range. IPv6 comes first because it'd also
            // be reflected in parse_ipv4 failures — any unambiguous IPv6
            // representation (with `::` or >3 colons) parses cleanly here.
            let parse_scalar = |value: &str| -> Option<Vec<u8>> {
                if let Some((ty, len)) = known_scalar_type {
                    if ty != 0 {
                        return Self::parse_typed_value_token(value, ty, len);
                    }
                }
                if let Some(addr) = Self::parse_ipv6(value) {
                    Some(addr.to_vec())
                } else if let Some(addr) = Self::parse_ipv4(value) {
                    Some(addr.to_vec())
                } else if let Ok(n) = value.parse::<u32>() {
                    Some(n.to_be_bytes().to_vec())
                } else {
                    None
                }
            };
            let start: Option<Vec<u8>> = parse_scalar(&tok);

            if let Some(s) = start {
                let end = if self.peek() == "-" {
                    self.advance();
                    let end_tok = self.advance().to_string();
                    parse_scalar(&end_tok)
                } else {
                    None
                };
                Self::push_set_element_key(cmd, s, end);
                let idx = cmd.element_exprs.len().saturating_sub(1);
                self.parse_set_element_statements(&mut cmd.element_exprs[idx])?;
                self.parse_element_value_if_present(
                    cmd,
                    compact_value.as_ref().map(|(_, value)| value.clone()),
                )?;
                continue;
            }

            let allow_string = matches!(cmd.set_spec.key_type, 0 | 5 | 16);
            if !allow_string {
                return Err(format!("invalid element '{}'", tok));
            }

            // String element (interface name, etc.) — no range semantics.
            let raw = if tok.starts_with('"') && tok.ends_with('"') && tok.len() >= 2 {
                &tok[1..tok.len() - 1]
            } else {
                tok.as_str()
            };
            let mut v = raw.as_bytes().to_vec();
            v.push(0);
            Self::push_set_element_key(cmd, v, None);
            let idx = cmd.element_exprs.len().saturating_sub(1);
            self.parse_set_element_statements(&mut cmd.element_exprs[idx])?;
            self.parse_element_value_if_present(
                cmd,
                compact_value.as_ref().map(|(_, value)| value.clone()),
            )?;
        }
        self.matches("}");
        Ok(())
    }

    /// After a `key :`, either a verdict keyword (accept/drop/jump...)
    /// or a data value (ipv4/ipv6/integer/string) follows. For
    /// verdicts the parsed `(code, chain)` goes to element_verdicts
    /// and None is pushed into element_datas so indexes stay aligned.
    /// For data values the raw bytes go to element_datas and a
    /// stub entry (0, "") goes into element_verdicts.
    fn parse_element_value(&mut self, cmd: &mut Command) -> Result<(), String> {
        self.advance(); // ":"
        let v = self.advance().to_string();
        self.push_element_value(cmd, v)
    }

    fn push_element_value(&mut self, cmd: &mut Command, v: String) -> Result<(), String> {
        if cmd.set_spec.data_type == 0xffffff00 {
            let Some((code, chain)) = self.parse_verdict(v.clone()) else {
                return Err(format!("invalid verdict '{}'", v));
            };
            cmd.element_verdicts.push((code, chain));
            cmd.element_datas.push(None);
            return Ok(());
        }

        match v.as_str() {
            "accept" | "drop" | "return" | "continue" | "jump" | "goto" => {
                let (code, chain) = match self.parse_verdict(v) {
                    Some(v) => v,
                    None => unreachable!(),
                };
                cmd.element_verdicts.push((code, chain));
                cmd.element_datas.push(None);
            }
            _ => {
                let bytes = if cmd.set_spec.data_type > 0 && cmd.set_spec.data_len > 0 {
                    Self::parse_typed_value_token(&v, cmd.set_spec.data_type, cmd.set_spec.data_len)
                } else if let Some(a) = Self::parse_ipv6(&v) {
                    Some(a.to_vec())
                } else if let Some(a) = Self::parse_ipv4(&v) {
                    Some(a.to_vec())
                } else if let Ok(n) = v.parse::<u32>() {
                    Some(n.to_be_bytes().to_vec())
                } else if v.starts_with('"') && v.ends_with('"') && v.len() >= 2 {
                    let mut bytes = v[1..v.len() - 1].as_bytes().to_vec();
                    bytes.push(0);
                    // Pad to 16 bytes (iface-name len).
                    while bytes.len() < 16 {
                        bytes.push(0);
                    }
                    Some(bytes)
                } else {
                    None
                };
                cmd.element_verdicts.push((0, String::new()));
                cmd.element_datas.push(bytes);
            }
        }
        Ok(())
    }

    fn parse_verdict(&mut self, tok: String) -> Option<(i32, String)> {
        match tok.as_str() {
            "accept" => Some((NF_ACCEPT, String::new())),
            "drop" => Some((NF_DROP, String::new())),
            "return" => Some((NFT_RETURN, String::new())),
            "continue" => Some((NFT_CONTINUE, String::new())),
            "jump" => Some((NFT_JUMP, self.parse_name())),
            "goto" => Some((NFT_GOTO, self.parse_name())),
            _ => None,
        }
    }

    fn parse_bound_chain_body(&mut self, cmd: &Command) -> Result<BoundChain, String> {
        let name = Self::next_bound_chain_name();
        if !self.matches("{") {
            return Err("expected '{' to start bound chain body".into());
        }

        let mut rules: Vec<Command> = Vec::new();
        while !self.at_end() && self.peek() != "}" {
            while self.matches(";") {}
            if self.peek() == "}" {
                break;
            }

            let before = self.pos;
            let near = self.peek().to_string();
            let mut rcmd = Command::default();
            rcmd.op = CmdOp::Add;
            rcmd.obj = CmdObj::Rule;
            rcmd.family = cmd.family;
            rcmd.table = cmd.table.clone();
            rcmd.chain = name.clone();
            self.parse_rule_exprs(&mut rcmd);
            if let Some(err) = self.error.take() {
                return Err(err);
            }
            self.matches(";");
            if !rcmd.exprs.is_empty() || rcmd.has_comment {
                rules.push(rcmd);
            } else if self.pos != before {
                return Err(format!("unknown rule statement near '{}'", near));
            }
        }

        if !self.matches("}") {
            return Err(format!("expected '}}' to close bound chain '{}'", name));
        }
        Ok(BoundChain { name, rules })
    }

    /// Parse the body of `add counter/quota/limit name { ... }`. Each
    /// object kind has its own keyword set; we dispatch on
    /// `cmd.obj_spec.kind` (already set by the caller). Unknown tokens
    /// inside the block are skipped so mismatched listings don't abort.
    fn parse_object_block(&mut self, cmd: &mut Command) {
        if !self.matches("{") {
            return;
        }
        while !self.at_end() && self.peek() != "}" {
            // Quota body can start with a bare number + unit:
            //   quota q { 25 mbytes }
            if cmd.obj_spec.kind == NFT_OBJECT_QUOTA {
                if let Ok(n) = self.peek().parse::<u64>() {
                    self.advance();
                    let mul = match self.peek() {
                        "bytes" => 1u64,
                        "kbytes" => 1024,
                        "mbytes" => 1024 * 1024,
                        "gbytes" => 1024 * 1024 * 1024,
                        _ => 1,
                    };
                    if matches!(self.peek(), "bytes" | "kbytes" | "mbytes" | "gbytes") {
                        self.advance();
                    }
                    cmd.obj_spec.bytes = n * mul;
                    // Optional `used N {unit}` — the amount already
                    // accounted for, reported back by `list quota`.
                    if self.peek() == "used" {
                        self.advance();
                        let _used: u64 = self.advance().parse().unwrap_or(0);
                        if matches!(self.peek(), "bytes" | "kbytes" | "mbytes" | "gbytes") {
                            self.advance();
                        }
                    }
                    continue;
                }
            }
            match self.peek() {
                ";" => {
                    self.advance();
                }
                "protocol"
                    if matches!(
                        cmd.obj_spec.kind,
                        NFT_OBJECT_CT_TIMEOUT | NFT_OBJECT_CT_EXPECT
                    ) =>
                {
                    self.advance();
                    cmd.obj_spec.ct_l4proto = proto_num(self.advance()).unwrap_or(0);
                }
                "l3proto"
                    if matches!(
                        cmd.obj_spec.kind,
                        NFT_OBJECT_CT_TIMEOUT | NFT_OBJECT_CT_EXPECT
                    ) =>
                {
                    self.advance();
                    cmd.obj_spec.ct_l3proto = nfproto_num(self.advance()).unwrap_or(0) as u16;
                }
                "policy" if cmd.obj_spec.kind == NFT_OBJECT_CT_TIMEOUT => {
                    self.advance();
                    self.matches("=");
                    if !self.matches("{") {
                        continue;
                    }
                    while !self.at_end() && self.peek() != "}" {
                        if self.matches(",") || self.matches(";") {
                            continue;
                        }
                        let state = self.advance().to_string();
                        self.matches(":");
                        let secs =
                            (Self::parse_duration_ms(self.advance()).unwrap_or(0) / 1000) as u32;
                        cmd.obj_spec.ct_timeout_policy.push((state, secs));
                        self.matches(",");
                    }
                    self.matches("}");
                }
                "dport" if cmd.obj_spec.kind == NFT_OBJECT_CT_EXPECT => {
                    self.advance();
                    let tok = self.advance().to_string();
                    cmd.obj_spec.ct_expect_dport = service_num(&tok)
                        .or_else(|| Self::parse_numeric_token(&tok).map(|v| v as u16))
                        .unwrap_or(0);
                }
                "timeout" if cmd.obj_spec.kind == NFT_OBJECT_CT_EXPECT => {
                    self.advance();
                    cmd.obj_spec.ct_expect_timeout_ms =
                        Self::parse_duration_ms(self.advance()).unwrap_or(0) as u32;
                }
                "size" if cmd.obj_spec.kind == NFT_OBJECT_CT_EXPECT => {
                    self.advance();
                    cmd.obj_spec.ct_expect_size = self.advance().parse::<u8>().unwrap_or(0);
                }
                "packets" => {
                    self.advance();
                    if let Ok(n) = self.advance().parse::<u64>() {
                        if cmd.obj_spec.kind == NFT_OBJECT_LIMIT {
                            cmd.obj_spec.limit_type = 0; // NFT_LIMIT_PKTS
                        } else {
                            cmd.obj_spec.packets = n;
                        }
                    }
                }
                "bytes" => {
                    self.advance();
                    if let Ok(n) = self.advance().parse::<u64>() {
                        cmd.obj_spec.bytes = n;
                    }
                }
                "over" => {
                    self.advance();
                    cmd.obj_spec.quota_flags |= NFT_QUOTA_F_INV;
                    // `over N bytes` — consume the number + unit.
                    if let Ok(n) = self.advance().parse::<u64>() {
                        cmd.obj_spec.bytes = n;
                    }
                    if matches!(self.peek(), "bytes" | "kbytes" | "mbytes" | "gbytes") {
                        self.advance();
                    }
                }
                "rate" => {
                    self.advance();
                    // optional `over` invert
                    if self.peek() == "over" {
                        self.advance();
                        cmd.obj_spec.limit_flags |= 1;
                    }
                    // `rate` value can arrive as either a bare number
                    // followed by `/` + unit, or as a single word like
                    // `10/second` (the tokenizer doesn't split on `/`
                    // because `/` is used by CIDR). Handle both.
                    let tok = self.advance().to_string();
                    if let Some(slash) = tok.find('/') {
                        cmd.obj_spec.limit_rate = tok[..slash].parse::<u64>().unwrap_or(0);
                        cmd.obj_spec.limit_unit = match &tok[slash + 1..] {
                            "second" => 1,
                            "minute" => 60,
                            "hour" => 3600,
                            "day" => 86400,
                            "week" => 604800,
                            _ => 1,
                        };
                    } else if let Ok(n) = tok.parse::<u64>() {
                        cmd.obj_spec.limit_rate = n;
                        if self.peek() == "/" {
                            self.advance();
                            cmd.obj_spec.limit_unit = match self.advance() {
                                "second" => 1,
                                "minute" => 60,
                                "hour" => 3600,
                                "day" => 86400,
                                "week" => 604800,
                                _ => 1,
                            };
                        } else {
                            cmd.obj_spec.limit_unit = 1;
                        }
                    }
                }
                "burst" => {
                    self.advance();
                    if let Ok(n) = self.advance().parse::<u32>() {
                        cmd.obj_spec.limit_burst = n;
                    }
                    if matches!(self.peek(), "packets" | "bytes") {
                        self.advance();
                    }
                }
                _ => {
                    self.advance();
                }
            }
        }
        self.matches("}");
    }

    fn parse_table_block(&mut self, cmd: &mut Command) {
        if !self.matches("{") {
            return;
        }
        while !self.at_end() && self.peek() != "}" {
            if self.matches("flags") {
                cmd.table_spec.has_flags = true;
                while self.peek() != ";" && !self.at_end() {
                    if self.peek() == "dormant" {
                        cmd.table_spec.flags |= NFT_TABLE_F_DORMANT;
                    }
                    self.advance();
                }
                self.matches(";");
            } else if self.matches(";") {
            } else {
                self.advance();
            }
        }
        self.matches("}");
    }

    /// Parse a top-level declarative `table FAMILY NAME { ... }` block
    /// (the form used in /etc/nftables.conf and the output of `nft list
    /// ruleset`). Emits synthetic `add table` / `add chain` / `add set`
    /// / `add rule` commands into `out`.
    fn parse_declarative_table(&mut self, out: &mut Vec<Command>) -> Result<(), String> {
        // leading "table"
        self.advance();
        let family = self.parse_family_default_ip();
        let table_name = self.parse_name();

        // Emit `add table FAMILY NAME`
        let mut tcmd = Command::default();
        tcmd.op = CmdOp::Add;
        tcmd.obj = CmdObj::Table;
        tcmd.family = family;
        tcmd.table = table_name.clone();
        out.push(tcmd);

        // Rules and verdict-map elements may reference chains defined
        // later in the same block. In an atomic batch those
        // references fail with ENOENT. So collect chain-dependent
        // commands separately and flush all chains first, then
        // verdict-map elements, then rules — matches libnftables
        // ordering closely enough for forward references.
        let mut deferred_post_chain: Vec<Command> = Vec::new();
        let mut deferred_rules: Vec<Command> = Vec::new();
        let mut seen_members: std::collections::BTreeSet<(String, String)> =
            std::collections::BTreeSet::new();
        let mut remember_member = |kind: &str, name: &str| -> Result<(), String> {
            let key = (kind.to_string(), name.to_string());
            if !seen_members.insert(key) {
                return Err(format!("duplicate {} '{}'", kind, name));
            }
            Ok(())
        };

        if !self.matches("{") {
            return Err(format!("expected '{{' after table '{}'", table_name));
        }

        while !self.at_end() && self.peek() != "}" {
            while self.matches(";") {}
            if self.peek() == "}" {
                break;
            }

            let tok = self.peek().to_string();
            match tok.as_str() {
                "flags" => {
                    self.advance();
                    // Rule body has no `;` after `flags dormant` when the
                    // writer used newlines, so bail on any token that
                    // could start the next member as well.
                    loop {
                        let p = self.peek();
                        if self.at_end()
                            || p == ";"
                            || p == "}"
                            || p == "chain"
                            || p == "set"
                            || p == "map"
                            || p == "flowtable"
                            || p == "counter"
                            || p == "quota"
                            || p == "limit"
                            || p == "ct"
                        {
                            break;
                        }
                        if p == "dormant" {
                            if let Some(last) = out
                                .iter_mut()
                                .rev()
                                .find(|c| matches!(c.obj, CmdObj::Table))
                            {
                                last.table_spec.has_flags = true;
                                last.table_spec.flags |= NFT_TABLE_F_DORMANT;
                            }
                        }
                        self.advance();
                    }
                    self.matches(";");
                }
                "chain" => {
                    self.advance();
                    let chain_name = self.parse_name();
                    remember_member("chain", &chain_name)?;
                    let mut ccmd = Command::default();
                    ccmd.op = CmdOp::Add;
                    ccmd.obj = CmdObj::Chain;
                    ccmd.family = family;
                    ccmd.table = table_name.clone();
                    ccmd.chain = chain_name.clone();

                    // Collect rule commands emitted from statements in the chain body.
                    let mut rules: Vec<Command> = Vec::new();
                    if self.matches("{") {
                        while !self.at_end() && self.peek() != "}" {
                            while self.matches(";") {}
                            if self.peek() == "}" {
                                break;
                            }
                            let t = self.peek().to_string();
                            if t == "type" {
                                self.advance();
                                ccmd.chain_spec.is_base = true;
                                ccmd.chain_spec.chain_type = self.parse_name();
                                if self.matches("hook") {
                                    ccmd.chain_spec.hook = self.parse_name();
                                }
                                if self.matches("device") {
                                    ccmd.chain_spec.device = self.parse_name();
                                    if ccmd.chain_spec.device.is_empty() {
                                        return Err("device name must not be empty".into());
                                    }
                                    ccmd.chain_spec.has_device = true;
                                }
                                if self.matches("priority") {
                                    let ct = ccmd.chain_spec.chain_type.clone();
                                    let hk = ccmd.chain_spec.hook.clone();
                                    ccmd.chain_spec.priority =
                                        self.parse_priority_ctx(family, &ct, &hk)?;
                                    ccmd.chain_spec.has_priority = true;
                                }
                                self.matches(";");
                            } else if t == "policy" {
                                self.advance();
                                let pol = self.parse_name();
                                if pol != "accept" && pol != "drop" {
                                    return Err(format!("unknown policy '{}'", pol));
                                }
                                if !ccmd.chain_spec.is_base {
                                    return Err("chain policy is only valid for base chains".into());
                                }
                                ccmd.chain_spec.policy = pol;
                                ccmd.chain_spec.has_policy = true;
                                self.matches(";");
                            } else {
                                // A rule statement: consume tokens up to next ';' or '}'
                                // into a fresh rule command. Fail if the line
                                // was entirely unknown — a rule that silently
                                // lexes to no expressions would otherwise let
                                // garbage rulesets load (upstream's rollback
                                // tests rely on bad syntax failing).
                                let before = self.pos;
                                let mut rcmd = Command::default();
                                rcmd.op = CmdOp::Add;
                                rcmd.obj = CmdObj::Rule;
                                rcmd.family = family;
                                rcmd.table = table_name.clone();
                                rcmd.chain = chain_name.clone();
                                self.parse_rule_exprs(&mut rcmd);
                                if let Some(err) = self.error.take() {
                                    return Err(err);
                                }
                                self.matches(";");
                                if !rcmd.exprs.is_empty() || rcmd.has_comment {
                                    rules.push(rcmd);
                                } else if self.pos != before {
                                    return Err(format!("unknown rule statement near '{}'", t));
                                }
                            }
                        }
                        if !self.matches("}") {
                            return Err(format!("expected '}}' to close chain '{}'", chain_name));
                        }
                    }
                    out.push(ccmd);
                    deferred_rules.extend(rules);
                }
                "set" | "map" => {
                    let is_map = tok == "map";
                    self.advance();
                    let set_name = self.parse_name();
                    remember_member(if is_map { "map" } else { "set" }, &set_name)?;
                    let mut scmd = Command::default();
                    scmd.op = CmdOp::Add;
                    scmd.obj = if is_map { CmdObj::Map } else { CmdObj::Set };
                    scmd.family = family;
                    scmd.table = table_name.clone();
                    scmd.set_name = set_name.clone();
                    if is_map {
                        scmd.set_spec.is_map = true;
                    }

                    // Collect elements separately so we can emit them as
                    // a follow-up `add element` command.
                    let mut elements: Vec<(Vec<u8>, Option<Vec<u8>>)> = Vec::new();
                    let mut element_verdicts: Vec<(i32, String)> = Vec::new();
                    let mut element_datas: Vec<Option<Vec<u8>>> = Vec::new();
                    let mut element_exprs: Vec<Vec<Expr>> = Vec::new();
                    if self.matches("{") {
                        while !self.at_end() && self.peek() != "}" {
                            while self.matches(";") {}
                            if self.peek() == "}" {
                                break;
                            }
                            if self.matches("type") {
                                let type_tok = self.advance().to_string();
                                if let Some((key, data)) = Self::split_compact_type_decl(&type_tok)
                                {
                                    Self::apply_set_key_fields(&mut scmd.set_spec, vec![key]);
                                    scmd.set_spec.is_map = true;
                                    Self::apply_set_data_fields(&mut scmd.set_spec, vec![data]);
                                } else {
                                    let key_fields = self.parse_type_fields(type_tok);
                                    Self::apply_set_key_fields(&mut scmd.set_spec, key_fields);
                                    if self.peek() == ":" {
                                        self.advance();
                                        scmd.set_spec.is_map = true;
                                        let data_tok = self.advance().to_string();
                                        let data_fields = self.parse_type_fields(data_tok);
                                        Self::apply_set_data_fields(
                                            &mut scmd.set_spec,
                                            data_fields,
                                        );
                                    }
                                }
                                self.matches(";");
                            } else if self.matches("typeof") {
                                let Some(fields) = self.parse_typeof_selectors() else {
                                    return Err(format!(
                                        "invalid typeof selector '{}'",
                                        self.peek()
                                    ));
                                };
                                Self::apply_typeof_key_fields(&mut scmd.set_spec, fields);
                                if self.peek() == ":" {
                                    self.advance();
                                    scmd.set_spec.is_map = true;
                                    if self.matches("queue") {
                                        scmd.set_spec.data_type_name = "queue".to_string();
                                        scmd.set_spec.data_type = 4;
                                        scmd.set_spec.data_len = 2;
                                        scmd.set_spec.data_is_typeof = true;
                                    } else {
                                        let data_tok = self.advance().to_string();
                                        let data_fields = self.parse_type_fields(data_tok);
                                        Self::apply_set_data_fields(
                                            &mut scmd.set_spec,
                                            data_fields,
                                        );
                                        scmd.set_spec.data_is_typeof = true;
                                    }
                                }
                                self.matches(";");
                            } else if self.matches("flags") {
                                scmd.set_spec.has_flags = true;
                                // Stop at ";" OR "}" OR any next-attribute keyword.
                                // Inside braces newlines no longer inject ";", so
                                // "flags interval elements = {...}" must terminate
                                // on the keyword "elements" rather than running off
                                // the end of the set body.
                                loop {
                                    let p = self.peek();
                                    if self.at_end()
                                        || p == ";"
                                        || p == "}"
                                        || p == "elements"
                                        || p == "type"
                                        || p == "size"
                                        || p == "gc-interval"
                                        || p == "policy"
                                        || p == "auto-merge"
                                    {
                                        break;
                                    }
                                    match p {
                                        "constant" => {
                                            scmd.set_spec.flags |= 0x2;
                                            self.advance();
                                        }
                                        "interval" => {
                                            scmd.set_spec.flags |= 0x4;
                                            self.advance();
                                        }
                                        "timeout" => {
                                            scmd.set_spec.flags |= NFT_SET_TIMEOUT;
                                            self.advance();
                                        }
                                        "dynamic" => {
                                            scmd.set_spec.flags |= NFT_SET_EVAL;
                                            self.advance();
                                        }
                                        "," => {
                                            self.advance();
                                        }
                                        _ => {
                                            self.advance();
                                        }
                                    }
                                }
                                self.matches(";");
                            } else if self.matches("size") {
                                scmd.set_spec.has_size = true;
                                scmd.set_spec.size =
                                    Self::parse_numeric_token(self.advance()).unwrap_or(0) as u32;
                                self.matches(";");
                            } else if self.matches("auto-merge") {
                                scmd.set_spec.auto_merge = true;
                                self.matches(";");
                            } else if self.matches("elements") {
                                self.matches("=");
                                if self.peek() == "{" {
                                    self.parse_element_block(&mut scmd)?;
                                    elements = std::mem::take(&mut scmd.elements);
                                    element_verdicts = std::mem::take(&mut scmd.element_verdicts);
                                    element_datas = std::mem::take(&mut scmd.element_datas);
                                    element_exprs = std::mem::take(&mut scmd.element_exprs);
                                }
                                self.matches(";");
                            } else {
                                // Unknown attribute inside set block; consume to next ;
                                while !self.at_end() && self.peek() != ";" && self.peek() != "}" {
                                    self.advance();
                                }
                                self.matches(";");
                            }
                        }
                        if !self.matches("}") {
                            return Err(format!(
                                "expected '}}' to close {} '{}'",
                                if is_map { "map" } else { "set" },
                                set_name
                            ));
                        }
                    }
                    Self::validate_named_set_spec(&scmd.set_spec)?;
                    self.remember_named_set(family, &table_name, &set_name, &scmd.set_spec);
                    out.push(scmd);
                    if !elements.is_empty() {
                        let mut ecmd = Command::default();
                        ecmd.op = CmdOp::Add;
                        ecmd.obj = CmdObj::Element;
                        ecmd.family = family;
                        ecmd.table = table_name.clone();
                        ecmd.set_name = set_name;
                        ecmd.elements = elements;
                        ecmd.element_verdicts = element_verdicts;
                        ecmd.element_datas = element_datas;
                        ecmd.element_exprs = element_exprs;
                        if !ecmd.element_verdicts.is_empty() {
                            deferred_post_chain.push(ecmd);
                        } else {
                            out.push(ecmd);
                        }
                    }
                }
                "counter" | "quota" | "limit" => {
                    let kind_tok = tok.clone();
                    self.advance();
                    let name = self.parse_name();
                    remember_member(&kind_tok, &name)?;
                    let mut ocmd = Command::default();
                    ocmd.op = CmdOp::Add;
                    ocmd.obj = match kind_tok.as_str() {
                        "counter" => CmdObj::Counter,
                        "quota" => CmdObj::Quota,
                        "limit" => CmdObj::Limit,
                        _ => unreachable!(),
                    };
                    ocmd.family = family;
                    ocmd.table = table_name.clone();
                    ocmd.set_name = name;
                    ocmd.obj_spec.kind = match ocmd.obj {
                        CmdObj::Counter => NFT_OBJECT_COUNTER,
                        CmdObj::Quota => NFT_OBJECT_QUOTA,
                        CmdObj::Limit => NFT_OBJECT_LIMIT,
                        _ => 0,
                    };
                    self.parse_object_block(&mut ocmd);
                    out.push(ocmd);
                }
                "ct" => {
                    self.advance();
                    let kind_tok = self.advance().to_string();
                    let (obj, kind, member_kind) = match kind_tok.as_str() {
                        "timeout" => (CmdObj::CtTimeout, NFT_OBJECT_CT_TIMEOUT, "ct timeout"),
                        "expectation" => (
                            CmdObj::CtExpectation,
                            NFT_OBJECT_CT_EXPECT,
                            "ct expectation",
                        ),
                        _ => return Err(format!("unknown table element 'ct {}'", kind_tok)),
                    };
                    let name = self.parse_name();
                    remember_member(member_kind, &name)?;
                    let mut ocmd = Command::default();
                    ocmd.op = CmdOp::Add;
                    ocmd.obj = obj;
                    ocmd.family = family;
                    ocmd.table = table_name.clone();
                    ocmd.set_name = name;
                    ocmd.obj_spec.kind = kind;
                    self.parse_object_block(&mut ocmd);
                    out.push(ocmd);
                }
                "flowtable" => {
                    self.advance();
                    let name = self.parse_name();
                    remember_member("flowtable", &name)?;
                    let mut fcmd = Command::default();
                    fcmd.op = CmdOp::Add;
                    fcmd.obj = CmdObj::Flowtable;
                    fcmd.family = family;
                    fcmd.table = table_name.clone();
                    fcmd.set_name = name;
                    self.parse_flowtable_block(&mut fcmd)?;
                    out.push(fcmd);
                }
                _ => {
                    return Err(format!("unknown table element '{}'", tok));
                }
            }
        }
        if !self.matches("}") {
            return Err(format!("expected '}}' to close table '{}'", table_name));
        }
        out.extend(deferred_post_chain);
        out.extend(deferred_rules);
        Ok(())
    }

    fn parse_command(&mut self) -> Result<Option<Command>, String> {
        while self.matches(";") {}
        if self.at_end() {
            return Ok(None);
        }

        let mut cmd = Command::default();

        // Operation
        let op_str = self.advance().to_string();
        cmd.op = match op_str.as_str() {
            "add" => CmdOp::Add,
            "create" => CmdOp::Create,
            "delete" => CmdOp::Delete,
            "destroy" => CmdOp::Destroy,
            "list" => CmdOp::List,
            "flush" => CmdOp::Flush,
            "rename" => CmdOp::Rename,
            "insert" => CmdOp::Insert,
            "replace" => CmdOp::Replace,
            "reset" => CmdOp::Reset,
            _ => return Err(format!("expected command, got '{}'", op_str)),
        };

        // Object type
        let obj_str = self.advance().to_string();
        cmd.obj = match obj_str.as_str() {
            "table" => CmdObj::Table,
            "chain" => CmdObj::Chain,
            "rule" => CmdObj::Rule,
            "set" => CmdObj::Set,
            "map" => CmdObj::Map,
            "element" => CmdObj::Element,
            "flowtable" => CmdObj::Flowtable,
            "ruleset" => CmdObj::Ruleset,
            "tables" => CmdObj::Tables,
            "chains" => CmdObj::Chains,
            "rules" => CmdObj::Rules,
            "sets" => CmdObj::Sets,
            "maps" => CmdObj::Maps,
            "flowtables" => CmdObj::Flowtables,
            "counter" => CmdObj::Counter,
            "quota" => CmdObj::Quota,
            "limit" => CmdObj::Limit,
            "counters" => CmdObj::Counters,
            "quotas" => CmdObj::Quotas,
            "limits" => CmdObj::Limits,
            "ct" => match self.advance() {
                "timeout" => CmdObj::CtTimeout,
                "expectation" => CmdObj::CtExpectation,
                other => return Err(format!("expected ct object type, got '{}'", other)),
            },
            _ => return Err(format!("expected object type, got '{}'", obj_str)),
        };

        // Ruleset/plural: optional family, default UNSPEC
        match cmd.obj {
            CmdObj::Ruleset
            | CmdObj::Tables
            | CmdObj::Chains
            | CmdObj::Rules
            | CmdObj::Sets
            | CmdObj::Maps
            | CmdObj::Flowtables
            | CmdObj::Counters
            | CmdObj::Quotas
            | CmdObj::Limits => {
                cmd.family = self.parse_family_default_unspec();
                return Ok(Some(cmd));
            }
            _ => {}
        }

        // [family] table
        let family_explicit = Self::is_family(self.peek());
        cmd.family = self.parse_family_default_ip();

        // `delete table FAMILY handle N` / `destroy table FAMILY handle N`
        // — target a table by kernel handle instead of name. Upstream's
        // transactions/handle_bad_family round-trips the handle grabbed
        // from `nft -a -e add table ip x`.
        if matches!(cmd.obj, CmdObj::Table)
            && matches!(cmd.op, CmdOp::Delete | CmdOp::Destroy)
            && self.peek() == "handle"
        {
            self.advance();
            cmd.handle = self.advance().parse().unwrap_or(0);
            cmd.has_handle = true;
            return Ok(Some(cmd));
        }

        cmd.table = self.parse_name();

        // Table-only commands
        if matches!(cmd.obj, CmdObj::Table) {
            if matches!(cmd.op, CmdOp::Add | CmdOp::Create) && self.peek() == "{" {
                self.parse_table_block(&mut cmd);
            }
            return Ok(Some(cmd));
        }

        // Chain/rule/set/object need another name. For chain delete
        // (and rule delete) the name slot can carry `handle N` instead
        // of a named identifier — `nft delete chain TABLE handle 42`.
        match cmd.obj {
            CmdObj::Chain | CmdObj::Rule => {
                if matches!(cmd.op, CmdOp::Delete | CmdOp::Destroy) && self.peek() == "handle" {
                    self.advance();
                    cmd.handle = self.advance().parse().unwrap_or(0);
                    cmd.has_handle = true;
                    return Ok(Some(cmd));
                }
                cmd.chain = self.parse_name();
            }
            CmdObj::Set
            | CmdObj::Map
            | CmdObj::Flowtable
            | CmdObj::Element
            | CmdObj::Counter
            | CmdObj::Quota
            | CmdObj::Limit
            | CmdObj::CtTimeout
            | CmdObj::CtExpectation => {
                if matches!(cmd.op, CmdOp::Delete | CmdOp::Destroy) && self.peek() == "handle" {
                    self.advance();
                    cmd.handle = self.advance().parse().unwrap_or(0);
                    cmd.has_handle = true;
                    return Ok(Some(cmd));
                }
                cmd.set_name = self.parse_name();
            }
            _ => {}
        }

        // Named stateful-object body:   add counter t cnt { packets 0 bytes 0 ; }
        if matches!(
            cmd.obj,
            CmdObj::Counter
                | CmdObj::Quota
                | CmdObj::Limit
                | CmdObj::CtTimeout
                | CmdObj::CtExpectation
        ) && matches!(cmd.op, CmdOp::Delete | CmdOp::Destroy)
            && !cmd.has_handle
            && !family_explicit
        {
            return Err(format!(
                "missing family for {} delete",
                match cmd.obj {
                    CmdObj::Counter => "counter",
                    CmdObj::Quota => "quota",
                    CmdObj::Limit => "limit",
                    CmdObj::CtTimeout => "ct timeout",
                    CmdObj::CtExpectation => "ct expectation",
                    _ => unreachable!(),
                }
            ));
        }
        if matches!(
            cmd.obj,
            CmdObj::Counter
                | CmdObj::Quota
                | CmdObj::Limit
                | CmdObj::CtTimeout
                | CmdObj::CtExpectation
        ) && matches!(cmd.op, CmdOp::Add | CmdOp::Create)
        {
            cmd.obj_spec.kind = match cmd.obj {
                CmdObj::Counter => NFT_OBJECT_COUNTER,
                CmdObj::Quota => NFT_OBJECT_QUOTA,
                CmdObj::Limit => NFT_OBJECT_LIMIT,
                CmdObj::CtTimeout => NFT_OBJECT_CT_TIMEOUT,
                CmdObj::CtExpectation => NFT_OBJECT_CT_EXPECT,
                _ => 0,
            };
            if self.peek() == "{" {
                self.parse_object_block(&mut cmd);
            } else if cmd.obj_spec.kind == NFT_OBJECT_QUOTA {
                // Inline quota form: `add quota t q 25 mbytes`.
                if let Ok(n) = self.peek().parse::<u64>() {
                    self.advance();
                    let mul = match self.peek() {
                        "bytes" => 1u64,
                        "kbytes" => 1024,
                        "mbytes" => 1024 * 1024,
                        "gbytes" => 1024 * 1024 * 1024,
                        _ => 1,
                    };
                    if matches!(self.peek(), "bytes" | "kbytes" | "mbytes" | "gbytes") {
                        self.advance();
                    }
                    cmd.obj_spec.bytes = n * mul;
                }
            }
            return Ok(Some(cmd));
        }

        // Chain block
        if matches!(cmd.obj, CmdObj::Chain)
            && matches!(cmd.op, CmdOp::Add | CmdOp::Create)
            && self.peek() == "{"
        {
            self.parse_chain_block(&mut cmd)?;
            return Ok(Some(cmd));
        }

        // Chain rename
        if matches!(cmd.obj, CmdObj::Chain) && matches!(cmd.op, CmdOp::Rename) {
            cmd.new_name = self.parse_name();
            return Ok(Some(cmd));
        }

        // Set block
        if matches!(cmd.obj, CmdObj::Set | CmdObj::Map)
            && matches!(cmd.op, CmdOp::Add | CmdOp::Create)
            && self.peek() == "{"
        {
            self.parse_set_block(&mut cmd);
            if matches!(cmd.obj, CmdObj::Map) {
                cmd.set_spec.is_map = true;
            }
            Self::validate_named_set_spec(&cmd.set_spec)?;
            self.remember_named_set(cmd.family, &cmd.table, &cmd.set_name, &cmd.set_spec);
            return Ok(Some(cmd));
        }

        if matches!(cmd.obj, CmdObj::Flowtable) {
            if matches!(cmd.op, CmdOp::Add | CmdOp::Create) && self.peek() == "{" {
                self.parse_flowtable_block(&mut cmd)?;
            } else if matches!(cmd.op, CmdOp::Delete | CmdOp::Destroy) && self.peek() == "{" {
                // Upstream accepts a trailing flowtable block on delete
                // for device-removal forms; the full partial-update path
                // is not implemented yet, but the syntax should still parse.
                let mut depth = 0i32;
                while !self.at_end() {
                    let tok = self.advance().to_string();
                    if tok == "{" {
                        depth += 1;
                    } else if tok == "}" {
                        depth -= 1;
                        if depth == 0 {
                            break;
                        }
                    }
                }
            }
            return Ok(Some(cmd));
        }

        // Element block
        if matches!(cmd.obj, CmdObj::Element) && !self.at_end() && self.peek() == "{" {
            if let Some(spec) = self
                .named_set_spec(cmd.family, &cmd.table, &cmd.set_name)
                .cloned()
            {
                cmd.set_spec = spec;
            }
            self.parse_element_block(&mut cmd)?;
            return Ok(Some(cmd));
        }

        // Rule positioning: `[add|insert|replace] rule T C [position N |
        // handle N | index N] EXPRS`. `position` and `handle` both take
        // the kernel rule handle as the anchor; `index` is a 0-based
        // ordinal within the chain that we resolve to a handle via a
        // GETRULE dump at exec time. All three set has_handle so the
        // encoder can attach NFTA_RULE_POSITION to the netlink msg.
        if matches!(cmd.obj, CmdObj::Rule) {
            match self.peek() {
                "handle" | "position" => {
                    self.advance();
                    cmd.handle = self.advance().parse().unwrap_or(0);
                    cmd.has_handle = true;
                }
                "index" => {
                    self.advance();
                    cmd.rule_index = self.advance().parse().unwrap_or(-1);
                    cmd.has_rule_index = true;
                }
                _ => {}
            }
            if matches!(cmd.op, CmdOp::Add | CmdOp::Insert | CmdOp::Replace) {
                let before_exprs = cmd.exprs.len();
                self.parse_rule_exprs(&mut cmd);
                if cmd.exprs.len() == before_exprs && !cmd.has_comment {
                    return Err("invalid rule".into());
                }
            }
        }

        Ok(Some(cmd))
    }

    fn parse_numeric_token(tok: &str) -> Option<u64> {
        if let Some(hex) = tok.strip_prefix("0x").or_else(|| tok.strip_prefix("0X")) {
            return u64::from_str_radix(hex, 16).ok();
        }
        if let Some(oct) = tok.strip_prefix("0o").or_else(|| tok.strip_prefix("0O")) {
            return u64::from_str_radix(oct, 8).ok();
        }
        if tok.len() > 1 && tok.starts_with('0') && tok.bytes().all(|b| b.is_ascii_digit()) {
            return u64::from_str_radix(&tok[1..], 8).ok();
        }
        tok.parse::<u64>().ok()
    }
}

pub fn parse(input: &str) -> Result<Vec<Command>, String> {
    // JSON detection: if the first non-whitespace byte is '{', treat the
    // input as an nft JSON command stream (as produced by `nft -j list
    // ruleset` or hand-written for `nft -j -f file.json`). This is the
    // same convention upstream libnftables uses internally.
    if input.trim_start().starts_with('{') {
        let v = crate::json::parse(input).map_err(|e| format!("json: {}", e))?;
        return json_to_commands(&v);
    }

    // Variable preprocessor. nft(8) documents `define NAME = value`
    // declarations and `$NAME` references; both are purely textual
    // (the kernel never sees them). Strip defines out of the input
    // and substitute uses inline before tokenising. A value can span
    // multiple tokens (`define ADDRS = { 1.1.1.1, 2.2.2.2 }`), so we
    // capture up to end-of-line, respecting balanced braces.
    let input = expand_variables(input)?;
    let input = input.as_str();

    let tokens = tokenize(input);
    let mut parser = Parser::new(tokens);
    let mut cmds = Vec::new();
    while !parser.at_end() {
        while parser.matches(";") {}
        if parser.at_end() {
            break;
        }

        // Declarative top-level block: `table FAMILY NAME { ... }` with no
        // leading verb. Standard /etc/nftables.conf style.
        if parser.peek() == "table" {
            parser.parse_declarative_table(&mut cmds)?;
            if let Some(err) = parser.error.take() {
                return Err(err);
            }
            continue;
        }

        if let Some(cmd) = parser.parse_command()? {
            cmds.push(cmd);
        }
        if let Some(err) = parser.error.take() {
            return Err(err);
        }
    }
    Ok(cmds)
}

// ── JSON command interpreter ────────────────────────────────────
//
// Walks the {"nftables": [...]} array and turns each element into a
// Command. Handles both the verb-wrapped form used for command scripts
//   {"add": {"table": {...}}}
// and the bare-object form used for dumps
//   {"table": {...}}.
// Rules inside a JSON dump carry a "raw" string field with the
// text-rendered rule body; we re-parse that body through the text
// parser so stormwall can round-trip its own JSON output (the
// upstream framework runs `-j --check -f <json>` on stormwall's own
// emission and expects it to succeed).

use crate::json::Value as JV;

fn json_to_commands(v: &JV) -> Result<Vec<Command>, String> {
    let root = v.as_object().ok_or("json: expected top-level object")?;
    let arr = root
        .get("nftables")
        .and_then(|x| x.as_array())
        .ok_or("json: expected \"nftables\" array")?;
    let mut out = Vec::new();
    'items: for item in arr {
        let obj = match item.as_object() {
            Some(o) => o,
            None => continue,
        };
        if obj.contains_key("metainfo") {
            continue;
        }

        // Verb-wrapped forms: {"add": {"table": {...}}}. Upstream emits
        // these for command scripts. Each object carries exactly one
        // verb key; the nested value is the object spec.
        for (verb, op) in &[
            ("add", CmdOp::Add),
            ("create", CmdOp::Create),
            ("delete", CmdOp::Delete),
            ("destroy", CmdOp::Destroy),
            ("insert", CmdOp::Insert),
            ("replace", CmdOp::Replace),
            ("flush", CmdOp::Flush),
            ("reset", CmdOp::Reset),
        ] {
            if let Some(inner) = obj.get(*verb).and_then(|x| x.as_object()) {
                if let Some(cmd) = json_object_to_command(inner, op.clone())? {
                    out.push(cmd);
                }
                continue 'items;
            }
        }

        // Bare form (dump): {"table": {...}} → `add table ...`.
        if let Some(cmd) = json_object_to_command(obj, CmdOp::Add)? {
            out.push(cmd);
        }
    }
    Ok(out)
}

fn json_family(s: &str) -> u8 {
    match s {
        "ip" => NFPROTO_IPV4,
        "ip6" => NFPROTO_IPV6,
        "inet" => NFPROTO_INET,
        "arp" => NFPROTO_ARP,
        "bridge" => NFPROTO_BRIDGE,
        "netdev" => NFPROTO_NETDEV,
        _ => NFPROTO_IPV4,
    }
}

fn json_object_to_command(
    obj: &std::collections::BTreeMap<String, JV>,
    op: CmdOp,
) -> Result<Option<Command>, String> {
    // Each object has exactly one key naming the nft object type.
    // Support the common ones: table, chain, rule, set, map, element.
    let (kind, body) = match obj.iter().next() {
        Some((k, v)) => (
            k.as_str(),
            v.as_object().ok_or("json: nested must be object")?,
        ),
        None => return Ok(None),
    };

    let mut cmd = Command::default();
    cmd.op = op;
    cmd.family = body
        .get("family")
        .and_then(|x| x.as_str())
        .map(json_family)
        .unwrap_or(NFPROTO_IPV4);
    cmd.table = body
        .get("table")
        .and_then(|x| x.as_str())
        .unwrap_or("")
        .to_string();

    match kind {
        "table" => {
            cmd.obj = CmdObj::Table;
            cmd.table = body
                .get("name")
                .and_then(|x| x.as_str())
                .unwrap_or("")
                .to_string();
        }
        "chain" => {
            cmd.obj = CmdObj::Chain;
            cmd.chain = body
                .get("name")
                .and_then(|x| x.as_str())
                .unwrap_or("")
                .to_string();
            if let Some(t) = body.get("type").and_then(|x| x.as_str()) {
                cmd.chain_spec.chain_type = t.to_string();
                cmd.chain_spec.is_base = true;
            }
            if let Some(h) = body.get("hook").and_then(|x| x.as_str()) {
                cmd.chain_spec.hook = h.to_string();
            }
            if let Some(p) = body.get("prio").and_then(|x| x.as_i64()) {
                cmd.chain_spec.priority = p as i32;
                cmd.chain_spec.has_priority = true;
            }
            if let Some(pol) = body.get("policy").and_then(|x| x.as_str()) {
                cmd.chain_spec.policy = pol.to_string();
                cmd.chain_spec.has_policy = true;
            }
        }
        "rule" => {
            cmd.obj = CmdObj::Rule;
            cmd.chain = body
                .get("chain")
                .and_then(|x| x.as_str())
                .unwrap_or("")
                .to_string();
            if let Some(h) = body.get("handle").and_then(|x| x.as_u64()) {
                cmd.handle = h;
                cmd.has_handle = true;
            }
            if let Some(c) = body.get("comment").and_then(|x| x.as_str()) {
                cmd.comment = c.to_string();
                cmd.has_comment = true;
            }
            // If a "raw" text rendering is present (stormwall's own JSON
            // dump carries one), re-parse it through the text expression
            // parser so we can faithfully reconstruct the rule body.
            if let Some(raw) = body.get("raw").and_then(|x| x.as_str()) {
                if !raw.trim().is_empty() {
                    let synth = format!(
                        "add rule {} {} {} {}",
                        family_name_for_parse(cmd.family),
                        cmd.table,
                        cmd.chain,
                        raw
                    );
                    if let Ok(mut cmds) = parse(&synth) {
                        if let Some(inner) = cmds.pop() {
                            cmd.exprs = inner.exprs;
                            if inner.has_comment && !cmd.has_comment {
                                cmd.comment = inner.comment;
                                cmd.has_comment = true;
                            }
                        }
                    }
                }
            }
        }
        "set" | "map" => {
            cmd.obj = if kind == "map" {
                CmdObj::Map
            } else {
                CmdObj::Set
            };
            cmd.set_name = body
                .get("name")
                .and_then(|x| x.as_str())
                .unwrap_or("")
                .to_string();
            if let Some(t) = body.get("type").and_then(|x| x.as_str()) {
                let (kt, kl) = crate::netlink::set_key_type(t);
                cmd.set_spec.key_type_name = t.to_string();
                cmd.set_spec.key_type = kt;
                cmd.set_spec.key_len = kl;
            }
        }
        "element" => {
            cmd.obj = CmdObj::Element;
            cmd.set_name = body
                .get("name")
                .and_then(|x| x.as_str())
                .unwrap_or("")
                .to_string();
        }
        _ => return Ok(None), // unknown — silently ignore for --check
    }
    Ok(Some(cmd))
}

fn family_name_for_parse(f: u8) -> &'static str {
    match f {
        NFPROTO_IPV4 => "ip",
        NFPROTO_IPV6 => "ip6",
        NFPROTO_INET => "inet",
        NFPROTO_ARP => "arp",
        NFPROTO_BRIDGE => "bridge",
        NFPROTO_NETDEV => "netdev",
        _ => "ip",
    }
}

// ── Variable preprocessor ────────────────────────────────────────
//
// Handles `define NAME = value` declarations and `$NAME` references in
// a single preprocessor pass over the input text, before tokenisation.
// Value extends from after `=` to the end of the logical statement:
// the first semicolon or newline at brace-depth 0. Braces and
// double-quoted strings are tracked so `define ADDRS = { 1.1.1.1,
// 2.2.2.2 }` or a value spanning multiple lines both work.

// Minimal shell-style glob: `*` matches any non-slash sequence, `?`
// matches a single non-slash char, anything else literal. Returns
// absolute/relative paths the caller passed through, lexicographically
// sorted — matching nft's `include` behaviour. If the pattern has no
// wildcards the result is just `[pattern]` (to preserve the error
// path for "file not found" errors at read time).
fn glob_expand(pattern: &str) -> Vec<String> {
    let has_wild = pattern.chars().any(|c| c == '*' || c == '?' || c == '[');
    if !has_wild {
        return vec![pattern.to_string()];
    }

    // Split the pattern into (dir, filename-pattern).
    let (dir, fname) = match pattern.rfind('/') {
        Some(i) => (&pattern[..=i], &pattern[i + 1..]),
        None => ("./", pattern),
    };

    let entries = match std::fs::read_dir(dir) {
        Ok(it) => it,
        Err(_) => return Vec::new(),
    };
    let mut out: Vec<String> = Vec::new();
    for e in entries.flatten() {
        let name = match e.file_name().into_string() {
            Ok(s) => s,
            Err(_) => continue,
        };
        if name.starts_with('.') && !fname.starts_with('.') {
            continue;
        }
        if glob_match(fname, &name) {
            out.push(format!("{}{}", dir, name));
        }
    }
    out.sort();
    out
}

fn glob_match(pat: &str, s: &str) -> bool {
    // Standard recursive glob — `*` can match zero or more characters
    // within a single path component, `?` matches exactly one.
    let pat = pat.as_bytes();
    let s = s.as_bytes();
    fn rec(p: &[u8], s: &[u8]) -> bool {
        if p.is_empty() {
            return s.is_empty();
        }
        match p[0] {
            b'*' => {
                for i in 0..=s.len() {
                    if rec(&p[1..], &s[i..]) {
                        return true;
                    }
                }
                false
            }
            b'?' => !s.is_empty() && rec(&p[1..], &s[1..]),
            c => !s.is_empty() && s[0] == c && rec(&p[1..], &s[1..]),
        }
    }
    rec(pat, s)
}

fn expand_variables(src: &str) -> Result<String, String> {
    let mut defs: std::collections::HashMap<String, String> = std::collections::HashMap::new();
    expand_variables_with(&mut defs, src)
}

fn expand_variables_with(
    defs: &mut std::collections::HashMap<String, String>,
    src: &str,
) -> Result<String, String> {
    let mut out = String::with_capacity(src.len());

    let bytes = src.as_bytes();
    let mut i = 0usize;
    // Running brace depth so `$v` expansion can decide whether to
    // splice `{ ... }` values inline (stripped) vs. preserve the
    // braces when used outside another set literal. Matches upstream
    // where `elements = { 2.2.2.2, $addrs }` unfolds the brace-value.
    let mut brace_depth: i32 = 0;
    while i < bytes.len() {
        // Skip #-comments (preserve them in output).
        if bytes[i] == b'#' {
            while i < bytes.len() && bytes[i] != b'\n' {
                out.push(bytes[i] as char);
                i += 1;
            }
            continue;
        }
        // `include "..."` — inline the referenced file. Matches
        // nft(8)'s directive. Relative paths are resolved against
        // the process cwd; wildcards are expanded with glob order.
        if bytes[i] == b'i'
            && bytes[i..].starts_with(b"include ")
            && (i == 0 || matches!(bytes[i - 1], b' ' | b'\t' | b'\n' | b';'))
        {
            let mut j = i + "include ".len();
            while j < bytes.len() && matches!(bytes[j], b' ' | b'\t') {
                j += 1;
            }
            if j >= bytes.len() || bytes[j] != b'"' {
                i += 1;
                continue;
            }
            j += 1;
            let path_start = j;
            while j < bytes.len() && bytes[j] != b'"' {
                j += 1;
            }
            if j >= bytes.len() {
                return Err("unterminated include string".into());
            }
            let path = std::str::from_utf8(&bytes[path_start..j])
                .map_err(|e| e.to_string())?
                .to_string();
            j += 1; // skip closing quote
                    // Eat optional trailing ';' / '\n'.
            while j < bytes.len() && matches!(bytes[j], b' ' | b'\t') {
                j += 1;
            }
            if j < bytes.len() && (bytes[j] == b';' || bytes[j] == b'\n') {
                j += 1;
            }

            // Expand glob patterns; load each matched file in sorted
            // order and recursively run the preprocessor on it so
            // defines and nested includes inside the file work. The
            // recursive call shares the defs map so the included
            // file's variables are visible to the including one.
            let paths = glob_expand(&path);
            for p in &paths {
                let meta = std::fs::metadata(p).map_err(|e| format!("include {}: {}", p, e))?;
                if !meta.is_file() {
                    return Err(format!("include {}: not a regular file", p));
                }
                let body =
                    std::fs::read_to_string(p).map_err(|e| format!("include {}: {}", p, e))?;
                let expanded = expand_variables_with(defs, &body)?;
                out.push_str(&expanded);
                out.push('\n');
            }
            i = j;
            continue;
        }

        // $NAME reference.
        if bytes[i] == b'$' {
            let start = i + 1;
            let mut j = start;
            while j < bytes.len() && is_ident_byte(bytes[j]) {
                j += 1;
            }
            if j > start {
                let name = std::str::from_utf8(&bytes[start..j]).map_err(|e| e.to_string())?;
                let val = defs
                    .get(name)
                    .ok_or_else(|| format!("undefined variable: ${}", name))?;
                // Only splice `{ ... }` values when the variable is
                // already sitting in an existing literal list like
                // `{ a, $b, c }`. Table/chain/set blocks also use
                // braces, so `brace_depth > 0` alone is too broad for
                // cases like `ip saddr $addrs` or `elements = $addrs`.
                let trimmed = val.trim();
                let prev_sig = out.chars().rev().find(|c| !c.is_whitespace());
                let mut next_sig_idx = j;
                while next_sig_idx < bytes.len() && (bytes[next_sig_idx] as char).is_whitespace() {
                    next_sig_idx += 1;
                }
                let next_sig = bytes.get(next_sig_idx).copied();
                let splice_braces = brace_depth > 0
                    && trimmed.starts_with('{')
                    && trimmed.ends_with('}')
                    && trimmed.len() >= 2
                    && matches!(prev_sig, Some('{') | Some(','))
                    && matches!(next_sig, Some(b',') | Some(b'}'));
                if splice_braces {
                    out.push_str(trimmed[1..trimmed.len() - 1].trim());
                } else {
                    out.push_str(val);
                }
                i = j;
                continue;
            }
        }

        // Track braces for brace-aware $-expansion above. `{` opens
        // a context (we strip inner $set braces), `}` closes it.
        if bytes[i] == b'{' {
            brace_depth += 1;
        }
        if bytes[i] == b'}' {
            brace_depth = (brace_depth - 1).max(0);
        }
        // `define` / `redefine` / `undefine` directives — must start
        // a statement.
        let kw = if bytes[i..].starts_with(b"define ")
            && (i == 0 || matches!(bytes[i - 1], b' ' | b'\t' | b'\n' | b';'))
        {
            Some(("define", true, false))
        } else if bytes[i..].starts_with(b"redefine ")
            && (i == 0 || matches!(bytes[i - 1], b' ' | b'\t' | b'\n' | b';'))
        {
            Some(("redefine", true, true))
        } else if bytes[i..].starts_with(b"undefine ")
            && (i == 0 || matches!(bytes[i - 1], b' ' | b'\t' | b'\n' | b';'))
        {
            Some(("undefine", false, false))
        } else {
            None
        };
        if let Some((kind, has_value, allow_redefine)) = kw {
            i += kind.len() + 1;
            while i < bytes.len() && matches!(bytes[i], b' ' | b'\t') {
                i += 1;
            }
            let name_start = i;
            while i < bytes.len() && is_ident_byte(bytes[i]) {
                i += 1;
            }
            let name = std::str::from_utf8(&bytes[name_start..i])
                .map_err(|e| e.to_string())?
                .to_string();

            if !has_value {
                // `undefine NAME` — remove the binding. Error if
                // missing, matching nft(8).
                if defs.remove(&name).is_none() {
                    return Err(format!("undefine: unknown variable '{}'", name));
                }
                while i < bytes.len() && matches!(bytes[i], b' ' | b'\t') {
                    i += 1;
                }
                if i < bytes.len() && (bytes[i] == b';' || bytes[i] == b'\n') {
                    i += 1;
                }
                continue;
            }

            // `[re]define NAME = VALUE`.
            while i < bytes.len() && matches!(bytes[i], b' ' | b'\t') {
                i += 1;
            }
            if i >= bytes.len() || bytes[i] != b'=' {
                return Err(format!("{} {}: expected '='", kind, name));
            }
            i += 1;
            while i < bytes.len() && matches!(bytes[i], b' ' | b'\t') {
                i += 1;
            }
            let val_start = i;
            let mut depth = 0i32;
            let mut in_quote = false;
            while i < bytes.len() {
                let c = bytes[i];
                if in_quote {
                    if c == b'\\' && i + 1 < bytes.len() {
                        i += 2;
                        continue;
                    }
                    if c == b'"' {
                        in_quote = false;
                    }
                    i += 1;
                    continue;
                }
                match c {
                    b'"' => {
                        in_quote = true;
                        i += 1;
                    }
                    b'{' | b'(' | b'[' => {
                        depth += 1;
                        i += 1;
                    }
                    b'}' | b')' | b']' => {
                        depth -= 1;
                        i += 1;
                    }
                    b';' | b'\n' if depth == 0 => break,
                    _ => {
                        i += 1;
                    }
                }
            }
            let val = src[val_start..i].trim().to_string();
            // Expand with the current defs map so earlier
            // definitions (from CLI --define or previous lines) are
            // visible inside the new value.
            let expanded = expand_variables_with(defs, &val)?;

            // `define` on a name that already exists is an error.
            // `redefine` requires the name to already exist — nft(8)
            // is strict on both.
            match (defs.contains_key(&name), allow_redefine) {
                (true, false) => {
                    return Err(format!("variable '{}' already defined", name));
                }
                (false, true) => {
                    return Err(format!("redefine: unknown variable '{}'", name));
                }
                _ => {}
            }
            defs.insert(name, expanded);
            if i < bytes.len() && (bytes[i] == b';' || bytes[i] == b'\n') {
                i += 1;
            }
            continue;
        }
        // Pass char through (track string literal boundaries so `$` in
        // a quoted string isn't expanded — nft quoted strings are
        // literal).
        if bytes[i] == b'"' {
            out.push('"');
            i += 1;
            while i < bytes.len() {
                if bytes[i] == b'\\' && i + 1 < bytes.len() {
                    out.push(bytes[i] as char);
                    out.push(bytes[i + 1] as char);
                    i += 2;
                    continue;
                }
                out.push(bytes[i] as char);
                if bytes[i] == b'"' {
                    i += 1;
                    break;
                }
                i += 1;
            }
            continue;
        }
        out.push(bytes[i] as char);
        i += 1;
    }
    Ok(out)
}

fn is_ident_byte(b: u8) -> bool {
    b.is_ascii_alphanumeric() || matches!(b, b'_' | b'-')
}

// ── Helpers ─────────────────────────────────────────────────────

fn ct_state_val(s: &str) -> u32 {
    match s {
        "invalid" => 1,
        "established" => 2,
        "related" => 4,
        "new" => 8,
        "untracked" => 64,
        _ => 0,
    }
}

fn proto_num(s: &str) -> Option<u8> {
    match s {
        "tcp" => Some(6),
        "udp" => Some(17),
        "icmp" => Some(1),
        "igmp" => Some(2),
        "icmpv6" | "ipv6-icmp" => Some(58),
        "sctp" => Some(132),
        "esp" => Some(50),
        "comp" => Some(108),
        _ => None,
    }
}

fn service_num(s: &str) -> Option<u16> {
    match s {
        "bootps" => Some(67),
        "bootpc" => Some(68),
        "domain" => Some(53),
        "domain-s" => Some(853),
        "ntp" => Some(123),
        "http" => Some(80),
        "https" => Some(443),
        "printer" => Some(515),
        "ipp" => Some(631),
        "snmp" => Some(161),
        "ssh" => Some(22),
        "mdns" => Some(5353),
        "dhcpv6-client" => Some(546),
        "dhcpv6-server" => Some(547),
        "netbios-ns" => Some(137),
        "netbios-dgm" => Some(138),
        "netbios-ssn" => Some(139),
        "microsoft-ds" => Some(445),
        _ => None,
    }
}

fn icmp_type_num(s: &str) -> Option<u8> {
    match s {
        "destination-unreachable" => Some(3),
        "echo-request" => Some(8),
        "echo-reply" => Some(0),
        "time-exceeded" => Some(11),
        "parameter-problem" => Some(12),
        _ => None,
    }
}

fn icmpv6_type_num(s: &str) -> Option<u8> {
    match s {
        "destination-unreachable" => Some(1),
        "packet-too-big" => Some(2),
        "time-exceeded" => Some(3),
        "parameter-problem" => Some(4),
        "mld-listener-query" => Some(130),
        "nd-router-solicit" => Some(133),
        "nd-router-advert" => Some(134),
        "nd-neighbor-solicit" => Some(135),
        "nd-neighbor-advert" => Some(136),
        "mld2-listener-report" => Some(143),
        "echo-request" => Some(128),
        _ => None,
    }
}

fn log_level(s: &str) -> Option<u32> {
    match s {
        "emerg" => Some(NFT_LOGLEVEL_EMERG),
        "alert" => Some(NFT_LOGLEVEL_ALERT),
        "crit" => Some(NFT_LOGLEVEL_CRIT),
        "err" => Some(NFT_LOGLEVEL_ERR),
        "warning" => Some(NFT_LOGLEVEL_WARNING),
        "notice" => Some(NFT_LOGLEVEL_NOTICE),
        "info" => Some(NFT_LOGLEVEL_INFO),
        "debug" => Some(NFT_LOGLEVEL_DEBUG),
        "audit" => Some(NFT_LOGLEVEL_AUDIT),
        _ => None,
    }
}

fn limit_unit(s: &str) -> u64 {
    match s {
        "second" => 1u64,
        "minute" => 60,
        "hour" => 3600,
        "day" => 86400,
        "week" => 604800,
        _ => 1,
    }
}

fn meta_key(s: &str) -> Option<(u32, usize)> {
    match s {
        "iifname" => Some((NFT_META_IIFNAME, 16)),
        "oifname" => Some((NFT_META_OIFNAME, 16)),
        "iif" => Some((NFT_META_IIF, 4)),
        "oif" => Some((NFT_META_OIF, 4)),
        "mark" => Some((NFT_META_MARK, 4)),
        "skuid" => Some((NFT_META_SKUID, 4)),
        "skgid" => Some((NFT_META_SKGID, 4)),
        "nfproto" => Some((NFT_META_NFPROTO, 1)),
        "l4proto" => Some((NFT_META_L4PROTO, 1)),
        "pkttype" => Some((NFT_META_PKTTYPE, 4)),
        "length" => Some((NFT_META_LEN, 4)),
        "protocol" => Some((NFT_META_PROTOCOL, 2)),
        _ => None,
    }
}

fn nfproto_num(s: &str) -> Option<u8> {
    match s {
        "ip" | "ipv4" => Some(NFPROTO_IPV4),
        "ip6" | "ipv6" => Some(NFPROTO_IPV6),
        "inet" => Some(NFPROTO_INET),
        "arp" => Some(NFPROTO_ARP),
        "bridge" => Some(NFPROTO_BRIDGE),
        "netdev" => Some(NFPROTO_NETDEV),
        _ => None,
    }
}

fn fib_addrtype_num(s: &str) -> Option<u32> {
    match s {
        "unicast" => Some(1),
        "local" => Some(2),
        "broadcast" => Some(3),
        "anycast" => Some(4),
        "multicast" => Some(5),
        "blackhole" => Some(6),
        "unreachable" => Some(7),
        "prohibit" => Some(8),
        "throw" => Some(9),
        "nat" => Some(10),
        "xresolve" => Some(11),
        _ => None,
    }
}

fn reject_icmpx_code(s: &str) -> Option<u8> {
    match s {
        "no-route" => Some(NFT_REJECT_ICMPX_NO_ROUTE),
        "port-unreachable" => Some(NFT_REJECT_ICMPX_PORT_UNREACH),
        "host-unreachable" => Some(NFT_REJECT_ICMPX_HOST_UNREACH),
        "admin-prohibited" => Some(NFT_REJECT_ICMPX_ADMIN_PROHIBITED),
        _ => None,
    }
}

fn ct_key(s: &str) -> Option<(u32, usize)> {
    match s {
        "state" => Some((NFT_CT_STATE, 4)),
        "mark" => Some((NFT_CT_MARK, 4)),
        "status" => Some((NFT_CT_STATUS, 4)),
        "direction" => Some((NFT_CT_DIRECTION, 1)),
        "zone" => Some((NFT_CT_ZONE, 2)),
        "helper" => Some((NFT_CT_HELPER, 16)),
        "l3proto" => Some((NFT_CT_L3PROTOCOL, 1)),
        "protocol" => Some((NFT_CT_PROTOCOL, 1)),
        "bytes" => Some((NFT_CT_BYTES, 8)),
        "packets" => Some((NFT_CT_PKTS, 8)),
        "expiration" => Some((NFT_CT_EXPIRATION, 4)),
        "label" => Some((NFT_CT_LABELS, 16)),
        _ => None,
    }
}

fn is_statement_start(s: &str) -> bool {
    matches!(
        s,
        "accept"
            | "drop"
            | "reject"
            | "return"
            | "jump"
            | "goto"
            | "continue"
            | "counter"
            | "quota"
            | "log"
            | "limit"
            | "masquerade"
            | "snat"
            | "dnat"
            | "notrack"
            | "add"
            | "update"
            | "set"
            | "queue"
            | "flow"
            | "tproxy"
            | "meta"
            | "ct"
            | "ip"
            | "ip6"
            | "tcp"
            | "udp"
            | "icmp"
            | "ether"
            | "iifname"
            | "oifname"
            | "comment"
    )
}

// ── Tests ────────────────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;
    use crate::netlink::*;
    use std::str::FromStr;

    // Helper: parse exactly one command, panic otherwise
    fn parse_one(input: &str) -> Command {
        let mut cmds = parse(input).expect("parse failed");
        assert_eq!(cmds.len(), 1, "expected 1 command, got {}", cmds.len());
        cmds.remove(0)
    }

    // ── Basic table commands ─────────────────────────────────────

    #[test]
    fn test_add_table_ip() {
        let cmd = parse_one("add table ip mytable");
        assert!(matches!(cmd.op, CmdOp::Add));
        assert!(matches!(cmd.obj, CmdObj::Table));
        assert_eq!(cmd.family, NFPROTO_IPV4);
        assert_eq!(cmd.table, "mytable");
    }

    #[test]
    fn test_add_table_inet() {
        let cmd = parse_one("add table inet filter");
        assert!(matches!(cmd.op, CmdOp::Add));
        assert!(matches!(cmd.obj, CmdObj::Table));
        assert_eq!(cmd.family, NFPROTO_INET);
        assert_eq!(cmd.table, "filter");
    }

    #[test]
    fn test_delete_table() {
        let cmd = parse_one("delete table ip mytable");
        assert!(matches!(cmd.op, CmdOp::Delete));
        assert!(matches!(cmd.obj, CmdObj::Table));
        assert_eq!(cmd.family, NFPROTO_IPV4);
        assert_eq!(cmd.table, "mytable");
    }

    #[test]
    fn test_list_ruleset() {
        let cmd = parse_one("list ruleset");
        assert!(matches!(cmd.op, CmdOp::List));
        assert!(matches!(cmd.obj, CmdObj::Ruleset));
    }

    #[test]
    fn test_list_tables() {
        let cmd = parse_one("list tables");
        assert!(matches!(cmd.op, CmdOp::List));
        assert!(matches!(cmd.obj, CmdObj::Tables));
    }

    #[test]
    fn test_flush_ruleset() {
        let cmd = parse_one("flush ruleset");
        assert!(matches!(cmd.op, CmdOp::Flush));
        assert!(matches!(cmd.obj, CmdObj::Ruleset));
    }

    // ── Basic chain commands ─────────────────────────────────────

    #[test]
    fn test_add_chain() {
        let cmd = parse_one("add chain ip filter mychain");
        assert!(matches!(cmd.op, CmdOp::Add));
        assert!(matches!(cmd.obj, CmdObj::Chain));
        assert_eq!(cmd.family, NFPROTO_IPV4);
        assert_eq!(cmd.table, "filter");
        assert_eq!(cmd.chain, "mychain");
    }

    #[test]
    fn test_delete_chain() {
        let cmd = parse_one("delete chain inet filter input");
        assert!(matches!(cmd.op, CmdOp::Delete));
        assert!(matches!(cmd.obj, CmdObj::Chain));
        assert_eq!(cmd.family, NFPROTO_INET);
        assert_eq!(cmd.table, "filter");
        assert_eq!(cmd.chain, "input");
    }

    #[test]
    fn test_list_chain() {
        let cmd = parse_one("list chain ip filter mychain");
        assert!(matches!(cmd.op, CmdOp::List));
        assert!(matches!(cmd.obj, CmdObj::Chain));
        assert_eq!(cmd.table, "filter");
        assert_eq!(cmd.chain, "mychain");
    }

    // ── Base chain spec ──────────────────────────────────────────

    #[test]
    fn test_add_chain_base_chain_spec() {
        let cmd = parse_one(
            "add chain inet filter input { type filter hook input priority filter; policy accept; }"
        );
        assert!(matches!(cmd.op, CmdOp::Add));
        assert!(matches!(cmd.obj, CmdObj::Chain));
        assert_eq!(cmd.family, NFPROTO_INET);
        assert_eq!(cmd.table, "filter");
        assert_eq!(cmd.chain, "input");

        let cs = &cmd.chain_spec;
        assert!(cs.is_base, "expected is_base=true");
        assert_eq!(cs.chain_type, "filter");
        assert_eq!(cs.hook, "input");
        assert_eq!(cs.priority, 0, "filter priority on inet should be 0");
        assert!(cs.has_priority);
        assert_eq!(cs.policy, "accept");
        assert!(cs.has_policy);
    }

    #[test]
    fn test_add_chain_prerouting_dstnat() {
        let cmd = parse_one(
            "add chain ip nat prerouting { type nat hook prerouting priority dstnat; policy accept; }"
        );
        let cs = &cmd.chain_spec;
        assert!(cs.is_base);
        assert_eq!(cs.chain_type, "nat");
        assert_eq!(cs.hook, "prerouting");
        // dstnat priority on ip = -100
        assert_eq!(cs.priority, -100);
        assert!(cs.has_policy);
        assert_eq!(cs.policy, "accept");
    }

    #[test]
    fn test_add_chain_numeric_priority() {
        let cmd = parse_one(
            "add chain ip filter fwd { type filter hook forward priority 50; policy drop; }",
        );
        let cs = &cmd.chain_spec;
        assert!(cs.is_base);
        assert_eq!(cs.priority, 50);
        assert_eq!(cs.policy, "drop");
    }

    // ── Basic rule commands ──────────────────────────────────────

    #[test]
    fn test_add_rule_empty() {
        let cmd = parse_one("add rule ip filter input accept");
        assert!(matches!(cmd.op, CmdOp::Add));
        assert!(matches!(cmd.obj, CmdObj::Rule));
        assert_eq!(cmd.family, NFPROTO_IPV4);
        assert_eq!(cmd.table, "filter");
        assert_eq!(cmd.chain, "input");
    }

    #[test]
    fn test_delete_rule_by_handle() {
        let cmd = parse_one("delete rule ip filter input handle 42");
        assert!(matches!(cmd.op, CmdOp::Delete));
        assert!(matches!(cmd.obj, CmdObj::Rule));
        assert_eq!(cmd.handle, 42);
        assert!(cmd.has_handle);
    }

    // ── Rule expressions: ip saddr/daddr ─────────────────────────

    #[test]
    fn test_rule_ip_saddr() {
        let cmd = parse_one("add rule ip filter input ip saddr 192.168.1.1 accept");
        let exprs = &cmd.exprs;
        // Payload load + Cmp + Verdict
        assert!(
            exprs.len() >= 3,
            "expected at least 3 exprs, got {}",
            exprs.len()
        );

        match &exprs[0] {
            Expr::Payload {
                base, offset, len, ..
            } => {
                assert_eq!(*base, NFT_PAYLOAD_NETWORK_HEADER);
                assert_eq!(*offset, 12); // saddr offset
                assert_eq!(*len, 4);
            }
            other => panic!("expected Payload, got {:?}", other),
        }
        match &exprs[1] {
            Expr::Cmp { op, data } => {
                assert_eq!(*op, NFT_CMP_EQ);
                assert_eq!(data, &[192, 168, 1, 1]);
            }
            other => panic!("expected Cmp, got {:?}", other),
        }
        match &exprs[2] {
            Expr::Verdict { code, .. } => assert_eq!(*code, NF_ACCEPT),
            other => panic!("expected Verdict, got {:?}", other),
        }
    }

    #[test]
    fn test_rule_ip_daddr() {
        let cmd = parse_one("add rule ip filter output ip daddr 10.0.0.1 drop");
        let exprs = &cmd.exprs;
        match &exprs[0] {
            Expr::Payload { offset, .. } => assert_eq!(*offset, 16), // daddr offset
            other => panic!("expected Payload, got {:?}", other),
        }
        match &exprs[1] {
            Expr::Cmp { data, .. } => assert_eq!(data, &[10, 0, 0, 1]),
            other => panic!("expected Cmp, got {:?}", other),
        }
        match &exprs[2] {
            Expr::Verdict { code, .. } => assert_eq!(*code, NF_DROP),
            other => panic!("expected Verdict(drop), got {:?}", other),
        }
    }

    // ── Rule expressions: tcp dport ──────────────────────────────

    #[test]
    fn test_rule_tcp_dport() {
        let cmd = parse_one("add rule ip filter input tcp dport 80 accept");
        let exprs = &cmd.exprs;
        match &exprs[0] {
            Expr::Meta { key, width, .. } => {
                assert_eq!(*key, NFT_META_L4PROTO);
                assert_eq!(*width, 1);
            }
            other => panic!("expected Meta(l4proto), got {:?}", other),
        }
        match &exprs[1] {
            Expr::Cmp { data, .. } => assert_eq!(data, &[6]),
            other => panic!("expected Cmp(tcp), got {:?}", other),
        }
        match &exprs[2] {
            Expr::Payload {
                base,
                offset,
                len,
                protocol,
                ..
            } => {
                assert_eq!(*base, NFT_PAYLOAD_TRANSPORT_HEADER);
                assert_eq!(*offset, 2);
                assert_eq!(*len, 2);
                assert_eq!(*protocol, 6); // TCP
            }
            other => panic!("expected Payload, got {:?}", other),
        }
        match &exprs[3] {
            Expr::Cmp { data, .. } => assert_eq!(data, &[0, 80]),
            other => panic!("expected Cmp(80), got {:?}", other),
        }
    }

    #[test]
    fn test_rule_tcp_sport() {
        let cmd = parse_one("add rule ip filter input tcp sport 443 accept");
        match &cmd.exprs[0] {
            Expr::Meta { key, width, .. } => {
                assert_eq!(*key, NFT_META_L4PROTO);
                assert_eq!(*width, 1);
            }
            other => panic!("expected Meta(l4proto), got {:?}", other),
        }
        match &cmd.exprs[1] {
            Expr::Cmp { data, .. } => assert_eq!(data, &[6]),
            other => panic!("expected Cmp(tcp), got {:?}", other),
        }
        match &cmd.exprs[2] {
            Expr::Payload { offset, .. } => assert_eq!(*offset, 0),
            other => panic!("expected Payload, got {:?}", other),
        }
        match &cmd.exprs[3] {
            Expr::Cmp { data, .. } => assert_eq!(data, &[1, 187]), // 443 = 0x01BB
            other => panic!("expected Cmp, got {:?}", other),
        }
    }

    #[test]
    fn test_rule_queue_num_reorders_ports() {
        let cmd = parse_one(
            "add rule ip filter input tcp dport 1 tcp sport 1 meta oifname \"foobar\" queue num 0 bypass"
        );
        assert!(matches!(&cmd.exprs[2], Expr::Payload { offset, .. } if *offset == 0));
        assert!(matches!(&cmd.exprs[4], Expr::Payload { offset, .. } if *offset == 2));
        assert!(matches!(
            cmd.exprs.last(),
            Some(Expr::Queue { num: Some(0), total: None, flags, sreg_qnum: None })
                if *flags == NFT_QUEUE_FLAG_BYPASS
        ));
    }

    #[test]
    fn test_rule_queue_symhash() {
        let cmd = parse_one(
            "add rule ip filter input tcp dport 1 tcp sport 1 meta oifname \"foobar\" queue to symhash mod 2"
        );
        assert!(matches!(
            &cmd.exprs[8],
            Expr::Hash { hash_type, modulus, sreg, len, dreg, .. }
                if *hash_type == NFT_HASH_SYM
                    && *modulus == 2
                    && sreg.is_none()
                    && *len == 0
                    && *dreg == NFT_REG32_00
        ));
        assert!(matches!(
            &cmd.exprs[9],
            Expr::Queue { num: None, total: None, flags: 0, sreg_qnum: Some(reg) }
                if *reg == NFT_REG32_00
        ));
    }

    #[test]
    fn test_rule_queue_jhash() {
        let cmd = parse_one(
            "add rule ip filter input tcp dport 1 tcp sport 1 meta oifname \"foobar\" queue flags bypass to jhash tcp dport . tcp sport mod 4"
        );
        assert!(matches!(&cmd.exprs[2], Expr::Payload { offset, .. } if *offset == 0));
        assert!(matches!(&cmd.exprs[4], Expr::Payload { offset, .. } if *offset == 2));
        assert!(matches!(
            &cmd.exprs[8],
            Expr::Payload { offset, dreg, .. }
                if *offset == 2 && *dreg == Some(NFT_REG32_01)
        ));
        assert!(matches!(
            &cmd.exprs[9],
            Expr::Payload { offset, dreg, .. }
                if *offset == 0 && *dreg == Some(NFT_REG32_02)
        ));
        assert!(matches!(
            &cmd.exprs[10],
            Expr::Hash { hash_type, modulus, sreg, len, dreg, .. }
                if *hash_type == NFT_HASH_JENKINS
                    && *modulus == 4
                    && *sreg == Some(NFT_REG32_01)
                    && *len == 8
                    && *dreg == NFT_REG32_00
        ));
        assert!(matches!(
            &cmd.exprs[11],
            Expr::Queue { num: None, total: None, flags, sreg_qnum: Some(reg) }
                if *flags == NFT_QUEUE_FLAG_BYPASS && *reg == NFT_REG32_00
        ));
    }

    #[test]
    fn test_rule_payload_set_numgen_map_spaced_range() {
        let cmd = parse_one(
            "add rule inet statelessnat prerouting ip daddr set numgen inc mod 16 map { 0-7 : 10.0.1.1, 8- 15 : 10.0.1.2 }"
        );

        assert!(
            matches!(&cmd.exprs[0], Expr::Numgen { mode, modulus, offset, dreg }
            if *mode == NFT_NG_INCREMENTAL && *modulus == 16 && *offset == 0 && *dreg == NFT_REG32_00)
        );
        assert!(
            matches!(&cmd.exprs[1], Expr::Byteorder { op, len, size, sreg, dreg }
            if *op == NFT_BYTEORDER_HTON && *len == 4 && *size == 4 && *sreg == NFT_REG32_00 && *dreg == NFT_REG32_00)
        );
        match &cmd.exprs[2] {
            Expr::AnonMap {
                pairs,
                key_type,
                data_type,
                data_len,
                dreg,
                ..
            } => {
                assert_eq!(*key_type, Some(4));
                assert_eq!(*data_type, 7);
                assert_eq!(*data_len, 4);
                assert_eq!(*dreg, NFT_REG32_00);
                assert_eq!(pairs.len(), 2);
                assert_eq!(pairs[0].0, 0u32.to_be_bytes());
                assert_eq!(pairs[0].1.as_deref(), Some(7u32.to_be_bytes().as_slice()));
                assert_eq!(pairs[0].2, [10, 0, 1, 1]);
                assert_eq!(pairs[1].0, 8u32.to_be_bytes());
                assert_eq!(pairs[1].1.as_deref(), Some(15u32.to_be_bytes().as_slice()));
                assert_eq!(pairs[1].2, [10, 0, 1, 2]);
            }
            other => panic!("expected AnonMap, got {:?}", other),
        }
        assert!(
            matches!(&cmd.exprs[3], Expr::PayloadSet { base, offset, len, sreg, csum_type, csum_offset, csum_flags }
            if *base == NFT_PAYLOAD_NETWORK_HEADER
                && *offset == 16
                && *len == 4
                && *sreg == NFT_REG32_00
                && *csum_type == NFT_PAYLOAD_CSUM_INET
                && *csum_offset == 10
                && *csum_flags == NFT_PAYLOAD_L4CSUM_PSEUDOHDR)
        );
    }

    #[test]
    fn test_rule_queue_named_map() {
        let cmd = parse_one(
            "add rule inet t test queue flags bypass to ip saddr . ip daddr . tcp dport map @get_queue_id"
        );
        assert!(matches!(&cmd.exprs[0], Expr::Payload { offset, .. } if *offset == 12));
        assert!(matches!(&cmd.exprs[1], Expr::Payload { offset, .. } if *offset == 16));
        assert!(matches!(&cmd.exprs[2], Expr::Meta { key, .. } if *key == NFT_META_L4PROTO));
        assert!(matches!(&cmd.exprs[3], Expr::Cmp { data, .. } if data == &[6]));
        assert!(matches!(&cmd.exprs[4], Expr::Payload { offset, .. } if *offset == 2));
        assert!(matches!(
            &cmd.exprs[5],
            Expr::Map { set_name, key_type: Some(key_type), dreg, .. }
                if set_name == "get_queue_id"
                    && *key_type == crate::netlink::concat_type_add(crate::netlink::concat_type_add(7, 7), 13)
                    && *dreg == NFT_REG32_00
        ));
        assert!(matches!(
            &cmd.exprs[6],
            Expr::Queue { flags, sreg_qnum: Some(reg), num: None, total: None }
                if *flags == NFT_QUEUE_FLAG_BYPASS && *reg == NFT_REG32_00
        ));
    }

    #[test]
    fn test_rule_tproxy_port_only() {
        let cmd = parse_one("add rule inet test prerouting meta l4proto @protos tproxy to :1088");
        assert!(matches!(&cmd.exprs[0], Expr::Meta { key, .. } if *key == NFT_META_L4PROTO));
        assert!(matches!(&cmd.exprs[1], Expr::Lookup { set_name, .. } if set_name == "protos"));
        assert!(matches!(
            &cmd.exprs[2],
            Expr::Tproxy { family, addr: None, port: Some(port) }
                if *family == NFPROTO_UNSPEC && port == &1088u16.to_be_bytes().to_vec()
        ));
    }

    // ── Rule expressions: meta iifname ───────────────────────────

    #[test]
    fn test_rule_meta_iifname() {
        // Use unquoted name so parse_value gets plain bytes without surrounding quotes
        let cmd = parse_one("add rule ip filter input meta iifname eth0 accept");
        match &cmd.exprs[0] {
            Expr::Meta { key, .. } => assert_eq!(*key, NFT_META_IIFNAME),
            other => panic!("expected Meta, got {:?}", other),
        }
        match &cmd.exprs[1] {
            Expr::Cmp { data, .. } => {
                // Interface name: "eth0" + null terminator, padded to 16 bytes
                assert_eq!(data[0..4], *b"eth0");
                assert_eq!(data[4], 0); // null terminator
            }
            other => panic!("expected Cmp, got {:?}", other),
        }
    }

    #[test]
    fn test_rule_meta_length() {
        let cmd = parse_one("add rule ip filter input meta length 128 accept");
        match &cmd.exprs[0] {
            Expr::Meta { key, .. } => assert_eq!(*key, NFT_META_LEN),
            other => panic!("expected Meta(length), got {:?}", other),
        }
    }

    #[test]
    fn test_rule_iifname_shorthand() {
        let cmd = parse_one("add rule ip filter input iifname lo accept");
        match &cmd.exprs[0] {
            Expr::Meta { key, .. } => assert_eq!(*key, NFT_META_IIFNAME),
            other => panic!("expected Meta(iifname), got {:?}", other),
        }
    }

    #[test]
    fn test_rule_oifname_shorthand() {
        let cmd = parse_one("add rule ip filter output oifname eth0 drop");
        match &cmd.exprs[0] {
            Expr::Meta { key, .. } => assert_eq!(*key, NFT_META_OIFNAME),
            other => panic!("expected Meta(oifname), got {:?}", other),
        }
    }

    #[test]
    fn test_rule_fib_check_missing() {
        let cmd = parse_one(
            "add rule inet filter input meta nfproto ipv6 fib saddr . iif check missing drop",
        );
        assert!(
            matches!(&cmd.exprs[0], Expr::Meta { key, width, .. } if *key == NFT_META_NFPROTO && *width == 1)
        );
        assert!(matches!(&cmd.exprs[1], Expr::Cmp { data, .. } if data == &[10]));
        assert!(
            matches!(&cmd.exprs[2], Expr::Fib { result, flags, width, .. }
            if *result == NFT_FIB_RESULT_OIF
            && *flags == (NFTA_FIB_F_SADDR | NFTA_FIB_F_IIF | NFTA_FIB_F_PRESENT)
            && *width == 1)
        );
        assert!(
            matches!(&cmd.exprs[3], Expr::Cmp { op, data } if *op == NFT_CMP_EQ && data == &[0])
        );
        assert!(matches!(&cmd.exprs[4], Expr::Verdict { code, .. } if *code == NF_DROP));
    }

    #[test]
    fn test_rule_fib_oif_eq_zero_uses_oif_as_result() {
        let cmd = parse_one("add rule inet t c fib saddr . iif oif eq 0 drop");
        assert!(
            matches!(&cmd.exprs[0], Expr::Fib { result, flags, width, .. }
                if *result == NFT_FIB_RESULT_OIF
                    && *flags == (NFTA_FIB_F_SADDR | NFTA_FIB_F_IIF)
                    && *width == 4)
        );
        assert!(
            matches!(&cmd.exprs[1], Expr::Cmp { op, data }
                if *op == NFT_CMP_EQ && data == &[0, 0, 0, 0])
        );
        assert!(matches!(&cmd.exprs[2], Expr::Verdict { code, .. } if *code == NF_DROP));
    }

    // ── Rule expressions: ct state ───────────────────────────────

    #[test]
    fn test_rule_ct_state_established() {
        let cmd = parse_one("add rule ip filter input ct state established accept");
        match &cmd.exprs[0] {
            Expr::Ct { key, dir, .. } => {
                assert_eq!(*key, NFT_CT_STATE);
                assert_eq!(*dir, -1);
            }
            other => panic!("expected Ct, got {:?}", other),
        }
        // ct state uses bitwise mask matching
        match &cmd.exprs[1] {
            Expr::Bitwise { mask, xor } => {
                let val = u32::from_ne_bytes(mask[..4].try_into().unwrap());
                assert_eq!(val, 2); // established = 2
                assert_eq!(xor, &[0, 0, 0, 0]);
            }
            other => panic!("expected Bitwise, got {:?}", other),
        }
        match &cmd.exprs[2] {
            Expr::Cmp { op, data } => {
                assert_eq!(*op, NFT_CMP_NEQ);
                assert_eq!(data, &[0, 0, 0, 0]);
            }
            other => panic!("expected Cmp(NEQ, 0), got {:?}", other),
        }
    }

    #[test]
    fn test_rule_ct_state_new_established() {
        let cmd = parse_one("add rule ip filter input ct state new,established accept");
        match &cmd.exprs[1] {
            Expr::Bitwise { mask, .. } => {
                let val = u32::from_ne_bytes(mask[..4].try_into().unwrap());
                assert_eq!(val, 8 | 2); // new=8, established=2
            }
            other => panic!("expected Bitwise, got {:?}", other),
        }
        match &cmd.exprs[2] {
            Expr::Cmp { op, data } => {
                assert_eq!(*op, NFT_CMP_NEQ);
                assert_eq!(data, &[0, 0, 0, 0]);
            }
            other => panic!("expected Cmp(NEQ, 0), got {:?}", other),
        }
    }

    // ── Rule expressions: counter ────────────────────────────────

    #[test]
    fn test_rule_counter() {
        let cmd = parse_one("add rule ip filter input counter accept");
        assert!(
            cmd.exprs.iter().any(|e| matches!(e, Expr::Counter { .. })),
            "expected Counter expr"
        );
    }

    // ── Rule expressions: log ────────────────────────────────────

    #[test]
    fn test_rule_log_no_prefix() {
        let cmd = parse_one("add rule ip filter input log drop");
        assert!(
            cmd.exprs.iter().any(|e| matches!(e, Expr::Log { .. })),
            "expected Log expr"
        );
    }

    #[test]
    fn test_rule_log_with_prefix() {
        let cmd = parse_one("add rule ip filter input log prefix \"DROP: \" drop");
        let log_expr = cmd.exprs.iter().find(|e| matches!(e, Expr::Log { .. }));
        assert!(log_expr.is_some());
        match log_expr.unwrap() {
            Expr::Log { prefix, .. } => assert_eq!(prefix, "DROP: "),
            _ => unreachable!(),
        }
    }

    // ── Rule expressions: limit ──────────────────────────────────

    #[test]
    fn test_rule_limit_rate() {
        // The parser expects rate, "/", and unit as separate tokens
        let cmd = parse_one("add rule ip filter input limit rate 100 / second accept");
        let limit_expr = cmd.exprs.iter().find(|e| matches!(e, Expr::Limit { .. }));
        assert!(limit_expr.is_some(), "expected Limit expr");
        match limit_expr.unwrap() {
            Expr::Limit { rate, unit, .. } => {
                assert_eq!(*rate, 100);
                assert_eq!(*unit, 1); // second = 1
            }
            _ => unreachable!(),
        }
    }

    #[test]
    fn test_rule_limit_per_minute() {
        // The parser expects rate, "/", and unit as separate tokens
        let cmd = parse_one("add rule ip filter input limit rate 10 / minute accept");
        let limit_expr = cmd.exprs.iter().find(|e| matches!(e, Expr::Limit { .. }));
        match limit_expr.unwrap() {
            Expr::Limit { rate, unit, .. } => {
                assert_eq!(*rate, 10);
                assert_eq!(*unit, 60); // minute = 60
            }
            _ => unreachable!(),
        }
    }

    // ── Rule expressions: verdicts ───────────────────────────────

    #[test]
    fn test_rule_verdict_accept() {
        let cmd = parse_one("add rule ip filter input accept");
        let v = cmd.exprs.iter().find(|e| matches!(e, Expr::Verdict { .. }));
        match v.unwrap() {
            Expr::Verdict { code, .. } => assert_eq!(*code, NF_ACCEPT),
            _ => unreachable!(),
        }
    }

    #[test]
    fn test_rule_verdict_drop() {
        let cmd = parse_one("add rule ip filter input drop");
        let v = cmd.exprs.iter().find(|e| matches!(e, Expr::Verdict { .. }));
        match v.unwrap() {
            Expr::Verdict { code, .. } => assert_eq!(*code, NF_DROP),
            _ => unreachable!(),
        }
    }

    #[test]
    fn test_rule_verdict_jump() {
        let cmd = parse_one("add rule ip filter input jump log-and-drop");
        let v = cmd.exprs.iter().find(|e| matches!(e, Expr::Verdict { .. }));
        match v.unwrap() {
            Expr::Verdict { code, chain } => {
                assert_eq!(*code, NFT_JUMP);
                assert_eq!(chain, "log-and-drop");
            }
            _ => unreachable!(),
        }
    }

    #[test]
    fn test_rule_verdict_goto() {
        let cmd = parse_one("add rule ip filter input goto mychaintarget");
        let v = cmd.exprs.iter().find(|e| matches!(e, Expr::Verdict { .. }));
        match v.unwrap() {
            Expr::Verdict { code, chain } => {
                assert_eq!(*code, NFT_GOTO);
                assert_eq!(chain, "mychaintarget");
            }
            _ => unreachable!(),
        }
    }

    // ── Rule expressions: masquerade ─────────────────────────────

    #[test]
    fn test_rule_masquerade() {
        let cmd = parse_one("add rule ip nat postrouting masquerade");
        assert!(
            cmd.exprs.iter().any(|e| matches!(e, Expr::Masquerade)),
            "expected Masquerade expr"
        );
    }

    // ── Rule expressions: snat/dnat ──────────────────────────────

    #[test]
    fn test_rule_snat() {
        let cmd = parse_one("add rule ip nat postrouting snat to 203.0.113.5");
        let nat = cmd.exprs.iter().find(|e| matches!(e, Expr::Nat { .. }));
        assert!(nat.is_some(), "expected Nat expr");
        match nat.unwrap() {
            Expr::Nat {
                nat_type,
                addr,
                has_addr,
                has_port,
                ..
            } => {
                assert_eq!(*nat_type, NFT_NAT_SNAT);
                assert!(has_addr);
                assert!(!has_port);
                assert_eq!(addr, &[203, 0, 113, 5]);
            }
            _ => unreachable!(),
        }
    }

    #[test]
    fn test_rule_dnat() {
        let cmd = parse_one("add rule ip nat prerouting dnat to 10.0.0.10");
        let nat = cmd.exprs.iter().find(|e| matches!(e, Expr::Nat { .. }));
        match nat.unwrap() {
            Expr::Nat {
                nat_type,
                addr,
                has_addr,
                ..
            } => {
                assert_eq!(*nat_type, NFT_NAT_DNAT);
                assert!(has_addr);
                assert_eq!(addr, &[10, 0, 0, 10]);
            }
            _ => unreachable!(),
        }
    }

    #[test]
    fn test_rule_dnat_to_port_only() {
        let cmd = parse_one("add rule ip nat prerouting dnat to :8080");
        let nat = cmd
            .exprs
            .iter()
            .find(|e| matches!(e, Expr::Nat { .. }))
            .unwrap();
        match nat {
            Expr::Nat {
                nat_type,
                family,
                has_addr,
                port,
                has_port,
                ..
            } => {
                assert_eq!(*nat_type, NFT_NAT_DNAT);
                assert_eq!(*family, NFPROTO_IPV4);
                assert!(!has_addr);
                assert!(*has_port);
                assert_eq!(*port, 8080);
            }
            _ => unreachable!(),
        }
    }

    #[test]
    fn test_rule_dnat_ip_to_addr_port() {
        let cmd = parse_one("add rule inet nat prerouting dnat ip to 10.0.0.10:8080");
        let nat = cmd
            .exprs
            .iter()
            .find(|e| matches!(e, Expr::Nat { .. }))
            .unwrap();
        match nat {
            Expr::Nat {
                nat_type,
                family,
                addr,
                has_addr,
                port,
                has_port,
            } => {
                assert_eq!(*nat_type, NFT_NAT_DNAT);
                assert_eq!(*family, NFPROTO_IPV4);
                assert!(has_addr);
                assert!(*has_port);
                assert_eq!(addr, &[10, 0, 0, 10]);
                assert_eq!(*port, 8080);
            }
            _ => unreachable!(),
        }
    }

    #[test]
    fn test_reject_nat_map_protocol_suffix() {
        let err = parse(
            r#"table t {
 chain y {
  snat to ip saddr . tcp sport map { 1.1.1.1 . 1 : 1.1.1.2 . 1 } : 6
 }
}"#,
        )
        .expect_err("nat map with protocol suffix should fail");
        assert!(
            err.contains("unsupported nat target 'ip'"),
            "unexpected error: {}",
            err
        );
    }

    #[test]
    fn test_reject_synproxy_objmap_prefix_value() {
        let err = parse(
            r#"table t {
        chain y {
                type filter hook input priority filter; policy accept;
                synproxy name ip saddr map { 192.168.1.0/24 : "x*" }
        }
}"#,
        )
        .expect_err("synproxy object map prefix value should fail");
        assert!(
            err.contains("invalid synproxy object map value '\"x*\"'"),
            "unexpected error: {}",
            err
        );
    }

    #[test]
    fn test_reject_policy_on_regular_chain() {
        let err = parse(
            r#"table ip x {
        chain y {
                policy drop;
        }
}"#,
        )
        .expect_err("policy on regular chain should fail");
        assert!(
            err.contains("chain policy is only valid for base chains"),
            "unexpected error: {}",
            err
        );
    }

    #[test]
    fn test_reject_empty_chain_device_name() {
        let err = parse(
            r#"table netdev x {
        chain Main_Ingress1 {
                type filter hook ingress device "" priority -1
        }
}"#,
        )
        .expect_err("empty chain device name should fail");
        assert!(
            err.contains("device name must not be empty"),
            "unexpected error: {}",
            err
        );
    }

    // ── Rule expressions: notrack/reject ─────────────────────────

    #[test]
    fn test_rule_notrack() {
        let cmd = parse_one("add rule ip raw prerouting notrack");
        assert!(
            cmd.exprs.iter().any(|e| matches!(e, Expr::Notrack)),
            "expected Notrack expr"
        );
    }

    #[test]
    fn test_rule_reject() {
        let cmd = parse_one("add rule ip filter input reject");
        assert!(
            cmd.exprs
                .iter()
                .any(|e| matches!(e, Expr::Reject { rej_type, icmp_code }
            if *rej_type == NFT_REJECT_ICMP_UNREACH && *icmp_code == Some(ICMP_PORT_UNREACH))),
            "expected Reject expr"
        );
    }

    #[test]
    fn test_rule_reject_icmpx_admin_prohibited() {
        let cmd = parse_one("add rule inet filter input reject with icmpx type admin-prohibited");
        assert!(
            cmd.exprs
                .iter()
                .any(|e| matches!(e, Expr::Reject { rej_type, icmp_code }
            if *rej_type == NFT_REJECT_ICMPX_UNREACH
                && *icmp_code == Some(NFT_REJECT_ICMPX_ADMIN_PROHIBITED))),
            "expected Reject expr"
        );
    }

    // ── CIDR matching ────────────────────────────────────────────

    #[test]
    fn test_rule_cidr_8() {
        let cmd = parse_one("add rule ip filter input ip saddr 10.0.0.0/8 accept");
        // Expected: Payload, Bitwise, Cmp, Verdict
        assert!(
            cmd.exprs.len() >= 3,
            "expected at least 3 exprs, got {}",
            cmd.exprs.len()
        );

        match &cmd.exprs[0] {
            Expr::Payload {
                base, offset, len, ..
            } => {
                assert_eq!(*base, NFT_PAYLOAD_NETWORK_HEADER);
                assert_eq!(*offset, 12);
                assert_eq!(*len, 4);
            }
            other => panic!("expected Payload, got {:?}", other),
        }
        match &cmd.exprs[1] {
            Expr::Bitwise { mask, xor } => {
                // /8 mask: 0xff 0x00 0x00 0x00
                assert_eq!(mask, &[0xff, 0x00, 0x00, 0x00]);
                assert_eq!(xor, &[0x00, 0x00, 0x00, 0x00]);
            }
            other => panic!("expected Bitwise, got {:?}", other),
        }
        match &cmd.exprs[2] {
            Expr::Cmp { data, .. } => {
                // 10.0.0.0 & /8 mask = [10, 0, 0, 0]
                assert_eq!(data, &[10, 0, 0, 0]);
            }
            other => panic!("expected Cmp, got {:?}", other),
        }
    }

    #[test]
    fn test_rule_cidr_24() {
        let cmd = parse_one("add rule ip filter input ip saddr 192.168.1.0/24 drop");
        match &cmd.exprs[1] {
            Expr::Bitwise { mask, .. } => {
                // /24 mask: 0xff 0xff 0xff 0x00
                assert_eq!(mask, &[0xff, 0xff, 0xff, 0x00]);
            }
            other => panic!("expected Bitwise, got {:?}", other),
        }
        match &cmd.exprs[2] {
            Expr::Cmp { data, .. } => {
                assert_eq!(data, &[192, 168, 1, 0]);
            }
            other => panic!("expected Cmp, got {:?}", other),
        }
    }

    #[test]
    fn test_rule_cidr_32() {
        let cmd = parse_one("add rule ip filter input ip saddr 1.2.3.4/32 accept");
        match &cmd.exprs[1] {
            Expr::Bitwise { mask, .. } => {
                assert_eq!(mask, &[0xff, 0xff, 0xff, 0xff]);
            }
            other => panic!("expected Bitwise, got {:?}", other),
        }
        match &cmd.exprs[2] {
            Expr::Cmp { data, .. } => {
                assert_eq!(data, &[1, 2, 3, 4]);
            }
            other => panic!("expected Cmp, got {:?}", other),
        }
    }

    // ── Rename chain ─────────────────────────────────────────────

    #[test]
    fn test_rename_chain() {
        let cmd = parse_one("rename chain inet filter old_name new_name");
        assert!(matches!(cmd.op, CmdOp::Rename));
        assert!(matches!(cmd.obj, CmdObj::Chain));
        assert_eq!(cmd.family, NFPROTO_INET);
        assert_eq!(cmd.table, "filter");
        assert_eq!(cmd.chain, "old_name");
        assert_eq!(cmd.new_name, "new_name");
    }

    #[test]
    fn test_rename_chain_ip() {
        let cmd = parse_one("rename chain ip mytable src dst");
        assert!(matches!(cmd.op, CmdOp::Rename));
        assert_eq!(cmd.family, NFPROTO_IPV4);
        assert_eq!(cmd.table, "mytable");
        assert_eq!(cmd.chain, "src");
        assert_eq!(cmd.new_name, "dst");
    }

    // ── add set ──────────────────────────────────────────────────

    #[test]
    fn test_add_set_ipv4_constant() {
        let cmd = parse_one("add set inet filter myset { type ipv4_addr; flags constant; }");
        assert!(matches!(cmd.op, CmdOp::Add));
        assert!(matches!(cmd.obj, CmdObj::Set));
        assert_eq!(cmd.family, NFPROTO_INET);
        assert_eq!(cmd.table, "filter");
        assert_eq!(cmd.set_name, "myset");

        let ss = &cmd.set_spec;
        assert_eq!(ss.key_type_name, "ipv4_addr");
        assert_eq!(ss.key_type, 7); // ipv4_addr type id
        assert_eq!(ss.key_len, 4); // 4 bytes
        assert!(ss.has_flags);
        assert_eq!(ss.flags & 0x2, 0x2, "expected constant flag (0x2)");
    }

    #[test]
    fn test_add_set_ipv4_interval() {
        let cmd = parse_one("add set ip filter blocked { type ipv4_addr; flags interval; }");
        let ss = &cmd.set_spec;
        assert_eq!(ss.key_type, 7);
        assert_eq!(ss.key_len, 4);
        assert!(ss.has_flags);
        assert_eq!(ss.flags & 0x4, 0x4, "expected interval flag (0x4)");
    }

    #[test]
    fn test_add_set_inet_service() {
        let cmd = parse_one("add set ip filter ports { type inet_service; }");
        let ss = &cmd.set_spec;
        assert_eq!(ss.key_type_name, "inet_service");
        assert_eq!(ss.key_type, 13);
        assert_eq!(ss.key_len, 2);
    }

    #[test]
    fn test_add_set_typeof_meta_l4proto() {
        let cmd = parse_one("add set inet test protos { typeof meta l4proto; }");
        let ss = &cmd.set_spec;
        assert_eq!(ss.key_type_name, "meta l4proto");
        assert_eq!(ss.key_type, 12);
        assert_eq!(ss.key_len, 1);
    }

    // ── delete set ───────────────────────────────────────────────

    #[test]
    fn test_delete_set() {
        let cmd = parse_one("delete set inet filter myset");
        assert!(matches!(cmd.op, CmdOp::Delete));
        assert!(matches!(cmd.obj, CmdObj::Set));
        assert_eq!(cmd.family, NFPROTO_INET);
        assert_eq!(cmd.table, "filter");
        assert_eq!(cmd.set_name, "myset");
    }

    // ── add element ──────────────────────────────────────────────

    #[test]
    fn test_add_element_ipv4() {
        let cmd = parse_one("add element inet filter myset { 10.0.0.1, 10.0.0.2 }");
        assert!(matches!(cmd.op, CmdOp::Add));
        assert!(matches!(cmd.obj, CmdObj::Element));
        assert_eq!(cmd.family, NFPROTO_INET);
        assert_eq!(cmd.table, "filter");
        assert_eq!(cmd.set_name, "myset");

        assert_eq!(cmd.elements.len(), 2);
        assert_eq!(cmd.elements[0], (vec![10, 0, 0, 1], None));
        assert_eq!(cmd.elements[1], (vec![10, 0, 0, 2], None));
    }

    #[test]
    fn test_add_element_single() {
        let cmd = parse_one("add element ip filter myset { 192.168.0.1 }");
        assert_eq!(cmd.elements.len(), 1);
        assert_eq!(cmd.elements[0], (vec![192, 168, 0, 1], None));
    }

    #[test]
    fn test_add_element_three_addrs() {
        let cmd = parse_one("add element ip filter myset { 1.1.1.1, 8.8.8.8, 9.9.9.9 }");
        assert_eq!(cmd.elements.len(), 3);
        assert_eq!(cmd.elements[0], (vec![1, 1, 1, 1], None));
        assert_eq!(cmd.elements[1], (vec![8, 8, 8, 8], None));
        assert_eq!(cmd.elements[2], (vec![9, 9, 9, 9], None));
    }

    #[test]
    fn test_add_element_compact_verdict_map_entry() {
        let cmd = parse_one("add element ip filter mymap { 10080:drop }");
        assert_eq!(cmd.elements.len(), 1);
        assert_eq!(cmd.elements[0], (10080u32.to_be_bytes().to_vec(), None));
        assert_eq!(cmd.element_verdicts, vec![(NF_DROP, String::new())]);
        assert_eq!(cmd.element_datas, vec![None]);
    }

    #[test]
    fn test_reject_invalid_verdict_map_element() {
        let input = "table ip foo {\n\
            map bar {\n\
                type ipv4_addr : verdict\n\
                elements = { 192.168.0.1 : ber }\n\
            }\n\
        }\n";
        assert!(parse(input).is_err());
    }

    #[test]
    fn test_parse_set_element_counter_and_limit_statements() {
        let input = "table ip foo {\n\
            set inflows_ratelimit {\n\
                type ipv4_addr . inet_service . ifname . ipv4_addr . inet_service\n\
                flags dynamic\n\
                elements = { 10.1.0.3 . 39466 . \"veth1\" . 10.3.0.99 . 5201 limit rate 1/second counter packets 0 bytes 0 }\n\
            }\n\
        }\n";
        let cmds = parse(input).expect("parse failed");
        let ecmd = cmds
            .iter()
            .find(|cmd| matches!(cmd.obj, CmdObj::Element))
            .expect("missing add element command");
        assert_eq!(ecmd.elements.len(), 1);
        assert_eq!(ecmd.element_exprs.len(), 1);
        assert!(matches!(
            ecmd.element_exprs[0].as_slice(),
            [
                Expr::Limit {
                    rate: 1,
                    unit: 1,
                    ..
                },
                Expr::Counter {
                    packets: 0,
                    bytes: 0
                },
            ]
        ));
    }

    #[test]
    fn test_parse_concat_element_ifname_padding() {
        let input = "table ip foo {\n\
            set inflows {\n\
                type ipv4_addr . inet_service . ifname . ipv4_addr . inet_service\n\
                flags dynamic\n\
                elements = { 10.1.0.3 . 39466 . \"veth1\" . 10.3.0.99 . 5201 }\n\
            }\n\
        }\n";
        let cmds = parse(input).expect("parse failed");
        let ecmd = cmds
            .iter()
            .find(|cmd| matches!(cmd.obj, CmdObj::Element))
            .expect("missing add element command");
        let key = &ecmd.elements[0].0;
        assert_eq!(key.len(), 32);
        assert_eq!(&key[0..4], &[10, 1, 0, 3]);
        assert_eq!(&key[4..8], &[0x9a, 0x2a, 0x00, 0x00]);
        assert_eq!(&key[8..14], b"veth1\0");
        assert_eq!(&key[24..28], &[10, 3, 0, 99]);
        assert_eq!(&key[28..32], &[0x14, 0x51, 0x00, 0x00]);
    }

    #[test]
    fn test_add_element_respects_known_set_type() {
        let input = "table inet filter {\n\
            set whitelist_v4 { type ipv4_addr; }\n\
        }\n\
        add element inet filter whitelist_v4 { wrong }\n";
        assert!(parse(input).is_err());
    }

    // ── delete element ───────────────────────────────────────────

    #[test]
    fn test_delete_element() {
        let cmd = parse_one("delete element inet filter myset { 10.0.0.1 }");
        assert!(matches!(cmd.op, CmdOp::Delete));
        assert!(matches!(cmd.obj, CmdObj::Element));
        assert_eq!(cmd.table, "filter");
        assert_eq!(cmd.set_name, "myset");
        assert_eq!(cmd.elements.len(), 1);
        assert_eq!(cmd.elements[0], (vec![10, 0, 0, 1], None));
    }

    // ── Multiple commands separated by semicolons ─────────────────

    #[test]
    fn test_multiple_commands_semicolons() {
        let cmds = parse(
            "add table inet filter; add chain inet filter input; add chain inet filter output",
        )
        .expect("parse failed");
        assert_eq!(cmds.len(), 3);

        assert!(matches!(cmds[0].op, CmdOp::Add));
        assert!(matches!(cmds[0].obj, CmdObj::Table));
        assert_eq!(cmds[0].table, "filter");

        assert!(matches!(cmds[1].op, CmdOp::Add));
        assert!(matches!(cmds[1].obj, CmdObj::Chain));
        assert_eq!(cmds[1].chain, "input");

        assert!(matches!(cmds[2].op, CmdOp::Add));
        assert!(matches!(cmds[2].obj, CmdObj::Chain));
        assert_eq!(cmds[2].chain, "output");
    }

    #[test]
    fn test_multiple_commands_with_trailing_semicolon() {
        let cmds = parse("add table ip filter; delete table ip filter;").expect("parse failed");
        assert_eq!(cmds.len(), 2);
    }

    // ── File input with newlines ──────────────────────────────────

    #[test]
    fn test_file_input_newlines() {
        let input =
            "add table inet filter\nadd chain inet filter input\nadd rule ip filter input accept\n";
        let cmds = parse(input).expect("parse failed");
        assert_eq!(cmds.len(), 3);
        assert!(matches!(cmds[0].obj, CmdObj::Table));
        assert!(matches!(cmds[1].obj, CmdObj::Chain));
        assert!(matches!(cmds[2].obj, CmdObj::Rule));
    }

    #[test]
    fn test_file_input_comments_and_newlines() {
        let input = "# This is a comment\nadd table inet filter\n# Another comment\nadd chain inet filter input\n";
        let cmds = parse(input).expect("parse failed");
        assert_eq!(cmds.len(), 2);
        assert_eq!(cmds[0].table, "filter");
        assert_eq!(cmds[1].chain, "input");
    }

    #[test]
    fn test_file_input_mixed_semicolons_and_newlines() {
        let input = "add table ip filter\nadd chain ip filter input; add chain ip filter output\nadd rule ip filter input accept\n";
        let cmds = parse(input).expect("parse failed");
        assert_eq!(cmds.len(), 4);
    }

    #[test]
    fn test_declarative_table_defers_verdict_map_elements_until_after_chains() {
        let cmds = parse(
            r#"table inet t {
            map m {
                type ifname : verdict
                elements = { "eth0" : jump c_late }
            }
            chain c_early {
                iifname vmap @m
            }
            chain c_late {
            }
        }"#,
        )
        .expect("parse failed");
        let chain_last = cmds
            .iter()
            .rposition(|cmd| matches!(cmd.obj, CmdObj::Chain))
            .expect("chain command");
        let elem_idx = cmds
            .iter()
            .position(|cmd| matches!(cmd.obj, CmdObj::Element))
            .expect("element command");
        let rule_idx = cmds
            .iter()
            .position(|cmd| matches!(cmd.obj, CmdObj::Rule))
            .expect("rule command");
        assert!(
            elem_idx > chain_last,
            "verdict map elements should be emitted after chains"
        );
        assert!(
            elem_idx < rule_idx,
            "verdict map elements should still precede rules"
        );
    }

    // ── Compound rule expressions ─────────────────────────────────

    #[test]
    fn test_rule_counter_and_accept() {
        let cmd = parse_one("add rule inet filter input counter accept");
        assert!(cmd.exprs.iter().any(|e| matches!(e, Expr::Counter { .. })));
        assert!(cmd
            .exprs
            .iter()
            .any(|e| matches!(e, Expr::Verdict { code, .. } if *code == NF_ACCEPT)));
    }

    #[test]
    fn test_rule_tcp_dport_counter_accept() {
        let cmd = parse_one("add rule inet filter input tcp dport 443 counter accept");
        assert!(cmd.exprs.iter().any(|e| matches!(e, Expr::Payload { .. })));
        assert!(cmd.exprs.iter().any(|e| matches!(e, Expr::Counter { .. })));
        assert!(cmd.exprs.iter().any(|e| matches!(e, Expr::Verdict { .. })));
    }

    #[test]
    fn test_rule_ct_state_established_related_accept() {
        let cmd = parse_one("add rule inet filter input ct state established,related accept");
        match &cmd.exprs[1] {
            Expr::Bitwise { mask, .. } => {
                let val = u32::from_ne_bytes(mask[..4].try_into().unwrap());
                assert_eq!(val, 2 | 4); // established=2, related=4
            }
            other => panic!("expected Bitwise, got {:?}", other),
        }
        match &cmd.exprs[2] {
            Expr::Cmp { op, data } => {
                assert_eq!(*op, NFT_CMP_NEQ);
                assert_eq!(data, &[0, 0, 0, 0]);
            }
            other => panic!("expected Cmp(NEQ, 0), got {:?}", other),
        }
    }

    // ── Neq comparison ────────────────────────────────────────────

    #[test]
    fn test_rule_neq_comparison() {
        let cmd = parse_one("add rule ip filter input ip saddr != 10.0.0.1 accept");
        match &cmd.exprs[1] {
            Expr::Cmp { op, data } => {
                assert_eq!(*op, NFT_CMP_NEQ);
                assert_eq!(data, &[10, 0, 0, 1]);
            }
            other => panic!("expected Cmp(neq), got {:?}", other),
        }
    }

    // ── Family defaults ───────────────────────────────────────────

    #[test]
    fn test_family_default_ip_for_table() {
        // Without explicit family on table, defaults to NFPROTO_IPV4
        let cmd = parse_one("add table filter");
        assert_eq!(cmd.family, NFPROTO_IPV4);
        assert_eq!(cmd.table, "filter");
    }

    #[test]
    fn test_family_ipv6() {
        let cmd = parse_one("add table ip6 mytable");
        assert_eq!(cmd.family, NFPROTO_IPV6);
    }

    #[test]
    fn test_family_bridge() {
        let cmd = parse_one("add table bridge mytable");
        assert_eq!(cmd.family, NFPROTO_BRIDGE);
    }

    #[test]
    fn test_family_netdev() {
        let cmd = parse_one("add table netdev mytable");
        assert_eq!(cmd.family, NFPROTO_NETDEV);
    }

    // ── Priority from named strings ───────────────────────────────

    #[test]
    fn test_priority_raw() {
        let cmd = parse_one(
            "add chain ip filter prerouting { type filter hook prerouting priority raw; policy accept; }"
        );
        assert_eq!(cmd.chain_spec.priority, -300);
    }

    #[test]
    fn test_priority_mangle() {
        let cmd = parse_one(
            "add chain ip filter prerouting { type filter hook prerouting priority mangle; policy accept; }"
        );
        assert_eq!(cmd.chain_spec.priority, -150);
    }

    #[test]
    fn test_priority_srcnat() {
        let cmd = parse_one(
            "add chain ip nat postrouting { type nat hook postrouting priority srcnat; policy accept; }"
        );
        assert_eq!(cmd.chain_spec.priority, 100);
    }

    // ── Flush table/chain ─────────────────────────────────────────

    #[test]
    fn test_flush_table() {
        let cmd = parse_one("flush table ip filter");
        assert!(matches!(cmd.op, CmdOp::Flush));
        assert!(matches!(cmd.obj, CmdObj::Table));
        assert_eq!(cmd.table, "filter");
    }

    #[test]
    fn test_flush_chain() {
        let cmd = parse_one("flush chain ip filter input");
        assert!(matches!(cmd.op, CmdOp::Flush));
        assert!(matches!(cmd.obj, CmdObj::Chain));
        assert_eq!(cmd.table, "filter");
        assert_eq!(cmd.chain, "input");
    }

    // ── Insert rule ───────────────────────────────────────────────

    #[test]
    fn test_insert_rule() {
        let cmd = parse_one("insert rule ip filter input drop");
        assert!(matches!(cmd.op, CmdOp::Insert));
        assert!(matches!(cmd.obj, CmdObj::Rule));
        assert!(cmd
            .exprs
            .iter()
            .any(|e| matches!(e, Expr::Verdict { code, .. } if *code == NF_DROP)));
    }

    // ── Destroy commands ──────────────────────────────────────────

    #[test]
    fn test_destroy_table() {
        let cmd = parse_one("destroy table ip mytable");
        assert!(matches!(cmd.op, CmdOp::Destroy));
        assert!(matches!(cmd.obj, CmdObj::Table));
        assert_eq!(cmd.table, "mytable");
    }

    // ── Create command ────────────────────────────────────────────

    #[test]
    fn test_create_table() {
        let cmd = parse_one("create table inet filter");
        assert!(matches!(cmd.op, CmdOp::Create));
        assert!(matches!(cmd.obj, CmdObj::Table));
        assert_eq!(cmd.family, NFPROTO_INET);
        assert_eq!(cmd.table, "filter");
    }

    #[test]
    fn test_create_chain_base() {
        let cmd = parse_one(
            "create chain ip nat postrouting { type nat hook postrouting priority 100; policy accept; }"
        );
        assert!(matches!(cmd.op, CmdOp::Create));
        assert!(matches!(cmd.obj, CmdObj::Chain));
        assert!(cmd.chain_spec.is_base);
        assert_eq!(cmd.chain_spec.priority, 100);
    }

    // ── Rule with handle ──────────────────────────────────────────

    #[test]
    fn test_rule_with_position_handle() {
        let cmd = parse_one("add rule ip filter input handle 7 accept");
        assert_eq!(cmd.handle, 7);
        assert!(cmd.has_handle);
        assert!(cmd
            .exprs
            .iter()
            .any(|e| matches!(e, Expr::Verdict { code, .. } if *code == NF_ACCEPT)));
    }

    // ── Quoted names ──────────────────────────────────────────────

    #[test]
    fn test_quoted_chain_name() {
        let cmd = parse_one("add chain ip filter \"my chain\"");
        assert_eq!(cmd.chain, "my chain");
    }

    #[test]
    fn test_quoted_table_name() {
        let cmd = parse_one("add table ip \"my table\"");
        assert_eq!(cmd.table, "my table");
    }

    // ── List chains/rules/sets ────────────────────────────────────

    #[test]
    fn test_list_chains() {
        let cmd = parse_one("list chains");
        assert!(matches!(cmd.op, CmdOp::List));
        assert!(matches!(cmd.obj, CmdObj::Chains));
    }

    #[test]
    fn test_list_rules() {
        let cmd = parse_one("list rules");
        assert!(matches!(cmd.op, CmdOp::List));
        assert!(matches!(cmd.obj, CmdObj::Rules));
    }

    #[test]
    fn test_list_sets() {
        let cmd = parse_one("list sets");
        assert!(matches!(cmd.op, CmdOp::List));
        assert!(matches!(cmd.obj, CmdObj::Sets));
    }

    // ── Map object ────────────────────────────────────────────────

    #[test]
    fn test_add_map() {
        let cmd = parse_one("add map ip filter mymap { type ipv4_addr : inet_service; }");
        assert!(matches!(cmd.op, CmdOp::Add));
        assert!(matches!(cmd.obj, CmdObj::Map));
        assert_eq!(cmd.set_name, "mymap");
        assert!(cmd.set_spec.is_map);
        assert_eq!(cmd.set_spec.key_type, 7); // ipv4_addr
        assert_eq!(cmd.set_spec.key_len, 4);
        assert_eq!(cmd.set_spec.data_type, 13); // inet_service
        assert_eq!(cmd.set_spec.data_len, 2);
    }

    #[test]
    fn test_add_map_compact_type() {
        let cmd = parse_one("add map ip filter mymap { type inet_service:verdict; }");
        assert!(cmd.set_spec.is_map);
        assert_eq!(cmd.set_spec.key_type_name, "inet_service");
        assert_eq!(cmd.set_spec.key_type, 13);
        assert_eq!(cmd.set_spec.key_len, 2);
        assert_eq!(cmd.set_spec.data_type_name, "verdict");
        assert_eq!(cmd.set_spec.data_type, 0xffffff00);
        assert_eq!(cmd.set_spec.data_len, 0);
    }

    #[test]
    fn test_add_map_typeof_concat_queue() {
        let cmd = parse_one(
            "add map inet t get_queue_id { typeof ip saddr . ip daddr . tcp dport : queue; }",
        );
        assert!(cmd.set_spec.is_map);
        assert_eq!(
            cmd.set_spec.key_type_name,
            "ip saddr . ip daddr . tcp dport"
        );
        assert_eq!(cmd.set_spec.key_field_types, vec![7, 7, 13]);
        assert_eq!(cmd.set_spec.key_field_lens, vec![4, 4, 2]);
        assert_eq!(cmd.set_spec.data_type_name, "queue");
        assert_eq!(cmd.set_spec.data_type, 4);
        assert_eq!(cmd.set_spec.data_len, 2);
    }

    #[test]
    fn test_rule_anon_vmap_compact_pairs() {
        let cmd = parse_one("add rule ip filter input udp sport vmap {1111:accept, 2222:drop}");
        let expr = cmd
            .exprs
            .iter()
            .find_map(|e| {
                if let Expr::AnonVmap { pairs, width, .. } = e {
                    Some((pairs, *width))
                } else {
                    None
                }
            })
            .expect("anon vmap expr");
        assert_eq!(expr.1, 2);
        assert_eq!(expr.0.len(), 2);
        assert_eq!(
            expr.0[0],
            (
                1111u16.to_be_bytes().to_vec(),
                None,
                NF_ACCEPT,
                String::new()
            )
        );
        assert_eq!(
            expr.0[1],
            (2222u16.to_be_bytes().to_vec(), None, NF_DROP, String::new())
        );
    }

    #[test]
    fn test_rule_anon_vmap_ipv6_keys() {
        let cmd = parse_one(
            "add rule ip6 filter input ip6 daddr vmap { fe0::1 : drop, fe0::2 : accept }",
        );
        let expr = cmd
            .exprs
            .iter()
            .find_map(|e| {
                if let Expr::AnonVmap { pairs, width, .. } = e {
                    Some((pairs, *width))
                } else {
                    None
                }
            })
            .expect("anon vmap expr");
        assert_eq!(expr.1, 16);
        assert_eq!(expr.0.len(), 2);
        assert_eq!(expr.0[0].2, NF_DROP);
        assert_eq!(expr.0[1].2, NF_ACCEPT);
        assert_eq!(
            expr.0[0].0,
            std::net::Ipv6Addr::from_str("fe0::1")
                .unwrap()
                .octets()
                .to_vec()
        );
        assert_eq!(
            expr.0[1].0,
            std::net::Ipv6Addr::from_str("fe0::2")
                .unwrap()
                .octets()
                .to_vec()
        );
    }

    #[test]
    fn test_rule_anon_vmap_interval_key() {
        let cmd = parse_one("add rule ip filter input udp dport vmap { 100-222 : accept }");
        let expr = cmd
            .exprs
            .iter()
            .find_map(|e| {
                if let Expr::AnonVmap { pairs, width, .. } = e {
                    Some((pairs, *width))
                } else {
                    None
                }
            })
            .expect("anon vmap expr");
        assert_eq!(expr.1, 2);
        assert_eq!(
            expr.0,
            &vec![(
                100u16.to_be_bytes().to_vec(),
                Some(222u16.to_be_bytes().to_vec()),
                NF_ACCEPT,
                String::new(),
            )]
        );
    }

    #[test]
    fn test_reject_invalid_raw_concat_vmap_masklen() {
        let input = r#"table inet t {
        chain c {
                udp length . @th,160,138 vmap { 47-63 . 0xe37313536313033&131303735353203 : accept }
        }
}"#;
        let err = parse(input).expect_err("invalid raw payload concat should fail");
        assert!(
            err.contains("invalid concat selector '@th,160,138'")
                || err.contains("invalid raw payload selector '@th,160,138'"),
            "unexpected error: {}",
            err
        );
    }

    #[test]
    fn test_parse_raw_payload_selector_split_tokens() {
        let cmd = parse_one("add rule inet t c @th,160,32 0x02736c00 drop");
        assert!(
            matches!(&cmd.exprs[0], Expr::Payload { base, offset, len, .. }
            if *base == NFT_PAYLOAD_TRANSPORT_HEADER && *offset == 20 && *len == 4)
        );
        assert!(matches!(&cmd.exprs[1], Expr::Cmp { data, .. }
            if data == &vec![0x02, 0x73, 0x6c, 0x00]));
        assert!(matches!(&cmd.exprs[2], Expr::Verdict { code, .. } if *code == NF_DROP));
    }

    #[test]
    fn test_reject_invalid_counter_objref_tail() {
        let input = r#"table inet x {
        chain y {
                counter name ip saddr bytes 1.1.1. 1024
        }
}"#;
        let err = parse(input).expect_err("invalid counter objref tail should fail");
        assert!(
            err.contains("unexpected token 'saddr' after counter name"),
            "unexpected error: {}",
            err
        );
    }

    #[test]
    fn test_declarative_counter_object_parses() {
        let cmds = parse(
            r#"table ip t {
        counter c { packets 1 bytes 2 }
}"#,
        )
        .expect("declarative counter should parse");
        assert_eq!(cmds.len(), 2);
        assert!(matches!(cmds[0].obj, CmdObj::Table));
        assert!(matches!(cmds[1].obj, CmdObj::Counter));
        assert_eq!(cmds[1].table, "t");
        assert_eq!(cmds[1].set_name, "c");
        assert_eq!(cmds[1].obj_spec.packets, 1);
        assert_eq!(cmds[1].obj_spec.bytes, 2);
    }

    #[test]
    fn test_declarative_ct_timeout_object_parses() {
        let cmds = parse(
            r#"table ip t {
        ct timeout ctt {
                protocol tcp
                l3proto ip
                policy = { established : 123, close : 12s }
        }
}"#,
        )
        .expect("declarative ct timeout should parse");
        assert_eq!(cmds.len(), 2);
        assert!(matches!(cmds[1].obj, CmdObj::CtTimeout));
        assert_eq!(cmds[1].obj_spec.ct_l4proto, 6);
        assert_eq!(cmds[1].obj_spec.ct_l3proto, NFPROTO_IPV4 as u16);
        assert_eq!(cmds[1].obj_spec.ct_timeout_policy.len(), 2);
        assert_eq!(
            cmds[1].obj_spec.ct_timeout_policy[0],
            ("established".to_string(), 123)
        );
        assert_eq!(
            cmds[1].obj_spec.ct_timeout_policy[1],
            ("close".to_string(), 12)
        );
    }

    #[test]
    fn test_reject_unclosed_declarative_table() {
        let err = parse(
            r#"table ip filter {
        ct timeout cttime {
                protocol tcp
                l3proto ip
                policy = { close : 12s }
"#,
        )
        .expect_err("unclosed declarative table should fail");
        assert!(
            err.contains("expected '}' to close table 'filter'"),
            "unexpected error: {}",
            err
        );
    }

    #[test]
    fn test_rule_ct_timeout_objref_parses() {
        let cmd = parse_one(r#"add rule ip t c ct timeout set "cttime""#);
        assert!(matches!(&cmd.exprs[0], Expr::ObjRef { kind, name }
            if *kind == NFT_OBJECT_CT_TIMEOUT && name == "cttime"));
    }

    #[test]
    fn test_parse_duration_ms_compound() {
        assert_eq!(Parser::parse_duration_ms("2m3s"), Some(123_000));
        assert_eq!(Parser::parse_duration_ms("1h2m3s4ms"), Some(3_723_004));
    }

    #[test]
    fn test_rule_rt_type_inet_injects_ipv6_dependency() {
        let cmd = parse_one("add rule inet t c rt type 0 drop");
        assert!(matches!(&cmd.exprs[0], Expr::Meta { key, .. } if *key == NFT_META_NFPROTO));
        assert!(matches!(&cmd.exprs[1], Expr::Cmp { data, .. } if data == &vec![NFPROTO_IPV6]));
        assert!(
            matches!(&cmd.exprs[2], Expr::Exthdr { raw_type, offset, len, op, .. }
            if *raw_type == IPPROTO_ROUTING && *offset == 2 && *len == 1 && *op == NFT_EXTHDR_OP_IPV6)
        );
        assert!(matches!(&cmd.exprs[3], Expr::Cmp { data, .. } if data == &vec![0]));
    }

    #[test]
    fn test_rule_tcp_option_maxseg_size_set_rt_mtu() {
        let cmd = parse_one("add rule inet t c tcp option maxseg size set rt mtu");
        assert!(matches!(&cmd.exprs[0], Expr::Meta { key, .. } if *key == NFT_META_L4PROTO));
        assert!(matches!(&cmd.exprs[1], Expr::Cmp { data, .. } if data == &vec![6]));
        assert!(
            matches!(&cmd.exprs[2], Expr::Rt { key, width, .. } if *key == NFT_RT_TCPMSS && *width == 2)
        );
        assert!(
            matches!(&cmd.exprs[3], Expr::Byteorder { op, len, size, .. }
            if *op == NFT_BYTEORDER_HTON && *len == 2 && *size == 2)
        );
        assert!(
            matches!(&cmd.exprs[4], Expr::Exthdr { raw_type, offset, len, op, sreg, .. }
            if *raw_type == TCPOPT_MAXSEG && *offset == 2 && *len == 2 && *op == NFT_EXTHDR_OP_TCPOPT && sreg.is_some())
        );
    }

    #[test]
    fn test_rule_tcp_option_maxseg_size_range_lowers_to_anon_set() {
        let cmd = parse_one("add rule inet t c tcp option maxseg size 1-500 drop");
        assert!(
            matches!(&cmd.exprs[2], Expr::Exthdr { raw_type, offset, len, op, .. }
            if *raw_type == TCPOPT_MAXSEG && *offset == 2 && *len == 2 && *op == NFT_EXTHDR_OP_TCPOPT)
        );
        assert!(cmd
            .exprs
            .iter()
            .any(|expr| matches!(expr, Expr::AnonSet { elements, width, .. }
            if *width == 2
                && elements.iter().any(|(start, end)| start == &1u16.to_be_bytes().to_vec()
                    && end.as_ref() == Some(&500u16.to_be_bytes().to_vec())))));
    }

    #[test]
    fn test_rule_ip6_set_literal_cidr_lowers_to_interval() {
        let cmd = parse_one("add rule ip6 t c ip6 saddr { ::/3, 2001:db8::/32 } drop");
        let expect_start0 = std::net::Ipv6Addr::from_str("::")
            .unwrap()
            .octets()
            .to_vec();
        let expect_end0 = std::net::Ipv6Addr::from_str("1fff:ffff:ffff:ffff:ffff:ffff:ffff:ffff")
            .unwrap()
            .octets()
            .to_vec();
        let expect_start1 = std::net::Ipv6Addr::from_str("2001:db8::")
            .unwrap()
            .octets()
            .to_vec();
        let expect_end1 = std::net::Ipv6Addr::from_str("2001:db8:ffff:ffff:ffff:ffff:ffff:ffff")
            .unwrap()
            .octets()
            .to_vec();
        assert!(cmd.exprs.iter().any(|expr| matches!(expr, Expr::AnonSet { elements, width, .. }
            if *width == 16
                && elements.iter().any(|(start, end)| start == &expect_start0 && end.as_ref() == Some(&expect_end0))
                && elements.iter().any(|(start, end)| start == &expect_start1 && end.as_ref() == Some(&expect_end1)))));
    }

    #[test]
    fn test_rule_fib_type_set_literal_accepts_named_addrtypes() {
        let cmd =
            parse_one("add rule inet t c fib daddr type { broadcast, anycast, multicast } drop");
        assert!(
            matches!(&cmd.exprs[0], Expr::Fib { result, flags, width, .. }
            if *result == NFT_FIB_RESULT_ADDRTYPE
                && *flags == NFTA_FIB_F_DADDR
                && *width == 4)
        );
        assert!(cmd.exprs.iter().any(|expr| matches!(expr, Expr::AnonSet { elements, width, .. }
            if *width == 4
                && elements.iter().any(|(start, end)| start == &3u32.to_be_bytes().to_vec() && end.is_none())
                && elements.iter().any(|(start, end)| start == &4u32.to_be_bytes().to_vec() && end.is_none())
                && elements.iter().any(|(start, end)| start == &5u32.to_be_bytes().to_vec() && end.is_none()))));
    }

    #[test]
    fn test_rule_tcp_dport_set_literal_accepts_domain_s_service_name() {
        let cmd = parse_one("add rule inet t c tcp dport { https, domain-s } accept");
        assert!(cmd.exprs.iter().any(|expr| matches!(expr, Expr::AnonSet { elements, width, .. }
            if *width == 2
                && elements.iter().any(|(start, end)| start == &443u16.to_be_bytes().to_vec() && end.is_none())
                && elements.iter().any(|(start, end)| start == &853u16.to_be_bytes().to_vec() && end.is_none()))));
    }

    #[test]
    fn test_rule_meta_l4proto_negated_set_literal_keeps_inversion() {
        let cmd = parse_one("add rule inet t c meta l4proto != { tcp, udp } drop");
        assert!(matches!(&cmd.exprs[0], Expr::Meta { key, width, .. }
            if *key == NFT_META_L4PROTO && *width == 1));
        assert!(cmd.exprs.iter().any(
            |expr| matches!(expr, Expr::AnonSet { inverted, key_type, .. }
            if *inverted && *key_type == Some(12))
        ));
    }

    #[test]
    fn test_rule_ct_state_vmap_keeps_state_key_type() {
        let cmd = parse_one("add rule inet t c ct state vmap { invalid : drop, related : accept }");
        assert!(
            matches!(&cmd.exprs[0], Expr::Ct { key, width, .. } if *key == NFT_CT_STATE && *width == 4)
        );
        assert!(cmd.exprs.iter().any(|expr| matches!(expr, Expr::AnonVmap { pairs, key_type, .. }
            if *key_type == Some(27)
                && pairs.iter().any(|(start, _, code, _)| start == &1u32.to_ne_bytes().to_vec() && *code == NF_DROP)
                && pairs.iter().any(|(start, _, code, _)| start == &4u32.to_ne_bytes().to_vec() && *code == NF_ACCEPT))));
    }

    #[test]
    fn test_rule_tcp_flags_mask_expression() {
        let cmd = parse_one("add rule inet t c tcp flags & (syn | rst) == syn drop");
        assert!(
            matches!(&cmd.exprs[2], Expr::Payload { offset, len, protocol, .. }
            if *offset == 13 && *len == 1 && *protocol == 6)
        );
        assert!(matches!(&cmd.exprs[3], Expr::Bitwise { mask, xor }
            if mask == &vec![0x06] && xor == &vec![0x00]));
        assert!(matches!(&cmd.exprs[4], Expr::Cmp { op, data }
            if *op == NFT_CMP_EQ && data == &vec![0x02]));
    }

    #[test]
    fn test_rule_tcp_flags_mask_expression_compact_tokens() {
        let cmd = parse_one("add rule inet t c tcp flags & (fin|syn|rst|ack) != syn drop");
        assert!(matches!(&cmd.exprs[3], Expr::Bitwise { mask, xor }
            if mask == &vec![0x17] && xor == &vec![0x00]));
        assert!(matches!(&cmd.exprs[4], Expr::Cmp { op, data }
            if *op == NFT_CMP_NEQ && data == &vec![0x02]));
    }

    #[test]
    fn test_rule_th_dport_uses_transport_selector() {
        let cmd = parse_one("add rule inet t c meta l4proto { tcp, udp } th dport domain accept");
        assert!(cmd.exprs.iter().any(
            |expr| matches!(expr, Expr::Payload { base, offset, len, .. }
            if *base == NFT_PAYLOAD_TRANSPORT_HEADER && *offset == 2 && *len == 2)
        ));
    }

    #[test]
    fn test_rule_ip6_hoplimit_selector() {
        let cmd = parse_one("add rule ip6 t c ip6 hoplimit 255 accept");
        assert!(
            matches!(&cmd.exprs[0], Expr::Payload { base, offset, len, .. }
            if *base == NFT_PAYLOAD_NETWORK_HEADER && *offset == 7 && *len == 1)
        );
    }

    #[test]
    fn test_reject_familyless_named_object_delete() {
        let err =
            parse("delete quota a b").expect_err("family-less named object delete should fail");
        assert!(
            err.contains("missing family for quota delete"),
            "unexpected error: {}",
            err
        );
    }

    #[test]
    fn test_rule_ip6_nexthdr_tcp() {
        let cmd = parse_one("add rule ip6 t c ip6 nexthdr tcp tcp dport 80");
        assert!(
            matches!(&cmd.exprs[0], Expr::Payload { base, offset, len, .. }
            if *base == NFT_PAYLOAD_NETWORK_HEADER && *offset == 6 && *len == 1)
        );
        assert!(matches!(&cmd.exprs[1], Expr::Cmp { data, .. } if data == &[6]));
        assert!(
            matches!(&cmd.exprs[2], Expr::Payload { base, offset, len, protocol, .. }
            if *base == NFT_PAYLOAD_TRANSPORT_HEADER && *offset == 2 && *len == 2 && *protocol == 6)
        );
        assert!(matches!(&cmd.exprs[3], Expr::Cmp { data, .. } if data == &[0, 80]));
    }

    #[test]
    fn test_reject_conflicting_ip6_nexthdr_udp_dependency() {
        let err = parse(
            r#"table ip6 t {
        chain c {
                ip6 nexthdr comp udp dport 4789
        }
}"#,
        )
        .expect_err("conflicting ip6 nexthdr dependency should fail");
        assert!(
            err.contains("conflicting protocol dependency for udp"),
            "unexpected error: {}",
            err
        );
    }

    #[test]
    fn test_reject_invalid_meta_selector_binop_chain() {
        let err = parse(
            r#"table t {
        chain c {
                meta oifname^a^b^c bar
        }
}"#,
        )
        .expect_err("invalid meta selector should fail");
        assert!(
            err.contains("unknown meta key 'oifname^a^b^c'"),
            "unexpected error: {}",
            err
        );
    }

    #[test]
    fn test_reject_huge_goto_chain_name() {
        let huge = "r".repeat(300);
        let input = format!(
            "table inet x {{ chain c {{ udp length vmap {{ 1 : goto {} }} }} }}",
            huge
        );
        let err = parse(&input).expect_err("oversized goto chain name should fail");
        assert!(
            err.contains("identifier too long"),
            "unexpected error: {}",
            err
        );
    }

    #[test]
    fn test_reject_include_device() {
        let err = expand_variables("include \"/dev/null\"\n")
            .expect_err("including a device should fail");
        assert!(
            err.contains("not a regular file"),
            "unexpected error: {}",
            err
        );
    }

    #[test]
    fn test_reject_invalid_typeof_selector_in_map() {
        let err = parse(
            r#"table inet t {
        map m2 {
                typeof udp length . @ih,32,32 : verdict
                elements = { 1-10 . 0xa : drop }
        }
}"#,
        )
        .expect_err("invalid typeof selector should fail");
        assert!(
            err.contains("invalid typeof selector '@ih'")
                || err.contains("invalid typeof selector '.'"),
            "unexpected error: {}",
            err
        );
    }

    #[test]
    fn test_reject_map_element_without_value() {
        let err = parse(
            r#"table ip x {
        map y {
                type ipv4_addr : ipv4_addr
                elements = { 1.168.0.4 }
        }
}"#,
        )
        .expect_err("map element without value should fail");
        assert!(
            err.contains("missing value for map element"),
            "unexpected error: {}",
            err
        );
    }

    #[test]
    fn test_reject_declarative_map_without_key() {
        let err = parse(
            r#"table inet t {
        map m {
                elements = { 0x00000023 : 0x00001337 }
        }
}"#,
        )
        .expect_err("map without key should fail");
        assert!(
            err.contains("set definition does not specify key"),
            "unexpected error: {}",
            err
        );
    }

    #[test]
    fn test_reject_imperative_set_without_key() {
        let err = parse(
            r#"add set ip t s {
        elements = { 0x00000023-0x00000142, 0x00001337 }
}"#,
        )
        .expect_err("set without key should fail");
        assert!(
            err.contains("set definition does not specify key"),
            "unexpected error: {}",
            err
        );
    }

    #[test]
    fn test_reject_duplicate_map_in_declarative_table() {
        let err = parse(
            r#"table ip x {
        map y {
                type ipv4_addr : ipv4_addr
                elements = { 10.0.0.2 : 192.168.0.4 }
        }
        map y {
                type ipv4_addr : counter
                elements = { 192.168.2.2 : "a" }
        }
}"#,
        )
        .expect_err("duplicate map should fail");
        assert!(
            err.contains("duplicate map 'y'"),
            "unexpected error: {}",
            err
        );
    }

    #[test]
    fn test_reject_bare_declarative_table_without_block() {
        let err = parse("table inet p\n").expect_err("bare declarative table should fail");
        assert!(
            err.contains("expected '{' after table 'p'"),
            "unexpected error: {}",
            err
        );
    }

    #[test]
    fn test_expand_variable_preserves_braces_in_rule_context() {
        let out = expand_variables(
            "define address = { 1.1.1.1, 2.2.2.2 }\n\
             table ip x {\n\
             \tchain y {\n\
             \t\tip saddr $address\n\
             \t}\n\
             }\n",
        )
        .unwrap();
        assert!(out.contains("ip saddr { 1.1.1.1, 2.2.2.2 }"));
    }

    #[test]
    fn test_expand_variable_splices_braces_inside_literal() {
        let out = expand_variables(
            "define addrs = { 1.1.1.1, 2.2.2.2 }\n\
             table ip x {\n\
             \tset s {\n\
             \t\ttype ipv4_addr\n\
             \t\telements = { 9.9.9.9, $addrs }\n\
             \t}\n\
             }\n",
        )
        .unwrap();
        assert!(out.contains("elements = { 9.9.9.9, 1.1.1.1, 2.2.2.2 }"));
    }

    #[test]
    fn test_expand_variable_hyphenated_name() {
        let out = expand_variables(
            "define concat-set-variable = { 10.10.10.10 . 25, 10.10.10.10 . 143 }\n\
             table inet forward {\n\
             \tset concat-set-variable {\n\
             \t\ttype ipv4_addr . inet_service\n\
             \t\telements = $concat-set-variable\n\
             \t}\n\
             }\n",
        )
        .unwrap();
        assert!(out.contains("elements = { 10.10.10.10 . 25, 10.10.10.10 . 143 }"));
    }
}
