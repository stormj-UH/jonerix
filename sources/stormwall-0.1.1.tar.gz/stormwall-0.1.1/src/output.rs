//! Output formatting - kernel data to nft syntax. 100% safe Rust.

use crate::netlink::*;
use std::net::{Ipv4Addr, Ipv6Addr};

fn attr_handle_u64(attrs: &[(u16, Vec<u8>)], attr_type: u16) -> Option<u64> {
    attrs
        .iter()
        .find(|(t, _)| *t == attr_type)
        .map(|(_, v)| attr_u64_be(v))
}

pub fn print_table_line(family: u8, attrs: &[(u16, Vec<u8>)]) {
    let name = attrs
        .iter()
        .find(|(t, _)| *t == NFTA_TABLE_NAME)
        .map(|(_, v)| attr_str(v))
        .unwrap_or("?");
    println!("table {} {}", family_str(family), name);
}

pub fn print_table_header(family: u8, attrs: &[(u16, Vec<u8>)], show_handle: bool) {
    let name = attrs
        .iter()
        .find(|(t, _)| *t == NFTA_TABLE_NAME)
        .map(|(_, v)| attr_str(v))
        .unwrap_or("?");
    let handle = attr_handle_u64(attrs, NFTA_TABLE_HANDLE);
    print!("table {} {} {{", family_str(family), name);
    if show_handle {
        if let Some(h) = handle {
            print!(" # handle {}", h);
        }
    }
    println!();
}

pub fn print_chain_header(family: u8, attrs: &[(u16, Vec<u8>)], show_handle: bool) {
    let name = attrs
        .iter()
        .find(|(t, _)| *t == NFTA_CHAIN_NAME)
        .map(|(_, v)| attr_str(v))
        .unwrap_or("?");
    let handle = attr_handle_u64(attrs, NFTA_CHAIN_HANDLE);

    print!("\tchain {} {{", name);
    if show_handle {
        if let Some(h) = handle {
            print!(" # handle {}", h);
        }
    }
    println!();

    // Base chain properties: look for HOOK nested attribute
    if let Some((_, hook_data)) = attrs.iter().find(|(t, _)| *t == NFTA_CHAIN_HOOK) {
        let hook_attrs = parse_attrs(hook_data);
        let hooknum = hook_attrs
            .iter()
            .find(|(t, _)| *t == NFTA_HOOK_HOOKNUM)
            .map(|(_, v)| attr_u32_be(v))
            .unwrap_or(0);
        let priority = hook_attrs
            .iter()
            .find(|(t, _)| *t == NFTA_HOOK_PRIORITY)
            .map(|(_, v)| attr_i32_be(v))
            .unwrap_or(0);

        let chain_type = attrs
            .iter()
            .find(|(t, _)| *t == NFTA_CHAIN_TYPE)
            .map(|(_, v)| attr_str(v))
            .unwrap_or("filter");
        let policy = attrs
            .iter()
            .find(|(t, _)| *t == NFTA_CHAIN_POLICY)
            .map(|(_, v)| attr_u32_be(v));

        print!(
            "\t\ttype {} hook {} ",
            chain_type,
            hook_str_family(hooknum, family)
        );
        // Ingress/egress chains carry a device attribute — render
        // it just before `priority` so the output matches upstream's
        // `type filter hook ingress device "lo" priority filter`.
        if let Some((_, devv)) = hook_attrs.iter().find(|(t, _)| *t == NFTA_HOOK_DEV) {
            print!("device \"{}\" ", attr_str(devv));
        }
        print!("priority ");
        print_priority(priority, family);
        print!(";");

        if let Some(p) = policy {
            print!(
                " policy {};",
                if p == NF_DROP as u32 {
                    "drop"
                } else {
                    "accept"
                }
            );
        }
        println!();
    }
}

pub fn print_chain_footer() {
    println!("\t}}");
}

fn set_desc_attrs(attrs: &[(u16, Vec<u8>)]) -> Vec<(u16, Vec<u8>)> {
    attrs
        .iter()
        .find(|(t, _)| *t == NFTA_SET_DESC)
        .map(|(_, v)| parse_attrs(v))
        .unwrap_or_default()
}

fn set_typeof_names(attrs: &[(u16, Vec<u8>)]) -> (Option<String>, Option<String>) {
    const SET_UDATA_KEY_TYPEOF: u8 = 1;
    const SET_UDATA_DATA_TYPEOF: u8 = 2;

    let Some((_, ud)) = attrs.iter().find(|(t, _)| *t == NFTA_SET_USERDATA) else {
        return (None, None);
    };
    let mut key = None;
    let mut data = None;
    let mut i = 0usize;
    while i + 2 <= ud.len() {
        let ty = ud[i];
        let len = ud[i + 1] as usize;
        i += 2;
        if i + len > ud.len() {
            break;
        }
        let text = String::from_utf8_lossy(&ud[i..i + len]).to_string();
        match ty {
            SET_UDATA_KEY_TYPEOF => key = Some(text),
            SET_UDATA_DATA_TYPEOF => data = Some(text),
            _ => {}
        }
        i += len;
    }
    (key, data)
}

fn set_auto_merge(attrs: &[(u16, Vec<u8>)]) -> bool {
    const SET_UDATA_AUTO_MERGE: u8 = 3;

    let Some((_, ud)) = attrs.iter().find(|(t, _)| *t == NFTA_SET_USERDATA) else {
        return false;
    };
    let mut i = 0usize;
    while i + 2 <= ud.len() {
        let ty = ud[i];
        let len = ud[i + 1] as usize;
        i += 2;
        if i + len > ud.len() {
            break;
        }
        if ty == SET_UDATA_AUTO_MERGE && ud[i..i + len].iter().any(|b| *b != 0) {
            return true;
        }
        i += len;
    }
    false
}

fn format_timeout_ms(timeout_ms: u64) -> String {
    let units = [
        ('w', 604_800_000u64),
        ('d', 86_400_000u64),
        ('h', 3_600_000u64),
        ('m', 60_000u64),
        ('s', 1000u64),
    ];
    let mut rem = timeout_ms;
    let mut out = String::new();
    for (suffix, scale) in units {
        let n = rem / scale;
        if n != 0 {
            out.push_str(&format!("{}{}", n, suffix));
            rem %= scale;
        }
    }
    if rem != 0 || out.is_empty() {
        out.push_str(&format!("{}ms", rem));
    }
    out
}

fn l4proto_name(proto: u8) -> String {
    match proto {
        6 => "tcp".to_string(),
        17 => "udp".to_string(),
        58 => "icmpv6".to_string(),
        1 => "icmp".to_string(),
        _ => proto.to_string(),
    }
}

fn ct_timeout_default_secs(l4proto: u8, attr: u16) -> Option<u64> {
    match l4proto {
        6 => match attr {
            CTA_TIMEOUT_TCP_SYN_SENT => Some(120),
            CTA_TIMEOUT_TCP_SYN_RECV => Some(60),
            CTA_TIMEOUT_TCP_ESTABLISHED => Some(432_000),
            CTA_TIMEOUT_TCP_FIN_WAIT => Some(120),
            CTA_TIMEOUT_TCP_CLOSE_WAIT => Some(60),
            CTA_TIMEOUT_TCP_LAST_ACK => Some(30),
            CTA_TIMEOUT_TCP_TIME_WAIT => Some(120),
            CTA_TIMEOUT_TCP_CLOSE => Some(10),
            CTA_TIMEOUT_TCP_SYN_SENT2 => Some(120),
            CTA_TIMEOUT_TCP_RETRANS => Some(300),
            CTA_TIMEOUT_TCP_UNACK => Some(300),
            _ => None,
        },
        17 => match attr {
            CTA_TIMEOUT_UDP_UNREPLIED => Some(30),
            CTA_TIMEOUT_UDP_REPLIED => Some(120),
            _ => None,
        },
        _ => None,
    }
}

fn iface_name_from_index(idx: u32) -> Option<String> {
    if idx == 1 {
        return Some("lo".to_string());
    }
    let entries = std::fs::read_dir("/sys/class/net").ok()?;
    for entry in entries.flatten() {
        let name = entry.file_name().into_string().ok()?;
        let path = entry.path().join("ifindex");
        let ifindex = std::fs::read_to_string(path)
            .ok()?
            .trim()
            .parse::<u32>()
            .ok()?;
        if ifindex == idx {
            return Some(name);
        }
    }
    None
}

fn interval_sort_key(key: &[u8], is_end: bool) -> (bool, &[u8], bool) {
    let wraps_max = is_end && key.iter().all(|b| *b == 0);
    (wraps_max, key, !is_end)
}

fn cmp_interval_raw_keys(a: &(Vec<u8>, bool), b: &(Vec<u8>, bool)) -> std::cmp::Ordering {
    interval_sort_key(&a.0, a.1).cmp(&interval_sort_key(&b.0, b.1))
}

fn ct_state_names(data: &[u8], sep: &str) -> Option<String> {
    if data.len() < 4 {
        return None;
    }
    let state = u32::from_ne_bytes([data[0], data[1], data[2], data[3]]);
    let mut parts = Vec::new();
    if state & 1 != 0 {
        parts.push("invalid");
    }
    if state & 2 != 0 {
        parts.push("established");
    }
    if state & 4 != 0 {
        parts.push("related");
    }
    if state & 8 != 0 {
        parts.push("new");
    }
    if state & 64 != 0 {
        parts.push("untracked");
    }
    if parts.is_empty() {
        None
    } else {
        Some(parts.join(sep))
    }
}

pub fn print_object(attrs: &[(u16, Vec<u8>)], show_handle: bool) {
    let name = attrs
        .iter()
        .find(|(t, _)| *t == NFTA_OBJ_NAME)
        .map(|(_, v)| attr_str(v))
        .unwrap_or("?");
    let kind = attrs
        .iter()
        .find(|(t, _)| *t == NFTA_OBJ_TYPE)
        .map(|(_, v)| attr_u32_be(v))
        .unwrap_or(0);
    let data = attrs
        .iter()
        .find(|(t, _)| *t == NFTA_OBJ_DATA)
        .map(|(_, v)| parse_attrs(v))
        .unwrap_or_default();
    let handle = attr_handle_u64(attrs, NFTA_OBJ_HANDLE);

    match kind {
        1 /* NFT_OBJECT_COUNTER */ => {
            let pkts = data.iter().find(|(t, _)| *t == NFTA_COUNTER_PACKETS)
                .map(|(_, v)| attr_u64_be(v)).unwrap_or(0);
            let bytes = data.iter().find(|(t, _)| *t == NFTA_COUNTER_BYTES)
                .map(|(_, v)| attr_u64_be(v)).unwrap_or(0);
            print!("\tcounter {} {{", name);
            if show_handle {
                if let Some(h) = handle { print!(" # handle {}", h); }
            }
            println!();
            println!("\t\tpackets {} bytes {}", pkts, bytes);
            println!("\t}}");
        }
        2 /* NFT_OBJECT_QUOTA */ => {
            let bytes = data.iter().find(|(t, _)| *t == NFTA_QUOTA_BYTES)
                .map(|(_, v)| attr_u64_be(v)).unwrap_or(0);
            let flags = data.iter().find(|(t, _)| *t == NFTA_QUOTA_FLAGS)
                .map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
            // Scale bytes back to the coarsest exact unit. Input form
            // `25 mbytes` encodes 26_214_400 bytes; we want to print
            // `25 mbytes`, not the raw value.
            let (val, unit) = if bytes >= 1 << 30 && bytes % (1 << 30) == 0 {
                (bytes >> 30, "gbytes")
            } else if bytes >= 1 << 20 && bytes % (1 << 20) == 0 {
                (bytes >> 20, "mbytes")
            } else if bytes >= 1 << 10 && bytes % (1 << 10) == 0 {
                (bytes >> 10, "kbytes")
            } else {
                (bytes, "bytes")
            };
            print!("\tquota {} {{", name);
            if show_handle {
                if let Some(h) = handle { print!(" # handle {}", h); }
            }
            println!();
            if flags & NFT_QUOTA_F_INV != 0 {
                println!("\t\tover {} {}", val, unit);
            } else {
                println!("\t\t{} {}", val, unit);
            }
            println!("\t}}");
        }
        4 /* NFT_OBJECT_LIMIT */ => {
            let rate = data.iter().find(|(t, _)| *t == NFTA_LIMIT_RATE)
                .map(|(_, v)| attr_u64_be(v)).unwrap_or(0);
            let unit = data.iter().find(|(t, _)| *t == NFTA_LIMIT_UNIT)
                .map(|(_, v)| attr_u64_be(v)).unwrap_or(1);
            let burst = data.iter().find(|(t, _)| *t == NFTA_LIMIT_BURST)
                .map(|(_, v)| attr_u32_be(v)).unwrap_or(0);
            let unit_str = match unit {
                1 => "second", 60 => "minute", 3600 => "hour",
                86400 => "day", 604800 => "week", _ => "second",
            };
            print!("\tlimit {} {{", name);
            if show_handle {
                if let Some(h) = handle { print!(" # handle {}", h); }
            }
            println!();
            if burst > 0 {
                println!("\t\trate {}/{} burst {} packets", rate, unit_str, burst);
            } else {
                println!("\t\trate {}/{}", rate, unit_str);
            }
            println!("\t}}");
        }
        7 /* NFT_OBJECT_CT_TIMEOUT */ => {
            let l4proto = data.iter().find(|(t, _)| *t == NFTA_CT_TIMEOUT_L4PROTO)
                .map(|(_, v)| attr_u8(v)).unwrap_or(0);
            let l3proto = data.iter().find(|(t, _)| *t == NFTA_CT_TIMEOUT_L3PROTO)
                .map(|(_, v)| attr_u16_be(v)).unwrap_or(0) as u8;
            let policy = data.iter().find(|(t, _)| *t == NFTA_CT_TIMEOUT_DATA)
                .map(|(_, v)| parse_attrs(v)).unwrap_or_default();
            print!("\tct timeout {} {{", name);
            if show_handle {
                if let Some(h) = handle { print!(" # handle {}", h); }
            }
            println!();
            println!("\t\tprotocol {}", l4proto_name(l4proto));
            if l3proto != 0 {
                println!("\t\tl3proto {}", family_str(l3proto));
            }
            let mut parts: Vec<String> = Vec::new();
            for (attr, value) in policy {
                if let Some(state) = ct_timeout_state_name(l4proto, attr) {
                    let secs = attr_u32_be(&value) as u64;
                    if ct_timeout_default_secs(l4proto, attr) == Some(secs) {
                        continue;
                    }
                    parts.push(format!("{} : {}", state, format_timeout_ms(secs * 1000)));
                }
            }
            println!("\t\tpolicy = {{ {} }}", parts.join(", "));
            println!("\t}}");
        }
        9 /* NFT_OBJECT_CT_EXPECT */ => {
            let l4proto = data.iter().find(|(t, _)| *t == NFTA_CT_EXPECT_L4PROTO)
                .map(|(_, v)| attr_u8(v)).unwrap_or(0);
            let l3proto = data.iter().find(|(t, _)| *t == NFTA_CT_EXPECT_L3PROTO)
                .map(|(_, v)| attr_u16_be(v)).unwrap_or(0) as u8;
            let dport = data.iter().find(|(t, _)| *t == NFTA_CT_EXPECT_DPORT)
                .map(|(_, v)| attr_u16_be(v)).unwrap_or(0);
            let timeout_ms = data.iter().find(|(t, _)| *t == NFTA_CT_EXPECT_TIMEOUT)
                .map(|(_, v)| attr_u32(v) as u64).unwrap_or(0);
            let size = data.iter().find(|(t, _)| *t == NFTA_CT_EXPECT_SIZE)
                .map(|(_, v)| attr_u8(v)).unwrap_or(0);
            print!("\tct expectation {} {{", name);
            if show_handle {
                if let Some(h) = handle { print!(" # handle {}", h); }
            }
            println!();
            println!("\t\tprotocol {}", l4proto_name(l4proto));
            println!("\t\tdport {}", dport);
            println!("\t\ttimeout {}", format_timeout_ms(timeout_ms));
            println!("\t\tsize {}", size);
            if l3proto != 0 {
                println!("\t\tl3proto {}", family_str(l3proto));
            }
            println!("\t}}");
        }
        _ => {}
    }
}

fn print_flowtable_priority(prio: i32) {
    if prio == 0 {
        print!("filter");
    } else if prio.abs() <= 10 {
        print!("filter {} {}", if prio > 0 { "+" } else { "-" }, prio.abs());
    } else {
        print!("{}", prio);
    }
}

pub fn print_flowtable(attrs: &[(u16, Vec<u8>)], show_handle: bool) {
    let name = attrs
        .iter()
        .find(|(t, _)| *t == NFTA_FLOWTABLE_NAME)
        .map(|(_, v)| attr_str(v))
        .unwrap_or("?");
    let handle = attr_handle_u64(attrs, NFTA_FLOWTABLE_HANDLE);
    let flags = attrs
        .iter()
        .find(|(t, _)| *t == NFTA_FLOWTABLE_FLAGS)
        .map(|(_, v)| attr_u32_be(v))
        .unwrap_or(0);

    print!("\tflowtable {} {{", name);
    if show_handle {
        if let Some(h) = handle {
            print!(" # handle {}", h);
        }
    }
    println!();

    if let Some((_, hook_data)) = attrs.iter().find(|(t, _)| *t == NFTA_FLOWTABLE_HOOK) {
        let hook_attrs = parse_attrs(hook_data);
        let hooknum = hook_attrs
            .iter()
            .find(|(t, _)| *t == NFTA_FLOWTABLE_HOOK_NUM)
            .map(|(_, v)| attr_u32_be(v))
            .unwrap_or(NF_NETDEV_INGRESS);
        let priority = hook_attrs
            .iter()
            .find(|(t, _)| *t == NFTA_FLOWTABLE_HOOK_PRIORITY)
            .map(|(_, v)| attr_i32_be(v))
            .unwrap_or(0);
        print!(
            "\t\thook {} priority ",
            if hooknum == NF_NETDEV_INGRESS {
                "ingress"
            } else {
                "unknown"
            }
        );
        print_flowtable_priority(priority);
        println!();
        if let Some((_, devs_data)) = hook_attrs
            .iter()
            .find(|(t, _)| *t == NFTA_FLOWTABLE_HOOK_DEVS)
        {
            let mut devs = Vec::new();
            for (ty, value) in parse_attrs(devs_data) {
                if ty == NFTA_DEVICE_NAME {
                    devs.push(attr_str(&value).to_string());
                } else if ty == NFTA_DEVICE_PREFIX {
                    devs.push(format!("{}*", attr_str(&value)));
                } else {
                    let attrs = parse_attrs(&value);
                    if let Some((_, v)) = attrs.iter().find(|(t, _)| *t == NFTA_DEVICE_NAME) {
                        devs.push(attr_str(v).to_string());
                    } else if let Some((_, v)) =
                        attrs.iter().find(|(t, _)| *t == NFTA_DEVICE_PREFIX)
                    {
                        devs.push(format!("{}*", attr_str(v)));
                    }
                }
            }
            if !devs.is_empty() {
                println!("\t\tdevices = {{ {} }}", devs.join(", "));
            }
        }
    }
    if flags & NFT_FLOWTABLE_COUNTER != 0 {
        println!("\t\tcounter");
    }
    println!("\t}}");
}

/// Emit a set body including its elements. Mirrors `nft list
/// ruleset` where each named set is followed by an `elements = { ... }`
/// line when non-empty.
pub fn print_set_with_elements(
    _family: u8,
    attrs: &[(u16, Vec<u8>)],
    elements: &[Vec<(u16, Vec<u8>)>],
    show_handle: bool,
    terse: bool,
) {
    let name = attrs
        .iter()
        .find(|(t, _)| *t == NFTA_SET_NAME)
        .map(|(_, v)| attr_str(v))
        .unwrap_or("?");
    let key_type = attrs
        .iter()
        .find(|(t, _)| *t == NFTA_SET_KEY_TYPE)
        .map(|(_, v)| attr_u32_be(v))
        .unwrap_or(0);
    let flags = attrs
        .iter()
        .find(|(t, _)| *t == NFTA_SET_FLAGS)
        .map(|(_, v)| attr_u32_be(v))
        .unwrap_or(0);
    let key_len = attrs
        .iter()
        .find(|(t, _)| *t == NFTA_SET_KEY_LEN)
        .map(|(_, v)| attr_u32_be(v))
        .unwrap_or(0);
    let desc = set_desc_attrs(attrs);
    let size = desc
        .iter()
        .find(|(t, _)| *t == NFTA_SET_DESC_SIZE)
        .map(|(_, v)| attr_u32_be(v))
        .unwrap_or(0);
    let auto_merge = set_auto_merge(attrs);
    let handle = attr_handle_u64(attrs, NFTA_SET_HANDLE);

    if flags & 0x1 != 0 {
        return;
    } // anonymous

    // `map` blocks render with the `map` keyword in real nft; only
    // plain sets use `set`. The kernel marks maps with NFT_SET_MAP.
    let kind = if flags & NFT_SET_MAP != 0 {
        "map"
    } else {
        "set"
    };
    let (key_typeof, data_typeof) = set_typeof_names(attrs);
    print!("\t{} {} {{", kind, name);
    if show_handle {
        if let Some(h) = handle {
            print!(" # handle {}", h);
        }
    }
    println!();
    if flags & NFT_SET_MAP != 0 {
        let data_type = attrs
            .iter()
            .find(|(t, _)| *t == NFTA_SET_DATA_TYPE)
            .map(|(_, v)| attr_u32_be(v))
            .unwrap_or(0);
        if let Some(key_expr) = key_typeof {
            let data_expr = data_typeof.unwrap_or_else(|| set_type_display_name(data_type));
            println!("\t\ttypeof {} : {}", key_expr, data_expr);
        } else {
            println!(
                "\t\ttype {} : {}",
                set_type_display_name(key_type),
                set_type_display_name(data_type)
            );
        }
    } else {
        if let Some(key_expr) = key_typeof {
            println!("\t\ttypeof {}", key_expr);
        } else {
            println!("\t\ttype {}", set_type_display_name(key_type));
        }
    }
    if size > 0 {
        println!("\t\tsize {}", size);
    }

    let mut flag_strs = Vec::new();
    if flags & NFT_SET_CONSTANT != 0 {
        flag_strs.push("constant");
    }
    if flags & NFT_SET_INTERVAL != 0 {
        flag_strs.push("interval");
    }
    if flags & NFT_SET_EVAL != 0 {
        flag_strs.push("dynamic");
    }
    if flags & NFT_SET_TIMEOUT != 0 {
        flag_strs.push("timeout");
    }
    if !flag_strs.is_empty() {
        println!("\t\tflags {}", flag_strs.join(","));
    }
    if auto_merge {
        println!("\t\tauto-merge");
    }

    // Render elements. Terse mode (-t) omits them entirely.
    // For interval sets, pair up each start with its trailing
    // INTERVAL_END sentinel so ranges round-trip as `a-b` (or as
    // `addr/prefix` when they happen to span a CIDR boundary).
    if !terse {
        let is_interval = flags & NFT_SET_INTERVAL != 0;
        let is_map = flags & NFT_SET_MAP != 0;
        let data_type = attrs
            .iter()
            .find(|(t, _)| *t == NFTA_SET_DATA_TYPE)
            .map(|(_, v)| attr_u32_be(v))
            .unwrap_or(0);
        let data_len = attrs
            .iter()
            .find(|(t, _)| *t == NFTA_SET_DATA_LEN)
            .map(|(_, v)| attr_u32_be(v))
            .unwrap_or(0);
        let mut raw: Vec<(
            Vec<u8>,
            bool,
            Option<(i32, String)>,
            Option<Vec<u8>>,
            Vec<String>,
        )> = Vec::new();
        for eattrs in elements {
            let eflags = eattrs
                .iter()
                .find(|(t, _)| *t == NFTA_SET_ELEM_FLAGS)
                .map(|(_, v)| attr_u32_be(v))
                .unwrap_or(0);
            let is_end = eflags & NFT_SET_ELEM_INTERVAL_END != 0;
            // Map element DATA is either NFTA_DATA_VERDICT (verdict
            // map) or NFTA_DATA_VALUE (data-valued map). Pull whichever
            // is present; both are exclusive on a given element.
            let (vd, data_val) = eattrs
                .iter()
                .find(|(t, _)| *t == NFTA_SET_ELEM_DATA)
                .map(|(_, d)| {
                    let inner = parse_attrs(d);
                    let verdict =
                        inner
                            .iter()
                            .find(|(t, _)| *t == NFTA_DATA_VERDICT)
                            .map(|(_, vd)| {
                                let v = parse_attrs(vd);
                                let code = v
                                    .iter()
                                    .find(|(t, _)| *t == NFTA_VERDICT_CODE)
                                    .map(|(_, x)| attr_u32_be(x) as i32)
                                    .unwrap_or(0);
                                let chain = v
                                    .iter()
                                    .find(|(t, _)| *t == NFTA_VERDICT_CHAIN)
                                    .map(|(_, x)| attr_str(x).to_string())
                                    .unwrap_or_default();
                                (code, chain)
                            });
                    let dv = inner
                        .iter()
                        .find(|(t, _)| *t == NFTA_DATA_VALUE)
                        .map(|(_, v)| v.clone());
                    (verdict, dv)
                })
                .unwrap_or((None, None));
            let expr_texts = decode_set_elem_exprs(eattrs);
            let key = eattrs
                .iter()
                .find(|(t, _)| *t == NFTA_SET_ELEM_KEY)
                .map(|(_, v)| parse_attrs(v));
            if let Some(k) = key {
                if let Some((_, data)) = k.iter().find(|(t, _)| *t == NFTA_DATA_VALUE) {
                    raw.push((data.clone(), is_end, vd, data_val, expr_texts));
                }
            }
        }
        let mut rendered: Vec<String> = Vec::new();
        if is_interval && is_map {
            // Interval-keyed map: pair start with end+1 sentinel, then
            // render `key : value` where value is either a verdict or
            // a data-valued map entry (e.g. ipv4_addr : ipv4_addr). The
            // kernel emits the END record with the same DATA value as
            // the start record; we keep the start's data. When two
            // ranges touch (end of one == start of next), the shared
            // value appears twice in the dump — put the END record
            // first so our start/end pairing doesn't misread them.
            raw.sort_by(|a, b| cmp_interval_raw_keys(&(a.0.clone(), a.1), &(b.0.clone(), b.1)));
            let mut i = 0;
            while i < raw.len() {
                let (start, end_flag, vd, dv, expr_texts) = raw[i].clone();
                if end_flag {
                    i += 1;
                    continue;
                }
                let mut end: Option<Vec<u8>> = None;
                if i + 1 < raw.len() && raw[i + 1].1 {
                    let mut v = raw[i + 1].0.clone();
                    for byte in v.iter_mut().rev() {
                        if *byte == 0 {
                            *byte = 0xff;
                        } else {
                            *byte -= 1;
                            break;
                        }
                    }
                    if v != start {
                        end = Some(v);
                    }
                    i += 2;
                } else {
                    i += 1;
                }
                let key_str = format_interval_key(key_type, key_len, &start, end.as_deref());
                let value_str = if let Some((code, chain)) = vd {
                    verdict_str(code, &chain)
                } else if let Some(bytes) = dv {
                    format_set_key(data_type, data_len, &bytes)
                } else {
                    String::new()
                };
                let suffix = if expr_texts.is_empty() {
                    String::new()
                } else {
                    format!(" {}", expr_texts.join(" "))
                };
                rendered.push(format!("{} : {}{}", key_str, value_str, suffix));
            }
        } else if is_interval {
            // Sort by (value, end_flag-desc) so touching intervals
            // pair up correctly — the end sentinel for the previous
            // range must sit immediately before the start of the
            // next range even when they share a value.
            raw.sort_by(|a, b| cmp_interval_raw_keys(&(a.0.clone(), a.1), &(b.0.clone(), b.1)));
            let mut i = 0;
            while i < raw.len() {
                let (start, end_flag, _, _, expr_texts) = &raw[i];
                if *end_flag {
                    i += 1;
                    continue;
                }
                let mut end: Option<Vec<u8>> = None;
                if i + 1 < raw.len() && raw[i + 1].1 {
                    let mut v = raw[i + 1].0.clone();
                    for byte in v.iter_mut().rev() {
                        if *byte == 0 {
                            *byte = 0xff;
                        } else {
                            *byte -= 1;
                            break;
                        }
                    }
                    if v != *start {
                        end = Some(v);
                    }
                    i += 2;
                } else {
                    i += 1;
                }
                let mut entry = format_interval_key(key_type, key_len, start, end.as_deref());
                if !expr_texts.is_empty() {
                    entry.push(' ');
                    entry.push_str(&expr_texts.join(" "));
                }
                rendered.push(entry);
            }
        } else if is_map {
            let mut items: Vec<(Vec<u8>, Option<(i32, String)>, Option<Vec<u8>>, Vec<String>)> =
                raw.into_iter()
                    .filter_map(
                        |(k, f, v, d, exprs)| if !f { Some((k, v, d, exprs)) } else { None },
                    )
                    .collect();
            items.sort_by(|a, b| a.0.cmp(&b.0));
            for (k, v, d, expr_texts) in items {
                let key_str = format_set_key(key_type, key_len, &k);
                let value_str = if let Some((code, chain)) = v {
                    verdict_str(code, &chain)
                } else if let Some(bytes) = d {
                    format_set_key(data_type, data_len, &bytes)
                } else {
                    String::new()
                };
                let suffix = if expr_texts.is_empty() {
                    String::new()
                } else {
                    format!(" {}", expr_texts.join(" "))
                };
                rendered.push(format!("{} : {}{}", key_str, value_str, suffix));
            }
        } else {
            let mut starts: Vec<(Vec<u8>, Vec<String>)> = raw
                .into_iter()
                .filter_map(|(k, f, _, _, exprs)| if !f { Some((k, exprs)) } else { None })
                .collect();
            starts.sort_by(|a, b| a.0.cmp(&b.0));
            for (d, expr_texts) in starts {
                let mut entry = format_set_key(key_type, key_len, &d);
                if !expr_texts.is_empty() {
                    entry.push(' ');
                    entry.push_str(&expr_texts.join(" "));
                }
                rendered.push(entry);
            }
        }
        if !rendered.is_empty() {
            print_wrapped_elements(&rendered);
        }
    }

    println!("\t}}");
}

/// Decode a ct-state bitmask into its JSON representation. The
/// kernel stores the mask as a 4-byte BE u32 where each bit maps
/// to a state keyword (1=new, 2=related, 4=established, 8=untracked,
/// 16=invalid). Single bit → bare string; multiple bits → array.
fn format_ct_state_json(mask: &[u8]) -> String {
    // nft stores ct state masks in host byte order (the register is
    // also host-order), so decode as native-endian, not BE.
    let v: u32 = if mask.len() >= 4 {
        u32::from_ne_bytes([mask[0], mask[1], mask[2], mask[3]])
    } else {
        0
    };
    let names: &[(&str, u32)] = &[
        ("invalid", 1),
        ("established", 2),
        ("related", 4),
        ("new", 8),
        ("untracked", 64),
    ];
    let mut set: Vec<&str> = Vec::new();
    for (n, bit) in names {
        if v & *bit != 0 {
            set.push(*n);
        }
    }
    if set.len() == 1 {
        format!("\"{}\"", set[0])
    } else if set.is_empty() {
        format!("\"0x{:08x}\"", v)
    } else {
        let inner: Vec<String> = set.iter().map(|s| format!("\"{}\"", s)).collect();
        format!("[{}]", inner.join(", "))
    }
}

/// Render an interval set element — either a single value (when
/// end is None), a CIDR if the [start, end] range spans a power-of-two
/// prefix-aligned block, else `start-end`.
fn format_interval_key(key_type: u32, key_len: u32, start: &[u8], end: Option<&[u8]>) -> String {
    match end {
        None => format_set_key(key_type, key_len, start),
        Some(e) => {
            if is_concat_type(key_type) {
                let mut offset = 0usize;
                let mut parts: Vec<String> = Vec::new();
                for field_type in concat_type_parts(key_type) {
                    let field_len = set_type_len(field_type) as usize;
                    let padded = padded_key_len(field_len as u32) as usize;
                    if offset + field_len > start.len() || offset + field_len > e.len() {
                        parts.clear();
                        break;
                    }
                    let start_part = &start[offset..offset + field_len];
                    let end_part = &e[offset..offset + field_len];
                    if start_part == end_part {
                        parts.push(format_set_key(field_type, field_len as u32, start_part));
                    } else {
                        parts.push(format_interval_key(
                            field_type,
                            field_len as u32,
                            start_part,
                            Some(end_part),
                        ));
                    }
                    offset += padded;
                }
                if !parts.is_empty() {
                    return parts.join(" . ");
                }
            }
            // Try CIDR detection for IPv4 (key_type 7) and IPv6 (8).
            if let Some(prefix) = try_cidr_prefix(start, e) {
                if key_type == 7 && start.len() == 4 {
                    return format!(
                        "{}.{}.{}.{}/{}",
                        start[0], start[1], start[2], start[3], prefix
                    );
                }
                if key_type == 8 && start.len() == 16 {
                    let mut octets = [0u8; 16];
                    octets.copy_from_slice(start);
                    let addr = std::net::Ipv6Addr::from(octets);
                    return format!("{}/{}", addr, prefix);
                }
            }
            format!(
                "{}-{}",
                format_set_key(key_type, key_len, start),
                format_set_key(key_type, key_len, e)
            )
        }
    }
}

fn should_inline_single_anon_set(info: &AnonSetInfo) -> bool {
    if info.is_map || info.elements.len() != 1 || is_concat_type(info.key_type) {
        return false;
    }
    let has_range = info.elements[0].1.is_some();
    if has_range {
        !matches!(info.key_type, 7 | 8 | 16 | 36)
    } else {
        !matches!(info.key_type, 16 | 36)
    }
}

fn print_wrapped_elements(rendered: &[String]) {
    if rendered.is_empty() {
        return;
    }
    let per_line = if rendered
        .iter()
        .any(|s| s.contains(" . ") || s.contains(" : ") || s.len() > 16)
    {
        1
    } else {
        2
    };
    if rendered.len() <= per_line {
        println!("\t\telements = {{ {} }}", rendered.join(", "));
        return;
    }
    for (idx, chunk) in rendered.chunks(per_line).enumerate() {
        let text = chunk.join(", ");
        let is_last = (idx + 1) * per_line >= rendered.len();
        if idx == 0 {
            println!(
                "\t\telements = {{ {}{}",
                text,
                if is_last { " }" } else { "," }
            );
        } else if is_last {
            println!("\t\t\t     {} }}", text);
        } else {
            println!("\t\t\t     {},", text);
        }
    }
}

/// If `[start, end]` spans exactly a power-of-two prefix-aligned
/// block, return the prefix length. `end` is inclusive. Returns None
/// if the range isn't a clean CIDR.
fn try_cidr_prefix(start: &[u8], end: &[u8]) -> Option<u32> {
    if start.len() != end.len() {
        return None;
    }
    let bits = (start.len() * 8) as u32;
    // Compute size = end - start + 1. If size is a power of 2 and
    // start is aligned to size, prefix = bits - log2(size).
    // Work with u128 so 16-byte IPv6 fits.
    let mut s: u128 = 0;
    let mut e: u128 = 0;
    for &b in start {
        s = (s << 8) | b as u128;
    }
    for &b in end {
        e = (e << 8) | b as u128;
    }
    if e < s {
        return None;
    }
    let size = e - s + 1;
    if !size.is_power_of_two() {
        return None;
    }
    if s & (size - 1) != 0 {
        return None;
    }
    let hostbits = size.trailing_zeros();
    Some(bits - hostbits)
}

/// Render an anon-set element list as the `{ a, b-c, ... }` body
/// that goes inside an inline lookup. Matches upstream's spacing —
/// comma+space between entries, `start-end` for ranges.
/// Text-form verdict for use inside vmap element renderings:
/// `accept` / `drop` / `return` / `continue` or `jump chain` /
/// `goto chain` for chain-targeted verdicts.
fn verdict_str(code: i32, chain: &str) -> String {
    match code {
        1 => "accept".to_string(),
        0 => "drop".to_string(),
        -1 => "continue".to_string(),
        -5 => "return".to_string(),
        -3 => format!("jump {}", chain),
        -4 => format!("goto {}", chain),
        _ => "accept".to_string(),
    }
}

/// Render a verdict code + chain pair as a libnftables-style JSON
/// value, matching the shape used inside vmap element tuples and
/// in `immediate` expressions. Unrecognised codes fall through to
/// `{"accept": null}` so the result is always valid JSON.
fn json_verdict(code: i32, chain: &str) -> String {
    match code {
        1 => "{\"accept\": null}".to_string(),
        0 => "{\"drop\": null}".to_string(),
        -1 => "{\"continue\": null}".to_string(),
        -5 => "{\"return\": null}".to_string(),
        -3 => format!("{{\"jump\": {{\"target\": \"{}\"}}}}", json_escape(chain)),
        -4 => format!("{{\"goto\": {{\"target\": \"{}\"}}}}", json_escape(chain)),
        _ => "{\"accept\": null}".to_string(),
    }
}

fn format_anon_set_elems(info: &AnonSetInfo) -> String {
    let mut parts: Vec<String> = Vec::new();
    for (start, end) in &info.elements {
        match end {
            Some(e) if e != start => parts.push(format_interval_key(
                info.key_type,
                info.key_len,
                start,
                Some(e),
            )),
            _ => parts.push(format_set_key(info.key_type, info.key_len, start)),
        }
    }
    parts.join(", ")
}

/// Like `format_anon_set_elems`, but emits `key : verdict` pairs for
/// anonymous verdict maps. Upstream formats these as
/// `{ 1.1.1.1 : accept, 2.2.2.2 : drop }`, with `jump chain` /
/// `goto chain` for chain-targeted verdicts.
fn format_anon_vmap_elems(info: &AnonSetInfo) -> String {
    let mut parts: Vec<String> = Vec::new();
    for (i, (start, end)) in info.elements.iter().enumerate() {
        let key = match end {
            Some(e) if e != start => {
                format_interval_key(info.key_type, info.key_len, start, Some(e))
            }
            _ => format_set_key(info.key_type, info.key_len, start),
        };
        let (code, chain) = info.verdicts.get(i).cloned().unwrap_or((0, String::new()));
        let verdict = match code {
            1 => "accept".to_string(),
            0 => "drop".to_string(),
            -1 => "continue".to_string(),
            -5 => "return".to_string(),
            -3 if !chain.is_empty() => format!("jump {}", chain),
            -4 if !chain.is_empty() => format!("goto {}", chain),
            _ => "accept".to_string(),
        };
        parts.push(format!("{} : {}", key, verdict));
    }
    parts.join(", ")
}

fn format_anon_map_elems(info: &AnonSetInfo) -> String {
    let mut parts: Vec<String> = Vec::new();
    for (i, (start, end)) in info.elements.iter().enumerate() {
        let key = match end {
            Some(e) if e != start => {
                format_interval_key(info.key_type, info.key_len, start, Some(e))
            }
            _ => format_set_key(info.key_type, info.key_len, start),
        };
        let value = info
            .data_values
            .get(i)
            .map(|bytes| format_set_key(info.data_type, info.data_len, bytes))
            .unwrap_or_default();
        parts.push(format!("{} : {}", key, value));
    }
    parts.join(", ")
}

fn fib_addrtype_name(val: u32) -> Option<&'static str> {
    match val {
        1 => Some("unicast"),
        2 => Some("local"),
        3 => Some("broadcast"),
        4 => Some("anycast"),
        5 => Some("multicast"),
        6 => Some("blackhole"),
        7 => Some("unreachable"),
        8 => Some("prohibit"),
        9 => Some("throw"),
        10 => Some("nat"),
        11 => Some("xresolve"),
        _ => None,
    }
}

fn nfproto_name(val: u8) -> Option<&'static str> {
    match val {
        2 => Some("ipv4"),
        10 => Some("ipv6"),
        1 => Some("inet"),
        3 => Some("arp"),
        7 => Some("bridge"),
        5 => Some("netdev"),
        _ => None,
    }
}

fn icmp_type_name(val: u8) -> Option<&'static str> {
    match val {
        3 => Some("destination-unreachable"),
        8 => Some("echo-request"),
        11 => Some("time-exceeded"),
        12 => Some("parameter-problem"),
        _ => None,
    }
}

fn icmpv6_type_name(val: u8) -> Option<&'static str> {
    match val {
        1 => Some("destination-unreachable"),
        2 => Some("packet-too-big"),
        3 => Some("time-exceeded"),
        4 => Some("parameter-problem"),
        128 => Some("echo-request"),
        130 => Some("mld-listener-query"),
        133 => Some("nd-router-solicit"),
        134 => Some("nd-router-advert"),
        135 => Some("nd-neighbor-solicit"),
        136 => Some("nd-neighbor-advert"),
        143 => Some("mld2-listener-report"),
        _ => None,
    }
}

fn tcp_flags_str(mask: u8, wrap: bool) -> Option<String> {
    let mut parts: Vec<&str> = Vec::new();
    if mask & 0x01 != 0 {
        parts.push("fin");
    }
    if mask & 0x02 != 0 {
        parts.push("syn");
    }
    if mask & 0x04 != 0 {
        parts.push("rst");
    }
    if mask & 0x08 != 0 {
        parts.push("psh");
    }
    if mask & 0x10 != 0 {
        parts.push("ack");
    }
    if mask & 0x20 != 0 {
        parts.push("urg");
    }
    if mask & 0x40 != 0 {
        parts.push("ece");
    }
    if mask & 0x80 != 0 {
        parts.push("cwr");
    }
    if parts.is_empty() {
        None
    } else if wrap && parts.len() > 1 {
        Some(format!("({})", parts.join(" | ")))
    } else {
        Some(parts.join(" | "))
    }
}

fn format_scalar_key(key_type: u32, data: &[u8]) -> String {
    match key_type {
        2 /* nf_proto */ if data.len() == 1 => nfproto_name(data[0])
            .map(str::to_string)
            .unwrap_or_else(|| format!("{}", data[0])),
        7 /* ipv4_addr */ if data.len() == 4 => {
            format!("{}.{}.{}.{}", data[0], data[1], data[2], data[3])
        }
        8 /* ipv6_addr */ if data.len() == 16 => {
            let mut octets = [0u8; 16];
            octets.copy_from_slice(data);
            let addr = std::net::Ipv6Addr::from(octets);
            format!("{}", addr)
        }
        9 /* ether_addr */ if data.len() == 6 => {
            format!("{:02x}:{:02x}:{:02x}:{:02x}:{:02x}:{:02x}",
                data[0], data[1], data[2], data[3], data[4], data[5])
        }
        12 /* inet_proto */ if data.len() == 1 => {
            match data[0] {
                1 => "icmp".to_string(),
                2 => "igmp".to_string(),
                6 => "tcp".to_string(),
                17 => "udp".to_string(),
                58 => "ipv6-icmp".to_string(),
                134 => "nd-router-advert".to_string(),
                135 => "nd-neighbor-solicit".to_string(),
                _ => format!("{}", data[0]),
            }
        }
        13 /* inet_service */ if data.len() == 2 => {
            format!("{}", u16::from_be_bytes([data[0], data[1]]))
        }
        14 /* icmp_type */ if data.len() == 1 => icmp_type_name(data[0])
            .map(str::to_string)
            .unwrap_or_else(|| format!("{}", data[0])),
        15 /* mark */ if data.len() == 4 => {
            format!("0x{:08x}", u32::from_be_bytes([data[0], data[1], data[2], data[3]]))
        }
        19 /* icmpv6_type */ if data.len() == 1 => icmpv6_type_name(data[0])
            .map(str::to_string)
            .unwrap_or_else(|| format!("{}", data[0])),
        25 /* fib_addrtype */ if data.len() == 4 => {
            let val = u32::from_be_bytes([data[0], data[1], data[2], data[3]]);
            fib_addrtype_name(val)
                .map(str::to_string)
                .unwrap_or_else(|| format!("{}", val))
        }
        27 /* ct_state */ if data.len() >= 4 => ct_state_names(data, ",")
            .unwrap_or_else(|| format!("{}", u32::from_ne_bytes([data[0], data[1], data[2], data[3]]))),
        36 /* iface_index */ if data.len() == 4 => {
            let idx = u32::from_be_bytes([data[0], data[1], data[2], data[3]]);
            iface_name_from_index(idx)
                .map(|name| format!("\"{}\"", name))
                .unwrap_or_else(|| format!("{}", idx))
        }
        16 /* ifname */ => {
            let s = data.iter().take_while(|&&b| b != 0).copied().collect::<Vec<u8>>();
            format!("\"{}\"", String::from_utf8_lossy(&s))
        }
        _ => {
            // Fallback: show as a decimal integer when it fits.
            if data.len() == 1 { format!("{}", data[0]) }
            else if data.len() == 2 { format!("{}", u16::from_be_bytes([data[0], data[1]])) }
            else if data.len() == 4 { format!("{}", u32::from_be_bytes([data[0], data[1], data[2], data[3]])) }
            else {
                data.iter().map(|b| format!("{:02x}", b)).collect::<Vec<_>>().join(":")
            }
        }
    }
}

fn format_set_key(key_type: u32, _key_len: u32, data: &[u8]) -> String {
    if is_concat_type(key_type) {
        let mut offset = 0usize;
        let mut parts: Vec<String> = Vec::new();
        for field_type in concat_type_parts(key_type) {
            let field_len = set_type_len(field_type) as usize;
            let padded = padded_key_len(field_len as u32) as usize;
            if offset + padded > data.len() {
                break;
            }
            parts.push(format_scalar_key(
                field_type,
                &data[offset..offset + field_len],
            ));
            offset += padded;
        }
        return parts.join(" . ");
    }
    format_scalar_key(key_type, data)
}

fn format_limit_unit(unit: u64) -> &'static str {
    match unit {
        1 => "second",
        60 => "minute",
        3600 => "hour",
        86400 => "day",
        604800 => "week",
        _ => "second",
    }
}

fn format_set_elem_expr(name: &str, data: &[(u16, Vec<u8>)]) -> Option<String> {
    match name {
        "counter" => {
            let packets = data
                .iter()
                .find(|(t, _)| *t == NFTA_COUNTER_PACKETS)
                .map(|(_, v)| attr_u64_be(v))
                .unwrap_or(0);
            let bytes = data
                .iter()
                .find(|(t, _)| *t == NFTA_COUNTER_BYTES)
                .map(|(_, v)| attr_u64_be(v))
                .unwrap_or(0);
            Some(format!("counter packets {} bytes {}", packets, bytes))
        }
        "limit" => {
            let rate = data
                .iter()
                .find(|(t, _)| *t == NFTA_LIMIT_RATE)
                .map(|(_, v)| attr_u64_be(v))
                .unwrap_or(0);
            let unit = data
                .iter()
                .find(|(t, _)| *t == NFTA_LIMIT_UNIT)
                .map(|(_, v)| attr_u64_be(v))
                .unwrap_or(1);
            let burst = data
                .iter()
                .find(|(t, _)| *t == NFTA_LIMIT_BURST)
                .map(|(_, v)| attr_u32_be(v))
                .unwrap_or(5);
            Some(format!(
                "limit rate {}/{} burst {} packets",
                rate,
                format_limit_unit(unit),
                burst
            ))
        }
        _ => None,
    }
}

fn decode_set_elem_exprs(eattrs: &[(u16, Vec<u8>)]) -> Vec<String> {
    let mut out: Vec<String> = Vec::new();
    if let Some((_, expr)) = eattrs.iter().find(|(t, _)| *t == NFTA_SET_ELEM_EXPR) {
        let attrs = parse_attrs(expr);
        let name = attrs
            .iter()
            .find(|(t, _)| *t == NFTA_EXPR_NAME)
            .map(|(_, v)| attr_str(v))
            .unwrap_or("");
        let data = attrs
            .iter()
            .find(|(t, _)| *t == NFTA_EXPR_DATA)
            .map(|(_, v)| parse_attrs(v))
            .unwrap_or_default();
        if let Some(text) = format_set_elem_expr(name, &data) {
            out.push(text);
        }
    }
    if let Some((_, exprs)) = eattrs.iter().find(|(t, _)| *t == NFTA_SET_ELEM_EXPRESSIONS) {
        for (_, item) in parse_attrs(exprs) {
            let attrs = parse_attrs(&item);
            let name = attrs
                .iter()
                .find(|(t, _)| *t == NFTA_EXPR_NAME)
                .map(|(_, v)| attr_str(v))
                .unwrap_or("");
            let data = attrs
                .iter()
                .find(|(t, _)| *t == NFTA_EXPR_DATA)
                .map(|(_, v)| parse_attrs(v))
                .unwrap_or_default();
            if let Some(text) = format_set_elem_expr(name, &data) {
                out.push(text);
            }
        }
    }
    out
}

pub fn print_set_header(_family: u8, attrs: &[(u16, Vec<u8>)], show_handle: bool) {
    let table = attrs
        .iter()
        .find(|(t, _)| *t == NFTA_SET_TABLE)
        .map(|(_, v)| attr_str(v))
        .unwrap_or("?");
    let name = attrs
        .iter()
        .find(|(t, _)| *t == NFTA_SET_NAME)
        .map(|(_, v)| attr_str(v))
        .unwrap_or("?");
    let key_type = attrs
        .iter()
        .find(|(t, _)| *t == NFTA_SET_KEY_TYPE)
        .map(|(_, v)| attr_u32_be(v))
        .unwrap_or(0);
    let flags = attrs
        .iter()
        .find(|(t, _)| *t == NFTA_SET_FLAGS)
        .map(|(_, v)| attr_u32_be(v))
        .unwrap_or(0);
    let desc = set_desc_attrs(attrs);
    let size = desc
        .iter()
        .find(|(t, _)| *t == NFTA_SET_DESC_SIZE)
        .map(|(_, v)| attr_u32_be(v))
        .unwrap_or(0);
    let auto_merge = set_auto_merge(attrs);
    let (key_typeof, data_typeof) = set_typeof_names(attrs);
    let handle = attr_handle_u64(attrs, NFTA_SET_HANDLE);

    // Skip anonymous sets (kernel-internal)
    if flags & 0x1 != 0 {
        return;
    }

    let kind = if flags & NFT_SET_MAP != 0 {
        "map"
    } else {
        "set"
    };
    print!("\t{} {} {{", kind, name);
    if show_handle {
        if let Some(h) = handle {
            print!(" # handle {}", h);
        }
    }
    println!();
    if flags & NFT_SET_MAP != 0 {
        let data_type = attrs
            .iter()
            .find(|(t, _)| *t == NFTA_SET_DATA_TYPE)
            .map(|(_, v)| attr_u32_be(v))
            .unwrap_or(0);
        if let Some(key_expr) = key_typeof {
            let data_expr = data_typeof.unwrap_or_else(|| set_type_display_name(data_type));
            println!("\t\ttypeof {} : {}", key_expr, data_expr);
        } else {
            println!(
                "\t\ttype {} : {}",
                set_type_display_name(key_type),
                set_type_display_name(data_type)
            );
        }
    } else {
        if let Some(key_expr) = key_typeof {
            println!("\t\ttypeof {}", key_expr);
        } else {
            println!("\t\ttype {}", set_type_display_name(key_type));
        }
    }
    if size > 0 {
        println!("\t\tsize {}", size);
    }

    let mut flag_strs = Vec::new();
    if flags & NFT_SET_CONSTANT != 0 {
        flag_strs.push("constant");
    }
    if flags & NFT_SET_INTERVAL != 0 {
        flag_strs.push("interval");
    }
    if flags & NFT_SET_EVAL != 0 {
        flag_strs.push("dynamic");
    }
    if flags & NFT_SET_TIMEOUT != 0 {
        flag_strs.push("timeout");
    }
    if !flag_strs.is_empty() {
        println!("\t\tflags {}", flag_strs.join(","));
    }
    if auto_merge {
        println!("\t\tauto-merge");
    }
    let _ = table;
    println!("\t}}");
}

fn print_priority(prio: i32, family: u8) {
    let names: &[(&str, i32)] = if family == NFPROTO_BRIDGE {
        &[
            ("dstnat", -300),
            ("filter", -200),
            ("out", 100),
            ("srcnat", 300),
        ]
    } else {
        &[
            ("raw", -300),
            ("mangle", -150),
            ("dstnat", -100),
            ("filter", 0),
            ("security", 50),
            ("srcnat", 100),
        ]
    };

    for &(name, val) in names {
        if prio == val {
            print!("{}", name);
            return;
        }
        let diff = prio - val;
        if diff.abs() <= 10 && diff != 0 {
            print!(
                "{} {} {}",
                name,
                if diff > 0 { "+" } else { "-" },
                diff.abs()
            );
            return;
        }
    }
    print!("{}", prio);
}

/// Bundle of per-set metadata needed to render rules in a table.
/// When a rule's `lookup` expression names an anonymous set we have
/// to inline its elements — upstream `nft list ruleset` does that
/// too, and the test framework's diff is sensitive to the keyword
/// vs. `@__setN` distinction. The registry maps set name ->
/// (key_type, key_len, element keys in INTERVAL_END-aware order,
/// range_ends parallel to the keys).
#[derive(Default, Clone)]
pub struct AnonSetRegistry {
    pub sets: std::collections::HashMap<String, AnonSetInfo>,
}
#[derive(Default, Clone)]
pub struct BoundChainRegistry {
    pub chains: std::collections::HashMap<String, Vec<Vec<(u16, Vec<u8>)>>>,
}
#[derive(Clone)]
pub struct AnonSetInfo {
    pub key_type: u32,
    pub key_len: u32,
    pub is_interval: bool,
    /// Element list with optional range ends. For an interval set
    /// the kernel stores [start, end+1|INTERVAL_END] pairs; the
    /// caller collapses those back into (start, Some(end)) here.
    pub elements: Vec<(Vec<u8>, Option<Vec<u8>>)>,
    /// `true` if this set is a verdict map (NFT_SET_MAP flag), in
    /// which case `verdicts` holds the per-element (code, chain)
    /// pairs parallel to `elements`.
    pub is_map: bool,
    pub verdicts: Vec<(i32, String)>,
    pub data_type: u32,
    pub data_len: u32,
    pub data_values: Vec<Vec<u8>>,
}

pub fn print_rule(attrs: &[(u16, Vec<u8>)], show_handle: bool, stateless: bool) {
    print_rule_with_sets(attrs, show_handle, stateless, &AnonSetRegistry::default())
}

pub fn print_rule_with_sets(
    attrs: &[(u16, Vec<u8>)],
    show_handle: bool,
    stateless: bool,
    registry: &AnonSetRegistry,
) {
    print_rule_with_sets_bound(
        attrs,
        show_handle,
        stateless,
        registry,
        &BoundChainRegistry::default(),
    )
}

pub fn print_rule_with_sets_bound(
    attrs: &[(u16, Vec<u8>)],
    show_handle: bool,
    stateless: bool,
    registry: &AnonSetRegistry,
    bound_registry: &BoundChainRegistry,
) {
    print_rule_with_sets_indent(
        attrs,
        show_handle,
        stateless,
        registry,
        bound_registry,
        "\t\t",
    );
}

fn print_rule_with_sets_indent(
    attrs: &[(u16, Vec<u8>)],
    show_handle: bool,
    stateless: bool,
    registry: &AnonSetRegistry,
    bound_registry: &BoundChainRegistry,
    indent: &str,
) {
    print!("{}", indent);

    if let Some((_, exprs_data)) = attrs.iter().find(|(t, _)| *t == NFTA_RULE_EXPRESSIONS) {
        let elems = parse_attrs(exprs_data);

        // Pre-scan the expression stream so we can elide
        // implicit `meta l4proto X` deps that precede a
        // transport-header payload load on the same proto
        // — upstream `nft list` hides them. We also still
        // use the proto to pick "tcp sport" vs "udp sport".
        let decoded: Vec<(String, Vec<(u16, Vec<u8>)>)> = elems
            .iter()
            .map(|(_, ed)| {
                let a = parse_attrs(ed);
                let n = a
                    .iter()
                    .find(|(t, _)| *t == NFTA_EXPR_NAME)
                    .map(|(_, v)| attr_str(v).to_string())
                    .unwrap_or_default();
                let d = a
                    .iter()
                    .find(|(t, _)| *t == NFTA_EXPR_DATA)
                    .map(|(_, v)| parse_attrs(v))
                    .unwrap_or_default();
                (n, d)
            })
            .collect();
        let (skip, proto_hint) = compute_l4proto_elision(&decoded);

        let mut ctx = RuleCtx::new();
        if let Some(p) = proto_hint {
            ctx.proto_ctx = p;
        }
        let mut first = true;
        for (i, (name, data_attrs)) in decoded.iter().enumerate() {
            if skip[i] {
                continue;
            }
            format_expr(
                name,
                data_attrs,
                &mut ctx,
                &mut first,
                stateless,
                registry,
                bound_registry,
                indent,
                show_handle,
            );
        }
    }

    // Rule comment lives in NFTA_RULE_USERDATA as a TLV blob. Format:
    //   [u8 type][u8 len][len bytes (NUL-terminated string)]
    // type 0 = NFTNL_UDATA_RULE_COMMENT. Walk the blob; the first comment
    // wins.
    if let Some((_, ud)) = attrs.iter().find(|(t, _)| *t == NFTA_RULE_USERDATA) {
        let mut i = 0usize;
        while i + 2 <= ud.len() {
            let ty = ud[i];
            let ln = ud[i + 1] as usize;
            i += 2;
            if i + ln > ud.len() {
                break;
            }
            if ty == 0 {
                let s = &ud[i..i + ln];
                let trimmed = s
                    .iter()
                    .take_while(|&&b| b != 0)
                    .copied()
                    .collect::<Vec<u8>>();
                if let Ok(txt) = std::str::from_utf8(&trimmed) {
                    print!(" comment \"{}\"", txt);
                }
                break;
            }
            i += ln;
        }
    }

    if show_handle {
        if let Some((_, v)) = attrs.iter().find(|(t, _)| *t == NFTA_RULE_HANDLE) {
            print!(" # handle {}", attr_u64_be(v));
        }
    }
    println!();
}

// ── Rule expression formatting ──────────────────────────────────

#[derive(Clone, Copy, PartialEq)]
enum FieldId {
    IpSaddr,
    IpDaddr,
    IpProto,
    Ip6Saddr,
    Ip6Daddr,
    Ip6NextHdr,
    Ip6Hoplimit,
    TcpSport,
    TcpDport,
    TcpFlags,
    UdpSport,
    UdpDport,
    IcmpType,
    IcmpCode,
    Unknown,
}

/// Decide which positions in the expression stream should be
/// elided from text output because they're implicit transport
/// dependencies. Input is the (name, data) pair list. Returns a
/// parallel Vec<bool> — true means "don't format this one".
fn compute_l4proto_elision(exprs: &[(String, Vec<(u16, Vec<u8>)>)]) -> (Vec<bool>, Option<u8>) {
    let mut skip = vec![false; exprs.len()];
    let mut proto_hint: Option<u8> = None;
    let mut i = 0;
    while i < exprs.len() {
        // Look for a `meta` with NFTA_META_KEY == NFT_META_L4PROTO.
        if exprs[i].0 == "meta" {
            let key = exprs[i]
                .1
                .iter()
                .find(|(t, _)| *t == NFTA_META_KEY)
                .map(|(_, v)| attr_u32_be(v))
                .unwrap_or(0);
            if key == NFT_META_L4PROTO && i + 1 < exprs.len() && exprs[i + 1].0 == "cmp" {
                let op = exprs[i + 1]
                    .1
                    .iter()
                    .find(|(t, _)| *t == NFTA_CMP_OP)
                    .map(|(_, v)| attr_u32_be(v))
                    .unwrap_or(0);
                let d = exprs[i + 1]
                    .1
                    .iter()
                    .find(|(t, _)| *t == NFTA_CMP_DATA)
                    .map(|(_, v)| {
                        let inner = parse_attrs(v);
                        inner
                            .iter()
                            .find(|(t, _)| *t == NFTA_DATA_VALUE)
                            .map(|(_, v)| v.clone())
                            .unwrap_or_default()
                    })
                    .unwrap_or_default();
                if op == NFT_CMP_EQ && d.len() == 1 {
                    let proto = d[0];
                    // Look ahead for a transport-header payload in the
                    // rest of the rule. If found on matching proto,
                    // elide the meta + cmp pair.
                    let mut found = false;
                    for (n, da) in exprs[i + 2..].iter() {
                        if n == "payload" {
                            let base = da
                                .iter()
                                .find(|(t, _)| *t == NFTA_PAYLOAD_BASE)
                                .map(|(_, v)| attr_u32_be(v))
                                .unwrap_or(0);
                            if base == NFT_PAYLOAD_TRANSPORT_HEADER
                                && matches!(proto, 1 | 6 | 17 | 58)
                            {
                                found = true;
                                break;
                            }
                        } else if n == "exthdr" {
                            let exthdr_op = da
                                .iter()
                                .find(|(t, _)| *t == NFTA_EXTHDR_OP)
                                .map(|(_, v)| attr_u32_be(v))
                                .unwrap_or(u32::MAX);
                            if exthdr_op == NFT_EXTHDR_OP_TCPOPT && proto == 6 {
                                found = true;
                                break;
                            }
                        }
                    }
                    if found {
                        skip[i] = true;
                        skip[i + 1] = true;
                        proto_hint = Some(proto);
                        i += 2;
                        continue;
                    }
                }
            }
            if key == NFT_META_NFPROTO && i + 1 < exprs.len() && exprs[i + 1].0 == "cmp" {
                let op = exprs[i + 1]
                    .1
                    .iter()
                    .find(|(t, _)| *t == NFTA_CMP_OP)
                    .map(|(_, v)| attr_u32_be(v))
                    .unwrap_or(0);
                let d = exprs[i + 1]
                    .1
                    .iter()
                    .find(|(t, _)| *t == NFTA_CMP_DATA)
                    .map(|(_, v)| {
                        let inner = parse_attrs(v);
                        inner
                            .iter()
                            .find(|(t, _)| *t == NFTA_DATA_VALUE)
                            .map(|(_, v)| v.clone())
                            .unwrap_or_default()
                    })
                    .unwrap_or_default();
                if op == NFT_CMP_EQ && matches!(d.as_slice(), [NFPROTO_IPV4] | [NFPROTO_IPV6]) {
                    let mut found = false;
                    for (n, da) in exprs[i + 2..].iter() {
                        if n == "payload" {
                            let base = da
                                .iter()
                                .find(|(t, _)| *t == NFTA_PAYLOAD_BASE)
                                .map(|(_, v)| attr_u32_be(v))
                                .unwrap_or(0);
                            if base == NFT_PAYLOAD_NETWORK_HEADER {
                                found = true;
                                break;
                            }
                        }
                        if d == [NFPROTO_IPV6] && n == "exthdr" {
                            let exthdr_op = da
                                .iter()
                                .find(|(t, _)| *t == NFTA_EXTHDR_OP)
                                .map(|(_, v)| attr_u32_be(v))
                                .unwrap_or(u32::MAX);
                            if exthdr_op == NFT_EXTHDR_OP_IPV6 {
                                found = true;
                                break;
                            }
                        }
                    }
                    if found {
                        skip[i] = true;
                        skip[i + 1] = true;
                        i += 2;
                        continue;
                    }
                }
            }
        }
        i += 1;
    }
    (skip, proto_hint)
}

struct RuleCtx {
    field: FieldId,
    special_left: Option<String>,
    meta_key: Option<u32>,
    ct_key: Option<u32>,
    has_bitwise: bool,
    bw_mask: Vec<u8>,
    lhs_terms: Vec<String>,
    proto_ctx: u8,
    generic_transport_ctx: bool,
    family_hint: Option<u8>,
    fib_result: Option<u32>,
    fib_flags: u32,
    reg_values: std::collections::BTreeMap<u32, Vec<u8>>,
    queue_hash_desc: Option<String>,
    assign_rhs: Option<String>,
}

impl RuleCtx {
    fn new() -> Self {
        RuleCtx {
            field: FieldId::Unknown,
            special_left: None,
            meta_key: None,
            ct_key: None,
            has_bitwise: false,
            bw_mask: Vec::new(),
            lhs_terms: Vec::new(),
            proto_ctx: 0,
            generic_transport_ctx: false,
            family_hint: None,
            fib_result: None,
            fib_flags: 0,
            reg_values: std::collections::BTreeMap::new(),
            queue_hash_desc: None,
            assign_rhs: None,
        }
    }
    fn current_left_term(&self) -> Option<String> {
        if let Some(term) = &self.special_left {
            Some(term.clone())
        } else if self.field != FieldId::Unknown {
            Some(field_name(self.field, self.proto_ctx, self.generic_transport_ctx).to_string())
        } else if let Some(k) = self.meta_key {
            Some(meta_key_name(k).to_string())
        } else if let Some(k) = self.ct_key {
            Some(ct_key_name(k).to_string())
        } else if let Some(result) = self.fib_result {
            let mut parts: Vec<&str> = Vec::new();
            if self.fib_flags & NFTA_FIB_F_SADDR != 0 {
                parts.push("saddr");
            }
            if self.fib_flags & NFTA_FIB_F_DADDR != 0 {
                parts.push("daddr");
            }
            if self.fib_flags & NFTA_FIB_F_MARK != 0 {
                parts.push("mark");
            }
            if self.fib_flags & NFTA_FIB_F_IIF != 0 {
                parts.push("iif");
            }
            if self.fib_flags & NFTA_FIB_F_OIF != 0 {
                parts.push("oif");
            }
            Some(format!(
                "fib {} {}",
                parts.join(" . "),
                match result {
                    NFT_FIB_RESULT_OIF => "oif",
                    NFT_FIB_RESULT_OIFNAME => "oifname",
                    NFT_FIB_RESULT_ADDRTYPE => "type",
                    _ => "unknown",
                }
            ))
        } else {
            None
        }
    }
    fn stash_current_left(&mut self) {
        if let Some(term) = self.current_left_term() {
            self.lhs_terms.push(term);
        }
    }
    fn take_left_expr(&self, count: usize) -> Option<String> {
        let mut parts = self.lhs_terms.clone();
        if let Some(term) = self.current_left_term() {
            parts.push(term);
        }
        if parts.is_empty() {
            return None;
        }
        let take = count.max(1).min(parts.len());
        Some(parts[parts.len() - take..].join(" . "))
    }
    fn take_all_left_expr(&self) -> Option<String> {
        let mut parts = self.lhs_terms.clone();
        if let Some(term) = self.current_left_term() {
            parts.push(term);
        }
        if parts.is_empty() {
            None
        } else {
            Some(parts.join(" . "))
        }
    }
    fn left_terms(&self) -> Vec<String> {
        let mut parts = self.lhs_terms.clone();
        if let Some(term) = self.current_left_term() {
            parts.push(term);
        }
        parts
    }
    fn clear(&mut self) {
        self.field = FieldId::Unknown;
        self.special_left = None;
        self.meta_key = None;
        self.ct_key = None;
        self.has_bitwise = false;
        self.bw_mask.clear();
        self.lhs_terms.clear();
        self.fib_result = None;
        self.fib_flags = 0;
        self.reg_values.clear();
    }
}

fn queue_flags_str(flags: u16) -> Option<String> {
    let mut parts: Vec<&str> = Vec::new();
    if flags & NFT_QUEUE_FLAG_BYPASS != 0 {
        parts.push("bypass");
    }
    if flags & NFT_QUEUE_FLAG_CPU_FANOUT != 0 {
        parts.push("fanout");
    }
    if parts.is_empty() {
        None
    } else {
        Some(parts.join(","))
    }
}

fn identify_payload(base: u32, offset: u32, len: u32) -> FieldId {
    match (base, offset, len) {
        (1, 12, 4) => FieldId::IpSaddr,
        (1, 16, 4) => FieldId::IpDaddr,
        (1, 9, 1) => FieldId::IpProto,
        (1, 8, 16) => FieldId::Ip6Saddr,
        (1, 24, 16) => FieldId::Ip6Daddr,
        (1, 6, 1) => FieldId::Ip6NextHdr,
        (1, 7, 1) => FieldId::Ip6Hoplimit,
        (2, 0, 2) => FieldId::TcpSport,
        (2, 2, 2) => FieldId::TcpDport,
        (2, 13, 1) => FieldId::TcpFlags,
        (2, 0, 1) => FieldId::IcmpType,
        (2, 1, 1) => FieldId::IcmpCode,
        _ => FieldId::Unknown,
    }
}

fn field_name(f: FieldId, proto: u8, generic_transport: bool) -> &'static str {
    match f {
        FieldId::IpSaddr => "ip saddr",
        FieldId::IpDaddr => "ip daddr",
        FieldId::IpProto => "ip protocol",
        FieldId::Ip6Saddr => "ip6 saddr",
        FieldId::Ip6Daddr => "ip6 daddr",
        FieldId::Ip6NextHdr => "ip6 nexthdr",
        FieldId::Ip6Hoplimit => "ip6 hoplimit",
        FieldId::TcpSport if generic_transport && proto != 17 => "th sport",
        FieldId::TcpSport => {
            if proto == 17 {
                "udp sport"
            } else {
                "tcp sport"
            }
        }
        FieldId::TcpDport if generic_transport && proto != 17 => "th dport",
        FieldId::TcpDport => {
            if proto == 17 {
                "udp dport"
            } else {
                "tcp dport"
            }
        }
        FieldId::TcpFlags => "tcp flags",
        FieldId::UdpSport => "udp sport",
        FieldId::UdpDport => "udp dport",
        FieldId::IcmpType => {
            if proto == 58 {
                "icmpv6 type"
            } else {
                "icmp type"
            }
        }
        FieldId::IcmpCode => {
            if proto == 58 {
                "icmpv6 code"
            } else {
                "icmp code"
            }
        }
        FieldId::Unknown => "unknown",
    }
}

fn meta_key_name(key: u32) -> &'static str {
    match key {
        NFT_META_IIFNAME => "iifname",
        NFT_META_OIFNAME => "oifname",
        NFT_META_IIF => "iif",
        NFT_META_OIF => "oif",
        NFT_META_MARK => "meta mark",
        NFT_META_L4PROTO => "meta l4proto",
        NFT_META_NFPROTO => "meta nfproto",
        NFT_META_PKTTYPE => "meta pkttype",
        NFT_META_SKUID => "meta skuid",
        NFT_META_SKGID => "meta skgid",
        NFT_META_LEN => "meta length",
        _ => "meta unknown",
    }
}

fn ct_key_name(key: u32) -> &'static str {
    match key {
        NFT_CT_STATE => "ct state",
        NFT_CT_MARK => "ct mark",
        NFT_CT_STATUS => "ct status",
        NFT_CT_DIRECTION => "ct direction",
        NFT_CT_ZONE => "ct zone",
        NFT_CT_HELPER => "ct helper",
        NFT_CT_L3PROTOCOL => "ct l3proto",
        NFT_CT_PROTOCOL => "ct protocol",
        NFT_CT_PKTS => "ct packets",
        NFT_CT_BYTES => "ct bytes",
        NFT_CT_EXPIRATION => "ct expiration",
        _ => "ct unknown",
    }
}

fn rt_key_name(key: u32) -> Option<&'static str> {
    match key {
        NFT_RT_CLASSID => Some("rt classid"),
        NFT_RT_NEXTHOP4 => Some("rt ip nexthop"),
        NFT_RT_NEXTHOP6 => Some("rt ip6 nexthop"),
        NFT_RT_TCPMSS => Some("rt mtu"),
        NFT_RT_XFRM => Some("rt ipsec"),
        _ => None,
    }
}

fn exthdr_selector_name(
    raw_type: u8,
    offset: u32,
    len: u32,
    op: u32,
    flags: u32,
) -> Option<&'static str> {
    match (op, raw_type, offset, len, flags) {
        (NFT_EXTHDR_OP_IPV6, IPPROTO_ROUTING, 2, 1, 0) => Some("rt type"),
        (NFT_EXTHDR_OP_TCPOPT, TCPOPT_MAXSEG, 0, 1, NFT_EXTHDR_F_PRESENT) => {
            Some("tcp option maxseg")
        }
        (NFT_EXTHDR_OP_TCPOPT, TCPOPT_MAXSEG, 1, 1, 0) => Some("tcp option maxseg length"),
        (NFT_EXTHDR_OP_TCPOPT, TCPOPT_MAXSEG, 2, 2, 0) => Some("tcp option maxseg size"),
        _ => None,
    }
}

fn format_expr(
    name: &str,
    data: &[(u16, Vec<u8>)],
    ctx: &mut RuleCtx,
    first: &mut bool,
    stateless: bool,
    registry: &AnonSetRegistry,
    bound_registry: &BoundChainRegistry,
    indent: &str,
    show_handle: bool,
) {
    match name {
        "payload" => {
            if let Some((_, sreg)) = data.iter().find(|(t, _)| *t == NFTA_PAYLOAD_SREG) {
                let _ = sreg;
                let base = data
                    .iter()
                    .find(|(t, _)| *t == NFTA_PAYLOAD_BASE)
                    .map(|(_, v)| attr_u32_be(v))
                    .unwrap_or(0);
                let offset = data
                    .iter()
                    .find(|(t, _)| *t == NFTA_PAYLOAD_OFFSET)
                    .map(|(_, v)| attr_u32_be(v))
                    .unwrap_or(0);
                let len = data
                    .iter()
                    .find(|(t, _)| *t == NFTA_PAYLOAD_LEN)
                    .map(|(_, v)| attr_u32_be(v))
                    .unwrap_or(0);
                let lhs = field_name(
                    identify_payload(base, offset, len),
                    ctx.proto_ctx,
                    ctx.generic_transport_ctx,
                )
                .to_string();
                if !*first {
                    print!(" ");
                }
                *first = false;
                let rhs = ctx
                    .assign_rhs
                    .take()
                    .or_else(|| ctx.take_all_left_expr())
                    .unwrap_or_default();
                print!("{} set {}", lhs, rhs);
                ctx.clear();
                return;
            }
            ctx.stash_current_left();
            let base = data
                .iter()
                .find(|(t, _)| *t == NFTA_PAYLOAD_BASE)
                .map(|(_, v)| attr_u32_be(v))
                .unwrap_or(0);
            let offset = data
                .iter()
                .find(|(t, _)| *t == NFTA_PAYLOAD_OFFSET)
                .map(|(_, v)| attr_u32_be(v))
                .unwrap_or(0);
            let len = data
                .iter()
                .find(|(t, _)| *t == NFTA_PAYLOAD_LEN)
                .map(|(_, v)| attr_u32_be(v))
                .unwrap_or(0);
            ctx.field = identify_payload(base, offset, len);
            match ctx.field {
                FieldId::IpSaddr | FieldId::IpDaddr | FieldId::IpProto => {
                    ctx.family_hint = Some(NFPROTO_IPV4)
                }
                FieldId::Ip6Saddr
                | FieldId::Ip6Daddr
                | FieldId::Ip6NextHdr
                | FieldId::Ip6Hoplimit => ctx.family_hint = Some(NFPROTO_IPV6),
                _ => {}
            }
            ctx.has_bitwise = false;
            ctx.fib_result = None;
            ctx.fib_flags = 0;
        }
        "rt" => {
            ctx.stash_current_left();
            let key = data
                .iter()
                .find(|(t, _)| *t == NFTA_RT_KEY)
                .map(|(_, v)| attr_u32_be(v))
                .unwrap_or(u32::MAX);
            ctx.field = FieldId::Unknown;
            ctx.special_left = rt_key_name(key).map(str::to_string);
            ctx.meta_key = None;
            ctx.ct_key = None;
            ctx.has_bitwise = false;
            ctx.fib_result = None;
            ctx.fib_flags = 0;
        }
        "exthdr" => {
            let raw_type = data
                .iter()
                .find(|(t, _)| *t == NFTA_EXTHDR_TYPE)
                .map(|(_, v)| attr_u8(v))
                .unwrap_or(0);
            let offset = data
                .iter()
                .find(|(t, _)| *t == NFTA_EXTHDR_OFFSET)
                .map(|(_, v)| attr_u32_be(v))
                .unwrap_or(0);
            let len = data
                .iter()
                .find(|(t, _)| *t == NFTA_EXTHDR_LEN)
                .map(|(_, v)| attr_u32_be(v))
                .unwrap_or(0);
            let op = data
                .iter()
                .find(|(t, _)| *t == NFTA_EXTHDR_OP)
                .map(|(_, v)| attr_u32_be(v))
                .unwrap_or(0);
            let flags = data
                .iter()
                .find(|(t, _)| *t == NFTA_EXTHDR_FLAGS)
                .map(|(_, v)| attr_u32_be(v))
                .unwrap_or(0);
            let label = exthdr_selector_name(raw_type, offset, len, op, flags)
                .map(str::to_string)
                .unwrap_or_else(|| "exthdr".to_string());
            if data.iter().any(|(t, _)| *t == NFTA_EXTHDR_SREG) {
                if !*first {
                    print!(" ");
                }
                *first = false;
                let rhs = ctx
                    .assign_rhs
                    .take()
                    .or_else(|| ctx.take_all_left_expr())
                    .unwrap_or_default();
                print!("{} set {}", label, rhs);
                ctx.clear();
                return;
            }
            ctx.stash_current_left();
            ctx.field = FieldId::Unknown;
            ctx.special_left = Some(label);
            ctx.meta_key = None;
            ctx.ct_key = None;
            ctx.has_bitwise = false;
            ctx.fib_result = None;
            ctx.fib_flags = 0;
        }
        "meta" => {
            ctx.stash_current_left();
            ctx.meta_key = data
                .iter()
                .find(|(t, _)| *t == NFTA_META_KEY)
                .map(|(_, v)| attr_u32_be(v));
            ctx.field = FieldId::Unknown;
            ctx.special_left = None;
            ctx.ct_key = None;
            ctx.has_bitwise = false;
            ctx.fib_result = None;
            ctx.fib_flags = 0;
        }
        "ct" => {
            ctx.stash_current_left();
            ctx.ct_key = data
                .iter()
                .find(|(t, _)| *t == NFTA_CT_KEY)
                .map(|(_, v)| attr_u32_be(v));
            ctx.field = FieldId::Unknown;
            ctx.special_left = None;
            ctx.meta_key = None;
            ctx.has_bitwise = false;
            ctx.fib_result = None;
            ctx.fib_flags = 0;
        }
        "fib" => {
            ctx.stash_current_left();
            ctx.field = FieldId::Unknown;
            ctx.special_left = None;
            ctx.meta_key = None;
            ctx.ct_key = None;
            ctx.has_bitwise = false;
            ctx.fib_result = data
                .iter()
                .find(|(t, _)| *t == NFTA_FIB_RESULT)
                .map(|(_, v)| attr_u32_be(v));
            ctx.fib_flags = data
                .iter()
                .find(|(t, _)| *t == NFTA_FIB_FLAGS)
                .map(|(_, v)| attr_u32_be(v))
                .unwrap_or(0);
        }
        "bitwise" => {
            ctx.has_bitwise = true;
            if let Some((_, v)) = data.iter().find(|(t, _)| *t == NFTA_BITWISE_MASK) {
                let inner = parse_attrs(v);
                if let Some((_, mask_data)) = inner.iter().find(|(t, _)| *t == NFTA_DATA_VALUE) {
                    ctx.bw_mask = mask_data.clone();
                }
            }
        }
        "cmp" => {
            let op = data
                .iter()
                .find(|(t, _)| *t == NFTA_CMP_OP)
                .map(|(_, v)| attr_u32_be(v))
                .unwrap_or(0);
            let cmp_data = data
                .iter()
                .find(|(t, _)| *t == NFTA_CMP_DATA)
                .map(|(_, v)| {
                    let inner = parse_attrs(v);
                    inner
                        .iter()
                        .find(|(t, _)| *t == NFTA_DATA_VALUE)
                        .map(|(_, d)| d.clone())
                        .unwrap_or_default()
                })
                .unwrap_or_default();

            if !*first {
                print!(" ");
            }
            *first = false;

            if ctx.fib_result.is_none() {
                if let Some(left) = ctx.take_left_expr(1) {
                    print!("{} ", left);
                }
            }

            // ct state bitmask: bitwise(mask) + cmp(neq|eq, 0).
            // `neq 0` → `ct state NAME`  (any bit set)
            // `eq 0`  → `ct state != NAME` (no bit set)
            if ctx.fib_result.is_some() {
                let result = ctx.fib_result.unwrap_or(0);
                let flags = ctx.fib_flags;
                let mut parts: Vec<&str> = Vec::new();
                if flags & NFTA_FIB_F_SADDR != 0 {
                    parts.push("saddr");
                }
                if flags & NFTA_FIB_F_DADDR != 0 {
                    parts.push("daddr");
                }
                if flags & NFTA_FIB_F_MARK != 0 {
                    parts.push("mark");
                }
                if flags & NFTA_FIB_F_IIF != 0 {
                    parts.push("iif");
                }
                if flags & NFTA_FIB_F_OIF != 0 {
                    parts.push("oif");
                }
                print!("fib {}", parts.join(" . "));
                if flags & NFTA_FIB_F_PRESENT != 0
                    && result == NFT_FIB_RESULT_OIF
                    && op == NFT_CMP_EQ
                    && cmp_data.len() == 1
                {
                    print!(
                        " check {}",
                        if cmp_data[0] == 0 {
                            "missing"
                        } else {
                            "exists"
                        }
                    );
                } else {
                    print!(
                        " {}",
                        match result {
                            NFT_FIB_RESULT_OIF => "oif",
                            NFT_FIB_RESULT_OIFNAME => "oifname",
                            NFT_FIB_RESULT_ADDRTYPE => "type",
                            _ => "unknown",
                        }
                    );
                    if op == NFT_CMP_NEQ {
                        print!(" != ");
                    } else {
                        print!(" ");
                    }
                    if result == NFT_FIB_RESULT_ADDRTYPE && cmp_data.len() == 4 {
                        let val = u32::from_be_bytes([
                            cmp_data[0],
                            cmp_data[1],
                            cmp_data[2],
                            cmp_data[3],
                        ]);
                        if let Some(name) = fib_addrtype_name(val) {
                            print!("{}", name);
                        } else {
                            print!("{}", val);
                        }
                    } else {
                        format_value(
                            &cmp_data,
                            ctx.field,
                            ctx.meta_key,
                            ctx.ct_key,
                            ctx.proto_ctx,
                        );
                    }
                }
            } else if ctx.has_bitwise
                && ctx.ct_key == Some(NFT_CT_STATE)
                && (op == NFT_CMP_NEQ || op == NFT_CMP_EQ)
            {
                let sep = if op == NFT_CMP_EQ { " | " } else { "," };
                if op == NFT_CMP_EQ {
                    print!("!= ");
                }
                if let Some(names) = ct_state_names(&ctx.bw_mask, sep) {
                    print!("{}", names);
                } else {
                    format_value(
                        &ctx.bw_mask,
                        ctx.field,
                        ctx.meta_key,
                        ctx.ct_key,
                        ctx.proto_ctx,
                    );
                }
            } else if ctx.has_bitwise
                && ctx.field == FieldId::TcpFlags
                && (op == NFT_CMP_EQ || op == NFT_CMP_NEQ)
            {
                if let Some(mask) = ctx.bw_mask.first().copied() {
                    if let Some(mask_str) = tcp_flags_str(mask, true) {
                        print!("& {} ", mask_str);
                    }
                }
                if op == NFT_CMP_NEQ {
                    print!("!= ");
                } else {
                    print!("== ");
                }
                format_value(
                    &cmp_data,
                    ctx.field,
                    ctx.meta_key,
                    ctx.ct_key,
                    ctx.proto_ctx,
                );
            } else {
                if op == NFT_CMP_NEQ {
                    print!("!= ");
                }

                // Print value with CIDR if bitwise
                if ctx.has_bitwise
                    && matches!(
                        ctx.field,
                        FieldId::IpSaddr | FieldId::IpDaddr | FieldId::Ip6Saddr | FieldId::Ip6Daddr
                    )
                {
                    format_value(
                        &cmp_data,
                        ctx.field,
                        ctx.meta_key,
                        ctx.ct_key,
                        ctx.proto_ctx,
                    );
                    let prefix = mask_to_prefix(&ctx.bw_mask);
                    let max_prefix = if matches!(ctx.field, FieldId::IpSaddr | FieldId::IpDaddr) {
                        32
                    } else {
                        128
                    };
                    if prefix != max_prefix {
                        print!("/{}", prefix);
                    }
                } else {
                    format_value(
                        &cmp_data,
                        ctx.field,
                        ctx.meta_key,
                        ctx.ct_key,
                        ctx.proto_ctx,
                    );
                }
            }

            if ctx.field == FieldId::IpProto && cmp_data.len() == 1 {
                ctx.proto_ctx = cmp_data[0];
                ctx.generic_transport_ctx = false;
                ctx.family_hint = Some(NFPROTO_IPV4);
            }
            if ctx.meta_key == Some(NFT_META_L4PROTO) && cmp_data.len() == 1 {
                ctx.proto_ctx = cmp_data[0];
                ctx.generic_transport_ctx = false;
            }
            if ctx.meta_key == Some(NFT_META_NFPROTO) && cmp_data.len() == 1 {
                if cmp_data[0] == NFPROTO_IPV4 || cmp_data[0] == NFPROTO_IPV6 {
                    ctx.family_hint = Some(cmp_data[0]);
                }
            }
            ctx.clear();
        }
        "immediate" => {
            let dreg = data
                .iter()
                .find(|(t, _)| *t == NFTA_IMM_DREG)
                .map(|(_, v)| attr_u32_be(v))
                .unwrap_or(0);
            if dreg == NFT_REG_VERDICT {
                if let Some((_, imm_data)) = data.iter().find(|(t, _)| *t == NFTA_IMM_DATA) {
                    let inner = parse_attrs(imm_data);
                    if let Some((_, verdict_data)) =
                        inner.iter().find(|(t, _)| *t == NFTA_DATA_VERDICT)
                    {
                        let vattrs = parse_attrs(verdict_data);
                        let code = vattrs
                            .iter()
                            .find(|(t, _)| *t == NFTA_VERDICT_CODE)
                            .map(|(_, v)| attr_i32_be(v))
                            .unwrap_or(0);
                        let chain = vattrs
                            .iter()
                            .find(|(t, _)| *t == NFTA_VERDICT_CHAIN)
                            .map(|(_, v)| attr_str(v).to_string());

                        let chain_str = chain.unwrap_or_default();
                        if code == NFT_JUMP || code == NFT_GOTO {
                            if let Some(rules) = bound_registry.chains.get(&chain_str) {
                                if !*first {
                                    print!(" ");
                                }
                                *first = false;
                                print!("{} {{\n", if code == NFT_JUMP { "jump" } else { "goto" });
                                let nested_indent = format!("{}\t", indent);
                                for rule in rules {
                                    print_rule_with_sets_indent(
                                        rule,
                                        show_handle,
                                        stateless,
                                        registry,
                                        bound_registry,
                                        &nested_indent,
                                    );
                                }
                                print!("{}}}", indent);
                                return;
                            }
                        }
                        if !*first {
                            print!(" ");
                        }
                        *first = false;
                        // Use unified verdict renderer; for jump/goto it
                        // already appends the chain name, so don't print
                        // the chain twice.
                        print!("{}", verdict_str(code, &chain_str));
                    }
                }
            } else if let Some((_, imm_data)) = data.iter().find(|(t, _)| *t == NFTA_IMM_DATA) {
                let inner = parse_attrs(imm_data);
                if let Some((_, value)) = inner.iter().find(|(t, _)| *t == NFTA_DATA_VALUE) {
                    ctx.reg_values.insert(dreg, value.clone());
                    ctx.stash_current_left();
                    let term = match value.len() {
                        1 => format!("{}", value[0]),
                        2 => format!("{}", u16::from_be_bytes([value[0], value[1]])),
                        4 => format!("{}", Ipv4Addr::new(value[0], value[1], value[2], value[3])),
                        16 => {
                            let mut a = [0u8; 16];
                            a.copy_from_slice(&value[..16]);
                            format!("{}", Ipv6Addr::from(a))
                        }
                        _ => value
                            .iter()
                            .map(|b| format!("{:02x}", b))
                            .collect::<String>(),
                    };
                    ctx.field = FieldId::Unknown;
                    ctx.meta_key = None;
                    ctx.ct_key = None;
                    ctx.fib_result = None;
                    ctx.fib_flags = 0;
                    ctx.has_bitwise = false;
                    ctx.lhs_terms.push(term);
                }
            }
        }
        "objref" => {
            let kind = data
                .iter()
                .find(|(t, _)| *t == NFTA_OBJREF_IMM_TYPE)
                .map(|(_, v)| attr_u32_be(v))
                .unwrap_or(0);
            let name = data
                .iter()
                .find(|(t, _)| *t == NFTA_OBJREF_IMM_NAME)
                .map(|(_, v)| attr_str(v).to_string())
                .unwrap_or_default();
            if !*first {
                print!(" ");
            }
            *first = false;
            match kind {
                3 => print!("ct helper set \"{}\"", name),
                7 => print!("ct timeout set \"{}\"", name),
                9 => print!("ct expectation set \"{}\"", name),
                1 => print!("counter name \"{}\"", name),
                2 => print!("quota name \"{}\"", name),
                4 => print!("limit name \"{}\"", name),
                _ => print!("objref name \"{}\"", name),
            }
        }
        "flow_offload" => {
            let name = data
                .iter()
                .find(|(t, _)| *t == NFTA_FLOW_TABLE_NAME)
                .map(|(_, v)| attr_str(v).to_string())
                .unwrap_or_default();
            if !*first {
                print!(" ");
            }
            *first = false;
            print!("flow add @{}", name);
        }
        "lookup" => {
            let set_name = data
                .iter()
                .find(|(t, _)| *t == NFTA_LOOKUP_SET)
                .map(|(_, v)| attr_str(v).to_string())
                .unwrap_or_default();
            let flags = data
                .iter()
                .find(|(t, _)| *t == NFTA_LOOKUP_FLAGS)
                .map(|(_, v)| attr_u32_be(v))
                .unwrap_or(0);
            let dreg = data
                .iter()
                .find(|(t, _)| *t == NFTA_LOOKUP_DREG)
                .map(|(_, v)| attr_u32_be(v));
            // DREG=NFT_REG_VERDICT marks a verdict-map lookup. Upstream
            // renders these as `<key> vmap <rhs>`, never as a bare set
            // membership. A lookup without DREG is a plain set-membership
            // check.
            let is_vmap = matches!(dreg, Some(r) if r == NFT_REG_VERDICT);
            let is_data_map = matches!(dreg, Some(r) if r != NFT_REG_VERDICT);
            let is_anon = set_name.starts_with("__set") || set_name.starts_with("__map");
            if is_data_map {
                let rhs = match registry.sets.get(&set_name) {
                    Some(info) if is_anon => format!("map {{ {} }}", format_anon_map_elems(info)),
                    _ => format!("map @{}", set_name),
                };
                let prefix = ctx.assign_rhs.take().unwrap_or_else(|| {
                    let concat_count = registry
                        .sets
                        .get(&set_name)
                        .map(|info| concat_type_parts(info.key_type).len())
                        .unwrap_or(1);
                    ctx.take_left_expr(concat_count).unwrap_or_default()
                });
                ctx.assign_rhs = Some(if prefix.is_empty() {
                    rhs
                } else {
                    format!("{} {}", prefix, rhs)
                });
                ctx.clear();
                return;
            }
            if !*first {
                print!(" ");
            }
            *first = false;
            let concat_count = registry
                .sets
                .get(&set_name)
                .map(|info| concat_type_parts(info.key_type).len())
                .unwrap_or(1);
            let left = ctx.take_left_expr(concat_count);
            if let Some(left) = left.as_ref() {
                print!("{} ", left);
            }
            if flags & NFT_LOOKUP_F_INV != 0 {
                print!("!= ");
            }
            if is_vmap {
                print!("vmap ");
            }
            // Anonymous sets render inline — upstream `nft list` prints
            // the element literal the rule contained, not the synthetic
            // `__setN` / `__mapN` name. Named sets stay as `@name`. A
            // single-value anon set drops the braces — that's how
            // upstream prints it and the test framework's diff is
            // sensitive to the bare form.
            match registry.sets.get(&set_name) {
                Some(info) if is_anon => {
                    if info.is_map {
                        if info.verdicts.is_empty() && !info.data_values.is_empty() {
                            print!("{{ {} }}", format_anon_map_elems(info));
                        } else {
                            print!("{{ {} }}", format_anon_vmap_elems(info));
                        }
                    } else if should_inline_single_anon_set(info) {
                        let (k, end) = &info.elements[0];
                        if let Some(e) = end {
                            print!(
                                "{}",
                                format_interval_key(info.key_type, info.key_len, k, Some(e))
                            );
                        } else {
                            print!("{}", format_set_key(info.key_type, info.key_len, k));
                        }
                    } else {
                        print!("{{ {} }}", format_anon_set_elems(info));
                    }
                }
                _ => {
                    print!("@{}", set_name);
                }
            }
            if left.as_deref() == Some("meta l4proto") {
                if let Some(info) = registry.sets.get(&set_name) {
                    let is_tcp_udp = info.key_type == 12
                        && info.elements.len() == 2
                        && info.elements[0].1.is_none()
                        && info.elements[1].1.is_none()
                        && info.elements[0].0 == vec![6]
                        && info.elements[1].0 == vec![17];
                    if is_tcp_udp {
                        ctx.generic_transport_ctx = true;
                    }
                }
            }
            ctx.clear();
        }
        "dynset" => {
            let set_name = data
                .iter()
                .find(|(t, _)| *t == NFTA_DYNSET_SET_NAME)
                .map(|(_, v)| attr_str(v).to_string())
                .unwrap_or_default();
            let op = data
                .iter()
                .find(|(t, _)| *t == NFTA_DYNSET_OP)
                .map(|(_, v)| attr_u32_be(v))
                .unwrap_or(NFT_DYNSET_OP_ADD);
            let timeout_ms = data
                .iter()
                .find(|(t, _)| *t == NFTA_DYNSET_TIMEOUT)
                .map(|(_, v)| attr_u64_be(v))
                .unwrap_or(0);
            if !*first {
                print!(" ");
            }
            *first = false;
            let concat_count = registry
                .sets
                .get(&set_name)
                .map(|info| concat_type_parts(info.key_type).len())
                .unwrap_or(1);
            let data_count = registry
                .sets
                .get(&set_name)
                .map(|info| concat_type_parts(info.data_type).len())
                .unwrap_or(1);
            let has_data = data.iter().any(|(t, _)| *t == NFTA_DYNSET_SREG_DATA);
            print!(
                "{}",
                if op == NFT_DYNSET_OP_UPDATE {
                    "update"
                } else {
                    "add"
                }
            );
            print!(" @{} {{ ", set_name);
            if has_data {
                let parts = ctx.left_terms();
                let needed = concat_count + data_count;
                if parts.len() >= needed {
                    let key_start = parts.len() - needed;
                    let key_end = key_start + concat_count;
                    print!("{}", parts[key_start..key_end].join(" . "));
                    print!(" : {}", parts[key_end..].join(" . "));
                } else if let Some(left) = ctx.take_left_expr(needed) {
                    print!("{}", left);
                }
            } else if let Some(left) = ctx.take_left_expr(concat_count) {
                print!("{}", left);
            }
            if timeout_ms > 0 {
                print!(" timeout {}", format_timeout_ms(timeout_ms));
            }
            print!(" }}");
            ctx.clear();
        }
        "counter" => {
            if stateless {
                return;
            }
            let pkts = data
                .iter()
                .find(|(t, _)| *t == NFTA_COUNTER_PACKETS)
                .map(|(_, v)| attr_u64_be(v))
                .unwrap_or(0);
            let bytes = data
                .iter()
                .find(|(t, _)| *t == NFTA_COUNTER_BYTES)
                .map(|(_, v)| attr_u64_be(v))
                .unwrap_or(0);
            if !*first {
                print!(" ");
            }
            *first = false;
            print!("counter packets {} bytes {}", pkts, bytes);
        }
        "log" => {
            if !*first {
                print!(" ");
            }
            *first = false;
            print!("log");
            if let Some((_, v)) = data.iter().find(|(t, _)| *t == NFTA_LOG_PREFIX) {
                print!(" prefix \"{}\"", attr_str(v));
            }
            if let Some((_, v)) = data.iter().find(|(t, _)| *t == NFTA_LOG_LEVEL) {
                let level = match attr_u32_be(v) {
                    NFT_LOGLEVEL_EMERG => "emerg",
                    NFT_LOGLEVEL_ALERT => "alert",
                    NFT_LOGLEVEL_CRIT => "crit",
                    NFT_LOGLEVEL_ERR => "err",
                    NFT_LOGLEVEL_WARNING => "warning",
                    NFT_LOGLEVEL_NOTICE => "notice",
                    NFT_LOGLEVEL_INFO => "info",
                    NFT_LOGLEVEL_DEBUG => "debug",
                    NFT_LOGLEVEL_AUDIT => "audit",
                    _ => "",
                };
                if !level.is_empty() && level != "warning" {
                    print!(" level {}", level);
                }
            }
            if let Some((_, v)) = data.iter().find(|(t, _)| *t == NFTA_LOG_FLAGS) {
                let flags = attr_u32_be(v);
                if flags == NF_LOG_MASK {
                    print!(" flags all");
                } else {
                    let ordered = [
                        (NF_LOG_TCPSEQ, "tcp sequence"),
                        (NF_LOG_TCPOPT, "tcp options"),
                        (NF_LOG_IPOPT, "ip options"),
                        (NF_LOG_UID, "skuid"),
                        (NF_LOG_MACDECODE, "ether"),
                    ];
                    for (bit, text) in ordered {
                        if flags & bit != 0 {
                            print!(" flags {}", text);
                        }
                    }
                }
            }
        }
        "numgen" => {
            let mode = data
                .iter()
                .find(|(t, _)| *t == NFTA_NG_TYPE)
                .map(|(_, v)| attr_u32_be(v))
                .unwrap_or(NFT_NG_INCREMENTAL);
            let modulus = data
                .iter()
                .find(|(t, _)| *t == NFTA_NG_MODULUS)
                .map(|(_, v)| attr_u32_be(v))
                .unwrap_or(0);
            let offset = data
                .iter()
                .find(|(t, _)| *t == NFTA_NG_OFFSET)
                .map(|(_, v)| attr_u32_be(v))
                .unwrap_or(0);
            let mode_str = match mode {
                NFT_NG_RANDOM => "random",
                _ => "inc",
            };
            let mut text = format!("numgen {} mod {}", mode_str, modulus);
            if offset != 0 {
                text.push_str(&format!(" offset {}", offset));
            }
            ctx.assign_rhs = Some(text);
            ctx.clear();
        }
        "byteorder" => {}
        "hash" => {
            let hash_type = data
                .iter()
                .find(|(t, _)| *t == NFTA_HASH_TYPE)
                .map(|(_, v)| attr_u32_be(v))
                .unwrap_or(NFT_HASH_JENKINS);
            let modulus = data
                .iter()
                .find(|(t, _)| *t == NFTA_HASH_MODULUS)
                .map(|(_, v)| attr_u32_be(v))
                .unwrap_or(0);
            ctx.queue_hash_desc = match hash_type {
                NFT_HASH_SYM => Some(format!("symhash mod {}", modulus)),
                NFT_HASH_JENKINS => ctx
                    .take_all_left_expr()
                    .map(|left| format!("jhash {} mod {}", left, modulus)),
                _ => None,
            };
            ctx.clear();
        }
        "queue" => {
            let num = data
                .iter()
                .find(|(t, _)| *t == NFTA_QUEUE_NUM)
                .map(|(_, v)| attr_u16_be(v));
            let total = data
                .iter()
                .find(|(t, _)| *t == NFTA_QUEUE_TOTAL)
                .map(|(_, v)| attr_u16_be(v));
            let flags = data
                .iter()
                .find(|(t, _)| *t == NFTA_QUEUE_FLAGS)
                .map(|(_, v)| attr_u16_be(v))
                .unwrap_or(0);
            let has_sreg_qnum = data.iter().any(|(t, _)| *t == NFTA_QUEUE_SREG_QNUM);
            if !*first {
                print!(" ");
            }
            *first = false;
            print!("queue");
            if let Some(flag_text) = queue_flags_str(flags) {
                print!(" flags {}", flag_text);
            }
            print!(" to ");
            if has_sreg_qnum {
                if let Some(desc) = ctx.queue_hash_desc.take() {
                    print!("{}", desc);
                } else if let Some(rhs) = ctx.assign_rhs.take() {
                    print!("{}", rhs);
                } else {
                    print!("0");
                }
            } else if let Some(num) = num {
                if let Some(total) = total.filter(|total| *total > 1) {
                    let end = num.saturating_add(total).saturating_sub(1);
                    print!("{}-{}", num, end);
                } else {
                    print!("{}", num);
                }
            } else {
                print!("0");
            }
            ctx.clear();
        }
        "tproxy" => {
            let family = data
                .iter()
                .find(|(t, _)| *t == NFTA_TPROXY_FAMILY)
                .map(|(_, v)| attr_u32_be(v) as u8)
                .unwrap_or(NFPROTO_UNSPEC);
            let addr = data
                .iter()
                .find(|(t, _)| *t == NFTA_TPROXY_REG_ADDR)
                .and_then(|(_, v)| ctx.reg_values.get(&attr_u32_be(v)).cloned());
            let port = data
                .iter()
                .find(|(t, _)| *t == NFTA_TPROXY_REG_PORT)
                .and_then(|(_, v)| ctx.reg_values.get(&attr_u32_be(v)).cloned());
            if !*first {
                print!(" ");
            }
            *first = false;
            print!("tproxy");
            match family {
                NFPROTO_IPV4 => print!(" ip"),
                NFPROTO_IPV6 => print!(" ip6"),
                _ => {}
            }
            if let Some(addr_bytes) = addr {
                print!(" to ");
                if family == NFPROTO_IPV6 && addr_bytes.len() == 16 {
                    print!("[{}]", format_set_key(8, 16, &addr_bytes));
                } else if addr_bytes.len() == 4 {
                    print!("{}", format_set_key(7, 4, &addr_bytes));
                } else if addr_bytes.len() == 16 {
                    print!("{}", format_set_key(8, 16, &addr_bytes));
                }
                if let Some(port_bytes) = port {
                    print!(":{}", format_set_key(13, 2, &port_bytes));
                }
            } else if let Some(port_bytes) = port {
                print!(" to :{}", format_set_key(13, 2, &port_bytes));
            }
            ctx.clear();
        }
        "limit" => {
            let rate = data
                .iter()
                .find(|(t, _)| *t == NFTA_LIMIT_RATE)
                .map(|(_, v)| attr_u64_be(v))
                .unwrap_or(0);
            let unit = data
                .iter()
                .find(|(t, _)| *t == NFTA_LIMIT_UNIT)
                .map(|(_, v)| attr_u64_be(v))
                .unwrap_or(1);
            let burst = data
                .iter()
                .find(|(t, _)| *t == NFTA_LIMIT_BURST)
                .map(|(_, v)| attr_u32_be(v))
                .unwrap_or(0);
            if !*first {
                print!(" ");
            }
            *first = false;
            let unit_str = match unit {
                1 => "second",
                60 => "minute",
                3600 => "hour",
                86400 => "day",
                604800 => "week",
                _ => "second",
            };
            print!("limit rate {}/{}", rate, unit_str);
            if burst > 0 {
                print!(" burst {} packets", burst);
            }
        }
        "nat" => {
            let nat_type = data
                .iter()
                .find(|(t, _)| *t == NFTA_NAT_TYPE)
                .map(|(_, v)| attr_u32_be(v))
                .unwrap_or(0);
            if !*first {
                print!(" ");
            }
            *first = false;
            print!(
                "{}",
                if nat_type == NFT_NAT_SNAT {
                    "snat"
                } else {
                    "dnat"
                }
            );
        }
        "masq" => {
            if !*first {
                print!(" ");
            }
            *first = false;
            print!("masquerade");
        }
        "notrack" => {
            if !*first {
                print!(" ");
            }
            *first = false;
            print!("notrack");
        }
        "reject" => {
            if !*first {
                print!(" ");
            }
            *first = false;
            print!("reject");
            let rej_type = data
                .iter()
                .find(|(t, _)| *t == NFTA_REJECT_TYPE)
                .map(|(_, v)| attr_u32_be(v));
            let icmp_code = data
                .iter()
                .find(|(t, _)| *t == NFTA_REJECT_ICMP_CODE)
                .and_then(|(_, v)| v.first().copied());
            match (rej_type, icmp_code) {
                (Some(NFT_REJECT_TCP_RST), _) => print!(" with tcp reset"),
                (Some(NFT_REJECT_ICMPX_UNREACH), Some(NFT_REJECT_ICMPX_PORT_UNREACH)) => {
                    if ctx.family_hint == Some(NFPROTO_IPV6) {
                        print!(" with icmpv6 port-unreachable");
                    }
                }
                (Some(NFT_REJECT_ICMP_UNREACH), Some(ICMP6_DST_UNREACH_NOPORT)) => {
                    print!(" with icmpv6 port-unreachable");
                }
                (Some(NFT_REJECT_ICMPX_UNREACH), Some(NFT_REJECT_ICMPX_NO_ROUTE)) => {
                    print!(" with icmpx no-route")
                }
                (Some(NFT_REJECT_ICMPX_UNREACH), Some(NFT_REJECT_ICMPX_HOST_UNREACH)) => {
                    print!(" with icmpx host-unreachable")
                }
                (Some(NFT_REJECT_ICMPX_UNREACH), Some(NFT_REJECT_ICMPX_ADMIN_PROHIBITED)) => {
                    print!(" with icmpx admin-prohibited")
                }
                _ => {}
            }
        }
        _ => {} // skip unknown
    }
}

fn format_value(
    data: &[u8],
    field: FieldId,
    meta_key: Option<u32>,
    ct_key: Option<u32>,
    proto_ctx: u8,
) {
    // IPv4 address
    if matches!(field, FieldId::IpSaddr | FieldId::IpDaddr) && data.len() == 4 {
        print!("{}", Ipv4Addr::new(data[0], data[1], data[2], data[3]));
        return;
    }
    // IPv6 address
    if matches!(field, FieldId::Ip6Saddr | FieldId::Ip6Daddr) && data.len() == 16 {
        let mut octets = [0u8; 16];
        octets.copy_from_slice(data);
        print!("{}", Ipv6Addr::from(octets));
        return;
    }
    if field == FieldId::Ip6Hoplimit && data.len() == 1 {
        print!("{}", data[0]);
        return;
    }
    // Port
    if matches!(
        field,
        FieldId::TcpSport | FieldId::TcpDport | FieldId::UdpSport | FieldId::UdpDport
    ) && data.len() == 2
    {
        print!("{}", u16::from_be_bytes([data[0], data[1]]));
        return;
    }
    if field == FieldId::TcpFlags && data.len() == 1 {
        if let Some(flags) = tcp_flags_str(data[0], false) {
            print!("{}", flags);
        } else {
            print!("{}", data[0]);
        }
        return;
    }
    // Protocol
    if matches!(field, FieldId::IpProto | FieldId::Ip6NextHdr) || meta_key == Some(NFT_META_L4PROTO)
    {
        if data.len() == 1 {
            print!(
                "{}",
                match data[0] {
                    6 => "tcp",
                    17 => "udp",
                    1 => "icmp",
                    2 => "igmp",
                    58 => "ipv6-icmp",
                    _ => {
                        print!("{}", data[0]);
                        return;
                    }
                }
            );
            return;
        }
    }
    if meta_key == Some(NFT_META_NFPROTO) && data.len() == 1 {
        if let Some(name) = nfproto_name(data[0]) {
            print!("{}", name);
        } else {
            print!("{}", data[0]);
        }
        return;
    }
    if field == FieldId::IcmpType && data.len() == 1 {
        if proto_ctx == 58 {
            if let Some(name) = icmpv6_type_name(data[0]) {
                print!("{}", name);
            } else {
                print!("{}", data[0]);
            }
        } else if let Some(name) = icmp_type_name(data[0]) {
            print!("{}", name);
        } else {
            print!("{}", data[0]);
        }
        return;
    }
    // CT state
    if ct_key == Some(NFT_CT_STATE) && data.len() >= 4 {
        if let Some(names) = ct_state_names(data, ",") {
            print!("{}", names);
        } else {
            print!(
                "{}",
                u32::from_ne_bytes([data[0], data[1], data[2], data[3]])
            );
        }
        return;
    }
    // Interface name
    if meta_key == Some(NFT_META_IIFNAME) || meta_key == Some(NFT_META_OIFNAME) {
        print!("\"{}\"", attr_str(data));
        return;
    }
    if (meta_key == Some(NFT_META_IIF) || meta_key == Some(NFT_META_OIF)) && data.len() == 4 {
        let idx = u32::from_be_bytes([data[0], data[1], data[2], data[3]]);
        if let Some(name) = iface_name_from_index(idx) {
            print!("\"{}\"", name);
        } else {
            print!("{}", idx);
        }
        return;
    }
    if meta_key == Some(NFT_META_MARK) && data.len() == 4 {
        print!(
            "0x{:08x}",
            u32::from_be_bytes([data[0], data[1], data[2], data[3]])
        );
        return;
    }
    if ct_key == Some(NFT_CT_HELPER) {
        print!("\"{}\"", attr_str(data));
        return;
    }
    // Generic
    if data.len() == 1 {
        print!("{}", data[0]);
    } else if data.len() == 2 {
        print!("{}", u16::from_be_bytes([data[0], data[1]]));
    } else if data.len() == 4 {
        print!(
            "{}",
            u32::from_be_bytes([data[0], data[1], data[2], data[3]])
        );
    } else {
        for b in data {
            print!("{:02x}", b);
        }
    }
}

fn mask_to_prefix(mask: &[u8]) -> u32 {
    let mut bits = 0u32;
    for &b in mask {
        for i in (0..8).rev() {
            if b & (1 << i) != 0 {
                bits += 1;
            } else {
                return bits;
            }
        }
    }
    bits
}

// ── JSON output ─────────────────────────────────────────────────
//
// Emit a cut-down but spec-shaped nftables JSON envelope. Tables,
// chains, and sets render as real JSON records; rules carry a "raw"
// string field with the text-rendered form (a truly compliant
// `expr` array would require a second full serializer for every
// expression type, which is a separate project). Tools that only
// want to enumerate tables/chains work out of the box; tools that
// introspect rule internals still need text parsing, but at least
// `-j` produces valid JSON now instead of a parse error.

// Render one set element's key bytes as the JSON scalar libnftables
// uses: IPv4 as dotted-quad, TCP/UDP service as integer, inet_proto
// as a protocol name, everything else as an integer literal.
fn format_set_elem_value(key_type: u32, data: &[u8]) -> String {
    if is_concat_type(key_type) {
        let mut offset = 0usize;
        let mut parts: Vec<String> = Vec::new();
        for field_type in concat_type_parts(key_type) {
            let field_len = set_type_len(field_type) as usize;
            let padded = padded_key_len(field_len as u32) as usize;
            if offset + padded > data.len() {
                break;
            }
            parts.push(format_set_elem_value(
                field_type,
                &data[offset..offset + field_len],
            ));
            offset += padded;
        }
        return format!("[{}]", parts.join(", "));
    }
    match key_type {
        7 /* ipv4_addr */ if data.len() == 4 =>
            format!("\"{}.{}.{}.{}\"", data[0], data[1], data[2], data[3]),
        13 /* inet_service */ if data.len() == 2 =>
            format!("{}", u16::from_be_bytes([data[0], data[1]])),
        12 /* inet_proto */ if data.len() == 1 => match data[0] {
            6 => "\"tcp\"".into(), 17 => "\"udp\"".into(),
            1 => "\"icmp\"".into(), 2 => "\"igmp\"".into(), 58 => "\"icmpv6\"".into(),
            n => format!("{}", n),
        },
        _ => {
            // Fallback: integer from whatever byte width we got.
            let mut v: u64 = 0;
            for b in data.iter().take(8) { v = (v << 8) | *b as u64; }
            format!("{}", v)
        }
    }
}

fn json_escape(s: &str) -> String {
    let mut out = String::with_capacity(s.len() + 2);
    for c in s.chars() {
        match c {
            '"' => out.push_str("\\\""),
            '\\' => out.push_str("\\\\"),
            '\n' => out.push_str("\\n"),
            '\r' => out.push_str("\\r"),
            '\t' => out.push_str("\\t"),
            c if (c as u32) < 0x20 => out.push_str(&format!("\\u{:04x}", c as u32)),
            c => out.push(c),
        }
    }
    out
}

/// Walks the expression stream inside a rule and emits JSON
/// fragments. Upstream libnftables fuses the `payload`/`meta`/`ct`
/// load + optional `bitwise` mask + `cmp` triple into a single
/// `{"match": {"left": ..., "right": ..., "op": "=="}}` object;
/// standalone expressions (verdict, counter, log, masquerade) emit
/// one fragment each. This is the small state machine that keeps
/// track of the load-side of a pending match.
struct ExprJsonCtx {
    // Left side of the pending match, if a payload/meta/ct load has
    // been seen. Stored as a JSON fragment (e.g.
    // `"left": {"payload": {"protocol": "ip", "field": "saddr"}}`).
    pending_left: Option<String>,
    field: FieldId,
    proto_ctx: u8,
    meta_key: Option<u32>,
    ct_key: Option<u32>,
    bw_mask: Option<Vec<u8>>,
    anon_sets: AnonSetRegistry,
}

impl ExprJsonCtx {
    fn new() -> Self {
        ExprJsonCtx {
            pending_left: None,
            field: FieldId::Unknown,
            proto_ctx: 0,
            meta_key: None,
            ct_key: None,
            bw_mask: None,
            anon_sets: AnonSetRegistry::default(),
        }
    }

    fn clear(&mut self) {
        self.pending_left = None;
        self.field = FieldId::Unknown;
        self.meta_key = None;
        self.ct_key = None;
        self.bw_mask = None;
    }

    /// Consume one netlink expression. Returns zero or more JSON
    /// object fragments to push to the rule's expr array.
    fn consume(&mut self, name: &str, data: &[(u16, Vec<u8>)]) -> Vec<String> {
        match name {
            "payload" => {
                let base = data
                    .iter()
                    .find(|(t, _)| *t == NFTA_PAYLOAD_BASE)
                    .map(|(_, v)| attr_u32_be(v))
                    .unwrap_or(0);
                let off = data
                    .iter()
                    .find(|(t, _)| *t == NFTA_PAYLOAD_OFFSET)
                    .map(|(_, v)| attr_u32_be(v))
                    .unwrap_or(0);
                let len = data
                    .iter()
                    .find(|(t, _)| *t == NFTA_PAYLOAD_LEN)
                    .map(|(_, v)| attr_u32_be(v))
                    .unwrap_or(0);
                self.field = identify_payload(base, off, len);
                self.meta_key = None;
                self.ct_key = None;
                self.bw_mask = None;
                let (proto, field) = match self.field {
                    FieldId::IpSaddr => ("ip", "saddr"),
                    FieldId::IpDaddr => ("ip", "daddr"),
                    FieldId::IpProto => ("ip", "protocol"),
                    FieldId::Ip6Saddr => ("ip6", "saddr"),
                    FieldId::Ip6Daddr => ("ip6", "daddr"),
                    FieldId::Ip6NextHdr => ("ip6", "nexthdr"),
                    FieldId::Ip6Hoplimit => ("ip6", "hoplimit"),
                    FieldId::TcpSport if self.proto_ctx == 17 => ("udp", "sport"),
                    FieldId::TcpSport => ("tcp", "sport"),
                    FieldId::TcpDport if self.proto_ctx == 17 => ("udp", "dport"),
                    FieldId::TcpDport => ("tcp", "dport"),
                    FieldId::TcpFlags => ("tcp", "flags"),
                    FieldId::UdpSport => ("udp", "sport"),
                    FieldId::UdpDport => ("udp", "dport"),
                    FieldId::IcmpType => ("icmp", "type"),
                    FieldId::IcmpCode => ("icmp", "code"),
                    FieldId::Unknown => {
                        self.pending_left = None;
                        return Vec::new();
                    }
                };
                self.pending_left = Some(format!(
                    "{{\"payload\": {{\"protocol\": \"{}\", \"field\": \"{}\"}}}}",
                    proto, field
                ));
                Vec::new()
            }
            "meta" => {
                self.meta_key = data
                    .iter()
                    .find(|(t, _)| *t == NFTA_META_KEY)
                    .map(|(_, v)| attr_u32_be(v));
                self.field = FieldId::Unknown;
                self.ct_key = None;
                self.bw_mask = None;
                if let Some(k) = self.meta_key {
                    let key = match k {
                        NFT_META_IIFNAME => "iifname",
                        NFT_META_OIFNAME => "oifname",
                        NFT_META_IIF => "iif",
                        NFT_META_OIF => "oif",
                        NFT_META_MARK => "mark",
                        NFT_META_L4PROTO => "l4proto",
                        NFT_META_NFPROTO => "nfproto",
                        NFT_META_PKTTYPE => "pkttype",
                        NFT_META_SKUID => "skuid",
                        NFT_META_SKGID => "skgid",
                        NFT_META_LEN => "length",
                        NFT_META_PROTOCOL => "protocol",
                        _ => {
                            self.pending_left = None;
                            return Vec::new();
                        }
                    };
                    self.pending_left = Some(format!("{{\"meta\": {{\"key\": \"{}\"}}}}", key));
                }
                Vec::new()
            }
            "ct" => {
                self.ct_key = data
                    .iter()
                    .find(|(t, _)| *t == NFTA_CT_KEY)
                    .map(|(_, v)| attr_u32_be(v));
                self.field = FieldId::Unknown;
                self.meta_key = None;
                self.bw_mask = None;
                if let Some(k) = self.ct_key {
                    let key = match k {
                        NFT_CT_STATE => "state",
                        NFT_CT_MARK => "mark",
                        NFT_CT_STATUS => "status",
                        NFT_CT_DIRECTION => "direction",
                        NFT_CT_PROTOCOL => "protocol",
                        NFT_CT_L3PROTOCOL => "l3proto",
                        NFT_CT_BYTES => "bytes",
                        NFT_CT_PKTS => "packets",
                        NFT_CT_EXPIRATION => "expiration",
                        _ => {
                            self.pending_left = None;
                            return Vec::new();
                        }
                    };
                    self.pending_left = Some(format!("{{\"ct\": {{\"key\": \"{}\"}}}}", key));
                }
                Vec::new()
            }
            "bitwise" => {
                if let Some((_, v)) = data.iter().find(|(t, _)| *t == NFTA_BITWISE_MASK) {
                    let inner = parse_attrs(v);
                    if let Some((_, m)) = inner.iter().find(|(t, _)| *t == NFTA_DATA_VALUE) {
                        self.bw_mask = Some(m.clone());
                    }
                }
                Vec::new()
            }
            "lookup" => {
                let set_name = data
                    .iter()
                    .find(|(t, _)| *t == NFTA_LOOKUP_SET)
                    .map(|(_, v)| attr_str(v).to_string())
                    .unwrap_or_default();
                let flags = data
                    .iter()
                    .find(|(t, _)| *t == NFTA_LOOKUP_FLAGS)
                    .map(|(_, v)| attr_u32_be(v))
                    .unwrap_or(0);
                let dreg = data
                    .iter()
                    .find(|(t, _)| *t == NFTA_LOOKUP_DREG)
                    .map(|(_, v)| attr_u32_be(v));
                let is_vmap = matches!(dreg, Some(r) if r == NFT_REG_VERDICT);
                let left = self.pending_left.take();
                self.clear();
                let op = if flags & NFT_LOOKUP_F_INV != 0 {
                    "!="
                } else {
                    "=="
                };
                let is_anon = set_name.starts_with("__set") || set_name.starts_with("__map");
                // Anonymous sets inline as {"set": [...]} per
                // libnftables; named sets stay as `@name`. Vmaps
                // wrap the `vmap` verb around whichever rhs form.
                let rhs_inline = if is_anon {
                    self.anon_sets
                        .sets
                        .get(&set_name)
                        .map(|info| {
                            if info.is_map {
                                let mut parts: Vec<String> = Vec::new();
                                for (i, (start, _)) in info.elements.iter().enumerate() {
                                    let k = format_set_elem_value(info.key_type, start);
                                    let (code, chain) =
                                        info.verdicts.get(i).cloned().unwrap_or((0, String::new()));
                                    let v = json_verdict(code, &chain);
                                    parts.push(format!("[{}, {}]", k, v));
                                }
                                format!("{{\"set\": [{}]}}", parts.join(", "))
                            } else if info.elements.len() == 1 && info.elements[0].1.is_none() {
                                // Single-value anon set drops the `{"set": []}`
                                // wrapper — upstream renders `"right": "1.1.1.1"`
                                // for `ip saddr { 1.1.1.1 }`.
                                format_set_elem_value(info.key_type, &info.elements[0].0)
                            } else {
                                let mut parts: Vec<String> = Vec::new();
                                for (start, end) in &info.elements {
                                    let s_str = format_set_elem_value(info.key_type, start);
                                    match end {
                                        Some(e) if e != start => {
                                            let e_str = format_set_elem_value(info.key_type, e);
                                            parts.push(format!(
                                                "{{\"range\": [{}, {}]}}",
                                                s_str, e_str
                                            ));
                                        }
                                        _ => parts.push(s_str),
                                    }
                                }
                                format!("{{\"set\": [{}]}}", parts.join(", "))
                            }
                        })
                        .unwrap_or_else(|| format!("\"@{}\"", json_escape(&set_name)))
                } else {
                    format!("\"@{}\"", json_escape(&set_name))
                };
                let right = if is_vmap {
                    // Upstream emits {"vmap": {"key": <left>, "data": <rhs>}}
                    // as the full match object. We assemble both halves
                    // below because we already have the left in hand.
                    rhs_inline
                } else {
                    rhs_inline
                };
                match (left, is_vmap) {
                    (Some(l), true) => vec![format!(
                        "{{\"vmap\": {{\"key\": {}, \"data\": {}}}}}",
                        l, right
                    )],
                    (Some(l), false) => vec![format!(
                        "{{\"match\": {{\"op\": \"{}\", \"left\": {}, \"right\": {}}}}}",
                        op, l, right
                    )],
                    (None, _) => Vec::new(),
                }
            }
            "cmp" => {
                let op = data
                    .iter()
                    .find(|(t, _)| *t == NFTA_CMP_OP)
                    .map(|(_, v)| attr_u32_be(v))
                    .unwrap_or(0);
                let cmp_data = data
                    .iter()
                    .find(|(t, _)| *t == NFTA_CMP_DATA)
                    .map(|(_, v)| {
                        let inner = parse_attrs(v);
                        inner
                            .iter()
                            .find(|(t, _)| *t == NFTA_DATA_VALUE)
                            .map(|(_, d)| d.clone())
                            .unwrap_or_default()
                    })
                    .unwrap_or_default();
                let left = self.pending_left.take();
                let mut proto_update = None;
                if self.field == FieldId::IpProto && cmp_data.len() == 1 {
                    proto_update = Some(cmp_data[0]);
                }

                // Capture state snapshot BEFORE clearing so the
                // bitmask/ct-state fusion and json_right can still see
                // the payload/meta/ct context.
                let had_bitwise = self.bw_mask.is_some();
                let bw_mask = self.bw_mask.clone();
                let ct_key = self.ct_key;
                let meta_key = self.meta_key;

                let op_str = match op {
                    NFT_CMP_EQ => "==",
                    NFT_CMP_NEQ => "!=",
                    NFT_CMP_LT => "<",
                    NFT_CMP_LTE => "<=",
                    NFT_CMP_GT => ">",
                    NFT_CMP_GTE => ">=",
                    _ => "==",
                };

                // Compute right side using the current ctx (before we
                // clear) so payload/meta/ct fields resolve correctly.
                let right = self.json_right(&cmp_data);

                self.clear();
                if let Some(p) = proto_update {
                    self.proto_ctx = p;
                }
                if meta_key == Some(NFT_META_L4PROTO) && cmp_data.len() == 1 {
                    self.proto_ctx = cmp_data[0];
                }

                // ct state bitmask triple: `ct` load + bitwise(mask) +
                // cmp(neq|eq, 0). `neq 0` matches "any bit of mask
                // set" → `op: in`; `eq 0` matches "no bit set" → the
                // negation, rendered as `op: !=`.
                if had_bitwise
                    && ct_key == Some(NFT_CT_STATE)
                    && (op == NFT_CMP_NEQ || op == NFT_CMP_EQ)
                {
                    if let (Some(l), Some(mask)) = (left, bw_mask) {
                        let r = format_ct_state_json(&mask);
                        let json_op = if op == NFT_CMP_NEQ { "in" } else { "!=" };
                        return vec![format!(
                            "{{\"match\": {{\"op\": \"{}\", \"left\": {}, \"right\": {}}}}}",
                            json_op, l, r
                        )];
                    }
                    return Vec::new();
                }

                match (left, right) {
                    (Some(l), Some(r)) => vec![format!(
                        "{{\"match\": {{\"op\": \"{}\", \"left\": {}, \"right\": {}}}}}",
                        op_str, l, r
                    )],
                    _ => Vec::new(),
                }
            }
            "immediate" => {
                let dreg = data
                    .iter()
                    .find(|(t, _)| *t == NFTA_IMM_DREG)
                    .map(|(_, v)| attr_u32_be(v))
                    .unwrap_or(0);
                if dreg != NFT_REG_VERDICT {
                    return Vec::new();
                }
                let imm_data = match data.iter().find(|(t, _)| *t == NFTA_IMM_DATA) {
                    Some((_, v)) => v,
                    None => return Vec::new(),
                };
                let inner = parse_attrs(imm_data);
                let verdict_data = match inner.iter().find(|(t, _)| *t == NFTA_DATA_VERDICT) {
                    Some((_, v)) => v,
                    None => return Vec::new(),
                };
                let vattrs = parse_attrs(verdict_data);
                let code = vattrs
                    .iter()
                    .find(|(t, _)| *t == NFTA_VERDICT_CODE)
                    .map(|(_, v)| attr_i32_be(v))
                    .unwrap_or(0);
                let chain = vattrs
                    .iter()
                    .find(|(t, _)| *t == NFTA_VERDICT_CHAIN)
                    .map(|(_, v)| attr_str(v).to_string());
                let v = match code {
                    NF_ACCEPT => "accept",
                    NF_DROP => "drop",
                    NFT_RETURN => "return",
                    NFT_CONTINUE => "continue",
                    NFT_JUMP => "jump",
                    NFT_GOTO => "goto",
                    _ => return Vec::new(),
                };
                if code == NFT_JUMP || code == NFT_GOTO {
                    if let Some(c) = chain {
                        return vec![format!(
                            "{{\"{}\": {{\"target\": \"{}\"}}}}",
                            v,
                            json_escape(&c)
                        )];
                    }
                    return Vec::new();
                }
                vec![format!("{{\"{}\": null}}", v)]
            }
            "counter" => {
                let pkts = data
                    .iter()
                    .find(|(t, _)| *t == NFTA_COUNTER_PACKETS)
                    .map(|(_, v)| attr_u64_be(v))
                    .unwrap_or(0);
                let bytes = data
                    .iter()
                    .find(|(t, _)| *t == NFTA_COUNTER_BYTES)
                    .map(|(_, v)| attr_u64_be(v))
                    .unwrap_or(0);
                vec![format!(
                    "{{\"counter\": {{\"packets\": {}, \"bytes\": {}}}}}",
                    pkts, bytes
                )]
            }
            "log" => {
                let prefix = data
                    .iter()
                    .find(|(t, _)| *t == NFTA_LOG_PREFIX)
                    .map(|(_, v)| attr_str(v).to_string());
                let level = data
                    .iter()
                    .find(|(t, _)| *t == NFTA_LOG_LEVEL)
                    .map(|(_, v)| match attr_u32_be(v) {
                        NFT_LOGLEVEL_EMERG => "emerg",
                        NFT_LOGLEVEL_ALERT => "alert",
                        NFT_LOGLEVEL_CRIT => "crit",
                        NFT_LOGLEVEL_ERR => "err",
                        NFT_LOGLEVEL_WARNING => "warning",
                        NFT_LOGLEVEL_NOTICE => "notice",
                        NFT_LOGLEVEL_INFO => "info",
                        NFT_LOGLEVEL_DEBUG => "debug",
                        NFT_LOGLEVEL_AUDIT => "audit",
                        _ => "",
                    })
                    .filter(|s| !s.is_empty() && *s != "warning")
                    .map(|s| s.to_string());
                let flags = data
                    .iter()
                    .find(|(t, _)| *t == NFTA_LOG_FLAGS)
                    .map(|(_, v)| attr_u32_be(v));
                if prefix.is_none() && level.is_none() && flags.is_none() {
                    vec!["{\"log\": null}".to_string()]
                } else {
                    let mut parts = Vec::new();
                    if let Some(p) = prefix {
                        parts.push(format!("\"prefix\": \"{}\"", json_escape(&p)));
                    }
                    if let Some(level) = level {
                        parts.push(format!("\"level\": \"{}\"", level));
                    }
                    if let Some(flags) = flags {
                        if flags == NF_LOG_MASK {
                            parts.push("\"flags\": \"all\"".to_string());
                        }
                    }
                    vec![format!("{{\"log\": {{{}}}}}", parts.join(", "))]
                }
            }
            "masq" | "masquerade" => vec!["{\"masquerade\": null}".to_string()],
            "notrack" => vec!["{\"notrack\": null}".to_string()],
            "reject" => vec!["{\"reject\": null}".to_string()],
            _ => Vec::new(),
        }
    }

    /// Format the right-hand side of a `match` based on what kind of
    /// left was seen. IPv4 addresses get printed as `"10.0.0.1"`,
    /// ports as bare integers, interface names as quoted strings, and
    /// numeric keys (mark, skuid, etc.) as decimal integers.
    fn json_right(&self, data: &[u8]) -> Option<String> {
        if matches!(self.field, FieldId::IpSaddr | FieldId::IpDaddr) && data.len() == 4 {
            // If a bitwise mask was seen it's a CIDR; render as
            // {"prefix": {"addr": "x.x.x.x", "len": N}}.
            if let Some(mask) = &self.bw_mask {
                let len = mask_to_prefix(mask);
                return Some(format!(
                    "{{\"prefix\": {{\"addr\": \"{}.{}.{}.{}\", \"len\": {}}}}}",
                    data[0], data[1], data[2], data[3], len
                ));
            }
            return Some(format!(
                "\"{}.{}.{}.{}\"",
                data[0], data[1], data[2], data[3]
            ));
        }
        if matches!(
            self.field,
            FieldId::TcpSport | FieldId::TcpDport | FieldId::UdpSport | FieldId::UdpDport
        ) && data.len() == 2
        {
            return Some(format!("{}", u16::from_be_bytes([data[0], data[1]])));
        }
        if matches!(self.field, FieldId::IpProto | FieldId::Ip6NextHdr)
            || self.meta_key == Some(NFT_META_L4PROTO)
        {
            if data.len() == 1 {
                return Some(match data[0] {
                    6 => "\"tcp\"".into(),
                    17 => "\"udp\"".into(),
                    1 => "\"icmp\"".into(),
                    2 => "\"igmp\"".into(),
                    58 => "\"icmpv6\"".into(),
                    n => format!("{}", n),
                });
            }
        }
        if self.meta_key == Some(NFT_META_IIFNAME) || self.meta_key == Some(NFT_META_OIFNAME) {
            let s = attr_str(data);
            return Some(format!("\"{}\"", json_escape(s)));
        }
        if self.ct_key == Some(NFT_CT_STATE) && data.len() >= 4 {
            let state = u32::from_ne_bytes([data[0], data[1], data[2], data[3]]);
            let mut parts: Vec<&str> = Vec::new();
            if state & 1 != 0 {
                parts.push("invalid");
            }
            if state & 2 != 0 {
                parts.push("established");
            }
            if state & 4 != 0 {
                parts.push("related");
            }
            if state & 8 != 0 {
                parts.push("new");
            }
            if state & 64 != 0 {
                parts.push("untracked");
            }
            if parts.len() == 1 {
                return Some(format!("\"{}\"", parts[0]));
            }
            let items: Vec<String> = parts.iter().map(|s| format!("\"{}\"", s)).collect();
            return Some(format!("[{}]", items.join(", ")));
        }
        // Generic numeric fallback.
        match data.len() {
            1 => Some(format!("{}", data[0])),
            2 => Some(format!("{}", u16::from_be_bytes([data[0], data[1]]))),
            4 => Some(format!(
                "{}",
                u32::from_be_bytes([data[0], data[1], data[2], data[3]])
            )),
            _ => None,
        }
    }
}

fn family_name(fam: u8) -> &'static str {
    // Kernel NFPROTO_* values — keep in sync with netlink.rs.
    // UNSPEC=0 INET=1 IPV4=2 ARP=3 NETDEV=5 BRIDGE=7 IPV6=10.
    match fam {
        2 => "ip",
        10 => "ip6",
        1 => "inet",
        3 => "arp",
        5 => "netdev",
        7 => "bridge",
        _ => "unknown",
    }
}

pub struct JsonOut {
    first: bool,
}

impl JsonOut {
    pub fn begin() -> Self {
        // Match upstream libnftables-json's spacing: a single space after
        // every ':' and ',' on the single-line form. The test framework's
        // json-sanitize-ruleset.sh regex anchors on that spacing and on a
        // purely-numeric version string ([0-9.]+), so version gets just
        // "0.1.1" with no "stormwall-" prefix.
        print!("{{\"nftables\": [");
        print!("{{\"metainfo\": {{\"version\": \"0.1.1\", \"release_name\": \"stormwall\", \"json_schema_version\": 1}}}}");
        JsonOut { first: false }
    }

    fn sep(&mut self) {
        if self.first {
            self.first = false;
        } else {
            print!(", ");
        }
    }

    pub fn table(&mut self, family: u8, attrs: &[(u16, Vec<u8>)]) {
        let name = attrs
            .iter()
            .find(|(t, _)| *t == NFTA_TABLE_NAME)
            .map(|(_, v)| attr_str(v))
            .unwrap_or("");
        let handle = attrs
            .iter()
            .find(|(t, _)| *t == NFTA_TABLE_HANDLE)
            .map(|(_, v)| attr_u64_be(v))
            .unwrap_or(0);
        let flags = attrs
            .iter()
            .find(|(t, _)| *t == NFTA_TABLE_FLAGS)
            .map(|(_, v)| attr_u32_be(v))
            .unwrap_or(0);
        self.sep();
        print!(
            "{{\"table\": {{\"family\": \"{}\", \"name\": \"{}\", \"handle\": {}",
            family_name(family),
            json_escape(name),
            handle
        );
        // libnftables emits a single flag as a bare string; only
        // when more than one is set does it switch to an array.
        // Today DORMANT is the only commonly-reported table flag.
        if flags & NFT_TABLE_F_DORMANT != 0 {
            print!(", \"flags\": [\"dormant\"]");
        }
        print!("}}}}");
    }

    pub fn chain(&mut self, family: u8, table: &str, attrs: &[(u16, Vec<u8>)]) {
        let name = attrs
            .iter()
            .find(|(t, _)| *t == NFTA_CHAIN_NAME)
            .map(|(_, v)| attr_str(v))
            .unwrap_or("");
        let handle = attrs
            .iter()
            .find(|(t, _)| *t == NFTA_CHAIN_HANDLE)
            .map(|(_, v)| attr_u64_be(v))
            .unwrap_or(0);
        self.sep();
        print!(
            "{{\"chain\": {{\"family\": \"{}\", \"table\": \"{}\", \"name\": \"{}\", \"handle\": {}",
            family_name(family), json_escape(table), json_escape(name), handle
        );
        // Upstream libnftables base-chain order (as emitted by
        // json_chain.c for NFT_CHAIN_BASE): dev, type, hook, prio,
        // policy. dev appears before type when an ingress/egress
        // chain has NFTA_HOOK_DEV.
        let hook_data = attrs
            .iter()
            .find(|(t, _)| *t == NFTA_CHAIN_HOOK)
            .map(|(_, v)| v);
        let hattrs = hook_data.map(|hd| parse_attrs(hd));
        if let Some(ref ha) = hattrs {
            if let Some((_, v)) = ha.iter().find(|(t, _)| *t == NFTA_HOOK_DEV) {
                print!(", \"dev\": \"{}\"", json_escape(attr_str(v)));
            }
        }
        if let Some((_, v)) = attrs.iter().find(|(t, _)| *t == NFTA_CHAIN_TYPE) {
            print!(", \"type\": \"{}\"", json_escape(attr_str(v)));
        }
        if let Some(ref ha) = hattrs {
            if let Some((_, v)) = ha.iter().find(|(t, _)| *t == NFTA_HOOK_HOOKNUM) {
                let h = attr_u32_be(v);
                let hn = hook_str_family(h, family);
                print!(", \"hook\": \"{}\"", hn);
            }
            if let Some((_, v)) = ha.iter().find(|(t, _)| *t == NFTA_HOOK_PRIORITY) {
                print!(", \"prio\": {}", attr_i32_be(v));
            }
        }
        if let Some((_, v)) = attrs.iter().find(|(t, _)| *t == NFTA_CHAIN_POLICY) {
            let p = attr_u32_be(v);
            let name = if p == 1 { "accept" } else { "drop" };
            print!(", \"policy\": \"{}\"", name);
        }
        print!("}}}}");
    }

    /// Emit a rule as JSON. Renders the rule skeleton plus an `expr`
    /// array where each expression gets its own structured object for
    /// the kinds we recognise (verdict, counter, log). More complex
    /// expressions (payload/meta comparisons, set lookups, bitwise ops)
    /// are still pending a full serializer; for now they contribute a
    /// `{}` placeholder so the array shape matches upstream.
    pub fn rule(
        &mut self,
        family: u8,
        table: &str,
        chain: &str,
        attrs: &[(u16, Vec<u8>)],
        _show_handles: bool,
        _stateless: bool,
    ) {
        self.rule_with_sets(
            family,
            table,
            chain,
            attrs,
            _show_handles,
            _stateless,
            &AnonSetRegistry::default(),
        );
    }

    pub fn rule_with_sets(
        &mut self,
        family: u8,
        table: &str,
        chain: &str,
        attrs: &[(u16, Vec<u8>)],
        _show_handles: bool,
        _stateless: bool,
        registry: &AnonSetRegistry,
    ) {
        let handle = attrs
            .iter()
            .find(|(t, _)| *t == NFTA_RULE_HANDLE)
            .map(|(_, v)| attr_u64_be(v))
            .unwrap_or(0);
        self.sep();
        print!(
            "{{\"rule\": {{\"family\": \"{}\", \"table\": \"{}\", \"chain\": \"{}\", \"handle\": {}",
            family_name(family), json_escape(table), json_escape(chain), handle
        );

        if let Some((_, ud)) = attrs.iter().find(|(t, _)| *t == NFTA_RULE_USERDATA) {
            let mut i = 0usize;
            while i + 2 <= ud.len() {
                let ty = ud[i];
                let ln = ud[i + 1] as usize;
                i += 2;
                if i + ln > ud.len() {
                    break;
                }
                if ty == 0 {
                    let s = &ud[i..i + ln];
                    let t = s
                        .iter()
                        .take_while(|&&b| b != 0)
                        .copied()
                        .collect::<Vec<u8>>();
                    if let Ok(txt) = std::str::from_utf8(&t) {
                        print!(", \"comment\": \"{}\"", json_escape(txt));
                    }
                    break;
                }
                i += ln;
            }
        }

        if let Some((_, exprs_data)) = attrs.iter().find(|(t, _)| *t == NFTA_RULE_EXPRESSIONS) {
            print!(", \"expr\": [");
            let elems = parse_attrs(exprs_data);
            let decoded: Vec<(String, Vec<(u16, Vec<u8>)>)> = elems
                .iter()
                .map(|(_, ed)| {
                    let a = parse_attrs(ed);
                    let n = a
                        .iter()
                        .find(|(t, _)| *t == NFTA_EXPR_NAME)
                        .map(|(_, v)| attr_str(v).to_string())
                        .unwrap_or_default();
                    let d = a
                        .iter()
                        .find(|(t, _)| *t == NFTA_EXPR_DATA)
                        .map(|(_, v)| parse_attrs(v))
                        .unwrap_or_default();
                    (n, d)
                })
                .collect();
            let (skip, proto_hint) = compute_l4proto_elision(&decoded);

            let mut ctx = ExprJsonCtx::new();
            ctx.anon_sets = registry.clone();
            if let Some(p) = proto_hint {
                ctx.proto_ctx = p;
            }
            let mut first_expr = true;
            for (i, (name, data_attrs)) in decoded.iter().enumerate() {
                if skip[i] {
                    continue;
                }
                let out = ctx.consume(name, data_attrs);
                for frag in out {
                    if !first_expr {
                        print!(", ");
                    }
                    first_expr = false;
                    print!("{}", frag);
                }
            }
            print!("]");
        }

        print!("}}}}");
    }

    pub fn set_pairs(
        &mut self,
        family: u8,
        table: &str,
        attrs: &[(u16, Vec<u8>)],
        pairs: &[(Vec<u8>, Option<Vec<u8>>)],
    ) {
        let name = attrs
            .iter()
            .find(|(t, _)| *t == NFTA_SET_NAME)
            .map(|(_, v)| attr_str(v))
            .unwrap_or("");
        let key_type = attrs
            .iter()
            .find(|(t, _)| *t == NFTA_SET_KEY_TYPE)
            .map(|(_, v)| attr_u32_be(v))
            .unwrap_or(0);
        let data_type = attrs
            .iter()
            .find(|(t, _)| *t == NFTA_SET_DATA_TYPE)
            .map(|(_, v)| attr_u32_be(v));
        let handle = attrs
            .iter()
            .find(|(t, _)| *t == NFTA_SET_HANDLE)
            .map(|(_, v)| attr_u64_be(v))
            .unwrap_or(0);
        let flags = attrs
            .iter()
            .find(|(t, _)| *t == NFTA_SET_FLAGS)
            .map(|(_, v)| attr_u32_be(v))
            .unwrap_or(0);
        self.sep();
        let kind = if flags & NFT_SET_MAP != 0 {
            "map"
        } else {
            "set"
        };
        print!(
            "{{\"{}\": {{\"family\": \"{}\", \"name\": \"{}\", \"table\": \"{}\", \"type\": \"{}\"",
            kind,
            family_name(family),
            json_escape(name),
            json_escape(table),
            set_type_display_name(key_type)
        );
        print!(", \"handle\": {}", handle);
        if flags & NFT_SET_MAP != 0 {
            if let Some(dt) = data_type {
                print!(", \"map\": \"{}\"", set_type_display_name(dt));
            }
        }
        let mut flag_names: Vec<&str> = Vec::new();
        if flags & NFT_SET_CONSTANT != 0 {
            flag_names.push("constant");
        }
        if flags & NFT_SET_INTERVAL != 0 {
            flag_names.push("interval");
        }
        if flags & NFT_SET_TIMEOUT != 0 {
            flag_names.push("timeout");
        }
        if flags & NFT_SET_EVAL != 0 {
            flag_names.push("dynamic");
        }
        if !flag_names.is_empty() {
            print!(", \"flags\": [");
            for (i, n) in flag_names.iter().enumerate() {
                if i > 0 {
                    print!(", ");
                }
                print!("\"{}\"", n);
            }
            print!("]");
        }
        if !pairs.is_empty() {
            print!(", \"elem\": [");
            for (i, (start, end)) in pairs.iter().enumerate() {
                if i > 0 {
                    print!(", ");
                }
                match end {
                    Some(e) if e != start => {
                        // Emit CIDR form when aligned, else a range tuple.
                        if let Some(prefix) = try_cidr_prefix(start, e) {
                            if key_type == 7 && start.len() == 4 {
                                print!(
                                    "{{\"prefix\": {{\"addr\": \"{}.{}.{}.{}\", \"len\": {}}}}}",
                                    start[0], start[1], start[2], start[3], prefix
                                );
                                continue;
                            }
                        }
                        print!(
                            "{{\"range\": [{}, {}]}}",
                            format_set_elem_value(key_type, start),
                            format_set_elem_value(key_type, e)
                        );
                    }
                    _ => print!("{}", format_set_elem_value(key_type, start)),
                }
            }
            print!("]");
        }
        print!("}}}}");
    }

    pub fn set(&mut self, family: u8, table: &str, attrs: &[(u16, Vec<u8>)], elems: &[Vec<u8>]) {
        let name = attrs
            .iter()
            .find(|(t, _)| *t == NFTA_SET_NAME)
            .map(|(_, v)| attr_str(v))
            .unwrap_or("");
        let key_type = attrs
            .iter()
            .find(|(t, _)| *t == NFTA_SET_KEY_TYPE)
            .map(|(_, v)| attr_u32_be(v))
            .unwrap_or(0);
        let data_type = attrs
            .iter()
            .find(|(t, _)| *t == NFTA_SET_DATA_TYPE)
            .map(|(_, v)| attr_u32_be(v));
        let handle = attrs
            .iter()
            .find(|(t, _)| *t == NFTA_SET_HANDLE)
            .map(|(_, v)| attr_u64_be(v))
            .unwrap_or(0);
        let flags = attrs
            .iter()
            .find(|(t, _)| *t == NFTA_SET_FLAGS)
            .map(|(_, v)| attr_u32_be(v))
            .unwrap_or(0);
        self.sep();
        // libnftables JSON envelope is `"map"` for NFT_SET_MAP, else
        // `"set"`. Field order: family, name, table, type, [map],
        // handle, [flags], [elem].
        let kind = if flags & NFT_SET_MAP != 0 {
            "map"
        } else {
            "set"
        };
        print!(
            "{{\"{}\": {{\"family\": \"{}\", \"name\": \"{}\", \"table\": \"{}\", \"type\": \"{}\"",
            kind,
            family_name(family),
            json_escape(name),
            json_escape(table),
            set_type_display_name(key_type)
        );
        print!(", \"handle\": {}", handle);
        if flags & NFT_SET_MAP != 0 {
            if let Some(dt) = data_type {
                print!(", \"map\": \"{}\"", set_type_display_name(dt));
            }
        }
        // Human-readable flag names; upstream orders them
        // constant, interval, timeout, dynamic — match that.
        let mut flag_names: Vec<&str> = Vec::new();
        if flags & NFT_SET_CONSTANT != 0 {
            flag_names.push("constant");
        }
        if flags & NFT_SET_INTERVAL != 0 {
            flag_names.push("interval");
        }
        if flags & NFT_SET_TIMEOUT != 0 {
            flag_names.push("timeout");
        }
        if flags & NFT_SET_EVAL != 0 {
            flag_names.push("dynamic");
        }
        if !flag_names.is_empty() {
            print!(", \"flags\": [");
            for (i, n) in flag_names.iter().enumerate() {
                if i > 0 {
                    print!(", ");
                }
                print!("\"{}\"", n);
            }
            print!("]");
        }
        if !elems.is_empty() {
            print!(", \"elem\": [");
            let mut first = true;
            for data in elems {
                if !first {
                    print!(", ");
                }
                first = false;
                print!("{}", format_set_elem_value(key_type, data));
            }
            print!("]");
        }
        print!("}}}}");
    }

    pub fn end(self) {
        println!("]}}");
    }
}
